// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_BDelayedBy 11524
#define TAG_CBind 55652
#define TAG_CEmpty 30359
#define TAG_Catch 6517
#define TAG_HLocal 25864
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_MkSt 48854
#define TAG_Right 62770
#define TAG_SpId 35501
#define LBL_bind 9519364
#define LBL_ctx 308385
#define LBL_infos 301706655
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_selfKey 62480824
#define LBL_trace 311979359
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_len__names__locals__ctx[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx};
V g_heff_2eelab_2eenvironment_2ebindName(V, V, V);
V g_heff_2eelab_2eenvironment_2ebindName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ebindName_clo;
V g_heff_2eelab_2eenvironment_2ecatchE(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ecatchE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ecatchE_clo;
V g_heff_2eelab_2eenvironment_2eemptyCore_get(void);
V g_heff_2eelab_2eenvironment_2eemptyScope_get(void);
V g_heff_2eelab_2eenvironment_2eemptySt_get(void);
V g_heff_2eelab_2eenvironment_2emultiBind(V, V, V);
V g_heff_2eelab_2eenvironment_2emultiBind_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2emultiBind_clo;
V g_heff_2eelab_2eenvironment_2etryE(V, V, V);
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2etryE_clo;
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_std_2emap_2eempty_get(void);

static V g_heff_2eelab_2eenvironment_2eemptyScope_val;
static HEFF_ONCE g_heff_2eelab_2eenvironment_2eemptyScope_st;
static V g_heff_2eelab_2eenvironment_2eemptyScope_init(void) {
  return heff_rec_n(4, shape_len__names__locals__ctx, (V[]){MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_LNil), NTAG(TAG_CEmpty)});
}
V g_heff_2eelab_2eenvironment_2eemptyScope_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eenvironment_2eemptyScope_st)) return g_heff_2eelab_2eenvironment_2eemptyScope_val;
  return heff_global(&g_heff_2eelab_2eenvironment_2eemptyScope_val, &g_heff_2eelab_2eenvironment_2eemptyScope_st, g_heff_2eelab_2eenvironment_2eemptyScope_init);
}
V g_heff_2eelab_2eenvironment_2ebindName_lam0(V self, V *args);
V g_heff_2eelab_2eenvironment_2ebindName_lam1(V self, V *args);
Clo g_heff_2eelab_2eenvironment_2ebindName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2ebindName_entry, 3, 0};

V g_heff_2eelab_2eenvironment_2ebindName(V v_x_240, V v_a_241, V v_c_242) {
top: ;
  V v_len_243 = heff_take_field(v_c_242, 0);
  V v_names_244 = heff_take_field(v_c_242, 1);
  V v_locals_245 = heff_take_field(v_c_242, 2);
  V v_ctx_246 = heff_get_n(v_c_242, 3, 4);
  V v_v_248 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(v_len_243)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eenvironment_2ebindName_lam0, 1, 1, (V[]){heff_dup(v_a_241)}), NTAG(TAG_Nothing)));
  V v_t_249 = heff_tag_n(TAG_CBind, 3, (V[]){v_ctx_246, heff_tag_n(TAG_BDelayedBy, 1, (V[]){MK_INT(0LL)}), v_a_241});
  return heff_rec_n(4, shape_len__names__locals__ctx, (V[]){heff_intAdd(v_len_243, MK_INT(1LL)), heff_tag_n(TAG_Cons, 2, (V[]){v_x_240, v_names_244}), heff_tag_n(TAG_LSnoc, 2, (V[]){v_locals_245, heff_clo_n(g_heff_2eelab_2eenvironment_2ebindName_lam1, 1, 1, (V[]){v_v_248})}), v_t_249});
}
V g_heff_2eelab_2eenvironment_2ebindName_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eenvironment_2ebindName(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eenvironment_2ebindName_lam0(V self, V *args) {
  V v_u_247 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_247);
  return v_a_241;
}
V g_heff_2eelab_2eenvironment_2ebindName_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  V v_v_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2410);
  return v_v_248;
}
Clo g_heff_2eelab_2eenvironment_2emultiBind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2emultiBind_entry, 3, 0};

V g_heff_2eelab_2eenvironment_2emultiBind(V v_x1_240, V v_x2_241, V v_s_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_s_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return v_s_242;
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x2_241, 0);
      V v_args_246 = heff_field(v_x2_241, 1);
      V v_t_247 = (g_heff_2eelab_2eenvironment_2ebindName(heff_dup(v_x_243), heff_dup(v_a_245), v_s_242));
      V t_0 = v_xs_244;
      V t_1 = v_args_246;
      V t_2 = v_t_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_s_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eenvironment_2emultiBind_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eenvironment_2emultiBind(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2eenvironment_2ewithBound_lam0(V self, V *args);
V g_heff_2eelab_2eenvironment_2ewithBound_lam1(V self, V *args);
V g_heff_2eelab_2eenvironment_2ewithBound_lam2(V self, V *args);
Clo g_heff_2eelab_2eenvironment_2ewithBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2ewithBound_entry, 4, 0};

V g_heff_2eelab_2eenvironment_2ewithBound(V v_x_240, V v_a_241, V v_c_242, V v_action_243) {
top: ;
  V v_len_244 = heff_take_field(v_c_242, 0);
  V v_names_245 = heff_take_field(v_c_242, 1);
  V v_locals_246 = heff_take_field(v_c_242, 2);
  V v_ctx_247 = heff_get_n(v_c_242, 3, 4);
  V v_t_249 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(v_len_244)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eenvironment_2ewithBound_lam0, 1, 1, (V[]){heff_dup(v_a_241)}), NTAG(TAG_Nothing)));
  V v_v_2411 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(v_len_244)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eenvironment_2ewithBound_lam1, 1, 1, (V[]){heff_dup(v_a_241)}), NTAG(TAG_Nothing)));
  V v_t_2412 = heff_tag_n(TAG_CBind, 3, (V[]){v_ctx_247, heff_tag_n(TAG_BDelayedBy, 1, (V[]){MK_INT(0LL)}), v_a_241});
  V v_t_2414 = heff_rec_n(4, shape_len__names__locals__ctx, (V[]){heff_intAdd(v_len_244, MK_INT(1LL)), heff_tag_n(TAG_Cons, 2, (V[]){v_x_240, v_names_245}), heff_tag_n(TAG_LSnoc, 2, (V[]){v_locals_246, heff_clo_n(g_heff_2eelab_2eenvironment_2ewithBound_lam2, 1, 1, (V[]){v_v_2411})}), v_t_2412});
  return heff_tail(v_action_243, 2, (V[]){v_t_249, v_t_2414});
}
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eenvironment_2ewithBound(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eenvironment_2ewithBound_lam0(V self, V *args) {
  V v_u_248 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  return v_a_241;
}
V g_heff_2eelab_2eenvironment_2ewithBound_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2410);
  return v_a_241;
}
V g_heff_2eelab_2eenvironment_2ewithBound_lam2(V self, V *args) {
  V v_u_2413 = args[0];
  V v_v_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_v_2411;
}

static V g_heff_2eelab_2eenvironment_2eemptyCore_val;
static HEFF_ONCE g_heff_2eelab_2eenvironment_2eemptyCore_st;
static V g_heff_2eelab_2eenvironment_2eemptyCore_init(void) {
  return heff_rec_n(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing)});
}
V g_heff_2eelab_2eenvironment_2eemptyCore_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eenvironment_2eemptyCore_st)) return g_heff_2eelab_2eenvironment_2eemptyCore_val;
  return heff_global(&g_heff_2eelab_2eenvironment_2eemptyCore_val, &g_heff_2eelab_2eenvironment_2eemptyCore_st, g_heff_2eelab_2eenvironment_2eemptyCore_init);
}

static V g_heff_2eelab_2eenvironment_2eemptySt_val;
static HEFF_ONCE g_heff_2eelab_2eenvironment_2eemptySt_st;
static V g_heff_2eelab_2eenvironment_2eemptySt_init(void) {
  return heff_tag_n(TAG_MkSt, 3, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyCore_get()), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2eenvironment_2eemptySt_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eenvironment_2eemptySt_st)) return g_heff_2eelab_2eenvironment_2eemptySt_val;
  return heff_global(&g_heff_2eelab_2eenvironment_2eemptySt_val, &g_heff_2eelab_2eenvironment_2eemptySt_st, g_heff_2eelab_2eenvironment_2eemptySt_init);
}
V g_heff_2eelab_2eenvironment_2ecatchE_lam0(V self, V *args);
Clo g_heff_2eelab_2eenvironment_2ecatchE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2ecatchE_entry, 4, 0};

V g_heff_2eelab_2eenvironment_2ecatchE(V v_m_240, V v_h_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_244 = heff_tr(heff_call(v_m_240, 2, (V[]){heff_dup(v_hd_242), heff_dup(heff_rfield(v_hd_242, 0))}));
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_244, heff_clo_n(g_heff_2eelab_2eenvironment_2ecatchE_lam0, 1, 2, (V[]){v_h_241, heff_dup(v_hd_242)})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_248}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_249, v_k2_243});
}
V g_heff_2eelab_2eenvironment_2ecatchE_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eenvironment_2ecatchE(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eenvironment_2ecatchE_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_h_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_246 = heff_tr(heff_call(v_h_241, 1, (V[]){v_s_245}));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eenvironment_2etryE_lam0(V self, V *args);
V g_heff_2eelab_2eenvironment_2etryE_lam1(V self, V *args);
Clo g_heff_2eelab_2eenvironment_2etryE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2etryE_entry, 3, 0};

V g_heff_2eelab_2eenvironment_2etryE(V v_m_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_244 = heff_tr(heff_call(v_m_240, 2, (V[]){heff_dup(v_hd_241), heff_clo_n(g_heff_2eelab_2eenvironment_2etryE_lam0, 1, 1, (V[]){heff_dup(v_hd_241)})}));
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_244, heff_clo_n(g_heff_2eelab_2eenvironment_2etryE_lam1, 1, 1, (V[]){heff_dup(v_hd_241)})})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_247}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_248, v_k2_242});
}
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eenvironment_2etryE(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eenvironment_2etryE_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_243});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eenvironment_2etryE_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_s_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}