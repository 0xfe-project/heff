// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArms 12052
#define TAG_MkArmsVals 35622
#define TAG_MkRes 5766
#define TAG_MkResVals 58586
#define TAG_MkSeen 11336
#define TAG_MkSeenVals 17452
#define TAG_MkTest 41567
#define TAG_Unreached 46435
#define TAG_Within 10658
#define LBL_body 9524841
#define LBL_calls 295783919
#define LBL_changed 970801394
#define LBL_consts 592362651
#define LBL_defs 9574869
#define LBL_fix 310927
#define LBL_gathered 1327153563
#define LBL_ints 9732907
#define LBL_key 315609
#define LBL_marking 1071112247
#define LBL_marks 305024864
#define LBL_name 9869138
#define LBL_params 951713969
#define LBL_ranges 1008858625
#define LBL_tests 311609915
#define LBL_words 314676931
static uint32_t shape_calls__marks[] = {LBL_calls, LBL_marks};
static uint32_t shape_defs__words[] = {LBL_defs, LBL_words};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_params__consts__marking[] = {LBL_params, LBL_consts, LBL_marking};
static uint32_t shape_params__gathered__changed[] = {LBL_params, LBL_gathered, LBL_changed};
static uint32_t shape_ranges__tests[] = {LBL_ranges, LBL_tests};
V g_heff_2ecompile_2eranges_2eanyRange_get(void);
V g_heff_2ecompile_2eranges_2ecalledIn(V, V, V, V);
V g_heff_2ecompile_2eranges_2ecalledIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ecalledIn_clo;
V g_heff_2ecompile_2eranges_2econdTests(V, V);
V g_heff_2ecompile_2eranges_2econdTests_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2econdTests_clo;
V g_heff_2ecompile_2eranges_2ecorners(V, V, V, V);
V g_heff_2ecompile_2eranges_2ecorners_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ecorners_clo;
V g_heff_2ecompile_2eranges_2ecorners_24tok1(V, V, V, V, V);
V g_heff_2ecompile_2eranges_2ecorners_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ecorners_24tok1_clo;
V g_heff_2ecompile_2eranges_2ecorners_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2eranges_2ecorners_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ecorners_24tok2_clo;
V g_heff_2ecompile_2eranges_2edivPositive_24tok1(V, V, V, V);
V g_heff_2ecompile_2eranges_2edivPositive_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2edivPositive_24tok1_clo;
V g_heff_2ecompile_2eranges_2eemptyEnv_get(void);
V g_heff_2ecompile_2eranges_2eemptySt_get(void);
V g_heff_2ecompile_2eranges_2egatherDef(V, V);
V g_heff_2ecompile_2eranges_2egatherDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egatherDef_clo;
V g_heff_2ecompile_2eranges_2egatherGo(V, V, V, V);
V g_heff_2ecompile_2eranges_2egatherGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egatherGo_clo;
V g_heff_2ecompile_2eranges_2ejoin(V, V);
V g_heff_2ecompile_2eranges_2ejoin_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ejoin_clo;
V g_heff_2ecompile_2eranges_2emarkRange(V, V);
V g_heff_2ecompile_2eranges_2emarkRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emarkRange_clo;
V g_heff_2ecompile_2eranges_2emarked(V, V, V, V);
V g_heff_2ecompile_2eranges_2emarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emarked_clo;
V g_heff_2ecompile_2eranges_2emeet(V, V);
V g_heff_2ecompile_2eranges_2emeet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emeet_clo;
V g_heff_2ecompile_2eranges_2emulR(V, V);
V g_heff_2ecompile_2eranges_2emulR_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emulR_clo;
V g_heff_2ecompile_2eranges_2enarrowWith(V, V, V, V);
V g_heff_2ecompile_2eranges_2enarrowWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowWith_clo;
V g_heff_2ecompile_2eranges_2enarrowing(V, V, V, V);
V g_heff_2ecompile_2eranges_2enarrowing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowing_clo;
V g_heff_2ecompile_2eranges_2eoperandRange(V, V, V);
V g_heff_2ecompile_2eranges_2eoperandRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eoperandRange_clo;
HeffT2 g_heff_2ecompile_2eranges_2eplaceOf_24cpr(V, V, V);
V g_heff_2ecompile_2eranges_2eprimRange(V, V);
V g_heff_2ecompile_2eranges_2eprimRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eprimRange_clo;
V g_heff_2ecompile_2eranges_2erangeEq(V, V);
V g_heff_2ecompile_2eranges_2erangeEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangeEq_clo;
V g_heff_2ecompile_2eranges_2erangedWith(V, V, V, V);
V g_heff_2ecompile_2eranges_2erangedWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangedWith_clo;
V g_heff_2ecompile_2eranges_2erangesEq(V, V);
V g_heff_2ecompile_2eranges_2erangesEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangesEq_clo;
V g_heff_2ecompile_2eranges_2erootGo(V, V, V);
V g_heff_2ecompile_2eranges_2erootGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erootGo_clo;
V g_heff_2ecompile_2eranges_2erootTo_24tok2(V, V, V, V);
V g_heff_2ecompile_2eranges_2erootTo_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erootTo_24tok2_clo;
V g_heff_2ecompile_2eranges_2esettled(V, V, V, V);
V g_heff_2ecompile_2eranges_2esettled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2esettled_clo;
V g_heff_2ecompile_2eranges_2etrimHigh(V, V);
V g_heff_2ecompile_2eranges_2etrimHigh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etrimHigh_clo;
V g_heff_2ecompile_2eranges_2etrimHigh_24tok2(V, V, V);
V g_heff_2ecompile_2eranges_2etrimHigh_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etrimHigh_24tok2_clo;
V g_heff_2ecompile_2eranges_2ewalkArms(V, V, V, V, V);
V g_heff_2ecompile_2eranges_2ewalkArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewalkArms_clo;
HeffT3 g_heff_2ecompile_2eranges_2ewalkArms_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2eranges_2ewalkDef(V, V);
V g_heff_2ecompile_2eranges_2ewalkDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewalkDef_clo;
HeffT2 g_heff_2ecompile_2eranges_2ewalkMany_24cpr(V, V, V);
V g_heff_2ecompile_2eranges_2ewidenLow(V, V, V);
V g_heff_2ecompile_2eranges_2ewidenLow_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewidenLow_clo;
V g_heff_2ecompile_2eranges_2ewithRange(V, V, V);
V g_heff_2ecompile_2eranges_2ewithRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewithRange_clo;
V g_list_2eall_24s853093203x77424416(V);
V g_list_2eall_24s853093203x77424416_entry(V self, V *a);
extern Clo g_list_2eall_24s853093203x77424416_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s213448614x618797387(V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s213448614x618797387_entry(V self, V *a);
extern Clo g_list_2efoldl_24s213448614x618797387_clo;
V g_list_2efoldl_24s510070423x219220408(V, V, V);
V g_list_2efoldl_24s510070423x219220408_entry(V self, V *a);
extern Clo g_list_2efoldl_24s510070423x219220408_clo;
V g_list_2efoldl_24s518632429x1911716206(V, V);
V g_list_2efoldl_24s518632429x1911716206_entry(V self, V *a);
extern Clo g_list_2efoldl_24s518632429x1911716206_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith_24s1026658656x682908126(V, V);
V g_list_2ezipWith_24s1026658656x682908126_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1026658656x682908126_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2ecompile_2eranges_2ejoin_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ejoin_entry, 2, 0};

V g_heff_2ecompile_2eranges_2ejoin(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Unreached: {
    return v_x2_241;
  }
  case TAG_Within: {
    V v_a_242 = heff_dup(heff_field(v_x1_240, 0));
    V v_b_243 = heff_dup(heff_field(v_x1_240, 1));
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Unreached: {
      heff_drop(v_a_242);
      heff_drop(v_b_243);
      return v_x1_240;
    }
    case TAG_Within: {
      V v_c_244 = heff_field(v_x2_241, 0);
      V v_d_245 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Within = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      heff_drop_tag(v_x1_240, 2);
      V v_t_249;
      switch (heff_tag_of(v_a_242)) {
      case TAG_Nothing: {
        heff_drop(v_c_244);
        v_t_249 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_a_246 = heff_field(v_a_242, 0);
        V v_ru_24a_242_24Just = heff_take_reuse_n(v_a_242, 1ULL, 1);
        switch (heff_tag_of(v_c_244)) {
        case TAG_Nothing: {
          heff_drop(v_a_246);
          heff_drop_cell(v_ru_24a_242_24Just, 1);
          v_t_249 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_b_247 = heff_field(v_c_244, 0);
          heff_take_n(v_c_244, 1ULL, 1);
          V v_t_248;
          if (heff_intLt_c_lent(v_a_246, v_b_247, 0)) {
            heff_drop(v_b_247);
            v_t_248 = v_a_246;
          } else {
            heff_drop(v_a_246);
            v_t_248 = v_b_247;
          }
          v_t_249 = heff_tag_at_n(v_ru_24a_242_24Just, TAG_Just, 1, (V[]){v_t_248});
          break;
        }
        default: heff_nomatch(v_c_244);
        }
        break;
      }
      default: heff_nomatch(v_a_242);
      }
      V v_t_2413;
      switch (heff_tag_of(v_b_243)) {
      case TAG_Nothing: {
        heff_drop(v_d_245);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_a_2410 = heff_field(v_b_243, 0);
        V v_ru_24b_243_24Just = heff_take_reuse_n(v_b_243, 1ULL, 1);
        switch (heff_tag_of(v_d_245)) {
        case TAG_Nothing: {
          heff_drop(v_a_2410);
          heff_drop_cell(v_ru_24b_243_24Just, 1);
          v_t_2413 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_b_2411 = heff_field(v_d_245, 0);
          heff_take_n(v_d_245, 1ULL, 1);
          V v_t_2412;
          if (heff_intLt_c_lent(v_a_2410, v_b_2411, 0)) {
            heff_drop(v_a_2410);
            v_t_2412 = v_b_2411;
          } else {
            heff_drop(v_b_2411);
            v_t_2412 = v_a_2410;
          }
          v_t_2413 = heff_tag_at_n(v_ru_24b_243_24Just, TAG_Just, 1, (V[]){v_t_2412});
          break;
        }
        default: heff_nomatch(v_d_245);
        }
        break;
      }
      default: heff_nomatch(v_b_243);
      }
      return heff_tag_at_n(v_ru_24x2_241_24Within, TAG_Within, 2, (V[]){v_t_249, v_t_2413});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eranges_2ejoin_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ejoin(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2emulR_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2emulR_entry, 2, 0};

V g_heff_2ecompile_2eranges_2emulR(V v_r_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_r_240)) {
  case TAG_Unreached: {
    heff_drop(v_s_241);
    return NTAG(TAG_Unreached);
  }
  case TAG_Within: {
    V v_r1_242 = heff_field(v_r_240, 0);
    V v_r2_243 = heff_field(v_r_240, 1);
    V v_ru_24r_240_24Within = heff_take_reuse_n(v_r_240, 3ULL, 2);
    switch (heff_tag_of(v_r1_242)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_s_241)) {
      case TAG_Unreached: {
        heff_drop(v_r2_243);
        heff_drop_cell(v_ru_24r_240_24Within, 2);
        return NTAG(TAG_Unreached);
      }
      case TAG_Within: {
        V v_c_244 = heff_field(v_s_241, 0);
        V v_d_245 = heff_field(v_s_241, 1);
        heff_take_n(v_s_241, 3ULL, 2);
        switch (heff_tag_of(v_r1_242)) {
        case TAG_Nothing: {
          heff_drop(v_r2_243);
          heff_drop_cell(v_ru_24r_240_24Within, 2);
          heff_drop(v_c_244);
          heff_drop(v_d_245);
          return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
        }
        case TAG_Just: {
          V v_a_246 = heff_dup(heff_field(v_r1_242, 0));
          if (heff_intLe_c(MK_INT(0LL), v_a_246)) {
            switch (heff_tag_of(v_c_244)) {
            case TAG_Nothing: {
              heff_drop_tag(v_r1_242, 1);
              heff_drop(v_r2_243);
              heff_drop_cell(v_ru_24r_240_24Within, 2);
              heff_drop(v_d_245);
              return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
            }
            case TAG_Just: {
              V v_a_247 = heff_dup(heff_field(v_c_244, 0));
              if (heff_intLe_c(MK_INT(0LL), v_a_247)) {
                V v_t_2410;
                switch (heff_tag_of(v_r1_242)) {
                case TAG_Nothing: {
                  heff_drop_tag(v_c_244, 1);
                  v_t_2410 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_a_248 = heff_field(v_r1_242, 0);
                  V v_ru_24r1_242_24Just = heff_take_reuse_n(v_r1_242, 1ULL, 1);
                  switch (heff_tag_of(v_c_244)) {
                  case TAG_Nothing: {
                    heff_drop(v_a_248);
                    heff_drop_cell(v_ru_24r1_242_24Just, 1);
                    v_t_2410 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_b_249 = heff_field(v_c_244, 0);
                    heff_take_n(v_c_244, 1ULL, 1);
                    v_t_2410 = heff_tag_at_n(v_ru_24r1_242_24Just, TAG_Just, 1, (V[]){heff_intMul(v_a_248, v_b_249)});
                    break;
                  }
                  default: heff_nomatch(v_c_244);
                  }
                  break;
                }
                default: heff_nomatch(v_r1_242);
                }
                V v_t_2413;
                switch (heff_tag_of(v_r2_243)) {
                case TAG_Nothing: {
                  heff_drop(v_d_245);
                  v_t_2413 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_a_2411 = heff_field(v_r2_243, 0);
                  V v_ru_24r2_243_24Just = heff_take_reuse_n(v_r2_243, 1ULL, 1);
                  switch (heff_tag_of(v_d_245)) {
                  case TAG_Nothing: {
                    heff_drop(v_a_2411);
                    heff_drop_cell(v_ru_24r2_243_24Just, 1);
                    v_t_2413 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_b_2412 = heff_field(v_d_245, 0);
                    heff_take_n(v_d_245, 1ULL, 1);
                    v_t_2413 = heff_tag_at_n(v_ru_24r2_243_24Just, TAG_Just, 1, (V[]){heff_intMul(v_a_2411, v_b_2412)});
                    break;
                  }
                  default: heff_nomatch(v_d_245);
                  }
                  break;
                }
                default: heff_nomatch(v_r2_243);
                }
                return heff_tag_at_n(v_ru_24r_240_24Within, TAG_Within, 2, (V[]){v_t_2410, v_t_2413});
              } else {
                heff_drop_tag(v_r1_242, 1);
                heff_drop(v_r2_243);
                heff_drop_cell(v_ru_24r_240_24Within, 2);
                heff_drop_tag(v_c_244, 1);
                heff_drop(v_d_245);
                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
            }
            default: return heff_nomatch(v_c_244);
            }
          } else {
            heff_drop_tag(v_r1_242, 1);
            heff_drop(v_r2_243);
            heff_drop_cell(v_ru_24r_240_24Within, 2);
            heff_drop(v_c_244);
            heff_drop(v_d_245);
            return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
        }
        default: return heff_nomatch(v_r1_242);
        }
      }
      default: return heff_nomatch(v_s_241);
      }
    }
    case TAG_Just: {
      V v_a_2414 = heff_dup(heff_field(v_r1_242, 0));
      switch (heff_tag_of(v_r2_243)) {
      case TAG_Nothing: {
        heff_drop(v_a_2414);
        switch (heff_tag_of(v_s_241)) {
        case TAG_Unreached: {
          heff_drop_tag(v_r1_242, 1);
          heff_drop_cell(v_ru_24r_240_24Within, 2);
          return NTAG(TAG_Unreached);
        }
        case TAG_Within: {
          V v_c_2415 = heff_field(v_s_241, 0);
          V v_d_2416 = heff_field(v_s_241, 1);
          heff_take_n(v_s_241, 3ULL, 2);
          switch (heff_tag_of(v_r1_242)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24r_240_24Within, 2);
            heff_drop(v_c_2415);
            heff_drop(v_d_2416);
            return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
          case TAG_Just: {
            V v_a_2417 = heff_dup(heff_field(v_r1_242, 0));
            if (heff_intLe_c(MK_INT(0LL), v_a_2417)) {
              switch (heff_tag_of(v_c_2415)) {
              case TAG_Nothing: {
                heff_drop_tag(v_r1_242, 1);
                heff_drop_cell(v_ru_24r_240_24Within, 2);
                heff_drop(v_d_2416);
                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
              case TAG_Just: {
                V v_a_2418 = heff_dup(heff_field(v_c_2415, 0));
                if (heff_intLe_c(MK_INT(0LL), v_a_2418)) {
                  V v_t_2421;
                  switch (heff_tag_of(v_r1_242)) {
                  case TAG_Nothing: {
                    heff_drop_tag(v_c_2415, 1);
                    v_t_2421 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_a_2419 = heff_field(v_r1_242, 0);
                    V v_ru_24r1_242_24Just = heff_take_reuse_n(v_r1_242, 1ULL, 1);
                    switch (heff_tag_of(v_c_2415)) {
                    case TAG_Nothing: {
                      heff_drop(v_a_2419);
                      heff_drop_cell(v_ru_24r1_242_24Just, 1);
                      v_t_2421 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_Just: {
                      V v_b_2420 = heff_field(v_c_2415, 0);
                      heff_take_n(v_c_2415, 1ULL, 1);
                      v_t_2421 = heff_tag_at_n(v_ru_24r1_242_24Just, TAG_Just, 1, (V[]){heff_intMul(v_a_2419, v_b_2420)});
                      break;
                    }
                    default: heff_nomatch(v_c_2415);
                    }
                    break;
                  }
                  default: heff_nomatch(v_r1_242);
                  }
                  V v_t_2424;
                  switch (heff_tag_of(v_r2_243)) {
                  case TAG_Nothing: {
                    heff_drop(v_d_2416);
                    v_t_2424 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_a_2422 = heff_field(v_r2_243, 0);
                    V v_ru_24r2_243_24Just = heff_take_reuse_n(v_r2_243, 1ULL, 1);
                    switch (heff_tag_of(v_d_2416)) {
                    case TAG_Nothing: {
                      heff_drop(v_a_2422);
                      heff_drop_cell(v_ru_24r2_243_24Just, 1);
                      v_t_2424 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_Just: {
                      V v_b_2423 = heff_field(v_d_2416, 0);
                      heff_take_n(v_d_2416, 1ULL, 1);
                      v_t_2424 = heff_tag_at_n(v_ru_24r2_243_24Just, TAG_Just, 1, (V[]){heff_intMul(v_a_2422, v_b_2423)});
                      break;
                    }
                    default: heff_nomatch(v_d_2416);
                    }
                    break;
                  }
                  default: heff_nomatch(v_r2_243);
                  }
                  return heff_tag_at_n(v_ru_24r_240_24Within, TAG_Within, 2, (V[]){v_t_2421, v_t_2424});
                } else {
                  heff_drop_tag(v_r1_242, 1);
                  heff_drop_cell(v_ru_24r_240_24Within, 2);
                  heff_drop_tag(v_c_2415, 1);
                  heff_drop(v_d_2416);
                  return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                }
              }
              default: return heff_nomatch(v_c_2415);
              }
            } else {
              heff_drop_tag(v_r1_242, 1);
              heff_drop_cell(v_ru_24r_240_24Within, 2);
              heff_drop(v_c_2415);
              heff_drop(v_d_2416);
              return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
            }
          }
          default: return heff_nomatch(v_r1_242);
          }
        }
        default: return heff_nomatch(v_s_241);
        }
      }
      case TAG_Just: {
        V v_b_2425 = heff_dup(heff_field(v_r2_243, 0));
        switch (heff_tag_of(v_s_241)) {
        case TAG_Unreached: {
          heff_drop_tag(v_r1_242, 1);
          heff_drop_tag(v_r2_243, 1);
          heff_drop_cell(v_ru_24r_240_24Within, 2);
          heff_drop(v_a_2414);
          heff_drop(v_b_2425);
          return NTAG(TAG_Unreached);
        }
        case TAG_Within: {
          V v_s1_2426 = heff_field(v_s_241, 0);
          V v_s2_2427 = heff_field(v_s_241, 1);
          heff_take_n(v_s_241, 3ULL, 2);
          switch (heff_tag_of(v_s1_2426)) {
          case TAG_Nothing: {
            heff_drop(v_a_2414);
            heff_drop(v_b_2425);
            switch (heff_tag_of(v_r1_242)) {
            case TAG_Nothing: {
              heff_drop_tag(v_r2_243, 1);
              heff_drop_cell(v_ru_24r_240_24Within, 2);
              heff_drop(v_s2_2427);
              return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
            }
            case TAG_Just: {
              V v_a_2428 = heff_dup(heff_field(v_r1_242, 0));
              if (heff_intLe_c(MK_INT(0LL), v_a_2428)) {
                switch (heff_tag_of(v_s1_2426)) {
                case TAG_Nothing: {
                  heff_drop_tag(v_r1_242, 1);
                  heff_drop_tag(v_r2_243, 1);
                  heff_drop_cell(v_ru_24r_240_24Within, 2);
                  heff_drop(v_s2_2427);
                  return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                }
                case TAG_Just: {
                  V v_a_2429 = heff_dup(heff_field(v_s1_2426, 0));
                  if (heff_intLe_c(MK_INT(0LL), v_a_2429)) {
                    V v_t_2432;
                    switch (heff_tag_of(v_r1_242)) {
                    case TAG_Nothing: {
                      heff_drop_tag(v_s1_2426, 1);
                      v_t_2432 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_Just: {
                      V v_a_2430 = heff_field(v_r1_242, 0);
                      V v_ru_24r1_242_24Just = heff_take_reuse_n(v_r1_242, 1ULL, 1);
                      switch (heff_tag_of(v_s1_2426)) {
                      case TAG_Nothing: {
                        heff_drop(v_a_2430);
                        heff_drop_cell(v_ru_24r1_242_24Just, 1);
                        v_t_2432 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Just: {
                        V v_b_2431 = heff_field(v_s1_2426, 0);
                        heff_take_n(v_s1_2426, 1ULL, 1);
                        v_t_2432 = heff_tag_at_n(v_ru_24r1_242_24Just, TAG_Just, 1, (V[]){heff_intMul(v_a_2430, v_b_2431)});
                        break;
                      }
                      default: heff_nomatch(v_s1_2426);
                      }
                      break;
                    }
                    default: heff_nomatch(v_r1_242);
                    }
                    V v_t_2435;
                    switch (heff_tag_of(v_r2_243)) {
                    case TAG_Nothing: {
                      heff_drop(v_s2_2427);
                      v_t_2435 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_Just: {
                      V v_a_2433 = heff_field(v_r2_243, 0);
                      V v_ru_24r2_243_24Just = heff_take_reuse_n(v_r2_243, 1ULL, 1);
                      switch (heff_tag_of(v_s2_2427)) {
                      case TAG_Nothing: {
                        heff_drop(v_a_2433);
                        heff_drop_cell(v_ru_24r2_243_24Just, 1);
                        v_t_2435 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Just: {
                        V v_b_2434 = heff_field(v_s2_2427, 0);
                        heff_take_n(v_s2_2427, 1ULL, 1);
                        v_t_2435 = heff_tag_at_n(v_ru_24r2_243_24Just, TAG_Just, 1, (V[]){heff_intMul(v_a_2433, v_b_2434)});
                        break;
                      }
                      default: heff_nomatch(v_s2_2427);
                      }
                      break;
                    }
                    default: heff_nomatch(v_r2_243);
                    }
                    return heff_tag_at_n(v_ru_24r_240_24Within, TAG_Within, 2, (V[]){v_t_2432, v_t_2435});
                  } else {
                    heff_drop_tag(v_r1_242, 1);
                    heff_drop_tag(v_r2_243, 1);
                    heff_drop_cell(v_ru_24r_240_24Within, 2);
                    heff_drop_tag(v_s1_2426, 1);
                    heff_drop(v_s2_2427);
                    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                  }
                }
                default: return heff_nomatch(v_s1_2426);
                }
              } else {
                heff_drop_tag(v_r1_242, 1);
                heff_drop_tag(v_r2_243, 1);
                heff_drop_cell(v_ru_24r_240_24Within, 2);
                heff_drop(v_s2_2427);
                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
            }
            default: return heff_nomatch(v_r1_242);
            }
          }
          case TAG_Just: {
            V v_c_2436 = heff_dup(heff_field(v_s1_2426, 0));
            switch (heff_tag_of(v_s2_2427)) {
            case TAG_Nothing: {
              heff_drop(v_a_2414);
              heff_drop(v_b_2425);
              heff_drop(v_c_2436);
              switch (heff_tag_of(v_r1_242)) {
              case TAG_Nothing: {
                heff_drop_tag(v_r2_243, 1);
                heff_drop_cell(v_ru_24r_240_24Within, 2);
                heff_drop_tag(v_s1_2426, 1);
                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
              case TAG_Just: {
                V v_a_2437 = heff_dup(heff_field(v_r1_242, 0));
                if (heff_intLe_c(MK_INT(0LL), v_a_2437)) {
                  switch (heff_tag_of(v_s1_2426)) {
                  case TAG_Nothing: {
                    heff_drop_tag(v_r1_242, 1);
                    heff_drop_tag(v_r2_243, 1);
                    heff_drop_cell(v_ru_24r_240_24Within, 2);
                    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                  }
                  case TAG_Just: {
                    V v_a_2438 = heff_dup(heff_field(v_s1_2426, 0));
                    if (heff_intLe_c(MK_INT(0LL), v_a_2438)) {
                      V v_t_2441;
                      switch (heff_tag_of(v_r1_242)) {
                      case TAG_Nothing: {
                        heff_drop_tag(v_s1_2426, 1);
                        v_t_2441 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Just: {
                        V v_a_2439 = heff_field(v_r1_242, 0);
                        V v_ru_24r1_242_24Just = heff_take_reuse_n(v_r1_242, 1ULL, 1);
                        switch (heff_tag_of(v_s1_2426)) {
                        case TAG_Nothing: {
                          heff_drop(v_a_2439);
                          heff_drop_cell(v_ru_24r1_242_24Just, 1);
                          v_t_2441 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_Just: {
                          V v_b_2440 = heff_field(v_s1_2426, 0);
                          heff_take_n(v_s1_2426, 1ULL, 1);
                          v_t_2441 = heff_tag_at_n(v_ru_24r1_242_24Just, TAG_Just, 1, (V[]){heff_intMul(v_a_2439, v_b_2440)});
                          break;
                        }
                        default: heff_nomatch(v_s1_2426);
                        }
                        break;
                      }
                      default: heff_nomatch(v_r1_242);
                      }
                      V v_t_2444;
                      switch (heff_tag_of(v_r2_243)) {
                      case TAG_Nothing: {
                        v_t_2444 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Just: {
                        V v_a_2442 = heff_field(v_r2_243, 0);
                        V v_ru_24r2_243_24Just = heff_take_reuse_n(v_r2_243, 1ULL, 1);
                        switch (heff_tag_of(v_s2_2427)) {
                        case TAG_Nothing: {
                          heff_drop(v_a_2442);
                          heff_drop_cell(v_ru_24r2_243_24Just, 1);
                          v_t_2444 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_Just: {
                          V v_b_2443 = heff_field(v_s2_2427, 0);
                          heff_take_n(v_s2_2427, 1ULL, 1);
                          v_t_2444 = heff_tag_at_n(v_ru_24r2_243_24Just, TAG_Just, 1, (V[]){heff_intMul(v_a_2442, v_b_2443)});
                          break;
                        }
                        default: heff_nomatch(v_s2_2427);
                        }
                        break;
                      }
                      default: heff_nomatch(v_r2_243);
                      }
                      return heff_tag_at_n(v_ru_24r_240_24Within, TAG_Within, 2, (V[]){v_t_2441, v_t_2444});
                    } else {
                      heff_drop_tag(v_r1_242, 1);
                      heff_drop_tag(v_r2_243, 1);
                      heff_drop_cell(v_ru_24r_240_24Within, 2);
                      heff_drop_tag(v_s1_2426, 1);
                      return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                    }
                  }
                  default: return heff_nomatch(v_s1_2426);
                  }
                } else {
                  heff_drop_tag(v_r1_242, 1);
                  heff_drop_tag(v_r2_243, 1);
                  heff_drop_cell(v_ru_24r_240_24Within, 2);
                  heff_drop_tag(v_s1_2426, 1);
                  return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                }
              }
              default: return heff_nomatch(v_r1_242);
              }
            }
            case TAG_Just: {
              V v_d_2445 = heff_field(v_s2_2427, 0);
              heff_take_n(v_s2_2427, 1ULL, 1);
              heff_drop_tag(v_r1_242, 1);
              heff_drop_tag(v_r2_243, 1);
              heff_drop_tag(v_s1_2426, 1);
              return (g_heff_2ecompile_2eranges_2ecorners_24tok2(v_ru_24r_240_24Within, heff_intMul(heff_dup(v_a_2414), heff_dup(v_c_2436)), heff_intMul(v_a_2414, heff_dup(v_d_2445)), heff_intMul(heff_dup(v_b_2425), v_c_2436), heff_intMul(v_b_2425, v_d_2445)));
            }
            default: return heff_nomatch(v_s2_2427);
            }
          }
          default: return heff_nomatch(v_s1_2426);
          }
        }
        default: return heff_nomatch(v_s_241);
        }
      }
      default: return heff_nomatch(v_r2_243);
      }
    }
    default: return heff_nomatch(v_r1_242);
    }
  }
  default: return heff_nomatch(v_r_240);
  }
}
V g_heff_2ecompile_2eranges_2emulR_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2emulR(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2etrimHigh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2etrimHigh_entry, 2, 0};

V g_heff_2ecompile_2eranges_2etrimHigh(V v_v_240, V v_r_241) {
top: ;
  switch (heff_tag_of(v_r_241)) {
  case TAG_Unreached: {
    heff_drop(v_v_240);
    return v_r_241;
  }
  case TAG_Within: {
    V v_r2_243 = heff_dup(heff_field(v_r_241, 1));
    switch (heff_tag_of(v_r2_243)) {
    case TAG_Nothing: {
      heff_drop(v_v_240);
      return v_r_241;
    }
    case TAG_Just: {
      V v_hi_244 = heff_field(v_r2_243, 0);
      V v_ru_24r2_243_24Just = heff_take_reuse_n(v_r2_243, 1ULL, 1);
      switch (heff_tag_of(v_r_241)) {
      case TAG_Within: {
        V v_lo_245 = heff_field(v_r_241, 0);
        V v_ru_24r_241_24Within = heff_take_reuse_n(v_r_241, 1ULL, 2);
        if (heff_intEq_c_lent(v_hi_244, v_v_240, 0)) {
          heff_drop(v_hi_244);
          V v_t_247 = heff_intSub(v_v_240, MK_INT(1LL));
          switch (heff_tag_of(v_lo_245)) {
          case TAG_Nothing: {
            return heff_tag_at_n(v_ru_24r_241_24Within, TAG_Within, 2, (V[]){v_lo_245, heff_tag_at_n(v_ru_24r2_243_24Just, TAG_Just, 1, (V[]){v_t_247})});
          }
          case TAG_Just: {
            V v_lo_248 = heff_field(v_lo_245, 0);
            heff_take_n(v_lo_245, 1ULL, 1);
            if (heff_intLt_c_lent(v_t_247, v_lo_248, 0)) {
              heff_drop_cell(v_ru_24r2_243_24Just, 1);
              heff_drop_cell(v_ru_24r_241_24Within, 2);
              heff_drop(v_t_247);
              heff_drop(v_lo_248);
              return NTAG(TAG_Unreached);
            } else {
              return heff_tag_at_n(v_ru_24r_241_24Within, TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24r2_243_24Just, TAG_Just, 1, (V[]){v_lo_248}), heff_tag_n(TAG_Just, 1, (V[]){v_t_247})});
            }
          }
          default: return heff_nomatch(v_lo_245);
          }
        } else {
          heff_drop(v_v_240);
          return heff_tag_at_n(v_ru_24r_241_24Within, TAG_Within, 2, (V[]){v_lo_245, heff_tag_at_n(v_ru_24r2_243_24Just, TAG_Just, 1, (V[]){v_hi_244})});
        }
      }
      default: return heff_nomatch(v_r_241);
      }
    }
    default: return heff_nomatch(v_r2_243);
    }
  }
  default: return heff_nomatch(v_r_241);
  }
}
V g_heff_2ecompile_2eranges_2etrimHigh_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2etrimHigh(a[0], a[1]);
}

static V g_heff_2ecompile_2eranges_2eemptySt_val;
static HEFF_ONCE g_heff_2ecompile_2eranges_2eemptySt_st;
static V g_heff_2ecompile_2eranges_2eemptySt_init(void) {
  return heff_rec_n(2, shape_calls__marks, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get())});
}
V g_heff_2ecompile_2eranges_2eemptySt_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eranges_2eemptySt_st)) return g_heff_2ecompile_2eranges_2eemptySt_val;
  return heff_global(&g_heff_2ecompile_2eranges_2eemptySt_val, &g_heff_2ecompile_2eranges_2eemptySt_st, g_heff_2ecompile_2eranges_2eemptySt_init);
}
Clo g_heff_2ecompile_2eranges_2eoperandRange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2eoperandRange_entry, 3, 0};

V g_heff_2ecompile_2eranges_2eoperandRange(V v_c_240, V v_env_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_c_240, 3);
    HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_env_241, 0, 2); V a_1 = v_x_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_243); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_246;
        return v_x_247;
      } else {
        heff_drop(v_field_246);
        return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
    }
  }
  case TAG_EGlobal: {
    V v_g_248 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EGlobal = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_env_241, 2);
    HeffT2 v_t_249 = ({ V b_0 = heff_get_n(v_c_240, 1, 3); V a_1 = v_g_248; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_g_248); r_; });
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_x_2412 = v_field_2411;
        return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24e_242_24EGlobal, TAG_Just, 1, (V[]){heff_dup(v_x_2412)}), heff_tag_n(TAG_Just, 1, (V[]){v_x_2412})});
      } else {
        heff_drop_cell(v_ru_24e_242_24EGlobal, 1);
        heff_drop(v_field_2411);
        return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
    }
  }
  case TAG_ELam: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EApp: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_ELet: {
    heff_take_n(v_e_242, 0ULL, 3);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_ERecord: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EProj: {
    heff_take_n(v_e_242, 0ULL, 4);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_ETag: {
    heff_take_n(v_e_242, 0ULL, 3);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EMatch: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EPrim: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EPrimCall: {
    V v_p_2432 = heff_field(v_e_242, 0);
    V v_args_2433 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2434 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2eoperandRange_clo), 2, (V[]){v_c_240, v_env_241}));
    V v_t_2435 = (g_list_2emap_24tok2(v_ru_24e_242_24EPrimCall, v_t_2434, v_args_2433));
    return ({ V a_0 = v_p_2432; V a_1 = v_t_2435; V r_ = (g_heff_2ecompile_2eranges_2eprimRange(a_0, a_1)); heff_drop(v_p_2432); heff_drop(v_t_2435); r_; });
  }
  case TAG_ECall: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EInt: {
    V v_n_2438 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EInt = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24e_242_24EInt, TAG_Just, 1, (V[]){heff_dup(v_n_2438)}), heff_tag_n(TAG_Just, 1, (V[]){v_n_2438})});
  }
  case TAG_EFloat: {
    heff_take_na(v_e_242, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EStr: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EBytes: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EFixed: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_242, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EBool: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_ESet: {
    heff_take_n(v_e_242, 0ULL, 3);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EValues: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EFix: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eranges_2eoperandRange_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2eoperandRange(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eranges_2ewithRange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ewithRange_entry, 3, 0};

V g_heff_2ecompile_2eranges_2ewithRange(V v_env_240, V v_x_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_r_242)) {
  case TAG_Unreached: {
    V v_t_243 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_env_240, 0), v_x_241, v_r_242));
    return ({ V rv_0 = v_t_243; V rr_ = heff_rec_reuse_nf(v_env_240, 2ULL, 2, shape_ranges__tests, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
  case TAG_Within: {
    V v_r1_244 = heff_dup(heff_field(v_r_242, 0));
    V v_r2_245 = heff_dup(heff_field(v_r_242, 1));
    switch (heff_tag_of(v_r1_244)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_r2_245)) {
      case TAG_Nothing: {
        heff_drop(v_x_241);
        heff_drop_tag(v_r_242, 2);
        return v_env_240;
      }
      case TAG_Just: {
        heff_take_n(v_r2_245, 0ULL, 1);
        V v_t_247 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_env_240, 0), v_x_241, v_r_242));
        return ({ V rv_0 = v_t_247; V rr_ = heff_rec_reuse_nf(v_env_240, 2ULL, 2, shape_ranges__tests, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      }
      default: return heff_nomatch(v_r2_245);
      }
    }
    case TAG_Just: {
      heff_take_n(v_r1_244, 0ULL, 1);
      heff_drop(v_r2_245);
      V v_t_249 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_env_240, 0), v_x_241, v_r_242));
      return ({ V rv_0 = v_t_249; V rr_ = heff_rec_reuse_nf(v_env_240, 2ULL, 2, shape_ranges__tests, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    }
    default: return heff_nomatch(v_r1_244);
    }
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2ecompile_2eranges_2ewithRange_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ewithRange(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eranges_2emarked_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2emarked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2emarked_entry, 4, 0};

V g_heff_2ecompile_2eranges_2emarked(V v_c_240, V v_env_241, V v_x3_242, V v_st_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_env_241);
    return v_st_243;
  }
  case TAG_Just: {
    V v_k_244 = heff_field(v_x3_242, 0);
    if (!(heff_dup(heff_rfield(v_c_240, 2)) == NTAG(TAG_True))) {
      heff_drop_rec(v_c_240, 3);
      heff_drop(v_env_241);
      return v_st_243;
    } else {
      V v_t_245 = (g_heff_2ecompile_2eranges_2econdTests(heff_dup(v_env_241), heff_dup(v_k_244)));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eranges_2emarked_lam0, 2, 2, (V[]){v_c_240, v_env_241}); V a_1 = v_st_243; V a_2 = v_t_245; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eranges_2emarked_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eranges_2emarked(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eranges_2emarked_lam0(V self, V *args) {
  V v_st_246 = args[0];
  V v_x4_247 = args[1];
  V v_c_240 = heff_env(self)[0];
  V v_env_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_calls_248 = heff_take_field(v_st_246, 0);
  V v_marks_249 = heff_get_n(v_st_246, 1, 2);
  switch (heff_tag_of(v_x4_247)) {
  case TAG_MkTest: {
    V v_a_2411 = heff_field(v_x4_247, 1);
    V v_b_2412 = heff_field(v_x4_247, 2);
    heff_take_n(v_x4_247, 6ULL, 3);
    V v_t_2413 = (g_heff_2ecompile_2eranges_2eoperandRange(heff_dup(v_c_240), heff_dup(v_env_241), v_a_2411));
    V v_t_2414 = ({ V a_0 = v_marks_249; V a_1 = v_t_2413; V r_ = (g_heff_2ecompile_2eranges_2emarkRange(a_0, a_1)); heff_drop(v_t_2413); r_; });
    V v_t_2415 = (g_heff_2ecompile_2eranges_2eoperandRange(v_c_240, v_env_241, v_b_2412));
    V v_t_2416 = ({ V a_0 = v_t_2414; V a_1 = v_t_2415; V r_ = (g_heff_2ecompile_2eranges_2emarkRange(a_0, a_1)); heff_drop(v_t_2415); r_; });
    return heff_rec_n(2, shape_calls__marks, (V[]){v_calls_248, v_t_2416});
  }
  default: return heff_nomatch(v_x4_247);
  }
}
Clo g_heff_2ecompile_2eranges_2ecalledIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ecalledIn_entry, 4, 0};

V g_heff_2ecompile_2eranges_2ecalledIn(V v_c_240, V v_g_241, V v_rs_242, V v_st_243) {
top: ;
  HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_c_240, 0, 3); V a_1 = v_g_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_ps_247 = v_field_246;
      V v_t_248 = ({ V a_0 = v_ps_247; V r_ = (g_list_2eall_24s853093203x77424416(a_0)); heff_drop(v_ps_247); r_; });
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_g_241);
        heff_drop(v_rs_242);
        heff_drop(v_t_248);
        return v_st_243;
      } else {
        heff_drop(v_t_248);
        HeffT2 v_t_249 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_st_243, 0), v_g_241));
        V v_t_2413;
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x_2412 = v_field_2411;
            v_t_2413 = (g_list_2ezipWith_24s1026658656x682908126(v_rs_242, v_x_2412));
          } else {
            heff_drop(v_field_2411);
            v_t_2413 = v_rs_242;
          }
        }
        V v_t_2414 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_st_243, 0), v_g_241, v_t_2413));
        return ({ V rv_0 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_st_243, 2ULL, 2, shape_calls__marks, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      }
    } else {
      heff_drop(v_g_241);
      heff_drop(v_rs_242);
      heff_drop(v_field_246);
      return v_st_243;
    }
  }
}
V g_heff_2ecompile_2eranges_2ecalledIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ecalledIn(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eranges_2egatherDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2egatherDef_entry, 2, 0};

V g_heff_2ecompile_2eranges_2egatherDef(V v_c_240, V v_d_241) {
top: ;
  V v_body_242 = heff_take_field(v_d_241, 2);
  V v_key_243 = heff_get_n(v_d_241, 0, 3);
  switch (heff_tag_of(v_body_242)) {
  case TAG_EVar: {
    heff_drop(v_key_243);
    V v_x1_245 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_MkSeen: {
      V v_st_247 = heff_field(v_x1_245, 1);
      heff_take_n(v_x1_245, 2ULL, 2);
      return v_st_247;
    }
    case TAG_MkSeenVals: {
      V v_st_249 = heff_field(v_x1_245, 1);
      heff_take_n(v_x1_245, 2ULL, 2);
      return v_st_249;
    }
    default: return heff_nomatch(v_x1_245);
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_key_243);
    V v_x1_2411 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_MkSeen: {
      V v_st_2413 = heff_field(v_x1_2411, 1);
      heff_take_n(v_x1_2411, 2ULL, 2);
      return v_st_2413;
    }
    case TAG_MkSeenVals: {
      V v_st_2415 = heff_field(v_x1_2411, 1);
      heff_take_n(v_x1_2411, 2ULL, 2);
      return v_st_2415;
    }
    default: return heff_nomatch(v_x1_2411);
    }
  }
  case TAG_ELam: {
    V v_xs_2416 = heff_field(v_body_242, 0);
    V v_b_2417 = heff_field(v_body_242, 1);
    heff_take_n(v_body_242, 3ULL, 2);
    HeffT2 v_t_2418 = ({ V a_0 = heff_rfield(v_c_240, 0); V a_1 = v_key_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_key_243); r_; });
    V v_t_2423;
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        V v_rs_2421 = v_field_2420;
        V v_t_2422 = (g_list_2ezipWith_24s1876717925x1404326288(v_xs_2416, v_rs_2421));
        v_t_2423 = ({ V a_0 = heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s518632429x1911716206(a_0, a_1)); heff_drop(v_t_2422); r_; });
      } else {
        heff_drop(v_xs_2416);
        heff_drop(v_field_2420);
        v_t_2423 = heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get());
      }
    }
    V v_x1_2424 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, v_t_2423, heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_b_2417));
    switch (heff_tag_of(v_x1_2424)) {
    case TAG_MkSeen: {
      V v_st_2426 = heff_field(v_x1_2424, 1);
      heff_take_n(v_x1_2424, 2ULL, 2);
      return v_st_2426;
    }
    case TAG_MkSeenVals: {
      V v_st_2428 = heff_field(v_x1_2424, 1);
      heff_take_n(v_x1_2424, 2ULL, 2);
      return v_st_2428;
    }
    default: return heff_nomatch(v_x1_2424);
    }
  }
  case TAG_EApp: {
    heff_drop(v_key_243);
    V v_x1_2431 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_2431)) {
    case TAG_MkSeen: {
      V v_st_2433 = heff_field(v_x1_2431, 1);
      heff_take_n(v_x1_2431, 2ULL, 2);
      return v_st_2433;
    }
    case TAG_MkSeenVals: {
      V v_st_2435 = heff_field(v_x1_2431, 1);
      heff_take_n(v_x1_2431, 2ULL, 2);
      return v_st_2435;
    }
    default: return heff_nomatch(v_x1_2431);
    }
  }
  case TAG_ELet: {
    heff_drop(v_key_243);
    V v_x1_2439 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_2439)) {
    case TAG_MkSeen: {
      V v_st_2441 = heff_field(v_x1_2439, 1);
      heff_take_n(v_x1_2439, 2ULL, 2);
      return v_st_2441;
    }
    case TAG_MkSeenVals: {
      V v_st_2443 = heff_field(v_x1_2439, 1);
      heff_take_n(v_x1_2439, 2ULL, 2);
      return v_st_2443;
    }
    default: return heff_nomatch(v_x1_2439);
    }
  }
  case TAG_ERecord: {
    heff_drop(v_key_243);
    V v_x1_2446 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_2446)) {
    case TAG_MkSeen: {
      V v_st_2448 = heff_field(v_x1_2446, 1);
      heff_take_n(v_x1_2446, 2ULL, 2);
      return v_st_2448;
    }
    case TAG_MkSeenVals: {
      V v_st_2450 = heff_field(v_x1_2446, 1);
      heff_take_n(v_x1_2446, 2ULL, 2);
      return v_st_2450;
    }
    default: return heff_nomatch(v_x1_2446);
    }
  }
  case TAG_EProj: {
    heff_drop(v_key_243);
    V v_x1_2455 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_2455)) {
    case TAG_MkSeen: {
      V v_st_2457 = heff_field(v_x1_2455, 1);
      heff_take_n(v_x1_2455, 2ULL, 2);
      return v_st_2457;
    }
    case TAG_MkSeenVals: {
      V v_st_2459 = heff_field(v_x1_2455, 1);
      heff_take_n(v_x1_2455, 2ULL, 2);
      return v_st_2459;
    }
    default: return heff_nomatch(v_x1_2455);
    }
  }
  case TAG_ETag: {
    heff_drop(v_key_243);
    V v_x1_2463 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_2463)) {
    case TAG_MkSeen: {
      V v_st_2465 = heff_field(v_x1_2463, 1);
      heff_take_n(v_x1_2463, 2ULL, 2);
      return v_st_2465;
    }
    case TAG_MkSeenVals: {
      V v_st_2467 = heff_field(v_x1_2463, 1);
      heff_take_n(v_x1_2463, 2ULL, 2);
      return v_st_2467;
    }
    default: return heff_nomatch(v_x1_2463);
    }
  }
  case TAG_EMatch: {
    heff_drop(v_key_243);
    V v_x1_2470 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_2470)) {
    case TAG_MkSeen: {
      V v_st_2472 = heff_field(v_x1_2470, 1);
      heff_take_n(v_x1_2470, 2ULL, 2);
      return v_st_2472;
    }
    case TAG_MkSeenVals: {
      V v_st_2474 = heff_field(v_x1_2470, 1);
      heff_take_n(v_x1_2470, 2ULL, 2);
      return v_st_2474;
    }
    default: return heff_nomatch(v_x1_2470);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_key_243);
    V v_x1_2476 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_2476)) {
    case TAG_MkSeen: {
      V v_st_2478 = heff_field(v_x1_2476, 1);
      heff_take_n(v_x1_2476, 2ULL, 2);
      return v_st_2478;
    }
    case TAG_MkSeenVals: {
      V v_st_2480 = heff_field(v_x1_2476, 1);
      heff_take_n(v_x1_2476, 2ULL, 2);
      return v_st_2480;
    }
    default: return heff_nomatch(v_x1_2476);
    }
  }
  case TAG_EPrimCall: {
    heff_drop(v_key_243);
    V v_x1_2483 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_2483)) {
    case TAG_MkSeen: {
      V v_st_2485 = heff_field(v_x1_2483, 1);
      heff_take_n(v_x1_2483, 2ULL, 2);
      return v_st_2485;
    }
    case TAG_MkSeenVals: {
      V v_st_2487 = heff_field(v_x1_2483, 1);
      heff_take_n(v_x1_2483, 2ULL, 2);
      return v_st_2487;
    }
    default: return heff_nomatch(v_x1_2483);
    }
  }
  case TAG_ECall: {
    heff_drop(v_key_243);
    V v_x1_2490 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_2490)) {
    case TAG_MkSeen: {
      V v_st_2492 = heff_field(v_x1_2490, 1);
      heff_take_n(v_x1_2490, 2ULL, 2);
      return v_st_2492;
    }
    case TAG_MkSeenVals: {
      V v_st_2494 = heff_field(v_x1_2490, 1);
      heff_take_n(v_x1_2490, 2ULL, 2);
      return v_st_2494;
    }
    default: return heff_nomatch(v_x1_2490);
    }
  }
  case TAG_EInt: {
    heff_drop(v_key_243);
    V v_x1_2496 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_2496)) {
    case TAG_MkSeen: {
      V v_st_2498 = heff_field(v_x1_2496, 1);
      heff_take_n(v_x1_2496, 2ULL, 2);
      return v_st_2498;
    }
    case TAG_MkSeenVals: {
      V v_st_24100 = heff_field(v_x1_2496, 1);
      heff_take_n(v_x1_2496, 2ULL, 2);
      return v_st_24100;
    }
    default: return heff_nomatch(v_x1_2496);
    }
  }
  case TAG_EFloat: {
    heff_drop(v_key_243);
    V v_x1_24102 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_24102)) {
    case TAG_MkSeen: {
      V v_st_24104 = heff_field(v_x1_24102, 1);
      heff_take_n(v_x1_24102, 2ULL, 2);
      return v_st_24104;
    }
    case TAG_MkSeenVals: {
      V v_st_24106 = heff_field(v_x1_24102, 1);
      heff_take_n(v_x1_24102, 2ULL, 2);
      return v_st_24106;
    }
    default: return heff_nomatch(v_x1_24102);
    }
  }
  case TAG_EStr: {
    heff_drop(v_key_243);
    V v_x1_24108 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_24108)) {
    case TAG_MkSeen: {
      V v_st_24110 = heff_field(v_x1_24108, 1);
      heff_take_n(v_x1_24108, 2ULL, 2);
      return v_st_24110;
    }
    case TAG_MkSeenVals: {
      V v_st_24112 = heff_field(v_x1_24108, 1);
      heff_take_n(v_x1_24108, 2ULL, 2);
      return v_st_24112;
    }
    default: return heff_nomatch(v_x1_24108);
    }
  }
  case TAG_EBytes: {
    heff_drop(v_key_243);
    V v_x1_24114 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_24114)) {
    case TAG_MkSeen: {
      V v_st_24116 = heff_field(v_x1_24114, 1);
      heff_take_n(v_x1_24114, 2ULL, 2);
      return v_st_24116;
    }
    case TAG_MkSeenVals: {
      V v_st_24118 = heff_field(v_x1_24114, 1);
      heff_take_n(v_x1_24114, 2ULL, 2);
      return v_st_24118;
    }
    default: return heff_nomatch(v_x1_24114);
    }
  }
  case TAG_EFixed: {
    heff_drop(v_key_243);
    V v_x1_24121 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_24121)) {
    case TAG_MkSeen: {
      V v_st_24123 = heff_field(v_x1_24121, 1);
      heff_take_n(v_x1_24121, 2ULL, 2);
      return v_st_24123;
    }
    case TAG_MkSeenVals: {
      V v_st_24125 = heff_field(v_x1_24121, 1);
      heff_take_n(v_x1_24121, 2ULL, 2);
      return v_st_24125;
    }
    default: return heff_nomatch(v_x1_24121);
    }
  }
  case TAG_EFloat32: {
    heff_drop(v_key_243);
    V v_x1_24127 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_24127)) {
    case TAG_MkSeen: {
      V v_st_24129 = heff_field(v_x1_24127, 1);
      heff_take_n(v_x1_24127, 2ULL, 2);
      return v_st_24129;
    }
    case TAG_MkSeenVals: {
      V v_st_24131 = heff_field(v_x1_24127, 1);
      heff_take_n(v_x1_24127, 2ULL, 2);
      return v_st_24131;
    }
    default: return heff_nomatch(v_x1_24127);
    }
  }
  case TAG_EAbandon: {
    heff_drop(v_key_243);
    V v_x1_24132 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_24132)) {
    case TAG_MkSeen: {
      V v_st_24134 = heff_field(v_x1_24132, 1);
      heff_take_n(v_x1_24132, 2ULL, 2);
      return v_st_24134;
    }
    case TAG_MkSeenVals: {
      V v_st_24136 = heff_field(v_x1_24132, 1);
      heff_take_n(v_x1_24132, 2ULL, 2);
      return v_st_24136;
    }
    default: return heff_nomatch(v_x1_24132);
    }
  }
  case TAG_EBool: {
    heff_drop(v_key_243);
    V v_x1_24138 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_24138)) {
    case TAG_MkSeen: {
      V v_st_24140 = heff_field(v_x1_24138, 1);
      heff_take_n(v_x1_24138, 2ULL, 2);
      return v_st_24140;
    }
    case TAG_MkSeenVals: {
      V v_st_24142 = heff_field(v_x1_24138, 1);
      heff_take_n(v_x1_24138, 2ULL, 2);
      return v_st_24142;
    }
    default: return heff_nomatch(v_x1_24138);
    }
  }
  case TAG_ESet: {
    heff_drop(v_key_243);
    V v_x1_24146 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_24146)) {
    case TAG_MkSeen: {
      V v_st_24148 = heff_field(v_x1_24146, 1);
      heff_take_n(v_x1_24146, 2ULL, 2);
      return v_st_24148;
    }
    case TAG_MkSeenVals: {
      V v_st_24150 = heff_field(v_x1_24146, 1);
      heff_take_n(v_x1_24146, 2ULL, 2);
      return v_st_24150;
    }
    default: return heff_nomatch(v_x1_24146);
    }
  }
  case TAG_EValues: {
    heff_drop(v_key_243);
    V v_x1_24152 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_24152)) {
    case TAG_MkSeen: {
      V v_st_24154 = heff_field(v_x1_24152, 1);
      heff_take_n(v_x1_24152, 2ULL, 2);
      return v_st_24154;
    }
    case TAG_MkSeenVals: {
      V v_st_24156 = heff_field(v_x1_24152, 1);
      heff_take_n(v_x1_24152, 2ULL, 2);
      return v_st_24156;
    }
    default: return heff_nomatch(v_x1_24152);
    }
  }
  case TAG_EFix: {
    heff_drop(v_key_243);
    V v_x1_24159 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_body_242));
    switch (heff_tag_of(v_x1_24159)) {
    case TAG_MkSeen: {
      V v_st_24161 = heff_field(v_x1_24159, 1);
      heff_take_n(v_x1_24159, 2ULL, 2);
      return v_st_24161;
    }
    case TAG_MkSeenVals: {
      V v_st_24163 = heff_field(v_x1_24159, 1);
      heff_take_n(v_x1_24159, 2ULL, 2);
      return v_st_24163;
    }
    default: return heff_nomatch(v_x1_24159);
    }
  }
  default: return heff_nomatch(v_body_242);
  }
}
V g_heff_2ecompile_2eranges_2egatherDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2egatherDef(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2eranges_2ewalkMany_24cpr(V v_go_240, V v_env_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    heff_drop(v_env_241);
    return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x3_242, 0);
    V v_es_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x1_245 = heff_tr(heff_call(heff_dup(v_go_240), 2, (V[]){heff_dup(v_env_241), v_e_243}));
    HeffT2 v_t_246 = (g_heff_2ecompile_2eranges_2ewalkMany_24cpr(v_go_240, v_env_241, v_es_244));
    {
      V v_field_247 = v_t_246.f[0];
      V v_field_248 = v_t_246.f[1];
      switch (heff_tag_of(v_x1_245)) {
      case TAG_MkRes: {
        V v_r_249 = heff_field(v_x1_245, 0);
        V v_e_2410 = heff_field(v_x1_245, 1);
        V v_ru_24x1_245_24MkRes = heff_take_reuse_n(v_x1_245, 3ULL, 2);
        V v_rs_2411 = v_field_247;
        V v_es_2412 = v_field_248;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_r_249, v_rs_2411}), heff_tag_at_n(v_ru_24x1_245_24MkRes, TAG_Cons, 2, (V[]){v_e_2410, v_es_2412})}});
      }
      case TAG_MkResVals: {
        V v_e_2414 = heff_field(v_x1_245, 1);
        V v_ru_24x1_245_24MkResVals = heff_take_reuse_n(v_x1_245, 2ULL, 2);
        V v_rs_2415 = v_field_247;
        V v_es_2416 = v_field_248;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_rs_2415}), heff_tag_at_n(v_ru_24x1_245_24MkResVals, TAG_Cons, 2, (V[]){v_e_2414, v_es_2416})}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_245)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
Clo g_heff_2ecompile_2eranges_2ewalkArms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ewalkArms_entry, 5, 0};

V g_heff_2ecompile_2eranges_2ewalkArms(V v_c_240, V v_go_241, V v_env_242, V v_t_243, V v_x5_244) {
top: ;
  HeffT3 v_t_245 = (g_heff_2ecompile_2eranges_2ewalkArms_24cpr(v_c_240, v_go_241, v_env_242, v_t_243, v_x5_244));
  {
    V v_field_247 = v_t_245.f[1];
    V v_field_248 = v_t_245.f[2];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_MkArms, 2, (V[]){v_field_247, v_field_248});
    } else {
      return heff_tag_n(TAG_MkArmsVals, 2, (V[]){v_field_247, v_field_248});
    }
  }
}
V g_heff_2ecompile_2eranges_2ewalkArms_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ecompile_2eranges_2ewalkArms(a[0], a[1], a[2], a3, a4); heff_drop(a3); heff_drop(a4); return r;
}
Clo g_heff_2ecompile_2eranges_2ewidenLow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ewidenLow_entry, 3, 0};

V g_heff_2ecompile_2eranges_2ewidenLow(V v_x1_240, V v_a_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_a_241)) {
    case TAG_Nothing: {
      return v_x3_242;
    }
    case TAG_Just: {
      V v_a_243 = heff_field(v_a_241, 0);
      heff_take_n(v_a_241, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nothing: {
        heff_drop(v_a_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_c_244 = heff_dup(heff_field(v_x3_242, 0));
        if (heff_intLt_c(v_c_244, v_a_243)) {
          heff_drop_tag(v_x3_242, 1);
          return NTAG(TAG_Nothing);
        } else {
          return v_x3_242;
        }
      }
      default: return heff_nomatch(v_x3_242);
      }
    }
    default: return heff_nomatch(v_a_241);
    }
  }
  case TAG_Just: {
    V v_ms_245 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nothing: {
      heff_drop(v_ms_245);
      heff_drop_cell(v_ru_24x1_240_24Just, 1);
      switch (heff_tag_of(v_a_241)) {
      case TAG_Nothing: {
        return v_x3_242;
      }
      case TAG_Just: {
        V v_a_246 = heff_field(v_a_241, 0);
        heff_take_n(v_a_241, 1ULL, 1);
        switch (heff_tag_of(v_x3_242)) {
        case TAG_Nothing: {
          heff_drop(v_a_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_c_247 = heff_dup(heff_field(v_x3_242, 0));
          if (heff_intLt_c(v_c_247, v_a_246)) {
            heff_drop_tag(v_x3_242, 1);
            return NTAG(TAG_Nothing);
          } else {
            return v_x3_242;
          }
        }
        default: return heff_nomatch(v_x3_242);
        }
      }
      default: return heff_nomatch(v_a_241);
      }
    }
    case TAG_Just: {
      V v_c_248 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      switch (heff_tag_of(v_a_241)) {
      case TAG_Nothing: {
        heff_drop(v_ms_245);
        return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_c_248});
      }
      case TAG_Just: {
        V v_a_249 = heff_field(v_a_241, 0);
        heff_take_n(v_a_241, 1ULL, 1);
        if (heff_intLt_c_lent(v_c_248, v_a_249, 2)) {
          heff_drop_cell(v_ru_24x1_240_24Just, 1);
          V v_t_2410 = ({ V a_0 = v_ms_245; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_ms_245); r_; });
          return ({ V a_0 = v_c_248; V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2410; V r_ = (g_list_2efoldl_24s510070423x219220408(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
        } else {
          heff_drop(v_ms_245);
          return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_c_248});
        }
      }
      default: return heff_nomatch(v_a_241);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eranges_2ewidenLow_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ewidenLow(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eranges_2erangesEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erangesEq_entry, 2, 0};

V g_heff_2ecompile_2eranges_2erangesEq(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_args_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      V v_t_248 = (g_heff_2ecompile_2eranges_2erangeEq(v_a_244, v_b_246));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V t_0 = v_args_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_248);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eranges_2erangesEq_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eranges_2erangesEq(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2eranges_2eplaceOf_24cpr(V v_x_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x3_242, 0);
    V v_ys_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_240, v_y_243, 2)) {
      heff_drop(v_ys_244);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_241}});
    } else {
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_ys_244;
      v_x_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2ecompile_2eranges_2erangedWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2erangedWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erangedWith_entry, 4, 0};

V g_heff_2ecompile_2eranges_2erangedWith(V v_consts_240, V v_sc_241, V v_defs_242, V v_params_243) {
top: ;
  V v_t_2411 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eranges_2erangedWith_lam0, 1, 3, (V[]){v_sc_241, heff_dup(v_params_243), v_consts_240}), v_defs_242));
  V v_t_2412 = ({ V a_0 = v_params_243; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_params_243); r_; });
  V v_t_2413 = ({ V a_0 = MK_INT(-4611686018427387904LL); V a_1 = MK_INT(4611686018427387903LL); V a_2 = MK_INT(0LL); V a_3 = MK_INT(1LL); V a_4 = MK_INT(0LL); V a_5 = MK_INT(1LL); V a_6 = MK_INT(-4611686018427387904LL); V a_7 = MK_INT(4611686018427387903LL); V a_8 = MK_INT(0LL); V a_9 = MK_INT(1LL); V a_10 = MK_INT(0LL); V a_11 = MK_INT(1LL); V a_12 = heff_dup(g_std_2emap_2eempty_get()); V a_13 = v_t_2412; V r_ = (g_list_2efoldl_24s213448614x618797387(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11, a_12, a_13)); heff_drop(v_t_2412); r_; });
  return heff_rec_n(2, shape_defs__words, (V[]){v_t_2411, v_t_2413});
}
V g_heff_2ecompile_2eranges_2erangedWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2erangedWith(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eranges_2erangedWith_lam0(V self, V *args) {
  V v_d_244 = args[0];
  V v_sc_241 = heff_env(self)[0];
  V v_params_243 = heff_env(self)[1];
  V v_consts_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_245 = ({ V b_0 = heff_get_n(v_sc_241, 3, 4); V a_1 = heff_rfield(v_d_244, 0); HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_247;
      heff_drop(v_x_248);
      V v_t_249 = heff_rec_n(3, shape_params__consts__marking, (V[]){v_params_243, v_consts_240, NTAG(TAG_False)});
      V v_body_2410 = (g_heff_2ecompile_2eranges_2ewalkDef(v_t_249, heff_dup(v_d_244)));
      return ({ V rv_2 = v_body_2410; V rr_ = heff_rec_reuse_nf(v_d_244, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    } else {
      heff_drop(v_params_243);
      heff_drop(v_consts_240);
      heff_drop(v_field_247);
      return v_d_244;
    }
  }
}
Clo g_heff_2ecompile_2eranges_2esettled_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2esettled_entry, 4, 0};

V g_heff_2ecompile_2eranges_2esettled(V v_consts_240, V v_sc_241, V v_defs_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_consts_240);
    heff_drop(v_sc_241);
    return heff_rec_n(2, shape_defs__words, (V[]){v_defs_242, heff_dup(g_std_2emap_2eempty_get())});
  }
  case TAG_Just: {
    V v_s_244 = heff_field(v_x4_243, 0);
    V v_fix_245 = heff_dup(heff_rfield(v_s_244, 0));
    V v_gathered_246 = heff_dup(heff_rfield(v_s_244, 2));
    V v_t_247 = heff_rec_n(3, shape_params__gathered__changed, (V[]){heff_dup(heff_rfield(v_fix_245, 0)), heff_dup(v_gathered_246), NTAG(TAG_Nil)});
    V v_t_248 = ({ V b_0 = heff_get_n(v_fix_245, 0, 3); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_249 = (g_list_2emap_24s1937570095x2110149801(v_t_248));
    V v_t_2410 = ({ V a_0 = heff_dup(v_sc_241); V a_1 = v_t_247; V a_2 = v_gathered_246; V a_3 = v_t_249; V r_ = (g_heff_2ecompile_2eranges_2enarrowWith(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
    V v_t_2411 = (g_heff_2ecompile_2eranges_2enarrowing(heff_dup(v_consts_240), heff_dup(v_sc_241), MK_INT(3LL), v_t_2410));
    HEFF_LAST return g_heff_2ecompile_2eranges_2erangedWith(v_consts_240, v_sc_241, v_defs_242, v_t_2411);
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eranges_2esettled_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eranges_2esettled(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2eranges_2ecorners_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ecorners_24tok2_entry, 5, 0};

V g_heff_2ecompile_2eranges_2ecorners_24tok2(V v_tok_240, V v_a_241, V v_b_242, V v_c_243, V v_d_244) {
top: ;
  V v_a_245;
  if (heff_intLt_c_lent(v_a_241, v_b_242, 0)) {
    v_a_245 = heff_dup(v_a_241);
  } else {
    v_a_245 = heff_dup(v_b_242);
  }
  V v_b_246;
  if (heff_intLt_c_lent(v_c_243, v_d_244, 0)) {
    v_b_246 = heff_dup(v_c_243);
  } else {
    v_b_246 = heff_dup(v_d_244);
  }
  V v_t_247;
  if (heff_intLt_c_lent(v_a_245, v_b_246, 0)) {
    heff_drop(v_b_246);
    v_t_247 = v_a_245;
  } else {
    heff_drop(v_a_245);
    v_t_247 = v_b_246;
  }
  V v_a_248;
  if (heff_intLt_c_lent(v_a_241, v_b_242, 0)) {
    heff_drop(v_a_241);
    v_a_248 = v_b_242;
  } else {
    heff_drop(v_b_242);
    v_a_248 = v_a_241;
  }
  V v_b_249;
  if (heff_intLt_c_lent(v_c_243, v_d_244, 0)) {
    heff_drop(v_c_243);
    v_b_249 = v_d_244;
  } else {
    heff_drop(v_d_244);
    v_b_249 = v_c_243;
  }
  V v_t_2410;
  if (heff_intLt_c_lent(v_a_248, v_b_249, 0)) {
    heff_drop(v_a_248);
    v_t_2410 = v_b_249;
  } else {
    heff_drop(v_b_249);
    v_t_2410 = v_a_248;
  }
  return heff_tag_at_n(v_tok_240, TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_t_247}), heff_tag_n(TAG_Just, 1, (V[]){v_t_2410})});
}
V g_heff_2ecompile_2eranges_2ecorners_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ecorners_24tok2(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2eranges_2edivPositive_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2edivPositive_24tok1_entry, 4, 0};

V g_heff_2ecompile_2eranges_2edivPositive_24tok1(V v_tok_240, V v_lb_241, V v_hb_242, V v_r_243) {
top: ;
  switch (heff_tag_of(v_r_243)) {
  case TAG_Unreached: {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_lb_241);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_Within: {
    V v_r1_244 = heff_field(v_r_243, 0);
    V v_r2_245 = heff_field(v_r_243, 1);
    V v_ru_24r_243_24Within = heff_take_reuse_n(v_r_243, 3ULL, 2);
    switch (heff_tag_of(v_r1_244)) {
    case TAG_Nothing: {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_lb_241);
      heff_drop(v_r2_245);
      heff_drop_cell(v_ru_24r_243_24Within, 2);
      return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
    }
    case TAG_Just: {
      V v_x_246 = heff_field(v_r1_244, 0);
      heff_take_n(v_r1_244, 1ULL, 1);
      switch (heff_tag_of(v_r2_245)) {
      case TAG_Nothing: {
        heff_drop_cell(v_tok_240, 1);
        heff_drop(v_lb_241);
        heff_drop_cell(v_ru_24r_243_24Within, 2);
        heff_drop(v_x_246);
        return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
      case TAG_Just: {
        V v_y_247 = heff_field(v_r2_245, 0);
        heff_take_n(v_r2_245, 1ULL, 1);
        V v_t_249;
        switch (heff_tag_of(v_hb_242)) {
        case TAG_Nothing: {
          if (heff_intLe_c_lent(MK_INT(0LL), v_x_246, 1)) {
            heff_drop(v_x_246);
            v_t_249 = MK_INT(0LL);
          } else {
            v_t_249 = heff_intDiv(v_x_246, heff_dup(v_lb_241));
          }
          break;
        }
        case TAG_Just: {
          V v_hb_248 = heff_field(v_hb_242, 0);
          if (heff_intLe_c_lent(MK_INT(0LL), v_x_246, 1)) {
            v_t_249 = heff_intDiv(v_x_246, heff_dup(v_hb_248));
          } else {
            v_t_249 = heff_intDiv(v_x_246, heff_dup(v_lb_241));
          }
          break;
        }
        default: heff_nomatch(v_hb_242);
        }
        V v_t_2411;
        switch (heff_tag_of(v_hb_242)) {
        case TAG_Nothing: {
          if (heff_intLe_c_lent(MK_INT(0LL), v_y_247, 1)) {
            v_t_2411 = heff_intDiv(v_y_247, v_lb_241);
          } else {
            heff_drop(v_lb_241);
            heff_drop(v_y_247);
            v_t_2411 = MK_INT(-1LL);
          }
          break;
        }
        case TAG_Just: {
          V v_hb_2410 = heff_field(v_hb_242, 0);
          if (heff_intLe_c_lent(MK_INT(0LL), v_y_247, 1)) {
            v_t_2411 = heff_intDiv(v_y_247, v_lb_241);
          } else {
            heff_drop(v_lb_241);
            v_t_2411 = heff_intDiv(v_y_247, heff_dup(v_hb_2410));
          }
          break;
        }
        default: heff_nomatch(v_hb_242);
        }
        return heff_tag_at_n(v_ru_24r_243_24Within, TAG_Within, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_t_249}), heff_tag_n(TAG_Just, 1, (V[]){v_t_2411})});
      }
      default: return heff_nomatch(v_r2_245);
      }
    }
    default: return heff_nomatch(v_r1_244);
    }
  }
  default: return heff_nomatch(v_r_243);
  }
}
V g_heff_2ecompile_2eranges_2edivPositive_24tok1_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eranges_2edivPositive_24tok1(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2eranges_2erootTo_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erootTo_24tok2_entry, 4, 0};

V g_heff_2ecompile_2eranges_2erootTo_24tok2(V v_tok_240, V v_env_241, V v_x_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_x_242);
    return v_env_241;
  }
  case TAG_Just: {
    V v_h_244 = heff_field(v_x3_243, 0);
    V v_ru_24x3_243_24Just = heff_take_reuse_n(v_x3_243, 1ULL, 1);
    if (heff_intLe_c_lent(MK_INT(0LL), v_h_244, 1)) {
      HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_env_241, 0), v_x_242));
      V v_t_249;
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          V v_x_248 = v_field_247;
          v_t_249 = v_x_248;
        } else {
          heff_drop(v_field_247);
          v_t_249 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
        }
      }
      V v_t_2410;
      if (heff_intLt_c_lent(v_h_244, MK_INT(2LL), 2)) {
        v_t_2410 = heff_dup(v_h_244);
      } else {
        v_t_2410 = heff_intAdd(heff_intDiv(heff_dup(v_h_244), MK_INT(2LL)), MK_INT(1LL));
      }
      V v_t_2411 = (g_heff_2ecompile_2eranges_2erootGo(heff_dup(v_h_244), MK_INT(0LL), v_t_2410));
      V v_t_2412 = heff_tag_at_n(v_ru_24x3_243_24Just, TAG_Just, 1, (V[]){heff_intSub(MK_INT(0LL), v_t_2411)});
      V v_t_2413;
      if (heff_intLt_c_lent(v_h_244, MK_INT(2LL), 2)) {
        v_t_2413 = heff_dup(v_h_244);
      } else {
        v_t_2413 = heff_intAdd(heff_intDiv(heff_dup(v_h_244), MK_INT(2LL)), MK_INT(1LL));
      }
      V v_t_2414 = (g_heff_2ecompile_2eranges_2erootGo(v_h_244, MK_INT(0LL), v_t_2413));
      V v_t_2415 = heff_tag_at_n(v_tok_240, TAG_Within, 2, (V[]){v_t_2412, heff_tag_n(TAG_Just, 1, (V[]){v_t_2414})});
      V v_t_2416 = (g_heff_2ecompile_2eranges_2emeet(v_t_249, v_t_2415));
      return (g_heff_2ecompile_2eranges_2ewithRange(v_env_241, v_x_242, v_t_2416));
    } else {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_x_242);
      heff_drop(v_h_244);
      heff_drop_cell(v_ru_24x3_243_24Just, 1);
      return v_env_241;
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2eranges_2erootTo_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2erootTo_24tok2(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eranges_2etrimHigh_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2etrimHigh_24tok2_entry, 3, 0};

V g_heff_2ecompile_2eranges_2etrimHigh_24tok2(V v_tok_240, V v_v_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_r_242)) {
  case TAG_Unreached: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_v_241);
    return v_r_242;
  }
  case TAG_Within: {
    V v_r2_244 = heff_dup(heff_field(v_r_242, 1));
    switch (heff_tag_of(v_r2_244)) {
    case TAG_Nothing: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_v_241);
      return v_r_242;
    }
    case TAG_Just: {
      V v_hi_245 = heff_field(v_r2_244, 0);
      heff_take_n(v_r2_244, 1ULL, 1);
      switch (heff_tag_of(v_r_242)) {
      case TAG_Within: {
        V v_lo_246 = heff_field(v_r_242, 0);
        heff_take_n(v_r_242, 1ULL, 2);
        if (heff_intEq_c_lent(v_hi_245, v_v_241, 0)) {
          heff_drop(v_hi_245);
          V v_t_248 = heff_intSub(v_v_241, MK_INT(1LL));
          switch (heff_tag_of(v_lo_246)) {
          case TAG_Nothing: {
            return heff_tag_at_n(v_tok_240, TAG_Within, 2, (V[]){v_lo_246, heff_tag_n(TAG_Just, 1, (V[]){v_t_248})});
          }
          case TAG_Just: {
            V v_lo_249 = heff_field(v_lo_246, 0);
            heff_take_n(v_lo_246, 1ULL, 1);
            if (heff_intLt_c_lent(v_t_248, v_lo_249, 0)) {
              heff_drop_cell(v_tok_240, 2);
              heff_drop(v_t_248);
              heff_drop(v_lo_249);
              return NTAG(TAG_Unreached);
            } else {
              return heff_tag_at_n(v_tok_240, TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_lo_249}), heff_tag_n(TAG_Just, 1, (V[]){v_t_248})});
            }
          }
          default: return heff_nomatch(v_lo_246);
          }
        } else {
          heff_drop(v_v_241);
          return heff_tag_at_n(v_tok_240, TAG_Within, 2, (V[]){v_lo_246, heff_tag_n(TAG_Just, 1, (V[]){v_hi_245})});
        }
      }
      default: return heff_nomatch(v_r_242);
      }
    }
    default: return heff_nomatch(v_r2_244);
    }
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2ecompile_2eranges_2etrimHigh_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2etrimHigh_24tok2(a[0], a[1], a[2]);
}