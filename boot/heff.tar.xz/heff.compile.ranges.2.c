// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkRes 5766
#define TAG_MkTest 41567
#define TAG_Unreached 46435
#define TAG_Within 10658
#define LBL_body 9524841
#define LBL_calls 295783919
#define LBL_changed 970801394
#define LBL_consts 592362651
#define LBL_defs 9574869
#define LBL_fix 310927
#define LBL_gathered 1327153563
#define LBL_ints 9732907
#define LBL_key 315609
#define LBL_marking 1071112247
#define LBL_marks 305024864
#define LBL_name 9869138
#define LBL_params 951713969
#define LBL_ranges 1008858625
#define LBL_tests 311609915
#define LBL_words 314676931
static uint32_t shape_calls__marks[] = {LBL_calls, LBL_marks};
static uint32_t shape_defs__words[] = {LBL_defs, LBL_words};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_params__consts__marking[] = {LBL_params, LBL_consts, LBL_marking};
static uint32_t shape_params__gathered__changed[] = {LBL_params, LBL_gathered, LBL_changed};
static uint32_t shape_ranges__tests[] = {LBL_ranges, LBL_tests};
V g_heff_2ecompile_2eranges_2eanyRange_get(void);
V g_heff_2ecompile_2eranges_2ecalledIn(V, V, V, V);
V g_heff_2ecompile_2eranges_2ecalledIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ecalledIn_clo;
V g_heff_2ecompile_2eranges_2ecorners(V, V, V, V);
V g_heff_2ecompile_2eranges_2ecorners_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ecorners_clo;
V g_heff_2ecompile_2eranges_2eemptyEnv_get(void);
V g_heff_2ecompile_2eranges_2eemptySt_get(void);
HeffT2 g_heff_2ecompile_2eranges_2egatherArms_24cpr(V, V, V, V, V, V);
V g_heff_2ecompile_2eranges_2egatherDef(V, V);
V g_heff_2ecompile_2eranges_2egatherDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egatherDef_clo;
V g_heff_2ecompile_2eranges_2egatherGo(V, V, V, V);
V g_heff_2ecompile_2eranges_2egatherGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egatherGo_clo;
HeffT2 g_heff_2ecompile_2eranges_2egatherGo_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2eranges_2egatherMany_24cpr(V, V, V, V);
V g_heff_2ecompile_2eranges_2eisComparison(V);
V g_heff_2ecompile_2eranges_2eisComparison_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eisComparison_clo;
V g_heff_2ecompile_2eranges_2ejoin(V, V);
V g_heff_2ecompile_2eranges_2ejoin_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ejoin_clo;
V g_heff_2ecompile_2eranges_2emarkRange(V, V);
V g_heff_2ecompile_2eranges_2emarkRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emarkRange_clo;
V g_heff_2ecompile_2eranges_2emulR(V, V);
V g_heff_2ecompile_2eranges_2emulR_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emulR_clo;
V g_heff_2ecompile_2eranges_2enarrowWith(V, V, V, V);
V g_heff_2ecompile_2eranges_2enarrowWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowWith_clo;
V g_heff_2ecompile_2eranges_2enarrowing(V, V, V, V);
V g_heff_2ecompile_2eranges_2enarrowing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowing_clo;
V g_heff_2ecompile_2eranges_2eoperandRange(V, V, V);
V g_heff_2ecompile_2eranges_2eoperandRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eoperandRange_clo;
HeffT2 g_heff_2ecompile_2eranges_2eplaceOf_24cpr(V, V, V);
V g_heff_2ecompile_2eranges_2eprimRange(V, V);
V g_heff_2ecompile_2eranges_2eprimRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eprimRange_clo;
V g_heff_2ecompile_2eranges_2erangeEq(V, V);
V g_heff_2ecompile_2eranges_2erangeEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangeEq_clo;
V g_heff_2ecompile_2eranges_2erangedWith(V, V, V, V);
V g_heff_2ecompile_2eranges_2erangedWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangedWith_clo;
V g_heff_2ecompile_2eranges_2erangesEq(V, V);
V g_heff_2ecompile_2eranges_2erangesEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangesEq_clo;
V g_heff_2ecompile_2eranges_2esettled(V, V, V, V);
V g_heff_2ecompile_2eranges_2esettled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2esettled_clo;
V g_heff_2ecompile_2eranges_2etestOf(V, V);
V g_heff_2ecompile_2eranges_2etestOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etestOf_clo;
HeffT2 g_heff_2ecompile_2eranges_2etestOf_24cpr(V, V);
V g_heff_2ecompile_2eranges_2etrimHigh(V, V);
V g_heff_2ecompile_2eranges_2etrimHigh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etrimHigh_clo;
V g_heff_2ecompile_2eranges_2ewalkDef(V, V);
V g_heff_2ecompile_2eranges_2ewalkDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewalkDef_clo;
HeffT2 g_heff_2ecompile_2eranges_2ewalkMany_24cpr(V, V, V);
V g_heff_2ecompile_2eranges_2ewidenLow(V, V, V);
V g_heff_2ecompile_2eranges_2ewidenLow_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewidenLow_clo;
V g_heff_2ecompile_2eranges_2ewithRange(V, V, V);
V g_heff_2ecompile_2eranges_2ewithRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewithRange_clo;
V g_heff_2ecompile_2eranges_2ewithTest(V, V, V);
V g_heff_2ecompile_2eranges_2ewithTest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewithTest_clo;
V g_list_2eall_24s853093203x77424416(V);
V g_list_2eall_24s853093203x77424416_entry(V self, V *a);
extern Clo g_list_2eall_24s853093203x77424416_clo;
V g_list_2efoldl_24s312236574x1326690653(V, V, V);
V g_list_2efoldl_24s312236574x1326690653_entry(V self, V *a);
extern Clo g_list_2efoldl_24s312236574x1326690653_clo;
V g_list_2efoldl_24s518632429x1911716206(V, V);
V g_list_2efoldl_24s518632429x1911716206_entry(V self, V *a);
extern Clo g_list_2efoldl_24s518632429x1911716206_clo;
V g_list_2efoldl_24s629835174x643023540(V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s629835174x643023540_entry(V self, V *a);
extern Clo g_list_2efoldl_24s629835174x643023540_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2ezipWith_24s1026658656x682908126(V, V);
V g_list_2ezipWith_24s1026658656x682908126_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1026658656x682908126_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2ecompile_2eranges_2ejoin_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ejoin_entry, 2, 0};

V g_heff_2ecompile_2eranges_2ejoin(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Unreached: {
    return v_x2_241;
  }
  case TAG_Within: {
    V v_a_242 = heff_dup(heff_field(v_x1_240, 0));
    V v_b_243 = heff_dup(heff_field(v_x1_240, 1));
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Unreached: {
      heff_drop(v_a_242);
      heff_drop(v_b_243);
      return v_x1_240;
    }
    case TAG_Within: {
      V v_c_244 = heff_field(v_x2_241, 0);
      V v_d_245 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Within = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      heff_drop_tag(v_x1_240, 2);
      V v_t_2410;
      switch (heff_tag_of(v_a_242)) {
      case TAG_Nothing: {
        heff_drop(v_c_244);
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_a_246 = heff_field(v_a_242, 0);
        V v_ru_24a_242_24Just = heff_take_reuse_n(v_a_242, 1ULL, 1);
        switch (heff_tag_of(v_c_244)) {
        case TAG_Nothing: {
          heff_drop(v_a_246);
          heff_drop_cell(v_ru_24a_242_24Just, 1);
          v_t_2410 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_b_247 = heff_field(v_c_244, 0);
          heff_take_n(v_c_244, 1ULL, 1);
          V v_t_249;
          if (heff_intLt_c_lent(v_a_246, v_b_247, 0)) {
            heff_drop(v_b_247);
            v_t_249 = v_a_246;
          } else {
            heff_drop(v_a_246);
            v_t_249 = v_b_247;
          }
          v_t_2410 = heff_tag_at_n(v_ru_24a_242_24Just, TAG_Just, 1, (V[]){v_t_249});
          break;
        }
        default: heff_nomatch(v_c_244);
        }
        break;
      }
      default: heff_nomatch(v_a_242);
      }
      V v_t_2415;
      switch (heff_tag_of(v_b_243)) {
      case TAG_Nothing: {
        heff_drop(v_d_245);
        v_t_2415 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_a_2411 = heff_field(v_b_243, 0);
        V v_ru_24b_243_24Just = heff_take_reuse_n(v_b_243, 1ULL, 1);
        switch (heff_tag_of(v_d_245)) {
        case TAG_Nothing: {
          heff_drop(v_a_2411);
          heff_drop_cell(v_ru_24b_243_24Just, 1);
          v_t_2415 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_b_2412 = heff_field(v_d_245, 0);
          heff_take_n(v_d_245, 1ULL, 1);
          V v_t_2414;
          if (heff_intLt_c_lent(v_a_2411, v_b_2412, 0)) {
            heff_drop(v_a_2411);
            v_t_2414 = v_b_2412;
          } else {
            heff_drop(v_b_2412);
            v_t_2414 = v_a_2411;
          }
          v_t_2415 = heff_tag_at_n(v_ru_24b_243_24Just, TAG_Just, 1, (V[]){v_t_2414});
          break;
        }
        default: heff_nomatch(v_d_245);
        }
        break;
      }
      default: heff_nomatch(v_b_243);
      }
      return heff_tag_at_n(v_ru_24x2_241_24Within, TAG_Within, 2, (V[]){v_t_2410, v_t_2415});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eranges_2ejoin_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ejoin(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2emulR_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2emulR_entry, 2, 0};

V g_heff_2ecompile_2eranges_2emulR(V v_r_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_r_240)) {
  case TAG_Unreached: {
    heff_drop(v_s_241);
    return NTAG(TAG_Unreached);
  }
  case TAG_Within: {
    V v_r1_242 = heff_field(v_r_240, 0);
    V v_r2_243 = heff_field(v_r_240, 1);
    V v_ru_24r_240_24Within = heff_take_reuse_n(v_r_240, 3ULL, 2);
    switch (heff_tag_of(v_r1_242)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_s_241)) {
      case TAG_Unreached: {
        heff_drop(v_r2_243);
        heff_drop_cell(v_ru_24r_240_24Within, 2);
        return NTAG(TAG_Unreached);
      }
      case TAG_Within: {
        V v_c_244 = heff_field(v_s_241, 0);
        V v_d_245 = heff_field(v_s_241, 1);
        heff_take_n(v_s_241, 3ULL, 2);
        switch (heff_tag_of(v_r1_242)) {
        case TAG_Nothing: {
          heff_drop(v_r2_243);
          heff_drop_cell(v_ru_24r_240_24Within, 2);
          heff_drop(v_c_244);
          heff_drop(v_d_245);
          return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
        }
        case TAG_Just: {
          V v_a_246 = heff_dup(heff_field(v_r1_242, 0));
          if (heff_intLe_c(MK_INT(0LL), v_a_246)) {
            switch (heff_tag_of(v_c_244)) {
            case TAG_Nothing: {
              heff_drop_tag(v_r1_242, 1);
              heff_drop(v_r2_243);
              heff_drop_cell(v_ru_24r_240_24Within, 2);
              heff_drop(v_d_245);
              return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
            }
            case TAG_Just: {
              V v_a_248 = heff_dup(heff_field(v_c_244, 0));
              if (heff_intLe_c(MK_INT(0LL), v_a_248)) {
                V v_t_2412;
                switch (heff_tag_of(v_r1_242)) {
                case TAG_Nothing: {
                  heff_drop_tag(v_c_244, 1);
                  v_t_2412 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_a_2410 = heff_field(v_r1_242, 0);
                  V v_ru_24r1_242_24Just = heff_take_reuse_n(v_r1_242, 1ULL, 1);
                  switch (heff_tag_of(v_c_244)) {
                  case TAG_Nothing: {
                    heff_drop(v_a_2410);
                    heff_drop_cell(v_ru_24r1_242_24Just, 1);
                    v_t_2412 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_b_2411 = heff_field(v_c_244, 0);
                    heff_take_n(v_c_244, 1ULL, 1);
                    v_t_2412 = heff_tag_at_n(v_ru_24r1_242_24Just, TAG_Just, 1, (V[]){heff_intMul(v_a_2410, v_b_2411)});
                    break;
                  }
                  default: heff_nomatch(v_c_244);
                  }
                  break;
                }
                default: heff_nomatch(v_r1_242);
                }
                V v_t_2415;
                switch (heff_tag_of(v_r2_243)) {
                case TAG_Nothing: {
                  heff_drop(v_d_245);
                  v_t_2415 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_a_2413 = heff_field(v_r2_243, 0);
                  V v_ru_24r2_243_24Just = heff_take_reuse_n(v_r2_243, 1ULL, 1);
                  switch (heff_tag_of(v_d_245)) {
                  case TAG_Nothing: {
                    heff_drop(v_a_2413);
                    heff_drop_cell(v_ru_24r2_243_24Just, 1);
                    v_t_2415 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_b_2414 = heff_field(v_d_245, 0);
                    heff_take_n(v_d_245, 1ULL, 1);
                    v_t_2415 = heff_tag_at_n(v_ru_24r2_243_24Just, TAG_Just, 1, (V[]){heff_intMul(v_a_2413, v_b_2414)});
                    break;
                  }
                  default: heff_nomatch(v_d_245);
                  }
                  break;
                }
                default: heff_nomatch(v_r2_243);
                }
                return heff_tag_at_n(v_ru_24r_240_24Within, TAG_Within, 2, (V[]){v_t_2412, v_t_2415});
              } else {
                heff_drop_tag(v_r1_242, 1);
                heff_drop(v_r2_243);
                heff_drop_cell(v_ru_24r_240_24Within, 2);
                heff_drop_tag(v_c_244, 1);
                heff_drop(v_d_245);
                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
            }
            default: return heff_nomatch(v_c_244);
            }
          } else {
            heff_drop_tag(v_r1_242, 1);
            heff_drop(v_r2_243);
            heff_drop_cell(v_ru_24r_240_24Within, 2);
            heff_drop(v_c_244);
            heff_drop(v_d_245);
            return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
        }
        default: return heff_nomatch(v_r1_242);
        }
      }
      default: return heff_nomatch(v_s_241);
      }
    }
    case TAG_Just: {
      V v_a_2416 = heff_dup(heff_field(v_r1_242, 0));
      switch (heff_tag_of(v_r2_243)) {
      case TAG_Nothing: {
        heff_drop(v_a_2416);
        switch (heff_tag_of(v_s_241)) {
        case TAG_Unreached: {
          heff_drop_tag(v_r1_242, 1);
          heff_drop_cell(v_ru_24r_240_24Within, 2);
          return NTAG(TAG_Unreached);
        }
        case TAG_Within: {
          V v_c_2417 = heff_field(v_s_241, 0);
          V v_d_2418 = heff_field(v_s_241, 1);
          heff_take_n(v_s_241, 3ULL, 2);
          switch (heff_tag_of(v_r1_242)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24r_240_24Within, 2);
            heff_drop(v_c_2417);
            heff_drop(v_d_2418);
            return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
          case TAG_Just: {
            V v_a_2419 = heff_dup(heff_field(v_r1_242, 0));
            if (heff_intLe_c(MK_INT(0LL), v_a_2419)) {
              switch (heff_tag_of(v_c_2417)) {
              case TAG_Nothing: {
                heff_drop_tag(v_r1_242, 1);
                heff_drop_cell(v_ru_24r_240_24Within, 2);
                heff_drop(v_d_2418);
                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
              case TAG_Just: {
                V v_a_2421 = heff_dup(heff_field(v_c_2417, 0));
                if (heff_intLe_c(MK_INT(0LL), v_a_2421)) {
                  V v_t_2425;
                  switch (heff_tag_of(v_r1_242)) {
                  case TAG_Nothing: {
                    heff_drop_tag(v_c_2417, 1);
                    v_t_2425 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_a_2423 = heff_field(v_r1_242, 0);
                    V v_ru_24r1_242_24Just = heff_take_reuse_n(v_r1_242, 1ULL, 1);
                    switch (heff_tag_of(v_c_2417)) {
                    case TAG_Nothing: {
                      heff_drop(v_a_2423);
                      heff_drop_cell(v_ru_24r1_242_24Just, 1);
                      v_t_2425 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_Just: {
                      V v_b_2424 = heff_field(v_c_2417, 0);
                      heff_take_n(v_c_2417, 1ULL, 1);
                      v_t_2425 = heff_tag_at_n(v_ru_24r1_242_24Just, TAG_Just, 1, (V[]){heff_intMul(v_a_2423, v_b_2424)});
                      break;
                    }
                    default: heff_nomatch(v_c_2417);
                    }
                    break;
                  }
                  default: heff_nomatch(v_r1_242);
                  }
                  V v_t_2428;
                  switch (heff_tag_of(v_r2_243)) {
                  case TAG_Nothing: {
                    heff_drop(v_d_2418);
                    v_t_2428 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_a_2426 = heff_field(v_r2_243, 0);
                    V v_ru_24r2_243_24Just = heff_take_reuse_n(v_r2_243, 1ULL, 1);
                    switch (heff_tag_of(v_d_2418)) {
                    case TAG_Nothing: {
                      heff_drop(v_a_2426);
                      heff_drop_cell(v_ru_24r2_243_24Just, 1);
                      v_t_2428 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_Just: {
                      V v_b_2427 = heff_field(v_d_2418, 0);
                      heff_take_n(v_d_2418, 1ULL, 1);
                      v_t_2428 = heff_tag_at_n(v_ru_24r2_243_24Just, TAG_Just, 1, (V[]){heff_intMul(v_a_2426, v_b_2427)});
                      break;
                    }
                    default: heff_nomatch(v_d_2418);
                    }
                    break;
                  }
                  default: heff_nomatch(v_r2_243);
                  }
                  return heff_tag_at_n(v_ru_24r_240_24Within, TAG_Within, 2, (V[]){v_t_2425, v_t_2428});
                } else {
                  heff_drop_tag(v_r1_242, 1);
                  heff_drop_cell(v_ru_24r_240_24Within, 2);
                  heff_drop_tag(v_c_2417, 1);
                  heff_drop(v_d_2418);
                  return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                }
              }
              default: return heff_nomatch(v_c_2417);
              }
            } else {
              heff_drop_tag(v_r1_242, 1);
              heff_drop_cell(v_ru_24r_240_24Within, 2);
              heff_drop(v_c_2417);
              heff_drop(v_d_2418);
              return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
            }
          }
          default: return heff_nomatch(v_r1_242);
          }
        }
        default: return heff_nomatch(v_s_241);
        }
      }
      case TAG_Just: {
        V v_b_2429 = heff_dup(heff_field(v_r2_243, 0));
        switch (heff_tag_of(v_s_241)) {
        case TAG_Unreached: {
          heff_drop_tag(v_r1_242, 1);
          heff_drop_tag(v_r2_243, 1);
          heff_drop_cell(v_ru_24r_240_24Within, 2);
          heff_drop(v_a_2416);
          heff_drop(v_b_2429);
          return NTAG(TAG_Unreached);
        }
        case TAG_Within: {
          V v_s1_2430 = heff_field(v_s_241, 0);
          V v_s2_2431 = heff_field(v_s_241, 1);
          heff_take_n(v_s_241, 3ULL, 2);
          switch (heff_tag_of(v_s1_2430)) {
          case TAG_Nothing: {
            heff_drop(v_a_2416);
            heff_drop(v_b_2429);
            switch (heff_tag_of(v_r1_242)) {
            case TAG_Nothing: {
              heff_drop_tag(v_r2_243, 1);
              heff_drop_cell(v_ru_24r_240_24Within, 2);
              heff_drop(v_s2_2431);
              return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
            }
            case TAG_Just: {
              V v_a_2432 = heff_dup(heff_field(v_r1_242, 0));
              if (heff_intLe_c(MK_INT(0LL), v_a_2432)) {
                switch (heff_tag_of(v_s1_2430)) {
                case TAG_Nothing: {
                  heff_drop_tag(v_r1_242, 1);
                  heff_drop_tag(v_r2_243, 1);
                  heff_drop_cell(v_ru_24r_240_24Within, 2);
                  heff_drop(v_s2_2431);
                  return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                }
                case TAG_Just: {
                  V v_a_2434 = heff_dup(heff_field(v_s1_2430, 0));
                  if (heff_intLe_c(MK_INT(0LL), v_a_2434)) {
                    V v_t_2438;
                    switch (heff_tag_of(v_r1_242)) {
                    case TAG_Nothing: {
                      heff_drop_tag(v_s1_2430, 1);
                      v_t_2438 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_Just: {
                      V v_a_2436 = heff_field(v_r1_242, 0);
                      V v_ru_24r1_242_24Just = heff_take_reuse_n(v_r1_242, 1ULL, 1);
                      switch (heff_tag_of(v_s1_2430)) {
                      case TAG_Nothing: {
                        heff_drop(v_a_2436);
                        heff_drop_cell(v_ru_24r1_242_24Just, 1);
                        v_t_2438 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Just: {
                        V v_b_2437 = heff_field(v_s1_2430, 0);
                        heff_take_n(v_s1_2430, 1ULL, 1);
                        v_t_2438 = heff_tag_at_n(v_ru_24r1_242_24Just, TAG_Just, 1, (V[]){heff_intMul(v_a_2436, v_b_2437)});
                        break;
                      }
                      default: heff_nomatch(v_s1_2430);
                      }
                      break;
                    }
                    default: heff_nomatch(v_r1_242);
                    }
                    V v_t_2441;
                    switch (heff_tag_of(v_r2_243)) {
                    case TAG_Nothing: {
                      heff_drop(v_s2_2431);
                      v_t_2441 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_Just: {
                      V v_a_2439 = heff_field(v_r2_243, 0);
                      V v_ru_24r2_243_24Just = heff_take_reuse_n(v_r2_243, 1ULL, 1);
                      switch (heff_tag_of(v_s2_2431)) {
                      case TAG_Nothing: {
                        heff_drop(v_a_2439);
                        heff_drop_cell(v_ru_24r2_243_24Just, 1);
                        v_t_2441 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Just: {
                        V v_b_2440 = heff_field(v_s2_2431, 0);
                        heff_take_n(v_s2_2431, 1ULL, 1);
                        v_t_2441 = heff_tag_at_n(v_ru_24r2_243_24Just, TAG_Just, 1, (V[]){heff_intMul(v_a_2439, v_b_2440)});
                        break;
                      }
                      default: heff_nomatch(v_s2_2431);
                      }
                      break;
                    }
                    default: heff_nomatch(v_r2_243);
                    }
                    return heff_tag_at_n(v_ru_24r_240_24Within, TAG_Within, 2, (V[]){v_t_2438, v_t_2441});
                  } else {
                    heff_drop_tag(v_r1_242, 1);
                    heff_drop_tag(v_r2_243, 1);
                    heff_drop_cell(v_ru_24r_240_24Within, 2);
                    heff_drop_tag(v_s1_2430, 1);
                    heff_drop(v_s2_2431);
                    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                  }
                }
                default: return heff_nomatch(v_s1_2430);
                }
              } else {
                heff_drop_tag(v_r1_242, 1);
                heff_drop_tag(v_r2_243, 1);
                heff_drop_cell(v_ru_24r_240_24Within, 2);
                heff_drop(v_s2_2431);
                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
            }
            default: return heff_nomatch(v_r1_242);
            }
          }
          case TAG_Just: {
            V v_c_2442 = heff_dup(heff_field(v_s1_2430, 0));
            switch (heff_tag_of(v_s2_2431)) {
            case TAG_Nothing: {
              heff_drop(v_a_2416);
              heff_drop(v_b_2429);
              heff_drop(v_c_2442);
              switch (heff_tag_of(v_r1_242)) {
              case TAG_Nothing: {
                heff_drop_tag(v_r2_243, 1);
                heff_drop_cell(v_ru_24r_240_24Within, 2);
                heff_drop_tag(v_s1_2430, 1);
                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
              case TAG_Just: {
                V v_a_2443 = heff_dup(heff_field(v_r1_242, 0));
                if (heff_intLe_c(MK_INT(0LL), v_a_2443)) {
                  switch (heff_tag_of(v_s1_2430)) {
                  case TAG_Nothing: {
                    heff_drop_tag(v_r1_242, 1);
                    heff_drop_tag(v_r2_243, 1);
                    heff_drop_cell(v_ru_24r_240_24Within, 2);
                    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                  }
                  case TAG_Just: {
                    V v_a_2445 = heff_dup(heff_field(v_s1_2430, 0));
                    if (heff_intLe_c(MK_INT(0LL), v_a_2445)) {
                      V v_t_2449;
                      switch (heff_tag_of(v_r1_242)) {
                      case TAG_Nothing: {
                        heff_drop_tag(v_s1_2430, 1);
                        v_t_2449 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Just: {
                        V v_a_2447 = heff_field(v_r1_242, 0);
                        V v_ru_24r1_242_24Just = heff_take_reuse_n(v_r1_242, 1ULL, 1);
                        switch (heff_tag_of(v_s1_2430)) {
                        case TAG_Nothing: {
                          heff_drop(v_a_2447);
                          heff_drop_cell(v_ru_24r1_242_24Just, 1);
                          v_t_2449 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_Just: {
                          V v_b_2448 = heff_field(v_s1_2430, 0);
                          heff_take_n(v_s1_2430, 1ULL, 1);
                          v_t_2449 = heff_tag_at_n(v_ru_24r1_242_24Just, TAG_Just, 1, (V[]){heff_intMul(v_a_2447, v_b_2448)});
                          break;
                        }
                        default: heff_nomatch(v_s1_2430);
                        }
                        break;
                      }
                      default: heff_nomatch(v_r1_242);
                      }
                      V v_t_2452;
                      switch (heff_tag_of(v_r2_243)) {
                      case TAG_Nothing: {
                        v_t_2452 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Just: {
                        V v_a_2450 = heff_field(v_r2_243, 0);
                        V v_ru_24r2_243_24Just = heff_take_reuse_n(v_r2_243, 1ULL, 1);
                        switch (heff_tag_of(v_s2_2431)) {
                        case TAG_Nothing: {
                          heff_drop(v_a_2450);
                          heff_drop_cell(v_ru_24r2_243_24Just, 1);
                          v_t_2452 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_Just: {
                          V v_b_2451 = heff_field(v_s2_2431, 0);
                          heff_take_n(v_s2_2431, 1ULL, 1);
                          v_t_2452 = heff_tag_at_n(v_ru_24r2_243_24Just, TAG_Just, 1, (V[]){heff_intMul(v_a_2450, v_b_2451)});
                          break;
                        }
                        default: heff_nomatch(v_s2_2431);
                        }
                        break;
                      }
                      default: heff_nomatch(v_r2_243);
                      }
                      return heff_tag_at_n(v_ru_24r_240_24Within, TAG_Within, 2, (V[]){v_t_2449, v_t_2452});
                    } else {
                      heff_drop_tag(v_r1_242, 1);
                      heff_drop_tag(v_r2_243, 1);
                      heff_drop_cell(v_ru_24r_240_24Within, 2);
                      heff_drop_tag(v_s1_2430, 1);
                      return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                    }
                  }
                  default: return heff_nomatch(v_s1_2430);
                  }
                } else {
                  heff_drop_tag(v_r1_242, 1);
                  heff_drop_tag(v_r2_243, 1);
                  heff_drop_cell(v_ru_24r_240_24Within, 2);
                  heff_drop_tag(v_s1_2430, 1);
                  return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                }
              }
              default: return heff_nomatch(v_r1_242);
              }
            }
            case TAG_Just: {
              V v_d_2453 = heff_field(v_s2_2431, 0);
              heff_take_n(v_s2_2431, 1ULL, 1);
              heff_drop_tag(v_r1_242, 1);
              heff_drop_tag(v_r2_243, 1);
              heff_drop_cell(v_ru_24r_240_24Within, 2);
              heff_drop_tag(v_s1_2430, 1);
              return (g_heff_2ecompile_2eranges_2ecorners(heff_intMul(heff_dup(v_a_2416), heff_dup(v_c_2442)), heff_intMul(v_a_2416, heff_dup(v_d_2453)), heff_intMul(heff_dup(v_b_2429), v_c_2442), heff_intMul(v_b_2429, v_d_2453)));
            }
            default: return heff_nomatch(v_s2_2431);
            }
          }
          default: return heff_nomatch(v_s1_2430);
          }
        }
        default: return heff_nomatch(v_s_241);
        }
      }
      default: return heff_nomatch(v_r2_243);
      }
    }
    default: return heff_nomatch(v_r1_242);
    }
  }
  default: return heff_nomatch(v_r_240);
  }
}
V g_heff_2ecompile_2eranges_2emulR_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2emulR(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2etrimHigh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2etrimHigh_entry, 2, 0};

V g_heff_2ecompile_2eranges_2etrimHigh(V v_v_240, V v_r_241) {
top: ;
  switch (heff_tag_of(v_r_241)) {
  case TAG_Unreached: {
    heff_drop(v_v_240);
    return v_r_241;
  }
  case TAG_Within: {
    V v_lo_242 = heff_dup(heff_field(v_r_241, 0));
    V v_r2_243 = heff_dup(heff_field(v_r_241, 1));
    switch (heff_tag_of(v_r2_243)) {
    case TAG_Nothing: {
      heff_drop(v_v_240);
      heff_drop(v_lo_242);
      return v_r_241;
    }
    case TAG_Just: {
      V v_hi_244 = heff_field(v_r2_243, 0);
      V v_ru_24r2_243_24Just = heff_take_reuse_n(v_r2_243, 1ULL, 1);
      heff_drop_tag(v_r_241, 2);
      if (heff_intEq_c_lent(v_hi_244, v_v_240, 0)) {
        heff_drop(v_hi_244);
        V v_t_246 = heff_intSub(v_v_240, MK_INT(1LL));
        switch (heff_tag_of(v_lo_242)) {
        case TAG_Nothing: {
          return heff_tag_n(TAG_Within, 2, (V[]){v_lo_242, heff_tag_at_n(v_ru_24r2_243_24Just, TAG_Just, 1, (V[]){v_t_246})});
        }
        case TAG_Just: {
          V v_lo_247 = heff_field(v_lo_242, 0);
          V v_ru_24lo_242_24Just = heff_take_reuse_n(v_lo_242, 1ULL, 1);
          if (heff_intLt_c_lent(v_t_246, v_lo_247, 0)) {
            heff_drop_cell(v_ru_24r2_243_24Just, 1);
            heff_drop(v_t_246);
            heff_drop(v_lo_247);
            heff_drop_cell(v_ru_24lo_242_24Just, 1);
            return NTAG(TAG_Unreached);
          } else {
            return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24r2_243_24Just, TAG_Just, 1, (V[]){v_lo_247}), heff_tag_at_n(v_ru_24lo_242_24Just, TAG_Just, 1, (V[]){v_t_246})});
          }
        }
        default: return heff_nomatch(v_lo_242);
        }
      } else {
        heff_drop(v_v_240);
        return heff_tag_n(TAG_Within, 2, (V[]){v_lo_242, heff_tag_at_n(v_ru_24r2_243_24Just, TAG_Just, 1, (V[]){v_hi_244})});
      }
    }
    default: return heff_nomatch(v_r2_243);
    }
  }
  default: return heff_nomatch(v_r_241);
  }
}
V g_heff_2ecompile_2eranges_2etrimHigh_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2etrimHigh(a[0], a[1]);
}

static V g_heff_2ecompile_2eranges_2eemptySt_val;
static HEFF_ONCE g_heff_2ecompile_2eranges_2eemptySt_st;
static V g_heff_2ecompile_2eranges_2eemptySt_init(void) {
  return heff_rec_n(2, shape_calls__marks, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get())});
}
V g_heff_2ecompile_2eranges_2eemptySt_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eranges_2eemptySt_st)) return g_heff_2ecompile_2eranges_2eemptySt_val;
  return heff_global(&g_heff_2ecompile_2eranges_2eemptySt_val, &g_heff_2ecompile_2eranges_2eemptySt_st, g_heff_2ecompile_2eranges_2eemptySt_init);
}
Clo g_heff_2ecompile_2eranges_2eoperandRange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2eoperandRange_entry, 3, 0};

V g_heff_2ecompile_2eranges_2eoperandRange(V v_c_240, V v_env_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_c_240, 3);
    HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_env_241, 0, 2); V a_1 = v_x_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_243); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_246;
        return v_x_248;
      } else {
        heff_drop(v_field_246);
        return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
    }
  }
  case TAG_EGlobal: {
    V v_g_249 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EGlobal = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_env_241, 2);
    HeffT2 v_t_2410 = ({ V b_0 = heff_get_n(v_c_240, 1, 3); V a_1 = v_g_249; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_g_249); r_; });
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_x_2414 = v_field_2412;
        return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24e_242_24EGlobal, TAG_Just, 1, (V[]){heff_dup(v_x_2414)}), heff_tag_n(TAG_Just, 1, (V[]){v_x_2414})});
      } else {
        heff_drop_cell(v_ru_24e_242_24EGlobal, 1);
        heff_drop(v_field_2412);
        return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
    }
  }
  case TAG_ELam: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EApp: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_ELet: {
    heff_take_n(v_e_242, 0ULL, 3);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_ERecord: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EProj: {
    heff_take_n(v_e_242, 0ULL, 4);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_ETag: {
    heff_take_n(v_e_242, 0ULL, 3);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EMatch: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EPrim: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EPrimCall: {
    V v_p_2434 = heff_field(v_e_242, 0);
    V v_args_2435 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2436 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2eoperandRange_clo), 2, (V[]){v_c_240, v_env_241}));
    V v_t_2437 = (g_list_2emap(v_t_2436, v_args_2435));
    return ({ V a_0 = v_p_2434; V a_1 = v_t_2437; V r_ = (g_heff_2ecompile_2eranges_2eprimRange(a_0, a_1)); heff_drop(v_p_2434); heff_drop(v_t_2437); r_; });
  }
  case TAG_ECall: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EInt: {
    V v_n_2440 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EInt = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24e_242_24EInt, TAG_Just, 1, (V[]){heff_dup(v_n_2440)}), heff_tag_n(TAG_Just, 1, (V[]){v_n_2440})});
  }
  case TAG_EFloat: {
    heff_take_na(v_e_242, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EStr: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EBytes: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EFixed: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_242, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_EFix: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eranges_2eoperandRange_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2eoperandRange(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eranges_2ewithRange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ewithRange_entry, 3, 0};

V g_heff_2ecompile_2eranges_2ewithRange(V v_env_240, V v_x_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_r_242)) {
  case TAG_Unreached: {
    V v_t_243 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_env_240, 0), v_x_241, v_r_242));
    return ({ V rv_0 = v_t_243; V rr_ = heff_rec_reuse_nf(v_env_240, 2ULL, 2, shape_ranges__tests, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
  case TAG_Within: {
    V v_r1_244 = heff_dup(heff_field(v_r_242, 0));
    V v_r2_245 = heff_dup(heff_field(v_r_242, 1));
    switch (heff_tag_of(v_r1_244)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_r2_245)) {
      case TAG_Nothing: {
        heff_drop(v_x_241);
        heff_drop_tag(v_r_242, 2);
        return v_env_240;
      }
      case TAG_Just: {
        heff_take_n(v_r2_245, 0ULL, 1);
        V v_t_247 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_env_240, 0), v_x_241, v_r_242));
        return ({ V rv_0 = v_t_247; V rr_ = heff_rec_reuse_nf(v_env_240, 2ULL, 2, shape_ranges__tests, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      }
      default: return heff_nomatch(v_r2_245);
      }
    }
    case TAG_Just: {
      heff_take_n(v_r1_244, 0ULL, 1);
      heff_drop(v_r2_245);
      V v_t_249 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_env_240, 0), v_x_241, v_r_242));
      return ({ V rv_0 = v_t_249; V rr_ = heff_rec_reuse_nf(v_env_240, 2ULL, 2, shape_ranges__tests, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    }
    default: return heff_nomatch(v_r1_244);
    }
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2ecompile_2eranges_2ewithRange_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ewithRange(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2eranges_2etestOf_24cpr(V v_env_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    return ({ V b_0 = heff_get_n(v_env_240, 1, 2); V a_1 = v_x_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_242); r_; });
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop_rec(v_env_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_take_n(v_e_241, 0ULL, 4);
    heff_drop_rec(v_env_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop_rec(v_env_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    V v_p_2423 = heff_field(v_e_241, 0);
    V v_e2_2424 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    heff_drop_rec(v_env_240, 2);
    switch (heff_tag_of(v_e2_2424)) {
    case TAG_Nil: {
      heff_drop(v_p_2423);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_a_2425 = heff_field(v_e2_2424, 0);
      V v_e22_2426 = heff_field(v_e2_2424, 1);
      heff_take_n(v_e2_2424, 3ULL, 2);
      switch (heff_tag_of(v_e22_2426)) {
      case TAG_Nil: {
        heff_drop(v_p_2423);
        heff_drop(v_a_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_b_2427 = heff_field(v_e22_2426, 0);
        V v_e222_2428 = heff_field(v_e22_2426, 1);
        heff_take_n(v_e22_2426, 3ULL, 2);
        switch (heff_tag_of(v_e222_2428)) {
        case TAG_Nil: {
          V v_t_2429 = (g_heff_2ecompile_2eranges_2eisComparison(heff_dup(v_p_2423)));
          if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
            heff_drop(v_t_2429);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkTest, 3, (V[]){v_p_2423, v_a_2425, v_b_2427})}});
          } else {
            heff_drop(v_p_2423);
            heff_drop(v_a_2425);
            heff_drop(v_b_2427);
            heff_drop(v_t_2429);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_e222_2428, 0ULL, 2);
          heff_drop(v_p_2423);
          heff_drop(v_a_2425);
          heff_drop(v_b_2427);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_e222_2428)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_e22_2426)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_e2_2424)}});
    }
  }
  case TAG_ECall: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_env_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_241)}});
  }
}
Clo g_heff_2ecompile_2eranges_2ecalledIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ecalledIn_entry, 4, 0};

V g_heff_2ecompile_2eranges_2ecalledIn(V v_c_240, V v_g_241, V v_rs_242, V v_st_243) {
top: ;
  HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_c_240, 0, 3); V a_1 = v_g_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_ps_248 = v_field_246;
      V v_t_249 = ({ V a_0 = v_ps_248; V r_ = (g_list_2eall_24s853093203x77424416(a_0)); heff_drop(v_ps_248); r_; });
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_g_241);
        heff_drop(v_rs_242);
        heff_drop(v_t_249);
        return v_st_243;
      } else {
        heff_drop(v_t_249);
        HeffT2 v_t_2410 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_st_243, 0), v_g_241));
        V v_t_2415;
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            V v_x_2414 = v_field_2412;
            v_t_2415 = (g_list_2ezipWith_24s1026658656x682908126(v_rs_242, v_x_2414));
          } else {
            heff_drop(v_field_2412);
            v_t_2415 = v_rs_242;
          }
        }
        V v_t_2416 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_st_243, 0), v_g_241, v_t_2415));
        return ({ V rv_0 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_st_243, 2ULL, 2, shape_calls__marks, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      }
    } else {
      heff_drop(v_g_241);
      heff_drop(v_rs_242);
      heff_drop(v_field_246);
      return v_st_243;
    }
  }
}
V g_heff_2ecompile_2eranges_2ecalledIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ecalledIn(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2ecompile_2eranges_2egatherGo_24cpr(V v_c_240, V v_env_241, V v_st_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    V v_x_244 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 3);
    HeffT2 v_t_245 = ({ V b_0 = heff_get_n(v_env_241, 0, 2); V a_1 = v_x_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_244); r_; });
    V v_f_2410;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        v_f_2410 = v_x_249;
      } else {
        heff_drop(v_field_247);
        v_f_2410 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
    }
    return ((HeffT2){{v_f_2410, v_st_242}});
  }
  case TAG_EGlobal: {
    V v_g_2411 = heff_field(v_e_243, 0);
    V v_ru_24e_243_24EGlobal = heff_take_reuse_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_env_241, 2);
    HeffT2 v_t_2412 = ({ V b_0 = heff_get_n(v_c_240, 1, 3); V a_1 = v_g_2411; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_g_2411); r_; });
    V v_f_2417;
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        V v_x_2416 = v_field_2414;
        v_f_2417 = heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24e_243_24EGlobal, TAG_Just, 1, (V[]){heff_dup(v_x_2416)}), heff_tag_n(TAG_Just, 1, (V[]){v_x_2416})});
      } else {
        heff_drop_cell(v_ru_24e_243_24EGlobal, 1);
        heff_drop(v_field_2414);
        v_f_2417 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
    }
    return ((HeffT2){{v_f_2417, v_st_242}});
  }
  case TAG_ELam: {
    V v_b_2419 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    HeffT2 v_t_2420 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, v_env_241, v_st_242, v_b_2419));
    {
      V v_field_2421 = v_t_2420.f[0];
      V v_field_2422 = v_t_2420.f[1];
      V v_r_2423 = v_field_2421;
      heff_drop(v_r_2423);
      V v_st_2424 = v_field_2422;
      return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_2424}});
    }
  }
  case TAG_EApp: {
    V v_f_2425 = heff_field(v_e_243, 0);
    V v_args_2426 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2egatherGo_clo), 1, (V[]){v_c_240}));
    HeffT2 v_t_2428 = (g_heff_2ecompile_2eranges_2egatherMany_24cpr(v_t_2427, v_env_241, v_st_242, heff_tag_at_n(v_ru_24e_243_24EApp, TAG_Cons, 2, (V[]){v_f_2425, v_args_2426})));
    {
      V v_field_2429 = v_t_2428.f[0];
      V v_field_2430 = v_t_2428.f[1];
      V v_rs_2431 = v_field_2429;
      heff_drop(v_rs_2431);
      V v_st_2432 = v_field_2430;
      return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_2432}});
    }
  }
  case TAG_ELet: {
    V v_x_2433 = heff_field(v_e_243, 0);
    V v_a_2434 = heff_field(v_e_243, 1);
    V v_b_2435 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    HeffT2 v_t_2436 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(heff_dup(v_c_240), heff_dup(v_env_241), v_st_242, heff_dup(v_a_2434)));
    {
      V v_field_2437 = v_t_2436.f[0];
      V v_field_2438 = v_t_2436.f[1];
      V v_r_2439 = v_field_2437;
      V v_st_2440 = v_field_2438;
      V v_t_2441 = (g_heff_2ecompile_2eranges_2ewithRange(v_env_241, heff_dup(v_x_2433), v_r_2439));
      V v_t_2442 = ({ V a_0 = v_t_2441; V a_1 = v_x_2433; V a_2 = v_a_2434; V r_ = (g_heff_2ecompile_2eranges_2ewithTest(a_0, a_1, a_2)); heff_drop(v_a_2434); r_; });
      V t_0 = v_c_240;
      V t_1 = v_t_2442;
      V t_2 = v_st_2440;
      V t_3 = v_b_2435;
      v_c_240 = t_0;
      v_env_241 = t_1;
      v_st_242 = t_2;
      v_e_243 = t_3;
      goto top;
    }
  }
  case TAG_ERecord: {
    V v_fs_2443 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 2);
    V v_t_2445 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2egatherGo_clo), 1, (V[]){v_c_240}));
    V v_t_2446 = (g_list_2emap_24s1173914895x100384474(v_fs_2443));
    HeffT2 v_t_2447 = (g_heff_2ecompile_2eranges_2egatherMany_24cpr(v_t_2445, v_env_241, v_st_242, v_t_2446));
    {
      V v_field_2448 = v_t_2447.f[0];
      V v_field_2449 = v_t_2447.f[1];
      V v_rs_2450 = v_field_2448;
      heff_drop(v_rs_2450);
      V v_st_2451 = v_field_2449;
      return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_2451}});
    }
  }
  case TAG_EProj: {
    V v_a_2452 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 4);
    HeffT2 v_t_2456 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, v_env_241, v_st_242, v_a_2452));
    {
      V v_field_2457 = v_t_2456.f[0];
      V v_field_2458 = v_t_2456.f[1];
      V v_r_2459 = v_field_2457;
      heff_drop(v_r_2459);
      V v_st_2460 = v_field_2458;
      return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_2460}});
    }
  }
  case TAG_ETag: {
    V v_args_2462 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 3);
    V v_t_2464 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2egatherGo_clo), 1, (V[]){v_c_240}));
    HeffT2 v_t_2465 = (g_heff_2ecompile_2eranges_2egatherMany_24cpr(v_t_2464, v_env_241, v_st_242, v_args_2462));
    {
      V v_field_2466 = v_t_2465.f[0];
      V v_field_2467 = v_t_2465.f[1];
      V v_rs_2468 = v_field_2466;
      heff_drop(v_rs_2468);
      V v_st_2469 = v_field_2467;
      return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_2469}});
    }
  }
  case TAG_EMatch: {
    V v_s_2470 = heff_field(v_e_243, 0);
    V v_arms_2471 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    HeffT2 v_t_2472 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(heff_dup(v_c_240), heff_dup(v_env_241), v_st_242, heff_dup(v_s_2470)));
    {
      V v_field_2473 = v_t_2472.f[0];
      V v_field_2474 = v_t_2472.f[1];
      V v_r_2475 = v_field_2473;
      heff_drop(v_r_2475);
      V v_st_2476 = v_field_2474;
      V v_t_2477 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2egatherGo_clo), 1, (V[]){heff_dup(v_c_240)}));
      V v_t_2478 = (g_heff_2ecompile_2eranges_2etestOf(heff_dup(v_env_241), heff_dup(v_s_2470)));
      HeffT2 v_t_2479 = (g_heff_2ecompile_2eranges_2etestOf_24cpr(heff_dup(v_env_241), v_s_2470));
      V v_t_2492;
      {
        V v_field_2481 = v_t_2479.f[1];
        int64_t v_tag_2480 = ((int64_t)v_t_2479.f[0]);
        if ((v_tag_2480 == ((int64_t)0ULL))) {
          V v_x31_2483 = v_field_2481;
          switch (heff_tag_of(v_x31_2483)) {
          case TAG_MkTest: {
            V v_a_2485 = heff_field(v_x31_2483, 1);
            V v_b_2486 = heff_field(v_x31_2483, 2);
            heff_take_n(v_x31_2483, 6ULL, 3);
            V v_t_2487 = heff_dup(heff_rfield(v_c_240, 2));
            if ((heff_dup(v_t_2487) == NTAG(TAG_True))) {
              heff_drop(v_t_2487);
              V v_t_2488 = (g_heff_2ecompile_2eranges_2eoperandRange(heff_dup(v_c_240), heff_dup(v_env_241), v_a_2485));
              V v_t_2489 = ({ V a_0 = heff_take_field(v_st_2476, 1); V a_1 = v_t_2488; V r_ = (g_heff_2ecompile_2eranges_2emarkRange(a_0, a_1)); heff_drop(v_t_2488); r_; });
              V v_t_2490 = (g_heff_2ecompile_2eranges_2eoperandRange(heff_dup(v_c_240), heff_dup(v_env_241), v_b_2486));
              V v_t_2491 = ({ V a_0 = v_t_2489; V a_1 = v_t_2490; V r_ = (g_heff_2ecompile_2eranges_2emarkRange(a_0, a_1)); heff_drop(v_t_2490); r_; });
              v_t_2492 = ({ V rv_1 = v_t_2491; V rr_ = heff_rec_reuse_nf(v_st_2476, 1ULL, 2, shape_calls__marks, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            } else {
              heff_drop(v_a_2485);
              heff_drop(v_b_2486);
              heff_drop(v_t_2487);
              v_t_2492 = v_st_2476;
            }
            break;
          }
          default: heff_nomatch(v_x31_2483);
          }
        } else {
          heff_drop(v_field_2481);
          v_t_2492 = v_st_2476;
        }
      }
      return ({ V a_0 = v_c_240; V a_1 = v_t_2477; V a_2 = v_env_241; V a_3 = v_t_2478; V a_4 = v_t_2492; V a_5 = v_arms_2471; HeffT2 r_ = (g_heff_2ecompile_2eranges_2egatherArms_24cpr(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2478); r_; });
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_242}});
  }
  case TAG_EPrimCall: {
    V v_p_2494 = heff_field(v_e_243, 0);
    V v_args_2495 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    V v_t_2496 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2egatherGo_clo), 1, (V[]){v_c_240}));
    HeffT2 v_t_2497 = (g_heff_2ecompile_2eranges_2egatherMany_24cpr(v_t_2496, v_env_241, v_st_242, v_args_2495));
    {
      V v_field_2498 = v_t_2497.f[0];
      V v_field_2499 = v_t_2497.f[1];
      V v_rs_24100 = v_field_2498;
      V v_st_24101 = v_field_2499;
      V v_f_24102 = ({ V a_0 = v_p_2494; V a_1 = v_rs_24100; V r_ = (g_heff_2ecompile_2eranges_2eprimRange(a_0, a_1)); heff_drop(v_p_2494); heff_drop(v_rs_24100); r_; });
      return ((HeffT2){{v_f_24102, v_st_24101}});
    }
  }
  case TAG_ECall: {
    V v_g_24103 = heff_field(v_e_243, 0);
    V v_args_24104 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    V v_t_24105 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2egatherGo_clo), 1, (V[]){heff_dup(v_c_240)}));
    HeffT2 v_t_24106 = (g_heff_2ecompile_2eranges_2egatherMany_24cpr(v_t_24105, v_env_241, v_st_242, v_args_24104));
    {
      V v_field_24107 = v_t_24106.f[0];
      V v_field_24108 = v_t_24106.f[1];
      V v_rs_24109 = v_field_24107;
      V v_st_24110 = v_field_24108;
      V v_f_24111 = (g_heff_2ecompile_2eranges_2ecalledIn(v_c_240, v_g_24103, v_rs_24109, v_st_24110));
      return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_f_24111}});
    }
  }
  case TAG_EInt: {
    V v_n_24112 = heff_field(v_e_243, 0);
    V v_ru_24e_243_24EInt = heff_take_reuse_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    V v_t_24113 = heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24e_243_24EInt, TAG_Just, 1, (V[]){heff_dup(v_n_24112)}), heff_tag_n(TAG_Just, 1, (V[]){v_n_24112})});
    return ((HeffT2){{v_t_24113, v_st_242}});
  }
  case TAG_EFloat: {
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_242}});
  }
  case TAG_EStr: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_242}});
  }
  case TAG_EBytes: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_242}});
  }
  case TAG_EFixed: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_242}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_242}});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_242}});
  }
  case TAG_EFix: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_242}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_243)}});
  }
}
Clo g_heff_2ecompile_2eranges_2egatherDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2egatherDef_entry, 2, 0};

V g_heff_2ecompile_2eranges_2egatherDef(V v_c_240, V v_d_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_d_241, 2));
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    HeffT2 v_t_244 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_x11_247 = v_field_245;
      heff_drop(v_x11_247);
      V v_st_248 = v_field_246;
      return v_st_248;
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    HeffT2 v_t_2410 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2411 = v_t_2410.f[0];
      V v_field_2412 = v_t_2410.f[1];
      V v_x11_2413 = v_field_2411;
      heff_drop(v_x11_2413);
      V v_st_2414 = v_field_2412;
      return v_st_2414;
    }
  }
  case TAG_ELam: {
    V v_xs_2415 = heff_field(v_t_242, 0);
    V v_b_2416 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 3ULL, 2);
    HeffT2 v_t_2417 = ({ V a_0 = heff_rfield(v_c_240, 0); V b_1 = heff_get_n(v_d_241, 0, 3); HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2423;
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      if ((v_tag_2418 == ((int64_t)0ULL))) {
        V v_rs_2421 = v_field_2419;
        V v_t_2422 = (g_list_2ezipWith_24s1876717925x1404326288(v_xs_2415, v_rs_2421));
        v_t_2423 = ({ V a_0 = heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s518632429x1911716206(a_0, a_1)); heff_drop(v_t_2422); r_; });
      } else {
        heff_drop(v_xs_2415);
        heff_drop(v_field_2419);
        v_t_2423 = heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get());
      }
    }
    HeffT2 v_t_2424 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, v_t_2423, heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), v_b_2416));
    {
      V v_field_2425 = v_t_2424.f[0];
      V v_field_2426 = v_t_2424.f[1];
      V v_x11_2427 = v_field_2425;
      heff_drop(v_x11_2427);
      V v_st_2428 = v_field_2426;
      return v_st_2428;
    }
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    HeffT2 v_t_2431 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2432 = v_t_2431.f[0];
      V v_field_2433 = v_t_2431.f[1];
      V v_x11_2434 = v_field_2432;
      heff_drop(v_x11_2434);
      V v_st_2435 = v_field_2433;
      return v_st_2435;
    }
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    HeffT2 v_t_2439 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2440 = v_t_2439.f[0];
      V v_field_2441 = v_t_2439.f[1];
      V v_x11_2442 = v_field_2440;
      heff_drop(v_x11_2442);
      V v_st_2443 = v_field_2441;
      return v_st_2443;
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 2);
    HeffT2 v_t_2446 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2447 = v_t_2446.f[0];
      V v_field_2448 = v_t_2446.f[1];
      V v_x11_2449 = v_field_2447;
      heff_drop(v_x11_2449);
      V v_st_2450 = v_field_2448;
      return v_st_2450;
    }
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 4);
    HeffT2 v_t_2455 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2456 = v_t_2455.f[0];
      V v_field_2457 = v_t_2455.f[1];
      V v_x11_2458 = v_field_2456;
      heff_drop(v_x11_2458);
      V v_st_2459 = v_field_2457;
      return v_st_2459;
    }
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 3);
    HeffT2 v_t_2463 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2464 = v_t_2463.f[0];
      V v_field_2465 = v_t_2463.f[1];
      V v_x11_2466 = v_field_2464;
      heff_drop(v_x11_2466);
      V v_st_2467 = v_field_2465;
      return v_st_2467;
    }
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    HeffT2 v_t_2470 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2471 = v_t_2470.f[0];
      V v_field_2472 = v_t_2470.f[1];
      V v_x11_2473 = v_field_2471;
      heff_drop(v_x11_2473);
      V v_st_2474 = v_field_2472;
      return v_st_2474;
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    HeffT2 v_t_2476 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2477 = v_t_2476.f[0];
      V v_field_2478 = v_t_2476.f[1];
      V v_x11_2479 = v_field_2477;
      heff_drop(v_x11_2479);
      V v_st_2480 = v_field_2478;
      return v_st_2480;
    }
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    HeffT2 v_t_2483 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2484 = v_t_2483.f[0];
      V v_field_2485 = v_t_2483.f[1];
      V v_x11_2486 = v_field_2484;
      heff_drop(v_x11_2486);
      V v_st_2487 = v_field_2485;
      return v_st_2487;
    }
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    HeffT2 v_t_2490 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2491 = v_t_2490.f[0];
      V v_field_2492 = v_t_2490.f[1];
      V v_x11_2493 = v_field_2491;
      heff_drop(v_x11_2493);
      V v_st_2494 = v_field_2492;
      return v_st_2494;
    }
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    HeffT2 v_t_2496 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2497 = v_t_2496.f[0];
      V v_field_2498 = v_t_2496.f[1];
      V v_x11_2499 = v_field_2497;
      heff_drop(v_x11_2499);
      V v_st_24100 = v_field_2498;
      return v_st_24100;
    }
  }
  case TAG_EFloat: {
    heff_take_na(v_t_242, 0ULL, 1);
    HeffT2 v_t_24102 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_24103 = v_t_24102.f[0];
      V v_field_24104 = v_t_24102.f[1];
      V v_x11_24105 = v_field_24103;
      heff_drop(v_x11_24105);
      V v_st_24106 = v_field_24104;
      return v_st_24106;
    }
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    HeffT2 v_t_24108 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_24109 = v_t_24108.f[0];
      V v_field_24110 = v_t_24108.f[1];
      V v_x11_24111 = v_field_24109;
      heff_drop(v_x11_24111);
      V v_st_24112 = v_field_24110;
      return v_st_24112;
    }
  }
  case TAG_EBytes: {
    heff_take_n(v_t_242, 0ULL, 1);
    HeffT2 v_t_24114 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_24115 = v_t_24114.f[0];
      V v_field_24116 = v_t_24114.f[1];
      V v_x11_24117 = v_field_24115;
      heff_drop(v_x11_24117);
      V v_st_24118 = v_field_24116;
      return v_st_24118;
    }
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    HeffT2 v_t_24121 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_24122 = v_t_24121.f[0];
      V v_field_24123 = v_t_24121.f[1];
      V v_x11_24124 = v_field_24122;
      heff_drop(v_x11_24124);
      V v_st_24125 = v_field_24123;
      return v_st_24125;
    }
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_242, 0ULL, 1);
    HeffT2 v_t_24127 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_24128 = v_t_24127.f[0];
      V v_field_24129 = v_t_24127.f[1];
      V v_x11_24130 = v_field_24128;
      heff_drop(v_x11_24130);
      V v_st_24131 = v_field_24129;
      return v_st_24131;
    }
  }
  case TAG_EAbandon: {
    HeffT2 v_t_24132 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_24133 = v_t_24132.f[0];
      V v_field_24134 = v_t_24132.f[1];
      V v_x11_24135 = v_field_24133;
      heff_drop(v_x11_24135);
      V v_st_24136 = v_field_24134;
      return v_st_24136;
    }
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    HeffT2 v_t_24139 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_dup(g_heff_2ecompile_2eranges_2eemptySt_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_24140 = v_t_24139.f[0];
      V v_field_24141 = v_t_24139.f[1];
      V v_x11_24142 = v_field_24140;
      heff_drop(v_x11_24142);
      V v_st_24143 = v_field_24141;
      return v_st_24143;
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eranges_2egatherDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2egatherDef(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2eranges_2ewalkMany_24cpr(V v_go_240, V v_env_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    heff_drop(v_env_241);
    return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x3_242, 0);
    V v_es_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x1_245 = heff_tr(heff_call(heff_dup(v_go_240), 2, (V[]){heff_dup(v_env_241), v_e_243}));
    HeffT2 v_t_246 = (g_heff_2ecompile_2eranges_2ewalkMany_24cpr(v_go_240, v_env_241, v_es_244));
    {
      V v_field_247 = v_t_246.f[0];
      V v_field_248 = v_t_246.f[1];
      switch (heff_tag_of(v_x1_245)) {
      case TAG_MkRes: {
        V v_r_249 = heff_field(v_x1_245, 0);
        V v_e_2410 = heff_field(v_x1_245, 1);
        V v_ru_24x1_245_24MkRes = heff_take_reuse_n(v_x1_245, 3ULL, 2);
        V v_rs_2411 = v_field_247;
        V v_es_2412 = v_field_248;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_r_249, v_rs_2411}), heff_tag_at_n(v_ru_24x1_245_24MkRes, TAG_Cons, 2, (V[]){v_e_2410, v_es_2412})}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_245)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
Clo g_heff_2ecompile_2eranges_2ewidenLow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ewidenLow_entry, 3, 0};

V g_heff_2ecompile_2eranges_2ewidenLow(V v_x1_240, V v_a_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_a_241)) {
    case TAG_Nothing: {
      return v_x3_242;
    }
    case TAG_Just: {
      V v_a_243 = heff_field(v_a_241, 0);
      heff_take_n(v_a_241, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nothing: {
        heff_drop(v_a_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_c_244 = heff_dup(heff_field(v_x3_242, 0));
        if (heff_intLt_c(v_c_244, v_a_243)) {
          heff_drop_tag(v_x3_242, 1);
          return NTAG(TAG_Nothing);
        } else {
          return v_x3_242;
        }
      }
      default: return heff_nomatch(v_x3_242);
      }
    }
    default: return heff_nomatch(v_a_241);
    }
  }
  case TAG_Just: {
    V v_ms_246 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nothing: {
      heff_drop(v_ms_246);
      heff_drop_cell(v_ru_24x1_240_24Just, 1);
      switch (heff_tag_of(v_a_241)) {
      case TAG_Nothing: {
        return v_x3_242;
      }
      case TAG_Just: {
        V v_a_247 = heff_field(v_a_241, 0);
        heff_take_n(v_a_241, 1ULL, 1);
        switch (heff_tag_of(v_x3_242)) {
        case TAG_Nothing: {
          heff_drop(v_a_247);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_c_248 = heff_dup(heff_field(v_x3_242, 0));
          if (heff_intLt_c(v_c_248, v_a_247)) {
            heff_drop_tag(v_x3_242, 1);
            return NTAG(TAG_Nothing);
          } else {
            return v_x3_242;
          }
        }
        default: return heff_nomatch(v_x3_242);
        }
      }
      default: return heff_nomatch(v_a_241);
      }
    }
    case TAG_Just: {
      V v_c_2410 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      switch (heff_tag_of(v_a_241)) {
      case TAG_Nothing: {
        heff_drop(v_ms_246);
        return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_c_2410});
      }
      case TAG_Just: {
        V v_a_2411 = heff_field(v_a_241, 0);
        heff_take_n(v_a_241, 1ULL, 1);
        if (heff_intLt_c_lent(v_c_2410, v_a_2411, 2)) {
          heff_drop_cell(v_ru_24x1_240_24Just, 1);
          V v_t_2413 = ({ V a_0 = v_ms_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_ms_246); r_; });
          return ({ V a_0 = v_c_2410; V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2413; V r_ = (g_list_2efoldl_24s312236574x1326690653(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
        } else {
          heff_drop(v_ms_246);
          return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_c_2410});
        }
      }
      default: return heff_nomatch(v_a_241);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eranges_2ewidenLow_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ewidenLow(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eranges_2erangesEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erangesEq_entry, 2, 0};

V g_heff_2ecompile_2eranges_2erangesEq(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_args_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      V v_t_248 = (g_heff_2ecompile_2eranges_2erangeEq(v_a_244, v_b_246));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V t_0 = v_args_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_248);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eranges_2erangesEq_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eranges_2erangesEq(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2eranges_2eplaceOf_24cpr(V v_x_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x3_242, 0);
    V v_ys_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_240, v_y_243, 2)) {
      heff_drop(v_ys_244);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_241}});
    } else {
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_ys_244;
      v_x_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2ecompile_2eranges_2erangedWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2erangedWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erangedWith_entry, 4, 0};

V g_heff_2ecompile_2eranges_2erangedWith(V v_consts_240, V v_sc_241, V v_defs_242, V v_params_243) {
top: ;
  V v_t_2412 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eranges_2erangedWith_lam0, 1, 3, (V[]){v_sc_241, heff_dup(v_params_243), v_consts_240}), v_defs_242));
  V v_t_2413 = ({ V a_0 = v_params_243; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_params_243); r_; });
  V v_t_2414 = ({ V a_0 = MK_INT(-4611686018427387904LL); V a_1 = MK_INT(4611686018427387903LL); V a_2 = MK_INT(0LL); V a_3 = MK_INT(1LL); V a_4 = MK_INT(0LL); V a_5 = MK_INT(1LL); V a_6 = MK_INT(-4611686018427387904LL); V a_7 = MK_INT(4611686018427387903LL); V a_8 = MK_INT(0LL); V a_9 = MK_INT(1LL); V a_10 = MK_INT(0LL); V a_11 = MK_INT(1LL); V a_12 = heff_dup(g_std_2emap_2eempty_get()); V a_13 = v_t_2413; V r_ = (g_list_2efoldl_24s629835174x643023540(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11, a_12, a_13)); heff_drop(v_t_2413); r_; });
  return heff_rec_n(2, shape_defs__words, (V[]){v_t_2412, v_t_2414});
}
V g_heff_2ecompile_2eranges_2erangedWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2erangedWith(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eranges_2erangedWith_lam0(V self, V *args) {
  V v_d_244 = args[0];
  V v_sc_241 = heff_env(self)[0];
  V v_params_243 = heff_env(self)[1];
  V v_consts_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_245 = ({ V b_0 = heff_get_n(v_sc_241, 3, 4); V a_1 = heff_rfield(v_d_244, 0); HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_247;
      heff_drop(v_x_249);
      V v_t_2410 = heff_rec_n(3, shape_params__consts__marking, (V[]){v_params_243, v_consts_240, NTAG(TAG_False)});
      V v_body_2411 = (g_heff_2ecompile_2eranges_2ewalkDef(v_t_2410, heff_dup(v_d_244)));
      return ({ V rv_2 = v_body_2411; V rr_ = heff_rec_reuse_nf(v_d_244, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    } else {
      heff_drop(v_params_243);
      heff_drop(v_consts_240);
      heff_drop(v_field_247);
      return v_d_244;
    }
  }
}
Clo g_heff_2ecompile_2eranges_2esettled_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2esettled_entry, 4, 0};

V g_heff_2ecompile_2eranges_2esettled(V v_consts_240, V v_sc_241, V v_defs_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_consts_240);
    heff_drop(v_sc_241);
    return heff_rec_n(2, shape_defs__words, (V[]){v_defs_242, heff_dup(g_std_2emap_2eempty_get())});
  }
  case TAG_Just: {
    V v_s_244 = heff_field(v_x4_243, 0);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_244, 0)), 0, 3);
    V v_t_246 = heff_rec_n(3, shape_params__gathered__changed, (V[]){v_t_245, heff_dup(heff_rfield(v_s_244, 2)), NTAG(TAG_Nil)});
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_244, 0)), 0, 3);
    V v_t_248 = ({ V a_0 = v_t_247; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_t_249 = (g_list_2emap_24s1937570095x2110149801(v_t_248));
    V v_t_2410 = ({ V a_0 = heff_dup(v_sc_241); V a_1 = v_t_246; V a_2 = heff_dup(heff_rfield(v_s_244, 2)); V a_3 = v_t_249; V r_ = (g_heff_2ecompile_2eranges_2enarrowWith(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
    V v_t_2411 = (g_heff_2ecompile_2eranges_2enarrowing(heff_dup(v_consts_240), heff_dup(v_sc_241), MK_INT(3LL), v_t_2410));
    HEFF_LAST return g_heff_2ecompile_2eranges_2erangedWith(v_consts_240, v_sc_241, v_defs_242, v_t_2411);
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eranges_2esettled_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eranges_2esettled(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}