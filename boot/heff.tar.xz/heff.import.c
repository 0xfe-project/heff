// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_alias 294261354
#define LBL_end 310101
#define LBL_imports 10411951
#define LBL_name 9869138
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
static uint32_t shape_imports__text[] = {LBL_imports, LBL_text};
static uint32_t shape_name__alias__span[] = {LBL_name, LBL_alias, LBL_span};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2eimport_2eallChars_24s593368137x641185878(V, V);
V g_heff_2eimport_2eallChars_24s593368137x641185878_entry(V self, V *a);
extern Clo g_heff_2eimport_2eallChars_24s593368137x641185878_clo;
V g_heff_2eimport_2ebuiltinModule_get(void);
V g_heff_2eimport_2ehasDot(V, V);
V g_heff_2eimport_2ehasDot_entry(V self, V *a);
extern Clo g_heff_2eimport_2ehasDot_clo;
V g_heff_2eimport_2eimportOf(V, V, V);
V g_heff_2eimport_2eimportOf_entry(V self, V *a);
extern Clo g_heff_2eimport_2eimportOf_clo;
V g_heff_2eimport_2eimportsGo(V, V, V);
V g_heff_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2eimport_2eimportsGo_clo;
V g_heff_2eimport_2eimportsOf(V, V);
V g_heff_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2eimport_2eimportsOf_clo;
V g_heff_2eimport_2eisAlias(V);
V g_heff_2eimport_2eisAlias_entry(V self, V *a);
extern Clo g_heff_2eimport_2eisAlias_clo;
V g_heff_2eimport_2elineEndAt(V, V);
V g_heff_2eimport_2elineEndAt_entry(V self, V *a);
extern Clo g_heff_2eimport_2elineEndAt_clo;
V g_heff_2eimport_2enameChar(V);
V g_heff_2eimport_2enameChar_entry(V self, V *a);
extern Clo g_heff_2eimport_2enameChar_clo;
V g_heff_2eimport_2erenameTo(V, V);
V g_heff_2eimport_2erenameTo_entry(V self, V *a);
extern Clo g_heff_2eimport_2erenameTo_clo;
V g_heff_2eimport_2espaces(V);
V g_heff_2eimport_2espaces_entry(V self, V *a);
extern Clo g_heff_2eimport_2espaces_clo;
V g_heff_2eimport_2etrimEnd(V);
V g_heff_2eimport_2etrimEnd_entry(V self, V *a);
extern Clo g_heff_2eimport_2etrimEnd_clo;
V g_heff_2eimport_2etrimStart(V);
V g_heff_2eimport_2etrimStart_entry(V self, V *a);
extern Clo g_heff_2eimport_2etrimStart_clo;
V g_heff_2eimport_2ewordsGo(V, V, V, V);
V g_heff_2eimport_2ewordsGo_entry(V self, V *a);
extern Clo g_heff_2eimport_2ewordsGo_clo;
V g_prelude_2eany_24s2095707853x1489837173(V);
V g_prelude_2eany_24s2095707853x1489837173_entry(V self, V *a);
extern Clo g_prelude_2eany_24s2095707853x1489837173_clo;
V g_prelude_2efoldl_24s1546929672x1472202881(V, V);
V g_prelude_2efoldl_24s1546929672x1472202881_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1546929672x1472202881_clo;
V g_prelude_2efoldl_24s2083806868x1400260102(V, V);
V g_prelude_2efoldl_24s2083806868x1400260102_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s2083806868x1400260102_clo;
Clo g_heff_2eimport_2enameChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eimport_2enameChar_entry, 1, 0};

V g_heff_2eimport_2enameChar(V v_c_240) {
top: ;
  V v_t_241 = heff_intEq(heff_dup(v_c_240), MK_INT(46LL));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_c_240);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    V v_t_242 = heff_intEq(heff_dup(v_c_240), MK_INT(95LL));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      heff_drop(v_c_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_243 = heff_intEq(heff_dup(v_c_240), MK_INT(45LL));
      switch (heff_tag_of(v_t_243)) {
      case TAG_True: {
        heff_drop(v_c_240);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V v_t_244 = heff_intLe(MK_INT(97LL), heff_dup(v_c_240));
        switch (heff_tag_of(v_t_244)) {
        case TAG_True: {
          V v_t_245 = heff_intLe(heff_dup(v_c_240), MK_INT(122LL));
          switch (heff_tag_of(v_t_245)) {
          case TAG_True: {
            heff_drop(v_c_240);
            return NTAG(TAG_True);
          }
          case TAG_False: {
            V v_t_246 = heff_intLe(MK_INT(65LL), heff_dup(v_c_240));
            switch (heff_tag_of(v_t_246)) {
            case TAG_True: {
              V v_t_247 = heff_intLe(heff_dup(v_c_240), MK_INT(90LL));
              switch (heff_tag_of(v_t_247)) {
              case TAG_True: {
                heff_drop(v_c_240);
                return NTAG(TAG_True);
              }
              case TAG_False: {
                V v_t_248 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
                switch (heff_tag_of(v_t_248)) {
                case TAG_True: {
                  return heff_intLe(v_c_240, MK_INT(57LL));
                }
                case TAG_False: {
                  heff_drop(v_c_240);
                  return NTAG(TAG_False);
                }
                default: return heff_nomatch(v_t_248);
                }
              }
              default: return heff_nomatch(v_t_247);
              }
            }
            case TAG_False: {
              V v_t_249 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
              switch (heff_tag_of(v_t_249)) {
              case TAG_True: {
                return heff_intLe(v_c_240, MK_INT(57LL));
              }
              case TAG_False: {
                heff_drop(v_c_240);
                return NTAG(TAG_False);
              }
              default: return heff_nomatch(v_t_249);
              }
            }
            default: return heff_nomatch(v_t_246);
            }
          }
          default: return heff_nomatch(v_t_245);
          }
        }
        case TAG_False: {
          V v_t_2410 = heff_intLe(MK_INT(65LL), heff_dup(v_c_240));
          switch (heff_tag_of(v_t_2410)) {
          case TAG_True: {
            V v_t_2411 = heff_intLe(heff_dup(v_c_240), MK_INT(90LL));
            switch (heff_tag_of(v_t_2411)) {
            case TAG_True: {
              heff_drop(v_c_240);
              return NTAG(TAG_True);
            }
            case TAG_False: {
              V v_t_2412 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
              switch (heff_tag_of(v_t_2412)) {
              case TAG_True: {
                return heff_intLe(v_c_240, MK_INT(57LL));
              }
              case TAG_False: {
                heff_drop(v_c_240);
                return NTAG(TAG_False);
              }
              default: return heff_nomatch(v_t_2412);
              }
            }
            default: return heff_nomatch(v_t_2411);
            }
          }
          case TAG_False: {
            V v_t_2413 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
            switch (heff_tag_of(v_t_2413)) {
            case TAG_True: {
              return heff_intLe(v_c_240, MK_INT(57LL));
            }
            case TAG_False: {
              heff_drop(v_c_240);
              return NTAG(TAG_False);
            }
            default: return heff_nomatch(v_t_2413);
            }
          }
          default: return heff_nomatch(v_t_2410);
          }
        }
        default: return heff_nomatch(v_t_244);
        }
      }
      default: return heff_nomatch(v_t_243);
      }
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eimport_2enameChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2eimport_2enameChar(a[0]);
}
Clo g_heff_2eimport_2eallChars_24s593368137x641185878_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eimport_2eallChars_24s593368137x641185878_entry, 2, 0};

V g_heff_2eimport_2eallChars_24s593368137x641185878(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    V v_t_243 = (g_heff_2eimport_2enameChar(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241))));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eimport_2eallChars_24s593368137x641185878_entry(V self, V *a) {
  (void)self;
  return g_heff_2eimport_2eallChars_24s593368137x641185878(a[0], a[1]);
}
Clo g_heff_2eimport_2ehasDot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eimport_2ehasDot_entry, 2, 0};

V g_heff_2eimport_2ehasDot(V v_x_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intLe(heff_strLength(heff_dup(v_x_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_x_240);
    heff_drop(v_i_241);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    V v_t_243 = heff_intEq(heff_strCharCode(heff_dup(v_x_240), heff_dup(v_i_241)), MK_INT(46LL));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_x_240);
      heff_drop(v_i_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eimport_2ehasDot_entry(V self, V *a) {
  (void)self;
  return g_heff_2eimport_2ehasDot(a[0], a[1]);
}
Clo g_heff_2eimport_2eisAlias_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eimport_2eisAlias_entry, 1, 0};

V g_heff_2eimport_2eisAlias(V v_x_240) {
top: ;
  V v_t_241 = heff_intLt(MK_INT(0LL), heff_strLength(heff_dup(v_x_240)));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    V v_t_242 = heff_intLe(MK_INT(65LL), heff_strCharCode(heff_dup(v_x_240), MK_INT(0LL)));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      V v_t_243 = heff_intLe(heff_strCharCode(heff_dup(v_x_240), MK_INT(0LL)), MK_INT(90LL));
      switch (heff_tag_of(v_t_243)) {
      case TAG_True: {
        V v_x1_244 = (g_heff_2eimport_2ehasDot(heff_dup(v_x_240), MK_INT(0LL)));
        switch (heff_tag_of(v_x1_244)) {
        case TAG_True: {
          heff_drop(v_x_240);
          return NTAG(TAG_False);
        }
        case TAG_False: {
          V v_t_245 = heff_intLt(MK_INT(0LL), heff_strLength(heff_dup(v_x_240)));
          switch (heff_tag_of(v_t_245)) {
          case TAG_True: {
            return (g_heff_2eimport_2eallChars_24s593368137x641185878(v_x_240, MK_INT(0LL)));
          }
          case TAG_False: {
            heff_drop(v_x_240);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_t_245);
          }
        }
        default: return heff_nomatch(v_x1_244);
        }
      }
      case TAG_False: {
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_243);
      }
    }
    case TAG_False: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_False: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eimport_2eisAlias_entry(V self, V *a) {
  (void)self;
  return g_heff_2eimport_2eisAlias(a[0]);
}
Clo g_heff_2eimport_2elineEndAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eimport_2elineEndAt_entry, 2, 0};

V g_heff_2eimport_2elineEndAt(V v_src_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intLe(heff_strLength(heff_dup(v_src_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_i_241);
    return heff_strLength(v_src_240);
  }
  case TAG_False: {
    V v_t_243 = heff_intEq(heff_strCharCode(heff_dup(v_src_240), heff_dup(v_i_241)), MK_INT(10LL));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_src_240);
      return v_i_241;
    }
    case TAG_False: {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eimport_2elineEndAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eimport_2elineEndAt(a[0], a[1]);
}
Clo g_heff_2eimport_2etrimEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eimport_2etrimEnd_entry, 1, 0};

V g_heff_2eimport_2etrimEnd(V v_s_240) {
top: ;
  V v_t_241 = heff_intLt(MK_INT(0LL), heff_strLength(heff_dup(v_s_240)));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    V v_t_242 = heff_intSub(heff_strLength(heff_dup(v_s_240)), MK_INT(1LL));
    V v_t_243 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), v_t_242), MK_INT(32LL));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V v_t_244 = heff_intSub(heff_strLength(heff_dup(v_s_240)), MK_INT(1LL));
      V t_0 = heff_strSlice(v_s_240, MK_INT(0LL), v_t_244);
      v_s_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return v_s_240;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_False: {
    return v_s_240;
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eimport_2etrimEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2eimport_2etrimEnd(a[0]);
}
Clo g_heff_2eimport_2etrimStart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eimport_2etrimStart_entry, 1, 0};

V g_heff_2eimport_2etrimStart(V v_s_240) {
top: ;
  V v_t_241 = heff_intLt(MK_INT(0LL), heff_strLength(heff_dup(v_s_240)));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    V v_t_242 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), MK_INT(0LL)), MK_INT(32LL));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      V v_t_243 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength(v_s_240));
      V t_0 = v_t_243;
      v_s_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return v_s_240;
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_False: {
    return v_s_240;
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eimport_2etrimStart_entry(V self, V *a) {
  (void)self;
  return g_heff_2eimport_2etrimStart(a[0]);
}
Clo g_heff_2eimport_2ewordsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eimport_2ewordsGo_entry, 4, 0};

V g_heff_2eimport_2ewordsGo(V v_s_240, V v_start_241, V v_i_242, V v_acc_243) {
top: ;
  V v_t_244 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_242));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    V v_t_245 = heff_intLt(heff_dup(v_start_241), heff_dup(v_i_242));
    V v_xs_246;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      v_xs_246 = heff_tag(TAG_Cons, 2, (V[]){heff_strSlice(v_s_240, v_start_241, v_i_242), v_acc_243});
      break;
    }
    case TAG_False: {
      heff_drop(v_s_240);
      heff_drop(v_start_241);
      heff_drop(v_i_242);
      v_xs_246 = v_acc_243;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    return (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_246));
  }
  case TAG_False: {
    V v_t_247 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_242)), MK_INT(32LL));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      V v_t_248 = heff_intLt(heff_dup(v_start_241), heff_dup(v_i_242));
      V v_t_249;
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        v_t_249 = heff_tag(TAG_Cons, 2, (V[]){heff_strSlice(heff_dup(v_s_240), v_start_241, heff_dup(v_i_242)), v_acc_243});
        break;
      }
      case TAG_False: {
        heff_drop(v_start_241);
        v_t_249 = v_acc_243;
        break;
      }
      default: heff_nomatch(v_t_248);
      }
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(heff_dup(v_i_242), MK_INT(1LL));
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_t_249;
      v_s_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
    case TAG_False: {
      V t_0 = v_s_240;
      V t_1 = v_start_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_acc_243;
      v_s_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eimport_2ewordsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eimport_2ewordsGo(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eimport_2espaces_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eimport_2espaces_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_heff_2eimport_2espaces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eimport_2espaces_entry, 1, 0};

V g_heff_2eimport_2espaces(V v_n_240) {
top: ;
  V v_t_241 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_n_240);
    return ((V)&g_heff_2eimport_2espaces_str0);
  }
  case TAG_False: {
    return heff_strAppend(((V)&g_heff_2eimport_2espaces_str1), (g_heff_2eimport_2espaces(heff_intSub(v_n_240, MK_INT(1LL)))));
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eimport_2espaces_entry(V self, V *a) {
  (void)self;
  return g_heff_2eimport_2espaces(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eimport_2eimportOf_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {97, 115}};
Clo g_heff_2eimport_2eimportOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eimport_2eimportOf_entry, 3, 0};

V g_heff_2eimport_2eimportOf(V v_i_240, V v_e_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_e_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x3_242, 0);
    V v_x32_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x32_244)) {
    case TAG_Nil: {
      V v_t_245 = heff_intLt(MK_INT(0LL), heff_strLength(heff_dup(v_m_243)));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        V v_t_246 = (g_heff_2eimport_2eallChars_24s593368137x641185878(heff_dup(v_m_243), MK_INT(0LL)));
        switch (heff_tag_of(v_t_246)) {
        case TAG_True: {
          V v_t_247 = heff_rec(3, shape_name__alias__span, (V[]){heff_dup(v_m_243), NTAG(TAG_Nothing), heff_rec(2, shape_start__end, (V[]){v_i_240, v_e_241})});
          return heff_tag(TAG_Just, 1, (V[]){v_t_247});
        }
        case TAG_False: {
          heff_drop(v_i_240);
          heff_drop(v_e_241);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_t_246);
        }
      }
      case TAG_False: {
        heff_drop(v_i_240);
        heff_drop(v_e_241);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    case TAG_Cons: {
      V v_x321_248 = heff_field(v_x32_244, 0);
      V v_x322_249 = heff_field(v_x32_244, 1);
      V v_t_2410 = heff_strEq(heff_dup(v_x321_248), ((V)&g_heff_2eimport_2eimportOf_str0));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        switch (heff_tag_of(v_x322_249)) {
        case TAG_Nil: {
          heff_drop(v_i_240);
          heff_drop(v_e_241);
          return NTAG(TAG_Nothing);
        }
        case TAG_Cons: {
          V v_a_2411 = heff_field(v_x322_249, 0);
          V v_x3222_2412 = heff_field(v_x322_249, 1);
          switch (heff_tag_of(v_x3222_2412)) {
          case TAG_Nil: {
            V v_t_2413 = heff_intLt(MK_INT(0LL), heff_strLength(heff_dup(v_m_243)));
            switch (heff_tag_of(v_t_2413)) {
            case TAG_True: {
              V v_t_2414 = (g_heff_2eimport_2eallChars_24s593368137x641185878(heff_dup(v_m_243), MK_INT(0LL)));
              switch (heff_tag_of(v_t_2414)) {
              case TAG_True: {
                V v_t_2415 = (g_heff_2eimport_2eisAlias(heff_dup(v_a_2411)));
                switch (heff_tag_of(v_t_2415)) {
                case TAG_True: {
                  V v_t_2416 = heff_rec(3, shape_name__alias__span, (V[]){heff_dup(v_m_243), heff_tag(TAG_Just, 1, (V[]){heff_dup(v_a_2411)}), heff_rec(2, shape_start__end, (V[]){v_i_240, v_e_241})});
                  return heff_tag(TAG_Just, 1, (V[]){v_t_2416});
                }
                case TAG_False: {
                  heff_drop(v_i_240);
                  heff_drop(v_e_241);
                  return NTAG(TAG_Nothing);
                }
                default: return heff_nomatch(v_t_2415);
                }
              }
              case TAG_False: {
                heff_drop(v_i_240);
                heff_drop(v_e_241);
                return NTAG(TAG_Nothing);
              }
              default: return heff_nomatch(v_t_2414);
              }
            }
            case TAG_False: {
              heff_drop(v_i_240);
              heff_drop(v_e_241);
              return NTAG(TAG_Nothing);
            }
            default: return heff_nomatch(v_t_2413);
            }
          }
          case TAG_Cons: {
            heff_drop(v_i_240);
            heff_drop(v_e_241);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_x3222_2412);
          }
        }
        default: return heff_nomatch(v_x322_249);
        }
      }
      case TAG_False: {
        heff_drop(v_i_240);
        heff_drop(v_e_241);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_x32_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eimport_2eimportOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eimport_2eimportOf(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eimport_2eimportsGo_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eimport_2eimportsGo_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eimport_2eimportsGo_str2 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 109, 112, 111, 114, 116, 32}};
Clo g_heff_2eimport_2eimportsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eimport_2eimportsGo_entry, 3, 0};

V g_heff_2eimport_2eimportsGo(V v_src_240, V v_i_241, V v_acc_242) {
top: ;
  V v_t_243 = heff_intLe(heff_strLength(heff_dup(v_src_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_i_241);
    V v_t_244 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_dup(v_acc_242)));
    V v_t_245 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_242));
    V v_t_246 = ({ V a_0 = v_src_240; V a_1 = v_t_245; V r_ = (g_prelude_2efoldl_24s2083806868x1400260102(a_0, a_1)); heff_drop(v_t_245); r_; });
    return heff_rec(2, shape_imports__text, (V[]){v_t_244, v_t_246});
  }
  case TAG_False: {
    V v_x_247 = (g_heff_2eimport_2elineEndAt(heff_dup(v_src_240), heff_dup(v_i_241)));
    V v_line_248 = heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), heff_dup(v_x_247));
    V v_t_249 = (g_heff_2eimport_2etrimStart(heff_dup(v_line_248)));
    V v_x_2410 = (g_heff_2eimport_2etrimEnd(v_t_249));
    V v_t_2411 = heff_strEq(heff_dup(v_x_2410), ((V)&g_heff_2eimport_2eimportsGo_str0));
    V v_t_2412;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      heff_drop(v_x_2410);
      v_t_2412 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      v_t_2412 = heff_strEq(heff_strSlice(v_x_2410, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2eimport_2eimportsGo_str1));
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_i_241);
      heff_drop(v_line_248);
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_x_247, MK_INT(1LL));
      V t_2 = v_acc_242;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
    case TAG_False: {
      V v_t_2413 = heff_strEq(heff_strSlice(heff_dup(v_line_248), MK_INT(0LL), MK_INT(7LL)), ((V)&g_heff_2eimport_2eimportsGo_str2));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_True: {
        V v_t_2414 = heff_strSlice(heff_dup(v_line_248), MK_INT(7LL), heff_strLength(v_line_248));
        V v_t_2415 = (g_heff_2eimport_2etrimStart(v_t_2414));
        V v_s_2416 = (g_heff_2eimport_2etrimEnd(v_t_2415));
        V v_t_2417 = (g_heff_2eimport_2ewordsGo(v_s_2416, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
        V v_t_2418 = ({ V a_0 = v_i_241; V a_1 = heff_dup(v_x_247); V a_2 = v_t_2417; V r_ = (g_heff_2eimport_2eimportOf(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nothing: {
          heff_drop(v_x_247);
          V v_t_2419 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_dup(v_acc_242)));
          V v_t_2420 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_242));
          V v_t_2421 = ({ V a_0 = v_src_240; V a_1 = v_t_2420; V r_ = (g_prelude_2efoldl_24s2083806868x1400260102(a_0, a_1)); heff_drop(v_t_2420); r_; });
          return heff_rec(2, shape_imports__text, (V[]){v_t_2419, v_t_2421});
        }
        case TAG_Just: {
          V v_imp_2422 = heff_field(v_t_2418, 0);
          heff_take_n(v_t_2418, 1ULL, 1);
          V t_0 = v_src_240;
          V t_1 = heff_intAdd(v_x_247, MK_INT(1LL));
          V t_2 = heff_tag(TAG_Cons, 2, (V[]){v_imp_2422, v_acc_242});
          v_src_240 = t_0;
          v_i_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_t_2418);
        }
      }
      case TAG_False: {
        heff_drop(v_i_241);
        heff_drop(v_x_247);
        heff_drop(v_line_248);
        V v_t_2423 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_dup(v_acc_242)));
        V v_t_2424 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_242));
        V v_t_2425 = ({ V a_0 = v_src_240; V a_1 = v_t_2424; V r_ = (g_prelude_2efoldl_24s2083806868x1400260102(a_0, a_1)); heff_drop(v_t_2424); r_; });
        return heff_rec(2, shape_imports__text, (V[]){v_t_2423, v_t_2425});
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eimport_2eimportsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eimport_2eimportsGo(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eimport_2ebuiltinModule_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {98, 117, 105, 108, 116, 105, 110}};

static V g_heff_2eimport_2ebuiltinModule_val;
static int g_heff_2eimport_2ebuiltinModule_st;
static V g_heff_2eimport_2ebuiltinModule_init(void) {
  return ((V)&g_heff_2eimport_2ebuiltinModule_str0);
}
V g_heff_2eimport_2ebuiltinModule_get(void) {
  if (g_heff_2eimport_2ebuiltinModule_st == 2) return g_heff_2eimport_2ebuiltinModule_val;
  if (g_heff_2eimport_2ebuiltinModule_st == 1) heff_fail("defined by itself");
  g_heff_2eimport_2ebuiltinModule_st = 1;
  g_heff_2eimport_2ebuiltinModule_val = heff_tr(g_heff_2eimport_2ebuiltinModule_init());
  g_heff_2eimport_2ebuiltinModule_st = 2;
  return g_heff_2eimport_2ebuiltinModule_val;
}
Clo g_heff_2eimport_2eimportsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eimport_2eimportsOf_entry, 2, 0};

V g_heff_2eimport_2eimportsOf(V v_m_240, V v_src_241) {
top: ;
  V v_r_242 = (g_heff_2eimport_2eimportsGo(v_src_241, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_243 = heff_strEq(v_m_240, heff_dup(g_heff_2eimport_2ebuiltinModule_get()));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    return v_r_242;
  }
  case TAG_False: {
    V v_t_244 = ({ V b_0 = heff_get(heff_dup(v_r_242), LBL_imports); V r_ = (g_prelude_2eany_24s2095707853x1489837173(b_0)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return v_r_242;
    }
    case TAG_False: {
      V v_t_245 = heff_rec(3, shape_name__alias__span, (V[]){heff_dup(g_heff_2eimport_2ebuiltinModule_get()), NTAG(TAG_Nothing), heff_rec(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)})});
      V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, heff_get(heff_dup(v_r_242), LBL_imports)});
      return heff_rec(2, shape_imports__text, (V[]){v_t_246, heff_get(v_r_242, LBL_text)});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eimport_2eimportsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eimport_2eimportsOf(a[0], a[1]);
}
Clo g_heff_2eimport_2erenameTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eimport_2erenameTo_entry, 2, 0};

V g_heff_2eimport_2erenameTo(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_x_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_from_244 = heff_field(v_x11_242, 0);
      V v_to_245 = heff_field(v_x11_242, 1);
      V v_t_246 = heff_strEq(heff_dup(v_from_244), heff_dup(v_x_241));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_x_241);
        return heff_dup(v_to_245);
      }
      case TAG_False: {
        V t_0 = v_rest_243;
        V t_1 = v_x_241;
        v_x1_240 = t_0;
        v_x_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eimport_2erenameTo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eimport_2erenameTo(a[0], a[1]); heff_drop(a[0]); return r;
}