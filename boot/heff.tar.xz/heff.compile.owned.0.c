// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_DFun 8330
#define TAG_DVal 23084
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkCArm 24694
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define LBL_body 9524841
#define LBL_lent 9813446
#define LBL_params 951713969
#define LBL_reprs 309759928
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_clo;
V g_heff_2ecompile_2eowned_2echain(V, V);
V g_heff_2ecompile_2eowned_2echain_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2echain_clo;
V g_heff_2ecompile_2eowned_2econdKids(V);
V g_heff_2ecompile_2eowned_2econdKids_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2econdKids_clo;
V g_heff_2ecompile_2eowned_2econdKids_24dps(V, V);
V g_heff_2ecompile_2eowned_2econdKids_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2econdKids_24dps_clo;
V g_heff_2ecompile_2eowned_2edefsSt_24s1110569521x699855806(V, V);
V g_heff_2ecompile_2eowned_2edefsSt_24s1110569521x699855806_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2edefsSt_24s1110569521x699855806_clo;
V g_heff_2ecompile_2eowned_2eelemS(V, V);
V g_heff_2ecompile_2eowned_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eelemS_clo;
HeffT2 g_heff_2ecompile_2eowned_2eheldOf_24cpr(V);
V g_heff_2ecompile_2eowned_2ekids(V);
V g_heff_2ecompile_2eowned_2ekids_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2ekids_clo;
V g_heff_2ecompile_2eowned_2elentOperand(V, V);
V g_heff_2ecompile_2eowned_2elentOperand_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2elentOperand_clo;
HeffT2 g_heff_2ecompile_2eowned_2elocalOf_24cpr(V);
V g_heff_2ecompile_2eowned_2emapCond(V, V);
V g_heff_2ecompile_2eowned_2emapCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_clo;
V g_heff_2ecompile_2eowned_2emapCond_24dps(V, V, V, V);
V g_heff_2ecompile_2eowned_2emapCond_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_24dps_clo;
V g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837(V);
V g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_clo;
V g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_24dps(V, V, V);
V g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_24dps_clo;
V g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405(V);
V g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_clo;
V g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_24dps(V, V, V);
V g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_24dps_clo;
V g_heff_2ecompile_2eowned_2eokArg(V, V, V);
V g_heff_2ecompile_2eowned_2eokArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eokArg_clo;
V g_heff_2ecompile_2eowned_2eokCond(V, V);
V g_heff_2ecompile_2eowned_2eokCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eokCond_clo;
V g_heff_2ecompile_2eowned_2eokExp(V, V, V);
V g_heff_2ecompile_2eowned_2eokExp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eokExp_clo;
V g_heff_2ecompile_2eowned_2eokSt(V, V, V, V);
V g_heff_2ecompile_2eowned_2eokSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eokSt_clo;
V g_heff_2ecompile_2eowned_2eokStmts(V, V, V);
V g_heff_2ecompile_2eowned_2eokStmts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eokStmts_clo;
V g_heff_2ecompile_2eowned_2eownCheck(V, V);
V g_heff_2ecompile_2eowned_2eownCheck_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eownCheck_clo;
V g_heff_2ecompile_2eowned_2eownExp(V, V);
V g_heff_2ecompile_2eowned_2eownExp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eownExp_clo;
V g_heff_2ecompile_2eowned_2eownExp_24dps(V, V, V, V);
V g_heff_2ecompile_2eowned_2eownExp_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eownExp_24dps_clo;
V g_heff_2ecompile_2eowned_2eownedAt(V, V);
V g_heff_2ecompile_2eowned_2eownedAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eownedAt_clo;
V g_heff_2ecompile_2eowned_2eownedChain(V, V, V, V);
V g_heff_2ecompile_2eowned_2eownedChain_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eownedChain_clo;
V g_heff_2ecompile_2eowned_2eownedDef(V);
V g_heff_2ecompile_2eowned_2eownedDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eownedDef_clo;
V g_heff_2ecompile_2eowned_2eplainOperand(V);
V g_heff_2ecompile_2eowned_2eplainOperand_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eplainOperand_clo;
HeffT2 g_heff_2ecompile_2eowned_2esetOf_24cpr(V);
V g_heff_2ecompile_2eowned_2esetRepr(V, V);
V g_heff_2ecompile_2eowned_2esetRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2esetRepr_clo;
V g_heff_2ecompile_2eowned_2ewordOnly(V);
V g_heff_2ecompile_2eowned_2ewordOnly_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2ewordOnly_clo;
V g_heff_2ecompile_2eranges_2ewordPrims_get(void);
V g_heff_2ecompile_2erefcount_2eelemI(V, V);
V g_heff_2ecompile_2erefcount_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemI_clo;
HeffT2 g_heff_2ecompile_2erefcount_2enthValue_24cpr(V, V);
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s141743730x1400463797(V, V, V, V);
V g_list_2eall_24s141743730x1400463797_entry(V self, V *a);
extern Clo g_list_2eall_24s141743730x1400463797_clo;
V g_list_2eany_24s1230506745x754542351(V, V);
V g_list_2eany_24s1230506745x754542351_entry(V self, V *a);
extern Clo g_list_2eany_24s1230506745x754542351_clo;
V g_list_2eany_24s357349853x1862456690(V, V);
V g_list_2eany_24s357349853x1862456690_entry(V self, V *a);
extern Clo g_list_2eany_24s357349853x1862456690_clo;
V g_list_2efoldl_24s1061624263x1097104198(V, V);
V g_list_2efoldl_24s1061624263x1097104198_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1061624263x1097104198_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s193704652x357697644(V, V);
V g_list_2efoldl_24s193704652x357697644_entry(V self, V *a);
extern Clo g_list_2efoldl_24s193704652x357697644_clo;
V g_list_2efoldl_24s490001784x345683100(V, V);
V g_list_2efoldl_24s490001784x345683100_entry(V self, V *a);
extern Clo g_list_2efoldl_24s490001784x345683100_clo;
V g_list_2efoldl_24s556506759x1439950987(V, V);
V g_list_2efoldl_24s556506759x1439950987_entry(V self, V *a);
extern Clo g_list_2efoldl_24s556506759x1439950987_clo;
V g_list_2efoldl_24s598828199x820230131(V, V);
V g_list_2efoldl_24s598828199x820230131_entry(V self, V *a);
extern Clo g_list_2efoldl_24s598828199x820230131_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1354671438x1264137843(V);
V g_list_2emap_24s1354671438x1264137843_entry(V self, V *a);
extern Clo g_list_2emap_24s1354671438x1264137843_clo;
V g_list_2emap_24s391650521x1406868658(V);
V g_list_2emap_24s391650521x1406868658_entry(V self, V *a);
extern Clo g_list_2emap_24s391650521x1406868658_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
Clo g_heff_2ecompile_2eowned_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2eowned_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eowned_2eelemS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eowned_2eelemS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eowned_2ewordOnly_str0, 4, "word");
Clo g_heff_2ecompile_2eowned_2ewordOnly_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2ewordOnly_entry, 1, 0};

V g_heff_2ecompile_2eowned_2ewordOnly(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RLocal: {
    return NTAG(TAG_True);
  }
  case TAG_RDup: {
    return NTAG(TAG_False);
  }
  case TAG_RClo: {
    return NTAG(TAG_False);
  }
  case TAG_RGet: {
    return NTAG(TAG_False);
  }
  case TAG_RGetRaw: {
    return NTAG(TAG_False);
  }
  case TAG_RInt: {
    return NTAG(TAG_False);
  }
  case TAG_RFloat: {
    return NTAG(TAG_False);
  }
  case TAG_RStr: {
    return NTAG(TAG_False);
  }
  case TAG_RBytes: {
    return NTAG(TAG_False);
  }
  case TAG_RFixed: {
    return NTAG(TAG_False);
  }
  case TAG_RF32: {
    return NTAG(TAG_False);
  }
  case TAG_RNTag: {
    return NTAG(TAG_False);
  }
  case TAG_RTag: {
    return NTAG(TAG_False);
  }
  case TAG_RTagIn: {
    return NTAG(TAG_False);
  }
  case TAG_RRec: {
    return NTAG(TAG_False);
  }
  case TAG_RRecIn: {
    return NTAG(TAG_False);
  }
  case TAG_RField: {
    return NTAG(TAG_False);
  }
  case TAG_RDupE: {
    return NTAG(TAG_False);
  }
  case TAG_RFieldV: {
    return NTAG(TAG_False);
  }
  case TAG_RGetN: {
    return NTAG(TAG_False);
  }
  case TAG_RFieldU: {
    return NTAG(TAG_False);
  }
  case TAG_RGetNU: {
    return NTAG(TAG_False);
  }
  case TAG_RWord: {
    return NTAG(TAG_False);
  }
  case TAG_RTakeField: {
    return NTAG(TAG_False);
  }
  case TAG_RGetLabel: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimFn: {
    return NTAG(TAG_False);
  }
  case TAG_RPrim: {
    return NTAG(TAG_False);
  }
  case TAG_RLam: {
    return NTAG(TAG_False);
  }
  case TAG_RCall: {
    return NTAG(TAG_False);
  }
  case TAG_RApply: {
    return NTAG(TAG_False);
  }
  case TAG_RBool: {
    return NTAG(TAG_False);
  }
  case TAG_RAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_RBox: {
    return NTAG(TAG_False);
  }
  case TAG_RUnbox: {
    return NTAG(TAG_False);
  }
  case TAG_RPeek: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimU: {
    V v_p_2475 = heff_field(v_x1_240, 0);
    V v_es_2476 = heff_field(v_x1_240, 1);
    if ((((int64_t)4ULL) < heff_unbox_word(heff_strLength_lent(v_p_2475, 0)))) {
      if (heff_strEq_c(heff_strSlice_lent(v_p_2475, MK_INT(0LL), MK_INT(4LL), 6), ((V)&g_heff_2ecompile_2eowned_2ewordOnly_str0))) {
        V v_t_2479 = ({ V a_0 = v_p_2475; V b_1 = heff_dup(g_heff_2ecompile_2eranges_2ewordPrims_get()); V r_ = (g_list_2eany_24s1230506745x754542351(a_0, b_1)); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_2479) == NTAG(TAG_True))) {
          heff_drop(v_t_2479);
          return (g_list_2eall(((V)&g_heff_2ecompile_2eowned_2ewordOnly_clo), v_es_2476));
        } else {
          heff_drop(v_t_2479);
          return NTAG(TAG_False);
        }
      } else {
        return NTAG(TAG_False);
      }
    } else {
      return NTAG(TAG_False);
    }
  }
  case TAG_RPrimAt: {
    return NTAG(TAG_False);
  }
  case TAG_RFixU: {
    return NTAG(TAG_True);
  }
  case TAG_RF32U: {
    return NTAG(TAG_False);
  }
  case TAG_RF64U: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eowned_2ewordOnly_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eowned_2ewordOnly(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eowned_2eplainOperand_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2eplainOperand_entry, 1, 0};

V g_heff_2ecompile_2eowned_2eplainOperand(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RLocal: {
    return NTAG(TAG_True);
  }
  case TAG_RDup: {
    return NTAG(TAG_True);
  }
  case TAG_RClo: {
    return NTAG(TAG_False);
  }
  case TAG_RGet: {
    return NTAG(TAG_False);
  }
  case TAG_RGetRaw: {
    return NTAG(TAG_False);
  }
  case TAG_RInt: {
    return NTAG(TAG_True);
  }
  case TAG_RFloat: {
    return NTAG(TAG_False);
  }
  case TAG_RStr: {
    return NTAG(TAG_True);
  }
  case TAG_RBytes: {
    return NTAG(TAG_False);
  }
  case TAG_RFixed: {
    return NTAG(TAG_False);
  }
  case TAG_RF32: {
    return NTAG(TAG_False);
  }
  case TAG_RNTag: {
    return NTAG(TAG_True);
  }
  case TAG_RTag: {
    return NTAG(TAG_False);
  }
  case TAG_RTagIn: {
    return NTAG(TAG_False);
  }
  case TAG_RRec: {
    return NTAG(TAG_False);
  }
  case TAG_RRecIn: {
    return NTAG(TAG_False);
  }
  case TAG_RField: {
    return NTAG(TAG_False);
  }
  case TAG_RDupE: {
    return NTAG(TAG_False);
  }
  case TAG_RFieldV: {
    return NTAG(TAG_False);
  }
  case TAG_RGetN: {
    return NTAG(TAG_False);
  }
  case TAG_RFieldU: {
    return NTAG(TAG_False);
  }
  case TAG_RGetNU: {
    return NTAG(TAG_False);
  }
  case TAG_RWord: {
    return NTAG(TAG_False);
  }
  case TAG_RTakeField: {
    return NTAG(TAG_False);
  }
  case TAG_RGetLabel: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimFn: {
    return NTAG(TAG_False);
  }
  case TAG_RPrim: {
    return NTAG(TAG_False);
  }
  case TAG_RLam: {
    return NTAG(TAG_False);
  }
  case TAG_RCall: {
    return NTAG(TAG_False);
  }
  case TAG_RApply: {
    return NTAG(TAG_False);
  }
  case TAG_RBool: {
    return NTAG(TAG_False);
  }
  case TAG_RAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_RBox: {
    V v_x11_2469 = heff_field(v_x1_240, 0);
    V v_e_2470 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_2469)) {
    case TAG_RepV: {
      return NTAG(TAG_False);
    }
    case TAG_RepFix: {
      return NTAG(TAG_False);
    }
    case TAG_RepF64: {
      return NTAG(TAG_False);
    }
    case TAG_RepInt: {
      HEFF_LAST return g_heff_2ecompile_2eowned_2ewordOnly(v_e_2470);
    }
    default: return heff_nomatch(v_x11_2469);
    }
  }
  case TAG_RUnbox: {
    return NTAG(TAG_False);
  }
  case TAG_RPeek: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimU: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimAt: {
    return NTAG(TAG_False);
  }
  case TAG_RFixU: {
    return NTAG(TAG_False);
  }
  case TAG_RF32U: {
    return NTAG(TAG_False);
  }
  case TAG_RF64U: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eowned_2eplainOperand_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eowned_2eplainOperand(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eowned_2elentOperand_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2elentOperand_entry, 2, 0};

V g_heff_2ecompile_2eowned_2elentOperand(V v_es_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_RLocal: {
    return NTAG(TAG_False);
  }
  case TAG_RDup: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_x1_244 = (g_list_2eany_24s357349853x1862456690(v_x_243, v_es_240));
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_244) == NTAG(TAG_True)));
    heff_drop(v_x1_244);
    return v_ret_24bool;
  }
  case TAG_RClo: {
    return NTAG(TAG_False);
  }
  case TAG_RGet: {
    return NTAG(TAG_False);
  }
  case TAG_RGetRaw: {
    return NTAG(TAG_False);
  }
  case TAG_RInt: {
    return NTAG(TAG_False);
  }
  case TAG_RFloat: {
    return NTAG(TAG_False);
  }
  case TAG_RStr: {
    return NTAG(TAG_False);
  }
  case TAG_RBytes: {
    return NTAG(TAG_False);
  }
  case TAG_RFixed: {
    return NTAG(TAG_False);
  }
  case TAG_RF32: {
    return NTAG(TAG_False);
  }
  case TAG_RNTag: {
    return NTAG(TAG_False);
  }
  case TAG_RTag: {
    return NTAG(TAG_False);
  }
  case TAG_RTagIn: {
    return NTAG(TAG_False);
  }
  case TAG_RRec: {
    return NTAG(TAG_False);
  }
  case TAG_RRecIn: {
    return NTAG(TAG_False);
  }
  case TAG_RField: {
    return NTAG(TAG_False);
  }
  case TAG_RDupE: {
    return NTAG(TAG_False);
  }
  case TAG_RFieldV: {
    return NTAG(TAG_False);
  }
  case TAG_RGetN: {
    return NTAG(TAG_False);
  }
  case TAG_RFieldU: {
    return NTAG(TAG_False);
  }
  case TAG_RGetNU: {
    return NTAG(TAG_False);
  }
  case TAG_RWord: {
    return NTAG(TAG_False);
  }
  case TAG_RTakeField: {
    return NTAG(TAG_False);
  }
  case TAG_RGetLabel: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimFn: {
    return NTAG(TAG_False);
  }
  case TAG_RPrim: {
    return NTAG(TAG_False);
  }
  case TAG_RLam: {
    return NTAG(TAG_False);
  }
  case TAG_RCall: {
    return NTAG(TAG_False);
  }
  case TAG_RApply: {
    return NTAG(TAG_False);
  }
  case TAG_RBool: {
    return NTAG(TAG_False);
  }
  case TAG_RAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_RBox: {
    return NTAG(TAG_False);
  }
  case TAG_RUnbox: {
    return NTAG(TAG_False);
  }
  case TAG_RPeek: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimU: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimAt: {
    return NTAG(TAG_False);
  }
  case TAG_RFixU: {
    return NTAG(TAG_False);
  }
  case TAG_RF32U: {
    return NTAG(TAG_False);
  }
  case TAG_RF64U: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eowned_2elentOperand_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eowned_2elentOperand(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eowned_2econdKids_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2econdKids_entry, 1, 0};

V g_heff_2ecompile_2eowned_2econdKids(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CondTrue: {
    return NTAG(TAG_Nil);
  }
  case TAG_CondFalse: {
    return NTAG(TAG_Nil);
  }
  case TAG_CondRel: {
    V v_es_242 = heff_field(v_x1_240, 1);
    return heff_dup(v_es_242);
  }
  case TAG_CondRelU: {
    V v_es_244 = heff_field(v_x1_240, 1);
    return heff_dup(v_es_244);
  }
  case TAG_CondBool: {
    V v_e_245 = heff_field(v_x1_240, 0);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_245), NTAG(TAG_Nil)});
  }
  case TAG_CondNot: {
    V v_c_246 = heff_field(v_x1_240, 0);
    V t_0 = v_c_246;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_CondIf: {
    V v_a_247 = heff_field(v_x1_240, 0);
    V v_b_248 = heff_field(v_x1_240, 1);
    V v_c_249 = heff_field(v_x1_240, 2);
    V v_t_2410 = (g_heff_2ecompile_2eowned_2econdKids(v_a_247));
    V v_t_2411 = (g_heff_2ecompile_2eowned_2econdKids(v_b_248));
    V v_t_2412 = (g_heff_2ecompile_2eowned_2econdKids(v_c_249));
    V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2412));
    return (g_prelude_2e_2b_2b(v_t_2410, v_t_2413));
  }
  case TAG_CondLet: {
    V v_e_2415 = heff_field(v_x1_240, 1);
    V v_c_2416 = heff_field(v_x1_240, 2);
    V v_cell_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2415), heff_hole()});
    V v_u_2419 = (g_heff_2ecompile_2eowned_2econdKids_24dps(v_c_2416, heff_dup(v_cell_2418)));
    heff_drop(v_u_2419);
    return v_cell_2418;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eowned_2econdKids_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eowned_2econdKids(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eowned_2ekids_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2ekids_entry, 1, 0};

V g_heff_2ecompile_2eowned_2ekids(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RDup: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RClo: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RGet: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RGetRaw: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_RF32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RNTag: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RTag: {
    V v_es_2416 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    return v_es_2416;
  }
  case TAG_RTagIn: {
    V v_e_2417 = heff_field(v_x1_240, 0);
    V v_es_2420 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 9ULL, 4);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_2417, v_es_2420});
  }
  case TAG_RRec: {
    V v_es_2423 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    return v_es_2423;
  }
  case TAG_RRecIn: {
    V v_fs_2430 = heff_field(v_x1_240, 6);
    heff_take_n(v_x1_240, 64ULL, 8);
    HEFF_LAST return g_list_2emap_24s1173914895x100384474(v_fs_2430);
  }
  case TAG_RField: {
    V v_e_2432 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24RField = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24RField, TAG_Cons, 2, (V[]){v_e_2432, NTAG(TAG_Nil)});
  }
  case TAG_RDupE: {
    V v_e_2434 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_2434, NTAG(TAG_Nil)});
  }
  case TAG_RFieldV: {
    V v_e_2435 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24RFieldV = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24RFieldV, TAG_Cons, 2, (V[]){v_e_2435, NTAG(TAG_Nil)});
  }
  case TAG_RGetN: {
    V v_e_2437 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 3);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_2437, NTAG(TAG_Nil)});
  }
  case TAG_RFieldU: {
    V v_e_2442 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 4);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_2442, NTAG(TAG_Nil)});
  }
  case TAG_RGetNU: {
    V v_e_2446 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_2446, NTAG(TAG_Nil)});
  }
  case TAG_RWord: {
    V v_e_2450 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24RWord = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24RWord, TAG_Cons, 2, (V[]){v_e_2450, NTAG(TAG_Nil)});
  }
  case TAG_RTakeField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_RGetLabel: {
    V v_e_2453 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24RGetLabel = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24RGetLabel, TAG_Cons, 2, (V[]){v_e_2453, NTAG(TAG_Nil)});
  }
  case TAG_RPrimFn: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RPrim: {
    V v_es_2457 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return v_es_2457;
  }
  case TAG_RLam: {
    V v_held_2460 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 4);
    return v_held_2460;
  }
  case TAG_RCall: {
    V v_args_2465 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    V v_t_2466 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2465));
    return (g_list_2efoldl_24s556506759x1439950987(NTAG(TAG_Nil), v_t_2466));
  }
  case TAG_RApply: {
    V v_f_2467 = heff_field(v_x1_240, 0);
    V v_es_2468 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24RApply = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24RApply, TAG_Cons, 2, (V[]){v_f_2467, v_es_2468});
  }
  case TAG_RBool: {
    V v_c_2469 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ({ V a_0 = v_c_2469; V r_ = (g_heff_2ecompile_2eowned_2econdKids(a_0)); heff_drop(v_c_2469); r_; });
  }
  case TAG_RAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_RBox: {
    V v_e_2471 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24RBox = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24RBox, TAG_Cons, 2, (V[]){v_e_2471, NTAG(TAG_Nil)});
  }
  case TAG_RUnbox: {
    V v_e_2473 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24RUnbox = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24RUnbox, TAG_Cons, 2, (V[]){v_e_2473, NTAG(TAG_Nil)});
  }
  case TAG_RPeek: {
    V v_e_2475 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24RPeek = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24RPeek, TAG_Cons, 2, (V[]){v_e_2475, NTAG(TAG_Nil)});
  }
  case TAG_RPrimU: {
    V v_es_2477 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return v_es_2477;
  }
  case TAG_RPrimAt: {
    V v_es_2480 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    return v_es_2480;
  }
  case TAG_RFixU: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_RF32U: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RF64U: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eowned_2ekids_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2ekids(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eowned_2esetOf_24cpr_str0, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2eowned_2esetOf_24cpr_str1, 8, "arraySet");

HeffT2 g_heff_2ecompile_2eowned_2esetOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RDup: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RClo: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGet: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetRaw: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RNTag: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTagIn: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRec: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRecIn: {
    heff_take_n(v_x1_240, 0ULL, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RDupE: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldV: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetN: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldU: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetNU: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RWord: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTakeField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetLabel: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimFn: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrim: {
    V v_p_2456 = heff_field(v_x1_240, 0);
    V v_es_2457 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(v_p_2456, ((V)&g_heff_2ecompile_2eowned_2esetOf_24cpr_str0))) {
      switch (heff_tag_of(v_es_2457)) {
      case TAG_Nil: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_e_2459 = heff_field(v_es_2457, 0);
        heff_take_n(v_es_2457, 1ULL, 2);
        HEFF_LAST return g_heff_2ecompile_2eowned_2elocalOf_24cpr(v_e_2459);
      }
      default: return ((HeffT2){{heff_nomatch(v_es_2457)}});
      }
    } else {
      heff_drop(v_es_2457);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_RLam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RCall: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RApply: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBool: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBox: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RUnbox: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPeek: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimU: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimAt: {
    V v_p_2480 = heff_field(v_x1_240, 0);
    V v_es_2482 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 5ULL, 3);
    if (heff_strEq_c(v_p_2480, ((V)&g_heff_2ecompile_2eowned_2esetOf_24cpr_str1))) {
      switch (heff_tag_of(v_es_2482)) {
      case TAG_Nil: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_e_2484 = heff_field(v_es_2482, 0);
        heff_take_n(v_es_2482, 1ULL, 2);
        HEFF_LAST return g_heff_2ecompile_2eowned_2elocalOf_24cpr(v_e_2484);
      }
      default: return ((HeffT2){{heff_nomatch(v_es_2482)}});
      }
    } else {
      heff_drop(v_es_2482);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_RFixU: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32U: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF64U: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_heff_2ecompile_2eowned_2eheldOf_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_RLocal: {
    V v_a_241 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_a_241}});
  }
  case TAG_RDup: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RClo: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RGet: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RGetRaw: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RInt: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RFloat: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RStr: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RBytes: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RFixed: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RF32: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RNTag: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RTag: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RTagIn: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RRec: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RRecIn: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RField: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RDupE: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RFieldV: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RGetN: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RFieldU: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RGetNU: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RWord: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RTakeField: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RGetLabel: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RPrimFn: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RPrim: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RLam: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RCall: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RApply: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RBool: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RAbandon: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RBox: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RUnbox: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RPeek: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RPrimU: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RPrimAt: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RFixU: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RF32U: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  case TAG_RF64U: {
    HEFF_LAST return g_heff_2ecompile_2eowned_2esetOf_24cpr(v_e_240);
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}
Clo g_heff_2ecompile_2eowned_2edefsSt_24s1110569521x699855806_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2edefsSt_24s1110569521x699855806_entry, 2, 0};

V g_heff_2ecompile_2eowned_2edefsSt_24s1110569521x699855806(V v_acc_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_s_241)) {
  case TAG_CDrop: {
    heff_take_n(v_s_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_CLet: {
    V v_x_243 = heff_field(v_s_241, 0);
    V v_e_244 = heff_field(v_s_241, 1);
    V v_ru_24s_241_24CLet = heff_take_reuse_n(v_s_241, 3ULL, 2);
    return heff_tag_at_n(v_ru_24s_241_24CLet, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_e_244}), v_acc_240});
  }
  case TAG_CDecl: {
    heff_take_n(v_s_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_CSet: {
    V v_x_246 = heff_field(v_s_241, 0);
    V v_e_247 = heff_field(v_s_241, 1);
    V v_ru_24s_241_24CSet = heff_take_reuse_n(v_s_241, 3ULL, 2);
    return heff_tag_at_n(v_ru_24s_241_24CSet, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_e_247}), v_acc_240});
  }
  case TAG_CAbandon: {
    return v_acc_240;
  }
  case TAG_CIf: {
    V v_a_249 = heff_field(v_s_241, 1);
    V v_b_2410 = heff_field(v_s_241, 2);
    heff_take_n(v_s_241, 6ULL, 3);
    V v_t_2411 = ({ V a_0 = v_acc_240; V a_1 = v_a_249; V r_ = (g_list_2efoldl_24s490001784x345683100(a_0, a_1)); heff_drop(v_a_249); r_; });
    return ({ V a_0 = v_t_2411; V a_1 = v_b_2410; V r_ = (g_list_2efoldl_24s490001784x345683100(a_0, a_1)); heff_drop(v_b_2410); r_; });
  }
  case TAG_CSwitch: {
    V v_arms_2413 = heff_field(v_s_241, 1);
    heff_take_n(v_s_241, 2ULL, 3);
    return ({ V a_0 = v_acc_240; V a_1 = v_arms_2413; V r_ = (g_list_2efoldl_24s193704652x357697644(a_0, a_1)); heff_drop(v_arms_2413); r_; });
  }
  case TAG_CReturn: {
    heff_take_n(v_s_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_CInPlace: {
    heff_take_n(v_s_241, 0ULL, 2);
    return v_acc_240;
  }
  case TAG_CRoomed: {
    heff_take_n(v_s_241, 0ULL, 2);
    return v_acc_240;
  }
  case TAG_CTail: {
    heff_take_n(v_s_241, 0ULL, 2);
    return v_acc_240;
  }
  case TAG_CLoop: {
    heff_take_n(v_s_241, 0ULL, 2);
    return v_acc_240;
  }
  case TAG_CLoopTo: {
    heff_take_n(v_s_241, 0ULL, 3);
    return v_acc_240;
  }
  case TAG_CLabel: {
    heff_take_n(v_s_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_CJump: {
    heff_take_n(v_s_241, 0ULL, 3);
    return v_acc_240;
  }
  default: return heff_nomatch(v_s_241);
  }
}
V g_heff_2ecompile_2eowned_2edefsSt_24s1110569521x699855806_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2edefsSt_24s1110569521x699855806(a[0], a[1]);
}
Clo g_heff_2ecompile_2eowned_2eokArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2eokArg_entry, 3, 0};

V g_heff_2ecompile_2eowned_2eokArg(V v_ok_240, V v_us_241, V v_a_242) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_Given: {
    V v_t_2410;
    switch (heff_tag_of(v_a_242)) {
    case TAG_Given: {
      V v_e_244 = heff_field(v_a_242, 0);
      heff_take_n(v_a_242, 1ULL, 1);
      v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
      break;
    }
    case TAG_GivenU: {
      V v_e_246 = heff_field(v_a_242, 1);
      V v_ru_24a_242_24GivenU = heff_take_reuse_n(v_a_242, 2ULL, 2);
      v_t_2410 = heff_tag_at_n(v_ru_24a_242_24GivenU, TAG_Cons, 2, (V[]){v_e_246, NTAG(TAG_Nil)});
      break;
    }
    case TAG_LentVar: {
      heff_take_n(v_a_242, 0ULL, 2);
      v_t_2410 = NTAG(TAG_Nil);
      break;
    }
    case TAG_LentValue: {
      V v_e_249 = heff_field(v_a_242, 0);
      heff_take_n(v_a_242, 1ULL, 1);
      v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_249, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    return ({ V a_0 = v_ok_240; V a_1 = v_t_2410; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2410); r_; });
  }
  case TAG_GivenU: {
    V v_t_2419;
    switch (heff_tag_of(v_a_242)) {
    case TAG_Given: {
      V v_e_2413 = heff_field(v_a_242, 0);
      heff_take_n(v_a_242, 1ULL, 1);
      v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2413, NTAG(TAG_Nil)});
      break;
    }
    case TAG_GivenU: {
      V v_e_2415 = heff_field(v_a_242, 1);
      V v_ru_24a_242_24GivenU = heff_take_reuse_n(v_a_242, 2ULL, 2);
      v_t_2419 = heff_tag_at_n(v_ru_24a_242_24GivenU, TAG_Cons, 2, (V[]){v_e_2415, NTAG(TAG_Nil)});
      break;
    }
    case TAG_LentVar: {
      heff_take_n(v_a_242, 0ULL, 2);
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    case TAG_LentValue: {
      V v_e_2418 = heff_field(v_a_242, 0);
      heff_take_n(v_a_242, 1ULL, 1);
      v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2418, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    return ({ V a_0 = v_ok_240; V a_1 = v_t_2419; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2419); r_; });
  }
  case TAG_LentVar: {
    V v_x_2420 = heff_field(v_a_242, 0);
    heff_take_n(v_a_242, 1ULL, 2);
    heff_drop(v_ok_240);
    V v_x1_2422 = ({ V a_0 = v_x_2420; V a_1 = v_us_241; V r_ = (g_heff_2ecompile_2eowned_2eelemS(a_0, a_1)); heff_drop(v_x_2420); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2422) == NTAG(TAG_True)));
    heff_drop(v_x1_2422);
    return v_ret_24bool;
  }
  case TAG_LentValue: {
    V v_t_2430;
    switch (heff_tag_of(v_a_242)) {
    case TAG_Given: {
      V v_e_2424 = heff_field(v_a_242, 0);
      heff_take_n(v_a_242, 1ULL, 1);
      v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2424, NTAG(TAG_Nil)});
      break;
    }
    case TAG_GivenU: {
      V v_e_2426 = heff_field(v_a_242, 1);
      V v_ru_24a_242_24GivenU = heff_take_reuse_n(v_a_242, 2ULL, 2);
      v_t_2430 = heff_tag_at_n(v_ru_24a_242_24GivenU, TAG_Cons, 2, (V[]){v_e_2426, NTAG(TAG_Nil)});
      break;
    }
    case TAG_LentVar: {
      heff_take_n(v_a_242, 0ULL, 2);
      v_t_2430 = NTAG(TAG_Nil);
      break;
    }
    case TAG_LentValue: {
      V v_e_2429 = heff_field(v_a_242, 0);
      heff_take_n(v_a_242, 1ULL, 1);
      v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2429, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    return ({ V a_0 = v_ok_240; V a_1 = v_t_2430; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2430); r_; });
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2ecompile_2eowned_2eokArg_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eowned_2eokArg(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eowned_2eokSt_lam0(V self, V *args);
Clo g_heff_2ecompile_2eowned_2eokSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2eokSt_entry, 4, 0};

V g_heff_2ecompile_2eowned_2eokSt(V v_go_240, V v_us_241, V v_j_242, V v_s_243) {
top: ;
  switch (heff_tag_of(v_s_243)) {
  case TAG_CDrop: {
    heff_take_n(v_s_243, 0ULL, 1);
    heff_drop(v_go_240);
    heff_drop(v_us_241);
    heff_drop(v_j_242);
    return NTAG(TAG_True);
  }
  case TAG_CLet: {
    V v_e_246 = heff_field(v_s_243, 1);
    heff_take_n(v_s_243, 2ULL, 2);
    heff_drop(v_j_242);
    return (g_heff_2ecompile_2eowned_2eokExp(v_go_240, v_us_241, v_e_246));
  }
  case TAG_CDecl: {
    heff_take_n(v_s_243, 0ULL, 1);
    heff_drop(v_go_240);
    heff_drop(v_us_241);
    heff_drop(v_j_242);
    return NTAG(TAG_True);
  }
  case TAG_CSet: {
    V v_e_249 = heff_field(v_s_243, 1);
    heff_take_n(v_s_243, 2ULL, 2);
    heff_drop(v_j_242);
    return (g_heff_2ecompile_2eowned_2eokExp(v_go_240, v_us_241, v_e_249));
  }
  case TAG_CAbandon: {
    heff_drop(v_go_240);
    heff_drop(v_us_241);
    heff_drop(v_j_242);
    return NTAG(TAG_True);
  }
  case TAG_CIf: {
    V v_c_2410 = heff_field(v_s_243, 0);
    V v_a_2411 = heff_field(v_s_243, 1);
    V v_b_2412 = heff_field(v_s_243, 2);
    heff_take_n(v_s_243, 7ULL, 3);
    heff_drop(v_j_242);
    V v_t_2413 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){heff_dup(v_go_240), v_us_241}));
    V v_t_2414 = ({ V a_0 = v_t_2413; V a_1 = v_c_2410; V r_ = (g_heff_2ecompile_2eowned_2eokCond(a_0, a_1)); heff_drop(v_c_2410); r_; });
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_t_2414);
      V v_t_2415 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_a_2411}));
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        return heff_tail(v_go_240, 1, (V[]){v_b_2412});
      } else {
        heff_drop(v_go_240);
        heff_drop(v_b_2412);
        heff_drop(v_t_2415);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_go_240);
      heff_drop(v_a_2411);
      heff_drop(v_b_2412);
      heff_drop(v_t_2414);
      return NTAG(TAG_False);
    }
  }
  case TAG_CSwitch: {
    V v_e_2416 = heff_field(v_s_243, 0);
    V v_arms_2417 = heff_field(v_s_243, 1);
    heff_take_n(v_s_243, 3ULL, 3);
    heff_drop(v_j_242);
    V v_t_2419 = heff_tr(g_heff_2ecompile_2eowned_2eokExp(heff_dup(v_go_240), v_us_241, v_e_2416));
    if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
      heff_drop(v_t_2419);
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eowned_2eokSt_lam0, 1, 1, (V[]){v_go_240}); V a_1 = v_arms_2417; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2417); r_; });
    } else {
      heff_drop(v_go_240);
      heff_drop(v_arms_2417);
      heff_drop(v_t_2419);
      return NTAG(TAG_False);
    }
  }
  case TAG_CReturn: {
    V v_e_2430 = heff_field(v_s_243, 0);
    heff_take_n(v_s_243, 1ULL, 1);
    heff_drop(v_j_242);
    return (g_heff_2ecompile_2eowned_2eokExp(v_go_240, v_us_241, v_e_2430));
  }
  case TAG_CInPlace: {
    V v_f_2431 = heff_field(v_s_243, 0);
    V v_es_2432 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CInPlace = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_j_242);
    V v_t_2433 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    return ({ V a_0 = v_t_2433; V b_1 = heff_tag_at_n(v_ru_24s_243_24CInPlace, TAG_Cons, 2, (V[]){v_f_2431, v_es_2432}); V r_ = (g_list_2eall(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_CRoomed: {
    V v_f_2434 = heff_field(v_s_243, 0);
    V v_es_2435 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CRoomed = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_j_242);
    V v_t_2436 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    return ({ V a_0 = v_t_2436; V b_1 = heff_tag_at_n(v_ru_24s_243_24CRoomed, TAG_Cons, 2, (V[]){v_f_2434, v_es_2435}); V r_ = (g_list_2eall(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_CTail: {
    V v_f_2437 = heff_field(v_s_243, 0);
    V v_es_2438 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CTail = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_j_242);
    V v_t_2439 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    return ({ V a_0 = v_t_2439; V b_1 = heff_tag_at_n(v_ru_24s_243_24CTail, TAG_Cons, 2, (V[]){v_f_2437, v_es_2438}); V r_ = (g_list_2eall(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_CLoop: {
    V v_es_2441 = heff_field(v_s_243, 1);
    heff_take_n(v_s_243, 2ULL, 2);
    HeffT2 v_t_2442 = (g_heff_2ecompile_2erefcount_2enthValue_24cpr(v_j_242, heff_dup(v_es_2441)));
    {
      V v_field_2444 = v_t_2442.f[1];
      int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
      if ((v_tag_2443 == ((int64_t)0ULL))) {
        V v_e_2446 = v_field_2444;
        HeffT2 v_t_2447 = (g_heff_2ecompile_2eowned_2eheldOf_24cpr(v_e_2446));
        {
          V v_field_2449 = v_t_2447.f[1];
          int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
          if ((v_tag_2448 == ((int64_t)0ULL))) {
            V v_x_2451 = v_field_2449;
            V v_t_2452 = ({ V a_0 = v_x_2451; V a_1 = v_us_241; V r_ = (g_heff_2ecompile_2eowned_2eelemS(a_0, a_1)); heff_drop(v_x_2451); r_; });
            if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
              heff_drop(v_t_2452);
              V v_t_2453 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
              return ({ V a_0 = v_t_2453; V a_1 = v_es_2441; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_es_2441); r_; });
            } else {
              heff_drop(v_go_240);
              heff_drop(v_us_241);
              heff_drop(v_es_2441);
              heff_drop(v_t_2452);
              return NTAG(TAG_False);
            }
          } else {
            heff_drop(v_go_240);
            heff_drop(v_us_241);
            heff_drop(v_es_2441);
            heff_drop(v_field_2449);
            return NTAG(TAG_False);
          }
        }
      } else {
        heff_drop(v_go_240);
        heff_drop(v_us_241);
        heff_drop(v_es_2441);
        heff_drop(v_field_2444);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_CLoopTo: {
    V v_es_2456 = heff_field(v_s_243, 2);
    heff_take_n(v_s_243, 4ULL, 3);
    HeffT2 v_t_2457 = (g_heff_2ecompile_2erefcount_2enthValue_24cpr(v_j_242, heff_dup(v_es_2456)));
    {
      V v_field_2459 = v_t_2457.f[1];
      int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
      if ((v_tag_2458 == ((int64_t)0ULL))) {
        V v_e_2461 = v_field_2459;
        HeffT2 v_t_2462 = (g_heff_2ecompile_2eowned_2eheldOf_24cpr(v_e_2461));
        {
          V v_field_2464 = v_t_2462.f[1];
          int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
          if ((v_tag_2463 == ((int64_t)0ULL))) {
            V v_x_2466 = v_field_2464;
            V v_t_2467 = ({ V a_0 = v_x_2466; V a_1 = v_us_241; V r_ = (g_heff_2ecompile_2eowned_2eelemS(a_0, a_1)); heff_drop(v_x_2466); r_; });
            if ((heff_dup(v_t_2467) == NTAG(TAG_True))) {
              heff_drop(v_t_2467);
              V v_t_2468 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
              return ({ V a_0 = v_t_2468; V a_1 = v_es_2456; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_es_2456); r_; });
            } else {
              heff_drop(v_go_240);
              heff_drop(v_us_241);
              heff_drop(v_es_2456);
              heff_drop(v_t_2467);
              return NTAG(TAG_False);
            }
          } else {
            heff_drop(v_go_240);
            heff_drop(v_us_241);
            heff_drop(v_es_2456);
            heff_drop(v_field_2464);
            return NTAG(TAG_False);
          }
        }
      } else {
        heff_drop(v_go_240);
        heff_drop(v_us_241);
        heff_drop(v_es_2456);
        heff_drop(v_field_2459);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_CLabel: {
    heff_take_n(v_s_243, 0ULL, 1);
    heff_drop(v_go_240);
    heff_drop(v_us_241);
    heff_drop(v_j_242);
    return NTAG(TAG_True);
  }
  case TAG_CJump: {
    V v_es_2472 = heff_field(v_s_243, 2);
    heff_take_n(v_s_243, 4ULL, 3);
    heff_drop(v_j_242);
    V v_t_2473 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    return ({ V a_0 = v_t_2473; V a_1 = v_es_2472; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_es_2472); r_; });
  }
  default: return heff_nomatch(v_s_243);
  }
}
V g_heff_2ecompile_2eowned_2eokSt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2eokSt(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eowned_2eokSt_lam0(V self, V *args) {
  V v_arm_2420 = args[0];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429;
  switch (heff_tag_of(v_arm_2420)) {
  case TAG_MkCArm: {
    V v_body_2427 = heff_field(v_arm_2420, 6);
    heff_take_n(v_arm_2420, 64ULL, 8);
    v_t_2429 = v_body_2427;
    break;
  }
  default: heff_nomatch(v_arm_2420);
  }
  V f_ = v_go_240;
  args[0] = v_t_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2ecompile_2eowned_2eokStmts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2eokStmts_entry, 3, 0};

V g_heff_2ecompile_2eowned_2eokStmts(V v_us_240, V v_j_241, V v_ss_242) {
top: ;
  V v_t_243 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokStmts_clo), 2, (V[]){heff_dup(v_us_240), heff_dup(v_j_241)}));
  return (g_list_2eall_24s141743730x1400463797(v_t_243, v_us_240, v_j_241, v_ss_242));
}
V g_heff_2ecompile_2eowned_2eokStmts_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eowned_2eokStmts(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eowned_2esetRepr_str0, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2eowned_2esetRepr_str1, 8, "arraySet");
Clo g_heff_2ecompile_2eowned_2esetRepr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2esetRepr_entry, 2, 0};

V g_heff_2ecompile_2eowned_2esetRepr(V v_us_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_RLocal: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RDup: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RClo: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RGet: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RGetRaw: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RFloat: {
    heff_take_na(v_e_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_RF32: {
    heff_take_na(v_e_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RNTag: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RTag: {
    heff_take_n(v_e_241, 0ULL, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_RTagIn: {
    heff_take_n(v_e_241, 0ULL, 4);
    return NTAG(TAG_Nil);
  }
  case TAG_RRec: {
    heff_take_n(v_e_241, 0ULL, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_RRecIn: {
    heff_take_n(v_e_241, 0ULL, 8);
    return NTAG(TAG_Nil);
  }
  case TAG_RField: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_RDupE: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RFieldV: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_RGetN: {
    heff_take_n(v_e_241, 0ULL, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_RFieldU: {
    heff_take_n(v_e_241, 0ULL, 4);
    return NTAG(TAG_Nil);
  }
  case TAG_RGetNU: {
    heff_take_n(v_e_241, 0ULL, 5);
    return NTAG(TAG_Nil);
  }
  case TAG_RWord: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_RTakeField: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_RGetLabel: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_RPrimFn: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RPrim: {
    V v_p_2457 = heff_field(v_e_241, 0);
    V v_es_2458 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24RPrim = heff_take_reuse_n(v_e_241, 3ULL, 2);
    HeffT2 v_t_2459 = (g_heff_2ecompile_2eowned_2eheldOf_24cpr(heff_tag_at_n(v_ru_24e_241_24RPrim, TAG_RPrim, 2, (V[]){heff_dup(v_p_2457), v_es_2458})));
    {
      V v_field_2461 = v_t_2459.f[1];
      int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
      if ((v_tag_2460 == ((int64_t)0ULL))) {
        V v_x_2463 = v_field_2461;
        V v_t_2464 = ({ V a_0 = v_x_2463; V a_1 = v_us_240; V r_ = (g_heff_2ecompile_2eowned_2eelemS(a_0, a_1)); heff_drop(v_x_2463); r_; });
        if ((heff_dup(v_t_2464) == NTAG(TAG_True))) {
          heff_drop(v_t_2464);
          if (heff_strEq_c(v_p_2457, ((V)&g_heff_2ecompile_2eowned_2esetRepr_str0))) {
            return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepV), NTAG(TAG_Nil)});
          } else {
            return NTAG(TAG_Nil);
          }
        } else {
          heff_drop(v_p_2457);
          heff_drop(v_t_2464);
          return NTAG(TAG_Nil);
        }
      } else {
        heff_drop(v_p_2457);
        heff_drop(v_field_2461);
        return NTAG(TAG_Nil);
      }
    }
  }
  case TAG_RLam: {
    heff_take_n(v_e_241, 0ULL, 4);
    return NTAG(TAG_Nil);
  }
  case TAG_RCall: {
    heff_take_n(v_e_241, 0ULL, 4);
    return NTAG(TAG_Nil);
  }
  case TAG_RApply: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_RBool: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_RBox: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_RUnbox: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_RPeek: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_RPrimU: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_RPrimAt: {
    V v_p_2485 = heff_field(v_e_241, 0);
    V v_r_2486 = heff_field(v_e_241, 1);
    V v_es_2487 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24RPrimAt = heff_take_reuse_n(v_e_241, 7ULL, 3);
    HeffT2 v_t_2488 = (g_heff_2ecompile_2eowned_2eheldOf_24cpr(heff_tag_at_n(v_ru_24e_241_24RPrimAt, TAG_RPrimAt, 3, (V[]){heff_dup(v_p_2485), heff_dup(v_r_2486), v_es_2487})));
    {
      V v_field_2490 = v_t_2488.f[1];
      int64_t v_tag_2489 = ((int64_t)v_t_2488.f[0]);
      if ((v_tag_2489 == ((int64_t)0ULL))) {
        V v_x_2492 = v_field_2490;
        V v_t_2493 = ({ V a_0 = v_x_2492; V a_1 = v_us_240; V r_ = (g_heff_2ecompile_2eowned_2eelemS(a_0, a_1)); heff_drop(v_x_2492); r_; });
        if ((heff_dup(v_t_2493) == NTAG(TAG_True))) {
          heff_drop(v_t_2493);
          if (heff_strEq_c(v_p_2485, ((V)&g_heff_2ecompile_2eowned_2esetRepr_str1))) {
            return heff_tag_n(TAG_Cons, 2, (V[]){v_r_2486, NTAG(TAG_Nil)});
          } else {
            heff_drop(v_r_2486);
            return NTAG(TAG_Nil);
          }
        } else {
          heff_drop(v_p_2485);
          heff_drop(v_r_2486);
          heff_drop(v_t_2493);
          return NTAG(TAG_Nil);
        }
      } else {
        heff_drop(v_p_2485);
        heff_drop(v_r_2486);
        heff_drop(v_field_2490);
        return NTAG(TAG_Nil);
      }
    }
  }
  case TAG_RFixU: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_RF32U: {
    heff_take_na(v_e_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_RF64U: {
    heff_take_na(v_e_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eowned_2esetRepr_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eowned_2esetRepr(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eowned_2emapCond_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2emapCond_24dps_entry, 4, 0};

V g_heff_2ecompile_2eowned_2emapCond_24dps(V v_f_240, V v_x2_241, V v_d_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CondTrue: {
    heff_drop(v_f_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_CondFalse: {
    heff_drop(v_f_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_CondRel: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_es_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_246 = (g_list_2emap(v_f_240, v_es_245));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_CondRel, 2, (V[]){v_p_244, v_t_246}));
  }
  case TAG_CondRelU: {
    V v_p_247 = heff_field(v_x2_241, 0);
    V v_es_248 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_249 = (g_list_2emap(v_f_240, v_es_248));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_CondRelU, 2, (V[]){v_p_247, v_t_249}));
  }
  case TAG_CondBool: {
    V v_e_2410 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_2411 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_2410}));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_CondBool, 1, (V[]){v_t_2411}));
  }
  case TAG_CondNot: {
    V v_c_2412 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24CondNot = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_241_24CondNot, TAG_CondNot, 1, (V[]){heff_hole()});
    V v_u_2414 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_f_240;
    V t_1 = v_c_2412;
    V t_2 = v_cell_2413;
    V t_3 = MK_INT(0LL);
    v_f_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_CondIf: {
    V v_a_2415 = heff_field(v_x2_241, 0);
    V v_b_2416 = heff_field(v_x2_241, 1);
    V v_c_2417 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24CondIf = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2418 = (g_heff_2ecompile_2eowned_2emapCond(heff_dup(v_f_240), v_a_2415));
    V v_t_2419 = (g_heff_2ecompile_2eowned_2emapCond(heff_dup(v_f_240), v_b_2416));
    V v_cell_2420 = heff_tag_at_n(v_ru_24x2_241_24CondIf, TAG_CondIf, 3, (V[]){v_t_2418, v_t_2419, heff_hole()});
    V v_u_2421 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2420));
    heff_drop(v_u_2421);
    V t_0 = v_f_240;
    V t_1 = v_c_2417;
    V t_2 = v_cell_2420;
    V t_3 = MK_INT(2LL);
    v_f_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_CondLet: {
    V v_x_2422 = heff_field(v_x2_241, 0);
    V v_e_2423 = heff_field(v_x2_241, 1);
    V v_c_2424 = heff_field(v_x2_241, 2);
    V v_ds_2425 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_t_2426 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_e_2423}));
    V v_t_2427 = (g_heff_2ecompile_2eowned_2emapCond(v_f_240, v_c_2424));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_CondLet, 4, (V[]){v_x_2422, v_t_2426, v_t_2427, v_ds_2425}));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eowned_2emapCond_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2emapCond_24dps(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eowned_2eownExp_str0, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2eowned_2eownExp_str1, 13, "arraySetOwned");
HEFF_LIT(g_heff_2ecompile_2eowned_2eownExp_str2, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2eowned_2eownExp_str3, 13, "arraySetOwned");
V g_heff_2ecompile_2eowned_2eownExp_lam0(V self, V *args);
V g_heff_2ecompile_2eowned_2eownExp_lam1(V self, V *args);
Clo g_heff_2ecompile_2eowned_2eownExp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2eownExp_entry, 2, 0};

V g_heff_2ecompile_2eowned_2eownExp(V v_us_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_RLocal: {
    heff_drop(v_us_240);
    return v_x2_241;
  }
  case TAG_RDup: {
    heff_drop(v_us_240);
    return v_x2_241;
  }
  case TAG_RClo: {
    heff_drop(v_us_240);
    return v_x2_241;
  }
  case TAG_RGet: {
    heff_drop(v_us_240);
    return v_x2_241;
  }
  case TAG_RGetRaw: {
    heff_drop(v_us_240);
    return v_x2_241;
  }
  case TAG_RInt: {
    heff_drop(v_us_240);
    return v_x2_241;
  }
  case TAG_RFloat: {
    heff_drop(v_us_240);
    return v_x2_241;
  }
  case TAG_RStr: {
    heff_drop(v_us_240);
    return v_x2_241;
  }
  case TAG_RBytes: {
    heff_drop(v_us_240);
    return v_x2_241;
  }
  case TAG_RFixed: {
    heff_drop(v_us_240);
    return v_x2_241;
  }
  case TAG_RF32: {
    heff_drop(v_us_240);
    return v_x2_241;
  }
  case TAG_RNTag: {
    heff_drop(v_us_240);
    return v_x2_241;
  }
  case TAG_RTag: {
    V v_t_2415 = heff_field(v_x2_241, 0);
    V v_b_2416 = heff_field(v_x2_241, 1);
    V v_es_2417 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24RTag = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2418 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_2419 = (g_list_2emap(v_t_2418, v_es_2417));
    return heff_tag_at_n(v_ru_24x2_241_24RTag, TAG_RTag, 3, (V[]){v_t_2415, v_b_2416, v_t_2419});
  }
  case TAG_RTagIn: {
    V v_e_2420 = heff_field(v_x2_241, 0);
    V v_t_2421 = heff_field(v_x2_241, 1);
    V v_b_2422 = heff_field(v_x2_241, 2);
    V v_es_2423 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24RTagIn = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_t_2424 = (g_heff_2ecompile_2eowned_2eownExp(heff_dup(v_us_240), v_e_2420));
    V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_2426 = (g_list_2emap(v_t_2425, v_es_2423));
    return heff_tag_at_n(v_ru_24x2_241_24RTagIn, TAG_RTagIn, 4, (V[]){v_t_2424, v_t_2421, v_b_2422, v_t_2426});
  }
  case TAG_RRec: {
    V v_ls_2427 = heff_field(v_x2_241, 0);
    V v_b_2428 = heff_field(v_x2_241, 1);
    V v_es_2429 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24RRec = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2430 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_2431 = (g_list_2emap(v_t_2430, v_es_2429));
    return heff_tag_at_n(v_ru_24x2_241_24RRec, TAG_RRec, 3, (V[]){v_ls_2427, v_b_2428, v_t_2431});
  }
  case TAG_RRecIn: {
    V v_x_2432 = heff_field(v_x2_241, 0);
    V v_n_2433 = heff_field(v_x2_241, 1);
    V v_k_2434 = heff_field(v_x2_241, 2);
    V v_f_2435 = heff_field(v_x2_241, 3);
    V v_s_2436 = heff_field(v_x2_241, 4);
    V v_ls_2437 = heff_field(v_x2_241, 5);
    V v_fs_2438 = heff_field(v_x2_241, 6);
    V v_sure_2439 = heff_field(v_x2_241, 7);
    V v_ru_24x2_241_24RRecIn = heff_take_reuse_n(v_x2_241, 255ULL, 8);
    V v_t_2448 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eowned_2eownExp_lam0, 1, 1, (V[]){v_us_240}), v_fs_2438));
    return heff_tag_at_n(v_ru_24x2_241_24RRecIn, TAG_RRecIn, 8, (V[]){v_x_2432, v_n_2433, v_k_2434, v_f_2435, v_s_2436, v_ls_2437, v_t_2448, v_sure_2439});
  }
  case TAG_RField: {
    V v_e_2449 = heff_field(v_x2_241, 0);
    V v_i_2450 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RField = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2451 = (g_heff_2ecompile_2eowned_2eownExp(v_us_240, v_e_2449));
    return heff_tag_at_n(v_ru_24x2_241_24RField, TAG_RField, 2, (V[]){v_t_2451, v_i_2450});
  }
  case TAG_RDupE: {
    V v_e_2452 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24RDupE = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_cell_2453 = heff_tag_at_n(v_ru_24x2_241_24RDupE, TAG_RDupE, 1, (V[]){heff_hole()});
    V v_u_2454 = (g_heff_2ecompile_2eowned_2eownExp_24dps(v_us_240, v_e_2452, heff_dup(v_cell_2453), MK_INT(0LL)));
    heff_drop(v_u_2454);
    return v_cell_2453;
  }
  case TAG_RFieldV: {
    V v_e_2455 = heff_field(v_x2_241, 0);
    V v_i_2456 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RFieldV = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2457 = (g_heff_2ecompile_2eowned_2eownExp(v_us_240, v_e_2455));
    return heff_tag_at_n(v_ru_24x2_241_24RFieldV, TAG_RFieldV, 2, (V[]){v_t_2457, v_i_2456});
  }
  case TAG_RGetN: {
    V v_e_2458 = heff_field(v_x2_241, 0);
    V v_i_2459 = heff_field(v_x2_241, 1);
    V v_n_2460 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24RGetN = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2461 = (g_heff_2ecompile_2eowned_2eownExp(v_us_240, v_e_2458));
    return heff_tag_at_n(v_ru_24x2_241_24RGetN, TAG_RGetN, 3, (V[]){v_t_2461, v_i_2459, v_n_2460});
  }
  case TAG_RFieldU: {
    V v_r_2462 = heff_field(v_x2_241, 0);
    V v_s_2463 = heff_field(v_x2_241, 1);
    V v_e_2464 = heff_field(v_x2_241, 2);
    V v_i_2465 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24RFieldU = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_t_2466 = (g_heff_2ecompile_2eowned_2eownExp(v_us_240, v_e_2464));
    return heff_tag_at_n(v_ru_24x2_241_24RFieldU, TAG_RFieldU, 4, (V[]){v_r_2462, v_s_2463, v_t_2466, v_i_2465});
  }
  case TAG_RGetNU: {
    V v_r_2467 = heff_field(v_x2_241, 0);
    V v_s_2468 = heff_field(v_x2_241, 1);
    V v_e_2469 = heff_field(v_x2_241, 2);
    V v_i_2470 = heff_field(v_x2_241, 3);
    V v_n_2471 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24RGetNU = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_t_2472 = (g_heff_2ecompile_2eowned_2eownExp(v_us_240, v_e_2469));
    return heff_tag_at_n(v_ru_24x2_241_24RGetNU, TAG_RGetNU, 5, (V[]){v_r_2467, v_s_2468, v_t_2472, v_i_2470, v_n_2471});
  }
  case TAG_RWord: {
    V v_r_2473 = heff_field(v_x2_241, 0);
    V v_e_2474 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RWord = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_2475 = heff_tag_at_n(v_ru_24x2_241_24RWord, TAG_RWord, 2, (V[]){v_r_2473, heff_hole()});
    V v_u_2476 = (g_heff_2ecompile_2eowned_2eownExp_24dps(v_us_240, v_e_2474, heff_dup(v_cell_2475), MK_INT(1LL)));
    heff_drop(v_u_2476);
    return v_cell_2475;
  }
  case TAG_RTakeField: {
    heff_drop(v_us_240);
    return v_x2_241;
  }
  case TAG_RGetLabel: {
    V v_e_2479 = heff_field(v_x2_241, 0);
    V v_l_2480 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RGetLabel = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2481 = (g_heff_2ecompile_2eowned_2eownExp(v_us_240, v_e_2479));
    return heff_tag_at_n(v_ru_24x2_241_24RGetLabel, TAG_RGetLabel, 2, (V[]){v_t_2481, v_l_2480});
  }
  case TAG_RPrimFn: {
    heff_drop(v_us_240);
    return v_x2_241;
  }
  case TAG_RPrim: {
    V v_p_2483 = heff_field(v_x2_241, 0);
    V v_es_2484 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RPrim = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2492;
    if (heff_strEq_c_lent(v_p_2483, ((V)&g_heff_2ecompile_2eowned_2eownExp_str0), 2)) {
      HeffT2 v_t_2486 = (g_heff_2ecompile_2eowned_2eheldOf_24cpr(heff_tag_at_n(v_ru_24x2_241_24RPrim, TAG_RPrim, 2, (V[]){heff_dup(v_p_2483), heff_dup(v_es_2484)})));
      {
        V v_field_2488 = v_t_2486.f[1];
        int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
        if ((v_tag_2487 == ((int64_t)0ULL))) {
          V v_x_2490 = v_field_2488;
          V v_t_2491 = ({ V a_0 = v_x_2490; V a_1 = v_us_240; V r_ = (g_heff_2ecompile_2eowned_2eelemS(a_0, a_1)); heff_drop(v_x_2490); r_; });
          if ((heff_dup(v_t_2491) == NTAG(TAG_True))) {
            heff_drop(v_p_2483);
            heff_drop(v_t_2491);
            v_t_2492 = ((V)&g_heff_2ecompile_2eowned_2eownExp_str1);
          } else {
            heff_drop(v_t_2491);
            v_t_2492 = v_p_2483;
          }
        } else {
          heff_drop(v_field_2488);
          v_t_2492 = v_p_2483;
        }
      }
    } else {
      heff_drop_cell(v_ru_24x2_241_24RPrim, 2);
      v_t_2492 = v_p_2483;
    }
    V v_t_2493 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_2494 = (g_list_2emap(v_t_2493, v_es_2484));
    return heff_tag_n(TAG_RPrim, 2, (V[]){v_t_2492, v_t_2494});
  }
  case TAG_RLam: {
    V v_xs_2495 = heff_field(v_x2_241, 0);
    V v_fv_2496 = heff_field(v_x2_241, 1);
    V v_held_2497 = heff_field(v_x2_241, 2);
    V v_body_2498 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24RLam = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_t_2499 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_24100 = (g_list_2emap(v_t_2499, v_held_2497));
    return heff_tag_at_n(v_ru_24x2_241_24RLam, TAG_RLam, 4, (V[]){v_xs_2495, v_fv_2496, v_t_24100, v_body_2498});
  }
  case TAG_RCall: {
    V v_g_24101 = heff_field(v_x2_241, 0);
    V v_tr_24102 = heff_field(v_x2_241, 1);
    V v_w_24103 = heff_field(v_x2_241, 2);
    V v_args_24104 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24RCall = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_f_24105 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_24116 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eowned_2eownExp_lam1, 1, 1, (V[]){v_f_24105}), v_args_24104));
    return heff_tag_at_n(v_ru_24x2_241_24RCall, TAG_RCall, 4, (V[]){v_g_24101, v_tr_24102, v_w_24103, v_t_24116});
  }
  case TAG_RApply: {
    V v_f_24117 = heff_field(v_x2_241, 0);
    V v_es_24118 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RApply = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_24119 = (g_heff_2ecompile_2eowned_2eownExp(heff_dup(v_us_240), v_f_24117));
    V v_t_24120 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_24121 = (g_list_2emap(v_t_24120, v_es_24118));
    return heff_tag_at_n(v_ru_24x2_241_24RApply, TAG_RApply, 2, (V[]){v_t_24119, v_t_24121});
  }
  case TAG_RBool: {
    V v_c_24122 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24RBool = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_24123 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_24124 = (g_heff_2ecompile_2eowned_2emapCond(v_t_24123, v_c_24122));
    return heff_tag_at_n(v_ru_24x2_241_24RBool, TAG_RBool, 1, (V[]){v_t_24124});
  }
  case TAG_RAbandon: {
    heff_drop(v_us_240);
    return v_x2_241;
  }
  case TAG_RBox: {
    V v_r_24125 = heff_field(v_x2_241, 0);
    V v_e_24126 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RBox = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_24127 = heff_tag_at_n(v_ru_24x2_241_24RBox, TAG_RBox, 2, (V[]){v_r_24125, heff_hole()});
    V v_u_24128 = (g_heff_2ecompile_2eowned_2eownExp_24dps(v_us_240, v_e_24126, heff_dup(v_cell_24127), MK_INT(1LL)));
    heff_drop(v_u_24128);
    return v_cell_24127;
  }
  case TAG_RUnbox: {
    V v_r_24129 = heff_field(v_x2_241, 0);
    V v_e_24130 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RUnbox = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_24131 = heff_tag_at_n(v_ru_24x2_241_24RUnbox, TAG_RUnbox, 2, (V[]){v_r_24129, heff_hole()});
    V v_u_24132 = (g_heff_2ecompile_2eowned_2eownExp_24dps(v_us_240, v_e_24130, heff_dup(v_cell_24131), MK_INT(1LL)));
    heff_drop(v_u_24132);
    return v_cell_24131;
  }
  case TAG_RPeek: {
    V v_r_24133 = heff_field(v_x2_241, 0);
    V v_e_24134 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RPeek = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_24135 = heff_tag_at_n(v_ru_24x2_241_24RPeek, TAG_RPeek, 2, (V[]){v_r_24133, heff_hole()});
    V v_u_24136 = (g_heff_2ecompile_2eowned_2eownExp_24dps(v_us_240, v_e_24134, heff_dup(v_cell_24135), MK_INT(1LL)));
    heff_drop(v_u_24136);
    return v_cell_24135;
  }
  case TAG_RPrimU: {
    V v_p_24137 = heff_field(v_x2_241, 0);
    V v_es_24138 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RPrimU = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_24139 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_24140 = (g_list_2emap(v_t_24139, v_es_24138));
    return heff_tag_at_n(v_ru_24x2_241_24RPrimU, TAG_RPrimU, 2, (V[]){v_p_24137, v_t_24140});
  }
  case TAG_RPrimAt: {
    V v_p_24141 = heff_field(v_x2_241, 0);
    V v_r_24142 = heff_field(v_x2_241, 1);
    V v_es_24143 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24RPrimAt = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_24151;
    if (heff_strEq_c_lent(v_p_24141, ((V)&g_heff_2ecompile_2eowned_2eownExp_str2), 2)) {
      HeffT2 v_t_24145 = (g_heff_2ecompile_2eowned_2eheldOf_24cpr(heff_tag_n(TAG_RPrim, 2, (V[]){heff_dup(v_p_24141), heff_dup(v_es_24143)})));
      {
        V v_field_24147 = v_t_24145.f[1];
        int64_t v_tag_24146 = ((int64_t)v_t_24145.f[0]);
        if ((v_tag_24146 == ((int64_t)0ULL))) {
          V v_x_24149 = v_field_24147;
          V v_t_24150 = ({ V a_0 = v_x_24149; V a_1 = v_us_240; V r_ = (g_heff_2ecompile_2eowned_2eelemS(a_0, a_1)); heff_drop(v_x_24149); r_; });
          if ((heff_dup(v_t_24150) == NTAG(TAG_True))) {
            heff_drop(v_p_24141);
            heff_drop(v_t_24150);
            v_t_24151 = ((V)&g_heff_2ecompile_2eowned_2eownExp_str3);
          } else {
            heff_drop(v_t_24150);
            v_t_24151 = v_p_24141;
          }
        } else {
          heff_drop(v_field_24147);
          v_t_24151 = v_p_24141;
        }
      }
    } else {
      v_t_24151 = v_p_24141;
    }
    V v_t_24152 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_24153 = (g_list_2emap(v_t_24152, v_es_24143));
    return heff_tag_at_n(v_ru_24x2_241_24RPrimAt, TAG_RPrimAt, 3, (V[]){v_t_24151, v_r_24142, v_t_24153});
  }
  case TAG_RFixU: {
    heff_drop(v_us_240);
    return v_x2_241;
  }
  case TAG_RF32U: {
    heff_drop(v_us_240);
    return v_x2_241;
  }
  case TAG_RF64U: {
    heff_drop(v_us_240);
    return v_x2_241;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eowned_2eownExp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2eownExp(a[0], a[1]);
}
V g_heff_2ecompile_2eowned_2eownExp_lam0(V self, V *args) {
  V v_p_2440 = args[0];
  V v_us_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2443;
  switch (heff_tag_of(v_p_2440)) {
  case TAG_MkPair: {
    V v_x_2441 = heff_dup(heff_field(v_p_2440, 0));
    v_t_2443 = v_x_2441;
    break;
  }
  default: heff_nomatch(v_p_2440);
  }
  V v_t_2446;
  switch (heff_tag_of(v_p_2440)) {
  case TAG_MkPair: {
    V v_y_2445 = heff_field(v_p_2440, 1);
    heff_take_n(v_p_2440, 2ULL, 2);
    v_t_2446 = v_y_2445;
    break;
  }
  default: heff_nomatch(v_p_2440);
  }
  V v_t_2447 = (g_heff_2ecompile_2eowned_2eownExp(v_us_240, v_t_2446));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2443, v_t_2447});
}
V g_heff_2ecompile_2eowned_2eownExp_lam1(V self, V *args) {
  V v_a_24106 = args[0];
  V v_f_24105 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_24106)) {
  case TAG_Given: {
    V v_e_24107 = heff_field(v_a_24106, 0);
    V v_ru_24a_24106_24Given = heff_take_reuse_n(v_a_24106, 1ULL, 1);
    V v_t_24108 = heff_tr(heff_call(v_f_24105, 1, (V[]){v_e_24107}));
    return heff_tag_at_n(v_ru_24a_24106_24Given, TAG_Given, 1, (V[]){v_t_24108});
  }
  case TAG_GivenU: {
    V v_r_24109 = heff_field(v_a_24106, 0);
    V v_e_24110 = heff_field(v_a_24106, 1);
    V v_ru_24a_24106_24GivenU = heff_take_reuse_n(v_a_24106, 3ULL, 2);
    V v_t_24111 = heff_tr(heff_call(v_f_24105, 1, (V[]){v_e_24110}));
    return heff_tag_at_n(v_ru_24a_24106_24GivenU, TAG_GivenU, 2, (V[]){v_r_24109, v_t_24111});
  }
  case TAG_LentVar: {
    heff_drop(v_f_24105);
    return v_a_24106;
  }
  case TAG_LentValue: {
    V v_e_24114 = heff_field(v_a_24106, 0);
    V v_ru_24a_24106_24LentValue = heff_take_reuse_n(v_a_24106, 1ULL, 1);
    V v_t_24115 = heff_tr(heff_call(v_f_24105, 1, (V[]){v_e_24114}));
    return heff_tag_at_n(v_ru_24a_24106_24LentValue, TAG_LentValue, 1, (V[]){v_t_24115});
  }
  default: return heff_nomatch(v_a_24106);
  }
}
HEFF_LIT(g_heff_2ecompile_2eowned_2eownCheck_str0, 8, "arrayOwn");
HEFF_LIT(g_heff_2ecompile_2eowned_2eownCheck_str1, 8, "arrayOwn");
HEFF_LIT(g_heff_2ecompile_2eowned_2eownCheck_str2, 8, "arrayOwn");
HEFF_LIT(g_heff_2ecompile_2eowned_2eownCheck_str3, 8, "arrayOwn");
Clo g_heff_2ecompile_2eowned_2eownCheck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2eownCheck_entry, 2, 0};

V g_heff_2ecompile_2eowned_2eownCheck(V v_x_240, V v_r_241) {
top: ;
  switch (heff_tag_of(v_r_241)) {
  case TAG_RepV: {
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){heff_dup(v_x_240)}), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_CSet, 2, (V[]){v_x_240, heff_tag_n(TAG_RPrim, 2, (V[]){((V)&g_heff_2ecompile_2eowned_2eownCheck_str0), v_t_242})});
  }
  case TAG_RepFix: {
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){heff_dup(v_x_240)}), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_CSet, 2, (V[]){v_x_240, heff_tag_n(TAG_RPrimAt, 3, (V[]){((V)&g_heff_2ecompile_2eowned_2eownCheck_str1), v_r_241, v_t_244})});
  }
  case TAG_RepF64: {
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){heff_dup(v_x_240)}), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_CSet, 2, (V[]){v_x_240, heff_tag_n(TAG_RPrimAt, 3, (V[]){((V)&g_heff_2ecompile_2eowned_2eownCheck_str2), v_r_241, v_t_245})});
  }
  case TAG_RepInt: {
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){heff_dup(v_x_240)}), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_CSet, 2, (V[]){v_x_240, heff_tag_n(TAG_RPrimAt, 3, (V[]){((V)&g_heff_2ecompile_2eowned_2eownCheck_str3), v_r_241, v_t_246})});
  }
  default: return heff_nomatch(v_r_241);
  }
}
V g_heff_2ecompile_2eowned_2eownCheck_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2eownCheck(a[0], a[1]);
}
Clo g_heff_2ecompile_2eowned_2eownedAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2eownedAt_entry, 2, 0};

V g_heff_2ecompile_2eowned_2eownedAt(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_j_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_f_240, 5), v_x_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_246;
        switch (heff_tag_of(v_x_248)) {
        case TAG_RepV: {
          V v_x1_249 = (g_heff_2ecompile_2erefcount_2eelemI(heff_dup(v_j_243), heff_rfield(v_f_240, 2)));
          if ((heff_dup(v_x1_249) == NTAG(TAG_True))) {
            heff_drop(v_x_242);
            heff_drop(v_j_243);
            heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
            heff_drop(v_x1_249);
            return v_f_240;
          } else {
            heff_drop(v_x1_249);
            V v_t_2410 = (g_list_2efoldl_24s490001784x345683100(NTAG(TAG_Nil), heff_rfield(v_f_240, 4)));
            V v_t_2411 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_x_242), NTAG(TAG_Nil)});
            V v_t_2412 = (g_heff_2ecompile_2eowned_2echain(v_t_2410, v_t_2411));
            return (g_heff_2ecompile_2eowned_2eownedChain(v_f_240, v_j_243, v_x_242, v_t_2412));
          }
        }
        case TAG_RepFix: {
          heff_take_n(v_x_248, 0ULL, 1);
          heff_drop(v_x_242);
          heff_drop(v_j_243);
          heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
          return v_f_240;
        }
        case TAG_RepF64: {
          heff_drop(v_x_242);
          heff_drop(v_j_243);
          heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
          return v_f_240;
        }
        case TAG_RepInt: {
          heff_drop(v_x_242);
          heff_drop(v_j_243);
          heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
          return v_f_240;
        }
        default: return heff_nomatch(v_x_248);
        }
      } else {
        heff_drop(v_field_246);
        V v_x1_2414 = (g_heff_2ecompile_2erefcount_2eelemI(heff_dup(v_j_243), heff_rfield(v_f_240, 2)));
        if ((heff_dup(v_x1_2414) == NTAG(TAG_True))) {
          heff_drop(v_x_242);
          heff_drop(v_j_243);
          heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
          heff_drop(v_x1_2414);
          return v_f_240;
        } else {
          heff_drop(v_x1_2414);
          V v_t_2415 = (g_list_2efoldl_24s490001784x345683100(NTAG(TAG_Nil), heff_rfield(v_f_240, 4)));
          V v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_x_242), NTAG(TAG_Nil)});
          V v_t_2417 = (g_heff_2ecompile_2eowned_2echain(v_t_2415, v_t_2416));
          return (g_heff_2ecompile_2eowned_2eownedChain(v_f_240, v_j_243, v_x_242, v_t_2417));
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eowned_2eownedAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2eownedAt(a[0], a[1]);
}
Clo g_heff_2ecompile_2eowned_2eownedDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2eownedDef_entry, 1, 0};

V g_heff_2ecompile_2eowned_2eownedDef(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DFun: {
    V v_f_241 = heff_field(v_d_240, 0);
    V v_ru_24d_240_24DFun = heff_take_reuse_n(v_d_240, 1ULL, 1);
    V v_t_242 = (g_list_2efoldl_24s598828199x820230131(NTAG(TAG_False), heff_rfield(v_f_241, 4)));
    V v_t_246;
    if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
      heff_drop(v_t_242);
      V v_t_243 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 1)));
      V v_t_244 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_243, MK_INT(1LL))));
      V v_t_245 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(heff_rfield(v_f_241, 1)), v_t_244));
      v_t_246 = ({ V a_0 = v_f_241; V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s1061624263x1097104198(a_0, a_1)); heff_drop(v_t_245); r_; });
    } else {
      heff_drop(v_t_242);
      v_t_246 = v_f_241;
    }
    return heff_tag_at_n(v_ru_24d_240_24DFun, TAG_DFun, 1, (V[]){v_t_246});
  }
  case TAG_DVal: {
    return v_d_240;
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2ecompile_2eowned_2eownedDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2eownedDef(a[0]);
}
Clo g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_entry, 1, 0};

V g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_CondTrue: {
    return v_x2_240;
  }
  case TAG_CondFalse: {
    return v_x2_240;
  }
  case TAG_CondRel: {
    V v_p_241 = heff_field(v_x2_240, 0);
    V v_es_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24CondRel = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_list_2emap_24s1354671438x1264137843(v_es_242));
    return heff_tag_at_n(v_ru_24x2_240_24CondRel, TAG_CondRel, 2, (V[]){v_p_241, v_t_243});
  }
  case TAG_CondRelU: {
    V v_p_244 = heff_field(v_x2_240, 0);
    V v_es_245 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24CondRelU = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246 = (g_list_2emap_24s1354671438x1264137843(v_es_245));
    return heff_tag_at_n(v_ru_24x2_240_24CondRelU, TAG_CondRelU, 2, (V[]){v_p_244, v_t_246});
  }
  case TAG_CondBool: {
    V v_e_247 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24CondBool = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_248 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_247));
    return heff_tag_at_n(v_ru_24x2_240_24CondBool, TAG_CondBool, 1, (V[]){v_t_248});
  }
  case TAG_CondNot: {
    V v_c_249 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24CondNot = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24CondNot, TAG_CondNot, 1, (V[]){heff_hole()});
    V v_u_2411 = (g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_24dps(v_c_249, heff_dup(v_cell_2410), MK_INT(0LL)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  case TAG_CondIf: {
    V v_a_2412 = heff_field(v_x2_240, 0);
    V v_b_2413 = heff_field(v_x2_240, 1);
    V v_c_2414 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24CondIf = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_2415 = (g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405(v_a_2412));
    V v_t_2416 = (g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405(v_b_2413));
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_240_24CondIf, TAG_CondIf, 3, (V[]){v_t_2415, v_t_2416, heff_hole()});
    V v_u_2418 = (g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_24dps(v_c_2414, heff_dup(v_cell_2417), MK_INT(2LL)));
    heff_drop(v_u_2418);
    return v_cell_2417;
  }
  case TAG_CondLet: {
    V v_x_2419 = heff_field(v_x2_240, 0);
    V v_e_2420 = heff_field(v_x2_240, 1);
    V v_c_2421 = heff_field(v_x2_240, 2);
    V v_ds_2422 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24CondLet = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2423 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_2420));
    V v_t_2424 = (g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405(v_c_2421));
    return heff_tag_at_n(v_ru_24x2_240_24CondLet, TAG_CondLet, 4, (V[]){v_x_2419, v_t_2423, v_t_2424, v_ds_2422});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405(a[0]);
}
Clo g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_24dps_entry, 3, 0};

V g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_24dps(V v_x2_240, V v_d_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_CondTrue: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_CondFalse: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_CondRel: {
    V v_p_243 = heff_field(v_x2_240, 0);
    V v_es_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_245 = (g_list_2emap_24s391650521x1406868658(v_es_244));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_CondRel, 2, (V[]){v_p_243, v_t_245}));
  }
  case TAG_CondRelU: {
    V v_p_246 = heff_field(v_x2_240, 0);
    V v_es_247 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_248 = (g_list_2emap_24s391650521x1406868658(v_es_247));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_CondRelU, 2, (V[]){v_p_246, v_t_248}));
  }
  case TAG_CondBool: {
    V v_e_249 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2410 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_e_249));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_CondBool, 1, (V[]){v_t_2410}));
  }
  case TAG_CondNot: {
    V v_c_2411 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24CondNot = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24CondNot, TAG_CondNot, 1, (V[]){heff_hole()});
    V v_u_2413 = heff_setField(v_d_241, v_i_242, heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_c_2411;
    V t_1 = v_cell_2412;
    V t_2 = MK_INT(0LL);
    v_x2_240 = t_0;
    v_d_241 = t_1;
    v_i_242 = t_2;
    goto top;
  }
  case TAG_CondIf: {
    V v_a_2414 = heff_field(v_x2_240, 0);
    V v_b_2415 = heff_field(v_x2_240, 1);
    V v_c_2416 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24CondIf = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_2417 = (g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837(v_a_2414));
    V v_t_2418 = (g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837(v_b_2415));
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_240_24CondIf, TAG_CondIf, 3, (V[]){v_t_2417, v_t_2418, heff_hole()});
    V v_u_2420 = heff_setField(v_d_241, v_i_242, heff_dup(v_cell_2419));
    heff_drop(v_u_2420);
    V t_0 = v_c_2416;
    V t_1 = v_cell_2419;
    V t_2 = MK_INT(2LL);
    v_x2_240 = t_0;
    v_d_241 = t_1;
    v_i_242 = t_2;
    goto top;
  }
  case TAG_CondLet: {
    V v_x_2421 = heff_field(v_x2_240, 0);
    V v_e_2422 = heff_field(v_x2_240, 1);
    V v_c_2423 = heff_field(v_x2_240, 2);
    V v_ds_2424 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_t_2425 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_e_2422));
    V v_t_2426 = (g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837(v_c_2423));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_CondLet, 4, (V[]){v_x_2421, v_t_2425, v_t_2426, v_ds_2424}));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_24dps(a[0], a[1], a[2]);
}