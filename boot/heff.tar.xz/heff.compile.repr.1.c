// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Binds 36386
#define TAG_Boxed 28180
#define TAG_BoxedWord 41718
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_Element 14172
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_IAny 21222
#define TAG_IBind 27068
#define TAG_ICond 62625
#define TAG_IOp 20150
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_Kept 49931
#define TAG_Literal 34173
#define TAG_Merge 54398
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_MkDef 57825
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_Often 32846
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_Pinned 8573
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_RetAs 20415
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Unboxed 46787
#define TAG_Wants 58903
#define LBL_args 9498020
#define LBL_big 307066
#define LBL_boxedIn 304670893
#define LBL_boxedOut 854869195
#define LBL_fixed 298804110
#define LBL_flat 9641024
#define LBL_kept 9783717
#define LBL_op 10312
#define LBL_params 951713969
#define LBL_pinned 958995203
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_sigs 10025609
#define LBL_unboxedIn 1261597312
#define LBL_unboxedOut 454817126
static uint32_t shape_args__result[] = {LBL_args, LBL_result};
static uint32_t shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big[] = {LBL_reprs, LBL_boxedIn, LBL_unboxedIn, LBL_boxedOut, LBL_unboxedOut, LBL_pinned, LBL_kept, LBL_big};
V g_heff_2ecompile_2eranges_2ewordPrims_get(void);
V g_heff_2ecompile_2erepr_2easTheyCome(V);
V g_heff_2ecompile_2erepr_2easTheyCome_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2easTheyCome_clo;
V g_heff_2ecompile_2erepr_2easWord(V, V);
V g_heff_2ecompile_2erepr_2easWord_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2easWord_clo;
V g_heff_2ecompile_2erepr_2easWord_24dps(V, V, V);
V g_heff_2ecompile_2erepr_2easWord_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2easWord_24dps_clo;
V g_heff_2ecompile_2erepr_2edecideOf(V, V);
V g_heff_2ecompile_2erepr_2edecideOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edecideOf_clo;
V g_heff_2ecompile_2erepr_2edecidedIn(V, V, V);
V g_heff_2ecompile_2erepr_2edecidedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edecidedIn_clo;
V g_heff_2ecompile_2erepr_2edefEvents(V, V);
V g_heff_2ecompile_2erepr_2edefEvents_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edefEvents_clo;
V g_heff_2ecompile_2erepr_2eelemS(V, V);
V g_heff_2ecompile_2erepr_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eelemS_clo;
V g_heff_2ecompile_2erepr_2eentered(V, V);
V g_heff_2ecompile_2erepr_2eentered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eentered_clo;
V g_heff_2ecompile_2erepr_2eeventName(V);
V g_heff_2ecompile_2erepr_2eeventName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eeventName_clo;
V g_heff_2ecompile_2erepr_2efloat1Prims_get(void);
V g_heff_2ecompile_2erepr_2efloat2Prims_get(void);
V g_heff_2ecompile_2erepr_2efloatRelPrims_get(void);
HeffT2 g_heff_2ecompile_2erepr_2efloatShape_24cpr(V);
V g_heff_2ecompile_2erepr_2efreeGo(V, V, V);
V g_heff_2ecompile_2erepr_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2efreeGo_clo;
V g_heff_2ecompile_2erepr_2eindexOfL(V, V, V);
V g_heff_2ecompile_2erepr_2eindexOfL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eindexOfL_clo;
V g_heff_2ecompile_2erepr_2ekeptOne(V, V, V, V);
V g_heff_2ecompile_2erepr_2ekeptOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ekeptOne_clo;
V g_heff_2ecompile_2erepr_2eloops(V);
V g_heff_2ecompile_2erepr_2eloops_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eloops_clo;
V g_heff_2ecompile_2erepr_2emayBeFlat(V);
V g_heff_2ecompile_2erepr_2emayBeFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2emayBeFlat_clo;
V g_heff_2ecompile_2erepr_2enoStats_get(void);
HeffT2 g_heff_2ecompile_2erepr_2eopShape_24cpr(V, V);
V g_heff_2ecompile_2erepr_2epinFields(V, V, V);
V g_heff_2ecompile_2erepr_2epinFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2epinFields_clo;
HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V);
V g_heff_2ecompile_2erepr_2epushPrim(V, V, V);
V g_heff_2ecompile_2erepr_2epushPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2epushPrim_clo;
V g_heff_2ecompile_2erepr_2ereadRepr(V, V);
V g_heff_2ecompile_2erepr_2ereadRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereadRepr_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2erepr_2ereprsEq(V, V);
V g_heff_2ecompile_2erepr_2ereprsEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprsEq_clo;
V g_heff_2ecompile_2erepr_2ereprsWords(V, V, V);
V g_heff_2ecompile_2erepr_2ereprsWords_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprsWords_clo;
V g_heff_2ecompile_2erepr_2eretName_get(void);
V g_heff_2ecompile_2erepr_2ereturned(V, V, V);
V g_heff_2ecompile_2erepr_2ereturned_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereturned_clo;
V g_heff_2ecompile_2erepr_2erootFrom(V, V, V);
V g_heff_2ecompile_2erepr_2erootFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2erootFrom_clo;
V g_heff_2ecompile_2erepr_2eseen(V, V);
V g_heff_2ecompile_2erepr_2eseen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eseen_clo;
V g_heff_2ecompile_2erepr_2eslotRepr(V, V);
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eslotRepr_clo;
V g_heff_2ecompile_2erepr_2esourceOf(V, V);
V g_heff_2ecompile_2erepr_2esourceOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2esourceOf_clo;
V g_heff_2ecompile_2erepr_2estatsOf(V, V);
V g_heff_2ecompile_2erepr_2estatsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2estatsOf_clo;
V g_heff_2ecompile_2erepr_2estatsWith(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erepr_2estatsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2estatsWith_clo;
V g_heff_2ecompile_2erepr_2estepGives(V, V, V, V);
V g_heff_2ecompile_2erepr_2estepGives_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2estepGives_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_heff_2ecompile_2erepr_2eunpinOne(V, V);
V g_heff_2ecompile_2erepr_2eunpinOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eunpinOne_clo;
V g_heff_2ecompile_2erepr_2ewalk(V, V, V, V);
V g_heff_2ecompile_2erepr_2ewalk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ewalk_clo;
V g_heff_2ecompile_2erepr_2ewithRepr(V, V);
V g_heff_2ecompile_2erepr_2ewithRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ewithRepr_clo;
V g_heff_2ecompile_2erepr_2ewordParams(V, V);
V g_heff_2ecompile_2erepr_2ewordParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ewordParams_clo;
HeffT2 g_heff_2ecompile_2erepr_2ewordShape_24cpr(V);
HeffT2 g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(V);
V g_list_2eany_24s100684943x1504448948(V, V);
V g_list_2eany_24s100684943x1504448948_entry(V self, V *a);
extern Clo g_list_2eany_24s100684943x1504448948_clo;
V g_list_2eany_24s1080008383x1763122651(V, V);
V g_list_2eany_24s1080008383x1763122651_entry(V self, V *a);
extern Clo g_list_2eany_24s1080008383x1763122651_clo;
V g_list_2eany_24s120814613x1439363162(V, V);
V g_list_2eany_24s120814613x1439363162_entry(V self, V *a);
extern Clo g_list_2eany_24s120814613x1439363162_clo;
V g_list_2eany_24s1230506745x754542351(V, V);
V g_list_2eany_24s1230506745x754542351_entry(V self, V *a);
extern Clo g_list_2eany_24s1230506745x754542351_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f155552269x628597815(V, V, V);
V g_list_2efoldl_24f155552269x628597815_entry(V self, V *a);
extern Clo g_list_2efoldl_24f155552269x628597815_clo;
V g_list_2efoldl_24f488322910x556193579(V, V, V);
V g_list_2efoldl_24f488322910x556193579_entry(V self, V *a);
extern Clo g_list_2efoldl_24f488322910x556193579_clo;
V g_list_2efoldl_24s1104809983x118204267(V, V);
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1104809983x118204267_clo;
V g_list_2efoldl_24s1134919403x2060330530(V, V);
V g_list_2efoldl_24s1134919403x2060330530_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1134919403x2060330530_clo;
V g_list_2efoldl_24s1275727578x1654209034(V, V);
V g_list_2efoldl_24s1275727578x1654209034_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1275727578x1654209034_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1674844076x2137676876(V, V, V, V);
V g_list_2efoldl_24s1674844076x2137676876_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1674844076x2137676876_clo;
V g_list_2efoldl_24s1690891682x1517899652(V, V);
V g_list_2efoldl_24s1690891682x1517899652_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1690891682x1517899652_clo;
V g_list_2efoldl_24s1694506840x958926808(V, V);
V g_list_2efoldl_24s1694506840x958926808_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1694506840x958926808_clo;
V g_list_2efoldl_24s1817528582x392224400(V, V, V);
V g_list_2efoldl_24s1817528582x392224400_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1817528582x392224400_clo;
V g_list_2efoldl_24s1923327646x248110754(V, V);
V g_list_2efoldl_24s1923327646x248110754_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923327646x248110754_clo;
V g_list_2efoldl_24s1923368998x1291788787(V, V);
V g_list_2efoldl_24s1923368998x1291788787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923368998x1291788787_clo;
V g_list_2efoldl_24s2096135476x728523350(V, V);
V g_list_2efoldl_24s2096135476x728523350_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2096135476x728523350_clo;
V g_list_2efoldl_24s2145639387x28888241(V, V, V, V);
V g_list_2efoldl_24s2145639387x28888241_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2145639387x28888241_clo;
V g_list_2efoldl_24s348204425x880103432(V, V);
V g_list_2efoldl_24s348204425x880103432_entry(V self, V *a);
extern Clo g_list_2efoldl_24s348204425x880103432_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s728686882x2096535788(V, V, V);
V g_list_2efoldl_24s728686882x2096535788_entry(V self, V *a);
extern Clo g_list_2efoldl_24s728686882x2096535788_clo;
V g_list_2efoldl_24s964765707x1396946999(V, V);
V g_list_2efoldl_24s964765707x1396946999_entry(V self, V *a);
extern Clo g_list_2efoldl_24s964765707x1396946999_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1598879313x231311047(V);
V g_list_2emap_24s1598879313x231311047_entry(V self, V *a);
extern Clo g_list_2emap_24s1598879313x231311047_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1713677103x1107896282(V, V);
V g_list_2ezipWith_24s1713677103x1107896282_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1713677103x1107896282_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
Clo g_heff_2ecompile_2erepr_2ereprsEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereprsEq_entry, 2, 0};

V g_heff_2ecompile_2erepr_2ereprsEq(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_argv_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      V v_t_248 = (g_heff_2ecompile_2erepr_2ereprEq(v_a_244, v_b_246));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V t_0 = v_argv_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_248);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2ereprsEq_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2ereprsEq(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erepr_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2erepr_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2eelemS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2eelemS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str0, 8, "floatLog");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str1, 9, "floatAtan");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str2, 8, "floatExp");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str3, 9, "floatAsin");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str4, 9, "floatAcos");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str5, 8, "floatCos");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str6, 8, "floatTan");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str7, 9, "floatSqrt");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str8, 8, "floatSin");

static V g_heff_2ecompile_2erepr_2efloat1Prims_val;
static HEFF_ONCE g_heff_2ecompile_2erepr_2efloat1Prims_st;
static V g_heff_2ecompile_2erepr_2efloat1Prims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str6), v_t_242})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str8), v_t_243})});
}
V g_heff_2ecompile_2erepr_2efloat1Prims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erepr_2efloat1Prims_st)) return g_heff_2ecompile_2erepr_2efloat1Prims_val;
  return heff_global(&g_heff_2ecompile_2erepr_2efloat1Prims_val, &g_heff_2ecompile_2erepr_2efloat1Prims_st, g_heff_2ecompile_2erepr_2efloat1Prims_init);
}
HEFF_LIT(g_heff_2ecompile_2erepr_2efloatShape_24cpr_str0, 12, "floatFromInt");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloatShape_24cpr_str1, 10, "floatFloor");

HeffT2 g_heff_2ecompile_2erepr_2efloatShape_24cpr(V v_p_240) {
top: ;
  V v_t_241 = ({ V a_0 = v_p_240; V b_1 = heff_dup(g_heff_2ecompile_2erepr_2efloat2Prims_get()); V r_ = (g_heff_2ecompile_2erepr_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), v_t_242});
    V v_t_244 = heff_rec_n(2, shape_args__result, (V[]){v_t_243, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_244}});
  } else {
    heff_drop(v_t_241);
    V v_t_245 = ({ V a_0 = v_p_240; V b_1 = heff_dup(g_heff_2ecompile_2erepr_2efloat1Prims_get()); V r_ = (g_heff_2ecompile_2erepr_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
      V v_t_247 = heff_rec_n(2, shape_args__result, (V[]){v_t_246, NTAG(TAG_RepF64)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_247}});
    } else {
      heff_drop(v_t_245);
      V v_t_248 = ({ V a_0 = v_p_240; V b_1 = heff_dup(g_heff_2ecompile_2erepr_2efloatRelPrims_get()); V r_ = (g_heff_2ecompile_2erepr_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), v_t_249});
        V v_t_2411 = heff_rec_n(2, shape_args__result, (V[]){v_t_2410, NTAG(TAG_RepV)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2411}});
      } else {
        heff_drop(v_t_248);
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2erepr_2efloatShape_24cpr_str0), 2)) {
          V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepV), NTAG(TAG_Nil)});
          V v_t_2414 = heff_rec_n(2, shape_args__result, (V[]){v_t_2413, NTAG(TAG_RepF64)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2414}});
        } else {
          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2erepr_2efloatShape_24cpr_str1), 2)) {
            V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
            V v_t_2417 = heff_rec_n(2, shape_args__result, (V[]){v_t_2416, NTAG(TAG_RepV)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2417}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2erepr_2ewordShape_24cpr_str0, 6, "wordEq");
HEFF_LIT(g_heff_2ecompile_2erepr_2ewordShape_24cpr_str1, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2erepr_2ewordShape_24cpr_str2, 6, "wordLe");
HEFF_LIT(g_heff_2ecompile_2erepr_2ewordShape_24cpr_str3, 11, "wordToFloat");

HeffT2 g_heff_2ecompile_2erepr_2ewordShape_24cpr(V v_p_240) {
top: ;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2erepr_2ewordShape_24cpr_str0), 2)) {
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), v_t_242});
    V v_t_244 = heff_rec_n(2, shape_args__result, (V[]){v_t_243, NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_244}});
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2erepr_2ewordShape_24cpr_str1), 2)) {
      V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), v_t_246});
      V v_t_248 = heff_rec_n(2, shape_args__result, (V[]){v_t_247, NTAG(TAG_RepV)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_248}});
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2erepr_2ewordShape_24cpr_str2), 2)) {
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), v_t_2410});
        V v_t_2412 = heff_rec_n(2, shape_args__result, (V[]){v_t_2411, NTAG(TAG_RepV)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2412}});
      } else {
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2erepr_2ewordShape_24cpr_str3), 2)) {
          V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
          V v_t_2415 = heff_rec_n(2, shape_args__result, (V[]){v_t_2414, NTAG(TAG_RepF64)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2415}});
        } else {
          V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
          V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), v_t_2416});
          V v_t_2418 = heff_rec_n(2, shape_args__result, (V[]){v_t_2417, NTAG(TAG_RepInt)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2418}});
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2erepr_2eprimShape_24cpr_str0, 4, "word");

HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V v_p_240) {
top: ;
  if ((((int64_t)4ULL) < heff_unbox_word(heff_strLength_lent(v_p_240, 0)))) {
    if (heff_strEq_c(heff_strSlice_lent(v_p_240, MK_INT(0LL), MK_INT(4LL), 6), ((V)&g_heff_2ecompile_2erepr_2eprimShape_24cpr_str0))) {
      V v_t_243 = ({ V a_0 = v_p_240; V b_1 = heff_dup(g_heff_2ecompile_2eranges_2ewordPrims_get()); V r_ = (g_list_2eany_24s1230506745x754542351(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
        heff_drop(v_t_243);
        HEFF_LAST return g_heff_2ecompile_2erepr_2ewordShape_24cpr(v_p_240);
      } else {
        heff_drop(v_t_243);
        HeffT2 v_t_244 = (g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(v_p_240));
        {
          V v_field_246 = v_t_244.f[1];
          int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
          if ((v_tag_245 == ((int64_t)0ULL))) {
            V v_fp_248 = v_field_246;
            V v_t_249 = heff_tag_n(TAG_RepFix, 1, (V[]){heff_take_field(v_fp_248, 0)});
            return ({ V a_0 = v_t_249; V b_1 = heff_get_n(v_fp_248, 1, 2); HeffT2 r_ = (g_heff_2ecompile_2erepr_2eopShape_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
          } else {
            heff_drop(v_field_246);
            HEFF_LAST return g_heff_2ecompile_2erepr_2efloatShape_24cpr(v_p_240);
          }
        }
      }
    } else {
      HeffT2 v_t_2410 = (g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(v_p_240));
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_fp_2414 = v_field_2412;
          V v_t_2415 = heff_tag_n(TAG_RepFix, 1, (V[]){heff_take_field(v_fp_2414, 0)});
          return ({ V a_0 = v_t_2415; V b_1 = heff_get_n(v_fp_2414, 1, 2); HeffT2 r_ = (g_heff_2ecompile_2erepr_2eopShape_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
        } else {
          heff_drop(v_field_2412);
          HEFF_LAST return g_heff_2ecompile_2erepr_2efloatShape_24cpr(v_p_240);
        }
      }
    }
  } else {
    HeffT2 v_t_2416 = (g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(v_p_240));
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        V v_fp_2420 = v_field_2418;
        V v_t_2421 = heff_tag_n(TAG_RepFix, 1, (V[]){heff_take_field(v_fp_2420, 0)});
        return ({ V a_0 = v_t_2421; V b_1 = heff_get_n(v_fp_2420, 1, 2); HeffT2 r_ = (g_heff_2ecompile_2erepr_2eopShape_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      } else {
        heff_drop(v_field_2418);
        HEFF_LAST return g_heff_2ecompile_2erepr_2efloatShape_24cpr(v_p_240);
      }
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2erepr_2easTheyCome_str0, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2erepr_2easTheyCome_str1, 14, "arrayReplicate");
HEFF_LIT(g_heff_2ecompile_2erepr_2easTheyCome_str2, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2erepr_2easTheyCome_str3, 8, "arraySet");
Clo g_heff_2ecompile_2erepr_2easTheyCome_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2easTheyCome_entry, 1, 0};

V g_heff_2ecompile_2erepr_2easTheyCome(V v_p_240) {
top: ;
  V v_t_243;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2erepr_2easTheyCome_str0), 2)) {
    v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(2LL), NTAG(TAG_Nil)});
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2erepr_2easTheyCome_str1), 2)) {
      v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(1LL), NTAG(TAG_Nil)});
    } else {
      v_t_243 = NTAG(TAG_Nil);
    }
  }
  V v_t_246;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2erepr_2easTheyCome_str2), 2)) {
    v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(1LL), NTAG(TAG_Nil)});
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2erepr_2easTheyCome_str3), 2)) {
      v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(1LL), NTAG(TAG_Nil)});
    } else {
      v_t_246 = NTAG(TAG_Nil);
    }
  }
  return (g_prelude_2e_2b_2b(v_t_243, v_t_246));
}
V g_heff_2ecompile_2erepr_2easTheyCome_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2easTheyCome(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erepr_2emayBeFlat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2emayBeFlat_entry, 1, 0};

V g_heff_2ecompile_2erepr_2emayBeFlat(V v_t_240) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_FtFloat: {
    switch (heff_tag_of(v_t_240)) {
    case TAG_FtFloat: {
      return NTAG(TAG_True);
    }
    case TAG_FtFixed: {
      V v_w_241 = heff_field(v_t_240, 0);
      int64_t v_t_242;
      switch (heff_tag_of(v_w_241)) {
      case TAG_I8: {
        v_t_242 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_242 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_242 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_242 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_242 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_242 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_242 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_242 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_242 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_241);
      }
      V v_ret_24bool = heff_bool((v_t_242 == ((int64_t)64ULL)));
      return v_ret_24bool;
    }
    case TAG_FtOther: {
      return NTAG(TAG_False);
    }
    case TAG_FtAny: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_FtFixed: {
    switch (heff_tag_of(v_t_240)) {
    case TAG_FtFloat: {
      return NTAG(TAG_True);
    }
    case TAG_FtFixed: {
      V v_w_245 = heff_field(v_t_240, 0);
      int64_t v_t_246;
      switch (heff_tag_of(v_w_245)) {
      case TAG_I8: {
        v_t_246 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_246 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_246 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_246 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_246 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_246 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_246 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_246 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_246 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_245);
      }
      V v_ret_24bool = heff_bool((v_t_246 == ((int64_t)64ULL)));
      return v_ret_24bool;
    }
    case TAG_FtOther: {
      return NTAG(TAG_False);
    }
    case TAG_FtAny: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_FtOther: {
    switch (heff_tag_of(v_t_240)) {
    case TAG_FtFloat: {
      return NTAG(TAG_True);
    }
    case TAG_FtFixed: {
      V v_w_248 = heff_field(v_t_240, 0);
      int64_t v_t_249;
      switch (heff_tag_of(v_w_248)) {
      case TAG_I8: {
        v_t_249 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_249 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_249 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_249 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_249 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_249 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_249 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_249 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_249 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_248);
      }
      V v_ret_24bool = heff_bool((v_t_249 == ((int64_t)64ULL)));
      return v_ret_24bool;
    }
    case TAG_FtOther: {
      return NTAG(TAG_False);
    }
    case TAG_FtAny: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_FtAny: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_240);
  }
}
V g_heff_2ecompile_2erepr_2emayBeFlat_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2emayBeFlat(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erepr_2ereadRepr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereadRepr_entry, 2, 0};

V g_heff_2ecompile_2erepr_2ereadRepr(V v_x1_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_t_241);
    return NTAG(TAG_RepV);
  }
  case TAG_Just: {
    V v_i_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    if (heff_intLt_c(v_i_242, MK_INT(16LL))) {
      switch (heff_tag_of(v_t_241)) {
      case TAG_FtFloat: {
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        return NTAG(TAG_RepF64);
      }
      case TAG_FtFixed: {
        V v_w_244 = heff_field(v_t_241, 0);
        heff_take_n(v_t_241, 1ULL, 1);
        int64_t v_t_245;
        switch (heff_tag_of(v_w_244)) {
        case TAG_I8: {
          v_t_245 = ((int64_t)8ULL);
          break;
        }
        case TAG_I16: {
          v_t_245 = ((int64_t)16ULL);
          break;
        }
        case TAG_I32: {
          v_t_245 = ((int64_t)32ULL);
          break;
        }
        case TAG_I64: {
          v_t_245 = ((int64_t)64ULL);
          break;
        }
        case TAG_U8: {
          v_t_245 = ((int64_t)8ULL);
          break;
        }
        case TAG_U16: {
          v_t_245 = ((int64_t)16ULL);
          break;
        }
        case TAG_U32: {
          v_t_245 = ((int64_t)32ULL);
          break;
        }
        case TAG_U64: {
          v_t_245 = ((int64_t)64ULL);
          break;
        }
        case TAG_F32: {
          v_t_245 = ((int64_t)32ULL);
          break;
        }
        default: heff_nomatch(v_w_244);
        }
        if ((v_t_245 == ((int64_t)64ULL))) {
          return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_RepFix, 1, (V[]){v_w_244});
        } else {
          heff_drop_cell(v_ru_24x1_240_24Just, 1);
          heff_drop(v_w_244);
          return NTAG(TAG_RepV);
        }
      }
      case TAG_FtOther: {
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        return NTAG(TAG_RepV);
      }
      case TAG_FtAny: {
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        return NTAG(TAG_RepV);
      }
      default: return heff_nomatch(v_t_241);
      }
    } else {
      heff_drop(v_t_241);
      heff_drop_cell(v_ru_24x1_240_24Just, 1);
      return NTAG(TAG_RepV);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2ereadRepr_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ereadRepr(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2erepr_2eretName_str0, 4, "$ret");

static V g_heff_2ecompile_2erepr_2eretName_val;
static HEFF_ONCE g_heff_2ecompile_2erepr_2eretName_st;
static V g_heff_2ecompile_2erepr_2eretName_init(void) {
  return ((V)&g_heff_2ecompile_2erepr_2eretName_str0);
}
V g_heff_2ecompile_2erepr_2eretName_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erepr_2eretName_st)) return g_heff_2ecompile_2erepr_2eretName_val;
  return heff_global(&g_heff_2ecompile_2erepr_2eretName_val, &g_heff_2ecompile_2erepr_2eretName_st, g_heff_2ecompile_2erepr_2eretName_init);
}
Clo g_heff_2ecompile_2erepr_2esourceOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2esourceOf_entry, 2, 0};

V g_heff_2ecompile_2erepr_2esourceOf(V v_x_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_SVar: {
    V v_ru_24v_241_24SVar = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SVar, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SGlobal: {
    V v_ru_24v_241_24SGlobal = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SGlobal, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SInt: {
    V v_n_244 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SInt = heff_take_reuse_n(v_v_241, 1ULL, 1);
    if (heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_n_244, 1)) {
      if (heff_intLe_c(v_n_244, MK_INT(4611686018427387903LL))) {
        heff_drop_cell(v_ru_24v_241_24SInt, 1);
        return heff_tag_n(TAG_Literal, 2, (V[]){v_x_240, NTAG(TAG_RepInt)});
      } else {
        return heff_tag_at_n(v_ru_24v_241_24SInt, TAG_Boxed, 1, (V[]){v_x_240});
      }
    } else {
      heff_drop(v_n_244);
      return heff_tag_at_n(v_ru_24v_241_24SInt, TAG_Boxed, 1, (V[]){v_x_240});
    }
  }
  case TAG_SFloat: {
    heff_take_na(v_v_241, 0ULL, 1);
    return heff_tag_n(TAG_Literal, 2, (V[]){v_x_240, NTAG(TAG_RepF64)});
  }
  case TAG_SStr: {
    V v_ru_24v_241_24SStr = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SStr, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SBytes: {
    V v_ru_24v_241_24SBytes = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SBytes, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SFixed: {
    V v_w_2410 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SFixed = heff_take_reuse_n(v_v_241, 1ULL, 2);
    return heff_tag_at_n(v_ru_24v_241_24SFixed, TAG_Literal, 2, (V[]){v_x_240, heff_tag_n(TAG_RepFix, 1, (V[]){v_w_2410})});
  }
  case TAG_SFloat32: {
    V v_ru_24v_241_24SFloat32 = heff_take_reuse_na(v_v_241, 0ULL, 1);
    V v_t_2413 = heff_tag_at_n(v_ru_24v_241_24SFloat32, TAG_RepFix, 1, (V[]){NTAG(TAG_F32)});
    return heff_tag_n(TAG_Literal, 2, (V[]){v_x_240, v_t_2413});
  }
  case TAG_SPrimFn: {
    V v_ru_24v_241_24SPrimFn = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SPrimFn, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SLam: {
    heff_take_n(v_v_241, 0ULL, 2);
    return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_STag: {
    heff_take_n(v_v_241, 0ULL, 3);
    return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SRec: {
    heff_take_n(v_v_241, 0ULL, 2);
    return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SProj: {
    V v_l_2423 = heff_field(v_v_241, 1);
    V v_sh_2424 = heff_field(v_v_241, 2);
    V v_t_2425 = heff_field(v_v_241, 3);
    heff_take_n(v_v_241, 14ULL, 4);
    V v_t_2426 = ({ V a_0 = v_l_2423; V a_1 = MK_INT(0LL); V a_2 = v_sh_2424; V r_ = (g_heff_2ecompile_2erepr_2eindexOfL(a_0, a_1, a_2)); heff_drop(v_l_2423); heff_drop(v_sh_2424); r_; });
    V v_r_2427 = (g_heff_2ecompile_2erepr_2ereadRepr(v_t_2426, v_t_2425));
    switch (heff_tag_of(v_r_2427)) {
    case TAG_RepV: {
      return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
    }
    case TAG_RepFix: {
      return heff_tag_n(TAG_Unboxed, 2, (V[]){v_x_240, v_r_2427});
    }
    case TAG_RepF64: {
      return heff_tag_n(TAG_Unboxed, 2, (V[]){v_x_240, v_r_2427});
    }
    case TAG_RepInt: {
      return heff_tag_n(TAG_Unboxed, 2, (V[]){v_x_240, v_r_2427});
    }
    default: return heff_nomatch(v_r_2427);
    }
  }
  case TAG_SPrim: {
    V v_p_2429 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SPrim = heff_take_reuse_n(v_v_241, 1ULL, 2);
    HeffT2 v_t_2431 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_2429));
    {
      V v_field_2433 = v_t_2431.f[1];
      int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
      if ((v_tag_2432 == ((int64_t)0ULL))) {
        V v_s_2435 = v_field_2433;
        V v_t_2436 = heff_get_n(v_s_2435, 1, 2);
        switch (heff_tag_of(v_t_2436)) {
        case TAG_RepV: {
          heff_drop(v_p_2429);
          heff_drop_cell(v_ru_24v_241_24SPrim, 2);
          return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
        }
        case TAG_RepFix: {
          heff_take_n(v_t_2436, 0ULL, 1);
          HeffT2 v_t_2438 = ({ V a_0 = v_p_2429; HeffT2 r_ = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(a_0)); heff_drop(v_p_2429); r_; });
          V v_t_2443;
          {
            V v_field_2440 = v_t_2438.f[1];
            int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
            if ((v_tag_2439 == ((int64_t)0ULL))) {
              V v_s_2442 = v_field_2440;
              v_t_2443 = heff_get_n(v_s_2442, 1, 2);
            } else {
              heff_drop(v_field_2440);
              v_t_2443 = NTAG(TAG_RepV);
            }
          }
          return heff_tag_at_n(v_ru_24v_241_24SPrim, TAG_Unboxed, 2, (V[]){v_x_240, v_t_2443});
        }
        case TAG_RepF64: {
          HeffT2 v_t_2444 = ({ V a_0 = v_p_2429; HeffT2 r_ = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(a_0)); heff_drop(v_p_2429); r_; });
          V v_t_2449;
          {
            V v_field_2446 = v_t_2444.f[1];
            int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
            if ((v_tag_2445 == ((int64_t)0ULL))) {
              V v_s_2448 = v_field_2446;
              v_t_2449 = heff_get_n(v_s_2448, 1, 2);
            } else {
              heff_drop(v_field_2446);
              v_t_2449 = NTAG(TAG_RepV);
            }
          }
          return heff_tag_at_n(v_ru_24v_241_24SPrim, TAG_Unboxed, 2, (V[]){v_x_240, v_t_2449});
        }
        case TAG_RepInt: {
          HeffT2 v_t_2450 = ({ V a_0 = v_p_2429; HeffT2 r_ = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(a_0)); heff_drop(v_p_2429); r_; });
          V v_t_2455;
          {
            V v_field_2452 = v_t_2450.f[1];
            int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
            if ((v_tag_2451 == ((int64_t)0ULL))) {
              V v_s_2454 = v_field_2452;
              v_t_2455 = heff_get_n(v_s_2454, 1, 2);
            } else {
              heff_drop(v_field_2452);
              v_t_2455 = NTAG(TAG_RepV);
            }
          }
          return heff_tag_at_n(v_ru_24v_241_24SPrim, TAG_Unboxed, 2, (V[]){v_x_240, v_t_2455});
        }
        default: return heff_nomatch(v_t_2436);
        }
      } else {
        heff_drop(v_p_2429);
        heff_drop_cell(v_ru_24v_241_24SPrim, 2);
        heff_drop(v_field_2433);
        return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
      }
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2erepr_2esourceOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2esourceOf(a[0], a[1]);
}
V g_heff_2ecompile_2erepr_2epinFields_lam0(V self, V *args);
Clo g_heff_2ecompile_2erepr_2epinFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2epinFields_entry, 3, 0};

V g_heff_2ecompile_2erepr_2epinFields(V v_ps_240, V v_acc_241, V v_vs_242) {
top: ;
  switch (heff_tag_of(v_ps_240)) {
  case TAG_Nil: {
    return (g_list_2efoldl_24s964765707x1396946999(v_acc_241, v_vs_242));
  }
  case TAG_Cons: {
    V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_242));
    V v_t_246 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_245, MK_INT(1LL))));
    V v_t_247 = (g_list_2ezipWith_24s1876717925x1404326288(v_vs_242, v_t_246));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erepr_2epinFields_lam0, 2, 1, (V[]){v_ps_240}); V a_1 = v_acc_241; V a_2 = v_t_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  }
  default: return heff_nomatch(v_ps_240);
  }
}
V g_heff_2ecompile_2erepr_2epinFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2epinFields(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erepr_2epinFields_lam0(V self, V *args) {
  V v_acc_248 = args[0];
  V v_x3_249 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x3_249, 0);
    V v_i_2411 = heff_field(v_x3_249, 1);
    V v_ru_24x3_249_24MkPair = heff_take_reuse_n(v_x3_249, 3ULL, 2);
    V v_t_2412 = ({ V a_0 = v_i_2411; V a_1 = v_ps_240; V r_ = (g_list_2eany_24s120814613x1439363162(a_0, a_1)); heff_drop_tag(v_ps_240, 2); r_; });
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      return heff_tag_at_n(v_ru_24x3_249_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){v_x_2410}), v_acc_248});
    } else {
      heff_drop(v_t_2412);
      V v_t_2413 = heff_tag_at_n(v_ru_24x3_249_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_2410)}), v_acc_248});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Pinned, 1, (V[]){v_x_2410}), v_t_2413});
    }
  }
  default: return heff_nomatch(v_x3_249);
  }
}
Clo g_heff_2ecompile_2erepr_2efreeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2efreeGo_entry, 3, 0};

V g_heff_2ecompile_2erepr_2efreeGo(V v_bs_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_bs_240);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_bs_240, v_x_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_x_249 = v_field_247;
        heff_drop(v_x_249);
        V t_0 = v_bs_240;
        V t_1 = v_xs_244;
        V t_2 = v_acc_242;
        v_bs_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_t_2410 = (g_std_2emap_2einsert_24s93785294x875597928(v_bs_240, heff_dup(v_x_243), NTAG(TAG_MkUnit)));
        V t_0 = v_t_2410;
        V t_1 = v_xs_244;
        V t_2 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_acc_242});
        v_bs_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2efreeGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2efreeGo(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erepr_2ewalk_lam0(V self, V *args);
V g_heff_2ecompile_2erepr_2ewalk_lam1(V self, V *args);
V g_heff_2ecompile_2erepr_2ewalk_lam2(V self, V *args);
Clo g_heff_2ecompile_2erepr_2ewalk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ewalk_entry, 4, 0};

V g_heff_2ecompile_2erepr_2ewalk(V v_sg_240, V v_lp_241, V v_acc_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_sg_240, 2);
    heff_drop(v_lp_241);
    return v_acc_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_IVal: {
      V v_r_246 = heff_field(v_x41_244, 0);
      V v_x412_247 = heff_field(v_x41_244, 1);
      V v_ru_24x41_244_24IVal = heff_take_reuse_n(v_x41_244, 3ULL, 2);
      switch (heff_tag_of(v_x412_247)) {
      case TAG_SVar: {
        V v_x_248 = heff_field(v_x412_247, 0);
        V v_ru_24x412_247_24SVar = heff_take_reuse_n(v_x412_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V v_t_249;
        if ((heff_dup(v_lp_241) == NTAG(TAG_True))) {
          v_t_249 = heff_tag_at_n(v_ru_24x412_247_24SVar, TAG_Often, 1, (V[]){heff_tag_n(TAG_Wants, 2, (V[]){v_x_248, v_r_246})});
        } else {
          heff_drop_cell(v_ru_24x412_247_24SVar, 1);
          v_t_249 = heff_tag_n(TAG_Wants, 2, (V[]){v_x_248, v_r_246});
        }
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_acc_242});
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SGlobal: {
        heff_take_n(v_x412_247, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SInt: {
        heff_take_n(v_x412_247, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SFloat: {
        heff_take_na(v_x412_247, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SStr: {
        heff_take_n(v_x412_247, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SBytes: {
        heff_take_n(v_x412_247, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SFixed: {
        heff_take_n(v_x412_247, 0ULL, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x412_247, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x412_247, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SLam: {
        V v_xs_2419 = heff_field(v_x412_247, 0);
        V v_x4122_2420 = heff_field(v_x412_247, 1);
        heff_take_n(v_x412_247, 3ULL, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        switch (heff_tag_of(v_x4122_2420)) {
        case TAG_MkBlock: {
          V v_t_2421 = heff_field(v_x4122_2420, 0);
          V v_ru_24x4122_2420_24MkBlock = heff_take_reuse_n(v_x4122_2420, 1ULL, 1);
          V v_t_2422 = heff_tag_at_n(v_ru_24x4122_2420_24MkBlock, TAG_RetAs, 1, (V[]){NTAG(TAG_RepV)});
          V v_t_2423 = heff_tag_n(TAG_ITl, 3, (V[]){NTAG(TAG_Nil), v_t_2422, v_t_2421});
          V v_t_2424 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
          V v_evs_2425 = (g_heff_2ecompile_2erepr_2ewalk(heff_dup(v_sg_240), NTAG(TAG_False), NTAG(TAG_Nil), v_t_2424));
          V v_t_2426 = (g_prelude_2e_2b_2b(heff_dup(v_evs_2425), v_acc_242));
          V v_t_2427 = (g_list_2efoldl_24s2096135476x728523350(v_t_2426, heff_dup(v_xs_2419)));
          V v_t_2428 = (g_list_2efoldl_24s1694506840x958926808(heff_dup(g_std_2emap_2eempty_get()), v_evs_2425));
          V v_t_2429 = ({ V a_0 = v_t_2428; V a_1 = v_xs_2419; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop(v_xs_2419); r_; });
          V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_evs_2425));
          V v_t_2431 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2430; V r_ = (g_list_2efoldl_24s1923327646x248110754(a_0, a_1)); heff_drop(v_t_2430); r_; });
          V v_t_2432 = (g_heff_2ecompile_2erepr_2efreeGo(v_t_2429, v_t_2431, NTAG(TAG_Nil)));
          V v_t_2433 = (g_list_2efoldl_24s1817528582x392224400(v_lp_241, v_t_2427, v_t_2432));
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = v_t_2433;
          V t_3 = v_rest_245;
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        default: return heff_nomatch(v_x4122_2420);
        }
      }
      case TAG_STag: {
        V v_argv_2435 = heff_field(v_x412_247, 1);
        V v_ts_2436 = heff_field(v_x412_247, 2);
        heff_take_n(v_x412_247, 6ULL, 3);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V v_n_2437 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2435));
        V v_t_2438 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2437, MK_INT(1LL))));
        V v_rs_2441 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erepr_2ewalk_lam0, 1, 1, (V[]){v_ts_2436}), v_t_2438));
        V v_t_2442 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_rs_2441, v_argv_2435));
        V v_t_2443 = (g_list_2efoldl_24s1690891682x1517899652(v_rest_245, v_t_2442));
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_2443;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SRec: {
        V v_fs_2444 = heff_field(v_x412_247, 0);
        V v_ts_2445 = heff_field(v_x412_247, 1);
        heff_take_n(v_x412_247, 3ULL, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V v_t_2446 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_2445));
        V v_t_2447 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2446, MK_INT(1LL))));
        V v_rs_2448 = (g_list_2ezipWith_24s1713677103x1107896282(v_t_2447, v_ts_2445));
        V v_vs_2449 = (g_list_2emap_24s1173914895x100384474(v_fs_2444));
        V v_t_2450 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_rs_2448, v_vs_2449));
        V v_t_2451 = (g_list_2efoldl_24s1690891682x1517899652(v_rest_245, v_t_2450));
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_2451;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SProj: {
        V v_v_2452 = heff_field(v_x412_247, 0);
        heff_take_n(v_x412_247, 1ULL, 4);
        heff_drop(v_r_246);
        V v_t_2456 = heff_tag_at_n(v_ru_24x41_244_24IVal, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_2452});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2456, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SPrim: {
        V v_p_2457 = heff_field(v_x412_247, 0);
        V v_argv_2458 = heff_field(v_x412_247, 1);
        heff_take_n(v_x412_247, 3ULL, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V v_t_2459 = ({ V a_0 = v_p_2457; V a_1 = v_argv_2458; V a_2 = v_rest_245; V r_ = (g_heff_2ecompile_2erepr_2epushPrim(a_0, a_1, a_2)); heff_drop(v_p_2457); r_; });
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_2459;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_x412_247);
      }
    }
    case TAG_IAny: {
      V v_x411_2460 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      switch (heff_tag_of(v_x411_2460)) {
      case TAG_SVar: {
        heff_take_n(v_x411_2460, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SGlobal: {
        V v_t_2463 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x411_2460});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2463, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SInt: {
        V v_t_2465 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x411_2460});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2465, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SFloat: {
        V v_t_2467 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x411_2460});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2467, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SStr: {
        V v_t_2469 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x411_2460});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2469, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SBytes: {
        V v_t_2471 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x411_2460});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2471, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SFixed: {
        V v_t_2474 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x411_2460});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2474, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SFloat32: {
        V v_t_2476 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x411_2460});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2476, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SPrimFn: {
        V v_t_2478 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x411_2460});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2478, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SLam: {
        V v_t_2481 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x411_2460});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2481, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_STag: {
        V v_t_2485 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x411_2460});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2485, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SRec: {
        V v_t_2488 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x411_2460});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2488, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SProj: {
        V v_t_2493 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x411_2460});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2493, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SPrim: {
        V v_t_2496 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x411_2460});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2496, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_x411_2460);
      }
    }
    case TAG_IBind: {
      V v_x_2497 = heff_field(v_x41_244, 0);
      V v_x412_2498 = heff_field(v_x41_244, 1);
      V v_ru_24x41_244_24IBind = heff_take_reuse_n(v_x41_244, 3ULL, 2);
      switch (heff_tag_of(v_x412_2498)) {
      case TAG_OSimple: {
        V v_x4121_2499 = heff_field(v_x412_2498, 0);
        V v_ru_24x412_2498_24OSimple = heff_take_reuse_n(v_x412_2498, 1ULL, 1);
        switch (heff_tag_of(v_x4121_2499)) {
        case TAG_SVar: {
          V v_y_24100 = heff_field(v_x4121_2499, 0);
          heff_take_n(v_x4121_2499, 1ULL, 1);
          heff_drop_cell(v_ru_24x41_244_24IBind, 2);
          heff_drop_cell(v_ru_24x412_2498_24OSimple, 1);
          V v_t_24101 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Merge, 2, (V[]){v_x_2497, v_y_24100}), v_acc_242});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = v_t_24101;
          V t_3 = v_rest_245;
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SGlobal: {
          V v_e_24103 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2497, heff_dup(v_x4121_2499)));
          V v_t_24104;
          if ((heff_dup(v_lp_241) == NTAG(TAG_True))) {
            v_t_24104 = heff_tag_at_n(v_ru_24x412_2498_24OSimple, TAG_Often, 1, (V[]){v_e_24103});
          } else {
            heff_drop_cell(v_ru_24x412_2498_24OSimple, 1);
            v_t_24104 = v_e_24103;
          }
          V v_t_24105 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x4121_2499});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24104, v_acc_242});
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24105, v_rest_245});
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SInt: {
          V v_e_24107 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2497, heff_dup(v_x4121_2499)));
          V v_t_24108;
          if ((heff_dup(v_lp_241) == NTAG(TAG_True))) {
            v_t_24108 = heff_tag_at_n(v_ru_24x412_2498_24OSimple, TAG_Often, 1, (V[]){v_e_24107});
          } else {
            heff_drop_cell(v_ru_24x412_2498_24OSimple, 1);
            v_t_24108 = v_e_24107;
          }
          V v_t_24109 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x4121_2499});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24108, v_acc_242});
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24109, v_rest_245});
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SFloat: {
          V v_e_24111 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2497, heff_dup(v_x4121_2499)));
          V v_t_24112;
          if ((heff_dup(v_lp_241) == NTAG(TAG_True))) {
            v_t_24112 = heff_tag_at_n(v_ru_24x412_2498_24OSimple, TAG_Often, 1, (V[]){v_e_24111});
          } else {
            heff_drop_cell(v_ru_24x412_2498_24OSimple, 1);
            v_t_24112 = v_e_24111;
          }
          V v_t_24113 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x4121_2499});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24112, v_acc_242});
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24113, v_rest_245});
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SStr: {
          V v_e_24115 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2497, heff_dup(v_x4121_2499)));
          V v_t_24116;
          if ((heff_dup(v_lp_241) == NTAG(TAG_True))) {
            v_t_24116 = heff_tag_at_n(v_ru_24x412_2498_24OSimple, TAG_Often, 1, (V[]){v_e_24115});
          } else {
            heff_drop_cell(v_ru_24x412_2498_24OSimple, 1);
            v_t_24116 = v_e_24115;
          }
          V v_t_24117 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x4121_2499});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24116, v_acc_242});
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24117, v_rest_245});
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SBytes: {
          V v_e_24119 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2497, heff_dup(v_x4121_2499)));
          V v_t_24120;
          if ((heff_dup(v_lp_241) == NTAG(TAG_True))) {
            v_t_24120 = heff_tag_at_n(v_ru_24x412_2498_24OSimple, TAG_Often, 1, (V[]){v_e_24119});
          } else {
            heff_drop_cell(v_ru_24x412_2498_24OSimple, 1);
            v_t_24120 = v_e_24119;
          }
          V v_t_24121 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x4121_2499});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24120, v_acc_242});
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24121, v_rest_245});
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SFixed: {
          V v_e_24124 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2497, heff_dup(v_x4121_2499)));
          V v_t_24125;
          if ((heff_dup(v_lp_241) == NTAG(TAG_True))) {
            v_t_24125 = heff_tag_at_n(v_ru_24x412_2498_24OSimple, TAG_Often, 1, (V[]){v_e_24124});
          } else {
            heff_drop_cell(v_ru_24x412_2498_24OSimple, 1);
            v_t_24125 = v_e_24124;
          }
          V v_t_24126 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x4121_2499});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24125, v_acc_242});
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24126, v_rest_245});
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SFloat32: {
          V v_e_24128 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2497, heff_dup(v_x4121_2499)));
          V v_t_24129;
          if ((heff_dup(v_lp_241) == NTAG(TAG_True))) {
            v_t_24129 = heff_tag_at_n(v_ru_24x412_2498_24OSimple, TAG_Often, 1, (V[]){v_e_24128});
          } else {
            heff_drop_cell(v_ru_24x412_2498_24OSimple, 1);
            v_t_24129 = v_e_24128;
          }
          V v_t_24130 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x4121_2499});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24129, v_acc_242});
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24130, v_rest_245});
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SPrimFn: {
          V v_e_24132 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2497, heff_dup(v_x4121_2499)));
          V v_t_24133;
          if ((heff_dup(v_lp_241) == NTAG(TAG_True))) {
            v_t_24133 = heff_tag_at_n(v_ru_24x412_2498_24OSimple, TAG_Often, 1, (V[]){v_e_24132});
          } else {
            heff_drop_cell(v_ru_24x412_2498_24OSimple, 1);
            v_t_24133 = v_e_24132;
          }
          V v_t_24134 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x4121_2499});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24133, v_acc_242});
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24134, v_rest_245});
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SLam: {
          V v_e_24137 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2497, heff_dup(v_x4121_2499)));
          V v_t_24138;
          if ((heff_dup(v_lp_241) == NTAG(TAG_True))) {
            v_t_24138 = heff_tag_at_n(v_ru_24x412_2498_24OSimple, TAG_Often, 1, (V[]){v_e_24137});
          } else {
            heff_drop_cell(v_ru_24x412_2498_24OSimple, 1);
            v_t_24138 = v_e_24137;
          }
          V v_t_24139 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x4121_2499});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24138, v_acc_242});
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24139, v_rest_245});
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_STag: {
          V v_e_24143 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2497, heff_dup(v_x4121_2499)));
          V v_t_24144;
          if ((heff_dup(v_lp_241) == NTAG(TAG_True))) {
            v_t_24144 = heff_tag_at_n(v_ru_24x412_2498_24OSimple, TAG_Often, 1, (V[]){v_e_24143});
          } else {
            heff_drop_cell(v_ru_24x412_2498_24OSimple, 1);
            v_t_24144 = v_e_24143;
          }
          V v_t_24145 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x4121_2499});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24144, v_acc_242});
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24145, v_rest_245});
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SRec: {
          V v_e_24148 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2497, heff_dup(v_x4121_2499)));
          V v_t_24149;
          if ((heff_dup(v_lp_241) == NTAG(TAG_True))) {
            v_t_24149 = heff_tag_at_n(v_ru_24x412_2498_24OSimple, TAG_Often, 1, (V[]){v_e_24148});
          } else {
            heff_drop_cell(v_ru_24x412_2498_24OSimple, 1);
            v_t_24149 = v_e_24148;
          }
          V v_t_24150 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x4121_2499});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24149, v_acc_242});
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24150, v_rest_245});
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SProj: {
          V v_e_24155 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2497, heff_dup(v_x4121_2499)));
          V v_t_24156;
          if ((heff_dup(v_lp_241) == NTAG(TAG_True))) {
            v_t_24156 = heff_tag_at_n(v_ru_24x412_2498_24OSimple, TAG_Often, 1, (V[]){v_e_24155});
          } else {
            heff_drop_cell(v_ru_24x412_2498_24OSimple, 1);
            v_t_24156 = v_e_24155;
          }
          V v_t_24157 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x4121_2499});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24156, v_acc_242});
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24157, v_rest_245});
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SPrim: {
          V v_e_24160 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2497, heff_dup(v_x4121_2499)));
          V v_t_24161;
          if ((heff_dup(v_lp_241) == NTAG(TAG_True))) {
            v_t_24161 = heff_tag_at_n(v_ru_24x412_2498_24OSimple, TAG_Often, 1, (V[]){v_e_24160});
          } else {
            heff_drop_cell(v_ru_24x412_2498_24OSimple, 1);
            v_t_24161 = v_e_24160;
          }
          V v_t_24162 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x4121_2499});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24161, v_acc_242});
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24162, v_rest_245});
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        default: return heff_nomatch(v_x4121_2499);
        }
      }
      case TAG_OCall: {
        V v_g_24163 = heff_field(v_x412_2498, 0);
        V v_argv_24164 = heff_field(v_x412_2498, 1);
        V v_ru_24x412_2498_24OCall = heff_take_reuse_n(v_x412_2498, 3ULL, 2);
        HeffT2 v_t_24165 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_sg_240, 0), v_g_24163));
        V v_t_24173;
        {
          V v_field_24167 = v_t_24165.f[1];
          int64_t v_tag_24166 = ((int64_t)v_t_24165.f[0]);
          V v_r_24170;
          if ((v_tag_24166 == ((int64_t)0ULL))) {
            V v_s_24169 = v_field_24167;
            v_r_24170 = heff_get_n(v_s_24169, 1, 2);
          } else {
            heff_drop(v_field_24167);
            v_r_24170 = NTAG(TAG_RepV);
          }
          V v_e_24172;
          switch (heff_tag_of(v_r_24170)) {
          case TAG_RepV: {
            heff_drop_cell(v_ru_24x41_244_24IBind, 2);
            v_e_24172 = heff_tag_n(TAG_Boxed, 1, (V[]){v_x_2497});
            break;
          }
          case TAG_RepFix: {
            v_e_24172 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_Unboxed, 2, (V[]){v_x_2497, v_r_24170});
            break;
          }
          case TAG_RepF64: {
            v_e_24172 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_Unboxed, 2, (V[]){v_x_2497, v_r_24170});
            break;
          }
          case TAG_RepInt: {
            v_e_24172 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_Unboxed, 2, (V[]){v_x_2497, v_r_24170});
            break;
          }
          default: heff_nomatch(v_r_24170);
          }
          if ((heff_dup(v_lp_241) == NTAG(TAG_True))) {
            v_t_24173 = heff_tag_n(TAG_Often, 1, (V[]){v_e_24172});
          } else {
            v_t_24173 = v_e_24172;
          }
        }
        V v_t_24174 = heff_tag_n(TAG_IOp, 1, (V[]){heff_tag_at_n(v_ru_24x412_2498_24OCall, TAG_OCall, 2, (V[]){v_g_24163, v_argv_24164})});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24173, v_acc_242});
        V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24174, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_OApply: {
        heff_drop_cell(v_ru_24x41_244_24IBind, 2);
        V v_t_24177 = (g_heff_2ecompile_2erepr_2estepGives(v_lp_241, v_x_2497, heff_dup(v_x412_2498), v_acc_242));
        V v_t_24178 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_x412_2498}), v_rest_245});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_t_24177;
        V t_3 = v_t_24178;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_OPrim: {
        heff_drop_cell(v_ru_24x41_244_24IBind, 2);
        V v_t_24181 = (g_heff_2ecompile_2erepr_2estepGives(v_lp_241, v_x_2497, heff_dup(v_x412_2498), v_acc_242));
        V v_t_24182 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_x412_2498}), v_rest_245});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_t_24181;
        V t_3 = v_t_24182;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_OAbandon: {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_x_2497);
        heff_drop_cell(v_ru_24x41_244_24IBind, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_OBool: {
        heff_drop_cell(v_ru_24x41_244_24IBind, 2);
        V v_t_24184 = (g_heff_2ecompile_2erepr_2estepGives(v_lp_241, v_x_2497, heff_dup(v_x412_2498), v_acc_242));
        V v_t_24185 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_x412_2498}), v_rest_245});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_t_24184;
        V t_3 = v_t_24185;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_x412_2498);
      }
    }
    case TAG_IOp: {
      V v_x411_24186 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      switch (heff_tag_of(v_x411_24186)) {
      case TAG_OSimple: {
        V v_v_24187 = heff_field(v_x411_24186, 0);
        heff_take_n(v_x411_24186, 1ULL, 1);
        V v_t_24188 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_24187});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24188, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_OCall: {
        V v_g_24189 = heff_field(v_x411_24186, 0);
        V v_argv_24190 = heff_field(v_x411_24186, 1);
        heff_take_n(v_x411_24186, 3ULL, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        HeffT2 v_t_24191 = ({ V a_0 = heff_rfield(v_sg_240, 0); V a_1 = v_g_24189; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_g_24189); r_; });
        V v_t_24198;
        {
          V v_field_24193 = v_t_24191.f[1];
          int64_t v_tag_24192 = ((int64_t)v_t_24191.f[0]);
          V v_rs_24196;
          if ((v_tag_24192 == ((int64_t)0ULL))) {
            V v_s_24195 = v_field_24193;
            v_rs_24196 = heff_get_n(v_s_24195, 0, 2);
          } else {
            heff_drop(v_field_24193);
            v_rs_24196 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_argv_24190)));
          }
          V v_t_24197 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_rs_24196, v_argv_24190));
          v_t_24198 = (g_list_2efoldl_24s1690891682x1517899652(v_rest_245, v_t_24197));
        }
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_24198;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_OApply: {
        V v_f_24199 = heff_field(v_x411_24186, 0);
        V v_argv_24200 = heff_field(v_x411_24186, 1);
        heff_take_n(v_x411_24186, 3ULL, 2);
        V v_t_24201 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_f_24199, v_argv_24200})));
        V v_t_24202 = (g_list_2efoldl_24s728686882x2096535788(NTAG(TAG_RepV), v_rest_245, v_t_24201));
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_24202;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_OPrim: {
        V v_argv_24204 = heff_field(v_x411_24186, 1);
        heff_take_n(v_x411_24186, 2ULL, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        V v_t_24205 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_24204));
        V v_t_24206 = (g_list_2efoldl_24s728686882x2096535788(NTAG(TAG_RepV), v_rest_245, v_t_24205));
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_24206;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_OAbandon: {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_OBool: {
        V v_c_24207 = heff_field(v_x411_24186, 0);
        heff_take_n(v_x411_24186, 1ULL, 1);
        V v_t_24208 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24207}), v_rest_245});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_24208;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_x411_24186);
      }
    }
    case TAG_ICond: {
      V v_x411_24209 = heff_field(v_x41_244, 0);
      V v_ru_24x41_244_24ICond = heff_take_reuse_n(v_x41_244, 1ULL, 1);
      switch (heff_tag_of(v_x411_24209)) {
      case TAG_PTrue: {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop_cell(v_ru_24x41_244_24ICond, 1);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_PFalse: {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop_cell(v_ru_24x41_244_24ICond, 1);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_PRel: {
        V v_p_24210 = heff_field(v_x411_24209, 0);
        V v_a_24211 = heff_field(v_x411_24209, 1);
        V v_b_24212 = heff_field(v_x411_24209, 2);
        heff_take_n(v_x411_24209, 7ULL, 3);
        heff_drop_cell(v_ru_24x41_244_24ICond, 1);
        HeffT2 v_t_24213 = ({ V a_0 = v_p_24210; HeffT2 r_ = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(a_0)); heff_drop(v_p_24210); r_; });
        V v_t_24222;
        {
          V v_field_24215 = v_t_24213.f[1];
          int64_t v_tag_24214 = ((int64_t)v_t_24213.f[0]);
          V v_rs_24219;
          if ((v_tag_24214 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x4_243_24Cons, 2);
            V v_s_24217 = v_field_24215;
            v_rs_24219 = heff_get_n(v_s_24217, 0, 2);
          } else {
            heff_drop(v_field_24215);
            V v_t_24218 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_24212), NTAG(TAG_Nil)});
            v_rs_24219 = (g_list_2emap_24s1598879313x231311047(heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_24211), v_t_24218})));
          }
          V v_t_24220 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_24212, NTAG(TAG_Nil)});
          V v_t_24221 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_rs_24219, heff_tag_n(TAG_Cons, 2, (V[]){v_a_24211, v_t_24220})));
          v_t_24222 = (g_list_2efoldl_24s1690891682x1517899652(v_rest_245, v_t_24221));
        }
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_24222;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_PBool: {
        V v_v_24223 = heff_field(v_x411_24209, 0);
        heff_take_n(v_x411_24209, 1ULL, 1);
        heff_drop_cell(v_ru_24x41_244_24ICond, 1);
        V v_t_24224 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_24223});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24224, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_PNot: {
        V v_c_24225 = heff_field(v_x411_24209, 0);
        heff_take_n(v_x411_24209, 1ULL, 1);
        heff_drop_cell(v_ru_24x41_244_24ICond, 1);
        V v_t_24226 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24225}), v_rest_245});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_24226;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_PIf: {
        V v_a_24227 = heff_field(v_x411_24209, 0);
        V v_b_24228 = heff_field(v_x411_24209, 1);
        V v_c_24229 = heff_field(v_x411_24209, 2);
        heff_take_n(v_x411_24209, 7ULL, 3);
        V v_t_24230 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24229}), v_rest_245});
        V v_t_24231 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24ICond, TAG_ICond, 1, (V[]){v_b_24228}), v_t_24230});
        V v_t_24232 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_a_24227}), v_t_24231});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_24232;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_PLet: {
        V v_x_24233 = heff_field(v_x411_24209, 0);
        V v_o_24234 = heff_field(v_x411_24209, 1);
        V v_c_24235 = heff_field(v_x411_24209, 2);
        heff_take_n(v_x411_24209, 7ULL, 3);
        V v_t_24236 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_24233)}), v_acc_242});
        V v_t_24237 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24ICond, TAG_ICond, 1, (V[]){v_c_24235}), v_rest_245});
        V v_t_24238 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IBind, 2, (V[]){v_x_24233, v_o_24234}), v_t_24237});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_t_24236;
        V t_3 = v_t_24238;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_x411_24209);
      }
    }
    case TAG_ISts: {
      V v_x411_24239 = heff_field(v_x41_244, 0);
      V v_ru_24x41_244_24ISts = heff_take_reuse_n(v_x41_244, 1ULL, 1);
      switch (heff_tag_of(v_x411_24239)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop_cell(v_ru_24x41_244_24ISts, 1);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_Cons: {
        V v_x4111_24240 = heff_field(v_x411_24239, 0);
        V v_ss_24241 = heff_field(v_x411_24239, 1);
        V v_ru_24x411_24239_24Cons = heff_take_reuse_n(v_x411_24239, 3ULL, 2);
        switch (heff_tag_of(v_x4111_24240)) {
        case TAG_SLet: {
          V v_x_24242 = heff_field(v_x4111_24240, 0);
          V v_o_24243 = heff_field(v_x4111_24240, 1);
          V v_ru_24x4111_24240_24SLet = heff_take_reuse_n(v_x4111_24240, 3ULL, 2);
          V v_t_24244 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_24242)}), v_acc_242});
          V v_t_24245 = heff_tag_at_n(v_ru_24x411_24239_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24ISts, TAG_ISts, 1, (V[]){v_ss_24241}), v_rest_245});
          V v_t_24246 = heff_tag_at_n(v_ru_24x4111_24240_24SLet, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IBind, 2, (V[]){v_x_24242, v_o_24243}), v_t_24245});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = v_t_24244;
          V t_3 = v_t_24246;
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SDecl: {
          V v_x_24247 = heff_field(v_x4111_24240, 0);
          heff_take_n(v_x4111_24240, 1ULL, 1);
          V v_t_24248 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){v_x_24247}), v_acc_242});
          V v_t_24249 = heff_tag_at_n(v_ru_24x411_24239_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24ISts, TAG_ISts, 1, (V[]){v_ss_24241}), v_rest_245});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = v_t_24248;
          V t_3 = v_t_24249;
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SSet: {
          V v_x_24250 = heff_field(v_x4111_24240, 0);
          V v_o_24251 = heff_field(v_x4111_24240, 1);
          heff_take_n(v_x4111_24240, 3ULL, 2);
          heff_drop_cell(v_ru_24x41_244_24ISts, 1);
          V v_t_24252 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24241}), v_rest_245});
          V v_t_24253 = heff_tag_at_n(v_ru_24x411_24239_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IBind, 2, (V[]){v_x_24250, v_o_24251}), v_t_24252});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = v_acc_242;
          V t_3 = v_t_24253;
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SIf: {
          V v_c_24254 = heff_field(v_x4111_24240, 0);
          V v_ts_24255 = heff_field(v_x4111_24240, 1);
          V v_fs_24256 = heff_field(v_x4111_24240, 2);
          heff_take_n(v_x4111_24240, 7ULL, 3);
          V v_t_24257 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24241}), v_rest_245});
          V v_t_24258 = heff_tag_at_n(v_ru_24x411_24239_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24ISts, TAG_ISts, 1, (V[]){v_fs_24256}), v_t_24257});
          V v_t_24259 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ts_24255}), v_t_24258});
          V v_t_24260 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24254}), v_t_24259});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = v_acc_242;
          V t_3 = v_t_24260;
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SCase: {
          V v_v_24261 = heff_field(v_x4111_24240, 0);
          V v_arms_24262 = heff_field(v_x4111_24240, 1);
          V v_ru_24x4111_24240_24SCase = heff_take_reuse_n(v_x4111_24240, 3ULL, 2);
          heff_drop_cell(v_ru_24x41_244_24ISts, 1);
          V v_t_24274 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2erepr_2ewalk_lam1, 2, 1, (V[]){heff_dup(v_sg_240)}), v_acc_242, v_arms_24262));
          V v_t_24275 = heff_tag_at_n(v_ru_24x4111_24240_24SCase, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_24261});
          V v_t_24276 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24241}), v_rest_245});
          V v_t_24277 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24262));
          V v_t_24278 = (g_list_2efoldl_24s1104809983x118204267(v_t_24276, v_t_24277));
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = v_t_24274;
          V t_3 = heff_tag_at_n(v_ru_24x411_24239_24Cons, TAG_Cons, 2, (V[]){v_t_24275, v_t_24278});
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        default: return heff_nomatch(v_x4111_24240);
        }
      }
      default: return heff_nomatch(v_x411_24239);
      }
    }
    case TAG_ITl: {
      V v_ps_24279 = heff_field(v_x41_244, 0);
      V v_rt_24280 = heff_field(v_x41_244, 1);
      V v_x413_24281 = heff_field(v_x41_244, 2);
      V v_ru_24x41_244_24ITl = heff_take_reuse_n(v_x41_244, 7ULL, 3);
      heff_drop(v_lp_241);
      switch (heff_tag_of(v_x413_24281)) {
      case TAG_TSeq: {
        V v_ss_24282 = heff_field(v_x413_24281, 0);
        V v_t_24283 = heff_field(v_x413_24281, 1);
        V v_ru_24x413_24281_24TSeq = heff_take_reuse_n(v_x413_24281, 3ULL, 2);
        heff_drop_cell(v_ru_24x41_244_24ITl, 3);
        V v_t_24284 = (g_heff_2ecompile_2erepr_2eloops(v_t_24283));
        V v_t_24285 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 3, (V[]){v_ps_24279, v_rt_24280, v_t_24283}), v_rest_245});
        V v_t_24286 = heff_tag_at_n(v_ru_24x413_24281_24TSeq, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24282}), v_t_24285});
        V t_0 = v_sg_240;
        V t_1 = v_t_24284;
        V t_2 = v_acc_242;
        V t_3 = v_t_24286;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_TReturn: {
        V v_o_24287 = heff_field(v_x413_24281, 0);
        heff_take_n(v_x413_24281, 1ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_ps_24279);
        heff_drop_cell(v_ru_24x41_244_24ITl, 3);
        V v_t_24288 = (g_heff_2ecompile_2erepr_2ereturned(v_rt_24280, v_o_24287, v_rest_245));
        V t_0 = v_sg_240;
        V t_1 = NTAG(TAG_False);
        V t_2 = v_acc_242;
        V t_3 = v_t_24288;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_TLoop: {
        V v_vs_24289 = heff_field(v_x413_24281, 0);
        heff_take_n(v_x413_24281, 1ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_rt_24280);
        heff_drop_cell(v_ru_24x41_244_24ITl, 3);
        V v_t_24290 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_ps_24279, v_vs_24289));
        V v_t_24291 = (g_list_2efoldl_24s348204425x880103432(v_rest_245, v_t_24290));
        V t_0 = v_sg_240;
        V t_1 = NTAG(TAG_True);
        V t_2 = v_acc_242;
        V t_3 = v_t_24291;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_TIf: {
        V v_c_24292 = heff_field(v_x413_24281, 0);
        V v_t_24293 = heff_field(v_x413_24281, 1);
        V v_e_24294 = heff_field(v_x413_24281, 2);
        heff_take_n(v_x413_24281, 7ULL, 3);
        V v_t_24295 = (g_heff_2ecompile_2erepr_2eloops(v_t_24293));
        V v_t_24296;
        if ((heff_dup(v_t_24295) == NTAG(TAG_True))) {
          heff_drop(v_t_24295);
          v_t_24296 = NTAG(TAG_True);
        } else {
          heff_drop(v_t_24295);
          v_t_24296 = (g_heff_2ecompile_2erepr_2eloops(v_e_24294));
        }
        V v_t_24297 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 3, (V[]){heff_dup(v_ps_24279), heff_dup(v_rt_24280), v_e_24294}), v_rest_245});
        V v_t_24298 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24ITl, TAG_ITl, 3, (V[]){v_ps_24279, v_rt_24280, v_t_24293}), v_t_24297});
        V v_t_24299 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24292}), v_t_24298});
        V t_0 = v_sg_240;
        V t_1 = v_t_24296;
        V t_2 = v_acc_242;
        V t_3 = v_t_24299;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_TCase: {
        V v_v_24300 = heff_field(v_x413_24281, 0);
        V v_arms_24301 = heff_field(v_x413_24281, 1);
        V v_ru_24x413_24281_24TCase = heff_take_reuse_n(v_x413_24281, 3ULL, 2);
        heff_drop_cell(v_ru_24x41_244_24ITl, 3);
        V v_t_24302 = ({ V b_0 = heff_tag_at_n(v_ru_24x413_24281_24TCase, TAG_TCase, 2, (V[]){heff_dup(v_v_24300), heff_dup(v_arms_24301)}); V r_ = (g_heff_2ecompile_2erepr_2eloops(b_0)); heff_drop(b_0); r_; });
        V v_t_24314 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2erepr_2ewalk_lam2, 2, 1, (V[]){heff_dup(v_sg_240)}), v_acc_242, v_arms_24301));
        V v_t_24315 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_24300});
        V v_t_24316 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24301));
        V v_t_24317 = (g_list_2efoldl_24s2145639387x28888241(v_ps_24279, v_rt_24280, v_rest_245, v_t_24316));
        V t_0 = v_sg_240;
        V t_1 = v_t_24302;
        V t_2 = v_t_24314;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24315, v_t_24317});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_x413_24281);
      }
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2erepr_2ewalk_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ewalk(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erepr_2ewalk_lam0(V self, V *args) {
  V v_i_2439 = args[0];
  V v_ts_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2440 = ({ V a_0 = heff_dup(v_i_2439); V a_1 = v_ts_2436; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2436); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2439, v_t_2440));
}
V g_heff_2ecompile_2erepr_2ewalk_lam1(V self, V *args) {
  V v_acc_24263 = args[0];
  V v_x3_24264 = args[1];
  V v_sg_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_24264)) {
  case TAG_MkArm: {
    V v_t_24265 = heff_field(v_x3_24264, 0);
    V v_vs_24266 = heff_field(v_x3_24264, 1);
    heff_take_n(v_x3_24264, 3ULL, 3);
    HeffT2 v_t_24268 = ({ V b_0 = heff_get_n(v_sg_240, 1, 2); V a_1 = v_t_24265; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_24265); r_; });
    V v_t_24273;
    {
      V v_field_24270 = v_t_24268.f[1];
      int64_t v_tag_24269 = ((int64_t)v_t_24268.f[0]);
      if ((v_tag_24269 == ((int64_t)0ULL))) {
        V v_x_24272 = v_field_24270;
        v_t_24273 = v_x_24272;
      } else {
        heff_drop(v_field_24270);
        v_t_24273 = NTAG(TAG_Nil);
      }
    }
    return (g_heff_2ecompile_2erepr_2epinFields(v_t_24273, v_acc_24263, v_vs_24266));
  }
  default: return heff_nomatch(v_x3_24264);
  }
}
V g_heff_2ecompile_2erepr_2ewalk_lam2(V self, V *args) {
  V v_acc_24303 = args[0];
  V v_x3_24304 = args[1];
  V v_sg_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_24304)) {
  case TAG_MkArm: {
    V v_t_24305 = heff_field(v_x3_24304, 0);
    V v_vs_24306 = heff_field(v_x3_24304, 1);
    heff_take_n(v_x3_24304, 3ULL, 3);
    HeffT2 v_t_24308 = ({ V b_0 = heff_get_n(v_sg_240, 1, 2); V a_1 = v_t_24305; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_24305); r_; });
    V v_t_24313;
    {
      V v_field_24310 = v_t_24308.f[1];
      int64_t v_tag_24309 = ((int64_t)v_t_24308.f[0]);
      if ((v_tag_24309 == ((int64_t)0ULL))) {
        V v_x_24312 = v_field_24310;
        v_t_24313 = v_x_24312;
      } else {
        heff_drop(v_field_24310);
        v_t_24313 = NTAG(TAG_Nil);
      }
    }
    return (g_heff_2ecompile_2erepr_2epinFields(v_t_24313, v_acc_24303, v_vs_24306));
  }
  default: return heff_nomatch(v_x3_24304);
  }
}
Clo g_heff_2ecompile_2erepr_2eentered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eentered_entry, 2, 0};

V g_heff_2ecompile_2erepr_2eentered(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_RepV: {
      V v_t_244 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_242)}), v_acc_240});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_242}), v_t_244});
    }
    case TAG_RepFix: {
      V v_t_246 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_242)}), v_acc_240});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Kept, 2, (V[]){v_x_242, v_x22_243}), v_t_246});
    }
    case TAG_RepF64: {
      V v_t_247 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_242)}), v_acc_240});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Kept, 2, (V[]){v_x_242, v_x22_243}), v_t_247});
    }
    case TAG_RepInt: {
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_242)}), v_acc_240});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Kept, 2, (V[]){v_x_242, v_x22_243}), v_t_248});
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2eentered_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2eentered(a[0], a[1]);
}
Clo g_heff_2ecompile_2erepr_2edefEvents_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2edefEvents_entry, 2, 0};

V g_heff_2ecompile_2erepr_2edefEvents(V v_sg_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkDef: {
    V v_key_242 = heff_field(v_x2_241, 0);
    V v_x23_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24MkDef = heff_take_reuse_n(v_x2_241, 5ULL, 3);
    switch (heff_tag_of(v_x23_244)) {
    case TAG_DefFun: {
      V v_xs_245 = heff_field(v_x23_244, 0);
      V v_x232_246 = heff_field(v_x23_244, 1);
      V v_ru_24x23_244_24DefFun = heff_take_reuse_n(v_x23_244, 3ULL, 2);
      switch (heff_tag_of(v_x232_246)) {
      case TAG_MkBlock: {
        V v_t_247 = heff_field(v_x232_246, 0);
        heff_take_n(v_x232_246, 1ULL, 1);
        HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_sg_240, 0), v_key_242));
        V v_t_2413;
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_s_2412 = v_field_2410;
            v_t_2413 = heff_get_n(v_s_2412, 0, 2);
          } else {
            heff_drop(v_field_2410);
            v_t_2413 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_xs_245)));
          }
        }
        V v_t_2414 = (g_list_2efoldl_24f488322910x556193579(NTAG(TAG_Nil), heff_dup(v_xs_245), v_t_2413));
        HeffT2 v_t_2415 = ({ V a_0 = heff_rfield(v_sg_240, 0); V a_1 = v_key_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_key_242); r_; });
        V v_t_2420;
        {
          V v_field_2417 = v_t_2415.f[1];
          int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            V v_s_2419 = v_field_2417;
            v_t_2420 = heff_get_n(v_s_2419, 1, 2);
          } else {
            heff_drop(v_field_2417);
            v_t_2420 = NTAG(TAG_RepV);
          }
        }
        V v_t_2421 = heff_tag_at_n(v_ru_24x2_241_24MkDef, TAG_ITl, 3, (V[]){v_xs_245, heff_tag_n(TAG_RetAs, 1, (V[]){v_t_2420}), v_t_247});
        V v_t_2422 = heff_tag_at_n(v_ru_24x23_244_24DefFun, TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
        return (g_heff_2ecompile_2erepr_2ewalk(v_sg_240, NTAG(TAG_False), v_t_2414, v_t_2422));
      }
      default: return heff_nomatch(v_x232_246);
      }
    }
    case TAG_DefVal: {
      V v_x231_2423 = heff_field(v_x23_244, 0);
      V v_ru_24x23_244_24DefVal = heff_take_reuse_n(v_x23_244, 1ULL, 1);
      heff_drop(v_key_242);
      switch (heff_tag_of(v_x231_2423)) {
      case TAG_MkBlock: {
        V v_t_2424 = heff_field(v_x231_2423, 0);
        heff_take_n(v_x231_2423, 1ULL, 1);
        V v_t_2425 = heff_tag_at_n(v_ru_24x23_244_24DefVal, TAG_RetAs, 1, (V[]){NTAG(TAG_RepV)});
        V v_t_2426 = heff_tag_at_n(v_ru_24x2_241_24MkDef, TAG_ITl, 3, (V[]){NTAG(TAG_Nil), v_t_2425, v_t_2424});
        V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
        return (g_heff_2ecompile_2erepr_2ewalk(v_sg_240, NTAG(TAG_False), NTAG(TAG_Nil), v_t_2427));
      }
      default: return heff_nomatch(v_x231_2423);
      }
    }
    default: return heff_nomatch(v_x23_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2edefEvents_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2edefEvents(a[0], a[1]);
}
Clo g_heff_2ecompile_2erepr_2easWord_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2easWord_entry, 2, 0};

V g_heff_2ecompile_2erepr_2easWord(V v_ws_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Merge: {
    return v_x2_241;
  }
  case TAG_Boxed: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Boxed = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_ws_240, v_x_244));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x2_241_24Boxed, 1);
        V v_x_249 = v_field_247;
        heff_drop(v_x_249);
        return heff_tag_n(TAG_BoxedWord, 1, (V[]){v_x_244});
      } else {
        heff_drop(v_field_247);
        return heff_tag_at_n(v_ru_24x2_241_24Boxed, TAG_Boxed, 1, (V[]){v_x_244});
      }
    }
  }
  case TAG_BoxedWord: {
    return v_x2_241;
  }
  case TAG_Element: {
    return v_x2_241;
  }
  case TAG_Unboxed: {
    return v_x2_241;
  }
  case TAG_Literal: {
    return v_x2_241;
  }
  case TAG_Wants: {
    return v_x2_241;
  }
  case TAG_Binds: {
    return v_x2_241;
  }
  case TAG_Pinned: {
    return v_x2_241;
  }
  case TAG_Kept: {
    return v_x2_241;
  }
  case TAG_Often: {
    V v_e_2422 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Often = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_cell_2423 = heff_tag_at_n(v_ru_24x2_241_24Often, TAG_Often, 1, (V[]){heff_hole()});
    V v_u_2424 = (g_heff_2ecompile_2erepr_2easWord_24dps(v_ws_240, v_e_2422, heff_dup(v_cell_2423)));
    heff_drop(v_u_2424);
    return v_cell_2423;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2easWord_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2easWord(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erepr_2easWord_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2easWord_24dps_entry, 3, 0};

V g_heff_2ecompile_2erepr_2easWord_24dps(V v_ws_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Merge: {
    return heff_setField(v_d_242, MK_INT(0LL), v_x2_241);
  }
  case TAG_Boxed: {
    V v_x_245 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_246 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_ws_240, v_x_245));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_x_2410 = v_field_248;
        heff_drop(v_x_2410);
        return heff_setField(v_d_242, MK_INT(0LL), heff_tag_n(TAG_BoxedWord, 1, (V[]){v_x_245}));
      } else {
        heff_drop(v_field_248);
        return heff_setField(v_d_242, MK_INT(0LL), heff_tag_n(TAG_Boxed, 1, (V[]){v_x_245}));
      }
    }
  }
  case TAG_BoxedWord: {
    return heff_setField(v_d_242, MK_INT(0LL), v_x2_241);
  }
  case TAG_Element: {
    return heff_setField(v_d_242, MK_INT(0LL), v_x2_241);
  }
  case TAG_Unboxed: {
    return heff_setField(v_d_242, MK_INT(0LL), v_x2_241);
  }
  case TAG_Literal: {
    return heff_setField(v_d_242, MK_INT(0LL), v_x2_241);
  }
  case TAG_Wants: {
    return heff_setField(v_d_242, MK_INT(0LL), v_x2_241);
  }
  case TAG_Binds: {
    return heff_setField(v_d_242, MK_INT(0LL), v_x2_241);
  }
  case TAG_Pinned: {
    return heff_setField(v_d_242, MK_INT(0LL), v_x2_241);
  }
  case TAG_Kept: {
    return heff_setField(v_d_242, MK_INT(0LL), v_x2_241);
  }
  case TAG_Often: {
    V v_e_2423 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Often = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_241_24Often, TAG_Often, 1, (V[]){heff_hole()});
    V v_u_2425 = heff_setField(v_d_242, MK_INT(0LL), heff_dup(v_cell_2424));
    heff_drop(v_u_2425);
    V t_0 = v_ws_240;
    V t_1 = v_e_2423;
    V t_2 = v_cell_2424;
    v_ws_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2easWord_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2easWord_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2erepr_2ewordParams_lam0(V self, V *args);
Clo g_heff_2ecompile_2erepr_2ewordParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ewordParams_entry, 2, 0};

V g_heff_2ecompile_2erepr_2ewordParams(V v_is_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_MkDef: {
    V v_d3_244 = heff_field(v_d_241, 2);
    switch (heff_tag_of(v_d3_244)) {
    case TAG_DefFun: {
      V v_xs_245 = heff_field(v_d3_244, 0);
      V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_245));
      V v_t_248 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_247, MK_INT(1LL))));
      V v_t_249 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_245), v_t_248));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erepr_2ewordParams_lam0, 2, 1, (V[]){heff_dup(v_is_240)}); V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
    }
    case TAG_DefVal: {
      return heff_dup(g_std_2emap_2eempty_get());
    }
    default: return heff_nomatch(v_d3_244);
    }
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2ecompile_2erepr_2ewordParams_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2ewordParams(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erepr_2ewordParams_lam0(V self, V *args) {
  V v_m_2410 = args[0];
  V v_p_2411 = args[1];
  V v_is_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = ({ V a_0 = v_p_2411; V a_1 = v_is_240; V r_ = (g_list_2eany_24s1080008383x1763122651(a_0, a_1)); heff_drop(v_is_240); r_; });
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_t_2412);
    V v_t_2415;
    switch (heff_tag_of(v_p_2411)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_p_2411, 0);
      heff_take_n(v_p_2411, 1ULL, 2);
      v_t_2415 = v_x_2413;
      break;
    }
    default: heff_nomatch(v_p_2411);
    }
    return (g_std_2emap_2einsert_24s93785294x875597928(v_m_2410, v_t_2415, NTAG(TAG_MkUnit)));
  } else {
    heff_drop(v_p_2411);
    heff_drop(v_t_2412);
    return v_m_2410;
  }
}
Clo g_heff_2ecompile_2erepr_2eunpinOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eunpinOne_entry, 2, 0};

V g_heff_2ecompile_2erepr_2eunpinOne(V v_pins_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Merge: {
    V v_x_242 = heff_field(v_e_241, 0);
    V v_y_243 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24Merge = heff_take_reuse_n(v_e_241, 3ULL, 2);
    HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_pins_240, v_x_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24e_241_24Merge, 2);
        V v_x_248 = v_field_246;
        heff_drop(v_x_248);
        V v_t_249 = heff_tag_n(TAG_Wants, 2, (V[]){v_y_243, NTAG(TAG_RepV)});
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_242}), v_t_2410});
      } else {
        heff_drop(v_field_246);
        HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_pins_240, v_y_243));
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24e_241_24Merge, 2);
            V v_x_2415 = v_field_2413;
            heff_drop(v_x_2415);
            V v_t_2416 = heff_tag_n(TAG_Wants, 2, (V[]){v_y_243, NTAG(TAG_RepV)});
            V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
            return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_242}), v_t_2417});
          } else {
            heff_drop(v_field_2413);
            return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24e_241_24Merge, TAG_Merge, 2, (V[]){v_x_242, v_y_243}), NTAG(TAG_Nil)});
          }
        }
      }
    }
  }
  case TAG_Boxed: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_BoxedWord: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Element: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Unboxed: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Literal: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Wants: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Binds: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Pinned: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Kept: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Often: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2erepr_2eunpinOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2eunpinOne(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erepr_2ewithRepr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ewithRepr_entry, 2, 0};

V g_heff_2ecompile_2erepr_2ewithRepr(V v_r_240, V v_rs_241) {
top: ;
  switch (heff_tag_of(v_r_240)) {
  case TAG_RepV: {
    return v_rs_241;
  }
  case TAG_RepFix: {
    V v_t_243 = (g_list_2eany_24s100684943x1504448948(v_r_240, v_rs_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop_tag(v_r_240, 1);
      heff_drop(v_t_243);
      return v_rs_241;
    } else {
      heff_drop(v_t_243);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_rs_241});
    }
  }
  case TAG_RepF64: {
    V v_t_244 = (g_list_2eany_24s100684943x1504448948(v_r_240, v_rs_241));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return v_rs_241;
    } else {
      heff_drop(v_t_244);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_rs_241});
    }
  }
  case TAG_RepInt: {
    V v_t_245 = (g_list_2eany_24s100684943x1504448948(v_r_240, v_rs_241));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      return v_rs_241;
    } else {
      heff_drop(v_t_245);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_rs_241});
    }
  }
  default: return heff_nomatch(v_r_240);
  }
}
V g_heff_2ecompile_2erepr_2ewithRepr_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ewithRepr(a[0], a[1]);
}
Clo g_heff_2ecompile_2erepr_2estatsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2estatsWith_entry, 7, 0};

V g_heff_2ecompile_2erepr_2estatsWith(V v_r_240, V v_bi_241, V v_ui_242, V v_bo_243, V v_uo_244, V v_pin_245, V v_s_246) {
top: ;
  V v_t_247 = (g_heff_2ecompile_2erepr_2ewithRepr(v_r_240, heff_take_field(v_s_246, 0)));
  V v_t_248 = heff_intAdd(heff_take_field(v_s_246, 1), v_bi_241);
  V v_t_249 = heff_intAdd(heff_take_field(v_s_246, 2), v_ui_242);
  V v_t_2410 = heff_intAdd(heff_take_field(v_s_246, 3), v_bo_243);
  V v_t_2411 = heff_intAdd(heff_take_field(v_s_246, 4), v_uo_244);
  V v_t_2412 = heff_take_field(v_s_246, 5);
  V v_t_2413;
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_pin_245);
    heff_drop(v_t_2412);
    v_t_2413 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2412);
    v_t_2413 = v_pin_245;
  }
  return ({ V rv_0 = v_t_247; V rv_1 = v_t_248; V rv_2 = v_t_249; V rv_3 = v_t_2410; V rv_4 = v_t_2411; V rv_5 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_s_246, 192ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 61440u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2ecompile_2erepr_2estatsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2estatsWith(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2erepr_2eseen_lam0(V self, V *args);
Clo g_heff_2ecompile_2erepr_2eseen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eseen_entry, 2, 0};

V g_heff_2ecompile_2erepr_2eseen(V v_x1_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Merge: {
    return v_s_241;
  }
  case TAG_Boxed: {
    V v_t_245 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(1LL));
    V v_t_246 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
    V v_t_247 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
    V v_t_248 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(0LL));
    V v_t_249 = heff_take_field(v_s_241, 5);
    V v_t_2410 = heff_bool((heff_dup(v_t_249) == NTAG(TAG_True)));
    heff_drop(v_t_249);
    return ({ V rv_1 = v_t_245; V rv_2 = v_t_246; V rv_3 = v_t_247; V rv_4 = v_t_248; V rv_5 = v_t_2410; V rv_7 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_s_241, 65ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 12291u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 7) = rv_7; rr_; });
  }
  case TAG_BoxedWord: {
    return (g_heff_2ecompile_2erepr_2estatsWith(NTAG(TAG_RepInt), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False), v_s_241));
  }
  case TAG_Element: {
    return ({ V rv_7 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_s_241, 127ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  }
  case TAG_Unboxed: {
    V v_r_2414 = heff_field(v_x1_240, 1);
    V v_t_2415 = (g_heff_2ecompile_2erepr_2ewithRepr(heff_dup(v_r_2414), heff_take_field(v_s_241, 0)));
    V v_t_2416 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
    V v_t_2417 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(1LL));
    V v_t_2418 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
    V v_t_2419 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(0LL));
    V v_t_2420 = heff_take_field(v_s_241, 5);
    V v_t_2421 = heff_bool((heff_dup(v_t_2420) == NTAG(TAG_True)));
    heff_drop(v_t_2420);
    return ({ V rv_0 = v_t_2415; V rv_1 = v_t_2416; V rv_2 = v_t_2417; V rv_3 = v_t_2418; V rv_4 = v_t_2419; V rv_5 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_s_241, 192ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 61440u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  }
  case TAG_Literal: {
    V v_r_2423 = heff_field(v_x1_240, 1);
    V v_t_2424 = (g_heff_2ecompile_2erepr_2ewithRepr(heff_dup(v_r_2423), heff_take_field(v_s_241, 0)));
    V v_t_2425 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
    V v_t_2426 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
    V v_t_2427 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
    V v_t_2428 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(0LL));
    V v_t_2429 = heff_take_field(v_s_241, 5);
    V v_t_2430 = heff_bool((heff_dup(v_t_2429) == NTAG(TAG_True)));
    heff_drop(v_t_2429);
    return ({ V rv_0 = v_t_2424; V rv_1 = v_t_2425; V rv_2 = v_t_2426; V rv_3 = v_t_2427; V rv_4 = v_t_2428; V rv_5 = v_t_2430; V rr_ = heff_rec_reuse_nf(v_s_241, 192ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 61440u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  }
  case TAG_Wants: {
    V v_x12_2432 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_2432)) {
    case TAG_RepV: {
      V v_t_2433 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
      V v_t_2434 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
      V v_t_2435 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(1LL));
      V v_t_2436 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(0LL));
      V v_t_2437 = heff_take_field(v_s_241, 5);
      V v_t_2438 = heff_bool((heff_dup(v_t_2437) == NTAG(TAG_True)));
      heff_drop(v_t_2437);
      return ({ V rv_1 = v_t_2433; V rv_2 = v_t_2434; V rv_3 = v_t_2435; V rv_4 = v_t_2436; V rv_5 = v_t_2438; V rr_ = heff_rec_reuse_nf(v_s_241, 193ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 61443u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
    }
    case TAG_RepFix: {
      V v_t_2440 = (g_heff_2ecompile_2erepr_2ewithRepr(heff_dup(v_x12_2432), heff_take_field(v_s_241, 0)));
      V v_t_2441 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
      V v_t_2442 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
      V v_t_2443 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
      V v_t_2444 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(1LL));
      V v_t_2445 = heff_take_field(v_s_241, 5);
      V v_t_2446 = heff_bool((heff_dup(v_t_2445) == NTAG(TAG_True)));
      heff_drop(v_t_2445);
      return ({ V rv_0 = v_t_2440; V rv_1 = v_t_2441; V rv_2 = v_t_2442; V rv_3 = v_t_2443; V rv_4 = v_t_2444; V rv_5 = v_t_2446; V rr_ = heff_rec_reuse_nf(v_s_241, 192ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 61440u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
    }
    case TAG_RepF64: {
      V v_t_2447 = (g_heff_2ecompile_2erepr_2ewithRepr(heff_dup(v_x12_2432), heff_take_field(v_s_241, 0)));
      V v_t_2448 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
      V v_t_2449 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
      V v_t_2450 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
      V v_t_2451 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(1LL));
      V v_t_2452 = heff_take_field(v_s_241, 5);
      V v_t_2453 = heff_bool((heff_dup(v_t_2452) == NTAG(TAG_True)));
      heff_drop(v_t_2452);
      return ({ V rv_0 = v_t_2447; V rv_1 = v_t_2448; V rv_2 = v_t_2449; V rv_3 = v_t_2450; V rv_4 = v_t_2451; V rv_5 = v_t_2453; V rr_ = heff_rec_reuse_nf(v_s_241, 192ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 61440u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
    }
    case TAG_RepInt: {
      V v_t_2454 = (g_heff_2ecompile_2erepr_2ewithRepr(heff_dup(v_x12_2432), heff_take_field(v_s_241, 0)));
      V v_t_2455 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
      V v_t_2456 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
      V v_t_2457 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
      V v_t_2458 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(1LL));
      V v_t_2459 = heff_take_field(v_s_241, 5);
      V v_t_2460 = heff_bool((heff_dup(v_t_2459) == NTAG(TAG_True)));
      heff_drop(v_t_2459);
      return ({ V rv_0 = v_t_2454; V rv_1 = v_t_2455; V rv_2 = v_t_2456; V rv_3 = v_t_2457; V rv_4 = v_t_2458; V rv_5 = v_t_2460; V rr_ = heff_rec_reuse_nf(v_s_241, 192ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 61440u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
    }
    default: return heff_nomatch(v_x12_2432);
    }
  }
  case TAG_Binds: {
    return v_s_241;
  }
  case TAG_Pinned: {
    V v_t_2463 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
    V v_t_2464 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
    V v_t_2465 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
    V v_t_2466 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(0LL));
    V v_t_2467 = heff_take_field(v_s_241, 5);
    V v_t_2468 = heff_bool(((heff_dup(v_t_2467) == NTAG(TAG_True)) || 1));
    heff_drop(v_t_2467);
    return ({ V rv_1 = v_t_2463; V rv_2 = v_t_2464; V rv_3 = v_t_2465; V rv_4 = v_t_2466; V rv_5 = v_t_2468; V rr_ = heff_rec_reuse_nf(v_s_241, 193ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 61443u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  }
  case TAG_Kept: {
    V v_r_2470 = heff_field(v_x1_240, 1);
    V v_t_2471 = (g_heff_2ecompile_2erepr_2ewithRepr(heff_dup(v_r_2470), heff_take_field(v_s_241, 0)));
    return ({ V rv_0 = v_t_2471; V rv_6 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_r_2470)}); V rr_ = heff_rec_reuse_nf(v_s_241, 190ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 53244u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 6) = rv_6; rr_; });
  }
  case TAG_Often: {
    V v_e_2472 = heff_field(v_x1_240, 0);
    V v_t_2473 = (g_list_2erange(MK_INT(1LL), MK_INT(8LL)));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erepr_2eseen_lam0, 2, 1, (V[]){heff_dup(v_e_2472)}); V a_1 = v_s_241; V a_2 = v_t_2473; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2473); r_; });
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2eseen_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2eseen(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2erepr_2eseen_lam0(V self, V *args) {
  V v_acc_2474 = args[0];
  V v_x_2475 = args[1];
  V v_e_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2475);
  return ({ V a_0 = v_e_2472; V a_1 = v_acc_2474; V r_ = (g_heff_2ecompile_2erepr_2eseen(a_0, a_1)); heff_drop(v_e_2472); r_; });
}
Clo g_heff_2ecompile_2erepr_2eeventName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eeventName_entry, 1, 0};

V g_heff_2ecompile_2erepr_2eeventName(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Merge: {
    V v_x_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_241);
  }
  case TAG_Boxed: {
    V v_x_243 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_243);
  }
  case TAG_BoxedWord: {
    V v_x_244 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_244);
  }
  case TAG_Element: {
    V v_x_245 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_245);
  }
  case TAG_Unboxed: {
    V v_x_246 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_246);
  }
  case TAG_Literal: {
    V v_x_248 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_248);
  }
  case TAG_Wants: {
    V v_x_2410 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2410);
  }
  case TAG_Binds: {
    V v_x_2412 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2412);
  }
  case TAG_Pinned: {
    V v_x_2413 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2413);
  }
  case TAG_Kept: {
    V v_x_2414 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2414);
  }
  case TAG_Often: {
    V v_e_2416 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2416;
    v_x1_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2eeventName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2eeventName(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erepr_2ekeptOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ekeptOne_entry, 4, 0};

V g_heff_2ecompile_2erepr_2ekeptOne(V v_parent_240, V v_stats_241, V v_m_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_Merge: {
    return v_m_242;
  }
  case TAG_Boxed: {
    return v_m_242;
  }
  case TAG_BoxedWord: {
    return v_m_242;
  }
  case TAG_Element: {
    return v_m_242;
  }
  case TAG_Unboxed: {
    return v_m_242;
  }
  case TAG_Literal: {
    return v_m_242;
  }
  case TAG_Wants: {
    return v_m_242;
  }
  case TAG_Binds: {
    V v_x_2415 = heff_field(v_e_243, 0);
    V v_t_2416 = (g_std_2emap_2elookup_24s1930949324x2078207031(v_parent_240, v_x_2415));
    V v_t_2417 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, heff_dup(v_x_2415), v_t_2416));
    HeffT2 v_t_2418 = ({ V a_0 = v_stats_241; V a_1 = v_t_2417; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_2417); r_; });
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      V v_s_2423;
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        V v_x_2422 = v_field_2420;
        v_s_2423 = v_x_2422;
      } else {
        heff_drop(v_field_2420);
        v_s_2423 = heff_dup(g_heff_2ecompile_2erepr_2enoStats_get());
      }
      V v_t_2424 = heff_dup(heff_rfield(v_s_2423, 6));
      V v_r_2430;
      switch (heff_tag_of(v_t_2424)) {
      case TAG_Nothing: {
        V v_t_2425 = heff_dup(heff_rfield(v_s_2423, 5));
        if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
          heff_drop_rec(v_s_2423, 8);
          heff_drop(v_t_2425);
          v_r_2430 = NTAG(TAG_RepV);
        } else {
          heff_drop(v_t_2425);
          V v_r_2426 = (g_heff_2ecompile_2erepr_2edecideOf(heff_dup(v_s_2423), heff_rfield(v_s_2423, 0)));
          switch (heff_tag_of(v_r_2426)) {
          case TAG_RepV: {
            heff_drop_rec(v_s_2423, 8);
            v_r_2430 = v_r_2426;
            break;
          }
          case TAG_RepFix: {
            heff_drop_rec(v_s_2423, 8);
            v_r_2430 = v_r_2426;
            break;
          }
          case TAG_RepF64: {
            heff_drop_rec(v_s_2423, 8);
            v_r_2430 = v_r_2426;
            break;
          }
          case TAG_RepInt: {
            V v_t_2428 = heff_get_n(v_s_2423, 7, 8);
            if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
              heff_drop(v_t_2428);
              v_r_2430 = NTAG(TAG_RepV);
            } else {
              heff_drop(v_t_2428);
              v_r_2430 = NTAG(TAG_RepInt);
            }
            break;
          }
          default: heff_nomatch(v_r_2426);
          }
        }
        break;
      }
      case TAG_Just: {
        V v_r_2429 = heff_field(v_t_2424, 0);
        heff_take_n(v_t_2424, 1ULL, 1);
        heff_drop_rec(v_s_2423, 8);
        v_r_2430 = v_r_2429;
        break;
      }
      default: heff_nomatch(v_t_2424);
      }
      switch (heff_tag_of(v_r_2430)) {
      case TAG_RepV: {
        return v_m_242;
      }
      case TAG_RepFix: {
        return (g_std_2emap_2einsert_24s93785294x875597928(v_m_242, heff_dup(v_x_2415), v_r_2430));
      }
      case TAG_RepF64: {
        return (g_std_2emap_2einsert_24s93785294x875597928(v_m_242, heff_dup(v_x_2415), v_r_2430));
      }
      case TAG_RepInt: {
        return (g_std_2emap_2einsert_24s93785294x875597928(v_m_242, heff_dup(v_x_2415), v_r_2430));
      }
      default: return heff_nomatch(v_r_2430);
      }
    }
  }
  case TAG_Pinned: {
    return v_m_242;
  }
  case TAG_Kept: {
    return v_m_242;
  }
  case TAG_Often: {
    return v_m_242;
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2erepr_2ekeptOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2erepr_2ekeptOne(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ecompile_2erepr_2ereprsWords_lam0(V self, V *args);
Clo g_heff_2ecompile_2erepr_2ereprsWords_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereprsWords_entry, 3, 0};

V g_heff_2ecompile_2erepr_2ereprsWords(V v_sg_240, V v_is_241, V v_d_242) {
top: ;
  V v_evs_248;
  switch (heff_tag_of(v_is_241)) {
  case TAG_Nil: {
    v_evs_248 = (g_heff_2ecompile_2erepr_2edefEvents(v_sg_240, v_d_242));
    break;
  }
  case TAG_Cons: {
    V v_t_245 = (g_heff_2ecompile_2erepr_2ewordParams(v_is_241, v_d_242));
    V v_t_246 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erepr_2easWord_clo), 1, (V[]){v_t_245}));
    V v_t_247 = (g_heff_2ecompile_2erepr_2edefEvents(v_sg_240, v_d_242));
    v_evs_248 = (g_list_2emap(v_t_246, v_t_247));
    break;
  }
  default: heff_nomatch(v_is_241);
  }
  V v_pins_249 = (g_list_2efoldl_24s1134919403x2060330530(heff_dup(g_std_2emap_2eempty_get()), v_evs_248));
  V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_evs_248));
  V v_evs_2414 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erepr_2ereprsWords_lam0, 2, 1, (V[]){v_pins_249}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2410; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
  V v_parent_2415 = (g_list_2efoldl_24s1275727578x1654209034(heff_dup(g_std_2emap_2eempty_get()), v_evs_2414));
  V v_t_2416 = (g_heff_2ecompile_2erepr_2estatsOf(v_parent_2415, v_evs_2414));
  return ({ V a_0 = v_parent_2415; V a_1 = v_t_2416; V a_2 = heff_dup(g_std_2emap_2eempty_get()); V a_3 = v_evs_2414; V r_ = (g_list_2efoldl_24s1674844076x2137676876(a_0, a_1, a_2, a_3)); heff_drop(v_parent_2415); heff_drop(v_t_2416); heff_drop(v_evs_2414); r_; });
}
V g_heff_2ecompile_2erepr_2ereprsWords_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2ereprsWords(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erepr_2ereprsWords_lam0(V self, V *args) {
  V v_acc_2411 = args[0];
  V v_x_2412 = args[1];
  V v_pins_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = ({ V a_0 = v_pins_249; V a_1 = v_x_2412; V r_ = (g_heff_2ecompile_2erepr_2eunpinOne(a_0, a_1)); heff_drop(v_pins_249); r_; });
  return (g_prelude_2e_2b_2b(v_t_2413, v_acc_2411));
}
Clo g_heff_2ecompile_2erepr_2edecidedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2edecidedIn_entry, 3, 0};

V g_heff_2ecompile_2erepr_2edecidedIn(V v_parent_240, V v_stats_241, V v_x_242) {
top: ;
  V v_t_243 = (g_std_2emap_2elookup_24s1930949324x2078207031(v_parent_240, v_x_242));
  V v_t_244 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, v_x_242, v_t_243));
  HeffT2 v_t_245 = ({ V a_0 = v_stats_241; V a_1 = v_t_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_244); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    V v_s_2410;
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_247;
      v_s_2410 = v_x_249;
    } else {
      heff_drop(v_field_247);
      v_s_2410 = heff_dup(g_heff_2ecompile_2erepr_2enoStats_get());
    }
    V v_t_2411 = heff_dup(heff_rfield(v_s_2410, 6));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nothing: {
      V v_t_2412 = heff_dup(heff_rfield(v_s_2410, 5));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop_rec(v_s_2410, 8);
        heff_drop(v_t_2412);
        return NTAG(TAG_RepV);
      } else {
        heff_drop(v_t_2412);
        V v_r_2413 = (g_heff_2ecompile_2erepr_2edecideOf(heff_dup(v_s_2410), heff_rfield(v_s_2410, 0)));
        switch (heff_tag_of(v_r_2413)) {
        case TAG_RepV: {
          heff_drop_rec(v_s_2410, 8);
          return v_r_2413;
        }
        case TAG_RepFix: {
          heff_drop_rec(v_s_2410, 8);
          return v_r_2413;
        }
        case TAG_RepF64: {
          heff_drop_rec(v_s_2410, 8);
          return v_r_2413;
        }
        case TAG_RepInt: {
          V v_t_2415 = heff_get_n(v_s_2410, 7, 8);
          if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
            heff_drop(v_t_2415);
            return NTAG(TAG_RepV);
          } else {
            heff_drop(v_t_2415);
            return NTAG(TAG_RepInt);
          }
        }
        default: return heff_nomatch(v_r_2413);
        }
      }
    }
    case TAG_Just: {
      V v_r_2416 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 1);
      heff_drop_rec(v_s_2410, 8);
      return v_r_2416;
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
}
V g_heff_2ecompile_2erepr_2edecidedIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2edecidedIn(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}