// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_Get 18914
#define TAG_HLocal 25864
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_Put 28059
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SmallU 20221
#define TAG_SpId 35501
#define TAG_Throw 56084
#define TAG_UnequalTys 2248
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_arity 294440695
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_cod 308210
#define LBL_dom 309180
#define LBL_el 9998
#define LBL_failed 665164648
#define LBL_infos 301706655
#define LBL_keys 9783995
#define LBL_left 9813198
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_mel 317518
#define LBL_metas 305145640
#define LBL_msp 317956
#define LBL_mty 317996
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ren 322325
#define LBL_right 309870134
#define LBL_selfKey 62480824
#define LBL_shape 310758331
#define LBL_sol 323594
#define LBL_solStx 1050338738
#define LBL_span 10032145
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_dom__cod__ren[] = {LBL_dom, LBL_cod, LBL_ren};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_mel__mty__msp[] = {LBL_mel, LBL_mty, LBL_msp};
static uint32_t shape_shape__left__right__failed[] = {LBL_shape, LBL_left, LBL_right, LBL_failed};
static uint32_t shape_ty__sol__solStx__arity__name__span[] = {LBL_ty, LBL_sol, LBL_solStx, LBL_arity, LBL_name, LBL_span};
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo;
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2eparams_2eeqLevel(V, V);
V g_heff_2eelab_2eparams_2eeqLevel_entry(V self, V *a);
extern Clo g_heff_2eelab_2eparams_2eeqLevel_clo;
V g_heff_2eelab_2eunify_2eappendL(V, V);
V g_heff_2eelab_2eunify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_clo;
V g_heff_2eelab_2eunify_2eappendL_24dps(V, V, V);
V g_heff_2eelab_2eunify_2eappendL_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_24dps_clo;
V g_heff_2eelab_2eunify_2ecatMaybes_24dps(V, V);
V g_heff_2eelab_2eunify_2ecatMaybes_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ecatMaybes_24dps_clo;
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24dps(V, V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24dps_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747(V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_clo;
V g_heff_2eelab_2eunify_2emetasK(V);
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasK_clo;
V g_heff_2eelab_2eunify_2emetasSpF(V, V, V, V, V);
V g_heff_2eelab_2eunify_2emetasSpF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasSpF_clo;
V g_heff_2eelab_2eunify_2emetasTermF(V, V, V, V, V);
V g_heff_2eelab_2eunify_2emetasTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasTermF_clo;
V g_heff_2eelab_2eunify_2emetasTypeF(V, V, V, V, V);
V g_heff_2eelab_2eunify_2emetasTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasTypeF_clo;
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687(V, V, V, V, V);
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_clo;
V g_heff_2eelab_2eunify_2enewMetaIn(V, V, V, V);
V g_heff_2eelab_2eunify_2enewMetaIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enewMetaIn_clo;
V g_heff_2eelab_2eunify_2enth(V, V);
V g_heff_2eelab_2eunify_2enth_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enth_clo;
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703(V, V, V, V, V);
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_clo;
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610(V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_clo;
V g_heff_2eelab_2eunify_2esubstTermF(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTermF_clo;
V g_heff_2eelab_2eunify_2esubstTyFields(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTyFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTyFields_clo;
V g_heff_2eelab_2eunify_2esubstTyFields_24dps(V, V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTyFields_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTyFields_24dps_clo;
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371(V, V, V, V);
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_clo;
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(V, V);
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_clo;
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_clo;
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2eisFixed(V, V);
V g_heff_2eelab_2evalue_2eisFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eisFixed_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1947501783x1475115781(V, V, V);
V g_list_2emap_24s1947501783x1475115781_entry(V self, V *a);
extern Clo g_list_2emap_24s1947501783x1475115781_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
Clo g_heff_2eelab_2eunify_2emapWithIndexL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_entry, 3, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL(V v_i_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), v_x_243}));
    V v_cell_246 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_heff_2eelab_2eunify_2emapWithIndexL_24dps(heff_intAdd(v_i_240, MK_INT(1LL)), v_f_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eunify_2ecatMaybes_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ecatMaybes_24dps_entry, 2, 0};

V g_heff_2eelab_2eunify_2ecatMaybes_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2ecatMaybes_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2ecatMaybes_24dps(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2eappendL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eappendL_24dps_entry, 3, 0};

V g_heff_2eelab_2eunify_2eappendL_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2eappendL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eappendL_24dps(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eunify_2emetasTypeF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2emetasTypeF_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2emetasTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emetasTypeF_entry, 5, 0};

V g_heff_2eelab_2eunify_2emetasTypeF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_t0_244) {
top: ;
  if (heff_intLe_c(heff_dup(v_depth_242), MK_INT(0LL))) {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    heff_drop(v_t0_244);
    return NTAG(TAG_Nil);
  } else {
    V v_t_246 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_241, v_t0_244));
    switch (heff_tag_of(v_t_246)) {
    case TAG_VU: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VDecode: {
      V v_el_2412 = heff_field(v_t_246, 4);
      heff_take_n(v_t_246, 16ULL, 5);
      V v_t_2413 = heff_tr(heff_call(v_el_2412, 1, (V[]){NTAG(TAG_MkUnit)}));
      return heff_tail(heff_get_n(v_r_240, 0, 3), 3, (V[]){v_depth_242, v_len_243, v_t_2413});
    }
    case TAG_VFunction: {
      V v_dom_2415 = heff_field(v_t_246, 1);
      V v_cod_2416 = heff_field(v_t_246, 2);
      heff_take_n(v_t_246, 6ULL, 5);
      V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 3, (V[]){heff_intSub(heff_dup(v_depth_242), MK_INT(1LL)), heff_dup(v_len_243), heff_dup(v_dom_2415)}));
      V v_x1_2426;
      switch (heff_tag_of(v_cod_2416)) {
      case TAG_MkClo: {
        V v_vs_2421 = heff_field(v_cod_2416, 1);
        V v_body_2422 = heff_field(v_cod_2416, 2);
        heff_take_n(v_cod_2416, 6ULL, 3);
        v_x1_2426 = heff_tr(heff_call(v_body_2422, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2421, heff_clo_n(g_heff_2eelab_2eunify_2emetasTypeF_lam0, 1, 2, (V[]){heff_dup(v_len_243), v_dom_2415})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2425 = heff_field(v_cod_2416, 0);
        heff_take_n(v_cod_2416, 1ULL, 1);
        heff_drop(v_dom_2415);
        v_x1_2426 = v_body_2425;
        break;
      }
      default: heff_nomatch(v_cod_2416);
      }
      V v_t_2430;
      switch (heff_tag_of(v_x1_2426)) {
      case TAG_Nom: {
        V v_x_2427 = heff_field(v_x1_2426, 0);
        heff_take_n(v_x1_2426, 1ULL, 1);
        v_t_2430 = v_x_2427;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2426, 0ULL, 1);
        v_t_2430 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2429 = heff_field(v_x1_2426, 0);
        heff_take_n(v_x1_2426, 1ULL, 1);
        v_t_2430 = v_x_2429;
        break;
      }
      default: heff_nomatch(v_x1_2426);
      }
      V v_t_2431 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), heff_intAdd(v_len_243, MK_INT(1LL)), v_t_2430}));
      return (g_heff_2eelab_2eunify_2eappendL(v_t_2419, v_t_2431));
    }
    case TAG_VRecord: {
      heff_take_n(v_t_246, 0ULL, 4);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VSum: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimInt: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimFloat: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimString: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimRune: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimArray: {
      V v_a_2437 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      return heff_tail(heff_get_n(v_r_240, 1, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, v_a_2437});
    }
    case TAG_VFixed: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
}
V g_heff_2eelab_2eunify_2emetasTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2emetasTypeF(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2emetasTypeF_lam1(V self, V *args) {
  V v_u_2424 = args[0];
  V v_dom_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2424);
  return v_dom_2415;
}
V g_heff_2eelab_2eunify_2emetasTypeF_lam0(V self, V *args) {
  V v_u_2423 = args[0];
  V v_len_243 = heff_env(self)[0];
  V v_dom_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2423);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_len_243}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2emetasTypeF_lam1, 1, 1, (V[]){v_dom_2415}), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2eunify_2emetasK_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2emetasK_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2emetasK_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2emetasK_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emetasK_entry, 1, 0};

V g_heff_2eelab_2eunify_2emetasK(V v_mc_240) {
top: ;
  return heff_rec_n(3, shape_mel__mty__msp, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2emetasK_lam0, 3, 1, (V[]){heff_dup(v_mc_240)}), heff_clo_n(g_heff_2eelab_2eunify_2emetasK_lam1, 3, 1, (V[]){heff_dup(v_mc_240)}), heff_clo_n(g_heff_2eelab_2eunify_2emetasK_lam2, 3, 1, (V[]){heff_dup(v_mc_240)})});
}
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2emetasK(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2emetasK_lam0(V self, V *args) {
  V v_depth_241 = args[0];
  V v_len_242 = args[1];
  V v_v_243 = args[2];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2eelab_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_244; V a_1 = v_mc_240; V a_2 = v_depth_241; V a_3 = v_len_242; V a_4 = v_v_243; V r_ = (g_heff_2eelab_2eunify_2emetasTermF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2eunify_2emetasK_lam1(V self, V *args) {
  V v_depth_245 = args[0];
  V v_len_246 = args[1];
  V v_t_247 = args[2];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2eelab_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_248; V a_1 = v_mc_240; V a_2 = v_depth_245; V a_3 = v_len_246; V a_4 = v_t_247; V r_ = (g_heff_2eelab_2eunify_2emetasTypeF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2eunify_2emetasK_lam2(V self, V *args) {
  V v_depth_249 = args[0];
  V v_len_2410 = args[1];
  V v_sp_2411 = args[2];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = (g_heff_2eelab_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_2412; V a_1 = v_mc_240; V a_2 = v_depth_249; V a_3 = v_len_2410; V a_4 = v_sp_2411; V r_ = (g_heff_2eelab_2eunify_2emetasSpF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); heff_drop(v_sp_2411); r_; });
}
V g_heff_2eelab_2eunify_2esubstTermF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTermF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTermF_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTermF_lam3(V self, V *args);
Clo g_heff_2eelab_2eunify_2esubstTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTermF_entry, 4, 0};

V g_heff_2eelab_2eunify_2esubstTermF(V v_r_240, V v_idxs_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SLocal = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    if (heff_intLt_c(heff_dup(v_i_244), heff_dup(v_d_242))) {
      heff_drop(v_d_242);
      return heff_tag_at_n(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){v_i_244});
    } else {
      V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_idxs_241));
      V v_t_247 = heff_intSub(heff_intSub(v_t_246, MK_INT(1LL)), heff_intSub(heff_dup(v_i_244), heff_dup(v_d_242)));
      V v_t_248 = (g_heff_2eelab_2eunify_2enth(v_idxs_241, v_t_247));
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nothing: {
        heff_drop(v_d_242);
        return heff_tag_at_n(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){v_i_244});
      }
      case TAG_Just: {
        V v_j_249 = heff_field(v_t_248, 0);
        heff_take_n(v_t_248, 1ULL, 1);
        heff_drop(v_i_244);
        return heff_tag_at_n(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){heff_intAdd(v_j_249, v_d_242)});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
  }
  case TAG_SGlobal: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SCode: {
    V v_ty_2411 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_ty_2411}));
    return heff_tag_at_n(v_ru_24t_243_24SCode, TAG_SCode, 1, (V[]){v_t_2412});
  }
  case TAG_SApp: {
    V v_f_2413 = heff_field(v_t_243, 0);
    V v_a_2414 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SApp = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_f_2413}));
    V v_t_2416 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_a_2414}));
    return heff_tag_at_n(v_ru_24t_243_24SApp, TAG_SApp, 2, (V[]){v_t_2415, v_t_2416});
  }
  case TAG_SLam: {
    V v_dd_2417 = heff_field(v_t_243, 0);
    V v_t2_2418 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SLam = heff_take_reuse_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_t2_2418)) {
    case TAG_MkAbs: {
      V v_x_2419 = heff_field(v_t2_2418, 0);
      V v_b_2420 = heff_field(v_t2_2418, 1);
      heff_take_n(v_t2_2418, 3ULL, 2);
      V v_t_2421 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2417}));
      V v_t_2422 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2420}));
      return heff_tag_at_n(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2421, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2419, v_t_2422})});
    }
    case TAG_AbsConst: {
      V v_b_2423 = heff_field(v_t2_2418, 0);
      heff_take_n(v_t2_2418, 1ULL, 1);
      V v_t_2424 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2417}));
      V v_t_2425 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_b_2423}));
      return heff_tag_at_n(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2424, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2425})});
    }
    default: return heff_nomatch(v_t2_2418);
    }
  }
  case TAG_SCons: {
    V v_dct_2426 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCons = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_f_2427 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_242}));
    V v_xs_2428 = heff_take_field(v_dct_2426, 2);
    V v_t_2431 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2428, 0), heff_clo_n(g_heff_2eelab_2eunify_2esubstTermF_lam0, 1, 2, (V[]){v_xs_2428, v_f_2427}));
    V v_t_2432 = ({ V rv_2 = v_t_2431; V rr_ = heff_rec_reuse_nf(v_dct_2426, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SCons, TAG_SCons, 1, (V[]){v_t_2432});
  }
  case TAG_SProj: {
    V v_e_2433 = heff_field(v_t_243, 0);
    V v_l_2434 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SProj = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2433}));
    return heff_tag_at_n(v_ru_24t_243_24SProj, TAG_SProj, 2, (V[]){v_t_2435, v_l_2434});
  }
  case TAG_STag: {
    V v_x_2436 = heff_field(v_t_243, 0);
    V v_as_2437 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24STag = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_f_2438 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_242}));
    V v_t_2441 = heff_arrayGenerate(heff_arrayLength_lent(v_as_2437, 0), heff_clo_n(g_heff_2eelab_2eunify_2esubstTermF_lam1, 1, 2, (V[]){v_as_2437, v_f_2438}));
    return heff_tag_at_n(v_ru_24t_243_24STag, TAG_STag, 2, (V[]){v_x_2436, v_t_2441});
  }
  case TAG_SMatch: {
    V v_e_2442 = heff_field(v_t_243, 0);
    V v_cs_2443 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SMatch = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2444 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_e_2442}));
    V v_xs_2445 = heff_take_field(v_cs_2443, 2);
    V v_t_2452 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2445, 0), heff_clo_n(g_heff_2eelab_2eunify_2esubstTermF_lam2, 1, 3, (V[]){v_xs_2445, v_d_242, v_r_240}));
    V v_t_2453 = ({ V rv_2 = v_t_2452; V rr_ = heff_rec_reuse_nf(v_cs_2443, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SMatch, TAG_SMatch, 2, (V[]){v_t_2444, v_t_2453});
  }
  case TAG_SSpecialize: {
    V v_e_2454 = heff_field(v_t_243, 0);
    V v_l_2455 = heff_field(v_t_243, 1);
    V v_v_2456 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SSpecialize = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2457 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_e_2454}));
    V v_t_2458 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_v_2456}));
    return heff_tag_at_n(v_ru_24t_243_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2457, v_l_2455, v_t_2458});
  }
  case TAG_SIs: {
    V v_e_2459 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIs = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2460 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2459}));
    return heff_tag_at_n(v_ru_24t_243_24SIs, TAG_SIs, 1, (V[]){v_t_2460});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SRec: {
    V v_e_2461 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SRec = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2462 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2461}));
    return heff_tag_at_n(v_ru_24t_243_24SRec, TAG_SRec, 1, (V[]){v_t_2462});
  }
  case TAG_SFix: {
    V v_dd_2463 = heff_field(v_t_243, 0);
    V v_t2_2464 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SFix = heff_take_reuse_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_t2_2464)) {
    case TAG_MkAbs: {
      V v_x_2465 = heff_field(v_t2_2464, 0);
      V v_b_2466 = heff_field(v_t2_2464, 1);
      heff_take_n(v_t2_2464, 3ULL, 2);
      V v_t_2467 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2463}));
      V v_t_2468 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2466}));
      return heff_tag_at_n(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2467, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2465, v_t_2468})});
    }
    case TAG_AbsConst: {
      V v_b_2469 = heff_field(v_t2_2464, 0);
      heff_take_n(v_t2_2464, 1ULL, 1);
      V v_t_2470 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2463}));
      V v_t_2471 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_b_2469}));
      return heff_tag_at_n(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2470, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2471})});
    }
    default: return heff_nomatch(v_t2_2464);
    }
  }
  case TAG_SImplicit: {
    V v_x_2472 = heff_field(v_t_243, 0);
    V v_e_2473 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SImplicit = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2474 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2473}));
    return heff_tag_at_n(v_ru_24t_243_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2472, v_t_2474});
  }
  case TAG_SPrim: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SMetaApp: {
    V v_m_2476 = heff_field(v_t_243, 0);
    V v_ix_2477 = heff_field(v_t_243, 1);
    V v_ty_2478 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SMetaApp = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2486 = heff_arrayGenerate(heff_arrayLength_lent(v_ix_2477, 0), heff_clo_n(g_heff_2eelab_2eunify_2esubstTermF_lam3, 1, 3, (V[]){v_ix_2477, heff_dup(v_d_242), heff_dup(v_idxs_241)}));
    V v_t_2487 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_ty_2478}));
    return heff_tag_at_n(v_ru_24t_243_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2476, v_t_2486, v_t_2487});
  }
  case TAG_SLitInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitBytes: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat32: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2eunify_2esubstTermF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2esubstTermF(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2esubstTermF_lam0(V self, V *args) {
  V v_i_2429 = args[0];
  V v_xs_2428 = heff_env(self)[0];
  V v_f_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_arrayIndex(v_xs_2428, v_i_2429);
  V f_ = v_f_2427;
  args[0] = v_t_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esubstTermF_lam1(V self, V *args) {
  V v_i_2439 = args[0];
  V v_as_2437 = heff_env(self)[0];
  V v_f_2438 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_arrayIndex(v_as_2437, v_i_2439);
  V f_ = v_f_2438;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esubstTermF_lam2(V self, V *args) {
  V v_i_2446 = args[0];
  V v_xs_2445 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_p_2447 = heff_arrayIndex(v_xs_2445, v_i_2446);
  switch (heff_tag_of(v_p_2447)) {
  case TAG_MkPair: {
    V v_xs_2448 = heff_field(v_p_2447, 0);
    V v_b_2449 = heff_field(v_p_2447, 1);
    V v_ru_24p_2447_24MkPair = heff_take_reuse_n(v_p_2447, 3ULL, 2);
    V v_t_2450 = heff_intAdd(v_d_242, heff_arrayLength_lent(v_xs_2448, 0));
    V v_t_2451 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_t_2450, v_b_2449}));
    return heff_tag_at_n(v_ru_24p_2447_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2448, v_t_2451});
  }
  default: return heff_nomatch(v_p_2447);
  }
}
V g_heff_2eelab_2eunify_2esubstTermF_lam3(V self, V *args) {
  V v_i_2479 = args[0];
  V v_ix_2477 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_idxs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_i_2480 = heff_arrayIndex(v_ix_2477, v_i_2479);
  if (heff_intLt_c(heff_dup(v_i_2480), heff_dup(v_d_242))) {
    heff_drop(v_d_242);
    heff_drop(v_idxs_241);
    return v_i_2480;
  } else {
    V v_t_2482 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_idxs_241));
    V v_t_2483 = heff_intSub(heff_intSub(v_t_2482, MK_INT(1LL)), heff_intSub(heff_dup(v_i_2480), heff_dup(v_d_242)));
    V v_t_2484 = ({ V a_0 = v_idxs_241; V a_1 = v_t_2483; V r_ = (g_heff_2eelab_2eunify_2enth(a_0, a_1)); heff_drop(v_idxs_241); r_; });
    switch (heff_tag_of(v_t_2484)) {
    case TAG_Nothing: {
      heff_drop(v_d_242);
      return v_i_2480;
    }
    case TAG_Just: {
      V v_j_2485 = heff_field(v_t_2484, 0);
      heff_take_n(v_t_2484, 1ULL, 1);
      heff_drop(v_i_2480);
      return heff_intAdd(v_j_2485, v_d_242);
    }
    default: return heff_nomatch(v_t_2484);
    }
  }
}
Clo g_heff_2eelab_2eunify_2esubstTyFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTyFields_entry, 4, 0};

V g_heff_2eelab_2eunify_2esubstTyFields(V v_r_240, V v_d_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ty_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_intAdd(heff_dup(v_d_241), heff_dup(v_i_242)), v_ty_244}));
    V v_cell_247 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_heff_2eelab_2eunify_2esubstTyFields_24dps(v_r_240, v_d_241, heff_intAdd(v_i_242, MK_INT(1LL)), v_rest_245, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eunify_2esubstTyFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esubstTyFields(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2eunify_2esubstTyFields_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTyFields_24dps_entry, 5, 0};

V g_heff_2eelab_2eunify_2esubstTyFields_24dps(V v_r_240, V v_d_241, V v_i_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_241);
    heff_drop(v_i_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_ty_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_intAdd(heff_dup(v_d_241), heff_dup(v_i_242)), v_ty_245}));
    V v_cell_248 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_r_240;
    V t_1 = v_d_241;
    V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
    V t_3 = v_rest_246;
    V t_4 = v_cell_248;
    v_r_240 = t_0;
    v_d_241 = t_1;
    v_i_242 = t_2;
    v_x4_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eunify_2esubstTyFields_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esubstTyFields_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2eelab_2eunify_2enewMetaIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2enewMetaIn_entry, 4, 0};

V g_heff_2eelab_2eunify_2enewMetaIn(V v_entry_240, V v_arity_241, V v_ty_242, V v_c_243) {
top: ;
  V v_t_244 = ({ V rv_0 = v_ty_242; V rv_1 = NTAG(TAG_Nothing); V rv_2 = NTAG(TAG_Nothing); V rv_3 = v_arity_241; V rr_ = heff_rec_reuse_nf(v_entry_240, 48ULL, 6, shape_ty__sol__solStx__arity__name__span, 3840u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_mc_245 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(heff_rfield(v_c_243, 4)), v_t_244, heff_take_field(v_c_243, 3)));
  V v_t_246 = heff_intAdd(heff_take_field(v_c_243, 4), MK_INT(1LL));
  return ({ V rv_3 = v_mc_245; V rv_4 = v_t_246; V rr_ = heff_rec_reuse_nf(v_c_243, 231ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 64575u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2eelab_2eunify_2enewMetaIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2enewMetaIn(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_entry, 2, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747(V v_i_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_t_249;
      switch (heff_tag_of(v_a_244)) {
      case TAG_PVar: {
        V v_a_246 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 1);
        switch (heff_tag_of(v_a_245)) {
        case TAG_PVar: {
          V v_a_247 = heff_field(v_a_245, 0);
          heff_take_n(v_a_245, 1ULL, 1);
          v_t_249 = heff_intEq(v_a_246, v_a_247);
          break;
        }
        case TAG_PSelf: {
          heff_drop(v_a_246);
          v_t_249 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_a_245)) {
        case TAG_PVar: {
          heff_take_n(v_a_245, 0ULL, 1);
          v_t_249 = NTAG(TAG_False);
          break;
        }
        case TAG_PSelf: {
          v_t_249 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_t_249);
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_i_240)});
      } else {
        heff_drop(v_t_249);
        v_t_2410 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps(heff_intAdd(v_i_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_entry, 3, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps(V v_i_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_241, 0);
    V v_xs_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_i_240), v_x_243}), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_xs_244;
    V t_2 = v_cell_245;
    v_i_240 = t_0;
    v_x3_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_entry, 5, 0};

V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703(V v_cs_240, V v_l_241, V v_r_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_lam0, 1, 3, (V[]){v_cs_240, v_l_241, v_r_242})})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_lam1, 1, 2, (V[]){v_hd_243, v_k_244})});
}
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_cs_240 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_r_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_246 = heff_rec_n(4, shape_shape__left__right__failed, (V[]){v_cs_240, v_l_241, v_r_242, NTAG(TAG_False)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_take_field(v_c_245, 5)});
  return ({ V rv_5 = v_t_247; V rr_ = heff_rec_reuse_nf(v_c_245, 223ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2410, NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tr(heff_call(heff_take_field(v_hd_243, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})}));
  V f_ = heff_get_n(v_hd_243, 1, 3);
  heff_room[0] = v_t_2412;
  heff_room[1] = v_k_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam6(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_245 = heff_field(v_x6_244, 0);
    V v_l_246 = heff_field(v_x6_244, 1);
    V v_f_247 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_248 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), MK_INT(1LL));
    V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 1)), MK_INT(1LL));
    V v_t_2410 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(heff_rfield(v_pr_242, 0)), heff_take_field(v_pr_242, 1), heff_take_field(v_pr_242, 2)));
    V v_pr_2411 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_248, v_t_249, v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_pr_242, 0, 3)});
    V v_v_2414 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2412, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_t_2416 = heff_tr(heff_call(v_f_247, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_246, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam1, 1, 1, (V[]){v_v_2414})})}));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam2, 2, 5, (V[]){v_t_2416, v_g_240, v_m_241, v_pr_2411, v_x_245});
  }
  case TAG_CloConst: {
    V v_t_2427 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam6, 2, 4, (V[]){v_t_2427, v_g_240, v_m_241, v_pr_242});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_dom_243;
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_v_2414;
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2411 = heff_env(self)[2];
  V v_a_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(v_g_240, v_m_241, v_pr_2411, v_a_2421, v_hd_2422, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam4, 1, 1, (V[]){v_k_2423})));
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_245, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_t_2416 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_2411 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2425;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_Nom: {
    V v_a_2419 = heff_field(v_t_2416, 0);
    heff_take_n(v_t_2416, 1ULL, 1);
    v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2419}));
    break;
  }
  case TAG_Describe: {
    V v_a_2420 = heff_field(v_t_2416, 0);
    heff_take_n(v_t_2416, 1ULL, 1);
    v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2420}));
    break;
  }
  case TAG_Become: {
    V v_a_2421 = heff_field(v_t_2416, 0);
    heff_take_n(v_t_2416, 1ULL, 1);
    v_t_2425 = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam3, 2, 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2421});
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V f_ = v_t_2425;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam5, 1, 2, (V[]){v_k_2418, v_x_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam8(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2434;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam7(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(v_g_240, v_m_241, v_pr_242, v_a_2432, v_hd_2433, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam8, 1, 1, (V[]){v_k_2434})));
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2429;
  args[0] = heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam6(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_t_2427 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2436;
  switch (heff_tag_of(v_t_2427)) {
  case TAG_Nom: {
    V v_a_2430 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2430}));
    break;
  }
  case TAG_Describe: {
    V v_a_2431 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2431}));
    break;
  }
  case TAG_Become: {
    V v_a_2432 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam7, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2432});
    break;
  }
  default: heff_nomatch(v_t_2427);
  }
  V f_ = v_t_2436;
  args[0] = v_hd_2428;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam9, 1, 1, (V[]){v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam0, 2, 0};
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_entry, 2, 0};

V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam1, 2, 3, (V[]){v_c_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(v_f_240, v_xs_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam3, 1, 2, (V[]){v_k_248, v_x_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam2, 1, 4, (V[]){v_f_240, v_xs_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_entry, 8, 0};

V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106(V v_g_240, V v_occursM_241, V v_storeM_242, V v_entry_243, V v_n_244, V v_kept_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_248 = heff_rec_n(3, shape_dom__cod__ren, (V[]){heff_dup(heff_rfield(v_entry_243, 3)), MK_INT(0LL), heff_dup(g_map_2eempty_get())});
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(heff_dup(v_g_240), v_occursM_241, v_t_248, heff_dup(heff_rfield(v_entry_243, 0)), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam0, 1, 7, (V[]){v_kept_245, v_g_240, v_entry_243, v_hd_246, v_n_244, v_storeM_242, v_k_247})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_v_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V f_ = v_k_247;
  args[0] = v_v_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_storeM_242 = heff_env(self)[0];
  V v_t_2419 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_v_2424 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2425);
  return (g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371(v_storeM_242, v_t_2419, v_hd_246, heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam3, 1, 2, (V[]){v_k_247, v_v_2424})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_n_244 = heff_env(self)[0];
  V v_kept_245 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_storeM_242 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2417 = (g_list_2emap_24s1947501783x1475115781(heff_dup(v_n_244), MK_INT(1LL), v_kept_245));
  V v_t_2418 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_x_2416, heff_arrayFromList(v_t_2417), v_x_249});
  V v_t_2419 = (g_heff_2eelab_2eunify_2elamsU(v_n_244, v_t_2418));
  V v_x1_2420 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_N), heff_dup(v_t_2419), NTAG(TAG_LNil)));
  V v_v_2424;
  switch (heff_tag_of(v_x1_2420)) {
  case TAG_Nom: {
    V v_x_2421 = heff_field(v_x1_2420, 0);
    heff_take_n(v_x1_2420, 1ULL, 1);
    v_v_2424 = v_x_2421;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2420, 0ULL, 1);
    v_v_2424 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2423 = heff_field(v_x1_2420, 0);
    heff_take_n(v_x1_2420, 1ULL, 1);
    v_v_2424 = v_x_2423;
    break;
  }
  default: heff_nomatch(v_x1_2420);
  }
  return (g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610(heff_dup(v_storeM_242), heff_dup(v_v_2424), heff_dup(v_t_2419), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam2, 1, 5, (V[]){v_storeM_242, v_t_2419, v_hd_246, v_k_247, v_v_2424})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_kept_245 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_entry_243 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_n_244 = heff_env(self)[4];
  V v_storeM_242 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_kept_245));
  V v_x1_2411 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(heff_dup(v_g_240), NTAG(TAG_N), heff_dup(v_x_249), NTAG(TAG_LNil)));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2412;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    v_t_2415 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  return (g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687(v_entry_243, v_t_2410, v_t_2415, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam1, 1, 7, (V[]){v_n_244, v_kept_245, v_x_249, v_g_240, v_storeM_242, v_hd_246, v_k_247})));
}
HEFF_LIT(g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_str0, 1, "x");
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_entry, 6, 0};

V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784(V v_g_240, V v_cs_241, V v_a_242, V v_b_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    V v_u_246 = heff_dup(heff_field(v_a_242, 0));
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_u_27_247 = heff_dup(heff_field(v_b_243, 0));
      V v_t_248;
      switch (heff_tag_of(v_u_246)) {
      case TAG_SmallU: {
        switch (heff_tag_of(v_u_27_247)) {
        case TAG_SmallU: {
          v_t_248 = NTAG(TAG_True);
          break;
        }
        case TAG_LargeU: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_u_27_247);
        }
        break;
      }
      case TAG_LargeU: {
        switch (heff_tag_of(v_u_27_247)) {
        case TAG_SmallU: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_LargeU: {
          v_t_248 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_u_27_247);
        }
        break;
      }
      default: heff_nomatch(v_u_246);
      }
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop_rec(v_cs_241, 2);
        heff_drop_tag(v_a_242, 1);
        heff_drop_tag(v_b_243, 1);
        heff_drop_rec(v_z_244, 3);
        heff_drop(v_t_248);
        return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
      } else {
        heff_drop(v_t_248);
        V v_t_249 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
        V v_t_2410 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})}));
        return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2410, v_z_245});
      }
    }
    case TAG_VDecode: {
      heff_drop(v_u_246);
      V v_t_2416 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2417 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2417, v_z_245});
    }
    case TAG_VFunction: {
      heff_drop(v_u_246);
      V v_t_2423 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2424 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2424, v_z_245});
    }
    case TAG_VRecord: {
      heff_drop(v_u_246);
      V v_t_2429 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2430 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2430, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_u_246);
      V v_t_2432 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2433 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2433, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_u_246);
      V v_t_2434 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2435 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2435, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_u_246);
      V v_t_2436 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2437 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2437, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_u_246);
      V v_t_2438 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2439 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2439, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_u_246);
      V v_t_2440 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2441 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2441, v_z_245});
    }
    case TAG_VPrimArray: {
      heff_drop(v_u_246);
      V v_t_2443 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2444 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2444, v_z_245});
    }
    case TAG_VFixed: {
      heff_drop(v_u_246);
      V v_t_2446 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2447 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2447, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VDecode: {
    V v_h_2448 = heff_dup(heff_field(v_a_242, 0));
    V v_sp_2449 = heff_dup(heff_field(v_a_242, 1));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_h_2448);
      heff_drop(v_sp_2449);
      V v_t_2454 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2455 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2455, v_z_245});
    }
    case TAG_VDecode: {
      V v_h_27_2456 = heff_field(v_b_243, 0);
      V v_sp_27_2457 = heff_field(v_b_243, 1);
      heff_take_n(v_b_243, 3ULL, 5);
      heff_drop_tag(v_a_242, 5);
      V v_t_2461 = (g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672(v_g_240, v_cs_241, v_h_2448, v_sp_2449, v_h_27_2456, v_sp_27_2457));
      return heff_tail(v_t_2461, 2, (V[]){v_z_244, v_z_245});
    }
    case TAG_VFunction: {
      heff_drop(v_g_240);
      heff_drop(v_h_2448);
      heff_drop(v_sp_2449);
      V v_t_2467 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2468 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2467})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2468, v_z_245});
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_h_2448);
      heff_drop(v_sp_2449);
      V v_t_2473 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2474 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2474, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_h_2448);
      heff_drop(v_sp_2449);
      V v_t_2476 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2477 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2477, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_h_2448);
      heff_drop(v_sp_2449);
      V v_t_2478 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2479 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2479, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_h_2448);
      heff_drop(v_sp_2449);
      V v_t_2480 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2481 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2481, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_h_2448);
      heff_drop(v_sp_2449);
      V v_t_2482 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2483 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2482})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2483, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_h_2448);
      heff_drop(v_sp_2449);
      V v_t_2484 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2485 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2485, v_z_245});
    }
    case TAG_VPrimArray: {
      heff_drop(v_g_240);
      heff_drop(v_h_2448);
      heff_drop(v_sp_2449);
      V v_t_2487 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2488 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2487})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2488, v_z_245});
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_h_2448);
      heff_drop(v_sp_2449);
      V v_t_2490 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2491 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2491, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VFunction: {
    V v_level_2492 = heff_dup(heff_field(v_a_242, 0));
    V v_dom_2493 = heff_dup(heff_field(v_a_242, 1));
    V v_cod_2494 = heff_dup(heff_field(v_a_242, 2));
    V v_implicit_2495 = heff_dup(heff_field(v_a_242, 3));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_level_2492);
      heff_drop(v_dom_2493);
      heff_drop(v_cod_2494);
      heff_drop(v_implicit_2495);
      V v_t_2498 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2499 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2498})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2499, v_z_245});
    }
    case TAG_VDecode: {
      heff_drop(v_g_240);
      heff_drop(v_level_2492);
      heff_drop(v_dom_2493);
      heff_drop(v_cod_2494);
      heff_drop(v_implicit_2495);
      V v_t_24105 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24106 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24105})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24106, v_z_245});
    }
    case TAG_VFunction: {
      V v_level_27_24107 = heff_dup(heff_field(v_b_243, 0));
      V v_dom_27_24108 = heff_dup(heff_field(v_b_243, 1));
      V v_cod_27_24109 = heff_dup(heff_field(v_b_243, 2));
      V v_implicit_27_24110 = heff_dup(heff_field(v_b_243, 3));
      V v_t_24112 = ({ V a_0 = v_level_2492; V a_1 = v_level_27_24107; V r_ = (g_heff_2eelab_2eparams_2eeqLevel(a_0, a_1)); heff_drop(v_level_2492); heff_drop(v_level_27_24107); r_; });
      V v_t_24113;
      if ((heff_dup(v_t_24112) == NTAG(TAG_True))) {
        heff_drop(v_t_24112);
        switch (heff_tag_of(v_implicit_2495)) {
        case TAG_Expl: {
          switch (heff_tag_of(v_implicit_27_24110)) {
          case TAG_Expl: {
            v_t_24113 = NTAG(TAG_True);
            break;
          }
          case TAG_Impl: {
            v_t_24113 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_24113 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_24110);
          }
          break;
        }
        case TAG_Impl: {
          switch (heff_tag_of(v_implicit_27_24110)) {
          case TAG_Expl: {
            v_t_24113 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_24113 = NTAG(TAG_True);
            break;
          }
          case TAG_Inst: {
            v_t_24113 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_24110);
          }
          break;
        }
        case TAG_Inst: {
          switch (heff_tag_of(v_implicit_27_24110)) {
          case TAG_Expl: {
            v_t_24113 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_24113 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_24113 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_implicit_27_24110);
          }
          break;
        }
        default: heff_nomatch(v_implicit_2495);
        }
      } else {
        heff_drop(v_implicit_2495);
        heff_drop(v_implicit_27_24110);
        heff_drop(v_t_24112);
        v_t_24113 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_24113) == NTAG(TAG_True))) {
        heff_drop_tag(v_a_242, 5);
        heff_drop_tag(v_b_243, 5);
        heff_drop(v_t_24113);
        HEFF_LAST return g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_dom_2493), v_dom_27_24108, heff_dup(v_z_244), heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam0, 1, 7, (V[]){v_cs_241, v_dom_2493, v_cod_2494, v_cod_27_24109, v_g_240, v_z_244, v_z_245}));
      } else {
        heff_drop(v_g_240);
        heff_drop(v_dom_2493);
        heff_drop(v_cod_2494);
        heff_drop(v_dom_27_24108);
        heff_drop(v_cod_27_24109);
        heff_drop(v_t_24113);
        V v_t_24145 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
        V v_t_24146 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24145})}));
        return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24146, v_z_245});
      }
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_level_2492);
      heff_drop(v_dom_2493);
      heff_drop(v_cod_2494);
      heff_drop(v_implicit_2495);
      V v_t_24151 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24152 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24151})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24152, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_level_2492);
      heff_drop(v_dom_2493);
      heff_drop(v_cod_2494);
      heff_drop(v_implicit_2495);
      V v_t_24154 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24155 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24154})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24155, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_level_2492);
      heff_drop(v_dom_2493);
      heff_drop(v_cod_2494);
      heff_drop(v_implicit_2495);
      V v_t_24156 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24157 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24156})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24157, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_level_2492);
      heff_drop(v_dom_2493);
      heff_drop(v_cod_2494);
      heff_drop(v_implicit_2495);
      V v_t_24158 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24159 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24158})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24159, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_level_2492);
      heff_drop(v_dom_2493);
      heff_drop(v_cod_2494);
      heff_drop(v_implicit_2495);
      V v_t_24160 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24161 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24160})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24161, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_level_2492);
      heff_drop(v_dom_2493);
      heff_drop(v_cod_2494);
      heff_drop(v_implicit_2495);
      V v_t_24162 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24163 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24162})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24163, v_z_245});
    }
    case TAG_VPrimArray: {
      heff_drop(v_g_240);
      heff_drop(v_level_2492);
      heff_drop(v_dom_2493);
      heff_drop(v_cod_2494);
      heff_drop(v_implicit_2495);
      V v_t_24165 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24166 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24165})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24166, v_z_245});
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_level_2492);
      heff_drop(v_dom_2493);
      heff_drop(v_cod_2494);
      heff_drop(v_implicit_2495);
      V v_t_24168 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24169 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24168})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24169, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VRecord: {
    heff_drop(v_g_240);
    V v_t_24174 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
    V v_t_24175 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24174})}));
    return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24175, v_z_245});
  }
  case TAG_VSum: {
    heff_drop(v_g_240);
    V v_t_24177 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
    V v_t_24178 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24177})}));
    return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24178, v_z_245});
  }
  case TAG_VPrimInt: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24180 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24181 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24180})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24181, v_z_245});
    }
    case TAG_VDecode: {
      V v_t_24187 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24188 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24187})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24188, v_z_245});
    }
    case TAG_VFunction: {
      V v_t_24194 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24195 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24194})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24195, v_z_245});
    }
    case TAG_VRecord: {
      V v_t_24200 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24201 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24200})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24201, v_z_245});
    }
    case TAG_VSum: {
      V v_t_24203 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24204 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24203})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24204, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_VPrimFloat: {
      V v_t_24205 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24206 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24205})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24206, v_z_245});
    }
    case TAG_VPrimString: {
      V v_t_24207 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24208 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24207})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24208, v_z_245});
    }
    case TAG_VPrimRune: {
      V v_t_24209 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24210 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24209})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24210, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_t_24212 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24213 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24212})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24213, v_z_245});
    }
    case TAG_VFixed: {
      V v_t_24215 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24216 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24215})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24216, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimFloat: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24218 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24219 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24218})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24219, v_z_245});
    }
    case TAG_VDecode: {
      V v_t_24225 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24226 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24225})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24226, v_z_245});
    }
    case TAG_VFunction: {
      V v_t_24232 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24233 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24232})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24233, v_z_245});
    }
    case TAG_VRecord: {
      V v_t_24238 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24239 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24238})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24239, v_z_245});
    }
    case TAG_VSum: {
      V v_t_24241 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24242 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24241})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24242, v_z_245});
    }
    case TAG_VPrimInt: {
      V v_t_24243 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24244 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24243})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24244, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_VPrimString: {
      V v_t_24245 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24246 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24245})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24246, v_z_245});
    }
    case TAG_VPrimRune: {
      V v_t_24247 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24248 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24247})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24248, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_t_24250 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24251 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24250})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24251, v_z_245});
    }
    case TAG_VFixed: {
      V v_t_24253 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24254 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24253})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24254, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimString: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24256 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24257 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24256})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24257, v_z_245});
    }
    case TAG_VDecode: {
      V v_t_24263 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24264 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24263})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24264, v_z_245});
    }
    case TAG_VFunction: {
      V v_t_24270 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24271 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24270})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24271, v_z_245});
    }
    case TAG_VRecord: {
      V v_t_24276 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24277 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24276})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24277, v_z_245});
    }
    case TAG_VSum: {
      V v_t_24279 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24280 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24279})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24280, v_z_245});
    }
    case TAG_VPrimInt: {
      V v_t_24281 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24282 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24281})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24282, v_z_245});
    }
    case TAG_VPrimFloat: {
      V v_t_24283 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24284 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24283})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24284, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_VPrimRune: {
      V v_t_24285 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24286 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24285})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24286, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_t_24288 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24289 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24288})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24289, v_z_245});
    }
    case TAG_VFixed: {
      V v_t_24291 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24292 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24291})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24292, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimRune: {
    heff_drop(v_g_240);
    V v_t_24311;
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      v_t_24311 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      v_t_24311 = NTAG(TAG_False);
      break;
    }
    case TAG_VFunction: {
      v_t_24311 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24311 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24311 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24311 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24311 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24311 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24311 = NTAG(TAG_True);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24311 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24311 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_b_243);
    }
    if ((heff_dup(v_t_24311) == NTAG(TAG_True))) {
      heff_drop_rec(v_cs_241, 2);
      heff_drop(v_b_243);
      heff_drop_rec(v_z_244, 3);
      heff_drop(v_t_24311);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    } else {
      heff_drop(v_t_24311);
      V v_t_24312 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24313 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24312})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24313, v_z_245});
    }
  }
  case TAG_VPrimArray: {
    V v_x_24314 = heff_dup(heff_field(v_a_242, 0));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_x_24314);
      V v_t_24316 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24317 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24316})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24317, v_z_245});
    }
    case TAG_VDecode: {
      heff_drop(v_g_240);
      heff_drop(v_x_24314);
      V v_t_24323 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24324 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24323})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24324, v_z_245});
    }
    case TAG_VFunction: {
      heff_drop(v_g_240);
      heff_drop(v_x_24314);
      V v_t_24330 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24331 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24330})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24331, v_z_245});
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_x_24314);
      V v_t_24336 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24337 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24336})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24337, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_x_24314);
      V v_t_24339 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24340 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24339})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24340, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_x_24314);
      V v_t_24341 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24342 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24341})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24342, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_x_24314);
      V v_t_24343 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24344 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24343})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24344, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_x_24314);
      V v_t_24345 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24346 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24345})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24346, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_x_24314);
      V v_t_24347 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24348 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24347})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24348, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_y_24349 = heff_field(v_b_243, 0);
      heff_take_n(v_b_243, 1ULL, 1);
      heff_drop_tag(v_a_242, 1);
      HEFF_LAST return g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(v_g_240, v_cs_241, v_x_24314, v_y_24349, v_z_244, v_z_245);
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_x_24314);
      V v_t_24351 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24352 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24351})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24352, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VFixed: {
    V v_w_24353 = heff_dup(heff_field(v_a_242, 0));
    heff_drop(v_g_240);
    V v_t_24354 = ({ V a_0 = v_w_24353; V a_1 = v_b_243; V r_ = (g_heff_2eelab_2evalue_2eisFixed(a_0, a_1)); heff_drop(v_w_24353); r_; });
    if ((heff_dup(v_t_24354) == NTAG(TAG_True))) {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_tag(v_a_242, 1);
      heff_drop(v_b_243);
      heff_drop_rec(v_z_244, 3);
      heff_drop(v_t_24354);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    } else {
      heff_drop(v_t_24354);
      V v_t_24355 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24356 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24355})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24356, v_z_245});
    }
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam1(V self, V *args) {
  V v_u_24116 = args[0];
  V v_dom_2493 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24116);
  return v_dom_2493;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam2(V self, V *args) {
  V v_w_24121 = args[0];
  V v_v_24117 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24121);
  return v_v_24117;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam3(V self, V *args) {
  V v_w_24131 = args[0];
  V v_v_24117 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24131);
  return v_v_24117;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam0(V self, V *args) {
  V v_x_24114 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_dom_2493 = heff_env(self)[1];
  V v_cod_2494 = heff_env(self)[2];
  V v_cod_27_24109 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_24114);
  V v_t_24115 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_cs_241, 0))});
  V v_v_24117 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_24115, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam1, 1, 1, (V[]){v_dom_2493}), NTAG(TAG_Nothing)));
  V v_x1_24123;
  switch (heff_tag_of(v_cod_2494)) {
  case TAG_MkClo: {
    V v_vs_24119 = heff_dup(heff_field(v_cod_2494, 1));
    V v_body_24120 = heff_dup(heff_field(v_cod_2494, 2));
    v_x1_24123 = heff_tr(heff_call(v_body_24120, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_24119, heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam2, 1, 1, (V[]){heff_dup(v_v_24117)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24122 = heff_dup(heff_field(v_cod_2494, 0));
    v_x1_24123 = v_body_24122;
    break;
  }
  default: heff_nomatch(v_cod_2494);
  }
  V v_a_24127;
  switch (heff_tag_of(v_x1_24123)) {
  case TAG_Nom: {
    V v_x_24124 = heff_field(v_x1_24123, 0);
    heff_take_n(v_x1_24123, 1ULL, 1);
    v_a_24127 = v_x_24124;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24123, 0ULL, 1);
    v_a_24127 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24126 = heff_field(v_x1_24123, 0);
    heff_take_n(v_x1_24123, 1ULL, 1);
    v_a_24127 = v_x_24126;
    break;
  }
  default: heff_nomatch(v_x1_24123);
  }
  V v_x1_24133;
  switch (heff_tag_of(v_cod_27_24109)) {
  case TAG_MkClo: {
    V v_vs_24129 = heff_field(v_cod_27_24109, 1);
    V v_body_24130 = heff_field(v_cod_27_24109, 2);
    heff_take_n(v_cod_27_24109, 6ULL, 3);
    v_x1_24133 = heff_tr(heff_call(v_body_24130, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_24129, heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam3, 1, 1, (V[]){v_v_24117})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24132 = heff_field(v_cod_27_24109, 0);
    heff_take_n(v_cod_27_24109, 1ULL, 1);
    heff_drop(v_v_24117);
    v_x1_24133 = v_body_24132;
    break;
  }
  default: heff_nomatch(v_cod_27_24109);
  }
  V v_b_24137;
  switch (heff_tag_of(v_x1_24133)) {
  case TAG_Nom: {
    V v_x_24134 = heff_field(v_x1_24133, 0);
    heff_take_n(v_x1_24133, 1ULL, 1);
    v_b_24137 = v_x_24134;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24133, 0ULL, 1);
    v_b_24137 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24136 = heff_field(v_x1_24133, 0);
    heff_take_n(v_x1_24133, 1ULL, 1);
    v_b_24137 = v_x_24136;
    break;
  }
  default: heff_nomatch(v_x1_24133);
  }
  V v_t_24138 = heff_intAdd(heff_take_field(v_cs_241, 0), MK_INT(1LL));
  V v_t_24143;
  switch (heff_tag_of(v_cod_2494)) {
  case TAG_MkClo: {
    V v_n_24139 = heff_field(v_cod_2494, 0);
    heff_take_n(v_cod_2494, 1ULL, 3);
    v_t_24143 = v_n_24139;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2494, 0ULL, 1);
    v_t_24143 = ((V)&g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_str0);
    break;
  }
  default: heff_nomatch(v_cod_2494);
  }
  V v_t_24144 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24143, heff_get_n(v_cs_241, 1, 2)});
  return (g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(v_g_240, heff_rec_n(2, shape_len__names, (V[]){v_t_24138, v_t_24144}), v_a_24127, v_b_24137, v_z_244, v_z_245));
}