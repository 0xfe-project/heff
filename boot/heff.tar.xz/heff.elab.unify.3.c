// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_Get 18914
#define TAG_HLocal 25864
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalTys 2248
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_arity 294440695
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_dom 309180
#define LBL_el 9998
#define LBL_infos 301706655
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_mel 317518
#define LBL_metas 305145640
#define LBL_msp 317956
#define LBL_mty 317996
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_selfKey 62480824
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_mel__mty__msp[] = {LBL_mel, LBL_mty, LBL_msp};
V g_heff_2eelab_2eparams_2eeqLevel(V, V);
V g_heff_2eelab_2eparams_2eeqLevel_entry(V self, V *a);
extern Clo g_heff_2eelab_2eparams_2eeqLevel_clo;
V g_heff_2eelab_2eunify_2eappendL(V, V);
V g_heff_2eelab_2eunify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_clo;
V g_heff_2eelab_2eunify_2eappendL_24dps(V, V, V);
V g_heff_2eelab_2eunify_2eappendL_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_24dps_clo;
HeffT2 g_heff_2eelab_2eunify_2eapproxEntry_24cpr(V, V, V, V, V);
HeffT2 g_heff_2eelab_2eunify_2eapproxWith_24cpr(V, V, V, V, V, V);
HeffT2 g_heff_2eelab_2eunify_2eappsRev_24cpr(V);
V g_heff_2eelab_2eunify_2eiterateLift(V, V);
V g_heff_2eelab_2eunify_2eiterateLift_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eiterateLift_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24dps(V, V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24dps_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_clo;
V g_heff_2eelab_2eunify_2emetasK(V);
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasK_clo;
V g_heff_2eelab_2eunify_2emetasSpF(V, V, V, V, V);
V g_heff_2eelab_2eunify_2emetasSpF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasSpF_clo;
V g_heff_2eelab_2eunify_2emetasTermF(V, V, V, V, V);
V g_heff_2eelab_2eunify_2emetasTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasTermF_clo;
V g_heff_2eelab_2eunify_2emetasTypeF(V, V, V, V, V);
V g_heff_2eelab_2eunify_2emetasTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasTypeF_clo;
V g_heff_2eelab_2eunify_2enominalBody(V);
V g_heff_2eelab_2eunify_2enominalBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enominalBody_clo;
HeffT2 g_heff_2eelab_2eunify_2enominalOf_24cpr(V, V, V);
HeffT2 g_heff_2eelab_2eunify_2enth_24cpr(V, V);
V g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474(V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474_clo;
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_clo;
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_clo;
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_clo;
V g_heff_2eelab_2eunify_2esubstTermF(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTermF_clo;
V g_heff_2eelab_2eunify_2esubstTyFields_24dps(V, V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTyFields_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTyFields_24dps_clo;
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_clo;
V g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2eisFixed(V, V);
V g_heff_2eelab_2evalue_2eisFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eisFixed_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_list_2efoldl_24s1583117218x1471782720(V, V);
V g_list_2efoldl_24s1583117218x1471782720_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1583117218x1471782720_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
Clo g_heff_2eelab_2eunify_2emapWithIndexL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_entry, 3, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL(V v_i_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), v_x_243}));
    V v_cell_246 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_heff_2eelab_2eunify_2emapWithIndexL_24dps(heff_box_word((heff_unbox_word(v_i_240) + ((int64_t)1ULL))), v_f_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eunify_2eappendL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eappendL_24dps_entry, 3, 0};

V g_heff_2eelab_2eunify_2eappendL_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2eappendL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eappendL_24dps(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eunify_2emetasTypeF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2emetasTypeF_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2emetasTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emetasTypeF_entry, 5, 0};

V g_heff_2eelab_2eunify_2emetasTypeF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_t0_244) {
top: ;
  if (heff_intLe_c_lent(v_depth_242, MK_INT(0LL), 2)) {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    heff_drop(v_t0_244);
    return NTAG(TAG_Nil);
  } else {
    V v_t_246 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_241, v_t0_244));
    switch (heff_tag_of(v_t_246)) {
    case TAG_VU: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VDecode: {
      V v_el_2412 = heff_field(v_t_246, 4);
      heff_take_n(v_t_246, 16ULL, 5);
      V v_t_2413 = heff_tr(heff_call(v_el_2412, 1, (V[]){NTAG(TAG_MkUnit)}));
      return heff_tail(heff_get_n(v_r_240, 0, 3), 3, (V[]){v_depth_242, v_len_243, v_t_2413});
    }
    case TAG_VFunction: {
      V v_dom_2415 = heff_field(v_t_246, 1);
      V v_cod_2416 = heff_field(v_t_246, 2);
      heff_take_n(v_t_246, 6ULL, 5);
      V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 3, (V[]){heff_intSub(heff_dup(v_depth_242), MK_INT(1LL)), heff_dup(v_len_243), heff_dup(v_dom_2415)}));
      V v_x1_2426;
      switch (heff_tag_of(v_cod_2416)) {
      case TAG_MkClo: {
        V v_vs_2421 = heff_field(v_cod_2416, 1);
        V v_body_2422 = heff_field(v_cod_2416, 2);
        heff_take_n(v_cod_2416, 6ULL, 3);
        v_x1_2426 = heff_tr(heff_call(v_body_2422, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2421, heff_clo_n(g_heff_2eelab_2eunify_2emetasTypeF_lam0, 1, 2, (V[]){heff_dup(v_len_243), v_dom_2415})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2425 = heff_field(v_cod_2416, 0);
        heff_take_n(v_cod_2416, 1ULL, 1);
        heff_drop(v_dom_2415);
        v_x1_2426 = v_body_2425;
        break;
      }
      default: heff_nomatch(v_cod_2416);
      }
      V v_t_2430;
      switch (heff_tag_of(v_x1_2426)) {
      case TAG_Nom: {
        V v_x_2427 = heff_field(v_x1_2426, 0);
        heff_take_n(v_x1_2426, 1ULL, 1);
        v_t_2430 = v_x_2427;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2426, 0ULL, 1);
        v_t_2430 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2429 = heff_field(v_x1_2426, 0);
        heff_take_n(v_x1_2426, 1ULL, 1);
        v_t_2430 = v_x_2429;
        break;
      }
      default: heff_nomatch(v_x1_2426);
      }
      V v_t_2431 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), heff_intAdd(v_len_243, MK_INT(1LL)), v_t_2430}));
      return (g_heff_2eelab_2eunify_2eappendL(v_t_2419, v_t_2431));
    }
    case TAG_VRecord: {
      heff_take_n(v_t_246, 0ULL, 4);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VSum: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimInt: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimFloat: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimString: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimRune: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimArray: {
      V v_a_2437 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      return heff_tail(heff_get_n(v_r_240, 1, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, v_a_2437});
    }
    case TAG_VFixed: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
}
V g_heff_2eelab_2eunify_2emetasTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2emetasTypeF(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2emetasTypeF_lam1(V self, V *args) {
  V v_u_2424 = args[0];
  V v_dom_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2424);
  return v_dom_2415;
}
V g_heff_2eelab_2eunify_2emetasTypeF_lam0(V self, V *args) {
  V v_u_2423 = args[0];
  V v_len_243 = heff_env(self)[0];
  V v_dom_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2423);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_len_243}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2emetasTypeF_lam1, 1, 1, (V[]){v_dom_2415}), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2eunify_2emetasK_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2emetasK_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2emetasK_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2emetasK_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emetasK_entry, 1, 0};

V g_heff_2eelab_2eunify_2emetasK(V v_mc_240) {
top: ;
  return heff_rec_n(3, shape_mel__mty__msp, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2emetasK_lam0, 3, 1, (V[]){heff_dup(v_mc_240)}), heff_clo_n(g_heff_2eelab_2eunify_2emetasK_lam1, 3, 1, (V[]){heff_dup(v_mc_240)}), heff_clo_n(g_heff_2eelab_2eunify_2emetasK_lam2, 3, 1, (V[]){heff_dup(v_mc_240)})});
}
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2emetasK(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2emetasK_lam0(V self, V *args) {
  V v_depth_241 = args[0];
  V v_len_242 = args[1];
  V v_v_243 = args[2];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2eelab_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_244; V a_1 = v_mc_240; V a_2 = v_depth_241; V a_3 = v_len_242; V a_4 = v_v_243; V r_ = (g_heff_2eelab_2eunify_2emetasTermF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2eunify_2emetasK_lam1(V self, V *args) {
  V v_depth_245 = args[0];
  V v_len_246 = args[1];
  V v_t_247 = args[2];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2eelab_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_248; V a_1 = v_mc_240; V a_2 = v_depth_245; V a_3 = v_len_246; V a_4 = v_t_247; V r_ = (g_heff_2eelab_2eunify_2emetasTypeF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2eunify_2emetasK_lam2(V self, V *args) {
  V v_depth_249 = args[0];
  V v_len_2410 = args[1];
  V v_sp_2411 = args[2];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = (g_heff_2eelab_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_2412; V a_1 = v_mc_240; V a_2 = v_depth_249; V a_3 = v_len_2410; V a_4 = v_sp_2411; V r_ = (g_heff_2eelab_2eunify_2emetasSpF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); heff_drop(v_sp_2411); r_; });
}
V g_heff_2eelab_2eunify_2esubstTermF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTermF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTermF_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTermF_lam3(V self, V *args);
Clo g_heff_2eelab_2eunify_2esubstTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTermF_entry, 4, 0};

V g_heff_2eelab_2eunify_2esubstTermF(V v_r_240, V v_idxs_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SLocal = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    if (heff_intLt_c_lent(v_i_244, v_d_242, 0)) {
      heff_drop(v_idxs_241);
      heff_drop(v_d_242);
      return heff_tag_at_n(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){v_i_244});
    } else {
      V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_idxs_241));
      V v_t_247 = heff_intSub(heff_intSub(v_t_246, MK_INT(1LL)), heff_intSub(heff_dup(v_i_244), heff_dup(v_d_242)));
      HeffT2 v_t_248 = (g_heff_2eelab_2eunify_2enth_24cpr(v_idxs_241, v_t_247));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          heff_drop(v_i_244);
          V v_j_2412 = v_field_2410;
          return heff_tag_at_n(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){heff_intAdd(v_j_2412, v_d_242)});
        } else {
          heff_drop(v_d_242);
          heff_drop(v_field_2410);
          return heff_tag_at_n(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){v_i_244});
        }
      }
    }
  }
  case TAG_SGlobal: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_idxs_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SCode: {
    V v_ty_2414 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_idxs_241);
    V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_ty_2414}));
    return heff_tag_at_n(v_ru_24t_243_24SCode, TAG_SCode, 1, (V[]){v_t_2415});
  }
  case TAG_SApp: {
    V v_f_2416 = heff_field(v_t_243, 0);
    V v_a_2417 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SApp = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_idxs_241);
    V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_f_2416}));
    V v_t_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_a_2417}));
    return heff_tag_at_n(v_ru_24t_243_24SApp, TAG_SApp, 2, (V[]){v_t_2418, v_t_2419});
  }
  case TAG_SLam: {
    V v_dd_2420 = heff_field(v_t_243, 0);
    V v_t2_2421 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SLam = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_idxs_241);
    switch (heff_tag_of(v_t2_2421)) {
    case TAG_MkAbs: {
      V v_x_2422 = heff_field(v_t2_2421, 0);
      V v_b_2423 = heff_field(v_t2_2421, 1);
      heff_take_n(v_t2_2421, 3ULL, 2);
      V v_t_2424 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2420}));
      V v_t_2425 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2423}));
      return heff_tag_at_n(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2424, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2422, v_t_2425})});
    }
    case TAG_AbsConst: {
      V v_b_2426 = heff_field(v_t2_2421, 0);
      heff_take_n(v_t2_2421, 1ULL, 1);
      V v_t_2427 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2420}));
      V v_t_2428 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_b_2426}));
      return heff_tag_at_n(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2427, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2428})});
    }
    default: return heff_nomatch(v_t2_2421);
    }
  }
  case TAG_SCons: {
    V v_dct_2429 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCons = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_idxs_241);
    V v_f_2430 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_242}));
    V v_xs_2431 = heff_take_field(v_dct_2429, 2);
    V v_t_2434 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2431, 0), heff_clo_n(g_heff_2eelab_2eunify_2esubstTermF_lam0, 1, 2, (V[]){v_xs_2431, v_f_2430}));
    V v_t_2435 = ({ V rv_2 = v_t_2434; V rr_ = heff_rec_reuse_nf(v_dct_2429, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SCons, TAG_SCons, 1, (V[]){v_t_2435});
  }
  case TAG_SProj: {
    V v_e_2436 = heff_field(v_t_243, 0);
    V v_l_2437 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SProj = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_idxs_241);
    V v_t_2438 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2436}));
    return heff_tag_at_n(v_ru_24t_243_24SProj, TAG_SProj, 2, (V[]){v_t_2438, v_l_2437});
  }
  case TAG_STag: {
    V v_x_2439 = heff_field(v_t_243, 0);
    V v_argv_2440 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24STag = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_idxs_241);
    V v_f_2441 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_242}));
    V v_t_2444 = heff_arrayGenerate(heff_arrayLength_lent(v_argv_2440, 0), heff_clo_n(g_heff_2eelab_2eunify_2esubstTermF_lam1, 1, 2, (V[]){v_argv_2440, v_f_2441}));
    return heff_tag_at_n(v_ru_24t_243_24STag, TAG_STag, 2, (V[]){v_x_2439, v_t_2444});
  }
  case TAG_SMatch: {
    V v_e_2445 = heff_field(v_t_243, 0);
    V v_cs_2446 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SMatch = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_idxs_241);
    V v_t_2447 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_e_2445}));
    V v_xs_2448 = heff_take_field(v_cs_2446, 2);
    V v_t_2455 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2448, 0), heff_clo_n(g_heff_2eelab_2eunify_2esubstTermF_lam2, 1, 3, (V[]){v_xs_2448, v_d_242, v_r_240}));
    V v_t_2456 = ({ V rv_2 = v_t_2455; V rr_ = heff_rec_reuse_nf(v_cs_2446, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SMatch, TAG_SMatch, 2, (V[]){v_t_2447, v_t_2456});
  }
  case TAG_SSpecialize: {
    V v_e_2457 = heff_field(v_t_243, 0);
    V v_l_2458 = heff_field(v_t_243, 1);
    V v_v_2459 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SSpecialize = heff_take_reuse_n(v_t_243, 7ULL, 3);
    heff_drop(v_idxs_241);
    V v_t_2460 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_e_2457}));
    V v_t_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_v_2459}));
    return heff_tag_at_n(v_ru_24t_243_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2460, v_l_2458, v_t_2461});
  }
  case TAG_SIs: {
    V v_e_2462 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIs = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_idxs_241);
    V v_t_2463 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2462}));
    return heff_tag_at_n(v_ru_24t_243_24SIs, TAG_SIs, 1, (V[]){v_t_2463});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_idxs_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_idxs_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SRec: {
    V v_e_2464 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SRec = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_idxs_241);
    V v_t_2465 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2464}));
    return heff_tag_at_n(v_ru_24t_243_24SRec, TAG_SRec, 1, (V[]){v_t_2465});
  }
  case TAG_SFix: {
    V v_dd_2466 = heff_field(v_t_243, 0);
    V v_t2_2467 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SFix = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_idxs_241);
    switch (heff_tag_of(v_t2_2467)) {
    case TAG_MkAbs: {
      V v_x_2468 = heff_field(v_t2_2467, 0);
      V v_b_2469 = heff_field(v_t2_2467, 1);
      heff_take_n(v_t2_2467, 3ULL, 2);
      V v_t_2470 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2466}));
      V v_t_2471 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2469}));
      return heff_tag_at_n(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2470, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2468, v_t_2471})});
    }
    case TAG_AbsConst: {
      V v_b_2472 = heff_field(v_t2_2467, 0);
      heff_take_n(v_t2_2467, 1ULL, 1);
      V v_t_2473 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2466}));
      V v_t_2474 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_b_2472}));
      return heff_tag_at_n(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2473, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2474})});
    }
    default: return heff_nomatch(v_t2_2467);
    }
  }
  case TAG_SImplicit: {
    V v_x_2475 = heff_field(v_t_243, 0);
    V v_e_2476 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SImplicit = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_idxs_241);
    V v_t_2477 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2476}));
    return heff_tag_at_n(v_ru_24t_243_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2475, v_t_2477});
  }
  case TAG_SPrim: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_idxs_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SMetaApp: {
    V v_m_2479 = heff_field(v_t_243, 0);
    V v_ix_2480 = heff_field(v_t_243, 1);
    V v_ty_2481 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SMetaApp = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2492 = heff_arrayGenerate(heff_arrayLength_lent(v_ix_2480, 0), heff_clo_n(g_heff_2eelab_2eunify_2esubstTermF_lam3, 1, 3, (V[]){v_ix_2480, heff_dup(v_d_242), v_idxs_241}));
    V v_t_2493 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_ty_2481}));
    return heff_tag_at_n(v_ru_24t_243_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2479, v_t_2492, v_t_2493});
  }
  case TAG_SLitInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_idxs_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_idxs_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_idxs_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitBytes: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_idxs_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_idxs_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_idxs_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat32: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_idxs_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2eunify_2esubstTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esubstTermF(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eunify_2esubstTermF_lam0(V self, V *args) {
  V v_i_2432 = args[0];
  V v_xs_2431 = heff_env(self)[0];
  V v_f_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = heff_arrayIndex(v_xs_2431, v_i_2432);
  V f_ = v_f_2430;
  args[0] = v_t_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esubstTermF_lam1(V self, V *args) {
  V v_i_2442 = args[0];
  V v_argv_2440 = heff_env(self)[0];
  V v_f_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2443 = heff_arrayIndex(v_argv_2440, v_i_2442);
  V f_ = v_f_2441;
  args[0] = v_t_2443;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esubstTermF_lam2(V self, V *args) {
  V v_i_2449 = args[0];
  V v_xs_2448 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_p_2450 = heff_arrayIndex(v_xs_2448, v_i_2449);
  switch (heff_tag_of(v_p_2450)) {
  case TAG_MkPair: {
    V v_xs_2451 = heff_field(v_p_2450, 0);
    V v_b_2452 = heff_field(v_p_2450, 1);
    V v_ru_24p_2450_24MkPair = heff_take_reuse_n(v_p_2450, 3ULL, 2);
    V v_t_2453 = heff_intAdd(v_d_242, heff_arrayLength_lent(v_xs_2451, 0));
    V v_t_2454 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_t_2453, v_b_2452}));
    return heff_tag_at_n(v_ru_24p_2450_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2451, v_t_2454});
  }
  default: return heff_nomatch(v_p_2450);
  }
}
V g_heff_2eelab_2eunify_2esubstTermF_lam3(V self, V *args) {
  V v_i_2482 = args[0];
  V v_ix_2480 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_idxs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_i_2483 = heff_arrayIndex(v_ix_2480, v_i_2482);
  if (heff_intLt_c_lent(v_i_2483, v_d_242, 0)) {
    heff_drop(v_d_242);
    heff_drop(v_idxs_241);
    return v_i_2483;
  } else {
    V v_t_2485 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_idxs_241));
    V v_t_2486 = heff_intSub(heff_intSub(v_t_2485, MK_INT(1LL)), heff_intSub(heff_dup(v_i_2483), heff_dup(v_d_242)));
    HeffT2 v_t_2487 = (g_heff_2eelab_2eunify_2enth_24cpr(v_idxs_241, v_t_2486));
    {
      V v_field_2489 = v_t_2487.f[1];
      int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
      if ((v_tag_2488 == ((int64_t)0ULL))) {
        heff_drop(v_i_2483);
        V v_j_2491 = v_field_2489;
        return heff_intAdd(v_j_2491, v_d_242);
      } else {
        heff_drop(v_d_242);
        heff_drop(v_field_2489);
        return v_i_2483;
      }
    }
  }
}
Clo g_heff_2eelab_2eunify_2esubstTyFields_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTyFields_24dps_entry, 5, 0};

V g_heff_2eelab_2eunify_2esubstTyFields_24dps(V v_r_240, V v_d_241, V v_i_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_241);
    heff_drop(v_i_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_ty_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_intAdd(heff_dup(v_d_241), heff_dup(v_i_242)), v_ty_245}));
    V v_cell_248 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_r_240;
    V t_1 = v_d_241;
    V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
    V t_3 = v_rest_246;
    V t_4 = v_cell_248;
    v_r_240 = t_0;
    v_d_241 = t_1;
    v_i_242 = t_2;
    v_x4_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eunify_2esubstTyFields_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esubstTyFields_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_entry, 3, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps(V v_i_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_241, 0);
    V v_xs_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_i_240), v_x_243}), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_xs_244;
    V t_2 = v_cell_245;
    v_i_240 = t_0;
    v_x3_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eunify_2enominalBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2enominalBody_entry, 1, 0};

V g_heff_2eelab_2eunify_2enominalBody(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    V v_t_243 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_t_243)) {
    case TAG_SU: {
      heff_take_n(v_t_243, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_SDecode: {
      heff_take_n(v_t_243, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_SFunction: {
      heff_take_n(v_t_243, 0ULL, 5);
      return NTAG(TAG_False);
    }
    case TAG_SRecord: {
      heff_take_n(v_t_243, 0ULL, 3);
      return NTAG(TAG_True);
    }
    case TAG_SSum: {
      heff_take_n(v_t_243, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SIsTy: {
      heff_take_n(v_t_243, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      heff_take_n(v_t_243, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_SFixed: {
      heff_take_n(v_t_243, 0ULL, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_SApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_SLam: {
    V v_b_2421 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V v_t_2425;
    switch (heff_tag_of(v_b_2421)) {
    case TAG_MkAbs: {
      V v_b_2423 = heff_field(v_b_2421, 1);
      heff_take_n(v_b_2421, 2ULL, 2);
      v_t_2425 = v_b_2423;
      break;
    }
    case TAG_AbsConst: {
      V v_b_2424 = heff_field(v_b_2421, 0);
      heff_take_n(v_b_2421, 1ULL, 1);
      v_t_2425 = v_b_2424;
      break;
    }
    default: heff_nomatch(v_b_2421);
    }
    V t_0 = v_t_2425;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_STag: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_SIs: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_SLitInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SLitBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2enominalBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2enominalBody(a[0]);
}

HeffT2 g_heff_2eelab_2eunify_2eapproxEntry_24cpr(V v_g_240, V v_m_241, V v_x3_242, V v_x4_243, V v_rigid_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop(v_rigid_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nothing: {
      heff_drop(v_g_240);
      heff_drop(v_m_241);
      heff_drop(v_rigid_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_metaArgs_246 = heff_field(v_x4_243, 0);
      switch (heff_tag_of(v_rigid_244)) {
      case TAG_VNeu: {
        V v_h_247 = heff_field(v_rigid_244, 0);
        V v_sp_248 = heff_field(v_rigid_244, 1);
        heff_take_n(v_rigid_244, 3ULL, 5);
        HeffT2 v_t_2412 = ({ V a_0 = heff_dup(v_g_240); V a_1 = v_h_247; V a_2 = v_sp_248; HeffT2 r_ = (g_heff_2eelab_2eunify_2enominalOf_24cpr(a_0, a_1, a_2)); heff_drop(v_h_247); r_; });
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_x51_2416 = v_field_2414;
            switch (heff_tag_of(v_x51_2416)) {
            case TAG_MkPair: {
              V v_key_2417 = heff_field(v_x51_2416, 0);
              V v_sp_2418 = heff_field(v_x51_2416, 1);
              heff_take_n(v_x51_2416, 3ULL, 2);
              HeffT2 v_t_2419 = (g_heff_2eelab_2eunify_2eappsRev_24cpr(v_sp_2418));
              {
                V v_field_2421 = v_t_2419.f[1];
                int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
                if ((v_tag_2420 == ((int64_t)0ULL))) {
                  V v_rigidArgs_2423 = v_field_2421;
                  V v_t_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_metaArgs_246));
                  V v_t_2425 = heff_intSub(v_t_2424, heff_dup(heff_rfield(v_e_245, 3)));
                  return ({ V a_0 = v_g_240; V a_1 = v_m_241; V a_2 = v_t_2425; V a_3 = heff_dup(v_metaArgs_246); V a_4 = v_key_2417; V a_5 = v_rigidArgs_2423; HeffT2 r_ = (g_heff_2eelab_2eunify_2eapproxWith_24cpr(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_key_2417); r_; });
                } else {
                  heff_drop(v_g_240);
                  heff_drop(v_m_241);
                  heff_drop(v_key_2417);
                  heff_drop(v_field_2421);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x51_2416)}});
            }
          } else {
            heff_drop(v_g_240);
            heff_drop(v_m_241);
            heff_drop(v_field_2414);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      case TAG_VCode: {
        heff_take_n(v_rigid_244, 0ULL, 1);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_VLam: {
        heff_take_n(v_rigid_244, 0ULL, 2);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_VCons: {
        heff_take_n(v_rigid_244, 0ULL, 1);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_VOpaque: {
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_rigid_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474_entry, 3, 0};

V g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474(V v_ms_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474_lam0, 1, 1, (V[]){heff_dup(v_ms_240)})})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474_lam1, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474_lam0(V self, V *args) {
  V v_c_243 = args[0];
  V v_ms_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ps_244 = ({ V a_0 = heff_take_field(v_c_243, 2); V a_1 = v_ms_240; V r_ = (g_list_2efoldl_24s1583117218x1471782720(a_0, a_1)); heff_drop(v_ms_240); r_; });
  return ({ V rv_2 = v_ps_244; V rr_ = heff_rec_reuse_nf(v_c_243, 251ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 65487u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tag_n(TAG_Put, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})}));
  V f_ = heff_get_n(v_hd_241, 1, 3);
  heff_room[0] = v_t_249;
  heff_room[1] = v_k_242;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam6(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231(V v_g_240, V v_m_241, V v_pr_242, V v_x5_243, V v_h_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SpId: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop(v_pr_242);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam0, 2, 1, (V[]){v_h_244});
  }
  case TAG_SpApp: {
    V v_s_247 = heff_field(v_x5_243, 0);
    V v_a_248 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_249 = (g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_247, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam1, 2, 5, (V[]){v_c_249, v_g_240, v_m_241, v_pr_242, v_a_248});
  }
  case TAG_SpProj: {
    V v_s_2414 = heff_field(v_x5_243, 0);
    V v_l_2415 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_2416 = (g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231(v_g_240, v_m_241, v_pr_242, v_s_2414, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam4, 2, 2, (V[]){v_c_2416, v_l_2415});
  }
  case TAG_SpSpec: {
    V v_s_2420 = heff_field(v_x5_243, 0);
    V v_l_2421 = heff_field(v_x5_243, 1);
    V v_a_2422 = heff_field(v_x5_243, 2);
    heff_take_n(v_x5_243, 7ULL, 3);
    V v_c_2423 = (g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_2420, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam6, 2, 6, (V[]){v_c_2423, v_g_240, v_m_241, v_pr_242, v_a_2422, v_l_2421});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_h_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_h_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_SApp, 2, (V[]){v_x_2412, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_248 = heff_env(self)[3];
  V v_hd_2410 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445(v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam3, 1, 2, (V[]){v_k_2411, v_x_2412})));
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_l_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_SProj, 2, (V[]){v_x_2419, v_l_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_l_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2416;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam5, 1, 2, (V[]){v_k_2418, v_l_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  V v_l_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_2426, v_l_2421, v_x_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_2422 = heff_env(self)[3];
  V v_hd_2424 = heff_env(self)[4];
  V v_k_2425 = heff_env(self)[5];
  V v_l_2421 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445(v_g_240, v_m_241, v_pr_242, v_a_2422, v_hd_2424, heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam8, 1, 3, (V[]){v_k_2425, v_x_2426, v_l_2421})));
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam6(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_2422 = heff_env(self)[4];
  V v_l_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_lam7, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2422, v_hd_2424, v_k_2425, v_l_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam0, 2, 0};
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793(V v_g_240, V v_m_241, V v_pr_242, V v_i_243, V v_ls_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop_rec(v_pr_242, 3);
    heff_drop(v_i_243);
    heff_drop(v_ls_244);
    return ((V)&g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam0_clo);
  }
  case TAG_Cons: {
    V v_fc_248 = heff_field(v_x7_245, 0);
    V v_rest_249 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_call(v_fc_248, 1, (V[]){heff_dup(v_ls_244)}));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_MkField: {
      V v_ty_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 2);
      V v_pr_2413 = (g_heff_2eelab_2eunify_2eiterateLift(heff_dup(v_i_243), heff_dup(v_pr_242)));
      return heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam1, 2, 8, (V[]){v_g_240, v_m_241, v_pr_2413, v_ty_2411, v_pr_242, v_i_243, v_ls_244, v_rest_249});
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam3(V self, V *args) {
  V v_u_2418 = args[0];
  V v_ty_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2418);
  return v_ty_2411;
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam4(V self, V *args) {
  V v_u_2420 = args[0];
  V v_v_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2420);
  return v_v_2419;
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2416, v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_ty_2411 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_ls_244 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  V v_hd_2414 = heff_env(self)[7];
  V v_k_2415 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2417 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), heff_dup(v_i_243));
  V v_v_2419 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_t_2417}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam3, 1, 1, (V[]){v_ty_2411}), NTAG(TAG_Nothing)));
  V v_c_2421 = (g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793(v_g_240, v_m_241, v_pr_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_tag_n(TAG_LSnoc, 2, (V[]){v_ls_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam4, 1, 1, (V[]){v_v_2419})}), v_rest_249));
  V f_ = v_c_2421;
  heff_room[0] = v_hd_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam5, 1, 2, (V[]){v_k_2415, v_x_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2413 = heff_env(self)[2];
  V v_ty_2411 = heff_env(self)[3];
  V v_pr_242 = heff_env(self)[4];
  V v_i_243 = heff_env(self)[5];
  V v_ls_244 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640(heff_dup(v_g_240), heff_dup(v_m_241), v_pr_2413, heff_dup(v_ty_2411), heff_dup(v_hd_2414), heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s1198608902x1402893793_lam2, 1, 9, (V[]){v_pr_242, v_i_243, v_ty_2411, v_g_240, v_m_241, v_ls_244, v_rest_249, v_hd_2414, v_k_2415})));
}
HEFF_LIT(g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_str0, 1, "x");
V g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_entry, 6, 0};

V g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208(V v_g_240, V v_cs_241, V v_a_242, V v_b_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    V v_u_246 = heff_dup(heff_field(v_a_242, 0));
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_u_27_247 = heff_dup(heff_field(v_b_243, 0));
      switch (heff_tag_of(v_u_246)) {
      case TAG_SmallU: {
        switch (heff_tag_of(v_u_27_247)) {
        case TAG_SmallU: {
          heff_drop_rec(v_cs_241, 2);
          heff_drop_tag(v_a_242, 1);
          heff_drop_tag(v_b_243, 1);
          heff_drop_rec(v_z_244, 3);
          return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
        }
        case TAG_LargeU: {
          V v_t_248 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
          V v_t_249 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})}));
          return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_249, v_z_245});
        }
        default: return heff_nomatch(v_u_27_247);
        }
      }
      case TAG_LargeU: {
        switch (heff_tag_of(v_u_27_247)) {
        case TAG_SmallU: {
          V v_t_2410 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
          V v_t_2411 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})}));
          return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2411, v_z_245});
        }
        case TAG_LargeU: {
          heff_drop_rec(v_cs_241, 2);
          heff_drop_tag(v_a_242, 1);
          heff_drop_tag(v_b_243, 1);
          heff_drop_rec(v_z_244, 3);
          return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
        }
        default: return heff_nomatch(v_u_27_247);
        }
      }
      default: return heff_nomatch(v_u_246);
      }
    }
    case TAG_VDecode: {
      heff_drop(v_u_246);
      V v_t_2417 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2418 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2418, v_z_245});
    }
    case TAG_VFunction: {
      heff_drop(v_u_246);
      V v_t_2424 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2425 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2425, v_z_245});
    }
    case TAG_VRecord: {
      heff_drop(v_u_246);
      V v_t_2430 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2431 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2431, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_u_246);
      V v_t_2433 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2434 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2434, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_u_246);
      V v_t_2435 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2436 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2436, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_u_246);
      V v_t_2437 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2438 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2438, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_u_246);
      V v_t_2439 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2440 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2440, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_u_246);
      V v_t_2441 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2442 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2442, v_z_245});
    }
    case TAG_VPrimArray: {
      heff_drop(v_u_246);
      V v_t_2444 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2445 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2445, v_z_245});
    }
    case TAG_VFixed: {
      heff_drop(v_u_246);
      V v_t_2447 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2448 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2448, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VDecode: {
    V v_h_2449 = heff_dup(heff_field(v_a_242, 0));
    V v_sp_2450 = heff_dup(heff_field(v_a_242, 1));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2455 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2456 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2456, v_z_245});
    }
    case TAG_VDecode: {
      V v_h_27_2457 = heff_field(v_b_243, 0);
      V v_sp_27_2458 = heff_field(v_b_243, 1);
      heff_take_n(v_b_243, 3ULL, 5);
      heff_drop_tag(v_a_242, 5);
      V v_t_2462 = (g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545(v_g_240, v_cs_241, v_h_2449, v_sp_2450, v_h_27_2457, v_sp_27_2458));
      return heff_tail(v_t_2462, 2, (V[]){v_z_244, v_z_245});
    }
    case TAG_VFunction: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2468 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2469 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2469, v_z_245});
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2474 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2475 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2474})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2475, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2477 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2478 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2478, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2479 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2480 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2480, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2481 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2482 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2482, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2483 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2484 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2484, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2485 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2486 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2485})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2486, v_z_245});
    }
    case TAG_VPrimArray: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2488 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2489 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2488})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2489, v_z_245});
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2491 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2492 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2491})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2492, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VFunction: {
    V v_level_2493 = heff_dup(heff_field(v_a_242, 0));
    V v_dom_2494 = heff_dup(heff_field(v_a_242, 1));
    V v_cod_2495 = heff_dup(heff_field(v_a_242, 2));
    V v_implicit_2496 = heff_dup(heff_field(v_a_242, 3));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_2499 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24100 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2499})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24100, v_z_245});
    }
    case TAG_VDecode: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_24106 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24107 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24106})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24107, v_z_245});
    }
    case TAG_VFunction: {
      V v_level_27_24108 = heff_dup(heff_field(v_b_243, 0));
      V v_dom_27_24109 = heff_dup(heff_field(v_b_243, 1));
      V v_cod_27_24110 = heff_dup(heff_field(v_b_243, 2));
      V v_implicit_27_24111 = heff_dup(heff_field(v_b_243, 3));
      V v_t_24113 = ({ V a_0 = v_level_2493; V a_1 = v_level_27_24108; V r_ = (g_heff_2eelab_2eparams_2eeqLevel(a_0, a_1)); heff_drop(v_level_2493); heff_drop(v_level_27_24108); r_; });
      V v_t_24114;
      if ((heff_dup(v_t_24113) == NTAG(TAG_True))) {
        heff_drop(v_t_24113);
        switch (heff_tag_of(v_implicit_2496)) {
        case TAG_Expl: {
          switch (heff_tag_of(v_implicit_27_24111)) {
          case TAG_Expl: {
            v_t_24114 = NTAG(TAG_True);
            break;
          }
          case TAG_Impl: {
            v_t_24114 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_24114 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_24111);
          }
          break;
        }
        case TAG_Impl: {
          switch (heff_tag_of(v_implicit_27_24111)) {
          case TAG_Expl: {
            v_t_24114 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_24114 = NTAG(TAG_True);
            break;
          }
          case TAG_Inst: {
            v_t_24114 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_24111);
          }
          break;
        }
        case TAG_Inst: {
          switch (heff_tag_of(v_implicit_27_24111)) {
          case TAG_Expl: {
            v_t_24114 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_24114 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_24114 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_implicit_27_24111);
          }
          break;
        }
        default: heff_nomatch(v_implicit_2496);
        }
      } else {
        heff_drop(v_implicit_2496);
        heff_drop(v_implicit_27_24111);
        heff_drop(v_t_24113);
        v_t_24114 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_24114) == NTAG(TAG_True))) {
        heff_drop_tag(v_a_242, 5);
        heff_drop_tag(v_b_243, 5);
        heff_drop(v_t_24114);
        HEFF_LAST return g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_dom_2494), v_dom_27_24109, heff_dup(v_z_244), heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_lam0, 1, 7, (V[]){v_cs_241, v_dom_2494, v_cod_2495, v_cod_27_24110, v_g_240, v_z_244, v_z_245}));
      } else {
        heff_drop(v_g_240);
        heff_drop(v_dom_2494);
        heff_drop(v_cod_2495);
        heff_drop(v_dom_27_24109);
        heff_drop(v_cod_27_24110);
        heff_drop(v_t_24114);
        V v_t_24146 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
        V v_t_24147 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24146})}));
        return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24147, v_z_245});
      }
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_24152 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24153 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24152})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24153, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_24155 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24156 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24155})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24156, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_24157 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24158 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24157})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24158, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_24159 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24160 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24159})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24160, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_24161 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24162 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24161})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24162, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_24163 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24164 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24163})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24164, v_z_245});
    }
    case TAG_VPrimArray: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_24166 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24167 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24166})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24167, v_z_245});
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_24169 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24170 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24169})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24170, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VRecord: {
    heff_drop(v_g_240);
    V v_t_24175 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
    V v_t_24176 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24175})}));
    return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24176, v_z_245});
  }
  case TAG_VSum: {
    heff_drop(v_g_240);
    V v_t_24178 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
    V v_t_24179 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24178})}));
    return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24179, v_z_245});
  }
  case TAG_VPrimInt: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24181 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24182 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24181})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24182, v_z_245});
    }
    case TAG_VDecode: {
      V v_t_24188 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24189 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24188})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24189, v_z_245});
    }
    case TAG_VFunction: {
      V v_t_24195 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24196 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24195})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24196, v_z_245});
    }
    case TAG_VRecord: {
      V v_t_24201 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24202 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24201})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24202, v_z_245});
    }
    case TAG_VSum: {
      V v_t_24204 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24205 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24204})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24205, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_VPrimFloat: {
      V v_t_24206 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24207 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24206})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24207, v_z_245});
    }
    case TAG_VPrimString: {
      V v_t_24208 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24209 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24208})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24209, v_z_245});
    }
    case TAG_VPrimRune: {
      V v_t_24210 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24211 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24210})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24211, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_t_24213 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24214 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24213})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24214, v_z_245});
    }
    case TAG_VFixed: {
      V v_t_24216 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24217 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24216})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24217, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimFloat: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24219 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24220 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24219})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24220, v_z_245});
    }
    case TAG_VDecode: {
      V v_t_24226 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24227 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24226})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24227, v_z_245});
    }
    case TAG_VFunction: {
      V v_t_24233 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24234 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24233})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24234, v_z_245});
    }
    case TAG_VRecord: {
      V v_t_24239 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24240 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24239})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24240, v_z_245});
    }
    case TAG_VSum: {
      V v_t_24242 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24243 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24242})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24243, v_z_245});
    }
    case TAG_VPrimInt: {
      V v_t_24244 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24245 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24244})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24245, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_VPrimString: {
      V v_t_24246 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24247 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24246})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24247, v_z_245});
    }
    case TAG_VPrimRune: {
      V v_t_24248 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24249 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24248})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24249, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_t_24251 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24252 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24251})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24252, v_z_245});
    }
    case TAG_VFixed: {
      V v_t_24254 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24255 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24254})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24255, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimString: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24257 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24258 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24257})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24258, v_z_245});
    }
    case TAG_VDecode: {
      V v_t_24264 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24265 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24264})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24265, v_z_245});
    }
    case TAG_VFunction: {
      V v_t_24271 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24272 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24271})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24272, v_z_245});
    }
    case TAG_VRecord: {
      V v_t_24277 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24278 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24277})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24278, v_z_245});
    }
    case TAG_VSum: {
      V v_t_24280 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24281 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24280})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24281, v_z_245});
    }
    case TAG_VPrimInt: {
      V v_t_24282 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24283 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24282})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24283, v_z_245});
    }
    case TAG_VPrimFloat: {
      V v_t_24284 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24285 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24284})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24285, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_VPrimRune: {
      V v_t_24286 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24287 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24286})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24287, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_t_24289 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24290 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24289})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24290, v_z_245});
    }
    case TAG_VFixed: {
      V v_t_24292 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24293 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24292})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24293, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimRune: {
    heff_drop(v_g_240);
    V v_t_24312;
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VFunction: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24312 = NTAG(TAG_True);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_b_243);
    }
    if ((heff_dup(v_t_24312) == NTAG(TAG_True))) {
      heff_drop_rec(v_cs_241, 2);
      heff_drop(v_b_243);
      heff_drop_rec(v_z_244, 3);
      heff_drop(v_t_24312);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    } else {
      heff_drop(v_t_24312);
      V v_t_24313 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24314 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24313})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24314, v_z_245});
    }
  }
  case TAG_VPrimArray: {
    V v_x_24315 = heff_dup(heff_field(v_a_242, 0));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24317 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24318 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24317})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24318, v_z_245});
    }
    case TAG_VDecode: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24324 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24325 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24324})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24325, v_z_245});
    }
    case TAG_VFunction: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24331 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24332 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24331})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24332, v_z_245});
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24337 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24338 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24337})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24338, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24340 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24341 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24340})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24341, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24342 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24343 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24342})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24343, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24344 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24345 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24344})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24345, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24346 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24347 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24346})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24347, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24348 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24349 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24348})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24349, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_y_24350 = heff_field(v_b_243, 0);
      heff_take_n(v_b_243, 1ULL, 1);
      heff_drop_tag(v_a_242, 1);
      HEFF_LAST return g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005(v_g_240, v_cs_241, v_x_24315, v_y_24350, v_z_244, v_z_245);
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24352 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24353 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24352})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24353, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VFixed: {
    V v_w_24354 = heff_dup(heff_field(v_a_242, 0));
    heff_drop(v_g_240);
    V v_t_24355 = ({ V a_0 = v_w_24354; V a_1 = v_b_243; V r_ = (g_heff_2eelab_2evalue_2eisFixed(a_0, a_1)); heff_drop(v_w_24354); r_; });
    if ((heff_dup(v_t_24355) == NTAG(TAG_True))) {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_tag(v_a_242, 1);
      heff_drop(v_b_243);
      heff_drop_rec(v_z_244, 3);
      heff_drop(v_t_24355);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    } else {
      heff_drop(v_t_24355);
      V v_t_24356 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24357 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24356})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24357, v_z_245});
    }
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_lam1(V self, V *args) {
  V v_u_24117 = args[0];
  V v_dom_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24117);
  return v_dom_2494;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_lam2(V self, V *args) {
  V v_w_24122 = args[0];
  V v_v_24118 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24122);
  return v_v_24118;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_lam3(V self, V *args) {
  V v_w_24132 = args[0];
  V v_v_24118 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24132);
  return v_v_24118;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_lam0(V self, V *args) {
  V v_x_24115 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_dom_2494 = heff_env(self)[1];
  V v_cod_2495 = heff_env(self)[2];
  V v_cod_27_24110 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_24115);
  V v_t_24116 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_cs_241, 0))});
  V v_v_24118 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_24116, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_lam1, 1, 1, (V[]){v_dom_2494}), NTAG(TAG_Nothing)));
  V v_x1_24124;
  switch (heff_tag_of(v_cod_2495)) {
  case TAG_MkClo: {
    V v_vs_24120 = heff_dup(heff_field(v_cod_2495, 1));
    V v_body_24121 = heff_dup(heff_field(v_cod_2495, 2));
    v_x1_24124 = heff_tr(heff_call(v_body_24121, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_24120, heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_lam2, 1, 1, (V[]){heff_dup(v_v_24118)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24123 = heff_dup(heff_field(v_cod_2495, 0));
    v_x1_24124 = v_body_24123;
    break;
  }
  default: heff_nomatch(v_cod_2495);
  }
  V v_a_24128;
  switch (heff_tag_of(v_x1_24124)) {
  case TAG_Nom: {
    V v_x_24125 = heff_field(v_x1_24124, 0);
    heff_take_n(v_x1_24124, 1ULL, 1);
    v_a_24128 = v_x_24125;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24124, 0ULL, 1);
    v_a_24128 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24127 = heff_field(v_x1_24124, 0);
    heff_take_n(v_x1_24124, 1ULL, 1);
    v_a_24128 = v_x_24127;
    break;
  }
  default: heff_nomatch(v_x1_24124);
  }
  V v_x1_24134;
  switch (heff_tag_of(v_cod_27_24110)) {
  case TAG_MkClo: {
    V v_vs_24130 = heff_field(v_cod_27_24110, 1);
    V v_body_24131 = heff_field(v_cod_27_24110, 2);
    heff_take_n(v_cod_27_24110, 6ULL, 3);
    v_x1_24134 = heff_tr(heff_call(v_body_24131, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_24130, heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_lam3, 1, 1, (V[]){v_v_24118})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24133 = heff_field(v_cod_27_24110, 0);
    heff_take_n(v_cod_27_24110, 1ULL, 1);
    heff_drop(v_v_24118);
    v_x1_24134 = v_body_24133;
    break;
  }
  default: heff_nomatch(v_cod_27_24110);
  }
  V v_b_24138;
  switch (heff_tag_of(v_x1_24134)) {
  case TAG_Nom: {
    V v_x_24135 = heff_field(v_x1_24134, 0);
    heff_take_n(v_x1_24134, 1ULL, 1);
    v_b_24138 = v_x_24135;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24134, 0ULL, 1);
    v_b_24138 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24137 = heff_field(v_x1_24134, 0);
    heff_take_n(v_x1_24134, 1ULL, 1);
    v_b_24138 = v_x_24137;
    break;
  }
  default: heff_nomatch(v_x1_24134);
  }
  V v_t_24139 = heff_intAdd(heff_take_field(v_cs_241, 0), MK_INT(1LL));
  V v_t_24144;
  switch (heff_tag_of(v_cod_2495)) {
  case TAG_MkClo: {
    V v_n_24140 = heff_field(v_cod_2495, 0);
    heff_take_n(v_cod_2495, 1ULL, 3);
    v_t_24144 = v_n_24140;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2495, 0ULL, 1);
    v_t_24144 = ((V)&g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_str0);
    break;
  }
  default: heff_nomatch(v_cod_2495);
  }
  V v_t_24145 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24144, heff_get_n(v_cs_241, 1, 2)});
  return (g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005(v_g_240, heff_rec_n(2, shape_len__names, (V[]){v_t_24139, v_t_24145}), v_a_24128, v_b_24138, v_z_244, v_z_245));
}