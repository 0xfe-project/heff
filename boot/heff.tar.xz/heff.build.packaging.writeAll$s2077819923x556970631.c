// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_WriteErr 37283
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631(V, V, V, V);
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_clo;
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V);
V g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129(V, V, V, V);
V g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0_str1, 19, "heff: cannot write ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0_str2, 1, "\012");
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0_lam1(V self, V *args);
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0_lam0(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0_entry, 8, 0};

V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0(V v_st_240, V v_dir_241, V v_f_242, V v_text_243, V v_p_244, V v_rest_245, V v_p_246, V v_x_247) {
top: ;
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_dir_241)));
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_f_242)));
  V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
  V v_s_2411 = ({ V a_0 = v_st_240; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2411));
  int64_t v_t_2413 = (heff_unbox_word(heff_strLength_lent(v_f_242, 0)) - ((int64_t)3ULL));
  V v_t_2414 = heff_strSlice_lent(v_f_242, heff_box_word(v_t_2413), heff_strLength_lent(v_f_242, 0), 6);
  V v_t_2420;
  if (heff_strEq_c(v_t_2414, ((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0_str0))) {
    HeffT2 v_t_2415 = (g_heff_2esyntax_2eformat_2eformat_24cpr(heff_dup(v_text_243)));
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        V v_x_2418 = v_field_2417;
        heff_drop(v_x_2418);
        v_t_2420 = v_text_243;
      } else {
        heff_drop(v_text_243);
        V v_out_2419 = v_field_2417;
        v_t_2420 = v_out_2419;
      }
    }
  } else {
    v_t_2420 = v_text_243;
  }
  return ({ V a_0 = v_t_2412; V a_1 = v_t_2420; V a_2 = heff_dup(v_p_244); V a_3 = heff_clo_n(g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0_lam0, 1, 7, (V[]){heff_dup(v_x_247), v_dir_241, v_rest_245, v_p_244, v_p_246, v_st_240, v_f_242}); V r_ = (g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129(a_0, a_1, a_2, a_3)); heff_drop(v_t_2412); r_; });
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a7 = a[7]; V r = g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a7); heff_drop(a7); return r;
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0_lam1(V self, V *args) {
  V v_x_2436 = args[0];
  V v_p_246 = heff_env(self)[0];
  heff_drop(v_x_2436);
  heff_clo_take(self, 1);
  V f_ = v_p_246;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0_lam0(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_p_246 = heff_env(self)[4];
  V v_st_240 = heff_env(self)[5];
  V v_f_242 = heff_env(self)[6];
  V v_t_2424;
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Left: {
    heff_take_n(v_x_247, 0ULL, 1);
    v_t_2424 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_247, 0ULL, 1);
    v_t_2424 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  if (((heff_dup(v_t_2424) == NTAG(TAG_True)) && (heff_dup(v_x_2421) == NTAG(TAG_True)))) {
    heff_drop(v_x_2421);
    heff_drop(v_st_240);
    heff_drop(v_f_242);
    heff_drop(v_t_2424);
    return (g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631(v_dir_241, v_rest_245, v_p_244, v_p_246));
  } else {
    heff_drop(v_x_2421);
    heff_drop(v_rest_245);
    heff_drop(v_t_2424);
    V v_t_2425 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_dir_241));
    V v_t_2426 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_f_242));
    V v_t_2427 = (g_std_2epath_2ejoin(v_t_2425, v_t_2426));
    V v_t_2428 = ({ V a_0 = v_st_240; V a_1 = v_t_2427; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2427); r_; });
    V v_str_2429 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0_str1), v_t_2428);
    V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2429, ((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0_str2)), NTAG(TAG_MkUnit)});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_p_244, heff_clo_n(g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0_lam1, 1, 1, (V[]){v_p_246})));
  }
}