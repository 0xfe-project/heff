// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_Bug 14592
#define TAG_Div 16157
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Ok 9325
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
V g_heff_2ecompile_2einterp_2ebitsCopy(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsCopy_clo;
V g_heff_2ecompile_2einterp_2ebitsOf_24s668170711x381591431(V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsOf_24s668170711x381591431_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsOf_24s668170711x381591431_clo;
V g_heff_2ecompile_2einterp_2ebitsPush(V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsPush_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsPush_clo;
V g_heff_2ecompile_2einterp_2ebitsRead(V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsRead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsRead_clo;
V g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103(V, V, V);
V g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103_clo;
V g_heff_2ecompile_2einterp_2ebitwise_24s612837565x2144654581(V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitwise_24s612837565x2144654581_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitwise_24s612837565x2144654581_clo;
V g_heff_2ecompile_2einterp_2eevalEach(V, V, V);
V g_heff_2ecompile_2einterp_2eevalEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalEach_clo;
V g_heff_2ecompile_2einterp_2ef32Take2(V, V, V);
V g_heff_2ecompile_2einterp_2ef32Take2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ef32Take2_clo;
V g_heff_2ecompile_2einterp_2efloat2(V);
V g_heff_2ecompile_2einterp_2efloat2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloat2_clo;
V g_heff_2ecompile_2einterp_2efloatTake2(V, V, V);
V g_heff_2ecompile_2einterp_2efloatTake2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloatTake2_clo;
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get(void);
V g_heff_2ecompile_2einterp_2enotAFloat32_get(void);
V g_heff_2ecompile_2einterp_2enotAnInt_get(void);
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(V);
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_clo;
V g_heff_2eelab_2efixed_2efixedMin(V);
V g_heff_2eelab_2efixed_2efixedMin_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMin_clo;
V g_heff_2eelab_2efixed_2etwoTo(V);
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2etwoTo_clo;
V g_heff_2ecompile_2einterp_2efloat2_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat2_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2efloat2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat2_entry, 1, 0};

V g_heff_2ecompile_2einterp_2efloat2(V v_f_240) {
top: ;
  return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2ecompile_2einterp_2efloat2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2efloat2(a[0]);
}
V g_heff_2ecompile_2einterp_2efloat2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Ok = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_call(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return ({ V a_0 = v_f_240; V a_1 = v_v_246; V a_2 = v_v_248; V r_ = (g_heff_2ecompile_2einterp_2efloatTake2(a_0, a_1, a_2)); heff_drop(v_v_246); heff_drop(v_v_248); r_; });
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_249 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return heff_tag_at_n(v_ru_24x1_245_24Ok, TAG_Bug, 1, (V[]){v_what_249});
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2410 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Bug = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return heff_tag_at_n(v_ru_24x1_245_24Bug, TAG_Bug, 1, (V[]){v_what_2410});
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2ecompile_2einterp_2efloat2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
Clo g_heff_2ecompile_2einterp_2ebitsCopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitsCopy_entry, 5, 0};

V g_heff_2ecompile_2einterp_2ebitsCopy(V v_n_240, V v_s_241, V v_t_242, V v_i_243, V v_j_244) {
top: ;
  if (heff_intLe_c(heff_dup(v_j_244), heff_dup(v_i_243))) {
    heff_drop(v_n_240);
    heff_drop(v_t_242);
    heff_drop(v_i_243);
    heff_drop(v_j_244);
    return v_s_241;
  } else {
    V v_t_248 = heff_bool((heff_intEq_c(heff_intMod(heff_dup(v_n_240), MK_INT(8LL)), MK_INT(0LL)) && (heff_intEq_c(heff_intMod(heff_dup(v_i_243), MK_INT(8LL)), MK_INT(0LL)) && heff_intLe_c(MK_INT(8LL), heff_intSub(heff_dup(v_j_244), heff_dup(v_i_243))))));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_t_249 = heff_intDiv(heff_intSub(heff_dup(v_j_244), heff_dup(v_i_243)), MK_INT(8LL));
      V v_t_2410 = heff_intAdd(v_n_240, heff_intMul(v_t_249, MK_INT(8LL)));
      V v_t_2411 = heff_intDiv(heff_intSub(heff_dup(v_j_244), heff_dup(v_i_243)), MK_INT(8LL));
      V v_t_2412 = heff_intAdd(heff_intDiv(heff_dup(v_i_243), MK_INT(8LL)), v_t_2411);
      V v_t_2413 = heff_strSlice(heff_dup(v_t_242), heff_intDiv(heff_dup(v_i_243), MK_INT(8LL)), v_t_2412);
      V v_t_2414 = heff_intDiv(heff_intSub(heff_dup(v_j_244), heff_dup(v_i_243)), MK_INT(8LL));
      V v_t_2415 = heff_intAdd(v_i_243, heff_intMul(v_t_2414, MK_INT(8LL)));
      V t_0 = v_t_2410;
      V t_1 = heff_strAppend(v_s_241, v_t_2413);
      V t_2 = v_t_242;
      V t_3 = v_t_2415;
      V t_4 = v_j_244;
      v_n_240 = t_0;
      v_s_241 = t_1;
      v_t_242 = t_2;
      v_i_243 = t_3;
      v_j_244 = t_4;
      goto top;
    } else {
      heff_drop(v_t_248);
      V v_y_2416 = heff_intSub(heff_dup(v_j_244), heff_dup(v_i_243));
      V v_t_2418;
      if (heff_intLe_c(MK_INT(8LL), heff_dup(v_y_2416))) {
        heff_drop(v_y_2416);
        v_t_2418 = MK_INT(8LL);
      } else {
        v_t_2418 = v_y_2416;
      }
      V v_y_2419 = heff_intSub(heff_dup(v_j_244), heff_dup(v_i_243));
      V v_t_2421;
      if (heff_intLe_c(MK_INT(8LL), heff_dup(v_y_2419))) {
        heff_drop(v_y_2419);
        v_t_2421 = MK_INT(8LL);
      } else {
        v_t_2421 = v_y_2419;
      }
      V v_t_2422 = (g_heff_2ecompile_2einterp_2ebitsRead(heff_dup(v_t_242), heff_dup(v_i_243), v_t_2421, MK_INT(0LL)));
      V v_y_2423 = heff_intSub(heff_dup(v_j_244), heff_dup(v_i_243));
      V v_t_2425;
      if (heff_intLe_c(MK_INT(8LL), heff_dup(v_y_2423))) {
        heff_drop(v_y_2423);
        v_t_2425 = MK_INT(8LL);
      } else {
        v_t_2425 = v_y_2423;
      }
      V v_t_2426 = (g_heff_2ecompile_2einterp_2ebitsPush(heff_dup(v_n_240), v_s_241, v_t_2422, v_t_2425));
      V v_y_2427 = heff_intSub(heff_dup(v_j_244), heff_dup(v_i_243));
      V v_t_2429;
      if (heff_intLe_c(MK_INT(8LL), heff_dup(v_y_2427))) {
        heff_drop(v_y_2427);
        v_t_2429 = MK_INT(8LL);
      } else {
        v_t_2429 = v_y_2427;
      }
      V t_0 = heff_intAdd(v_n_240, v_t_2418);
      V t_1 = v_t_2426;
      V t_2 = v_t_242;
      V t_3 = heff_intAdd(v_i_243, v_t_2429);
      V t_4 = v_j_244;
      v_n_240 = t_0;
      v_s_241 = t_1;
      v_t_242 = t_2;
      v_i_243 = t_3;
      v_j_244 = t_4;
      goto top;
    }
  }
}
V g_heff_2ecompile_2einterp_2ebitsCopy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebitsCopy(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103(V v_n_240, V v_a_241, V v_b_242) {
top: ;
  if (heff_intEq_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return MK_INT(0LL);
  } else {
    V v_t_244 = heff_intMul(heff_intMod(heff_dup(v_a_241), MK_INT(2LL)), heff_intMod(heff_dup(v_b_242), MK_INT(2LL)));
    V v_t_245 = (g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103(heff_intSub(v_n_240, MK_INT(1LL)), heff_intDiv(v_a_241, MK_INT(2LL)), heff_intDiv(v_b_242, MK_INT(2LL))));
    return heff_intAdd(v_t_244, heff_intMul(MK_INT(2LL), v_t_245));
  }
}
V g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2ebitsOf_24s668170711x381591431_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitsOf_24s668170711x381591431_entry, 4, 0};

V g_heff_2ecompile_2einterp_2ebitsOf_24s668170711x381591431(V v_lit_240, V v_w_241, V v_a_242, V v_b_243) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_244 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_244 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_244 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_244 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_244 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_244 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  V v_t_245;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_245 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_245 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_245 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_245 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_245 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_245 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_245 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_245 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_245 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  V v_t_246 = (g_heff_2eelab_2efixed_2etwoTo(v_t_245));
  V v_t_247;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_247 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_247 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_247 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_247 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_247 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_247 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_247 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_247 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_247 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  V v_t_248 = (g_heff_2eelab_2efixed_2etwoTo(v_t_247));
  V v_n_249 = (g_heff_2ecompile_2einterp_2ebitwise_24s612837565x2144654581(v_lit_240, v_t_244, heff_intMod(v_a_242, v_t_246), heff_intMod(v_b_243, v_t_248)));
  V v_t_2410 = (g_heff_2eelab_2efixed_2efixedMin(v_w_241));
  V v_t_2411 = (g_heff_2eelab_2efixed_2efixedMin(v_w_241));
  V v_t_2412;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_2412 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_2412 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_2412 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_2412 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_2412 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_2412 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_2412 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_2412 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_2412 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  V v_t_2413 = (g_heff_2eelab_2efixed_2etwoTo(v_t_2412));
  V v_t_2414 = heff_intMod(heff_intSub(v_n_249, v_t_2411), v_t_2413);
  V v_t_2415 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2410, v_t_2414)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2415});
}
V g_heff_2ecompile_2einterp_2ebitsOf_24s668170711x381591431_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2einterp_2ebitsOf_24s668170711x381591431(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2einterp_2ef32Take2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ef32Take2_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ef32Take2(V v_f_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_VFun: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
  }
  case TAG_VCons: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
  }
  case TAG_VTag: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
  }
  case TAG_VInt: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
  }
  case TAG_VFloat: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
  }
  case TAG_VFloat32: {
    V v_a_249 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_VFun: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VCons: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VTag: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VInt: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VFloat: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VFloat32: {
      V v_b_2416 = heff_field(v_x3_242, 0);
      return heff_tail(v_f_240, 2, (V[]){heff_dup(v_a_249), heff_dup(v_b_2416)});
    }
    case TAG_VStr: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VRune: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VArr: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VBytes: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VBits: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VErased: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_VStr: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
  }
  case TAG_VRune: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
  }
  case TAG_VArr: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
  }
  case TAG_VBytes: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
  }
  case TAG_VBits: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
  }
  case TAG_VErased: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2einterp_2ef32Take2_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2einterp_2ef32Take2(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_st;
static V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_st)) return g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_val;
  return heff_global(&g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_val, &g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_st, g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_init);
}
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_VInt, 1, (V[]){heff_intAdd(v_a_2412, v_b_2417)});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2418});
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2eevalEach_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2eevalEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eevalEach_entry, 3, 0};

V g_heff_2ecompile_2einterp_2eevalEach(V v_ev_240, V v_x2_241, V v_k_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ev_240);
    return heff_tail(v_k_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_t_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_x1_245 = heff_tr(heff_call(heff_dup(v_ev_240), 1, (V[]){v_t_243}));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_Ok: {
      V v_v_246 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      V t_0 = v_ev_240;
      V t_1 = v_rest_244;
      V t_2 = heff_clo_n(g_heff_2ecompile_2einterp_2eevalEach_lam0, 1, 2, (V[]){v_k_242, v_v_246});
      v_ev_240 = t_0;
      v_x2_241 = t_1;
      v_k_242 = t_2;
      goto top;
    }
    case TAG_Abn: {
      heff_drop(v_ev_240);
      heff_drop(v_k_242);
      heff_drop(v_rest_244);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_ev_240);
      heff_drop(v_k_242);
      heff_drop(v_rest_244);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_248 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24Bug = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      heff_drop(v_ev_240);
      heff_drop(v_k_242);
      heff_drop(v_rest_244);
      return heff_tag_at_n(v_ru_24x1_245_24Bug, TAG_Bug, 1, (V[]){v_what_248});
    }
    default: return heff_nomatch(v_x1_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2einterp_2eevalEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eevalEach(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2einterp_2eevalEach_lam0(V self, V *args) {
  V v_vs_247 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_v_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_v_246, v_vs_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_str0, 3, "Nil");
HEFF_LIT(g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_str1, 4, "Cons");
Clo g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_entry, 1, 0};

V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_str0), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x_243 = heff_tag_n(TAG_VRune, 1, (V[]){heff_runeToInt(v_x_241)});
    V v_t_244 = (g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(v_xs_242));
    V v_t_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_str1), heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_t_245})});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(a[0]);
}