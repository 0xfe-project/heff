// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_Bug 14592
#define TAG_Div 16157
#define TAG_Ok 9325
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_keys 9783995
#define LBL_values 1123329101
V g_heff_2ecompile_2einterp_2ebitsCopy(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsCopy_clo;
V g_heff_2ecompile_2einterp_2ebitsPush(V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsPush_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsPush_clo;
V g_heff_2ecompile_2einterp_2ebitsRead(V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsRead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsRead_clo;
V g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103(V, V, V);
V g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103_clo;
V g_heff_2ecompile_2einterp_2eevalEach(V, V, V);
V g_heff_2ecompile_2einterp_2eevalEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalEach_clo;
V g_heff_2ecompile_2einterp_2efloat2(V);
V g_heff_2ecompile_2einterp_2efloat2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloat2_clo;
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get(void);
V g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130_clo;
V g_heff_2ecompile_2einterp_2elistValsGo(V, V);
V g_heff_2ecompile_2einterp_2elistValsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elistValsGo_clo;
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void);
V g_heff_2ecompile_2einterp_2enotAnInt_get(void);
V g_heff_2ecompile_2einterp_2escalarV(V);
V g_heff_2ecompile_2einterp_2escalarV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2escalarV_clo;
V g_heff_2ecompile_2einterp_2eshowValGo_24tok1(V, V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_24tok1_clo;
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(V);
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2emap_24s24324293x740715900(V, V);
V g_list_2emap_24s24324293x740715900_entry(V self, V *a);
extern Clo g_list_2emap_24s24324293x740715900_clo;
V g_list_2emap_24s391931963x434308123(V);
V g_list_2emap_24s391931963x434308123_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_clo;
V g_list_2emap_24s503834852x510769098(V, V);
V g_list_2emap_24s503834852x510769098_entry(V self, V *a);
extern Clo g_list_2emap_24s503834852x510769098_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_heff_2ecompile_2einterp_2efloat2_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat2_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2efloat2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat2_entry, 1, 0};

V g_heff_2ecompile_2einterp_2efloat2(V v_f_240) {
top: ;
  return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2ecompile_2einterp_2efloat2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2efloat2(a[0]);
}
V g_heff_2ecompile_2einterp_2efloat2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Ok = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_call(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      V v_f_249 = v_f_240;
      V v_x2_2410 = v_v_246;
      V v_x3_2411 = v_v_248;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_VFun: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VCons: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VTag: {
        heff_take_n(v_x2_2410, 0ULL, 2);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VInt: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VFloat: {
        V v_a_2417 = heff_tget_v(v_x2_2410, 0);
        heff_take_na(v_x2_2410, 0ULL, 1);
        switch (heff_tag_of(v_x3_2411)) {
        case TAG_VFun: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VCons: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VTag: {
          heff_take_n(v_x3_2411, 0ULL, 2);
          heff_drop(v_f_249);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VInt: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VFloat: {
          V v_b_2423 = heff_tget_v(v_x3_2411, 0);
          heff_take_na(v_x3_2411, 0ULL, 1);
          V f_ = v_f_249;
          args[0] = v_a_2417;
          args[1] = v_b_2423;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        case TAG_VFloat32: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VStr: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VRune: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VArr: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBits: {
          heff_take_n(v_x3_2411, 0ULL, 2);
          heff_drop(v_f_249);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VErased: {
          heff_drop(v_f_249);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        default: return heff_nomatch(v_x3_2411);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VStr: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VRune: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VArr: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBits: {
        heff_take_n(v_x2_2410, 0ULL, 2);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VErased: {
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      default: return heff_nomatch(v_x2_2410);
      }
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2438 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return heff_tag_at_n(v_ru_24x1_245_24Ok, TAG_Bug, 1, (V[]){v_what_2438});
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2439 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Bug = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return heff_tag_at_n(v_ru_24x1_245_24Bug, TAG_Bug, 1, (V[]){v_what_2439});
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2ecompile_2einterp_2efloat2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
Clo g_heff_2ecompile_2einterp_2ebitsCopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitsCopy_entry, 5, 0};

V g_heff_2ecompile_2einterp_2ebitsCopy(V v_n_240, V v_s_241, V v_t_242, V v_i_243, V v_j_244) {
top: ;
  if (heff_intLe_c_lent(v_j_244, v_i_243, 0)) {
    heff_drop(v_n_240);
    heff_drop(v_i_243);
    heff_drop(v_j_244);
    return v_s_241;
  } else {
    if (((heff_unbox_word(heff_intMod(heff_dup(v_n_240), MK_INT(8LL))) == ((int64_t)0ULL)) && ((heff_unbox_word(heff_intMod(heff_dup(v_i_243), MK_INT(8LL))) == ((int64_t)0ULL)) && heff_intLe_c(MK_INT(8LL), heff_intSub(heff_dup(v_j_244), heff_dup(v_i_243)))))) {
      V v_t_245 = heff_intDiv(heff_intSub(heff_dup(v_j_244), heff_dup(v_i_243)), MK_INT(8LL));
      V v_t_246 = heff_intAdd(v_n_240, heff_intMul(v_t_245, MK_INT(8LL)));
      V v_t_247 = heff_intDiv(heff_intSub(heff_dup(v_j_244), heff_dup(v_i_243)), MK_INT(8LL));
      V v_t_248 = heff_intAdd(heff_intDiv(heff_dup(v_i_243), MK_INT(8LL)), v_t_247);
      V v_t_249 = heff_strSlice(heff_dup(v_t_242), heff_intDiv(heff_dup(v_i_243), MK_INT(8LL)), v_t_248);
      V v_t_2410 = heff_intDiv(heff_intSub(heff_dup(v_j_244), heff_dup(v_i_243)), MK_INT(8LL));
      V v_t_2411 = heff_intAdd(v_i_243, heff_intMul(v_t_2410, MK_INT(8LL)));
      V t_0 = v_t_246;
      V t_1 = heff_strAppend(v_s_241, v_t_249);
      V t_2 = v_t_242;
      V t_3 = v_t_2411;
      V t_4 = v_j_244;
      v_n_240 = t_0;
      v_s_241 = t_1;
      v_t_242 = t_2;
      v_i_243 = t_3;
      v_j_244 = t_4;
      goto top;
    } else {
      V v_y_2412 = heff_intSub(heff_dup(v_j_244), heff_dup(v_i_243));
      V v_t_2413;
      if (heff_intLe_c_lent(MK_INT(8LL), v_y_2412, 1)) {
        heff_drop(v_y_2412);
        v_t_2413 = MK_INT(8LL);
      } else {
        v_t_2413 = v_y_2412;
      }
      V v_y_2414 = heff_intSub(heff_dup(v_j_244), heff_dup(v_i_243));
      V v_t_2415;
      if (heff_intLe_c_lent(MK_INT(8LL), v_y_2414, 1)) {
        heff_drop(v_y_2414);
        v_t_2415 = MK_INT(8LL);
      } else {
        v_t_2415 = v_y_2414;
      }
      V v_t_2416 = (g_heff_2ecompile_2einterp_2ebitsRead(v_t_242, heff_dup(v_i_243), v_t_2415, MK_INT(0LL)));
      V v_y_2417 = heff_intSub(heff_dup(v_j_244), heff_dup(v_i_243));
      V v_t_2418;
      if (heff_intLe_c_lent(MK_INT(8LL), v_y_2417, 1)) {
        heff_drop(v_y_2417);
        v_t_2418 = MK_INT(8LL);
      } else {
        v_t_2418 = v_y_2417;
      }
      V v_t_2419 = (g_heff_2ecompile_2einterp_2ebitsPush(heff_dup(v_n_240), v_s_241, v_t_2416, v_t_2418));
      V v_y_2420 = heff_intSub(heff_dup(v_j_244), heff_dup(v_i_243));
      V v_t_2421;
      if (heff_intLe_c_lent(MK_INT(8LL), v_y_2420, 1)) {
        heff_drop(v_y_2420);
        v_t_2421 = MK_INT(8LL);
      } else {
        v_t_2421 = v_y_2420;
      }
      V t_0 = heff_intAdd(v_n_240, v_t_2413);
      V t_1 = v_t_2419;
      V t_2 = v_t_242;
      V t_3 = heff_intAdd(v_i_243, v_t_2421);
      V t_4 = v_j_244;
      v_n_240 = t_0;
      v_s_241 = t_1;
      v_t_242 = t_2;
      v_i_243 = t_3;
      v_j_244 = t_4;
      goto top;
    }
  }
}
V g_heff_2ecompile_2einterp_2ebitsCopy_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2einterp_2ebitsCopy(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103(V v_box_24n_240, V v_a_241, V v_b_242) {
  int64_t v_n_240 = heff_unbox_word(v_box_24n_240);
top: ;
  if ((v_n_240 == ((int64_t)0ULL))) {
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return MK_INT(0LL);
  } else {
    int64_t v_t_243 = (heff_unbox_word(heff_intMod(heff_dup(v_a_241), MK_INT(2LL))) * heff_unbox_word(heff_intMod(heff_dup(v_b_242), MK_INT(2LL))));
    V v_t_244 = (g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103(heff_box_word((v_n_240 - ((int64_t)1ULL))), heff_intDiv(v_a_241, MK_INT(2LL)), heff_intDiv(v_b_242, MK_INT(2LL))));
    return heff_intAdd(heff_box_word(v_t_243), heff_intMul(MK_INT(2LL), v_t_244));
  }
}
V g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_st;
static V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_st)) return g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_val;
  return heff_global(&g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_val, &g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_st, g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_init);
}
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_VInt, 1, (V[]){heff_intAdd(v_a_2412, v_b_2417)});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2418});
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_lam1, 2, 1, (V[]){v_a_241})})});
}
Clo g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130_entry, 5, 0};

V g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130(V v_box_24lit_240, V v_lit_241, V v_lit_242, V v_a_243, V v_b_244) {
  int64_t v_lit_240 = heff_unbox_word(v_box_24lit_240);
top: ;
  if (((heff_intEq_c_lent(v_a_243, MK_INT(0LL), 2) || heff_intEq_c_lent(v_a_243, MK_INT(-1LL), 2)) && (heff_intEq_c_lent(v_b_244, MK_INT(0LL), 2) || heff_intEq_c_lent(v_b_244, MK_INT(-1LL), 2)))) {
    int64_t v_t_245 = (heff_unbox_word(heff_intMod(v_a_243, MK_INT(2LL))) + heff_unbox_word(heff_intMod(v_b_244, MK_INT(2LL))));
    V v_t_246;
    if ((v_lit_240 < v_t_245)) {
      heff_drop(v_lit_242);
      v_t_246 = v_lit_241;
    } else {
      heff_drop(v_lit_241);
      v_t_246 = v_lit_242;
    }
    return heff_box_word((((int64_t)0ULL) - heff_unbox_word(v_t_246)));
  } else {
    int64_t v_t_247 = (heff_unbox_word(heff_intMod(heff_dup(v_a_243), MK_INT(2LL))) + heff_unbox_word(heff_intMod(heff_dup(v_b_244), MK_INT(2LL))));
    V v_t_248;
    if ((v_lit_240 < v_t_247)) {
      v_t_248 = heff_dup(v_lit_241);
    } else {
      v_t_248 = heff_dup(v_lit_242);
    }
    V v_t_249 = (g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130(heff_box_word(v_lit_240), v_lit_241, v_lit_242, heff_intDiv(v_a_243, MK_INT(2LL)), heff_intDiv(v_b_244, MK_INT(2LL))));
    return heff_intAdd(v_t_248, heff_intMul(MK_INT(2LL), v_t_249));
  }
}
V g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2einterp_2eevalEach_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2eevalEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eevalEach_entry, 3, 0};

V g_heff_2ecompile_2einterp_2eevalEach(V v_ev_240, V v_x2_241, V v_k_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ev_240);
    return heff_tail(v_k_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_t_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_x1_245 = heff_tr(heff_call(heff_dup(v_ev_240), 1, (V[]){v_t_243}));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_Ok: {
      V v_v_246 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      V t_0 = v_ev_240;
      V t_1 = v_rest_244;
      V t_2 = heff_clo_n(g_heff_2ecompile_2einterp_2eevalEach_lam0, 1, 2, (V[]){v_k_242, v_v_246});
      v_ev_240 = t_0;
      v_x2_241 = t_1;
      v_k_242 = t_2;
      goto top;
    }
    case TAG_Abn: {
      heff_drop(v_ev_240);
      heff_drop(v_k_242);
      heff_drop(v_rest_244);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_ev_240);
      heff_drop(v_k_242);
      heff_drop(v_rest_244);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_248 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24Bug = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      heff_drop(v_ev_240);
      heff_drop(v_k_242);
      heff_drop(v_rest_244);
      return heff_tag_at_n(v_ru_24x1_245_24Bug, TAG_Bug, 1, (V[]){v_what_248});
    }
    default: return heff_nomatch(v_x1_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2einterp_2eevalEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eevalEach(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2einterp_2eevalEach_lam0(V self, V *args) {
  V v_vs_247 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_v_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_v_246, v_vs_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_str0, 3, "Nil");
HEFF_LIT(g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_str1, 4, "Cons");
Clo g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_entry, 1, 0};

V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_str0), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x_243 = heff_tag_n(TAG_VRune, 1, (V[]){heff_runeToInt(v_x_241)});
    V v_t_244 = (g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(v_xs_242));
    V v_t_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_str1), heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_t_245})});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str0, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str2, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str3, 2, "{ ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str4, 2, " }");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str5, 3, "Nil");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str6, 4, "Cons");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str7, 1, " ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str10, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str11, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str12, 1, " ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str16, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str17, 1, "[");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str18, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str20, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str21, 1, "[");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str22, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str23, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str24, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str25, 1, ")");
Clo g_heff_2ecompile_2einterp_2eshowValGo_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eshowValGo_24tok1_entry, 3, 0};

V g_heff_2ecompile_2einterp_2eshowValGo_24tok1(V v_tok_240, V v_inArg_241, V v_v_242) {
top: ;
  switch (heff_tag_of(v_v_242)) {
  case TAG_VCons: {
    V v_fs_243 = heff_field(v_v_242, 0);
    heff_take_n(v_v_242, 1ULL, 1);
    heff_drop_cell(v_tok_240, 1);
    V v_keys_244 = heff_take_field(v_fs_243, 0);
    V v_values_245 = heff_get_n(v_fs_243, 2, 3);
    V v_t_246 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_244), heff_arrayToList(v_values_245)));
    V v_x2_247 = (g_list_2emap_24s24324293x740715900(((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str0), v_t_246));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str3), v_t_2410), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str4));
  }
  case TAG_VTag: {
    V v_x_2411 = heff_field(v_v_242, 0);
    V v_vs_2412 = heff_field(v_v_242, 1);
    V v_ru_24v_242_24VTag = heff_take_reuse_n(v_v_242, 3ULL, 2);
    V v_t_2422;
    if (heff_strEq_c_lent(v_x_2411, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str5), 2)) {
      heff_drop_cell(v_ru_24v_242_24VTag, 2);
      switch (heff_tag_of(v_vs_2412)) {
      case TAG_Nil: {
        v_t_2422 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        heff_drop_cell(v_tok_240, 1);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_vs_2412);
      }
    } else {
      heff_drop_cell(v_tok_240, 1);
      if (heff_strEq_c_lent(v_x_2411, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str6), 2)) {
        switch (heff_tag_of(v_vs_2412)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24v_242_24VTag, 2);
          v_t_2422 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_x_2415 = heff_dup(heff_field(v_vs_2412, 0));
          V v_x122_2416 = heff_dup(heff_field(v_vs_2412, 1));
          switch (heff_tag_of(v_x122_2416)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24v_242_24VTag, 2);
            heff_drop(v_x_2415);
            v_t_2422 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Cons: {
            V v_rest_2417 = heff_field(v_x122_2416, 0);
            V v_x1222_2418 = heff_field(v_x122_2416, 1);
            heff_take_n(v_x122_2416, 3ULL, 2);
            switch (heff_tag_of(v_x1222_2418)) {
            case TAG_Nil: {
              V v_t_2419 = heff_tag_at_n(v_ru_24v_242_24VTag, TAG_Cons, 2, (V[]){v_x_2415, NTAG(TAG_Nil)});
              v_t_2422 = (g_heff_2ecompile_2einterp_2elistValsGo(v_rest_2417, v_t_2419));
              break;
            }
            case TAG_Cons: {
              heff_take_n(v_x1222_2418, 0ULL, 2);
              heff_drop_cell(v_ru_24v_242_24VTag, 2);
              heff_drop(v_x_2415);
              heff_drop(v_rest_2417);
              v_t_2422 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_x1222_2418);
            }
            break;
          }
          default: heff_nomatch(v_x122_2416);
          }
          break;
        }
        default: heff_nomatch(v_vs_2412);
        }
      } else {
        heff_drop_cell(v_ru_24v_242_24VTag, 2);
        v_t_2422 = NTAG(TAG_Nothing);
      }
    }
    switch (heff_tag_of(v_t_2422)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_vs_2412)) {
      case TAG_Nil: {
        return v_x_2411;
      }
      case TAG_Cons: {
        if ((heff_dup(v_inArg_241) == NTAG(TAG_True))) {
          V v_x2_2425 = (g_list_2emap_24s503834852x510769098(((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str7), v_vs_2412));
          V v_t_2428;
          switch (heff_tag_of(v_x2_2425)) {
          case TAG_Nil: {
            v_t_2428 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str8);
            break;
          }
          case TAG_Cons: {
            V v_x_2426 = heff_field(v_x2_2425, 0);
            V v_xs_2427 = heff_field(v_x2_2425, 1);
            heff_take_n(v_x2_2425, 3ULL, 2);
            v_t_2428 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str9); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2425);
          }
          V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str10), v_x_2411), v_t_2428);
          return heff_strAppend(v_t_2429, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str11));
        } else {
          V v_x2_2430 = (g_list_2emap_24s503834852x510769098(((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str12), v_vs_2412));
          V v_t_2433;
          switch (heff_tag_of(v_x2_2430)) {
          case TAG_Nil: {
            v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str13);
            break;
          }
          case TAG_Cons: {
            V v_x_2431 = heff_field(v_x2_2430, 0);
            V v_xs_2432 = heff_field(v_x2_2430, 1);
            heff_take_n(v_x2_2430, 3ULL, 2);
            v_t_2433 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str14); V a_1 = v_x_2431; V a_2 = v_xs_2432; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2432); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2430);
          }
          return heff_strAppend(v_x_2411, v_t_2433);
        }
      }
      default: return heff_nomatch(v_vs_2412);
      }
    }
    case TAG_Just: {
      V v_items_2434 = heff_field(v_t_2422, 0);
      heff_take_n(v_t_2422, 1ULL, 1);
      heff_drop(v_x_2411);
      heff_drop(v_vs_2412);
      V v_x2_2435 = (g_list_2emap_24s391931963x434308123(v_items_2434));
      V v_t_2438;
      switch (heff_tag_of(v_x2_2435)) {
      case TAG_Nil: {
        v_t_2438 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str15);
        break;
      }
      case TAG_Cons: {
        V v_x_2436 = heff_field(v_x2_2435, 0);
        V v_xs_2437 = heff_field(v_x2_2435, 1);
        heff_take_n(v_x2_2435, 3ULL, 2);
        v_t_2438 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str16); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2435);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str17), v_t_2438), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str18));
    }
    default: return heff_nomatch(v_t_2422);
    }
  }
  case TAG_VArr: {
    V v_xs_2439 = heff_field(v_v_242, 0);
    heff_take_n(v_v_242, 1ULL, 1);
    heff_drop_cell(v_tok_240, 1);
    V v_x2_2440 = (g_list_2emap_24s391931963x434308123(heff_arrayToList(v_xs_2439)));
    V v_t_2443;
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_xs_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      v_t_2443 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str20); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2440);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str21), v_t_2443), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str22));
  }
  default: {
    heff_drop_cell(v_tok_240, 1);
    if ((heff_dup(v_inArg_241) == NTAG(TAG_True))) {
      V v_s_2444 = (g_heff_2ecompile_2einterp_2escalarV(v_v_242));
      if (heff_strEq_c(heff_strSlice(v_s_2444, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str23))) {
        V v_t_2445 = ({ V a_0 = v_v_242; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop(v_v_242); r_; });
        return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str24), v_t_2445), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_24tok1_str25));
      } else {
        return ({ V a_0 = v_v_242; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop(v_v_242); r_; });
      }
    } else {
      return ({ V a_0 = v_v_242; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop(v_v_242); r_; });
    }
  }
  }
}
V g_heff_2ecompile_2einterp_2eshowValGo_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2einterp_2eshowValGo_24tok1(a[0], a1, a[2]); heff_drop(a1); return r;
}