// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_Right 62770
#define LBL_hash 9690581
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_clo;
V g_list_2ekeepIf_24s25507577x707942422(V, V, V);
V g_list_2ekeepIf_24s25507577x707942422_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s25507577x707942422_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str0, 10, " requires ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str2, 38, ", which is not fetched: run `heff get`");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str3, 25, "heff.sum says nothing of ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str5, 16, ": run `heff get`");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str6, 1, " ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str7, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str8, 4, " is ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str9, 20, ", and heff.sum says ");
Clo g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_entry, 8, 0};

V g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0(V v_k_240, V v_by_241, V v_path_242, V v_v_243, V v_sums_244, V v_ps_245, V v_hd_246, V v_x_247) {
top: ;
  switch (heff_tag_of(v_x_247)) {
  case TAG_Left: {
    V v_ru_24x_247_24Left = heff_take_reuse_n(v_x_247, 0ULL, 1);
    heff_drop(v_sums_244);
    heff_drop(v_ps_245);
    heff_drop(v_hd_246);
    V v_t_249 = heff_strAppend(heff_strAppend(v_by_241, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str0)), v_path_242);
    V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str1)), v_v_243);
    V v_t_2411 = heff_tag_at_n(v_ru_24x_247_24Left, TAG_Left, 1, (V[]){heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str2))});
    return heff_tail(v_k_240, 1, (V[]){v_t_2411});
  }
  case TAG_Right: {
    V v_y_2412 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Right = heff_take_reuse_n(v_x_247, 1ULL, 1);
    heff_drop(v_by_241);
    V v_t_2413 = (g_list_2ekeepIf_24s25507577x707942422(v_path_242, v_v_243, v_sums_244));
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nil: {
      heff_drop(v_ps_245);
      heff_drop(v_hd_246);
      heff_drop(v_y_2412);
      heff_drop_cell(v_ru_24x_247_24Right, 1);
      V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str3), v_path_242), ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str4));
      V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2414, v_v_243), ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str5));
      return heff_tail(v_k_240, 1, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2415})});
    }
    case TAG_Cons: {
      V v_s_2416 = heff_field(v_t_2413, 0);
      heff_take_n(v_t_2413, 1ULL, 2);
      V v_want_2418 = heff_get_n(v_s_2416, 2, 3);
      V v_t_2419 = (g_prelude_2eskipSpaces(v_y_2412, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2420 = (heff_unbox_word(heff_strLength_lent(v_y_2412, 0)) - ((int64_t)1ULL));
      V v_t_2421 = (g_prelude_2eskipSpaces(v_y_2412, heff_box_word(v_t_2420), MK_INT(-1LL)));
      V v_t_2422 = heff_strSlice(heff_dup(v_y_2412), v_t_2419, heff_intAdd(v_t_2421, MK_INT(1LL)));
      if (heff_strEq_c_lent(v_t_2422, v_want_2418, 1)) {
        heff_drop(v_y_2412);
        heff_drop_cell(v_ru_24x_247_24Right, 1);
        heff_drop(v_want_2418);
        V v_t_2423 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_245), heff_dup(v_path_242), v_v_243));
        V v_t_2424 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546(v_ps_245, v_t_2423, v_path_242));
        return heff_tail(v_t_2424, 2, (V[]){v_hd_246, v_k_240});
      } else {
        heff_drop(v_hd_246);
        V v_t_2425 = (g_heff_2ebuild_2eload_2ecachedDir(v_ps_245, heff_dup(v_path_242), heff_dup(v_v_243)));
        V v_t_2426 = (g_prelude_2eskipSpaces(v_y_2412, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2427 = (heff_unbox_word(heff_strLength_lent(v_y_2412, 0)) - ((int64_t)1ULL));
        V v_t_2428 = (g_prelude_2eskipSpaces(v_y_2412, heff_box_word(v_t_2427), MK_INT(-1LL)));
        V v_t_2429 = heff_strAppend(heff_strAppend(v_path_242, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str6)), v_v_243);
        V v_t_2430 = heff_strAppend(heff_strAppend(v_t_2429, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str7)), v_t_2425);
        V v_t_2431 = heff_strSlice(v_y_2412, v_t_2426, heff_intAdd(v_t_2428, MK_INT(1LL)));
        V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2430, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str8)), v_t_2431);
        V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2432, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_str9)), v_want_2418);
        V v_x_2434 = heff_tag_at_n(v_ru_24x_247_24Right, TAG_Left, 1, (V[]){v_t_2433});
        return heff_tail(v_k_240, 1, (V[]){v_x_2434});
      }
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}