// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891 9477
#define TAG_Enter_24heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301 6154
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_args 9498020
#define LBL_ctx 308385
#define LBL_def 308863
#define LBL_head 9693863
#define LBL_im 10123
#define LBL_indent 762902487
#define LBL_keys 9783995
#define LBL_large 304101205
#define LBL_names 305943394
#define LBL_out 319944
#define LBL_rest 9992347
#define LBL_values 1123329101
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_im__indent[] = {LBL_im, LBL_indent};
static uint32_t shape_names__out[] = {LBL_names, LBL_out};
static uint32_t shape_names__rest__ctx[] = {LBL_names, LBL_rest, LBL_ctx};
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_clo;
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_clo;
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345_clo;
V g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994_clo;
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_clo;
V g_heff_2esyntax_2esurfaceprint_2eformerAt(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eformerAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eformerAt_clo;
V g_heff_2esyntax_2esurfaceprint_2eformerParam(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eformerParam_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eformerParam_clo;
V g_heff_2esyntax_2esurfaceprint_2eimplicitGroup(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eimplicitGroup_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eimplicitGroup_clo;
V g_heff_2esyntax_2esurfaceprint_2eisData(V, V);
V g_heff_2esyntax_2esurfaceprint_2eisData_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eisData_clo;
V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_clo;
V g_heff_2esyntax_2esurfaceprint_2elambdas(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2elambdas_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elambdas_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr(V);
V g_heff_2esyntax_2esurfaceprint_2elocalName(V, V);
V g_heff_2esyntax_2esurfaceprint_2elocalName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elocalName_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_clo;
V g_heff_2esyntax_2esurfaceprint_2espineGo(V, V);
V g_heff_2esyntax_2esurfaceprint_2espineGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2espineGo_clo;
V g_heff_2esyntax_2esurfaceprint_2estripIs(V);
V g_heff_2esyntax_2esurfaceprint_2estripIs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2estripIs_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle(V, V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(V, V, V, V);
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_heff_2eutil_2erune_2equoteBytesGo(V, V, V, V);
V g_heff_2eutil_2erune_2equoteBytesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteBytesGo_clo;
V g_heff_2eutil_2erune_2equoteGo(V, V, V);
V g_heff_2eutil_2erune_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteGo_clo;
V g_heff_2eutil_2erune_2equoted(V);
V g_heff_2eutil_2erune_2equoted_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoted_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_clo;
Clo g_heff_2esyntax_2esurfaceprint_2espineGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2espineGo_entry, 2, 0};

V g_heff_2esyntax_2esurfaceprint_2espineGo(V v_h_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_h_240)) {
  case TAG_SLocal: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SGlobal: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SCode: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SApp: {
    V v_f_245 = heff_field(v_h_240, 0);
    V v_a_246 = heff_field(v_h_240, 1);
    V v_ru_24h_240_24SApp = heff_take_reuse_n(v_h_240, 3ULL, 2);
    V t_0 = v_f_245;
    V t_1 = heff_tag_at_n(v_ru_24h_240_24SApp, TAG_Cons, 2, (V[]){v_a_246, v_acc_241});
    v_h_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_SLam: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SCons: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SProj: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_STag: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SMatch: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SSpecialize: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SIs: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SOpaque: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SAbandon: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SRec: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SFix: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SImplicit: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SPrim: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SMetaApp: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitInt: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitFloat: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitString: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitBytes: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitRune: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitFixed: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitFloat32: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  default: return heff_nomatch(v_h_240);
  }
}
V g_heff_2esyntax_2esurfaceprint_2espineGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2espineGo(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurfaceprint_2eimplicitGroup_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eimplicitGroup_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eimplicitGroup(V v_names_240, V v_u_241, V v_rest_242, V v_ctx_243) {
top: ;
  switch (heff_tag_of(v_rest_242)) {
  case TAG_SU: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SDecode: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SFunction: {
    V v_rest2_247 = heff_dup(heff_field(v_rest_242, 1));
    V v_rest3_248 = heff_dup(heff_field(v_rest_242, 2));
    V v_rest4_249 = heff_dup(heff_field(v_rest_242, 3));
    V v_rest5_2410 = heff_dup(heff_field(v_rest_242, 4));
    switch (heff_tag_of(v_rest2_247)) {
    case TAG_SU: {
      V v_u_27_2411 = heff_field(v_rest2_247, 0);
      heff_take_n(v_rest2_247, 1ULL, 1);
      switch (heff_tag_of(v_rest3_248)) {
      case TAG_MkAbs: {
        V v_y_2412 = heff_field(v_rest3_248, 0);
        V v_b_2413 = heff_field(v_rest3_248, 1);
        V v_ru_24rest3_248_24MkAbs = heff_take_reuse_n(v_rest3_248, 3ULL, 2);
        switch (heff_tag_of(v_rest4_249)) {
        case TAG_Expl: {
          heff_drop(v_rest5_2410);
          heff_drop(v_u_27_2411);
          heff_drop(v_y_2412);
          heff_drop(v_b_2413);
          heff_drop_cell(v_ru_24rest3_248_24MkAbs, 2);
          return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
        }
        case TAG_Impl: {
          switch (heff_tag_of(v_rest5_2410)) {
          case TAG_Nothing: {
            switch (heff_tag_of(v_u_241)) {
            case TAG_SmallU: {
              switch (heff_tag_of(v_u_27_2411)) {
              case TAG_SmallU: {
                heff_drop_tag(v_rest_242, 5);
                V v_t_2414 = heff_tag_at_n(v_ru_24rest3_248_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_y_2412), NTAG(TAG_Nil)});
                V v_t_2415 = (g_prelude_2e_2b_2b(v_names_240, v_t_2414));
                V t_0 = v_t_2415;
                V t_1 = v_u_241;
                V t_2 = v_b_2413;
                V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_2412, v_ctx_243});
                v_names_240 = t_0;
                v_u_241 = t_1;
                v_rest_242 = t_2;
                v_ctx_243 = t_3;
                goto top;
              }
              case TAG_LargeU: {
                heff_drop(v_y_2412);
                heff_drop(v_b_2413);
                heff_drop_cell(v_ru_24rest3_248_24MkAbs, 2);
                return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
              }
              default: return heff_nomatch(v_u_27_2411);
              }
            }
            case TAG_LargeU: {
              switch (heff_tag_of(v_u_27_2411)) {
              case TAG_SmallU: {
                heff_drop(v_y_2412);
                heff_drop(v_b_2413);
                heff_drop_cell(v_ru_24rest3_248_24MkAbs, 2);
                return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
              }
              case TAG_LargeU: {
                heff_drop_tag(v_rest_242, 5);
                V v_t_2416 = heff_tag_at_n(v_ru_24rest3_248_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_y_2412), NTAG(TAG_Nil)});
                V v_t_2417 = (g_prelude_2e_2b_2b(v_names_240, v_t_2416));
                V t_0 = v_t_2417;
                V t_1 = v_u_241;
                V t_2 = v_b_2413;
                V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_2412, v_ctx_243});
                v_names_240 = t_0;
                v_u_241 = t_1;
                v_rest_242 = t_2;
                v_ctx_243 = t_3;
                goto top;
              }
              default: return heff_nomatch(v_u_27_2411);
              }
            }
            default: return heff_nomatch(v_u_241);
            }
          }
          case TAG_Just: {
            heff_take_n(v_rest5_2410, 0ULL, 1);
            heff_drop(v_u_27_2411);
            heff_drop(v_y_2412);
            heff_drop(v_b_2413);
            heff_drop_cell(v_ru_24rest3_248_24MkAbs, 2);
            return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
          }
          default: return heff_nomatch(v_rest5_2410);
          }
        }
        case TAG_Inst: {
          heff_drop(v_rest5_2410);
          heff_drop(v_u_27_2411);
          heff_drop(v_y_2412);
          heff_drop(v_b_2413);
          heff_drop_cell(v_ru_24rest3_248_24MkAbs, 2);
          return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
        }
        default: return heff_nomatch(v_rest4_249);
        }
      }
      case TAG_AbsConst: {
        heff_take_n(v_rest3_248, 0ULL, 1);
        heff_drop(v_rest4_249);
        heff_drop(v_rest5_2410);
        heff_drop(v_u_27_2411);
        return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
      }
      default: return heff_nomatch(v_rest3_248);
      }
    }
    case TAG_SDecode: {
      heff_take_n(v_rest2_247, 0ULL, 1);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SFunction: {
      heff_take_n(v_rest2_247, 0ULL, 5);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SRecord: {
      heff_take_n(v_rest2_247, 0ULL, 3);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SSum: {
      heff_take_n(v_rest2_247, 0ULL, 1);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SIsTy: {
      heff_take_n(v_rest2_247, 0ULL, 1);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SPrimInt: {
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SPrimFloat: {
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SPrimString: {
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SPrimRune: {
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SPrimArray: {
      heff_take_n(v_rest2_247, 0ULL, 1);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SFixed: {
      heff_take_n(v_rest2_247, 0ULL, 1);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    default: return heff_nomatch(v_rest2_247);
    }
  }
  case TAG_SRecord: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SSum: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SIsTy: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SPrimInt: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SPrimFloat: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SPrimString: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SPrimRune: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SPrimArray: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SFixed: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  default: return heff_nomatch(v_rest_242);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eimplicitGroup_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurfaceprint_2eimplicitGroup(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994_str2, 5, "} -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994_str3, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994_str4, 1, "{");
Clo g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994(V v_c_240, V v_xs_241, V v_dom_242, V v_r_243) {
top: ;
  V v_t_244 = heff_take_field(v_r_243, 0);
  V v_t_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_t_244, 0);
    V v_xs_246 = heff_field(v_t_244, 1);
    heff_take_n(v_t_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_248 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_dup(v_c_240), MK_INT(0LL), v_xs_241, v_dom_242));
  V v_t_249 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_c_240, MK_INT(0LL), heff_take_field(v_r_243, 2), heff_get_n(v_r_243, 1, 3)));
  V v_t_2410 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994_str2), v_t_249));
  V v_t_2411 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994_str3), v_t_2410));
  return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994_str4), v_t_2411);
}
V g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2earrowGrouped_24s1193018207x1662914994(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str0, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str1, 6, "Theory");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str6, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str7, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str9, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str10, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str11, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str14, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str15, 7, "data { ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str16, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str17, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str18, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str19, 6, "String");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str20, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str21, 6, "Array ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str22, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str23, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str24, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str25, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str26, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str27, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str28, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str29, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str30, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str31, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str32, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str33, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str34, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str35, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str36, 3, "op_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str37, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str38, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str39, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str40, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str41, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str42, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str43, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str44, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str45, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str46, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str47, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str48, 1, ".");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str49, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str50, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str51, 1, "[");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str52, 1, "]");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str53, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str54, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str55, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str56, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str57, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str58, 3, " of");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str59, 5, "case ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str60, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str61, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str62, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str63, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str64, 5, " ~ { ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str65, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str66, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str67, 8, "<opaque>");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str68, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str69, 7, "<local>");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str70, 11, "<primitive ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str71, 1, ">");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str72, 1, "\?");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str73, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str74, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str75, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str76, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str77, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str78, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str79, 1, "]");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str80, 1, "'");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str81, 1, "'");
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam0(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam2(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam1(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam3(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam4(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam5(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam6(V self, V *args);
Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_entry, 9, 0};

V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle(V v_tag_240, V v_c_241, V v_p_242, V v_xs_243, V v_x5_244, V v_c_245, V v_p_246, V v_xs_247, V v_e_248) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301: {
    top_TAG_Enter_24heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301: ;
    switch (heff_tag_of(v_x5_244)) {
    case TAG_SU: {
      V v_x51_249 = heff_field(v_x5_244, 0);
      heff_take_n(v_x5_244, 1ULL, 1);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      heff_drop(v_e_248);
      switch (heff_tag_of(v_x51_249)) {
      case TAG_SmallU: {
        return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str0);
      }
      case TAG_LargeU: {
        return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str1);
      }
      default: return heff_nomatch(v_x51_249);
      }
    }
    case TAG_SDecode: {
      V v_e_2410 = heff_field(v_x5_244, 0);
      heff_take_n(v_x5_244, 1ULL, 1);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      heff_drop(v_e_248);
      V t_0 = NTAG(TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891);
      V t_1 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str2);
      V t_2 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str3);
      V t_3 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str4);
      V t_4 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str5);
      V t_5 = v_c_241;
      V t_6 = v_p_242;
      V t_7 = v_xs_243;
      V t_8 = v_e_2410;
      v_tag_240 = t_0;
      v_c_241 = t_1;
      v_p_242 = t_2;
      v_xs_243 = t_3;
      v_x5_244 = t_4;
      v_c_245 = t_5;
      v_p_246 = t_6;
      v_xs_247 = t_7;
      v_e_248 = t_8;
      goto top_TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891;
    }
    case TAG_SFunction: {
      V v_level_2411 = heff_field(v_x5_244, 0);
      V v_dom_2412 = heff_field(v_x5_244, 1);
      V v_cod_2413 = heff_field(v_x5_244, 2);
      V v_implicit_2414 = heff_field(v_x5_244, 3);
      V v_dflt_2415 = heff_field(v_x5_244, 4);
      heff_take_n(v_x5_244, 31ULL, 5);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      heff_drop(v_e_248);
      V v_s_2417;
      switch (heff_tag_of(v_dflt_2415)) {
      case TAG_Nothing: {
        v_s_2417 = ({ V a_0 = v_c_241; V a_1 = v_xs_243; V a_2 = v_level_2411; V a_3 = v_dom_2412; V a_4 = v_cod_2413; V a_5 = v_implicit_2414; V r_ = (g_heff_2esyntax_2esurfaceprint_2earrowStr_24s75288723x423497497(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_level_2411); heff_drop(v_implicit_2414); r_; });
        break;
      }
      case TAG_Just: {
        V v_d_2416 = heff_field(v_dflt_2415, 0);
        heff_take_n(v_dflt_2415, 1ULL, 1);
        heff_drop(v_level_2411);
        heff_drop(v_implicit_2414);
        v_s_2417 = (g_heff_2esyntax_2esurfaceprint_2earrowDefault_24s853278263x1295744345(v_c_241, v_xs_243, v_dom_2412, v_cod_2413, v_d_2416));
        break;
      }
      default: heff_nomatch(v_dflt_2415);
      }
      if (heff_intLe_c(MK_INT(1LL), v_p_242)) {
        return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str6), heff_strAppend(v_s_2417, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str7)));
      } else {
        return v_s_2417;
      }
    }
    case TAG_SRecord: {
      V v_fs_2420 = heff_field(v_x5_244, 1);
      V v_ds_2421 = heff_field(v_x5_244, 2);
      heff_take_n(v_x5_244, 6ULL, 3);
      heff_drop(v_p_242);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      heff_drop(v_e_248);
      V v_t_2422 = heff_arrayToList(heff_take_field(v_fs_2420, 0));
      V v_t_2423 = heff_arrayToList(heff_get_n(v_fs_2420, 2, 3));
      V v_fs_2424 = (g_heff_2eutil_2edict_2ezipKV(v_t_2422, v_t_2423));
      V v_t_2425 = heff_rec_n(2, shape_names__out, (V[]){v_xs_243, NTAG(TAG_Nil)});
      V v_acc_2428 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam0, 2, 2, (V[]){v_c_241, v_ds_2421}); V a_1 = v_t_2425; V a_2 = v_fs_2424; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2424); r_; });
      V v_t_2429 = heff_get_n(v_acc_2428, 1, 2);
      V v_t_2432;
      switch (heff_tag_of(v_t_2429)) {
      case TAG_Nil: {
        v_t_2432 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str8);
        break;
      }
      case TAG_Cons: {
        V v_x_2430 = heff_field(v_t_2429, 0);
        V v_xs_2431 = heff_field(v_t_2429, 1);
        heff_take_n(v_t_2429, 3ULL, 2);
        v_t_2432 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str9); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
        break;
      }
      default: heff_nomatch(v_t_2429);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str10), heff_strAppend(v_t_2432, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str11)));
    }
    case TAG_SSum: {
      V v_vs_2433 = heff_field(v_x5_244, 0);
      heff_take_n(v_x5_244, 1ULL, 1);
      heff_drop(v_p_242);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      heff_drop(v_e_248);
      V v_t_2434 = heff_arrayToList(heff_take_field(v_vs_2433, 0));
      V v_t_2435 = heff_arrayToList(heff_get_n(v_vs_2433, 2, 3));
      V v_t_2436 = (g_heff_2eutil_2edict_2ezipKV(v_t_2434, v_t_2435));
      V v_x2_2441 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam1, 1, 2, (V[]){v_c_241, v_xs_243}), v_t_2436));
      V v_t_2444;
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_Nil: {
        v_t_2444 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_xs_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        v_t_2444 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str14); V a_1 = v_x_2442; V a_2 = v_xs_2443; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2443); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2441);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str15), heff_strAppend(v_t_2444, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str16)));
    }
    case TAG_SIsTy: {
      V v_t2_2445 = heff_field(v_x5_244, 0);
      heff_take_n(v_x5_244, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301);
      V t_1 = v_c_241;
      V t_2 = v_p_242;
      V t_3 = v_xs_243;
      V t_4 = v_t2_2445;
      V t_5 = v_c_245;
      V t_6 = v_p_246;
      V t_7 = v_xs_247;
      V t_8 = v_e_248;
      v_tag_240 = t_0;
      v_c_241 = t_1;
      v_p_242 = t_2;
      v_xs_243 = t_3;
      v_x5_244 = t_4;
      v_c_245 = t_5;
      v_p_246 = t_6;
      v_xs_247 = t_7;
      v_e_248 = t_8;
      goto top_TAG_Enter_24heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301;
    }
    case TAG_SPrimInt: {
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      heff_drop(v_e_248);
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str17);
    }
    case TAG_SPrimFloat: {
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      heff_drop(v_e_248);
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str18);
    }
    case TAG_SPrimString: {
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      heff_drop(v_e_248);
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str19);
    }
    case TAG_SPrimRune: {
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      heff_drop(v_e_248);
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str20);
    }
    case TAG_SPrimArray: {
      V v_a_2446 = heff_field(v_x5_244, 0);
      heff_take_n(v_x5_244, 1ULL, 1);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      heff_drop(v_e_248);
      V v_t_2447 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_c_241, MK_INT(2LL), v_xs_243, v_a_2446));
      V v_s_2448 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str21), v_t_2447);
      if (heff_intLe_c(MK_INT(2LL), v_p_242)) {
        return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str22), heff_strAppend(v_s_2448, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str23)));
      } else {
        return v_s_2448;
      }
    }
    case TAG_SFixed: {
      V v_w_2450 = heff_field(v_x5_244, 0);
      heff_take_n(v_x5_244, 1ULL, 1);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      heff_drop(v_e_248);
      switch (heff_tag_of(v_w_2450)) {
      case TAG_I8: {
        return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str24);
      }
      case TAG_I16: {
        return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str25);
      }
      case TAG_I32: {
        return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str26);
      }
      case TAG_I64: {
        return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str27);
      }
      case TAG_U8: {
        return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str28);
      }
      case TAG_U16: {
        return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str29);
      }
      case TAG_U32: {
        return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str30);
      }
      case TAG_U64: {
        return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str31);
      }
      case TAG_F32: {
        return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str32);
      }
      default: return heff_nomatch(v_w_2450);
      }
    }
    default: return heff_nomatch(v_x5_244);
    }
  }
  case TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891: {
    top_TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891: ;
    switch (heff_tag_of(v_e_248)) {
    case TAG_SLocal: {
      V v_i_2451 = heff_field(v_e_248, 0);
      heff_take_n(v_e_248, 1ULL, 1);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      return (g_heff_2esyntax_2esurfaceprint_2elocalName(v_xs_247, v_i_2451));
    }
    case TAG_SGlobal: {
      V v_x_2452 = heff_field(v_e_248, 0);
      heff_take_n(v_e_248, 1ULL, 1);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      if (heff_strEq_c_lent(v_x_2452, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str33), 2)) {
        return v_x_2452;
      } else {
        HeffT2 v_t_2454 = (g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(v_x_2452, MK_INT(0LL), NTAG(TAG_Nil)));
        {
          V v_field_2456 = v_t_2454.f[1];
          int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
          if ((v_tag_2455 == ((int64_t)0ULL))) {
            V v_ws_2458 = v_field_2456;
            V v_t_2461;
            switch (heff_tag_of(v_ws_2458)) {
            case TAG_Nil: {
              v_t_2461 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str34);
              break;
            }
            case TAG_Cons: {
              V v_x_2459 = heff_field(v_ws_2458, 0);
              V v_xs_2460 = heff_field(v_ws_2458, 1);
              heff_take_n(v_ws_2458, 3ULL, 2);
              v_t_2461 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str35); V a_1 = v_x_2459; V a_2 = v_xs_2460; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2460); r_; });
              break;
            }
            default: heff_nomatch(v_ws_2458);
            }
            V v_t_2462 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str36), v_t_2461);
            heff_drop(v_t_2462);
            return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str37), heff_strAppend(v_x_2452, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str38)));
          } else {
            heff_drop(v_field_2456);
            return v_x_2452;
          }
        }
      }
    }
    case TAG_SCode: {
      V v_t_2463 = heff_field(v_e_248, 0);
      heff_take_n(v_e_248, 1ULL, 1);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      V t_0 = NTAG(TAG_Enter_24heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301);
      V t_1 = v_c_245;
      V t_2 = v_p_246;
      V t_3 = v_xs_247;
      V t_4 = v_t_2463;
      V t_5 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str39);
      V t_6 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str40);
      V t_7 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str41);
      V t_8 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str42);
      v_tag_240 = t_0;
      v_c_241 = t_1;
      v_p_242 = t_2;
      v_xs_243 = t_3;
      v_x5_244 = t_4;
      v_c_245 = t_5;
      v_p_246 = t_6;
      v_xs_247 = t_7;
      v_e_248 = t_8;
      goto top_TAG_Enter_24heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301;
    }
    case TAG_SApp: {
      V v_f_2464 = heff_field(v_e_248, 0);
      V v_a_2465 = heff_field(v_e_248, 1);
      V v_ru_24e_248_24SApp = heff_take_reuse_n(v_e_248, 3ULL, 2);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      return (g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(v_c_245, v_p_246, v_xs_247, heff_tag_at_n(v_ru_24e_248_24SApp, TAG_SApp, 2, (V[]){v_f_2464, v_a_2465})));
    }
    case TAG_SLam: {
      V v_t_2466 = heff_field(v_e_248, 0);
      V v_b_2467 = heff_field(v_e_248, 1);
      V v_ru_24e_248_24SLam = heff_take_reuse_n(v_e_248, 3ULL, 2);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      V v_t_2468 = (g_heff_2esyntax_2esurfaceprint_2elambdas(heff_dup(v_xs_247), NTAG(TAG_Nil), heff_tag_at_n(v_ru_24e_248_24SLam, TAG_SLam, 2, (V[]){v_t_2466, v_b_2467})));
      return ({ V a_0 = v_c_245; V a_1 = v_p_246; V a_2 = v_xs_247; V a_3 = v_t_2468; V r_ = (g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(a_0, a_1, a_2, a_3)); heff_drop(v_xs_247); r_; });
    }
    case TAG_SCons: {
      V v_d_2469 = heff_field(v_e_248, 0);
      heff_take_n(v_e_248, 1ULL, 1);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      heff_drop(v_p_246);
      V v_t_2470 = heff_arrayToList(heff_take_field(v_d_2469, 0));
      V v_t_2471 = heff_arrayToList(heff_get_n(v_d_2469, 2, 3));
      V v_t_2472 = (g_heff_2eutil_2edict_2ezipKV(v_t_2470, v_t_2471));
      V v_x2_2477 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam3, 1, 2, (V[]){v_c_245, v_xs_247}), v_t_2472));
      V v_t_2480;
      switch (heff_tag_of(v_x2_2477)) {
      case TAG_Nil: {
        v_t_2480 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str44);
        break;
      }
      case TAG_Cons: {
        V v_x_2478 = heff_field(v_x2_2477, 0);
        V v_xs_2479 = heff_field(v_x2_2477, 1);
        heff_take_n(v_x2_2477, 3ULL, 2);
        v_t_2480 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str45); V a_1 = v_x_2478; V a_2 = v_xs_2479; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2479); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2477);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str46), heff_strAppend(v_t_2480, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str47)));
    }
    case TAG_SProj: {
      V v_e2_2481 = heff_field(v_e_248, 0);
      V v_l_2482 = heff_field(v_e_248, 1);
      heff_take_n(v_e_248, 3ULL, 2);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      heff_drop(v_p_246);
      V v_t_2483 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_245, MK_INT(2LL), v_xs_247, v_e2_2481));
      return heff_strAppend(v_t_2483, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str48), v_l_2482));
    }
    case TAG_STag: {
      V v_x_2484 = heff_dup(heff_field(v_e_248, 0));
      V v_ts_2485 = heff_dup(heff_field(v_e_248, 1));
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      HeffT2 v_t_2486 = (g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr(v_e_248));
      {
        V v_field_2488 = v_t_2486.f[1];
        int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
        if ((v_tag_2487 == ((int64_t)0ULL))) {
          heff_drop(v_p_246);
          heff_drop(v_x_2484);
          heff_drop(v_ts_2485);
          V v_items_2490 = v_field_2488;
          V v_x2_2492 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam4, 1, 2, (V[]){v_c_245, v_xs_247}), v_items_2490));
          V v_t_2495;
          switch (heff_tag_of(v_x2_2492)) {
          case TAG_Nil: {
            v_t_2495 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str49);
            break;
          }
          case TAG_Cons: {
            V v_x_2493 = heff_field(v_x2_2492, 0);
            V v_xs_2494 = heff_field(v_x2_2492, 1);
            heff_take_n(v_x2_2492, 3ULL, 2);
            v_t_2495 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str50); V a_1 = v_x_2493; V a_2 = v_xs_2494; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2494); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2492);
          }
          return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str51), heff_strAppend(v_t_2495, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str52)));
        } else {
          heff_drop(v_field_2488);
          V v_t_2496 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_ts_2485)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
          if (heff_intEq_c(v_t_2496, MK_INT(0LL))) {
            heff_drop_rec(v_c_245, 2);
            heff_drop(v_p_246);
            heff_drop(v_xs_247);
            heff_drop(v_ts_2485);
            return v_x_2484;
          } else {
            V v_s_2499 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str53); V a_1 = v_x_2484; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam5, 1, 2, (V[]){v_c_245, v_xs_247}); V b_3 = heff_arrayToList(v_ts_2485); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
            if (heff_intLe_c(MK_INT(2LL), v_p_246)) {
              return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str54), heff_strAppend(v_s_2499, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str55)));
            } else {
              return v_s_2499;
            }
          }
        }
      }
    }
    case TAG_SMatch: {
      V v_s_24101 = heff_field(v_e_248, 0);
      V v_cases_24102 = heff_field(v_e_248, 1);
      heff_take_n(v_e_248, 3ULL, 2);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      V v_t_24103 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_245), MK_INT(0LL), heff_dup(v_xs_247), v_s_24101));
      V v_t_24104 = heff_arrayToList(heff_take_field(v_cases_24102, 0));
      V v_t_24105 = heff_arrayToList(heff_get_n(v_cases_24102, 2, 3));
      V v_t_24106 = (g_heff_2eutil_2edict_2ezipKV(v_t_24104, v_t_24105));
      V v_x2_24110 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam6, 1, 2, (V[]){v_c_245, v_xs_247}), v_t_24106));
      V v_t_24113;
      switch (heff_tag_of(v_x2_24110)) {
      case TAG_Nil: {
        v_t_24113 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str56);
        break;
      }
      case TAG_Cons: {
        V v_x_24111 = heff_field(v_x2_24110, 0);
        V v_xs_24112 = heff_field(v_x2_24110, 1);
        heff_take_n(v_x2_24110, 3ULL, 2);
        v_t_24113 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str57); V a_1 = v_x_24111; V a_2 = v_xs_24112; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24112); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24110);
      }
      V v_t_24114 = heff_strAppend(v_t_24103, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str58), v_t_24113));
      V v_s_24115 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str59), v_t_24114);
      if (heff_intLe_c(MK_INT(1LL), v_p_246)) {
        return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str60), heff_strAppend(v_s_24115, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str61)));
      } else {
        return v_s_24115;
      }
    }
    case TAG_SSpecialize: {
      V v_e2_24117 = heff_field(v_e_248, 0);
      V v_x_24118 = heff_field(v_e_248, 1);
      V v_v_24119 = heff_field(v_e_248, 2);
      heff_take_n(v_e_248, 7ULL, 3);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      V v_t_24120 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_245), MK_INT(2LL), heff_dup(v_xs_247), v_e2_24117));
      V v_t_24121 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_245, MK_INT(0LL), v_xs_247, v_v_24119));
      V v_t_24122 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str62), heff_strAppend(v_t_24121, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str63)));
      V v_t_24123 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str64), heff_strAppend(v_x_24118, v_t_24122));
      V v_s_24124 = heff_strAppend(v_t_24120, v_t_24123);
      if (heff_intLe_c(MK_INT(1LL), v_p_246)) {
        return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str65), heff_strAppend(v_s_24124, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str66)));
      } else {
        return v_s_24124;
      }
    }
    case TAG_SIs: {
      V v_e2_24126 = heff_field(v_e_248, 0);
      heff_take_n(v_e_248, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891);
      V t_1 = v_c_241;
      V t_2 = v_p_242;
      V t_3 = v_xs_243;
      V t_4 = v_x5_244;
      V t_5 = v_c_245;
      V t_6 = v_p_246;
      V t_7 = v_xs_247;
      V t_8 = v_e2_24126;
      v_tag_240 = t_0;
      v_c_241 = t_1;
      v_p_242 = t_2;
      v_xs_243 = t_3;
      v_x5_244 = t_4;
      v_c_245 = t_5;
      v_p_246 = t_6;
      v_xs_247 = t_7;
      v_e_248 = t_8;
      goto top_TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891;
    }
    case TAG_SOpaque: {
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str67);
    }
    case TAG_SAbandon: {
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str68);
    }
    case TAG_SRec: {
      V v_e2_24127 = heff_field(v_e_248, 0);
      heff_take_n(v_e_248, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891);
      V t_1 = v_c_241;
      V t_2 = v_p_242;
      V t_3 = v_xs_243;
      V t_4 = v_x5_244;
      V t_5 = v_c_245;
      V t_6 = v_p_246;
      V t_7 = v_xs_247;
      V t_8 = v_e2_24127;
      v_tag_240 = t_0;
      v_c_241 = t_1;
      v_p_242 = t_2;
      v_xs_243 = t_3;
      v_x5_244 = t_4;
      v_c_245 = t_5;
      v_p_246 = t_6;
      v_xs_247 = t_7;
      v_e_248 = t_8;
      goto top_TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891;
    }
    case TAG_SFix: {
      V v_e2_27_24129 = heff_field(v_e_248, 1);
      heff_take_n(v_e_248, 2ULL, 2);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      switch (heff_tag_of(v_e2_27_24129)) {
      case TAG_MkAbs: {
        V v_x_24130 = heff_field(v_e2_27_24129, 0);
        heff_take_n(v_e2_27_24129, 1ULL, 2);
        return v_x_24130;
      }
      case TAG_AbsConst: {
        heff_take_n(v_e2_27_24129, 0ULL, 1);
        return ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str69);
      }
      default: return heff_nomatch(v_e2_27_24129);
      }
    }
    case TAG_SImplicit: {
      V v_e2_24134 = heff_field(v_e_248, 1);
      heff_take_n(v_e_248, 2ULL, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891);
      V t_1 = v_c_241;
      V t_2 = v_p_242;
      V t_3 = v_xs_243;
      V t_4 = v_x5_244;
      V t_5 = v_c_245;
      V t_6 = v_p_246;
      V t_7 = v_xs_247;
      V t_8 = v_e2_24134;
      v_tag_240 = t_0;
      v_c_241 = t_1;
      v_p_242 = t_2;
      v_xs_243 = t_3;
      v_x5_244 = t_4;
      v_c_245 = t_5;
      v_p_246 = t_6;
      v_xs_247 = t_7;
      v_e_248 = t_8;
      goto top_TAG_Enter_24heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891;
    }
    case TAG_SPrim: {
      V v_x_24135 = heff_field(v_e_248, 0);
      heff_take_n(v_e_248, 1ULL, 1);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str70), heff_strAppend(v_x_24135, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str71)));
    }
    case TAG_SMetaApp: {
      V v_m_24136 = heff_field(v_e_248, 0);
      heff_take_n(v_e_248, 1ULL, 3);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str72), heff_intShow(v_m_24136));
    }
    case TAG_SLitInt: {
      V v_i_24139 = heff_field(v_e_248, 0);
      heff_take_n(v_e_248, 1ULL, 1);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      return heff_intShow(v_i_24139);
    }
    case TAG_SLitFloat: {
      V v_x_24140 = heff_tget_v(v_e_248, 0);
      heff_take_na(v_e_248, 0ULL, 1);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      return heff_floatShow(v_x_24140);
    }
    case TAG_SLitString: {
      V v_s_24141 = heff_field(v_e_248, 0);
      heff_take_n(v_e_248, 1ULL, 1);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      V v_t_24142 = ({ V a_0 = v_s_24141; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str73); V r_ = (g_heff_2eutil_2erune_2equoteGo(a_0, a_1, a_2)); heff_drop(v_s_24141); r_; });
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str74), heff_strAppend(v_t_24142, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str75)));
    }
    case TAG_SLitBytes: {
      V v_s_24143 = heff_field(v_e_248, 0);
      heff_take_n(v_e_248, 1ULL, 1);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      V v_t_24144 = ({ V a_0 = v_s_24143; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str76); V a_3 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str77); V r_ = (g_heff_2eutil_2erune_2equoteBytesGo(a_0, a_1, a_2, a_3)); heff_drop(v_s_24143); r_; });
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str78), heff_strAppend(v_t_24144, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str79)));
    }
    case TAG_SLitRune: {
      V v_ch_24145 = heff_field(v_e_248, 0);
      heff_take_n(v_e_248, 1ULL, 1);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      V v_t_24146 = (g_heff_2eutil_2erune_2equoted(v_ch_24145));
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str80), heff_strAppend(v_t_24146, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str81)));
    }
    case TAG_SLitFixed: {
      V v_n_24148 = heff_field(v_e_248, 1);
      heff_take_n(v_e_248, 2ULL, 2);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      return heff_intShow(v_n_24148);
    }
    case TAG_SLitFloat32: {
      V v_x_24149 = heff_tget_v(v_e_248, 0);
      heff_take_na(v_e_248, 0ULL, 1);
      heff_drop(v_c_241);
      heff_drop(v_p_242);
      heff_drop(v_xs_243);
      heff_drop(v_x5_244);
      heff_drop_rec(v_c_245, 2);
      heff_drop(v_p_246);
      heff_drop(v_xs_247);
      return heff_floatShow(v_x_24149);
    }
    default: return heff_nomatch(v_e_248);
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam0(V self, V *args) {
  V v_acc_2426 = args[0];
  V v_f_2427 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_ds_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(v_c_241, v_ds_2421, v_acc_2426, v_f_2427));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam2(V self, V *args) {
  V v_t2_2440 = args[0];
  V v_c_241 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_c_241, MK_INT(2LL), v_xs_243, v_t2_2440));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam1(V self, V *args) {
  V v_v_2437 = args[0];
  V v_c_241 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2437)) {
  case TAG_MkPair: {
    V v_t_2438 = heff_field(v_v_2437, 0);
    V v_ts_2439 = heff_field(v_v_2437, 1);
    heff_take_n(v_v_2437, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str12); V a_1 = v_t_2438; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam2, 1, 2, (V[]){v_c_241, v_xs_243}); V b_3 = heff_arrayToList(v_ts_2439); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  }
  default: return heff_nomatch(v_v_2437);
  }
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam3(V self, V *args) {
  V v_f_2473 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_xs_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_f_2473)) {
  case TAG_MkPair: {
    V v_l_2474 = heff_field(v_f_2473, 0);
    V v_e_2475 = heff_field(v_f_2473, 1);
    heff_take_n(v_f_2473, 3ULL, 2);
    V v_t_2476 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_245, MK_INT(0LL), v_xs_247, v_e_2475));
    return heff_strAppend(v_l_2474, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_str43), v_t_2476));
  }
  default: return heff_nomatch(v_f_2473);
  }
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam4(V self, V *args) {
  V v_a_2491 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_xs_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_245, MK_INT(0LL), v_xs_247, v_a_2491));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam5(V self, V *args) {
  V v_a_2498 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_xs_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_245, MK_INT(2LL), v_xs_247, v_a_2498));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle_lam6(V self, V *args) {
  V v_alt_24107 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_xs_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24108 = heff_intAdd(heff_take_field(v_c_245, 1), MK_INT(2LL));
  V v_t_24109 = ({ V rv_1 = v_t_24108; V rr_ = heff_rec_reuse_nf(v_c_245, 1ULL, 2, shape_im__indent, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  return ({ V a_0 = v_t_24109; V a_1 = v_xs_247; V a_2 = v_alt_24107; V r_ = (g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(a_0, a_1, a_2)); heff_drop(v_alt_24107); r_; });
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_str3, 0, "");
Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(V v_c_240, V v_p_241, V v_xs_242, V v_x5_243) {
top: ;
  return (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_24cycle(NTAG(TAG_Enter_24heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301), v_c_240, v_p_241, v_xs_242, v_x5_243, ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_str0), ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_str1), ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_str2), ((V)&g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_str3)));
}
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(V v_t_240, V v_body_241, V v_ns_242, V v_params_243) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_SU: {
    V v_u_244 = heff_field(v_t_240, 0);
    V v_t_245 = (g_heff_2esyntax_2esurfaceprint_2estripIs(v_body_241));
    V v_t_246;
    switch (heff_tag_of(v_u_244)) {
    case TAG_SmallU: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    case TAG_LargeU: {
      v_t_246 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_u_244);
    }
    V v_f_247 = (g_heff_2esyntax_2esurfaceprint_2eformerAt(v_params_243, v_ns_242, v_t_245, v_t_246));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_247}});
  }
  case TAG_SDecode: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIs: {
      V v_b_2426 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_2426;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_body_241)}});
    }
  }
  case TAG_SFunction: {
    V v_dom_2445 = heff_field(v_t_240, 1);
    V v_t3_2446 = heff_field(v_t_240, 2);
    V v_t4_2447 = heff_field(v_t_240, 3);
    switch (heff_tag_of(v_t3_2446)) {
    case TAG_MkAbs: {
      V v_cod_2450 = heff_field(v_t3_2446, 1);
      switch (heff_tag_of(v_t4_2447)) {
      case TAG_Expl: {
        switch (heff_tag_of(v_body_241)) {
        case TAG_SLocal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SGlobal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SCode: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SApp: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLam: {
          V v_it2_2457 = heff_field(v_body_241, 1);
          V v_ru_24body_241_24SLam = heff_take_reuse_n(v_body_241, 2ULL, 2);
          switch (heff_tag_of(v_it2_2457)) {
          case TAG_MkAbs: {
            V v_x_2458 = heff_field(v_it2_2457, 0);
            V v_b_2459 = heff_field(v_it2_2457, 1);
            V v_ru_24it2_2457_24MkAbs = heff_take_reuse_n(v_it2_2457, 3ULL, 2);
            V v_t_2460 = (g_heff_2esyntax_2esurfaceprint_2eformerParam(heff_dup(v_ns_242), heff_dup(v_x_2458), v_dom_2445));
            V v_t_2461 = heff_tag_at_n(v_ru_24body_241_24SLam, TAG_Cons, 2, (V[]){v_t_2460, NTAG(TAG_Nil)});
            V v_t_2462 = (g_prelude_2e_2b_2b(v_params_243, v_t_2461));
            V t_0 = v_cod_2450;
            V t_1 = v_b_2459;
            V t_2 = heff_tag_at_n(v_ru_24it2_2457_24MkAbs, TAG_Cons, 2, (V[]){v_x_2458, v_ns_242});
            V t_3 = v_t_2462;
            v_t_240 = t_0;
            v_body_241 = t_1;
            v_ns_242 = t_2;
            v_params_243 = t_3;
            goto top;
          }
          case TAG_AbsConst: {
            heff_take_n(v_it2_2457, 0ULL, 1);
            heff_drop(v_ns_242);
            heff_drop(v_params_243);
            heff_drop_cell(v_ru_24body_241_24SLam, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it2_2457)}});
          }
        }
        case TAG_SCons: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SProj: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_STag: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SMatch: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SSpecialize: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SIs: {
          V v_b_2474 = heff_field(v_body_241, 0);
          heff_take_n(v_body_241, 1ULL, 1);
          V t_0 = v_t_240;
          V t_1 = v_b_2474;
          V t_2 = v_ns_242;
          V t_3 = v_params_243;
          v_t_240 = t_0;
          v_body_241 = t_1;
          v_ns_242 = t_2;
          v_params_243 = t_3;
          goto top;
        }
        case TAG_SOpaque: {
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SAbandon: {
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SRec: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SFix: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SImplicit: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SPrim: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SMetaApp: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitInt: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFloat: {
          heff_take_na(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitString: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitBytes: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitRune: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFixed: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFloat32: {
          heff_take_na(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_body_241)}});
        }
      }
      case TAG_Impl: {
        switch (heff_tag_of(v_body_241)) {
        case TAG_SLocal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SGlobal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SCode: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SApp: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLam: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SCons: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SProj: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_STag: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SMatch: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SSpecialize: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SIs: {
          V v_b_24109 = heff_field(v_body_241, 0);
          heff_take_n(v_body_241, 1ULL, 1);
          V t_0 = v_t_240;
          V t_1 = v_b_24109;
          V t_2 = v_ns_242;
          V t_3 = v_params_243;
          v_t_240 = t_0;
          v_body_241 = t_1;
          v_ns_242 = t_2;
          v_params_243 = t_3;
          goto top;
        }
        case TAG_SOpaque: {
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SAbandon: {
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SRec: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SFix: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SImplicit: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SPrim: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SMetaApp: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitInt: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFloat: {
          heff_take_na(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitString: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitBytes: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitRune: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFixed: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFloat32: {
          heff_take_na(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_body_241)}});
        }
      }
      case TAG_Inst: {
        switch (heff_tag_of(v_body_241)) {
        case TAG_SLocal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SGlobal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SCode: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SApp: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLam: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SCons: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SProj: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_STag: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SMatch: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SSpecialize: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SIs: {
          V v_b_24144 = heff_field(v_body_241, 0);
          heff_take_n(v_body_241, 1ULL, 1);
          V t_0 = v_t_240;
          V t_1 = v_b_24144;
          V t_2 = v_ns_242;
          V t_3 = v_params_243;
          v_t_240 = t_0;
          v_body_241 = t_1;
          v_ns_242 = t_2;
          v_params_243 = t_3;
          goto top;
        }
        case TAG_SOpaque: {
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SAbandon: {
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SRec: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SFix: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SImplicit: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SPrim: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SMetaApp: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitInt: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFloat: {
          heff_take_na(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitString: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitBytes: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitRune: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFixed: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFloat32: {
          heff_take_na(v_body_241, 0ULL, 1);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_body_241)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_t4_2447)}});
      }
    }
    case TAG_AbsConst: {
      switch (heff_tag_of(v_body_241)) {
      case TAG_SLocal: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SGlobal: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SCode: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SApp: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLam: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SCons: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SProj: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_STag: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SMatch: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SSpecialize: {
        heff_take_n(v_body_241, 0ULL, 3);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SIs: {
        V v_b_24180 = heff_field(v_body_241, 0);
        heff_take_n(v_body_241, 1ULL, 1);
        V t_0 = v_t_240;
        V t_1 = v_b_24180;
        V t_2 = v_ns_242;
        V t_3 = v_params_243;
        v_t_240 = t_0;
        v_body_241 = t_1;
        v_ns_242 = t_2;
        v_params_243 = t_3;
        goto top;
      }
      case TAG_SOpaque: {
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SAbandon: {
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SRec: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SFix: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SImplicit: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SPrim: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SMetaApp: {
        heff_take_n(v_body_241, 0ULL, 3);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitInt: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFloat: {
        heff_take_na(v_body_241, 0ULL, 1);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitString: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitBytes: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitRune: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFixed: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_body_241, 0ULL, 1);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_body_241)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t3_2446)}});
    }
  }
  case TAG_SRecord: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIs: {
      V v_b_24218 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24218;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_body_241)}});
    }
  }
  case TAG_SSum: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIs: {
      V v_b_24254 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24254;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_body_241)}});
    }
  }
  case TAG_SIsTy: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIs: {
      V v_b_24290 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24290;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_body_241)}});
    }
  }
  case TAG_SPrimInt: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIs: {
      V v_b_24325 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24325;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_body_241)}});
    }
  }
  case TAG_SPrimFloat: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIs: {
      V v_b_24360 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24360;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_body_241)}});
    }
  }
  case TAG_SPrimString: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIs: {
      V v_b_24395 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24395;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_body_241)}});
    }
  }
  case TAG_SPrimRune: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIs: {
      V v_b_24430 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24430;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_body_241)}});
    }
  }
  case TAG_SPrimArray: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIs: {
      V v_b_24466 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24466;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_body_241)}});
    }
  }
  case TAG_SFixed: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIs: {
      V v_b_24502 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24502;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitBytes: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_body_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_t_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eisData_str0, 1, "_");
Clo g_heff_2esyntax_2esurfaceprint_2eisData_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eisData_entry, 2, 0};

V g_heff_2esyntax_2esurfaceprint_2eisData(V v_t_240, V v_body_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2eisData_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_243 = (g_heff_2esyntax_2esurfaceprint_2etypeFormer_24cpr(v_t_240, v_body_241, v_t_242, NTAG(TAG_Nil)));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_tf_247 = v_field_245;
      V v_t_248 = heff_take_field(v_tf_247, 2);
      switch (heff_tag_of(v_t_248)) {
      case TAG_SU: {
        heff_take_n(v_t_248, 0ULL, 1);
        heff_drop_rec(v_tf_247, 4);
        return NTAG(TAG_False);
      }
      case TAG_SDecode: {
        heff_take_n(v_t_248, 0ULL, 1);
        heff_drop_rec(v_tf_247, 4);
        return NTAG(TAG_False);
      }
      case TAG_SFunction: {
        heff_take_n(v_t_248, 0ULL, 5);
        heff_drop_rec(v_tf_247, 4);
        return NTAG(TAG_False);
      }
      case TAG_SRecord: {
        heff_take_n(v_t_248, 0ULL, 3);
        heff_drop_rec(v_tf_247, 4);
        return NTAG(TAG_False);
      }
      case TAG_SSum: {
        heff_take_n(v_t_248, 0ULL, 1);
        V v_t_2420 = heff_get_n(v_tf_247, 3, 4);
        V v_ret_24bool = heff_bool(!(heff_dup(v_t_2420) == NTAG(TAG_True)));
        heff_drop(v_t_2420);
        return v_ret_24bool;
      }
      case TAG_SIsTy: {
        heff_take_n(v_t_248, 0ULL, 1);
        heff_drop_rec(v_tf_247, 4);
        return NTAG(TAG_False);
      }
      case TAG_SPrimInt: {
        heff_drop_rec(v_tf_247, 4);
        return NTAG(TAG_False);
      }
      case TAG_SPrimFloat: {
        heff_drop_rec(v_tf_247, 4);
        return NTAG(TAG_False);
      }
      case TAG_SPrimString: {
        heff_drop_rec(v_tf_247, 4);
        return NTAG(TAG_False);
      }
      case TAG_SPrimRune: {
        heff_drop_rec(v_tf_247, 4);
        return NTAG(TAG_False);
      }
      case TAG_SPrimArray: {
        heff_take_n(v_t_248, 0ULL, 1);
        heff_drop_rec(v_tf_247, 4);
        return NTAG(TAG_False);
      }
      case TAG_SFixed: {
        heff_take_n(v_t_248, 0ULL, 1);
        heff_drop_rec(v_tf_247, 4);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_248);
      }
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2esurfaceprint_2eisData_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurfaceprint_2eisData(a0, a[1]); heff_drop(a0); return r;
}