// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TPi 30745
#define TAG_TSig 38418
#define TAG_TSum 38796
#define LBL_decl 9574769
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_head 9693863
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_unit 10090059
#define LBL_vars 10107635
V g_heff_2esyntax_2epresyntax_2ealtOf(V, V);
V g_heff_2esyntax_2epresyntax_2ealtOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_clo;
V g_heff_2esyntax_2epresyntax_2eannLamOf(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eannLamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eannLamOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eappOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eappOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2earmOn(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2earmOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmOn_clo;
V g_heff_2esyntax_2epresyntax_2earmT(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2earmT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmT_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryIn(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_clo;
HeffT1 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebytesBinary_24s164675078x1710946710_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
HeffT2 g_heff_2esyntax_2epresyntax_2edoBlock_24s1455639597x676970604_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2epiBinderOf(V, V);
V g_heff_2esyntax_2epresyntax_2epiBinderOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_clo;
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(V);
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_clo;
V g_heff_2esyntax_2epresyntax_2ereversedBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2ereversedBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ereversedBytes_clo;
V g_heff_2esyntax_2epresyntax_2erunArgs(V, V);
V g_heff_2esyntax_2epresyntax_2erunArgs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2erunArgs_clo;
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eupdateSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo;
V g_heff_2esyntax_2epresyntax_2ewholeBinary(V, V);
V g_heff_2esyntax_2epresyntax_2ewholeBinary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewholeBinary_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ewordOf(V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_24tok1(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_24tok1_clo;
V g_list_2eany_24s1075282620x806006020(V);
V g_list_2eany_24s1075282620x806006020_entry(V self, V *a);
extern Clo g_list_2eany_24s1075282620x806006020_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1230969749x2018313496(V);
V g_list_2emap_24s1230969749x2018313496_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1258450377x973220636(V);
V g_list_2emap_24s1258450377x973220636_entry(V self, V *a);
extern Clo g_list_2emap_24s1258450377x973220636_clo;
V g_list_2emap_24s137457135x961689574(V);
V g_list_2emap_24s137457135x961689574_entry(V self, V *a);
extern Clo g_list_2emap_24s137457135x961689574_clo;
V g_list_2emap_24s1844509821x2028168277(V);
V g_list_2emap_24s1844509821x2028168277_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_clo;
V g_list_2emap_24s2016093283x1174801437(V, V);
V g_list_2emap_24s2016093283x1174801437_entry(V self, V *a);
extern Clo g_list_2emap_24s2016093283x1174801437_clo;
V g_list_2emap_24s2039279853x710813703(V, V);
V g_list_2emap_24s2039279853x710813703_entry(V self, V *a);
extern Clo g_list_2emap_24s2039279853x710813703_clo;
V g_list_2emap_24s205414595x1692305030(V);
V g_list_2emap_24s205414595x1692305030_entry(V self, V *a);
extern Clo g_list_2emap_24s205414595x1692305030_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
V g_list_2emap_24s961097229x1129443801(V);
V g_list_2emap_24s961097229x1129443801_entry(V self, V *a);
extern Clo g_list_2emap_24s961097229x1129443801_clo;
V g_list_2emap_24s97919758x216970748(V, V);
V g_list_2emap_24s97919758x216970748_entry(V self, V *a);
extern Clo g_list_2emap_24s97919758x216970748_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
Clo g_heff_2esyntax_2epresyntax_2ereversedBytes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ereversedBytes_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ereversedBytes(V v_s_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return v_acc_242;
  } else {
    V v_t_243 = heff_strSlice_lent(v_s_240, heff_box_word(v_i_241), heff_box_word((v_i_241 + ((int64_t)1ULL))), 6);
    V t_0 = v_s_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_strAppend(v_t_243, v_acc_242);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2esyntax_2epresyntax_2ereversedBytes_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2ereversedBytes(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eleaving_str0, 16, "prelude.inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eleaving_str1, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eleaving_str2, 4, "Unit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eleaving_str3, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2eleaving_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eleaving_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2eleaving(V v_cx_240, V v_sp_241, V v_n_242, V v_call_243) {
top: ;
  if (heff_intLe_c_lent(v_n_242, MK_INT(0LL), 2)) {
    heff_drop_rec(v_cx_240, 6);
    heff_drop(v_sp_241);
    heff_drop(v_n_242);
    return v_call_243;
  } else {
    V v_e_244 = (g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_240), heff_dup(v_sp_241), heff_intSub(v_n_242, MK_INT(1LL)), v_call_243));
    V v_sp_247;
    switch (heff_tag_of(v_e_244)) {
    case TAG_At: {
      V v_s_246 = heff_dup(heff_field(v_e_244, 1));
      v_sp_247 = v_s_246;
      break;
    }
    default: heff_nomatch(v_e_244);
    }
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eleaving_str0)}), heff_dup(v_sp_247)});
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eleaving_str1)}), v_sp_247});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    V v_t_2411 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_248, v_t_2410));
    V v_t_2414;
    switch (heff_tag_of(v_e_244)) {
    case TAG_At: {
      V v_s_2413 = heff_dup(heff_field(v_e_244, 1));
      v_t_2414 = v_s_2413;
      break;
    }
    default: heff_nomatch(v_e_244);
    }
    V v_e_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_e_244, v_t_2411}), v_t_2414});
    V v_t_2416 = heff_get_n(heff_get_n(v_cx_240, 0, 6), 1, 3);
    V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2416}), heff_dup(v_sp_241)});
    V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eleaving_str2)}), heff_dup(v_sp_241)});
    V v_t_2419 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamAnn, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eleaving_str3), heff_dup(v_sp_241), v_t_2418}), v_e_2415});
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_241}), NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2417, v_t_2420));
  }
}
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eleaving(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2epresyntax_2eisControl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eisControl_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eisControl(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EString: {
      return NTAG(TAG_False);
    }
    case TAG_EBinary: {
      return NTAG(TAG_False);
    }
    case TAG_ERune: {
      return NTAG(TAG_False);
    }
    case TAG_EWord: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_EProject: {
      return NTAG(TAG_False);
    }
    case TAG_ENamed: {
      return NTAG(TAG_False);
    }
    case TAG_EPi: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EAnn: {
      return NTAG(TAG_False);
    }
    case TAG_ESpec: {
      return NTAG(TAG_False);
    }
    case TAG_ESig: {
      return NTAG(TAG_False);
    }
    case TAG_ESum: {
      return NTAG(TAG_False);
    }
    case TAG_EStruct: {
      return NTAG(TAG_False);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      V v_alts_2433 = heff_field(v_x11_241, 1);
      HEFF_LAST return g_list_2eany_24s1075282620x806006020(v_alts_2433);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_False);
    }
    case TAG_EDo: {
      return NTAG(TAG_False);
    }
    case TAG_ELocal: {
      return NTAG(TAG_False);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_False);
    }
    case TAG_EAssign: {
      return NTAG(TAG_True);
    }
    case TAG_EWhile: {
      return NTAG(TAG_True);
    }
    case TAG_EFor: {
      return NTAG(TAG_True);
    }
    case TAG_EIfThen: {
      return NTAG(TAG_True);
    }
    case TAG_EBreak: {
      return NTAG(TAG_True);
    }
    case TAG_EContinue: {
      return NTAG(TAG_True);
    }
    case TAG_EReturn: {
      return NTAG(TAG_True);
    }
    case TAG_ENest: {
      return NTAG(TAG_False);
    }
    case TAG_ELazy: {
      return NTAG(TAG_False);
    }
    case TAG_ETuple: {
      return NTAG(TAG_False);
    }
    case TAG_ETry: {
      return NTAG(TAG_True);
    }
    case TAG_EWith: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2eisControl(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2epresyntax_2earmOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2earmOn_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2earmOn(V v_t_240, V v_cx_241, V v_rest_242, V v_end_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_p_245 = heff_field(v_x5_244, 0);
    V v_ss_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24MkPair = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_x1_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_246)));
    V v_t_2424;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nil: {
      v_t_2424 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 2);
      switch (heff_tag_of(v_x_248)) {
      case TAG_At: {
        V v_it11_2410 = heff_field(v_x_248, 0);
        heff_take_n(v_x_248, 1ULL, 2);
        switch (heff_tag_of(v_it11_2410)) {
        case TAG_StmtBind: {
          heff_take_n(v_it11_2410, 0ULL, 3);
          v_t_2424 = NTAG(TAG_True);
          break;
        }
        case TAG_StmtLet: {
          heff_take_n(v_it11_2410, 0ULL, 2);
          v_t_2424 = NTAG(TAG_True);
          break;
        }
        case TAG_StmtExpr: {
          V v_e_2417 = heff_field(v_it11_2410, 0);
          heff_take_n(v_it11_2410, 1ULL, 1);
          v_t_2424 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_e_2417));
          break;
        }
        case TAG_StmtLetMut: {
          heff_take_n(v_it11_2410, 0ULL, 3);
          v_t_2424 = NTAG(TAG_True);
          break;
        }
        case TAG_StmtLetElse: {
          heff_take_n(v_it11_2410, 0ULL, 3);
          v_t_2424 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_it11_2410);
        }
        break;
      }
      default: heff_nomatch(v_x_248);
      }
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
      heff_drop(v_t_2424);
      V v_t_2425 = (g_prelude_2e_2b_2b(v_ss_246, v_rest_242));
      return (g_heff_2esyntax_2epresyntax_2earmT(v_t_240, v_cx_241, v_end_243, heff_tag_at_n(v_ru_24x5_244_24MkPair, TAG_MkPair, 2, (V[]){v_p_245, v_t_2425})));
    } else {
      heff_drop(v_rest_242);
      heff_drop(v_t_2424);
      return (g_heff_2esyntax_2epresyntax_2earmT(v_t_240, v_cx_241, v_end_243, heff_tag_at_n(v_ru_24x5_244_24MkPair, TAG_MkPair, 2, (V[]){v_p_245, v_ss_246})));
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2esyntax_2epresyntax_2earmOn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2earmOn(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epiBinderOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epiBinderOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xsp_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24PiNamed = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_x1_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_244}));
    V v_t_2415;
    switch (heff_tag_of(v_x1_245)) {
    case TAG_IsInferable: {
      V v_i_246 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24IsInferable = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      V v_t_249;
      switch (heff_tag_of(v_i_246)) {
      case TAG_At: {
        V v_s_248 = heff_dup(heff_field(v_i_246, 1));
        v_t_249 = v_s_248;
        break;
      }
      default: heff_nomatch(v_i_246);
      }
      v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_245_24IsInferable, TAG_TInf, 1, (V[]){v_i_246}), v_t_249});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2410 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24IsCheckable = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      V v_t_2413;
      switch (heff_tag_of(v_c_2410)) {
      case TAG_At: {
        V v_s_2412 = heff_dup(heff_field(v_c_2410, 1));
        v_t_2413 = v_s_2412;
        break;
      }
      default: heff_nomatch(v_c_2410);
      }
      v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_245_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2410}), v_t_2413});
      break;
    }
    case TAG_IsType: {
      V v_t_2414 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      v_t_2415 = v_t_2414;
      break;
    }
    default: heff_nomatch(v_x1_245);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_242, v_xsp_243, v_t_2415});
  }
  case TAG_PiImplicit: {
    V v_x_2416 = heff_field(v_x2_241, 0);
    V v_xsp_2417 = heff_field(v_x2_241, 1);
    V v_bsp_2418 = heff_field(v_x2_241, 2);
    V v_t_2419 = heff_field(v_x2_241, 3);
    V v_d_2420 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24PiImplicit = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_x1_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2419}));
    V v_t_2431;
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_IsInferable: {
      V v_i_2422 = heff_field(v_x1_2421, 0);
      V v_ru_24x1_2421_24IsInferable = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
      V v_t_2425;
      switch (heff_tag_of(v_i_2422)) {
      case TAG_At: {
        V v_s_2424 = heff_dup(heff_field(v_i_2422, 1));
        v_t_2425 = v_s_2424;
        break;
      }
      default: heff_nomatch(v_i_2422);
      }
      v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2421_24IsInferable, TAG_TInf, 1, (V[]){v_i_2422}), v_t_2425});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2426 = heff_field(v_x1_2421, 0);
      V v_ru_24x1_2421_24IsCheckable = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
      V v_t_2429;
      switch (heff_tag_of(v_c_2426)) {
      case TAG_At: {
        V v_s_2428 = heff_dup(heff_field(v_c_2426, 1));
        v_t_2429 = v_s_2428;
        break;
      }
      default: heff_nomatch(v_c_2426);
      }
      v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2421_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2426}), v_t_2429});
      break;
    }
    case TAG_IsType: {
      V v_t_2430 = heff_field(v_x1_2421, 0);
      heff_take_n(v_x1_2421, 1ULL, 1);
      v_t_2431 = v_t_2430;
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
    V v_t_2444;
    switch (heff_tag_of(v_d_2420)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 2);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2432 = heff_field(v_d_2420, 0);
      V v_ru_24d_2420_24Just = heff_take_reuse_n(v_d_2420, 1ULL, 1);
      V v_x1_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x_2432}));
      V v_t_2443;
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_IsInferable: {
        V v_i_2434 = heff_field(v_x1_2433, 0);
        V v_ru_24x1_2433_24IsInferable = heff_take_reuse_n(v_x1_2433, 1ULL, 1);
        V v_t_2437;
        switch (heff_tag_of(v_i_2434)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_i_2434, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_i_2434);
        }
        v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2433_24IsInferable, TAG_CInf, 1, (V[]){v_i_2434}), v_t_2437});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2438 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        v_t_2443 = v_c_2438;
        break;
      }
      case TAG_IsType: {
        V v_t_2439 = heff_field(v_x1_2433, 0);
        V v_ru_24x1_2433_24IsType = heff_take_reuse_n(v_x1_2433, 1ULL, 1);
        V v_t_2442;
        switch (heff_tag_of(v_t_2439)) {
        case TAG_At: {
          V v_s_2441 = heff_dup(heff_field(v_t_2439, 1));
          v_t_2442 = v_s_2441;
          break;
        }
        default: heff_nomatch(v_t_2439);
        }
        v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2433_24IsType, TAG_CType, 1, (V[]){v_t_2439}), v_t_2442});
        break;
      }
      default: heff_nomatch(v_x1_2433);
      }
      v_t_2444 = heff_tag_at_n(v_ru_24d_2420_24Just, TAG_Just, 1, (V[]){v_t_2443});
      break;
    }
    default: heff_nomatch(v_d_2420);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_2416, v_xsp_2417, v_bsp_2418, v_t_2431, v_t_2444});
  }
  case TAG_PiInstance: {
    V v_x_2445 = heff_field(v_x2_241, 0);
    V v_xsp_2446 = heff_field(v_x2_241, 1);
    V v_bsp_2447 = heff_field(v_x2_241, 2);
    V v_t_2448 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24PiInstance = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_x1_2449 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2448}));
    V v_t_2459;
    switch (heff_tag_of(v_x1_2449)) {
    case TAG_IsInferable: {
      V v_i_2450 = heff_field(v_x1_2449, 0);
      V v_ru_24x1_2449_24IsInferable = heff_take_reuse_n(v_x1_2449, 1ULL, 1);
      V v_t_2453;
      switch (heff_tag_of(v_i_2450)) {
      case TAG_At: {
        V v_s_2452 = heff_dup(heff_field(v_i_2450, 1));
        v_t_2453 = v_s_2452;
        break;
      }
      default: heff_nomatch(v_i_2450);
      }
      v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2449_24IsInferable, TAG_TInf, 1, (V[]){v_i_2450}), v_t_2453});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2454 = heff_field(v_x1_2449, 0);
      V v_ru_24x1_2449_24IsCheckable = heff_take_reuse_n(v_x1_2449, 1ULL, 1);
      V v_t_2457;
      switch (heff_tag_of(v_c_2454)) {
      case TAG_At: {
        V v_s_2456 = heff_dup(heff_field(v_c_2454, 1));
        v_t_2457 = v_s_2456;
        break;
      }
      default: heff_nomatch(v_c_2454);
      }
      v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2449_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2454}), v_t_2457});
      break;
    }
    case TAG_IsType: {
      V v_t_2458 = heff_field(v_x1_2449, 0);
      heff_take_n(v_x1_2449, 1ULL, 1);
      v_t_2459 = v_t_2458;
      break;
    }
    default: heff_nomatch(v_x1_2449);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2445, v_xsp_2446, v_bsp_2447, v_t_2459});
  }
  case TAG_PiAnon: {
    V v_t_2460 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24PiAnon = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x1_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2460}));
    V v_t_2471;
    switch (heff_tag_of(v_x1_2461)) {
    case TAG_IsInferable: {
      V v_i_2462 = heff_field(v_x1_2461, 0);
      V v_ru_24x1_2461_24IsInferable = heff_take_reuse_n(v_x1_2461, 1ULL, 1);
      V v_t_2465;
      switch (heff_tag_of(v_i_2462)) {
      case TAG_At: {
        V v_s_2464 = heff_dup(heff_field(v_i_2462, 1));
        v_t_2465 = v_s_2464;
        break;
      }
      default: heff_nomatch(v_i_2462);
      }
      v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2461_24IsInferable, TAG_TInf, 1, (V[]){v_i_2462}), v_t_2465});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2466 = heff_field(v_x1_2461, 0);
      V v_ru_24x1_2461_24IsCheckable = heff_take_reuse_n(v_x1_2461, 1ULL, 1);
      V v_t_2469;
      switch (heff_tag_of(v_c_2466)) {
      case TAG_At: {
        V v_s_2468 = heff_dup(heff_field(v_c_2466, 1));
        v_t_2469 = v_s_2468;
        break;
      }
      default: heff_nomatch(v_c_2466);
      }
      v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2461_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2466}), v_t_2469});
      break;
    }
    case TAG_IsType: {
      V v_t_2470 = heff_field(v_x1_2461, 0);
      heff_take_n(v_x1_2461, 1ULL, 1);
      v_t_2471 = v_t_2470;
      break;
    }
    default: heff_nomatch(v_x1_2461);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2471});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2epiBinderOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epiBinderOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclareField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_xsp_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_d_247 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24DeclareField = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_x1_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_246}));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_c_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_c_2413);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
        break;
      }
      case TAG_IsType: {
        V v_t_2417 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2418 = v_t_2417;
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      V v_t_2431;
      switch (heff_tag_of(v_d_247)) {
      case TAG_Nothing: {
        heff_drop_rec(v_r_240, 2);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2419 = heff_field(v_d_247, 0);
        V v_ru_24d_247_24Just = heff_take_reuse_n(v_d_247, 1ULL, 1);
        V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x_2419}));
        V v_t_2430;
        switch (heff_tag_of(v_x1_2420)) {
        case TAG_IsInferable: {
          V v_i_2421 = heff_field(v_x1_2420, 0);
          V v_ru_24x1_2420_24IsInferable = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
          V v_t_2424;
          switch (heff_tag_of(v_i_2421)) {
          case TAG_At: {
            V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
            v_t_2424 = v_s_2423;
            break;
          }
          default: heff_nomatch(v_i_2421);
          }
          v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsInferable, TAG_CInf, 1, (V[]){v_i_2421}), v_t_2424});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2425 = heff_field(v_x1_2420, 0);
          heff_take_n(v_x1_2420, 1ULL, 1);
          v_t_2430 = v_c_2425;
          break;
        }
        case TAG_IsType: {
          V v_t_2426 = heff_field(v_x1_2420, 0);
          V v_ru_24x1_2420_24IsType = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
          V v_t_2429;
          switch (heff_tag_of(v_t_2426)) {
          case TAG_At: {
            V v_s_2428 = heff_dup(heff_field(v_t_2426, 1));
            v_t_2429 = v_s_2428;
            break;
          }
          default: heff_nomatch(v_t_2426);
          }
          v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsType, TAG_CType, 1, (V[]){v_t_2426}), v_t_2429});
          break;
        }
        default: heff_nomatch(v_x1_2420);
        }
        v_t_2431 = heff_tag_at_n(v_ru_24d_247_24Just, TAG_Just, 1, (V[]){v_t_2430});
        break;
      }
      default: heff_nomatch(v_d_247);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_244, v_xsp_245, v_t_2418, v_t_2431}), v_sp_243});
    }
    case TAG_BadFieldDecl: {
      V v_e_2432 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24BadFieldDecl = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2432}));
      V v_t_2443;
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_IsInferable: {
        V v_i_2434 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        V v_t_2437;
        switch (heff_tag_of(v_i_2434)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_i_2434, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_i_2434);
        }
        v_t_2443 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2434}), v_t_2437});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2438 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        V v_t_2441;
        switch (heff_tag_of(v_c_2438)) {
        case TAG_At: {
          V v_s_2440 = heff_dup(heff_field(v_c_2438, 1));
          v_t_2441 = v_s_2440;
          break;
        }
        default: heff_nomatch(v_c_2438);
        }
        v_t_2443 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2438}), v_t_2441});
        break;
      }
      case TAG_IsType: {
        V v_t_2442 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2443 = v_t_2442;
        break;
      }
      default: heff_nomatch(v_x1_2433);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2443}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldDeclOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2ewholeBinary_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewholeBinary_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ewholeBinary(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Just, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_At: {
      V v_seg_244 = heff_field(v_x11_242, 0);
      HeffT2 v_t_246 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_244));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_s_249 = v_field_248;
          V t_0 = v_rest_243;
          V t_1 = heff_strAppend(v_acc_241, v_s_249);
          v_x1_240 = t_0;
          v_acc_241 = t_1;
          goto top;
        } else {
          heff_drop(v_acc_241);
          heff_drop(v_field_248);
          return NTAG(TAG_Nothing);
        }
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ewholeBinary_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2ewholeBinary(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str0, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str1, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str2, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str4, 67, " := e` sets a `let mut` variable: it is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str5, 45, "a `while` loop is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str6, 43, "a `for` loop is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str7, 78, "an `if` without `else` is a statement of a `do` block: a value's has an `else`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str8, 78, "`break` is a statement of a loop's body: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str9, 81, "`continue` is a statement of a loop's body: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str10, 103, "`return e` ends a `do` block as one of its statements (or an arm of its `if` or `case`), not as a value");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str11, 67, "`(<- c)`, the value of an action, is in a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str12, 72, "a `try` is a statement of a `do` block (or an arm of its `if` or `case`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str13, 73, "a `with` is a statement of a `do` block (or an arm of its `if` or `case`)");
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EVar = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_244}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EVar, TAG_IsInferable, 1, (V[]){v_t_245});
    }
    case TAG_EImplicitVar: {
      V v_x_246 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EImplicitVar = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EImplicitVar, TAG_IsInferable, 1, (V[]){v_t_247});
    }
    case TAG_ETag: {
      V v_t_248 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ETag = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_249 = heff_tag_n(TAG_CTag, 3, (V[]){v_t_248, heff_dup(v_sp_243), NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x21_242_24ETag, TAG_IsCheckable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_249, v_sp_243})});
    }
    case TAG_EInt: {
      V v_i_2410 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EInt = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2411 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_i_2410}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EInt, TAG_IsInferable, 1, (V[]){v_t_2411});
    }
    case TAG_EFloat: {
      double v_x_2412 = heff_tflat_f64(v_x21_242, 0);
      V v_ru_24x21_242_24EFloat = heff_take_reuse_na(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_nf(TAG_IFloat, 1, 1u, (V[]){heff_word_f64(v_x_2412)}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EFloat, TAG_IsInferable, 1, (V[]){v_t_2413});
    }
    case TAG_EString: {
      V v_x_2414 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EString = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2415 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IString, 1, (V[]){v_x_2414}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EString, TAG_IsInferable, 1, (V[]){v_t_2415});
    }
    case TAG_EBinary: {
      V v_segs_2416 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EBinary = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return ({ V a_0 = v_ru_24x21_242_24EBinary; V a_1 = v_r_240; V b_2 = NTAG(TAG_False); V a_3 = v_segs_2416; V a_4 = v_sp_243; V r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
    }
    case TAG_ERune: {
      V v_c_2417 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ERune = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IRune, 1, (V[]){v_c_2417}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24ERune, TAG_IsInferable, 1, (V[]){v_t_2418});
    }
    case TAG_EWord: {
      V v_w_2419 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EWord = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return (g_heff_2esyntax_2epresyntax_2ewordOf_24tok1(v_ru_24x21_242_24EWord, v_w_2419, v_sp_243));
    }
    case TAG_EApp: {
      V v_h_2420 = heff_field(v_x21_242, 0);
      V v_args_2421 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_2422 = (g_heff_2esyntax_2epresyntax_2erunArgs(heff_dup(v_h_2420), v_args_2421));
      return (g_heff_2esyntax_2epresyntax_2eappOf(v_r_240, v_h_2420, v_t_2422, v_sp_243));
    }
    case TAG_EProject: {
      V v_ru_24x21_242_24EProject = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2424 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str0), NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24EProject, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2424, v_sp_243})});
    }
    case TAG_ENamed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 2);
      V v_t_2427 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str1), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2427, v_sp_243})});
    }
    case TAG_EPi: {
      V v_b_2428 = heff_field(v_x21_242, 0);
      V v_cod_2429 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EPi = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2430 = (g_heff_2esyntax_2epresyntax_2epiBinderOf(heff_dup(v_r_240), v_b_2428));
      V v_x1_2431 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_cod_2429}));
      V v_t_2441;
      switch (heff_tag_of(v_x1_2431)) {
      case TAG_IsInferable: {
        V v_i_2432 = heff_field(v_x1_2431, 0);
        heff_take_n(v_x1_2431, 1ULL, 1);
        V v_t_2435;
        switch (heff_tag_of(v_i_2432)) {
        case TAG_At: {
          V v_s_2434 = heff_dup(heff_field(v_i_2432, 1));
          v_t_2435 = v_s_2434;
          break;
        }
        default: heff_nomatch(v_i_2432);
        }
        v_t_2441 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2432}), v_t_2435});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2436 = heff_field(v_x1_2431, 0);
        heff_take_n(v_x1_2431, 1ULL, 1);
        V v_t_2439;
        switch (heff_tag_of(v_c_2436)) {
        case TAG_At: {
          V v_s_2438 = heff_dup(heff_field(v_c_2436, 1));
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_c_2436);
        }
        v_t_2441 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2436}), v_t_2439});
        break;
      }
      case TAG_IsType: {
        V v_t_2440 = heff_field(v_x1_2431, 0);
        heff_take_n(v_x1_2431, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2441 = v_t_2440;
        break;
      }
      default: heff_nomatch(v_x1_2431);
      }
      V v_t_2442 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_TPi, 2, (V[]){v_t_2430, v_t_2441}), v_sp_243});
      return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2442});
    }
    case TAG_ELam: {
      V v_x211_2443 = heff_field(v_x21_242, 0);
      V v_body_2444 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELam = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      switch (heff_tag_of(v_x211_2443)) {
      case TAG_LamName: {
        V v_x_2445 = heff_field(v_x211_2443, 0);
        V v_xsp_2446 = heff_field(v_x211_2443, 1);
        heff_take_n(v_x211_2443, 3ULL, 2);
        V v_x1_2447 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2444}));
        V v_t_2457;
        switch (heff_tag_of(v_x1_2447)) {
        case TAG_IsInferable: {
          V v_i_2448 = heff_field(v_x1_2447, 0);
          heff_take_n(v_x1_2447, 1ULL, 1);
          V v_t_2451;
          switch (heff_tag_of(v_i_2448)) {
          case TAG_At: {
            V v_s_2450 = heff_dup(heff_field(v_i_2448, 1));
            v_t_2451 = v_s_2450;
            break;
          }
          default: heff_nomatch(v_i_2448);
          }
          v_t_2457 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2448}), v_t_2451});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2452 = heff_field(v_x1_2447, 0);
          heff_take_n(v_x1_2447, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2457 = v_c_2452;
          break;
        }
        case TAG_IsType: {
          V v_t_2453 = heff_field(v_x1_2447, 0);
          heff_take_n(v_x1_2447, 1ULL, 1);
          V v_t_2456;
          switch (heff_tag_of(v_t_2453)) {
          case TAG_At: {
            V v_s_2455 = heff_dup(heff_field(v_t_2453, 1));
            v_t_2456 = v_s_2455;
            break;
          }
          default: heff_nomatch(v_t_2453);
          }
          v_t_2457 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2453}), v_t_2456});
          break;
        }
        default: heff_nomatch(v_x1_2447);
        }
        V v_t_2458 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CLam, 3, (V[]){v_x_2445, v_xsp_2446, v_t_2457}), v_sp_243});
        return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2458});
      }
      case TAG_LamImplicit: {
        V v_x_2459 = heff_field(v_x211_2443, 0);
        V v_xsp_2460 = heff_field(v_x211_2443, 1);
        heff_take_n(v_x211_2443, 3ULL, 2);
        V v_x1_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2444}));
        V v_t_2471;
        switch (heff_tag_of(v_x1_2461)) {
        case TAG_IsInferable: {
          V v_i_2462 = heff_field(v_x1_2461, 0);
          heff_take_n(v_x1_2461, 1ULL, 1);
          V v_t_2465;
          switch (heff_tag_of(v_i_2462)) {
          case TAG_At: {
            V v_s_2464 = heff_dup(heff_field(v_i_2462, 1));
            v_t_2465 = v_s_2464;
            break;
          }
          default: heff_nomatch(v_i_2462);
          }
          v_t_2471 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2462}), v_t_2465});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2466 = heff_field(v_x1_2461, 0);
          heff_take_n(v_x1_2461, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2471 = v_c_2466;
          break;
        }
        case TAG_IsType: {
          V v_t_2467 = heff_field(v_x1_2461, 0);
          heff_take_n(v_x1_2461, 1ULL, 1);
          V v_t_2470;
          switch (heff_tag_of(v_t_2467)) {
          case TAG_At: {
            V v_s_2469 = heff_dup(heff_field(v_t_2467, 1));
            v_t_2470 = v_s_2469;
            break;
          }
          default: heff_nomatch(v_t_2467);
          }
          v_t_2471 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2467}), v_t_2470});
          break;
        }
        default: heff_nomatch(v_x1_2461);
        }
        V v_t_2472 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CImplicitLam, 3, (V[]){v_x_2459, v_xsp_2460, v_t_2471}), v_sp_243});
        return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2472});
      }
      case TAG_LamAnn: {
        V v_x_2473 = heff_field(v_x211_2443, 0);
        V v_xsp_2474 = heff_field(v_x211_2443, 1);
        V v_t_2475 = heff_field(v_x211_2443, 2);
        heff_take_n(v_x211_2443, 7ULL, 3);
        heff_drop_cell(v_ru_24x21_242_24ELam, 2);
        V v_x1_2476 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2475}));
        V v_t_2486;
        switch (heff_tag_of(v_x1_2476)) {
        case TAG_IsInferable: {
          V v_i_2477 = heff_field(v_x1_2476, 0);
          heff_take_n(v_x1_2476, 1ULL, 1);
          V v_t_2480;
          switch (heff_tag_of(v_i_2477)) {
          case TAG_At: {
            V v_s_2479 = heff_dup(heff_field(v_i_2477, 1));
            v_t_2480 = v_s_2479;
            break;
          }
          default: heff_nomatch(v_i_2477);
          }
          v_t_2486 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2477}), v_t_2480});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2481 = heff_field(v_x1_2476, 0);
          heff_take_n(v_x1_2476, 1ULL, 1);
          V v_t_2484;
          switch (heff_tag_of(v_c_2481)) {
          case TAG_At: {
            V v_s_2483 = heff_dup(heff_field(v_c_2481, 1));
            v_t_2484 = v_s_2483;
            break;
          }
          default: heff_nomatch(v_c_2481);
          }
          v_t_2486 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2481}), v_t_2484});
          break;
        }
        case TAG_IsType: {
          V v_t_2485 = heff_field(v_x1_2476, 0);
          heff_take_n(v_x1_2476, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2486 = v_t_2485;
          break;
        }
        default: heff_nomatch(v_x1_2476);
        }
        V v_t_2487 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2444}));
        return (g_heff_2esyntax_2epresyntax_2eannLamOf(v_x_2473, v_xsp_2474, v_t_2486, v_t_2487, v_sp_243));
      }
      default: return heff_nomatch(v_x211_2443);
      }
    }
    case TAG_EAnn: {
      V v_a_2488 = heff_field(v_x21_242, 0);
      V v_t_2489 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EAnn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_2490 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_2488}));
      V v_t_24100;
      switch (heff_tag_of(v_x1_2490)) {
      case TAG_IsInferable: {
        V v_i_2491 = heff_field(v_x1_2490, 0);
        heff_take_n(v_x1_2490, 1ULL, 1);
        V v_t_2494;
        switch (heff_tag_of(v_i_2491)) {
        case TAG_At: {
          V v_s_2493 = heff_dup(heff_field(v_i_2491, 1));
          v_t_2494 = v_s_2493;
          break;
        }
        default: heff_nomatch(v_i_2491);
        }
        v_t_24100 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2491}), v_t_2494});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2495 = heff_field(v_x1_2490, 0);
        heff_take_n(v_x1_2490, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24100 = v_c_2495;
        break;
      }
      case TAG_IsType: {
        V v_t_2496 = heff_field(v_x1_2490, 0);
        heff_take_n(v_x1_2490, 1ULL, 1);
        V v_t_2499;
        switch (heff_tag_of(v_t_2496)) {
        case TAG_At: {
          V v_s_2498 = heff_dup(heff_field(v_t_2496, 1));
          v_t_2499 = v_s_2498;
          break;
        }
        default: heff_nomatch(v_t_2496);
        }
        v_t_24100 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2496}), v_t_2499});
        break;
      }
      default: heff_nomatch(v_x1_2490);
      }
      V v_x1_24101 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2489}));
      V v_t_24111;
      switch (heff_tag_of(v_x1_24101)) {
      case TAG_IsInferable: {
        V v_i_24102 = heff_field(v_x1_24101, 0);
        heff_take_n(v_x1_24101, 1ULL, 1);
        V v_t_24105;
        switch (heff_tag_of(v_i_24102)) {
        case TAG_At: {
          V v_s_24104 = heff_dup(heff_field(v_i_24102, 1));
          v_t_24105 = v_s_24104;
          break;
        }
        default: heff_nomatch(v_i_24102);
        }
        v_t_24111 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_24102}), v_t_24105});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24106 = heff_field(v_x1_24101, 0);
        heff_take_n(v_x1_24101, 1ULL, 1);
        V v_t_24109;
        switch (heff_tag_of(v_c_24106)) {
        case TAG_At: {
          V v_s_24108 = heff_dup(heff_field(v_c_24106, 1));
          v_t_24109 = v_s_24108;
          break;
        }
        default: heff_nomatch(v_c_24106);
        }
        v_t_24111 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_24106}), v_t_24109});
        break;
      }
      case TAG_IsType: {
        V v_t_24110 = heff_field(v_x1_24101, 0);
        heff_take_n(v_x1_24101, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EAnn, 2);
        v_t_24111 = v_t_24110;
        break;
      }
      default: heff_nomatch(v_x1_24101);
      }
      V v_t_24112 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_24100, v_t_24111}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24112});
    }
    case TAG_ESpec: {
      V v_a_24113 = heff_field(v_x21_242, 0);
      V v_x_24114 = heff_field(v_x21_242, 1);
      V v_fsp_24115 = heff_field(v_x21_242, 2);
      V v_v_24116 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24ESpec = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_t_24117 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24113}));
      V v_t_24118 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24117));
      V v_x1_24119 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_24116}));
      V v_t_24129;
      switch (heff_tag_of(v_x1_24119)) {
      case TAG_IsInferable: {
        V v_i_24120 = heff_field(v_x1_24119, 0);
        heff_take_n(v_x1_24119, 1ULL, 1);
        V v_t_24123;
        switch (heff_tag_of(v_i_24120)) {
        case TAG_At: {
          V v_s_24122 = heff_dup(heff_field(v_i_24120, 1));
          v_t_24123 = v_s_24122;
          break;
        }
        default: heff_nomatch(v_i_24120);
        }
        v_t_24129 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24120}), v_t_24123});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24124 = heff_field(v_x1_24119, 0);
        heff_take_n(v_x1_24119, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24129 = v_c_24124;
        break;
      }
      case TAG_IsType: {
        V v_t_24125 = heff_field(v_x1_24119, 0);
        heff_take_n(v_x1_24119, 1ULL, 1);
        V v_t_24128;
        switch (heff_tag_of(v_t_24125)) {
        case TAG_At: {
          V v_s_24127 = heff_dup(heff_field(v_t_24125, 1));
          v_t_24128 = v_s_24127;
          break;
        }
        default: heff_nomatch(v_t_24125);
        }
        v_t_24129 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24125}), v_t_24128});
        break;
      }
      default: heff_nomatch(v_x1_24119);
      }
      V v_t_24130 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESpec, TAG_ISpec, 4, (V[]){v_t_24118, v_x_24114, v_fsp_24115, v_t_24129}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24130});
    }
    case TAG_ESig: {
      V v_fs_24131 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ESig = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24132 = (g_list_2emap_24s2016093283x1174801437(v_r_240, v_fs_24131));
      V v_t_24133 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TSig, 1, (V[]){v_t_24132}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24ESig, TAG_IsType, 1, (V[]){v_t_24133});
    }
    case TAG_ESum: {
      V v_vs_24134 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ESum = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24135 = (g_list_2emap_24s97919758x216970748(v_r_240, v_vs_24134));
      V v_t_24136 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TSum, 1, (V[]){v_t_24135}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24ESum, TAG_IsType, 1, (V[]){v_t_24136});
    }
    case TAG_EStruct: {
      V v_fs_24137 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EStruct = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24138 = (g_list_2emap_24s2039279853x710813703(v_r_240, v_fs_24137));
      V v_t_24139 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CStruct, 1, (V[]){v_t_24138}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EStruct, TAG_IsCheckable, 1, (V[]){v_t_24139});
    }
    case TAG_EUpdate: {
      V v_a_24140 = heff_field(v_x21_242, 0);
      V v_fs_24141 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EUpdate = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24142 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24140}));
      V v_t_24143 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24142));
      V v_t_24144 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo), 1, (V[]){v_r_240}));
      V v_t_24145 = (g_list_2emap_24tok2(v_ru_24x21_242_24EUpdate, v_t_24144, v_fs_24141));
      V v_t_24146 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IUpdate, 2, (V[]){v_t_24143, v_t_24145}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24146});
    }
    case TAG_EMatch: {
      V v_s_24147 = heff_field(v_x21_242, 0);
      V v_alts_24148 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EMatch = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24149 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_s_24147}));
      V v_t_24150 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24149));
      V v_t_24151 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ealtOf_clo), 1, (V[]){v_r_240}));
      V v_t_24152 = (g_list_2emap_24tok2(v_ru_24x21_242_24EMatch, v_t_24151, v_alts_24148));
      V v_t_24153 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_t_24150, v_t_24152}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24153});
    }
    case TAG_ELetIn: {
      V v_rhs_24154 = heff_field(v_x21_242, 0);
      V v_a_24155 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELetIn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24156 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rhs_24154}));
      V v_t_24157 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24156));
      V v_t_24173;
      switch (heff_tag_of(v_a_24155)) {
      case TAG_At: {
        V v_x21_24158 = heff_field(v_a_24155, 0);
        V v_sp_24159 = heff_field(v_a_24155, 1);
        heff_take_n(v_a_24155, 3ULL, 2);
        switch (heff_tag_of(v_x21_24158)) {
        case TAG_MkAlt: {
          V v_p_24160 = heff_field(v_x21_24158, 0);
          V v_b_24161 = heff_field(v_x21_24158, 1);
          heff_take_n(v_x21_24158, 3ULL, 2);
          V v_x1_24162 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_b_24161}));
          V v_t_24172;
          switch (heff_tag_of(v_x1_24162)) {
          case TAG_IsInferable: {
            V v_i_24163 = heff_field(v_x1_24162, 0);
            heff_take_n(v_x1_24162, 1ULL, 1);
            V v_t_24166;
            switch (heff_tag_of(v_i_24163)) {
            case TAG_At: {
              V v_s_24165 = heff_dup(heff_field(v_i_24163, 1));
              v_t_24166 = v_s_24165;
              break;
            }
            default: heff_nomatch(v_i_24163);
            }
            v_t_24172 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24163}), v_t_24166});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24167 = heff_field(v_x1_24162, 0);
            heff_take_n(v_x1_24162, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_241_24At, 2);
            v_t_24172 = v_c_24167;
            break;
          }
          case TAG_IsType: {
            V v_t_24168 = heff_field(v_x1_24162, 0);
            heff_take_n(v_x1_24162, 1ULL, 1);
            V v_t_24171;
            switch (heff_tag_of(v_t_24168)) {
            case TAG_At: {
              V v_s_24170 = heff_dup(heff_field(v_t_24168, 1));
              v_t_24171 = v_s_24170;
              break;
            }
            default: heff_nomatch(v_t_24168);
            }
            v_t_24172 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24168}), v_t_24171});
            break;
          }
          default: heff_nomatch(v_x1_24162);
          }
          v_t_24173 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24160, v_t_24172}), v_sp_24159});
          break;
        }
        default: heff_nomatch(v_x21_24158);
        }
        break;
      }
      default: heff_nomatch(v_a_24155);
      }
      V v_t_24174 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_t_24157, v_t_24173}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24174});
    }
    case TAG_EDo: {
      V v_stmts_24175 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EDo = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      HeffT2 v_t_24176 = (g_heff_2esyntax_2epresyntax_2edoBlock_24s1455639597x676970604_24cpr(heff_dup(v_sp_243), v_stmts_24175));
      {
        V v_field_24178 = v_t_24176.f[1];
        int64_t v_tag_24177 = ((int64_t)v_t_24176.f[0]);
        if ((v_tag_24177 == ((int64_t)0ULL))) {
          heff_drop(v_sp_243);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop_cell(v_ru_24x21_242_24EDo, 1);
          V v_e_27_24179 = v_field_24178;
          return heff_tail(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_27_24179});
        } else {
          heff_drop_rec(v_r_240, 2);
          heff_drop(v_field_24178);
          V v_t_24180 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str2), NTAG(TAG_Nothing)});
          return heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24180, v_sp_243})});
        }
      }
    }
    case TAG_ELocal: {
      V v_body_24181 = heff_field(v_x21_242, 0);
      V v_ds_24182 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELocal = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_24183 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 1, (V[]){v_body_24181}));
      V v_t_24193;
      switch (heff_tag_of(v_x1_24183)) {
      case TAG_IsInferable: {
        V v_i_24184 = heff_field(v_x1_24183, 0);
        heff_take_n(v_x1_24183, 1ULL, 1);
        V v_t_24187;
        switch (heff_tag_of(v_i_24184)) {
        case TAG_At: {
          V v_s_24186 = heff_dup(heff_field(v_i_24184, 1));
          v_t_24187 = v_s_24186;
          break;
        }
        default: heff_nomatch(v_i_24184);
        }
        v_t_24193 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24184}), v_t_24187});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24188 = heff_field(v_x1_24183, 0);
        heff_take_n(v_x1_24183, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24193 = v_c_24188;
        break;
      }
      case TAG_IsType: {
        V v_t_24189 = heff_field(v_x1_24183, 0);
        heff_take_n(v_x1_24183, 1ULL, 1);
        V v_t_24192;
        switch (heff_tag_of(v_t_24189)) {
        case TAG_At: {
          V v_s_24191 = heff_dup(heff_field(v_t_24189, 1));
          v_t_24192 = v_s_24191;
          break;
        }
        default: heff_nomatch(v_t_24189);
        }
        v_t_24193 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24189}), v_t_24192});
        break;
      }
      default: heff_nomatch(v_x1_24183);
      }
      V v_t_24194 = (g_list_2emap(heff_get_n(v_r_240, 1, 2), v_ds_24182));
      V v_t_24195 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CLocal, 2, (V[]){v_t_24193, v_t_24194}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24195});
    }
    case TAG_EInvalid: {
      V v_why_24196 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EInvalid = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24197 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_why_24196, NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24EInvalid, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24197, v_sp_243})});
    }
    case TAG_EAssign: {
      V v_x_24198 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EAssign = heff_take_reuse_n(v_x21_242, 1ULL, 3);
      heff_drop_rec(v_r_240, 2);
      V v_t_24201 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str3), heff_strAppend(v_x_24198, ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str4)));
      V v_t_24202 = heff_tag_at_n(v_ru_24x21_242_24EAssign, TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_t_24201, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24202, v_sp_243})});
    }
    case TAG_EWhile: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 2);
      V v_t_24205 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str5), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24205, v_sp_243})});
    }
    case TAG_EFor: {
      V v_ru_24x21_242_24EFor = heff_take_reuse_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_r_240, 2);
      V v_t_24209 = heff_tag_at_n(v_ru_24x21_242_24EFor, TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str6), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24209, v_sp_243})});
    }
    case TAG_EIfThen: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 2);
      V v_t_24212 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str7), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24212, v_sp_243})});
    }
    case TAG_EBreak: {
      heff_drop_rec(v_r_240, 2);
      V v_t_24213 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str8), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24213, v_sp_243})});
    }
    case TAG_EContinue: {
      heff_drop_rec(v_r_240, 2);
      V v_t_24214 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str9), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24214, v_sp_243})});
    }
    case TAG_EReturn: {
      V v_ru_24x21_242_24EReturn = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24216 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str10), NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24EReturn, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24216, v_sp_243})});
    }
    case TAG_ENest: {
      V v_ru_24x21_242_24ENest = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24218 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str11), NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24ENest, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24218, v_sp_243})});
    }
    case TAG_ELazy: {
      V v_e_24219 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ELazy = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_24220 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24219}));
      V v_t_24230;
      switch (heff_tag_of(v_x1_24220)) {
      case TAG_IsInferable: {
        V v_i_24221 = heff_field(v_x1_24220, 0);
        heff_take_n(v_x1_24220, 1ULL, 1);
        V v_t_24224;
        switch (heff_tag_of(v_i_24221)) {
        case TAG_At: {
          V v_s_24223 = heff_dup(heff_field(v_i_24221, 1));
          v_t_24224 = v_s_24223;
          break;
        }
        default: heff_nomatch(v_i_24221);
        }
        v_t_24230 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24221}), v_t_24224});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24225 = heff_field(v_x1_24220, 0);
        heff_take_n(v_x1_24220, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24230 = v_c_24225;
        break;
      }
      case TAG_IsType: {
        V v_t_24226 = heff_field(v_x1_24220, 0);
        heff_take_n(v_x1_24220, 1ULL, 1);
        V v_t_24229;
        switch (heff_tag_of(v_t_24226)) {
        case TAG_At: {
          V v_s_24228 = heff_dup(heff_field(v_t_24226, 1));
          v_t_24229 = v_s_24228;
          break;
        }
        default: heff_nomatch(v_t_24226);
        }
        v_t_24230 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24226}), v_t_24229});
        break;
      }
      default: heff_nomatch(v_x1_24220);
      }
      V v_t_24231 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ELazy, TAG_ILazy, 1, (V[]){v_t_24230}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24231});
    }
    case TAG_ETuple: {
      V v_es_24232 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ETuple = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24244 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2eclassifyTermF_lam0, 1, 1, (V[]){v_r_240}), v_es_24232));
      V v_t_24245 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ITuple, 1, (V[]){v_t_24244}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24ETuple, TAG_IsInferable, 1, (V[]){v_t_24245});
    }
    case TAG_ETry: {
      V v_ru_24x21_242_24ETry = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24247 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str12), NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24ETry, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24247, v_sp_243})});
    }
    case TAG_EWith: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_r_240, 2);
      V v_t_24252 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str13), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24252, v_sp_243})});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyTermF(a[0], a[1]);
}
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_lam0(V self, V *args) {
  V v_e_24233 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24234 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24233}));
  switch (heff_tag_of(v_x1_24234)) {
  case TAG_IsInferable: {
    V v_i_24235 = heff_field(v_x1_24234, 0);
    V v_ru_24x1_24234_24IsInferable = heff_take_reuse_n(v_x1_24234, 1ULL, 1);
    V v_t_24238;
    switch (heff_tag_of(v_i_24235)) {
    case TAG_At: {
      V v_s_24237 = heff_dup(heff_field(v_i_24235, 1));
      v_t_24238 = v_s_24237;
      break;
    }
    default: heff_nomatch(v_i_24235);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24234_24IsInferable, TAG_CInf, 1, (V[]){v_i_24235}), v_t_24238});
  }
  case TAG_IsCheckable: {
    V v_c_24239 = heff_field(v_x1_24234, 0);
    heff_take_n(v_x1_24234, 1ULL, 1);
    return v_c_24239;
  }
  case TAG_IsType: {
    V v_t_24240 = heff_field(v_x1_24234, 0);
    V v_ru_24x1_24234_24IsType = heff_take_reuse_n(v_x1_24234, 1ULL, 1);
    V v_t_24243;
    switch (heff_tag_of(v_t_24240)) {
    case TAG_At: {
      V v_s_24242 = heff_dup(heff_field(v_t_24240, 1));
      v_t_24243 = v_s_24242;
      break;
    }
    default: heff_nomatch(v_t_24240);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24234_24IsType, TAG_CType, 1, (V[]){v_t_24240}), v_t_24243});
  }
  default: return heff_nomatch(v_x1_24234);
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesBinary_24s164675078x1710946710_24cpr_str0, 11, "bytesConcat");

HeffT2 g_heff_2esyntax_2epresyntax_2ebytesBinary_24s164675078x1710946710_24cpr(V v_segs_240, V v_sp_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nothing: {
    V v_xs_243 = (g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(v_segs_240, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_243));
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_244, heff_dup(v_sp_241)));
    V v_args_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesBinary_24s164675078x1710946710_24cpr_str0)}), heff_dup(v_sp_241)});
    V v_t_248 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_246));
    V v_f_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_247, v_t_248}), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_249}});
  }
  case TAG_Just: {
    V v_s_2410 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24Just = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_segs_240);
    V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_242_24Just, TAG_IBytes, 1, (V[]){v_s_2410}), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2411}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xsp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24PiNamed = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    HeffT2 v_t_244 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_243));
    V v_t_2416;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_c_247 = v_field_246;
        V v_t_2410;
        switch (heff_tag_of(v_c_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_c_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_c_247);
        }
        v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_247}), v_t_2410});
      } else {
        if ((v_tag_245 == ((int64_t)1ULL))) {
          V v_i_2411 = v_field_246;
          V v_t_2414;
          switch (heff_tag_of(v_i_2411)) {
          case TAG_At: {
            V v_s_2413 = heff_dup(heff_field(v_i_2411, 1));
            v_t_2414 = v_s_2413;
            break;
          }
          default: heff_nomatch(v_i_2411);
          }
          v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2411}), v_t_2414});
        } else {
          V v_t_2415 = v_field_246;
          v_t_2416 = v_t_2415;
        }
      }
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_241, v_xsp_242, v_t_2416});
  }
  case TAG_PiImplicit: {
    V v_x_2417 = heff_field(v_x2_240, 0);
    V v_xsp_2418 = heff_field(v_x2_240, 1);
    V v_bsp_2419 = heff_field(v_x2_240, 2);
    V v_t_2420 = heff_field(v_x2_240, 3);
    V v_d_2421 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24PiImplicit = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    HeffT2 v_t_2422 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2420));
    V v_t_2434;
    {
      V v_field_2424 = v_t_2422.f[1];
      int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
      if ((v_tag_2423 == ((int64_t)0ULL))) {
        V v_c_2425 = v_field_2424;
        V v_t_2428;
        switch (heff_tag_of(v_c_2425)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_c_2425, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_c_2425);
        }
        v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2425}), v_t_2428});
      } else {
        if ((v_tag_2423 == ((int64_t)1ULL))) {
          V v_i_2429 = v_field_2424;
          V v_t_2432;
          switch (heff_tag_of(v_i_2429)) {
          case TAG_At: {
            V v_s_2431 = heff_dup(heff_field(v_i_2429, 1));
            v_t_2432 = v_s_2431;
            break;
          }
          default: heff_nomatch(v_i_2429);
          }
          v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2429}), v_t_2432});
        } else {
          V v_t_2433 = v_field_2424;
          v_t_2434 = v_t_2433;
        }
      }
    }
    V v_t_2449;
    switch (heff_tag_of(v_d_2421)) {
    case TAG_Nothing: {
      v_t_2449 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2435 = heff_field(v_d_2421, 0);
      V v_ru_24d_2421_24Just = heff_take_reuse_n(v_d_2421, 1ULL, 1);
      HeffT2 v_t_2436 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_2435));
      V v_t_2448;
      {
        V v_field_2438 = v_t_2436.f[1];
        int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
        if ((v_tag_2437 == ((int64_t)0ULL))) {
          V v_c_2439 = v_field_2438;
          v_t_2448 = v_c_2439;
        } else {
          if ((v_tag_2437 == ((int64_t)1ULL))) {
            V v_i_2440 = v_field_2438;
            V v_t_2443;
            switch (heff_tag_of(v_i_2440)) {
            case TAG_At: {
              V v_s_2442 = heff_dup(heff_field(v_i_2440, 1));
              v_t_2443 = v_s_2442;
              break;
            }
            default: heff_nomatch(v_i_2440);
            }
            v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2440}), v_t_2443});
          } else {
            V v_t_2444 = v_field_2438;
            V v_t_2447;
            switch (heff_tag_of(v_t_2444)) {
            case TAG_At: {
              V v_s_2446 = heff_dup(heff_field(v_t_2444, 1));
              v_t_2447 = v_s_2446;
              break;
            }
            default: heff_nomatch(v_t_2444);
            }
            v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2444}), v_t_2447});
          }
        }
      }
      v_t_2449 = heff_tag_at_n(v_ru_24d_2421_24Just, TAG_Just, 1, (V[]){v_t_2448});
      break;
    }
    default: heff_nomatch(v_d_2421);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_2417, v_xsp_2418, v_bsp_2419, v_t_2434, v_t_2449});
  }
  case TAG_PiInstance: {
    V v_x_2450 = heff_field(v_x2_240, 0);
    V v_xsp_2451 = heff_field(v_x2_240, 1);
    V v_bsp_2452 = heff_field(v_x2_240, 2);
    V v_t_2453 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24PiInstance = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    HeffT2 v_t_2454 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2453));
    V v_t_2466;
    {
      V v_field_2456 = v_t_2454.f[1];
      int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
      if ((v_tag_2455 == ((int64_t)0ULL))) {
        V v_c_2457 = v_field_2456;
        V v_t_2460;
        switch (heff_tag_of(v_c_2457)) {
        case TAG_At: {
          V v_s_2459 = heff_dup(heff_field(v_c_2457, 1));
          v_t_2460 = v_s_2459;
          break;
        }
        default: heff_nomatch(v_c_2457);
        }
        v_t_2466 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2457}), v_t_2460});
      } else {
        if ((v_tag_2455 == ((int64_t)1ULL))) {
          V v_i_2461 = v_field_2456;
          V v_t_2464;
          switch (heff_tag_of(v_i_2461)) {
          case TAG_At: {
            V v_s_2463 = heff_dup(heff_field(v_i_2461, 1));
            v_t_2464 = v_s_2463;
            break;
          }
          default: heff_nomatch(v_i_2461);
          }
          v_t_2466 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2461}), v_t_2464});
        } else {
          V v_t_2465 = v_field_2456;
          v_t_2466 = v_t_2465;
        }
      }
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2450, v_xsp_2451, v_bsp_2452, v_t_2466});
  }
  case TAG_PiAnon: {
    V v_t_2467 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24PiAnon = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    HeffT2 v_t_2468 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2467));
    V v_t_2480;
    {
      V v_field_2470 = v_t_2468.f[1];
      int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
      if ((v_tag_2469 == ((int64_t)0ULL))) {
        V v_c_2471 = v_field_2470;
        V v_t_2474;
        switch (heff_tag_of(v_c_2471)) {
        case TAG_At: {
          V v_s_2473 = heff_dup(heff_field(v_c_2471, 1));
          v_t_2474 = v_s_2473;
          break;
        }
        default: heff_nomatch(v_c_2471);
        }
        v_t_2480 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2471}), v_t_2474});
      } else {
        if ((v_tag_2469 == ((int64_t)1ULL))) {
          V v_i_2475 = v_field_2470;
          V v_t_2478;
          switch (heff_tag_of(v_i_2475)) {
          case TAG_At: {
            V v_s_2477 = heff_dup(heff_field(v_i_2475, 1));
            v_t_2478 = v_s_2477;
            break;
          }
          default: heff_nomatch(v_i_2475);
          }
          v_t_2480 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2475}), v_t_2478});
        } else {
          V v_t_2479 = v_field_2470;
          v_t_2480 = v_t_2479;
        }
      }
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2480});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str0, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str1, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str2, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str4, 67, " := e` sets a `let mut` variable: it is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str5, 45, "a `while` loop is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str6, 43, "a `for` loop is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str7, 78, "an `if` without `else` is a statement of a `do` block: a value's has an `else`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str8, 78, "`break` is a statement of a loop's body: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str9, 81, "`continue` is a statement of a loop's body: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str10, 103, "`return e` ends a `do` block as one of its statements (or an arm of its `if` or `case`), not as a value");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str11, 67, "`(<- c)`, the value of an action, is in a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str12, 72, "a `try` is a statement of a `do` block (or an arm of its `if` or `case`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str13, 73, "a `with` is a statement of a `do` block (or an arm of its `if` or `case`)");

HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_EVar: {
      V v_x_243 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_243}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_244}});
    }
    case TAG_EImplicitVar: {
      V v_x_245 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_246 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_245}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_246}});
    }
    case TAG_ETag: {
      V v_t_247 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_248 = heff_tag_n(TAG_CTag, 3, (V[]){v_t_247, heff_dup(v_sp_242), NTAG(TAG_Nil)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_248, v_sp_242})}});
    }
    case TAG_EInt: {
      V v_i_249 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_2410 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_i_249}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2410}});
    }
    case TAG_EFloat: {
      double v_x_2411 = heff_tflat_f64(v_x21_241, 0);
      heff_take_na(v_x21_241, 0ULL, 1);
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_nf(TAG_IFloat, 1, 1u, (V[]){heff_word_f64(v_x_2411)}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2412}});
    }
    case TAG_EString: {
      V v_x_2413 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IString, 1, (V[]){v_x_2413}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2414}});
    }
    case TAG_EBinary: {
      V v_segs_2415 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_segs_2415; V a_2 = v_sp_242; HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    }
    case TAG_ERune: {
      V v_c_2416 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IRune, 1, (V[]){v_c_2416}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2417}});
    }
    case TAG_EWord: {
      V v_w_2418 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return (g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(v_w_2418, v_sp_242));
    }
    case TAG_EApp: {
      V v_h_2419 = heff_field(v_x21_241, 0);
      V v_args_2420 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_2421 = (g_heff_2esyntax_2epresyntax_2erunArgs(heff_dup(v_h_2419), v_args_2420));
      return (g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr(v_h_2419, v_t_2421, v_sp_242));
    }
    case TAG_EProject: {
      heff_take_n(v_x21_241, 0ULL, 1);
      V v_t_2423 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str0), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2423, v_sp_242})}});
    }
    case TAG_ENamed: {
      heff_take_n(v_x21_241, 0ULL, 2);
      V v_t_2426 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str1), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2426, v_sp_242})}});
    }
    case TAG_EPi: {
      V v_b_2427 = heff_field(v_x21_241, 0);
      V v_cod_2428 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24EPi = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_t_2429 = (g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(v_b_2427));
      HeffT2 v_t_2430 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_cod_2428));
      V v_t_2442;
      {
        V v_field_2432 = v_t_2430.f[1];
        int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
        if ((v_tag_2431 == ((int64_t)0ULL))) {
          V v_c_2433 = v_field_2432;
          V v_t_2436;
          switch (heff_tag_of(v_c_2433)) {
          case TAG_At: {
            V v_s_2435 = heff_dup(heff_field(v_c_2433, 1));
            v_t_2436 = v_s_2435;
            break;
          }
          default: heff_nomatch(v_c_2433);
          }
          v_t_2442 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2433}), v_t_2436});
        } else {
          if ((v_tag_2431 == ((int64_t)1ULL))) {
            V v_i_2437 = v_field_2432;
            V v_t_2440;
            switch (heff_tag_of(v_i_2437)) {
            case TAG_At: {
              V v_s_2439 = heff_dup(heff_field(v_i_2437, 1));
              v_t_2440 = v_s_2439;
              break;
            }
            default: heff_nomatch(v_i_2437);
            }
            v_t_2442 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2437}), v_t_2440});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2441 = v_field_2432;
            v_t_2442 = v_t_2441;
          }
        }
      }
      V v_f_2443 = heff_tag_at_n(v_ru_24x21_241_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_TPi, 2, (V[]){v_t_2429, v_t_2442}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_f_2443}});
    }
    case TAG_ELam: {
      V v_x211_2444 = heff_field(v_x21_241, 0);
      V v_body_2445 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELam = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      switch (heff_tag_of(v_x211_2444)) {
      case TAG_LamName: {
        V v_x_2446 = heff_field(v_x211_2444, 0);
        V v_xsp_2447 = heff_field(v_x211_2444, 1);
        heff_take_n(v_x211_2444, 3ULL, 2);
        HeffT2 v_t_2448 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_2445));
        V v_t_2460;
        {
          V v_field_2450 = v_t_2448.f[1];
          int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
          if ((v_tag_2449 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_c_2451 = v_field_2450;
            v_t_2460 = v_c_2451;
          } else {
            if ((v_tag_2449 == ((int64_t)1ULL))) {
              V v_i_2452 = v_field_2450;
              V v_t_2455;
              switch (heff_tag_of(v_i_2452)) {
              case TAG_At: {
                V v_s_2454 = heff_dup(heff_field(v_i_2452, 1));
                v_t_2455 = v_s_2454;
                break;
              }
              default: heff_nomatch(v_i_2452);
              }
              v_t_2460 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2452}), v_t_2455});
            } else {
              V v_t_2456 = v_field_2450;
              V v_t_2459;
              switch (heff_tag_of(v_t_2456)) {
              case TAG_At: {
                V v_s_2458 = heff_dup(heff_field(v_t_2456, 1));
                v_t_2459 = v_s_2458;
                break;
              }
              default: heff_nomatch(v_t_2456);
              }
              v_t_2460 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2456}), v_t_2459});
            }
          }
        }
        V v_f_2461 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CLam, 3, (V[]){v_x_2446, v_xsp_2447, v_t_2460}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2461}});
      }
      case TAG_LamImplicit: {
        V v_x_2462 = heff_field(v_x211_2444, 0);
        V v_xsp_2463 = heff_field(v_x211_2444, 1);
        heff_take_n(v_x211_2444, 3ULL, 2);
        HeffT2 v_t_2464 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_2445));
        V v_t_2476;
        {
          V v_field_2466 = v_t_2464.f[1];
          int64_t v_tag_2465 = ((int64_t)v_t_2464.f[0]);
          if ((v_tag_2465 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_c_2467 = v_field_2466;
            v_t_2476 = v_c_2467;
          } else {
            if ((v_tag_2465 == ((int64_t)1ULL))) {
              V v_i_2468 = v_field_2466;
              V v_t_2471;
              switch (heff_tag_of(v_i_2468)) {
              case TAG_At: {
                V v_s_2470 = heff_dup(heff_field(v_i_2468, 1));
                v_t_2471 = v_s_2470;
                break;
              }
              default: heff_nomatch(v_i_2468);
              }
              v_t_2476 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2468}), v_t_2471});
            } else {
              V v_t_2472 = v_field_2466;
              V v_t_2475;
              switch (heff_tag_of(v_t_2472)) {
              case TAG_At: {
                V v_s_2474 = heff_dup(heff_field(v_t_2472, 1));
                v_t_2475 = v_s_2474;
                break;
              }
              default: heff_nomatch(v_t_2472);
              }
              v_t_2476 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2472}), v_t_2475});
            }
          }
        }
        V v_f_2477 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CImplicitLam, 3, (V[]){v_x_2462, v_xsp_2463, v_t_2476}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2477}});
      }
      case TAG_LamAnn: {
        V v_x_2478 = heff_field(v_x211_2444, 0);
        V v_xsp_2479 = heff_field(v_x211_2444, 1);
        V v_t_2480 = heff_field(v_x211_2444, 2);
        heff_take_n(v_x211_2444, 7ULL, 3);
        heff_drop_cell(v_ru_24x21_241_24ELam, 2);
        HeffT2 v_t_2481 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2480));
        V v_t_2493;
        {
          V v_field_2483 = v_t_2481.f[1];
          int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
          if ((v_tag_2482 == ((int64_t)0ULL))) {
            V v_c_2484 = v_field_2483;
            V v_t_2487;
            switch (heff_tag_of(v_c_2484)) {
            case TAG_At: {
              V v_s_2486 = heff_dup(heff_field(v_c_2484, 1));
              v_t_2487 = v_s_2486;
              break;
            }
            default: heff_nomatch(v_c_2484);
            }
            v_t_2493 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2484}), v_t_2487});
          } else {
            if ((v_tag_2482 == ((int64_t)1ULL))) {
              V v_i_2488 = v_field_2483;
              V v_t_2491;
              switch (heff_tag_of(v_i_2488)) {
              case TAG_At: {
                V v_s_2490 = heff_dup(heff_field(v_i_2488, 1));
                v_t_2491 = v_s_2490;
                break;
              }
              default: heff_nomatch(v_i_2488);
              }
              v_t_2493 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2488}), v_t_2491});
            } else {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_t_2492 = v_field_2483;
              v_t_2493 = v_t_2492;
            }
          }
        }
        V v_t_2494 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_body_2445));
        return (g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(v_x_2478, v_xsp_2479, v_t_2493, v_t_2494, v_sp_242));
      }
      default: return ((HeffT2){{heff_nomatch(v_x211_2444)}});
      }
    }
    case TAG_EAnn: {
      V v_a_2495 = heff_field(v_x21_241, 0);
      V v_t_2496 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24EAnn = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      HeffT2 v_t_2497 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_a_2495));
      V v_t_24109;
      {
        V v_field_2499 = v_t_2497.f[1];
        int64_t v_tag_2498 = ((int64_t)v_t_2497.f[0]);
        if ((v_tag_2498 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_24100 = v_field_2499;
          v_t_24109 = v_c_24100;
        } else {
          if ((v_tag_2498 == ((int64_t)1ULL))) {
            V v_i_24101 = v_field_2499;
            V v_t_24104;
            switch (heff_tag_of(v_i_24101)) {
            case TAG_At: {
              V v_s_24103 = heff_dup(heff_field(v_i_24101, 1));
              v_t_24104 = v_s_24103;
              break;
            }
            default: heff_nomatch(v_i_24101);
            }
            v_t_24109 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24101}), v_t_24104});
          } else {
            V v_t_24105 = v_field_2499;
            V v_t_24108;
            switch (heff_tag_of(v_t_24105)) {
            case TAG_At: {
              V v_s_24107 = heff_dup(heff_field(v_t_24105, 1));
              v_t_24108 = v_s_24107;
              break;
            }
            default: heff_nomatch(v_t_24105);
            }
            v_t_24109 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24105}), v_t_24108});
          }
        }
      }
      HeffT2 v_t_24110 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2496));
      V v_t_24122;
      {
        V v_field_24112 = v_t_24110.f[1];
        int64_t v_tag_24111 = ((int64_t)v_t_24110.f[0]);
        if ((v_tag_24111 == ((int64_t)0ULL))) {
          V v_c_24113 = v_field_24112;
          V v_t_24116;
          switch (heff_tag_of(v_c_24113)) {
          case TAG_At: {
            V v_s_24115 = heff_dup(heff_field(v_c_24113, 1));
            v_t_24116 = v_s_24115;
            break;
          }
          default: heff_nomatch(v_c_24113);
          }
          v_t_24122 = heff_tag_at_n(v_ru_24x21_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_24113}), v_t_24116});
        } else {
          if ((v_tag_24111 == ((int64_t)1ULL))) {
            V v_i_24117 = v_field_24112;
            V v_t_24120;
            switch (heff_tag_of(v_i_24117)) {
            case TAG_At: {
              V v_s_24119 = heff_dup(heff_field(v_i_24117, 1));
              v_t_24120 = v_s_24119;
              break;
            }
            default: heff_nomatch(v_i_24117);
            }
            v_t_24122 = heff_tag_at_n(v_ru_24x21_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_24117}), v_t_24120});
          } else {
            heff_drop_cell(v_ru_24x21_241_24EAnn, 2);
            V v_t_24121 = v_field_24112;
            v_t_24122 = v_t_24121;
          }
        }
      }
      V v_f_24123 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_24109, v_t_24122}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24123}});
    }
    case TAG_ESpec: {
      V v_a_24124 = heff_field(v_x21_241, 0);
      V v_x_24125 = heff_field(v_x21_241, 1);
      V v_fsp_24126 = heff_field(v_x21_241, 2);
      V v_v_24127 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24ESpec = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_t_24128 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_a_24124));
      V v_t_24129 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24128));
      HeffT2 v_t_24130 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_24127));
      V v_t_24142;
      {
        V v_field_24132 = v_t_24130.f[1];
        int64_t v_tag_24131 = ((int64_t)v_t_24130.f[0]);
        if ((v_tag_24131 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_24133 = v_field_24132;
          v_t_24142 = v_c_24133;
        } else {
          if ((v_tag_24131 == ((int64_t)1ULL))) {
            V v_i_24134 = v_field_24132;
            V v_t_24137;
            switch (heff_tag_of(v_i_24134)) {
            case TAG_At: {
              V v_s_24136 = heff_dup(heff_field(v_i_24134, 1));
              v_t_24137 = v_s_24136;
              break;
            }
            default: heff_nomatch(v_i_24134);
            }
            v_t_24142 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24134}), v_t_24137});
          } else {
            V v_t_24138 = v_field_24132;
            V v_t_24141;
            switch (heff_tag_of(v_t_24138)) {
            case TAG_At: {
              V v_s_24140 = heff_dup(heff_field(v_t_24138, 1));
              v_t_24141 = v_s_24140;
              break;
            }
            default: heff_nomatch(v_t_24138);
            }
            v_t_24142 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24138}), v_t_24141});
          }
        }
      }
      V v_f_24143 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ESpec, TAG_ISpec, 4, (V[]){v_t_24129, v_x_24125, v_fsp_24126, v_t_24142}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24143}});
    }
    case TAG_ESig: {
      V v_fs_24144 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_24145 = (g_list_2emap_24s205414595x1692305030(v_fs_24144));
      V v_f_24146 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TSig, 1, (V[]){v_t_24145}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_f_24146}});
    }
    case TAG_ESum: {
      V v_vs_24147 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_24148 = (g_list_2emap_24s1258450377x973220636(v_vs_24147));
      V v_f_24149 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TSum, 1, (V[]){v_t_24148}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_f_24149}});
    }
    case TAG_EStruct: {
      V v_fs_24150 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_24151 = (g_list_2emap_24s961097229x1129443801(v_fs_24150));
      V v_f_24152 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CStruct, 1, (V[]){v_t_24151}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24152}});
    }
    case TAG_EUpdate: {
      V v_a_24153 = heff_field(v_x21_241, 0);
      V v_fs_24154 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      V v_t_24155 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_a_24153));
      V v_t_24156 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24155));
      V v_t_24157 = (g_list_2emap_24s137457135x961689574(v_fs_24154));
      V v_f_24158 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IUpdate, 2, (V[]){v_t_24156, v_t_24157}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24158}});
    }
    case TAG_EMatch: {
      V v_s_24159 = heff_field(v_x21_241, 0);
      V v_alts_24160 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      V v_t_24161 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_s_24159));
      V v_t_24162 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24161));
      V v_t_24163 = (g_list_2emap_24s1230969749x2018313496(v_alts_24160));
      V v_f_24164 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_t_24162, v_t_24163}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24164}});
    }
    case TAG_ELetIn: {
      V v_rhs_24165 = heff_field(v_x21_241, 0);
      V v_a_24166 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELetIn = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_t_24167 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_rhs_24165));
      V v_t_24168 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24167));
      V v_t_24186;
      switch (heff_tag_of(v_a_24166)) {
      case TAG_At: {
        V v_x21_24169 = heff_field(v_a_24166, 0);
        V v_sp_24170 = heff_field(v_a_24166, 1);
        heff_take_n(v_a_24166, 3ULL, 2);
        switch (heff_tag_of(v_x21_24169)) {
        case TAG_MkAlt: {
          V v_p_24171 = heff_field(v_x21_24169, 0);
          V v_b_24172 = heff_field(v_x21_24169, 1);
          heff_take_n(v_x21_24169, 3ULL, 2);
          HeffT2 v_t_24173 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_b_24172));
          V v_t_24185;
          {
            V v_field_24175 = v_t_24173.f[1];
            int64_t v_tag_24174 = ((int64_t)v_t_24173.f[0]);
            if ((v_tag_24174 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_24176 = v_field_24175;
              v_t_24185 = v_c_24176;
            } else {
              if ((v_tag_24174 == ((int64_t)1ULL))) {
                V v_i_24177 = v_field_24175;
                V v_t_24180;
                switch (heff_tag_of(v_i_24177)) {
                case TAG_At: {
                  V v_s_24179 = heff_dup(heff_field(v_i_24177, 1));
                  v_t_24180 = v_s_24179;
                  break;
                }
                default: heff_nomatch(v_i_24177);
                }
                v_t_24185 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24177}), v_t_24180});
              } else {
                V v_t_24181 = v_field_24175;
                V v_t_24184;
                switch (heff_tag_of(v_t_24181)) {
                case TAG_At: {
                  V v_s_24183 = heff_dup(heff_field(v_t_24181, 1));
                  v_t_24184 = v_s_24183;
                  break;
                }
                default: heff_nomatch(v_t_24181);
                }
                v_t_24185 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24181}), v_t_24184});
              }
            }
          }
          v_t_24186 = heff_tag_at_n(v_ru_24x21_241_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24171, v_t_24185}), v_sp_24170});
          break;
        }
        default: heff_nomatch(v_x21_24169);
        }
        break;
      }
      default: heff_nomatch(v_a_24166);
      }
      V v_f_24187 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_t_24168, v_t_24186}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24187}});
    }
    case TAG_EDo: {
      V v_stmts_24188 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      HeffT2 v_t_24189 = (g_heff_2esyntax_2epresyntax_2edoBlock_24s1455639597x676970604_24cpr(heff_dup(v_sp_242), v_stmts_24188));
      {
        V v_field_24191 = v_t_24189.f[1];
        int64_t v_tag_24190 = ((int64_t)v_t_24189.f[0]);
        if ((v_tag_24190 == ((int64_t)0ULL))) {
          heff_drop(v_sp_242);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_e_27_24192 = v_field_24191;
          V t_0 = v_e_27_24192;
          v_x2_240 = t_0;
          goto top;
        } else {
          heff_drop(v_field_24191);
          V v_t_24193 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str2), NTAG(TAG_Nothing)});
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24193, v_sp_242})}});
        }
      }
    }
    case TAG_ELocal: {
      V v_body_24194 = heff_field(v_x21_241, 0);
      V v_ds_24195 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELocal = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      HeffT2 v_t_24196 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_24194));
      V v_t_24208;
      {
        V v_field_24198 = v_t_24196.f[1];
        int64_t v_tag_24197 = ((int64_t)v_t_24196.f[0]);
        if ((v_tag_24197 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_24199 = v_field_24198;
          v_t_24208 = v_c_24199;
        } else {
          if ((v_tag_24197 == ((int64_t)1ULL))) {
            V v_i_24200 = v_field_24198;
            V v_t_24203;
            switch (heff_tag_of(v_i_24200)) {
            case TAG_At: {
              V v_s_24202 = heff_dup(heff_field(v_i_24200, 1));
              v_t_24203 = v_s_24202;
              break;
            }
            default: heff_nomatch(v_i_24200);
            }
            v_t_24208 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24200}), v_t_24203});
          } else {
            V v_t_24204 = v_field_24198;
            V v_t_24207;
            switch (heff_tag_of(v_t_24204)) {
            case TAG_At: {
              V v_s_24206 = heff_dup(heff_field(v_t_24204, 1));
              v_t_24207 = v_s_24206;
              break;
            }
            default: heff_nomatch(v_t_24204);
            }
            v_t_24208 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24204}), v_t_24207});
          }
        }
      }
      V v_t_24209 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2esyntax_2epresyntax_2eclassifier_get(), 1)), v_ds_24195));
      V v_f_24210 = heff_tag_at_n(v_ru_24x21_241_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CLocal, 2, (V[]){v_t_24208, v_t_24209}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24210}});
    }
    case TAG_EInvalid: {
      V v_why_24211 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_24212 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_why_24211, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24212, v_sp_242})}});
    }
    case TAG_EAssign: {
      V v_x_24213 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EAssign = heff_take_reuse_n(v_x21_241, 1ULL, 3);
      V v_t_24216 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str3), heff_strAppend(v_x_24213, ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str4)));
      V v_t_24217 = heff_tag_at_n(v_ru_24x21_241_24EAssign, TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_t_24216, NTAG(TAG_Nothing)});
      V v_f_24218 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24217, v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24218}});
    }
    case TAG_EWhile: {
      heff_take_n(v_x21_241, 0ULL, 2);
      V v_t_24221 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str5), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24221, v_sp_242})}});
    }
    case TAG_EFor: {
      V v_ru_24x21_241_24EFor = heff_take_reuse_n(v_x21_241, 0ULL, 3);
      V v_t_24225 = heff_tag_at_n(v_ru_24x21_241_24EFor, TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str6), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24225, v_sp_242})}});
    }
    case TAG_EIfThen: {
      heff_take_n(v_x21_241, 0ULL, 2);
      V v_t_24228 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str7), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24228, v_sp_242})}});
    }
    case TAG_EBreak: {
      V v_t_24229 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str8), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24229, v_sp_242})}});
    }
    case TAG_EContinue: {
      V v_t_24230 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str9), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24230, v_sp_242})}});
    }
    case TAG_EReturn: {
      heff_take_n(v_x21_241, 0ULL, 1);
      V v_t_24232 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str10), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24232, v_sp_242})}});
    }
    case TAG_ENest: {
      heff_take_n(v_x21_241, 0ULL, 1);
      V v_t_24234 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str11), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24234, v_sp_242})}});
    }
    case TAG_ELazy: {
      V v_e_24235 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24ELazy = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      HeffT2 v_t_24236 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_24235));
      V v_t_24248;
      {
        V v_field_24238 = v_t_24236.f[1];
        int64_t v_tag_24237 = ((int64_t)v_t_24236.f[0]);
        if ((v_tag_24237 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_24239 = v_field_24238;
          v_t_24248 = v_c_24239;
        } else {
          if ((v_tag_24237 == ((int64_t)1ULL))) {
            V v_i_24240 = v_field_24238;
            V v_t_24243;
            switch (heff_tag_of(v_i_24240)) {
            case TAG_At: {
              V v_s_24242 = heff_dup(heff_field(v_i_24240, 1));
              v_t_24243 = v_s_24242;
              break;
            }
            default: heff_nomatch(v_i_24240);
            }
            v_t_24248 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24240}), v_t_24243});
          } else {
            V v_t_24244 = v_field_24238;
            V v_t_24247;
            switch (heff_tag_of(v_t_24244)) {
            case TAG_At: {
              V v_s_24246 = heff_dup(heff_field(v_t_24244, 1));
              v_t_24247 = v_s_24246;
              break;
            }
            default: heff_nomatch(v_t_24244);
            }
            v_t_24248 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24244}), v_t_24247});
          }
        }
      }
      V v_f_24249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ELazy, TAG_ILazy, 1, (V[]){v_t_24248}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24249}});
    }
    case TAG_ETuple: {
      V v_es_24250 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_24251 = (g_list_2emap_24s1844509821x2028168277(v_es_24250));
      V v_f_24252 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ITuple, 1, (V[]){v_t_24251}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24252}});
    }
    case TAG_ETry: {
      heff_take_n(v_x21_241, 0ULL, 1);
      V v_t_24254 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str12), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24254, v_sp_242})}});
    }
    case TAG_EWith: {
      heff_take_n(v_x21_241, 0ULL, 4);
      V v_t_24259 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str13), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24259, v_sp_242})}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V v_x2_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x2_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_field_243});
    } else {
      if ((v_tag_242 == ((int64_t)1ULL))) {
        return heff_tag_n(TAG_IsInferable, 1, (V[]){v_field_243});
      } else {
        return heff_tag_n(TAG_IsType, 1, (V[]){v_field_243});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1(V v_tok_240, V v_r_241, V v_asBits_242, V v_segs_243, V v_sp_244) {
top: ;
  HeffT1 v_t_245 = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(v_r_241, v_asBits_242, v_segs_243, v_sp_244));
  {
    V v_field_246 = v_t_245.f[0];
    return heff_tag_at_n(v_tok_240, TAG_IsInferable, 1, (V[]){v_field_246});
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(V v_tok_240, V v_sp_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_n_242)) {
  case TAG_IVar: {
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
    V v_t_245 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_244, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_241});
  }
  case TAG_IInt: {
    V v_t_247 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
    V v_t_248 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_247, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_sp_241});
  }
  case TAG_IFloat: {
    V v_t_2410 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
    V v_t_2411 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2410, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_sp_241});
  }
  case TAG_IString: {
    V v_t_2413 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
    V v_t_2414 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_sp_241});
  }
  case TAG_IBytes: {
    V v_t_2416 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
    V v_t_2417 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2416, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_sp_241});
  }
  case TAG_IPrim: {
    V v_t_2419 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
    V v_t_2420 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2419, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_sp_241});
  }
  case TAG_IRune: {
    V v_t_2422 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
    V v_t_2423 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2422, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_sp_241});
  }
  case TAG_IApp: {
    V v_t_2426 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
    V v_t_2427 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2426, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2427, v_sp_241});
  }
  case TAG_IAnn: {
    V v_c_2428 = heff_field(v_n_242, 0);
    V v_t_2429 = heff_field(v_n_242, 1);
    V v_ru_24n_242_24IAnn = heff_take_reuse_n(v_n_242, 3ULL, 2);
    V v_t_2432;
    switch (heff_tag_of(v_c_2428)) {
    case TAG_At: {
      V v_n_2430 = heff_field(v_c_2428, 0);
      V v_sp_2431 = heff_field(v_c_2428, 1);
      heff_take_n(v_c_2428, 3ULL, 2);
      v_t_2432 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2431, v_n_2430));
      break;
    }
    default: heff_nomatch(v_c_2428);
    }
    V v_t_2435;
    switch (heff_tag_of(v_t_2429)) {
    case TAG_At: {
      V v_n_2433 = heff_field(v_t_2429, 0);
      V v_sp_2434 = heff_field(v_t_2429, 1);
      heff_take_n(v_t_2429, 3ULL, 2);
      v_t_2435 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24n_242_24IAnn, v_sp_2434, v_n_2433));
      break;
    }
    default: heff_nomatch(v_t_2429);
    }
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_2432, v_t_2435}), v_sp_241});
  }
  case TAG_ISpec: {
    V v_t_2440 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
    V v_t_2441 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2440, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2441, v_sp_241});
  }
  case TAG_IUpdate: {
    V v_t_2444 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
    V v_t_2445 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2444, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2445, v_sp_241});
  }
  case TAG_IAnnLam: {
    V v_t_2450 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
    V v_t_2451 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2450, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2451, v_sp_241});
  }
  case TAG_IInvalid: {
    V v_code_2452 = heff_field(v_n_242, 0);
    V v_why_2453 = heff_field(v_n_242, 1);
    V v_note_2454 = heff_field(v_n_242, 2);
    heff_take_n(v_n_242, 7ULL, 3);
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 3, (V[]){v_code_2452, v_why_2453, v_note_2454}), v_sp_241});
  }
  case TAG_INominal: {
    V v_t_2456 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
    V v_t_2457 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2456, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2457, v_sp_241});
  }
  case TAG_ILitEq: {
    V v_t_2462 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
    V v_t_2463 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2462, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2463, v_sp_241});
  }
  case TAG_ILazy: {
    V v_t_2465 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
    V v_t_2466 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2465, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2466, v_sp_241});
  }
  case TAG_ITuple: {
    V v_t_2468 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
    V v_t_2469 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2468, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2469, v_sp_241});
  }
  default: return heff_nomatch(v_n_242);
  }
}
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_str0, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1(V v_tok_240, V v_cx_241, V v_sp_242, V v_j_243) {
top: ;
  V v_depth_244 = heff_take_field(v_j_243, 3);
  V v_head_245 = heff_take_field(v_j_243, 0);
  V v_vars_246 = heff_take_field(v_j_243, 1);
  V v_unit_247 = heff_get_n(v_j_243, 2, 4);
  V v_t_248 = heff_intSub(heff_dup(heff_rfield(v_cx_241, 4)), v_depth_244);
  V v_vars_249 = v_vars_246;
  V v_t_2413;
  if ((heff_dup(v_unit_247) == NTAG(TAG_True))) {
    heff_drop(v_unit_247);
    switch (heff_tag_of(v_vars_249)) {
    case TAG_Nil: {
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_str0)}), heff_dup(v_sp_242)});
      v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      heff_drop_cell(v_tok_240, 1);
      v_t_2413 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_249));
      break;
    }
    default: heff_nomatch(v_vars_249);
    }
  } else {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_unit_247);
    v_t_2413 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_249));
  }
  V v_t_2414 = (g_heff_2esyntax_2epresyntax_2eapp(v_head_245, v_t_2413));
  HEFF_LAST return g_heff_2esyntax_2epresyntax_2eleaving(v_cx_241, v_sp_242, v_t_248, v_t_2414);
}
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1(a[0], a[1], a[2], a[3]);
}