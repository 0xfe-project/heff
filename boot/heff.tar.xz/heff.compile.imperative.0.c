// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DLet 13606
#define TAG_DSet 20333
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_PartVal 41444
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define LBL_atom 9500184
#define LBL_bindTo 558176963
#define LBL_cond 9554921
#define LBL_full 9650006
#define LBL_op 10312
#define LBL_pred 9944808
#define LBL_setTo 310686359
#define LBL_simple 1044855005
#define LBL_sts 323756
#define LBL_tail 10047767
#define LBL_tl 10463
#define LBL_val 326043
static uint32_t shape_full__simple__tail__bindTo__setTo__atom__op__pred[] = {LBL_full, LBL_simple, LBL_tail, LBL_bindTo, LBL_setTo, LBL_atom, LBL_op, LBL_pred};
V g_heff_2ecompile_2eimperative_2eallL_24s2034742406x913054912(V);
V g_heff_2ecompile_2eimperative_2eallL_24s2034742406x913054912_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eallL_24s2034742406x913054912_clo;
HeffT2 g_heff_2ecompile_2eimperative_2earmNamed_24cpr(V, V);
V g_heff_2ecompile_2eimperative_2eatomOf(V, V);
V g_heff_2ecompile_2eimperative_2eatomOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eatomOf_clo;
V g_heff_2ecompile_2eimperative_2eatomsOf(V, V);
V g_heff_2ecompile_2eimperative_2eatomsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eatomsOf_clo;
V g_heff_2ecompile_2eimperative_2econdIf(V, V, V);
V g_heff_2ecompile_2eimperative_2econdIf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2econdIf_clo;
V g_heff_2ecompile_2eimperative_2econdIf_24dps(V, V, V, V);
V g_heff_2ecompile_2eimperative_2econdIf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2econdIf_24dps_clo;
V g_heff_2ecompile_2eimperative_2econdShaped(V);
V g_heff_2ecompile_2eimperative_2econdShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2econdShaped_clo;
V g_heff_2ecompile_2eimperative_2edeclBefore(V, V);
V g_heff_2ecompile_2eimperative_2edeclBefore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2edeclBefore_clo;
V g_heff_2ecompile_2eimperative_2edeclBefore_24dps(V, V, V);
V g_heff_2ecompile_2eimperative_2edeclBefore_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2edeclBefore_24dps_clo;
V g_heff_2ecompile_2eimperative_2egenOf(V);
V g_heff_2ecompile_2eimperative_2egenOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2egenOf_clo;
V g_heff_2ecompile_2eimperative_2eisRel(V);
V g_heff_2ecompile_2eimperative_2eisRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eisRel_clo;
V g_heff_2ecompile_2eimperative_2eisRelCall(V);
V g_heff_2ecompile_2eimperative_2eisRelCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eisRelCall_clo;
V g_heff_2ecompile_2eimperative_2eisSimple(V);
V g_heff_2ecompile_2eimperative_2eisSimple_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eisSimple_clo;
V g_heff_2ecompile_2eimperative_2eopOf(V, V);
V g_heff_2ecompile_2eimperative_2eopOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eopOf_clo;
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(V, V);
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_clo;
V g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233(V, V);
V g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233_clo;
V g_heff_2ecompile_2eimperative_2epartsTl(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_clo;
V g_heff_2ecompile_2eimperative_2epartsVal(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_clo;
V g_heff_2ecompile_2eimperative_2epk_get(void);
V g_heff_2ecompile_2eimperative_2epredAny(V, V);
V g_heff_2ecompile_2eimperative_2epredAny_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epredAny_clo;
V g_heff_2ecompile_2eimperative_2epredLets(V, V);
V g_heff_2ecompile_2eimperative_2epredLets_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epredLets_clo;
V g_heff_2ecompile_2eimperative_2epredValue(V, V);
V g_heff_2ecompile_2eimperative_2epredValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epredValue_clo;
V g_heff_2ecompile_2eimperative_2erelPrims_get(void);
V g_heff_2ecompile_2eimperative_2esimpleOf(V, V);
V g_heff_2ecompile_2eimperative_2esimpleOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2esimpleOf_clo;
HeffT2 g_heff_2ecompile_2eimperative_2esinkTest_24cpr(V, V, V);
V g_heff_2ecompile_2eimperative_2etailOf(V, V, V);
V g_heff_2ecompile_2eimperative_2etailOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etailOf_clo;
V g_heff_2ecompile_2eimperative_2etoDest(V, V, V);
V g_heff_2ecompile_2eimperative_2etoDest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etoDest_clo;
V g_heff_2ecompile_2eimperative_2eusedOnceNext(V, V, V);
V g_heff_2ecompile_2eimperative_2eusedOnceNext_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eusedOnceNext_clo;
V g_heff_2ecompile_2eimperative_2evalNamesTop(V, V);
V g_heff_2ecompile_2eimperative_2evalNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2evalNamesTop_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2efailing_get(void);
HeffT2 g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(V);
V g_list_2eany_24s930586707x1164893977(V, V);
V g_list_2eany_24s930586707x1164893977_entry(V self, V *a);
extern Clo g_list_2eany_24s930586707x1164893977_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f2064224154x1075431823(V, V, V, V);
V g_list_2efoldl_24f2064224154x1075431823_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2064224154x1075431823_clo;
V g_list_2efoldl_24f613246640x472569916(V, V, V, V);
V g_list_2efoldl_24f613246640x472569916_entry(V self, V *a);
extern Clo g_list_2efoldl_24f613246640x472569916_clo;
V g_list_2efoldl_24s1318914558x1386196507(V, V);
V g_list_2efoldl_24s1318914558x1386196507_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1318914558x1386196507_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1735038056x329845490(V, V);
V g_list_2efoldl_24s1735038056x329845490_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1735038056x329845490_clo;
V g_list_2efoldl_24s2003609603x1707519208(V, V);
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2003609603x1707519208_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2ecompile_2eimperative_2eallL_24s2034742406x913054912_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eallL_24s2034742406x913054912_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2eallL_24s2034742406x913054912(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      v_t_245 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2ecompile_2eimperative_2eisSimple(a_0)); heff_drop(v_t_245); r_; });
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_246);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimperative_2eallL_24s2034742406x913054912_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2eallL_24s2034742406x913054912(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2eisRel_str0, 6, "wordEq");
HEFF_LIT(g_heff_2ecompile_2eimperative_2eisRel_str1, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2eimperative_2eisRel_str2, 6, "wordLe");
HEFF_LIT(g_heff_2ecompile_2eimperative_2eisRel_str3, 6, "wordEq");
HEFF_LIT(g_heff_2ecompile_2eimperative_2eisRel_str4, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2eimperative_2eisRel_str5, 6, "wordLe");
Clo g_heff_2ecompile_2eimperative_2eisRel_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eisRel_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2eisRel(V v_p_240) {
top: ;
  V v_t_241 = ({ V a_0 = v_p_240; V b_1 = heff_dup(g_heff_2ecompile_2eimperative_2erelPrims_get()); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(b_1); r_; });
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_241);
    HeffT2 v_t_242 = (g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(v_p_240));
    {
      V v_field_244 = v_t_242.f[1];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_x_246 = v_field_244;
        V v_t_247 = heff_get_n(v_x_246, 1, 2);
        V v_t_248;
        switch (heff_tag_of(v_t_247)) {
        case TAG_OpAdd: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_OpSub: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_OpMul: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_OpDiv: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_OpRem: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_OpEq: {
          v_t_248 = NTAG(TAG_True);
          break;
        }
        case TAG_OpLt: {
          v_t_248 = NTAG(TAG_True);
          break;
        }
        case TAG_OpLe: {
          v_t_248 = NTAG(TAG_True);
          break;
        }
        case TAG_OpAnd: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_OpOr: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_OpXor: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_OpShl: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_OpShr: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_OpShow: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_OpFromInt: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_OpToInt: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_OpSqrt: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_OpFromFloat: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_OpToFloat: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_OpFloor: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_247);
        }
        V v_ret_24bool = heff_bool(((heff_dup(v_t_248) == NTAG(TAG_True)) || (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eimperative_2eisRel_str0), 2) || (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eimperative_2eisRel_str1), 2) || heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eimperative_2eisRel_str2), 2)))));
        heff_drop(v_t_248);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_244);
        V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eimperative_2eisRel_str3), 2) || (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eimperative_2eisRel_str4), 2) || heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eimperative_2eisRel_str5), 2))));
        return v_ret_24bool;
      }
    }
  }
}
V g_heff_2ecompile_2eimperative_2eisRel_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2eisRel(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2eimperative_2earmNamed_24cpr(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t2_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      if (heff_strEq_c_lent(v_t2_244, v_t_240, 1)) {
        switch (heff_tag_of(v_vs_245)) {
        case TAG_Nil: {
          heff_drop(v_rest_243);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_b_246}});
        }
        case TAG_Cons: {
          heff_take_n(v_vs_245, 0ULL, 2);
          heff_drop(v_b_246);
          V t_0 = v_t_240;
          V t_1 = v_rest_243;
          v_t_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return ((HeffT2){{heff_nomatch(v_vs_245)}});
        }
      } else {
        heff_drop(v_vs_245);
        heff_drop(v_b_246);
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2econdShaped_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2econdShaped_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eimperative_2econdShaped_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2econdShaped_str3, 5, "False");
Clo g_heff_2ecompile_2eimperative_2econdShaped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2econdShaped_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2econdShaped(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_b_249 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 4ULL, 3);
    V t_0 = v_b_249;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_t_2416 = heff_field(v_e_240, 0);
    V v_e2_2417 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 3);
    switch (heff_tag_of(v_e2_2417)) {
    case TAG_Nil: {
      if (heff_strEq_c_lent(v_t_2416, ((V)&g_heff_2ecompile_2eimperative_2econdShaped_str0), 2)) {
        heff_drop(v_t_2416);
        return NTAG(TAG_True);
      } else {
        return heff_strEq(v_t_2416, ((V)&g_heff_2ecompile_2eimperative_2econdShaped_str1));
      }
    }
    case TAG_Cons: {
      heff_take_n(v_e2_2417, 0ULL, 2);
      heff_drop(v_t_2416);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e2_2417);
    }
  }
  case TAG_EMatch: {
    V v_arms_2423 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 2ULL, 2);
    V v_t_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2423));
    if (heff_intEq_c(v_t_2424, MK_INT(2LL))) {
      HeffT2 v_t_2426 = ({ V b_0 = ((V)&g_heff_2ecompile_2eimperative_2econdShaped_str2); V a_1 = heff_dup(v_arms_2423); HeffT2 r_ = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2428 = v_t_2426.f[1];
        int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
        if ((v_tag_2427 == ((int64_t)0ULL))) {
          V v_t_2430 = v_field_2428;
          HeffT2 v_t_2431 = ({ V b_0 = ((V)&g_heff_2ecompile_2eimperative_2econdShaped_str3); V a_1 = v_arms_2423; HeffT2 r_ = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
          {
            V v_field_2433 = v_t_2431.f[1];
            int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
            if ((v_tag_2432 == ((int64_t)0ULL))) {
              V v_f_2435 = v_field_2433;
              V v_t_2436 = (g_heff_2ecompile_2eimperative_2econdShaped(v_t_2430));
              if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
                heff_drop(v_t_2436);
                V t_0 = v_f_2435;
                v_e_240 = t_0;
                goto top;
              } else {
                heff_drop(v_f_2435);
                heff_drop(v_t_2436);
                return NTAG(TAG_False);
              }
            } else {
              heff_drop(v_t_2430);
              heff_drop(v_field_2433);
              return NTAG(TAG_False);
            }
          }
        } else {
          heff_drop(v_arms_2423);
          heff_drop(v_field_2428);
          return NTAG(TAG_False);
        }
      }
    } else {
      heff_drop(v_arms_2423);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2438 = heff_field(v_e_240, 0);
    V v_e2_2439 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    switch (heff_tag_of(v_e2_2439)) {
    case TAG_Nil: {
      heff_drop(v_p_2438);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_e22_2441 = heff_field(v_e2_2439, 1);
      heff_take_n(v_e2_2439, 2ULL, 2);
      switch (heff_tag_of(v_e22_2441)) {
      case TAG_Nil: {
        heff_drop(v_p_2438);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_e222_2443 = heff_field(v_e22_2441, 1);
        heff_take_n(v_e22_2441, 2ULL, 2);
        switch (heff_tag_of(v_e222_2443)) {
        case TAG_Nil: {
          return ({ V a_0 = v_p_2438; V r_ = (g_heff_2ecompile_2eimperative_2eisRel(a_0)); heff_drop(v_p_2438); r_; });
        }
        case TAG_Cons: {
          heff_take_n(v_e222_2443, 0ULL, 2);
          heff_drop(v_p_2438);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_e222_2443);
        }
      }
      default: return heff_nomatch(v_e22_2441);
      }
    }
    default: return heff_nomatch(v_e2_2439);
    }
  }
  case TAG_ECall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eimperative_2econdShaped_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2econdShaped(a[0]);
}
Clo g_heff_2ecompile_2eimperative_2eisRelCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eisRelCall_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2eisRelCall(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2422 = heff_field(v_e_240, 0);
    V v_e2_2423 = heff_field(v_e_240, 1);
    switch (heff_tag_of(v_e2_2423)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_e22_2425 = heff_field(v_e2_2423, 1);
      switch (heff_tag_of(v_e22_2425)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_e222_2427 = heff_field(v_e22_2425, 1);
        switch (heff_tag_of(v_e222_2427)) {
        case TAG_Nil: {
          HEFF_LAST return g_heff_2ecompile_2eimperative_2eisRel(v_p_2422);
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_e222_2427);
        }
      }
      default: return heff_nomatch(v_e22_2425);
      }
    }
    default: return heff_nomatch(v_e2_2423);
    }
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eimperative_2eisRelCall_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2eisRelCall(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eimperative_2econdIf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2econdIf_24dps_entry, 4, 0};

V g_heff_2ecompile_2eimperative_2econdIf_24dps(V v_x1_240, V v_t_241, V v_e_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PTrue: {
    heff_drop(v_e_242);
    return heff_setField(v_d_243, MK_INT(2LL), v_t_241);
  }
  case TAG_PFalse: {
    heff_drop(v_t_241);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_PRel: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PFalse: {
        return heff_setField(v_d_243, MK_INT(2LL), v_x1_240);
      }
      case TAG_PRel: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PBool: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PNot: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PIf: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PLet: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PNot, 1, (V[]){v_x1_240}));
      }
      case TAG_PFalse: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PRel: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PBool: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PNot: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PIf: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PLet: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PRel: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
    }
    case TAG_PBool: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
    }
    case TAG_PNot: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
    }
    case TAG_PIf: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
    }
    case TAG_PLet: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  case TAG_PBool: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PFalse: {
        return heff_setField(v_d_243, MK_INT(2LL), v_x1_240);
      }
      case TAG_PRel: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PBool: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PNot: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PIf: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PLet: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PNot, 1, (V[]){v_x1_240}));
      }
      case TAG_PFalse: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PRel: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PBool: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PNot: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PIf: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PLet: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PRel: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
    }
    case TAG_PBool: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
    }
    case TAG_PNot: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
    }
    case TAG_PIf: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
    }
    case TAG_PLet: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  case TAG_PNot: {
    V v_c_2474 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_c_2474;
    V t_1 = v_e_242;
    V t_2 = v_t_241;
    V t_3 = v_d_243;
    v_x1_240 = t_0;
    v_t_241 = t_1;
    v_e_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_PIf: {
    V v_a_2475 = heff_field(v_x1_240, 0);
    V v_b_2476 = heff_field(v_x1_240, 1);
    V v_c_2477 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24PIf = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_t_2489;
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      v_t_2489 = NTAG(TAG_True);
      break;
    }
    case TAG_PFalse: {
      v_t_2489 = NTAG(TAG_True);
      break;
    }
    case TAG_PRel: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_PBool: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_PNot: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_PIf: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_PLet: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_241);
    }
    if ((heff_dup(v_t_2489) == NTAG(TAG_True))) {
      heff_drop(v_t_2489);
      V v_t_24101;
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        v_t_24101 = NTAG(TAG_True);
        break;
      }
      case TAG_PFalse: {
        v_t_24101 = NTAG(TAG_True);
        break;
      }
      case TAG_PRel: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_PBool: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_PNot: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_PIf: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_PLet: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_242);
      }
      if ((heff_dup(v_t_24101) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_240_24PIf, 3);
        heff_drop(v_t_24101);
        V v_t_24102 = (g_heff_2ecompile_2eimperative_2econdIf(v_b_2476, heff_dup(v_t_241), heff_dup(v_e_242)));
        V v_t_24103 = (g_heff_2ecompile_2eimperative_2econdIf(v_c_2477, v_t_241, v_e_242));
        V t_0 = v_a_2475;
        V t_1 = v_t_24102;
        V t_2 = v_t_24103;
        V t_3 = v_d_243;
        v_x1_240 = t_0;
        v_t_241 = t_1;
        v_e_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        heff_drop(v_t_24101);
        V v_t_24104 = heff_tag_at_n(v_ru_24x1_240_24PIf, TAG_PIf, 3, (V[]){heff_tag_n(TAG_PIf, 3, (V[]){v_a_2475, v_b_2476, v_c_2477}), v_t_241, v_e_242});
        return heff_setField(v_d_243, MK_INT(2LL), v_t_24104);
      }
    } else {
      heff_drop(v_t_2489);
      V v_t_24105 = heff_tag_at_n(v_ru_24x1_240_24PIf, TAG_PIf, 3, (V[]){heff_tag_n(TAG_PIf, 3, (V[]){v_a_2475, v_b_2476, v_c_2477}), v_t_241, v_e_242});
      return heff_setField(v_d_243, MK_INT(2LL), v_t_24105);
    }
  }
  case TAG_PLet: {
    V v_x_24106 = heff_field(v_x1_240, 0);
    V v_o_24107 = heff_field(v_x1_240, 1);
    V v_c_24108 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24PLet = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_cell_24109 = heff_tag_at_n(v_ru_24x1_240_24PLet, TAG_PLet, 3, (V[]){v_x_24106, v_o_24107, heff_hole()});
    V v_u_24110 = heff_setField(v_d_243, MK_INT(2LL), heff_dup(v_cell_24109));
    heff_drop(v_u_24110);
    V t_0 = v_c_24108;
    V t_1 = v_t_241;
    V t_2 = v_e_242;
    V t_3 = v_cell_24109;
    v_x1_240 = t_0;
    v_t_241 = t_1;
    v_e_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eimperative_2econdIf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2econdIf_24dps(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2epredValue_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2epredValue_str1, 1, "c");
V g_heff_2ecompile_2eimperative_2epredValue_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2epredValue_lam1(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2epredValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epredValue_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epredValue(V v_g_240, V v_e_241) {
top: ;
  V v_t_242 = (g_heff_2ecompile_2eimperative_2eisSimple(v_e_241));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2epredValue_lam0, 1, 1, (V[]){v_m_243});
  } else {
    heff_drop(v_t_242);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2epredValue_lam1, 1, 2, (V[]){v_g_240, v_e_241});
  }
}
V g_heff_2ecompile_2eimperative_2epredValue_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epredValue(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2epredValue_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_n_244}));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_n_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_PBool, 1, (V[]){v_x_246})});
    return heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_248, v_n_247});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ecompile_2eimperative_2epredValue_lam1(V self, V *args) {
  V v_n_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2epredValue_str0), heff_intShow(heff_dup(v_n_249)));
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2epredValue_str1), v_t_2410);
  V v_m_2412 = heff_tr(heff_call(heff_get_n(v_g_240, 3, 8), 2, (V[]){heff_dup(v_t_2411), v_e_241}));
  V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){heff_intAdd(v_n_249, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_n_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = heff_tag_n(TAG_PBool, 1, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){v_t_2411})});
    V v_x_2417 = (g_heff_2ecompile_2eimperative_2epredLets(v_x_2414, v_t_2416));
    return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_x_2417, v_n_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2epredAny_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2epredAny_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eimperative_2epredAny_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2epredAny_str3, 5, "False");
V g_heff_2ecompile_2eimperative_2epredAny_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2epredAny_lam1(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epredAny_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epredAny_lam1, 1, 0};
V g_heff_2ecompile_2eimperative_2epredAny_lam2(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epredAny_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epredAny_lam2, 1, 0};
V g_heff_2ecompile_2eimperative_2epredAny_lam3(V self, V *args);
V g_heff_2ecompile_2eimperative_2epredAny_lam4(V self, V *args);
V g_heff_2ecompile_2eimperative_2epredAny_lam5(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2epredAny_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epredAny_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epredAny(V v_g_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_ELet: {
    V v_x_248 = heff_field(v_e_241, 0);
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    HeffT2 v_t_2411 = (g_heff_2ecompile_2eimperative_2esinkTest_24cpr(v_x_248, heff_dup(v_a_249), heff_dup(v_b_2410)));
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        heff_drop(v_x_248);
        heff_drop(v_a_249);
        heff_drop(v_b_2410);
        V v_e2_2415 = v_field_2413;
        return heff_tail(heff_get_n(v_g_240, 7, 8), 1, (V[]){v_e2_2415});
      } else {
        heff_drop(v_field_2413);
        V v_m_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 3)), 2, (V[]){v_x_248, v_a_249}));
        return heff_clo_n(g_heff_2ecompile_2eimperative_2epredAny_lam0, 1, 3, (V[]){v_m_2416, v_g_240, v_b_2410});
      }
    }
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_ETag: {
    V v_t_2433 = heff_dup(heff_field(v_e_241, 0));
    V v_e2_27_2434 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e2_27_2434)) {
    case TAG_Nil: {
      heff_drop_rec(v_g_240, 8);
      heff_drop_tag(v_e_241, 3);
      if (heff_strEq_c_lent(v_t_2433, ((V)&g_heff_2ecompile_2eimperative_2epredAny_str0), 2)) {
        heff_drop(v_t_2433);
        return ((V)&g_heff_2ecompile_2eimperative_2epredAny_lam1_clo);
      } else {
        if (heff_strEq_c_lent(v_t_2433, ((V)&g_heff_2ecompile_2eimperative_2epredAny_str1), 2)) {
          heff_drop(v_t_2433);
          return ((V)&g_heff_2ecompile_2eimperative_2epredAny_lam2_clo);
        } else {
          return heff_clo_n(g_heff_2ecompile_2eimperative_2epredAny_lam3, 1, 1, (V[]){v_t_2433});
        }
      }
    }
    case TAG_Cons: {
      heff_take_n(v_e2_27_2434, 0ULL, 2);
      heff_drop(v_t_2433);
      HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
    }
    default: return heff_nomatch(v_e2_27_2434);
    }
  }
  case TAG_EMatch: {
    V v_s_2447 = heff_dup(heff_field(v_e_241, 0));
    V v_arms_2448 = heff_dup(heff_field(v_e_241, 1));
    V v_t_2449 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2448));
    V v_it_2461;
    if (heff_intEq_c(v_t_2449, MK_INT(2LL))) {
      HeffT2 v_t_2451 = ({ V b_0 = ((V)&g_heff_2ecompile_2eimperative_2epredAny_str2); V a_1 = heff_dup(v_arms_2448); HeffT2 r_ = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2453 = v_t_2451.f[1];
        int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
        if ((v_tag_2452 == ((int64_t)0ULL))) {
          V v_t_2455 = v_field_2453;
          HeffT2 v_t_2456 = ({ V b_0 = ((V)&g_heff_2ecompile_2eimperative_2epredAny_str3); V a_1 = v_arms_2448; HeffT2 r_ = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
          {
            V v_field_2458 = v_t_2456.f[1];
            int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
            if ((v_tag_2457 == ((int64_t)0ULL))) {
              V v_f_2460 = v_field_2458;
              v_it_2461 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2455, v_f_2460})});
            } else {
              heff_drop(v_t_2455);
              heff_drop(v_field_2458);
              v_it_2461 = NTAG(TAG_Nothing);
            }
          }
        } else {
          heff_drop(v_arms_2448);
          heff_drop(v_field_2453);
          v_it_2461 = NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop(v_arms_2448);
      v_it_2461 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_it_2461)) {
    case TAG_Nothing: {
      heff_drop(v_s_2447);
      HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
    }
    case TAG_Just: {
      V v_it1_2462 = heff_field(v_it_2461, 0);
      heff_take_n(v_it_2461, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      switch (heff_tag_of(v_it1_2462)) {
      case TAG_MkPair: {
        V v_t_2463 = heff_field(v_it1_2462, 0);
        V v_f_2464 = heff_field(v_it1_2462, 1);
        heff_take_n(v_it1_2462, 3ULL, 2);
        V v_m_2465 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){v_s_2447}));
        return heff_clo_n(g_heff_2ecompile_2eimperative_2epredAny_lam4, 1, 4, (V[]){v_m_2465, v_g_240, v_t_2463, v_f_2464});
      }
      default: return heff_nomatch(v_it1_2462);
      }
    }
    default: return heff_nomatch(v_it_2461);
    }
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EPrimCall: {
    V v_p_2484 = heff_dup(heff_field(v_e_241, 0));
    V v_e2_27_2485 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e2_27_2485)) {
    case TAG_Nil: {
      heff_drop(v_p_2484);
      HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
    }
    case TAG_Cons: {
      V v_a_2486 = heff_field(v_e2_27_2485, 0);
      V v_e2_272_2487 = heff_field(v_e2_27_2485, 1);
      heff_take_n(v_e2_27_2485, 3ULL, 2);
      switch (heff_tag_of(v_e2_272_2487)) {
      case TAG_Nil: {
        heff_drop(v_p_2484);
        heff_drop(v_a_2486);
        HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
      }
      case TAG_Cons: {
        V v_b_2488 = heff_field(v_e2_272_2487, 0);
        V v_e2_2722_2489 = heff_field(v_e2_272_2487, 1);
        heff_take_n(v_e2_272_2487, 3ULL, 2);
        switch (heff_tag_of(v_e2_2722_2489)) {
        case TAG_Nil: {
          V v_t_2490 = (g_heff_2ecompile_2eimperative_2eisRel(v_p_2484));
          if ((heff_dup(v_t_2490) == NTAG(TAG_True))) {
            heff_drop_tag(v_e_241, 2);
            heff_drop(v_t_2490);
            V v_m_2491 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 5)), 1, (V[]){v_a_2486}));
            return heff_clo_n(g_heff_2ecompile_2eimperative_2epredAny_lam5, 1, 4, (V[]){v_m_2491, v_g_240, v_b_2488, v_p_2484});
          } else {
            heff_drop(v_p_2484);
            heff_drop(v_a_2486);
            heff_drop(v_b_2488);
            heff_drop(v_t_2490);
            HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_e2_2722_2489, 0ULL, 2);
          heff_drop(v_p_2484);
          heff_drop(v_a_2486);
          heff_drop(v_b_2488);
          HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
        }
        default: return heff_nomatch(v_e2_2722_2489);
        }
      }
      default: return heff_nomatch(v_e2_272_2487);
      }
    }
    default: return heff_nomatch(v_e2_27_2485);
    }
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eimperative_2epredAny_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epredAny(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2epredAny_lam0(V self, V *args) {
  V v_n_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_b_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_n_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_n_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_m_2421 = heff_tr(heff_call(heff_get_n(v_g_240, 7, 8), 1, (V[]){v_b_2410}));
    V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_n_2420}));
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_MkPair: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_n_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      V v_x_2426;
      switch (heff_tag_of(v_x_2423)) {
      case TAG_Nothing: {
        heff_drop(v_x_2419);
        v_x_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_q_2425 = heff_field(v_x_2423, 0);
        heff_take_n(v_x_2423, 1ULL, 1);
        v_x_2426 = (g_heff_2ecompile_2eimperative_2epredLets(v_x_2419, v_q_2425));
        break;
      }
      default: heff_nomatch(v_x_2423);
      }
      return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_x_2426, v_n_2424});
    }
    default: return heff_nomatch(v_x2_2422);
    }
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2eimperative_2epredAny_lam1(V self, V *args) {
  V v_n_2437 = args[0];
  V v_t_2438 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_PTrue)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2438, v_n_2437});
}
V g_heff_2ecompile_2eimperative_2epredAny_lam2(V self, V *args) {
  V v_n_2440 = args[0];
  V v_t_2441 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_PFalse)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2441, v_n_2440});
}
V g_heff_2ecompile_2eimperative_2epredAny_lam3(V self, V *args) {
  V v_n_2442 = args[0];
  V v_t_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2443 = heff_tag_n(TAG_STag, 3, (V[]){v_t_2433, NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_2444 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_PBool, 1, (V[]){v_t_2443})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2444, v_n_2442});
}
V g_heff_2ecompile_2eimperative_2epredAny_lam4(V self, V *args) {
  V v_n_2466 = args[0];
  V v_m_2465 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_t_2463 = heff_env(self)[2];
  V v_f_2464 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2467 = heff_tr(heff_call(v_m_2465, 1, (V[]){v_n_2466}));
  switch (heff_tag_of(v_x2_2467)) {
  case TAG_MkPair: {
    V v_x_2468 = heff_field(v_x2_2467, 0);
    V v_n_2469 = heff_field(v_x2_2467, 1);
    V v_ru_24x2_2467_24MkPair = heff_take_reuse_n(v_x2_2467, 3ULL, 2);
    V v_m_2470 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){v_t_2463}));
    V v_x2_2471 = heff_tr(heff_call(v_m_2470, 1, (V[]){v_n_2469}));
    switch (heff_tag_of(v_x2_2471)) {
    case TAG_MkPair: {
      V v_x_2472 = heff_field(v_x2_2471, 0);
      V v_n_2473 = heff_field(v_x2_2471, 1);
      heff_take_n(v_x2_2471, 3ULL, 2);
      V v_m_2474 = heff_tr(heff_call(heff_get_n(v_g_240, 7, 8), 1, (V[]){v_f_2464}));
      V v_x2_2475 = heff_tr(heff_call(v_m_2474, 1, (V[]){v_n_2473}));
      switch (heff_tag_of(v_x2_2475)) {
      case TAG_MkPair: {
        V v_x_2476 = heff_field(v_x2_2475, 0);
        V v_n_2477 = heff_field(v_x2_2475, 1);
        heff_take_n(v_x2_2475, 3ULL, 2);
        V v_x_2482;
        switch (heff_tag_of(v_x_2468)) {
        case TAG_Nothing: {
          heff_drop(v_x_2472);
          heff_drop(v_x_2476);
          v_x_2482 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_cs_2478 = heff_field(v_x_2468, 0);
          V v_ru_24x_2468_24Just = heff_take_reuse_n(v_x_2468, 1ULL, 1);
          switch (heff_tag_of(v_x_2472)) {
          case TAG_Nothing: {
            heff_drop(v_x_2476);
            heff_drop(v_cs_2478);
            heff_drop_cell(v_ru_24x_2468_24Just, 1);
            v_x_2482 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_ct_2479 = heff_field(v_x_2472, 0);
            heff_take_n(v_x_2472, 1ULL, 1);
            switch (heff_tag_of(v_x_2476)) {
            case TAG_Nothing: {
              heff_drop(v_cs_2478);
              heff_drop_cell(v_ru_24x_2468_24Just, 1);
              heff_drop(v_ct_2479);
              v_x_2482 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_cf_2480 = heff_field(v_x_2476, 0);
              heff_take_n(v_x_2476, 1ULL, 1);
              V v_t_2481 = (g_heff_2ecompile_2eimperative_2econdIf(v_cs_2478, v_ct_2479, v_cf_2480));
              v_x_2482 = heff_tag_at_n(v_ru_24x_2468_24Just, TAG_Just, 1, (V[]){v_t_2481});
              break;
            }
            default: heff_nomatch(v_x_2476);
            }
            break;
          }
          default: heff_nomatch(v_x_2472);
          }
          break;
        }
        default: heff_nomatch(v_x_2468);
        }
        return heff_tag_at_n(v_ru_24x2_2467_24MkPair, TAG_MkPair, 2, (V[]){v_x_2482, v_n_2477});
      }
      default: return heff_nomatch(v_x2_2475);
      }
    }
    default: return heff_nomatch(v_x2_2471);
    }
  }
  default: return heff_nomatch(v_x2_2467);
  }
}
V g_heff_2ecompile_2eimperative_2epredAny_lam5(V self, V *args) {
  V v_n_2492 = args[0];
  V v_m_2491 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_b_2488 = heff_env(self)[2];
  V v_p_2484 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2493 = heff_tr(heff_call(v_m_2491, 1, (V[]){v_n_2492}));
  switch (heff_tag_of(v_x2_2493)) {
  case TAG_MkPair: {
    V v_x_2494 = heff_field(v_x2_2493, 0);
    V v_n_2495 = heff_field(v_x2_2493, 1);
    V v_ru_24x2_2493_24MkPair = heff_take_reuse_n(v_x2_2493, 3ULL, 2);
    V v_m_2496 = heff_tr(heff_call(heff_get_n(v_g_240, 5, 8), 1, (V[]){v_b_2488}));
    V v_x2_2497 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_n_2495}));
    switch (heff_tag_of(v_x2_2497)) {
    case TAG_MkPair: {
      V v_x_2498 = heff_field(v_x2_2497, 0);
      V v_n_2499 = heff_field(v_x2_2497, 1);
      heff_take_n(v_x2_2497, 3ULL, 2);
      V v_t_24102;
      switch (heff_tag_of(v_x_2494)) {
      case TAG_MkPair: {
        V v_x_24100 = heff_dup(heff_field(v_x_2494, 0));
        v_t_24102 = v_x_24100;
        break;
      }
      default: heff_nomatch(v_x_2494);
      }
      V v_t_24105;
      switch (heff_tag_of(v_x_2498)) {
      case TAG_MkPair: {
        V v_x_24103 = heff_dup(heff_field(v_x_2498, 0));
        v_t_24105 = v_x_24103;
        break;
      }
      default: heff_nomatch(v_x_2498);
      }
      V v_t_24106 = (g_prelude_2e_2b_2b(v_t_24102, v_t_24105));
      V v_t_24109;
      switch (heff_tag_of(v_x_2494)) {
      case TAG_MkPair: {
        V v_y_24108 = heff_field(v_x_2494, 1);
        heff_take_n(v_x_2494, 2ULL, 2);
        v_t_24109 = v_y_24108;
        break;
      }
      default: heff_nomatch(v_x_2494);
      }
      V v_t_24112;
      switch (heff_tag_of(v_x_2498)) {
      case TAG_MkPair: {
        V v_y_24111 = heff_field(v_x_2498, 1);
        heff_take_n(v_x_2498, 2ULL, 2);
        v_t_24112 = v_y_24111;
        break;
      }
      default: heff_nomatch(v_x_2498);
      }
      V v_x_24113 = (g_heff_2ecompile_2eimperative_2epredLets(v_t_24106, heff_tag_n(TAG_PRel, 3, (V[]){v_p_2484, v_t_24109, v_t_24112})));
      return heff_tag_at_n(v_ru_24x2_2493_24MkPair, TAG_MkPair, 2, (V[]){v_x_24113, v_n_2499});
    }
    default: return heff_nomatch(v_x2_2497);
    }
  }
  default: return heff_nomatch(v_x2_2493);
  }
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2eatomOf_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2eatomOf_str1, 1, "t");
V g_heff_2ecompile_2eimperative_2eatomOf_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2eatomOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2eatomOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eatomOf_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2eatomOf(V v_g_240, V v_e_241) {
top: ;
  V v_t_242 = (g_heff_2ecompile_2eimperative_2eisSimple(v_e_241));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eatomOf_lam0, 1, 1, (V[]){v_m_243});
  } else {
    heff_drop(v_t_242);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eatomOf_lam1, 1, 2, (V[]){v_g_240, v_e_241});
  }
}
V g_heff_2ecompile_2eimperative_2eatomOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eatomOf(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2eatomOf_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_n_244}));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_n_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_x_246});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_n_247});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ecompile_2eimperative_2eatomOf_lam1(V self, V *args) {
  V v_n_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2eatomOf_str0), heff_intShow(heff_dup(v_n_249)));
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2eatomOf_str1), v_t_2410);
  V v_m_2412 = heff_tr(heff_call(heff_get_n(v_g_240, 3, 8), 2, (V[]){heff_dup(v_t_2411), v_e_241}));
  V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){heff_intAdd(v_n_249, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_n_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_x_2414, heff_tag_n(TAG_SVar, 1, (V[]){v_t_2411})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, v_n_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2eimperative_2eatomsOf_lam0(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2eatomsOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eatomsOf_lam0, 1, 0};
V g_heff_2ecompile_2eimperative_2eatomsOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2eatomsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eatomsOf_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2eatomsOf(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2eatomsOf_lam0_clo);
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x2_241, 0);
    V v_es_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 5)), 1, (V[]){v_e_244}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eatomsOf_lam1, 1, 3, (V[]){v_m_246, v_g_240, v_es_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2eatomsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eatomsOf(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2eatomsOf_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_n_242});
}
V g_heff_2ecompile_2eimperative_2eatomsOf_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_es_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_m_2411 = (g_heff_2ecompile_2eimperative_2eatomsOf(v_g_240, v_es_245));
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2410}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_n_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_dup(heff_field(v_x_249, 0));
        v_t_2417 = v_x_2415;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2420;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_MkPair: {
        V v_x_2418 = heff_dup(heff_field(v_x_2413, 0));
        v_t_2420 = v_x_2418;
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      V v_t_2421 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2420));
      V v_t_2424;
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_y_2423 = heff_field(v_x_249, 1);
        heff_take_n(v_x_249, 2ULL, 2);
        v_t_2424 = v_y_2423;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2427;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_MkPair: {
        V v_y_2426 = heff_field(v_x_2413, 1);
        heff_take_n(v_x_2413, 2ULL, 2);
        v_t_2427 = v_y_2426;
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      V v_x_2428 = heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, v_t_2427})});
      return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){v_x_2428, v_n_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam3(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam4(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam5(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam6(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam7(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam8(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam9(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam10(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam11(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam12(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam13(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam14(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam15(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam16(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam17(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam18(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2eopOf_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eopOf_lam18, 1, 0};
V g_heff_2ecompile_2eimperative_2eopOf_lam19(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2eopOf_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eopOf_lam19, 1, 0};
Clo g_heff_2ecompile_2eimperative_2eopOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eopOf_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2eopOf(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam0, 1, 1, (V[]){v_m_243});
  }
  case TAG_EGlobal: {
    V v_m_2410 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam1, 1, 1, (V[]){v_m_2410});
  }
  case TAG_ELam: {
    V v_m_2418 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam2, 1, 1, (V[]){v_m_2418});
  }
  case TAG_EApp: {
    V v_f_2424 = heff_field(v_x2_241, 0);
    V v_as_2425 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_2426 = (g_heff_2ecompile_2eimperative_2eatomsOf(v_g_240, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_f_2424, v_as_2425})));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam3, 1, 1, (V[]){v_m_2426});
  }
  case TAG_ELet: {
    V v_m_2440 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam4, 1, 1, (V[]){v_m_2440});
  }
  case TAG_ERecord: {
    V v_fs_2446 = heff_field(v_x2_241, 0);
    V v_ts_2447 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2448 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2446)));
    V v_m_2449 = (g_heff_2ecompile_2eimperative_2eatomsOf(v_g_240, v_t_2448));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam5, 1, 3, (V[]){v_m_2449, v_fs_2446, v_ts_2447});
  }
  case TAG_EProj: {
    V v_e_2459 = heff_field(v_x2_241, 0);
    V v_l_2460 = heff_field(v_x2_241, 1);
    V v_sh_2461 = heff_field(v_x2_241, 2);
    V v_t_2462 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2459, NTAG(TAG_Nil)});
    V v_m_2464 = (g_heff_2ecompile_2eimperative_2eatomsOf(v_g_240, v_t_2463));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam6, 1, 4, (V[]){v_m_2464, v_l_2460, v_sh_2461, v_t_2462});
  }
  case TAG_ETag: {
    V v_t_2475 = heff_field(v_x2_241, 0);
    V v_as_2476 = heff_field(v_x2_241, 1);
    V v_ts_2477 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2478 = (g_heff_2ecompile_2eimperative_2eatomsOf(v_g_240, v_as_2476));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam7, 1, 3, (V[]){v_m_2478, v_t_2475, v_ts_2477});
  }
  case TAG_EMatch: {
    V v_m_2489 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam8, 1, 1, (V[]){v_m_2489});
  }
  case TAG_EPrim: {
    V v_m_2496 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam9, 1, 1, (V[]){v_m_2496});
  }
  case TAG_EPrimCall: {
    V v_p_24102 = heff_field(v_x2_241, 0);
    V v_as_24103 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24104 = (g_heff_2ecompile_2eimperative_2eatomsOf(v_g_240, v_as_24103));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam10, 1, 2, (V[]){v_m_24104, v_p_24102});
  }
  case TAG_ECall: {
    V v_k_24114 = heff_field(v_x2_241, 0);
    V v_as_24115 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24116 = (g_heff_2ecompile_2eimperative_2eatomsOf(v_g_240, v_as_24115));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam11, 1, 2, (V[]){v_m_24116, v_k_24114});
  }
  case TAG_EInt: {
    V v_m_24125 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam12, 1, 1, (V[]){v_m_24125});
  }
  case TAG_EFloat: {
    V v_m_24132 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam13, 1, 1, (V[]){v_m_24132});
  }
  case TAG_EStr: {
    V v_m_24139 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam14, 1, 1, (V[]){v_m_24139});
  }
  case TAG_EBytes: {
    V v_m_24146 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam15, 1, 1, (V[]){v_m_24146});
  }
  case TAG_EFixed: {
    V v_m_24154 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam16, 1, 1, (V[]){v_m_24154});
  }
  case TAG_EFloat32: {
    V v_m_24161 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam17, 1, 1, (V[]){v_m_24161});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2eopOf_lam18_clo);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2eopOf_lam19_clo);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eopOf(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2eopOf_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_n_244}));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_n_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_246})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_n_247});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam1(V self, V *args) {
  V v_n_2411 = args[0];
  V v_m_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2412 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_2411}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_n_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    V v_t_2415 = heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_2413})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_n_2414});
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam2(V self, V *args) {
  V v_n_2419 = args[0];
  V v_m_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2420 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_n_2419}));
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_MkPair: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_n_2422 = heff_field(v_x2_2420, 1);
    V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
    V v_t_2423 = heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_2421})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_n_2422});
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam3(V self, V *args) {
  V v_n_2427 = args[0];
  V v_m_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2428 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_n_2427}));
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_MkPair: {
    V v_x_2429 = heff_field(v_x2_2428, 0);
    V v_n_2430 = heff_field(v_x2_2428, 1);
    V v_ru_24x2_2428_24MkPair = heff_take_reuse_n(v_x2_2428, 3ULL, 2);
    V v_t_2436;
    switch (heff_tag_of(v_x_2429)) {
    case TAG_MkPair: {
      V v_ss_2431 = heff_field(v_x_2429, 0);
      V v_vs_2432 = heff_field(v_x_2429, 1);
      V v_ru_24x_2429_24MkPair = heff_take_reuse_n(v_x_2429, 3ULL, 2);
      V v_t_2435;
      switch (heff_tag_of(v_vs_2432)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
        v_t_2435 = NTAG(TAG_OAbandon);
        break;
      }
      case TAG_Cons: {
        V v_fv_2433 = heff_field(v_vs_2432, 0);
        V v_avs_2434 = heff_field(v_vs_2432, 1);
        heff_take_n(v_vs_2432, 3ULL, 2);
        v_t_2435 = heff_tag_at_n(v_ru_24x_2429_24MkPair, TAG_OApply, 2, (V[]){v_fv_2433, v_avs_2434});
        break;
      }
      default: heff_nomatch(v_vs_2432);
      }
      v_t_2436 = heff_tag_at_n(v_ru_24x2_2428_24MkPair, TAG_MkPair, 2, (V[]){v_ss_2431, v_t_2435});
      break;
    }
    default: heff_nomatch(v_x_2429);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2436, v_n_2430});
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam4(V self, V *args) {
  V v_n_2441 = args[0];
  V v_m_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2442 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_n_2441}));
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_MkPair: {
    V v_x_2443 = heff_field(v_x2_2442, 0);
    V v_n_2444 = heff_field(v_x2_2442, 1);
    V v_ru_24x2_2442_24MkPair = heff_take_reuse_n(v_x2_2442, 3ULL, 2);
    V v_t_2445 = heff_tag_at_n(v_ru_24x2_2442_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_2443})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2445, v_n_2444});
  }
  default: return heff_nomatch(v_x2_2442);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam5(V self, V *args) {
  V v_n_2450 = args[0];
  V v_m_2449 = heff_env(self)[0];
  V v_fs_2446 = heff_env(self)[1];
  V v_ts_2447 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2451 = heff_tr(heff_call(v_m_2449, 1, (V[]){v_n_2450}));
  switch (heff_tag_of(v_x2_2451)) {
  case TAG_MkPair: {
    V v_x_2452 = heff_field(v_x2_2451, 0);
    V v_n_2453 = heff_field(v_x2_2451, 1);
    V v_ru_24x2_2451_24MkPair = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
    V v_x_2458;
    switch (heff_tag_of(v_x_2452)) {
    case TAG_MkPair: {
      V v_ss_2454 = heff_field(v_x_2452, 0);
      V v_vs_2455 = heff_field(v_x_2452, 1);
      V v_ru_24x_2452_24MkPair = heff_take_reuse_n(v_x_2452, 3ULL, 2);
      V v_t_2456 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2446, v_vs_2455));
      V v_t_2457 = heff_tag_n(TAG_OSimple, 1, (V[]){heff_tag_at_n(v_ru_24x_2452_24MkPair, TAG_SRec, 2, (V[]){v_t_2456, v_ts_2447})});
      v_x_2458 = heff_tag_at_n(v_ru_24x2_2451_24MkPair, TAG_MkPair, 2, (V[]){v_ss_2454, v_t_2457});
      break;
    }
    default: heff_nomatch(v_x_2452);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2458, v_n_2453});
  }
  default: return heff_nomatch(v_x2_2451);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam6(V self, V *args) {
  V v_n_2465 = args[0];
  V v_m_2464 = heff_env(self)[0];
  V v_l_2460 = heff_env(self)[1];
  V v_sh_2461 = heff_env(self)[2];
  V v_t_2462 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2466 = heff_tr(heff_call(v_m_2464, 1, (V[]){v_n_2465}));
  switch (heff_tag_of(v_x2_2466)) {
  case TAG_MkPair: {
    V v_x_2467 = heff_field(v_x2_2466, 0);
    V v_n_2468 = heff_field(v_x2_2466, 1);
    V v_ru_24x2_2466_24MkPair = heff_take_reuse_n(v_x2_2466, 3ULL, 2);
    V v_t_2474;
    switch (heff_tag_of(v_x_2467)) {
    case TAG_MkPair: {
      V v_ss_2469 = heff_field(v_x_2467, 0);
      V v_vs_2470 = heff_field(v_x_2467, 1);
      heff_take_n(v_x_2467, 3ULL, 2);
      V v_t_2473;
      switch (heff_tag_of(v_vs_2470)) {
      case TAG_Nil: {
        heff_drop(v_l_2460);
        heff_drop(v_sh_2461);
        heff_drop(v_t_2462);
        v_t_2473 = NTAG(TAG_OAbandon);
        break;
      }
      case TAG_Cons: {
        V v_v_2471 = heff_field(v_vs_2470, 0);
        heff_take_n(v_vs_2470, 1ULL, 2);
        v_t_2473 = heff_tag_n(TAG_OSimple, 1, (V[]){heff_tag_n(TAG_SProj, 4, (V[]){v_v_2471, v_l_2460, v_sh_2461, v_t_2462})});
        break;
      }
      default: heff_nomatch(v_vs_2470);
      }
      v_t_2474 = heff_tag_at_n(v_ru_24x2_2466_24MkPair, TAG_MkPair, 2, (V[]){v_ss_2469, v_t_2473});
      break;
    }
    default: heff_nomatch(v_x_2467);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2474, v_n_2468});
  }
  default: return heff_nomatch(v_x2_2466);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam7(V self, V *args) {
  V v_n_2479 = args[0];
  V v_m_2478 = heff_env(self)[0];
  V v_t_2475 = heff_env(self)[1];
  V v_ts_2477 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2480 = heff_tr(heff_call(v_m_2478, 1, (V[]){v_n_2479}));
  switch (heff_tag_of(v_x2_2480)) {
  case TAG_MkPair: {
    V v_x_2481 = heff_field(v_x2_2480, 0);
    V v_n_2482 = heff_field(v_x2_2480, 1);
    V v_ru_24x2_2480_24MkPair = heff_take_reuse_n(v_x2_2480, 3ULL, 2);
    V v_t_2486;
    switch (heff_tag_of(v_x_2481)) {
    case TAG_MkPair: {
      V v_ss_2483 = heff_field(v_x_2481, 0);
      V v_vs_2484 = heff_field(v_x_2481, 1);
      heff_take_n(v_x_2481, 3ULL, 2);
      V v_t_2485 = heff_tag_n(TAG_OSimple, 1, (V[]){heff_tag_n(TAG_STag, 3, (V[]){v_t_2475, v_vs_2484, v_ts_2477})});
      v_t_2486 = heff_tag_at_n(v_ru_24x2_2480_24MkPair, TAG_MkPair, 2, (V[]){v_ss_2483, v_t_2485});
      break;
    }
    default: heff_nomatch(v_x_2481);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2486, v_n_2482});
  }
  default: return heff_nomatch(v_x2_2480);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam8(V self, V *args) {
  V v_n_2490 = args[0];
  V v_m_2489 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2491 = heff_tr(heff_call(v_m_2489, 1, (V[]){v_n_2490}));
  switch (heff_tag_of(v_x2_2491)) {
  case TAG_MkPair: {
    V v_x_2492 = heff_field(v_x2_2491, 0);
    V v_n_2493 = heff_field(v_x2_2491, 1);
    V v_ru_24x2_2491_24MkPair = heff_take_reuse_n(v_x2_2491, 3ULL, 2);
    V v_t_2494 = heff_tag_at_n(v_ru_24x2_2491_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_2492})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2494, v_n_2493});
  }
  default: return heff_nomatch(v_x2_2491);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam9(V self, V *args) {
  V v_n_2497 = args[0];
  V v_m_2496 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2498 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_n_2497}));
  switch (heff_tag_of(v_x2_2498)) {
  case TAG_MkPair: {
    V v_x_2499 = heff_field(v_x2_2498, 0);
    V v_n_24100 = heff_field(v_x2_2498, 1);
    V v_ru_24x2_2498_24MkPair = heff_take_reuse_n(v_x2_2498, 3ULL, 2);
    V v_t_24101 = heff_tag_at_n(v_ru_24x2_2498_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_2499})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24101, v_n_24100});
  }
  default: return heff_nomatch(v_x2_2498);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam10(V self, V *args) {
  V v_n_24105 = args[0];
  V v_m_24104 = heff_env(self)[0];
  V v_p_24102 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24106 = heff_tr(heff_call(v_m_24104, 1, (V[]){v_n_24105}));
  switch (heff_tag_of(v_x2_24106)) {
  case TAG_MkPair: {
    V v_x_24107 = heff_field(v_x2_24106, 0);
    V v_n_24108 = heff_field(v_x2_24106, 1);
    V v_ru_24x2_24106_24MkPair = heff_take_reuse_n(v_x2_24106, 3ULL, 2);
    V v_x_24113;
    switch (heff_tag_of(v_x_24107)) {
    case TAG_MkPair: {
      V v_ss_24109 = heff_field(v_x_24107, 0);
      V v_vs_24110 = heff_field(v_x_24107, 1);
      V v_ru_24x_24107_24MkPair = heff_take_reuse_n(v_x_24107, 3ULL, 2);
      V v_t_24111 = ({ V a_0 = v_p_24102; V b_1 = heff_dup(g_heff_2ecompile_2esimplify_2efailing_get()); V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_24112;
      if ((heff_dup(v_t_24111) == NTAG(TAG_True))) {
        heff_drop(v_t_24111);
        v_t_24112 = heff_tag_at_n(v_ru_24x_24107_24MkPair, TAG_OPrim, 2, (V[]){v_p_24102, v_vs_24110});
      } else {
        heff_drop(v_t_24111);
        v_t_24112 = heff_tag_n(TAG_OSimple, 1, (V[]){heff_tag_at_n(v_ru_24x_24107_24MkPair, TAG_SPrim, 2, (V[]){v_p_24102, v_vs_24110})});
      }
      v_x_24113 = heff_tag_at_n(v_ru_24x2_24106_24MkPair, TAG_MkPair, 2, (V[]){v_ss_24109, v_t_24112});
      break;
    }
    default: heff_nomatch(v_x_24107);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24113, v_n_24108});
  }
  default: return heff_nomatch(v_x2_24106);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam11(V self, V *args) {
  V v_n_24117 = args[0];
  V v_m_24116 = heff_env(self)[0];
  V v_k_24114 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24118 = heff_tr(heff_call(v_m_24116, 1, (V[]){v_n_24117}));
  switch (heff_tag_of(v_x2_24118)) {
  case TAG_MkPair: {
    V v_x_24119 = heff_field(v_x2_24118, 0);
    V v_n_24120 = heff_field(v_x2_24118, 1);
    V v_ru_24x2_24118_24MkPair = heff_take_reuse_n(v_x2_24118, 3ULL, 2);
    V v_t_24123;
    switch (heff_tag_of(v_x_24119)) {
    case TAG_MkPair: {
      V v_ss_24121 = heff_field(v_x_24119, 0);
      V v_vs_24122 = heff_field(v_x_24119, 1);
      heff_take_n(v_x_24119, 3ULL, 2);
      v_t_24123 = heff_tag_at_n(v_ru_24x2_24118_24MkPair, TAG_MkPair, 2, (V[]){v_ss_24121, heff_tag_n(TAG_OCall, 2, (V[]){v_k_24114, v_vs_24122})});
      break;
    }
    default: heff_nomatch(v_x_24119);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24123, v_n_24120});
  }
  default: return heff_nomatch(v_x2_24118);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam12(V self, V *args) {
  V v_n_24126 = args[0];
  V v_m_24125 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24127 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_n_24126}));
  switch (heff_tag_of(v_x2_24127)) {
  case TAG_MkPair: {
    V v_x_24128 = heff_field(v_x2_24127, 0);
    V v_n_24129 = heff_field(v_x2_24127, 1);
    V v_ru_24x2_24127_24MkPair = heff_take_reuse_n(v_x2_24127, 3ULL, 2);
    V v_t_24130 = heff_tag_at_n(v_ru_24x2_24127_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_24128})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24130, v_n_24129});
  }
  default: return heff_nomatch(v_x2_24127);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam13(V self, V *args) {
  V v_n_24133 = args[0];
  V v_m_24132 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24134 = heff_tr(heff_call(v_m_24132, 1, (V[]){v_n_24133}));
  switch (heff_tag_of(v_x2_24134)) {
  case TAG_MkPair: {
    V v_x_24135 = heff_field(v_x2_24134, 0);
    V v_n_24136 = heff_field(v_x2_24134, 1);
    V v_ru_24x2_24134_24MkPair = heff_take_reuse_n(v_x2_24134, 3ULL, 2);
    V v_t_24137 = heff_tag_at_n(v_ru_24x2_24134_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_24135})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24137, v_n_24136});
  }
  default: return heff_nomatch(v_x2_24134);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam14(V self, V *args) {
  V v_n_24140 = args[0];
  V v_m_24139 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24141 = heff_tr(heff_call(v_m_24139, 1, (V[]){v_n_24140}));
  switch (heff_tag_of(v_x2_24141)) {
  case TAG_MkPair: {
    V v_x_24142 = heff_field(v_x2_24141, 0);
    V v_n_24143 = heff_field(v_x2_24141, 1);
    V v_ru_24x2_24141_24MkPair = heff_take_reuse_n(v_x2_24141, 3ULL, 2);
    V v_t_24144 = heff_tag_at_n(v_ru_24x2_24141_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_24142})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24144, v_n_24143});
  }
  default: return heff_nomatch(v_x2_24141);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam15(V self, V *args) {
  V v_n_24147 = args[0];
  V v_m_24146 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24148 = heff_tr(heff_call(v_m_24146, 1, (V[]){v_n_24147}));
  switch (heff_tag_of(v_x2_24148)) {
  case TAG_MkPair: {
    V v_x_24149 = heff_field(v_x2_24148, 0);
    V v_n_24150 = heff_field(v_x2_24148, 1);
    V v_ru_24x2_24148_24MkPair = heff_take_reuse_n(v_x2_24148, 3ULL, 2);
    V v_t_24151 = heff_tag_at_n(v_ru_24x2_24148_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_24149})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24151, v_n_24150});
  }
  default: return heff_nomatch(v_x2_24148);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam16(V self, V *args) {
  V v_n_24155 = args[0];
  V v_m_24154 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24156 = heff_tr(heff_call(v_m_24154, 1, (V[]){v_n_24155}));
  switch (heff_tag_of(v_x2_24156)) {
  case TAG_MkPair: {
    V v_x_24157 = heff_field(v_x2_24156, 0);
    V v_n_24158 = heff_field(v_x2_24156, 1);
    V v_ru_24x2_24156_24MkPair = heff_take_reuse_n(v_x2_24156, 3ULL, 2);
    V v_t_24159 = heff_tag_at_n(v_ru_24x2_24156_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_24157})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24159, v_n_24158});
  }
  default: return heff_nomatch(v_x2_24156);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam17(V self, V *args) {
  V v_n_24162 = args[0];
  V v_m_24161 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24163 = heff_tr(heff_call(v_m_24161, 1, (V[]){v_n_24162}));
  switch (heff_tag_of(v_x2_24163)) {
  case TAG_MkPair: {
    V v_x_24164 = heff_field(v_x2_24163, 0);
    V v_n_24165 = heff_field(v_x2_24163, 1);
    V v_ru_24x2_24163_24MkPair = heff_take_reuse_n(v_x2_24163, 3ULL, 2);
    V v_t_24166 = heff_tag_at_n(v_ru_24x2_24163_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_24164})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24166, v_n_24165});
  }
  default: return heff_nomatch(v_x2_24163);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam18(V self, V *args) {
  V v_n_24167 = args[0];
  V v_t_24168 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_OAbandon)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24168, v_n_24167});
}
V g_heff_2ecompile_2eimperative_2eopOf_lam19(V self, V *args) {
  V v_n_24171 = args[0];
  V v_t_24172 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_OAbandon)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24172, v_n_24171});
}
Clo g_heff_2ecompile_2eimperative_2edeclBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2edeclBefore_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2edeclBefore(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SDecl, 1, (V[]){v_x_240}), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_st_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      V v_t_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_st_242, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SDecl, 1, (V[]){v_x_240}), v_t_244});
    }
    case TAG_Cons: {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_st_242, heff_hole()});
      V v_u_248 = (g_heff_2ecompile_2eimperative_2edeclBefore_24dps(v_x_240, v_x22_243, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2edeclBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2edeclBefore(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2egenOf_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2egenOf_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2egenOf_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2egenOf_lam3(V self, V *args);
V g_heff_2ecompile_2eimperative_2egenOf_lam4(V self, V *args);
V g_heff_2ecompile_2eimperative_2egenOf_lam5(V self, V *args);
V g_heff_2ecompile_2eimperative_2egenOf_lam7(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2egenOf_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2egenOf_lam7, 1, 0};
V g_heff_2ecompile_2eimperative_2egenOf_lam6(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2egenOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2egenOf_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2egenOf(V v_full_240) {
top: ;
  return heff_rec_n(8, shape_full__simple__tail__bindTo__setTo__atom__op__pred, (V[]){heff_dup(v_full_240), heff_clo_n(g_heff_2ecompile_2eimperative_2egenOf_lam0, 1, 1, (V[]){heff_dup(v_full_240)}), heff_clo_n(g_heff_2ecompile_2eimperative_2egenOf_lam1, 2, 1, (V[]){heff_dup(v_full_240)}), heff_clo_n(g_heff_2ecompile_2eimperative_2egenOf_lam2, 2, 1, (V[]){heff_dup(v_full_240)}), heff_clo_n(g_heff_2ecompile_2eimperative_2egenOf_lam3, 2, 1, (V[]){heff_dup(v_full_240)}), heff_clo_n(g_heff_2ecompile_2eimperative_2egenOf_lam4, 1, 1, (V[]){heff_dup(v_full_240)}), heff_clo_n(g_heff_2ecompile_2eimperative_2egenOf_lam5, 1, 1, (V[]){heff_dup(v_full_240)}), heff_clo_n(g_heff_2ecompile_2eimperative_2egenOf_lam6, 1, 1, (V[]){v_full_240})});
}
V g_heff_2ecompile_2eimperative_2egenOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2egenOf(a[0]);
}
V g_heff_2ecompile_2eimperative_2egenOf_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = (g_heff_2ecompile_2eimperative_2egenOf(v_full_240));
  return (g_heff_2ecompile_2eimperative_2esimpleOf(v_t_242, v_e_241));
}
V g_heff_2ecompile_2eimperative_2egenOf_lam1(V self, V *args) {
  V v_self_243 = args[0];
  V v_e_244 = args[1];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = (g_heff_2ecompile_2eimperative_2egenOf(v_full_240));
  return (g_heff_2ecompile_2eimperative_2etailOf(v_t_245, v_self_243, v_e_244));
}
V g_heff_2ecompile_2eimperative_2egenOf_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_e_247 = args[1];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2ecompile_2eimperative_2egenOf(v_full_240));
  return (g_heff_2ecompile_2eimperative_2etoDest(v_t_248, heff_tag_n(TAG_DLet, 1, (V[]){v_x_246}), v_e_247));
}
V g_heff_2ecompile_2eimperative_2egenOf_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_2410 = args[1];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = (g_heff_2ecompile_2eimperative_2egenOf(v_full_240));
  return (g_heff_2ecompile_2eimperative_2etoDest(v_t_2411, heff_tag_n(TAG_DSet, 1, (V[]){v_x_249}), v_e_2410));
}
V g_heff_2ecompile_2eimperative_2egenOf_lam4(V self, V *args) {
  V v_e_2412 = args[0];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = (g_heff_2ecompile_2eimperative_2egenOf(v_full_240));
  return (g_heff_2ecompile_2eimperative_2eatomOf(v_t_2413, v_e_2412));
}
V g_heff_2ecompile_2eimperative_2egenOf_lam5(V self, V *args) {
  V v_e_2414 = args[0];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = (g_heff_2ecompile_2eimperative_2egenOf(v_full_240));
  return (g_heff_2ecompile_2eimperative_2eopOf(v_t_2415, v_e_2414));
}
V g_heff_2ecompile_2eimperative_2egenOf_lam7(V self, V *args) {
  V v_n_2420 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_2420});
}
V g_heff_2ecompile_2eimperative_2egenOf_lam6(V self, V *args) {
  V v_e_2416 = args[0];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_g_2417 = (g_heff_2ecompile_2eimperative_2egenOf(v_full_240));
  V v_t_2418 = heff_dup(heff_rfield(v_g_2417, 0));
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_t_2418);
    return (g_heff_2ecompile_2eimperative_2epredAny(v_g_2417, v_e_2416));
  } else {
    heff_drop(v_t_2418);
    V v_t_2419 = (g_heff_2ecompile_2eimperative_2eisRelCall(v_e_2416));
    if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
      heff_drop(v_t_2419);
      return (g_heff_2ecompile_2eimperative_2epredAny(v_g_2417, v_e_2416));
    } else {
      heff_drop(v_e_2416);
      heff_drop_rec(v_g_2417, 8);
      heff_drop(v_t_2419);
      return ((V)&g_heff_2ecompile_2eimperative_2egenOf_lam7_clo);
    }
  }
}
V g_heff_2ecompile_2eimperative_2epartsVal_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2epartsVal_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2epartsVal_lam2(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2epartsVal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsVal_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2epartsVal(V v_r_240, V v_v_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_SVar: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SGlobal: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SInt: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SFloat: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SStr: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SBytes: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SFloat32: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SPrimFn: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SLam: {
    V v_v2_2414 = heff_dup(heff_field(v_v_241, 1));
    switch (heff_tag_of(v_v2_2414)) {
    case TAG_MkBlock: {
      V v_t_2415 = heff_field(v_v2_2414, 0);
      V v_ru_24v2_2414_24MkBlock = heff_take_reuse_n(v_v2_2414, 1ULL, 1);
      V v_t_2416 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 2, (V[]){v_t_2415, v_acc_242}));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24v2_2414_24MkBlock, TAG_PartVal, 1, (V[]){v_v_241}), v_t_2416});
    }
    default: return heff_nomatch(v_v2_2414);
    }
  }
  case TAG_STag: {
    V v_as_2418 = heff_dup(heff_field(v_v_241, 1));
    V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2418));
    V v_t_2423 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epartsVal_lam0, 2, 1, (V[]){v_r_240}); V a_1 = v_acc_242; V a_2 = v_t_2420; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2420); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_t_2423});
  }
  case TAG_SRec: {
    V v_fs_2424 = heff_dup(heff_field(v_v_241, 0));
    V v_t_2426 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2424));
    V v_t_2429 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epartsVal_lam1, 2, 1, (V[]){v_r_240}); V a_1 = v_acc_242; V a_2 = v_t_2426; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2426); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_t_2429});
  }
  case TAG_SProj: {
    V v_w_2430 = heff_dup(heff_field(v_v_241, 0));
    V v_t_2434 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 5), 2, (V[]){v_w_2430, v_acc_242}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_t_2434});
  }
  case TAG_SPrim: {
    V v_as_2436 = heff_dup(heff_field(v_v_241, 1));
    V v_t_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2436));
    V v_t_2440 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epartsVal_lam2, 2, 1, (V[]){v_r_240}); V a_1 = v_acc_242; V a_2 = v_t_2437; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2437); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_t_2440});
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2eimperative_2epartsVal_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epartsVal(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimperative_2epartsVal_lam0(V self, V *args) {
  V v_acc_2421 = args[0];
  V v_x_2422 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 5);
  args[0] = v_x_2422;
  args[1] = v_acc_2421;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimperative_2epartsVal_lam1(V self, V *args) {
  V v_acc_2427 = args[0];
  V v_x_2428 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 5);
  args[0] = v_x_2428;
  args[1] = v_acc_2427;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimperative_2epartsVal_lam2(V self, V *args) {
  V v_acc_2438 = args[0];
  V v_x_2439 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 5);
  args[0] = v_x_2439;
  args[1] = v_acc_2438;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimperative_2epartsTl_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2epartsTl_lam1(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2epartsTl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsTl_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2epartsTl(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_TSeq: {
    V v_ss_243 = heff_field(v_x2_241, 0);
    V v_t_244 = heff_field(v_x2_241, 1);
    V v_t_245 = heff_tr(heff_call(heff_take_field(v_r_240, 4), 2, (V[]){heff_dup(v_t_244), v_acc_242}));
    return heff_tail(heff_get_n(v_r_240, 3, 5), 2, (V[]){heff_dup(v_ss_243), v_t_245});
  }
  case TAG_TReturn: {
    V v_o_246 = heff_field(v_x2_241, 0);
    return heff_tail(heff_get_n(v_r_240, 1, 5), 2, (V[]){heff_dup(v_o_246), v_acc_242});
  }
  case TAG_TLoop: {
    V v_vs_247 = heff_field(v_x2_241, 0);
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_vs_247)));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epartsTl_lam0, 2, 1, (V[]){v_r_240}); V a_1 = v_acc_242; V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  }
  case TAG_TIf: {
    V v_c_2411 = heff_field(v_x2_241, 0);
    V v_t_2412 = heff_field(v_x2_241, 1);
    V v_e_2413 = heff_field(v_x2_241, 2);
    V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 4)), 2, (V[]){heff_dup(v_e_2413), v_acc_242}));
    V v_t_2415 = heff_tr(heff_call(heff_take_field(v_r_240, 4), 2, (V[]){heff_dup(v_t_2412), v_t_2414}));
    return heff_tail(heff_get_n(v_r_240, 2, 5), 2, (V[]){heff_dup(v_c_2411), v_t_2415});
  }
  case TAG_TCase: {
    V v_v_2416 = heff_field(v_x2_241, 0);
    V v_arms_2417 = heff_field(v_x2_241, 1);
    V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2417)));
    V v_t_2424 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epartsTl_lam1, 2, 1, (V[]){heff_dup(v_r_240)}); V a_1 = v_acc_242; V a_2 = v_t_2418; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
    return heff_tail(heff_get_n(v_r_240, 0, 5), 2, (V[]){heff_dup(v_v_2416), v_t_2424});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2epartsTl_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eimperative_2epartsTl(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eimperative_2epartsTl_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_x_2410 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 5);
  args[0] = v_x_2410;
  args[1] = v_acc_249;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimperative_2epartsTl_lam1(V self, V *args) {
  V v_acc_2419 = args[0];
  V v_x_2420 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2420)) {
  case TAG_MkArm: {
    V v_t_2423 = heff_field(v_x_2420, 2);
    heff_take_n(v_x_2420, 4ULL, 3);
    V f_ = heff_get_n(v_r_240, 4, 5);
    args[0] = v_t_2423;
    args[1] = v_acc_2419;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_x_2420);
  }
}
Clo g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SLet: {
    V v_o_243 = heff_field(v_x2_240, 1);
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(heff_dup(v_o_243), v_acc_241);
  }
  case TAG_SDecl: {
    return v_acc_241;
  }
  case TAG_SSet: {
    V v_o_246 = heff_field(v_x2_240, 1);
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(heff_dup(v_o_246), v_acc_241);
  }
  case TAG_SIf: {
    V v_c_247 = heff_field(v_x2_240, 0);
    V v_ts_248 = heff_field(v_x2_240, 1);
    V v_fs_249 = heff_field(v_x2_240, 2);
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_249)));
    V v_t_2411 = ({ V a_0 = v_acc_241; V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_2410); r_; });
    V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 3)), 2, (V[]){heff_dup(v_ts_248), v_t_2411}));
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_c_247), v_t_2412});
  }
  case TAG_SCase: {
    V v_v_2413 = heff_field(v_x2_240, 0);
    V v_arms_2414 = heff_field(v_x2_240, 1);
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2414)));
    V v_t_2416 = ({ V a_0 = v_acc_241; V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s1318914558x1386196507(a_0, a_1)); heff_drop(v_t_2415); r_; });
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 0)), 2, (V[]){heff_dup(v_v_2413), v_t_2416});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eimperative_2evalNamesTop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2evalNamesTop_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2evalNamesTop(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SVar: {
    V v_x_242 = heff_field(v_x1_240, 0);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_242), v_acc_241});
  }
  case TAG_SGlobal: {
    return v_acc_241;
  }
  case TAG_SInt: {
    return v_acc_241;
  }
  case TAG_SFloat: {
    return v_acc_241;
  }
  case TAG_SStr: {
    return v_acc_241;
  }
  case TAG_SBytes: {
    return v_acc_241;
  }
  case TAG_SFixed: {
    return v_acc_241;
  }
  case TAG_SFloat32: {
    return v_acc_241;
  }
  case TAG_SPrimFn: {
    return v_acc_241;
  }
  case TAG_SLam: {
    return v_acc_241;
  }
  case TAG_STag: {
    V v_as_2415 = heff_field(v_x1_240, 1);
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_as_2415)));
    return ({ V a_0 = v_acc_241; V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_2417); r_; });
  }
  case TAG_SRec: {
    V v_fs_2418 = heff_field(v_x1_240, 0);
    V v_t_2420 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), heff_dup(v_fs_2418)));
    return ({ V a_0 = v_acc_241; V a_1 = v_t_2420; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_2420); r_; });
  }
  case TAG_SProj: {
    V v_v_2421 = heff_field(v_x1_240, 0);
    V t_0 = v_v_2421;
    V t_1 = v_acc_241;
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_SPrim: {
    V v_as_2426 = heff_field(v_x1_240, 1);
    V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_as_2426)));
    return ({ V a_0 = v_acc_241; V a_1 = v_t_2427; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_2427); r_; });
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eimperative_2evalNamesTop_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2evalNamesTop(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eimperative_2eusedOnceNext_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eusedOnceNext_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2eusedOnceNext(V v_x_240, V v_next_241, V v_rest_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24f2064224154x1075431823(MK_INT(1LL), MK_INT(0LL), v_x_240, v_next_241));
  V v_ret_24bool = heff_bool((heff_intEq_c_lent(v_t_243, MK_INT(1LL), 2) && ({ V v_t_245 = (g_list_2efoldl_24f613246640x472569916(MK_INT(1LL), MK_INT(0LL), v_x_240, v_rest_242)); int c_ = heff_intEq_c_lent(v_t_245, MK_INT(1LL), 2); heff_drop(v_t_245); c_; })));
  heff_drop(v_t_243);
  return v_ret_24bool;
}
V g_heff_2ecompile_2eimperative_2eusedOnceNext_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eimperative_2eusedOnceNext(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}