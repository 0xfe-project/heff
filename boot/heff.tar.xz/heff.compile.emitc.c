// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Asg 13569
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_KnownCell 38933
#define TAG_KnownClo 18392
#define TAG_KnownRec 32578
#define TAG_KnownTag 34380
#define TAG_Leaf 13717
#define TAG_MkArm 55352
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_Plus 9189
#define TAG_Ret 29485
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_after 294093302
#define LBL_arg 306384
#define LBL_args 9498020
#define LBL_arms 9498206
#define LBL_body 9524841
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_code 9554612
#define LBL_defs 9574869
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_funs 9650075
#define LBL_key 315609
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_lams 9809570
#define LBL_lbls 9810500
#define LBL_name 9869138
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_op 10312
#define LBL_owned 307523263
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_post 9942375
#define LBL_pre 320797
#define LBL_prefix 967031229
#define LBL_prim 9944941
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_self 10021907
#define LBL_shapes 1043573789
#define LBL_source 1050636102
#define LBL_strs 10036521
#define LBL_tags 10047712
#define LBL_takes 311482598
static uint32_t shape_arg__pre__post[] = {LBL_arg, LBL_pre, LBL_post};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_key__params[] = {LBL_key, LBL_params};
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
static uint32_t shape_prefix__end[] = {LBL_prefix, LBL_end};
static uint32_t shape_prim__args__arms[] = {LBL_prim, LBL_args, LBL_arms};
static uint32_t shape_protos__code[] = {LBL_protos, LBL_code};
static uint32_t shape_source__errors[] = {LBL_source, LBL_errors};
static uint32_t shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes[] = {LBL_tags, LBL_lbls, LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes};
V g_heff_2ecompile_2eemit_2ebounceGo(V, V);
V g_heff_2ecompile_2eemit_2ebounceGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebounceGo_clo;
V g_heff_2ecompile_2eemitc_2eaddLam(V, V, V);
V g_heff_2ecompile_2eemitc_2eaddLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eaddLam_clo;
V g_heff_2ecompile_2eemitc_2eagain(V, V);
V g_heff_2ecompile_2eemitc_2eagain_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eagain_clo;
V g_heff_2ecompile_2eemitc_2eagrees(V, V, V);
V g_heff_2ecompile_2eemitc_2eagrees_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eagrees_clo;
V g_heff_2ecompile_2eemitc_2earityOne(V, V);
V g_heff_2ecompile_2eemitc_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2earityOne_clo;
V g_heff_2ecompile_2eemitc_2earmFor(V, V);
V g_heff_2ecompile_2eemitc_2earmFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2earmFor_clo;
V g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_clo;
V g_heff_2ecompile_2eemitc_2earmLines_24s2056739052x1812096441(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2earmLines_24s2056739052x1812096441_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2earmLines_24s2056739052x1812096441_clo;
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862(V, V, V);
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_clo;
V g_heff_2ecompile_2eemitc_2eborAll(V, V);
V g_heff_2ecompile_2eemitc_2eborAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eborAll_clo;
V g_heff_2ecompile_2eemitc_2eborDef(V, V);
V g_heff_2ecompile_2eemitc_2eborDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eborDef_clo;
V g_heff_2ecompile_2eemitc_2eborFix(V, V, V);
V g_heff_2ecompile_2eemitc_2eborFix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eborFix_clo;
V g_heff_2ecompile_2eemitc_2ebuildsSize(V, V);
V g_heff_2ecompile_2eemitc_2ebuildsSize_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ebuildsSize_clo;
V g_heff_2ecompile_2eemitc_2ebuiltOf(V);
V g_heff_2ecompile_2eemitc_2ebuiltOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ebuiltOf_clo;
V g_heff_2ecompile_2eemitc_2ecallText(V, V, V);
V g_heff_2ecompile_2eemitc_2ecallText_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallText_clo;
V g_heff_2ecompile_2eemitc_2ecatMaybesC(V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_clo;
V g_heff_2ecompile_2eemitc_2eceOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eceOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eceOf_clo;
V g_heff_2ecompile_2eemitc_2echangedOf(V, V, V);
V g_heff_2ecompile_2eemitc_2echangedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echangedOf_clo;
V g_heff_2ecompile_2eemitc_2echeckEnd(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckEnd_clo;
V g_heff_2ecompile_2eemitc_2echeckOut(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckOut_clo;
V g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(V, V, V);
V g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_clo;
V g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281(V, V, V, V);
V g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_clo;
V g_heff_2ecompile_2eemitc_2econdLet(V, V, V);
V g_heff_2ecompile_2eemitc_2econdLet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2econdLet_clo;
V g_heff_2ecompile_2eemitc_2econdOn(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2econdOn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2econdOn_clo;
V g_heff_2ecompile_2eemitc_2econdPrims_get(void);
V g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_clo;
V g_heff_2ecompile_2eemitc_2edeclOf(V, V);
V g_heff_2ecompile_2eemitc_2edeclOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edeclOf_clo;
V g_heff_2ecompile_2eemitc_2edefC(V, V);
V g_heff_2ecompile_2eemitc_2edefC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edefC_clo;
V g_heff_2ecompile_2eemitc_2edefOwn(V, V);
V g_heff_2ecompile_2eemitc_2edefOwn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edefOwn_clo;
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2edropsIn(V, V);
V g_heff_2ecompile_2eemitc_2edropsIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropsIn_clo;
V g_heff_2ecompile_2eemitc_2eelemI(V, V);
V g_heff_2ecompile_2eemitc_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemI_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void);
V g_heff_2ecompile_2eemitc_2eentryCall(V, V, V);
V g_heff_2ecompile_2eemitc_2eentryCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eentryCall_clo;
V g_heff_2ecompile_2eemitc_2eentryPart_get(void);
V g_heff_2ecompile_2eemitc_2efieldAt_24s1436815667x2123639710(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2efieldAt_24s1436815667x2123639710_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efieldAt_24s1436815667x2123639710_clo;
V g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_clo;
V g_heff_2ecompile_2eemitc_2efieldLent(V, V, V, V);
V g_heff_2ecompile_2eemitc_2efieldLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efieldLent_clo;
V g_heff_2ecompile_2eemitc_2efieldLine(V, V, V, V);
V g_heff_2ecompile_2eemitc_2efieldLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efieldLine_clo;
V g_heff_2ecompile_2eemitc_2efieldMask(V, V, V);
V g_heff_2ecompile_2eemitc_2efieldMask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efieldMask_clo;
V g_heff_2ecompile_2eemitc_2efixedLit(V, V);
V g_heff_2ecompile_2eemitc_2efixedLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedLit_clo;
V g_heff_2ecompile_2eemitc_2efreeGo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efreeGo_clo;
V g_heff_2ecompile_2eemitc_2efreeOf(V, V);
V g_heff_2ecompile_2eemitc_2efreeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efreeOf_clo;
V g_heff_2ecompile_2eemitc_2efunDef(V, V, V, V);
V g_heff_2ecompile_2eemitc_2efunDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunDef_clo;
V g_heff_2ecompile_2eemitc_2efvW(V, V, V);
V g_heff_2ecompile_2eemitc_2efvW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efvW_clo;
V g_heff_2ecompile_2eemitc_2eglobalGet(V, V);
V g_heff_2ecompile_2eemitc_2eglobalGet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglobalGet_clo;
V g_heff_2ecompile_2eemitc_2ehashBelow(V, V, V, V);
V g_heff_2ecompile_2eemitc_2ehashBelow_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ehashBelow_clo;
V g_heff_2ecompile_2eemitc_2ehashedGo(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ehashedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ehashedGo_clo;
V g_heff_2ecompile_2eemitc_2eheldVar(V, V);
V g_heff_2ecompile_2eemitc_2eheldVar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eheldVar_clo;
V g_heff_2ecompile_2eemitc_2eidentAt(V, V, V);
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eidentAt_clo;
V g_heff_2ecompile_2eemitc_2einPlace(V);
V g_heff_2ecompile_2eemitc_2einPlace_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2einPlace_clo;
V g_heff_2ecompile_2eemitc_2eindexIn(V, V, V);
V g_heff_2ecompile_2eemitc_2eindexIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eindexIn_clo;
V g_heff_2ecompile_2eemitc_2eisAlnum(V);
V g_heff_2ecompile_2eemitc_2eisAlnum_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eisAlnum_clo;
V g_heff_2ecompile_2eemitc_2eisCondCall(V);
V g_heff_2ecompile_2eemitc_2eisCondCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eisCondCall_clo;
V g_heff_2ecompile_2eemitc_2eisMatchOn(V, V);
V g_heff_2ecompile_2eemitc_2eisMatchOn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eisMatchOn_clo;
V g_heff_2ecompile_2eemitc_2ejustsOf(V);
V g_heff_2ecompile_2eemitc_2ejustsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ejustsOf_clo;
V g_heff_2ecompile_2eemitc_2ekeepBits(V);
V g_heff_2ecompile_2eemitc_2ekeepBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeepBits_clo;
V g_heff_2ecompile_2eemitc_2ekeptFrom(V, V);
V g_heff_2ecompile_2eemitc_2ekeptFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeptFrom_clo;
V g_heff_2ecompile_2eemitc_2eknowCell(V, V, V);
V g_heff_2ecompile_2eemitc_2eknowCell_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eknowCell_clo;
V g_heff_2ecompile_2eemitc_2eknowing(V, V, V);
V g_heff_2ecompile_2eemitc_2eknowing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eknowing_clo;
V g_heff_2ecompile_2eemitc_2eknownLet(V, V, V);
V g_heff_2ecompile_2eemitc_2eknownLet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eknownLet_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2elamBody_24s793100636x1014529228(V, V, V, V);
V g_heff_2ecompile_2eemitc_2elamBody_24s793100636x1014529228_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elamBody_24s793100636x1014529228_clo;
V g_heff_2ecompile_2eemitc_2elamLines(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2elamLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elamLines_clo;
V g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_clo;
V g_heff_2ecompile_2eemitc_2elastDotGo(V, V, V);
V g_heff_2ecompile_2eemitc_2elastDotGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elastDotGo_clo;
V g_heff_2ecompile_2eemitc_2elentField(V, V, V);
V g_heff_2ecompile_2eemitc_2elentField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elentField_clo;
V g_heff_2ecompile_2eemitc_2elentOperands_24s476183159x330509729(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2elentOperands_24s476183159x330509729_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elentOperands_24s476183159x330509729_clo;
V g_heff_2ecompile_2eemitc_2elentOr_24s341891767x1199481071(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2elentOr_24s341891767x1199481071_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elentOr_24s341891767x1199481071_clo;
V g_heff_2ecompile_2eemitc_2elentVar(V, V, V);
V g_heff_2ecompile_2eemitc_2elentVar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elentVar_clo;
V g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_clo;
V g_heff_2ecompile_2eemitc_2elentVars(V, V);
V g_heff_2ecompile_2eemitc_2elentVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elentVars_clo;
V g_heff_2ecompile_2eemitc_2eletOrCond_24s386767440x905233418(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eletOrCond_24s386767440x905233418_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eletOrCond_24s386767440x905233418_clo;
V g_heff_2ecompile_2eemitc_2eletReuse(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eletReuse_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eletReuse_clo;
V g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305_clo;
V g_heff_2ecompile_2eemitc_2eloopLent(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eloopLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eloopLent_clo;
V g_heff_2ecompile_2eemitc_2emangleChar(V);
V g_heff_2ecompile_2eemitc_2emangleChar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleChar_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emodulePart(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2emodulePart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emodulePart_clo;
V g_heff_2ecompile_2eemitc_2enamesInGo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2enamesInGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enamesInGo_clo;
V g_heff_2ecompile_2eemitc_2enamesTable(V, V);
V g_heff_2ecompile_2eemitc_2enamesTable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enamesTable_clo;
V g_heff_2ecompile_2eemitc_2enewLam(V);
V g_heff_2ecompile_2eemitc_2enewLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enewLam_clo;
V g_heff_2ecompile_2eemitc_2enumbered(V, V, V);
V g_heff_2ecompile_2eemitc_2enumbered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enumbered_clo;
V g_heff_2ecompile_2eemitc_2enumbersOf(V, V);
V g_heff_2ecompile_2eemitc_2enumbersOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enumbersOf_clo;
V g_heff_2ecompile_2eemitc_2eonceInOrder(V, V);
V g_heff_2ecompile_2eemitc_2eonceInOrder_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eonceInOrder_clo;
V g_heff_2ecompile_2eemitc_2eonlyLent(V, V, V);
V g_heff_2ecompile_2eemitc_2eonlyLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eonlyLent_clo;
V g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634(V, V, V);
V g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634_clo;
V g_heff_2ecompile_2eemitc_2eoperandsOf(V);
V g_heff_2ecompile_2eemitc_2eoperandsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eoperandsOf_clo;
V g_heff_2ecompile_2eemitc_2eothersW(V, V, V);
V g_heff_2ecompile_2eemitc_2eothersW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eothersW_clo;
V g_heff_2ecompile_2eemitc_2eoutputOf(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eoutputOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eoutputOf_clo;
V g_heff_2ecompile_2eemitc_2eownHas(V, V, V);
V g_heff_2ecompile_2eemitc_2eownHas_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownHas_clo;
V g_heff_2ecompile_2eemitc_2eownLines(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownLines_clo;
V g_heff_2ecompile_2eemitc_2eparamsAt(V, V, V);
V g_heff_2ecompile_2eemitc_2eparamsAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eparamsAt_clo;
V g_heff_2ecompile_2eemitc_2epartsWith(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2epartsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartsWith_clo;
V g_heff_2ecompile_2eemitc_2eperformNodes(V, V);
V g_heff_2ecompile_2eemitc_2eperformNodes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eperformNodes_clo;
V g_heff_2ecompile_2eemitc_2eplusDone(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eplusDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eplusDone_clo;
V g_heff_2ecompile_2eemitc_2epow2(V);
V g_heff_2ecompile_2eemitc_2epow2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epow2_clo;
V g_heff_2ecompile_2eemitc_2eprimCloDef(V);
V g_heff_2ecompile_2eemitc_2eprimCloDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimCloDef_clo;
V g_heff_2ecompile_2eemitc_2eprimLit(V, V);
V g_heff_2ecompile_2eemitc_2eprimLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimLit_clo;
V g_heff_2ecompile_2eemitc_2eprogramCE(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eprogramCE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprogramCE_clo;
V g_heff_2ecompile_2eemitc_2eprogramParts(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eprogramParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprogramParts_clo;
V g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_clo;
V g_heff_2ecompile_2eemitc_2epubLine(V);
V g_heff_2ecompile_2eemitc_2epubLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epubLine_clo;
V g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920(V, V, V, V);
V g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_clo;
V g_heff_2ecompile_2eemitc_2erelFixed(V);
V g_heff_2ecompile_2eemitc_2erelFixed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erelFixed_clo;
V g_heff_2ecompile_2eemitc_2ereuseArgs(V, V);
V g_heff_2ecompile_2eemitc_2ereuseArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ereuseArgs_clo;
V g_heff_2ecompile_2eemitc_2ereuseIn(V, V, V);
V g_heff_2ecompile_2eemitc_2ereuseIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ereuseIn_clo;
V g_heff_2ecompile_2eemitc_2ereusePrim_get(void);
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047(V, V, V);
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_clo;
V g_heff_2ecompile_2eemitc_2ereusedOf(V);
V g_heff_2ecompile_2eemitc_2ereusedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ereusedOf_clo;
V g_heff_2ecompile_2eemitc_2ereuses(V, V);
V g_heff_2ecompile_2eemitc_2ereuses_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ereuses_clo;
V g_heff_2ecompile_2eemitc_2ereusing(V, V, V, V);
V g_heff_2ecompile_2eemitc_2ereusing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ereusing_clo;
V g_heff_2ecompile_2eemitc_2erunEnd(V, V);
V g_heff_2ecompile_2eemitc_2erunEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erunEnd_clo;
V g_heff_2ecompile_2eemitc_2esameS(V, V);
V g_heff_2ecompile_2eemitc_2esameS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2esameS_clo;
V g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452(V, V);
V g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_clo;
V g_heff_2ecompile_2eemitc_2eshapeDef(V);
V g_heff_2ecompile_2eemitc_2eshapeDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeDef_clo;
V g_heff_2ecompile_2eemitc_2eshapeLit(V, V);
V g_heff_2ecompile_2eemitc_2eshapeLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeLit_clo;
V g_heff_2ecompile_2eemitc_2eshapedGo(V, V);
V g_heff_2ecompile_2eemitc_2eshapedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapedGo_clo;
V g_heff_2ecompile_2eemitc_2eshapedOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eshapedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapedOf_clo;
V g_heff_2ecompile_2eemitc_2eslotFrom(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eslotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eslotFrom_clo;
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499(V, V, V);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_clo;
V g_heff_2ecompile_2eemitc_2estrDef(V, V);
V g_heff_2ecompile_2eemitc_2estrDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estrDef_clo;
V g_heff_2ecompile_2eemitc_2estrDefRunes(V, V);
V g_heff_2ecompile_2eemitc_2estrDefRunes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estrDefRunes_clo;
V g_heff_2ecompile_2eemitc_2estrLit(V, V);
V g_heff_2ecompile_2eemitc_2estrLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estrLit_clo;
V g_heff_2ecompile_2eemitc_2esunkGo(V, V, V);
V g_heff_2ecompile_2eemitc_2esunkGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2esunkGo_clo;
V g_heff_2ecompile_2eemitc_2etagsLbls(V);
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo;
V g_heff_2ecompile_2eemitc_2etakeKept(V, V, V, V);
V g_heff_2ecompile_2eemitc_2etakeKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etakeKept_clo;
V g_heff_2ecompile_2eemitc_2etakeOne(V, V, V);
V g_heff_2ecompile_2eemitc_2etakeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etakeOne_clo;
V g_heff_2ecompile_2eemitc_2etakeVar(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2etakeVar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etakeVar_clo;
V g_heff_2ecompile_2eemitc_2etakeVarIn(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2etakeVarIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etakeVarIn_clo;
V g_heff_2ecompile_2eemitc_2etakenFv(V, V, V, V);
V g_heff_2ecompile_2eemitc_2etakenFv_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etakenFv_clo;
V g_heff_2ecompile_2eemitc_2etakesAt(V, V, V, V);
V g_heff_2ecompile_2eemitc_2etakesAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etakesAt_clo;
V g_heff_2ecompile_2eemitc_2etraverseC(V, V);
V g_heff_2ecompile_2eemitc_2etraverseC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etraverseC_clo;
V g_heff_2ecompile_2eemitc_2eunits8(V);
V g_heff_2ecompile_2eemitc_2eunits8_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eunits8_clo;
V g_heff_2ecompile_2eemitc_2eupdateText(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eupdateText_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eupdateText_clo;
V g_heff_2ecompile_2eemitc_2eupdateVal_24s612948083x338018248(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eupdateVal_24s612948083x338018248_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eupdateVal_24s612948083x338018248_clo;
V g_heff_2ecompile_2eemitc_2eupdatedIn(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eupdatedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eupdatedIn_clo;
V g_heff_2ecompile_2eemitc_2eusedBy(V, V);
V g_heff_2ecompile_2eemitc_2eusedBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eusedBy_clo;
V g_heff_2ecompile_2eemitc_2evalDef(V, V);
V g_heff_2ecompile_2eemitc_2evalDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2evalDef_clo;
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(V, V, V);
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_clo;
V g_heff_2ecompile_2eemitc_2evarUse(V, V, V);
V g_heff_2ecompile_2eemitc_2evarUse_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2evarUse_clo;
V g_heff_2ecompile_2eemitc_2ewithKnown(V, V, V);
V g_heff_2ecompile_2eemitc_2ewithKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewithKnown_clo;
V g_heff_2ecompile_2eemitc_2ezipDE(V, V);
V g_heff_2ecompile_2eemitc_2ezipDE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ezipDE_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2ecompile_2eprims_2eallPrims_get(void);
V g_heff_2ecompile_2eprims_2easciiFrom(V, V);
V g_heff_2ecompile_2eprims_2easciiFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2easciiFrom_clo;
V g_heff_2ecompile_2eprims_2eprimArityGo(V, V);
V g_heff_2ecompile_2eprims_2eprimArityGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eprimArityGo_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_heff_2eelab_2efixed_2efixedPrimOf(V);
V g_heff_2eelab_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimOf_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s1703554932x1387778930(V);
V g_list_2eall_24s1703554932x1387778930_entry(V self, V *a);
extern Clo g_list_2eall_24s1703554932x1387778930_clo;
V g_list_2eall_24s607638492x847921129(V);
V g_list_2eall_24s607638492x847921129_entry(V self, V *a);
extern Clo g_list_2eall_24s607638492x847921129_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s261760131x1433598489(V);
V g_list_2eany_24s261760131x1433598489_entry(V self, V *a);
extern Clo g_list_2eany_24s261760131x1433598489_clo;
V g_list_2eany_24s910662703x1730636603(V);
V g_list_2eany_24s910662703x1730636603_entry(V self, V *a);
extern Clo g_list_2eany_24s910662703x1730636603_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1018181017x1541469354(V);
V g_list_2efilter_24s1018181017x1541469354_entry(V self, V *a);
extern Clo g_list_2efilter_24s1018181017x1541469354_clo;
V g_list_2efilter_24s1727592350x8580145(V);
V g_list_2efilter_24s1727592350x8580145_entry(V self, V *a);
extern Clo g_list_2efilter_24s1727592350x8580145_clo;
V g_list_2efilter_24s1967523567x64647275(V);
V g_list_2efilter_24s1967523567x64647275_entry(V self, V *a);
extern Clo g_list_2efilter_24s1967523567x64647275_clo;
V g_list_2efilter_24s2056490818x625949248(V, V);
V g_list_2efilter_24s2056490818x625949248_entry(V self, V *a);
extern Clo g_list_2efilter_24s2056490818x625949248_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s114050048x1903860601(V, V);
V g_list_2efoldl_24s114050048x1903860601_entry(V self, V *a);
extern Clo g_list_2efoldl_24s114050048x1903860601_clo;
V g_list_2efoldl_24s1196401404x611901340(V, V);
V g_list_2efoldl_24s1196401404x611901340_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1196401404x611901340_clo;
V g_list_2efoldl_24s125569247x179592613(V, V);
V g_list_2efoldl_24s125569247x179592613_entry(V self, V *a);
extern Clo g_list_2efoldl_24s125569247x179592613_clo;
V g_list_2efoldl_24s132236332x1381264820(V, V);
V g_list_2efoldl_24s132236332x1381264820_entry(V self, V *a);
extern Clo g_list_2efoldl_24s132236332x1381264820_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1530401830x609500251(V, V);
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1530401830x609500251_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s1685809585x983762522(V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1685809585x983762522_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1685809585x983762522_clo;
V g_list_2efoldl_24s1760706274x1469253109(V, V);
V g_list_2efoldl_24s1760706274x1469253109_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1760706274x1469253109_clo;
V g_list_2efoldl_24s1761834913x283136918(V, V);
V g_list_2efoldl_24s1761834913x283136918_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1761834913x283136918_clo;
V g_list_2efoldl_24s1891821040x773772203(V, V);
V g_list_2efoldl_24s1891821040x773772203_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1891821040x773772203_clo;
V g_list_2efoldl_24s2093480427x456774456(V, V, V, V);
V g_list_2efoldl_24s2093480427x456774456_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2093480427x456774456_clo;
V g_list_2efoldl_24s313132209x118284909(V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s313132209x118284909_entry(V self, V *a);
extern Clo g_list_2efoldl_24s313132209x118284909_clo;
V g_list_2efoldl_24s321107625x1130584089(V, V);
V g_list_2efoldl_24s321107625x1130584089_entry(V self, V *a);
extern Clo g_list_2efoldl_24s321107625x1130584089_clo;
V g_list_2efoldl_24s348322209x75032364(V, V);
V g_list_2efoldl_24s348322209x75032364_entry(V self, V *a);
extern Clo g_list_2efoldl_24s348322209x75032364_clo;
V g_list_2efoldl_24s449727021x365548005(V, V);
V g_list_2efoldl_24s449727021x365548005_entry(V self, V *a);
extern Clo g_list_2efoldl_24s449727021x365548005_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2efoldl_24s690408737x127625622(V, V);
V g_list_2efoldl_24s690408737x127625622_entry(V self, V *a);
extern Clo g_list_2efoldl_24s690408737x127625622_clo;
V g_list_2efoldl_24s873517001x1016672031(V, V);
V g_list_2efoldl_24s873517001x1016672031_entry(V self, V *a);
extern Clo g_list_2efoldl_24s873517001x1016672031_clo;
V g_list_2efoldl_24s907092709x2006193176(V, V);
V g_list_2efoldl_24s907092709x2006193176_entry(V self, V *a);
extern Clo g_list_2efoldl_24s907092709x2006193176_clo;
V g_list_2efoldl_24s96775841x2127473534(V, V);
V g_list_2efoldl_24s96775841x2127473534_entry(V self, V *a);
extern Clo g_list_2efoldl_24s96775841x2127473534_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1006477676x1816442814(V, V, V);
V g_list_2emap_24s1006477676x1816442814_entry(V self, V *a);
extern Clo g_list_2emap_24s1006477676x1816442814_clo;
V g_list_2emap_24s1009200955x251267316(V);
V g_list_2emap_24s1009200955x251267316_entry(V self, V *a);
extern Clo g_list_2emap_24s1009200955x251267316_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1196049889x1646679775(V, V, V, V, V, V, V);
V g_list_2emap_24s1196049889x1646679775_entry(V self, V *a);
extern Clo g_list_2emap_24s1196049889x1646679775_clo;
V g_list_2emap_24s1198759183x473355350(V);
V g_list_2emap_24s1198759183x473355350_entry(V self, V *a);
extern Clo g_list_2emap_24s1198759183x473355350_clo;
V g_list_2emap_24s1328195927x21044528(V, V);
V g_list_2emap_24s1328195927x21044528_entry(V self, V *a);
extern Clo g_list_2emap_24s1328195927x21044528_clo;
V g_list_2emap_24s1367796012x2117543847(V, V);
V g_list_2emap_24s1367796012x2117543847_entry(V self, V *a);
extern Clo g_list_2emap_24s1367796012x2117543847_clo;
V g_list_2emap_24s1378753456x1787722089(V, V, V, V);
V g_list_2emap_24s1378753456x1787722089_entry(V self, V *a);
extern Clo g_list_2emap_24s1378753456x1787722089_clo;
V g_list_2emap_24s1490052334x152035327(V);
V g_list_2emap_24s1490052334x152035327_entry(V self, V *a);
extern Clo g_list_2emap_24s1490052334x152035327_clo;
V g_list_2emap_24s1573559022x513331157(V, V, V);
V g_list_2emap_24s1573559022x513331157_entry(V self, V *a);
extern Clo g_list_2emap_24s1573559022x513331157_clo;
V g_list_2emap_24s1601949456x759540121(V, V, V, V);
V g_list_2emap_24s1601949456x759540121_entry(V self, V *a);
extern Clo g_list_2emap_24s1601949456x759540121_clo;
V g_list_2emap_24s1691650970x173345163(V);
V g_list_2emap_24s1691650970x173345163_entry(V self, V *a);
extern Clo g_list_2emap_24s1691650970x173345163_clo;
V g_list_2emap_24s1801850472x1352108398(V);
V g_list_2emap_24s1801850472x1352108398_entry(V self, V *a);
extern Clo g_list_2emap_24s1801850472x1352108398_clo;
V g_list_2emap_24s1917746138x1825516092(V);
V g_list_2emap_24s1917746138x1825516092_entry(V self, V *a);
extern Clo g_list_2emap_24s1917746138x1825516092_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s2073083146x1445066245(V);
V g_list_2emap_24s2073083146x1445066245_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_clo;
V g_list_2emap_24s380834591x871125279(V);
V g_list_2emap_24s380834591x871125279_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_clo;
V g_list_2emap_24s420582357x1720502382(V);
V g_list_2emap_24s420582357x1720502382_entry(V self, V *a);
extern Clo g_list_2emap_24s420582357x1720502382_clo;
V g_list_2emap_24s424921060x1532378(V, V, V, V, V, V, V);
V g_list_2emap_24s424921060x1532378_entry(V self, V *a);
extern Clo g_list_2emap_24s424921060x1532378_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24s617071700x1606310602(V, V, V, V, V, V);
V g_list_2emap_24s617071700x1606310602_entry(V self, V *a);
extern Clo g_list_2emap_24s617071700x1606310602_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2ezipWith_24s1814128165x1680687847(V, V, V, V, V);
V g_list_2ezipWith_24s1814128165x1680687847_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1814128165x1680687847_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s203264781x503274820(V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s203264781x503274820_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s203264781x503274820_clo;
V g_list_2ezipWith_24s2039753704x2095677241(V, V, V, V, V);
V g_list_2ezipWith_24s2039753704x2095677241_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s2039753704x2095677241_clo;
V g_list_2ezipWith_24s763642811x1204809256(V, V);
V g_list_2ezipWith_24s763642811x1204809256_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s763642811x1204809256_clo;
V g_list_2ezipWith_24s924458827x719285517(V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s924458827x719285517_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s924458827x719285517_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_map_2elookup_24s1338854231x236594845(V, V);
V g_map_2elookup_24s1338854231x236594845_entry(V self, V *a);
extern Clo g_map_2elookup_24s1338854231x236594845_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eshowInt_get(void);
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_rune_2etoInt_get(void);
Clo g_heff_2ecompile_2eemitc_2eisAlnum_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eisAlnum_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eisAlnum(V v_c_240) {
top: ;
  if (heff_intLe_c(MK_INT(97LL), heff_dup(v_c_240))) {
    if (heff_intLe_c(heff_dup(v_c_240), MK_INT(122LL))) {
      heff_drop(v_c_240);
      return NTAG(TAG_True);
    } else {
      if (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240))) {
        if (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL))) {
          heff_drop(v_c_240);
          return NTAG(TAG_True);
        } else {
          if (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240))) {
            return heff_intLe(v_c_240, MK_INT(57LL));
          } else {
            heff_drop(v_c_240);
            return NTAG(TAG_False);
          }
        }
      } else {
        if (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240))) {
          return heff_intLe(v_c_240, MK_INT(57LL));
        } else {
          heff_drop(v_c_240);
          return NTAG(TAG_False);
        }
      }
    }
  } else {
    if (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240))) {
      if (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL))) {
        heff_drop(v_c_240);
        return NTAG(TAG_True);
      } else {
        if (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240))) {
          return heff_intLe(v_c_240, MK_INT(57LL));
        } else {
          heff_drop(v_c_240);
          return NTAG(TAG_False);
        }
      }
    } else {
      if (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240))) {
        return heff_intLe(v_c_240, MK_INT(57LL));
      } else {
        heff_drop(v_c_240);
        return NTAG(TAG_False);
      }
    }
  }
}
V g_heff_2ecompile_2eemitc_2eisAlnum_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eisAlnum(a[0]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2emangleChar_str0, 16, (48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102));
HEFF_STRA(g_heff_2ecompile_2eemitc_2emangleChar_str1, 16, (48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102));
HEFF_STRA(g_heff_2ecompile_2eemitc_2emangleChar_str2, 1, (95));
Clo g_heff_2ecompile_2eemitc_2emangleChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emangleChar_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2emangleChar(V v_c_240) {
top: ;
  V v_t_241 = (g_heff_2ecompile_2eemitc_2eisAlnum(heff_dup(v_c_240)));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    return heff_strFromCharCode(v_c_240);
  }
  case TAG_False: {
    V v_t_242 = heff_intMod(heff_dup(v_c_240), MK_INT(256LL));
    V v_d_243 = heff_intDiv(v_t_242, MK_INT(16LL));
    V v_t_244 = heff_strSlice(((V)&g_heff_2ecompile_2eemitc_2emangleChar_str0), heff_dup(v_d_243), heff_intAdd(v_d_243, MK_INT(1LL)));
    V v_d_245 = heff_intMod(v_c_240, MK_INT(16LL));
    V v_t_246 = heff_strSlice(((V)&g_heff_2ecompile_2eemitc_2emangleChar_str1), heff_dup(v_d_245), heff_intAdd(v_d_245, MK_INT(1LL)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2emangleChar_str2), heff_strAppend(v_t_244, v_t_246));
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2eemitc_2emangleChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2emangleChar(a[0]);
}
Clo g_heff_2ecompile_2eemitc_2emangleW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emangleW_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2emangleW(V v_s_240, V v_i_241, V v_j_242, V v_acc_243) {
top: ;
  V v_t_245;
  if (heff_intLt_c(heff_dup(v_j_242), heff_strLength(heff_dup(v_s_240)))) {
    v_t_245 = (g_heff_2ecompile_2eemitc_2eisAlnum(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_242))));
  } else {
    v_t_245 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    V t_0 = v_s_240;
    V t_1 = v_i_241;
    V t_2 = heff_intAdd(v_j_242, MK_INT(1LL));
    V t_3 = v_acc_243;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_j_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
  case TAG_False: {
    if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_j_242))) {
      return heff_strAppend(v_acc_243, heff_strSlice(v_s_240, v_i_241, v_j_242));
    } else {
      V v_t_247 = heff_strAppend(v_acc_243, heff_strAppend(heff_strSlice(heff_dup(v_s_240), v_i_241, heff_dup(v_j_242)), (g_heff_2ecompile_2eemitc_2emangleChar(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_242))))));
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(heff_dup(v_j_242), MK_INT(1LL));
      V t_2 = heff_intAdd(v_j_242, MK_INT(1LL));
      V t_3 = v_t_247;
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2emangleW(a[0], a[1], a[2], a[3]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2eknownTags_str0, 3, (73, 110, 82));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eknownTags_str1, 6, (77, 107, 80, 97, 105, 114));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eknownTags_str2, 3, (73, 110, 76));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eknownTags_str3, 4, (74, 117, 115, 116));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eknownTags_str4, 7, (78, 111, 116, 104, 105, 110, 103));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eknownTags_str5, 4, (67, 111, 110, 115));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eknownTags_str6, 6, (77, 107, 85, 110, 105, 116));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eknownTags_str7, 5, (70, 97, 108, 115, 101));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eknownTags_str8, 3, (78, 105, 108));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eknownTags_str9, 4, (84, 114, 117, 101));

static V g_heff_2ecompile_2eemitc_2eknownTags_val;
static int g_heff_2ecompile_2eemitc_2eknownTags_st;
static V g_heff_2ecompile_2eemitc_2eknownTags_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str8), v_t_243})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str9), v_t_244});
}
V g_heff_2ecompile_2eemitc_2eknownTags_get(void) {
  if (g_heff_2ecompile_2eemitc_2eknownTags_st == 2) return g_heff_2ecompile_2eemitc_2eknownTags_val;
  if (g_heff_2ecompile_2eemitc_2eknownTags_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eemitc_2eknownTags_st = 1;
  g_heff_2ecompile_2eemitc_2eknownTags_val = heff_tr(g_heff_2ecompile_2eemitc_2eknownTags_init());
  g_heff_2ecompile_2eemitc_2eknownTags_st = 2;
  return g_heff_2ecompile_2eemitc_2eknownTags_val;
}
Clo g_heff_2ecompile_2eemitc_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x_240), heff_dup(v_y_242))) {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2eelemS(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etagsLbls_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2etagsLbls(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V t_0 = v_b_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_x1_240, 0);
    V v_as_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247 = heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_f_245, v_as_246})));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_247, v_t_248));
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x1_240, 1);
    V v_b_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2411, NTAG(TAG_Nil)});
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_a_2410, v_t_2413})));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2412, v_t_2414));
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_ls_2416 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2415)));
    V v_es_2417 = (g_list_2emap_24s1173914895x100384474(v_fs_2415));
    V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2417));
    V v_x2_2420 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2418, v_t_2419));
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_MkPair: {
      V v_ts_2421 = heff_field(v_x2_2420, 0);
      V v_ls2_2422 = heff_field(v_x2_2420, 1);
      V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){v_ts_2421, (g_prelude_2e_2b_2b(v_ls_2416, v_ls2_2422))});
    }
    default: return heff_nomatch(v_x2_2420);
    }
  }
  case TAG_EProj: {
    V v_e_2423 = heff_field(v_x1_240, 0);
    V v_l_2424 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 3);
    V v_x2_2426 = (g_heff_2ecompile_2eemitc_2etagsLbls(v_e_2423));
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_MkPair: {
      V v_ts_2427 = heff_field(v_x2_2426, 0);
      V v_ls2_2428 = heff_field(v_x2_2426, 1);
      V v_ru_24x2_2426_24MkPair = heff_take_reuse_n(v_x2_2426, 3ULL, 2);
      V v_t_2429 = heff_tag_at_n(v_ru_24x2_2426_24MkPair, TAG_Cons, 2, (V[]){v_l_2424, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2427, (g_prelude_2e_2b_2b(v_t_2429, v_ls2_2428))});
    }
    default: return heff_nomatch(v_x2_2426);
    }
  }
  case TAG_ETag: {
    V v_t_2430 = heff_field(v_x1_240, 0);
    V v_as_2431 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ETag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2432 = heff_tag_at_n(v_ru_24x1_240_24ETag, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2433 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2431));
    V v_x2_2434 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2432, v_t_2433));
    switch (heff_tag_of(v_x2_2434)) {
    case TAG_MkPair: {
      V v_ts2_2435 = heff_field(v_x2_2434, 0);
      V v_ls_2436 = heff_field(v_x2_2434, 1);
      V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
      V v_t_2437 = heff_tag_at_n(v_ru_24x2_2434_24MkPair, TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
      V v_t_2438 = (g_prelude_2e_2b_2b(v_t_2437, v_ts2_2435));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2438, v_ls_2436});
    }
    default: return heff_nomatch(v_x2_2434);
    }
  }
  case TAG_EMatch: {
    V v_s_2439 = heff_field(v_x1_240, 0);
    V v_arms_2440 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_ts_2441 = (g_list_2emap_24s1009200955x251267316(heff_dup(v_arms_2440)));
    V v_es_2442 = heff_tag_at_n(v_ru_24x1_240_24EMatch, TAG_Cons, 2, (V[]){v_s_2439, (g_list_2emap_24s60612435x257154841(v_arms_2440))});
    V v_t_2443 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2442));
    V v_x2_2445 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2443, v_t_2444));
    switch (heff_tag_of(v_x2_2445)) {
    case TAG_MkPair: {
      V v_ts2_2446 = heff_field(v_x2_2445, 0);
      V v_ls_2447 = heff_field(v_x2_2445, 1);
      V v_ru_24x2_2445_24MkPair = heff_take_reuse_n(v_x2_2445, 3ULL, 2);
      V v_t_2448 = (g_prelude_2e_2b_2b(v_ts_2441, v_ts2_2446));
      return heff_tag_at_n(v_ru_24x2_2445_24MkPair, TAG_MkPair, 2, (V[]){v_t_2448, v_ls_2447});
    }
    default: return heff_nomatch(v_x2_2445);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EPrimCall: {
    V v_as_2451 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EPrimCall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    V v_t_2452 = heff_tag_at_n(v_ru_24x1_240_24EPrimCall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2453 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2451));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2452, v_t_2453));
  }
  case TAG_ECall: {
    V v_as_2455 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    V v_t_2456 = heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2457 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2455));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2456, v_t_2457));
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFixed: {
    V v_ru_24x1_240_24EFixed = heff_take_reuse_n(v_x1_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24EFixed, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFix: {
    V v_ru_24x1_240_24EFix = heff_take_reuse_n(v_x1_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24EFix, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etagsLbls(a[0]);
}
Clo g_heff_2ecompile_2eemitc_2eidentAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eidentAt_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eidentAt(V v_text_240, V v_start_241, V v_i_242) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_242), heff_strLength(heff_dup(v_text_240)))) {
    V v_t_244 = (g_heff_2ecompile_2eemitc_2eisAlnum(heff_strCharCode(heff_dup(v_text_240), heff_dup(v_i_242))));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V t_0 = v_text_240;
      V t_1 = v_start_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_text_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
    case TAG_False: {
      if (heff_intEq_c(heff_strCharCode(heff_dup(v_text_240), heff_dup(v_i_242)), MK_INT(95LL))) {
        V t_0 = v_text_240;
        V t_1 = v_start_241;
        V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
        v_text_240 = t_0;
        v_start_241 = t_1;
        v_i_242 = t_2;
        goto top;
      } else {
        return heff_strSlice(v_text_240, v_start_241, v_i_242);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  } else {
    return heff_strSlice(v_text_240, v_start_241, v_i_242);
  }
}
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eidentAt(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2enamesInGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enamesInGo_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2enamesInGo(V v_pre_240, V v_text_241, V v_i_242, V v_acc_243) {
top: ;
  V v_t_244 = heff_strSlice(heff_dup(v_text_241), heff_dup(v_i_242), heff_strLength(heff_dup(v_text_241)));
  V v_t_245 = (g_prelude_2eindexFrom(heff_dup(v_pre_240), v_t_244, MK_INT(0LL)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_pre_240);
    heff_drop(v_text_241);
    heff_drop(v_i_242);
    return v_acc_243;
  }
  case TAG_Just: {
    V v_j_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_247 = heff_intAdd(heff_intAdd(heff_dup(v_i_242), heff_dup(v_j_246)), heff_strLength(heff_dup(v_pre_240)));
    V v_t_248 = heff_intAdd(heff_intAdd(heff_dup(v_i_242), heff_dup(v_j_246)), heff_strLength(heff_dup(v_pre_240)));
    V v_t_249 = heff_intAdd(heff_intAdd(v_i_242, v_j_246), heff_strLength(heff_dup(v_pre_240)));
    V v_t_2410 = (g_heff_2ecompile_2eemitc_2eidentAt(heff_dup(v_text_241), v_t_248, v_t_249));
    V t_0 = v_pre_240;
    V t_1 = v_text_241;
    V t_2 = v_t_247;
    V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_acc_243});
    v_pre_240 = t_0;
    v_text_241 = t_1;
    v_i_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ecompile_2eemitc_2enamesInGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2enamesInGo(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eemitc_2enumbered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enumbered_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2enumbered(V v_n_240, V v_x2_241, V v_m_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_x3_245 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_243), v_m_242));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      V v_t_246 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_243), heff_dup(v_n_240), v_m_242));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_t_246;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      v_m_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      V t_0 = v_n_240;
      V t_1 = v_xs_244;
      V t_2 = v_m_242;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      v_m_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2enumbered_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2enumbered(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
Clo g_heff_2ecompile_2eemitc_2ehashBelow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ehashBelow_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2ehashBelow(V v_t_240, V v_m_241, V v_i_242, V v_a_243) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_t_240)), heff_dup(v_i_242))) {
    heff_drop(v_t_240);
    heff_drop(v_m_241);
    heff_drop(v_i_242);
    return v_a_243;
  } else {
    V v_t_245 = heff_intAdd(heff_intMul(v_a_243, MK_INT(31LL)), heff_strCharCode(heff_dup(v_t_240), heff_dup(v_i_242)));
    V v_t_246 = heff_intMod(heff_intAdd(v_t_245, MK_INT(1LL)), heff_dup(v_m_241));
    V t_0 = v_t_240;
    V t_1 = v_m_241;
    V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
    V t_3 = v_t_246;
    v_t_240 = t_0;
    v_m_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  }
}
V g_heff_2ecompile_2eemitc_2ehashBelow_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ehashBelow(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eemitc_2eslotFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eslotFrom_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eslotFrom(V v_base_240, V v_m_241, V v_h_242, V v_taken_243) {
top: ;
  V v_x3_244 = (g_map_2elookup_24s1338854231x236594845(heff_intAdd(heff_dup(v_base_240), heff_dup(v_h_242)), v_taken_243));
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    return heff_intAdd(v_base_240, v_h_242);
  }
  case TAG_Just: {
    heff_take_n(v_x3_244, 0ULL, 1);
    V v_t_246 = heff_intMod(heff_intAdd(v_h_242, MK_INT(1LL)), heff_dup(v_m_241));
    V t_0 = v_base_240;
    V t_1 = v_m_241;
    V t_2 = v_t_246;
    V t_3 = v_taken_243;
    v_base_240 = t_0;
    v_m_241 = t_1;
    v_h_242 = t_2;
    v_taken_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2ecompile_2eemitc_2eslotFrom_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2eslotFrom(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
Clo g_heff_2ecompile_2eemitc_2ehashedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ehashedGo_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2ehashedGo(V v_base_240, V v_m_241, V v_x3_242, V v_names_243, V v_taken_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_base_240);
    heff_drop(v_m_241);
    heff_drop(v_taken_244);
    return v_names_243;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_xs_246 = heff_field(v_x3_242, 1);
    V v_x3_247 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_245), v_names_243));
    V v_t_249;
    switch (heff_tag_of(v_x3_247)) {
    case TAG_Nothing: {
      v_t_249 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_247, 0ULL, 1);
      v_t_249 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_247);
    }
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      V t_0 = v_base_240;
      V t_1 = v_m_241;
      V t_2 = v_xs_246;
      V t_3 = v_names_243;
      V t_4 = v_taken_244;
      v_base_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      v_names_243 = t_3;
      v_taken_244 = t_4;
      goto top;
    }
    case TAG_False: {
      V v_t_2410 = (g_heff_2ecompile_2eemitc_2ehashBelow(heff_dup(v_x_245), heff_dup(v_m_241), MK_INT(0LL), MK_INT(7LL)));
      V v_t_2411 = (g_heff_2ecompile_2eemitc_2eslotFrom(heff_dup(v_base_240), heff_dup(v_m_241), v_t_2410, v_taken_244));
      V v_t_2412 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_245), v_t_2411, v_names_243));
      V v_t_2413 = (g_heff_2ecompile_2eemitc_2ehashBelow(heff_dup(v_x_245), heff_dup(v_m_241), MK_INT(0LL), MK_INT(7LL)));
      V v_t_2414 = (g_heff_2ecompile_2eemitc_2eslotFrom(heff_dup(v_base_240), heff_dup(v_m_241), v_t_2413, v_taken_244));
      V v_t_2415 = (g_map_2einsert_24s1689409319x1710080871(v_t_2414, NTAG(TAG_MkUnit), v_taken_244));
      V t_0 = v_base_240;
      V t_1 = v_m_241;
      V t_2 = v_xs_246;
      V t_3 = v_t_2412;
      V t_4 = v_t_2415;
      v_base_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      v_names_243 = t_3;
      v_taken_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2ehashedGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2ehashedGo(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
Clo g_heff_2ecompile_2eemitc_2ewithKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ewithKnown_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ewithKnown(V v_x_240, V v_k_241, V v_ce_242) {
top: ;
  V v_t_243 = (g_map_2einsert_24s1341440536x470972936(v_x_240, v_k_241, heff_take_field(v_ce_242, 10)));
  return ({ V rv_10 = v_t_243; V rr_ = heff_rec_reuse_n(v_ce_242, 3071ULL, 12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes); heff_rfield(rr_, 10) = rv_10; rr_; });
}
V g_heff_2ecompile_2eemitc_2ewithKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ewithKnown(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2etraverseC_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2etraverseC_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etraverseC_lam0, 1, 0};
V g_heff_2ecompile_2eemitc_2etraverseC_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2etraverseC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etraverseC_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2etraverseC(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eemitc_2etraverseC_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etraverseC_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2etraverseC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etraverseC(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2etraverseC_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_heff_2ecompile_2eemitc_2etraverseC_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_apply(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2ecompile_2eemitc_2etraverseC(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_apply(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
Clo g_heff_2ecompile_2eemitc_2eunits8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eunits8_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eunits8(V v_c_240) {
top: ;
  if (heff_intLt_c(heff_dup(v_c_240), MK_INT(128LL))) {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_c_240, NTAG(TAG_Nil)});
  } else {
    if (heff_intLt_c(heff_dup(v_c_240), MK_INT(2048LL))) {
      V v_t_243 = heff_intDiv(heff_dup(v_c_240), MK_INT(64LL));
      V v_t_244 = heff_intMod(v_c_240, MK_INT(64LL));
      V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intAdd(MK_INT(128LL), v_t_244), NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_intAdd(MK_INT(192LL), v_t_243), v_t_245});
    } else {
      if (heff_intLt_c(heff_dup(v_c_240), MK_INT(65536LL))) {
        V v_t_247 = heff_intDiv(heff_dup(v_c_240), MK_INT(4096LL));
        V v_t_248 = heff_intDiv(heff_dup(v_c_240), MK_INT(64LL));
        V v_t_249 = heff_intMod(v_t_248, MK_INT(64LL));
        V v_t_2410 = heff_intMod(v_c_240, MK_INT(64LL));
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intAdd(MK_INT(128LL), v_t_2410), NTAG(TAG_Nil)});
        V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intAdd(MK_INT(128LL), v_t_249), v_t_2411});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_intAdd(MK_INT(224LL), v_t_247), v_t_2412});
      } else {
        V v_t_2413 = heff_intDiv(heff_dup(v_c_240), MK_INT(262144LL));
        V v_t_2414 = heff_intDiv(heff_dup(v_c_240), MK_INT(4096LL));
        V v_t_2415 = heff_intMod(v_t_2414, MK_INT(64LL));
        V v_t_2416 = heff_intDiv(heff_dup(v_c_240), MK_INT(64LL));
        V v_t_2417 = heff_intMod(v_t_2416, MK_INT(64LL));
        V v_t_2418 = heff_intMod(v_c_240, MK_INT(64LL));
        V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intAdd(MK_INT(128LL), v_t_2418), NTAG(TAG_Nil)});
        V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intAdd(MK_INT(128LL), v_t_2417), v_t_2419});
        V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intAdd(MK_INT(128LL), v_t_2415), v_t_2420});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_intAdd(MK_INT(240LL), v_t_2413), v_t_2421});
      }
    }
  }
}
V g_heff_2ecompile_2eemitc_2eunits8_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eunits8(a[0]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDefRunes_str0, 3, (40, 48, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDefRunes_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDefRunes_str2, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDefRunes_str3, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDefRunes_str4, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDefRunes_str5, 3, (40, 48, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDefRunes_str6, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDefRunes_str7, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDefRunes_str8, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDefRunes_str9, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDefRunes_str10, 9, (72, 69, 70, 70, 95, 83, 84, 82, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDefRunes_str11, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDefRunes_str12, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDefRunes_str13, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDefRunes_str14, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDefRunes_str15, 2, (41, 59));
Clo g_heff_2ecompile_2eemitc_2estrDefRunes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estrDefRunes_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2estrDefRunes(V v_name_240, V v_cs_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_cs_241)));
  V v_xs_243 = (g_list_2efoldl_24s313132209x118284909(MK_INT(65536LL), MK_INT(55296LL), MK_INT(65536LL), MK_INT(1024LL), MK_INT(56320LL), MK_INT(65536LL), MK_INT(1024LL), NTAG(TAG_Nil), v_t_242));
  V v_t_244 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_243; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
  V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_cs_241)));
  V v_t_246 = (g_list_2efoldl_24s313132209x118284909(MK_INT(65536LL), MK_INT(55296LL), MK_INT(65536LL), MK_INT(1024LL), MK_INT(56320LL), MK_INT(65536LL), MK_INT(1024LL), NTAG(TAG_Nil), v_t_245));
  V v_us_247 = (g_list_2emap(heff_dup(g_prelude_2eshowInt_get()), v_t_246));
  V v_t_2413;
  switch (heff_tag_of(v_us_247)) {
  case TAG_Nil: {
    v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2estrDefRunes_str0);
    break;
  }
  case TAG_Cons: {
    V v_t_2412;
    switch (heff_tag_of(v_us_247)) {
    case TAG_Nil: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2estrDefRunes_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2410 = heff_field(v_us_247, 0);
      V v_xs_2411 = heff_field(v_us_247, 1);
      heff_take_n(v_us_247, 3ULL, 2);
      v_t_2412 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2estrDefRunes_str2); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
      break;
    }
    default: heff_nomatch(v_us_247);
    }
    v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrDefRunes_str3), heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemitc_2estrDefRunes_str4)));
    break;
  }
  default: heff_nomatch(v_us_247);
  }
  V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_cs_241)));
  V v_xs_2415 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s1760706274x1469253109(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_t_2416 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2415; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
  V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_241));
  V v_t_2418 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1760706274x1469253109(a_0, a_1)); heff_drop(v_t_2417); r_; });
  V v_us_2419 = (g_list_2emap(heff_dup(g_prelude_2eshowInt_get()), v_t_2418));
  V v_t_2425;
  switch (heff_tag_of(v_us_2419)) {
  case TAG_Nil: {
    v_t_2425 = ((V)&g_heff_2ecompile_2eemitc_2estrDefRunes_str5);
    break;
  }
  case TAG_Cons: {
    V v_t_2424;
    switch (heff_tag_of(v_us_2419)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2estrDefRunes_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_us_2419, 0);
      V v_xs_2423 = heff_field(v_us_2419, 1);
      heff_take_n(v_us_2419, 3ULL, 2);
      v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2estrDefRunes_str7); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_us_2419);
    }
    v_t_2425 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrDefRunes_str8), heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemitc_2estrDefRunes_str9)));
    break;
  }
  default: heff_nomatch(v_us_2419);
  }
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrDefRunes_str10), heff_strAppend(v_name_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrDefRunes_str11), heff_strAppend(heff_intShow(v_t_244), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrDefRunes_str12), heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrDefRunes_str13), heff_strAppend(heff_intShow(v_t_2416), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrDefRunes_str14), heff_strAppend(v_t_2425, ((V)&g_heff_2ecompile_2eemitc_2estrDefRunes_str15)))))))))));
}
V g_heff_2ecompile_2eemitc_2estrDefRunes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2estrDefRunes(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDef_str0, 3, (40, 48, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDef_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDef_str2, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDef_str3, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDef_str4, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDef_str5, 10, (72, 69, 70, 70, 95, 83, 84, 82, 65, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDef_str6, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDef_str7, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrDef_str8, 2, (41, 59));
V g_heff_2ecompile_2eemitc_2estrDef_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2estrDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estrDef_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2estrDef(V v_name_240, V v_str_241) {
top: ;
  V v_t_242 = (g_heff_2ecompile_2eprims_2easciiFrom(heff_dup(v_str_241), MK_INT(0LL)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_t_243 = heff_intShow(heff_strLength(heff_dup(v_str_241)));
    V v_t_244 = heff_intSub(heff_strLength(heff_dup(v_str_241)), MK_INT(1LL));
    V v_t_245 = (g_list_2erange(MK_INT(0LL), v_t_244));
    V v_us_247 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2estrDef_lam0, 1, 1, (V[]){v_str_241}), v_t_245));
    V v_t_2413;
    switch (heff_tag_of(v_us_247)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2estrDef_str0);
      break;
    }
    case TAG_Cons: {
      V v_t_2412;
      switch (heff_tag_of(v_us_247)) {
      case TAG_Nil: {
        v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2estrDef_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_us_247, 0);
        V v_xs_2411 = heff_field(v_us_247, 1);
        heff_take_n(v_us_247, 3ULL, 2);
        v_t_2412 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2estrDef_str2); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
        break;
      }
      default: heff_nomatch(v_us_247);
      }
      v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrDef_str3), heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemitc_2estrDef_str4)));
      break;
    }
    default: heff_nomatch(v_us_247);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrDef_str5), heff_strAppend(v_name_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrDef_str6), heff_strAppend(v_t_243, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrDef_str7), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2estrDef_str8)))))));
  }
  case TAG_False: {
    V v_t_2414 = (g_list_2emap(heff_dup(g_rune_2etoInt_get()), heff_strRunes(v_str_241)));
    HEFF_LAST return g_heff_2ecompile_2eemitc_2estrDefRunes(v_name_240, v_t_2414);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eemitc_2estrDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2estrDef(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2estrDef_lam0(V self, V *args) {
  V v_i_246 = args[0];
  V v_str_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intShow(heff_strCharCode(v_str_241, v_i_246));
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrLit_str0, 5, (40, 40, 86, 41, 38));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrLit_str1, 4, (95, 115, 116, 114));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrLit_str2, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estrLit_str3, 4, (95, 115, 116, 114));
Clo g_heff_2ecompile_2eemitc_2estrLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estrLit_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2estrLit(V v_str_240, V v_s_241) {
top: ;
  V v_t_242 = heff_intShow(heff_dup(heff_rfield(v_s_241, 4)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str0), heff_strAppend(heff_dup(heff_rfield(v_s_241, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str1), heff_strAppend(v_t_242, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str2)))));
  V v_t_244 = heff_intAdd(heff_dup(heff_rfield(v_s_241, 4)), MK_INT(1LL));
  V v_t_245 = heff_intShow(heff_take_field(v_s_241, 4));
  V v_t_246 = heff_strAppend(heff_dup(heff_rfield(v_s_241, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str3), v_t_245));
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_s_241, 0)), (g_heff_2ecompile_2eemitc_2estrDef(v_t_246, v_str_240))});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_take_field(v_s_241, 5)});
  V v_t_249 = ({ V rv_4 = v_t_244; V rv_5 = v_t_248; V rr_ = heff_rec_reuse_n(v_s_241, 207ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims); heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_t_249});
}
V g_heff_2ecompile_2eemitc_2estrLit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2estrLit(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemitc_2eownHas_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eownHas_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eownHas(V v_o_240, V v_k_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_o_240);
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_o2_245 = heff_field(v_x31_243, 0);
      V v_k2_246 = heff_field(v_x31_243, 1);
      if (heff_strEq_c(heff_dup(v_o_240), heff_dup(v_o2_245))) {
        if (heff_strEq_c(heff_dup(v_k_241), heff_dup(v_k2_246))) {
          heff_drop(v_o_240);
          heff_drop(v_k_241);
          return NTAG(TAG_True);
        } else {
          V t_0 = v_o_240;
          V t_1 = v_k_241;
          V t_2 = v_rest_244;
          v_o_240 = t_0;
          v_k_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      } else {
        heff_drop(v_o_240);
        heff_drop(v_k_241);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2eownHas_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2eownHas(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2eshapeLit_str0, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eshapeLit_str1, 2, (95, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eshapeLit_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eshapeLit_str3, 2, (95, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eshapeLit_str4, 6, (115, 104, 97, 112, 101, 95));
Clo g_heff_2ecompile_2eemitc_2eshapeLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eshapeLit_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eshapeLit(V v_ls_240, V v_s_241) {
top: ;
  V v_x2_242 = (g_list_2emap_24s420582357x1720502382(heff_dup(v_ls_240)));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2eshapeLit_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eshapeLit_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_o_246 = heff_dup(heff_rfield(v_s_241, 0));
  V v_x2_247 = (g_list_2emap_24s420582357x1720502382(v_ls_240));
  V v_k_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_k_2410 = ((V)&g_heff_2ecompile_2eemitc_2eshapeLit_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_k_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eshapeLit_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_ps_2411 = heff_take_field(v_s_241, 6);
  V v_t_2412 = (g_heff_2ecompile_2eemitc_2eownHas(heff_dup(v_o_246), heff_dup(v_k_2410), v_ps_2411));
  V v_t_2413;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_True: {
    heff_drop(v_o_246);
    heff_drop(v_k_2410);
    v_t_2413 = v_ps_2411;
    break;
  }
  case TAG_False: {
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_o_246, v_k_2410}), v_ps_2411});
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  V v_t_2414 = ({ V rv_6 = v_t_2413; V rr_ = heff_rec_reuse_n(v_s_241, 191ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims); heff_rfield(rr_, 6) = rv_6; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eshapeLit_str4), v_t_245), v_t_2414});
}
V g_heff_2ecompile_2eemitc_2eshapeLit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eshapeLit(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprimLit_str0, 10, (40, 40, 86, 41, 38, 112, 114, 105, 109, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprimLit_str1, 5, (95, 99, 108, 111, 41));
Clo g_heff_2ecompile_2eemitc_2eprimLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprimLit_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eprimLit(V v_p_240, V v_s_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimLit_str0), heff_strAppend(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2eemitc_2eprimLit_str1)));
  V v_o_243 = heff_dup(heff_rfield(v_s_241, 0));
  V v_ps_244 = heff_take_field(v_s_241, 7);
  V v_t_245 = (g_heff_2ecompile_2eemitc_2eownHas(heff_dup(v_o_243), heff_dup(v_p_240), v_ps_244));
  V v_t_246;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_p_240);
    heff_drop(v_o_243);
    v_t_246 = v_ps_244;
    break;
  }
  case TAG_False: {
    v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_o_243, v_p_240}), v_ps_244});
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_247 = ({ V rv_7 = v_t_246; V rr_ = heff_rec_reuse_n(v_s_241, 127ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims); heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_t_247});
}
V g_heff_2ecompile_2eemitc_2eprimLit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eprimLit(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2enewLam_str0, 4, (95, 108, 97, 109));
Clo g_heff_2ecompile_2eemitc_2enewLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enewLam_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2enewLam(V v_s_240) {
top: ;
  V v_t_241 = heff_intShow(heff_dup(heff_rfield(v_s_240, 1)));
  V v_t_242 = heff_strAppend(heff_dup(heff_rfield(v_s_240, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enewLam_str0), v_t_241));
  V v_t_243 = heff_intAdd(heff_take_field(v_s_240, 1), MK_INT(1LL));
  V v_t_244 = ({ V rv_1 = v_t_243; V rr_ = heff_rec_reuse_n(v_s_240, 253ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims); heff_rfield(rr_, 1) = rv_1; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_t_244});
}
V g_heff_2ecompile_2eemitc_2enewLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2enewLam(a[0]);
}
Clo g_heff_2ecompile_2eemitc_2eaddLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eaddLam_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eaddLam(V v_proto_240, V v_def_241, V v_s_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_s_242, 0)), v_def_241});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_take_field(v_s_242, 2)});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_s_242, 0)), v_proto_240});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_take_field(v_s_242, 3)});
  V v_t_247 = ({ V rv_2 = v_t_244; V rv_3 = v_t_246; V rr_ = heff_rec_reuse_n(v_s_242, 243ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_247});
}
V g_heff_2ecompile_2eemitc_2eaddLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eaddLam(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2efvW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efvW_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2efvW(V v_bs_240, V v_ms_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_bs_240, v_ms_241});
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      V v_x_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V t_0 = v_bs_240;
      V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, v_ms_241});
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_xs_247 = heff_field(v_x31_243, 0);
      V v_b_248 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_249 = (g_prelude_2e_2b_2b(v_xs_247, v_bs_240));
      V t_0 = v_t_249;
      V t_1 = v_ms_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_248, v_rest_244});
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2410 = heff_field(v_x31_243, 0);
      V v_as_2411 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2410, (g_prelude_2e_2b_2b(v_as_2411, v_rest_244))});
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_t_2412;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_x_2413 = heff_field(v_x31_243, 0);
      V v_a_2414 = heff_field(v_x31_243, 1);
      V v_b_2415 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_t_2416 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2415, v_rest_244})});
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, v_bs_240});
      V t_1 = v_ms_241;
      V t_2 = v_t_2416;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2417 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2418 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2417, v_rest_244));
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_t_2418;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2419 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 3);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2419, v_rest_244});
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2423 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2424 = (g_prelude_2e_2b_2b(v_as_2423, v_rest_244));
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_t_2424;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2425 = heff_field(v_x31_243, 0);
      V v_arms_2426 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2426)));
      V v_t_2428 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2427; V r_ = (g_list_2efoldl_24s1530401830x609500251(a_0, a_1)); heff_drop(v_t_2427); r_; });
      V v_t_2429 = (g_prelude_2e_2b_2b(v_t_2428, v_bs_240));
      V v_t_2430 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2425, (g_heff_2ecompile_2eir_2epushArms(v_arms_2426, v_rest_244))});
      V t_0 = v_t_2429;
      V t_1 = v_ms_241;
      V t_2 = v_t_2430;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2433 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2434 = (g_prelude_2e_2b_2b(v_as_2433, v_rest_244));
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_t_2434;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2436 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2437 = (g_prelude_2e_2b_2b(v_as_2436, v_rest_244));
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_t_2437;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2efvW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2efvW(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2efreeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efreeGo_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2efreeGo(V v_bs_240, V v_seen_241, V v_x3_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_seen_241);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
  }
  case TAG_Cons: {
    V v_v_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x3_246 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_v_244), v_bs_240));
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      V v_x3_247 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_v_244), v_seen_241));
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        V v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_v_244), NTAG(TAG_MkUnit), v_seen_241));
        V t_0 = v_bs_240;
        V t_1 = v_t_248;
        V t_2 = v_vs_245;
        V t_3 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_v_244, v_acc_243});
        v_bs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      }
      case TAG_Just: {
        heff_take_n(v_x3_247, 0ULL, 1);
        heff_drop(v_v_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_seen_241;
        V t_2 = v_vs_245;
        V t_3 = v_acc_243;
        v_bs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_x3_247);
      }
    }
    case TAG_Just: {
      heff_take_n(v_x3_246, 0ULL, 1);
      heff_drop(v_v_244);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_seen_241;
      V t_2 = v_vs_245;
      V t_3 = v_acc_243;
      v_bs_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2efreeGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2efreeGo(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
Clo g_heff_2ecompile_2eemitc_2efreeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efreeOf_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2efreeOf(V v_xs_240, V v_b_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_241, NTAG(TAG_Nil)});
  V v_x2_243 = (g_heff_2ecompile_2eemitc_2efvW(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_242));
  switch (heff_tag_of(v_x2_243)) {
  case TAG_MkPair: {
    V v_bs_244 = heff_field(v_x2_243, 0);
    V v_ms_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    V v_bs_246 = (g_prelude_2e_2b_2b(v_xs_240, v_bs_244));
    V v_ms_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_245));
    V v_t_248 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_246; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_bs_246); r_; });
    return ({ V a_0 = v_t_248; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_ms_247; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eemitc_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_248); r_; });
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ecompile_2eemitc_2efreeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2efreeOf(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemitc_2eshapedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eshapedOf_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eshapedOf(V v_e_240, V v_sh_241, V v_acc_242) {
top: ;
  V v_x1_2433;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24EVar = heff_take_reuse_n(v_e_240, 1ULL, 1);
    v_x1_2433 = heff_tag_at_n(v_ru_24e_240_24EVar, TAG_Just, 1, (V[]){v_x_243});
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    v_x1_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_e_240, 0ULL, 2);
    v_x1_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    v_x1_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_e_240, 0ULL, 3);
    v_x1_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 1);
    v_x1_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 3);
    v_x1_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_e_240, 0ULL, 2);
    v_x1_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_e_240, 0ULL, 2);
    v_x1_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    v_x1_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_240, 0ULL, 2);
    v_x1_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_e_240, 0ULL, 2);
    v_x1_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    v_x1_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat: {
    heff_take_n(v_e_240, 0ULL, 1);
    v_x1_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    v_x1_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    v_x1_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat32: {
    heff_take_n(v_e_240, 0ULL, 1);
    v_x1_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EAbandon: {
    v_x1_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    v_x1_2433 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_e_240);
  }
  switch (heff_tag_of(v_x1_2433)) {
  case TAG_Nothing: {
    heff_drop(v_sh_241);
    return v_acc_242;
  }
  case TAG_Just: {
    V v_x_2434 = heff_field(v_x1_2433, 0);
    V v_ru_24x1_2433_24Just = heff_take_reuse_n(v_x1_2433, 1ULL, 1);
    switch (heff_tag_of(v_sh_241)) {
    case TAG_Nil: {
      heff_drop(v_x_2434);
      heff_drop_cell(v_ru_24x1_2433_24Just, 1);
      return v_acc_242;
    }
    case TAG_Cons: {
      V v_t_2437 = heff_tag_at_n(v_ru_24x1_2433_24Just, TAG_KnownRec, 1, (V[]){({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_sh_241; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop_tag(v_sh_241, 2); r_; })});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2434, v_t_2437}), v_acc_242});
    }
    default: return heff_nomatch(v_sh_241);
    }
  }
  default: return heff_nomatch(v_x1_2433);
  }
}
V g_heff_2ecompile_2eemitc_2eshapedOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eshapedOf(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2eshapedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eshapedGo_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eshapedGo(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_acc_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = v_acc_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, v_rest_243});
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x21_242, 0);
      V v_as_249 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_248, (g_prelude_2e_2b_2b(v_as_249, v_rest_243))});
      V t_0 = v_acc_240;
      V t_1 = v_t_2410;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2412 = heff_field(v_x21_242, 1);
      V v_b_2413 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2413, v_rest_243})});
      V t_0 = v_acc_240;
      V t_1 = v_t_2414;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2416 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2415, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_2416;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2417 = heff_field(v_x21_242, 0);
      V v_sh_2419 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_2420 = (g_heff_2ecompile_2eemitc_2eshapedOf(heff_dup(v_e_2417), v_sh_2419, v_acc_240));
      V t_0 = v_t_2420;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2417, v_rest_243});
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2422 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2423 = (g_prelude_2e_2b_2b(v_as_2422, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_2423;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2424 = heff_field(v_x21_242, 0);
      V v_arms_2425 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2426 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2424, (g_heff_2ecompile_2eir_2epushArms(v_arms_2425, v_rest_243))});
      V t_0 = v_acc_240;
      V t_1 = v_t_2426;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2429 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2430 = (g_prelude_2e_2b_2b(v_as_2429, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_2430;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2432 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2433 = (g_prelude_2e_2b_2b(v_as_2432, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_2433;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eshapedGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eshapedGo(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2evarUse_str0, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evarUse_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evarUse_str2, 9, (104, 101, 102, 102, 95, 100, 117, 112, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evarUse_str3, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evarUse_str4, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evarUse_str5, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evarUse_str6, 9, (104, 101, 102, 102, 95, 100, 117, 112, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evarUse_str7, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evarUse_str8, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evarUse_str9, 0, (0));
Clo g_heff_2ecompile_2eemitc_2evarUse_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2evarUse_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2evarUse(V v_lent_240, V v_live_241, V v_x_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eemitc_2eelemS(heff_dup(v_x_242), v_live_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evarUse_str0), (g_heff_2ecompile_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evarUse_str1))));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evarUse_str2), heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2evarUse_str3)));
  }
  case TAG_False: {
    V v_t_245 = (g_heff_2ecompile_2eemitc_2eelemS(heff_dup(v_x_242), v_lent_240));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evarUse_str4), (g_heff_2ecompile_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evarUse_str5))));
      return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evarUse_str6), heff_strAppend(v_t_246, ((V)&g_heff_2ecompile_2eemitc_2evarUse_str7)));
    }
    case TAG_False: {
      return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evarUse_str8), (g_heff_2ecompile_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evarUse_str9))));
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2eemitc_2evarUse_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2evarUse(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str0, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str2, 14, (104, 101, 102, 102, 95, 100, 114, 111, 112, 95, 116, 97, 103, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str3, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str4, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str5, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str6, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str7, 15, (104, 101, 102, 102, 95, 100, 114, 111, 112, 95, 99, 101, 108, 108, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str8, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str9, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str10, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str11, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str12, 14, (104, 101, 102, 102, 95, 100, 114, 111, 112, 95, 114, 101, 99, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str13, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str14, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str15, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str16, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str17, 14, (104, 101, 102, 102, 95, 100, 114, 111, 112, 95, 99, 108, 111, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str18, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropAs_str19, 2, (41, 59));
Clo g_heff_2ecompile_2eemitc_2edropAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2edropAs_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2edropAs(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_KnownTag: {
    V v_n_242 = heff_field(v_x2_241, 0);
    if (heff_intEq_c(heff_dup(v_n_242), MK_INT(0LL))) {
      heff_drop(v_x_240);
      return NTAG(TAG_Nil);
    } else {
      V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str0), (g_heff_2ecompile_2eemitc_2emangleW(v_x_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str1))));
      V v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str2), heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str3), heff_strAppend(heff_intShow(heff_dup(v_n_242)), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str4)))));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    }
  }
  case TAG_KnownCell: {
    V v_n_246 = heff_field(v_x2_241, 0);
    V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str5), (g_heff_2ecompile_2eemitc_2emangleW(v_x_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str6))));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str7), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str8), heff_strAppend(heff_intShow(heff_dup(v_n_246)), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str9)))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  }
  case TAG_KnownRec: {
    V v_n_249 = heff_field(v_x2_241, 0);
    V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str10), (g_heff_2ecompile_2eemitc_2emangleW(v_x_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str11))));
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str12), heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str13), heff_strAppend(heff_intShow(heff_dup(v_n_249)), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str14)))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  }
  case TAG_KnownClo: {
    V v_n_2412 = heff_field(v_x2_241, 0);
    if (heff_intEq_c(heff_dup(v_n_2412), MK_INT(0LL))) {
      heff_drop(v_x_240);
      return NTAG(TAG_Nil);
    } else {
      V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str15), (g_heff_2ecompile_2eemitc_2emangleW(v_x_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str16))));
      V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str17), heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str18), heff_strAppend(heff_intShow(heff_dup(v_n_2412)), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str19)))));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2edropAs(a[0], a[1]); heff_drop(a[1]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropsIn_str0, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropsIn_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropsIn_str2, 10, (104, 101, 102, 102, 95, 100, 114, 111, 112, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edropsIn_str3, 2, (41, 59));
V g_heff_2ecompile_2eemitc_2edropsIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2edropsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2edropsIn_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2edropsIn(V v_ce_240, V v_xs_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_241));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2edropsIn_lam0, 2, 1, (V[]){v_ce_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
}
V g_heff_2ecompile_2eemitc_2edropsIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2edropsIn(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2edropsIn_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_245 = ({ V a_0 = heff_dup(v_x_244); V b_1 = heff_get_n(v_ce_240, 10, 12); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_249;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nothing: {
    V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropsIn_str0), (g_heff_2ecompile_2eemitc_2emangleW(v_x_244, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edropsIn_str1))));
    V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropsIn_str2), heff_strAppend(v_t_246, ((V)&g_heff_2ecompile_2eemitc_2edropsIn_str3)));
    v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_k_248 = heff_field(v_x2_245, 0);
    heff_take_n(v_x2_245, 1ULL, 1);
    v_t_249 = ({ V a_0 = v_x_244; V a_1 = v_k_248; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_k_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  return (g_prelude_2e_2b_2b(v_t_249, v_acc_243));
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2efixedLit_str0, 7, (77, 75, 95, 73, 78, 84, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efixedLit_str1, 3, (76, 76, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efixedLit_str2, 10, (72, 69, 70, 70, 95, 66, 73, 71, 40, 34));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efixedLit_str3, 2, (34, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efixedLit_str4, 10, (72, 69, 70, 70, 95, 66, 73, 71, 40, 34));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efixedLit_str5, 2, (34, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efixedLit_str6, 7, (77, 75, 95, 73, 78, 84, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efixedLit_str7, 3, (76, 76, 41));
Clo g_heff_2ecompile_2eemitc_2efixedLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efixedLit_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2efixedLit(V v_w_240, V v_n_241) {
top: ;
  V v_t_242;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_242 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_242 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_242 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_242 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_242 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_242 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_242 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_242 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_242 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  if (heff_intEq_c(v_t_242, MK_INT(64LL))) {
    if (heff_intLt_c(heff_dup(v_n_241), HEFF_BIG("4611686018427387904"))) {
      if (heff_intLe_c(MK_INT(-4611686018427387904LL), heff_dup(v_n_241))) {
        return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedLit_str0), heff_strAppend(heff_intShow(v_n_241), ((V)&g_heff_2ecompile_2eemitc_2efixedLit_str1)));
      } else {
        return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedLit_str2), heff_strAppend(heff_intShow(v_n_241), ((V)&g_heff_2ecompile_2eemitc_2efixedLit_str3)));
      }
    } else {
      return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedLit_str4), heff_strAppend(heff_intShow(v_n_241), ((V)&g_heff_2ecompile_2eemitc_2efixedLit_str5)));
    }
  } else {
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedLit_str6), heff_strAppend(heff_intShow(v_n_241), ((V)&g_heff_2ecompile_2eemitc_2efixedLit_str7)));
  }
}
V g_heff_2ecompile_2eemitc_2efixedLit_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2efixedLit(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2ecompile_2eemitc_2eelemI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eelemI_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eelemI(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_j_242 = heff_field(v_x2_241, 0);
    V v_js_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(v_i_240), heff_dup(v_j_242))) {
      heff_drop(v_i_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_i_240;
      V t_1 = v_js_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eelemI_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2eelemI(a[0], a[1]); heff_drop(a[1]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2elentVar_str0, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elentVar_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elentVar_str2, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elentVar_str3, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elentVar_str4, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elentVar_str5, 0, (0));
Clo g_heff_2ecompile_2eemitc_2elentVar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elentVar_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2elentVar(V v_ce_240, V v_live_241, V v_x_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eemitc_2eelemS(heff_dup(v_x_242), v_live_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop_rec(v_ce_240, 12);
    V v_v_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elentVar_str0), (g_heff_2ecompile_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2elentVar_str1))));
    return heff_rec_n(3, shape_arg__pre__post, (V[]){v_v_244, NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_False: {
    V v_t_245 = (g_heff_2ecompile_2eemitc_2eelemS(heff_dup(v_x_242), heff_rfield(v_ce_240, 8)));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop_rec(v_ce_240, 12);
      V v_v_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elentVar_str2), (g_heff_2ecompile_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2elentVar_str3))));
      return heff_rec_n(3, shape_arg__pre__post, (V[]){v_v_246, NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_False: {
      V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elentVar_str4), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_x_242), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2elentVar_str5))));
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
      V v_t_249 = (g_heff_2ecompile_2eemitc_2edropsIn(v_ce_240, v_t_248));
      return heff_rec_n(3, shape_arg__pre__post, (V[]){v_t_247, NTAG(TAG_Nil), v_t_249});
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2eemitc_2elentVar_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2elentVar(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
Clo g_heff_2ecompile_2eemitc_2eindexIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eindexIn_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eindexIn(V v_l_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_ks_244 = heff_field(v_x3_242, 1);
    if (heff_strEq_c(heff_dup(v_l_240), heff_dup(v_k_243))) {
      heff_drop(v_l_240);
      return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
    } else {
      V t_0 = v_l_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_ks_244;
      v_l_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2eindexIn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2eindexIn(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLent_str0, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLent_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLent_str2, 12, (104, 101, 102, 102, 95, 114, 102, 105, 101, 108, 100, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLent_str3, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLent_str4, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLent_str5, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLent_str6, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLent_str7, 12, (104, 101, 102, 102, 95, 114, 102, 105, 101, 108, 100, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLent_str8, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLent_str9, 1, (41));
Clo g_heff_2ecompile_2eemitc_2efieldLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efieldLent_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2efieldLent(V v_ce_240, V v_after_241, V v_x_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ce_240, 12);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_i_244 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Just = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_t_245 = (g_heff_2ecompile_2eemitc_2eelemS(heff_dup(v_x_242), v_after_241));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop_rec(v_ce_240, 12);
      V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLent_str0), (g_heff_2ecompile_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efieldLent_str1))));
      V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLent_str2), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLent_str3), heff_strAppend(heff_intShow(v_i_244), ((V)&g_heff_2ecompile_2eemitc_2efieldLent_str4)))));
      return heff_tag_at_n(v_ru_24x4_243_24Just, TAG_Just, 1, (V[]){v_t_247});
    }
    case TAG_False: {
      V v_t_248 = ({ V a_0 = heff_dup(v_x_242); V b_1 = heff_get_n(v_ce_240, 8, 12); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLent_str5), (g_heff_2ecompile_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efieldLent_str6))));
        V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLent_str7), heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLent_str8), heff_strAppend(heff_intShow(v_i_244), ((V)&g_heff_2ecompile_2eemitc_2efieldLent_str9)))));
        return heff_tag_at_n(v_ru_24x4_243_24Just, TAG_Just, 1, (V[]){v_t_2410});
      }
      case TAG_False: {
        heff_drop(v_x_242);
        heff_drop(v_i_244);
        heff_drop_cell(v_ru_24x4_243_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2efieldLent_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2efieldLent(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
Clo g_heff_2ecompile_2eemitc_2elentField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elentField_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2elentField(V v_ce_240, V v_after_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    V v_e_2413 = heff_field(v_x3_242, 0);
    V v_l_2414 = heff_field(v_x3_242, 1);
    V v_sh_2415 = heff_field(v_x3_242, 2);
    V v_x3_2446;
    switch (heff_tag_of(v_e_2413)) {
    case TAG_EVar: {
      V v_x_2416 = heff_field(v_e_2413, 0);
      v_x3_2446 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2416)});
      break;
    }
    case TAG_EGlobal: {
      v_x3_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELam: {
      v_x3_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EApp: {
      v_x3_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELet: {
      v_x3_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ERecord: {
      v_x3_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EProj: {
      v_x3_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ETag: {
      v_x3_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EMatch: {
      v_x3_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrim: {
      v_x3_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrimCall: {
      v_x3_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ECall: {
      v_x3_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EInt: {
      v_x3_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat: {
      v_x3_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EStr: {
      v_x3_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFixed: {
      v_x3_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat32: {
      v_x3_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EAbandon: {
      v_x3_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFix: {
      v_x3_2446 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_e_2413);
    }
    V v_i_2447 = (g_heff_2ecompile_2eemitc_2eindexIn(heff_dup(v_l_2414), MK_INT(0LL), v_sh_2415));
    switch (heff_tag_of(v_x3_2446)) {
    case TAG_Nothing: {
      heff_drop(v_ce_240);
      heff_drop(v_i_2447);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x_2448 = heff_field(v_x3_2446, 0);
      heff_take_n(v_x3_2446, 1ULL, 1);
      return (g_heff_2ecompile_2eemitc_2efieldLent(v_ce_240, v_after_241, v_x_2448, v_i_2447));
    }
    default: return heff_nomatch(v_x3_2446);
    }
  }
  case TAG_ETag: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2elentField_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2elentField(a[0], a[1], a[2]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str0, 8, (104, 101, 102, 102, 95, 116, 114, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str1, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str2, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str3, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str4, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str5, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str6, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str7, 2, (41, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str8, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str9, 1, (32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str10, 8, (104, 101, 102, 102, 95, 116, 114, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str11, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str12, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str13, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str14, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str15, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str16, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str17, 1, (32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str18, 3, (40, 123, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str19, 8, (32, 86, 32, 114, 95, 32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str20, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str21, 4, (41, 41, 59, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecallText_str22, 7, (32, 114, 95, 59, 32, 125, 41));
Clo g_heff_2ecompile_2eemitc_2ecallText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecallText_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ecallText(V v_g_240, V v_tr_241, V v_ls_242) {
top: ;
  V v_t_243 = (g_list_2eall_24s607638492x847921129(v_ls_242));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_t_244;
    switch (heff_tag_of(v_tr_241)) {
    case TAG_True: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2ecallText_str0);
      break;
    }
    case TAG_False: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2ecallText_str1);
      break;
    }
    default: heff_nomatch(v_tr_241);
    }
    V v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallText_str2), (g_heff_2ecompile_2eemitc_2emangleW(v_g_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ecallText_str3))));
    V v_x2_246 = (g_list_2emap_24s1198759183x473355350(v_ls_242));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2ecallText_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallText_str5); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    return heff_strAppend(v_t_244, heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallText_str6), heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2ecallText_str7)))));
  }
  case TAG_False: {
    V v_t_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ls_242));
    V v_t_2411 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2410, MK_INT(1LL))));
    V v_ordered_2412 = (g_list_2ezipWith_24s763642811x1204809256(v_ls_242, v_t_2411));
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ordered_2412)));
    V v_x2_2414 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2413; V r_ = (g_list_2efoldl_24s348322209x75032364(a_0, a_1)); heff_drop(v_t_2413); r_; });
    V v_t_2417;
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_heff_2ecompile_2eemitc_2ecallText_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      v_t_2417 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallText_str9); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2414);
    }
    V v_t_2418;
    switch (heff_tag_of(v_tr_241)) {
    case TAG_True: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2ecallText_str10);
      break;
    }
    case TAG_False: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2ecallText_str11);
      break;
    }
    default: heff_nomatch(v_tr_241);
    }
    V v_t_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallText_str12), (g_heff_2ecompile_2eemitc_2emangleW(v_g_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ecallText_str13))));
    V v_x2_2420 = (g_list_2emap_24s1198759183x473355350(heff_dup(v_ordered_2412)));
    V v_t_2423;
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_Nil: {
      v_t_2423 = ((V)&g_heff_2ecompile_2eemitc_2ecallText_str14);
      break;
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_xs_2422 = heff_field(v_x2_2420, 1);
      heff_take_n(v_x2_2420, 3ULL, 2);
      v_t_2423 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallText_str15); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2420);
    }
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ordered_2412));
    V v_x2_2425 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2424; V r_ = (g_list_2efoldl_24s449727021x365548005(a_0, a_1)); heff_drop(v_t_2424); r_; });
    V v_t_2428;
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_Nil: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2ecallText_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_xs_2427 = heff_field(v_x2_2425, 1);
      heff_take_n(v_x2_2425, 3ULL, 2);
      v_t_2428 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallText_str17); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2425);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallText_str18), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallText_str19), heff_strAppend(v_t_2418, heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallText_str20), heff_strAppend(v_t_2423, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallText_str21), heff_strAppend(v_t_2428, ((V)&g_heff_2ecompile_2eemitc_2ecallText_str22))))))))));
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2eemitc_2ecallText_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2ecallText(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str0, 9, (115, 116, 97, 116, 105, 99, 32, 86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str1, 19, (40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 114, 103, 115, 41, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str2, 4, (32, 32, 86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str3, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str4, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str5, 8, (32, 61, 32, 97, 114, 103, 115, 91));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str6, 2, (93, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str7, 4, (32, 32, 86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str8, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str9, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str10, 18, (32, 61, 32, 104, 101, 102, 102, 95, 101, 110, 118, 40, 115, 101, 108, 102, 41, 91));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str11, 2, (93, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str12, 22, (32, 32, 104, 101, 102, 102, 95, 99, 108, 111, 95, 116, 97, 107, 101, 40, 115, 101, 108, 102, 44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str13, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str14, 10, (104, 101, 102, 102, 95, 100, 114, 111, 112, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str15, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str16, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str17, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str18, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str19, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamLines_str20, 1, (125));
Clo g_heff_2ecompile_2eemitc_2elamLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elamLines_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2elamLines(V v_k_240, V v_xs_241, V v_fv_242, V v_dead_243, V v_body_244) {
top: ;
  V v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamLines_str0), heff_strAppend(v_k_240, ((V)&g_heff_2ecompile_2eemitc_2elamLines_str1)));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_t_248 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_247, MK_INT(1LL))));
  V v_t_249 = (g_list_2ezipWith_24s203264781x503274820(((V)&g_heff_2ecompile_2eemitc_2elamLines_str2), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str3), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str4), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str5), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str6), v_xs_241, v_t_248));
  V v_t_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_fv_242));
  V v_t_2411 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2410, MK_INT(1LL))));
  V v_t_2412 = (g_list_2ezipWith_24s203264781x503274820(((V)&g_heff_2ecompile_2eemitc_2elamLines_str7), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str8), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str9), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str10), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str11), heff_dup(v_fv_242), v_t_2411));
  V v_t_2417;
  switch (heff_tag_of(v_fv_242)) {
  case TAG_Nil: {
    v_t_2417 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fv_242; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop_tag(v_fv_242, 2); r_; });
    V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamLines_str12), heff_strAppend(heff_intShow(v_t_2415), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str13)));
    v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_fv_242);
  }
  V v_t_2418 = (g_list_2emap_24s1196049889x1646679775(((V)&g_heff_2ecompile_2eemitc_2elamLines_str14), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str15), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str16), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str17), v_dead_243));
  V v_t_2419 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2ecompile_2eemitc_2elamLines_str18), v_t_2418));
  V v_t_2420 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2ecompile_2eemitc_2elamLines_str19), v_body_244));
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elamLines_str20), NTAG(TAG_Nil)});
  V v_t_2422 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2421));
  V v_t_2423 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2422));
  V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2423));
  V v_t_2425 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2424));
  V v_t_2426 = (g_prelude_2e_2b_2b(v_t_249, v_t_2425));
  return (g_prelude_2e_2b_2b(v_t_246, v_t_2426));
}
V g_heff_2ecompile_2eemitc_2elamLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2elamLines(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereusePrim_str0, 6, (36, 114, 101, 117, 115, 101));

static V g_heff_2ecompile_2eemitc_2ereusePrim_val;
static int g_heff_2ecompile_2eemitc_2ereusePrim_st;
static V g_heff_2ecompile_2eemitc_2ereusePrim_init(void) {
  return ((V)&g_heff_2ecompile_2eemitc_2ereusePrim_str0);
}
V g_heff_2ecompile_2eemitc_2ereusePrim_get(void) {
  if (g_heff_2ecompile_2eemitc_2ereusePrim_st == 2) return g_heff_2ecompile_2eemitc_2ereusePrim_val;
  if (g_heff_2ecompile_2eemitc_2ereusePrim_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eemitc_2ereusePrim_st = 1;
  g_heff_2ecompile_2eemitc_2ereusePrim_val = heff_tr(g_heff_2ecompile_2eemitc_2ereusePrim_init());
  g_heff_2ecompile_2eemitc_2ereusePrim_st = 2;
  return g_heff_2ecompile_2eemitc_2ereusePrim_val;
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2etakeVarIn_str0, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2etakeVarIn_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2etakeVarIn_str2, 16, (104, 101, 102, 102, 95, 116, 97, 107, 101, 95, 102, 105, 101, 108, 100, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2etakeVarIn_str3, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2etakeVarIn_str4, 1, (41));
V g_heff_2ecompile_2eemitc_2etakeVarIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2etakeVarIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etakeVarIn_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2etakeVarIn(V v_ts_240, V v_live_241, V v_x3_242, V v_l_243, V v_i_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_l_243);
    heff_drop(v_i_244);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_246 = (g_heff_2ecompile_2eemitc_2eelemS(heff_dup(v_x_245), v_live_241));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V v_t_2415 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eemitc_2etakeVarIn_lam0, 1, 2, (V[]){heff_dup(v_x_245), v_l_243}), v_ts_240));
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etakeVarIn_str0), (g_heff_2ecompile_2eemitc_2emangleW(v_x_245, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etakeVarIn_str1))));
        V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etakeVarIn_str2), heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etakeVarIn_str3), heff_strAppend(heff_intShow(v_i_244), ((V)&g_heff_2ecompile_2eemitc_2etakeVarIn_str4)))));
        return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_t_2417});
      }
      case TAG_False: {
        heff_drop(v_i_244);
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    case TAG_False: {
      heff_drop(v_l_243);
      heff_drop(v_i_244);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2etakeVarIn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2etakeVarIn(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2ecompile_2eemitc_2etakeVarIn_lam0(V self, V *args) {
  V v_p_247 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_l_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410;
  switch (heff_tag_of(v_p_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_dup(heff_field(v_p_247, 0));
    v_t_2410 = v_x_248;
    break;
  }
  default: heff_nomatch(v_p_247);
  }
  if (heff_strEq_c(v_t_2410, v_x_245)) {
    V v_t_2414;
    switch (heff_tag_of(v_p_247)) {
    case TAG_MkPair: {
      V v_y_2413 = heff_field(v_p_247, 1);
      heff_take_n(v_p_247, 2ULL, 2);
      v_t_2414 = v_y_2413;
      break;
    }
    default: heff_nomatch(v_p_247);
    }
    return heff_strEq(v_t_2414, v_l_243);
  } else {
    heff_drop(v_p_247);
    heff_drop(v_l_243);
    return NTAG(TAG_False);
  }
}
Clo g_heff_2ecompile_2eemitc_2esameS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2esameS_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2esameS(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c(heff_dup(v_x_244), heff_dup(v_y_246))) {
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2esameS_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2esameS(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2ecompile_2eemitc_2ekeptFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ekeptFrom_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2ekeptFrom(V v_ls_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_l_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_EVar: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      V v_e_2414 = heff_field(v_x22_243, 0);
      V v_l2_2415 = heff_field(v_x22_243, 1);
      V v_sh_2416 = heff_field(v_x22_243, 2);
      if (heff_strEq_c(heff_dup(v_l_242), heff_dup(v_l2_2415))) {
        V v_t_2418 = (g_heff_2ecompile_2eemitc_2esameS(v_ls_240, v_sh_2416));
        switch (heff_tag_of(v_t_2418)) {
        case TAG_True: {
          switch (heff_tag_of(v_e_2414)) {
          case TAG_EVar: {
            V v_x_2419 = heff_field(v_e_2414, 0);
            return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2419)});
          }
          case TAG_EGlobal: {
            return NTAG(TAG_Nothing);
          }
          case TAG_ELam: {
            return NTAG(TAG_Nothing);
          }
          case TAG_EApp: {
            return NTAG(TAG_Nothing);
          }
          case TAG_ELet: {
            return NTAG(TAG_Nothing);
          }
          case TAG_ERecord: {
            return NTAG(TAG_Nothing);
          }
          case TAG_EProj: {
            return NTAG(TAG_Nothing);
          }
          case TAG_ETag: {
            return NTAG(TAG_Nothing);
          }
          case TAG_EMatch: {
            return NTAG(TAG_Nothing);
          }
          case TAG_EPrim: {
            return NTAG(TAG_Nothing);
          }
          case TAG_EPrimCall: {
            return NTAG(TAG_Nothing);
          }
          case TAG_ECall: {
            return NTAG(TAG_Nothing);
          }
          case TAG_EInt: {
            return NTAG(TAG_Nothing);
          }
          case TAG_EFloat: {
            return NTAG(TAG_Nothing);
          }
          case TAG_EStr: {
            return NTAG(TAG_Nothing);
          }
          case TAG_EFixed: {
            return NTAG(TAG_Nothing);
          }
          case TAG_EFloat32: {
            return NTAG(TAG_Nothing);
          }
          case TAG_EAbandon: {
            return NTAG(TAG_Nothing);
          }
          case TAG_EFix: {
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_e_2414);
          }
        }
        case TAG_False: {
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_t_2418);
        }
      } else {
        return NTAG(TAG_Nothing);
      }
    }
    case TAG_ETag: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2ekeptFrom_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2ekeptFrom(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2ecompile_2eemitc_2ejustsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ejustsOf_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2ejustsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2ecompile_2eemitc_2ejustsOf(v_rest_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2ejustsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ejustsOf(a[0]);
}
V g_heff_2ecompile_2eemitc_2eupdatedIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eupdatedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eupdatedIn_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eupdatedIn(V v_ce_240, V v_live_241, V v_ls_242, V v_fs_243) {
top: ;
  V v_a_244 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_fs_243));
  if (heff_intLt_c(MK_INT(62LL), v_a_244)) {
    heff_drop_rec(v_ce_240, 12);
    heff_drop(v_ls_242);
    heff_drop(v_fs_243);
    return NTAG(TAG_Nothing);
  } else {
    V v_t_246 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2ekeptFrom_clo), 1, (V[]){v_ls_242}));
    V v_t_247 = (g_list_2emap(v_t_246, v_fs_243));
    V v_t_248 = (g_heff_2ecompile_2eemitc_2ejustsOf(v_t_247));
    V v_x1_2413 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2eupdatedIn_lam0, 1, 2, (V[]){v_ce_240, heff_dup(v_live_241)}), v_t_248));
    switch (heff_tag_of(v_x1_2413)) {
    case TAG_Nil: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x1_2413, 0);
      heff_take_n(v_x1_2413, 1ULL, 2);
      return heff_tag_n(TAG_Just, 1, (V[]){v_x_2414});
    }
    default: return heff_nomatch(v_x1_2413);
    }
  }
}
V g_heff_2ecompile_2eemitc_2eupdatedIn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2eupdatedIn(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2ecompile_2eemitc_2eupdatedIn_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_ce_240 = heff_env(self)[0];
  V v_live_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = (g_heff_2ecompile_2eemitc_2eelemS(heff_dup(v_x_249), heff_rfield(v_ce_240, 6)));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    V v_x1_2411 = ({ V a_0 = heff_dup(v_x_249); V a_1 = v_live_241; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_live_241); r_; });
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_True: {
      heff_drop(v_x_249);
      heff_drop_rec(v_ce_240, 12);
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V v_x1_2412 = ({ V a_0 = v_x_249; V b_1 = heff_get_n(v_ce_240, 8, 12); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_x1_2412)) {
      case TAG_True: {
        return NTAG(TAG_False);
      }
      case TAG_False: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_x1_2412);
      }
    }
    default: return heff_nomatch(v_x1_2411);
    }
  }
  case TAG_False: {
    heff_drop(v_x_249);
    heff_drop_rec(v_ce_240, 12);
    heff_drop(v_live_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_2410);
  }
}
Clo g_heff_2ecompile_2eemitc_2ekeepBits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ekeepBits_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2ekeepBits(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_b_241 = heff_field(v_x1_240, 0);
    V v_bs_242 = heff_field(v_x1_240, 1);
    V v_t_243;
    switch (heff_tag_of(v_b_241)) {
    case TAG_True: {
      v_t_243 = MK_INT(1LL);
      break;
    }
    case TAG_False: {
      v_t_243 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_b_241);
    }
    V v_t_244 = (g_heff_2ecompile_2eemitc_2ekeepBits(v_bs_242));
    return heff_intAdd(v_t_243, heff_intMul(MK_INT(2LL), v_t_244));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2ekeepBits_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2ekeepBits(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2ecompile_2eemitc_2echangedOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2echangedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2echangedOf_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2echangedOf(V v_ls_240, V v_x_241, V v_fs_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_fs_242));
  V v_t_244 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_243, MK_INT(1LL))));
  V v_t_245 = (g_list_2ezipWith_24s1876717925x1404326288(v_fs_242, v_t_244));
  V v_t_2413 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2echangedOf_lam0, 1, 2, (V[]){heff_dup(v_ls_240), v_x_241}), v_t_245));
  return (g_list_2emap_24s1490052334x152035327(v_t_2413));
}
V g_heff_2ecompile_2eemitc_2echangedOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2echangedOf(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2ecompile_2eemitc_2echangedOf_lam0(V self, V *args) {
  V v_p_246 = args[0];
  V v_ls_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_f_249;
  switch (heff_tag_of(v_p_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_p_246, 0);
    heff_take_n(v_p_246, 1ULL, 2);
    v_f_249 = v_x_247;
    break;
  }
  default: heff_nomatch(v_p_246);
  }
  V v_x2_2410 = ({ V a_0 = v_ls_240; V a_1 = v_f_249; V r_ = (g_heff_2ecompile_2eemitc_2ekeptFrom(a_0, a_1)); heff_drop(v_ls_240); heff_drop(v_f_249); r_; });
  V v_x1_2412;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nothing: {
    heff_drop(v_x_241);
    v_x1_2412 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    V v_y_2411 = heff_field(v_x2_2410, 0);
    heff_take_n(v_x2_2410, 1ULL, 1);
    v_x1_2412 = heff_strEq(v_x_241, v_y_2411);
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2412);
  }
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2eupdateText_str0, 5, (86, 32, 114, 118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eupdateText_str1, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eupdateText_str2, 2, (59, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eupdateText_str3, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eupdateText_str4, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eupdateText_str5, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eupdateText_str6, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eupdateText_str7, 17, (104, 101, 102, 102, 95, 114, 102, 105, 101, 108, 100, 40, 114, 114, 95, 44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eupdateText_str8, 7, (41, 32, 61, 32, 114, 118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eupdateText_str9, 2, (59, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eupdateText_str10, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eupdateText_str11, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eupdateText_str12, 3, (40, 123, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eupdateText_str13, 25, (86, 32, 114, 114, 95, 32, 61, 32, 104, 101, 102, 102, 95, 114, 101, 99, 95, 114, 101, 117, 115, 101, 95, 110, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eupdateText_str14, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eupdateText_str15, 5, (85, 76, 76, 44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eupdateText_str16, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eupdateText_str17, 3, (41, 59, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eupdateText_str18, 7, (114, 114, 95, 59, 32, 125, 41));
Clo g_heff_2ecompile_2eemitc_2eupdateText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eupdateText_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2eupdateText(V v_x_240, V v_shape_241, V v_keep_242, V v_n_243, V v_vs_244, V v_changed_245) {
top: ;
  V v_x2_246 = (g_list_2ezipWith_24s2039753704x2095677241(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str0), ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str1), ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str2), v_vs_244, heff_dup(v_changed_245)));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str4); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str5), (g_heff_2ecompile_2eemitc_2emangleW(v_x_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str6))));
  V v_x2_2411 = (g_list_2emap_24s1601949456x759540121(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str7), ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str8), ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str9), v_changed_245));
  V v_t_2414;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str10);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    heff_take_n(v_x2_2411, 3ULL, 2);
    v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str11); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str12), heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str13), heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str14), heff_strAppend(heff_intShow(v_keep_242), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str15), heff_strAppend(heff_intShow(v_n_243), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str16), heff_strAppend(v_shape_241, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eupdateText_str17), heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemitc_2eupdateText_str18)))))))))))));
}
V g_heff_2ecompile_2eemitc_2eupdateText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eupdateText(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2eagain_str0, 4, (86, 32, 116, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eagain_str1, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eagain_str2, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eagain_str3, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eagain_str4, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eagain_str5, 5, (32, 61, 32, 116, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eagain_str6, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eagain_str7, 9, (103, 111, 116, 111, 32, 116, 111, 112, 59));
Clo g_heff_2ecompile_2eemitc_2eagain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eagain_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eagain(V v_ce_240, V v_vs_241) {
top: ;
  V v_t_242 = heff_get_n(v_ce_240, 4, 12);
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_vs_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_s_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_t_244 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_241));
    V v_t_245 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_244, MK_INT(1LL))));
    V v_t_246 = (g_list_2ezipWith_24s1814128165x1680687847(((V)&g_heff_2ecompile_2eemitc_2eagain_str0), ((V)&g_heff_2ecompile_2eemitc_2eagain_str1), ((V)&g_heff_2ecompile_2eemitc_2eagain_str2), heff_dup(v_vs_241), v_t_245));
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_241; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_vs_241); r_; });
    V v_t_248 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_247, MK_INT(1LL))));
    V v_t_249 = (g_list_2ezipWith_24s924458827x719285517(((V)&g_heff_2ecompile_2eemitc_2eagain_str3), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eagain_str4), ((V)&g_heff_2ecompile_2eemitc_2eagain_str5), ((V)&g_heff_2ecompile_2eemitc_2eagain_str6), heff_get_n(v_s_243, 1, 2), v_t_248));
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eagain_str7), NTAG(TAG_Nil)});
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_249, v_t_2410));
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_246, v_t_2411);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eemitc_2eagain_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eagain(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemitc_2eagrees_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eagrees_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eagrees(V v_ce_240, V v_g_241, V v_as_242) {
top: ;
  V v_m_243 = (g_map_2elookup_24s1546226666x2146984184(v_g_241, heff_rfield(v_ce_240, 2)));
  V v_n_244 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_242));
  V v_t_245 = heff_get_n(v_ce_240, 4, 12);
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_m_243);
    heff_drop(v_n_244);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_s_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_s_246, 1, 2); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    if (heff_intEq_c(v_t_247, heff_dup(v_n_244))) {
      switch (heff_tag_of(v_m_243)) {
      case TAG_Nothing: {
        heff_drop(v_n_244);
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_m_249 = heff_field(v_m_243, 0);
        heff_take_n(v_m_243, 1ULL, 1);
        return heff_intEq(v_n_244, v_m_249);
      }
      default: return heff_nomatch(v_m_243);
      }
    } else {
      heff_drop(v_m_243);
      heff_drop(v_n_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ecompile_2eemitc_2eagrees_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2eagrees(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2einPlace_str0, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2einPlace_str1, 7, (86, 32, 102, 95, 32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2einPlace_str2, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2einPlace_str3, 5, (97, 114, 103, 115, 91));
HEFF_STRA(g_heff_2ecompile_2eemitc_2einPlace_str4, 4, (93, 32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2einPlace_str5, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2einPlace_str6, 19, (105, 102, 32, 40, 104, 101, 102, 102, 95, 101, 120, 97, 99, 116, 40, 102, 95, 44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2einPlace_str7, 52, (44, 32, 97, 114, 103, 115, 41, 41, 32, 72, 69, 70, 70, 95, 76, 65, 83, 84, 32, 114, 101, 116, 117, 114, 110, 32, 40, 40, 67, 108, 111, 32, 42, 41, 102, 95, 41, 45, 62, 102, 110, 40, 102, 95, 44, 32, 97, 114, 103, 115, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2einPlace_str8, 21, (114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 116, 97, 105, 108, 40, 102, 95, 44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2einPlace_str9, 8, (44, 32, 97, 114, 103, 115, 41, 59));
Clo g_heff_2ecompile_2eemitc_2einPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2einPlace_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2einPlace(V v_vs_240) {
top: ;
  V v_x2_243;
  switch (heff_tag_of(v_vs_240)) {
  case TAG_Nil: {
    v_x2_243 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_vs_240, 0));
    v_x2_243 = heff_tag_n(TAG_Just, 1, (V[]){v_x_241});
    break;
  }
  default: heff_nomatch(v_vs_240);
  }
  V v_t_245;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nothing: {
    v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2einPlace_str0);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x2_243, 0);
    heff_take_n(v_x2_243, 1ULL, 1);
    v_t_245 = v_x_244;
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2einPlace_str1), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2einPlace_str2)));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = (g_list_2edrop(MK_INT(1LL), heff_dup(v_vs_240)));
  V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_2410 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_249, MK_INT(2LL))));
  V v_t_2411 = (g_list_2ezipWith_24s1814128165x1680687847(((V)&g_heff_2ecompile_2eemitc_2einPlace_str3), ((V)&g_heff_2ecompile_2eemitc_2einPlace_str4), ((V)&g_heff_2ecompile_2eemitc_2einPlace_str5), v_t_248, v_t_2410));
  V v_t_2412 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_2413 = heff_intShow(heff_intSub(v_t_2412, MK_INT(1LL)));
  V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2einPlace_str6), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2einPlace_str7)));
  V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_240; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_vs_240); r_; });
  V v_t_2416 = heff_intShow(heff_intSub(v_t_2415, MK_INT(1LL)));
  V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2einPlace_str8), heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemitc_2einPlace_str9)));
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
  V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2418})));
  return (g_prelude_2e_2b_2b(v_t_247, v_t_2419));
}
V g_heff_2ecompile_2eemitc_2einPlace_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2einPlace(a[0]);
}
Clo g_heff_2ecompile_2eemitc_2etakenFv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etakenFv_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2etakenFv(V v_ce_240, V v_x2_241, V v_vs_242, V v_fb_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ce_240, 12);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x1_247;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_x1_247 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      v_x1_247 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    switch (heff_tag_of(v_x1_247)) {
    case TAG_True: {
      heff_drop_rec(v_ce_240, 12);
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_248 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_242));
      if (heff_intLe_c(v_t_248, MK_INT(60LL))) {
        V v_x1_2410 = (g_heff_2ecompile_2eemitc_2eelemS(heff_dup(v_x_244), v_fb_243));
        switch (heff_tag_of(v_x1_2410)) {
        case TAG_True: {
          heff_drop_rec(v_ce_240, 12);
          heff_drop(v_x_244);
          heff_drop_cell(v_ru_24x2_241_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_False: {
          V v_x1_2411 = ({ V a_0 = heff_dup(v_x_244); V b_1 = heff_get_n(v_ce_240, 7, 12); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
          switch (heff_tag_of(v_x1_2411)) {
          case TAG_True: {
            heff_drop(v_x_244);
            heff_drop_cell(v_ru_24x2_241_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_False: {
            return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_x_244});
          }
          default: return heff_nomatch(v_x1_2411);
          }
        }
        default: return heff_nomatch(v_x1_2410);
        }
      } else {
        heff_drop_rec(v_ce_240, 12);
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2etakenFv_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2etakenFv(a[0], a[1], a[2], a[3]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLine_str0, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLine_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLine_str2, 11, (104, 101, 102, 102, 95, 102, 105, 101, 108, 100, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLine_str3, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLine_str4, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLine_str5, 20, (104, 101, 102, 102, 95, 100, 117, 112, 40, 104, 101, 102, 102, 95, 102, 105, 101, 108, 100, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLine_str6, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLine_str7, 2, (41, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLine_str8, 4, (32, 32, 86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLine_str9, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldLine_str10, 1, (59));
Clo g_heff_2ecompile_2eemitc_2efieldLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efieldLine_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2efieldLine(V v_sv_240, V v_plain_241, V v_used_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_v_244 = heff_field(v_x4_243, 0);
    V v_i_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2eemitc_2eelemS(heff_dup(v_v_244), v_used_242));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLine_str0), (g_heff_2ecompile_2eemitc_2emangleW(v_v_244, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efieldLine_str1))));
      V v_t_248;
      switch (heff_tag_of(v_plain_241)) {
      case TAG_True: {
        v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLine_str2), heff_strAppend(v_sv_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLine_str3), heff_strAppend(heff_intShow(v_i_245), ((V)&g_heff_2ecompile_2eemitc_2efieldLine_str4)))));
        break;
      }
      case TAG_False: {
        v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLine_str5), heff_strAppend(v_sv_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLine_str6), heff_strAppend(heff_intShow(v_i_245), ((V)&g_heff_2ecompile_2eemitc_2efieldLine_str7)))));
        break;
      }
      default: heff_nomatch(v_plain_241);
      }
      V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLine_str8), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLine_str9), heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemitc_2efieldLine_str10)))));
      return heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    }
    case TAG_False: {
      heff_drop(v_sv_240);
      heff_drop(v_v_244);
      heff_drop(v_i_245);
      heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2efieldLine_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2efieldLine(a[0], a[1], a[2], a[3]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
Clo g_heff_2ecompile_2eemitc_2epow2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epow2_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2epow2(V v_n_240) {
top: ;
  if (heff_intEq_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return MK_INT(1LL);
  } else {
    V v_t_242 = (g_heff_2ecompile_2eemitc_2epow2(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(2LL), v_t_242);
  }
}
V g_heff_2ecompile_2eemitc_2epow2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epow2(a[0]);
}
Clo g_heff_2ecompile_2eemitc_2efieldMask_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efieldMask_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2efieldMask(V v_used_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_v_243 = heff_field(v_x3_242, 0);
    V v_vs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ecompile_2eemitc_2eelemS(heff_dup(v_v_243), v_used_240));
    V v_t_246;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      v_t_246 = (g_heff_2ecompile_2eemitc_2epow2(heff_dup(v_i_241)));
      break;
    }
    case TAG_False: {
      v_t_246 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_247 = (g_heff_2ecompile_2eemitc_2efieldMask(v_used_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_vs_244));
    return heff_intAdd(v_t_246, v_t_247);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2efieldMask_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2efieldMask(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[2]); return r;
}
V g_heff_2ecompile_2eemitc_2ereuseArgs_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2ereuseArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseArgs_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2ereuseArgs(V v_go_240, V v_es_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), NTAG(TAG_Nil)});
  return (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eemitc_2ereuseArgs_lam0, 2, 1, (V[]){v_go_240}), v_t_242, v_es_241));
}
V g_heff_2ecompile_2eemitc_2ereuseArgs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2ereuseArgs(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2ecompile_2eemitc_2ereuseArgs_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_e_244 = args[1];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247;
  switch (heff_tag_of(v_acc_243)) {
  case TAG_MkPair: {
    V v_x_245 = heff_dup(heff_field(v_acc_243, 0));
    v_t_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_acc_243);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_go_240);
    V v_t_2410;
    switch (heff_tag_of(v_acc_243)) {
    case TAG_MkPair: {
      V v_y_249 = heff_field(v_acc_243, 1);
      heff_take_n(v_acc_243, 2ULL, 2);
      v_t_2410 = v_y_249;
      break;
    }
    default: heff_nomatch(v_acc_243);
    }
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), (g_prelude_2e_2b_2b(v_t_2410, v_t_2411))});
  }
  case TAG_False: {
    V v_done_2414;
    switch (heff_tag_of(v_acc_243)) {
    case TAG_MkPair: {
      V v_y_2413 = heff_field(v_acc_243, 1);
      heff_take_n(v_acc_243, 2ULL, 2);
      v_done_2414 = v_y_2413;
      break;
    }
    default: heff_nomatch(v_acc_243);
    }
    V v_x2_2415 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_244}));
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_MkPair: {
      V v_b_2416 = heff_field(v_x2_2415, 0);
      V v_e_2417 = heff_field(v_x2_2415, 1);
      V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
      V v_t_2418 = heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_Cons, 2, (V[]){v_e_2417, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2416, (g_prelude_2e_2b_2b(v_done_2414, v_t_2418))});
    }
    default: return heff_nomatch(v_x2_2415);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
Clo g_heff_2ecompile_2eemitc_2eletReuse_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eletReuse_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2eletReuse(V v_go_240, V v_x_241, V v_a_242, V v_b_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    V v_a2_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24MkPair = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_True: {
      heff_drop(v_go_240);
      heff_drop(v_a_242);
      return heff_tag_at_n(v_ru_24x5_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a2_246, v_b_243})});
    }
    case TAG_False: {
      heff_drop(v_a2_246);
      V v_x1_247 = heff_tr(heff_apply(v_go_240, 1, (V[]){heff_dup(v_b_243)}));
      V v_x2_2411;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_MkPair: {
        V v_b_248 = heff_field(v_x1_247, 0);
        V v_e_249 = heff_field(v_x1_247, 1);
        V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
        V v_t_2410 = heff_tag_at_n(v_ru_24x5_244_24MkPair, TAG_Cons, 2, (V[]){v_e_249, NTAG(TAG_Nil)});
        v_x2_2411 = heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){v_b_248, v_t_2410});
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_MkPair: {
        V v_b_2412 = heff_field(v_x2_2411, 0);
        V v_es_2413 = heff_field(v_x2_2411, 1);
        V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
        V v_x2_2416;
        switch (heff_tag_of(v_es_2413)) {
        case TAG_Nil: {
          v_x2_2416 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_x_2414 = heff_field(v_es_2413, 0);
          heff_take_n(v_es_2413, 1ULL, 2);
          v_x2_2416 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2414});
          break;
        }
        default: heff_nomatch(v_es_2413);
        }
        V v_t_2418;
        switch (heff_tag_of(v_x2_2416)) {
        case TAG_Nothing: {
          v_t_2418 = v_b_243;
          break;
        }
        case TAG_Just: {
          V v_x_2417 = heff_field(v_x2_2416, 0);
          heff_take_n(v_x2_2416, 1ULL, 1);
          heff_drop(v_b_243);
          v_t_2418 = v_x_2417;
          break;
        }
        default: heff_nomatch(v_x2_2416);
        }
        return heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){v_b_2412, heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_t_2418})});
      }
      default: return heff_nomatch(v_x2_2411);
      }
    }
    default: return heff_nomatch(v_x51_245);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2eemitc_2eletReuse_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eletReuse(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2eemitc_2ereuseIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2ereuseIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseIn_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ereuseIn(V v_ru_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EGlobal: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_ELam: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EApp: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_ELet: {
    V v_x_249 = heff_field(v_e_242, 0);
    V v_a_2410 = heff_field(v_e_242, 1);
    V v_b_2411 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_2412 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2ereuseIn_clo), 2, (V[]){heff_dup(v_ru_240), heff_dup(v_n_241)}));
    V v_t_2413 = (g_heff_2ecompile_2eemitc_2ereuseIn(v_ru_240, v_n_241, heff_dup(v_a_2410)));
    return (g_heff_2ecompile_2eemitc_2eletReuse(v_t_2412, v_x_249, v_a_2410, v_b_2411, v_t_2413));
  }
  case TAG_ERecord: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EProj: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_ETag: {
    V v_t_2418 = heff_field(v_e_242, 0);
    V v_as_2419 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2420 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2419));
    if (heff_intEq_c(v_t_2420, heff_dup(v_n_241))) {
      heff_drop(v_n_241);
      V v_t_2422 = heff_tag_at_n(v_ru_24e_242_24ETag, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ETag, 2, (V[]){v_t_2418, v_as_2419}), NTAG(TAG_Nil)});
      V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_ru_240}), v_t_2422});
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag_n(TAG_EPrimCall, 2, (V[]){heff_dup(g_heff_2ecompile_2eemitc_2ereusePrim_get()), v_t_2423})});
    } else {
      V v_t_2424 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2ereuseIn_clo), 2, (V[]){v_ru_240, v_n_241}));
      V v_x2_2425 = ({ V a_0 = v_t_2424; V a_1 = v_as_2419; V r_ = (g_heff_2ecompile_2eemitc_2ereuseArgs(a_0, a_1)); heff_drop(v_as_2419); r_; });
      switch (heff_tag_of(v_x2_2425)) {
      case TAG_MkPair: {
        V v_b_2426 = heff_field(v_x2_2425, 0);
        V v_es_2427 = heff_field(v_x2_2425, 1);
        heff_take_n(v_x2_2425, 3ULL, 2);
        return heff_tag_at_n(v_ru_24e_242_24ETag, TAG_MkPair, 2, (V[]){v_b_2426, heff_tag_n(TAG_ETag, 2, (V[]){v_t_2418, v_es_2427})});
      }
      default: return heff_nomatch(v_x2_2425);
      }
    }
  }
  case TAG_EMatch: {
    V v_s_2428 = heff_field(v_e_242, 0);
    V v_arms_2429 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_ps_2441 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2ereuseIn_lam0, 1, 2, (V[]){v_ru_240, v_n_241}), v_arms_2429));
    V v_t_2442 = (g_list_2eany_24s910662703x1730636603(v_ps_2441));
    V v_t_2443 = heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_2428, (g_list_2emap_24s1173914895x100384474(v_ps_2441))});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2442, v_t_2443});
  }
  case TAG_EPrim: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EPrimCall: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_ECall: {
    V v_g_2447 = heff_field(v_e_242, 0);
    V v_as_2448 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2449 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2ereuseIn_clo), 2, (V[]){v_ru_240, v_n_241}));
    V v_x2_2450 = ({ V a_0 = v_t_2449; V a_1 = v_as_2448; V r_ = (g_heff_2ecompile_2eemitc_2ereuseArgs(a_0, a_1)); heff_drop(v_as_2448); r_; });
    switch (heff_tag_of(v_x2_2450)) {
    case TAG_MkPair: {
      V v_b_2451 = heff_field(v_x2_2450, 0);
      V v_es_2452 = heff_field(v_x2_2450, 1);
      heff_take_n(v_x2_2450, 3ULL, 2);
      return heff_tag_at_n(v_ru_24e_242_24ECall, TAG_MkPair, 2, (V[]){v_b_2451, heff_tag_n(TAG_ECall, 2, (V[]){v_g_2447, v_es_2452})});
    }
    default: return heff_nomatch(v_x2_2450);
    }
  }
  case TAG_EInt: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EFloat: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EStr: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EFixed: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EFloat32: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EAbandon: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EFix: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eemitc_2ereuseIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ereuseIn(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2ereuseIn_lam0(V self, V *args) {
  V v_a_2430 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434;
  switch (heff_tag_of(v_a_2430)) {
  case TAG_MkArm: {
    V v_b_2433 = heff_dup(heff_field(v_a_2430, 2));
    v_t_2434 = v_b_2433;
    break;
  }
  default: heff_nomatch(v_a_2430);
  }
  V v_x2_2435 = (g_heff_2ecompile_2eemitc_2ereuseIn(v_ru_240, v_n_241, v_t_2434));
  switch (heff_tag_of(v_a_2430)) {
  case TAG_MkArm: {
    V v_t_2436 = heff_field(v_a_2430, 0);
    V v_vs_2437 = heff_field(v_a_2430, 1);
    V v_ru_24a_2430_24MkArm = heff_take_reuse_n(v_a_2430, 3ULL, 3);
    switch (heff_tag_of(v_x2_2435)) {
    case TAG_MkPair: {
      V v_r_2439 = heff_field(v_x2_2435, 0);
      V v_b_2440 = heff_field(v_x2_2435, 1);
      V v_ru_24x2_2435_24MkPair = heff_take_reuse_n(v_x2_2435, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2435_24MkPair, TAG_MkPair, 2, (V[]){v_r_2439, heff_tag_at_n(v_ru_24a_2430_24MkArm, TAG_MkArm, 3, (V[]){v_t_2436, v_vs_2437, v_b_2440})});
    }
    default: return heff_nomatch(v_x2_2435);
    }
  }
  default: return heff_nomatch(v_a_2430);
  }
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereusing_str0, 3, (114, 117, 36));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereusing_str1, 1, (36));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereusing_str2, 3, (114, 117, 36));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereusing_str3, 1, (36));
Clo g_heff_2ecompile_2eemitc_2ereusing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereusing_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2ereusing(V v_x1_240, V v_t_241, V v_vs_242, V v_b_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_t_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_b_243});
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ereusing_str0), heff_strAppend(heff_dup(v_x_244), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ereusing_str1), heff_dup(v_t_241))));
    V v_t_246 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_242));
    V v_it_247 = (g_heff_2ecompile_2eemitc_2ereuseIn(v_t_245, v_t_246, heff_dup(v_b_243)));
    switch (heff_tag_of(v_it_247)) {
    case TAG_MkPair: {
      V v_it1_248 = heff_field(v_it_247, 0);
      V v_b2_249 = heff_field(v_it_247, 1);
      V v_ru_24it_247_24MkPair = heff_take_reuse_n(v_it_247, 3ULL, 2);
      switch (heff_tag_of(v_it1_248)) {
      case TAG_True: {
        heff_drop(v_b_243);
        V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ereusing_str2), heff_strAppend(v_x_244, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ereusing_str3), v_t_241)));
        return heff_tag_at_n(v_ru_24it_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_t_2410}), v_b2_249});
      }
      case TAG_False: {
        heff_drop(v_t_241);
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        heff_drop(v_b2_249);
        return heff_tag_at_n(v_ru_24it_247_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_b_243});
      }
      default: return heff_nomatch(v_it1_248);
      }
    }
    default: return heff_nomatch(v_it_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2ereusing_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2ereusing(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2etakeKept_str0, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2etakeKept_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2etakeKept_str2, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2etakeKept_str3, 21, (32, 61, 32, 104, 101, 102, 102, 95, 116, 97, 107, 101, 95, 114, 101, 117, 115, 101, 95, 110, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2etakeKept_str4, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2etakeKept_str5, 5, (85, 76, 76, 44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2etakeKept_str6, 2, (41, 59));
Clo g_heff_2ecompile_2eemitc_2etakeKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etakeKept_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2etakeKept(V v_sv_240, V v_x2_241, V v_vs_242, V v_used_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_sv_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_ru_244 = heff_field(v_x2_241, 0);
    V v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etakeKept_str0), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_ru_244), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etakeKept_str1))));
    V v_t_246 = (g_heff_2ecompile_2eemitc_2efieldMask(v_used_243, MK_INT(0LL), v_vs_242));
    V v_t_247 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_242));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etakeKept_str2), heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etakeKept_str3), heff_strAppend(v_sv_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etakeKept_str4), heff_strAppend(heff_intShow(v_t_246), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etakeKept_str5), heff_strAppend(heff_intShow(v_t_247), ((V)&g_heff_2ecompile_2eemitc_2etakeKept_str6)))))))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2etakeKept_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2etakeKept(a[0], a[1], a[2], a[3]); heff_drop(a[1]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
Clo g_heff_2ecompile_2eemitc_2eknowing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eknowing_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eknowing(V v_x1_240, V v_n_241, V v_ce_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_n_241);
    return v_ce_242;
  }
  case TAG_Just: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(v_x_243, heff_tag_at_n(v_ru_24x1_240_24Just, TAG_KnownTag, 1, (V[]){v_n_241}), heff_take_field(v_ce_242, 10)));
    return ({ V rv_10 = v_t_244; V rr_ = heff_rec_reuse_n(v_ce_242, 3071ULL, 12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes); heff_rfield(rr_, 10) = rv_10; rr_; });
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2eknowing_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eknowing(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2eknowCell_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eknowCell_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eknowCell(V v_x1_240, V v_n_241, V v_ce_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_n_241);
    return v_ce_242;
  }
  case TAG_Just: {
    V v_ru_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(v_ru_243, heff_tag_at_n(v_ru_24x1_240_24Just, TAG_KnownCell, 1, (V[]){v_n_241}), heff_take_field(v_ce_242, 10)));
    return ({ V rv_10 = v_t_244; V rr_ = heff_rec_reuse_n(v_ce_242, 3071ULL, 12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes); heff_rfield(rr_, 10) = rv_10; rr_; });
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2eknowCell_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eknowCell(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2eheldVar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eheldVar_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eheldVar(V v_ce_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EVar = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_243 = ({ V a_0 = heff_dup(v_x_242); V b_1 = heff_get_n(v_ce_240, 6, 12); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return heff_tag_at_n(v_ru_24x2_241_24EVar, TAG_Just, 1, (V[]){v_x_242});
    }
    case TAG_False: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24EVar, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 12);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 12);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 12);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop_rec(v_ce_240, 12);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 12);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop_rec(v_ce_240, 12);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 12);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 12);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 12);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 12);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 12);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 12);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 12);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 12);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 12);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 12);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_ce_240, 12);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 12);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eheldVar_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eheldVar(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemitc_2ereusedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereusedOf_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2ereusedOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x121_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x121_243)) {
      case TAG_EVar: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EGlobal: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ELam: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EApp: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ELet: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ERecord: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EProj: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ETag: {
        V v_as_2419 = heff_field(v_x121_243, 1);
        switch (heff_tag_of(v_x122_244)) {
        case TAG_Nil: {
          V v_t_2420 = heff_tag_n(TAG_KnownTag, 1, (V[]){(g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2419))});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
        }
        case TAG_Cons: {
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_x122_244);
        }
      }
      case TAG_EMatch: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EPrim: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ECall: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EInt: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EFloat: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EStr: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EFixed: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EFix: {
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x121_243);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2ereusedOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2ereusedOf(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2ecompile_2eemitc_2ebuiltOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ebuiltOf_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2ebuiltOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_x1_240, 0);
    V v_b_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_xs_245 = (g_heff_2ecompile_2eemitc_2efreeOf(v_xs_243, v_b_244));
    V v_t_246 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_245; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_KnownClo, 1, (V[]){v_t_246})});
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    V v_fs_2412 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2413 = heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_KnownRec, 1, (V[]){({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fs_2412; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_fs_2412); r_; })});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
  }
  case TAG_EProj: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    V v_as_2418 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V v_t_2419 = heff_tag_n(TAG_KnownTag, 1, (V[]){({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_as_2418; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_as_2418); r_; })});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2419});
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    V v_p_2423 = heff_field(v_x1_240, 0);
    V v_as_2424 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(v_p_2423, heff_dup(g_heff_2ecompile_2eemitc_2ereusePrim_get()))) {
      return ({ V a_0 = v_as_2424; V r_ = (g_heff_2ecompile_2eemitc_2ereusedOf(a_0)); heff_drop(v_as_2424); r_; });
    } else {
      heff_drop(v_as_2424);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_ECall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2ebuiltOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ebuiltOf(a[0]);
}
Clo g_heff_2ecompile_2eemitc_2eknownLet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eknownLet_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eknownLet(V v_x_240, V v_x2_241, V v_ce_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_x_240);
    return v_ce_242;
  }
  case TAG_Just: {
    V v_k_243 = heff_field(v_x2_241, 0);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(v_x_240, heff_dup(v_k_243), heff_take_field(v_ce_242, 10)));
    return ({ V rv_10 = v_t_244; V rr_ = heff_rec_reuse_n(v_ce_242, 3071ULL, 12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes); heff_rfield(rr_, 10) = rv_10; rr_; });
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eknownLet_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2eknownLet(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdPrims_str0, 6, (114, 117, 110, 101, 76, 101));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdPrims_str1, 6, (114, 117, 110, 101, 69, 113));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdPrims_str2, 6, (114, 117, 110, 101, 76, 116));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdPrims_str3, 5, (115, 116, 114, 69, 113));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdPrims_str4, 5, (115, 116, 114, 76, 116));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdPrims_str5, 7, (102, 108, 111, 97, 116, 76, 116));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdPrims_str6, 7, (102, 108, 111, 97, 116, 76, 101));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdPrims_str7, 5, (105, 110, 116, 76, 101));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdPrims_str8, 7, (102, 108, 111, 97, 116, 69, 113));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdPrims_str9, 5, (105, 110, 116, 69, 113));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdPrims_str10, 5, (105, 110, 116, 76, 116));

static V g_heff_2ecompile_2eemitc_2econdPrims_val;
static int g_heff_2ecompile_2eemitc_2econdPrims_st;
static V g_heff_2ecompile_2eemitc_2econdPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2econdPrims_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2econdPrims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2econdPrims_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2econdPrims_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2econdPrims_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2econdPrims_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2econdPrims_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2econdPrims_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2econdPrims_str8), v_t_243})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2econdPrims_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2econdPrims_str10), v_t_244})});
}
V g_heff_2ecompile_2eemitc_2econdPrims_get(void) {
  if (g_heff_2ecompile_2eemitc_2econdPrims_st == 2) return g_heff_2ecompile_2eemitc_2econdPrims_val;
  if (g_heff_2ecompile_2eemitc_2econdPrims_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eemitc_2econdPrims_st = 1;
  g_heff_2ecompile_2eemitc_2econdPrims_val = heff_tr(g_heff_2ecompile_2eemitc_2econdPrims_init());
  g_heff_2ecompile_2eemitc_2econdPrims_st = 2;
  return g_heff_2ecompile_2eemitc_2econdPrims_val;
}
Clo g_heff_2ecompile_2eemitc_2erelFixed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2erelFixed_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2erelFixed(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_t_242 = heff_dup(heff_rfield(v_p_241, 1));
    switch (heff_tag_of(v_t_242)) {
    case TAG_OpAdd: {
      return NTAG(TAG_False);
    }
    case TAG_OpSub: {
      return NTAG(TAG_False);
    }
    case TAG_OpMul: {
      return NTAG(TAG_False);
    }
    case TAG_OpDiv: {
      return NTAG(TAG_False);
    }
    case TAG_OpRem: {
      return NTAG(TAG_False);
    }
    case TAG_OpEq: {
      return NTAG(TAG_True);
    }
    case TAG_OpLt: {
      return NTAG(TAG_True);
    }
    case TAG_OpLe: {
      return NTAG(TAG_True);
    }
    case TAG_OpAnd: {
      return NTAG(TAG_False);
    }
    case TAG_OpOr: {
      return NTAG(TAG_False);
    }
    case TAG_OpXor: {
      return NTAG(TAG_False);
    }
    case TAG_OpShl: {
      return NTAG(TAG_False);
    }
    case TAG_OpShr: {
      return NTAG(TAG_False);
    }
    case TAG_OpShow: {
      return NTAG(TAG_False);
    }
    case TAG_OpFromInt: {
      return NTAG(TAG_False);
    }
    case TAG_OpToInt: {
      return NTAG(TAG_False);
    }
    case TAG_OpSqrt: {
      return NTAG(TAG_False);
    }
    case TAG_OpFromFloat: {
      return NTAG(TAG_False);
    }
    case TAG_OpToFloat: {
      return NTAG(TAG_False);
    }
    case TAG_OpFloor: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2erelFixed_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2erelFixed(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2ecompile_2eemitc_2econdOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2econdOn_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2econdOn(V v_x_240, V v_p_241, V v_as_242, V v_s_243, V v_arms_244) {
top: ;
  V v_t_245 = ({ V a_0 = heff_dup(v_p_241); V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2econdPrims_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_247;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    v_t_247 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    V v_t_246 = (g_heff_2eelab_2efixed_2efixedPrimOf(heff_dup(v_p_241)));
    v_t_247 = ({ V a_0 = v_t_246; V r_ = (g_heff_2ecompile_2eemitc_2erelFixed(a_0)); heff_drop(v_t_246); r_; });
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    V v_t_2438;
    switch (heff_tag_of(v_s_243)) {
    case TAG_EVar: {
      V v_y_248 = heff_field(v_s_243, 0);
      v_t_2438 = heff_strEq(heff_dup(v_x_240), heff_dup(v_y_248));
      break;
    }
    case TAG_EGlobal: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_243);
    }
    switch (heff_tag_of(v_t_2438)) {
    case TAG_True: {
      V v_t_2439 = (g_list_2eall_24s1703554932x1387778930(v_arms_244));
      switch (heff_tag_of(v_t_2439)) {
      case TAG_True: {
        V v_es_2440 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_244)));
        V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2440));
        V v_t_2442 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2441; V r_ = (g_list_2efoldl_24s873517001x1016672031(a_0, a_1)); heff_drop(v_t_2441); r_; });
        V v_x1_2443 = ({ V a_0 = v_x_240; V a_1 = v_t_2442; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_t_2442); r_; });
        switch (heff_tag_of(v_x1_2443)) {
        case TAG_True: {
          heff_drop(v_p_241);
          heff_drop(v_as_242);
          heff_drop(v_arms_244);
          return NTAG(TAG_Nothing);
        }
        case TAG_False: {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_prim__args__arms, (V[]){v_p_241, v_as_242, v_arms_244})});
        }
        default: return heff_nomatch(v_x1_2443);
        }
      }
      case TAG_False: {
        heff_drop(v_x_240);
        heff_drop(v_p_241);
        heff_drop(v_as_242);
        heff_drop(v_arms_244);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_t_2439);
      }
    }
    case TAG_False: {
      heff_drop(v_x_240);
      heff_drop(v_p_241);
      heff_drop(v_as_242);
      heff_drop(v_arms_244);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_2438);
    }
  }
  case TAG_False: {
    heff_drop(v_x_240);
    heff_drop(v_p_241);
    heff_drop(v_as_242);
    heff_drop(v_arms_244);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ecompile_2eemitc_2econdOn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2econdOn(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[3]); return r;
}
Clo g_heff_2ecompile_2eemitc_2econdLet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2econdLet_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2econdLet(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    V v_p_2421 = heff_field(v_a_241, 0);
    V v_as_2422 = heff_field(v_a_241, 1);
    switch (heff_tag_of(v_b_242)) {
    case TAG_EVar: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      V v_s_2438 = heff_field(v_b_242, 0);
      V v_arms_2439 = heff_field(v_b_242, 1);
      return (g_heff_2ecompile_2eemitc_2econdOn(v_x_240, heff_dup(v_p_2421), heff_dup(v_as_2422), v_s_2438, heff_dup(v_arms_2439)));
    }
    case TAG_EPrim: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_b_242);
    }
  }
  case TAG_ECall: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2eemitc_2econdLet_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2econdLet(a[0], a[1], a[2]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
Clo g_heff_2ecompile_2eemitc_2eisCondCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eisCondCall_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eisCondCall(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2419 = heff_field(v_x1_240, 0);
    V v_t_2421 = ({ V a_0 = heff_dup(v_p_2419); V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2econdPrims_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2421)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_2422 = (g_heff_2eelab_2efixed_2efixedPrimOf(heff_dup(v_p_2419)));
      return ({ V a_0 = v_t_2422; V r_ = (g_heff_2ecompile_2eemitc_2erelFixed(a_0)); heff_drop(v_t_2422); r_; });
    }
    default: return heff_nomatch(v_t_2421);
    }
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2eisCondCall_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2eisCondCall(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2ecompile_2eemitc_2eisMatchOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eisMatchOn_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eisMatchOn(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_s_2417 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_s_2417)) {
    case TAG_EVar: {
      V v_y_2419 = heff_field(v_s_2417, 0);
      return heff_strEq(v_x_240, heff_dup(v_y_2419));
    }
    case TAG_EGlobal: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_s_2417);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eisMatchOn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2eisMatchOn(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2ecompile_2eemitc_2esunkGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2esunkGo_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2esunkGo(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_b_242)) {
  case TAG_EVar: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    V v_y_249 = heff_field(v_b_242, 0);
    V v_m_2410 = heff_field(v_b_242, 1);
    V v_e_2411 = heff_field(v_b_242, 2);
    V v_ru_24b_242_24ELet = heff_take_reuse_n(v_b_242, 7ULL, 3);
    V v_t_2412 = (g_heff_2ecompile_2eemitc_2eisMatchOn(heff_dup(v_x_240), v_m_2410));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      V v_t_2413 = (g_heff_2ecompile_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_e_2411)));
      V v_x1_2414 = ({ V a_0 = heff_dup(v_x_240); V a_1 = v_t_2413; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_t_2413); r_; });
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_True: {
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_y_249);
        heff_drop(v_m_2410);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        V v_t_2415 = heff_tag_at_n(v_ru_24b_242_24ELet, TAG_ELet, 3, (V[]){v_y_249, heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_m_2410}), v_e_2411});
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_2415});
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    case TAG_False: {
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_y_249);
      heff_drop(v_m_2410);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_b_242, 0ULL, 3);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_b_242);
  }
}
V g_heff_2ecompile_2eemitc_2esunkGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2esunkGo(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2earmFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2earmFor_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2earmFor(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_u_244 = heff_field(v_x21_242, 0);
      V v_b_246 = heff_field(v_x21_242, 2);
      if (heff_strEq_c(heff_dup(v_t_240), heff_dup(v_u_244))) {
        heff_drop(v_t_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_b_246)});
      } else {
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2earmFor_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2earmFor(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2ecompile_2eemitc_2eothersW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eothersW_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eothersW(V v_x_240, V v_l_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    heff_drop(v_l_241);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      V v_y_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      if (heff_strEq_c(heff_dup(v_x_240), v_y_245)) {
        heff_drop(v_x_240);
        heff_drop(v_l_241);
        heff_drop(v_rest_244);
        return NTAG(TAG_False);
      } else {
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_l_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_l_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_b_249 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V v_t_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_249, NTAG(TAG_Nil)});
      V v_t_2411 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_240), MK_INT(0LL), v_t_2410));
      if (heff_intEq_c(v_t_2411, MK_INT(0LL))) {
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_x_240);
        heff_drop(v_l_241);
        heff_drop(v_rest_244);
        return NTAG(TAG_False);
      }
    }
    case TAG_EApp: {
      V v_f_2413 = heff_field(v_x31_243, 0);
      V v_as_2414 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2413, (g_prelude_2e_2b_2b(v_as_2414, v_rest_244))});
      V t_0 = v_x_240;
      V t_1 = v_l_241;
      V t_2 = v_t_2415;
      v_x_240 = t_0;
      v_l_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2417 = heff_field(v_x31_243, 1);
      V v_b_2418 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2419 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2417, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2418, v_rest_244})});
      V t_0 = v_x_240;
      V t_1 = v_l_241;
      V t_2 = v_t_2419;
      v_x_240 = t_0;
      v_l_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2420 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2421 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2420, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_l_241;
      V t_2 = v_t_2421;
      v_x_240 = t_0;
      v_l_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2422 = heff_field(v_x31_243, 0);
      V v_l2_2423 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 3);
      V v_t_2455;
      switch (heff_tag_of(v_e_2422)) {
      case TAG_EVar: {
        V v_y_2425 = heff_dup(heff_field(v_e_2422, 0));
        v_t_2455 = heff_strEq(heff_dup(v_x_240), v_y_2425);
        break;
      }
      case TAG_EGlobal: {
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_2422);
      }
      switch (heff_tag_of(v_t_2455)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_e_2422);
        if (heff_strEq_c(heff_dup(v_l_241), v_l2_2423)) {
          heff_drop(v_x_240);
          heff_drop(v_l_241);
          heff_drop(v_rest_244);
          return NTAG(TAG_False);
        } else {
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_rest_244;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      }
      case TAG_False: {
        heff_drop(v_l2_2423);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2422, v_rest_244});
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_t_2455);
      }
    }
    case TAG_ETag: {
      V v_as_2458 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2459 = (g_prelude_2e_2b_2b(v_as_2458, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_l_241;
      V t_2 = v_t_2459;
      v_x_240 = t_0;
      v_l_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2460 = heff_field(v_x31_243, 0);
      V v_arms_2461 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2462 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2460, (g_heff_2ecompile_2eir_2epushArms(v_arms_2461, v_rest_244))});
      V t_0 = v_x_240;
      V t_1 = v_l_241;
      V t_2 = v_t_2462;
      v_x_240 = t_0;
      v_l_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_l_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_l_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2465 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2466 = (g_prelude_2e_2b_2b(v_as_2465, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_l_241;
      V t_2 = v_t_2466;
      v_x_240 = t_0;
      v_l_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2468 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2469 = (g_prelude_2e_2b_2b(v_as_2468, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_l_241;
      V t_2 = v_t_2469;
      v_x_240 = t_0;
      v_l_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_l_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_l_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_l_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_l_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_l_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_l_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_l_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_l_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_l_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_l_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_l_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_l_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_l_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_l_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2eothersW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eothersW(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2eoperandsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eoperandsOf_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eoperandsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_x1_240, 0);
    V v_as_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_Cons, 2, (V[]){v_f_245, v_as_246});
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_ERecord: {
    V v_fs_2410 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    HEFF_LAST return g_list_2emap_24s1173914895x100384474(v_fs_2410);
  }
  case TAG_EProj: {
    V v_e_2411 = heff_field(v_x1_240, 0);
    V v_l_2412 = heff_field(v_x1_240, 1);
    V v_sh_2413 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24EProj = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EProj, TAG_EProj, 3, (V[]){v_e_2411, v_l_2412, v_sh_2413}), NTAG(TAG_Nil)});
  }
  case TAG_ETag: {
    V v_as_2415 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return v_as_2415;
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    V v_as_2420 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return v_as_2420;
  }
  case TAG_ECall: {
    V v_as_2422 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return v_as_2422;
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2eoperandsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eoperandsOf(a[0]);
}
Clo g_heff_2ecompile_2eemitc_2etakeVar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etakeVar_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2etakeVar(V v_ce_240, V v_rest_241, V v_x3_242, V v_l_243, V v_sh_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ce_240, 12);
    heff_drop(v_rest_241);
    heff_drop(v_l_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_x1_248;
    switch (heff_tag_of(v_sh_244)) {
    case TAG_Nil: {
      v_x1_248 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      v_x1_248 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_sh_244);
    }
    switch (heff_tag_of(v_x1_248)) {
    case TAG_True: {
      heff_drop_rec(v_ce_240, 12);
      heff_drop(v_rest_241);
      heff_drop(v_l_243);
      return NTAG(TAG_Nil);
    }
    case TAG_False: {
      V v_t_249 = (g_heff_2ecompile_2eemitc_2eelemS(heff_dup(v_x_245), heff_rfield(v_ce_240, 6)));
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        V v_x1_2410 = (g_heff_2ecompile_2eemitc_2eelemS(heff_dup(v_x_245), heff_rfield(v_ce_240, 8)));
        switch (heff_tag_of(v_x1_2410)) {
        case TAG_True: {
          heff_drop_rec(v_ce_240, 12);
          heff_drop(v_rest_241);
          heff_drop(v_l_243);
          return NTAG(TAG_Nil);
        }
        case TAG_False: {
          V v_x1_2411 = ({ V a_0 = heff_dup(v_x_245); V b_1 = heff_get_n(v_ce_240, 7, 12); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
          switch (heff_tag_of(v_x1_2411)) {
          case TAG_True: {
            heff_drop(v_rest_241);
            heff_drop(v_l_243);
            return NTAG(TAG_Nil);
          }
          case TAG_False: {
            V v_t_2412 = (g_heff_2ecompile_2eemitc_2eothersW(heff_dup(v_x_245), heff_dup(v_l_243), v_rest_241));
            switch (heff_tag_of(v_t_2412)) {
            case TAG_True: {
              return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_245), v_l_243}), NTAG(TAG_Nil)});
            }
            case TAG_False: {
              heff_drop(v_l_243);
              return NTAG(TAG_Nil);
            }
            default: return heff_nomatch(v_t_2412);
            }
          }
          default: return heff_nomatch(v_x1_2411);
          }
        }
        default: return heff_nomatch(v_x1_2410);
        }
      }
      case TAG_False: {
        heff_drop_rec(v_ce_240, 12);
        heff_drop(v_rest_241);
        heff_drop(v_l_243);
        return NTAG(TAG_Nil);
      }
      default: return heff_nomatch(v_t_249);
      }
    }
    default: return heff_nomatch(v_x1_248);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2etakeVar_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2etakeVar(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); heff_drop(a[4]); return r;
}
Clo g_heff_2ecompile_2eemitc_2etakeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etakeOne_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2etakeOne(V v_ce_240, V v_rest_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_ERecord: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    V v_e1_2413 = heff_field(v_e_242, 0);
    V v_l_2414 = heff_field(v_e_242, 1);
    V v_sh_2415 = heff_field(v_e_242, 2);
    V v_t_2446;
    switch (heff_tag_of(v_e1_2413)) {
    case TAG_EVar: {
      V v_x_2416 = heff_field(v_e1_2413, 0);
      v_t_2446 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2416)});
      break;
    }
    case TAG_EGlobal: {
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELam: {
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EApp: {
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELet: {
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ERecord: {
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EProj: {
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ETag: {
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EMatch: {
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrim: {
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ECall: {
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EInt: {
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat: {
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EStr: {
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFixed: {
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat32: {
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EAbandon: {
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFix: {
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_e1_2413);
    }
    return ({ V a_0 = v_ce_240; V a_1 = v_rest_241; V a_2 = v_t_2446; V a_3 = heff_dup(v_l_2414); V a_4 = v_sh_2415; V r_ = (g_heff_2ecompile_2eemitc_2etakeVar(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2446); r_; });
  }
  case TAG_ETag: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrim: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eemitc_2etakeOne_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2etakeOne(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_heff_2ecompile_2eemitc_2etakesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etakesAt_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2etakesAt(V v_ce_240, V v_before_241, V v_b_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_before_241);
    heff_drop(v_b_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_es_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
    V v_t_247 = (g_prelude_2e_2b_2b(heff_dup(v_es_245), v_t_246));
    V v_t_248 = (g_prelude_2e_2b_2b(heff_dup(v_before_241), v_t_247));
    V v_t_249 = (g_heff_2ecompile_2eemitc_2etakeOne(heff_dup(v_ce_240), v_t_248, v_e_244));
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    V v_t_2411 = (g_prelude_2e_2b_2b(v_before_241, v_t_2410));
    V v_t_2412 = (g_heff_2ecompile_2eemitc_2etakesAt(v_ce_240, v_t_2411, v_b_242, v_es_245));
    return (g_prelude_2e_2b_2b(v_t_249, v_t_2412));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2etakesAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etakesAt(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eemitc_2eparamsAt_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eparamsAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eparamsAt_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eparamsAt(V v_want_240, V v_bi_241, V v_xs_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_242));
  V v_t_244 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_243, MK_INT(1LL))));
  V v_t_245 = (g_list_2ezipWith_24s1876717925x1404326288(v_xs_242, v_t_244));
  V v_t_2414 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2eparamsAt_lam0, 1, 2, (V[]){heff_dup(v_want_240), heff_dup(v_bi_241)}), v_t_245));
  return (g_list_2emap_24s1937570095x2110149801(v_t_2414));
}
V g_heff_2ecompile_2eemitc_2eparamsAt_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2eparamsAt(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2ecompile_2eemitc_2eparamsAt_lam0(V self, V *args) {
  V v_p_246 = args[0];
  V v_want_240 = heff_env(self)[0];
  V v_bi_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_want_240)) {
  case TAG_True: {
    V v_t_249;
    switch (heff_tag_of(v_p_246)) {
    case TAG_MkPair: {
      V v_y_248 = heff_field(v_p_246, 1);
      heff_take_n(v_p_246, 2ULL, 2);
      v_t_249 = v_y_248;
      break;
    }
    default: heff_nomatch(v_p_246);
    }
    return ({ V a_0 = v_t_249; V a_1 = v_bi_241; V r_ = (g_heff_2ecompile_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_241); r_; });
  }
  case TAG_False: {
    V v_t_2412;
    switch (heff_tag_of(v_p_246)) {
    case TAG_MkPair: {
      V v_y_2411 = heff_field(v_p_246, 1);
      heff_take_n(v_p_246, 2ULL, 2);
      v_t_2412 = v_y_2411;
      break;
    }
    default: heff_nomatch(v_p_246);
    }
    V v_x1_2413 = ({ V a_0 = v_t_2412; V a_1 = v_bi_241; V r_ = (g_heff_2ecompile_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_241); r_; });
    switch (heff_tag_of(v_x1_2413)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_2413);
    }
  }
  default: return heff_nomatch(v_want_240);
  }
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str0, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str2, 2, (97, 91));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str3, 1, (93));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str4, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str5, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str6, 9, (32, 32, 114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str7, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str8, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str9, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str10, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str11, 2, (97, 91));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str12, 1, (93));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str13, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str14, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str15, 12, (104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 97, 91));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str16, 3, (93, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str17, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str18, 1, (32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str19, 8, (32, 32, 86, 32, 114, 32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str20, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str21, 3, (41, 59, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryCall_str22, 10, (32, 114, 101, 116, 117, 114, 110, 32, 114, 59));
Clo g_heff_2ecompile_2eemitc_2eentryCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eentryCall_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eentryCall(V v_key_240, V v_bi_241, V v_n_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_bi_241)) {
  case TAG_Nil: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_bi_241);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_bi_241);
    V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str0), (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str1))));
    V v_t_247 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_242, MK_INT(1LL))));
    V v_x2_248 = (g_list_2emap_24s1006477676x1816442814(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str2), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str3), v_t_247));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str5); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str6), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str7), heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str8)))));
  }
  case TAG_False: {
    V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str9), (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str10))));
    V v_t_2413 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_242, MK_INT(1LL))));
    V v_x2_2414 = (g_list_2emap_24s1006477676x1816442814(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str11), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str12), v_t_2413));
    V v_t_2417;
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str13);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      v_t_2417 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str14); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2414);
    }
    V v_x2_2418 = (g_list_2emap_24s1006477676x1816442814(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str15), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str16), v_bi_241));
    V v_t_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str17);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_t_2421 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str18); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str19), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str20), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str21), heff_strAppend(v_t_2421, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str22)))))));
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ecompile_2eemitc_2eentryCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eentryCall(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2elamBody_24s793100636x1014529228_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2elamBody_24s793100636x1014529228_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elamBody_24s793100636x1014529228_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2elamBody_24s793100636x1014529228(V v_ce_240, V v_xs_241, V v_b_242, V v_fv_243) {
top: ;
  V v_owned_244 = (g_prelude_2e_2b_2b(heff_dup(v_xs_241), v_fv_243));
  V v_wanted_245 = (g_heff_2ecompile_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_b_242)));
  V v_owned_247 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2elamBody_24s793100636x1014529228_lam0, 1, 1, (V[]){v_wanted_245}), v_owned_244));
  V v_n_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_241); r_; });
  V v_ce_249 = ({ V rv_4 = NTAG(TAG_Nothing); V rv_5 = v_n_248; V rv_11 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_n(v_ce_240, 1999ULL, 12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes); heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 11) = rv_11; rr_; });
  V v_ce_2410 = ({ V rv_8 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_n(v_ce_249, 3839ULL, 12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes); heff_rfield(rr_, 8) = rv_8; rr_; });
  V v_ce_2411 = ({ V rv_6 = v_owned_247; V rv_7 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_n(v_ce_2410, 3903ULL, 12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes); heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
  return (g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499(v_ce_2411, NTAG(TAG_Ret), v_b_242));
}
V g_heff_2ecompile_2eemitc_2elamBody_24s793100636x1014529228_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2elamBody_24s793100636x1014529228(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eemitc_2elamBody_24s793100636x1014529228_lam0(V self, V *args) {
  V v_v_246 = args[0];
  V v_wanted_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_246; V a_1 = v_wanted_245; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_245); r_; });
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str0, 9, (115, 116, 97, 116, 105, 99, 32, 86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str1, 30, (40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 114, 103, 115, 41, 59, 32, 115, 116, 97, 116, 105, 99, 32, 67, 108, 111, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str2, 33, (95, 99, 108, 111, 32, 61, 32, 123, 123, 48, 120, 56, 48, 48, 48, 48, 48, 48, 48, 117, 44, 32, 75, 95, 67, 76, 79, 44, 32, 48, 125, 44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str3, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str4, 5, (44, 32, 48, 125, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str5, 9, (115, 116, 97, 116, 105, 99, 32, 86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str6, 18, (40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 114, 103, 115, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str7, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str8, 1, (10));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str9, 5, (40, 40, 86, 41, 38));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str10, 5, (95, 99, 108, 111, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str11, 4, (78, 85, 76, 76));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str12, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str13, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str14, 6, (40, 86, 91, 93, 41, 123));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str15, 1, (125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str16, 11, (104, 101, 102, 102, 95, 99, 108, 111, 95, 110, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str17, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str18, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str19, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str20, 1, (41));
V g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523(V v_ce_240, V v_live_241, V v_xs_242, V v_b_243, V v_fv_244, V v_s_245) {
top: ;
  V v_x2_246 = (g_heff_2ecompile_2eemitc_2enewLam(v_s_245));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_249 = (g_heff_2ecompile_2eemitc_2elamBody_24s793100636x1014529228(heff_dup(v_ce_240), heff_dup(v_xs_242), heff_dup(v_b_243), heff_dup(v_fv_244)));
    V v_x2_2410 = heff_tr(heff_apply(v_m_249, 1, (V[]){v_s_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      V v_n_2413 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_242));
      V v_t_2416;
      switch (heff_tag_of(v_fv_244)) {
      case TAG_Nil: {
        v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str0), heff_strAppend(heff_dup(v_x_247), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str1), heff_strAppend(heff_dup(v_x_247), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str2), heff_strAppend(heff_dup(v_x_247), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str3), heff_strAppend(heff_intShow(v_n_2413), ((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str4)))))))));
        break;
      }
      case TAG_Cons: {
        heff_drop(v_n_2413);
        v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str5), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str6)));
        break;
      }
      default: heff_nomatch(v_fv_244);
      }
      V v_wanted_2417 = (g_heff_2ecompile_2eemitc_2efreeOf(NTAG(TAG_Nil), v_b_243));
      V v_t_2420 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_lam0, 1, 1, (V[]){v_wanted_2417}), heff_dup(v_xs_242)));
      V v_x2_2421 = (g_heff_2ecompile_2eemitc_2elamLines(heff_dup(v_x_247), heff_dup(v_xs_242), heff_dup(v_fv_244), v_t_2420, v_x_2411));
      V v_t_2424;
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Nil: {
        v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_x2_2421, 0);
        V v_xs_2423 = heff_field(v_x2_2421, 1);
        heff_take_n(v_x2_2421, 3ULL, 2);
        v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str8); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      V v_m_2425 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2eaddLam_clo), 2, (V[]){v_t_2416, v_t_2424}));
      V v_x2_2426 = heff_tr(heff_apply(v_m_2425, 1, (V[]){v_s_2412}));
      switch (heff_tag_of(v_x2_2426)) {
      case TAG_MkPair: {
        V v_s_2428 = heff_field(v_x2_2426, 1);
        heff_take_n(v_x2_2426, 2ULL, 2);
        V v_t_2431;
        switch (heff_tag_of(v_fv_244)) {
        case TAG_Nil: {
          v_t_2431 = NTAG(TAG_True);
          break;
        }
        case TAG_Cons: {
          v_t_2431 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_fv_244);
        }
        V v_x_2442;
        switch (heff_tag_of(v_t_2431)) {
        case TAG_True: {
          heff_drop_rec(v_ce_240, 12);
          heff_drop(v_live_241);
          heff_drop(v_xs_242);
          heff_drop(v_fv_244);
          v_x_2442 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str9), heff_strAppend(v_x_247, ((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str10)));
          break;
        }
        case TAG_False: {
          V v_t_2432 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_242; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_242); r_; });
          V v_t_2433 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_fv_244));
          V v_t_2434 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2evarUse_clo), 2, (V[]){heff_get_n(v_ce_240, 8, 12), v_live_241}));
          V v_vs_2435 = (g_list_2emap(v_t_2434, v_fv_244));
          V v_t_2441;
          switch (heff_tag_of(v_vs_2435)) {
          case TAG_Nil: {
            v_t_2441 = ((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str11);
            break;
          }
          case TAG_Cons: {
            V v_t_2440;
            switch (heff_tag_of(v_vs_2435)) {
            case TAG_Nil: {
              v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str12);
              break;
            }
            case TAG_Cons: {
              V v_x_2438 = heff_field(v_vs_2435, 0);
              V v_xs_2439 = heff_field(v_vs_2435, 1);
              heff_take_n(v_vs_2435, 3ULL, 2);
              v_t_2440 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str13); V a_1 = v_x_2438; V a_2 = v_xs_2439; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
              break;
            }
            default: heff_nomatch(v_vs_2435);
            }
            v_t_2441 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str14), heff_strAppend(v_t_2440, ((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str15)));
            break;
          }
          default: heff_nomatch(v_vs_2435);
          }
          v_x_2442 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str16), heff_strAppend(v_x_247, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str17), heff_strAppend(heff_intShow(v_t_2432), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str18), heff_strAppend(heff_intShow(v_t_2433), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str19), heff_strAppend(v_t_2441, ((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_str20)))))))));
          break;
        }
        default: heff_nomatch(v_t_2431);
        }
        return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2442, v_s_2428});
      }
      default: return heff_nomatch(v_x2_2426);
      }
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_lam0(V self, V *args) {
  V v_v_2418 = args[0];
  V v_wanted_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2419 = ({ V a_0 = v_v_2418; V a_1 = v_wanted_2417; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2417); r_; });
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634_lam0, 1, 0};
V g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return ((V)&g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634_lam0_clo);
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_242, 0);
    V v_es_245 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_245)));
    V v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s873517001x1016672031(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_live_248 = (g_prelude_2e_2b_2b(v_t_247, heff_dup(v_live_241)));
    V v_m_249 = heff_tr(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(heff_dup(v_ce_240), v_live_248, v_e_244));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634_lam1, 1, 4, (V[]){v_m_249, v_ce_240, v_live_241, v_es_245});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_243});
}
V g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  V v_live_241 = heff_env(self)[2];
  V v_es_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2411 = heff_tr(heff_apply(v_m_249, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_m_2414 = (g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634(v_ce_240, v_live_241, v_es_245));
    V v_x2_2415 = heff_tr(heff_apply(v_m_2414, 1, (V[]){v_s_2413}));
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_MkPair: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      V v_s_2417 = heff_field(v_x2_2415, 1);
      heff_take_n(v_x2_2415, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_x_2416}), v_s_2417});
    }
    default: return heff_nomatch(v_x2_2415);
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2ecompile_2eemitc_2eupdateVal_24s612948083x338018248_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2eupdateVal_24s612948083x338018248_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eupdateVal_24s612948083x338018248_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eupdateVal_24s612948083x338018248_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eupdateVal_24s612948083x338018248(V v_ce_240, V v_live_241, V v_fs_242, V v_x_243) {
top: ;
  V v_t_244 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_242)));
  V v_t_245 = ({ V a_0 = v_t_244; V a_1 = heff_dup(v_x_243); V a_2 = heff_dup(v_fs_242); V r_ = (g_heff_2ecompile_2eemitc_2echangedOf(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  V v_t_246 = (g_list_2emap_24s1173914895x100384474(v_t_245));
  V v_m_247 = (g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634(v_ce_240, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), v_live_241}), v_t_246));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2eupdateVal_24s612948083x338018248_lam0, 1, 3, (V[]){v_m_247, v_fs_242, v_x_243});
}
V g_heff_2ecompile_2eemitc_2eupdateVal_24s612948083x338018248_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eupdateVal_24s612948083x338018248(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eemitc_2eupdateVal_24s612948083x338018248_lam1(V self, V *args) {
  V v_f_2418 = args[0];
  V v_ls_2417 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2419 = ({ V a_0 = v_ls_2417; V a_1 = v_f_2418; V r_ = (g_heff_2ecompile_2eemitc_2ekeptFrom(a_0, a_1)); heff_drop(v_ls_2417); heff_drop(v_f_2418); r_; });
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_Nothing: {
    heff_drop(v_x_243);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_y_2420 = heff_field(v_x2_2419, 0);
    heff_take_n(v_x2_2419, 1ULL, 1);
    return heff_strEq(v_x_243, v_y_2420);
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eemitc_2eupdateVal_24s612948083x338018248_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_fs_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_249 = heff_tr(heff_apply(v_m_247, 1, (V[]){v_s_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_t_2412 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_242)));
    V v_m_2413 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2eshapeLit_clo), 1, (V[]){v_t_2412}));
    V v_x2_2414 = heff_tr(heff_apply(v_m_2413, 1, (V[]){v_s_2411}));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_MkPair: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_s_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      V v_ls_2417 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_242)));
      V v_t_2421 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2eupdateVal_24s612948083x338018248_lam1, 1, 2, (V[]){v_ls_2417, heff_dup(v_x_243)}), heff_dup(v_fs_242)));
      V v_t_2422 = ({ V a_0 = v_t_2421; V r_ = (g_heff_2ecompile_2eemitc_2ekeepBits(a_0)); heff_drop(v_t_2421); r_; });
      V v_t_2423 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_fs_242));
      V v_t_2424 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_242)));
      V v_t_2425 = ({ V a_0 = v_t_2424; V a_1 = heff_dup(v_x_243); V a_2 = v_fs_242; V r_ = (g_heff_2ecompile_2eemitc_2echangedOf(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
      V v_x_2426 = (g_heff_2ecompile_2eemitc_2eupdateText(v_x_243, v_x_2415, v_t_2422, v_t_2423, v_x_2410, v_t_2425));
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2426, v_s_2416});
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_str0, 4, (78, 85, 76, 76));
HEFF_STRA(g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_str2, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_str3, 6, (40, 86, 91, 93, 41, 123));
HEFF_STRA(g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_str4, 1, (125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_str5, 11, (104, 101, 102, 102, 95, 114, 101, 99, 95, 110, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_str6, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_str7, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_str8, 1, (41));
V g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920(V v_ce_240, V v_live_241, V v_fs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_242)));
    V v_m_245 = (g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634(v_ce_240, v_live_241, v_t_244));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_lam0, 1, 2, (V[]){v_m_245, v_fs_242});
  }
  case TAG_Just: {
    V v_x_2423 = heff_field(v_x5_243, 0);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2eupdateVal_24s612948083x338018248(v_ce_240, v_live_241, v_fs_242, heff_dup(v_x_2423));
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
V g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_fs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_247 = heff_tr(heff_apply(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_242)));
    V v_m_2411 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2eshapeLit_clo), 1, (V[]){v_t_2410}));
    V v_x2_2412 = heff_tr(heff_apply(v_m_2411, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fs_242; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_fs_242); r_; });
      V v_t_2421;
      switch (heff_tag_of(v_x_248)) {
      case TAG_Nil: {
        v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_str0);
        break;
      }
      case TAG_Cons: {
        V v_t_2420;
        switch (heff_tag_of(v_x_248)) {
        case TAG_Nil: {
          v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_2418 = heff_field(v_x_248, 0);
          V v_xs_2419 = heff_field(v_x_248, 1);
          heff_take_n(v_x_248, 3ULL, 2);
          v_t_2420 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_str2); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
          break;
        }
        default: heff_nomatch(v_x_248);
        }
        v_t_2421 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_str3), heff_strAppend(v_t_2420, ((V)&g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_str4)));
        break;
      }
      default: heff_nomatch(v_x_248);
      }
      V v_x_2422 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_str5), heff_strAppend(heff_intShow(v_t_2415), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_str6), heff_strAppend(v_x_2413, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_str7), heff_strAppend(v_t_2421, ((V)&g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920_str8)))))));
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){v_x_2422, v_s_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str0, 11, (104, 101, 102, 102, 95, 103, 101, 116, 95, 110, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str1, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str2, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str3, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str4, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str5, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str6, 21, (104, 101, 102, 102, 95, 100, 117, 112, 40, 104, 101, 102, 102, 95, 114, 102, 105, 101, 108, 100, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str7, 8, (95, 103, 101, 116, 40, 41, 44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str8, 2, (41, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str9, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str10, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str11, 21, (104, 101, 102, 102, 95, 100, 117, 112, 40, 104, 101, 102, 102, 95, 114, 102, 105, 101, 108, 100, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str12, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str13, 2, (41, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str14, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str15, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str16, 11, (104, 101, 102, 102, 95, 103, 101, 116, 95, 110, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str17, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str18, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str19, 1, (41));
V g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_lam2(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_entry, 7, 0};

V g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906(V v_ce_240, V v_live_241, V v_e_242, V v_i_243, V v_n_244, V v_x7_245, V v_g_246) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_g_246)) {
    case TAG_Nothing: {
      V v_m_247 = heff_tr(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_lam0, 1, 3, (V[]){v_m_247, v_i_243, v_n_244});
    }
    case TAG_Just: {
      V v_g1_2413 = heff_field(v_g_246, 0);
      heff_drop_rec(v_ce_240, 12);
      heff_drop(v_live_241);
      heff_drop(v_e_242);
      heff_drop(v_n_244);
      V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str4), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_g1_2413), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str5))));
      V v_x_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str6), heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str7), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str8)))));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_lam1, 1, 1, (V[]){v_x_2415});
    }
    default: return heff_nomatch(v_g_246);
    }
  }
  case TAG_Just: {
    V v_x_2417 = heff_field(v_x7_245, 0);
    heff_drop(v_e_242);
    V v_t_2418 = ({ V a_0 = heff_dup(v_x_2417); V a_1 = v_live_241; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_live_241); r_; });
    V v_t_2419;
    switch (heff_tag_of(v_t_2418)) {
    case TAG_True: {
      heff_drop_rec(v_ce_240, 12);
      v_t_2419 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      v_t_2419 = ({ V a_0 = heff_dup(v_x_2417); V b_1 = heff_get_n(v_ce_240, 8, 12); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    V v_x_2422;
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      heff_drop(v_n_244);
      V v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str9), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_x_2417), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str10))));
      v_x_2422 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str11), heff_strAppend(v_t_2420, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str12), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str13)))));
      break;
    }
    case TAG_False: {
      V v_t_2421 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str14), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_x_2417), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str15))));
      v_x_2422 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str16), heff_strAppend(v_t_2421, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str17), heff_strAppend(heff_intShow(v_i_243), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str18), heff_strAppend(heff_intShow(v_n_244), ((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str19)))))));
      break;
    }
    default: heff_nomatch(v_t_2419);
    }
    return heff_clo_n(g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_lam2, 1, 1, (V[]){v_x_2422});
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[5]); heff_drop(a[6]); return r;
}
V g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_n_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_249 = heff_tr(heff_apply(v_m_247, 1, (V[]){v_s_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str0), heff_strAppend(v_x_2410, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str1), heff_strAppend(heff_intShow(v_i_243), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str2), heff_strAppend(heff_intShow(v_n_244), ((V)&g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_str3)))))));
    return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){v_t_2412, v_s_2411});
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_lam1(V self, V *args) {
  V v_s_2416 = args[0];
  V v_x_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2415, v_s_2416});
}
V g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906_lam2(V self, V *args) {
  V v_s_2423 = args[0];
  V v_x_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2422, v_s_2423});
}
Clo g_heff_2ecompile_2eemitc_2efieldAt_24s1436815667x2123639710_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efieldAt_24s1436815667x2123639710_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2efieldAt_24s1436815667x2123639710(V v_ce_240, V v_live_241, V v_e_242, V v_i_243, V v_n_244) {
top: ;
  V v_t_2435;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x_245 = heff_dup(heff_field(v_e_242, 0));
    v_t_2435 = heff_tag_n(TAG_Just, 1, (V[]){v_x_245});
    break;
  }
  case TAG_EGlobal: {
    v_t_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELam: {
    v_t_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EApp: {
    v_t_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELet: {
    v_t_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ERecord: {
    v_t_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EProj: {
    v_t_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ETag: {
    v_t_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EMatch: {
    v_t_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrim: {
    v_t_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ECall: {
    v_t_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EInt: {
    v_t_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat: {
    v_t_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EStr: {
    v_t_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFixed: {
    v_t_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat32: {
    v_t_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EAbandon: {
    v_t_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFix: {
    v_t_2435 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_e_242);
  }
  V v_t_2466;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    v_t_2466 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EGlobal: {
    V v_g_2437 = heff_dup(heff_field(v_e_242, 0));
    v_t_2466 = heff_tag_n(TAG_Just, 1, (V[]){v_g_2437});
    break;
  }
  case TAG_ELam: {
    v_t_2466 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EApp: {
    v_t_2466 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELet: {
    v_t_2466 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ERecord: {
    v_t_2466 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EProj: {
    v_t_2466 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ETag: {
    v_t_2466 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EMatch: {
    v_t_2466 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrim: {
    v_t_2466 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2466 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ECall: {
    v_t_2466 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EInt: {
    v_t_2466 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat: {
    v_t_2466 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EStr: {
    v_t_2466 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFixed: {
    v_t_2466 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat32: {
    v_t_2466 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EAbandon: {
    v_t_2466 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFix: {
    v_t_2466 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_e_242);
  }
  return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_e_242; V a_3 = v_i_243; V a_4 = v_n_244; V a_5 = v_t_2435; V a_6 = v_t_2466; V r_ = (g_heff_2ecompile_2eemitc_2efieldIn_24s1989104490x53100906(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2435); heff_drop(v_t_2466); r_; });
}
V g_heff_2ecompile_2eemitc_2efieldAt_24s1436815667x2123639710_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2efieldAt_24s1436815667x2123639710(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_str0, 4, (76, 66, 76, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_str2, 9, (104, 101, 102, 102, 95, 103, 101, 116, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_str3, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_str4, 1, (41));
V g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381(V v_ce_240, V v_live_241, V v_e_242, V v_l_243, V v_n_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nothing: {
    heff_drop(v_n_244);
    V v_m_246 = heff_tr(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_242));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_lam0, 1, 2, (V[]){v_m_246, v_l_243});
  }
  case TAG_Just: {
    V v_i_2413 = heff_field(v_x7_245, 0);
    V v_ru_24x7_245_24Just = heff_take_reuse_n(v_x7_245, 1ULL, 1);
    V v_t_2444;
    switch (heff_tag_of(v_e_242)) {
    case TAG_EVar: {
      V v_x_2414 = heff_dup(heff_field(v_e_242, 0));
      v_t_2444 = heff_tag_at_n(v_ru_24x7_245_24Just, TAG_Just, 1, (V[]){v_x_2414});
      break;
    }
    case TAG_EGlobal: {
      heff_drop_cell(v_ru_24x7_245_24Just, 1);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELam: {
      heff_drop_cell(v_ru_24x7_245_24Just, 1);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EApp: {
      heff_drop_cell(v_ru_24x7_245_24Just, 1);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELet: {
      heff_drop_cell(v_ru_24x7_245_24Just, 1);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ERecord: {
      heff_drop_cell(v_ru_24x7_245_24Just, 1);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EProj: {
      heff_drop_cell(v_ru_24x7_245_24Just, 1);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ETag: {
      heff_drop_cell(v_ru_24x7_245_24Just, 1);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EMatch: {
      heff_drop_cell(v_ru_24x7_245_24Just, 1);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrim: {
      heff_drop_cell(v_ru_24x7_245_24Just, 1);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrimCall: {
      heff_drop_cell(v_ru_24x7_245_24Just, 1);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ECall: {
      heff_drop_cell(v_ru_24x7_245_24Just, 1);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EInt: {
      heff_drop_cell(v_ru_24x7_245_24Just, 1);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat: {
      heff_drop_cell(v_ru_24x7_245_24Just, 1);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EStr: {
      heff_drop_cell(v_ru_24x7_245_24Just, 1);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFixed: {
      heff_drop_cell(v_ru_24x7_245_24Just, 1);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat32: {
      heff_drop_cell(v_ru_24x7_245_24Just, 1);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x7_245_24Just, 1);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFix: {
      heff_drop_cell(v_ru_24x7_245_24Just, 1);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_e_242);
    }
    V v_x7_2445 = (g_heff_2ecompile_2eemitc_2etakeVarIn(heff_rfield(v_ce_240, 11), v_live_241, v_t_2444, v_l_243, heff_dup(v_i_2413)));
    switch (heff_tag_of(v_x7_2445)) {
    case TAG_Nothing: {
      return (g_heff_2ecompile_2eemitc_2efieldAt_24s1436815667x2123639710(v_ce_240, v_live_241, v_e_242, v_i_2413, v_n_244));
    }
    case TAG_Just: {
      V v_t_2446 = heff_field(v_x7_2445, 0);
      heff_take_n(v_x7_2445, 1ULL, 1);
      heff_drop_rec(v_ce_240, 12);
      heff_drop(v_live_241);
      heff_drop(v_e_242);
      heff_drop(v_n_244);
      heff_drop(v_i_2413);
      return heff_clo_n(g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_lam1, 1, 1, (V[]){v_t_2446});
    }
    default: return heff_nomatch(v_x7_2445);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_lam0(V self, V *args) {
  V v_s_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_l_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_248 = heff_tr(heff_apply(v_m_246, 1, (V[]){v_s_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_s_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_str0), (g_heff_2ecompile_2eemitc_2emangleW(v_l_243, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_str1))));
    V v_x_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_str2), heff_strAppend(v_x_249, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_str3), heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_str4)))));
    return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_x_2412, v_s_2410});
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381_lam1(V self, V *args) {
  V v_s_2447 = args[0];
  V v_t_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2446, v_s_2447});
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str0, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str1, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str2, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str3, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str4, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str5, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str6, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str7, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str8, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str9, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str10, 4, (84, 65, 71, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str11, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str12, 4, (78, 85, 76, 76));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str13, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str14, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str15, 6, (40, 86, 91, 93, 41, 123));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str16, 1, (125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str17, 14, (104, 101, 102, 102, 95, 116, 97, 103, 95, 97, 116, 95, 110, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str18, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str19, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str20, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str21, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str22, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str23, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str24, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str25, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str26, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str27, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str28, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str29, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str30, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str31, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str32, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str33, 1, (48));
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam0, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam1(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam1, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam2(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam2, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam3(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam3, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam4(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam4, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam5(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam5, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam6(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam6, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam7(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam7, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam8(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam8, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam9(V self, V *args);
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam10(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam10, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam11(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam11, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam12(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam12, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam13(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam13, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam14(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam14, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam15(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam15, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam16(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam16, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam17(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam17, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam18(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam18, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam19(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam19, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam20(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam20, 1, 0};
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam21(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam21, 1, 0};
Clo g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam0_clo);
  }
  case TAG_Cons: {
    V v_ru_244 = heff_field(v_x4_242, 0);
    V v_x42_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x42_245)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_ru_244);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam1_clo);
    }
    case TAG_Cons: {
      V v_x421_247 = heff_field(v_x42_245, 0);
      V v_x422_248 = heff_field(v_x42_245, 1);
      heff_take_n(v_x42_245, 3ULL, 2);
      switch (heff_tag_of(v_x421_247)) {
      case TAG_EVar: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam2_clo);
      }
      case TAG_EGlobal: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam3_clo);
      }
      case TAG_ELam: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam4_clo);
      }
      case TAG_EApp: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam5_clo);
      }
      case TAG_ELet: {
        heff_take_n(v_x421_247, 0ULL, 3);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam6_clo);
      }
      case TAG_ERecord: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam7_clo);
      }
      case TAG_EProj: {
        heff_take_n(v_x421_247, 0ULL, 3);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam8_clo);
      }
      case TAG_ETag: {
        V v_t_2429 = heff_field(v_x421_247, 0);
        V v_as_2430 = heff_field(v_x421_247, 1);
        heff_take_n(v_x421_247, 3ULL, 2);
        switch (heff_tag_of(v_x422_248)) {
        case TAG_Nil: {
          V v_m_2431 = (g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634(v_ce_240, v_live_241, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_ru_244, heff_dup(v_as_2430)})));
          return heff_clo_n(g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam9, 1, 3, (V[]){v_m_2431, v_t_2429, v_as_2430});
        }
        case TAG_Cons: {
          heff_take_n(v_x422_248, 0ULL, 2);
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          heff_drop(v_ru_244);
          heff_drop_cell(v_ru_24x4_242_24Cons, 2);
          heff_drop(v_t_2429);
          heff_drop(v_as_2430);
          return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam10_clo);
        }
        default: return heff_nomatch(v_x422_248);
        }
      }
      case TAG_EMatch: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam11_clo);
      }
      case TAG_EPrim: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam12_clo);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam13_clo);
      }
      case TAG_ECall: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam14_clo);
      }
      case TAG_EInt: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam15_clo);
      }
      case TAG_EFloat: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam16_clo);
      }
      case TAG_EStr: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam17_clo);
      }
      case TAG_EFixed: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam18_clo);
      }
      case TAG_EFloat32: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam19_clo);
      }
      case TAG_EAbandon: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam20_clo);
      }
      case TAG_EFix: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam21_clo);
      }
      default: return heff_nomatch(v_x421_247);
      }
    }
    default: return heff_nomatch(v_x42_245);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str0), v_s_243});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam1(V self, V *args) {
  V v_s_246 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str1), v_s_246});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str2), v_s_2410});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam3(V self, V *args) {
  V v_s_2412 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str3), v_s_2412});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam4(V self, V *args) {
  V v_s_2415 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str4), v_s_2415});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam5(V self, V *args) {
  V v_s_2418 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str5), v_s_2418});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam6(V self, V *args) {
  V v_s_2422 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str6), v_s_2422});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam7(V self, V *args) {
  V v_s_2424 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str7), v_s_2424});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam8(V self, V *args) {
  V v_s_2428 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str8), v_s_2428});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam9(V self, V *args) {
  V v_s_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_t_2429 = heff_env(self)[1];
  V v_as_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2433 = heff_tr(heff_apply(v_m_2431, 1, (V[]){v_s_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_s_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_x2_2438;
    switch (heff_tag_of(v_x_2434)) {
    case TAG_Nil: {
      v_x2_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2436 = heff_dup(heff_field(v_x_2434, 0));
      v_x2_2438 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2436});
      break;
    }
    default: heff_nomatch(v_x_2434);
    }
    V v_t_2440;
    switch (heff_tag_of(v_x2_2438)) {
    case TAG_Nothing: {
      v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str9);
      break;
    }
    case TAG_Just: {
      V v_x_2439 = heff_field(v_x2_2438, 0);
      heff_take_n(v_x2_2438, 1ULL, 1);
      v_t_2440 = v_x_2439;
      break;
    }
    default: heff_nomatch(v_x2_2438);
    }
    V v_t_2441 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str10), (g_heff_2ecompile_2eemitc_2emangleW(v_t_2429, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str11))));
    V v_t_2442 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_as_2430; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_as_2430); r_; });
    V v_vs_2443 = (g_list_2edrop(MK_INT(1LL), v_x_2434));
    V v_t_2449;
    switch (heff_tag_of(v_vs_2443)) {
    case TAG_Nil: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str12);
      break;
    }
    case TAG_Cons: {
      V v_t_2448;
      switch (heff_tag_of(v_vs_2443)) {
      case TAG_Nil: {
        v_t_2448 = ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2446 = heff_field(v_vs_2443, 0);
        V v_xs_2447 = heff_field(v_vs_2443, 1);
        heff_take_n(v_vs_2443, 3ULL, 2);
        v_t_2448 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str14); V a_1 = v_x_2446; V a_2 = v_xs_2447; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2447); r_; });
        break;
      }
      default: heff_nomatch(v_vs_2443);
      }
      v_t_2449 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str15), heff_strAppend(v_t_2448, ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str16)));
      break;
    }
    default: heff_nomatch(v_vs_2443);
    }
    V v_x_2450 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str17), heff_strAppend(v_t_2440, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str18), heff_strAppend(v_t_2441, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str19), heff_strAppend(heff_intShow(v_t_2442), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str20), heff_strAppend(v_t_2449, ((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str21)))))))));
    return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){v_x_2450, v_s_2435});
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam10(V self, V *args) {
  V v_s_2453 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str22), v_s_2453});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam11(V self, V *args) {
  V v_s_2456 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str23), v_s_2456});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam12(V self, V *args) {
  V v_s_2458 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str24), v_s_2458});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam13(V self, V *args) {
  V v_s_2461 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str25), v_s_2461});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam14(V self, V *args) {
  V v_s_2464 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str26), v_s_2464});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam15(V self, V *args) {
  V v_s_2466 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str27), v_s_2466});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam16(V self, V *args) {
  V v_s_2468 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str28), v_s_2468});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam17(V self, V *args) {
  V v_s_2470 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str29), v_s_2470});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam18(V self, V *args) {
  V v_s_2473 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str30), v_s_2473});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam19(V self, V *args) {
  V v_s_2475 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str31), v_s_2475});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam20(V self, V *args) {
  V v_s_2476 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str32), v_s_2476});
}
V g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_lam21(V self, V *args) {
  V v_s_2479 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047_str33), v_s_2479});
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str0, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str2, 9, (104, 101, 102, 102, 95, 100, 117, 112, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str3, 7, (95, 103, 101, 116, 40, 41, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str4, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str5, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str6, 5, (40, 40, 86, 41, 38));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str7, 5, (95, 99, 108, 111, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str8, 4, (84, 65, 71, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str9, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str10, 5, (78, 84, 65, 71, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str11, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str12, 4, (84, 65, 71, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str13, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str14, 4, (78, 85, 76, 76));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str15, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str16, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str17, 6, (40, 86, 91, 93, 41, 123));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str18, 1, (125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str19, 11, (104, 101, 102, 102, 95, 116, 97, 103, 95, 110, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str20, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str21, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str22, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str23, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str24, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str25, 5, (104, 101, 102, 102, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str26, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str27, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str28, 7, (77, 75, 95, 73, 78, 84, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str29, 3, (76, 76, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str30, 10, (72, 69, 70, 70, 95, 66, 73, 71, 40, 34));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str31, 2, (34, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str32, 10, (72, 69, 70, 70, 95, 66, 73, 71, 40, 34));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str33, 2, (34, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str34, 3, (78, 97, 78));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str35, 13, (104, 101, 102, 102, 95, 102, 108, 116, 40, 78, 65, 78, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str36, 8, (73, 110, 102, 105, 110, 105, 116, 121));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str37, 18, (104, 101, 102, 102, 95, 102, 108, 116, 40, 73, 78, 70, 73, 78, 73, 84, 89, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str38, 9, (45, 73, 110, 102, 105, 110, 105, 116, 121));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str39, 19, (104, 101, 102, 102, 95, 102, 108, 116, 40, 45, 73, 78, 70, 73, 78, 73, 84, 89, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str40, 9, (104, 101, 102, 102, 95, 102, 108, 116, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str41, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str42, 16, (104, 101, 102, 102, 95, 102, 51, 50, 40, 40, 102, 108, 111, 97, 116, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str43, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str44, 14, (104, 101, 102, 102, 95, 97, 98, 97, 110, 100, 111, 110, 40, 41));
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam8(V self, V *args);
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam9(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam9, 1, 0};
Clo g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(V v_ce_240, V v_live_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_x_244 = ({ V b_0 = heff_get_n(v_ce_240, 8, 12); V a_1 = v_live_241; V a_2 = v_x_243; V r_ = (g_heff_2ecompile_2eemitc_2evarUse(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_live_241); r_; });
    return heff_clo_n(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam0, 1, 1, (V[]){v_x_244});
  }
  case TAG_EGlobal: {
    V v_g_246 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_live_241);
    V v_x3_247 = ({ V a_0 = heff_dup(v_g_246); V b_1 = heff_get_n(v_ce_240, 2, 12); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
    V v_x_2411;
    switch (heff_tag_of(v_x3_247)) {
    case TAG_Nothing: {
      V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str0), (g_heff_2ecompile_2eemitc_2emangleW(v_g_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str1))));
      v_x_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str2), heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str3)));
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_247, 0ULL, 1);
      V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str4), (g_heff_2ecompile_2eemitc_2emangleW(v_g_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str5))));
      v_x_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str6), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str7)));
      break;
    }
    default: heff_nomatch(v_x3_247);
    }
    return heff_clo_n(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam1, 1, 1, (V[]){v_x_2411});
  }
  case TAG_ELam: {
    V v_xs_2413 = heff_field(v_e_242, 0);
    V v_b_2414 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2415 = (g_heff_2ecompile_2eemitc_2efreeOf(heff_dup(v_xs_2413), heff_dup(v_b_2414)));
    return heff_tail(((V)&g_heff_2ecompile_2eemitc_2elamWith_24s903847300x489431523_clo), 5, (V[]){v_ce_240, v_live_241, v_xs_2413, v_b_2414, v_t_2415});
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_ELet: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_ERecord: {
    V v_fs_2421 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_t_2422 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2421)));
    V v_t_2423 = (g_heff_2ecompile_2eemitc_2eupdatedIn(heff_dup(v_ce_240), v_live_241, v_t_2422, heff_dup(v_fs_2421)));
    return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_fs_2421; V a_3 = v_t_2423; V r_ = (g_heff_2ecompile_2eemitc_2erecordVal_24s1571608585x1959996920(a_0, a_1, a_2, a_3)); heff_drop(v_t_2423); r_; });
  }
  case TAG_EProj: {
    V v_e1_2424 = heff_field(v_e_242, 0);
    V v_l_2425 = heff_field(v_e_242, 1);
    V v_sh_2426 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_2427 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_sh_2426));
    V v_t_2428 = ({ V a_0 = heff_dup(v_l_2425); V a_1 = MK_INT(0LL); V a_2 = v_sh_2426; V r_ = (g_heff_2ecompile_2eemitc_2eindexIn(a_0, a_1, a_2)); heff_drop(v_sh_2426); r_; });
    return (g_heff_2ecompile_2eemitc_2eprojAt_24s524213169x1958674381(v_ce_240, v_live_241, v_e1_2424, v_l_2425, v_t_2427, v_t_2428));
  }
  case TAG_ETag: {
    V v_t_2429 = heff_field(v_e_242, 0);
    V v_as_2430 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2433;
    switch (heff_tag_of(v_as_2430)) {
    case TAG_Nil: {
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_as_2430);
    }
    switch (heff_tag_of(v_t_2433)) {
    case TAG_True: {
      heff_drop_rec(v_ce_240, 12);
      heff_drop(v_live_241);
      heff_drop(v_as_2430);
      V v_t_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str8), (g_heff_2ecompile_2eemitc_2emangleW(v_t_2429, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str9))));
      V v_x_2435 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str10), heff_strAppend(v_t_2434, ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str11)));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam2, 1, 1, (V[]){v_x_2435});
    }
    case TAG_False: {
      V v_m_2437 = (g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634(v_ce_240, v_live_241, heff_dup(v_as_2430)));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam3, 1, 3, (V[]){v_m_2437, v_t_2429, v_as_2430});
    }
    default: return heff_nomatch(v_t_2433);
    }
  }
  case TAG_EMatch: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EPrim: {
    V v_p_2453 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 12);
    heff_drop(v_live_241);
    return heff_tail(((V)&g_heff_2ecompile_2eemitc_2eprimLit_clo), 1, (V[]){v_p_2453});
  }
  case TAG_EPrimCall: {
    V v_p_2454 = heff_field(v_e_242, 0);
    V v_as_2455 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_p_2454), heff_dup(g_heff_2ecompile_2eemitc_2ereusePrim_get()))) {
      heff_drop(v_p_2454);
      HEFF_LAST return g_heff_2ecompile_2eemitc_2ereuseVal_24s1487554939x1108810047(v_ce_240, v_live_241, v_as_2455);
    } else {
      V v_m_2457 = (g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634(v_ce_240, v_live_241, v_as_2455));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam4, 1, 2, (V[]){v_m_2457, v_p_2454});
    }
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EInt: {
    V v_n_2468 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 12);
    heff_drop(v_live_241);
    V v_x_2471;
    if (heff_intLt_c(heff_dup(v_n_2468), HEFF_BIG("4611686018427387904"))) {
      if (heff_intLe_c(MK_INT(-4611686018427387904LL), heff_dup(v_n_2468))) {
        v_x_2471 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str28), heff_strAppend(heff_intShow(v_n_2468), ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str29)));
      } else {
        v_x_2471 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str30), heff_strAppend(heff_intShow(v_n_2468), ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str31)));
      }
    } else {
      v_x_2471 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str32), heff_strAppend(heff_intShow(v_n_2468), ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str33)));
    }
    return heff_clo_n(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam5, 1, 1, (V[]){v_x_2471});
  }
  case TAG_EFloat: {
    V v_x_2473 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 12);
    heff_drop(v_live_241);
    V v_x_2477;
    if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2473)), ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str34))) {
      heff_drop(v_x_2473);
      v_x_2477 = ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str35);
    } else {
      if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2473)), ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str36))) {
        heff_drop(v_x_2473);
        v_x_2477 = ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str37);
      } else {
        if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2473)), ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str38))) {
          heff_drop(v_x_2473);
          v_x_2477 = ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str39);
        } else {
          v_x_2477 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str40), heff_strAppend(heff_floatShow(v_x_2473), ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str41)));
        }
      }
    }
    return heff_clo_n(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam6, 1, 1, (V[]){v_x_2477});
  }
  case TAG_EStr: {
    V v_s_2479 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 12);
    heff_drop(v_live_241);
    return heff_tail(((V)&g_heff_2ecompile_2eemitc_2estrLit_clo), 1, (V[]){v_s_2479});
  }
  case TAG_EFixed: {
    V v_w_2480 = heff_field(v_e_242, 0);
    V v_n_2481 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    heff_drop_rec(v_ce_240, 12);
    heff_drop(v_live_241);
    V v_x_2482 = ({ V a_0 = v_w_2480; V a_1 = v_n_2481; V r_ = (g_heff_2ecompile_2eemitc_2efixedLit(a_0, a_1)); heff_drop(v_w_2480); r_; });
    return heff_clo_n(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam7, 1, 1, (V[]){v_x_2482});
  }
  case TAG_EFloat32: {
    V v_x_2484 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 12);
    heff_drop(v_live_241);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam8, 1, 1, (V[]){v_x_2484});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_ce_240, 12);
    heff_drop(v_live_241);
    return ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam9_clo);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, v_live_241, v_e_242);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_244, v_s_245});
}
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_s_2412});
}
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam2(V self, V *args) {
  V v_s_2436 = args[0];
  V v_x_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2435, v_s_2436});
}
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam3(V self, V *args) {
  V v_s_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  V v_t_2429 = heff_env(self)[1];
  V v_as_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2439 = heff_tr(heff_apply(v_m_2437, 1, (V[]){v_s_2438}));
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_field(v_x2_2439, 0);
    V v_s_2441 = heff_field(v_x2_2439, 1);
    V v_ru_24x2_2439_24MkPair = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
    V v_t_2442 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str12), (g_heff_2ecompile_2eemitc_2emangleW(v_t_2429, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str13))));
    V v_t_2443 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_as_2430; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_as_2430); r_; });
    V v_t_2449;
    switch (heff_tag_of(v_x_2440)) {
    case TAG_Nil: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str14);
      break;
    }
    case TAG_Cons: {
      V v_t_2448;
      switch (heff_tag_of(v_x_2440)) {
      case TAG_Nil: {
        v_t_2448 = ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str15);
        break;
      }
      case TAG_Cons: {
        V v_x_2446 = heff_field(v_x_2440, 0);
        V v_xs_2447 = heff_field(v_x_2440, 1);
        heff_take_n(v_x_2440, 3ULL, 2);
        v_t_2448 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str16); V a_1 = v_x_2446; V a_2 = v_xs_2447; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2447); r_; });
        break;
      }
      default: heff_nomatch(v_x_2440);
      }
      v_t_2449 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str17), heff_strAppend(v_t_2448, ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str18)));
      break;
    }
    default: heff_nomatch(v_x_2440);
    }
    V v_x_2450 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str19), heff_strAppend(v_t_2442, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str20), heff_strAppend(heff_intShow(v_t_2443), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str21), heff_strAppend(v_t_2449, ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str22)))))));
    return heff_tag_at_n(v_ru_24x2_2439_24MkPair, TAG_MkPair, 2, (V[]){v_x_2450, v_s_2441});
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam4(V self, V *args) {
  V v_s_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_p_2454 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2459 = heff_tr(heff_apply(v_m_2457, 1, (V[]){v_s_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_s_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    V v_t_2464;
    switch (heff_tag_of(v_x_2460)) {
    case TAG_Nil: {
      v_t_2464 = ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str23);
      break;
    }
    case TAG_Cons: {
      V v_x_2462 = heff_field(v_x_2460, 0);
      V v_xs_2463 = heff_field(v_x_2460, 1);
      heff_take_n(v_x_2460, 3ULL, 2);
      v_t_2464 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str24); V a_1 = v_x_2462; V a_2 = v_xs_2463; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2463); r_; });
      break;
    }
    default: heff_nomatch(v_x_2460);
    }
    V v_x_2465 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str25), v_p_2454), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str26), heff_strAppend(v_t_2464, ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str27))));
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){v_x_2465, v_s_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam5(V self, V *args) {
  V v_s_2472 = args[0];
  V v_x_2471 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2471, v_s_2472});
}
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam6(V self, V *args) {
  V v_s_2478 = args[0];
  V v_x_2477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2477, v_s_2478});
}
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam7(V self, V *args) {
  V v_s_2483 = args[0];
  V v_x_2482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2482, v_s_2483});
}
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam8(V self, V *args) {
  V v_s_2485 = args[0];
  V v_x_2484 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2486 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str42), heff_strAppend(heff_floatShow(v_x_2484), ((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str43)));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2486, v_s_2485});
}
V g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_lam9(V self, V *args) {
  V v_s_2487 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982_str44), v_s_2487});
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_str0, 2, (98, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_str1, 4, (86, 32, 98, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_str2, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_str3, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_str4, 12, (104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_str5, 2, (41, 59));
V g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_lam2(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061(V v_ce_240, V v_live_241, V v_bi_242, V v_i_243, V v_e_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nothing: {
    V v_m_246 = heff_tr(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_244));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_lam0, 1, 3, (V[]){v_m_246, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_Just: {
    V v_x_2418 = heff_field(v_x7_245, 0);
    V v_t_2419 = (g_heff_2ecompile_2eemitc_2eelemI(v_i_243, v_bi_242));
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      heff_drop(v_e_244);
      V v_x_2420 = ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = heff_dup(v_x_2418); V r_ = (g_heff_2ecompile_2eemitc_2elentVar(a_0, a_1, a_2)); heff_drop(v_live_241); r_; });
      return heff_clo_n(g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_lam1, 1, 1, (V[]){v_x_2420});
    }
    case TAG_False: {
      V v_m_2422 = heff_tr(g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_244));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_lam2, 1, 1, (V[]){v_m_2422});
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[2]); heff_drop(a[5]); return r;
}
V g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_lam0(V self, V *args) {
  V v_s_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_apply(v_m_246, 1, (V[]){v_s_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_s_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_t_2411 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2ecompile_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_2417;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_str0), heff_intShow(heff_dup(v_i_243)));
      V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_str1), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_str2), heff_strAppend(v_x_249, ((V)&g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_str3)))));
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
      V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_str4), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_str5)));
      V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
      v_x_2417 = heff_rec_n(3, shape_arg__pre__post, (V[]){v_t_2412, v_t_2414, v_t_2416});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_248_24MkPair, 2);
      v_x_2417 = heff_rec_n(3, shape_arg__pre__post, (V[]){v_x_249, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_s_2410});
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_lam1(V self, V *args) {
  V v_s_2421 = args[0];
  V v_x_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2420, v_s_2421});
}
V g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061_lam2(V self, V *args) {
  V v_s_2423 = args[0];
  V v_m_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2424 = heff_tr(heff_apply(v_m_2422, 1, (V[]){v_s_2423}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_s_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    V v_t_2427 = heff_rec_n(3, shape_arg__pre__post, (V[]){v_x_2425, NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, (V[]){v_t_2427, v_s_2426});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2eemitc_2elentOr_24s341891767x1199481071_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2elentOr_24s341891767x1199481071_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elentOr_24s341891767x1199481071_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2elentOr_24s341891767x1199481071(V v_ce_240, V v_live_241, V v_bi_242, V v_i_243, V v_e_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nothing: {
    V v_t_2436;
    switch (heff_tag_of(v_e_244)) {
    case TAG_EVar: {
      V v_x_246 = heff_dup(heff_field(v_e_244, 0));
      v_t_2436 = heff_tag_n(TAG_Just, 1, (V[]){v_x_246});
      break;
    }
    case TAG_EGlobal: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELam: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EApp: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELet: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ERecord: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EProj: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ETag: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EMatch: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrim: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ECall: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EInt: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EStr: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFixed: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat32: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EAbandon: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFix: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_e_244);
    }
    return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_bi_242; V a_3 = v_i_243; V a_4 = v_e_244; V a_5 = v_t_2436; V r_ = (g_heff_2ecompile_2eemitc_2elentVarOr_24s689748158x2107457061(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2436); r_; });
  }
  case TAG_Just: {
    V v_a_2437 = heff_field(v_x7_245, 0);
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    heff_drop(v_i_243);
    heff_drop(v_e_244);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2elentOr_24s341891767x1199481071_lam0, 1, 1, (V[]){heff_dup(v_a_2437)});
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2eemitc_2elentOr_24s341891767x1199481071_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2elentOr_24s341891767x1199481071(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[2]); heff_drop(a[5]); return r;
}
V g_heff_2ecompile_2eemitc_2elentOr_24s341891767x1199481071_lam0(V self, V *args) {
  V v_s_2438 = args[0];
  V v_a_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2439 = heff_rec_n(3, shape_arg__pre__post, (V[]){v_a_2437, NTAG(TAG_Nil), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2439, v_s_2438});
}
V g_heff_2ecompile_2eemitc_2elentOperands_24s476183159x330509729_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2elentOperands_24s476183159x330509729_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elentOperands_24s476183159x330509729_lam0, 1, 0};
V g_heff_2ecompile_2eemitc_2elentOperands_24s476183159x330509729_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2elentOperands_24s476183159x330509729_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elentOperands_24s476183159x330509729_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2elentOperands_24s476183159x330509729(V v_ce_240, V v_live_241, V v_bi_242, V v_i_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    heff_drop(v_i_243);
    return ((V)&g_heff_2ecompile_2eemitc_2elentOperands_24s476183159x330509729_lam0_clo);
  }
  case TAG_Cons: {
    V v_e_246 = heff_field(v_x6_244, 0);
    V v_es_247 = heff_field(v_x6_244, 1);
    heff_take_n(v_x6_244, 3ULL, 2);
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_247)));
    V v_t_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s873517001x1016672031(a_0, a_1)); heff_drop(v_t_248); r_; });
    V v_live_2410 = (g_prelude_2e_2b_2b(v_t_249, heff_dup(v_live_241)));
    V v_t_2411 = (g_heff_2ecompile_2eemitc_2eelemI(heff_dup(v_i_243), v_bi_242));
    V v_t_2412;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      v_t_2412 = (g_heff_2ecompile_2eemitc_2elentField(heff_dup(v_ce_240), v_live_241, v_e_246));
      break;
    }
    case TAG_False: {
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    V v_m_2413 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_live_2410; V a_2 = v_bi_242; V a_3 = heff_dup(v_i_243); V a_4 = v_e_246; V a_5 = v_t_2412; V r_ = (g_heff_2ecompile_2eemitc_2elentOr_24s341891767x1199481071(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2412); r_; });
    return heff_clo_n(g_heff_2ecompile_2eemitc_2elentOperands_24s476183159x330509729_lam1, 1, 6, (V[]){v_m_2413, v_ce_240, v_live_241, heff_dup(v_bi_242), v_i_243, v_es_247});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ecompile_2eemitc_2elentOperands_24s476183159x330509729_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2elentOperands_24s476183159x330509729(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2ecompile_2eemitc_2elentOperands_24s476183159x330509729_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_245});
}
V g_heff_2ecompile_2eemitc_2elentOperands_24s476183159x330509729_lam1(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  V v_live_241 = heff_env(self)[2];
  V v_bi_242 = heff_env(self)[3];
  V v_i_243 = heff_env(self)[4];
  V v_es_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2415 = heff_tr(heff_apply(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    V v_m_2418 = ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_bi_242; V a_3 = heff_intAdd(v_i_243, MK_INT(1LL)); V a_4 = v_es_247; V r_ = (g_heff_2ecompile_2eemitc_2elentOperands_24s476183159x330509729(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_bi_242); r_; });
    V v_x2_2419 = heff_tr(heff_apply(v_m_2418, 1, (V[]){v_s_2417}));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_s_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2416, v_x_2420}), v_s_2421});
    }
    default: return heff_nomatch(v_x2_2419);
    }
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str0, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str1, 4, (78, 85, 76, 76));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str3, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str4, 6, (40, 86, 91, 93, 41, 123));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str5, 1, (125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str6, 19, (104, 101, 102, 102, 95, 116, 114, 40, 104, 101, 102, 102, 95, 97, 112, 112, 108, 121, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str7, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str8, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str9, 2, (41, 41));
V g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(V v_ce_240, V v_live_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EApp: {
    V v_f_247 = heff_field(v_e_242, 0);
    V v_as_248 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_m_249 = (g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634(v_ce_240, v_live_241, heff_tag_at_n(v_ru_24e_242_24EApp, TAG_Cons, 2, (V[]){v_f_247, heff_dup(v_as_248)})));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_lam0, 1, 2, (V[]){v_m_249, v_as_248});
  }
  case TAG_ELet: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EMatch: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_ECall: {
    V v_g_2442 = heff_field(v_e_242, 0);
    V v_as_2443 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_x2_2444 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_2442), heff_rfield(v_ce_240, 9)));
    V v_t_2446;
    switch (heff_tag_of(v_x2_2444)) {
    case TAG_Nothing: {
      v_t_2446 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2445 = heff_field(v_x2_2444, 0);
      heff_take_n(v_x2_2444, 1ULL, 1);
      v_t_2446 = v_x_2445;
      break;
    }
    default: heff_nomatch(v_x2_2444);
    }
    V v_m_2447 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_live_241; V a_2 = v_t_2446; V a_3 = MK_INT(0LL); V a_4 = v_as_2443; V r_ = (g_heff_2ecompile_2eemitc_2elentOperands_24s476183159x330509729(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2446); r_; });
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_lam1, 1, 3, (V[]){v_m_2447, v_g_2442, v_ce_240});
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, v_live_241, v_e_242);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_lam0(V self, V *args) {
  V v_s_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_as_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2411 = heff_tr(heff_apply(v_m_249, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_x2_2416;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_Nil: {
      v_x2_2416 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_dup(heff_field(v_x_2412, 0));
      v_x2_2416 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2414});
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_t_2418;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nothing: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str0);
      break;
    }
    case TAG_Just: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      heff_take_n(v_x2_2416, 1ULL, 1);
      v_t_2418 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    V v_t_2419 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_as_248; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_as_248); r_; });
    V v_vs_2420 = (g_list_2edrop(MK_INT(1LL), v_x_2412));
    V v_t_2426;
    switch (heff_tag_of(v_vs_2420)) {
    case TAG_Nil: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str1);
      break;
    }
    case TAG_Cons: {
      V v_t_2425;
      switch (heff_tag_of(v_vs_2420)) {
      case TAG_Nil: {
        v_t_2425 = ((V)&g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2423 = heff_field(v_vs_2420, 0);
        V v_xs_2424 = heff_field(v_vs_2420, 1);
        heff_take_n(v_vs_2420, 3ULL, 2);
        v_t_2425 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str3); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
        break;
      }
      default: heff_nomatch(v_vs_2420);
      }
      v_t_2426 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str4), heff_strAppend(v_t_2425, ((V)&g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str5)));
      break;
    }
    default: heff_nomatch(v_vs_2420);
    }
    V v_x_2427 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str6), heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str7), heff_strAppend(heff_intShow(v_t_2419), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str8), heff_strAppend(v_t_2426, ((V)&g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_str9)))))));
    return heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){v_x_2427, v_s_2413});
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487_lam1(V self, V *args) {
  V v_s_2448 = args[0];
  V v_m_2447 = heff_env(self)[0];
  V v_g_2442 = heff_env(self)[1];
  V v_ce_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2449 = heff_tr(heff_apply(v_m_2447, 1, (V[]){v_s_2448}));
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_MkPair: {
    V v_x_2450 = heff_field(v_x2_2449, 0);
    V v_s_2451 = heff_field(v_x2_2449, 1);
    V v_ru_24x2_2449_24MkPair = heff_take_reuse_n(v_x2_2449, 3ULL, 2);
    V v_x3_2452 = ({ V a_0 = heff_dup(v_g_2442); V b_1 = heff_get_n(v_ce_240, 3, 12); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2454;
    switch (heff_tag_of(v_x3_2452)) {
    case TAG_Nothing: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_2452, 0ULL, 1);
      v_t_2454 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_2452);
    }
    V v_x_2455 = ({ V a_0 = v_g_2442; V a_1 = v_t_2454; V a_2 = v_x_2450; V r_ = (g_heff_2ecompile_2eemitc_2ecallText(a_0, a_1, a_2)); heff_drop(v_t_2454); r_; });
    return heff_tag_at_n(v_ru_24x2_2449_24MkPair, TAG_MkPair, 2, (V[]){v_x_2455, v_s_2451});
  }
  default: return heff_nomatch(v_x2_2449);
  }
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str0, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str2, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str3, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str4, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str5, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str6, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str7, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str8, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str9, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str10, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str11, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str12, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str13, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str14, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str15, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str16, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str17, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str18, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str19, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str20, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str21, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str22, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str23, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str24, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str25, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str26, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str27, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str28, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str29, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str30, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str31, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str32, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str33, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str34, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str35, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str36, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str37, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str38, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str39, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str40, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str41, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str42, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str43, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str44, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str45, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str46, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str47, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str48, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str49, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str50, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str51, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str52, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str53, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str54, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str55, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str56, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str57, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str58, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str59, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str60, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str61, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str62, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str63, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str64, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str65, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str66, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str67, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str68, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str69, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str70, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str71, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str72, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str73, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str74, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str75, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str76, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str77, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str78, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str79, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str80, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str81, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str82, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str83, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str84, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str85, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str86, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str87, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str88, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str89, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str90, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str91, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str92, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str93, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str94, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str95, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str96, 1, (59));
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam8(V self, V *args);
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam9(V self, V *args);
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam10(V self, V *args);
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam11(V self, V *args);
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam12(V self, V *args);
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam13(V self, V *args);
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam14(V self, V *args);
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam15(V self, V *args);
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam16(V self, V *args);
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam17(V self, V *args);
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam18(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862(V v_ce_240, V v_x_241, V v_a_242) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    V v_m_244 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_a_242));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam0, 1, 2, (V[]){v_m_244, v_x_241});
  }
  case TAG_EGlobal: {
    V v_m_2413 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_a_242));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam1, 1, 2, (V[]){v_m_2413, v_x_241});
  }
  case TAG_ELam: {
    V v_m_2423 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_a_242));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam2, 1, 2, (V[]){v_m_2423, v_x_241});
  }
  case TAG_EApp: {
    V v_m_2433 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_a_242));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam3, 1, 2, (V[]){v_m_2433, v_x_241});
  }
  case TAG_ELet: {
    V v_y_2441 = heff_field(v_a_242, 0);
    V v_a2_2442 = heff_field(v_a_242, 1);
    V v_b_2443 = heff_field(v_a_242, 2);
    V v_ru_24a_242_24ELet = heff_take_reuse_n(v_a_242, 7ULL, 3);
    V v_t_2444 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str20), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_x_241), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str21))));
    V v_dest_2445 = heff_tag_n(TAG_Asg, 1, (V[]){v_t_2444});
    V v_m_2446 = (g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499(v_ce_240, v_dest_2445, heff_tag_at_n(v_ru_24a_242_24ELet, TAG_ELet, 3, (V[]){v_y_2441, v_a2_2442, v_b_2443})));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam4, 1, 2, (V[]){v_m_2446, v_x_241});
  }
  case TAG_ERecord: {
    V v_m_2455 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_a_242));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam5, 1, 2, (V[]){v_m_2455, v_x_241});
  }
  case TAG_EProj: {
    V v_m_2466 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_a_242));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam6, 1, 2, (V[]){v_m_2466, v_x_241});
  }
  case TAG_ETag: {
    V v_m_2476 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_a_242));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam7, 1, 2, (V[]){v_m_2476, v_x_241});
  }
  case TAG_EMatch: {
    V v_s_2484 = heff_field(v_a_242, 0);
    V v_arms_2485 = heff_field(v_a_242, 1);
    V v_ru_24a_242_24EMatch = heff_take_reuse_n(v_a_242, 3ULL, 2);
    V v_t_2486 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str41), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_x_241), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str42))));
    V v_dest_2487 = heff_tag_n(TAG_Asg, 1, (V[]){v_t_2486});
    V v_m_2488 = (g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499(v_ce_240, v_dest_2487, heff_tag_at_n(v_ru_24a_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_2484, v_arms_2485})));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam8, 1, 2, (V[]){v_m_2488, v_x_241});
  }
  case TAG_EPrim: {
    V v_m_2497 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_a_242));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam9, 1, 2, (V[]){v_m_2497, v_x_241});
  }
  case TAG_EPrimCall: {
    V v_m_24107 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_a_242));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam10, 1, 2, (V[]){v_m_24107, v_x_241});
  }
  case TAG_ECall: {
    V v_m_24117 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_a_242));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam11, 1, 2, (V[]){v_m_24117, v_x_241});
  }
  case TAG_EInt: {
    V v_m_24126 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_a_242));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam12, 1, 2, (V[]){v_m_24126, v_x_241});
  }
  case TAG_EFloat: {
    V v_m_24135 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_a_242));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam13, 1, 2, (V[]){v_m_24135, v_x_241});
  }
  case TAG_EStr: {
    V v_m_24144 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_a_242));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam14, 1, 2, (V[]){v_m_24144, v_x_241});
  }
  case TAG_EFixed: {
    V v_m_24154 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_a_242));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam15, 1, 2, (V[]){v_m_24154, v_x_241});
  }
  case TAG_EFloat32: {
    V v_m_24163 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_a_242));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam16, 1, 2, (V[]){v_m_24163, v_x_241});
  }
  case TAG_EAbandon: {
    V v_m_24171 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_a_242));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam17, 1, 2, (V[]){v_m_24171, v_x_241});
  }
  case TAG_EFix: {
    V v_m_24181 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_a_242));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam18, 1, 2, (V[]){v_m_24181, v_x_241});
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_apply(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str0), (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str1))));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str2), heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str3), heff_strAppend(v_x_247, ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str4)))));
    V v_x_2411 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_s_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam1(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2415 = heff_tr(heff_apply(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str5), (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str6))));
    V v_t_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str7), heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str8), heff_strAppend(v_x_2416, ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str9)))));
    V v_x_2420 = heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2420, v_s_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam2(V self, V *args) {
  V v_s_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2425 = heff_tr(heff_apply(v_m_2423, 1, (V[]){v_s_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_s_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    V v_t_2428 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str10), (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str11))));
    V v_t_2429 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str12), heff_strAppend(v_t_2428, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str13), heff_strAppend(v_x_2426, ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str14)))));
    V v_x_2430 = heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2430, v_s_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam3(V self, V *args) {
  V v_s_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2435 = heff_tr(heff_apply(v_m_2433, 1, (V[]){v_s_2434}));
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_MkPair: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    V v_s_2437 = heff_field(v_x2_2435, 1);
    V v_ru_24x2_2435_24MkPair = heff_take_reuse_n(v_x2_2435, 3ULL, 2);
    V v_t_2438 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str15), (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str16))));
    V v_t_2439 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str17), heff_strAppend(v_t_2438, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str18), heff_strAppend(v_x_2436, ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str19)))));
    V v_x_2440 = heff_tag_at_n(v_ru_24x2_2435_24MkPair, TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2440, v_s_2437});
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam4(V self, V *args) {
  V v_s_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2448 = heff_tr(heff_apply(v_m_2446, 1, (V[]){v_s_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_s_2450 = heff_field(v_x2_2448, 1);
    V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
    V v_t_2451 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str22), (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str23))));
    V v_t_2452 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str24), heff_strAppend(v_t_2451, ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str25)));
    V v_x_2453 = heff_tag_at_n(v_ru_24x2_2448_24MkPair, TAG_Cons, 2, (V[]){v_t_2452, v_x_2449});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2453, v_s_2450});
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam5(V self, V *args) {
  V v_s_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2457 = heff_tr(heff_apply(v_m_2455, 1, (V[]){v_s_2456}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_s_2459 = heff_field(v_x2_2457, 1);
    V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
    V v_t_2460 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str26), (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str27))));
    V v_t_2461 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str28), heff_strAppend(v_t_2460, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str29), heff_strAppend(v_x_2458, ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str30)))));
    V v_x_2462 = heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2462, v_s_2459});
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam6(V self, V *args) {
  V v_s_2467 = args[0];
  V v_m_2466 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2468 = heff_tr(heff_apply(v_m_2466, 1, (V[]){v_s_2467}));
  switch (heff_tag_of(v_x2_2468)) {
  case TAG_MkPair: {
    V v_x_2469 = heff_field(v_x2_2468, 0);
    V v_s_2470 = heff_field(v_x2_2468, 1);
    V v_ru_24x2_2468_24MkPair = heff_take_reuse_n(v_x2_2468, 3ULL, 2);
    V v_t_2471 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str31), (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str32))));
    V v_t_2472 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str33), heff_strAppend(v_t_2471, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str34), heff_strAppend(v_x_2469, ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str35)))));
    V v_x_2473 = heff_tag_at_n(v_ru_24x2_2468_24MkPair, TAG_Cons, 2, (V[]){v_t_2472, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2473, v_s_2470});
  }
  default: return heff_nomatch(v_x2_2468);
  }
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam7(V self, V *args) {
  V v_s_2477 = args[0];
  V v_m_2476 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2478 = heff_tr(heff_apply(v_m_2476, 1, (V[]){v_s_2477}));
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_MkPair: {
    V v_x_2479 = heff_field(v_x2_2478, 0);
    V v_s_2480 = heff_field(v_x2_2478, 1);
    V v_ru_24x2_2478_24MkPair = heff_take_reuse_n(v_x2_2478, 3ULL, 2);
    V v_t_2481 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str36), (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str37))));
    V v_t_2482 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str38), heff_strAppend(v_t_2481, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str39), heff_strAppend(v_x_2479, ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str40)))));
    V v_x_2483 = heff_tag_at_n(v_ru_24x2_2478_24MkPair, TAG_Cons, 2, (V[]){v_t_2482, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2483, v_s_2480});
  }
  default: return heff_nomatch(v_x2_2478);
  }
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam8(V self, V *args) {
  V v_s_2489 = args[0];
  V v_m_2488 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2490 = heff_tr(heff_apply(v_m_2488, 1, (V[]){v_s_2489}));
  switch (heff_tag_of(v_x2_2490)) {
  case TAG_MkPair: {
    V v_x_2491 = heff_field(v_x2_2490, 0);
    V v_s_2492 = heff_field(v_x2_2490, 1);
    V v_ru_24x2_2490_24MkPair = heff_take_reuse_n(v_x2_2490, 3ULL, 2);
    V v_t_2493 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str43), (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str44))));
    V v_t_2494 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str45), heff_strAppend(v_t_2493, ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str46)));
    V v_x_2495 = heff_tag_at_n(v_ru_24x2_2490_24MkPair, TAG_Cons, 2, (V[]){v_t_2494, v_x_2491});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2495, v_s_2492});
  }
  default: return heff_nomatch(v_x2_2490);
  }
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam9(V self, V *args) {
  V v_s_2498 = args[0];
  V v_m_2497 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2499 = heff_tr(heff_apply(v_m_2497, 1, (V[]){v_s_2498}));
  switch (heff_tag_of(v_x2_2499)) {
  case TAG_MkPair: {
    V v_x_24100 = heff_field(v_x2_2499, 0);
    V v_s_24101 = heff_field(v_x2_2499, 1);
    V v_ru_24x2_2499_24MkPair = heff_take_reuse_n(v_x2_2499, 3ULL, 2);
    V v_t_24102 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str47), (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str48))));
    V v_t_24103 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str49), heff_strAppend(v_t_24102, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str50), heff_strAppend(v_x_24100, ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str51)))));
    V v_x_24104 = heff_tag_at_n(v_ru_24x2_2499_24MkPair, TAG_Cons, 2, (V[]){v_t_24103, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24104, v_s_24101});
  }
  default: return heff_nomatch(v_x2_2499);
  }
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam10(V self, V *args) {
  V v_s_24108 = args[0];
  V v_m_24107 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24109 = heff_tr(heff_apply(v_m_24107, 1, (V[]){v_s_24108}));
  switch (heff_tag_of(v_x2_24109)) {
  case TAG_MkPair: {
    V v_x_24110 = heff_field(v_x2_24109, 0);
    V v_s_24111 = heff_field(v_x2_24109, 1);
    V v_ru_24x2_24109_24MkPair = heff_take_reuse_n(v_x2_24109, 3ULL, 2);
    V v_t_24112 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str52), (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str53))));
    V v_t_24113 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str54), heff_strAppend(v_t_24112, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str55), heff_strAppend(v_x_24110, ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str56)))));
    V v_x_24114 = heff_tag_at_n(v_ru_24x2_24109_24MkPair, TAG_Cons, 2, (V[]){v_t_24113, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24114, v_s_24111});
  }
  default: return heff_nomatch(v_x2_24109);
  }
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam11(V self, V *args) {
  V v_s_24118 = args[0];
  V v_m_24117 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24119 = heff_tr(heff_apply(v_m_24117, 1, (V[]){v_s_24118}));
  switch (heff_tag_of(v_x2_24119)) {
  case TAG_MkPair: {
    V v_x_24120 = heff_field(v_x2_24119, 0);
    V v_s_24121 = heff_field(v_x2_24119, 1);
    V v_ru_24x2_24119_24MkPair = heff_take_reuse_n(v_x2_24119, 3ULL, 2);
    V v_t_24122 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str57), (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str58))));
    V v_t_24123 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str59), heff_strAppend(v_t_24122, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str60), heff_strAppend(v_x_24120, ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str61)))));
    V v_x_24124 = heff_tag_at_n(v_ru_24x2_24119_24MkPair, TAG_Cons, 2, (V[]){v_t_24123, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24124, v_s_24121});
  }
  default: return heff_nomatch(v_x2_24119);
  }
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam12(V self, V *args) {
  V v_s_24127 = args[0];
  V v_m_24126 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24128 = heff_tr(heff_apply(v_m_24126, 1, (V[]){v_s_24127}));
  switch (heff_tag_of(v_x2_24128)) {
  case TAG_MkPair: {
    V v_x_24129 = heff_field(v_x2_24128, 0);
    V v_s_24130 = heff_field(v_x2_24128, 1);
    V v_ru_24x2_24128_24MkPair = heff_take_reuse_n(v_x2_24128, 3ULL, 2);
    V v_t_24131 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str62), (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str63))));
    V v_t_24132 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str64), heff_strAppend(v_t_24131, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str65), heff_strAppend(v_x_24129, ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str66)))));
    V v_x_24133 = heff_tag_at_n(v_ru_24x2_24128_24MkPair, TAG_Cons, 2, (V[]){v_t_24132, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24133, v_s_24130});
  }
  default: return heff_nomatch(v_x2_24128);
  }
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam13(V self, V *args) {
  V v_s_24136 = args[0];
  V v_m_24135 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24137 = heff_tr(heff_apply(v_m_24135, 1, (V[]){v_s_24136}));
  switch (heff_tag_of(v_x2_24137)) {
  case TAG_MkPair: {
    V v_x_24138 = heff_field(v_x2_24137, 0);
    V v_s_24139 = heff_field(v_x2_24137, 1);
    V v_ru_24x2_24137_24MkPair = heff_take_reuse_n(v_x2_24137, 3ULL, 2);
    V v_t_24140 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str67), (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str68))));
    V v_t_24141 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str69), heff_strAppend(v_t_24140, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str70), heff_strAppend(v_x_24138, ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str71)))));
    V v_x_24142 = heff_tag_at_n(v_ru_24x2_24137_24MkPair, TAG_Cons, 2, (V[]){v_t_24141, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24142, v_s_24139});
  }
  default: return heff_nomatch(v_x2_24137);
  }
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam14(V self, V *args) {
  V v_s_24145 = args[0];
  V v_m_24144 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24146 = heff_tr(heff_apply(v_m_24144, 1, (V[]){v_s_24145}));
  switch (heff_tag_of(v_x2_24146)) {
  case TAG_MkPair: {
    V v_x_24147 = heff_field(v_x2_24146, 0);
    V v_s_24148 = heff_field(v_x2_24146, 1);
    V v_ru_24x2_24146_24MkPair = heff_take_reuse_n(v_x2_24146, 3ULL, 2);
    V v_t_24149 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str72), (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str73))));
    V v_t_24150 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str74), heff_strAppend(v_t_24149, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str75), heff_strAppend(v_x_24147, ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str76)))));
    V v_x_24151 = heff_tag_at_n(v_ru_24x2_24146_24MkPair, TAG_Cons, 2, (V[]){v_t_24150, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24151, v_s_24148});
  }
  default: return heff_nomatch(v_x2_24146);
  }
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam15(V self, V *args) {
  V v_s_24155 = args[0];
  V v_m_24154 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24156 = heff_tr(heff_apply(v_m_24154, 1, (V[]){v_s_24155}));
  switch (heff_tag_of(v_x2_24156)) {
  case TAG_MkPair: {
    V v_x_24157 = heff_field(v_x2_24156, 0);
    V v_s_24158 = heff_field(v_x2_24156, 1);
    V v_ru_24x2_24156_24MkPair = heff_take_reuse_n(v_x2_24156, 3ULL, 2);
    V v_t_24159 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str77), (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str78))));
    V v_t_24160 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str79), heff_strAppend(v_t_24159, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str80), heff_strAppend(v_x_24157, ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str81)))));
    V v_x_24161 = heff_tag_at_n(v_ru_24x2_24156_24MkPair, TAG_Cons, 2, (V[]){v_t_24160, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24161, v_s_24158});
  }
  default: return heff_nomatch(v_x2_24156);
  }
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam16(V self, V *args) {
  V v_s_24164 = args[0];
  V v_m_24163 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24165 = heff_tr(heff_apply(v_m_24163, 1, (V[]){v_s_24164}));
  switch (heff_tag_of(v_x2_24165)) {
  case TAG_MkPair: {
    V v_x_24166 = heff_field(v_x2_24165, 0);
    V v_s_24167 = heff_field(v_x2_24165, 1);
    V v_ru_24x2_24165_24MkPair = heff_take_reuse_n(v_x2_24165, 3ULL, 2);
    V v_t_24168 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str82), (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str83))));
    V v_t_24169 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str84), heff_strAppend(v_t_24168, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str85), heff_strAppend(v_x_24166, ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str86)))));
    V v_x_24170 = heff_tag_at_n(v_ru_24x2_24165_24MkPair, TAG_Cons, 2, (V[]){v_t_24169, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24170, v_s_24167});
  }
  default: return heff_nomatch(v_x2_24165);
  }
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam17(V self, V *args) {
  V v_s_24172 = args[0];
  V v_m_24171 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24173 = heff_tr(heff_apply(v_m_24171, 1, (V[]){v_s_24172}));
  switch (heff_tag_of(v_x2_24173)) {
  case TAG_MkPair: {
    V v_x_24174 = heff_field(v_x2_24173, 0);
    V v_s_24175 = heff_field(v_x2_24173, 1);
    V v_ru_24x2_24173_24MkPair = heff_take_reuse_n(v_x2_24173, 3ULL, 2);
    V v_t_24176 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str87), (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str88))));
    V v_t_24177 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str89), heff_strAppend(v_t_24176, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str90), heff_strAppend(v_x_24174, ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str91)))));
    V v_x_24178 = heff_tag_at_n(v_ru_24x2_24173_24MkPair, TAG_Cons, 2, (V[]){v_t_24177, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24178, v_s_24175});
  }
  default: return heff_nomatch(v_x2_24173);
  }
}
V g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_lam18(V self, V *args) {
  V v_s_24182 = args[0];
  V v_m_24181 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24183 = heff_tr(heff_apply(v_m_24181, 1, (V[]){v_s_24182}));
  switch (heff_tag_of(v_x2_24183)) {
  case TAG_MkPair: {
    V v_x_24184 = heff_field(v_x2_24183, 0);
    V v_s_24185 = heff_field(v_x2_24183, 1);
    V v_ru_24x2_24183_24MkPair = heff_take_reuse_n(v_x2_24183, 3ULL, 2);
    V v_t_24186 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str92), (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str93))));
    V v_t_24187 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str94), heff_strAppend(v_t_24186, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str95), heff_strAppend(v_x_24184, ((V)&g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862_str96)))));
    V v_x_24188 = heff_tag_at_n(v_ru_24x2_24183_24MkPair, TAG_Cons, 2, (V[]){v_t_24187, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24188, v_s_24185});
  }
  default: return heff_nomatch(v_x2_24183);
  }
}
V g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305_entry, 7, 0};

V g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305(V v_ce_240, V v_dest_241, V v_x_242, V v_a_243, V v_b_244, V v_fa_245, V v_wb_246) {
top: ;
  V v_t_247 = (g_heff_2ecompile_2eemitc_2eoperandsOf(heff_dup(v_a_243)));
  V v_ts_248 = (g_heff_2ecompile_2eemitc_2etakesAt(heff_dup(v_ce_240), NTAG(TAG_Nil), heff_dup(v_b_244), v_t_247));
  V v_wanted_249 = (g_prelude_2e_2b_2b(heff_dup(v_fa_245), heff_dup(v_wb_246)));
  V v_owned_2411 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305_lam0, 1, 1, (V[]){v_wanted_249}), heff_dup(heff_rfield(v_ce_240, 6))));
  V v_ce_2412 = heff_rec_n(12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes, (V[]){heff_dup(heff_rfield(v_ce_240, 0)), heff_dup(heff_rfield(v_ce_240, 1)), heff_dup(heff_rfield(v_ce_240, 2)), heff_dup(heff_rfield(v_ce_240, 3)), heff_dup(heff_rfield(v_ce_240, 4)), heff_dup(heff_rfield(v_ce_240, 5)), v_owned_2411, heff_dup(v_wb_246), heff_dup(heff_rfield(v_ce_240, 8)), heff_dup(heff_rfield(v_ce_240, 9)), heff_dup(heff_rfield(v_ce_240, 10)), heff_dup(heff_rfield(v_ce_240, 11))});
  V v_t_2413 = ({ V rv_11 = v_ts_248; V rr_ = heff_rec_reuse_n(v_ce_2412, 2047ULL, 12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes); heff_rfield(rr_, 11) = rv_11; rr_; });
  V v_m_2414 = (g_heff_2ecompile_2eemitc_2ebindTo_24s661860354x1997306862(v_t_2413, heff_dup(v_x_242), heff_dup(v_a_243)));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305_lam1, 1, 8, (V[]){v_m_2414, v_wb_246, v_ce_240, v_x_242, v_a_243, v_dest_241, v_b_244, v_fa_245});
}
V g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305_lam0(V self, V *args) {
  V v_v_2410 = args[0];
  V v_wanted_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2410; V a_1 = v_wanted_249; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_249); r_; });
}
V g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305_lam2(V self, V *args) {
  V v_v_2419 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2419; V a_1 = v_wb_246; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wb_246); r_; });
}
V g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305_lam3(V self, V *args) {
  V v_v_2433 = args[0];
  V v_wanted_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2434 = ({ V a_0 = v_v_2433; V a_1 = v_wanted_2432; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2432); r_; });
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2434);
  }
}
V g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305_lam1(V self, V *args) {
  V v_s_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_wb_246 = heff_env(self)[1];
  V v_ce_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_a_243 = heff_env(self)[4];
  V v_dest_241 = heff_env(self)[5];
  V v_b_244 = heff_env(self)[6];
  V v_fa_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x2_2416 = heff_tr(heff_apply(v_m_2414, 1, (V[]){v_s_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_s_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    V v_t_2420 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305_lam2, 1, 1, (V[]){heff_dup(v_wb_246)}), heff_dup(heff_rfield(v_ce_240, 6))));
    V v_t_2421 = (g_heff_2ecompile_2eemitc_2eelemS(heff_dup(v_x_242), v_wb_246));
    V v_t_2422;
    switch (heff_tag_of(v_t_2421)) {
    case TAG_True: {
      v_t_2422 = heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_x_242), NTAG(TAG_Nil)});
      break;
    }
    case TAG_False: {
      heff_drop_cell(v_ru_24x2_2416_24MkPair, 2);
      v_t_2422 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_2421);
    }
    V v_owned_2423 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2422));
    V v_t_2424 = (g_heff_2ecompile_2eemitc_2ebuiltOf(heff_dup(v_a_243)));
    V v_ce_2425 = ({ V a_0 = heff_dup(v_x_242); V a_1 = v_t_2424; V a_2 = heff_dup(v_ce_240); V r_ = (g_heff_2ecompile_2eemitc_2eknownLet(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
    V v_ce_2426 = ({ V rv_11 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_n(v_ce_2425, 2047ULL, 12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes); heff_rfield(rr_, 11) = rv_11; rr_; });
    V v_ce_2427 = ({ V rv_6 = v_owned_2423; V rv_7 = heff_dup(heff_rfield(v_ce_240, 7)); V rr_ = heff_rec_reuse_n(v_ce_2426, 3903ULL, 12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes); heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
    V v_m_2428 = (g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499(v_ce_2427, v_dest_241, v_b_244));
    V v_x2_2429 = heff_tr(heff_apply(v_m_2428, 1, (V[]){v_s_2418}));
    switch (heff_tag_of(v_x2_2429)) {
    case TAG_MkPair: {
      V v_x_2430 = heff_field(v_x2_2429, 0);
      V v_s_2431 = heff_field(v_x2_2429, 1);
      V v_ru_24x2_2429_24MkPair = heff_take_reuse_n(v_x2_2429, 3ULL, 2);
      V v_wanted_2432 = (g_prelude_2e_2b_2b(v_fa_245, heff_dup(v_wb_246)));
      V v_t_2435 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305_lam3, 1, 1, (V[]){v_wanted_2432}), heff_dup(heff_rfield(v_ce_240, 6))));
      V v_t_2436 = (g_heff_2ecompile_2eemitc_2edropsIn(heff_dup(v_ce_240), v_t_2435));
      V v_t_2437 = ({ V a_0 = heff_dup(v_x_242); V a_1 = v_wb_246; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wb_246); r_; });
      V v_t_2441;
      switch (heff_tag_of(v_t_2437)) {
      case TAG_True: {
        heff_drop_rec(v_ce_240, 12);
        heff_drop(v_x_242);
        heff_drop(v_a_243);
        heff_drop_cell(v_ru_24x2_2429_24MkPair, 2);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_False: {
        V v_t_2438 = (g_heff_2ecompile_2eemitc_2ebuiltOf(v_a_243));
        V v_t_2439 = ({ V a_0 = heff_dup(v_x_242); V a_1 = v_t_2438; V a_2 = v_ce_240; V r_ = (g_heff_2ecompile_2eemitc_2eknownLet(a_0, a_1, a_2)); heff_drop(v_t_2438); r_; });
        V v_t_2440 = heff_tag_at_n(v_ru_24x2_2429_24MkPair, TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
        v_t_2441 = (g_heff_2ecompile_2eemitc_2edropsIn(v_t_2439, v_t_2440));
        break;
      }
      default: heff_nomatch(v_t_2437);
      }
      V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2441, v_x_2430));
      V v_t_2443 = (g_prelude_2e_2b_2b(v_x_2417, v_t_2442));
      V v_x_2444 = (g_prelude_2e_2b_2b(v_t_2436, v_t_2443));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2444, v_s_2431});
    }
    default: return heff_nomatch(v_x2_2429);
    }
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_str0, 4, (84, 65, 71, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_str2, 5, (78, 84, 65, 71, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_str3, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_str4, 20, (114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 110, 111, 109, 97, 116, 99, 104, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_str5, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_str6, 13, (104, 101, 102, 102, 95, 110, 111, 109, 97, 116, 99, 104, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_str7, 2, (41, 59));
V g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_lam2(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281(V v_ce_240, V v_dest_241, V v_t_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ce_240, 12);
    V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_str0), (g_heff_2ecompile_2eemitc_2emangleW(v_t_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_str1))));
    V v_sv_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_str2), heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_str3)));
    V v_t_247;
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_str4), heff_strAppend(v_sv_245, ((V)&g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_str5)));
      break;
    }
    case TAG_Asg: {
      heff_take_n(v_dest_241, 0ULL, 1);
      v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_str6), heff_strAppend(v_sv_245, ((V)&g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_str7)));
      break;
    }
    default: heff_nomatch(v_dest_241);
    }
    V v_x_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    return heff_clo_n(g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_lam0, 1, 1, (V[]){v_x_248});
  }
  case TAG_Just: {
    V v_b_2410 = heff_field(v_x5_243, 0);
    heff_drop(v_t_242);
    V v_t_2411 = (g_heff_2ecompile_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_b_2410)));
    V v_wanted_2412 = (g_prelude_2e_2b_2b(v_t_2411, heff_dup(heff_rfield(v_ce_240, 7))));
    V v_owned_2414 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_lam1, 1, 1, (V[]){v_wanted_2412}), heff_dup(heff_rfield(v_ce_240, 6))));
    V v_ce_2415 = heff_rec_n(12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes, (V[]){heff_dup(heff_rfield(v_ce_240, 0)), heff_dup(heff_rfield(v_ce_240, 1)), heff_dup(heff_rfield(v_ce_240, 2)), heff_dup(heff_rfield(v_ce_240, 3)), heff_dup(heff_rfield(v_ce_240, 4)), heff_dup(heff_rfield(v_ce_240, 5)), v_owned_2414, heff_dup(heff_rfield(v_ce_240, 7)), heff_dup(heff_rfield(v_ce_240, 8)), heff_dup(heff_rfield(v_ce_240, 9)), heff_dup(heff_rfield(v_ce_240, 10)), heff_dup(heff_rfield(v_ce_240, 11))});
    V v_m_2416 = (g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499(v_ce_2415, v_dest_241, heff_dup(v_b_2410)));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_lam2, 1, 3, (V[]){v_m_2416, heff_dup(v_b_2410), v_ce_240});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
V g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_lam0(V self, V *args) {
  V v_s_249 = args[0];
  V v_x_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_248, v_s_249});
}
V g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_lam1(V self, V *args) {
  V v_v_2413 = args[0];
  V v_wanted_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2413; V a_1 = v_wanted_2412; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2412); r_; });
}
V g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_lam3(V self, V *args) {
  V v_v_2423 = args[0];
  V v_wanted_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2424 = ({ V a_0 = v_v_2423; V a_1 = v_wanted_2422; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2422); r_; });
  switch (heff_tag_of(v_x1_2424)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2424);
  }
}
V g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_lam2(V self, V *args) {
  V v_s_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  V v_b_2410 = heff_env(self)[1];
  V v_ce_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2418 = heff_tr(heff_apply(v_m_2416, 1, (V[]){v_s_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_t_2421 = (g_heff_2ecompile_2eemitc_2efreeOf(NTAG(TAG_Nil), v_b_2410));
    V v_wanted_2422 = (g_prelude_2e_2b_2b(v_t_2421, heff_dup(heff_rfield(v_ce_240, 7))));
    V v_t_2425 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281_lam3, 1, 1, (V[]){v_wanted_2422}), heff_dup(heff_rfield(v_ce_240, 6))));
    V v_t_2426 = (g_heff_2ecompile_2eemitc_2edropsIn(v_ce_240, v_t_2425));
    V v_x_2427 = (g_prelude_2e_2b_2b(v_t_2426, v_x_2419));
    return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_x_2427, v_s_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str0, 4, (84, 114, 117, 101));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str1, 4, (84, 114, 117, 101));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str2, 5, (70, 97, 108, 115, 101));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str3, 5, (70, 97, 108, 115, 101));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str4, 5, (104, 101, 102, 102, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str5, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str6, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str7, 4, (105, 102, 32, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str8, 3, (95, 99, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str9, 4, (41, 41, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str10, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str11, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str12, 1, (125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str13, 8, (125, 32, 101, 108, 115, 101, 32, 123));
V g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033(V v_ce_240, V v_dest_241, V v_c_242, V v_fa_243, V v_wb_244) {
top: ;
  V v_wanted_245 = (g_prelude_2e_2b_2b(heff_dup(v_fa_243), heff_dup(v_wb_244)));
  V v_owned_247 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_lam0, 1, 1, (V[]){v_wanted_245}), heff_dup(heff_rfield(v_ce_240, 6))));
  V v_t_248 = heff_rec_n(12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes, (V[]){heff_dup(heff_rfield(v_ce_240, 0)), heff_dup(heff_rfield(v_ce_240, 1)), heff_dup(heff_rfield(v_ce_240, 2)), heff_dup(heff_rfield(v_ce_240, 3)), heff_dup(heff_rfield(v_ce_240, 4)), heff_dup(heff_rfield(v_ce_240, 5)), v_owned_247, heff_dup(v_wb_244), heff_dup(heff_rfield(v_ce_240, 8)), heff_dup(heff_rfield(v_ce_240, 9)), heff_dup(heff_rfield(v_ce_240, 10)), heff_dup(heff_rfield(v_ce_240, 11))});
  V v_m_249 = (g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634(v_t_248, heff_dup(v_wb_244), heff_dup(heff_rfield(v_c_242, 1))));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_lam1, 1, 6, (V[]){v_m_249, v_wb_244, v_ce_240, v_c_242, v_dest_241, v_fa_243});
}
V g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_lam0(V self, V *args) {
  V v_v_246 = args[0];
  V v_wanted_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_246; V a_1 = v_wanted_245; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_245); r_; });
}
V g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_lam2(V self, V *args) {
  V v_v_2414 = args[0];
  V v_wb_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2414; V a_1 = v_wb_244; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wb_244); r_; });
}
V g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_lam3(V self, V *args) {
  V v_v_2422 = args[0];
  V v_wb_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2422; V a_1 = v_wb_244; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wb_244); r_; });
}
V g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_lam4(V self, V *args) {
  V v_v_2431 = args[0];
  V v_wanted_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2432 = ({ V a_0 = v_v_2431; V a_1 = v_wanted_2430; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2430); r_; });
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2432);
  }
}
V g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_wb_244 = heff_env(self)[1];
  V v_ce_240 = heff_env(self)[2];
  V v_c_242 = heff_env(self)[3];
  V v_dest_241 = heff_env(self)[4];
  V v_fa_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2411 = heff_tr(heff_apply(v_m_249, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_owned_2415 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_lam2, 1, 1, (V[]){heff_dup(v_wb_244)}), heff_dup(heff_rfield(v_ce_240, 6))));
    V v_t_2416 = heff_rec_n(12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes, (V[]){heff_dup(heff_rfield(v_ce_240, 0)), heff_dup(heff_rfield(v_ce_240, 1)), heff_dup(heff_rfield(v_ce_240, 2)), heff_dup(heff_rfield(v_ce_240, 3)), heff_dup(heff_rfield(v_ce_240, 4)), heff_dup(heff_rfield(v_ce_240, 5)), v_owned_2415, heff_dup(heff_rfield(v_ce_240, 7)), heff_dup(heff_rfield(v_ce_240, 8)), heff_dup(heff_rfield(v_ce_240, 9)), heff_dup(heff_rfield(v_ce_240, 10)), heff_dup(heff_rfield(v_ce_240, 11))});
    V v_t_2417 = (g_heff_2ecompile_2eemitc_2earmFor(((V)&g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str0), heff_rfield(v_c_242, 2)));
    V v_m_2418 = ({ V a_0 = v_t_2416; V a_1 = heff_dup(v_dest_241); V a_2 = ((V)&g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str1); V a_3 = v_t_2417; V r_ = (g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281(a_0, a_1, a_2, a_3)); heff_drop(v_t_2417); r_; });
    V v_x2_2419 = heff_tr(heff_apply(v_m_2418, 1, (V[]){v_s_2413}));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_s_2421 = heff_field(v_x2_2419, 1);
      V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
      V v_owned_2423 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_lam3, 1, 1, (V[]){heff_dup(v_wb_244)}), heff_dup(heff_rfield(v_ce_240, 6))));
      V v_t_2424 = heff_rec_n(12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes, (V[]){heff_dup(heff_rfield(v_ce_240, 0)), heff_dup(heff_rfield(v_ce_240, 1)), heff_dup(heff_rfield(v_ce_240, 2)), heff_dup(heff_rfield(v_ce_240, 3)), heff_dup(heff_rfield(v_ce_240, 4)), heff_dup(heff_rfield(v_ce_240, 5)), v_owned_2423, heff_dup(heff_rfield(v_ce_240, 7)), heff_dup(heff_rfield(v_ce_240, 8)), heff_dup(heff_rfield(v_ce_240, 9)), heff_dup(heff_rfield(v_ce_240, 10)), heff_dup(heff_rfield(v_ce_240, 11))});
      V v_t_2425 = (g_heff_2ecompile_2eemitc_2earmFor(((V)&g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str2), heff_rfield(v_c_242, 2)));
      V v_m_2426 = ({ V a_0 = v_t_2424; V a_1 = v_dest_241; V a_2 = ((V)&g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str3); V a_3 = v_t_2425; V r_ = (g_heff_2ecompile_2eemitc_2econdArm_24s273666443x1625659281(a_0, a_1, a_2, a_3)); heff_drop(v_t_2425); r_; });
      V v_x2_2427 = heff_tr(heff_apply(v_m_2426, 1, (V[]){v_s_2421}));
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_MkPair: {
        V v_x_2428 = heff_field(v_x2_2427, 0);
        V v_s_2429 = heff_field(v_x2_2427, 1);
        V v_ru_24x2_2427_24MkPair = heff_take_reuse_n(v_x2_2427, 3ULL, 2);
        V v_wanted_2430 = (g_prelude_2e_2b_2b(v_fa_243, v_wb_244));
        V v_t_2433 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_lam4, 1, 1, (V[]){v_wanted_2430}), heff_dup(heff_rfield(v_ce_240, 6))));
        V v_t_2434 = (g_heff_2ecompile_2eemitc_2edropsIn(v_ce_240, v_t_2433));
        V v_t_2435 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str4), heff_get_n(v_c_242, 0, 3));
        V v_t_2438;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_Nil: {
          v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2436 = heff_field(v_x_2412, 0);
          V v_xs_2437 = heff_field(v_x_2412, 1);
          heff_take_n(v_x_2412, 3ULL, 2);
          v_t_2438 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str6); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        V v_t_2439 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str7), heff_strAppend(v_t_2435, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str8), heff_strAppend(v_t_2438, ((V)&g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str9)))));
        V v_t_2440 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str10), v_x_2420));
        V v_t_2441 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str11), v_x_2428));
        V v_t_2442 = heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str12), NTAG(TAG_Nil)});
        V v_t_2443 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033_str13), (g_prelude_2e_2b_2b(v_t_2441, v_t_2442))});
        V v_t_2444 = heff_tag_at_n(v_ru_24x2_2427_24MkPair, TAG_Cons, 2, (V[]){v_t_2439, (g_prelude_2e_2b_2b(v_t_2440, v_t_2443))});
        V v_x_2445 = (g_prelude_2e_2b_2b(v_t_2434, v_t_2444));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2445, v_s_2429});
      }
      default: return heff_nomatch(v_x2_2427);
      }
    }
    default: return heff_nomatch(v_x2_2419);
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
Clo g_heff_2ecompile_2eemitc_2eletOrCond_24s386767440x905233418_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eletOrCond_24s386767440x905233418_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2eletOrCond_24s386767440x905233418(V v_ce_240, V v_dest_241, V v_x_242, V v_a_243, V v_b_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nothing: {
    V v_t_246 = (g_heff_2ecompile_2eemitc_2eisCondCall(v_a_243));
    V v_x7_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      v_x7_247 = (g_heff_2ecompile_2eemitc_2esunkGo(heff_dup(v_x_242), heff_dup(v_a_243), heff_dup(v_b_244)));
      break;
    }
    case TAG_False: {
      v_x7_247 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    switch (heff_tag_of(v_x7_247)) {
    case TAG_Nothing: {
      V v_t_248 = (g_heff_2ecompile_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_a_243)));
      V v_t_249 = (g_heff_2ecompile_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_b_244)));
      V v_t_2410 = (g_prelude_2e_2b_2b(v_t_249, heff_dup(heff_rfield(v_ce_240, 7))));
      return (g_heff_2ecompile_2eemitc_2eletWith_24s1243526743x457380305(v_ce_240, v_dest_241, v_x_242, v_a_243, v_b_244, v_t_248, v_t_2410));
    }
    case TAG_Just: {
      V v_e_2411 = heff_field(v_x7_247, 0);
      heff_take_n(v_x7_247, 1ULL, 1);
      heff_drop(v_x_242);
      heff_drop(v_a_243);
      heff_drop(v_b_244);
      return (g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499(v_ce_240, v_dest_241, v_e_2411));
    }
    default: return heff_nomatch(v_x7_247);
    }
  }
  case TAG_Just: {
    V v_c_2412 = heff_field(v_x7_245, 0);
    heff_drop(v_x_242);
    heff_drop(v_a_243);
    heff_drop(v_b_244);
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_2412, 1))));
    V v_t_2414 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2413; V r_ = (g_list_2efoldl_24s873517001x1016672031(a_0, a_1)); heff_drop(v_t_2413); r_; });
    V v_es_2415 = (g_list_2emap_24s60612435x257154841(heff_dup(heff_rfield(v_c_2412, 2))));
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2415));
    V v_t_2417 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s873517001x1016672031(a_0, a_1)); heff_drop(v_t_2416); r_; });
    V v_t_2418 = (g_prelude_2e_2b_2b(v_t_2417, heff_dup(heff_rfield(v_ce_240, 7))));
    return (g_heff_2ecompile_2eemitc_2econdWith_24s1964927732x477092033(v_ce_240, v_dest_241, heff_dup(v_c_2412), v_t_2414, v_t_2418));
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2eemitc_2eletOrCond_24s386767440x905233418_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2eletOrCond_24s386767440x905233418(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[5]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_str0, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_str2, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_str3, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_str4, 6, (95, 103, 101, 116, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_str5, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_str6, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_str7, 5, (40, 40, 86, 41, 38));
HEFF_STRA(g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_str8, 5, (95, 99, 108, 111, 41));
V g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452(V v_ce_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_ce_240, 12);
    V v_x_243 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_str0), (g_heff_2ecompile_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_str1))));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_lam0, 1, 1, (V[]){v_x_243});
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_x3_246 = ({ V a_0 = heff_dup(v_g_245); V b_1 = heff_get_n(v_ce_240, 2, 12); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
    V v_x_2410;
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_str2), (g_heff_2ecompile_2eemitc_2emangleW(v_g_245, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_str3))));
      v_x_2410 = heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_str4));
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_246, 0ULL, 1);
      V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_str5), (g_heff_2ecompile_2eemitc_2emangleW(v_g_245, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_str6))));
      v_x_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_str7), heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_str8)));
      break;
    }
    default: heff_nomatch(v_x3_246);
    }
    return heff_clo_n(g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_lam1, 1, 1, (V[]){v_x_2410});
  }
  case TAG_ELam: {
    return (g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EApp: {
    return (g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_ELet: {
    return (g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_ERecord: {
    return (g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EProj: {
    return (g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_ETag: {
    return (g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EMatch: {
    return (g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EPrim: {
    return (g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EPrimCall: {
    return (g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_ECall: {
    return (g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EInt: {
    return (g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EFloat: {
    return (g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EStr: {
    return (g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EFixed: {
    return (g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EFloat32: {
    return (g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EAbandon: {
    return (g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EFix: {
    return (g_heff_2ecompile_2eemitc_2evalF_24s1898900168x589890982(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_s_244});
}
V g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2410, v_s_2411});
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str0, 4, (84, 65, 71, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str2, 5, (99, 97, 115, 101, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str3, 3, (58, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str4, 12, (104, 101, 102, 102, 95, 116, 97, 107, 101, 95, 110, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str5, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str6, 5, (85, 76, 76, 44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str7, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str8, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str9, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str10, 8, (32, 32, 98, 114, 101, 97, 107, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str11, 1, (125));
V g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam2(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_entry, 10, 0};

V g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939(V v_ce_240, V v_dest_241, V v_sv_242, V v_taken_243, V v_lent_244, V v_t_245, V v_vs_246, V v_b_247, V v_fb_248, V v_x11_249) {
top: ;
  switch (heff_tag_of(v_x11_249)) {
  case TAG_MkPair: {
    V v_ru_2410 = heff_field(v_x11_249, 0);
    V v_b2_2411 = heff_field(v_x11_249, 1);
    V v_ru_24x11_249_24MkPair = heff_take_reuse_n(v_x11_249, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_lent_244)) {
    case TAG_True: {
      v_t_2413 = NTAG(TAG_Nil);
      break;
    }
    case TAG_False: {
      v_t_2413 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam0, 1, 1, (V[]){heff_dup(v_fb_248)}), heff_dup(v_vs_246)));
      break;
    }
    default: heff_nomatch(v_lent_244);
    }
    V v_t_2415;
    switch (heff_tag_of(v_ru_2410)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x11_249_24MkPair, 2);
      v_t_2415 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2414 = heff_dup(heff_field(v_ru_2410, 0));
      v_t_2415 = heff_tag_at_n(v_ru_24x11_249_24MkPair, TAG_Cons, 2, (V[]){v_x_2414, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_ru_2410);
    }
    V v_t_2416 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2415));
    V v_owned_2417 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_240, 6)), v_t_2416));
    V v_t_2419;
    switch (heff_tag_of(v_ru_2410)) {
    case TAG_Nothing: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2418 = heff_dup(heff_field(v_ru_2410, 0));
      v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2418, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_ru_2410);
    }
    V v_t_2420 = (g_prelude_2e_2b_2b(heff_dup(v_fb_248), v_t_2419));
    V v_wanted_2421 = (g_prelude_2e_2b_2b(v_t_2420, heff_dup(heff_rfield(v_ce_240, 7))));
    V v_owned_2423 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam1, 1, 1, (V[]){v_wanted_2421}), v_owned_2417));
    V v_bs_2424;
    switch (heff_tag_of(v_lent_244)) {
    case TAG_True: {
      v_bs_2424 = (g_prelude_2e_2b_2b(heff_dup(v_vs_246), heff_dup(heff_rfield(v_ce_240, 8))));
      break;
    }
    case TAG_False: {
      v_bs_2424 = heff_dup(heff_rfield(v_ce_240, 8));
      break;
    }
    default: heff_nomatch(v_lent_244);
    }
    V v_t_2425 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_246));
    V v_ce_2426 = (g_heff_2ecompile_2eemitc_2eknowCell(heff_dup(v_ru_2410), v_t_2425, heff_dup(v_ce_240)));
    V v_ce_2427 = ({ V rv_8 = v_bs_2424; V rr_ = heff_rec_reuse_n(v_ce_2426, 3839ULL, 12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes); heff_rfield(rr_, 8) = rv_8; rr_; });
    V v_ce_2428 = ({ V rv_6 = v_owned_2423; V rv_7 = heff_dup(heff_rfield(v_ce_240, 7)); V rr_ = heff_rec_reuse_n(v_ce_2427, 3903ULL, 12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes); heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
    V v_m_2429 = (g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499(v_ce_2428, heff_dup(v_dest_241), v_b2_2411));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam2, 1, 10, (V[]){v_m_2429, v_t_245, heff_dup(v_lent_244), heff_dup(v_taken_243), v_sv_242, v_fb_248, v_vs_246, v_ru_2410, v_ce_240, v_dest_241});
  }
  default: return heff_nomatch(v_x11_249);
  }
}
V g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]); heff_drop(a[3]); heff_drop(a[4]); heff_drop(a[7]); return r;
}
V g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam0(V self, V *args) {
  V v_v_2412 = args[0];
  V v_fb_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2412; V a_1 = v_fb_248; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_fb_248); r_; });
}
V g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam1(V self, V *args) {
  V v_v_2422 = args[0];
  V v_wanted_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2422; V a_1 = v_wanted_2421; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2421); r_; });
}
V g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam3(V self, V *args) {
  V v_acc_2444 = args[0];
  V v_x_2445 = args[1];
  V v_f_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446 = heff_tr(heff_apply(v_f_2439, 1, (V[]){v_x_2445}));
  return (g_prelude_2e_2b_2b(v_t_2446, v_acc_2444));
}
V g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam4(V self, V *args) {
  V v_v_2454 = args[0];
  V v_fb_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2454; V a_1 = v_fb_248; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_fb_248); r_; });
}
V g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam5(V self, V *args) {
  V v_v_2458 = args[0];
  V v_wanted_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2459 = ({ V a_0 = v_v_2458; V a_1 = v_wanted_2457; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2457); r_; });
  switch (heff_tag_of(v_x1_2459)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2459);
  }
}
V g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam6(V self, V *args) {
  V v_v_2461 = args[0];
  V v_taken_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2463;
  switch (heff_tag_of(v_taken_243)) {
  case TAG_Nothing: {
    v_t_2463 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2462 = heff_field(v_taken_243, 0);
    heff_take_n(v_taken_243, 1ULL, 1);
    v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2462, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_taken_243);
  }
  V v_x1_2464 = ({ V a_0 = v_v_2461; V a_1 = v_t_2463; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_t_2463); r_; });
  switch (heff_tag_of(v_x1_2464)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2464);
  }
}
V g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam2(V self, V *args) {
  V v_s_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_lent_244 = heff_env(self)[2];
  V v_taken_243 = heff_env(self)[3];
  V v_sv_242 = heff_env(self)[4];
  V v_fb_248 = heff_env(self)[5];
  V v_vs_246 = heff_env(self)[6];
  V v_ru_2410 = heff_env(self)[7];
  V v_ce_240 = heff_env(self)[8];
  V v_dest_241 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_x2_2431 = heff_tr(heff_apply(v_m_2429, 1, (V[]){v_s_2430}));
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_s_2433 = heff_field(v_x2_2431, 1);
    V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
    V v_t_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str0), (g_heff_2ecompile_2eemitc_2emangleW(v_t_245, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str1))));
    V v_t_2435 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str2), heff_strAppend(v_t_2434, ((V)&g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str3)));
    V v_t_2436 = heff_tag_at_n(v_ru_24x2_2431_24MkPair, TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
    V v_t_2438;
    switch (heff_tag_of(v_lent_244)) {
    case TAG_True: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      switch (heff_tag_of(v_taken_243)) {
      case TAG_Nothing: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        v_t_2438 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_taken_243);
      }
      break;
    }
    default: heff_nomatch(v_lent_244);
    }
    V v_f_2439 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2efieldLine_clo), 3, (V[]){heff_dup(v_sv_242), v_t_2438, heff_dup(v_fb_248)}));
    V v_t_2440 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_246));
    V v_t_2441 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2440, MK_INT(1LL))));
    V v_xs_2442 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_vs_246), v_t_2441));
    V v_t_2443 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2442));
    V v_t_2447 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam3, 2, 1, (V[]){v_f_2439}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2443; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2443); r_; });
    V v_t_2453;
    switch (heff_tag_of(v_ru_2410)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_taken_243)) {
      case TAG_Nothing: {
        heff_drop(v_sv_242);
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_t_2449 = (g_heff_2ecompile_2eemitc_2efieldMask(v_fb_248, MK_INT(0LL), v_vs_246));
        V v_t_2450 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_246));
        V v_t_2451 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str4), heff_strAppend(v_sv_242, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str5), heff_strAppend(heff_intShow(v_t_2449), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str6), heff_strAppend(heff_intShow(v_t_2450), ((V)&g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str7)))))));
        v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_taken_243);
      }
      break;
    }
    case TAG_Just: {
      v_t_2453 = ({ V a_0 = v_sv_242; V a_1 = v_ru_2410; V a_2 = v_vs_246; V a_3 = v_fb_248; V r_ = (g_heff_2ecompile_2eemitc_2etakeKept(a_0, a_1, a_2, a_3)); heff_drop_tag(v_ru_2410, 1); r_; });
      break;
    }
    default: heff_nomatch(v_ru_2410);
    }
    V v_t_2455;
    switch (heff_tag_of(v_lent_244)) {
    case TAG_True: {
      heff_drop(v_vs_246);
      v_t_2455 = NTAG(TAG_Nil);
      break;
    }
    case TAG_False: {
      v_t_2455 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam4, 1, 1, (V[]){heff_dup(v_fb_248)}), v_vs_246));
      break;
    }
    default: heff_nomatch(v_lent_244);
    }
    V v_owned_2456 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_240, 6)), v_t_2455));
    V v_wanted_2457 = (g_prelude_2e_2b_2b(v_fb_248, heff_dup(heff_rfield(v_ce_240, 7))));
    V v_t_2460 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam5, 1, 1, (V[]){v_wanted_2457}), v_owned_2456));
    V v_t_2465 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_lam6, 1, 1, (V[]){v_taken_243}), v_t_2460));
    V v_t_2466 = (g_heff_2ecompile_2eemitc_2edropsIn(v_ce_240, v_t_2465));
    V v_t_2467 = (g_prelude_2e_2b_2b(v_t_2453, v_t_2466));
    V v_t_2468 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str8), v_t_2467));
    V v_t_2469 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str9), v_x_2432));
    V v_t_2471;
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      v_t_2471 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Asg: {
      heff_take_n(v_dest_241, 0ULL, 1);
      v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str10), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_dest_241);
    }
    V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939_str11), NTAG(TAG_Nil)});
    V v_t_2473 = (g_prelude_2e_2b_2b(v_t_2471, v_t_2472));
    V v_t_2474 = (g_prelude_2e_2b_2b(v_t_2469, v_t_2473));
    V v_t_2475 = (g_prelude_2e_2b_2b(v_t_2468, v_t_2474));
    V v_t_2476 = (g_prelude_2e_2b_2b(v_t_2447, v_t_2475));
    V v_x_2477 = (g_prelude_2e_2b_2b(v_t_2436, v_t_2476));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2477, v_s_2433});
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
Clo g_heff_2ecompile_2eemitc_2earmLines_24s2056739052x1812096441_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2earmLines_24s2056739052x1812096441_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2earmLines_24s2056739052x1812096441(V v_ce_240, V v_dest_241, V v_sv_242, V v_held_243, V v_lent_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_MkArm: {
    V v_t_246 = heff_field(v_x7_245, 0);
    V v_vs_247 = heff_field(v_x7_245, 1);
    V v_b_248 = heff_field(v_x7_245, 2);
    V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_247));
    V v_ce_2410 = (g_heff_2ecompile_2eemitc_2eknowing(heff_dup(v_held_243), v_t_249, v_ce_240));
    V v_fb_2411 = (g_heff_2ecompile_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_b_248)));
    V v_taken_2412 = (g_heff_2ecompile_2eemitc_2etakenFv(heff_dup(v_ce_2410), v_held_243, v_vs_247, v_fb_2411));
    V v_t_2413 = (g_heff_2ecompile_2eemitc_2ereusing(heff_dup(v_taken_2412), heff_dup(v_t_246), v_vs_247, heff_dup(v_b_248)));
    return ({ V a_0 = v_ce_2410; V a_1 = v_dest_241; V a_2 = v_sv_242; V a_3 = v_taken_2412; V a_4 = v_lent_244; V a_5 = heff_dup(v_t_246); V a_6 = heff_dup(v_vs_247); V a_7 = v_b_248; V a_8 = v_fb_2411; V a_9 = v_t_2413; V r_ = (g_heff_2ecompile_2eemitc_2earmKept_24s2074031880x703916939(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_taken_2412); r_; });
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2eemitc_2earmLines_24s2056739052x1812096441_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2earmLines_24s2056739052x1812096441(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[4]); heff_drop(a[5]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str0, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str1, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str2, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str3, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str4, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str5, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str6, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str7, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str8, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str9, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str10, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str11, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str12, 1, (48));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str13, 4, (78, 85, 76, 76));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str14, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str15, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str16, 6, (40, 86, 91, 93, 41, 123));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str17, 1, (125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str18, 17, (114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 116, 97, 105, 108, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str19, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str20, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str21, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str22, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str23, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str24, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str25, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str26, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str27, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str28, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str29, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str30, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str31, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str32, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str33, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str34, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str35, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str36, 20, (115, 119, 105, 116, 99, 104, 32, 40, 104, 101, 102, 102, 95, 116, 97, 103, 95, 111, 102, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str37, 4, (41, 41, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str38, 20, (114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 110, 111, 109, 97, 116, 99, 104, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str39, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str40, 13, (104, 101, 102, 102, 95, 110, 111, 109, 97, 116, 99, 104, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str41, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str42, 1, (125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str43, 9, (100, 101, 102, 97, 117, 108, 116, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str44, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str45, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str46, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str47, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str48, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str49, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str50, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str51, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str52, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str53, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str54, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str55, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str56, 17, (72, 69, 70, 70, 95, 76, 65, 83, 84, 32, 114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str57, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str58, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str59, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str60, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str61, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str62, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str63, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str64, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str65, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str66, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str67, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str68, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str69, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str70, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str71, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str72, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str73, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str74, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str75, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str76, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str77, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str78, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str79, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str80, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str81, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str82, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str83, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str84, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str85, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str86, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str87, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str88, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str89, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str90, 1, (59));
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam8(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam9(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam10(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam11(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam12(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam13(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam14(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam15(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam16(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam17(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam18(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam19(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam20(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam21(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam22(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam23(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam24(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam25(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam26(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam27(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam28(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam29(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam30(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam31(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam32(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam33(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam34(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499(V v_ce_240, V v_dest_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_244 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam0, 1, 1, (V[]){v_m_244});
    }
    case TAG_Asg: {
      V v_x_2411 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_2412 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam1, 1, 2, (V[]){v_m_2412, v_x_2411});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EGlobal: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_2420 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam2, 1, 1, (V[]){v_m_2420});
    }
    case TAG_Asg: {
      V v_x_2427 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_2428 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam3, 1, 2, (V[]){v_m_2428, v_x_2427});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_ELam: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_2437 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam4, 1, 1, (V[]){v_m_2437});
    }
    case TAG_Asg: {
      V v_x_2444 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_2445 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam5, 1, 2, (V[]){v_m_2445, v_x_2444});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EApp: {
    V v_f_2452 = heff_dup(heff_field(v_e_242, 0));
    V v_as_2453 = heff_dup(heff_field(v_e_242, 1));
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      heff_drop_tag(v_e_242, 2);
      V v_m_2454 = (g_heff_2ecompile_2eemitc_2eoperandsF_24s324528462x1799687634(heff_dup(v_ce_240), NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_f_2452, heff_dup(v_as_2453)})));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam6, 1, 3, (V[]){v_m_2454, v_as_2453, v_ce_240});
    }
    case TAG_Asg: {
      V v_x_2478 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      heff_drop(v_f_2452);
      heff_drop(v_as_2453);
      V v_m_2479 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam7, 1, 2, (V[]){v_m_2479, v_x_2478});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_ELet: {
    V v_x_2486 = heff_field(v_e_242, 0);
    V v_a_2487 = heff_field(v_e_242, 1);
    V v_b_2488 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_2489 = (g_heff_2ecompile_2eemitc_2econdLet(heff_dup(v_x_2486), v_a_2487, v_b_2488));
    return ({ V a_0 = v_ce_240; V a_1 = v_dest_241; V a_2 = v_x_2486; V a_3 = v_a_2487; V a_4 = v_b_2488; V a_5 = v_t_2489; V r_ = (g_heff_2ecompile_2eemitc_2eletOrCond_24s386767440x905233418(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2489); r_; });
  }
  case TAG_ERecord: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_2491 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam8, 1, 1, (V[]){v_m_2491});
    }
    case TAG_Asg: {
      V v_x_2498 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_2499 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam9, 1, 2, (V[]){v_m_2499, v_x_2498});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EProj: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24109 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam10, 1, 1, (V[]){v_m_24109});
    }
    case TAG_Asg: {
      V v_x_24116 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24117 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam11, 1, 2, (V[]){v_m_24117, v_x_24116});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_ETag: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24126 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam12, 1, 1, (V[]){v_m_24126});
    }
    case TAG_Asg: {
      V v_x_24133 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24134 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam13, 1, 2, (V[]){v_m_24134, v_x_24133});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EMatch: {
    V v_s_24141 = heff_field(v_e_242, 0);
    V v_arms_24142 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_24143 = heff_tr(g_heff_2ecompile_2eemitc_2escrutF_24s200989067x2110690452(heff_dup(v_ce_240), heff_dup(v_s_24141)));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam14, 1, 5, (V[]){v_m_24143, v_ce_240, v_s_24141, v_dest_241, v_arms_24142});
  }
  case TAG_EPrim: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24196 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam15, 1, 1, (V[]){v_m_24196});
    }
    case TAG_Asg: {
      V v_x_24203 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24204 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam16, 1, 2, (V[]){v_m_24204, v_x_24203});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EPrimCall: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24213 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam17, 1, 1, (V[]){v_m_24213});
    }
    case TAG_Asg: {
      V v_x_24220 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24221 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam18, 1, 2, (V[]){v_m_24221, v_x_24220});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_ECall: {
    V v_g_24228 = heff_dup(heff_field(v_e_242, 0));
    V v_as_24229 = heff_dup(heff_field(v_e_242, 1));
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      heff_drop_tag(v_e_242, 2);
      V v_x2_24230 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_24228), heff_rfield(v_ce_240, 9)));
      V v_t_24232;
      switch (heff_tag_of(v_x2_24230)) {
      case TAG_Nothing: {
        v_t_24232 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_24231 = heff_field(v_x2_24230, 0);
        heff_take_n(v_x2_24230, 1ULL, 1);
        v_t_24232 = v_x_24231;
        break;
      }
      default: heff_nomatch(v_x2_24230);
      }
      V v_m_24233 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24232; V a_3 = MK_INT(0LL); V a_4 = heff_dup(v_as_24229); V r_ = (g_heff_2ecompile_2eemitc_2elentOperands_24s476183159x330509729(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_24232); r_; });
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam19, 1, 4, (V[]){v_m_24233, v_ce_240, v_g_24228, v_as_24229});
    }
    case TAG_Asg: {
      V v_x_24257 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      heff_drop(v_g_24228);
      heff_drop(v_as_24229);
      V v_m_24258 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam20, 1, 2, (V[]){v_m_24258, v_x_24257});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EInt: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24266 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam21, 1, 1, (V[]){v_m_24266});
    }
    case TAG_Asg: {
      V v_x_24273 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24274 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam22, 1, 2, (V[]){v_m_24274, v_x_24273});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EFloat: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24282 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam23, 1, 1, (V[]){v_m_24282});
    }
    case TAG_Asg: {
      V v_x_24289 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24290 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam24, 1, 2, (V[]){v_m_24290, v_x_24289});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EStr: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24298 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam25, 1, 1, (V[]){v_m_24298});
    }
    case TAG_Asg: {
      V v_x_24305 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24306 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam26, 1, 2, (V[]){v_m_24306, v_x_24305});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EFixed: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24315 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam27, 1, 1, (V[]){v_m_24315});
    }
    case TAG_Asg: {
      V v_x_24322 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24323 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam28, 1, 2, (V[]){v_m_24323, v_x_24322});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EFloat32: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24331 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam29, 1, 1, (V[]){v_m_24331});
    }
    case TAG_Asg: {
      V v_x_24338 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24339 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam30, 1, 2, (V[]){v_m_24339, v_x_24338});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EAbandon: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24346 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam31, 1, 1, (V[]){v_m_24346});
    }
    case TAG_Asg: {
      V v_x_24353 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24354 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam32, 1, 2, (V[]){v_m_24354, v_x_24353});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EFix: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24363 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam33, 1, 1, (V[]){v_m_24363});
    }
    case TAG_Asg: {
      V v_x_24370 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24371 = heff_tr(g_heff_2ecompile_2eemitc_2ecompF_24s1852451023x122390487(heff_dup(v_ce_240), heff_get_n(v_ce_240, 7, 12), v_e_242));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam34, 1, 2, (V[]){v_m_24371, v_x_24370});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_246 = heff_tr(heff_apply(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str0), heff_strAppend(v_x_247, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str1)));
    V v_t_2410 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_s_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam1(V self, V *args) {
  V v_s_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2414 = heff_tr(heff_apply(v_m_2412, 1, (V[]){v_s_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_s_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    V v_t_2417 = heff_strAppend(v_x_2411, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str2), heff_strAppend(v_x_2415, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str3))));
    V v_t_2418 = heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, v_s_2416});
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam2(V self, V *args) {
  V v_s_2421 = args[0];
  V v_m_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2422 = heff_tr(heff_apply(v_m_2420, 1, (V[]){v_s_2421}));
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_MkPair: {
    V v_x_2423 = heff_field(v_x2_2422, 0);
    V v_s_2424 = heff_field(v_x2_2422, 1);
    V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
    V v_t_2425 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str4), heff_strAppend(v_x_2423, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str5)));
    V v_t_2426 = heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2426, v_s_2424});
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam3(V self, V *args) {
  V v_s_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2430 = heff_tr(heff_apply(v_m_2428, 1, (V[]){v_s_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_s_2432 = heff_field(v_x2_2430, 1);
    V v_ru_24x2_2430_24MkPair = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
    V v_t_2433 = heff_strAppend(v_x_2427, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str6), heff_strAppend(v_x_2431, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str7))));
    V v_t_2434 = heff_tag_at_n(v_ru_24x2_2430_24MkPair, TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2434, v_s_2432});
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam4(V self, V *args) {
  V v_s_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2439 = heff_tr(heff_apply(v_m_2437, 1, (V[]){v_s_2438}));
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_field(v_x2_2439, 0);
    V v_s_2441 = heff_field(v_x2_2439, 1);
    V v_ru_24x2_2439_24MkPair = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
    V v_t_2442 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str8), heff_strAppend(v_x_2440, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str9)));
    V v_t_2443 = heff_tag_at_n(v_ru_24x2_2439_24MkPair, TAG_Cons, 2, (V[]){v_t_2442, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2443, v_s_2441});
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam5(V self, V *args) {
  V v_s_2446 = args[0];
  V v_m_2445 = heff_env(self)[0];
  V v_x_2444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2447 = heff_tr(heff_apply(v_m_2445, 1, (V[]){v_s_2446}));
  switch (heff_tag_of(v_x2_2447)) {
  case TAG_MkPair: {
    V v_x_2448 = heff_field(v_x2_2447, 0);
    V v_s_2449 = heff_field(v_x2_2447, 1);
    V v_ru_24x2_2447_24MkPair = heff_take_reuse_n(v_x2_2447, 3ULL, 2);
    V v_t_2450 = heff_strAppend(v_x_2444, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str10), heff_strAppend(v_x_2448, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str11))));
    V v_t_2451 = heff_tag_at_n(v_ru_24x2_2447_24MkPair, TAG_Cons, 2, (V[]){v_t_2450, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2451, v_s_2449});
  }
  default: return heff_nomatch(v_x2_2447);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam6(V self, V *args) {
  V v_s_2455 = args[0];
  V v_m_2454 = heff_env(self)[0];
  V v_as_2453 = heff_env(self)[1];
  V v_ce_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2456 = heff_tr(heff_apply(v_m_2454, 1, (V[]){v_s_2455}));
  switch (heff_tag_of(v_x2_2456)) {
  case TAG_MkPair: {
    V v_x_2457 = heff_field(v_x2_2456, 0);
    V v_s_2458 = heff_field(v_x2_2456, 1);
    V v_ru_24x2_2456_24MkPair = heff_take_reuse_n(v_x2_2456, 3ULL, 2);
    V v_t_2459 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2453));
    V v_t_2462;
    if (heff_intLt_c(MK_INT(0LL), v_t_2459)) {
      V v_t_2461 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2453));
      v_t_2462 = heff_intLe(v_t_2461, heff_get_n(v_ce_240, 5, 12));
    } else {
      heff_drop_rec(v_ce_240, 12);
      v_t_2462 = NTAG(TAG_False);
    }
    V v_x_2477;
    switch (heff_tag_of(v_t_2462)) {
    case TAG_True: {
      heff_drop(v_as_2453);
      heff_drop_cell(v_ru_24x2_2456_24MkPair, 2);
      v_x_2477 = (g_heff_2ecompile_2eemitc_2einPlace(v_x_2457));
      break;
    }
    case TAG_False: {
      V v_x2_2465;
      switch (heff_tag_of(v_x_2457)) {
      case TAG_Nil: {
        v_x2_2465 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2463 = heff_dup(heff_field(v_x_2457, 0));
        v_x2_2465 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2463});
        break;
      }
      default: heff_nomatch(v_x_2457);
      }
      V v_t_2467;
      switch (heff_tag_of(v_x2_2465)) {
      case TAG_Nothing: {
        v_t_2467 = ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str12);
        break;
      }
      case TAG_Just: {
        V v_x_2466 = heff_field(v_x2_2465, 0);
        heff_take_n(v_x2_2465, 1ULL, 1);
        v_t_2467 = v_x_2466;
        break;
      }
      default: heff_nomatch(v_x2_2465);
      }
      V v_t_2468 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_as_2453; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_as_2453); r_; });
      V v_vs_2469 = (g_list_2edrop(MK_INT(1LL), v_x_2457));
      V v_t_2475;
      switch (heff_tag_of(v_vs_2469)) {
      case TAG_Nil: {
        v_t_2475 = ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str13);
        break;
      }
      case TAG_Cons: {
        V v_t_2474;
        switch (heff_tag_of(v_vs_2469)) {
        case TAG_Nil: {
          v_t_2474 = ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str14);
          break;
        }
        case TAG_Cons: {
          V v_x_2472 = heff_field(v_vs_2469, 0);
          V v_xs_2473 = heff_field(v_vs_2469, 1);
          heff_take_n(v_vs_2469, 3ULL, 2);
          v_t_2474 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str15); V a_1 = v_x_2472; V a_2 = v_xs_2473; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2473); r_; });
          break;
        }
        default: heff_nomatch(v_vs_2469);
        }
        v_t_2475 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str16), heff_strAppend(v_t_2474, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str17)));
        break;
      }
      default: heff_nomatch(v_vs_2469);
      }
      V v_t_2476 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str18), heff_strAppend(v_t_2467, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str19), heff_strAppend(heff_intShow(v_t_2468), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str20), heff_strAppend(v_t_2475, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str21)))))));
      v_x_2477 = heff_tag_at_n(v_ru_24x2_2456_24MkPair, TAG_Cons, 2, (V[]){v_t_2476, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2462);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2477, v_s_2458});
  }
  default: return heff_nomatch(v_x2_2456);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam7(V self, V *args) {
  V v_s_2480 = args[0];
  V v_m_2479 = heff_env(self)[0];
  V v_x_2478 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2481 = heff_tr(heff_apply(v_m_2479, 1, (V[]){v_s_2480}));
  switch (heff_tag_of(v_x2_2481)) {
  case TAG_MkPair: {
    V v_x_2482 = heff_field(v_x2_2481, 0);
    V v_s_2483 = heff_field(v_x2_2481, 1);
    V v_ru_24x2_2481_24MkPair = heff_take_reuse_n(v_x2_2481, 3ULL, 2);
    V v_t_2484 = heff_strAppend(v_x_2478, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str22), heff_strAppend(v_x_2482, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str23))));
    V v_t_2485 = heff_tag_at_n(v_ru_24x2_2481_24MkPair, TAG_Cons, 2, (V[]){v_t_2484, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2485, v_s_2483});
  }
  default: return heff_nomatch(v_x2_2481);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam8(V self, V *args) {
  V v_s_2492 = args[0];
  V v_m_2491 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2493 = heff_tr(heff_apply(v_m_2491, 1, (V[]){v_s_2492}));
  switch (heff_tag_of(v_x2_2493)) {
  case TAG_MkPair: {
    V v_x_2494 = heff_field(v_x2_2493, 0);
    V v_s_2495 = heff_field(v_x2_2493, 1);
    V v_ru_24x2_2493_24MkPair = heff_take_reuse_n(v_x2_2493, 3ULL, 2);
    V v_t_2496 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str24), heff_strAppend(v_x_2494, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str25)));
    V v_t_2497 = heff_tag_at_n(v_ru_24x2_2493_24MkPair, TAG_Cons, 2, (V[]){v_t_2496, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2497, v_s_2495});
  }
  default: return heff_nomatch(v_x2_2493);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam9(V self, V *args) {
  V v_s_24100 = args[0];
  V v_m_2499 = heff_env(self)[0];
  V v_x_2498 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24101 = heff_tr(heff_apply(v_m_2499, 1, (V[]){v_s_24100}));
  switch (heff_tag_of(v_x2_24101)) {
  case TAG_MkPair: {
    V v_x_24102 = heff_field(v_x2_24101, 0);
    V v_s_24103 = heff_field(v_x2_24101, 1);
    V v_ru_24x2_24101_24MkPair = heff_take_reuse_n(v_x2_24101, 3ULL, 2);
    V v_t_24104 = heff_strAppend(v_x_2498, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str26), heff_strAppend(v_x_24102, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str27))));
    V v_t_24105 = heff_tag_at_n(v_ru_24x2_24101_24MkPair, TAG_Cons, 2, (V[]){v_t_24104, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24105, v_s_24103});
  }
  default: return heff_nomatch(v_x2_24101);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam10(V self, V *args) {
  V v_s_24110 = args[0];
  V v_m_24109 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24111 = heff_tr(heff_apply(v_m_24109, 1, (V[]){v_s_24110}));
  switch (heff_tag_of(v_x2_24111)) {
  case TAG_MkPair: {
    V v_x_24112 = heff_field(v_x2_24111, 0);
    V v_s_24113 = heff_field(v_x2_24111, 1);
    V v_ru_24x2_24111_24MkPair = heff_take_reuse_n(v_x2_24111, 3ULL, 2);
    V v_t_24114 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str28), heff_strAppend(v_x_24112, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str29)));
    V v_t_24115 = heff_tag_at_n(v_ru_24x2_24111_24MkPair, TAG_Cons, 2, (V[]){v_t_24114, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24115, v_s_24113});
  }
  default: return heff_nomatch(v_x2_24111);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam11(V self, V *args) {
  V v_s_24118 = args[0];
  V v_m_24117 = heff_env(self)[0];
  V v_x_24116 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24119 = heff_tr(heff_apply(v_m_24117, 1, (V[]){v_s_24118}));
  switch (heff_tag_of(v_x2_24119)) {
  case TAG_MkPair: {
    V v_x_24120 = heff_field(v_x2_24119, 0);
    V v_s_24121 = heff_field(v_x2_24119, 1);
    V v_ru_24x2_24119_24MkPair = heff_take_reuse_n(v_x2_24119, 3ULL, 2);
    V v_t_24122 = heff_strAppend(v_x_24116, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str30), heff_strAppend(v_x_24120, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str31))));
    V v_t_24123 = heff_tag_at_n(v_ru_24x2_24119_24MkPair, TAG_Cons, 2, (V[]){v_t_24122, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24123, v_s_24121});
  }
  default: return heff_nomatch(v_x2_24119);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam12(V self, V *args) {
  V v_s_24127 = args[0];
  V v_m_24126 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24128 = heff_tr(heff_apply(v_m_24126, 1, (V[]){v_s_24127}));
  switch (heff_tag_of(v_x2_24128)) {
  case TAG_MkPair: {
    V v_x_24129 = heff_field(v_x2_24128, 0);
    V v_s_24130 = heff_field(v_x2_24128, 1);
    V v_ru_24x2_24128_24MkPair = heff_take_reuse_n(v_x2_24128, 3ULL, 2);
    V v_t_24131 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str32), heff_strAppend(v_x_24129, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str33)));
    V v_t_24132 = heff_tag_at_n(v_ru_24x2_24128_24MkPair, TAG_Cons, 2, (V[]){v_t_24131, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24132, v_s_24130});
  }
  default: return heff_nomatch(v_x2_24128);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam13(V self, V *args) {
  V v_s_24135 = args[0];
  V v_m_24134 = heff_env(self)[0];
  V v_x_24133 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24136 = heff_tr(heff_apply(v_m_24134, 1, (V[]){v_s_24135}));
  switch (heff_tag_of(v_x2_24136)) {
  case TAG_MkPair: {
    V v_x_24137 = heff_field(v_x2_24136, 0);
    V v_s_24138 = heff_field(v_x2_24136, 1);
    V v_ru_24x2_24136_24MkPair = heff_take_reuse_n(v_x2_24136, 3ULL, 2);
    V v_t_24139 = heff_strAppend(v_x_24133, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str34), heff_strAppend(v_x_24137, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str35))));
    V v_t_24140 = heff_tag_at_n(v_ru_24x2_24136_24MkPair, TAG_Cons, 2, (V[]){v_t_24139, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24140, v_s_24138});
  }
  default: return heff_nomatch(v_x2_24136);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam14(V self, V *args) {
  V v_s_24144 = args[0];
  V v_m_24143 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  V v_s_24141 = heff_env(self)[2];
  V v_dest_241 = heff_env(self)[3];
  V v_arms_24142 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24145 = heff_tr(heff_apply(v_m_24143, 1, (V[]){v_s_24144}));
  switch (heff_tag_of(v_x2_24145)) {
  case TAG_MkPair: {
    V v_x_24146 = heff_field(v_x2_24145, 0);
    V v_s_24147 = heff_field(v_x2_24145, 1);
    V v_ru_24x2_24145_24MkPair = heff_take_reuse_n(v_x2_24145, 3ULL, 2);
    V v_t_24148 = (g_heff_2ecompile_2eemitc_2eheldVar(heff_dup(v_ce_240), heff_dup(v_s_24141)));
    V v_t_24179;
    switch (heff_tag_of(v_s_24141)) {
    case TAG_EVar: {
      V v_x_24149 = heff_field(v_s_24141, 0);
      heff_take_n(v_s_24141, 1ULL, 1);
      v_t_24179 = (g_heff_2ecompile_2eemitc_2eelemS(v_x_24149, heff_rfield(v_ce_240, 8)));
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_s_24141, 0ULL, 1);
      v_t_24179 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_s_24141, 0ULL, 2);
      v_t_24179 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_s_24141, 0ULL, 2);
      v_t_24179 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_s_24141, 0ULL, 3);
      v_t_24179 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_s_24141, 0ULL, 1);
      v_t_24179 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_s_24141, 0ULL, 3);
      v_t_24179 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_s_24141, 0ULL, 2);
      v_t_24179 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_s_24141, 0ULL, 2);
      v_t_24179 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_s_24141, 0ULL, 1);
      v_t_24179 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_s_24141, 0ULL, 2);
      v_t_24179 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_s_24141, 0ULL, 2);
      v_t_24179 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_s_24141, 0ULL, 1);
      v_t_24179 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_n(v_s_24141, 0ULL, 1);
      v_t_24179 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_s_24141, 0ULL, 1);
      v_t_24179 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_s_24141, 0ULL, 2);
      v_t_24179 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_n(v_s_24141, 0ULL, 1);
      v_t_24179 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_24179 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_s_24141, 0ULL, 2);
      v_t_24179 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_24141);
    }
    V v_t_24180 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2earmLines_24s2056739052x1812096441_clo), 5, (V[]){v_ce_240, heff_dup(v_dest_241), heff_dup(v_x_24146), v_t_24148, v_t_24179}));
    V v_m_24181 = (g_heff_2ecompile_2eemitc_2etraverseC(v_t_24180, v_arms_24142));
    V v_x2_24182 = heff_tr(heff_apply(v_m_24181, 1, (V[]){v_s_24147}));
    switch (heff_tag_of(v_x2_24182)) {
    case TAG_MkPair: {
      V v_x_24183 = heff_field(v_x2_24182, 0);
      V v_s_24184 = heff_field(v_x2_24182, 1);
      V v_ru_24x2_24182_24MkPair = heff_take_reuse_n(v_x2_24182, 3ULL, 2);
      V v_t_24185 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str36), heff_strAppend(heff_dup(v_x_24146), ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str37)));
      V v_t_24186 = heff_tag_at_n(v_ru_24x2_24145_24MkPair, TAG_Cons, 2, (V[]){v_t_24185, NTAG(TAG_Nil)});
      V v_t_24187 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_24183));
      V v_t_24188 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24187; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_24187); r_; });
      V v_t_24190;
      switch (heff_tag_of(v_dest_241)) {
      case TAG_Ret: {
        v_t_24190 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str38), heff_strAppend(v_x_24146, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str39)));
        break;
      }
      case TAG_Asg: {
        heff_take_n(v_dest_241, 0ULL, 1);
        v_t_24190 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str40), heff_strAppend(v_x_24146, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str41)));
        break;
      }
      default: heff_nomatch(v_dest_241);
      }
      V v_t_24191 = heff_tag_at_n(v_ru_24x2_24182_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str42), NTAG(TAG_Nil)});
      V v_t_24192 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str43), v_t_24190), v_t_24191});
      V v_t_24193 = (g_prelude_2e_2b_2b(v_t_24188, v_t_24192));
      V v_x_24194 = (g_prelude_2e_2b_2b(v_t_24186, v_t_24193));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24194, v_s_24184});
    }
    default: return heff_nomatch(v_x2_24182);
    }
  }
  default: return heff_nomatch(v_x2_24145);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam15(V self, V *args) {
  V v_s_24197 = args[0];
  V v_m_24196 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24198 = heff_tr(heff_apply(v_m_24196, 1, (V[]){v_s_24197}));
  switch (heff_tag_of(v_x2_24198)) {
  case TAG_MkPair: {
    V v_x_24199 = heff_field(v_x2_24198, 0);
    V v_s_24200 = heff_field(v_x2_24198, 1);
    V v_ru_24x2_24198_24MkPair = heff_take_reuse_n(v_x2_24198, 3ULL, 2);
    V v_t_24201 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str44), heff_strAppend(v_x_24199, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str45)));
    V v_t_24202 = heff_tag_at_n(v_ru_24x2_24198_24MkPair, TAG_Cons, 2, (V[]){v_t_24201, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24202, v_s_24200});
  }
  default: return heff_nomatch(v_x2_24198);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam16(V self, V *args) {
  V v_s_24205 = args[0];
  V v_m_24204 = heff_env(self)[0];
  V v_x_24203 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24206 = heff_tr(heff_apply(v_m_24204, 1, (V[]){v_s_24205}));
  switch (heff_tag_of(v_x2_24206)) {
  case TAG_MkPair: {
    V v_x_24207 = heff_field(v_x2_24206, 0);
    V v_s_24208 = heff_field(v_x2_24206, 1);
    V v_ru_24x2_24206_24MkPair = heff_take_reuse_n(v_x2_24206, 3ULL, 2);
    V v_t_24209 = heff_strAppend(v_x_24203, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str46), heff_strAppend(v_x_24207, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str47))));
    V v_t_24210 = heff_tag_at_n(v_ru_24x2_24206_24MkPair, TAG_Cons, 2, (V[]){v_t_24209, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24210, v_s_24208});
  }
  default: return heff_nomatch(v_x2_24206);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam17(V self, V *args) {
  V v_s_24214 = args[0];
  V v_m_24213 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24215 = heff_tr(heff_apply(v_m_24213, 1, (V[]){v_s_24214}));
  switch (heff_tag_of(v_x2_24215)) {
  case TAG_MkPair: {
    V v_x_24216 = heff_field(v_x2_24215, 0);
    V v_s_24217 = heff_field(v_x2_24215, 1);
    V v_ru_24x2_24215_24MkPair = heff_take_reuse_n(v_x2_24215, 3ULL, 2);
    V v_t_24218 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str48), heff_strAppend(v_x_24216, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str49)));
    V v_t_24219 = heff_tag_at_n(v_ru_24x2_24215_24MkPair, TAG_Cons, 2, (V[]){v_t_24218, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24219, v_s_24217});
  }
  default: return heff_nomatch(v_x2_24215);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam18(V self, V *args) {
  V v_s_24222 = args[0];
  V v_m_24221 = heff_env(self)[0];
  V v_x_24220 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24223 = heff_tr(heff_apply(v_m_24221, 1, (V[]){v_s_24222}));
  switch (heff_tag_of(v_x2_24223)) {
  case TAG_MkPair: {
    V v_x_24224 = heff_field(v_x2_24223, 0);
    V v_s_24225 = heff_field(v_x2_24223, 1);
    V v_ru_24x2_24223_24MkPair = heff_take_reuse_n(v_x2_24223, 3ULL, 2);
    V v_t_24226 = heff_strAppend(v_x_24220, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str50), heff_strAppend(v_x_24224, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str51))));
    V v_t_24227 = heff_tag_at_n(v_ru_24x2_24223_24MkPair, TAG_Cons, 2, (V[]){v_t_24226, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24227, v_s_24225});
  }
  default: return heff_nomatch(v_x2_24223);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam19(V self, V *args) {
  V v_s_24234 = args[0];
  V v_m_24233 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  V v_g_24228 = heff_env(self)[2];
  V v_as_24229 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24235 = heff_tr(heff_apply(v_m_24233, 1, (V[]){v_s_24234}));
  switch (heff_tag_of(v_x2_24235)) {
  case TAG_MkPair: {
    V v_x_24236 = heff_field(v_x2_24235, 0);
    V v_s_24237 = heff_field(v_x2_24235, 1);
    V v_ru_24x2_24235_24MkPair = heff_take_reuse_n(v_x2_24235, 3ULL, 2);
    V v_t_24238 = heff_dup(heff_rfield(v_ce_240, 4));
    V v_t_24244;
    switch (heff_tag_of(v_t_24238)) {
    case TAG_Nothing: {
      v_t_24244 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_s_24239 = heff_field(v_t_24238, 0);
      heff_take_n(v_t_24238, 1ULL, 1);
      if (heff_strEq_c(heff_dup(heff_rfield(v_s_24239, 0)), heff_dup(v_g_24228))) {
        V v_t_24241 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_s_24239, 1, 2); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        V v_t_24242 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_24229));
        if (heff_intEq_c(v_t_24241, v_t_24242)) {
          v_t_24244 = (g_list_2eall_24s607638492x847921129(v_x_24236));
        } else {
          v_t_24244 = NTAG(TAG_False);
        }
      } else {
        heff_drop_rec(v_s_24239, 2);
        v_t_24244 = NTAG(TAG_False);
      }
      break;
    }
    default: heff_nomatch(v_t_24238);
    }
    V v_x_24256;
    switch (heff_tag_of(v_t_24244)) {
    case TAG_True: {
      heff_drop(v_g_24228);
      heff_drop(v_as_24229);
      heff_drop_cell(v_ru_24x2_24235_24MkPair, 2);
      V v_t_24245 = (g_list_2emap_24s1198759183x473355350(v_x_24236));
      v_x_24256 = (g_heff_2ecompile_2eemitc_2eagain(v_ce_240, v_t_24245));
      break;
    }
    case TAG_False: {
      V v_t_24246 = ({ V a_0 = v_ce_240; V a_1 = heff_dup(v_g_24228); V a_2 = v_as_24229; V r_ = (g_heff_2ecompile_2eemitc_2eagrees(a_0, a_1, a_2)); heff_drop(v_as_24229); r_; });
      V v_t_24247;
      switch (heff_tag_of(v_t_24246)) {
      case TAG_True: {
        v_t_24247 = (g_list_2eall_24s607638492x847921129(v_x_24236));
        break;
      }
      case TAG_False: {
        v_t_24247 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_24246);
      }
      switch (heff_tag_of(v_t_24247)) {
      case TAG_True: {
        V v_t_24248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str52), (g_heff_2ecompile_2eemitc_2emangleW(v_g_24228, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str53))));
        V v_x2_24249 = (g_list_2emap_24s1198759183x473355350(v_x_24236));
        V v_t_24252;
        switch (heff_tag_of(v_x2_24249)) {
        case TAG_Nil: {
          v_t_24252 = ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str54);
          break;
        }
        case TAG_Cons: {
          V v_x_24250 = heff_field(v_x2_24249, 0);
          V v_xs_24251 = heff_field(v_x2_24249, 1);
          heff_take_n(v_x2_24249, 3ULL, 2);
          v_t_24252 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str55); V a_1 = v_x_24250; V a_2 = v_xs_24251; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24251); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24249);
        }
        V v_t_24253 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str56), heff_strAppend(v_t_24248, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str57), heff_strAppend(v_t_24252, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str58)))));
        v_x_24256 = heff_tag_at_n(v_ru_24x2_24235_24MkPair, TAG_Cons, 2, (V[]){v_t_24253, NTAG(TAG_Nil)});
        break;
      }
      case TAG_False: {
        V v_t_24254 = ({ V a_0 = v_g_24228; V b_1 = NTAG(TAG_False); V a_2 = v_x_24236; V r_ = (g_heff_2ecompile_2eemitc_2ecallText(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        V v_t_24255 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str59), heff_strAppend(v_t_24254, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str60)));
        v_x_24256 = heff_tag_at_n(v_ru_24x2_24235_24MkPair, TAG_Cons, 2, (V[]){v_t_24255, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_t_24247);
      }
      break;
    }
    default: heff_nomatch(v_t_24244);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24256, v_s_24237});
  }
  default: return heff_nomatch(v_x2_24235);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam20(V self, V *args) {
  V v_s_24259 = args[0];
  V v_m_24258 = heff_env(self)[0];
  V v_x_24257 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24260 = heff_tr(heff_apply(v_m_24258, 1, (V[]){v_s_24259}));
  switch (heff_tag_of(v_x2_24260)) {
  case TAG_MkPair: {
    V v_x_24261 = heff_field(v_x2_24260, 0);
    V v_s_24262 = heff_field(v_x2_24260, 1);
    V v_ru_24x2_24260_24MkPair = heff_take_reuse_n(v_x2_24260, 3ULL, 2);
    V v_t_24263 = heff_strAppend(v_x_24257, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str61), heff_strAppend(v_x_24261, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str62))));
    V v_t_24264 = heff_tag_at_n(v_ru_24x2_24260_24MkPair, TAG_Cons, 2, (V[]){v_t_24263, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24264, v_s_24262});
  }
  default: return heff_nomatch(v_x2_24260);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam21(V self, V *args) {
  V v_s_24267 = args[0];
  V v_m_24266 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24268 = heff_tr(heff_apply(v_m_24266, 1, (V[]){v_s_24267}));
  switch (heff_tag_of(v_x2_24268)) {
  case TAG_MkPair: {
    V v_x_24269 = heff_field(v_x2_24268, 0);
    V v_s_24270 = heff_field(v_x2_24268, 1);
    V v_ru_24x2_24268_24MkPair = heff_take_reuse_n(v_x2_24268, 3ULL, 2);
    V v_t_24271 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str63), heff_strAppend(v_x_24269, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str64)));
    V v_t_24272 = heff_tag_at_n(v_ru_24x2_24268_24MkPair, TAG_Cons, 2, (V[]){v_t_24271, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24272, v_s_24270});
  }
  default: return heff_nomatch(v_x2_24268);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam22(V self, V *args) {
  V v_s_24275 = args[0];
  V v_m_24274 = heff_env(self)[0];
  V v_x_24273 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24276 = heff_tr(heff_apply(v_m_24274, 1, (V[]){v_s_24275}));
  switch (heff_tag_of(v_x2_24276)) {
  case TAG_MkPair: {
    V v_x_24277 = heff_field(v_x2_24276, 0);
    V v_s_24278 = heff_field(v_x2_24276, 1);
    V v_ru_24x2_24276_24MkPair = heff_take_reuse_n(v_x2_24276, 3ULL, 2);
    V v_t_24279 = heff_strAppend(v_x_24273, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str65), heff_strAppend(v_x_24277, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str66))));
    V v_t_24280 = heff_tag_at_n(v_ru_24x2_24276_24MkPair, TAG_Cons, 2, (V[]){v_t_24279, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24280, v_s_24278});
  }
  default: return heff_nomatch(v_x2_24276);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam23(V self, V *args) {
  V v_s_24283 = args[0];
  V v_m_24282 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24284 = heff_tr(heff_apply(v_m_24282, 1, (V[]){v_s_24283}));
  switch (heff_tag_of(v_x2_24284)) {
  case TAG_MkPair: {
    V v_x_24285 = heff_field(v_x2_24284, 0);
    V v_s_24286 = heff_field(v_x2_24284, 1);
    V v_ru_24x2_24284_24MkPair = heff_take_reuse_n(v_x2_24284, 3ULL, 2);
    V v_t_24287 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str67), heff_strAppend(v_x_24285, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str68)));
    V v_t_24288 = heff_tag_at_n(v_ru_24x2_24284_24MkPair, TAG_Cons, 2, (V[]){v_t_24287, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24288, v_s_24286});
  }
  default: return heff_nomatch(v_x2_24284);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam24(V self, V *args) {
  V v_s_24291 = args[0];
  V v_m_24290 = heff_env(self)[0];
  V v_x_24289 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24292 = heff_tr(heff_apply(v_m_24290, 1, (V[]){v_s_24291}));
  switch (heff_tag_of(v_x2_24292)) {
  case TAG_MkPair: {
    V v_x_24293 = heff_field(v_x2_24292, 0);
    V v_s_24294 = heff_field(v_x2_24292, 1);
    V v_ru_24x2_24292_24MkPair = heff_take_reuse_n(v_x2_24292, 3ULL, 2);
    V v_t_24295 = heff_strAppend(v_x_24289, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str69), heff_strAppend(v_x_24293, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str70))));
    V v_t_24296 = heff_tag_at_n(v_ru_24x2_24292_24MkPair, TAG_Cons, 2, (V[]){v_t_24295, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24296, v_s_24294});
  }
  default: return heff_nomatch(v_x2_24292);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam25(V self, V *args) {
  V v_s_24299 = args[0];
  V v_m_24298 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24300 = heff_tr(heff_apply(v_m_24298, 1, (V[]){v_s_24299}));
  switch (heff_tag_of(v_x2_24300)) {
  case TAG_MkPair: {
    V v_x_24301 = heff_field(v_x2_24300, 0);
    V v_s_24302 = heff_field(v_x2_24300, 1);
    V v_ru_24x2_24300_24MkPair = heff_take_reuse_n(v_x2_24300, 3ULL, 2);
    V v_t_24303 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str71), heff_strAppend(v_x_24301, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str72)));
    V v_t_24304 = heff_tag_at_n(v_ru_24x2_24300_24MkPair, TAG_Cons, 2, (V[]){v_t_24303, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24304, v_s_24302});
  }
  default: return heff_nomatch(v_x2_24300);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam26(V self, V *args) {
  V v_s_24307 = args[0];
  V v_m_24306 = heff_env(self)[0];
  V v_x_24305 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24308 = heff_tr(heff_apply(v_m_24306, 1, (V[]){v_s_24307}));
  switch (heff_tag_of(v_x2_24308)) {
  case TAG_MkPair: {
    V v_x_24309 = heff_field(v_x2_24308, 0);
    V v_s_24310 = heff_field(v_x2_24308, 1);
    V v_ru_24x2_24308_24MkPair = heff_take_reuse_n(v_x2_24308, 3ULL, 2);
    V v_t_24311 = heff_strAppend(v_x_24305, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str73), heff_strAppend(v_x_24309, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str74))));
    V v_t_24312 = heff_tag_at_n(v_ru_24x2_24308_24MkPair, TAG_Cons, 2, (V[]){v_t_24311, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24312, v_s_24310});
  }
  default: return heff_nomatch(v_x2_24308);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam27(V self, V *args) {
  V v_s_24316 = args[0];
  V v_m_24315 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24317 = heff_tr(heff_apply(v_m_24315, 1, (V[]){v_s_24316}));
  switch (heff_tag_of(v_x2_24317)) {
  case TAG_MkPair: {
    V v_x_24318 = heff_field(v_x2_24317, 0);
    V v_s_24319 = heff_field(v_x2_24317, 1);
    V v_ru_24x2_24317_24MkPair = heff_take_reuse_n(v_x2_24317, 3ULL, 2);
    V v_t_24320 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str75), heff_strAppend(v_x_24318, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str76)));
    V v_t_24321 = heff_tag_at_n(v_ru_24x2_24317_24MkPair, TAG_Cons, 2, (V[]){v_t_24320, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24321, v_s_24319});
  }
  default: return heff_nomatch(v_x2_24317);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam28(V self, V *args) {
  V v_s_24324 = args[0];
  V v_m_24323 = heff_env(self)[0];
  V v_x_24322 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24325 = heff_tr(heff_apply(v_m_24323, 1, (V[]){v_s_24324}));
  switch (heff_tag_of(v_x2_24325)) {
  case TAG_MkPair: {
    V v_x_24326 = heff_field(v_x2_24325, 0);
    V v_s_24327 = heff_field(v_x2_24325, 1);
    V v_ru_24x2_24325_24MkPair = heff_take_reuse_n(v_x2_24325, 3ULL, 2);
    V v_t_24328 = heff_strAppend(v_x_24322, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str77), heff_strAppend(v_x_24326, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str78))));
    V v_t_24329 = heff_tag_at_n(v_ru_24x2_24325_24MkPair, TAG_Cons, 2, (V[]){v_t_24328, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24329, v_s_24327});
  }
  default: return heff_nomatch(v_x2_24325);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam29(V self, V *args) {
  V v_s_24332 = args[0];
  V v_m_24331 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24333 = heff_tr(heff_apply(v_m_24331, 1, (V[]){v_s_24332}));
  switch (heff_tag_of(v_x2_24333)) {
  case TAG_MkPair: {
    V v_x_24334 = heff_field(v_x2_24333, 0);
    V v_s_24335 = heff_field(v_x2_24333, 1);
    V v_ru_24x2_24333_24MkPair = heff_take_reuse_n(v_x2_24333, 3ULL, 2);
    V v_t_24336 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str79), heff_strAppend(v_x_24334, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str80)));
    V v_t_24337 = heff_tag_at_n(v_ru_24x2_24333_24MkPair, TAG_Cons, 2, (V[]){v_t_24336, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24337, v_s_24335});
  }
  default: return heff_nomatch(v_x2_24333);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam30(V self, V *args) {
  V v_s_24340 = args[0];
  V v_m_24339 = heff_env(self)[0];
  V v_x_24338 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24341 = heff_tr(heff_apply(v_m_24339, 1, (V[]){v_s_24340}));
  switch (heff_tag_of(v_x2_24341)) {
  case TAG_MkPair: {
    V v_x_24342 = heff_field(v_x2_24341, 0);
    V v_s_24343 = heff_field(v_x2_24341, 1);
    V v_ru_24x2_24341_24MkPair = heff_take_reuse_n(v_x2_24341, 3ULL, 2);
    V v_t_24344 = heff_strAppend(v_x_24338, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str81), heff_strAppend(v_x_24342, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str82))));
    V v_t_24345 = heff_tag_at_n(v_ru_24x2_24341_24MkPair, TAG_Cons, 2, (V[]){v_t_24344, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24345, v_s_24343});
  }
  default: return heff_nomatch(v_x2_24341);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam31(V self, V *args) {
  V v_s_24347 = args[0];
  V v_m_24346 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24348 = heff_tr(heff_apply(v_m_24346, 1, (V[]){v_s_24347}));
  switch (heff_tag_of(v_x2_24348)) {
  case TAG_MkPair: {
    V v_x_24349 = heff_field(v_x2_24348, 0);
    V v_s_24350 = heff_field(v_x2_24348, 1);
    V v_ru_24x2_24348_24MkPair = heff_take_reuse_n(v_x2_24348, 3ULL, 2);
    V v_t_24351 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str83), heff_strAppend(v_x_24349, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str84)));
    V v_t_24352 = heff_tag_at_n(v_ru_24x2_24348_24MkPair, TAG_Cons, 2, (V[]){v_t_24351, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24352, v_s_24350});
  }
  default: return heff_nomatch(v_x2_24348);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam32(V self, V *args) {
  V v_s_24355 = args[0];
  V v_m_24354 = heff_env(self)[0];
  V v_x_24353 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24356 = heff_tr(heff_apply(v_m_24354, 1, (V[]){v_s_24355}));
  switch (heff_tag_of(v_x2_24356)) {
  case TAG_MkPair: {
    V v_x_24357 = heff_field(v_x2_24356, 0);
    V v_s_24358 = heff_field(v_x2_24356, 1);
    V v_ru_24x2_24356_24MkPair = heff_take_reuse_n(v_x2_24356, 3ULL, 2);
    V v_t_24359 = heff_strAppend(v_x_24353, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str85), heff_strAppend(v_x_24357, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str86))));
    V v_t_24360 = heff_tag_at_n(v_ru_24x2_24356_24MkPair, TAG_Cons, 2, (V[]){v_t_24359, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24360, v_s_24358});
  }
  default: return heff_nomatch(v_x2_24356);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam33(V self, V *args) {
  V v_s_24364 = args[0];
  V v_m_24363 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24365 = heff_tr(heff_apply(v_m_24363, 1, (V[]){v_s_24364}));
  switch (heff_tag_of(v_x2_24365)) {
  case TAG_MkPair: {
    V v_x_24366 = heff_field(v_x2_24365, 0);
    V v_s_24367 = heff_field(v_x2_24365, 1);
    V v_ru_24x2_24365_24MkPair = heff_take_reuse_n(v_x2_24365, 3ULL, 2);
    V v_t_24368 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str87), heff_strAppend(v_x_24366, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str88)));
    V v_t_24369 = heff_tag_at_n(v_ru_24x2_24365_24MkPair, TAG_Cons, 2, (V[]){v_t_24368, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24369, v_s_24367});
  }
  default: return heff_nomatch(v_x2_24365);
  }
}
V g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_lam34(V self, V *args) {
  V v_s_24372 = args[0];
  V v_m_24371 = heff_env(self)[0];
  V v_x_24370 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24373 = heff_tr(heff_apply(v_m_24371, 1, (V[]){v_s_24372}));
  switch (heff_tag_of(v_x2_24373)) {
  case TAG_MkPair: {
    V v_x_24374 = heff_field(v_x2_24373, 0);
    V v_s_24375 = heff_field(v_x2_24373, 1);
    V v_ru_24x2_24373_24MkPair = heff_take_reuse_n(v_x2_24373, 3ULL, 2);
    V v_t_24376 = heff_strAppend(v_x_24370, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str89), heff_strAppend(v_x_24374, ((V)&g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499_str90))));
    V v_t_24377 = heff_tag_at_n(v_ru_24x2_24373_24MkPair, TAG_Cons, 2, (V[]){v_t_24376, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24377, v_s_24375});
  }
  default: return heff_nomatch(v_x2_24373);
  }
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str0, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str2, 4, (118, 111, 105, 100));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str3, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str4, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str5, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str6, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str7, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str8, 9, (115, 116, 97, 116, 105, 99, 32, 86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str9, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str10, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str11, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str12, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str13, 9, (115, 116, 97, 116, 105, 99, 32, 86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str14, 21, (95, 101, 110, 116, 114, 121, 40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str15, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str16, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str17, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str18, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str19, 11, (115, 116, 97, 116, 105, 99, 32, 67, 108, 111, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str20, 33, (95, 99, 108, 111, 32, 61, 32, 123, 123, 48, 120, 56, 48, 48, 48, 48, 48, 48, 48, 117, 44, 32, 75, 95, 67, 76, 79, 44, 32, 48, 125, 44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str21, 8, (95, 101, 110, 116, 114, 121, 44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str22, 5, (44, 32, 48, 125, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str23, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str24, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str25, 4, (118, 111, 105, 100));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str26, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str27, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str28, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str29, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str30, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str31, 9, (115, 116, 97, 116, 105, 99, 32, 86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str32, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str33, 3, (41, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str34, 6, (116, 111, 112, 58, 32, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str35, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str36, 10, (104, 101, 102, 102, 95, 100, 114, 111, 112, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str37, 2, (118, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str38, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str39, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str40, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str41, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str42, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str43, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str44, 9, (115, 116, 97, 116, 105, 99, 32, 86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str45, 22, (95, 101, 110, 116, 114, 121, 40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 41, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str46, 1, (125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str47, 13, (32, 32, 40, 118, 111, 105, 100, 41, 115, 101, 108, 102, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2efunDef_str48, 1, (125));
V g_heff_2ecompile_2eemitc_2efunDef_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2efunDef_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2efunDef_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2efunDef_lam2(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2efunDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efunDef_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2efunDef(V v_ce_240, V v_d_241, V v_xs_242, V v_b_243) {
top: ;
  V v_x2_244 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), heff_rfield(v_ce_240, 9)));
  V v_t_246;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x2_244, 0);
    heff_take_n(v_x2_244, 1ULL, 1);
    v_t_246 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_owned_247 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_246; V a_2 = heff_dup(v_xs_242); V r_ = (g_heff_2ecompile_2eemitc_2eparamsAt(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_246); r_; });
  V v_wanted_248 = (g_heff_2ecompile_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_b_243)));
  V v_owned_2410 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2efunDef_lam0, 1, 1, (V[]){v_wanted_248}), v_owned_247));
  V v_x2_2411 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), heff_rfield(v_ce_240, 9)));
  V v_bi_2413;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nothing: {
    v_bi_2413 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    heff_take_n(v_x2_2411, 1ULL, 1);
    v_bi_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  V v_t_2414 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_242));
  V v_t_2415 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2414, MK_INT(1LL))));
  V v_t_2416 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_242), v_t_2415));
  V v_t_2421 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2efunDef_lam1, 1, 1, (V[]){v_bi_2413}), v_t_2416));
  V v_bs_2422 = (g_list_2emap_24s1937570095x2110149801(v_t_2421));
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
  V v_t_2424 = (g_heff_2ecompile_2eemitc_2eshapedGo(NTAG(TAG_Nil), v_t_2423));
  V v_ce_2425 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_t_2424; V r_ = (g_list_2efoldl_24s321107625x1130584089(a_0, a_1)); heff_drop(v_t_2424); r_; });
  V v_t_2426 = heff_rec_n(2, shape_key__params, (V[]){heff_dup(heff_rfield(v_d_241, 0)), heff_dup(v_xs_242)});
  V v_ce_2427 = ({ V rv_4 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2426}); V rv_5 = MK_INT(0LL); V rv_11 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_n(v_ce_2425, 1999ULL, 12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes); heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 11) = rv_11; rr_; });
  V v_ce_2428 = ({ V rv_8 = v_bs_2422; V rr_ = heff_rec_reuse_n(v_ce_2427, 3839ULL, 12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes); heff_rfield(rr_, 8) = rv_8; rr_; });
  V v_ce_2429 = ({ V rv_6 = v_owned_2410; V rv_7 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_n(v_ce_2428, 3903ULL, 12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes); heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
  V v_m_2430 = (g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499(v_ce_2429, NTAG(TAG_Ret), heff_dup(v_b_243)));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2efunDef_lam2, 1, 5, (V[]){v_m_2430, v_d_241, v_xs_242, v_ce_240, v_b_243});
}
V g_heff_2ecompile_2eemitc_2efunDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2efunDef(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eemitc_2efunDef_lam0(V self, V *args) {
  V v_v_249 = args[0];
  V v_wanted_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_249; V a_1 = v_wanted_248; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_248); r_; });
}
V g_heff_2ecompile_2eemitc_2efunDef_lam1(V self, V *args) {
  V v_p_2417 = args[0];
  V v_bi_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420;
  switch (heff_tag_of(v_p_2417)) {
  case TAG_MkPair: {
    V v_y_2419 = heff_field(v_p_2417, 1);
    heff_take_n(v_p_2417, 2ULL, 2);
    v_t_2420 = v_y_2419;
    break;
  }
  default: heff_nomatch(v_p_2417);
  }
  return ({ V a_0 = v_t_2420; V a_1 = v_bi_2413; V r_ = (g_heff_2ecompile_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_2413); r_; });
}
V g_heff_2ecompile_2eemitc_2efunDef_lam3(V self, V *args) {
  V v_v_2466 = args[0];
  V v_wanted_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2467 = ({ V a_0 = v_v_2466; V a_1 = v_wanted_2465; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2465); r_; });
  switch (heff_tag_of(v_x1_2467)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2467);
  }
}
V g_heff_2ecompile_2eemitc_2efunDef_lam2(V self, V *args) {
  V v_s_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  V v_xs_242 = heff_env(self)[2];
  V v_ce_240 = heff_env(self)[3];
  V v_b_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2432 = heff_tr(heff_apply(v_m_2430, 1, (V[]){v_s_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_s_2434 = heff_field(v_x2_2432, 1);
    V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 3ULL, 2);
    V v_t_2435 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str0), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str1))));
    V v_t_2441;
    switch (heff_tag_of(v_xs_242)) {
    case TAG_Nil: {
      v_t_2441 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_str2);
      break;
    }
    case TAG_Cons: {
      V v_x2_2438 = (g_list_2emap_24s617071700x1606310602(((V)&g_heff_2ecompile_2eemitc_2efunDef_str3), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str4), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str5), heff_dup(v_xs_242)));
      switch (heff_tag_of(v_x2_2438)) {
      case TAG_Nil: {
        v_t_2441 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_str6);
        break;
      }
      case TAG_Cons: {
        V v_x_2439 = heff_field(v_x2_2438, 0);
        V v_xs_2440 = heff_field(v_x2_2438, 1);
        heff_take_n(v_x2_2438, 3ULL, 2);
        v_t_2441 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_str7); V a_1 = v_x_2439; V a_2 = v_xs_2440; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2440); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2438);
      }
      break;
    }
    default: heff_nomatch(v_xs_242);
    }
    V v_t_2442 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str8), heff_strAppend(v_t_2435, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str9), heff_strAppend(v_t_2441, ((V)&g_heff_2ecompile_2eemitc_2efunDef_str10)))));
    V v_t_2443 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str11), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str12))));
    V v_t_2444 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str13), heff_strAppend(v_t_2443, ((V)&g_heff_2ecompile_2eemitc_2efunDef_str14)));
    V v_t_2445 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str15), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str16))));
    V v_t_2446 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str17), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str18))));
    V v_t_2447 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_242));
    V v_t_2448 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str19), heff_strAppend(v_t_2445, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str20), heff_strAppend(v_t_2446, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str21), heff_strAppend(heff_intShow(v_t_2447), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str22)))))));
    V v_t_2449 = heff_tag_at_n(v_ru_24x2_2432_24MkPair, TAG_Cons, 2, (V[]){v_t_2448, NTAG(TAG_Nil)});
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2444, v_t_2449})});
    V v_t_2451 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str23), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str24))));
    V v_t_2457;
    switch (heff_tag_of(v_xs_242)) {
    case TAG_Nil: {
      v_t_2457 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_str25);
      break;
    }
    case TAG_Cons: {
      V v_x2_2454 = (g_list_2emap_24s617071700x1606310602(((V)&g_heff_2ecompile_2eemitc_2efunDef_str26), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str27), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str28), heff_dup(v_xs_242)));
      switch (heff_tag_of(v_x2_2454)) {
      case TAG_Nil: {
        v_t_2457 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_str29);
        break;
      }
      case TAG_Cons: {
        V v_x_2455 = heff_field(v_x2_2454, 0);
        V v_xs_2456 = heff_field(v_x2_2454, 1);
        heff_take_n(v_x2_2454, 3ULL, 2);
        v_t_2457 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_str30); V a_1 = v_x_2455; V a_2 = v_xs_2456; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2456); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2454);
      }
      break;
    }
    default: heff_nomatch(v_xs_242);
    }
    V v_t_2458 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str31), heff_strAppend(v_t_2451, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str32), heff_strAppend(v_t_2457, ((V)&g_heff_2ecompile_2eemitc_2efunDef_str33)))));
    V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str34), NTAG(TAG_Nil)});
    V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str35), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, v_t_2459})});
    V v_x2_2461 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), heff_rfield(v_ce_240, 9)));
    V v_t_2463;
    switch (heff_tag_of(v_x2_2461)) {
    case TAG_Nothing: {
      v_t_2463 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2462 = heff_field(v_x2_2461, 0);
      heff_take_n(v_x2_2461, 1ULL, 1);
      v_t_2463 = v_x_2462;
      break;
    }
    default: heff_nomatch(v_x2_2461);
    }
    V v_owned_2464 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_2463; V a_2 = heff_dup(v_xs_242); V r_ = (g_heff_2ecompile_2eemitc_2eparamsAt(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2463); r_; });
    V v_wanted_2465 = (g_heff_2ecompile_2eemitc_2efreeOf(NTAG(TAG_Nil), v_b_243));
    V v_xs_2468 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2efunDef_lam3, 1, 1, (V[]){v_wanted_2465}), v_owned_2464));
    V v_t_2469 = (g_list_2emap_24s1196049889x1646679775(((V)&g_heff_2ecompile_2eemitc_2efunDef_str36), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str37), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str38), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str39), v_xs_2468));
    V v_t_2470 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2ecompile_2eemitc_2efunDef_str40), v_t_2469));
    V v_t_2471 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2ecompile_2eemitc_2efunDef_str41), v_x_2433));
    V v_t_2472 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str42), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str43))));
    V v_t_2473 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str44), heff_strAppend(v_t_2472, ((V)&g_heff_2ecompile_2eemitc_2efunDef_str45)));
    V v_x2_2474 = ({ V a_0 = heff_dup(heff_rfield(v_d_241, 0)); V b_1 = heff_get_n(v_ce_240, 9, 12); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2476;
    switch (heff_tag_of(v_x2_2474)) {
    case TAG_Nothing: {
      v_t_2476 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2475 = heff_field(v_x2_2474, 0);
      heff_take_n(v_x2_2474, 1ULL, 1);
      v_t_2476 = v_x_2475;
      break;
    }
    default: heff_nomatch(v_x2_2474);
    }
    V v_t_2477 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_242; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_242); r_; });
    V v_t_2478 = (g_heff_2ecompile_2eemitc_2eentryCall(heff_get_n(v_d_241, 0, 3), v_t_2476, v_t_2477));
    V v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str46), NTAG(TAG_Nil)});
    V v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str47), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2478, v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str48), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2473, v_t_2480})});
    V v_t_2482 = (g_prelude_2e_2b_2b(v_t_2471, v_t_2481));
    V v_t_2483 = (g_prelude_2e_2b_2b(v_t_2470, v_t_2482));
    V v_t_2484 = (g_prelude_2e_2b_2b(v_t_2460, v_t_2483));
    V v_x_2485 = heff_rec_n(2, shape_protos__code, (V[]){v_t_2450, v_t_2484});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2485, v_s_2434});
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str0, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str2, 9, (115, 116, 97, 116, 105, 99, 32, 86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str3, 11, (95, 103, 101, 116, 40, 118, 111, 105, 100, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str4, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str5, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str6, 9, (115, 116, 97, 116, 105, 99, 32, 86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str7, 5, (95, 118, 97, 108, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str8, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str9, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str10, 11, (115, 116, 97, 116, 105, 99, 32, 105, 110, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str11, 4, (95, 115, 116, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str12, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str13, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str14, 9, (115, 116, 97, 116, 105, 99, 32, 86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str15, 13, (95, 105, 110, 105, 116, 40, 118, 111, 105, 100, 41, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str16, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str17, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str18, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str19, 9, (115, 116, 97, 116, 105, 99, 32, 86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str20, 12, (95, 103, 101, 116, 40, 118, 111, 105, 100, 41, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str21, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str22, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str23, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str24, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str25, 6, (32, 32, 105, 102, 32, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str26, 17, (95, 115, 116, 32, 61, 61, 32, 50, 41, 32, 114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str27, 5, (95, 118, 97, 108, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str28, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str29, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str30, 6, (32, 32, 105, 102, 32, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str31, 41, (95, 115, 116, 32, 61, 61, 32, 49, 41, 32, 104, 101, 102, 102, 95, 102, 97, 105, 108, 40, 34, 100, 101, 102, 105, 110, 101, 100, 32, 98, 121, 32, 105, 116, 115, 101, 108, 102, 34, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str32, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str33, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str34, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str35, 8, (95, 115, 116, 32, 61, 32, 49, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str36, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str37, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str38, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str39, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str40, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str41, 15, (95, 118, 97, 108, 32, 61, 32, 104, 101, 102, 102, 95, 116, 114, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str42, 9, (95, 105, 110, 105, 116, 40, 41, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str43, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str44, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str45, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str46, 8, (95, 115, 116, 32, 61, 32, 50, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str47, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str48, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str49, 9, (32, 32, 114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str50, 5, (95, 118, 97, 108, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str51, 1, (125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str52, 1, (125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2evalDef_str53, 0, (0));
V g_heff_2ecompile_2eemitc_2evalDef_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2evalDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2evalDef_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2evalDef(V v_ce_240, V v_d_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_d_241, 2)), NTAG(TAG_Nil)});
  V v_t_243 = (g_heff_2ecompile_2eemitc_2eshapedGo(NTAG(TAG_Nil), v_t_242));
  V v_ce_244 = ({ V a_0 = v_ce_240; V a_1 = v_t_243; V r_ = (g_list_2efoldl_24s321107625x1130584089(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_ce_245 = ({ V rv_4 = NTAG(TAG_Nothing); V rv_5 = MK_INT(0LL); V rv_11 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_n(v_ce_244, 1999ULL, 12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes); heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 11) = rv_11; rr_; });
  V v_ce_246 = ({ V rv_6 = NTAG(TAG_Nil); V rv_7 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_n(v_ce_245, 3903ULL, 12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes); heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
  V v_m_247 = (g_heff_2ecompile_2eemitc_2estmtsF_24s2100294302x1706015499(v_ce_246, NTAG(TAG_Ret), heff_dup(heff_rfield(v_d_241, 2))));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2evalDef_lam0, 1, 2, (V[]){v_m_247, v_d_241});
}
V g_heff_2ecompile_2eemitc_2evalDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2evalDef(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2evalDef_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_249 = heff_tr(heff_apply(v_m_247, 1, (V[]){v_s_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str0), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str1))));
    V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str2), heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemitc_2evalDef_str3)));
    V v_t_2414 = heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
    V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str4), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str5))));
    V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str6), heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemitc_2evalDef_str7)));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str8), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str9))));
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str10), heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemitc_2evalDef_str11)));
    V v_t_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str12), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str13))));
    V v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str14), heff_strAppend(v_t_2419, ((V)&g_heff_2ecompile_2eemitc_2evalDef_str15)));
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2421})});
    V v_t_2423 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2ecompile_2eemitc_2evalDef_str16), v_x_2410));
    V v_t_2424 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str17), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str18))));
    V v_t_2425 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str19), heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemitc_2evalDef_str20)));
    V v_t_2426 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str21), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str22))));
    V v_t_2427 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str23), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str24))));
    V v_t_2428 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str25), heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str26), heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eemitc_2evalDef_str27)))));
    V v_t_2429 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str28), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str29))));
    V v_t_2430 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str30), heff_strAppend(v_t_2429, ((V)&g_heff_2ecompile_2eemitc_2evalDef_str31)));
    V v_t_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str32), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str33))));
    V v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str34), heff_strAppend(v_t_2431, ((V)&g_heff_2ecompile_2eemitc_2evalDef_str35)));
    V v_t_2433 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str36), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str37))));
    V v_t_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str38), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str39))));
    V v_t_2435 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str40), heff_strAppend(v_t_2433, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str41), heff_strAppend(v_t_2434, ((V)&g_heff_2ecompile_2eemitc_2evalDef_str42)))));
    V v_t_2436 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str43), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str44))));
    V v_t_2437 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str45), heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2eemitc_2evalDef_str46)));
    V v_t_2438 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str47), (g_heff_2ecompile_2eemitc_2emangleW(heff_get_n(v_d_241, 0, 3), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str48))));
    V v_t_2439 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str49), heff_strAppend(v_t_2438, ((V)&g_heff_2ecompile_2eemitc_2evalDef_str50)));
    V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2evalDef_str51), NTAG(TAG_Nil)});
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2evalDef_str52), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, v_t_2443})});
    V v_t_2445 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2444));
    V v_t_2446 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2evalDef_str53), v_t_2422}), v_t_2445));
    V v_x_2447 = heff_rec_n(2, shape_protos__code, (V[]){v_t_2414, v_t_2446});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2447, v_s_2411});
  }
  default: return heff_nomatch(v_x2_249);
  }
}
Clo g_heff_2ecompile_2eemitc_2edefC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2edefC_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2edefC(V v_ce_240, V v_d_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_d_241, 2));
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    V v_b_246 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 3ULL, 2);
    return (g_heff_2ecompile_2eemitc_2efunDef(v_ce_240, v_d_241, v_xs_245, v_b_246));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 3);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EFloat: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EFloat32: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2ecompile_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eemitc_2edefC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2edefC(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2eplusDone_str0, 22, (115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eplusDone_str1, 120, (40, 86, 32, 112, 44, 32, 86, 32, 107, 41, 32, 123, 32, 105, 110, 116, 32, 108, 32, 61, 32, 104, 101, 102, 102, 95, 116, 97, 103, 95, 111, 102, 40, 112, 41, 32, 61, 61, 32, 84, 65, 71, 95, 73, 110, 76, 59, 32, 86, 32, 113, 32, 61, 32, 104, 101, 102, 102, 95, 100, 117, 112, 40, 104, 101, 102, 102, 95, 102, 105, 101, 108, 100, 40, 112, 44, 32, 48, 41, 41, 59, 32, 104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 112, 41, 59, 32, 114, 101, 116, 117, 114, 110, 32, 108, 32, 63, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eplusDone_str2, 22, (40, 113, 44, 32, 107, 41, 32, 58, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eplusDone_str3, 9, (40, 113, 44, 32, 107, 41, 59, 32, 125));
Clo g_heff_2ecompile_2eemitc_2eplusDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eplusDone_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eplusDone(V v_n_240, V v_la_241, V v_na_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_lb_244 = heff_field(v_x4_243, 0);
    V v_nb_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_intShow(heff_intAdd(heff_dup(v_n_240), MK_INT(1LL)));
    V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eplusDone_str0), heff_strAppend(heff_intShow(v_n_240), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eplusDone_str1), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eplusDone_str2), heff_strAppend(heff_intShow(v_na_242), ((V)&g_heff_2ecompile_2eemitc_2eplusDone_str3)))))));
    V v_t_248 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    V v_t_249 = (g_prelude_2e_2b_2b(v_lb_244, v_t_248));
    V v_t_2410 = (g_prelude_2e_2b_2b(v_la_241, v_t_249));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_nb_245});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2eplusDone_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eplusDone(a[0], a[1], a[2], a[3]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2eperformNodes_str0, 1, (46));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eperformNodes_str1, 22, (115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eperformNodes_str2, 34, (40, 86, 32, 112, 44, 32, 86, 32, 107, 41, 32, 123, 32, 114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 112, 114, 111, 118, 105, 100, 101, 114, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eperformNodes_str3, 9, (40, 112, 44, 32, 107, 41, 59, 32, 125));
Clo g_heff_2ecompile_2eemitc_2eperformNodes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eperformNodes_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eperformNodes(V v_x1_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Leaf: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_t_243 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemitc_2eperformNodes_str0), heff_dup(v_k_242), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_244 = ({ V a_0 = heff_dup(v_k_242); V a_1 = v_t_243; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_243); r_; });
    V v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eperformNodes_str1), heff_strAppend(heff_intShow(heff_dup(v_n_241)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eperformNodes_str2), heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2eperformNodes_str3)))));
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, heff_intAdd(v_n_241, MK_INT(1LL))});
  }
  case TAG_Plus: {
    V v_a_247 = heff_field(v_x1_240, 0);
    V v_b_248 = heff_field(v_x1_240, 1);
    V v_x4_249 = (g_heff_2ecompile_2eemitc_2eperformNodes(v_a_247, heff_intAdd(heff_dup(v_n_241), MK_INT(1LL))));
    switch (heff_tag_of(v_x4_249)) {
    case TAG_MkPair: {
      V v_la_2410 = heff_field(v_x4_249, 0);
      V v_na_2411 = heff_field(v_x4_249, 1);
      heff_take_n(v_x4_249, 3ULL, 2);
      V v_t_2412 = (g_heff_2ecompile_2eemitc_2eperformNodes(v_b_248, heff_dup(v_na_2411)));
      return (g_heff_2ecompile_2eemitc_2eplusDone(v_n_241, v_la_2410, v_na_2411, v_t_2412));
    }
    default: return heff_nomatch(v_x4_249);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2eperformNodes_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2eperformNodes(a[0], a[1]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprimCloDef_str0, 2, (97, 91));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprimCloDef_str1, 1, (93));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprimCloDef_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprimCloDef_str3, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprimCloDef_str4, 14, (115, 116, 97, 116, 105, 99, 32, 86, 32, 112, 114, 105, 109, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprimCloDef_str5, 42, (95, 101, 110, 116, 114, 121, 40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 41, 32, 123, 32, 40, 118, 111, 105, 100, 41, 115, 101, 108, 102, 59, 32, 114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprimCloDef_str6, 5, (104, 101, 102, 102, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprimCloDef_str7, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprimCloDef_str8, 4, (41, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprimCloDef_str9, 16, (115, 116, 97, 116, 105, 99, 32, 67, 108, 111, 32, 112, 114, 105, 109, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprimCloDef_str10, 38, (95, 99, 108, 111, 32, 61, 32, 123, 123, 48, 120, 56, 48, 48, 48, 48, 48, 48, 48, 117, 44, 32, 75, 95, 67, 76, 79, 44, 32, 48, 125, 44, 32, 112, 114, 105, 109, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprimCloDef_str11, 8, (95, 101, 110, 116, 114, 121, 44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprimCloDef_str12, 5, (44, 32, 48, 125, 59));
Clo g_heff_2ecompile_2eemitc_2eprimCloDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprimCloDef_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eprimCloDef(V v_p_240) {
top: ;
  V v_t_241 = ({ V a_0 = heff_dup(v_p_240); V b_1 = heff_dup(g_heff_2ecompile_2eprims_2eallPrims_get()); V r_ = (g_heff_2ecompile_2eprims_2eprimArityGo(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nothing: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_n_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_t_243 = (g_list_2erange(MK_INT(0LL), heff_intSub(heff_dup(v_n_242), MK_INT(1LL))));
    V v_x2_244 = (g_list_2emap_24s1006477676x1816442814(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str0), ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str1), v_t_243));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str3); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str4), heff_strAppend(heff_dup(v_p_240), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str5), heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str6), heff_dup(v_p_240)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str7), heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str8)))))));
    V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str9), heff_strAppend(heff_dup(v_p_240), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str10), heff_strAppend(v_p_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str11), heff_strAppend(heff_intShow(v_n_242), ((V)&g_heff_2ecompile_2eemitc_2eprimCloDef_str12)))))));
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2410});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2eemitc_2eprimCloDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eprimCloDef(a[0]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2eshapeDef_str0, 2, (95, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eshapeDef_str1, 4, (76, 66, 76, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eshapeDef_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eshapeDef_str3, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eshapeDef_str4, 22, (115, 116, 97, 116, 105, 99, 32, 117, 105, 110, 116, 51, 50, 95, 116, 32, 115, 104, 97, 112, 101, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eshapeDef_str5, 6, (91, 93, 32, 61, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eshapeDef_str6, 2, (125, 59));
Clo g_heff_2ecompile_2eemitc_2eshapeDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eshapeDef_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eshapeDef(V v_key_240) {
top: ;
  V v_t_241 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str0), heff_dup(v_key_240), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_242 = (g_list_2efilter_24s2056490818x625949248(MK_INT(0LL), v_t_241));
  V v_x2_243 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str1), v_t_242));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str3); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str4), heff_strAppend(v_key_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str5), heff_strAppend(v_t_246, ((V)&g_heff_2ecompile_2eemitc_2eshapeDef_str6)))));
}
V g_heff_2ecompile_2eemitc_2eshapeDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eshapeDef(a[0]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2edefOwn_str0, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edefOwn_str1, 0, (0));
V g_heff_2ecompile_2eemitc_2edefOwn_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2edefOwn_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2edefOwn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2edefOwn_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2edefOwn(V v_ce_240, V v_d_241) {
top: ;
  V v_o_242 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edefOwn_str0), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edefOwn_str1))));
  V v_m_245 = heff_clo_n(g_heff_2ecompile_2eemitc_2edefOwn_lam0, 1, 1, (V[]){v_o_242});
  return heff_clo_n(g_heff_2ecompile_2eemitc_2edefOwn_lam1, 1, 3, (V[]){v_m_245, v_d_241, v_ce_240});
}
V g_heff_2ecompile_2eemitc_2edefOwn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2edefOwn(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2edefOwn_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_o_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = ({ V rv_0 = v_o_242; V rv_1 = MK_INT(0LL); V rv_4 = MK_INT(0LL); V rr_ = heff_rec_reuse_n(v_s_243, 236ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 4) = rv_4; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_244});
}
V g_heff_2ecompile_2eemitc_2edefOwn_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  V v_ce_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_apply(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_s_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 2ULL, 2);
    V v_x1_2410 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(g_map_2eempty_get()), MK_INT(0LL), heff_take_field(v_d_241, 2)));
    V v_body_2413;
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x1_2410, 0);
      heff_take_n(v_x1_2410, 1ULL, 2);
      v_body_2413 = v_x_2411;
      break;
    }
    default: heff_nomatch(v_x1_2410);
    }
    V v_t_2414 = ({ V rv_2 = v_body_2413; V rr_ = heff_rec_reuse_n(v_d_241, 3ULL, 3, shape_key__name__body); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2415 = (g_heff_2ecompile_2eemitc_2edefC(v_ce_240, v_t_2414));
    V f_ = v_t_2415;
    args[0] = v_s_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_247);
  }
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2eemptyCS_str0, 0, (0));

static V g_heff_2ecompile_2eemitc_2eemptyCS_val;
static int g_heff_2ecompile_2eemitc_2eemptyCS_st;
static V g_heff_2ecompile_2eemitc_2eemptyCS_init(void) {
  return heff_rec_n(8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, (V[]){((V)&g_heff_2ecompile_2eemitc_2eemptyCS_str0), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void) {
  if (g_heff_2ecompile_2eemitc_2eemptyCS_st == 2) return g_heff_2ecompile_2eemitc_2eemptyCS_val;
  if (g_heff_2ecompile_2eemitc_2eemptyCS_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eemitc_2eemptyCS_st = 1;
  g_heff_2ecompile_2eemitc_2eemptyCS_val = heff_tr(g_heff_2ecompile_2eemitc_2eemptyCS_init());
  g_heff_2ecompile_2eemitc_2eemptyCS_st = 2;
  return g_heff_2ecompile_2eemitc_2eemptyCS_val;
}
Clo g_heff_2ecompile_2eemitc_2earityOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2earityOne_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2earityOne(V v_m_240, V v_d_241) {
top: ;
  V v_t_242 = heff_take_field(v_d_241, 2);
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_245; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    return (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_d_241, 0, 3), v_t_247, v_m_240));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat32: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eemitc_2earityOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2earityOne(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemitc_2eonceInOrder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eonceInOrder_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eonceInOrder(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_242), v_seen_240));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      V v_t_245 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_242), NTAG(TAG_MkUnit), v_seen_240));
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2ecompile_2eemitc_2eonceInOrder(v_t_245, v_xs_243))});
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_seen_240;
      V t_1 = v_xs_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eonceInOrder_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eonceInOrder(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2enamesTable_str0, 1, (123));
HEFF_STRA(g_heff_2ecompile_2eemitc_2enamesTable_str1, 3, (44, 32, 34));
HEFF_STRA(g_heff_2ecompile_2eemitc_2enamesTable_str2, 2, (34, 125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2enamesTable_str3, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2enamesTable_str4, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2enamesTable_str5, 9, (123, 48, 44, 32, 78, 85, 76, 76, 125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2enamesTable_str6, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2enamesTable_str7, 22, (115, 116, 97, 116, 105, 99, 32, 99, 111, 110, 115, 116, 32, 72, 101, 102, 102, 78, 97, 109, 101, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2enamesTable_str8, 6, (91, 93, 32, 61, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemitc_2enamesTable_str9, 2, (125, 59));
Clo g_heff_2ecompile_2eemitc_2enamesTable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enamesTable_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2enamesTable(V v_name_240, V v_m_241) {
top: ;
  V v_t_242 = (g_map_2etoListOnto(v_m_241, NTAG(TAG_Nil)));
  V v_x2_243 = (g_list_2emap_24s1378753456x1787722089(((V)&g_heff_2ecompile_2eemitc_2enamesTable_str0), ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str1), ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str2), v_t_242));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str4); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_247 = (g_map_2esize(v_m_241));
  V v_t_249;
  if (heff_intEq_c(v_t_247, MK_INT(0LL))) {
    v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str5);
  } else {
    v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str6);
  }
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enamesTable_str7), heff_strAppend(v_name_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enamesTable_str8), heff_strAppend(v_t_246, heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str9))))));
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2eemitc_2enamesTable_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2enamesTable(a[0], a[1]); heff_drop(a[1]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2erunEnd_str0, 64, (115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40, 86, 32, 112, 44, 32, 86, 32, 107, 41, 32, 123, 32, 114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 95, 48, 40, 112, 44, 32, 107, 41, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2erunEnd_str1, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2erunEnd_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2erunEnd_str3, 35, (115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 101, 110, 116, 114, 121, 40, 118, 111, 105, 100, 41, 32, 123, 32, 114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2erunEnd_str4, 9, (95, 103, 101, 116, 40, 41, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2erunEnd_str5, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2erunEnd_str6, 0, (0));
Clo g_heff_2ecompile_2eemitc_2erunEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2erunEnd_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2erunEnd(V v_eff_240, V v_ce_241) {
top: ;
  V v_x1_242 = (g_heff_2ecompile_2eemitc_2eperformNodes(v_eff_240, MK_INT(0LL)));
  V v_t_245;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_MkPair: {
    V v_x_243 = heff_field(v_x1_242, 0);
    heff_take_n(v_x1_242, 1ULL, 2);
    v_t_245 = v_x_243;
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2erunEnd_str0), NTAG(TAG_Nil)});
  V v_t_247 = (g_prelude_2e_2b_2b(v_t_245, v_t_246));
  V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erunEnd_str1), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2erunEnd_str2))));
  V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erunEnd_str3), heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemitc_2erunEnd_str4)));
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2erunEnd_str5), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2erunEnd_str6), heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2410})});
  HEFF_LAST return g_prelude_2e_2b_2b(v_t_247, v_t_2411);
}
V g_heff_2ecompile_2eemitc_2erunEnd_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2erunEnd(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2eglobalGet_str0, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eglobalGet_str1, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eglobalGet_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eglobalGet_str3, 14, (115, 116, 97, 116, 105, 99, 32, 86, 32, 103, 103, 101, 116, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eglobalGet_str4, 20, (40, 118, 111, 105, 100, 41, 32, 123, 32, 114, 101, 116, 117, 114, 110, 32, 40, 86, 41, 38));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eglobalGet_str5, 7, (95, 99, 108, 111, 59, 32, 125));
Clo g_heff_2ecompile_2eemitc_2eglobalGet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eglobalGet_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eglobalGet(V v_ce_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_key_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_x3_244 = ({ V a_0 = heff_dup(v_key_243); V b_1 = heff_get_n(v_ce_240, 2, 12); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      heff_drop(v_key_243);
      heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      V v_t_246 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_key_243), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str0)));
      V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str1), (g_heff_2ecompile_2eemitc_2emangleW(v_key_243, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str2))));
      V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str3), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str4), heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str5)))));
      return heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eglobalGet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eglobalGet(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str0, 76, (115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40, 86, 32, 112, 44, 32, 86, 32, 107, 41, 32, 123, 32, 40, 118, 111, 105, 100, 41, 112, 59, 32, 40, 118, 111, 105, 100, 41, 107, 59, 32, 114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 97, 98, 97, 110, 100, 111, 110, 40, 41, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str1, 18, (104, 101, 102, 102, 95, 116, 97, 103, 95, 110, 97, 109, 101, 115, 95, 97, 114, 114));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str2, 18, (104, 101, 102, 102, 95, 108, 98, 108, 95, 110, 97, 109, 101, 115, 95, 97, 114, 114));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str3, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str4, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str5, 4, (95, 103, 101, 116));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str6, 5, (103, 103, 101, 116, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str7, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str8, 2, (123, 34));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str9, 3, (34, 44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str10, 1, (125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str11, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str12, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str13, 12, (123, 78, 85, 76, 76, 44, 32, 78, 85, 76, 76, 125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str14, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str15, 42, (115, 116, 97, 116, 105, 99, 32, 99, 111, 110, 115, 116, 32, 71, 108, 111, 98, 97, 108, 32, 104, 101, 102, 102, 95, 103, 108, 111, 98, 97, 108, 115, 95, 97, 114, 114, 91, 93, 32, 61, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str16, 2, (125, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str17, 18, (32, 32, 104, 101, 102, 102, 95, 110, 103, 108, 111, 98, 97, 108, 115, 32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str18, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str19, 20, (32, 32, 104, 101, 102, 102, 95, 110, 116, 97, 103, 95, 110, 97, 109, 101, 115, 32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str20, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str21, 20, (32, 32, 104, 101, 102, 102, 95, 110, 108, 98, 108, 95, 110, 97, 109, 101, 115, 32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str22, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str23, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str24, 1, (125));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str25, 38, (32, 32, 104, 101, 102, 102, 95, 108, 98, 108, 95, 110, 97, 109, 101, 115, 32, 61, 32, 104, 101, 102, 102, 95, 108, 98, 108, 95, 110, 97, 109, 101, 115, 95, 97, 114, 114, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str26, 38, (32, 32, 104, 101, 102, 102, 95, 116, 97, 103, 95, 110, 97, 109, 101, 115, 32, 61, 32, 104, 101, 102, 102, 95, 116, 97, 103, 95, 110, 97, 109, 101, 115, 95, 97, 114, 114, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str27, 35, (115, 116, 97, 116, 105, 99, 32, 118, 111, 105, 100, 32, 104, 101, 102, 102, 95, 99, 104, 101, 99, 107, 95, 105, 110, 105, 116, 40, 118, 111, 105, 100, 41, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckEnd_str28, 34, (32, 32, 104, 101, 102, 102, 95, 103, 108, 111, 98, 97, 108, 115, 32, 61, 32, 104, 101, 102, 102, 95, 103, 108, 111, 98, 97, 108, 115, 95, 97, 114, 114, 59));
V g_heff_2ecompile_2eemitc_2echeckEnd_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam9(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam8(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2echeckEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2echeckEnd_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2echeckEnd(V v_exports_240, V v_defs_241, V v_ce_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str0), NTAG(TAG_Nil)});
  V v_xs_249 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam0, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
  V v_t_2414 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam2, 2, 1, (V[]){heff_dup(v_ce_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2410; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
  V v_t_2415 = (g_heff_2ecompile_2eemitc_2enamesTable(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str1), heff_rfield(v_ce_242, 0)));
  V v_t_2416 = (g_heff_2ecompile_2eemitc_2enamesTable(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str2), heff_rfield(v_ce_242, 1)));
  V v_t_2422 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam3, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_x2_2434 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam5, 1, 1, (V[]){heff_dup(v_ce_242)}), v_t_2422));
  V v_t_2437;
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_Nil: {
    v_t_2437 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str11);
    break;
  }
  case TAG_Cons: {
    V v_x_2435 = heff_field(v_x2_2434, 0);
    V v_xs_2436 = heff_field(v_x2_2434, 1);
    heff_take_n(v_x2_2434, 3ULL, 2);
    v_t_2437 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str12); V a_1 = v_x_2435; V a_2 = v_xs_2436; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2436); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2434);
  }
  V v_x1_2443 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam6, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_t_2446;
  switch (heff_tag_of(v_x1_2443)) {
  case TAG_Nil: {
    v_t_2446 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str13);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2443, 0ULL, 2);
    v_t_2446 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str14);
    break;
  }
  default: heff_nomatch(v_x1_2443);
  }
  V v_t_2447 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str15), heff_strAppend(v_t_2437, heff_strAppend(v_t_2446, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str16))));
  V v_xs_2453 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam8, 1, 1, (V[]){heff_dup(v_defs_241)}), v_exports_240));
  V v_t_2454 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2453; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_2453); r_; });
  V v_t_2455 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str17), heff_strAppend(heff_intShow(v_t_2454), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str18)));
  V v_t_2456 = (g_map_2esize(heff_rfield(v_ce_242, 0)));
  V v_t_2457 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str19), heff_strAppend(heff_intShow(v_t_2456), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str20)));
  V v_t_2458 = ({ V b_0 = heff_get_n(v_ce_242, 1, 12); V r_ = (g_map_2esize(b_0)); heff_drop(b_0); r_; });
  V v_t_2459 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str21), heff_strAppend(heff_intShow(v_t_2458), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str22)));
  V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str23), NTAG(TAG_Nil)});
  V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2459, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str24), v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2457, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str25), v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str26), v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str27), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str28), v_t_2463})});
  V v_t_2465 = (g_prelude_2e_2b_2b(v_t_2416, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, v_t_2464})));
  V v_t_2466 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2465));
  V v_t_2467 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2466));
  return (g_prelude_2e_2b_2b(v_t_243, v_t_2467));
}
V g_heff_2ecompile_2eemitc_2echeckEnd_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2echeckEnd(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam1(V self, V *args) {
  V v_d_248 = args[0];
  V v_key_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_d_248, 0, 3), v_key_247);
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam0(V self, V *args) {
  V v_p_244 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_247;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_y_246 = heff_field(v_p_244, 1);
    heff_take_n(v_p_244, 2ULL, 2);
    v_key_247 = v_y_246;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam1, 1, 1, (V[]){v_key_247}); V a_1 = v_defs_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam2(V self, V *args) {
  V v_acc_2411 = args[0];
  V v_x_2412 = args[1];
  V v_ce_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = (g_heff_2ecompile_2eemitc_2eglobalGet(v_ce_242, v_x_2412));
  return (g_prelude_2e_2b_2b(v_t_2413, v_acc_2411));
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam4(V self, V *args) {
  V v_d_2421 = args[0];
  V v_key_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_d_2421, 0, 3), v_key_2420);
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam3(V self, V *args) {
  V v_p_2417 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_2420;
  switch (heff_tag_of(v_p_2417)) {
  case TAG_MkPair: {
    V v_y_2419 = heff_field(v_p_2417, 1);
    heff_take_n(v_p_2417, 2ULL, 2);
    v_key_2420 = v_y_2419;
    break;
  }
  default: heff_nomatch(v_p_2417);
  }
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam4, 1, 1, (V[]){v_key_2420}); V a_1 = v_defs_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam5(V self, V *args) {
  V v_p_2423 = args[0];
  V v_ce_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426;
  switch (heff_tag_of(v_p_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_dup(heff_field(v_p_2423, 0));
    v_t_2426 = v_x_2424;
    break;
  }
  default: heff_nomatch(v_p_2423);
  }
  V v_key_2429;
  switch (heff_tag_of(v_p_2423)) {
  case TAG_MkPair: {
    V v_y_2428 = heff_field(v_p_2423, 1);
    heff_take_n(v_p_2423, 2ULL, 2);
    v_key_2429 = v_y_2428;
    break;
  }
  default: heff_nomatch(v_p_2423);
  }
  V v_x3_2430 = ({ V a_0 = heff_dup(v_key_2429); V b_1 = heff_get_n(v_ce_242, 2, 12); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2433;
  switch (heff_tag_of(v_x3_2430)) {
  case TAG_Nothing: {
    V v_t_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str3), (g_heff_2ecompile_2eemitc_2emangleW(v_key_2429, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str4))));
    v_t_2433 = heff_strAppend(v_t_2431, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str5));
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_2430, 0ULL, 1);
    v_t_2433 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str6), (g_heff_2ecompile_2eemitc_2emangleW(v_key_2429, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str7))));
    break;
  }
  default: heff_nomatch(v_x3_2430);
  }
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str8), heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str9), heff_strAppend(v_t_2433, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str10)))));
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam7(V self, V *args) {
  V v_d_2442 = args[0];
  V v_key_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_d_2442, 0, 3), v_key_2441);
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam6(V self, V *args) {
  V v_p_2438 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_2441;
  switch (heff_tag_of(v_p_2438)) {
  case TAG_MkPair: {
    V v_y_2440 = heff_field(v_p_2438, 1);
    heff_take_n(v_p_2438, 2ULL, 2);
    v_key_2441 = v_y_2440;
    break;
  }
  default: heff_nomatch(v_p_2438);
  }
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam7, 1, 1, (V[]){v_key_2441}); V a_1 = v_defs_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam9(V self, V *args) {
  V v_d_2452 = args[0];
  V v_key_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_d_2452, 0, 3), v_key_2451);
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam8(V self, V *args) {
  V v_p_2448 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_2451;
  switch (heff_tag_of(v_p_2448)) {
  case TAG_MkPair: {
    V v_y_2450 = heff_field(v_p_2448, 1);
    heff_take_n(v_p_2448, 2ULL, 2);
    v_key_2451 = v_y_2450;
    break;
  }
  default: heff_nomatch(v_p_2448);
  }
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam9, 1, 1, (V[]){v_key_2451}); V a_1 = v_defs_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2eonlyLent_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eonlyLent_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2eonlyLent_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2eonlyLent_lam3(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eonlyLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eonlyLent_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eonlyLent(V v_bor_240, V v_p_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    heff_drop(v_bor_240);
    if (heff_strEq_c(v_p_241, v_x_243)) {
      return NTAG(TAG_False);
    } else {
      return NTAG(TAG_True);
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    V v_b_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 2);
    V t_0 = v_bor_240;
    V t_1 = v_p_241;
    V t_2 = v_b_247;
    v_bor_240 = t_0;
    v_p_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_x3_242, 0);
    V v_as_249 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24EApp = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2eonlyLent_clo), 2, (V[]){v_bor_240, v_p_241}));
    return ({ V a_0 = v_t_2410; V b_1 = heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_f_248, v_as_249}); V r_ = (g_list_2eall(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2412 = heff_field(v_x3_242, 1);
    V v_b_2413 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 6ULL, 3);
    V v_t_2414 = (g_heff_2ecompile_2eemitc_2eonlyLent(heff_dup(v_bor_240), heff_dup(v_p_241), v_a_2412));
    switch (heff_tag_of(v_t_2414)) {
    case TAG_True: {
      V t_0 = v_bor_240;
      V t_1 = v_p_241;
      V t_2 = v_b_2413;
      v_bor_240 = t_0;
      v_p_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_bor_240);
      heff_drop(v_p_241);
      heff_drop(v_b_2413);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2414);
    }
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2eonlyLent_lam0, 1, 2, (V[]){v_bor_240, v_p_241}); V a_1 = v_fs_2415; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_fs_2415); r_; });
  }
  case TAG_EProj: {
    V v_e_2420 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 3);
    V t_0 = v_bor_240;
    V t_1 = v_p_241;
    V t_2 = v_e_2420;
    v_bor_240 = t_0;
    v_p_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2424 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 2);
    V v_t_2425 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2eonlyLent_clo), 2, (V[]){v_bor_240, v_p_241}));
    return ({ V a_0 = v_t_2425; V a_1 = v_as_2424; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2424); r_; });
  }
  case TAG_EMatch: {
    V v_s_2426 = heff_field(v_x3_242, 0);
    V v_arms_2427 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2458;
    switch (heff_tag_of(v_s_2426)) {
    case TAG_EVar: {
      V v_x_2428 = heff_dup(heff_field(v_s_2426, 0));
      v_t_2458 = heff_strEq(heff_dup(v_p_241), v_x_2428);
      break;
    }
    case TAG_EGlobal: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2426);
    }
    switch (heff_tag_of(v_t_2458)) {
    case TAG_True: {
      heff_drop(v_s_2426);
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2eonlyLent_lam1, 1, 2, (V[]){v_bor_240, v_p_241}); V a_1 = v_arms_2427; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2427); r_; });
    }
    case TAG_False: {
      V v_t_2464 = (g_heff_2ecompile_2eemitc_2eonlyLent(heff_dup(v_bor_240), heff_dup(v_p_241), v_s_2426));
      switch (heff_tag_of(v_t_2464)) {
      case TAG_True: {
        return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2eonlyLent_lam2, 1, 2, (V[]){v_bor_240, v_p_241}); V a_1 = v_arms_2427; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2427); r_; });
      }
      case TAG_False: {
        heff_drop(v_bor_240);
        heff_drop(v_p_241);
        heff_drop(v_arms_2427);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2464);
      }
    }
    default: return heff_nomatch(v_t_2458);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_as_2472 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 2);
    V v_t_2473 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2eonlyLent_clo), 2, (V[]){v_bor_240, v_p_241}));
    return ({ V a_0 = v_t_2473; V a_1 = v_as_2472; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2472); r_; });
  }
  case TAG_ECall: {
    V v_g_2474 = heff_field(v_x3_242, 0);
    V v_as_2475 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2476 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2475));
    V v_t_2477 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2476, MK_INT(1LL))));
    V v_t_2478 = (g_list_2ezipWith_24s1876717925x1404326288(v_as_2475, v_t_2477));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2eonlyLent_lam3, 1, 3, (V[]){v_p_241, v_g_2474, v_bor_240}); V a_1 = v_t_2478; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2478); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFix: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2eonlyLent_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eonlyLent(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2eonlyLent_lam0(V self, V *args) {
  V v_f_2416 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419;
  switch (heff_tag_of(v_f_2416)) {
  case TAG_MkPair: {
    V v_y_2418 = heff_field(v_f_2416, 1);
    heff_take_n(v_f_2416, 2ULL, 2);
    v_t_2419 = v_y_2418;
    break;
  }
  default: heff_nomatch(v_f_2416);
  }
  return (g_heff_2ecompile_2eemitc_2eonlyLent(v_bor_240, v_p_241, v_t_2419));
}
V g_heff_2ecompile_2eemitc_2eonlyLent_lam1(V self, V *args) {
  V v_a_2459 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2463;
  switch (heff_tag_of(v_a_2459)) {
  case TAG_MkArm: {
    V v_b_2462 = heff_field(v_a_2459, 2);
    heff_take_n(v_a_2459, 4ULL, 3);
    v_t_2463 = v_b_2462;
    break;
  }
  default: heff_nomatch(v_a_2459);
  }
  return (g_heff_2ecompile_2eemitc_2eonlyLent(v_bor_240, v_p_241, v_t_2463));
}
V g_heff_2ecompile_2eemitc_2eonlyLent_lam2(V self, V *args) {
  V v_a_2465 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2469;
  switch (heff_tag_of(v_a_2465)) {
  case TAG_MkArm: {
    V v_b_2468 = heff_field(v_a_2465, 2);
    heff_take_n(v_a_2465, 4ULL, 3);
    v_t_2469 = v_b_2468;
    break;
  }
  default: heff_nomatch(v_a_2465);
  }
  return (g_heff_2ecompile_2eemitc_2eonlyLent(v_bor_240, v_p_241, v_t_2469));
}
V g_heff_2ecompile_2eemitc_2eonlyLent_lam3(V self, V *args) {
  V v_pr_2479 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_g_2474 = heff_env(self)[1];
  V v_bor_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2482;
  switch (heff_tag_of(v_pr_2479)) {
  case TAG_MkPair: {
    V v_x_2480 = heff_dup(heff_field(v_pr_2479, 0));
    v_x2_2482 = v_x_2480;
    break;
  }
  default: heff_nomatch(v_pr_2479);
  }
  V v_t_24113;
  switch (heff_tag_of(v_x2_2482)) {
  case TAG_EVar: {
    V v_x_2483 = heff_field(v_x2_2482, 0);
    heff_take_n(v_x2_2482, 1ULL, 1);
    v_t_24113 = heff_strEq(heff_dup(v_p_241), v_x_2483);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_2482, 0ULL, 1);
    v_t_24113 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_x2_2482, 0ULL, 2);
    v_t_24113 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_x2_2482, 0ULL, 2);
    v_t_24113 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_x2_2482, 0ULL, 3);
    v_t_24113 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_2482, 0ULL, 1);
    v_t_24113 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_x2_2482, 0ULL, 3);
    v_t_24113 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_x2_2482, 0ULL, 2);
    v_t_24113 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_2482, 0ULL, 2);
    v_t_24113 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_2482, 0ULL, 1);
    v_t_24113 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_2482, 0ULL, 2);
    v_t_24113 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_x2_2482, 0ULL, 2);
    v_t_24113 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_x2_2482, 0ULL, 1);
    v_t_24113 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_2482, 0ULL, 1);
    v_t_24113 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_x2_2482, 0ULL, 1);
    v_t_24113 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_2482, 0ULL, 2);
    v_t_24113 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_2482, 0ULL, 1);
    v_t_24113 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_24113 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_x2_2482, 0ULL, 2);
    v_t_24113 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x2_2482);
  }
  switch (heff_tag_of(v_t_24113)) {
  case TAG_True: {
    V v_t_24116;
    switch (heff_tag_of(v_pr_2479)) {
    case TAG_MkPair: {
      V v_y_24115 = heff_dup(heff_field(v_pr_2479, 1));
      v_t_24116 = v_y_24115;
      break;
    }
    default: heff_nomatch(v_pr_2479);
    }
    V v_x2_24117 = (g_map_2elookup_24s1546226666x2146984184(v_g_2474, v_bor_240));
    V v_t_24119;
    switch (heff_tag_of(v_x2_24117)) {
    case TAG_Nothing: {
      v_t_24119 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_24118 = heff_field(v_x2_24117, 0);
      heff_take_n(v_x2_24117, 1ULL, 1);
      v_t_24119 = v_x_24118;
      break;
    }
    default: heff_nomatch(v_x2_24117);
    }
    V v_t_24120 = ({ V a_0 = v_t_24116; V a_1 = v_t_24119; V r_ = (g_heff_2ecompile_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_t_24119); r_; });
    switch (heff_tag_of(v_t_24120)) {
    case TAG_True: {
      heff_drop(v_pr_2479);
      heff_drop(v_p_241);
      heff_drop(v_bor_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_24123;
      switch (heff_tag_of(v_pr_2479)) {
      case TAG_MkPair: {
        V v_x_24121 = heff_field(v_pr_2479, 0);
        heff_take_n(v_pr_2479, 1ULL, 2);
        v_t_24123 = v_x_24121;
        break;
      }
      default: heff_nomatch(v_pr_2479);
      }
      return (g_heff_2ecompile_2eemitc_2eonlyLent(v_bor_240, v_p_241, v_t_24123));
    }
    default: return heff_nomatch(v_t_24120);
    }
  }
  case TAG_False: {
    heff_drop(v_g_2474);
    V v_t_24126;
    switch (heff_tag_of(v_pr_2479)) {
    case TAG_MkPair: {
      V v_x_24124 = heff_field(v_pr_2479, 0);
      heff_take_n(v_pr_2479, 1ULL, 2);
      v_t_24126 = v_x_24124;
      break;
    }
    default: heff_nomatch(v_pr_2479);
    }
    return (g_heff_2ecompile_2eemitc_2eonlyLent(v_bor_240, v_p_241, v_t_24126));
  }
  default: return heff_nomatch(v_t_24113);
  }
}
V g_heff_2ecompile_2eemitc_2ebuildsSize_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2ebuildsSize_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2ebuildsSize_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ebuildsSize_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2ebuildsSize(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V t_0 = v_n_240;
    V t_1 = v_b_245;
    v_n_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x2_241, 0);
    V v_as_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    return ({ V a_0 = v_t_248; V b_1 = heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_f_246, v_as_247}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x2_241, 1);
    V v_b_2411 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2412 = (g_heff_2ecompile_2eemitc_2ebuildsSize(heff_dup(v_n_240), v_a_2410));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_n_240);
      heff_drop(v_b_2411);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_n_240;
      V t_1 = v_b_2411;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_ERecord: {
    V v_fs_2413 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2ebuildsSize_lam0, 1, 1, (V[]){v_n_240}); V a_1 = v_fs_2413; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_fs_2413); r_; });
  }
  case TAG_EProj: {
    V v_e_2418 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 3);
    V t_0 = v_n_240;
    V t_1 = v_e_2418;
    v_n_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2422 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2423 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2422));
    if (heff_intEq_c(v_t_2423, heff_dup(v_n_240))) {
      heff_drop(v_n_240);
      heff_drop(v_as_2422);
      return NTAG(TAG_True);
    } else {
      V v_t_2425 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2ebuildsSize_clo), 1, (V[]){v_n_240}));
      return ({ V a_0 = v_t_2425; V a_1 = v_as_2422; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2422); r_; });
    }
  }
  case TAG_EMatch: {
    V v_s_2426 = heff_field(v_x2_241, 0);
    V v_arms_2427 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2428 = (g_heff_2ecompile_2eemitc_2ebuildsSize(heff_dup(v_n_240), v_s_2426));
    switch (heff_tag_of(v_t_2428)) {
    case TAG_True: {
      heff_drop(v_n_240);
      heff_drop(v_arms_2427);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2ebuildsSize_lam1, 1, 1, (V[]){v_n_240}); V a_1 = v_arms_2427; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_arms_2427); r_; });
    }
    default: return heff_nomatch(v_t_2428);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_as_2436 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2437 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    return ({ V a_0 = v_t_2437; V a_1 = v_as_2436; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2436); r_; });
  }
  case TAG_ECall: {
    V v_as_2439 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2440 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    return ({ V a_0 = v_t_2440; V a_1 = v_as_2439; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2439); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2ebuildsSize_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ebuildsSize(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2ebuildsSize_lam0(V self, V *args) {
  V v_f_2414 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417;
  switch (heff_tag_of(v_f_2414)) {
  case TAG_MkPair: {
    V v_y_2416 = heff_field(v_f_2414, 1);
    heff_take_n(v_f_2414, 2ULL, 2);
    v_t_2417 = v_y_2416;
    break;
  }
  default: heff_nomatch(v_f_2414);
  }
  return (g_heff_2ecompile_2eemitc_2ebuildsSize(v_n_240, v_t_2417));
}
V g_heff_2ecompile_2eemitc_2ebuildsSize_lam1(V self, V *args) {
  V v_a_2429 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433;
  switch (heff_tag_of(v_a_2429)) {
  case TAG_MkArm: {
    V v_b_2432 = heff_field(v_a_2429, 2);
    heff_take_n(v_a_2429, 4ULL, 3);
    v_t_2433 = v_b_2432;
    break;
  }
  default: heff_nomatch(v_a_2429);
  }
  return (g_heff_2ecompile_2eemitc_2ebuildsSize(v_n_240, v_t_2433));
}
V g_heff_2ecompile_2eemitc_2ereuses_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2ereuses_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2ereuses_lam2(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2ereuses_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ereuses_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2ereuses(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V t_0 = v_p_240;
    V t_1 = v_b_245;
    v_p_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x2_241, 0);
    V v_as_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_248; V b_1 = heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_f_246, v_as_247}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x2_241, 1);
    V v_b_2411 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2412 = (g_heff_2ecompile_2eemitc_2ereuses(heff_dup(v_p_240), v_a_2410));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_p_240);
      heff_drop(v_b_2411);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_b_2411;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_ERecord: {
    V v_fs_2413 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2ereuses_lam0, 1, 1, (V[]){v_p_240}); V a_1 = v_fs_2413; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_fs_2413); r_; });
  }
  case TAG_EProj: {
    V v_e_2418 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 3);
    V t_0 = v_p_240;
    V t_1 = v_e_2418;
    v_p_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2422 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2423 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_2423; V a_1 = v_as_2422; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2422); r_; });
  }
  case TAG_EMatch: {
    V v_s_2424 = heff_field(v_x2_241, 0);
    V v_arms_2425 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2456;
    switch (heff_tag_of(v_s_2424)) {
    case TAG_EVar: {
      V v_x_2426 = heff_dup(heff_field(v_s_2424, 0));
      v_t_2456 = heff_strEq(heff_dup(v_p_240), v_x_2426);
      break;
    }
    case TAG_EGlobal: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2424);
    }
    switch (heff_tag_of(v_t_2456)) {
    case TAG_True: {
      V v_t_2457 = (g_list_2eany_24s261760131x1433598489(v_arms_2425));
      switch (heff_tag_of(v_t_2457)) {
      case TAG_True: {
        heff_drop(v_p_240);
        heff_drop(v_s_2424);
        heff_drop(v_arms_2425);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V v_t_2458 = (g_heff_2ecompile_2eemitc_2ereuses(heff_dup(v_p_240), v_s_2424));
        switch (heff_tag_of(v_t_2458)) {
        case TAG_True: {
          heff_drop(v_p_240);
          heff_drop(v_arms_2425);
          return NTAG(TAG_True);
        }
        case TAG_False: {
          return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2ereuses_lam1, 1, 1, (V[]){v_p_240}); V a_1 = v_arms_2425; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_arms_2425); r_; });
        }
        default: return heff_nomatch(v_t_2458);
        }
      }
      default: return heff_nomatch(v_t_2457);
      }
    }
    case TAG_False: {
      V v_t_2464 = (g_heff_2ecompile_2eemitc_2ereuses(heff_dup(v_p_240), v_s_2424));
      switch (heff_tag_of(v_t_2464)) {
      case TAG_True: {
        heff_drop(v_p_240);
        heff_drop(v_arms_2425);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2ereuses_lam2, 1, 1, (V[]){v_p_240}); V a_1 = v_arms_2425; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_arms_2425); r_; });
      }
      default: return heff_nomatch(v_t_2464);
      }
    }
    default: return heff_nomatch(v_t_2456);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_as_2472 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2473 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_2473; V a_1 = v_as_2472; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2472); r_; });
  }
  case TAG_ECall: {
    V v_as_2475 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2476 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_2476; V a_1 = v_as_2475; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2475); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2ereuses_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ereuses(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2ereuses_lam0(V self, V *args) {
  V v_f_2414 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417;
  switch (heff_tag_of(v_f_2414)) {
  case TAG_MkPair: {
    V v_y_2416 = heff_field(v_f_2414, 1);
    heff_take_n(v_f_2414, 2ULL, 2);
    v_t_2417 = v_y_2416;
    break;
  }
  default: heff_nomatch(v_f_2414);
  }
  return (g_heff_2ecompile_2eemitc_2ereuses(v_p_240, v_t_2417));
}
V g_heff_2ecompile_2eemitc_2ereuses_lam1(V self, V *args) {
  V v_a_2459 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2463;
  switch (heff_tag_of(v_a_2459)) {
  case TAG_MkArm: {
    V v_b_2462 = heff_field(v_a_2459, 2);
    heff_take_n(v_a_2459, 4ULL, 3);
    v_t_2463 = v_b_2462;
    break;
  }
  default: heff_nomatch(v_a_2459);
  }
  return (g_heff_2ecompile_2eemitc_2ereuses(v_p_240, v_t_2463));
}
V g_heff_2ecompile_2eemitc_2ereuses_lam2(V self, V *args) {
  V v_a_2465 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469;
  switch (heff_tag_of(v_a_2465)) {
  case TAG_MkArm: {
    V v_b_2468 = heff_field(v_a_2465, 2);
    heff_take_n(v_a_2465, 4ULL, 3);
    v_t_2469 = v_b_2468;
    break;
  }
  default: heff_nomatch(v_a_2465);
  }
  return (g_heff_2ecompile_2eemitc_2ereuses(v_p_240, v_t_2469));
}
V g_heff_2ecompile_2eemitc_2elentVars_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2elentVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elentVars_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2elentVars(V v_ds_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    V v_a_249 = heff_field(v_x2_241, 1);
    V v_b_2410 = heff_field(v_x2_241, 2);
    V v_t_2411 = (g_heff_2ecompile_2eemitc_2elentVars(heff_dup(v_ds_240), v_a_249));
    V v_t_2412 = (g_heff_2ecompile_2eemitc_2elentVars(v_ds_240, v_b_2410));
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2411, v_t_2412);
  }
  case TAG_ERecord: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    V v_s_2419 = heff_field(v_x2_241, 0);
    V v_arms_2420 = heff_field(v_x2_241, 1);
    V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2420)));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2elentVars_lam0, 2, 2, (V[]){heff_dup(v_s_2419), v_ds_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2421; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2421); r_; });
  }
  case TAG_EPrim: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2elentVars_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2elentVars(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2ecompile_2eemitc_2elentVars_lam0(V self, V *args) {
  V v_acc_2422 = args[0];
  V v_x_2423 = args[1];
  V v_s_2419 = heff_env(self)[0];
  V v_ds_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2454;
  switch (heff_tag_of(v_s_2419)) {
  case TAG_EVar: {
    V v_x_2424 = heff_field(v_s_2419, 0);
    heff_take_n(v_s_2419, 1ULL, 1);
    v_t_2454 = (g_heff_2ecompile_2eemitc_2eelemS(v_x_2424, v_ds_240));
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_s_2419, 0ULL, 1);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_s_2419, 0ULL, 2);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_s_2419, 0ULL, 2);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_s_2419, 0ULL, 3);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_s_2419, 0ULL, 1);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_s_2419, 0ULL, 3);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_s_2419, 0ULL, 2);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_s_2419, 0ULL, 2);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_s_2419, 0ULL, 1);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_s_2419, 0ULL, 2);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_s_2419, 0ULL, 2);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_s_2419, 0ULL, 1);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_n(v_s_2419, 0ULL, 1);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_s_2419, 0ULL, 1);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_s_2419, 0ULL, 2);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_take_n(v_s_2419, 0ULL, 1);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_s_2419, 0ULL, 2);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_s_2419);
  }
  V v_t_2473;
  switch (heff_tag_of(v_t_2454)) {
  case TAG_True: {
    V v_t_2458;
    switch (heff_tag_of(v_x_2423)) {
    case TAG_MkArm: {
      V v_vs_2456 = heff_dup(heff_field(v_x_2423, 1));
      v_t_2458 = v_vs_2456;
      break;
    }
    default: heff_nomatch(v_x_2423);
    }
    V v_t_2462;
    switch (heff_tag_of(v_x_2423)) {
    case TAG_MkArm: {
      V v_vs_2460 = heff_dup(heff_field(v_x_2423, 1));
      v_t_2462 = v_vs_2460;
      break;
    }
    default: heff_nomatch(v_x_2423);
    }
    V v_t_2463 = (g_prelude_2e_2b_2b(v_t_2462, v_ds_240));
    V v_t_2467;
    switch (heff_tag_of(v_x_2423)) {
    case TAG_MkArm: {
      V v_b_2466 = heff_field(v_x_2423, 2);
      heff_take_n(v_x_2423, 4ULL, 3);
      v_t_2467 = v_b_2466;
      break;
    }
    default: heff_nomatch(v_x_2423);
    }
    V v_t_2468 = ({ V a_0 = v_t_2463; V a_1 = v_t_2467; V r_ = (g_heff_2ecompile_2eemitc_2elentVars(a_0, a_1)); heff_drop(v_t_2467); r_; });
    v_t_2473 = (g_prelude_2e_2b_2b(v_t_2458, v_t_2468));
    break;
  }
  case TAG_False: {
    V v_t_2472;
    switch (heff_tag_of(v_x_2423)) {
    case TAG_MkArm: {
      V v_b_2471 = heff_field(v_x_2423, 2);
      heff_take_n(v_x_2423, 4ULL, 3);
      v_t_2472 = v_b_2471;
      break;
    }
    default: heff_nomatch(v_x_2423);
    }
    v_t_2473 = ({ V a_0 = v_ds_240; V a_1 = v_t_2472; V r_ = (g_heff_2ecompile_2eemitc_2elentVars(a_0, a_1)); heff_drop(v_t_2472); r_; });
    break;
  }
  default: heff_nomatch(v_t_2454);
  }
  return (g_prelude_2e_2b_2b(v_t_2473, v_acc_2422));
}
V g_heff_2ecompile_2eemitc_2eloopLent_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eloopLent_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2eloopLent_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eloopLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eloopLent_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eloopLent(V v_key_240, V v_i_241, V v_ds_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_EVar: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_x4_243, 0);
    V v_as_249 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24EApp = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
    return ({ V a_0 = v_t_2410; V b_1 = heff_tag_at_n(v_ru_24x4_243_24EApp, TAG_Cons, 2, (V[]){v_f_248, v_as_249}); V r_ = (g_list_2eall(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2412 = heff_field(v_x4_243, 1);
    V v_b_2413 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 6ULL, 3);
    V v_t_2414 = (g_heff_2ecompile_2eemitc_2eloopLent(heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242), v_a_2412));
    switch (heff_tag_of(v_t_2414)) {
    case TAG_True: {
      V t_0 = v_key_240;
      V t_1 = v_i_241;
      V t_2 = v_ds_242;
      V t_3 = v_b_2413;
      v_key_240 = t_0;
      v_i_241 = t_1;
      v_ds_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_key_240);
      heff_drop(v_i_241);
      heff_drop(v_ds_242);
      heff_drop(v_b_2413);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2414);
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EProj: {
    heff_take_n(v_x4_243, 0ULL, 3);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_ETag: {
    V v_as_2420 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 2ULL, 2);
    V v_t_2421 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
    return ({ V a_0 = v_t_2421; V a_1 = v_as_2420; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2420); r_; });
  }
  case TAG_EMatch: {
    V v_s_2422 = heff_field(v_x4_243, 0);
    V v_arms_2423 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_2424 = (g_heff_2ecompile_2eemitc_2eloopLent(heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242), v_s_2422));
    switch (heff_tag_of(v_t_2424)) {
    case TAG_True: {
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2eloopLent_lam0, 1, 3, (V[]){v_key_240, v_i_241, v_ds_242}); V a_1 = v_arms_2423; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2423); r_; });
    }
    case TAG_False: {
      heff_drop(v_key_240);
      heff_drop(v_i_241);
      heff_drop(v_ds_242);
      heff_drop(v_arms_2423);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_ECall: {
    V v_g_2433 = heff_field(v_x4_243, 0);
    V v_as_2434 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_2436;
    if (heff_strEq_c(v_g_2433, heff_dup(v_key_240))) {
      v_t_2436 = NTAG(TAG_False);
    } else {
      v_t_2436 = NTAG(TAG_True);
    }
    switch (heff_tag_of(v_t_2436)) {
    case TAG_True: {
      V v_t_2437 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
      return ({ V a_0 = v_t_2437; V a_1 = v_as_2434; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2434); r_; });
    }
    case TAG_False: {
      V v_t_2438 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2434));
      V v_t_2439 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2438, MK_INT(1LL))));
      V v_t_2440 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_as_2434), v_t_2439));
      V v_t_2480 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2eloopLent_lam1, 1, 2, (V[]){heff_dup(v_i_241), heff_dup(v_ds_242)}); V a_1 = v_t_2440; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2440); r_; });
      switch (heff_tag_of(v_t_2480)) {
      case TAG_True: {
        V v_t_2481 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
        return ({ V a_0 = v_t_2481; V a_1 = v_as_2434; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2434); r_; });
      }
      case TAG_False: {
        heff_drop(v_key_240);
        heff_drop(v_i_241);
        heff_drop(v_ds_242);
        heff_drop(v_as_2434);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2480);
      }
    }
    default: return heff_nomatch(v_t_2436);
    }
  }
  case TAG_EInt: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFix: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2eloopLent_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eloopLent(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eemitc_2eloopLent_lam0(V self, V *args) {
  V v_a_2425 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_ds_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2429;
  switch (heff_tag_of(v_a_2425)) {
  case TAG_MkArm: {
    V v_b_2428 = heff_field(v_a_2425, 2);
    heff_take_n(v_a_2425, 4ULL, 3);
    v_t_2429 = v_b_2428;
    break;
  }
  default: heff_nomatch(v_a_2425);
  }
  return (g_heff_2ecompile_2eemitc_2eloopLent(v_key_240, v_i_241, v_ds_242, v_t_2429));
}
V g_heff_2ecompile_2eemitc_2eloopLent_lam2(V self, V *args) {
  V v_d_2446 = args[0];
  V v_pr_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2449;
  switch (heff_tag_of(v_pr_2441)) {
  case TAG_MkPair: {
    V v_x_2447 = heff_field(v_pr_2441, 0);
    heff_take_n(v_pr_2441, 1ULL, 2);
    v_x2_2449 = v_x_2447;
    break;
  }
  default: heff_nomatch(v_pr_2441);
  }
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_EVar: {
    V v_x_2450 = heff_field(v_x2_2449, 0);
    heff_take_n(v_x2_2449, 1ULL, 1);
    return heff_strEq(v_d_2446, v_x_2450);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_2449, 0ULL, 1);
    heff_drop(v_d_2446);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_2449, 0ULL, 2);
    heff_drop(v_d_2446);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_2449, 0ULL, 2);
    heff_drop(v_d_2446);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_2449, 0ULL, 3);
    heff_drop(v_d_2446);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_2449, 0ULL, 1);
    heff_drop(v_d_2446);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_2449, 0ULL, 3);
    heff_drop(v_d_2446);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_2449, 0ULL, 2);
    heff_drop(v_d_2446);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_2449, 0ULL, 2);
    heff_drop(v_d_2446);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_2449, 0ULL, 1);
    heff_drop(v_d_2446);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_2449, 0ULL, 2);
    heff_drop(v_d_2446);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_2449, 0ULL, 2);
    heff_drop(v_d_2446);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_2449, 0ULL, 1);
    heff_drop(v_d_2446);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_2449, 0ULL, 1);
    heff_drop(v_d_2446);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_2449, 0ULL, 1);
    heff_drop(v_d_2446);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_2449, 0ULL, 2);
    heff_drop(v_d_2446);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_2449, 0ULL, 1);
    heff_drop(v_d_2446);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_d_2446);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_2449, 0ULL, 2);
    heff_drop(v_d_2446);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_2449);
  }
}
V g_heff_2ecompile_2eemitc_2eloopLent_lam1(V self, V *args) {
  V v_pr_2441 = args[0];
  V v_i_241 = heff_env(self)[0];
  V v_ds_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2444;
  switch (heff_tag_of(v_pr_2441)) {
  case TAG_MkPair: {
    V v_y_2443 = heff_dup(heff_field(v_pr_2441, 1));
    v_t_2444 = v_y_2443;
    break;
  }
  default: heff_nomatch(v_pr_2441);
  }
  if (heff_intEq_c(v_t_2444, v_i_241)) {
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2eloopLent_lam2, 1, 1, (V[]){v_pr_2441}); V a_1 = v_ds_242; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_ds_242); r_; });
  } else {
    heff_drop(v_pr_2441);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
}
V g_heff_2ecompile_2eemitc_2eborDef_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eborDef_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2eborDef_lam2(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eborDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eborDef_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eborDef(V v_bor_240, V v_d_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_d_241, 2));
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    V v_b_246 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 3ULL, 2);
    V v_x2_247 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_bor_240));
    V v_bi_249;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      v_bi_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_x2_247, 0);
      heff_take_n(v_x2_247, 1ULL, 1);
      v_bi_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_245));
    V v_t_2411 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2410, MK_INT(1LL))));
    V v_t_2412 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_245), v_t_2411));
    V v_t_2417 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2eborDef_lam0, 1, 1, (V[]){v_bi_249}), v_t_2412));
    V v_t_2418 = (g_list_2emap_24s1937570095x2110149801(v_t_2417));
    V v_x2_2419 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_bor_240));
    V v_bi_2421;
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nothing: {
      v_bi_2421 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      heff_take_n(v_x2_2419, 1ULL, 1);
      v_bi_2421 = v_x_2420;
      break;
    }
    default: heff_nomatch(v_x2_2419);
    }
    V v_t_2422 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_245));
    V v_t_2423 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2422, MK_INT(1LL))));
    V v_t_2424 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_245), v_t_2423));
    V v_t_2429 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2eborDef_lam1, 1, 1, (V[]){v_bi_2421}), v_t_2424));
    V v_t_2430 = (g_list_2emap_24s1937570095x2110149801(v_t_2429));
    V v_t_2431 = (g_heff_2ecompile_2eemitc_2elentVars(v_t_2430, v_b_246));
    V v_ds_2432 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2431));
    V v_x2_2433 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_bor_240));
    V v_t_2435;
    switch (heff_tag_of(v_x2_2433)) {
    case TAG_Nothing: {
      v_t_2435 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2434 = heff_field(v_x2_2433, 0);
      heff_take_n(v_x2_2433, 1ULL, 1);
      v_t_2435 = v_x_2434;
      break;
    }
    default: heff_nomatch(v_x2_2433);
    }
    V v_t_2442 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2eborDef_lam2, 1, 5, (V[]){v_xs_245, heff_dup(v_bor_240), v_b_246, heff_dup(v_d_241), v_ds_2432}), v_t_2435));
    return (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_d_241, 0, 3), v_t_2442, v_bor_240));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EFloat: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EFloat32: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eemitc_2eborDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eborDef(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2eborDef_lam0(V self, V *args) {
  V v_p_2413 = args[0];
  V v_bi_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416;
  switch (heff_tag_of(v_p_2413)) {
  case TAG_MkPair: {
    V v_y_2415 = heff_field(v_p_2413, 1);
    heff_take_n(v_p_2413, 2ULL, 2);
    v_t_2416 = v_y_2415;
    break;
  }
  default: heff_nomatch(v_p_2413);
  }
  return ({ V a_0 = v_t_2416; V a_1 = v_bi_249; V r_ = (g_heff_2ecompile_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_249); r_; });
}
V g_heff_2ecompile_2eemitc_2eborDef_lam1(V self, V *args) {
  V v_p_2425 = args[0];
  V v_bi_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428;
  switch (heff_tag_of(v_p_2425)) {
  case TAG_MkPair: {
    V v_y_2427 = heff_field(v_p_2425, 1);
    heff_take_n(v_p_2425, 2ULL, 2);
    v_t_2428 = v_y_2427;
    break;
  }
  default: heff_nomatch(v_p_2425);
  }
  return ({ V a_0 = v_t_2428; V a_1 = v_bi_2421; V r_ = (g_heff_2ecompile_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_2421); r_; });
}
V g_heff_2ecompile_2eemitc_2eborDef_lam2(V self, V *args) {
  V v_i_2436 = args[0];
  V v_xs_245 = heff_env(self)[0];
  V v_bor_240 = heff_env(self)[1];
  V v_b_246 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_ds_2432 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2437 = (g_list_2edrop(heff_dup(v_i_2436), v_xs_245));
  switch (heff_tag_of(v_t_2437)) {
  case TAG_Nil: {
    heff_drop(v_i_2436);
    heff_drop(v_bor_240);
    heff_drop(v_b_246);
    heff_drop_rec(v_d_241, 3);
    heff_drop(v_ds_2432);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_2438 = heff_field(v_t_2437, 0);
    heff_take_n(v_t_2437, 1ULL, 2);
    V v_t_2440 = (g_heff_2ecompile_2eemitc_2eonlyLent(v_bor_240, heff_dup(v_p_2438), heff_dup(v_b_246)));
    switch (heff_tag_of(v_t_2440)) {
    case TAG_True: {
      V v_x1_2441 = (g_heff_2ecompile_2eemitc_2ereuses(v_p_2438, heff_dup(v_b_246)));
      switch (heff_tag_of(v_x1_2441)) {
      case TAG_True: {
        heff_drop(v_i_2436);
        heff_drop(v_b_246);
        heff_drop_rec(v_d_241, 3);
        heff_drop(v_ds_2432);
        return NTAG(TAG_False);
      }
      case TAG_False: {
        return (g_heff_2ecompile_2eemitc_2eloopLent(heff_get_n(v_d_241, 0, 3), v_i_2436, v_ds_2432, v_b_246));
      }
      default: return heff_nomatch(v_x1_2441);
      }
    }
    case TAG_False: {
      heff_drop(v_i_2436);
      heff_drop(v_b_246);
      heff_drop_rec(v_d_241, 3);
      heff_drop(v_ds_2432);
      heff_drop(v_p_2438);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2440);
    }
  }
  default: return heff_nomatch(v_t_2437);
  }
}
Clo g_heff_2ecompile_2eemitc_2eborFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eborFix_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eborFix(V v_defs_240, V v_size_241, V v_bor_242) {
top: ;
  V v_t_243 = (g_map_2etoListOnto(v_bor_242, NTAG(TAG_Nil)));
  V v_xs_244 = (g_list_2emap_24s1573559022x513331157(MK_INT(1LL), MK_INT(0LL), v_t_243));
  V v_t_245 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_244; V r_ = (g_list_2efoldl_24s114050048x1903860601(a_0, a_1)); heff_drop(v_xs_244); r_; });
  if (heff_intEq_c(v_t_245, v_size_241)) {
    return v_bor_242;
  } else {
    V v_t_247 = (g_map_2etoListOnto(v_bor_242, NTAG(TAG_Nil)));
    V v_xs_248 = (g_list_2emap_24s1573559022x513331157(MK_INT(1LL), MK_INT(0LL), v_t_247));
    V v_t_249 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_248; V r_ = (g_list_2efoldl_24s114050048x1903860601(a_0, a_1)); heff_drop(v_xs_248); r_; });
    V v_t_2410 = (g_list_2efoldl_24s1891821040x773772203(v_bor_242, v_defs_240));
    V t_0 = v_defs_240;
    V t_1 = v_t_249;
    V t_2 = v_t_2410;
    v_defs_240 = t_0;
    v_size_241 = t_1;
    v_bor_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eemitc_2eborFix_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2eborFix(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
Clo g_heff_2ecompile_2eemitc_2eborAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eborAll_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eborAll(V v_m_240, V v_d_241) {
top: ;
  V v_t_242 = heff_take_field(v_d_241, 2);
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_245; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    V v_t_248 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_247, MK_INT(1LL))));
    return (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_d_241, 0, 3), v_t_248, v_m_240));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat32: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eemitc_2eborAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eborAll(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprogramCE_str0, 42, (47, 47, 32, 71, 101, 110, 101, 114, 97, 116, 101, 100, 32, 102, 114, 111, 109, 32, 72, 105, 112, 112, 111, 103, 114, 105, 102, 102, 59, 32, 100, 111, 32, 110, 111, 116, 32, 101, 100, 105, 116, 46));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprogramCE_str1, 8, (35, 100, 101, 102, 105, 110, 101, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprogramCE_str2, 4, (84, 65, 71, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprogramCE_str3, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprogramCE_str4, 1, (32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprogramCE_str5, 8, (35, 100, 101, 102, 105, 110, 101, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprogramCE_str6, 4, (76, 66, 76, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprogramCE_str7, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprogramCE_str8, 1, (32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprogramCE_str9, 32, (115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40, 86, 32, 112, 44, 32, 86, 32, 107, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprogramCE_str10, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eprogramCE_str11, 1, (10));
Clo g_heff_2ecompile_2eemitc_2eprogramCE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprogramCE_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2eprogramCE(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243, V v_ce_244) {
top: ;
  V v_t_245 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2edefOwn_clo), 1, (V[]){heff_dup(v_ce_244)}));
  V v_t_246 = (g_heff_2ecompile_2eemitc_2etraverseC(v_t_245, v_defs_243));
  V v_t_247 = heff_tr(heff_apply(v_t_246, 1, (V[]){heff_dup(g_heff_2ecompile_2eemitc_2eemptyCS_get())}));
  switch (heff_tag_of(v_t_247)) {
  case TAG_MkPair: {
    V v_ems_248 = heff_field(v_t_247, 0);
    V v_s_249 = heff_field(v_t_247, 1);
    V v_ru_24t_247_24MkPair = heff_take_reuse_n(v_t_247, 3ULL, 2);
    V v_t_2410 = heff_tag_at_n(v_ru_24t_247_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str0), heff_dup(heff_rfield(v_ending_242, 0))});
    V v_t_2411 = (g_map_2etoListOnto(heff_rfield(v_ce_244, 0), NTAG(TAG_Nil)));
    V v_t_2412 = (g_list_2efilter_24s1018181017x1541469354(v_t_2411));
    V v_t_2413 = (g_list_2emap_24s424921060x1532378(((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str1), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str2), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str3), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str4), v_t_2412));
    V v_t_2414 = (g_map_2etoListOnto(heff_rfield(v_ce_244, 1), NTAG(TAG_Nil)));
    V v_t_2415 = (g_list_2emap_24s424921060x1532378(((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str5), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str6), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str7), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str8), v_t_2414));
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_runtime_240, NTAG(TAG_Nil)});
    V v_t_2417 = (g_list_2emap_24s1917746138x1825516092(v_provs_241));
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str9), NTAG(TAG_Nil)});
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_s_249, 5)));
    V v_t_2420 = (g_list_2emap_24s1173914895x100384474(v_t_2419));
    V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_s_249, 6)));
    V v_t_2422 = (g_list_2emap_24s1173914895x100384474(v_t_2421));
    V v_t_2423 = (g_heff_2ecompile_2eemitc_2eonceInOrder(heff_dup(g_map_2eempty_get()), v_t_2422));
    V v_t_2424 = (g_list_2emap_24s2073083146x1445066245(v_t_2423));
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ems_248)));
    V v_t_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s690408737x127625622(a_0, a_1)); heff_drop(v_t_2425); r_; });
    V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_s_249, 3)));
    V v_t_2428 = (g_list_2emap_24s1173914895x100384474(v_t_2427));
    V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_s_249, 7)));
    V v_t_2430 = (g_list_2emap_24s1173914895x100384474(v_t_2429));
    V v_xs_2431 = (g_heff_2ecompile_2eemitc_2eonceInOrder(heff_dup(g_map_2eempty_get()), v_t_2430));
    V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2431));
    V v_t_2433 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2432; V r_ = (g_list_2efoldl_24s125569247x179592613(a_0, a_1)); heff_drop(v_t_2432); r_; });
    V v_t_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ems_248));
    V v_t_2435 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2434; V r_ = (g_list_2efoldl_24s1761834913x283136918(a_0, a_1)); heff_drop(v_t_2434); r_; });
    V v_t_2436 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_s_249, 2, 8)));
    V v_t_2437 = (g_list_2emap_24s1173914895x100384474(v_t_2436));
    V v_t_2438 = heff_tr(heff_apply(heff_get_n(v_ending_242, 1, 2), 1, (V[]){v_ce_244}));
    V v_t_2439 = (g_prelude_2e_2b_2b(v_t_2437, v_t_2438));
    V v_t_2440 = (g_prelude_2e_2b_2b(v_t_2435, v_t_2439));
    V v_t_2441 = (g_prelude_2e_2b_2b(v_t_2433, v_t_2440));
    V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2428, v_t_2441));
    V v_t_2443 = (g_prelude_2e_2b_2b(v_t_2426, v_t_2442));
    V v_t_2444 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2443));
    V v_t_2445 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2444));
    V v_t_2446 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2445));
    V v_t_2447 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2446));
    V v_t_2448 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2447));
    V v_t_2449 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2448));
    V v_t_2450 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2449));
    V v_x2_2451 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2450));
    switch (heff_tag_of(v_x2_2451)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str10);
    }
    case TAG_Cons: {
      V v_x_2452 = heff_field(v_x2_2451, 0);
      V v_xs_2453 = heff_field(v_x2_2451, 1);
      heff_take_n(v_x2_2451, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str11); V a_1 = v_x_2452; V a_2 = v_xs_2453; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2453); r_; });
    }
    default: return heff_nomatch(v_x2_2451);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ecompile_2eemitc_2eprogramCE_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eprogramCE(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2eceOf_str0, 4, (84, 65, 71, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eceOf_str1, 4, (76, 66, 76, 95));
Clo g_heff_2ecompile_2eemitc_2eceOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eceOf_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eceOf(V v_provs_240, V v_defs_241, V v_names_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_names_242)) {
  case TAG_MkPair: {
    V v_x_243 = heff_field(v_names_242, 0);
    v_t_245 = heff_dup(v_x_243);
    break;
  }
  default: heff_nomatch(v_names_242);
  }
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_240)));
  V v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str0); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_246; V r_ = (g_list_2efoldl_24s2093480427x456774456(a_0, a_1, a_2, a_3)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_prelude_2e_2b_2b(v_t_245, v_t_247));
  V v_xs_249 = (g_list_2efilter_24s1967523567x64647275(v_t_248));
  V v_m_2410 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_249; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_xs_249); r_; });
  V v_t_2411 = ({ V a_0 = v_m_2410; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2410); r_; });
  V v_t_2412 = (g_list_2emap_24s1937570095x2110149801(v_t_2411));
  V v_t_2413 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V a_2 = heff_dup(g_map_2eempty_get()); V r_ = (g_heff_2ecompile_2eemitc_2enumbered(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2414 = ({ V a_0 = MK_INT(10LL); V a_1 = MK_INT(65526LL); V a_2 = v_t_2412; V a_3 = v_t_2413; V a_4 = heff_dup(g_map_2eempty_get()); V r_ = (g_heff_2ecompile_2eemitc_2ehashedGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2412); r_; });
  V v_t_2417;
  switch (heff_tag_of(v_names_242)) {
  case TAG_MkPair: {
    V v_y_2416 = heff_field(v_names_242, 1);
    v_t_2417 = heff_dup(v_y_2416);
    break;
  }
  default: heff_nomatch(v_names_242);
  }
  V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_provs_240));
  V v_t_2419 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str1); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2418; V r_ = (g_list_2efoldl_24s2093480427x456774456(a_0, a_1, a_2, a_3)); heff_drop(v_t_2418); r_; });
  V v_xs_2420 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2419));
  V v_m_2421 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_2420; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_xs_2420); r_; });
  V v_t_2422 = ({ V a_0 = v_m_2421; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2421); r_; });
  V v_t_2423 = (g_list_2emap_24s1937570095x2110149801(v_t_2422));
  V v_t_2424 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(2147483647LL); V a_2 = v_t_2423; V a_3 = heff_dup(g_map_2eempty_get()); V a_4 = heff_dup(g_map_2eempty_get()); V r_ = (g_heff_2ecompile_2eemitc_2ehashedGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2423); r_; });
  V v_t_2425 = (g_list_2efoldl_24s1196401404x611901340(heff_dup(g_map_2eempty_get()), v_defs_241));
  V v_t_2426 = (g_heff_2ecompile_2eemit_2ebounceGo(v_defs_241, heff_dup(g_map_2eempty_get())));
  V v_t_2427 = (g_list_2efoldl_24s96775841x2127473534(heff_dup(g_map_2eempty_get()), v_defs_241));
  V v_t_2428 = (g_heff_2ecompile_2eemitc_2eborFix(v_defs_241, MK_INT(-1LL), v_t_2427));
  return heff_rec_n(12, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known__takes, (V[]){v_t_2414, v_t_2424, v_t_2425, v_t_2426, NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2428, heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2eemitc_2eceOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2eceOf(a[0], a[1], a[2]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
Clo g_heff_2ecompile_2eemitc_2elastDotGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elastDotGo_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2elastDotGo(V v_k_240, V v_i_241, V v_at_242) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_k_240)), heff_dup(v_i_241))) {
    heff_drop(v_k_240);
    heff_drop(v_i_241);
    return v_at_242;
  } else {
    V v_t_245;
    if (heff_intEq_c(heff_strCharCode(heff_dup(v_k_240), heff_dup(v_i_241)), MK_INT(46LL))) {
      heff_drop(v_at_242);
      v_t_245 = heff_dup(v_i_241);
    } else {
      v_t_245 = v_at_242;
    }
    V t_0 = v_k_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_245;
    v_k_240 = t_0;
    v_i_241 = t_1;
    v_at_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eemitc_2elastDotGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2elastDotGo(a[0], a[1], a[2]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2epubLine_str0, 11, (115, 116, 97, 116, 105, 99, 32, 86, 32, 103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2epubLine_str1, 5, (95, 118, 97, 108, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2epubLine_str2, 22, (115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2epubLine_str3, 11, (95, 105, 110, 105, 116, 40, 118, 111, 105, 100, 41));
HEFF_STRA(g_heff_2ecompile_2eemitc_2epubLine_str4, 22, (115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2epubLine_str5, 22, (115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40));
Clo g_heff_2ecompile_2eemitc_2epubLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epubLine_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2epubLine(V v_l_240) {
top: ;
  if (heff_strEq_c(heff_strSlice(heff_dup(v_l_240), MK_INT(0LL), MK_INT(11LL)), ((V)&g_heff_2ecompile_2eemitc_2epubLine_str0))) {
    V v_t_242 = heff_intSub(heff_strLength(heff_dup(v_l_240)), MK_INT(5LL));
    V v_t_243 = heff_strSlice(heff_dup(v_l_240), v_t_242, heff_strLength(heff_dup(v_l_240)));
    if (heff_strEq_c(v_t_243, ((V)&g_heff_2ecompile_2eemitc_2epubLine_str1))) {
      if (heff_strEq_c(heff_strSlice(heff_dup(v_l_240), MK_INT(0LL), MK_INT(22LL)), ((V)&g_heff_2ecompile_2eemitc_2epubLine_str2))) {
        return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
      } else {
        return v_l_240;
      }
    } else {
      V v_x3_246 = (g_prelude_2eindexFrom(((V)&g_heff_2ecompile_2eemitc_2epubLine_str3), heff_dup(v_l_240), MK_INT(0LL)));
      V v_x1_248;
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        v_x1_248 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_x3_246, 0ULL, 1);
        v_x1_248 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x3_246);
      }
      switch (heff_tag_of(v_x1_248)) {
      case TAG_True: {
        if (heff_strEq_c(heff_strSlice(heff_dup(v_l_240), MK_INT(0LL), MK_INT(22LL)), ((V)&g_heff_2ecompile_2eemitc_2epubLine_str4))) {
          return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
        } else {
          return v_l_240;
        }
      }
      case TAG_False: {
        return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
      }
      default: return heff_nomatch(v_x1_248);
      }
    }
  } else {
    if (heff_strEq_c(heff_strSlice(heff_dup(v_l_240), MK_INT(0LL), MK_INT(22LL)), ((V)&g_heff_2ecompile_2eemitc_2epubLine_str5))) {
      return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
    } else {
      return v_l_240;
    }
  }
}
V g_heff_2ecompile_2eemitc_2epubLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epubLine(a[0]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2enumbersOf_str0, 4, (84, 65, 71, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2enumbersOf_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2enumbersOf_str2, 8, (35, 100, 101, 102, 105, 110, 101, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2enumbersOf_str3, 1, (32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2enumbersOf_str4, 4, (76, 66, 76, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2enumbersOf_str5, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2enumbersOf_str6, 8, (35, 100, 101, 102, 105, 110, 101, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2enumbersOf_str7, 1, (32));
V g_heff_2ecompile_2eemitc_2enumbersOf_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2enumbersOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2enumbersOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enumbersOf_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2enumbersOf(V v_ce_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_ts_242 = heff_field(v_x2_241, 0);
    V v_ls_243 = heff_field(v_x2_241, 1);
    V v_m_244 = (g_list_2efoldl_24s657006386x1833506039(heff_dup(g_map_2eempty_get()), v_ts_242));
    V v_t_245 = ({ V a_0 = v_m_244; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_244); r_; });
    V v_t_246 = (g_list_2emap_24s1937570095x2110149801(v_t_245));
    V v_t_247 = (g_list_2efilter_24s1967523567x64647275(v_t_246));
    V v_t_2413 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2enumbersOf_lam0, 1, 1, (V[]){heff_dup(v_ce_240)}), v_t_247));
    V v_m_2414 = (g_list_2efoldl_24s657006386x1833506039(heff_dup(g_map_2eempty_get()), v_ls_243));
    V v_t_2415 = ({ V a_0 = v_m_2414; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2414); r_; });
    V v_t_2416 = (g_list_2emap_24s1937570095x2110149801(v_t_2415));
    V v_t_2422 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2enumbersOf_lam1, 1, 1, (V[]){v_ce_240}), v_t_2416));
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2413, v_t_2422);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2enumbersOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2enumbersOf(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2ecompile_2eemitc_2enumbersOf_lam0(V self, V *args) {
  V v_t_248 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str0), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_t_248), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str1))));
  V v_x2_2410 = ({ V a_0 = v_t_248; V b_1 = heff_get_n(v_ce_240, 0, 12); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2412;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nothing: {
    v_t_2412 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    heff_take_n(v_x2_2410, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str2), heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str3), heff_intShow(v_t_2412))));
}
V g_heff_2ecompile_2eemitc_2enumbersOf_lam1(V self, V *args) {
  V v_l_2417 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str4), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_l_2417), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str5))));
  V v_x2_2419 = ({ V a_0 = v_l_2417; V b_1 = heff_get_n(v_ce_240, 1, 12); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2421;
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_Nothing: {
    v_t_2421 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    heff_take_n(v_x2_2419, 1ULL, 1);
    v_t_2421 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_x2_2419);
  }
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str6), heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str7), heff_intShow(v_t_2421))));
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str0, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str2, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str3, 11, (95, 103, 101, 116, 40, 118, 111, 105, 100, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str4, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str5, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str6, 4, (118, 111, 105, 100));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str7, 1, (86));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str8, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str9, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str10, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str11, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str12, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str13, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str14, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str15, 2, (86, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str16, 21, (95, 101, 110, 116, 114, 121, 40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str17, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str18, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str19, 11, (101, 120, 116, 101, 114, 110, 32, 67, 108, 111, 32));
HEFF_STRA(g_heff_2ecompile_2eemitc_2edeclOf_str20, 5, (95, 99, 108, 111, 59));
Clo g_heff_2ecompile_2eemitc_2edeclOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2edeclOf_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2edeclOf(V v_ce_240, V v_k_241) {
top: ;
  V v_t_242 = ({ V a_0 = heff_dup(v_k_241); V b_1 = heff_get_n(v_ce_240, 2, 12); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_t_243 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str0), (g_heff_2ecompile_2eemitc_2emangleW(v_k_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str1))));
    V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str2), heff_strAppend(v_t_243, ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str3)));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  }
  case TAG_Just: {
    V v_n_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str4), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_k_241), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str5))));
    V v_t_2411;
    if (heff_intEq_c(heff_dup(v_n_245), MK_INT(0LL))) {
      heff_drop(v_n_245);
      v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str6);
    } else {
      V v_x2_248 = (g_list_2ereplicate(v_n_245, ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str7)));
      switch (heff_tag_of(v_x2_248)) {
      case TAG_Nil: {
        v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str8);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_x2_248, 0);
        V v_xs_2410 = heff_field(v_x2_248, 1);
        heff_take_n(v_x2_248, 3ULL, 2);
        v_t_2411 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str9); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
        break;
      }
      default: heff_nomatch(v_x2_248);
      }
    }
    V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str10), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str11), heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str12)))));
    V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str13), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_k_241), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str14))));
    V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str15), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str16)));
    V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str17), (g_heff_2ecompile_2eemitc_2emangleW(v_k_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str18))));
    V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str19), heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str20)));
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2417})});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eemitc_2edeclOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2edeclOf(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2eownLines_str0, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eownLines_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eownLines_str2, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eownLines_str3, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eownLines_str4, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eownLines_str5, 0, (0));
Clo g_heff_2ecompile_2eemitc_2eownLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eownLines_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2eownLines(V v_s_240, V v_strs_241, V v_protos_242, V v_lams_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_d_245 = heff_field(v_x5_244, 0);
    V v_e_246 = heff_field(v_x5_244, 1);
    V v_o_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eownLines_str0), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eownLines_str1))));
    V v_x2_248 = (g_map_2elookup_24s1546226666x2146984184(v_o_247, v_strs_241));
    V v_t_2410;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nothing: {
      v_t_2410 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_249 = heff_field(v_x2_248, 0);
      heff_take_n(v_x2_248, 1ULL, 1);
      v_t_2410 = v_x_249;
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_o_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eownLines_str2), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eownLines_str3))));
    V v_x2_2412 = (g_map_2elookup_24s1546226666x2146984184(v_o_2411, v_protos_242));
    V v_t_2414;
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nothing: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      heff_take_n(v_x2_2412, 1ULL, 1);
      v_t_2414 = v_x_2413;
      break;
    }
    default: heff_nomatch(v_x2_2412);
    }
    V v_t_2415 = (g_list_2emap_24s380834591x871125279(v_t_2414));
    V v_t_2416 = (g_list_2efilter_24s1727592350x8580145(heff_dup(heff_rfield(v_e_246, 0))));
    V v_t_2417 = (g_list_2emap_24s1328195927x21044528(MK_INT(7LL), v_t_2416));
    V v_t_2418 = (g_list_2emap_24s380834591x871125279(heff_dup(heff_rfield(v_e_246, 1))));
    V v_o_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eownLines_str4), (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eownLines_str5))));
    V v_x2_2420 = (g_map_2elookup_24s1546226666x2146984184(v_o_2419, v_lams_243));
    V v_t_2422;
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_Nothing: {
      v_t_2422 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      heff_take_n(v_x2_2420, 1ULL, 1);
      v_t_2422 = v_x_2421;
      break;
    }
    default: heff_nomatch(v_x2_2420);
    }
    V v_t_2423 = (g_list_2emap_24s380834591x871125279(v_t_2422));
    V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2423));
    V v_t_2425 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2424));
    V v_t_2426 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2425));
    return (g_prelude_2e_2b_2b(v_t_2410, v_t_2426));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2eownLines(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); heff_drop(a[1]); heff_drop(a[2]); heff_drop(a[3]); heff_drop(a[4]); return r;
}
Clo g_heff_2ecompile_2eemitc_2ezipDE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ezipDE_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2ezipDE(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x1_240, 0);
    V v_ds_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_d_242);
      heff_drop(v_ds_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_e_244 = heff_field(v_x2_241, 0);
      V v_es_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_d_242, v_e_244}), (g_heff_2ecompile_2eemitc_2ezipDE(v_ds_243, v_es_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2ezipDE_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ezipDE(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2eusedBy_str0, 2, (103, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2eusedBy_str1, 0, (0));
V g_heff_2ecompile_2eemitc_2eusedBy_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eusedBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eusedBy_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eusedBy(V v_m_240, V v_ps_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_241));
  V v_xs_2412 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2eusedBy_lam0, 2, 1, (V[]){heff_dup(v_m_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
  V v_m_2413 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_2412; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_xs_2412); r_; });
  V v_t_2414 = ({ V a_0 = v_m_2413; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2413); r_; });
  return (g_list_2emap_24s1937570095x2110149801(v_t_2414));
}
V g_heff_2ecompile_2eemitc_2eusedBy_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2eusedBy(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecompile_2eemitc_2eusedBy_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_k_247;
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkPair: {
    V v_d_245 = heff_field(v_x_244, 0);
    heff_take_n(v_x_244, 1ULL, 2);
    v_k_247 = heff_get_n(v_d_245, 0, 3);
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V v_o_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eusedBy_str0), (g_heff_2ecompile_2eemitc_2emangleW(v_k_247, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eusedBy_str1))));
  V v_x2_249 = ({ V a_0 = v_o_248; V a_1 = v_m_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_m_240); r_; });
  V v_t_2411;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nothing: {
    v_t_2411 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    heff_take_n(v_x2_249, 1ULL, 1);
    v_t_2411 = v_x_2410;
    break;
  }
  default: heff_nomatch(v_x2_249);
  }
  return (g_prelude_2e_2b_2b(v_t_2411, v_acc_243));
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2emodulePart_str0, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2emodulePart_str1, 1, (10));
HEFF_STRA(g_heff_2ecompile_2eemitc_2emodulePart_str2, 2, (46, 99));
V g_heff_2ecompile_2eemitc_2emodulePart_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2emodulePart_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2emodulePart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emodulePart_entry, 9, 0};

V g_heff_2ecompile_2eemitc_2emodulePart(V v_head_240, V v_ce_241, V v_s_242, V v_shapes_243, V v_prims_244, V v_strs_245, V v_protos_246, V v_lams_247, V v_x9_248) {
top: ;
  switch (heff_tag_of(v_x9_248)) {
  case TAG_MkPair: {
    V v_m_249 = heff_field(v_x9_248, 0);
    V v_ps_2410 = heff_field(v_x9_248, 1);
    V v_ru_24x9_248_24MkPair = heff_take_reuse_n(v_x9_248, 3ULL, 2);
    V v_es_2411 = (g_list_2emap_24s1691650970x173345163(heff_dup(v_ps_2410)));
    V v_t_2412 = heff_tag_at_n(v_ru_24x9_248_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2411));
    V v_t_2414 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2412, v_t_2413));
    V v_t_2415 = ({ V a_0 = heff_dup(v_ce_241); V a_1 = v_t_2414; V r_ = (g_heff_2ecompile_2eemitc_2enumbersOf(a_0, a_1)); heff_drop(v_t_2414); r_; });
    V v_t_2416 = (g_heff_2ecompile_2eemitc_2eusedBy(v_shapes_243, heff_dup(v_ps_2410)));
    V v_t_2417 = (g_list_2emap_24s2073083146x1445066245(v_t_2416));
    V v_xs_2418 = (g_heff_2ecompile_2eemitc_2eusedBy(v_prims_244, heff_dup(v_ps_2410)));
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2418));
    V v_t_2420 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s125569247x179592613(a_0, a_1)); heff_drop(v_t_2419); r_; });
    V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_2410)));
    V v_xs_2422 = (g_list_2efoldl_24s907092709x2006193176(NTAG(TAG_Nil), v_t_2421));
    V v_m_2423 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_2422; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_xs_2422); r_; });
    V v_t_2424 = ({ V a_0 = v_m_2423; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2423); r_; });
    V v_xs_2425 = (g_list_2emap_24s1937570095x2110149801(v_t_2424));
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2425));
    V v_t_2430 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2emodulePart_lam0, 2, 1, (V[]){v_ce_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2426; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2426); r_; });
    V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2410));
    V v_t_2435 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2emodulePart_lam1, 2, 4, (V[]){heff_dup(v_s_242), heff_dup(v_strs_245), heff_dup(v_protos_246), heff_dup(v_lams_247)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2431; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2431); r_; });
    V v_t_2436 = (g_prelude_2e_2b_2b(v_t_2430, v_t_2435));
    V v_t_2437 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2436));
    V v_t_2438 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2437));
    V v_t_2439 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2438));
    V v_x2_2440 = (g_prelude_2e_2b_2b(v_head_240, v_t_2439));
    V v_t_2443;
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2emodulePart_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_xs_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      v_t_2443 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2emodulePart_str1); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2440);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_m_249, ((V)&g_heff_2ecompile_2eemitc_2emodulePart_str2)), v_t_2443});
  }
  default: return heff_nomatch(v_x9_248);
  }
}
V g_heff_2ecompile_2eemitc_2emodulePart_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemitc_2emodulePart(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]); heff_drop(a[2]); heff_drop(a[3]); heff_drop(a[4]); heff_drop(a[5]); heff_drop(a[6]); heff_drop(a[7]); return r;
}
V g_heff_2ecompile_2eemitc_2emodulePart_lam0(V self, V *args) {
  V v_acc_2427 = args[0];
  V v_x_2428 = args[1];
  V v_ce_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = (g_heff_2ecompile_2eemitc_2edeclOf(v_ce_241, v_x_2428));
  return (g_prelude_2e_2b_2b(v_t_2429, v_acc_2427));
}
V g_heff_2ecompile_2eemitc_2emodulePart_lam1(V self, V *args) {
  V v_acc_2432 = args[0];
  V v_x_2433 = args[1];
  V v_s_242 = heff_env(self)[0];
  V v_strs_245 = heff_env(self)[1];
  V v_protos_246 = heff_env(self)[2];
  V v_lams_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2434 = ({ V a_0 = v_s_242; V a_1 = v_strs_245; V a_2 = v_protos_246; V a_3 = v_lams_247; V a_4 = v_x_2433; V r_ = (g_heff_2ecompile_2eemitc_2eownLines(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_242); heff_drop(v_strs_245); heff_drop(v_protos_246); heff_drop(v_lams_247); heff_drop(v_x_2433); r_; });
  return (g_prelude_2e_2b_2b(v_t_2434, v_acc_2432));
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2eentryPart_str0, 10, (114, 117, 110, 36, 109, 97, 105, 110, 46, 99));

static V g_heff_2ecompile_2eemitc_2eentryPart_val;
static int g_heff_2ecompile_2eemitc_2eentryPart_st;
static V g_heff_2ecompile_2eemitc_2eentryPart_init(void) {
  return ((V)&g_heff_2ecompile_2eemitc_2eentryPart_str0);
}
V g_heff_2ecompile_2eemitc_2eentryPart_get(void) {
  if (g_heff_2ecompile_2eemitc_2eentryPart_st == 2) return g_heff_2ecompile_2eemitc_2eentryPart_val;
  if (g_heff_2ecompile_2eemitc_2eentryPart_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eemitc_2eentryPart_st = 1;
  g_heff_2ecompile_2eemitc_2eentryPart_val = heff_tr(g_heff_2ecompile_2eemitc_2eentryPart_init());
  g_heff_2ecompile_2eemitc_2eentryPart_st = 2;
  return g_heff_2ecompile_2eemitc_2eentryPart_val;
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2epartsWith_str0, 42, (47, 47, 32, 71, 101, 110, 101, 114, 97, 116, 101, 100, 32, 102, 114, 111, 109, 32, 72, 105, 112, 112, 111, 103, 114, 105, 102, 102, 59, 32, 100, 111, 32, 110, 111, 116, 32, 101, 100, 105, 116, 46));
HEFF_STRA(g_heff_2ecompile_2eemitc_2epartsWith_str1, 25, (86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40, 86, 32, 112, 44, 32, 86, 32, 107, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemitc_2epartsWith_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2epartsWith_str3, 1, (10));
HEFF_STRA(g_heff_2ecompile_2eemitc_2epartsWith_str4, 4, (84, 65, 71, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2epartsWith_str5, 4, (76, 66, 76, 95));
HEFF_STRA(g_heff_2ecompile_2eemitc_2epartsWith_str6, 17, (35, 105, 110, 99, 108, 117, 100, 101, 32, 34, 104, 101, 102, 102, 46, 104, 34));
HEFF_STRA(g_heff_2ecompile_2eemitc_2epartsWith_str7, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemitc_2epartsWith_str8, 1, (10));
HEFF_STRA(g_heff_2ecompile_2eemitc_2epartsWith_str9, 17, (35, 105, 110, 99, 108, 117, 100, 101, 32, 34, 104, 101, 102, 102, 46, 104, 34));
HEFF_STRA(g_heff_2ecompile_2eemitc_2epartsWith_str10, 42, (47, 47, 32, 71, 101, 110, 101, 114, 97, 116, 101, 100, 32, 102, 114, 111, 109, 32, 72, 105, 112, 112, 111, 103, 114, 105, 102, 102, 59, 32, 100, 111, 32, 110, 111, 116, 32, 101, 100, 105, 116, 46));
HEFF_STRA(g_heff_2ecompile_2eemitc_2epartsWith_str11, 17, (35, 100, 101, 102, 105, 110, 101, 32, 72, 69, 70, 70, 95, 80, 65, 82, 84));
HEFF_STRA(g_heff_2ecompile_2eemitc_2epartsWith_str12, 6, (104, 101, 102, 102, 46, 104));
Clo g_heff_2ecompile_2eemitc_2epartsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epartsWith_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2epartsWith(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243, V v_ce_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_MkPair: {
    V v_ems_246 = heff_field(v_x6_245, 0);
    V v_s_247 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24MkPair = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    V v_t_248 = heff_tag_at_n(v_ru_24x6_245_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str0), NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str1), NTAG(TAG_Nil)});
    V v_t_2410 = (g_prelude_2e_2b_2b(heff_take_field(v_ending_242, 0), heff_tag_n(TAG_Cons, 2, (V[]){v_runtime_240, v_t_249})));
    V v_x2_2411 = (g_prelude_2e_2b_2b(v_t_248, v_t_2410));
    V v_t_2414;
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_Nil: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_xs_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str3); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2411);
    }
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_241)));
    V v_t_2416 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str4); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2415; V r_ = (g_list_2efoldl_24s2093480427x456774456(a_0, a_1, a_2, a_3)); heff_drop(v_t_2415); r_; });
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_241)));
    V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str5); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2417; V r_ = (g_list_2efoldl_24s2093480427x456774456(a_0, a_1, a_2, a_3)); heff_drop(v_t_2417); r_; })});
    V v_t_2419 = ({ V a_0 = heff_dup(v_ce_244); V a_1 = v_t_2418; V r_ = (g_heff_2ecompile_2eemitc_2enumbersOf(a_0, a_1)); heff_drop_tag(v_t_2418, 2); r_; });
    V v_t_2420 = (g_heff_2ecompile_2eemitc_2edeclOf(heff_dup(v_ce_244), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get())));
    V v_t_2421 = (g_list_2emap_24s1917746138x1825516092(v_provs_241));
    V v_t_2422 = heff_tr(heff_apply(heff_get_n(v_ending_242, 1, 2), 1, (V[]){heff_dup(v_ce_244)}));
    V v_t_2423 = (g_list_2emap_24s380834591x871125279(v_t_2422));
    V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2423));
    V v_t_2425 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2424));
    V v_x2_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str6), (g_prelude_2e_2b_2b(v_t_2419, v_t_2425))});
    V v_t_2429;
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_Nil: {
      v_t_2429 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2427 = heff_field(v_x2_2426, 0);
      V v_xs_2428 = heff_field(v_x2_2426, 1);
      heff_take_n(v_x2_2426, 3ULL, 2);
      v_t_2429 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str8); V a_1 = v_x_2427; V a_2 = v_xs_2428; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2428); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2426);
    }
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str9), NTAG(TAG_Nil)});
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str10), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str11), v_t_2430})});
    V v_t_2432 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_s_247, 6))));
    V v_t_2433 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_s_247, 7))));
    V v_t_2434 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_s_247, 5))));
    V v_t_2435 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_s_247, 3))));
    V v_t_2436 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_s_247, 2))));
    V v_t_2437 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2emodulePart_clo), 8, (V[]){v_t_2431, v_ce_244, v_s_247, v_t_2432, v_t_2433, v_t_2434, v_t_2435, v_t_2436}));
    V v_ps_2438 = (g_heff_2ecompile_2eemitc_2ezipDE(v_defs_243, v_ems_246));
    V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2438));
    V v_m_2440 = (g_list_2efoldl_24s1685809585x983762522(MK_INT(0LL), MK_INT(-1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(-1LL), MK_INT(0LL), MK_INT(0LL), heff_dup(g_map_2eempty_get()), v_t_2439));
    V v_t_2441 = ({ V a_0 = v_m_2440; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2440); r_; });
    V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2ecompile_2eemitc_2eentryPart_get()), v_t_2429}), (g_list_2emap(v_t_2437, v_t_2441))});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str12), v_t_2414}), v_t_2442});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ecompile_2eemitc_2epartsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epartsWith(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ecompile_2eemitc_2eprogramParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprogramParts_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eprogramParts(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243) {
top: ;
  V v_es_244 = (g_list_2emap_24s1801850472x1352108398(heff_dup(v_defs_243)));
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_244));
  V v_t_247 = (g_list_2efoldl_24s1659194469x1936830512(v_t_245, v_t_246));
  V v_ce_248 = ({ V a_0 = heff_dup(v_provs_241); V a_1 = v_defs_243; V a_2 = v_t_247; V r_ = (g_heff_2ecompile_2eemitc_2eceOf(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  V v_t_249 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2edefOwn_clo), 1, (V[]){heff_dup(v_ce_248)}));
  V v_t_2410 = (g_heff_2ecompile_2eemitc_2etraverseC(v_t_249, heff_dup(v_defs_243)));
  V v_t_2411 = heff_tr(heff_apply(v_t_2410, 1, (V[]){heff_dup(g_heff_2ecompile_2eemitc_2eemptyCS_get())}));
  return (g_heff_2ecompile_2eemitc_2epartsWith(v_runtime_240, v_provs_241, v_ending_242, v_defs_243, v_ce_248, v_t_2411));
}
V g_heff_2ecompile_2eemitc_2eprogramParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eprogramParts(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eemitc_2eoutputOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eoutputOf_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eoutputOf(V v_runtime_240, V v_provs_241, V v_ending_242, V v_l_243) {
top: ;
  V v_defs_244 = heff_take_field(v_l_243, 0);
  V v_es_245 = (g_list_2emap_24s1801850472x1352108398(heff_dup(v_defs_244)));
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_245));
  V v_names_248 = (g_list_2efoldl_24s1659194469x1936830512(v_t_246, v_t_247));
  V v_t_249 = ({ V a_0 = heff_dup(v_provs_241); V a_1 = v_defs_244; V a_2 = v_names_248; V r_ = (g_heff_2ecompile_2eemitc_2eceOf(a_0, a_1, a_2)); heff_drop(v_names_248); r_; });
  V v_t_2410 = (g_heff_2ecompile_2eemitc_2eprogramCE(v_runtime_240, v_provs_241, v_ending_242, v_defs_244, v_t_249));
  return heff_rec_n(2, shape_source__errors, (V[]){v_t_2410, heff_get_n(v_l_243, 1, 2)});
}
V g_heff_2ecompile_2eemitc_2eoutputOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eoutputOf(a[0], a[1], a[2], a[3]);
}
HEFF_STRA(g_heff_2ecompile_2eemitc_2echeckOut_str0, 18, (35, 100, 101, 102, 105, 110, 101, 32, 72, 69, 70, 70, 95, 67, 72, 69, 67, 75));
Clo g_heff_2ecompile_2eemitc_2echeckOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2echeckOut_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2echeckOut(V v_runtime_240, V v_exports_241, V v_l_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckOut_str0), NTAG(TAG_Nil)});
  V v_t_244 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_clo), 2, (V[]){v_exports_241, heff_dup(heff_rfield(v_l_242, 0))}));
  V v_ending_245 = heff_rec_n(2, shape_prefix__end, (V[]){v_t_243, v_t_244});
  V v_defs_246 = heff_take_field(v_l_242, 0);
  V v_es_247 = (g_list_2emap_24s1801850472x1352108398(heff_dup(v_defs_246)));
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_247));
  V v_names_2410 = (g_list_2efoldl_24s1659194469x1936830512(v_t_248, v_t_249));
  V v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_defs_246; V a_2 = v_names_2410; V r_ = (g_heff_2ecompile_2eemitc_2eceOf(a_0, a_1, a_2)); heff_drop(v_names_2410); r_; });
  V v_t_2412 = (g_heff_2ecompile_2eemitc_2eprogramCE(v_runtime_240, NTAG(TAG_Nil), v_ending_245, v_defs_246, v_t_2411));
  return heff_rec_n(2, shape_source__errors, (V[]){v_t_2412, heff_get_n(v_l_242, 1, 2)});
}
V g_heff_2ecompile_2eemitc_2echeckOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2echeckOut(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecatMaybesC_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2ecatMaybesC(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2ecompile_2eemitc_2ecatMaybesC(v_rest_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2ecatMaybesC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ecatMaybesC(a[0]);
}