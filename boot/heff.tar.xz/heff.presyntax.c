// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_INominal 43674
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_IVar 40993
#define TAG_ImplicitParam 51130
#define TAG_IntWord 51777
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_PatAs 19989
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_SetField 47531
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StringWord 15530
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_TagVariant 25174
#define TAG_TypeWord 10401
#define LBL_args 9498020
#define LBL_decl 9574769
#define LBL_e 319
#define LBL_end 310101
#define LBL_head 9693863
#define LBL_start 311115900
static uint32_t shape_e__decl[] = {LBL_e, LBL_decl};
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2epresyntax_2ealtOf(V, V);
V g_heff_2epresyntax_2ealtOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2ealtOf_clo;
V g_heff_2epresyntax_2ealtOf_24s1311504944x45681609(V);
V g_heff_2epresyntax_2ealtOf_24s1311504944x45681609_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2ealtOf_24s1311504944x45681609_clo;
V g_heff_2epresyntax_2eannLamOf(V, V, V, V, V);
V g_heff_2epresyntax_2eannLamOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eannLamOf_clo;
V g_heff_2epresyntax_2eapp(V, V);
V g_heff_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eapp_clo;
V g_heff_2epresyntax_2eappOf(V, V, V, V);
V g_heff_2epresyntax_2eappOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eappOf_clo;
V g_heff_2epresyntax_2eappOf_24s269192126x2121543052(V, V, V);
V g_heff_2epresyntax_2eappOf_24s269192126x2121543052_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eappOf_24s269192126x2121543052_clo;
V g_heff_2epresyntax_2eargOf(V, V);
V g_heff_2epresyntax_2eargOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eargOf_clo;
V g_heff_2epresyntax_2eargOf_24s1825882790x1322352207(V);
V g_heff_2epresyntax_2eargOf_24s1825882790x1322352207_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eargOf_24s1825882790x1322352207_clo;
V g_heff_2epresyntax_2echkDe_24s1632343938x112901564(V, V);
V g_heff_2epresyntax_2echkDe_24s1632343938x112901564_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2echkDe_24s1632343938x112901564_clo;
V g_heff_2epresyntax_2echkNode_24s769858677x299167023(V);
V g_heff_2epresyntax_2echkNode_24s769858677x299167023_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2echkNode_24s769858677x299167023_clo;
V g_heff_2epresyntax_2eclassifier_get(void);
V g_heff_2epresyntax_2eclassify_get(void);
V g_heff_2epresyntax_2eclassifyDeclF(V, V);
V g_heff_2epresyntax_2eclassifyDeclF_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eclassifyDeclF_clo;
V g_heff_2epresyntax_2eclassifyDeclF_24s1000182462x736866817(V);
V g_heff_2epresyntax_2eclassifyDeclF_24s1000182462x736866817_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eclassifyDeclF_24s1000182462x736866817_clo;
V g_heff_2epresyntax_2eclassifyTermF(V, V);
V g_heff_2epresyntax_2eclassifyTermF_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eclassifyTermF_clo;
V g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(V);
V g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823_clo;
V g_heff_2epresyntax_2edeclN_24s819476248x1348827013(V);
V g_heff_2epresyntax_2edeclN_24s819476248x1348827013_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2edeclN_24s819476248x1348827013_clo;
V g_heff_2epresyntax_2edoFrom(V, V, V);
V g_heff_2epresyntax_2edoFrom_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2edoFrom_clo;
V g_heff_2epresyntax_2edoStep(V, V, V);
V g_heff_2epresyntax_2edoStep_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2edoStep_clo;
V g_heff_2epresyntax_2eequationOf(V, V);
V g_heff_2epresyntax_2eequationOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eequationOf_clo;
V g_heff_2epresyntax_2eequationOf_24s1475199660x271778313(V);
V g_heff_2epresyntax_2eequationOf_24s1475199660x271778313_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eequationOf_24s1475199660x271778313_clo;
V g_heff_2epresyntax_2efieldDeclN_24s28815368x1200642142(V);
V g_heff_2epresyntax_2efieldDeclN_24s28815368x1200642142_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2efieldDeclN_24s28815368x1200642142_clo;
V g_heff_2epresyntax_2efieldDeclOf(V, V);
V g_heff_2epresyntax_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2efieldDeclOf_clo;
V g_heff_2epresyntax_2efieldDeclOf_24s2049272031x2094854488(V);
V g_heff_2epresyntax_2efieldDeclOf_24s2049272031x2094854488_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2efieldDeclOf_24s2049272031x2094854488_clo;
V g_heff_2epresyntax_2efieldSetOf(V, V);
V g_heff_2epresyntax_2efieldSetOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2efieldSetOf_clo;
V g_heff_2epresyntax_2efieldSetOf_24s1980909823x69898947(V);
V g_heff_2epresyntax_2efieldSetOf_24s1980909823x69898947_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2efieldSetOf_24s1980909823x69898947_clo;
V g_heff_2epresyntax_2einfApp(V, V);
V g_heff_2epresyntax_2einfApp_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2einfApp_clo;
V g_heff_2epresyntax_2einfDe_24s1088488601x1677399249(V, V);
V g_heff_2epresyntax_2einfDe_24s1088488601x1677399249_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2einfDe_24s1088488601x1677399249_clo;
V g_heff_2epresyntax_2einfNode_24s226003340x1863664708(V);
V g_heff_2epresyntax_2einfNode_24s226003340x1863664708_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2einfNode_24s226003340x1863664708_clo;
V g_heff_2epresyntax_2einfSpineOf(V);
V g_heff_2epresyntax_2einfSpineOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2einfSpineOf_clo;
V g_heff_2epresyntax_2elastOr(V, V);
V g_heff_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2elastOr_clo;
V g_heff_2epresyntax_2eparamOf(V, V);
V g_heff_2epresyntax_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eparamOf_clo;
V g_heff_2epresyntax_2eparamOf_24s1115423126x2093765648(V);
V g_heff_2epresyntax_2eparamOf_24s1115423126x2093765648_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eparamOf_24s1115423126x2093765648_clo;
V g_heff_2epresyntax_2epatSpineOf(V);
V g_heff_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2epatSpineOf_clo;
V g_heff_2epresyntax_2epiBinderOf(V, V);
V g_heff_2epresyntax_2epiBinderOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2epiBinderOf_clo;
V g_heff_2epresyntax_2epiBinderOf_24s113941090x157037166(V);
V g_heff_2epresyntax_2epiBinderOf_24s113941090x157037166_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2epiBinderOf_24s113941090x157037166_clo;
V g_heff_2epresyntax_2epiN_24s1811034599x1720743734(V);
V g_heff_2epresyntax_2epiN_24s1811034599x1720743734_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2epiN_24s1811034599x1720743734_clo;
V g_heff_2epresyntax_2espineOf(V);
V g_heff_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2espineOf_clo;
V g_heff_2epresyntax_2etoInferable(V);
V g_heff_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2etoInferable_clo;
V g_heff_2epresyntax_2etypDe_24s203630508x1828297368(V, V);
V g_heff_2epresyntax_2etypDe_24s203630508x1828297368_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2etypDe_24s203630508x1828297368_clo;
V g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(V);
V g_heff_2epresyntax_2etypNode_24s1488628894x2014562827_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2etypNode_24s1488628894x2014562827_clo;
V g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(V, V);
V g_heff_2epresyntax_2etypNom_24s2062588653x1022079868_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2etypNom_24s2062588653x1022079868_clo;
V g_heff_2epresyntax_2evariantOf(V, V);
V g_heff_2epresyntax_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2evariantOf_clo;
V g_heff_2epresyntax_2evariantOf_24s1987057975x582429604(V);
V g_heff_2epresyntax_2evariantOf_24s1987057975x582429604_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2evariantOf_24s1987057975x582429604_clo;
V g_heff_2epresyntax_2ewatchOf(V);
V g_heff_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2ewatchOf_clo;
V g_heff_2epresyntax_2ewordOf(V, V);
V g_heff_2epresyntax_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2ewordOf_clo;
V g_prelude_2econcatList(V, V);
V g_prelude_2econcatList_entry(V self, V *a);
extern Clo g_prelude_2econcatList_clo;
V g_prelude_2efoldl_24s1546929672x1472202881(V, V);
V g_prelude_2efoldl_24s1546929672x1472202881_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1546929672x1472202881_clo;
V g_prelude_2emap(V, V);
V g_prelude_2emap_entry(V self, V *a);
extern Clo g_prelude_2emap_clo;
V g_prelude_2emap_24s1097491904x416138181(V);
V g_prelude_2emap_24s1097491904x416138181_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1097491904x416138181_clo;
V g_prelude_2emap_24s1170054603x901729204(V);
V g_prelude_2emap_24s1170054603x901729204_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1170054603x901729204_clo;
V g_prelude_2emap_24s1276521852x477277004(V);
V g_prelude_2emap_24s1276521852x477277004_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1276521852x477277004_clo;
V g_prelude_2emap_24s1340987657x1082998826(V);
V g_prelude_2emap_24s1340987657x1082998826_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1340987657x1082998826_clo;
V g_prelude_2emap_24s1439972680x346961496(V);
V g_prelude_2emap_24s1439972680x346961496_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1439972680x346961496_clo;
V g_prelude_2emap_24s1449394102x85632237(V);
V g_prelude_2emap_24s1449394102x85632237_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1449394102x85632237_clo;
V g_prelude_2emap_24s1472739944x318103388(V);
V g_prelude_2emap_24s1472739944x318103388_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1472739944x318103388_clo;
V g_prelude_2emap_24s1491261851x220013917(V);
V g_prelude_2emap_24s1491261851x220013917_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1491261851x220013917_clo;
V g_prelude_2emap_24s1548800724x1090490128(V);
V g_prelude_2emap_24s1548800724x1090490128_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1548800724x1090490128_clo;
V g_prelude_2emap_24s271878692x1909813941(V);
V g_prelude_2emap_24s271878692x1909813941_entry(V self, V *a);
extern Clo g_prelude_2emap_24s271878692x1909813941_clo;
V g_prelude_2emap_24s354657900x1587558784(V);
V g_prelude_2emap_24s354657900x1587558784_entry(V self, V *a);
extern Clo g_prelude_2emap_24s354657900x1587558784_clo;
V g_prelude_2emap_24s504509305x1309437118(V);
V g_prelude_2emap_24s504509305x1309437118_entry(V self, V *a);
extern Clo g_prelude_2emap_24s504509305x1309437118_clo;
V g_prelude_2emap_24s588898442x1763987159(V);
V g_prelude_2emap_24s588898442x1763987159_entry(V self, V *a);
extern Clo g_prelude_2emap_24s588898442x1763987159_clo;
V g_prelude_2emap_24s67362943x99565768(V);
V g_prelude_2emap_24s67362943x99565768_entry(V self, V *a);
extern Clo g_prelude_2emap_24s67362943x99565768_clo;
V g_prelude_2emap_24s684503405x117589606(V);
V g_prelude_2emap_24s684503405x117589606_entry(V self, V *a);
extern Clo g_prelude_2emap_24s684503405x117589606_clo;
V g_prelude_2emap_24s760761549x776536213(V);
V g_prelude_2emap_24s760761549x776536213_entry(V self, V *a);
extern Clo g_prelude_2emap_24s760761549x776536213_clo;
V g_prelude_2emap_24s7771255x22951525(V);
V g_prelude_2emap_24s7771255x22951525_entry(V self, V *a);
extern Clo g_prelude_2emap_24s7771255x22951525_clo;
V g_prelude_2emap_24s842967967x223843022(V);
V g_prelude_2emap_24s842967967x223843022_entry(V self, V *a);
extern Clo g_prelude_2emap_24s842967967x223843022_clo;
V g_prelude_2emap_24s914971304x1928750522(V);
V g_prelude_2emap_24s914971304x1928750522_entry(V self, V *a);
extern Clo g_prelude_2emap_24s914971304x1928750522_clo;
Clo g_heff_2epresyntax_2elastOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2elastOr_entry, 2, 0};

V g_heff_2epresyntax_2elastOr(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop(v_z_240);
      return heff_dup(v_x_242);
    }
    case TAG_Cons: {
      V t_0 = v_z_240;
      V t_1 = v_x22_243;
      v_z_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2epresyntax_2elastOr_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2epresyntax_2elastOr(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2epresyntax_2eapp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2eapp_entry, 2, 0};

V g_heff_2epresyntax_2eapp(V v_f_240, V v_args_241) {
top: ;
  switch (heff_tag_of(v_args_241)) {
  case TAG_Nil: {
    return v_f_240;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_f_240)) {
    case TAG_At: {
      V v_f1_244 = heff_dup(heff_field(v_f_240, 0));
      V v_sp_245 = heff_dup(heff_field(v_f_240, 1));
      switch (heff_tag_of(v_f1_244)) {
      case TAG_EVar: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop(v_sp_245);
        V v_a_249;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_248 = heff_dup(heff_field(v_f_240, 1));
          v_a_249 = v_s_248;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2410 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_2413;
        switch (heff_tag_of(v_x1_2410)) {
        case TAG_At: {
          V v_s_2412 = heff_field(v_x1_2410, 1);
          heff_take_n(v_x1_2410, 2ULL, 2);
          v_b_2413 = v_s_2412;
          break;
        }
        default: heff_nomatch(v_x1_2410);
        }
        V v_t_2414 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_249, LBL_start), heff_get(v_b_2413, LBL_end)});
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2414});
      }
      case TAG_EImplicitVar: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop(v_sp_245);
        V v_a_2418;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2417 = heff_dup(heff_field(v_f_240, 1));
          v_a_2418 = v_s_2417;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2419 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_2422;
        switch (heff_tag_of(v_x1_2419)) {
        case TAG_At: {
          V v_s_2421 = heff_field(v_x1_2419, 1);
          heff_take_n(v_x1_2419, 2ULL, 2);
          v_b_2422 = v_s_2421;
          break;
        }
        default: heff_nomatch(v_x1_2419);
        }
        V v_t_2423 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_2418, LBL_start), heff_get(v_b_2422, LBL_end)});
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2423});
      }
      case TAG_ETag: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop(v_sp_245);
        V v_a_2427;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2426 = heff_dup(heff_field(v_f_240, 1));
          v_a_2427 = v_s_2426;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2428 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_2431;
        switch (heff_tag_of(v_x1_2428)) {
        case TAG_At: {
          V v_s_2430 = heff_field(v_x1_2428, 1);
          heff_take_n(v_x1_2428, 2ULL, 2);
          v_b_2431 = v_s_2430;
          break;
        }
        default: heff_nomatch(v_x1_2428);
        }
        V v_t_2432 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_2427, LBL_start), heff_get(v_b_2431, LBL_end)});
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2432});
      }
      case TAG_EInt: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop(v_sp_245);
        V v_a_2436;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2435 = heff_dup(heff_field(v_f_240, 1));
          v_a_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2437 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_2440;
        switch (heff_tag_of(v_x1_2437)) {
        case TAG_At: {
          V v_s_2439 = heff_field(v_x1_2437, 1);
          heff_take_n(v_x1_2437, 2ULL, 2);
          v_b_2440 = v_s_2439;
          break;
        }
        default: heff_nomatch(v_x1_2437);
        }
        V v_t_2441 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_2436, LBL_start), heff_get(v_b_2440, LBL_end)});
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2441});
      }
      case TAG_EFloat: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop(v_sp_245);
        V v_a_2445;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2444 = heff_dup(heff_field(v_f_240, 1));
          v_a_2445 = v_s_2444;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2446 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_2449;
        switch (heff_tag_of(v_x1_2446)) {
        case TAG_At: {
          V v_s_2448 = heff_field(v_x1_2446, 1);
          heff_take_n(v_x1_2446, 2ULL, 2);
          v_b_2449 = v_s_2448;
          break;
        }
        default: heff_nomatch(v_x1_2446);
        }
        V v_t_2450 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_2445, LBL_start), heff_get(v_b_2449, LBL_end)});
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2450});
      }
      case TAG_EString: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop(v_sp_245);
        V v_a_2454;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2453 = heff_dup(heff_field(v_f_240, 1));
          v_a_2454 = v_s_2453;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2455 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_2458;
        switch (heff_tag_of(v_x1_2455)) {
        case TAG_At: {
          V v_s_2457 = heff_field(v_x1_2455, 1);
          heff_take_n(v_x1_2455, 2ULL, 2);
          v_b_2458 = v_s_2457;
          break;
        }
        default: heff_nomatch(v_x1_2455);
        }
        V v_t_2459 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_2454, LBL_start), heff_get(v_b_2458, LBL_end)});
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2459});
      }
      case TAG_EWord: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop(v_sp_245);
        V v_a_2463;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2462 = heff_dup(heff_field(v_f_240, 1));
          v_a_2463 = v_s_2462;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2464 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_2467;
        switch (heff_tag_of(v_x1_2464)) {
        case TAG_At: {
          V v_s_2466 = heff_field(v_x1_2464, 1);
          heff_take_n(v_x1_2464, 2ULL, 2);
          v_b_2467 = v_s_2466;
          break;
        }
        default: heff_nomatch(v_x1_2464);
        }
        V v_t_2468 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_2463, LBL_start), heff_get(v_b_2467, LBL_end)});
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2468});
      }
      case TAG_EApp: {
        V v_h_2469 = heff_field(v_f1_244, 0);
        V v_xs_2470 = heff_field(v_f1_244, 1);
        V v_ru_24f1_244_24EApp = heff_take_reuse_n(v_f1_244, 3ULL, 2);
        heff_drop_tag(v_f_240, 2);
        V v_t_2471 = heff_tag_at(v_ru_24f1_244_24EApp, TAG_EApp, 2, (V[]){heff_dup(v_h_2469), (g_prelude_2econcatList(v_xs_2470, heff_dup(v_args_241)))});
        V v_x1_2472 = ({ V a_0 = v_h_2469; V a_1 = v_args_241; V r_ = (g_heff_2epresyntax_2elastOr(a_0, a_1)); heff_drop_tag(v_args_241, 2); r_; });
        V v_b_2475;
        switch (heff_tag_of(v_x1_2472)) {
        case TAG_At: {
          V v_s_2474 = heff_field(v_x1_2472, 1);
          heff_take_n(v_x1_2472, 2ULL, 2);
          v_b_2475 = v_s_2474;
          break;
        }
        default: heff_nomatch(v_x1_2472);
        }
        V v_t_2476 = heff_rec(2, shape_start__end, (V[]){heff_get(v_sp_245, LBL_start), heff_get(v_b_2475, LBL_end)});
        return heff_tag(TAG_At, 2, (V[]){v_t_2471, v_t_2476});
      }
      case TAG_EProject: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop(v_sp_245);
        V v_a_2480;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2479 = heff_dup(heff_field(v_f_240, 1));
          v_a_2480 = v_s_2479;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2481 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_2484;
        switch (heff_tag_of(v_x1_2481)) {
        case TAG_At: {
          V v_s_2483 = heff_field(v_x1_2481, 1);
          heff_take_n(v_x1_2481, 2ULL, 2);
          v_b_2484 = v_s_2483;
          break;
        }
        default: heff_nomatch(v_x1_2481);
        }
        V v_t_2485 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_2480, LBL_start), heff_get(v_b_2484, LBL_end)});
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2485});
      }
      case TAG_ENamed: {
        V v_ru_24f1_244_24ENamed = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop(v_sp_245);
        V v_a_2490;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2489 = heff_dup(heff_field(v_f_240, 1));
          v_a_2490 = v_s_2489;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2491 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_2494;
        switch (heff_tag_of(v_x1_2491)) {
        case TAG_At: {
          V v_s_2493 = heff_field(v_x1_2491, 1);
          heff_take_n(v_x1_2491, 2ULL, 2);
          v_b_2494 = v_s_2493;
          break;
        }
        default: heff_nomatch(v_x1_2491);
        }
        V v_t_2495 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_2490, LBL_start), heff_get(v_b_2494, LBL_end)});
        return heff_tag_at(v_ru_24f1_244_24ENamed, TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2495});
      }
      case TAG_EPi: {
        V v_ru_24f1_244_24EPi = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop(v_sp_245);
        V v_a_24100;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2499 = heff_dup(heff_field(v_f_240, 1));
          v_a_24100 = v_s_2499;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24101 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24104;
        switch (heff_tag_of(v_x1_24101)) {
        case TAG_At: {
          V v_s_24103 = heff_field(v_x1_24101, 1);
          heff_take_n(v_x1_24101, 2ULL, 2);
          v_b_24104 = v_s_24103;
          break;
        }
        default: heff_nomatch(v_x1_24101);
        }
        V v_t_24105 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_24100, LBL_start), heff_get(v_b_24104, LBL_end)});
        return heff_tag_at(v_ru_24f1_244_24EPi, TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24105});
      }
      case TAG_ELam: {
        V v_ru_24f1_244_24ELam = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop(v_sp_245);
        V v_a_24110;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24109 = heff_dup(heff_field(v_f_240, 1));
          v_a_24110 = v_s_24109;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24111 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24114;
        switch (heff_tag_of(v_x1_24111)) {
        case TAG_At: {
          V v_s_24113 = heff_field(v_x1_24111, 1);
          heff_take_n(v_x1_24111, 2ULL, 2);
          v_b_24114 = v_s_24113;
          break;
        }
        default: heff_nomatch(v_x1_24111);
        }
        V v_t_24115 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_24110, LBL_start), heff_get(v_b_24114, LBL_end)});
        return heff_tag_at(v_ru_24f1_244_24ELam, TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24115});
      }
      case TAG_EAnn: {
        V v_ru_24f1_244_24EAnn = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop(v_sp_245);
        V v_a_24120;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24119 = heff_dup(heff_field(v_f_240, 1));
          v_a_24120 = v_s_24119;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24121 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24124;
        switch (heff_tag_of(v_x1_24121)) {
        case TAG_At: {
          V v_s_24123 = heff_field(v_x1_24121, 1);
          heff_take_n(v_x1_24121, 2ULL, 2);
          v_b_24124 = v_s_24123;
          break;
        }
        default: heff_nomatch(v_x1_24121);
        }
        V v_t_24125 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_24120, LBL_start), heff_get(v_b_24124, LBL_end)});
        return heff_tag_at(v_ru_24f1_244_24EAnn, TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24125});
      }
      case TAG_ESpec: {
        heff_take_n(v_f1_244, 0ULL, 4);
        heff_drop(v_sp_245);
        V v_a_24132;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24131 = heff_dup(heff_field(v_f_240, 1));
          v_a_24132 = v_s_24131;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24133 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24136;
        switch (heff_tag_of(v_x1_24133)) {
        case TAG_At: {
          V v_s_24135 = heff_field(v_x1_24133, 1);
          heff_take_n(v_x1_24133, 2ULL, 2);
          v_b_24136 = v_s_24135;
          break;
        }
        default: heff_nomatch(v_x1_24133);
        }
        V v_t_24137 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_24132, LBL_start), heff_get(v_b_24136, LBL_end)});
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24137});
      }
      case TAG_ESig: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop(v_sp_245);
        V v_a_24141;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24140 = heff_dup(heff_field(v_f_240, 1));
          v_a_24141 = v_s_24140;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24142 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24145;
        switch (heff_tag_of(v_x1_24142)) {
        case TAG_At: {
          V v_s_24144 = heff_field(v_x1_24142, 1);
          heff_take_n(v_x1_24142, 2ULL, 2);
          v_b_24145 = v_s_24144;
          break;
        }
        default: heff_nomatch(v_x1_24142);
        }
        V v_t_24146 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_24141, LBL_start), heff_get(v_b_24145, LBL_end)});
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24146});
      }
      case TAG_ESum: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop(v_sp_245);
        V v_a_24150;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24149 = heff_dup(heff_field(v_f_240, 1));
          v_a_24150 = v_s_24149;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24151 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24154;
        switch (heff_tag_of(v_x1_24151)) {
        case TAG_At: {
          V v_s_24153 = heff_field(v_x1_24151, 1);
          heff_take_n(v_x1_24151, 2ULL, 2);
          v_b_24154 = v_s_24153;
          break;
        }
        default: heff_nomatch(v_x1_24151);
        }
        V v_t_24155 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_24150, LBL_start), heff_get(v_b_24154, LBL_end)});
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24155});
      }
      case TAG_EStruct: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop(v_sp_245);
        V v_a_24159;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24158 = heff_dup(heff_field(v_f_240, 1));
          v_a_24159 = v_s_24158;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24160 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24163;
        switch (heff_tag_of(v_x1_24160)) {
        case TAG_At: {
          V v_s_24162 = heff_field(v_x1_24160, 1);
          heff_take_n(v_x1_24160, 2ULL, 2);
          v_b_24163 = v_s_24162;
          break;
        }
        default: heff_nomatch(v_x1_24160);
        }
        V v_t_24164 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_24159, LBL_start), heff_get(v_b_24163, LBL_end)});
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24164});
      }
      case TAG_EMatch: {
        V v_ru_24f1_244_24EMatch = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop(v_sp_245);
        V v_a_24169;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24168 = heff_dup(heff_field(v_f_240, 1));
          v_a_24169 = v_s_24168;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24170 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24173;
        switch (heff_tag_of(v_x1_24170)) {
        case TAG_At: {
          V v_s_24172 = heff_field(v_x1_24170, 1);
          heff_take_n(v_x1_24170, 2ULL, 2);
          v_b_24173 = v_s_24172;
          break;
        }
        default: heff_nomatch(v_x1_24170);
        }
        V v_t_24174 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_24169, LBL_start), heff_get(v_b_24173, LBL_end)});
        return heff_tag_at(v_ru_24f1_244_24EMatch, TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24174});
      }
      case TAG_ELetIn: {
        V v_ru_24f1_244_24ELetIn = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop(v_sp_245);
        V v_a_24179;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24178 = heff_dup(heff_field(v_f_240, 1));
          v_a_24179 = v_s_24178;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24180 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24183;
        switch (heff_tag_of(v_x1_24180)) {
        case TAG_At: {
          V v_s_24182 = heff_field(v_x1_24180, 1);
          heff_take_n(v_x1_24180, 2ULL, 2);
          v_b_24183 = v_s_24182;
          break;
        }
        default: heff_nomatch(v_x1_24180);
        }
        V v_t_24184 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_24179, LBL_start), heff_get(v_b_24183, LBL_end)});
        return heff_tag_at(v_ru_24f1_244_24ELetIn, TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24184});
      }
      case TAG_EDo: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop(v_sp_245);
        V v_a_24188;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24187 = heff_dup(heff_field(v_f_240, 1));
          v_a_24188 = v_s_24187;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24189 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24192;
        switch (heff_tag_of(v_x1_24189)) {
        case TAG_At: {
          V v_s_24191 = heff_field(v_x1_24189, 1);
          heff_take_n(v_x1_24189, 2ULL, 2);
          v_b_24192 = v_s_24191;
          break;
        }
        default: heff_nomatch(v_x1_24189);
        }
        V v_t_24193 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_24188, LBL_start), heff_get(v_b_24192, LBL_end)});
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24193});
      }
      case TAG_ELocal: {
        V v_ru_24f1_244_24ELocal = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop(v_sp_245);
        V v_a_24198;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24197 = heff_dup(heff_field(v_f_240, 1));
          v_a_24198 = v_s_24197;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24199 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24202;
        switch (heff_tag_of(v_x1_24199)) {
        case TAG_At: {
          V v_s_24201 = heff_field(v_x1_24199, 1);
          heff_take_n(v_x1_24199, 2ULL, 2);
          v_b_24202 = v_s_24201;
          break;
        }
        default: heff_nomatch(v_x1_24199);
        }
        V v_t_24203 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_24198, LBL_start), heff_get(v_b_24202, LBL_end)});
        return heff_tag_at(v_ru_24f1_244_24ELocal, TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24203});
      }
      case TAG_EInvalid: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop(v_sp_245);
        V v_a_24207;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24206 = heff_dup(heff_field(v_f_240, 1));
          v_a_24207 = v_s_24206;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24208 = (g_heff_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24211;
        switch (heff_tag_of(v_x1_24208)) {
        case TAG_At: {
          V v_s_24210 = heff_field(v_x1_24208, 1);
          heff_take_n(v_x1_24208, 2ULL, 2);
          v_b_24211 = v_s_24210;
          break;
        }
        default: heff_nomatch(v_x1_24208);
        }
        V v_t_24212 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_24207, LBL_start), heff_get(v_b_24211, LBL_end)});
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24212});
      }
      default: return heff_nomatch(v_f1_244);
      }
    }
    default: return heff_nomatch(v_f_240);
    }
  }
  default: return heff_nomatch(v_args_241);
  }
}
V g_heff_2epresyntax_2eapp_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2eapp(a[0], a[1]);
}
Clo g_heff_2epresyntax_2espineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2espineOf_entry, 1, 0};

V g_heff_2epresyntax_2espineOf(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ETag: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EInt: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EFloat: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EString: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EWord: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EApp: {
      V v_h_2410 = heff_field(v_e1_241, 0);
      V v_xs_2411 = heff_field(v_e1_241, 1);
      heff_take_n(v_e1_241, 3ULL, 2);
      heff_drop_tag(v_e_240, 2);
      return heff_rec(2, shape_head__args, (V[]){v_h_2410, v_xs_2411});
    }
    case TAG_EProject: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EPi: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ELam: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EAnn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_241, 0ULL, 4);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ESig: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ESum: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EStruct: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ELetIn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EDo: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EInvalid: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_e1_241);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2epresyntax_2espineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2espineOf(a[0]);
}
Clo g_heff_2epresyntax_2epatSpineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2epatSpineOf_entry, 1, 0};

V g_heff_2epresyntax_2epatSpineOf(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_dup(heff_field(v_p_240, 0));
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatTag: {
      V v_t_244 = heff_field(v_p1_241, 0);
      V v_tsp_245 = heff_field(v_p1_241, 1);
      V v_ps_246 = heff_field(v_p1_241, 2);
      V v_ru_24p1_241_24PatTag = heff_take_reuse_n(v_p1_241, 7ULL, 3);
      heff_drop_tag(v_p_240, 2);
      V v_t_247 = heff_tag_at(v_ru_24p1_241_24PatTag, TAG_PatTag, 3, (V[]){v_t_244, heff_dup(v_tsp_245), NTAG(TAG_Nil)});
      return heff_rec(2, shape_head__args, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_247, v_tsp_245}), v_ps_246});
    }
    case TAG_PatOp: {
      V v_x_248 = heff_field(v_p1_241, 0);
      V v_xsp_249 = heff_field(v_p1_241, 1);
      V v_ps_2410 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 7ULL, 3);
      heff_drop_tag(v_p_240, 2);
      V v_t_2411 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_PatVar, 1, (V[]){v_x_248}), v_xsp_249});
      return heff_rec(2, shape_head__args, (V[]){v_t_2411, v_ps_2410});
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatString: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatRecord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatAs: {
      heff_take_n(v_p1_241, 0ULL, 3);
      return heff_rec(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2epresyntax_2epatSpineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2epatSpineOf(a[0]);
}
Clo g_heff_2epresyntax_2einfSpineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2einfSpineOf_entry, 1, 0};

V g_heff_2epresyntax_2einfSpineOf(V v_i_240) {
top: ;
  switch (heff_tag_of(v_i_240)) {
  case TAG_At: {
    V v_i1_241 = heff_dup(heff_field(v_i_240, 0));
    switch (heff_tag_of(v_i1_241)) {
    case TAG_IVar: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IInt: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IFloat: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IString: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IApp: {
      V v_h_247 = heff_field(v_i1_241, 0);
      V v_xs_248 = heff_field(v_i1_241, 1);
      heff_take_n(v_i1_241, 3ULL, 2);
      heff_drop_tag(v_i_240, 2);
      return heff_rec(2, shape_head__args, (V[]){v_h_247, v_xs_248});
    }
    case TAG_IAnn: {
      heff_take_n(v_i1_241, 0ULL, 2);
      return heff_rec(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_ISpec: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return heff_rec(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IAnnLam: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return heff_rec(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IInvalid: {
      heff_take_n(v_i1_241, 0ULL, 2);
      return heff_rec(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_INominal: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_i1_241);
    }
  }
  default: return heff_nomatch(v_i_240);
  }
}
V g_heff_2epresyntax_2einfSpineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2einfSpineOf(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epresyntax_2einfApp_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2epresyntax_2einfApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2einfApp_entry, 2, 0};

V g_heff_2epresyntax_2einfApp(V v_f_240, V v_args_241) {
top: ;
  V v_a_244;
  switch (heff_tag_of(v_f_240)) {
  case TAG_At: {
    V v_s_243 = heff_dup(heff_field(v_f_240, 1));
    v_a_244 = v_s_243;
    break;
  }
  default: heff_nomatch(v_f_240);
  }
  V v_t_247;
  switch (heff_tag_of(v_f_240)) {
  case TAG_At: {
    V v_s_246 = heff_dup(heff_field(v_f_240, 1));
    v_t_247 = v_s_246;
    break;
  }
  default: heff_nomatch(v_f_240);
  }
  V v_t_248 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgProject, 1, (V[]){((V)&g_heff_2epresyntax_2einfApp_str0)}), v_t_247});
  V v_x1_249 = (g_heff_2epresyntax_2elastOr(v_t_248, v_args_241));
  V v_b_2412;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_At: {
    V v_s_2411 = heff_field(v_x1_249, 1);
    heff_take_n(v_x1_249, 2ULL, 2);
    v_b_2412 = v_s_2411;
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  V v_t_2413 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_244, LBL_start), heff_get(v_b_2412, LBL_end)});
  return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IApp, 2, (V[]){v_f_240, v_args_241}), v_t_2413});
}
V g_heff_2epresyntax_2einfApp_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2einfApp(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2epresyntax_2edoStep_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {98, 105, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2epresyntax_2edoStep_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {98, 105, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epresyntax_2edoStep_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_heff_2epresyntax_2edoStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2edoStep_entry, 3, 0};

V g_heff_2epresyntax_2edoStep(V v_sp_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_x22_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_StmtBind: {
      V v_x_245 = heff_field(v_x21_243, 0);
      V v_xsp_246 = heff_field(v_x21_243, 1);
      V v_e_247 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 7ULL, 3);
      heff_drop(v_x22_244);
      V v_t_248 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_EVar, 1, (V[]){((V)&g_heff_2epresyntax_2edoStep_str0)}), v_sp_240});
      V v_t_249 = heff_tag(TAG_ELam, 2, (V[]){heff_tag(TAG_LamName, 2, (V[]){v_x_245, heff_dup(v_xsp_246)}), heff_dup(v_rest_242)});
      V v_b_2412;
      switch (heff_tag_of(v_rest_242)) {
      case TAG_At: {
        V v_s_2411 = heff_field(v_rest_242, 1);
        heff_take_n(v_rest_242, 2ULL, 2);
        v_b_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_rest_242);
      }
      V v_t_2413 = heff_rec(2, shape_start__end, (V[]){heff_get(v_xsp_246, LBL_start), heff_get(v_b_2412, LBL_end)});
      V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_249, v_t_2413}), NTAG(TAG_Nil)});
      return (g_heff_2epresyntax_2eapp(v_t_248, heff_tag(TAG_Cons, 2, (V[]){v_e_247, v_t_2414})));
    }
    case TAG_StmtLet: {
      V v_p_2415 = heff_field(v_x21_243, 0);
      V v_rhs_2416 = heff_field(v_x21_243, 1);
      V v_ru_24x21_243_24StmtLet = heff_take_reuse_n(v_x21_243, 3ULL, 2);
      heff_drop(v_sp_240);
      V v_a_2419;
      switch (heff_tag_of(v_p_2415)) {
      case TAG_At: {
        V v_s_2418 = heff_dup(heff_field(v_p_2415, 1));
        v_a_2419 = v_s_2418;
        break;
      }
      default: heff_nomatch(v_p_2415);
      }
      V v_b_2422;
      switch (heff_tag_of(v_rest_242)) {
      case TAG_At: {
        V v_s_2421 = heff_dup(heff_field(v_rest_242, 1));
        v_b_2422 = v_s_2421;
        break;
      }
      default: heff_nomatch(v_rest_242);
      }
      V v_t_2423 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_2419, LBL_start), heff_get(v_b_2422, LBL_end)});
      V v_t_2424 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_MkAlt, 2, (V[]){v_p_2415, heff_dup(v_rest_242)}), v_t_2423});
      V v_t_2427;
      switch (heff_tag_of(v_rest_242)) {
      case TAG_At: {
        V v_s_2426 = heff_field(v_rest_242, 1);
        heff_take_n(v_rest_242, 2ULL, 2);
        v_t_2427 = v_s_2426;
        break;
      }
      default: heff_nomatch(v_rest_242);
      }
      V v_t_2428 = heff_rec(2, shape_start__end, (V[]){heff_get(v_x22_244, LBL_start), heff_get(v_t_2427, LBL_end)});
      return heff_tag_at(v_ru_24x21_243_24StmtLet, TAG_At, 2, (V[]){heff_tag(TAG_ELetIn, 2, (V[]){v_rhs_2416, v_t_2424}), v_t_2428});
    }
    case TAG_StmtExpr: {
      V v_e_2429 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop(v_x22_244);
      V v_t_2430 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_EVar, 1, (V[]){((V)&g_heff_2epresyntax_2edoStep_str1)}), heff_dup(v_sp_240)});
      V v_t_2431 = heff_tag(TAG_ELam, 2, (V[]){heff_tag(TAG_LamName, 2, (V[]){((V)&g_heff_2epresyntax_2edoStep_str2), heff_dup(v_sp_240)}), heff_dup(v_rest_242)});
      V v_b_2434;
      switch (heff_tag_of(v_rest_242)) {
      case TAG_At: {
        V v_s_2433 = heff_field(v_rest_242, 1);
        heff_take_n(v_rest_242, 2ULL, 2);
        v_b_2434 = v_s_2433;
        break;
      }
      default: heff_nomatch(v_rest_242);
      }
      V v_t_2435 = heff_rec(2, shape_start__end, (V[]){heff_get(v_sp_240, LBL_start), heff_get(v_b_2434, LBL_end)});
      V v_t_2436 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2431, v_t_2435}), NTAG(TAG_Nil)});
      return (g_heff_2epresyntax_2eapp(v_t_2430, heff_tag(TAG_Cons, 2, (V[]){v_e_2429, v_t_2436})));
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2epresyntax_2edoStep_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2edoStep(a[0], a[1], a[2]);
}
Clo g_heff_2epresyntax_2edoFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2edoFrom_entry, 3, 0};

V g_heff_2epresyntax_2edoFrom(V v_sp_240, V v_x2_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_sp_240);
    return v_e_242;
  }
  case TAG_Cons: {
    V v_s_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_t_245 = (g_heff_2epresyntax_2edoFrom(heff_dup(v_sp_240), v_rest_244, v_e_242));
    HEFF_LAST return g_heff_2epresyntax_2edoStep(v_sp_240, heff_dup(v_s_243), v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2epresyntax_2edoFrom_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2epresyntax_2edoFrom(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[48]; } g_heff_2epresyntax_2etoInferable_str0 = {{0x80000000u, K_STR, 0}, 48, 48, {116, 104, 105, 115, 32, 110, 111, 116, 97, 116, 105, 111, 110, 32, 109, 117, 115, 116, 32, 98, 101, 32, 112, 117, 116, 32, 105, 110, 32, 97, 32, 99, 104, 101, 99, 107, 105, 110, 103, 32, 112, 111, 115, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2epresyntax_2etoInferable_str1 = {{0x80000000u, K_STR, 0}, 54, 54, {97, 32, 116, 121, 112, 101, 32, 117, 115, 101, 100, 32, 97, 115, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 109, 117, 115, 116, 32, 98, 101, 32, 105, 110, 32, 99, 104, 101, 99, 107, 105, 110, 103, 32, 112, 111, 115, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[49]; } g_heff_2epresyntax_2etoInferable_str2 = {{0x80000000u, K_STR, 0}, 49, 49, {99, 97, 110, 110, 111, 116, 32, 117, 115, 101, 32, 100, 101, 115, 99, 114, 105, 112, 116, 105, 118, 101, 32, 115, 121, 110, 116, 97, 120, 32, 105, 110, 32, 110, 111, 109, 105, 110, 97, 108, 32, 112, 111, 115, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[49]; } g_heff_2epresyntax_2etoInferable_str3 = {{0x80000000u, K_STR, 0}, 49, 49, {99, 97, 110, 110, 111, 116, 32, 117, 115, 101, 32, 100, 101, 115, 99, 114, 105, 112, 116, 105, 118, 101, 32, 115, 121, 110, 116, 97, 120, 32, 105, 110, 32, 110, 111, 109, 105, 110, 97, 108, 32, 112, 111, 115, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2epresyntax_2etoInferable_str4 = {{0x80000000u, K_STR, 0}, 54, 54, {97, 32, 116, 121, 112, 101, 32, 117, 115, 101, 100, 32, 97, 115, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 109, 117, 115, 116, 32, 98, 101, 32, 105, 110, 32, 99, 104, 101, 99, 107, 105, 110, 103, 32, 112, 111, 115, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2epresyntax_2etoInferable_str5 = {{0x80000000u, K_STR, 0}, 54, 54, {97, 32, 116, 121, 112, 101, 32, 117, 115, 101, 100, 32, 97, 115, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 109, 117, 115, 116, 32, 98, 101, 32, 105, 110, 32, 99, 104, 101, 99, 107, 105, 110, 103, 32, 112, 111, 115, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2epresyntax_2etoInferable_str6 = {{0x80000000u, K_STR, 0}, 54, 54, {97, 32, 116, 121, 112, 101, 32, 117, 115, 101, 100, 32, 97, 115, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 109, 117, 115, 116, 32, 98, 101, 32, 105, 110, 32, 99, 104, 101, 99, 107, 105, 110, 103, 32, 112, 111, 115, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2epresyntax_2etoInferable_str7 = {{0x80000000u, K_STR, 0}, 54, 54, {97, 32, 116, 121, 112, 101, 32, 117, 115, 101, 100, 32, 97, 115, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 109, 117, 115, 116, 32, 98, 101, 32, 105, 110, 32, 99, 104, 101, 99, 107, 105, 110, 103, 32, 112, 111, 115, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2epresyntax_2etoInferable_str8 = {{0x80000000u, K_STR, 0}, 54, 54, {97, 32, 116, 121, 112, 101, 32, 117, 115, 101, 100, 32, 97, 115, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 109, 117, 115, 116, 32, 98, 101, 32, 105, 110, 32, 99, 104, 101, 99, 107, 105, 110, 103, 32, 112, 111, 115, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2epresyntax_2etoInferable_str9 = {{0x80000000u, K_STR, 0}, 54, 54, {97, 32, 116, 121, 112, 101, 32, 117, 115, 101, 100, 32, 97, 115, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 109, 117, 115, 116, 32, 98, 101, 32, 105, 110, 32, 99, 104, 101, 99, 107, 105, 110, 103, 32, 112, 111, 115, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2epresyntax_2etoInferable_str10 = {{0x80000000u, K_STR, 0}, 54, 54, {97, 32, 116, 121, 112, 101, 32, 117, 115, 101, 100, 32, 97, 115, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 109, 117, 115, 116, 32, 98, 101, 32, 105, 110, 32, 99, 104, 101, 99, 107, 105, 110, 103, 32, 112, 111, 115, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2epresyntax_2etoInferable_str11 = {{0x80000000u, K_STR, 0}, 54, 54, {97, 32, 116, 121, 112, 101, 32, 117, 115, 101, 100, 32, 97, 115, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 109, 117, 115, 116, 32, 98, 101, 32, 105, 110, 32, 99, 104, 101, 99, 107, 105, 110, 103, 32, 112, 111, 115, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2epresyntax_2etoInferable_str12 = {{0x80000000u, K_STR, 0}, 54, 54, {97, 32, 116, 121, 112, 101, 32, 117, 115, 101, 100, 32, 97, 115, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 109, 117, 115, 116, 32, 98, 101, 32, 105, 110, 32, 99, 104, 101, 99, 107, 105, 110, 103, 32, 112, 111, 115, 105, 116, 105, 111, 110}};
Clo g_heff_2epresyntax_2etoInferable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2etoInferable_entry, 1, 0};

V g_heff_2epresyntax_2etoInferable(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_IsInferable: {
    V v_i_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_i_241);
  }
  case TAG_IsCheckable: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_sp_245;
    switch (heff_tag_of(v_c_242)) {
    case TAG_At: {
      V v_s_244 = heff_field(v_c_242, 1);
      v_sp_245 = heff_dup(v_s_244);
      break;
    }
    default: heff_nomatch(v_c_242);
    }
    return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2epresyntax_2etoInferable_str0)}), v_sp_245});
  }
  case TAG_IsType: {
    V v_x11_246 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_At: {
      V v_x111_247 = heff_field(v_x11_246, 0);
      V v_sp_248 = heff_field(v_x11_246, 1);
      switch (heff_tag_of(v_x111_247)) {
      case TAG_TPi: {
        V v_sp_2413;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2412 = heff_field(v_x11_246, 1);
          v_sp_2413 = heff_dup(v_s_2412);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2epresyntax_2etoInferable_str1)}), v_sp_2413});
      }
      case TAG_TSig: {
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(4LL), ((V)&g_heff_2epresyntax_2etoInferable_str2)}), heff_dup(v_sp_248)});
      }
      case TAG_TSum: {
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(4LL), ((V)&g_heff_2epresyntax_2etoInferable_str3)}), heff_dup(v_sp_248)});
      }
      case TAG_TType: {
        V v_sp_2418;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2417 = heff_field(v_x11_246, 1);
          v_sp_2418 = heff_dup(v_s_2417);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2epresyntax_2etoInferable_str4)}), v_sp_2418});
      }
      case TAG_TInt: {
        V v_sp_2421;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2420 = heff_field(v_x11_246, 1);
          v_sp_2421 = heff_dup(v_s_2420);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2epresyntax_2etoInferable_str5)}), v_sp_2421});
      }
      case TAG_TFloat: {
        V v_sp_2424;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2423 = heff_field(v_x11_246, 1);
          v_sp_2424 = heff_dup(v_s_2423);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2epresyntax_2etoInferable_str6)}), v_sp_2424});
      }
      case TAG_TString: {
        V v_sp_2427;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2426 = heff_field(v_x11_246, 1);
          v_sp_2427 = heff_dup(v_s_2426);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2epresyntax_2etoInferable_str7)}), v_sp_2427});
      }
      case TAG_TArray: {
        V v_sp_2431;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2430 = heff_field(v_x11_246, 1);
          v_sp_2431 = heff_dup(v_s_2430);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2epresyntax_2etoInferable_str8)}), v_sp_2431});
      }
      case TAG_TFixed: {
        V v_sp_2435;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2434 = heff_field(v_x11_246, 1);
          v_sp_2435 = heff_dup(v_s_2434);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2epresyntax_2etoInferable_str9)}), v_sp_2435});
      }
      case TAG_TInf: {
        V v_sp_2439;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2438 = heff_field(v_x11_246, 1);
          v_sp_2439 = heff_dup(v_s_2438);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2epresyntax_2etoInferable_str10)}), v_sp_2439});
      }
      case TAG_TChk: {
        V v_sp_2443;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2442 = heff_field(v_x11_246, 1);
          v_sp_2443 = heff_dup(v_s_2442);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2epresyntax_2etoInferable_str11)}), v_sp_2443});
      }
      case TAG_TNominal: {
        V v_sp_2447;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2446 = heff_field(v_x11_246, 1);
          v_sp_2447 = heff_dup(v_s_2446);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2epresyntax_2etoInferable_str12)}), v_sp_2447});
      }
      default: return heff_nomatch(v_x111_247);
      }
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2epresyntax_2etoInferable_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2epresyntax_2etoInferable(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2epresyntax_2ewordOf_str0 = {{0x80000000u, K_STR, 0}, 22, 22, {96, 65, 114, 114, 97, 121, 96, 32, 116, 97, 107, 101, 115, 32, 111, 110, 101, 32, 116, 121, 112, 101}};
Clo g_heff_2epresyntax_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2ewordOf_entry, 2, 0};

V g_heff_2epresyntax_2ewordOf(V v_x1_240, V v_sp_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_TypeWord: {
    V v_t_242 = heff_tag(TAG_At, 2, (V[]){NTAG(TAG_TType), v_sp_241});
    return heff_tag(TAG_IsType, 1, (V[]){v_t_242});
  }
  case TAG_IntWord: {
    V v_t_243 = heff_tag(TAG_At, 2, (V[]){NTAG(TAG_TInt), v_sp_241});
    return heff_tag(TAG_IsType, 1, (V[]){v_t_243});
  }
  case TAG_FloatWord: {
    V v_t_244 = heff_tag(TAG_At, 2, (V[]){NTAG(TAG_TFloat), v_sp_241});
    return heff_tag(TAG_IsType, 1, (V[]){v_t_244});
  }
  case TAG_StringWord: {
    V v_t_245 = heff_tag(TAG_At, 2, (V[]){NTAG(TAG_TString), v_sp_241});
    return heff_tag(TAG_IsType, 1, (V[]){v_t_245});
  }
  case TAG_ArrayWord: {
    V v_t_246 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(3LL), ((V)&g_heff_2epresyntax_2ewordOf_str0)}), heff_dup(v_sp_241)});
    V v_t_247 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_t_246}), v_sp_241});
    return heff_tag(TAG_IsType, 1, (V[]){v_t_247});
  }
  case TAG_AbandonWord: {
    V v_t_248 = heff_tag(TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_241});
    return heff_tag(TAG_IsCheckable, 1, (V[]){v_t_248});
  }
  case TAG_FixedWord: {
    V v_w_249 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24FixedWord = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2410 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_240_24FixedWord, TAG_TFixed, 1, (V[]){v_w_249}), v_sp_241});
    return heff_tag(TAG_IsType, 1, (V[]){v_t_2410});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2epresyntax_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2ewordOf(a[0], a[1]);
}
Clo g_heff_2epresyntax_2eargOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2eargOf_entry, 2, 0};

V g_heff_2epresyntax_2eargOf(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_At: {
    V v_e1_242 = heff_dup(heff_field(v_e_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_EVar: {
      V v_ru_24e1_242_24EVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_245 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_2415;
      switch (heff_tag_of(v_x1_245)) {
      case TAG_IsInferable: {
        V v_i_246 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_249;
        switch (heff_tag_of(v_i_246)) {
        case TAG_At: {
          V v_s_248 = heff_dup(heff_field(v_i_246, 1));
          v_t_249 = v_s_248;
          break;
        }
        default: heff_nomatch(v_i_246);
        }
        v_t_2415 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24EVar, TAG_CInf, 1, (V[]){v_i_246}), v_t_249});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2410 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EVar, 1);
        v_t_2415 = v_c_2410;
        break;
      }
      case TAG_IsType: {
        V v_t_2411 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_At: {
          V v_s_2413 = heff_dup(heff_field(v_t_2411, 1));
          v_t_2414 = v_s_2413;
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        v_t_2415 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24EVar, TAG_CType, 1, (V[]){v_t_2411}), v_t_2414});
        break;
      }
      default: heff_nomatch(v_x1_245);
      }
      V v_t_2418;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_2417 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_2418 = v_s_2417;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_2415}), v_t_2418});
    }
    case TAG_EImplicitVar: {
      V v_ru_24e1_242_24EImplicitVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2420 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_2430;
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_IsInferable: {
        V v_i_2421 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2424;
        switch (heff_tag_of(v_i_2421)) {
        case TAG_At: {
          V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_i_2421);
        }
        v_t_2430 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24EImplicitVar, TAG_CInf, 1, (V[]){v_i_2421}), v_t_2424});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2425 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EImplicitVar, 1);
        v_t_2430 = v_c_2425;
        break;
      }
      case TAG_IsType: {
        V v_t_2426 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2429;
        switch (heff_tag_of(v_t_2426)) {
        case TAG_At: {
          V v_s_2428 = heff_dup(heff_field(v_t_2426, 1));
          v_t_2429 = v_s_2428;
          break;
        }
        default: heff_nomatch(v_t_2426);
        }
        v_t_2430 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24EImplicitVar, TAG_CType, 1, (V[]){v_t_2426}), v_t_2429});
        break;
      }
      default: heff_nomatch(v_x1_2420);
      }
      V v_t_2433;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_2433 = v_s_2432;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_2430}), v_t_2433});
    }
    case TAG_ETag: {
      V v_ru_24e1_242_24ETag = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2435 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_2445;
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_IsInferable: {
        V v_i_2436 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        V v_t_2439;
        switch (heff_tag_of(v_i_2436)) {
        case TAG_At: {
          V v_s_2438 = heff_dup(heff_field(v_i_2436, 1));
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_i_2436);
        }
        v_t_2445 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24ETag, TAG_CInf, 1, (V[]){v_i_2436}), v_t_2439});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2440 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ETag, 1);
        v_t_2445 = v_c_2440;
        break;
      }
      case TAG_IsType: {
        V v_t_2441 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        V v_t_2444;
        switch (heff_tag_of(v_t_2441)) {
        case TAG_At: {
          V v_s_2443 = heff_dup(heff_field(v_t_2441, 1));
          v_t_2444 = v_s_2443;
          break;
        }
        default: heff_nomatch(v_t_2441);
        }
        v_t_2445 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24ETag, TAG_CType, 1, (V[]){v_t_2441}), v_t_2444});
        break;
      }
      default: heff_nomatch(v_x1_2435);
      }
      V v_t_2448;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_2447 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_2448 = v_s_2447;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_2445}), v_t_2448});
    }
    case TAG_EInt: {
      V v_ru_24e1_242_24EInt = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2450 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_2460;
      switch (heff_tag_of(v_x1_2450)) {
      case TAG_IsInferable: {
        V v_i_2451 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        V v_t_2454;
        switch (heff_tag_of(v_i_2451)) {
        case TAG_At: {
          V v_s_2453 = heff_dup(heff_field(v_i_2451, 1));
          v_t_2454 = v_s_2453;
          break;
        }
        default: heff_nomatch(v_i_2451);
        }
        v_t_2460 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24EInt, TAG_CInf, 1, (V[]){v_i_2451}), v_t_2454});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2455 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EInt, 1);
        v_t_2460 = v_c_2455;
        break;
      }
      case TAG_IsType: {
        V v_t_2456 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        V v_t_2459;
        switch (heff_tag_of(v_t_2456)) {
        case TAG_At: {
          V v_s_2458 = heff_dup(heff_field(v_t_2456, 1));
          v_t_2459 = v_s_2458;
          break;
        }
        default: heff_nomatch(v_t_2456);
        }
        v_t_2460 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24EInt, TAG_CType, 1, (V[]){v_t_2456}), v_t_2459});
        break;
      }
      default: heff_nomatch(v_x1_2450);
      }
      V v_t_2463;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_2462 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_2463 = v_s_2462;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_2460}), v_t_2463});
    }
    case TAG_EFloat: {
      V v_ru_24e1_242_24EFloat = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2465 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_2475;
      switch (heff_tag_of(v_x1_2465)) {
      case TAG_IsInferable: {
        V v_i_2466 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        V v_t_2469;
        switch (heff_tag_of(v_i_2466)) {
        case TAG_At: {
          V v_s_2468 = heff_dup(heff_field(v_i_2466, 1));
          v_t_2469 = v_s_2468;
          break;
        }
        default: heff_nomatch(v_i_2466);
        }
        v_t_2475 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24EFloat, TAG_CInf, 1, (V[]){v_i_2466}), v_t_2469});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2470 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EFloat, 1);
        v_t_2475 = v_c_2470;
        break;
      }
      case TAG_IsType: {
        V v_t_2471 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        V v_t_2474;
        switch (heff_tag_of(v_t_2471)) {
        case TAG_At: {
          V v_s_2473 = heff_dup(heff_field(v_t_2471, 1));
          v_t_2474 = v_s_2473;
          break;
        }
        default: heff_nomatch(v_t_2471);
        }
        v_t_2475 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24EFloat, TAG_CType, 1, (V[]){v_t_2471}), v_t_2474});
        break;
      }
      default: heff_nomatch(v_x1_2465);
      }
      V v_t_2478;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_2477 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_2478 = v_s_2477;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_2475}), v_t_2478});
    }
    case TAG_EString: {
      V v_ru_24e1_242_24EString = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2480 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_2490;
      switch (heff_tag_of(v_x1_2480)) {
      case TAG_IsInferable: {
        V v_i_2481 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        V v_t_2484;
        switch (heff_tag_of(v_i_2481)) {
        case TAG_At: {
          V v_s_2483 = heff_dup(heff_field(v_i_2481, 1));
          v_t_2484 = v_s_2483;
          break;
        }
        default: heff_nomatch(v_i_2481);
        }
        v_t_2490 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24EString, TAG_CInf, 1, (V[]){v_i_2481}), v_t_2484});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2485 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EString, 1);
        v_t_2490 = v_c_2485;
        break;
      }
      case TAG_IsType: {
        V v_t_2486 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        V v_t_2489;
        switch (heff_tag_of(v_t_2486)) {
        case TAG_At: {
          V v_s_2488 = heff_dup(heff_field(v_t_2486, 1));
          v_t_2489 = v_s_2488;
          break;
        }
        default: heff_nomatch(v_t_2486);
        }
        v_t_2490 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24EString, TAG_CType, 1, (V[]){v_t_2486}), v_t_2489});
        break;
      }
      default: heff_nomatch(v_x1_2480);
      }
      V v_t_2493;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_2492 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_2493 = v_s_2492;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_2490}), v_t_2493});
    }
    case TAG_EWord: {
      V v_ru_24e1_242_24EWord = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2495 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24105;
      switch (heff_tag_of(v_x1_2495)) {
      case TAG_IsInferable: {
        V v_i_2496 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        V v_t_2499;
        switch (heff_tag_of(v_i_2496)) {
        case TAG_At: {
          V v_s_2498 = heff_dup(heff_field(v_i_2496, 1));
          v_t_2499 = v_s_2498;
          break;
        }
        default: heff_nomatch(v_i_2496);
        }
        v_t_24105 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24EWord, TAG_CInf, 1, (V[]){v_i_2496}), v_t_2499});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24100 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EWord, 1);
        v_t_24105 = v_c_24100;
        break;
      }
      case TAG_IsType: {
        V v_t_24101 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        V v_t_24104;
        switch (heff_tag_of(v_t_24101)) {
        case TAG_At: {
          V v_s_24103 = heff_dup(heff_field(v_t_24101, 1));
          v_t_24104 = v_s_24103;
          break;
        }
        default: heff_nomatch(v_t_24101);
        }
        v_t_24105 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24EWord, TAG_CType, 1, (V[]){v_t_24101}), v_t_24104});
        break;
      }
      default: heff_nomatch(v_x1_2495);
      }
      V v_t_24108;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24107 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24108 = v_s_24107;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24105}), v_t_24108});
    }
    case TAG_EApp: {
      V v_ru_24e1_242_24EApp = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24111 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24121;
      switch (heff_tag_of(v_x1_24111)) {
      case TAG_IsInferable: {
        V v_i_24112 = heff_field(v_x1_24111, 0);
        heff_take_n(v_x1_24111, 1ULL, 1);
        V v_t_24115;
        switch (heff_tag_of(v_i_24112)) {
        case TAG_At: {
          V v_s_24114 = heff_dup(heff_field(v_i_24112, 1));
          v_t_24115 = v_s_24114;
          break;
        }
        default: heff_nomatch(v_i_24112);
        }
        v_t_24121 = heff_tag_at(v_ru_24e1_242_24EApp, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24112}), v_t_24115});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24116 = heff_field(v_x1_24111, 0);
        heff_take_n(v_x1_24111, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EApp, 2);
        v_t_24121 = v_c_24116;
        break;
      }
      case TAG_IsType: {
        V v_t_24117 = heff_field(v_x1_24111, 0);
        heff_take_n(v_x1_24111, 1ULL, 1);
        V v_t_24120;
        switch (heff_tag_of(v_t_24117)) {
        case TAG_At: {
          V v_s_24119 = heff_dup(heff_field(v_t_24117, 1));
          v_t_24120 = v_s_24119;
          break;
        }
        default: heff_nomatch(v_t_24117);
        }
        v_t_24121 = heff_tag_at(v_ru_24e1_242_24EApp, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24117}), v_t_24120});
        break;
      }
      default: heff_nomatch(v_x1_24111);
      }
      V v_t_24124;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24123 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24124 = v_s_24123;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24121}), v_t_24124});
    }
    case TAG_EProject: {
      V v_x_24125 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24EProject = heff_take_reuse_n(v_e1_242, 1ULL, 1);
      heff_drop(v_r_240);
      heff_drop_tag(v_e_241, 2);
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24EProject, TAG_ArgProject, 1, (V[]){v_x_24125}), v_sp_243});
    }
    case TAG_ENamed: {
      V v_x_24126 = heff_field(v_e1_242, 0);
      V v_e12_24127 = heff_field(v_e1_242, 1);
      V v_ru_24e1_242_24ENamed = heff_take_reuse_n(v_e1_242, 3ULL, 2);
      heff_drop_tag(v_e_241, 2);
      V v_x1_24128 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e12_24127}));
      V v_t_24138;
      switch (heff_tag_of(v_x1_24128)) {
      case TAG_IsInferable: {
        V v_i_24129 = heff_field(v_x1_24128, 0);
        heff_take_n(v_x1_24128, 1ULL, 1);
        V v_t_24132;
        switch (heff_tag_of(v_i_24129)) {
        case TAG_At: {
          V v_s_24131 = heff_dup(heff_field(v_i_24129, 1));
          v_t_24132 = v_s_24131;
          break;
        }
        default: heff_nomatch(v_i_24129);
        }
        v_t_24138 = heff_tag_at(v_ru_24e1_242_24ENamed, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24129}), v_t_24132});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24133 = heff_field(v_x1_24128, 0);
        heff_take_n(v_x1_24128, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ENamed, 2);
        v_t_24138 = v_c_24133;
        break;
      }
      case TAG_IsType: {
        V v_t_24134 = heff_field(v_x1_24128, 0);
        heff_take_n(v_x1_24128, 1ULL, 1);
        V v_t_24137;
        switch (heff_tag_of(v_t_24134)) {
        case TAG_At: {
          V v_s_24136 = heff_dup(heff_field(v_t_24134, 1));
          v_t_24137 = v_s_24136;
          break;
        }
        default: heff_nomatch(v_t_24134);
        }
        v_t_24138 = heff_tag_at(v_ru_24e1_242_24ENamed, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24134}), v_t_24137});
        break;
      }
      default: heff_nomatch(v_x1_24128);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgNamed, 2, (V[]){v_x_24126, v_t_24138}), v_sp_243});
    }
    case TAG_EPi: {
      V v_ru_24e1_242_24EPi = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24141 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24151;
      switch (heff_tag_of(v_x1_24141)) {
      case TAG_IsInferable: {
        V v_i_24142 = heff_field(v_x1_24141, 0);
        heff_take_n(v_x1_24141, 1ULL, 1);
        V v_t_24145;
        switch (heff_tag_of(v_i_24142)) {
        case TAG_At: {
          V v_s_24144 = heff_dup(heff_field(v_i_24142, 1));
          v_t_24145 = v_s_24144;
          break;
        }
        default: heff_nomatch(v_i_24142);
        }
        v_t_24151 = heff_tag_at(v_ru_24e1_242_24EPi, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24142}), v_t_24145});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24146 = heff_field(v_x1_24141, 0);
        heff_take_n(v_x1_24141, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EPi, 2);
        v_t_24151 = v_c_24146;
        break;
      }
      case TAG_IsType: {
        V v_t_24147 = heff_field(v_x1_24141, 0);
        heff_take_n(v_x1_24141, 1ULL, 1);
        V v_t_24150;
        switch (heff_tag_of(v_t_24147)) {
        case TAG_At: {
          V v_s_24149 = heff_dup(heff_field(v_t_24147, 1));
          v_t_24150 = v_s_24149;
          break;
        }
        default: heff_nomatch(v_t_24147);
        }
        v_t_24151 = heff_tag_at(v_ru_24e1_242_24EPi, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24147}), v_t_24150});
        break;
      }
      default: heff_nomatch(v_x1_24141);
      }
      V v_t_24154;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24153 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24154 = v_s_24153;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24151}), v_t_24154});
    }
    case TAG_ELam: {
      V v_ru_24e1_242_24ELam = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24157 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24167;
      switch (heff_tag_of(v_x1_24157)) {
      case TAG_IsInferable: {
        V v_i_24158 = heff_field(v_x1_24157, 0);
        heff_take_n(v_x1_24157, 1ULL, 1);
        V v_t_24161;
        switch (heff_tag_of(v_i_24158)) {
        case TAG_At: {
          V v_s_24160 = heff_dup(heff_field(v_i_24158, 1));
          v_t_24161 = v_s_24160;
          break;
        }
        default: heff_nomatch(v_i_24158);
        }
        v_t_24167 = heff_tag_at(v_ru_24e1_242_24ELam, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24158}), v_t_24161});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24162 = heff_field(v_x1_24157, 0);
        heff_take_n(v_x1_24157, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ELam, 2);
        v_t_24167 = v_c_24162;
        break;
      }
      case TAG_IsType: {
        V v_t_24163 = heff_field(v_x1_24157, 0);
        heff_take_n(v_x1_24157, 1ULL, 1);
        V v_t_24166;
        switch (heff_tag_of(v_t_24163)) {
        case TAG_At: {
          V v_s_24165 = heff_dup(heff_field(v_t_24163, 1));
          v_t_24166 = v_s_24165;
          break;
        }
        default: heff_nomatch(v_t_24163);
        }
        v_t_24167 = heff_tag_at(v_ru_24e1_242_24ELam, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24163}), v_t_24166});
        break;
      }
      default: heff_nomatch(v_x1_24157);
      }
      V v_t_24170;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24169 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24170 = v_s_24169;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24167}), v_t_24170});
    }
    case TAG_EAnn: {
      V v_ru_24e1_242_24EAnn = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24173 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24183;
      switch (heff_tag_of(v_x1_24173)) {
      case TAG_IsInferable: {
        V v_i_24174 = heff_field(v_x1_24173, 0);
        heff_take_n(v_x1_24173, 1ULL, 1);
        V v_t_24177;
        switch (heff_tag_of(v_i_24174)) {
        case TAG_At: {
          V v_s_24176 = heff_dup(heff_field(v_i_24174, 1));
          v_t_24177 = v_s_24176;
          break;
        }
        default: heff_nomatch(v_i_24174);
        }
        v_t_24183 = heff_tag_at(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24174}), v_t_24177});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24178 = heff_field(v_x1_24173, 0);
        heff_take_n(v_x1_24173, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EAnn, 2);
        v_t_24183 = v_c_24178;
        break;
      }
      case TAG_IsType: {
        V v_t_24179 = heff_field(v_x1_24173, 0);
        heff_take_n(v_x1_24173, 1ULL, 1);
        V v_t_24182;
        switch (heff_tag_of(v_t_24179)) {
        case TAG_At: {
          V v_s_24181 = heff_dup(heff_field(v_t_24179, 1));
          v_t_24182 = v_s_24181;
          break;
        }
        default: heff_nomatch(v_t_24179);
        }
        v_t_24183 = heff_tag_at(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24179}), v_t_24182});
        break;
      }
      default: heff_nomatch(v_x1_24173);
      }
      V v_t_24186;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24185 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24186 = v_s_24185;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24183}), v_t_24186});
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_242, 0ULL, 4);
      heff_drop(v_sp_243);
      V v_x1_24191 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24201;
      switch (heff_tag_of(v_x1_24191)) {
      case TAG_IsInferable: {
        V v_i_24192 = heff_field(v_x1_24191, 0);
        V v_ru_24x1_24191_24IsInferable = heff_take_reuse_n(v_x1_24191, 1ULL, 1);
        V v_t_24195;
        switch (heff_tag_of(v_i_24192)) {
        case TAG_At: {
          V v_s_24194 = heff_dup(heff_field(v_i_24192, 1));
          v_t_24195 = v_s_24194;
          break;
        }
        default: heff_nomatch(v_i_24192);
        }
        v_t_24201 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_24191_24IsInferable, TAG_CInf, 1, (V[]){v_i_24192}), v_t_24195});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24196 = heff_field(v_x1_24191, 0);
        heff_take_n(v_x1_24191, 1ULL, 1);
        v_t_24201 = v_c_24196;
        break;
      }
      case TAG_IsType: {
        V v_t_24197 = heff_field(v_x1_24191, 0);
        V v_ru_24x1_24191_24IsType = heff_take_reuse_n(v_x1_24191, 1ULL, 1);
        V v_t_24200;
        switch (heff_tag_of(v_t_24197)) {
        case TAG_At: {
          V v_s_24199 = heff_dup(heff_field(v_t_24197, 1));
          v_t_24200 = v_s_24199;
          break;
        }
        default: heff_nomatch(v_t_24197);
        }
        v_t_24201 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_24191_24IsType, TAG_CType, 1, (V[]){v_t_24197}), v_t_24200});
        break;
      }
      default: heff_nomatch(v_x1_24191);
      }
      V v_t_24204;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24203 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24204 = v_s_24203;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24201}), v_t_24204});
    }
    case TAG_ESig: {
      V v_ru_24e1_242_24ESig = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24206 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24216;
      switch (heff_tag_of(v_x1_24206)) {
      case TAG_IsInferable: {
        V v_i_24207 = heff_field(v_x1_24206, 0);
        heff_take_n(v_x1_24206, 1ULL, 1);
        V v_t_24210;
        switch (heff_tag_of(v_i_24207)) {
        case TAG_At: {
          V v_s_24209 = heff_dup(heff_field(v_i_24207, 1));
          v_t_24210 = v_s_24209;
          break;
        }
        default: heff_nomatch(v_i_24207);
        }
        v_t_24216 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24ESig, TAG_CInf, 1, (V[]){v_i_24207}), v_t_24210});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24211 = heff_field(v_x1_24206, 0);
        heff_take_n(v_x1_24206, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ESig, 1);
        v_t_24216 = v_c_24211;
        break;
      }
      case TAG_IsType: {
        V v_t_24212 = heff_field(v_x1_24206, 0);
        heff_take_n(v_x1_24206, 1ULL, 1);
        V v_t_24215;
        switch (heff_tag_of(v_t_24212)) {
        case TAG_At: {
          V v_s_24214 = heff_dup(heff_field(v_t_24212, 1));
          v_t_24215 = v_s_24214;
          break;
        }
        default: heff_nomatch(v_t_24212);
        }
        v_t_24216 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24ESig, TAG_CType, 1, (V[]){v_t_24212}), v_t_24215});
        break;
      }
      default: heff_nomatch(v_x1_24206);
      }
      V v_t_24219;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24218 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24219 = v_s_24218;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24216}), v_t_24219});
    }
    case TAG_ESum: {
      V v_ru_24e1_242_24ESum = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24221 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24231;
      switch (heff_tag_of(v_x1_24221)) {
      case TAG_IsInferable: {
        V v_i_24222 = heff_field(v_x1_24221, 0);
        heff_take_n(v_x1_24221, 1ULL, 1);
        V v_t_24225;
        switch (heff_tag_of(v_i_24222)) {
        case TAG_At: {
          V v_s_24224 = heff_dup(heff_field(v_i_24222, 1));
          v_t_24225 = v_s_24224;
          break;
        }
        default: heff_nomatch(v_i_24222);
        }
        v_t_24231 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24ESum, TAG_CInf, 1, (V[]){v_i_24222}), v_t_24225});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24226 = heff_field(v_x1_24221, 0);
        heff_take_n(v_x1_24221, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ESum, 1);
        v_t_24231 = v_c_24226;
        break;
      }
      case TAG_IsType: {
        V v_t_24227 = heff_field(v_x1_24221, 0);
        heff_take_n(v_x1_24221, 1ULL, 1);
        V v_t_24230;
        switch (heff_tag_of(v_t_24227)) {
        case TAG_At: {
          V v_s_24229 = heff_dup(heff_field(v_t_24227, 1));
          v_t_24230 = v_s_24229;
          break;
        }
        default: heff_nomatch(v_t_24227);
        }
        v_t_24231 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24ESum, TAG_CType, 1, (V[]){v_t_24227}), v_t_24230});
        break;
      }
      default: heff_nomatch(v_x1_24221);
      }
      V v_t_24234;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24233 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24234 = v_s_24233;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24231}), v_t_24234});
    }
    case TAG_EStruct: {
      V v_ru_24e1_242_24EStruct = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24236 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24246;
      switch (heff_tag_of(v_x1_24236)) {
      case TAG_IsInferable: {
        V v_i_24237 = heff_field(v_x1_24236, 0);
        heff_take_n(v_x1_24236, 1ULL, 1);
        V v_t_24240;
        switch (heff_tag_of(v_i_24237)) {
        case TAG_At: {
          V v_s_24239 = heff_dup(heff_field(v_i_24237, 1));
          v_t_24240 = v_s_24239;
          break;
        }
        default: heff_nomatch(v_i_24237);
        }
        v_t_24246 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24EStruct, TAG_CInf, 1, (V[]){v_i_24237}), v_t_24240});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24241 = heff_field(v_x1_24236, 0);
        heff_take_n(v_x1_24236, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EStruct, 1);
        v_t_24246 = v_c_24241;
        break;
      }
      case TAG_IsType: {
        V v_t_24242 = heff_field(v_x1_24236, 0);
        heff_take_n(v_x1_24236, 1ULL, 1);
        V v_t_24245;
        switch (heff_tag_of(v_t_24242)) {
        case TAG_At: {
          V v_s_24244 = heff_dup(heff_field(v_t_24242, 1));
          v_t_24245 = v_s_24244;
          break;
        }
        default: heff_nomatch(v_t_24242);
        }
        v_t_24246 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24EStruct, TAG_CType, 1, (V[]){v_t_24242}), v_t_24245});
        break;
      }
      default: heff_nomatch(v_x1_24236);
      }
      V v_t_24249;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24248 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24249 = v_s_24248;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24246}), v_t_24249});
    }
    case TAG_EMatch: {
      V v_ru_24e1_242_24EMatch = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24252 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24262;
      switch (heff_tag_of(v_x1_24252)) {
      case TAG_IsInferable: {
        V v_i_24253 = heff_field(v_x1_24252, 0);
        heff_take_n(v_x1_24252, 1ULL, 1);
        V v_t_24256;
        switch (heff_tag_of(v_i_24253)) {
        case TAG_At: {
          V v_s_24255 = heff_dup(heff_field(v_i_24253, 1));
          v_t_24256 = v_s_24255;
          break;
        }
        default: heff_nomatch(v_i_24253);
        }
        v_t_24262 = heff_tag_at(v_ru_24e1_242_24EMatch, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24253}), v_t_24256});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24257 = heff_field(v_x1_24252, 0);
        heff_take_n(v_x1_24252, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EMatch, 2);
        v_t_24262 = v_c_24257;
        break;
      }
      case TAG_IsType: {
        V v_t_24258 = heff_field(v_x1_24252, 0);
        heff_take_n(v_x1_24252, 1ULL, 1);
        V v_t_24261;
        switch (heff_tag_of(v_t_24258)) {
        case TAG_At: {
          V v_s_24260 = heff_dup(heff_field(v_t_24258, 1));
          v_t_24261 = v_s_24260;
          break;
        }
        default: heff_nomatch(v_t_24258);
        }
        v_t_24262 = heff_tag_at(v_ru_24e1_242_24EMatch, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24258}), v_t_24261});
        break;
      }
      default: heff_nomatch(v_x1_24252);
      }
      V v_t_24265;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24264 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24265 = v_s_24264;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24262}), v_t_24265});
    }
    case TAG_ELetIn: {
      V v_ru_24e1_242_24ELetIn = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24268 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24278;
      switch (heff_tag_of(v_x1_24268)) {
      case TAG_IsInferable: {
        V v_i_24269 = heff_field(v_x1_24268, 0);
        heff_take_n(v_x1_24268, 1ULL, 1);
        V v_t_24272;
        switch (heff_tag_of(v_i_24269)) {
        case TAG_At: {
          V v_s_24271 = heff_dup(heff_field(v_i_24269, 1));
          v_t_24272 = v_s_24271;
          break;
        }
        default: heff_nomatch(v_i_24269);
        }
        v_t_24278 = heff_tag_at(v_ru_24e1_242_24ELetIn, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24269}), v_t_24272});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24273 = heff_field(v_x1_24268, 0);
        heff_take_n(v_x1_24268, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ELetIn, 2);
        v_t_24278 = v_c_24273;
        break;
      }
      case TAG_IsType: {
        V v_t_24274 = heff_field(v_x1_24268, 0);
        heff_take_n(v_x1_24268, 1ULL, 1);
        V v_t_24277;
        switch (heff_tag_of(v_t_24274)) {
        case TAG_At: {
          V v_s_24276 = heff_dup(heff_field(v_t_24274, 1));
          v_t_24277 = v_s_24276;
          break;
        }
        default: heff_nomatch(v_t_24274);
        }
        v_t_24278 = heff_tag_at(v_ru_24e1_242_24ELetIn, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24274}), v_t_24277});
        break;
      }
      default: heff_nomatch(v_x1_24268);
      }
      V v_t_24281;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24280 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24281 = v_s_24280;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24278}), v_t_24281});
    }
    case TAG_EDo: {
      V v_ru_24e1_242_24EDo = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24283 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24293;
      switch (heff_tag_of(v_x1_24283)) {
      case TAG_IsInferable: {
        V v_i_24284 = heff_field(v_x1_24283, 0);
        heff_take_n(v_x1_24283, 1ULL, 1);
        V v_t_24287;
        switch (heff_tag_of(v_i_24284)) {
        case TAG_At: {
          V v_s_24286 = heff_dup(heff_field(v_i_24284, 1));
          v_t_24287 = v_s_24286;
          break;
        }
        default: heff_nomatch(v_i_24284);
        }
        v_t_24293 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24EDo, TAG_CInf, 1, (V[]){v_i_24284}), v_t_24287});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24288 = heff_field(v_x1_24283, 0);
        heff_take_n(v_x1_24283, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EDo, 1);
        v_t_24293 = v_c_24288;
        break;
      }
      case TAG_IsType: {
        V v_t_24289 = heff_field(v_x1_24283, 0);
        heff_take_n(v_x1_24283, 1ULL, 1);
        V v_t_24292;
        switch (heff_tag_of(v_t_24289)) {
        case TAG_At: {
          V v_s_24291 = heff_dup(heff_field(v_t_24289, 1));
          v_t_24292 = v_s_24291;
          break;
        }
        default: heff_nomatch(v_t_24289);
        }
        v_t_24293 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24EDo, TAG_CType, 1, (V[]){v_t_24289}), v_t_24292});
        break;
      }
      default: heff_nomatch(v_x1_24283);
      }
      V v_t_24296;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24295 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24296 = v_s_24295;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24293}), v_t_24296});
    }
    case TAG_ELocal: {
      V v_ru_24e1_242_24ELocal = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24299 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24309;
      switch (heff_tag_of(v_x1_24299)) {
      case TAG_IsInferable: {
        V v_i_24300 = heff_field(v_x1_24299, 0);
        heff_take_n(v_x1_24299, 1ULL, 1);
        V v_t_24303;
        switch (heff_tag_of(v_i_24300)) {
        case TAG_At: {
          V v_s_24302 = heff_dup(heff_field(v_i_24300, 1));
          v_t_24303 = v_s_24302;
          break;
        }
        default: heff_nomatch(v_i_24300);
        }
        v_t_24309 = heff_tag_at(v_ru_24e1_242_24ELocal, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24300}), v_t_24303});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24304 = heff_field(v_x1_24299, 0);
        heff_take_n(v_x1_24299, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ELocal, 2);
        v_t_24309 = v_c_24304;
        break;
      }
      case TAG_IsType: {
        V v_t_24305 = heff_field(v_x1_24299, 0);
        heff_take_n(v_x1_24299, 1ULL, 1);
        V v_t_24308;
        switch (heff_tag_of(v_t_24305)) {
        case TAG_At: {
          V v_s_24307 = heff_dup(heff_field(v_t_24305, 1));
          v_t_24308 = v_s_24307;
          break;
        }
        default: heff_nomatch(v_t_24305);
        }
        v_t_24309 = heff_tag_at(v_ru_24e1_242_24ELocal, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24305}), v_t_24308});
        break;
      }
      default: heff_nomatch(v_x1_24299);
      }
      V v_t_24312;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24311 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24312 = v_s_24311;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24309}), v_t_24312});
    }
    case TAG_EInvalid: {
      V v_ru_24e1_242_24EInvalid = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24314 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24324;
      switch (heff_tag_of(v_x1_24314)) {
      case TAG_IsInferable: {
        V v_i_24315 = heff_field(v_x1_24314, 0);
        heff_take_n(v_x1_24314, 1ULL, 1);
        V v_t_24318;
        switch (heff_tag_of(v_i_24315)) {
        case TAG_At: {
          V v_s_24317 = heff_dup(heff_field(v_i_24315, 1));
          v_t_24318 = v_s_24317;
          break;
        }
        default: heff_nomatch(v_i_24315);
        }
        v_t_24324 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24EInvalid, TAG_CInf, 1, (V[]){v_i_24315}), v_t_24318});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24319 = heff_field(v_x1_24314, 0);
        heff_take_n(v_x1_24314, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EInvalid, 1);
        v_t_24324 = v_c_24319;
        break;
      }
      case TAG_IsType: {
        V v_t_24320 = heff_field(v_x1_24314, 0);
        heff_take_n(v_x1_24314, 1ULL, 1);
        V v_t_24323;
        switch (heff_tag_of(v_t_24320)) {
        case TAG_At: {
          V v_s_24322 = heff_dup(heff_field(v_t_24320, 1));
          v_t_24323 = v_s_24322;
          break;
        }
        default: heff_nomatch(v_t_24320);
        }
        v_t_24324 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_242_24EInvalid, TAG_CType, 1, (V[]){v_t_24320}), v_t_24323});
        break;
      }
      default: heff_nomatch(v_x1_24314);
      }
      V v_t_24327;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24326 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24327 = v_s_24326;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24324}), v_t_24327});
    }
    default: return heff_nomatch(v_e1_242);
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2epresyntax_2eargOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2eargOf(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2epresyntax_2eappOf_str0 = {{0x80000000u, K_STR, 0}, 22, 22, {96, 65, 114, 114, 97, 121, 96, 32, 116, 97, 107, 101, 115, 32, 111, 110, 101, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2epresyntax_2eappOf_str1 = {{0x80000000u, K_STR, 0}, 22, 22, {96, 65, 114, 114, 97, 121, 96, 32, 116, 97, 107, 101, 115, 32, 111, 110, 101, 32, 116, 121, 112, 101}};
V g_heff_2epresyntax_2eappOf_lam0(V self, V *args);
Clo g_heff_2epresyntax_2eappOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2eappOf_entry, 4, 0};

V g_heff_2epresyntax_2eappOf(V v_r_240, V v_h_241, V v_args_242, V v_sp_243) {
top: ;
  switch (heff_tag_of(v_h_241)) {
  case TAG_At: {
    V v_it1_244 = heff_dup(heff_field(v_h_241, 0));
    V v_tsp_245 = heff_dup(heff_field(v_h_241, 1));
    switch (heff_tag_of(v_it1_244)) {
    case TAG_EVar: {
      V v_ru_24it1_244_24EVar = heff_take_reuse_n(v_it1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_247); r_; });
      V v_t_249 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_2410 = heff_tag(TAG_IApp, 2, (V[]){v_t_248, (g_prelude_2emap(v_t_249, v_args_242))});
      return heff_tag_at(v_ru_24it1_244_24EVar, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2410, v_sp_243})});
    }
    case TAG_EImplicitVar: {
      V v_ru_24it1_244_24EImplicitVar = heff_take_reuse_n(v_it1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2412); r_; });
      V v_t_2414 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_2415 = heff_tag(TAG_IApp, 2, (V[]){v_t_2413, (g_prelude_2emap(v_t_2414, v_args_242))});
      return heff_tag_at(v_ru_24it1_244_24EImplicitVar, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2415, v_sp_243})});
    }
    case TAG_ETag: {
      V v_t_2416 = heff_field(v_it1_244, 0);
      V v_ru_24it1_244_24ETag = heff_take_reuse_n(v_it1_244, 1ULL, 1);
      heff_drop_tag(v_h_241, 2);
      V v_t_2428 = heff_tag(TAG_CTag, 3, (V[]){v_t_2416, v_tsp_245, (g_prelude_2emap(heff_clo(g_heff_2epresyntax_2eappOf_lam0, 1, 1, (V[]){v_r_240}), v_args_242))});
      return heff_tag_at(v_ru_24it1_244_24ETag, TAG_IsCheckable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2428, v_sp_243})});
    }
    case TAG_EInt: {
      V v_ru_24it1_244_24EInt = heff_take_reuse_n(v_it1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_2431 = ({ V a_0 = v_t_2430; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2430); r_; });
      V v_t_2432 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_2433 = heff_tag(TAG_IApp, 2, (V[]){v_t_2431, (g_prelude_2emap(v_t_2432, v_args_242))});
      return heff_tag_at(v_ru_24it1_244_24EInt, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2433, v_sp_243})});
    }
    case TAG_EFloat: {
      V v_ru_24it1_244_24EFloat = heff_take_reuse_n(v_it1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2435 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_2436 = ({ V a_0 = v_t_2435; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2435); r_; });
      V v_t_2437 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_2438 = heff_tag(TAG_IApp, 2, (V[]){v_t_2436, (g_prelude_2emap(v_t_2437, v_args_242))});
      return heff_tag_at(v_ru_24it1_244_24EFloat, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2438, v_sp_243})});
    }
    case TAG_EString: {
      V v_ru_24it1_244_24EString = heff_take_reuse_n(v_it1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2440 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_2441 = ({ V a_0 = v_t_2440; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2440); r_; });
      V v_t_2442 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_2443 = heff_tag(TAG_IApp, 2, (V[]){v_t_2441, (g_prelude_2emap(v_t_2442, v_args_242))});
      return heff_tag_at(v_ru_24it1_244_24EString, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2443, v_sp_243})});
    }
    case TAG_EWord: {
      V v_it11_2444 = heff_field(v_it1_244, 0);
      V v_ru_24it1_244_24EWord = heff_take_reuse_n(v_it1_244, 1ULL, 1);
      heff_drop(v_tsp_245);
      switch (heff_tag_of(v_it11_2444)) {
      case TAG_TypeWord: {
        V v_t_2445 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
        V v_t_2446 = ({ V a_0 = v_t_2445; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2445); r_; });
        V v_t_2447 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_2448 = heff_tag(TAG_IApp, 2, (V[]){v_t_2446, (g_prelude_2emap(v_t_2447, v_args_242))});
        return heff_tag_at(v_ru_24it1_244_24EWord, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2448, v_sp_243})});
      }
      case TAG_IntWord: {
        V v_t_2449 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
        V v_t_2450 = ({ V a_0 = v_t_2449; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2449); r_; });
        V v_t_2451 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_2452 = heff_tag(TAG_IApp, 2, (V[]){v_t_2450, (g_prelude_2emap(v_t_2451, v_args_242))});
        return heff_tag_at(v_ru_24it1_244_24EWord, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2452, v_sp_243})});
      }
      case TAG_FloatWord: {
        V v_t_2453 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
        V v_t_2454 = ({ V a_0 = v_t_2453; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2453); r_; });
        V v_t_2455 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_2456 = heff_tag(TAG_IApp, 2, (V[]){v_t_2454, (g_prelude_2emap(v_t_2455, v_args_242))});
        return heff_tag_at(v_ru_24it1_244_24EWord, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2456, v_sp_243})});
      }
      case TAG_StringWord: {
        V v_t_2457 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
        V v_t_2458 = ({ V a_0 = v_t_2457; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2457); r_; });
        V v_t_2459 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_2460 = heff_tag(TAG_IApp, 2, (V[]){v_t_2458, (g_prelude_2emap(v_t_2459, v_args_242))});
        return heff_tag_at(v_ru_24it1_244_24EWord, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2460, v_sp_243})});
      }
      case TAG_ArrayWord: {
        heff_drop_tag(v_h_241, 2);
        switch (heff_tag_of(v_args_242)) {
        case TAG_Nil: {
          heff_drop(v_r_240);
          V v_t_2461 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(3LL), ((V)&g_heff_2epresyntax_2eappOf_str0)}), heff_dup(v_sp_243)});
          V v_t_2462 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_244_24EWord, TAG_TInf, 1, (V[]){v_t_2461}), v_sp_243});
          return heff_tag(TAG_IsType, 1, (V[]){v_t_2462});
        }
        case TAG_Cons: {
          V v_a_2463 = heff_field(v_args_242, 0);
          V v_it2_2464 = heff_field(v_args_242, 1);
          V v_ru_24args_242_24Cons = heff_take_reuse_n(v_args_242, 3ULL, 2);
          switch (heff_tag_of(v_it2_2464)) {
          case TAG_Nil: {
            V v_x1_2465 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_a_2463}));
            V v_t_2475;
            switch (heff_tag_of(v_x1_2465)) {
            case TAG_IsInferable: {
              V v_i_2466 = heff_field(v_x1_2465, 0);
              heff_take_n(v_x1_2465, 1ULL, 1);
              V v_t_2469;
              switch (heff_tag_of(v_i_2466)) {
              case TAG_At: {
                V v_s_2468 = heff_dup(heff_field(v_i_2466, 1));
                v_t_2469 = v_s_2468;
                break;
              }
              default: heff_nomatch(v_i_2466);
              }
              v_t_2475 = heff_tag_at(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_244_24EWord, TAG_TInf, 1, (V[]){v_i_2466}), v_t_2469});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_2470 = heff_field(v_x1_2465, 0);
              heff_take_n(v_x1_2465, 1ULL, 1);
              V v_t_2473;
              switch (heff_tag_of(v_c_2470)) {
              case TAG_At: {
                V v_s_2472 = heff_dup(heff_field(v_c_2470, 1));
                v_t_2473 = v_s_2472;
                break;
              }
              default: heff_nomatch(v_c_2470);
              }
              v_t_2475 = heff_tag_at(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_244_24EWord, TAG_TChk, 1, (V[]){v_c_2470}), v_t_2473});
              break;
            }
            case TAG_IsType: {
              V v_t_2474 = heff_field(v_x1_2465, 0);
              heff_take_n(v_x1_2465, 1ULL, 1);
              heff_drop_cell(v_ru_24it1_244_24EWord, 1);
              heff_drop_cell(v_ru_24args_242_24Cons, 2);
              v_t_2475 = v_t_2474;
              break;
            }
            default: heff_nomatch(v_x1_2465);
            }
            V v_t_2476 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_TArray, 1, (V[]){v_t_2475}), v_sp_243});
            return heff_tag(TAG_IsType, 1, (V[]){v_t_2476});
          }
          case TAG_Cons: {
            V v_ru_24it2_2464_24Cons = heff_take_reuse_n(v_it2_2464, 0ULL, 2);
            heff_drop(v_r_240);
            heff_drop(v_a_2463);
            V v_t_2479 = heff_tag_at(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(3LL), ((V)&g_heff_2epresyntax_2eappOf_str1)}), heff_dup(v_sp_243)});
            V v_t_2480 = heff_tag_at(v_ru_24it2_2464_24Cons, TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_244_24EWord, TAG_TInf, 1, (V[]){v_t_2479}), v_sp_243});
            return heff_tag(TAG_IsType, 1, (V[]){v_t_2480});
          }
          default: return heff_nomatch(v_it2_2464);
          }
        }
        default: return heff_nomatch(v_args_242);
        }
      }
      case TAG_AbandonWord: {
        V v_t_2481 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
        V v_t_2482 = ({ V a_0 = v_t_2481; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2481); r_; });
        V v_t_2483 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_2484 = heff_tag(TAG_IApp, 2, (V[]){v_t_2482, (g_prelude_2emap(v_t_2483, v_args_242))});
        return heff_tag_at(v_ru_24it1_244_24EWord, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2484, v_sp_243})});
      }
      case TAG_FixedWord: {
        heff_take_n(v_it11_2444, 0ULL, 1);
        V v_t_2486 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
        V v_t_2487 = ({ V a_0 = v_t_2486; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2486); r_; });
        V v_t_2488 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_2489 = heff_tag(TAG_IApp, 2, (V[]){v_t_2487, (g_prelude_2emap(v_t_2488, v_args_242))});
        return heff_tag_at(v_ru_24it1_244_24EWord, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2489, v_sp_243})});
      }
      default: return heff_nomatch(v_it11_2444);
      }
    }
    case TAG_EApp: {
      V v_ru_24it1_244_24EApp = heff_take_reuse_n(v_it1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_2492 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_2493 = ({ V a_0 = v_t_2492; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2492); r_; });
      V v_t_2494 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_2495 = heff_tag_at(v_ru_24it1_244_24EApp, TAG_IApp, 2, (V[]){v_t_2493, (g_prelude_2emap(v_t_2494, v_args_242))});
      return heff_tag(TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2495, v_sp_243})});
    }
    case TAG_EProject: {
      V v_ru_24it1_244_24EProject = heff_take_reuse_n(v_it1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2497 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_2498 = ({ V a_0 = v_t_2497; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2497); r_; });
      V v_t_2499 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24100 = heff_tag(TAG_IApp, 2, (V[]){v_t_2498, (g_prelude_2emap(v_t_2499, v_args_242))});
      return heff_tag_at(v_ru_24it1_244_24EProject, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24100, v_sp_243})});
    }
    case TAG_ENamed: {
      V v_ru_24it1_244_24ENamed = heff_take_reuse_n(v_it1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24103 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_24104 = ({ V a_0 = v_t_24103; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24103); r_; });
      V v_t_24105 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24106 = heff_tag_at(v_ru_24it1_244_24ENamed, TAG_IApp, 2, (V[]){v_t_24104, (g_prelude_2emap(v_t_24105, v_args_242))});
      return heff_tag(TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24106, v_sp_243})});
    }
    case TAG_EPi: {
      V v_ru_24it1_244_24EPi = heff_take_reuse_n(v_it1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24109 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_24110 = ({ V a_0 = v_t_24109; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24109); r_; });
      V v_t_24111 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24112 = heff_tag_at(v_ru_24it1_244_24EPi, TAG_IApp, 2, (V[]){v_t_24110, (g_prelude_2emap(v_t_24111, v_args_242))});
      return heff_tag(TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24112, v_sp_243})});
    }
    case TAG_ELam: {
      V v_ru_24it1_244_24ELam = heff_take_reuse_n(v_it1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24115 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_24116 = ({ V a_0 = v_t_24115; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24115); r_; });
      V v_t_24117 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24118 = heff_tag_at(v_ru_24it1_244_24ELam, TAG_IApp, 2, (V[]){v_t_24116, (g_prelude_2emap(v_t_24117, v_args_242))});
      return heff_tag(TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24118, v_sp_243})});
    }
    case TAG_EAnn: {
      V v_ru_24it1_244_24EAnn = heff_take_reuse_n(v_it1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24121 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_24122 = ({ V a_0 = v_t_24121; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24121); r_; });
      V v_t_24123 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24124 = heff_tag_at(v_ru_24it1_244_24EAnn, TAG_IApp, 2, (V[]){v_t_24122, (g_prelude_2emap(v_t_24123, v_args_242))});
      return heff_tag(TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24124, v_sp_243})});
    }
    case TAG_ESpec: {
      heff_take_n(v_it1_244, 0ULL, 4);
      heff_drop(v_tsp_245);
      V v_t_24129 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_24130 = ({ V a_0 = v_t_24129; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24129); r_; });
      V v_t_24131 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24132 = heff_tag(TAG_IApp, 2, (V[]){v_t_24130, (g_prelude_2emap(v_t_24131, v_args_242))});
      return heff_tag(TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24132, v_sp_243})});
    }
    case TAG_ESig: {
      V v_ru_24it1_244_24ESig = heff_take_reuse_n(v_it1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24134 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_24135 = ({ V a_0 = v_t_24134; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24134); r_; });
      V v_t_24136 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24137 = heff_tag(TAG_IApp, 2, (V[]){v_t_24135, (g_prelude_2emap(v_t_24136, v_args_242))});
      return heff_tag_at(v_ru_24it1_244_24ESig, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24137, v_sp_243})});
    }
    case TAG_ESum: {
      V v_ru_24it1_244_24ESum = heff_take_reuse_n(v_it1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24139 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_24140 = ({ V a_0 = v_t_24139; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24139); r_; });
      V v_t_24141 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24142 = heff_tag(TAG_IApp, 2, (V[]){v_t_24140, (g_prelude_2emap(v_t_24141, v_args_242))});
      return heff_tag_at(v_ru_24it1_244_24ESum, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24142, v_sp_243})});
    }
    case TAG_EStruct: {
      V v_ru_24it1_244_24EStruct = heff_take_reuse_n(v_it1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24144 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_24145 = ({ V a_0 = v_t_24144; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24144); r_; });
      V v_t_24146 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24147 = heff_tag(TAG_IApp, 2, (V[]){v_t_24145, (g_prelude_2emap(v_t_24146, v_args_242))});
      return heff_tag_at(v_ru_24it1_244_24EStruct, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24147, v_sp_243})});
    }
    case TAG_EMatch: {
      V v_ru_24it1_244_24EMatch = heff_take_reuse_n(v_it1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24150 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_24151 = ({ V a_0 = v_t_24150; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24150); r_; });
      V v_t_24152 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24153 = heff_tag_at(v_ru_24it1_244_24EMatch, TAG_IApp, 2, (V[]){v_t_24151, (g_prelude_2emap(v_t_24152, v_args_242))});
      return heff_tag(TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24153, v_sp_243})});
    }
    case TAG_ELetIn: {
      V v_ru_24it1_244_24ELetIn = heff_take_reuse_n(v_it1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24156 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_24157 = ({ V a_0 = v_t_24156; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24156); r_; });
      V v_t_24158 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24159 = heff_tag_at(v_ru_24it1_244_24ELetIn, TAG_IApp, 2, (V[]){v_t_24157, (g_prelude_2emap(v_t_24158, v_args_242))});
      return heff_tag(TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24159, v_sp_243})});
    }
    case TAG_EDo: {
      V v_ru_24it1_244_24EDo = heff_take_reuse_n(v_it1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24161 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_24162 = ({ V a_0 = v_t_24161; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24161); r_; });
      V v_t_24163 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24164 = heff_tag(TAG_IApp, 2, (V[]){v_t_24162, (g_prelude_2emap(v_t_24163, v_args_242))});
      return heff_tag_at(v_ru_24it1_244_24EDo, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24164, v_sp_243})});
    }
    case TAG_ELocal: {
      V v_ru_24it1_244_24ELocal = heff_take_reuse_n(v_it1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24167 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_24168 = ({ V a_0 = v_t_24167; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24167); r_; });
      V v_t_24169 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24170 = heff_tag_at(v_ru_24it1_244_24ELocal, TAG_IApp, 2, (V[]){v_t_24168, (g_prelude_2emap(v_t_24169, v_args_242))});
      return heff_tag(TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24170, v_sp_243})});
    }
    case TAG_EInvalid: {
      V v_ru_24it1_244_24EInvalid = heff_take_reuse_n(v_it1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24172 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_h_241}));
      V v_t_24173 = ({ V a_0 = v_t_24172; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24172); r_; });
      V v_t_24174 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24175 = heff_tag(TAG_IApp, 2, (V[]){v_t_24173, (g_prelude_2emap(v_t_24174, v_args_242))});
      return heff_tag_at(v_ru_24it1_244_24EInvalid, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24175, v_sp_243})});
    }
    default: return heff_nomatch(v_it1_244);
    }
  }
  default: return heff_nomatch(v_h_241);
  }
}
V g_heff_2epresyntax_2eappOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2eappOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2epresyntax_2eappOf_lam0(V self, V *args) {
  V v_e_2417 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2418 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_2417}));
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_IsInferable: {
    V v_i_2419 = heff_field(v_x1_2418, 0);
    V v_ru_24x1_2418_24IsInferable = heff_take_reuse_n(v_x1_2418, 1ULL, 1);
    V v_t_2422;
    switch (heff_tag_of(v_i_2419)) {
    case TAG_At: {
      V v_s_2421 = heff_dup(heff_field(v_i_2419, 1));
      v_t_2422 = v_s_2421;
      break;
    }
    default: heff_nomatch(v_i_2419);
    }
    return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_2418_24IsInferable, TAG_CInf, 1, (V[]){v_i_2419}), v_t_2422});
  }
  case TAG_IsCheckable: {
    V v_c_2423 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    return v_c_2423;
  }
  case TAG_IsType: {
    V v_t_2424 = heff_field(v_x1_2418, 0);
    V v_ru_24x1_2418_24IsType = heff_take_reuse_n(v_x1_2418, 1ULL, 1);
    V v_t_2427;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_At: {
      V v_s_2426 = heff_dup(heff_field(v_t_2424, 1));
      v_t_2427 = v_s_2426;
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_2418_24IsType, TAG_CType, 1, (V[]){v_t_2424}), v_t_2427});
  }
  default: return heff_nomatch(v_x1_2418);
  }
}
Clo g_heff_2epresyntax_2epiBinderOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2epiBinderOf_entry, 2, 0};

V g_heff_2epresyntax_2epiBinderOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xsp_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24PiNamed = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_x1_245 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_t_244}));
    V v_t_2415;
    switch (heff_tag_of(v_x1_245)) {
    case TAG_IsInferable: {
      V v_i_246 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24IsInferable = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      V v_t_249;
      switch (heff_tag_of(v_i_246)) {
      case TAG_At: {
        V v_s_248 = heff_dup(heff_field(v_i_246, 1));
        v_t_249 = v_s_248;
        break;
      }
      default: heff_nomatch(v_i_246);
      }
      v_t_2415 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_245_24IsInferable, TAG_TInf, 1, (V[]){v_i_246}), v_t_249});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2410 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24IsCheckable = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      V v_t_2413;
      switch (heff_tag_of(v_c_2410)) {
      case TAG_At: {
        V v_s_2412 = heff_dup(heff_field(v_c_2410, 1));
        v_t_2413 = v_s_2412;
        break;
      }
      default: heff_nomatch(v_c_2410);
      }
      v_t_2415 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_245_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2410}), v_t_2413});
      break;
    }
    case TAG_IsType: {
      V v_t_2414 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      v_t_2415 = v_t_2414;
      break;
    }
    default: heff_nomatch(v_x1_245);
    }
    return heff_tag_at(v_ru_24x2_241_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_242, v_xsp_243, v_t_2415});
  }
  case TAG_PiImplicit: {
    V v_x_2416 = heff_field(v_x2_241, 0);
    V v_xsp_2417 = heff_field(v_x2_241, 1);
    V v_bsp_2418 = heff_field(v_x2_241, 2);
    V v_t_2419 = heff_field(v_x2_241, 3);
    V v_d_2420 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24PiImplicit = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_x1_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_t_2419}));
    V v_t_2431;
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_IsInferable: {
      V v_i_2422 = heff_field(v_x1_2421, 0);
      V v_ru_24x1_2421_24IsInferable = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
      V v_t_2425;
      switch (heff_tag_of(v_i_2422)) {
      case TAG_At: {
        V v_s_2424 = heff_dup(heff_field(v_i_2422, 1));
        v_t_2425 = v_s_2424;
        break;
      }
      default: heff_nomatch(v_i_2422);
      }
      v_t_2431 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_2421_24IsInferable, TAG_TInf, 1, (V[]){v_i_2422}), v_t_2425});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2426 = heff_field(v_x1_2421, 0);
      V v_ru_24x1_2421_24IsCheckable = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
      V v_t_2429;
      switch (heff_tag_of(v_c_2426)) {
      case TAG_At: {
        V v_s_2428 = heff_dup(heff_field(v_c_2426, 1));
        v_t_2429 = v_s_2428;
        break;
      }
      default: heff_nomatch(v_c_2426);
      }
      v_t_2431 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_2421_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2426}), v_t_2429});
      break;
    }
    case TAG_IsType: {
      V v_t_2430 = heff_field(v_x1_2421, 0);
      heff_take_n(v_x1_2421, 1ULL, 1);
      v_t_2431 = v_t_2430;
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
    V v_t_2444;
    switch (heff_tag_of(v_d_2420)) {
    case TAG_Nothing: {
      heff_drop(v_r_240);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2432 = heff_field(v_d_2420, 0);
      V v_ru_24d_2420_24Just = heff_take_reuse_n(v_d_2420, 1ULL, 1);
      V v_x1_2433 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_x_2432}));
      V v_t_2443;
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_IsInferable: {
        V v_i_2434 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        V v_t_2437;
        switch (heff_tag_of(v_i_2434)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_i_2434, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_i_2434);
        }
        v_t_2443 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24d_2420_24Just, TAG_CInf, 1, (V[]){v_i_2434}), v_t_2437});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2438 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        heff_drop_cell(v_ru_24d_2420_24Just, 1);
        v_t_2443 = v_c_2438;
        break;
      }
      case TAG_IsType: {
        V v_t_2439 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        V v_t_2442;
        switch (heff_tag_of(v_t_2439)) {
        case TAG_At: {
          V v_s_2441 = heff_dup(heff_field(v_t_2439, 1));
          v_t_2442 = v_s_2441;
          break;
        }
        default: heff_nomatch(v_t_2439);
        }
        v_t_2443 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24d_2420_24Just, TAG_CType, 1, (V[]){v_t_2439}), v_t_2442});
        break;
      }
      default: heff_nomatch(v_x1_2433);
      }
      v_t_2444 = heff_tag(TAG_Just, 1, (V[]){v_t_2443});
      break;
    }
    default: heff_nomatch(v_d_2420);
    }
    return heff_tag_at(v_ru_24x2_241_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_2416, v_xsp_2417, v_bsp_2418, v_t_2431, v_t_2444});
  }
  case TAG_PiInstance: {
    V v_x_2445 = heff_field(v_x2_241, 0);
    V v_xsp_2446 = heff_field(v_x2_241, 1);
    V v_bsp_2447 = heff_field(v_x2_241, 2);
    V v_t_2448 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24PiInstance = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_x1_2449 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_t_2448}));
    V v_t_2459;
    switch (heff_tag_of(v_x1_2449)) {
    case TAG_IsInferable: {
      V v_i_2450 = heff_field(v_x1_2449, 0);
      V v_ru_24x1_2449_24IsInferable = heff_take_reuse_n(v_x1_2449, 1ULL, 1);
      V v_t_2453;
      switch (heff_tag_of(v_i_2450)) {
      case TAG_At: {
        V v_s_2452 = heff_dup(heff_field(v_i_2450, 1));
        v_t_2453 = v_s_2452;
        break;
      }
      default: heff_nomatch(v_i_2450);
      }
      v_t_2459 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_2449_24IsInferable, TAG_TInf, 1, (V[]){v_i_2450}), v_t_2453});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2454 = heff_field(v_x1_2449, 0);
      V v_ru_24x1_2449_24IsCheckable = heff_take_reuse_n(v_x1_2449, 1ULL, 1);
      V v_t_2457;
      switch (heff_tag_of(v_c_2454)) {
      case TAG_At: {
        V v_s_2456 = heff_dup(heff_field(v_c_2454, 1));
        v_t_2457 = v_s_2456;
        break;
      }
      default: heff_nomatch(v_c_2454);
      }
      v_t_2459 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_2449_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2454}), v_t_2457});
      break;
    }
    case TAG_IsType: {
      V v_t_2458 = heff_field(v_x1_2449, 0);
      heff_take_n(v_x1_2449, 1ULL, 1);
      v_t_2459 = v_t_2458;
      break;
    }
    default: heff_nomatch(v_x1_2449);
    }
    return heff_tag_at(v_ru_24x2_241_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2445, v_xsp_2446, v_bsp_2447, v_t_2459});
  }
  case TAG_PiAnon: {
    V v_t_2460 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24PiAnon = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x1_2461 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_t_2460}));
    V v_t_2471;
    switch (heff_tag_of(v_x1_2461)) {
    case TAG_IsInferable: {
      V v_i_2462 = heff_field(v_x1_2461, 0);
      heff_take_n(v_x1_2461, 1ULL, 1);
      V v_t_2465;
      switch (heff_tag_of(v_i_2462)) {
      case TAG_At: {
        V v_s_2464 = heff_dup(heff_field(v_i_2462, 1));
        v_t_2465 = v_s_2464;
        break;
      }
      default: heff_nomatch(v_i_2462);
      }
      v_t_2471 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x2_241_24PiAnon, TAG_TInf, 1, (V[]){v_i_2462}), v_t_2465});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2466 = heff_field(v_x1_2461, 0);
      heff_take_n(v_x1_2461, 1ULL, 1);
      V v_t_2469;
      switch (heff_tag_of(v_c_2466)) {
      case TAG_At: {
        V v_s_2468 = heff_dup(heff_field(v_c_2466, 1));
        v_t_2469 = v_s_2468;
        break;
      }
      default: heff_nomatch(v_c_2466);
      }
      v_t_2471 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x2_241_24PiAnon, TAG_TChk, 1, (V[]){v_c_2466}), v_t_2469});
      break;
    }
    case TAG_IsType: {
      V v_t_2470 = heff_field(v_x1_2461, 0);
      heff_take_n(v_x1_2461, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24PiAnon, 1);
      v_t_2471 = v_t_2470;
      break;
    }
    default: heff_nomatch(v_x1_2461);
    }
    return heff_tag(TAG_PiAnon, 1, (V[]){v_t_2471});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2epresyntax_2epiBinderOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2epiBinderOf(a[0], a[1]);
}
Clo g_heff_2epresyntax_2ealtOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2ealtOf_entry, 2, 0};

V g_heff_2epresyntax_2ealtOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkAlt: {
      V v_p_244 = heff_field(v_x21_242, 0);
      V v_b_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24MkAlt = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_246 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_b_245}));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2416 = v_c_2411;
        break;
      }
      case TAG_IsType: {
        V v_t_2412 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_t_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        v_t_2416 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_2412}), v_t_2415});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag_at(v_ru_24x21_242_24MkAlt, TAG_At, 2, (V[]){heff_tag(TAG_MkAlt, 2, (V[]){v_p_244, v_t_2416}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2epresyntax_2ealtOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2ealtOf(a[0], a[1]);
}
Clo g_heff_2epresyntax_2efieldDeclOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2efieldDeclOf_entry, 2, 0};

V g_heff_2epresyntax_2efieldDeclOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclareField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_xsp_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_d_247 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24DeclareField = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_x1_248 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_t_246}));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_c_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_c_2413);
        }
        v_t_2418 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
        break;
      }
      case TAG_IsType: {
        V v_t_2417 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2418 = v_t_2417;
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      V v_t_2431;
      switch (heff_tag_of(v_d_247)) {
      case TAG_Nothing: {
        heff_drop(v_r_240);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2419 = heff_field(v_d_247, 0);
        V v_ru_24d_247_24Just = heff_take_reuse_n(v_d_247, 1ULL, 1);
        V v_x1_2420 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_x_2419}));
        V v_t_2430;
        switch (heff_tag_of(v_x1_2420)) {
        case TAG_IsInferable: {
          V v_i_2421 = heff_field(v_x1_2420, 0);
          heff_take_n(v_x1_2420, 1ULL, 1);
          V v_t_2424;
          switch (heff_tag_of(v_i_2421)) {
          case TAG_At: {
            V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
            v_t_2424 = v_s_2423;
            break;
          }
          default: heff_nomatch(v_i_2421);
          }
          v_t_2430 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24d_247_24Just, TAG_CInf, 1, (V[]){v_i_2421}), v_t_2424});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2425 = heff_field(v_x1_2420, 0);
          heff_take_n(v_x1_2420, 1ULL, 1);
          heff_drop_cell(v_ru_24d_247_24Just, 1);
          v_t_2430 = v_c_2425;
          break;
        }
        case TAG_IsType: {
          V v_t_2426 = heff_field(v_x1_2420, 0);
          heff_take_n(v_x1_2420, 1ULL, 1);
          V v_t_2429;
          switch (heff_tag_of(v_t_2426)) {
          case TAG_At: {
            V v_s_2428 = heff_dup(heff_field(v_t_2426, 1));
            v_t_2429 = v_s_2428;
            break;
          }
          default: heff_nomatch(v_t_2426);
          }
          v_t_2430 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24d_247_24Just, TAG_CType, 1, (V[]){v_t_2426}), v_t_2429});
          break;
        }
        default: heff_nomatch(v_x1_2420);
        }
        v_t_2431 = heff_tag(TAG_Just, 1, (V[]){v_t_2430});
        break;
      }
      default: heff_nomatch(v_d_247);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x21_242_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_244, v_xsp_245, v_t_2418, v_t_2431}), v_sp_243});
    }
    case TAG_BadFieldDecl: {
      V v_e_2432 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24BadFieldDecl = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_2433 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_2432}));
      V v_t_2443;
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_IsInferable: {
        V v_i_2434 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        V v_t_2437;
        switch (heff_tag_of(v_i_2434)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_i_2434, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_i_2434);
        }
        v_t_2443 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_2434}), v_t_2437});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2438 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        V v_t_2441;
        switch (heff_tag_of(v_c_2438)) {
        case TAG_At: {
          V v_s_2440 = heff_dup(heff_field(v_c_2438, 1));
          v_t_2441 = v_s_2440;
          break;
        }
        default: heff_nomatch(v_c_2438);
        }
        v_t_2443 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2438}), v_t_2441});
        break;
      }
      case TAG_IsType: {
        V v_t_2442 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2443 = v_t_2442;
        break;
      }
      default: heff_nomatch(v_x1_2433);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x21_242_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2443}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2epresyntax_2efieldDeclOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2efieldDeclOf(a[0], a[1]);
}
Clo g_heff_2epresyntax_2efieldSetOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2efieldSetOf_entry, 2, 0};

V g_heff_2epresyntax_2efieldSetOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SetField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_xsp_245 = heff_field(v_x21_242, 1);
      V v_e_246 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24SetField = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_247 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_246}));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2417 = v_c_2412;
        break;
      }
      case TAG_IsType: {
        V v_t_2413 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_t_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_t_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        v_t_2417 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_2413}), v_t_2416});
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x21_242_24SetField, TAG_SetField, 3, (V[]){v_x_244, v_xsp_245, v_t_2417}), v_sp_243});
    }
    case TAG_BadFieldSet: {
      V v_e_2418 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24BadFieldSet = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_2419 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_2418}));
      V v_t_2429;
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_IsInferable: {
        V v_i_2420 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        V v_t_2423;
        switch (heff_tag_of(v_i_2420)) {
        case TAG_At: {
          V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
          v_t_2423 = v_s_2422;
          break;
        }
        default: heff_nomatch(v_i_2420);
        }
        v_t_2429 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_2420}), v_t_2423});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2424 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2429 = v_c_2424;
        break;
      }
      case TAG_IsType: {
        V v_t_2425 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        V v_t_2428;
        switch (heff_tag_of(v_t_2425)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_t_2425, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_t_2425);
        }
        v_t_2429 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
        break;
      }
      default: heff_nomatch(v_x1_2419);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x21_242_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2429}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2epresyntax_2efieldSetOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2efieldSetOf(a[0], a[1]);
}
V g_heff_2epresyntax_2evariantOf_lam0(V self, V *args);
Clo g_heff_2epresyntax_2evariantOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2evariantOf_entry, 2, 0};

V g_heff_2epresyntax_2evariantOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_TagVariant: {
      V v_t_244 = heff_field(v_x21_242, 0);
      V v_tsp_245 = heff_field(v_x21_242, 1);
      V v_args_246 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24TagVariant = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_t_2418 = heff_tag_at(v_ru_24x21_242_24TagVariant, TAG_TagVariant, 3, (V[]){v_t_244, v_tsp_245, (g_prelude_2emap(heff_clo(g_heff_2epresyntax_2evariantOf_lam0, 1, 1, (V[]){v_r_240}), v_args_246))});
      return heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2418, v_sp_243});
    }
    case TAG_BadVariant: {
      V v_e_2419 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24BadVariant = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_2420 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_2419}));
      V v_t_2430;
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_IsInferable: {
        V v_i_2421 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2424;
        switch (heff_tag_of(v_i_2421)) {
        case TAG_At: {
          V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_i_2421);
        }
        v_t_2430 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_2421}), v_t_2424});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2425 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2428;
        switch (heff_tag_of(v_c_2425)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_c_2425, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_c_2425);
        }
        v_t_2430 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2425}), v_t_2428});
        break;
      }
      case TAG_IsType: {
        V v_t_2429 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2430 = v_t_2429;
        break;
      }
      default: heff_nomatch(v_x1_2420);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x21_242_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2430}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2epresyntax_2evariantOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2evariantOf(a[0], a[1]);
}
V g_heff_2epresyntax_2evariantOf_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_248 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_IsInferable: {
    V v_i_249 = heff_field(v_x1_248, 0);
    V v_ru_24x1_248_24IsInferable = heff_take_reuse_n(v_x1_248, 1ULL, 1);
    V v_t_2412;
    switch (heff_tag_of(v_i_249)) {
    case TAG_At: {
      V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
      v_t_2412 = v_s_2411;
      break;
    }
    default: heff_nomatch(v_i_249);
    }
    return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_248_24IsInferable, TAG_TInf, 1, (V[]){v_i_249}), v_t_2412});
  }
  case TAG_IsCheckable: {
    V v_c_2413 = heff_field(v_x1_248, 0);
    V v_ru_24x1_248_24IsCheckable = heff_take_reuse_n(v_x1_248, 1ULL, 1);
    V v_t_2416;
    switch (heff_tag_of(v_c_2413)) {
    case TAG_At: {
      V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
      v_t_2416 = v_s_2415;
      break;
    }
    default: heff_nomatch(v_c_2413);
    }
    return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_248_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
  }
  case TAG_IsType: {
    V v_t_2417 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    return v_t_2417;
  }
  default: return heff_nomatch(v_x1_248);
  }
}
Clo g_heff_2epresyntax_2eannLamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2eannLamOf_entry, 5, 0};

V g_heff_2epresyntax_2eannLamOf(V v_x_240, V v_xsp_241, V v_t_242, V v_b_243, V v_sp_244) {
top: ;
  switch (heff_tag_of(v_b_243)) {
  case TAG_IsInferable: {
    V v_b1_245 = heff_field(v_b_243, 0);
    V v_ru_24b_243_24IsInferable = heff_take_reuse_n(v_b_243, 1ULL, 1);
    V v_t_246 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_b1_245}), v_sp_244});
    return heff_tag_at(v_ru_24b_243_24IsInferable, TAG_IsInferable, 1, (V[]){v_t_246});
  }
  case TAG_IsCheckable: {
    V v_t_2417;
    switch (heff_tag_of(v_b_243)) {
    case TAG_IsInferable: {
      V v_i_248 = heff_field(v_b_243, 0);
      V v_ru_24b_243_24IsInferable = heff_take_reuse_n(v_b_243, 1ULL, 1);
      V v_t_2411;
      switch (heff_tag_of(v_i_248)) {
      case TAG_At: {
        V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
        v_t_2411 = v_s_2410;
        break;
      }
      default: heff_nomatch(v_i_248);
      }
      v_t_2417 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24b_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2412 = heff_field(v_b_243, 0);
      heff_take_n(v_b_243, 1ULL, 1);
      v_t_2417 = v_c_2412;
      break;
    }
    case TAG_IsType: {
      V v_t_2413 = heff_field(v_b_243, 0);
      V v_ru_24b_243_24IsType = heff_take_reuse_n(v_b_243, 1ULL, 1);
      V v_t_2416;
      switch (heff_tag_of(v_t_2413)) {
      case TAG_At: {
        V v_s_2415 = heff_dup(heff_field(v_t_2413, 1));
        v_t_2416 = v_s_2415;
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      v_t_2417 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24b_243_24IsType, TAG_CType, 1, (V[]){v_t_2413}), v_t_2416});
      break;
    }
    default: heff_nomatch(v_b_243);
    }
    V v_t_2418 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_CAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_t_2417}), v_sp_244});
    return heff_tag(TAG_IsCheckable, 1, (V[]){v_t_2418});
  }
  case TAG_IsType: {
    V v_t_2429;
    switch (heff_tag_of(v_b_243)) {
    case TAG_IsInferable: {
      V v_i_2420 = heff_field(v_b_243, 0);
      V v_ru_24b_243_24IsInferable = heff_take_reuse_n(v_b_243, 1ULL, 1);
      V v_t_2423;
      switch (heff_tag_of(v_i_2420)) {
      case TAG_At: {
        V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
        v_t_2423 = v_s_2422;
        break;
      }
      default: heff_nomatch(v_i_2420);
      }
      v_t_2429 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24b_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_2420}), v_t_2423});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2424 = heff_field(v_b_243, 0);
      heff_take_n(v_b_243, 1ULL, 1);
      v_t_2429 = v_c_2424;
      break;
    }
    case TAG_IsType: {
      V v_t_2425 = heff_field(v_b_243, 0);
      V v_ru_24b_243_24IsType = heff_take_reuse_n(v_b_243, 1ULL, 1);
      V v_t_2428;
      switch (heff_tag_of(v_t_2425)) {
      case TAG_At: {
        V v_s_2427 = heff_dup(heff_field(v_t_2425, 1));
        v_t_2428 = v_s_2427;
        break;
      }
      default: heff_nomatch(v_t_2425);
      }
      v_t_2429 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24b_243_24IsType, TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
      break;
    }
    default: heff_nomatch(v_b_243);
    }
    V v_t_2430 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_CAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_t_2429}), v_sp_244});
    return heff_tag(TAG_IsCheckable, 1, (V[]){v_t_2430});
  }
  default: return heff_nomatch(v_b_243);
  }
}
V g_heff_2epresyntax_2eannLamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2eannLamOf(a[0], a[1], a[2], a[3], a[4]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2epresyntax_2eclassifyTermF_str0 = {{0x80000000u, K_STR, 0}, 19, 19, {117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2epresyntax_2eclassifyTermF_str1 = {{0x80000000u, K_STR, 0}, 19, 19, {117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2epresyntax_2eclassifyTermF_str2 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 96, 100, 111, 96, 32, 98, 108, 111, 99, 107, 32, 101, 110, 100, 115, 32, 119, 105, 116, 104, 32, 97, 110, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2epresyntax_2eclassifyTermF_str3 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 96, 100, 111, 96, 32, 98, 108, 111, 99, 107, 32, 101, 110, 100, 115, 32, 119, 105, 116, 104, 32, 97, 110, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110}};
Clo g_heff_2epresyntax_2eclassifyTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2eclassifyTermF_entry, 2, 0};

V g_heff_2epresyntax_2eclassifyTermF(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_At: {
    V v_it1_242 = heff_field(v_e_241, 0);
    V v_sp_243 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_it1_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24EVar = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      heff_drop(v_r_240);
      V v_t_245 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_IVar, 1, (V[]){v_x_244}), v_sp_243});
      return heff_tag_at(v_ru_24it1_242_24EVar, TAG_IsInferable, 1, (V[]){v_t_245});
    }
    case TAG_EImplicitVar: {
      V v_x_246 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24EImplicitVar = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      heff_drop(v_r_240);
      V v_t_247 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_IVar, 1, (V[]){v_x_246}), v_sp_243});
      return heff_tag_at(v_ru_24it1_242_24EImplicitVar, TAG_IsInferable, 1, (V[]){v_t_247});
    }
    case TAG_ETag: {
      V v_t_248 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24ETag = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      heff_drop(v_r_240);
      V v_t_249 = heff_tag(TAG_CTag, 3, (V[]){v_t_248, heff_dup(v_sp_243), NTAG(TAG_Nil)});
      return heff_tag_at(v_ru_24it1_242_24ETag, TAG_IsCheckable, 1, (V[]){heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){v_t_249, v_sp_243})});
    }
    case TAG_EInt: {
      V v_i_2410 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24EInt = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      heff_drop(v_r_240);
      V v_t_2411 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_IInt, 1, (V[]){v_i_2410}), v_sp_243});
      return heff_tag_at(v_ru_24it1_242_24EInt, TAG_IsInferable, 1, (V[]){v_t_2411});
    }
    case TAG_EFloat: {
      V v_x_2412 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24EFloat = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      heff_drop(v_r_240);
      V v_t_2413 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_IFloat, 1, (V[]){v_x_2412}), v_sp_243});
      return heff_tag_at(v_ru_24it1_242_24EFloat, TAG_IsInferable, 1, (V[]){v_t_2413});
    }
    case TAG_EString: {
      V v_x_2414 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24EString = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      heff_drop(v_r_240);
      V v_t_2415 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_IString, 1, (V[]){v_x_2414}), v_sp_243});
      return heff_tag_at(v_ru_24it1_242_24EString, TAG_IsInferable, 1, (V[]){v_t_2415});
    }
    case TAG_EWord: {
      V v_w_2416 = heff_field(v_it1_242, 0);
      heff_take_n(v_it1_242, 1ULL, 1);
      heff_drop(v_r_240);
      heff_drop_cell(v_ru_24e_241_24At, 2);
      HEFF_LAST return g_heff_2epresyntax_2ewordOf(v_w_2416, v_sp_243);
    }
    case TAG_EApp: {
      V v_h_2417 = heff_field(v_it1_242, 0);
      V v_args_2418 = heff_field(v_it1_242, 1);
      heff_take_n(v_it1_242, 3ULL, 2);
      heff_drop_cell(v_ru_24e_241_24At, 2);
      return (g_heff_2epresyntax_2eappOf(v_r_240, v_h_2417, v_args_2418, v_sp_243));
    }
    case TAG_EProject: {
      V v_ru_24it1_242_24EProject = heff_take_reuse_n(v_it1_242, 0ULL, 1);
      heff_drop(v_r_240);
      V v_t_2420 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(3LL), ((V)&g_heff_2epresyntax_2eclassifyTermF_str0)}), v_sp_243});
      return heff_tag_at(v_ru_24it1_242_24EProject, TAG_IsInferable, 1, (V[]){v_t_2420});
    }
    case TAG_ENamed: {
      heff_take_n(v_it1_242, 0ULL, 2);
      heff_drop(v_r_240);
      V v_t_2423 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(3LL), ((V)&g_heff_2epresyntax_2eclassifyTermF_str1)}), v_sp_243});
      return heff_tag(TAG_IsInferable, 1, (V[]){v_t_2423});
    }
    case TAG_EPi: {
      V v_b_2424 = heff_field(v_it1_242, 0);
      V v_cod_2425 = heff_field(v_it1_242, 1);
      V v_ru_24it1_242_24EPi = heff_take_reuse_n(v_it1_242, 3ULL, 2);
      V v_t_2426 = (g_heff_2epresyntax_2epiBinderOf(heff_dup(v_r_240), v_b_2424));
      V v_x1_2427 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_cod_2425}));
      V v_t_2437;
      switch (heff_tag_of(v_x1_2427)) {
      case TAG_IsInferable: {
        V v_i_2428 = heff_field(v_x1_2427, 0);
        heff_take_n(v_x1_2427, 1ULL, 1);
        V v_t_2431;
        switch (heff_tag_of(v_i_2428)) {
        case TAG_At: {
          V v_s_2430 = heff_dup(heff_field(v_i_2428, 1));
          v_t_2431 = v_s_2430;
          break;
        }
        default: heff_nomatch(v_i_2428);
        }
        v_t_2437 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_2428}), v_t_2431});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2432 = heff_field(v_x1_2427, 0);
        heff_take_n(v_x1_2427, 1ULL, 1);
        V v_t_2435;
        switch (heff_tag_of(v_c_2432)) {
        case TAG_At: {
          V v_s_2434 = heff_dup(heff_field(v_c_2432, 1));
          v_t_2435 = v_s_2434;
          break;
        }
        default: heff_nomatch(v_c_2432);
        }
        v_t_2437 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2432}), v_t_2435});
        break;
      }
      case TAG_IsType: {
        V v_t_2436 = heff_field(v_x1_2427, 0);
        heff_take_n(v_x1_2427, 1ULL, 1);
        heff_drop_cell(v_ru_24e_241_24At, 2);
        v_t_2437 = v_t_2436;
        break;
      }
      default: heff_nomatch(v_x1_2427);
      }
      V v_t_2438 = heff_tag_at(v_ru_24it1_242_24EPi, TAG_At, 2, (V[]){heff_tag(TAG_TPi, 2, (V[]){v_t_2426, v_t_2437}), v_sp_243});
      return heff_tag(TAG_IsType, 1, (V[]){v_t_2438});
    }
    case TAG_ELam: {
      V v_it11_2439 = heff_field(v_it1_242, 0);
      V v_body_2440 = heff_field(v_it1_242, 1);
      V v_ru_24it1_242_24ELam = heff_take_reuse_n(v_it1_242, 3ULL, 2);
      switch (heff_tag_of(v_it11_2439)) {
      case TAG_LamName: {
        V v_x_2441 = heff_field(v_it11_2439, 0);
        V v_xsp_2442 = heff_field(v_it11_2439, 1);
        heff_take_n(v_it11_2439, 3ULL, 2);
        V v_x1_2443 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_body_2440}));
        V v_t_2453;
        switch (heff_tag_of(v_x1_2443)) {
        case TAG_IsInferable: {
          V v_i_2444 = heff_field(v_x1_2443, 0);
          heff_take_n(v_x1_2443, 1ULL, 1);
          V v_t_2447;
          switch (heff_tag_of(v_i_2444)) {
          case TAG_At: {
            V v_s_2446 = heff_dup(heff_field(v_i_2444, 1));
            v_t_2447 = v_s_2446;
            break;
          }
          default: heff_nomatch(v_i_2444);
          }
          v_t_2453 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_2444}), v_t_2447});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2448 = heff_field(v_x1_2443, 0);
          heff_take_n(v_x1_2443, 1ULL, 1);
          heff_drop_cell(v_ru_24e_241_24At, 2);
          v_t_2453 = v_c_2448;
          break;
        }
        case TAG_IsType: {
          V v_t_2449 = heff_field(v_x1_2443, 0);
          heff_take_n(v_x1_2443, 1ULL, 1);
          V v_t_2452;
          switch (heff_tag_of(v_t_2449)) {
          case TAG_At: {
            V v_s_2451 = heff_dup(heff_field(v_t_2449, 1));
            v_t_2452 = v_s_2451;
            break;
          }
          default: heff_nomatch(v_t_2449);
          }
          v_t_2453 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_2449}), v_t_2452});
          break;
        }
        default: heff_nomatch(v_x1_2443);
        }
        V v_t_2454 = heff_tag_at(v_ru_24it1_242_24ELam, TAG_At, 2, (V[]){heff_tag(TAG_CLam, 3, (V[]){v_x_2441, v_xsp_2442, v_t_2453}), v_sp_243});
        return heff_tag(TAG_IsCheckable, 1, (V[]){v_t_2454});
      }
      case TAG_LamImplicit: {
        V v_x_2455 = heff_field(v_it11_2439, 0);
        V v_xsp_2456 = heff_field(v_it11_2439, 1);
        heff_take_n(v_it11_2439, 3ULL, 2);
        V v_x1_2457 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_body_2440}));
        V v_t_2467;
        switch (heff_tag_of(v_x1_2457)) {
        case TAG_IsInferable: {
          V v_i_2458 = heff_field(v_x1_2457, 0);
          heff_take_n(v_x1_2457, 1ULL, 1);
          V v_t_2461;
          switch (heff_tag_of(v_i_2458)) {
          case TAG_At: {
            V v_s_2460 = heff_dup(heff_field(v_i_2458, 1));
            v_t_2461 = v_s_2460;
            break;
          }
          default: heff_nomatch(v_i_2458);
          }
          v_t_2467 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_2458}), v_t_2461});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2462 = heff_field(v_x1_2457, 0);
          heff_take_n(v_x1_2457, 1ULL, 1);
          heff_drop_cell(v_ru_24e_241_24At, 2);
          v_t_2467 = v_c_2462;
          break;
        }
        case TAG_IsType: {
          V v_t_2463 = heff_field(v_x1_2457, 0);
          heff_take_n(v_x1_2457, 1ULL, 1);
          V v_t_2466;
          switch (heff_tag_of(v_t_2463)) {
          case TAG_At: {
            V v_s_2465 = heff_dup(heff_field(v_t_2463, 1));
            v_t_2466 = v_s_2465;
            break;
          }
          default: heff_nomatch(v_t_2463);
          }
          v_t_2467 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_2463}), v_t_2466});
          break;
        }
        default: heff_nomatch(v_x1_2457);
        }
        V v_t_2468 = heff_tag_at(v_ru_24it1_242_24ELam, TAG_At, 2, (V[]){heff_tag(TAG_CImplicitLam, 3, (V[]){v_x_2455, v_xsp_2456, v_t_2467}), v_sp_243});
        return heff_tag(TAG_IsCheckable, 1, (V[]){v_t_2468});
      }
      case TAG_LamAnn: {
        V v_x_2469 = heff_field(v_it11_2439, 0);
        V v_xsp_2470 = heff_field(v_it11_2439, 1);
        V v_t_2471 = heff_field(v_it11_2439, 2);
        heff_take_n(v_it11_2439, 7ULL, 3);
        heff_drop_cell(v_ru_24it1_242_24ELam, 2);
        V v_x1_2472 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_t_2471}));
        V v_t_2482;
        switch (heff_tag_of(v_x1_2472)) {
        case TAG_IsInferable: {
          V v_i_2473 = heff_field(v_x1_2472, 0);
          heff_take_n(v_x1_2472, 1ULL, 1);
          V v_t_2476;
          switch (heff_tag_of(v_i_2473)) {
          case TAG_At: {
            V v_s_2475 = heff_dup(heff_field(v_i_2473, 1));
            v_t_2476 = v_s_2475;
            break;
          }
          default: heff_nomatch(v_i_2473);
          }
          v_t_2482 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_2473}), v_t_2476});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2477 = heff_field(v_x1_2472, 0);
          heff_take_n(v_x1_2472, 1ULL, 1);
          V v_t_2480;
          switch (heff_tag_of(v_c_2477)) {
          case TAG_At: {
            V v_s_2479 = heff_dup(heff_field(v_c_2477, 1));
            v_t_2480 = v_s_2479;
            break;
          }
          default: heff_nomatch(v_c_2477);
          }
          v_t_2482 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2477}), v_t_2480});
          break;
        }
        case TAG_IsType: {
          V v_t_2481 = heff_field(v_x1_2472, 0);
          heff_take_n(v_x1_2472, 1ULL, 1);
          heff_drop_cell(v_ru_24e_241_24At, 2);
          v_t_2482 = v_t_2481;
          break;
        }
        default: heff_nomatch(v_x1_2472);
        }
        V v_t_2483 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_body_2440}));
        return (g_heff_2epresyntax_2eannLamOf(v_x_2469, v_xsp_2470, v_t_2482, v_t_2483, v_sp_243));
      }
      default: return heff_nomatch(v_it11_2439);
      }
    }
    case TAG_EAnn: {
      V v_a_2484 = heff_field(v_it1_242, 0);
      V v_t_2485 = heff_field(v_it1_242, 1);
      V v_ru_24it1_242_24EAnn = heff_take_reuse_n(v_it1_242, 3ULL, 2);
      V v_x1_2486 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_a_2484}));
      V v_t_2496;
      switch (heff_tag_of(v_x1_2486)) {
      case TAG_IsInferable: {
        V v_i_2487 = heff_field(v_x1_2486, 0);
        heff_take_n(v_x1_2486, 1ULL, 1);
        V v_t_2490;
        switch (heff_tag_of(v_i_2487)) {
        case TAG_At: {
          V v_s_2489 = heff_dup(heff_field(v_i_2487, 1));
          v_t_2490 = v_s_2489;
          break;
        }
        default: heff_nomatch(v_i_2487);
        }
        v_t_2496 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_2487}), v_t_2490});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2491 = heff_field(v_x1_2486, 0);
        heff_take_n(v_x1_2486, 1ULL, 1);
        heff_drop_cell(v_ru_24e_241_24At, 2);
        v_t_2496 = v_c_2491;
        break;
      }
      case TAG_IsType: {
        V v_t_2492 = heff_field(v_x1_2486, 0);
        heff_take_n(v_x1_2486, 1ULL, 1);
        V v_t_2495;
        switch (heff_tag_of(v_t_2492)) {
        case TAG_At: {
          V v_s_2494 = heff_dup(heff_field(v_t_2492, 1));
          v_t_2495 = v_s_2494;
          break;
        }
        default: heff_nomatch(v_t_2492);
        }
        v_t_2496 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_2492}), v_t_2495});
        break;
      }
      default: heff_nomatch(v_x1_2486);
      }
      V v_x1_2497 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_t_2485}));
      V v_t_24107;
      switch (heff_tag_of(v_x1_2497)) {
      case TAG_IsInferable: {
        V v_i_2498 = heff_field(v_x1_2497, 0);
        heff_take_n(v_x1_2497, 1ULL, 1);
        V v_t_24101;
        switch (heff_tag_of(v_i_2498)) {
        case TAG_At: {
          V v_s_24100 = heff_dup(heff_field(v_i_2498, 1));
          v_t_24101 = v_s_24100;
          break;
        }
        default: heff_nomatch(v_i_2498);
        }
        v_t_24107 = heff_tag_at(v_ru_24it1_242_24EAnn, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_2498}), v_t_24101});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24102 = heff_field(v_x1_2497, 0);
        heff_take_n(v_x1_2497, 1ULL, 1);
        V v_t_24105;
        switch (heff_tag_of(v_c_24102)) {
        case TAG_At: {
          V v_s_24104 = heff_dup(heff_field(v_c_24102, 1));
          v_t_24105 = v_s_24104;
          break;
        }
        default: heff_nomatch(v_c_24102);
        }
        v_t_24107 = heff_tag_at(v_ru_24it1_242_24EAnn, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_24102}), v_t_24105});
        break;
      }
      case TAG_IsType: {
        V v_t_24106 = heff_field(v_x1_2497, 0);
        heff_take_n(v_x1_2497, 1ULL, 1);
        heff_drop_cell(v_ru_24it1_242_24EAnn, 2);
        v_t_24107 = v_t_24106;
        break;
      }
      default: heff_nomatch(v_x1_2497);
      }
      V v_t_24108 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IAnn, 2, (V[]){v_t_2496, v_t_24107}), v_sp_243});
      return heff_tag(TAG_IsInferable, 1, (V[]){v_t_24108});
    }
    case TAG_ESpec: {
      V v_a_24109 = heff_field(v_it1_242, 0);
      V v_x_24110 = heff_field(v_it1_242, 1);
      V v_fsp_24111 = heff_field(v_it1_242, 2);
      V v_v_24112 = heff_field(v_it1_242, 3);
      V v_ru_24it1_242_24ESpec = heff_take_reuse_n(v_it1_242, 15ULL, 4);
      V v_t_24113 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_a_24109}));
      V v_t_24114 = ({ V a_0 = v_t_24113; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24113); r_; });
      V v_x1_24115 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_v_24112}));
      V v_t_24125;
      switch (heff_tag_of(v_x1_24115)) {
      case TAG_IsInferable: {
        V v_i_24116 = heff_field(v_x1_24115, 0);
        heff_take_n(v_x1_24115, 1ULL, 1);
        V v_t_24119;
        switch (heff_tag_of(v_i_24116)) {
        case TAG_At: {
          V v_s_24118 = heff_dup(heff_field(v_i_24116, 1));
          v_t_24119 = v_s_24118;
          break;
        }
        default: heff_nomatch(v_i_24116);
        }
        v_t_24125 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24116}), v_t_24119});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24120 = heff_field(v_x1_24115, 0);
        heff_take_n(v_x1_24115, 1ULL, 1);
        heff_drop_cell(v_ru_24e_241_24At, 2);
        v_t_24125 = v_c_24120;
        break;
      }
      case TAG_IsType: {
        V v_t_24121 = heff_field(v_x1_24115, 0);
        heff_take_n(v_x1_24115, 1ULL, 1);
        V v_t_24124;
        switch (heff_tag_of(v_t_24121)) {
        case TAG_At: {
          V v_s_24123 = heff_dup(heff_field(v_t_24121, 1));
          v_t_24124 = v_s_24123;
          break;
        }
        default: heff_nomatch(v_t_24121);
        }
        v_t_24125 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24121}), v_t_24124});
        break;
      }
      default: heff_nomatch(v_x1_24115);
      }
      V v_t_24126 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24ESpec, TAG_ISpec, 4, (V[]){v_t_24114, v_x_24110, v_fsp_24111, v_t_24125}), v_sp_243});
      return heff_tag(TAG_IsInferable, 1, (V[]){v_t_24126});
    }
    case TAG_ESig: {
      V v_fs_24127 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24ESig = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      V v_t_24128 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2efieldDeclOf_clo), 1, (V[]){v_r_240}));
      V v_t_24129 = heff_tag_at(v_ru_24it1_242_24ESig, TAG_TSig, 1, (V[]){(g_prelude_2emap(v_t_24128, v_fs_24127))});
      return heff_tag(TAG_IsType, 1, (V[]){heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){v_t_24129, v_sp_243})});
    }
    case TAG_ESum: {
      V v_vs_24130 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24ESum = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      V v_t_24131 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2evariantOf_clo), 1, (V[]){v_r_240}));
      V v_t_24132 = heff_tag_at(v_ru_24it1_242_24ESum, TAG_TSum, 1, (V[]){(g_prelude_2emap(v_t_24131, v_vs_24130))});
      return heff_tag(TAG_IsType, 1, (V[]){heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){v_t_24132, v_sp_243})});
    }
    case TAG_EStruct: {
      V v_fs_24133 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24EStruct = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      V v_t_24134 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2efieldSetOf_clo), 1, (V[]){v_r_240}));
      V v_t_24135 = heff_tag_at(v_ru_24it1_242_24EStruct, TAG_CStruct, 1, (V[]){(g_prelude_2emap(v_t_24134, v_fs_24133))});
      return heff_tag(TAG_IsCheckable, 1, (V[]){heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){v_t_24135, v_sp_243})});
    }
    case TAG_EMatch: {
      V v_s_24136 = heff_field(v_it1_242, 0);
      V v_alts_24137 = heff_field(v_it1_242, 1);
      V v_ru_24it1_242_24EMatch = heff_take_reuse_n(v_it1_242, 3ULL, 2);
      V v_t_24138 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_s_24136}));
      V v_t_24139 = ({ V a_0 = v_t_24138; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24138); r_; });
      V v_t_24140 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2ealtOf_clo), 1, (V[]){v_r_240}));
      V v_t_24141 = heff_tag_at(v_ru_24e_241_24At, TAG_CMatch, 2, (V[]){v_t_24139, (g_prelude_2emap(v_t_24140, v_alts_24137))});
      return heff_tag(TAG_IsCheckable, 1, (V[]){heff_tag_at(v_ru_24it1_242_24EMatch, TAG_At, 2, (V[]){v_t_24141, v_sp_243})});
    }
    case TAG_ELetIn: {
      V v_rhs_24142 = heff_field(v_it1_242, 0);
      V v_a_24143 = heff_field(v_it1_242, 1);
      V v_ru_24it1_242_24ELetIn = heff_take_reuse_n(v_it1_242, 3ULL, 2);
      V v_t_24144 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_rhs_24142}));
      V v_t_24145 = ({ V a_0 = v_t_24144; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24144); r_; });
      V v_t_24161;
      switch (heff_tag_of(v_a_24143)) {
      case TAG_At: {
        V v_x21_24146 = heff_field(v_a_24143, 0);
        V v_sp_24147 = heff_field(v_a_24143, 1);
        heff_take_n(v_a_24143, 3ULL, 2);
        switch (heff_tag_of(v_x21_24146)) {
        case TAG_MkAlt: {
          V v_p_24148 = heff_field(v_x21_24146, 0);
          V v_b_24149 = heff_field(v_x21_24146, 1);
          heff_take_n(v_x21_24146, 3ULL, 2);
          V v_x1_24150 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_b_24149}));
          V v_t_24160;
          switch (heff_tag_of(v_x1_24150)) {
          case TAG_IsInferable: {
            V v_i_24151 = heff_field(v_x1_24150, 0);
            heff_take_n(v_x1_24150, 1ULL, 1);
            V v_t_24154;
            switch (heff_tag_of(v_i_24151)) {
            case TAG_At: {
              V v_s_24153 = heff_dup(heff_field(v_i_24151, 1));
              v_t_24154 = v_s_24153;
              break;
            }
            default: heff_nomatch(v_i_24151);
            }
            v_t_24160 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24151}), v_t_24154});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24155 = heff_field(v_x1_24150, 0);
            heff_take_n(v_x1_24150, 1ULL, 1);
            heff_drop_cell(v_ru_24e_241_24At, 2);
            v_t_24160 = v_c_24155;
            break;
          }
          case TAG_IsType: {
            V v_t_24156 = heff_field(v_x1_24150, 0);
            heff_take_n(v_x1_24150, 1ULL, 1);
            V v_t_24159;
            switch (heff_tag_of(v_t_24156)) {
            case TAG_At: {
              V v_s_24158 = heff_dup(heff_field(v_t_24156, 1));
              v_t_24159 = v_s_24158;
              break;
            }
            default: heff_nomatch(v_t_24156);
            }
            v_t_24160 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24156}), v_t_24159});
            break;
          }
          default: heff_nomatch(v_x1_24150);
          }
          v_t_24161 = heff_tag_at(v_ru_24it1_242_24ELetIn, TAG_At, 2, (V[]){heff_tag(TAG_MkAlt, 2, (V[]){v_p_24148, v_t_24160}), v_sp_24147});
          break;
        }
        default: heff_nomatch(v_x21_24146);
        }
        break;
      }
      default: heff_nomatch(v_a_24143);
      }
      V v_t_24162 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_CLetIn, 2, (V[]){v_t_24145, v_t_24161}), v_sp_243});
      return heff_tag(TAG_IsCheckable, 1, (V[]){v_t_24162});
    }
    case TAG_EDo: {
      V v_stmts_24163 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24EDo = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      V v_t_24164 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_stmts_24163));
      switch (heff_tag_of(v_t_24164)) {
      case TAG_Nil: {
        heff_drop(v_r_240);
        V v_t_24165 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(12LL), ((V)&g_heff_2epresyntax_2eclassifyTermF_str2)}), v_sp_243});
        return heff_tag_at(v_ru_24it1_242_24EDo, TAG_IsInferable, 1, (V[]){v_t_24165});
      }
      case TAG_Cons: {
        V v_last_24166 = heff_field(v_t_24164, 0);
        V v_init_24167 = heff_field(v_t_24164, 1);
        heff_take_n(v_t_24164, 3ULL, 2);
        V v_init_24168 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_init_24167));
        V v_t_24177;
        switch (heff_tag_of(v_last_24166)) {
        case TAG_At: {
          V v_x31_24169 = heff_field(v_last_24166, 0);
          heff_take_n(v_last_24166, 1ULL, 2);
          switch (heff_tag_of(v_x31_24169)) {
          case TAG_StmtBind: {
            heff_take_n(v_x31_24169, 0ULL, 3);
            heff_drop_cell(v_ru_24it1_242_24EDo, 1);
            heff_drop(v_init_24168);
            v_t_24177 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_StmtLet: {
            heff_take_n(v_x31_24169, 0ULL, 2);
            heff_drop_cell(v_ru_24it1_242_24EDo, 1);
            heff_drop(v_init_24168);
            v_t_24177 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_StmtExpr: {
            V v_e_24176 = heff_field(v_x31_24169, 0);
            heff_take_n(v_x31_24169, 1ULL, 1);
            v_t_24177 = heff_tag_at(v_ru_24it1_242_24EDo, TAG_Just, 1, (V[]){({ V a_0 = heff_dup(v_sp_243); V a_1 = v_init_24168; V a_2 = v_e_24176; V r_ = (g_heff_2epresyntax_2edoFrom(a_0, a_1, a_2)); heff_drop(v_init_24168); r_; })});
            break;
          }
          default: heff_nomatch(v_x31_24169);
          }
          break;
        }
        default: heff_nomatch(v_last_24166);
        }
        switch (heff_tag_of(v_t_24177)) {
        case TAG_Nothing: {
          heff_drop(v_r_240);
          V v_t_24178 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(12LL), ((V)&g_heff_2epresyntax_2eclassifyTermF_str3)}), v_sp_243});
          return heff_tag(TAG_IsInferable, 1, (V[]){v_t_24178});
        }
        case TAG_Just: {
          V v_e_27_24179 = heff_field(v_t_24177, 0);
          heff_take_n(v_t_24177, 1ULL, 1);
          heff_drop(v_sp_243);
          heff_drop_cell(v_ru_24e_241_24At, 2);
          return heff_tail(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_27_24179});
        }
        default: return heff_nomatch(v_t_24177);
        }
      }
      default: return heff_nomatch(v_t_24164);
      }
    }
    case TAG_ELocal: {
      V v_body_24180 = heff_field(v_it1_242, 0);
      V v_ds_24181 = heff_field(v_it1_242, 1);
      V v_ru_24it1_242_24ELocal = heff_take_reuse_n(v_it1_242, 3ULL, 2);
      V v_x1_24182 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_body_24180}));
      V v_t_24192;
      switch (heff_tag_of(v_x1_24182)) {
      case TAG_IsInferable: {
        V v_i_24183 = heff_field(v_x1_24182, 0);
        heff_take_n(v_x1_24182, 1ULL, 1);
        V v_t_24186;
        switch (heff_tag_of(v_i_24183)) {
        case TAG_At: {
          V v_s_24185 = heff_dup(heff_field(v_i_24183, 1));
          v_t_24186 = v_s_24185;
          break;
        }
        default: heff_nomatch(v_i_24183);
        }
        v_t_24192 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24183}), v_t_24186});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24187 = heff_field(v_x1_24182, 0);
        heff_take_n(v_x1_24182, 1ULL, 1);
        heff_drop_cell(v_ru_24e_241_24At, 2);
        v_t_24192 = v_c_24187;
        break;
      }
      case TAG_IsType: {
        V v_t_24188 = heff_field(v_x1_24182, 0);
        heff_take_n(v_x1_24182, 1ULL, 1);
        V v_t_24191;
        switch (heff_tag_of(v_t_24188)) {
        case TAG_At: {
          V v_s_24190 = heff_dup(heff_field(v_t_24188, 1));
          v_t_24191 = v_s_24190;
          break;
        }
        default: heff_nomatch(v_t_24188);
        }
        v_t_24192 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24188}), v_t_24191});
        break;
      }
      default: heff_nomatch(v_x1_24182);
      }
      V v_t_24193 = heff_tag_at(v_ru_24it1_242_24ELocal, TAG_CLocal, 2, (V[]){v_t_24192, (g_prelude_2emap(heff_get(v_r_240, LBL_decl), v_ds_24181))});
      return heff_tag(TAG_IsCheckable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24193, v_sp_243})});
    }
    case TAG_EInvalid: {
      V v_why_24194 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24EInvalid = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      heff_drop(v_r_240);
      V v_t_24195 = heff_tag_at(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(3LL), v_why_24194}), v_sp_243});
      return heff_tag_at(v_ru_24it1_242_24EInvalid, TAG_IsInferable, 1, (V[]){v_t_24195});
    }
    default: return heff_nomatch(v_it1_242);
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2epresyntax_2eclassifyTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2eclassifyTermF(a[0], a[1]);
}
Clo g_heff_2epresyntax_2eparamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2eparamOf_entry, 2, 0};

V g_heff_2epresyntax_2eparamOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_ExplicitParam: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_xsp_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24ExplicitParam = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_247 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_t_246}));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_c_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_c_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_c_2412);
        }
        v_t_2417 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2412}), v_t_2415});
        break;
      }
      case TAG_IsType: {
        V v_t_2416 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2417 = v_t_2416;
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x21_242_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_x_244, v_xsp_245, v_t_2417}), v_sp_243});
    }
    case TAG_ImplicitParam: {
      V v_x_2418 = heff_field(v_x21_242, 0);
      V v_xsp_2419 = heff_field(v_x21_242, 1);
      V v_t_2420 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24ImplicitParam = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_2421 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_t_2420}));
      V v_t_2431;
      switch (heff_tag_of(v_x1_2421)) {
      case TAG_IsInferable: {
        V v_i_2422 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        V v_t_2425;
        switch (heff_tag_of(v_i_2422)) {
        case TAG_At: {
          V v_s_2424 = heff_dup(heff_field(v_i_2422, 1));
          v_t_2425 = v_s_2424;
          break;
        }
        default: heff_nomatch(v_i_2422);
        }
        v_t_2431 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_2422}), v_t_2425});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2426 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        V v_t_2429;
        switch (heff_tag_of(v_c_2426)) {
        case TAG_At: {
          V v_s_2428 = heff_dup(heff_field(v_c_2426, 1));
          v_t_2429 = v_s_2428;
          break;
        }
        default: heff_nomatch(v_c_2426);
        }
        v_t_2431 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2426}), v_t_2429});
        break;
      }
      case TAG_IsType: {
        V v_t_2430 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2431 = v_t_2430;
        break;
      }
      default: heff_nomatch(v_x1_2421);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x21_242_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_x_2418, v_xsp_2419, v_t_2431}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2epresyntax_2eparamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2eparamOf(a[0], a[1]);
}
Clo g_heff_2epresyntax_2eequationOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2eequationOf_entry, 2, 0};

V g_heff_2epresyntax_2eequationOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkEquation: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_ps_246 = heff_field(v_x21_242, 2);
      V v_rhs_247 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24MkEquation = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_x1_248 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_rhs_247}));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2418 = v_c_2413;
        break;
      }
      case TAG_IsType: {
        V v_t_2414 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2417;
        switch (heff_tag_of(v_t_2414)) {
        case TAG_At: {
          V v_s_2416 = heff_dup(heff_field(v_t_2414, 1));
          v_t_2417 = v_s_2416;
          break;
        }
        default: heff_nomatch(v_t_2414);
        }
        v_t_2418 = heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_2414}), v_t_2417});
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x21_242_24MkEquation, TAG_MkEquation, 4, (V[]){v_f_244, v_fsp_245, v_ps_246, v_t_2418}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2epresyntax_2eequationOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2eequationOf(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2epresyntax_2ewatchOf_str0 = {{0x80000000u, K_STR, 0}, 57, 57, {97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 45, 45, 32, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2epresyntax_2ewatchOf_str1 = {{0x80000000u, K_STR, 0}, 57, 57, {97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 45, 45, 32, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96}};
Clo g_heff_2epresyntax_2ewatchOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2ewatchOf_entry, 1, 0};

V g_heff_2epresyntax_2ewatchOf(V v_c_240) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_IsInferable: {
    V v_i_241 = heff_field(v_c_240, 0);
    V v_ru_24c_240_24IsInferable = heff_take_reuse_n(v_c_240, 1ULL, 1);
    V v_t_244;
    switch (heff_tag_of(v_i_241)) {
    case TAG_At: {
      V v_s_243 = heff_dup(heff_field(v_i_241, 1));
      v_t_244 = v_s_243;
      break;
    }
    default: heff_nomatch(v_i_241);
    }
    return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24c_240_24IsInferable, TAG_CInf, 1, (V[]){v_i_241}), v_t_244});
  }
  case TAG_IsCheckable: {
    V v_sp_2415;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_246 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_i_246)) {
      case TAG_At: {
        V v_s_248 = heff_field(v_i_246, 1);
        heff_take_n(v_i_246, 2ULL, 2);
        v_sp_2415 = v_s_248;
        break;
      }
      default: heff_nomatch(v_i_246);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_249 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_c_249)) {
      case TAG_At: {
        V v_s_2411 = heff_field(v_c_249, 1);
        heff_take_n(v_c_249, 2ULL, 2);
        v_sp_2415 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_c_249);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2412 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_At: {
        V v_s_2414 = heff_field(v_t_2412, 1);
        heff_take_n(v_t_2412, 2ULL, 2);
        v_sp_2415 = v_s_2414;
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2416 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2epresyntax_2ewatchOf_str0)}), v_sp_2415});
    V v_t_2426;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2417 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_i_2417)) {
      case TAG_At: {
        V v_s_2419 = heff_field(v_i_2417, 1);
        heff_take_n(v_i_2417, 2ULL, 2);
        v_t_2426 = v_s_2419;
        break;
      }
      default: heff_nomatch(v_i_2417);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2420 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_c_2420)) {
      case TAG_At: {
        V v_s_2422 = heff_field(v_c_2420, 1);
        heff_take_n(v_c_2420, 2ULL, 2);
        v_t_2426 = v_s_2422;
        break;
      }
      default: heff_nomatch(v_c_2420);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2423 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_t_2423)) {
      case TAG_At: {
        V v_s_2425 = heff_field(v_t_2423, 1);
        heff_take_n(v_t_2423, 2ULL, 2);
        v_t_2426 = v_s_2425;
        break;
      }
      default: heff_nomatch(v_t_2423);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_t_2416}), v_t_2426});
  }
  case TAG_IsType: {
    V v_sp_2437;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2428 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_i_2428)) {
      case TAG_At: {
        V v_s_2430 = heff_field(v_i_2428, 1);
        heff_take_n(v_i_2428, 2ULL, 2);
        v_sp_2437 = v_s_2430;
        break;
      }
      default: heff_nomatch(v_i_2428);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2431 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_c_2431)) {
      case TAG_At: {
        V v_s_2433 = heff_field(v_c_2431, 1);
        heff_take_n(v_c_2431, 2ULL, 2);
        v_sp_2437 = v_s_2433;
        break;
      }
      default: heff_nomatch(v_c_2431);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2434 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_t_2434)) {
      case TAG_At: {
        V v_s_2436 = heff_field(v_t_2434, 1);
        heff_take_n(v_t_2434, 2ULL, 2);
        v_sp_2437 = v_s_2436;
        break;
      }
      default: heff_nomatch(v_t_2434);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2438 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2epresyntax_2ewatchOf_str1)}), v_sp_2437});
    V v_t_2448;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2439 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_i_2439)) {
      case TAG_At: {
        V v_s_2441 = heff_field(v_i_2439, 1);
        heff_take_n(v_i_2439, 2ULL, 2);
        v_t_2448 = v_s_2441;
        break;
      }
      default: heff_nomatch(v_i_2439);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2442 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_c_2442)) {
      case TAG_At: {
        V v_s_2444 = heff_field(v_c_2442, 1);
        heff_take_n(v_c_2442, 2ULL, 2);
        v_t_2448 = v_s_2444;
        break;
      }
      default: heff_nomatch(v_c_2442);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2445 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_t_2445)) {
      case TAG_At: {
        V v_s_2447 = heff_field(v_t_2445, 1);
        heff_take_n(v_t_2445, 2ULL, 2);
        v_t_2448 = v_s_2447;
        break;
      }
      default: heff_nomatch(v_t_2445);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_t_2438}), v_t_2448});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2epresyntax_2ewatchOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2ewatchOf(a[0]);
}
Clo g_heff_2epresyntax_2eclassifyDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2eclassifyDeclF_entry, 2, 0};

V g_heff_2epresyntax_2eclassifyDeclF(V v_r_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_it1_242 = heff_field(v_d_241, 0);
    V v_sp_243 = heff_field(v_d_241, 1);
    V v_ru_24d_241_24At = heff_take_reuse_n(v_d_241, 3ULL, 2);
    switch (heff_tag_of(v_it1_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_it1_242, 0);
      V v_fsp_245 = heff_field(v_it1_242, 1);
      V v_ty_246 = heff_field(v_it1_242, 2);
      V v_eqs_247 = heff_field(v_it1_242, 3);
      V v_ru_24it1_242_24DeclEquations = heff_take_reuse_n(v_it1_242, 15ULL, 4);
      V v_x1_248 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_ty_246}));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at(v_ru_24d_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_c_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_c_2413);
        }
        v_t_2418 = heff_tag_at(v_ru_24d_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
        break;
      }
      case TAG_IsType: {
        V v_t_2417 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24d_241_24At, 2);
        v_t_2418 = v_t_2417;
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      V v_t_2419 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eequationOf_clo), 1, (V[]){v_r_240}));
      V v_t_2420 = heff_tag_at(v_ru_24it1_242_24DeclEquations, TAG_DeclEquations, 4, (V[]){v_f_244, v_fsp_245, v_t_2418, (g_prelude_2emap(v_t_2419, v_eqs_247))});
      return heff_tag(TAG_At, 2, (V[]){v_t_2420, v_sp_243});
    }
    case TAG_DeclDefine: {
      V v_x_2421 = heff_field(v_it1_242, 0);
      V v_xsp_2422 = heff_field(v_it1_242, 1);
      V v_ps_2423 = heff_field(v_it1_242, 2);
      V v_u_2424 = heff_field(v_it1_242, 3);
      V v_body_2425 = heff_field(v_it1_242, 4);
      V v_ru_24it1_242_24DeclDefine = heff_take_reuse_n(v_it1_242, 31ULL, 5);
      V v_t_2426 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eparamOf_clo), 1, (V[]){heff_dup(v_r_240)}));
      V v_t_2427 = (g_prelude_2emap(v_t_2426, v_ps_2423));
      V v_x1_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_e), 1, (V[]){v_u_2424}));
      V v_t_2438;
      switch (heff_tag_of(v_x1_2428)) {
      case TAG_IsInferable: {
        V v_i_2429 = heff_field(v_x1_2428, 0);
        heff_take_n(v_x1_2428, 1ULL, 1);
        V v_t_2432;
        switch (heff_tag_of(v_i_2429)) {
        case TAG_At: {
          V v_s_2431 = heff_dup(heff_field(v_i_2429, 1));
          v_t_2432 = v_s_2431;
          break;
        }
        default: heff_nomatch(v_i_2429);
        }
        v_t_2438 = heff_tag_at(v_ru_24d_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_2429}), v_t_2432});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2433 = heff_field(v_x1_2428, 0);
        heff_take_n(v_x1_2428, 1ULL, 1);
        V v_t_2436;
        switch (heff_tag_of(v_c_2433)) {
        case TAG_At: {
          V v_s_2435 = heff_dup(heff_field(v_c_2433, 1));
          v_t_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_c_2433);
        }
        v_t_2438 = heff_tag_at(v_ru_24d_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2433}), v_t_2436});
        break;
      }
      case TAG_IsType: {
        V v_t_2437 = heff_field(v_x1_2428, 0);
        heff_take_n(v_x1_2428, 1ULL, 1);
        heff_drop_cell(v_ru_24d_241_24At, 2);
        v_t_2438 = v_t_2437;
        break;
      }
      default: heff_nomatch(v_x1_2428);
      }
      V v_x1_2439 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_body_2425}));
      V v_t_2449;
      switch (heff_tag_of(v_x1_2439)) {
      case TAG_IsInferable: {
        V v_i_2440 = heff_field(v_x1_2439, 0);
        V v_ru_24x1_2439_24IsInferable = heff_take_reuse_n(v_x1_2439, 1ULL, 1);
        V v_t_2443;
        switch (heff_tag_of(v_i_2440)) {
        case TAG_At: {
          V v_s_2442 = heff_dup(heff_field(v_i_2440, 1));
          v_t_2443 = v_s_2442;
          break;
        }
        default: heff_nomatch(v_i_2440);
        }
        v_t_2449 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_2439_24IsInferable, TAG_CInf, 1, (V[]){v_i_2440}), v_t_2443});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2444 = heff_field(v_x1_2439, 0);
        heff_take_n(v_x1_2439, 1ULL, 1);
        v_t_2449 = v_c_2444;
        break;
      }
      case TAG_IsType: {
        V v_t_2445 = heff_field(v_x1_2439, 0);
        V v_ru_24x1_2439_24IsType = heff_take_reuse_n(v_x1_2439, 1ULL, 1);
        V v_t_2448;
        switch (heff_tag_of(v_t_2445)) {
        case TAG_At: {
          V v_s_2447 = heff_dup(heff_field(v_t_2445, 1));
          v_t_2448 = v_s_2447;
          break;
        }
        default: heff_nomatch(v_t_2445);
        }
        v_t_2449 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_2439_24IsType, TAG_CType, 1, (V[]){v_t_2445}), v_t_2448});
        break;
      }
      default: heff_nomatch(v_x1_2439);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_2421, v_xsp_2422, v_t_2427, v_t_2438, v_t_2449}), v_sp_243});
    }
    case TAG_DeclTheory: {
      V v_x_2450 = heff_field(v_it1_242, 0);
      V v_xsp_2451 = heff_field(v_it1_242, 1);
      V v_ps_2452 = heff_field(v_it1_242, 2);
      V v_body_2453 = heff_field(v_it1_242, 3);
      V v_ru_24it1_242_24DeclTheory = heff_take_reuse_n(v_it1_242, 15ULL, 4);
      V v_t_2454 = heff_tr(heff_apply(((V)&g_heff_2epresyntax_2eparamOf_clo), 1, (V[]){heff_dup(v_r_240)}));
      V v_t_2455 = (g_prelude_2emap(v_t_2454, v_ps_2452));
      V v_x1_2456 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_body_2453}));
      V v_t_2466;
      switch (heff_tag_of(v_x1_2456)) {
      case TAG_IsInferable: {
        V v_i_2457 = heff_field(v_x1_2456, 0);
        heff_take_n(v_x1_2456, 1ULL, 1);
        V v_t_2460;
        switch (heff_tag_of(v_i_2457)) {
        case TAG_At: {
          V v_s_2459 = heff_dup(heff_field(v_i_2457, 1));
          v_t_2460 = v_s_2459;
          break;
        }
        default: heff_nomatch(v_i_2457);
        }
        v_t_2466 = heff_tag_at(v_ru_24d_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_2457}), v_t_2460});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2461 = heff_field(v_x1_2456, 0);
        heff_take_n(v_x1_2456, 1ULL, 1);
        heff_drop_cell(v_ru_24d_241_24At, 2);
        v_t_2466 = v_c_2461;
        break;
      }
      case TAG_IsType: {
        V v_t_2462 = heff_field(v_x1_2456, 0);
        heff_take_n(v_x1_2456, 1ULL, 1);
        V v_t_2465;
        switch (heff_tag_of(v_t_2462)) {
        case TAG_At: {
          V v_s_2464 = heff_dup(heff_field(v_t_2462, 1));
          v_t_2465 = v_s_2464;
          break;
        }
        default: heff_nomatch(v_t_2462);
        }
        v_t_2466 = heff_tag_at(v_ru_24d_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_2462}), v_t_2465});
        break;
      }
      default: heff_nomatch(v_x1_2456);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2450, v_xsp_2451, v_t_2455, v_t_2466}), v_sp_243});
    }
    case TAG_DeclPrimitive: {
      V v_x_2467 = heff_field(v_it1_242, 0);
      V v_xsp_2468 = heff_field(v_it1_242, 1);
      V v_t_2469 = heff_field(v_it1_242, 2);
      V v_ru_24it1_242_24DeclPrimitive = heff_take_reuse_n(v_it1_242, 7ULL, 3);
      V v_x1_2470 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_t_2469}));
      V v_t_2480;
      switch (heff_tag_of(v_x1_2470)) {
      case TAG_IsInferable: {
        V v_i_2471 = heff_field(v_x1_2470, 0);
        heff_take_n(v_x1_2470, 1ULL, 1);
        V v_t_2474;
        switch (heff_tag_of(v_i_2471)) {
        case TAG_At: {
          V v_s_2473 = heff_dup(heff_field(v_i_2471, 1));
          v_t_2474 = v_s_2473;
          break;
        }
        default: heff_nomatch(v_i_2471);
        }
        v_t_2480 = heff_tag_at(v_ru_24d_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_2471}), v_t_2474});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2475 = heff_field(v_x1_2470, 0);
        heff_take_n(v_x1_2470, 1ULL, 1);
        V v_t_2478;
        switch (heff_tag_of(v_c_2475)) {
        case TAG_At: {
          V v_s_2477 = heff_dup(heff_field(v_c_2475, 1));
          v_t_2478 = v_s_2477;
          break;
        }
        default: heff_nomatch(v_c_2475);
        }
        v_t_2480 = heff_tag_at(v_ru_24d_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2475}), v_t_2478});
        break;
      }
      case TAG_IsType: {
        V v_t_2479 = heff_field(v_x1_2470, 0);
        heff_take_n(v_x1_2470, 1ULL, 1);
        heff_drop_cell(v_ru_24d_241_24At, 2);
        v_t_2480 = v_t_2479;
        break;
      }
      default: heff_nomatch(v_x1_2470);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2467, v_xsp_2468, v_t_2480}), v_sp_243});
    }
    case TAG_DeclTest: {
      V v_x_2481 = heff_field(v_it1_242, 0);
      V v_xsp_2482 = heff_field(v_it1_242, 1);
      heff_take_n(v_it1_242, 3ULL, 2);
      heff_drop(v_r_240);
      return heff_tag_at(v_ru_24d_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_DeclTest, 2, (V[]){v_x_2481, v_xsp_2482}), v_sp_243});
    }
    case TAG_DeclWatch: {
      V v_e_2483 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24DeclWatch = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      V v_t_2484 = heff_tr(heff_apply(heff_get(v_r_240, LBL_e), 1, (V[]){v_e_2483}));
      V v_t_2485 = heff_tag_at(v_ru_24it1_242_24DeclWatch, TAG_DeclWatch, 1, (V[]){(g_heff_2epresyntax_2ewatchOf(v_t_2484))});
      return heff_tag_at(v_ru_24d_241_24At, TAG_At, 2, (V[]){v_t_2485, v_sp_243});
    }
    default: return heff_nomatch(v_it1_242);
    }
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2epresyntax_2eclassifyDeclF_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2eclassifyDeclF(a[0], a[1]);
}
V g_heff_2epresyntax_2eclassifier_lam0(V self, V *args); static Clo g_heff_2epresyntax_2eclassifier_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2eclassifier_lam0, 1, 0};
V g_heff_2epresyntax_2eclassifier_lam1(V self, V *args); static Clo g_heff_2epresyntax_2eclassifier_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2eclassifier_lam1, 1, 0};

static V g_heff_2epresyntax_2eclassifier_val;
static int g_heff_2epresyntax_2eclassifier_st;
static V g_heff_2epresyntax_2eclassifier_init(void) {
  return heff_rec(2, shape_e__decl, (V[]){((V)&g_heff_2epresyntax_2eclassifier_lam0_clo), ((V)&g_heff_2epresyntax_2eclassifier_lam1_clo)});
}
V g_heff_2epresyntax_2eclassifier_get(void) {
  if (g_heff_2epresyntax_2eclassifier_st == 2) return g_heff_2epresyntax_2eclassifier_val;
  if (g_heff_2epresyntax_2eclassifier_st == 1) heff_fail("defined by itself");
  g_heff_2epresyntax_2eclassifier_st = 1;
  g_heff_2epresyntax_2eclassifier_val = heff_tr(g_heff_2epresyntax_2eclassifier_init());
  g_heff_2epresyntax_2eclassifier_st = 2;
  return g_heff_2epresyntax_2eclassifier_val;
}
V g_heff_2epresyntax_2eclassifier_lam0(V self, V *args) {
  V v_e_240 = args[0];
  return (g_heff_2epresyntax_2eclassifyTermF(heff_dup(g_heff_2epresyntax_2eclassifier_get()), v_e_240));
}
V g_heff_2epresyntax_2eclassifier_lam1(V self, V *args) {
  V v_d_241 = args[0];
  return (g_heff_2epresyntax_2eclassifyDeclF(heff_dup(g_heff_2epresyntax_2eclassifier_get()), v_d_241));
}
Clo g_heff_2epresyntax_2eargOf_24s1825882790x1322352207_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2eargOf_24s1825882790x1322352207_entry, 1, 0};

V g_heff_2epresyntax_2eargOf_24s1825882790x1322352207(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    V v_sp_242 = heff_dup(heff_field(v_e_240, 1));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EVar: {
      V v_ru_24e1_241_24EVar = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_244 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_2414;
      switch (heff_tag_of(v_x1_244)) {
      case TAG_IsInferable: {
        V v_i_245 = heff_field(v_x1_244, 0);
        heff_take_n(v_x1_244, 1ULL, 1);
        V v_t_248;
        switch (heff_tag_of(v_i_245)) {
        case TAG_At: {
          V v_s_247 = heff_dup(heff_field(v_i_245, 1));
          v_t_248 = v_s_247;
          break;
        }
        default: heff_nomatch(v_i_245);
        }
        v_t_2414 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24EVar, TAG_CInf, 1, (V[]){v_i_245}), v_t_248});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_249 = heff_field(v_x1_244, 0);
        heff_take_n(v_x1_244, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EVar, 1);
        v_t_2414 = v_c_249;
        break;
      }
      case TAG_IsType: {
        V v_t_2410 = heff_field(v_x1_244, 0);
        heff_take_n(v_x1_244, 1ULL, 1);
        V v_t_2413;
        switch (heff_tag_of(v_t_2410)) {
        case TAG_At: {
          V v_s_2412 = heff_dup(heff_field(v_t_2410, 1));
          v_t_2413 = v_s_2412;
          break;
        }
        default: heff_nomatch(v_t_2410);
        }
        v_t_2414 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24EVar, TAG_CType, 1, (V[]){v_t_2410}), v_t_2413});
        break;
      }
      default: heff_nomatch(v_x1_244);
      }
      V v_t_2417;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2416 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_2414}), v_t_2417});
    }
    case TAG_EImplicitVar: {
      V v_ru_24e1_241_24EImplicitVar = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_2419 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_2429;
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_IsInferable: {
        V v_i_2420 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        V v_t_2423;
        switch (heff_tag_of(v_i_2420)) {
        case TAG_At: {
          V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
          v_t_2423 = v_s_2422;
          break;
        }
        default: heff_nomatch(v_i_2420);
        }
        v_t_2429 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24EImplicitVar, TAG_CInf, 1, (V[]){v_i_2420}), v_t_2423});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2424 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EImplicitVar, 1);
        v_t_2429 = v_c_2424;
        break;
      }
      case TAG_IsType: {
        V v_t_2425 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        V v_t_2428;
        switch (heff_tag_of(v_t_2425)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_t_2425, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_t_2425);
        }
        v_t_2429 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24EImplicitVar, TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
        break;
      }
      default: heff_nomatch(v_x1_2419);
      }
      V v_t_2432;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2431 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2432 = v_s_2431;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_2429}), v_t_2432});
    }
    case TAG_ETag: {
      V v_ru_24e1_241_24ETag = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_2434 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_2444;
      switch (heff_tag_of(v_x1_2434)) {
      case TAG_IsInferable: {
        V v_i_2435 = heff_field(v_x1_2434, 0);
        heff_take_n(v_x1_2434, 1ULL, 1);
        V v_t_2438;
        switch (heff_tag_of(v_i_2435)) {
        case TAG_At: {
          V v_s_2437 = heff_dup(heff_field(v_i_2435, 1));
          v_t_2438 = v_s_2437;
          break;
        }
        default: heff_nomatch(v_i_2435);
        }
        v_t_2444 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24ETag, TAG_CInf, 1, (V[]){v_i_2435}), v_t_2438});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2439 = heff_field(v_x1_2434, 0);
        heff_take_n(v_x1_2434, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ETag, 1);
        v_t_2444 = v_c_2439;
        break;
      }
      case TAG_IsType: {
        V v_t_2440 = heff_field(v_x1_2434, 0);
        heff_take_n(v_x1_2434, 1ULL, 1);
        V v_t_2443;
        switch (heff_tag_of(v_t_2440)) {
        case TAG_At: {
          V v_s_2442 = heff_dup(heff_field(v_t_2440, 1));
          v_t_2443 = v_s_2442;
          break;
        }
        default: heff_nomatch(v_t_2440);
        }
        v_t_2444 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24ETag, TAG_CType, 1, (V[]){v_t_2440}), v_t_2443});
        break;
      }
      default: heff_nomatch(v_x1_2434);
      }
      V v_t_2447;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2446 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2447 = v_s_2446;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_2444}), v_t_2447});
    }
    case TAG_EInt: {
      V v_ru_24e1_241_24EInt = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_2449 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_2459;
      switch (heff_tag_of(v_x1_2449)) {
      case TAG_IsInferable: {
        V v_i_2450 = heff_field(v_x1_2449, 0);
        heff_take_n(v_x1_2449, 1ULL, 1);
        V v_t_2453;
        switch (heff_tag_of(v_i_2450)) {
        case TAG_At: {
          V v_s_2452 = heff_dup(heff_field(v_i_2450, 1));
          v_t_2453 = v_s_2452;
          break;
        }
        default: heff_nomatch(v_i_2450);
        }
        v_t_2459 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24EInt, TAG_CInf, 1, (V[]){v_i_2450}), v_t_2453});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2454 = heff_field(v_x1_2449, 0);
        heff_take_n(v_x1_2449, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EInt, 1);
        v_t_2459 = v_c_2454;
        break;
      }
      case TAG_IsType: {
        V v_t_2455 = heff_field(v_x1_2449, 0);
        heff_take_n(v_x1_2449, 1ULL, 1);
        V v_t_2458;
        switch (heff_tag_of(v_t_2455)) {
        case TAG_At: {
          V v_s_2457 = heff_dup(heff_field(v_t_2455, 1));
          v_t_2458 = v_s_2457;
          break;
        }
        default: heff_nomatch(v_t_2455);
        }
        v_t_2459 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24EInt, TAG_CType, 1, (V[]){v_t_2455}), v_t_2458});
        break;
      }
      default: heff_nomatch(v_x1_2449);
      }
      V v_t_2462;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2461 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2462 = v_s_2461;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_2459}), v_t_2462});
    }
    case TAG_EFloat: {
      V v_ru_24e1_241_24EFloat = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_2464 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_2474;
      switch (heff_tag_of(v_x1_2464)) {
      case TAG_IsInferable: {
        V v_i_2465 = heff_field(v_x1_2464, 0);
        heff_take_n(v_x1_2464, 1ULL, 1);
        V v_t_2468;
        switch (heff_tag_of(v_i_2465)) {
        case TAG_At: {
          V v_s_2467 = heff_dup(heff_field(v_i_2465, 1));
          v_t_2468 = v_s_2467;
          break;
        }
        default: heff_nomatch(v_i_2465);
        }
        v_t_2474 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24EFloat, TAG_CInf, 1, (V[]){v_i_2465}), v_t_2468});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2469 = heff_field(v_x1_2464, 0);
        heff_take_n(v_x1_2464, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EFloat, 1);
        v_t_2474 = v_c_2469;
        break;
      }
      case TAG_IsType: {
        V v_t_2470 = heff_field(v_x1_2464, 0);
        heff_take_n(v_x1_2464, 1ULL, 1);
        V v_t_2473;
        switch (heff_tag_of(v_t_2470)) {
        case TAG_At: {
          V v_s_2472 = heff_dup(heff_field(v_t_2470, 1));
          v_t_2473 = v_s_2472;
          break;
        }
        default: heff_nomatch(v_t_2470);
        }
        v_t_2474 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24EFloat, TAG_CType, 1, (V[]){v_t_2470}), v_t_2473});
        break;
      }
      default: heff_nomatch(v_x1_2464);
      }
      V v_t_2477;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2476 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2477 = v_s_2476;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_2474}), v_t_2477});
    }
    case TAG_EString: {
      V v_ru_24e1_241_24EString = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_2479 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_2489;
      switch (heff_tag_of(v_x1_2479)) {
      case TAG_IsInferable: {
        V v_i_2480 = heff_field(v_x1_2479, 0);
        heff_take_n(v_x1_2479, 1ULL, 1);
        V v_t_2483;
        switch (heff_tag_of(v_i_2480)) {
        case TAG_At: {
          V v_s_2482 = heff_dup(heff_field(v_i_2480, 1));
          v_t_2483 = v_s_2482;
          break;
        }
        default: heff_nomatch(v_i_2480);
        }
        v_t_2489 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24EString, TAG_CInf, 1, (V[]){v_i_2480}), v_t_2483});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2484 = heff_field(v_x1_2479, 0);
        heff_take_n(v_x1_2479, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EString, 1);
        v_t_2489 = v_c_2484;
        break;
      }
      case TAG_IsType: {
        V v_t_2485 = heff_field(v_x1_2479, 0);
        heff_take_n(v_x1_2479, 1ULL, 1);
        V v_t_2488;
        switch (heff_tag_of(v_t_2485)) {
        case TAG_At: {
          V v_s_2487 = heff_dup(heff_field(v_t_2485, 1));
          v_t_2488 = v_s_2487;
          break;
        }
        default: heff_nomatch(v_t_2485);
        }
        v_t_2489 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24EString, TAG_CType, 1, (V[]){v_t_2485}), v_t_2488});
        break;
      }
      default: heff_nomatch(v_x1_2479);
      }
      V v_t_2492;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2491 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2492 = v_s_2491;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_2489}), v_t_2492});
    }
    case TAG_EWord: {
      V v_ru_24e1_241_24EWord = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_2494 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_24104;
      switch (heff_tag_of(v_x1_2494)) {
      case TAG_IsInferable: {
        V v_i_2495 = heff_field(v_x1_2494, 0);
        heff_take_n(v_x1_2494, 1ULL, 1);
        V v_t_2498;
        switch (heff_tag_of(v_i_2495)) {
        case TAG_At: {
          V v_s_2497 = heff_dup(heff_field(v_i_2495, 1));
          v_t_2498 = v_s_2497;
          break;
        }
        default: heff_nomatch(v_i_2495);
        }
        v_t_24104 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24EWord, TAG_CInf, 1, (V[]){v_i_2495}), v_t_2498});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2499 = heff_field(v_x1_2494, 0);
        heff_take_n(v_x1_2494, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EWord, 1);
        v_t_24104 = v_c_2499;
        break;
      }
      case TAG_IsType: {
        V v_t_24100 = heff_field(v_x1_2494, 0);
        heff_take_n(v_x1_2494, 1ULL, 1);
        V v_t_24103;
        switch (heff_tag_of(v_t_24100)) {
        case TAG_At: {
          V v_s_24102 = heff_dup(heff_field(v_t_24100, 1));
          v_t_24103 = v_s_24102;
          break;
        }
        default: heff_nomatch(v_t_24100);
        }
        v_t_24104 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24EWord, TAG_CType, 1, (V[]){v_t_24100}), v_t_24103});
        break;
      }
      default: heff_nomatch(v_x1_2494);
      }
      V v_t_24107;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24106 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24107 = v_s_24106;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24104}), v_t_24107});
    }
    case TAG_EApp: {
      V v_ru_24e1_241_24EApp = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24110 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_24120;
      switch (heff_tag_of(v_x1_24110)) {
      case TAG_IsInferable: {
        V v_i_24111 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        V v_t_24114;
        switch (heff_tag_of(v_i_24111)) {
        case TAG_At: {
          V v_s_24113 = heff_dup(heff_field(v_i_24111, 1));
          v_t_24114 = v_s_24113;
          break;
        }
        default: heff_nomatch(v_i_24111);
        }
        v_t_24120 = heff_tag_at(v_ru_24e1_241_24EApp, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24111}), v_t_24114});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24115 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EApp, 2);
        v_t_24120 = v_c_24115;
        break;
      }
      case TAG_IsType: {
        V v_t_24116 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        V v_t_24119;
        switch (heff_tag_of(v_t_24116)) {
        case TAG_At: {
          V v_s_24118 = heff_dup(heff_field(v_t_24116, 1));
          v_t_24119 = v_s_24118;
          break;
        }
        default: heff_nomatch(v_t_24116);
        }
        v_t_24120 = heff_tag_at(v_ru_24e1_241_24EApp, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24116}), v_t_24119});
        break;
      }
      default: heff_nomatch(v_x1_24110);
      }
      V v_t_24123;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24122 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24123 = v_s_24122;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24120}), v_t_24123});
    }
    case TAG_EProject: {
      V v_x_24124 = heff_field(v_e1_241, 0);
      V v_ru_24e1_241_24EProject = heff_take_reuse_n(v_e1_241, 1ULL, 1);
      heff_drop_tag(v_e_240, 2);
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24EProject, TAG_ArgProject, 1, (V[]){v_x_24124}), v_sp_242});
    }
    case TAG_ENamed: {
      V v_x_24125 = heff_field(v_e1_241, 0);
      V v_e12_24126 = heff_field(v_e1_241, 1);
      V v_ru_24e1_241_24ENamed = heff_take_reuse_n(v_e1_241, 3ULL, 2);
      heff_drop_tag(v_e_240, 2);
      V v_x1_24127 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_e12_24126));
      V v_t_24137;
      switch (heff_tag_of(v_x1_24127)) {
      case TAG_IsInferable: {
        V v_i_24128 = heff_field(v_x1_24127, 0);
        heff_take_n(v_x1_24127, 1ULL, 1);
        V v_t_24131;
        switch (heff_tag_of(v_i_24128)) {
        case TAG_At: {
          V v_s_24130 = heff_dup(heff_field(v_i_24128, 1));
          v_t_24131 = v_s_24130;
          break;
        }
        default: heff_nomatch(v_i_24128);
        }
        v_t_24137 = heff_tag_at(v_ru_24e1_241_24ENamed, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24128}), v_t_24131});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24132 = heff_field(v_x1_24127, 0);
        heff_take_n(v_x1_24127, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ENamed, 2);
        v_t_24137 = v_c_24132;
        break;
      }
      case TAG_IsType: {
        V v_t_24133 = heff_field(v_x1_24127, 0);
        heff_take_n(v_x1_24127, 1ULL, 1);
        V v_t_24136;
        switch (heff_tag_of(v_t_24133)) {
        case TAG_At: {
          V v_s_24135 = heff_dup(heff_field(v_t_24133, 1));
          v_t_24136 = v_s_24135;
          break;
        }
        default: heff_nomatch(v_t_24133);
        }
        v_t_24137 = heff_tag_at(v_ru_24e1_241_24ENamed, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24133}), v_t_24136});
        break;
      }
      default: heff_nomatch(v_x1_24127);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgNamed, 2, (V[]){v_x_24125, v_t_24137}), v_sp_242});
    }
    case TAG_EPi: {
      V v_ru_24e1_241_24EPi = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24140 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_24150;
      switch (heff_tag_of(v_x1_24140)) {
      case TAG_IsInferable: {
        V v_i_24141 = heff_field(v_x1_24140, 0);
        heff_take_n(v_x1_24140, 1ULL, 1);
        V v_t_24144;
        switch (heff_tag_of(v_i_24141)) {
        case TAG_At: {
          V v_s_24143 = heff_dup(heff_field(v_i_24141, 1));
          v_t_24144 = v_s_24143;
          break;
        }
        default: heff_nomatch(v_i_24141);
        }
        v_t_24150 = heff_tag_at(v_ru_24e1_241_24EPi, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24141}), v_t_24144});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24145 = heff_field(v_x1_24140, 0);
        heff_take_n(v_x1_24140, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EPi, 2);
        v_t_24150 = v_c_24145;
        break;
      }
      case TAG_IsType: {
        V v_t_24146 = heff_field(v_x1_24140, 0);
        heff_take_n(v_x1_24140, 1ULL, 1);
        V v_t_24149;
        switch (heff_tag_of(v_t_24146)) {
        case TAG_At: {
          V v_s_24148 = heff_dup(heff_field(v_t_24146, 1));
          v_t_24149 = v_s_24148;
          break;
        }
        default: heff_nomatch(v_t_24146);
        }
        v_t_24150 = heff_tag_at(v_ru_24e1_241_24EPi, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24146}), v_t_24149});
        break;
      }
      default: heff_nomatch(v_x1_24140);
      }
      V v_t_24153;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24152 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24153 = v_s_24152;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24150}), v_t_24153});
    }
    case TAG_ELam: {
      V v_ru_24e1_241_24ELam = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24156 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_24166;
      switch (heff_tag_of(v_x1_24156)) {
      case TAG_IsInferable: {
        V v_i_24157 = heff_field(v_x1_24156, 0);
        heff_take_n(v_x1_24156, 1ULL, 1);
        V v_t_24160;
        switch (heff_tag_of(v_i_24157)) {
        case TAG_At: {
          V v_s_24159 = heff_dup(heff_field(v_i_24157, 1));
          v_t_24160 = v_s_24159;
          break;
        }
        default: heff_nomatch(v_i_24157);
        }
        v_t_24166 = heff_tag_at(v_ru_24e1_241_24ELam, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24157}), v_t_24160});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24161 = heff_field(v_x1_24156, 0);
        heff_take_n(v_x1_24156, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ELam, 2);
        v_t_24166 = v_c_24161;
        break;
      }
      case TAG_IsType: {
        V v_t_24162 = heff_field(v_x1_24156, 0);
        heff_take_n(v_x1_24156, 1ULL, 1);
        V v_t_24165;
        switch (heff_tag_of(v_t_24162)) {
        case TAG_At: {
          V v_s_24164 = heff_dup(heff_field(v_t_24162, 1));
          v_t_24165 = v_s_24164;
          break;
        }
        default: heff_nomatch(v_t_24162);
        }
        v_t_24166 = heff_tag_at(v_ru_24e1_241_24ELam, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24162}), v_t_24165});
        break;
      }
      default: heff_nomatch(v_x1_24156);
      }
      V v_t_24169;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24168 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24169 = v_s_24168;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24166}), v_t_24169});
    }
    case TAG_EAnn: {
      V v_ru_24e1_241_24EAnn = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24172 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_24182;
      switch (heff_tag_of(v_x1_24172)) {
      case TAG_IsInferable: {
        V v_i_24173 = heff_field(v_x1_24172, 0);
        heff_take_n(v_x1_24172, 1ULL, 1);
        V v_t_24176;
        switch (heff_tag_of(v_i_24173)) {
        case TAG_At: {
          V v_s_24175 = heff_dup(heff_field(v_i_24173, 1));
          v_t_24176 = v_s_24175;
          break;
        }
        default: heff_nomatch(v_i_24173);
        }
        v_t_24182 = heff_tag_at(v_ru_24e1_241_24EAnn, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24173}), v_t_24176});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24177 = heff_field(v_x1_24172, 0);
        heff_take_n(v_x1_24172, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EAnn, 2);
        v_t_24182 = v_c_24177;
        break;
      }
      case TAG_IsType: {
        V v_t_24178 = heff_field(v_x1_24172, 0);
        heff_take_n(v_x1_24172, 1ULL, 1);
        V v_t_24181;
        switch (heff_tag_of(v_t_24178)) {
        case TAG_At: {
          V v_s_24180 = heff_dup(heff_field(v_t_24178, 1));
          v_t_24181 = v_s_24180;
          break;
        }
        default: heff_nomatch(v_t_24178);
        }
        v_t_24182 = heff_tag_at(v_ru_24e1_241_24EAnn, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24178}), v_t_24181});
        break;
      }
      default: heff_nomatch(v_x1_24172);
      }
      V v_t_24185;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24184 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24185 = v_s_24184;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24182}), v_t_24185});
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_241, 0ULL, 4);
      heff_drop(v_sp_242);
      V v_x1_24190 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_24200;
      switch (heff_tag_of(v_x1_24190)) {
      case TAG_IsInferable: {
        V v_i_24191 = heff_field(v_x1_24190, 0);
        V v_ru_24x1_24190_24IsInferable = heff_take_reuse_n(v_x1_24190, 1ULL, 1);
        V v_t_24194;
        switch (heff_tag_of(v_i_24191)) {
        case TAG_At: {
          V v_s_24193 = heff_dup(heff_field(v_i_24191, 1));
          v_t_24194 = v_s_24193;
          break;
        }
        default: heff_nomatch(v_i_24191);
        }
        v_t_24200 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_24190_24IsInferable, TAG_CInf, 1, (V[]){v_i_24191}), v_t_24194});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24195 = heff_field(v_x1_24190, 0);
        heff_take_n(v_x1_24190, 1ULL, 1);
        v_t_24200 = v_c_24195;
        break;
      }
      case TAG_IsType: {
        V v_t_24196 = heff_field(v_x1_24190, 0);
        V v_ru_24x1_24190_24IsType = heff_take_reuse_n(v_x1_24190, 1ULL, 1);
        V v_t_24199;
        switch (heff_tag_of(v_t_24196)) {
        case TAG_At: {
          V v_s_24198 = heff_dup(heff_field(v_t_24196, 1));
          v_t_24199 = v_s_24198;
          break;
        }
        default: heff_nomatch(v_t_24196);
        }
        v_t_24200 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_24190_24IsType, TAG_CType, 1, (V[]){v_t_24196}), v_t_24199});
        break;
      }
      default: heff_nomatch(v_x1_24190);
      }
      V v_t_24203;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24202 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24203 = v_s_24202;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24200}), v_t_24203});
    }
    case TAG_ESig: {
      V v_ru_24e1_241_24ESig = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_24205 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_24215;
      switch (heff_tag_of(v_x1_24205)) {
      case TAG_IsInferable: {
        V v_i_24206 = heff_field(v_x1_24205, 0);
        heff_take_n(v_x1_24205, 1ULL, 1);
        V v_t_24209;
        switch (heff_tag_of(v_i_24206)) {
        case TAG_At: {
          V v_s_24208 = heff_dup(heff_field(v_i_24206, 1));
          v_t_24209 = v_s_24208;
          break;
        }
        default: heff_nomatch(v_i_24206);
        }
        v_t_24215 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24ESig, TAG_CInf, 1, (V[]){v_i_24206}), v_t_24209});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24210 = heff_field(v_x1_24205, 0);
        heff_take_n(v_x1_24205, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ESig, 1);
        v_t_24215 = v_c_24210;
        break;
      }
      case TAG_IsType: {
        V v_t_24211 = heff_field(v_x1_24205, 0);
        heff_take_n(v_x1_24205, 1ULL, 1);
        V v_t_24214;
        switch (heff_tag_of(v_t_24211)) {
        case TAG_At: {
          V v_s_24213 = heff_dup(heff_field(v_t_24211, 1));
          v_t_24214 = v_s_24213;
          break;
        }
        default: heff_nomatch(v_t_24211);
        }
        v_t_24215 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24ESig, TAG_CType, 1, (V[]){v_t_24211}), v_t_24214});
        break;
      }
      default: heff_nomatch(v_x1_24205);
      }
      V v_t_24218;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24217 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24218 = v_s_24217;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24215}), v_t_24218});
    }
    case TAG_ESum: {
      V v_ru_24e1_241_24ESum = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_24220 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_24230;
      switch (heff_tag_of(v_x1_24220)) {
      case TAG_IsInferable: {
        V v_i_24221 = heff_field(v_x1_24220, 0);
        heff_take_n(v_x1_24220, 1ULL, 1);
        V v_t_24224;
        switch (heff_tag_of(v_i_24221)) {
        case TAG_At: {
          V v_s_24223 = heff_dup(heff_field(v_i_24221, 1));
          v_t_24224 = v_s_24223;
          break;
        }
        default: heff_nomatch(v_i_24221);
        }
        v_t_24230 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24ESum, TAG_CInf, 1, (V[]){v_i_24221}), v_t_24224});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24225 = heff_field(v_x1_24220, 0);
        heff_take_n(v_x1_24220, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ESum, 1);
        v_t_24230 = v_c_24225;
        break;
      }
      case TAG_IsType: {
        V v_t_24226 = heff_field(v_x1_24220, 0);
        heff_take_n(v_x1_24220, 1ULL, 1);
        V v_t_24229;
        switch (heff_tag_of(v_t_24226)) {
        case TAG_At: {
          V v_s_24228 = heff_dup(heff_field(v_t_24226, 1));
          v_t_24229 = v_s_24228;
          break;
        }
        default: heff_nomatch(v_t_24226);
        }
        v_t_24230 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24ESum, TAG_CType, 1, (V[]){v_t_24226}), v_t_24229});
        break;
      }
      default: heff_nomatch(v_x1_24220);
      }
      V v_t_24233;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24232 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24233 = v_s_24232;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24230}), v_t_24233});
    }
    case TAG_EStruct: {
      V v_ru_24e1_241_24EStruct = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_24235 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_24245;
      switch (heff_tag_of(v_x1_24235)) {
      case TAG_IsInferable: {
        V v_i_24236 = heff_field(v_x1_24235, 0);
        heff_take_n(v_x1_24235, 1ULL, 1);
        V v_t_24239;
        switch (heff_tag_of(v_i_24236)) {
        case TAG_At: {
          V v_s_24238 = heff_dup(heff_field(v_i_24236, 1));
          v_t_24239 = v_s_24238;
          break;
        }
        default: heff_nomatch(v_i_24236);
        }
        v_t_24245 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24EStruct, TAG_CInf, 1, (V[]){v_i_24236}), v_t_24239});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24240 = heff_field(v_x1_24235, 0);
        heff_take_n(v_x1_24235, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EStruct, 1);
        v_t_24245 = v_c_24240;
        break;
      }
      case TAG_IsType: {
        V v_t_24241 = heff_field(v_x1_24235, 0);
        heff_take_n(v_x1_24235, 1ULL, 1);
        V v_t_24244;
        switch (heff_tag_of(v_t_24241)) {
        case TAG_At: {
          V v_s_24243 = heff_dup(heff_field(v_t_24241, 1));
          v_t_24244 = v_s_24243;
          break;
        }
        default: heff_nomatch(v_t_24241);
        }
        v_t_24245 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24EStruct, TAG_CType, 1, (V[]){v_t_24241}), v_t_24244});
        break;
      }
      default: heff_nomatch(v_x1_24235);
      }
      V v_t_24248;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24247 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24248 = v_s_24247;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24245}), v_t_24248});
    }
    case TAG_EMatch: {
      V v_ru_24e1_241_24EMatch = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24251 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_24261;
      switch (heff_tag_of(v_x1_24251)) {
      case TAG_IsInferable: {
        V v_i_24252 = heff_field(v_x1_24251, 0);
        heff_take_n(v_x1_24251, 1ULL, 1);
        V v_t_24255;
        switch (heff_tag_of(v_i_24252)) {
        case TAG_At: {
          V v_s_24254 = heff_dup(heff_field(v_i_24252, 1));
          v_t_24255 = v_s_24254;
          break;
        }
        default: heff_nomatch(v_i_24252);
        }
        v_t_24261 = heff_tag_at(v_ru_24e1_241_24EMatch, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24252}), v_t_24255});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24256 = heff_field(v_x1_24251, 0);
        heff_take_n(v_x1_24251, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EMatch, 2);
        v_t_24261 = v_c_24256;
        break;
      }
      case TAG_IsType: {
        V v_t_24257 = heff_field(v_x1_24251, 0);
        heff_take_n(v_x1_24251, 1ULL, 1);
        V v_t_24260;
        switch (heff_tag_of(v_t_24257)) {
        case TAG_At: {
          V v_s_24259 = heff_dup(heff_field(v_t_24257, 1));
          v_t_24260 = v_s_24259;
          break;
        }
        default: heff_nomatch(v_t_24257);
        }
        v_t_24261 = heff_tag_at(v_ru_24e1_241_24EMatch, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24257}), v_t_24260});
        break;
      }
      default: heff_nomatch(v_x1_24251);
      }
      V v_t_24264;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24263 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24264 = v_s_24263;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24261}), v_t_24264});
    }
    case TAG_ELetIn: {
      V v_ru_24e1_241_24ELetIn = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24267 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_24277;
      switch (heff_tag_of(v_x1_24267)) {
      case TAG_IsInferable: {
        V v_i_24268 = heff_field(v_x1_24267, 0);
        heff_take_n(v_x1_24267, 1ULL, 1);
        V v_t_24271;
        switch (heff_tag_of(v_i_24268)) {
        case TAG_At: {
          V v_s_24270 = heff_dup(heff_field(v_i_24268, 1));
          v_t_24271 = v_s_24270;
          break;
        }
        default: heff_nomatch(v_i_24268);
        }
        v_t_24277 = heff_tag_at(v_ru_24e1_241_24ELetIn, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24268}), v_t_24271});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24272 = heff_field(v_x1_24267, 0);
        heff_take_n(v_x1_24267, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ELetIn, 2);
        v_t_24277 = v_c_24272;
        break;
      }
      case TAG_IsType: {
        V v_t_24273 = heff_field(v_x1_24267, 0);
        heff_take_n(v_x1_24267, 1ULL, 1);
        V v_t_24276;
        switch (heff_tag_of(v_t_24273)) {
        case TAG_At: {
          V v_s_24275 = heff_dup(heff_field(v_t_24273, 1));
          v_t_24276 = v_s_24275;
          break;
        }
        default: heff_nomatch(v_t_24273);
        }
        v_t_24277 = heff_tag_at(v_ru_24e1_241_24ELetIn, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24273}), v_t_24276});
        break;
      }
      default: heff_nomatch(v_x1_24267);
      }
      V v_t_24280;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24279 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24280 = v_s_24279;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24277}), v_t_24280});
    }
    case TAG_EDo: {
      V v_ru_24e1_241_24EDo = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_24282 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_24292;
      switch (heff_tag_of(v_x1_24282)) {
      case TAG_IsInferable: {
        V v_i_24283 = heff_field(v_x1_24282, 0);
        heff_take_n(v_x1_24282, 1ULL, 1);
        V v_t_24286;
        switch (heff_tag_of(v_i_24283)) {
        case TAG_At: {
          V v_s_24285 = heff_dup(heff_field(v_i_24283, 1));
          v_t_24286 = v_s_24285;
          break;
        }
        default: heff_nomatch(v_i_24283);
        }
        v_t_24292 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24EDo, TAG_CInf, 1, (V[]){v_i_24283}), v_t_24286});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24287 = heff_field(v_x1_24282, 0);
        heff_take_n(v_x1_24282, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EDo, 1);
        v_t_24292 = v_c_24287;
        break;
      }
      case TAG_IsType: {
        V v_t_24288 = heff_field(v_x1_24282, 0);
        heff_take_n(v_x1_24282, 1ULL, 1);
        V v_t_24291;
        switch (heff_tag_of(v_t_24288)) {
        case TAG_At: {
          V v_s_24290 = heff_dup(heff_field(v_t_24288, 1));
          v_t_24291 = v_s_24290;
          break;
        }
        default: heff_nomatch(v_t_24288);
        }
        v_t_24292 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24EDo, TAG_CType, 1, (V[]){v_t_24288}), v_t_24291});
        break;
      }
      default: heff_nomatch(v_x1_24282);
      }
      V v_t_24295;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24294 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24295 = v_s_24294;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24292}), v_t_24295});
    }
    case TAG_ELocal: {
      V v_ru_24e1_241_24ELocal = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24298 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_24308;
      switch (heff_tag_of(v_x1_24298)) {
      case TAG_IsInferable: {
        V v_i_24299 = heff_field(v_x1_24298, 0);
        heff_take_n(v_x1_24298, 1ULL, 1);
        V v_t_24302;
        switch (heff_tag_of(v_i_24299)) {
        case TAG_At: {
          V v_s_24301 = heff_dup(heff_field(v_i_24299, 1));
          v_t_24302 = v_s_24301;
          break;
        }
        default: heff_nomatch(v_i_24299);
        }
        v_t_24308 = heff_tag_at(v_ru_24e1_241_24ELocal, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24299}), v_t_24302});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24303 = heff_field(v_x1_24298, 0);
        heff_take_n(v_x1_24298, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ELocal, 2);
        v_t_24308 = v_c_24303;
        break;
      }
      case TAG_IsType: {
        V v_t_24304 = heff_field(v_x1_24298, 0);
        heff_take_n(v_x1_24298, 1ULL, 1);
        V v_t_24307;
        switch (heff_tag_of(v_t_24304)) {
        case TAG_At: {
          V v_s_24306 = heff_dup(heff_field(v_t_24304, 1));
          v_t_24307 = v_s_24306;
          break;
        }
        default: heff_nomatch(v_t_24304);
        }
        v_t_24308 = heff_tag_at(v_ru_24e1_241_24ELocal, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24304}), v_t_24307});
        break;
      }
      default: heff_nomatch(v_x1_24298);
      }
      V v_t_24311;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24310 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24311 = v_s_24310;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24308}), v_t_24311});
    }
    case TAG_EInvalid: {
      V v_ru_24e1_241_24EInvalid = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_24313 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(heff_dup(v_e_240)));
      V v_t_24323;
      switch (heff_tag_of(v_x1_24313)) {
      case TAG_IsInferable: {
        V v_i_24314 = heff_field(v_x1_24313, 0);
        heff_take_n(v_x1_24313, 1ULL, 1);
        V v_t_24317;
        switch (heff_tag_of(v_i_24314)) {
        case TAG_At: {
          V v_s_24316 = heff_dup(heff_field(v_i_24314, 1));
          v_t_24317 = v_s_24316;
          break;
        }
        default: heff_nomatch(v_i_24314);
        }
        v_t_24323 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24EInvalid, TAG_CInf, 1, (V[]){v_i_24314}), v_t_24317});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24318 = heff_field(v_x1_24313, 0);
        heff_take_n(v_x1_24313, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EInvalid, 1);
        v_t_24323 = v_c_24318;
        break;
      }
      case TAG_IsType: {
        V v_t_24319 = heff_field(v_x1_24313, 0);
        heff_take_n(v_x1_24313, 1ULL, 1);
        V v_t_24322;
        switch (heff_tag_of(v_t_24319)) {
        case TAG_At: {
          V v_s_24321 = heff_dup(heff_field(v_t_24319, 1));
          v_t_24322 = v_s_24321;
          break;
        }
        default: heff_nomatch(v_t_24319);
        }
        v_t_24323 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24e1_241_24EInvalid, TAG_CType, 1, (V[]){v_t_24319}), v_t_24322});
        break;
      }
      default: heff_nomatch(v_x1_24313);
      }
      V v_t_24326;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24325 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24326 = v_s_24325;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_24323}), v_t_24326});
    }
    default: return heff_nomatch(v_e1_241);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2epresyntax_2eargOf_24s1825882790x1322352207_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2eargOf_24s1825882790x1322352207(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2epresyntax_2eappOf_24s269192126x2121543052_str0 = {{0x80000000u, K_STR, 0}, 22, 22, {96, 65, 114, 114, 97, 121, 96, 32, 116, 97, 107, 101, 115, 32, 111, 110, 101, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2epresyntax_2eappOf_24s269192126x2121543052_str1 = {{0x80000000u, K_STR, 0}, 22, 22, {96, 65, 114, 114, 97, 121, 96, 32, 116, 97, 107, 101, 115, 32, 111, 110, 101, 32, 116, 121, 112, 101}};
Clo g_heff_2epresyntax_2eappOf_24s269192126x2121543052_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2eappOf_24s269192126x2121543052_entry, 3, 0};

V g_heff_2epresyntax_2eappOf_24s269192126x2121543052(V v_h_240, V v_args_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_h_240)) {
  case TAG_At: {
    V v_it1_243 = heff_dup(heff_field(v_h_240, 0));
    V v_tsp_244 = heff_dup(heff_field(v_h_240, 1));
    switch (heff_tag_of(v_it1_243)) {
    case TAG_EVar: {
      V v_ru_24it1_243_24EVar = heff_take_reuse_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_246 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_247 = ({ V a_0 = v_t_246; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_246); r_; });
      V v_t_248 = heff_tag(TAG_IApp, 2, (V[]){v_t_247, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag_at(v_ru_24it1_243_24EVar, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_248, v_sp_242})});
    }
    case TAG_EImplicitVar: {
      V v_ru_24it1_243_24EImplicitVar = heff_take_reuse_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2410 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2410); r_; });
      V v_t_2412 = heff_tag(TAG_IApp, 2, (V[]){v_t_2411, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag_at(v_ru_24it1_243_24EImplicitVar, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2412, v_sp_242})});
    }
    case TAG_ETag: {
      V v_t_2413 = heff_field(v_it1_243, 0);
      V v_ru_24it1_243_24ETag = heff_take_reuse_n(v_it1_243, 1ULL, 1);
      heff_drop_tag(v_h_240, 2);
      V v_t_2414 = heff_tag(TAG_CTag, 3, (V[]){v_t_2413, v_tsp_244, (g_prelude_2emap_24s67362943x99565768(v_args_241))});
      return heff_tag_at(v_ru_24it1_243_24ETag, TAG_IsCheckable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2414, v_sp_242})});
    }
    case TAG_EInt: {
      V v_ru_24it1_243_24EInt = heff_take_reuse_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2416 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_2417 = ({ V a_0 = v_t_2416; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2416); r_; });
      V v_t_2418 = heff_tag(TAG_IApp, 2, (V[]){v_t_2417, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag_at(v_ru_24it1_243_24EInt, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2418, v_sp_242})});
    }
    case TAG_EFloat: {
      V v_ru_24it1_243_24EFloat = heff_take_reuse_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2420 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_2421 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2420); r_; });
      V v_t_2422 = heff_tag(TAG_IApp, 2, (V[]){v_t_2421, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag_at(v_ru_24it1_243_24EFloat, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2422, v_sp_242})});
    }
    case TAG_EString: {
      V v_ru_24it1_243_24EString = heff_take_reuse_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2424 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_2425 = ({ V a_0 = v_t_2424; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2424); r_; });
      V v_t_2426 = heff_tag(TAG_IApp, 2, (V[]){v_t_2425, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag_at(v_ru_24it1_243_24EString, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2426, v_sp_242})});
    }
    case TAG_EWord: {
      V v_it11_2427 = heff_field(v_it1_243, 0);
      V v_ru_24it1_243_24EWord = heff_take_reuse_n(v_it1_243, 1ULL, 1);
      heff_drop(v_tsp_244);
      switch (heff_tag_of(v_it11_2427)) {
      case TAG_TypeWord: {
        V v_t_2428 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
        V v_t_2429 = ({ V a_0 = v_t_2428; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2428); r_; });
        V v_t_2430 = heff_tag(TAG_IApp, 2, (V[]){v_t_2429, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
        return heff_tag_at(v_ru_24it1_243_24EWord, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2430, v_sp_242})});
      }
      case TAG_IntWord: {
        V v_t_2431 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
        V v_t_2432 = ({ V a_0 = v_t_2431; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2431); r_; });
        V v_t_2433 = heff_tag(TAG_IApp, 2, (V[]){v_t_2432, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
        return heff_tag_at(v_ru_24it1_243_24EWord, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2433, v_sp_242})});
      }
      case TAG_FloatWord: {
        V v_t_2434 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
        V v_t_2435 = ({ V a_0 = v_t_2434; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2434); r_; });
        V v_t_2436 = heff_tag(TAG_IApp, 2, (V[]){v_t_2435, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
        return heff_tag_at(v_ru_24it1_243_24EWord, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2436, v_sp_242})});
      }
      case TAG_StringWord: {
        V v_t_2437 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
        V v_t_2438 = ({ V a_0 = v_t_2437; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2437); r_; });
        V v_t_2439 = heff_tag(TAG_IApp, 2, (V[]){v_t_2438, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
        return heff_tag_at(v_ru_24it1_243_24EWord, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2439, v_sp_242})});
      }
      case TAG_ArrayWord: {
        heff_drop_tag(v_h_240, 2);
        switch (heff_tag_of(v_args_241)) {
        case TAG_Nil: {
          V v_t_2440 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(3LL), ((V)&g_heff_2epresyntax_2eappOf_24s269192126x2121543052_str0)}), heff_dup(v_sp_242)});
          V v_t_2441 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_243_24EWord, TAG_TInf, 1, (V[]){v_t_2440}), v_sp_242});
          return heff_tag(TAG_IsType, 1, (V[]){v_t_2441});
        }
        case TAG_Cons: {
          V v_a_2442 = heff_field(v_args_241, 0);
          V v_it2_2443 = heff_field(v_args_241, 1);
          V v_ru_24args_241_24Cons = heff_take_reuse_n(v_args_241, 3ULL, 2);
          switch (heff_tag_of(v_it2_2443)) {
          case TAG_Nil: {
            V v_x1_2444 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_a_2442));
            V v_t_2454;
            switch (heff_tag_of(v_x1_2444)) {
            case TAG_IsInferable: {
              V v_i_2445 = heff_field(v_x1_2444, 0);
              heff_take_n(v_x1_2444, 1ULL, 1);
              V v_t_2448;
              switch (heff_tag_of(v_i_2445)) {
              case TAG_At: {
                V v_s_2447 = heff_dup(heff_field(v_i_2445, 1));
                v_t_2448 = v_s_2447;
                break;
              }
              default: heff_nomatch(v_i_2445);
              }
              v_t_2454 = heff_tag_at(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_243_24EWord, TAG_TInf, 1, (V[]){v_i_2445}), v_t_2448});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_2449 = heff_field(v_x1_2444, 0);
              heff_take_n(v_x1_2444, 1ULL, 1);
              V v_t_2452;
              switch (heff_tag_of(v_c_2449)) {
              case TAG_At: {
                V v_s_2451 = heff_dup(heff_field(v_c_2449, 1));
                v_t_2452 = v_s_2451;
                break;
              }
              default: heff_nomatch(v_c_2449);
              }
              v_t_2454 = heff_tag_at(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_243_24EWord, TAG_TChk, 1, (V[]){v_c_2449}), v_t_2452});
              break;
            }
            case TAG_IsType: {
              V v_t_2453 = heff_field(v_x1_2444, 0);
              heff_take_n(v_x1_2444, 1ULL, 1);
              heff_drop_cell(v_ru_24it1_243_24EWord, 1);
              heff_drop_cell(v_ru_24args_241_24Cons, 2);
              v_t_2454 = v_t_2453;
              break;
            }
            default: heff_nomatch(v_x1_2444);
            }
            V v_t_2455 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_TArray, 1, (V[]){v_t_2454}), v_sp_242});
            return heff_tag(TAG_IsType, 1, (V[]){v_t_2455});
          }
          case TAG_Cons: {
            V v_ru_24it2_2443_24Cons = heff_take_reuse_n(v_it2_2443, 0ULL, 2);
            heff_drop(v_a_2442);
            V v_t_2458 = heff_tag_at(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(3LL), ((V)&g_heff_2epresyntax_2eappOf_24s269192126x2121543052_str1)}), heff_dup(v_sp_242)});
            V v_t_2459 = heff_tag_at(v_ru_24it2_2443_24Cons, TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_243_24EWord, TAG_TInf, 1, (V[]){v_t_2458}), v_sp_242});
            return heff_tag(TAG_IsType, 1, (V[]){v_t_2459});
          }
          default: return heff_nomatch(v_it2_2443);
          }
        }
        default: return heff_nomatch(v_args_241);
        }
      }
      case TAG_AbandonWord: {
        V v_t_2460 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
        V v_t_2461 = ({ V a_0 = v_t_2460; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2460); r_; });
        V v_t_2462 = heff_tag(TAG_IApp, 2, (V[]){v_t_2461, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
        return heff_tag_at(v_ru_24it1_243_24EWord, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2462, v_sp_242})});
      }
      case TAG_FixedWord: {
        heff_take_n(v_it11_2427, 0ULL, 1);
        V v_t_2464 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
        V v_t_2465 = ({ V a_0 = v_t_2464; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2464); r_; });
        V v_t_2466 = heff_tag(TAG_IApp, 2, (V[]){v_t_2465, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
        return heff_tag_at(v_ru_24it1_243_24EWord, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2466, v_sp_242})});
      }
      default: return heff_nomatch(v_it11_2427);
      }
    }
    case TAG_EApp: {
      V v_ru_24it1_243_24EApp = heff_take_reuse_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2469 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_2470 = ({ V a_0 = v_t_2469; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2469); r_; });
      V v_t_2471 = heff_tag_at(v_ru_24it1_243_24EApp, TAG_IApp, 2, (V[]){v_t_2470, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag(TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2471, v_sp_242})});
    }
    case TAG_EProject: {
      V v_ru_24it1_243_24EProject = heff_take_reuse_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2473 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_2474 = ({ V a_0 = v_t_2473; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2473); r_; });
      V v_t_2475 = heff_tag(TAG_IApp, 2, (V[]){v_t_2474, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag_at(v_ru_24it1_243_24EProject, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2475, v_sp_242})});
    }
    case TAG_ENamed: {
      V v_ru_24it1_243_24ENamed = heff_take_reuse_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2478 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_2479 = ({ V a_0 = v_t_2478; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2478); r_; });
      V v_t_2480 = heff_tag_at(v_ru_24it1_243_24ENamed, TAG_IApp, 2, (V[]){v_t_2479, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag(TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2480, v_sp_242})});
    }
    case TAG_EPi: {
      V v_ru_24it1_243_24EPi = heff_take_reuse_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2483 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_2484 = ({ V a_0 = v_t_2483; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2483); r_; });
      V v_t_2485 = heff_tag_at(v_ru_24it1_243_24EPi, TAG_IApp, 2, (V[]){v_t_2484, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag(TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2485, v_sp_242})});
    }
    case TAG_ELam: {
      V v_ru_24it1_243_24ELam = heff_take_reuse_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2488 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_2489 = ({ V a_0 = v_t_2488; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2488); r_; });
      V v_t_2490 = heff_tag_at(v_ru_24it1_243_24ELam, TAG_IApp, 2, (V[]){v_t_2489, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag(TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2490, v_sp_242})});
    }
    case TAG_EAnn: {
      V v_ru_24it1_243_24EAnn = heff_take_reuse_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2493 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_2494 = ({ V a_0 = v_t_2493; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2493); r_; });
      V v_t_2495 = heff_tag_at(v_ru_24it1_243_24EAnn, TAG_IApp, 2, (V[]){v_t_2494, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag(TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2495, v_sp_242})});
    }
    case TAG_ESpec: {
      heff_take_n(v_it1_243, 0ULL, 4);
      heff_drop(v_tsp_244);
      V v_t_24100 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_24101 = ({ V a_0 = v_t_24100; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24100); r_; });
      V v_t_24102 = heff_tag(TAG_IApp, 2, (V[]){v_t_24101, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag(TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24102, v_sp_242})});
    }
    case TAG_ESig: {
      V v_ru_24it1_243_24ESig = heff_take_reuse_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24104 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_24105 = ({ V a_0 = v_t_24104; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24104); r_; });
      V v_t_24106 = heff_tag(TAG_IApp, 2, (V[]){v_t_24105, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag_at(v_ru_24it1_243_24ESig, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24106, v_sp_242})});
    }
    case TAG_ESum: {
      V v_ru_24it1_243_24ESum = heff_take_reuse_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24108 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_24109 = ({ V a_0 = v_t_24108; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24108); r_; });
      V v_t_24110 = heff_tag(TAG_IApp, 2, (V[]){v_t_24109, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag_at(v_ru_24it1_243_24ESum, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24110, v_sp_242})});
    }
    case TAG_EStruct: {
      V v_ru_24it1_243_24EStruct = heff_take_reuse_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24112 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_24113 = ({ V a_0 = v_t_24112; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24112); r_; });
      V v_t_24114 = heff_tag(TAG_IApp, 2, (V[]){v_t_24113, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag_at(v_ru_24it1_243_24EStruct, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24114, v_sp_242})});
    }
    case TAG_EMatch: {
      V v_ru_24it1_243_24EMatch = heff_take_reuse_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24117 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_24118 = ({ V a_0 = v_t_24117; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24117); r_; });
      V v_t_24119 = heff_tag_at(v_ru_24it1_243_24EMatch, TAG_IApp, 2, (V[]){v_t_24118, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag(TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24119, v_sp_242})});
    }
    case TAG_ELetIn: {
      V v_ru_24it1_243_24ELetIn = heff_take_reuse_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24122 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_24123 = ({ V a_0 = v_t_24122; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24122); r_; });
      V v_t_24124 = heff_tag_at(v_ru_24it1_243_24ELetIn, TAG_IApp, 2, (V[]){v_t_24123, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag(TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24124, v_sp_242})});
    }
    case TAG_EDo: {
      V v_ru_24it1_243_24EDo = heff_take_reuse_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24126 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_24127 = ({ V a_0 = v_t_24126; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24126); r_; });
      V v_t_24128 = heff_tag(TAG_IApp, 2, (V[]){v_t_24127, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag_at(v_ru_24it1_243_24EDo, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24128, v_sp_242})});
    }
    case TAG_ELocal: {
      V v_ru_24it1_243_24ELocal = heff_take_reuse_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24131 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_24132 = ({ V a_0 = v_t_24131; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24131); r_; });
      V v_t_24133 = heff_tag_at(v_ru_24it1_243_24ELocal, TAG_IApp, 2, (V[]){v_t_24132, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag(TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24133, v_sp_242})});
    }
    case TAG_EInvalid: {
      V v_ru_24it1_243_24EInvalid = heff_take_reuse_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24135 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_h_240));
      V v_t_24136 = ({ V a_0 = v_t_24135; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24135); r_; });
      V v_t_24137 = heff_tag(TAG_IApp, 2, (V[]){v_t_24136, (g_prelude_2emap_24s684503405x117589606(v_args_241))});
      return heff_tag_at(v_ru_24it1_243_24EInvalid, TAG_IsInferable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24137, v_sp_242})});
    }
    default: return heff_nomatch(v_it1_243);
    }
  }
  default: return heff_nomatch(v_h_240);
  }
}
V g_heff_2epresyntax_2eappOf_24s269192126x2121543052_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2eappOf_24s269192126x2121543052(a[0], a[1], a[2]);
}
Clo g_heff_2epresyntax_2epiBinderOf_24s113941090x157037166_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2epiBinderOf_24s113941090x157037166_entry, 1, 0};

V g_heff_2epresyntax_2epiBinderOf_24s113941090x157037166(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xsp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24PiNamed = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_x1_244 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_t_243));
    V v_t_2414;
    switch (heff_tag_of(v_x1_244)) {
    case TAG_IsInferable: {
      V v_i_245 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24IsInferable = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      V v_t_248;
      switch (heff_tag_of(v_i_245)) {
      case TAG_At: {
        V v_s_247 = heff_dup(heff_field(v_i_245, 1));
        v_t_248 = v_s_247;
        break;
      }
      default: heff_nomatch(v_i_245);
      }
      v_t_2414 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_244_24IsInferable, TAG_TInf, 1, (V[]){v_i_245}), v_t_248});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_249 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24IsCheckable = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_c_249)) {
      case TAG_At: {
        V v_s_2411 = heff_dup(heff_field(v_c_249, 1));
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_c_249);
      }
      v_t_2414 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_244_24IsCheckable, TAG_TChk, 1, (V[]){v_c_249}), v_t_2412});
      break;
    }
    case TAG_IsType: {
      V v_t_2413 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 1);
      v_t_2414 = v_t_2413;
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    return heff_tag_at(v_ru_24x2_240_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_241, v_xsp_242, v_t_2414});
  }
  case TAG_PiImplicit: {
    V v_x_2415 = heff_field(v_x2_240, 0);
    V v_xsp_2416 = heff_field(v_x2_240, 1);
    V v_bsp_2417 = heff_field(v_x2_240, 2);
    V v_t_2418 = heff_field(v_x2_240, 3);
    V v_d_2419 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24PiImplicit = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_x1_2420 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_t_2418));
    V v_t_2430;
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_IsInferable: {
      V v_i_2421 = heff_field(v_x1_2420, 0);
      V v_ru_24x1_2420_24IsInferable = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
      V v_t_2424;
      switch (heff_tag_of(v_i_2421)) {
      case TAG_At: {
        V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
        v_t_2424 = v_s_2423;
        break;
      }
      default: heff_nomatch(v_i_2421);
      }
      v_t_2430 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_2420_24IsInferable, TAG_TInf, 1, (V[]){v_i_2421}), v_t_2424});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2425 = heff_field(v_x1_2420, 0);
      V v_ru_24x1_2420_24IsCheckable = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
      V v_t_2428;
      switch (heff_tag_of(v_c_2425)) {
      case TAG_At: {
        V v_s_2427 = heff_dup(heff_field(v_c_2425, 1));
        v_t_2428 = v_s_2427;
        break;
      }
      default: heff_nomatch(v_c_2425);
      }
      v_t_2430 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_2420_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2425}), v_t_2428});
      break;
    }
    case TAG_IsType: {
      V v_t_2429 = heff_field(v_x1_2420, 0);
      heff_take_n(v_x1_2420, 1ULL, 1);
      v_t_2430 = v_t_2429;
      break;
    }
    default: heff_nomatch(v_x1_2420);
    }
    V v_t_2443;
    switch (heff_tag_of(v_d_2419)) {
    case TAG_Nothing: {
      v_t_2443 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2431 = heff_field(v_d_2419, 0);
      V v_ru_24d_2419_24Just = heff_take_reuse_n(v_d_2419, 1ULL, 1);
      V v_x1_2432 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_x_2431));
      V v_t_2442;
      switch (heff_tag_of(v_x1_2432)) {
      case TAG_IsInferable: {
        V v_i_2433 = heff_field(v_x1_2432, 0);
        heff_take_n(v_x1_2432, 1ULL, 1);
        V v_t_2436;
        switch (heff_tag_of(v_i_2433)) {
        case TAG_At: {
          V v_s_2435 = heff_dup(heff_field(v_i_2433, 1));
          v_t_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_i_2433);
        }
        v_t_2442 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24d_2419_24Just, TAG_CInf, 1, (V[]){v_i_2433}), v_t_2436});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2437 = heff_field(v_x1_2432, 0);
        heff_take_n(v_x1_2432, 1ULL, 1);
        heff_drop_cell(v_ru_24d_2419_24Just, 1);
        v_t_2442 = v_c_2437;
        break;
      }
      case TAG_IsType: {
        V v_t_2438 = heff_field(v_x1_2432, 0);
        heff_take_n(v_x1_2432, 1ULL, 1);
        V v_t_2441;
        switch (heff_tag_of(v_t_2438)) {
        case TAG_At: {
          V v_s_2440 = heff_dup(heff_field(v_t_2438, 1));
          v_t_2441 = v_s_2440;
          break;
        }
        default: heff_nomatch(v_t_2438);
        }
        v_t_2442 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24d_2419_24Just, TAG_CType, 1, (V[]){v_t_2438}), v_t_2441});
        break;
      }
      default: heff_nomatch(v_x1_2432);
      }
      v_t_2443 = heff_tag(TAG_Just, 1, (V[]){v_t_2442});
      break;
    }
    default: heff_nomatch(v_d_2419);
    }
    return heff_tag_at(v_ru_24x2_240_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_2415, v_xsp_2416, v_bsp_2417, v_t_2430, v_t_2443});
  }
  case TAG_PiInstance: {
    V v_x_2444 = heff_field(v_x2_240, 0);
    V v_xsp_2445 = heff_field(v_x2_240, 1);
    V v_bsp_2446 = heff_field(v_x2_240, 2);
    V v_t_2447 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24PiInstance = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_x1_2448 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_t_2447));
    V v_t_2458;
    switch (heff_tag_of(v_x1_2448)) {
    case TAG_IsInferable: {
      V v_i_2449 = heff_field(v_x1_2448, 0);
      V v_ru_24x1_2448_24IsInferable = heff_take_reuse_n(v_x1_2448, 1ULL, 1);
      V v_t_2452;
      switch (heff_tag_of(v_i_2449)) {
      case TAG_At: {
        V v_s_2451 = heff_dup(heff_field(v_i_2449, 1));
        v_t_2452 = v_s_2451;
        break;
      }
      default: heff_nomatch(v_i_2449);
      }
      v_t_2458 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_2448_24IsInferable, TAG_TInf, 1, (V[]){v_i_2449}), v_t_2452});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2453 = heff_field(v_x1_2448, 0);
      V v_ru_24x1_2448_24IsCheckable = heff_take_reuse_n(v_x1_2448, 1ULL, 1);
      V v_t_2456;
      switch (heff_tag_of(v_c_2453)) {
      case TAG_At: {
        V v_s_2455 = heff_dup(heff_field(v_c_2453, 1));
        v_t_2456 = v_s_2455;
        break;
      }
      default: heff_nomatch(v_c_2453);
      }
      v_t_2458 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_2448_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2453}), v_t_2456});
      break;
    }
    case TAG_IsType: {
      V v_t_2457 = heff_field(v_x1_2448, 0);
      heff_take_n(v_x1_2448, 1ULL, 1);
      v_t_2458 = v_t_2457;
      break;
    }
    default: heff_nomatch(v_x1_2448);
    }
    return heff_tag_at(v_ru_24x2_240_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2444, v_xsp_2445, v_bsp_2446, v_t_2458});
  }
  case TAG_PiAnon: {
    V v_t_2459 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24PiAnon = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_x1_2460 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_t_2459));
    V v_t_2470;
    switch (heff_tag_of(v_x1_2460)) {
    case TAG_IsInferable: {
      V v_i_2461 = heff_field(v_x1_2460, 0);
      heff_take_n(v_x1_2460, 1ULL, 1);
      V v_t_2464;
      switch (heff_tag_of(v_i_2461)) {
      case TAG_At: {
        V v_s_2463 = heff_dup(heff_field(v_i_2461, 1));
        v_t_2464 = v_s_2463;
        break;
      }
      default: heff_nomatch(v_i_2461);
      }
      v_t_2470 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x2_240_24PiAnon, TAG_TInf, 1, (V[]){v_i_2461}), v_t_2464});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2465 = heff_field(v_x1_2460, 0);
      heff_take_n(v_x1_2460, 1ULL, 1);
      V v_t_2468;
      switch (heff_tag_of(v_c_2465)) {
      case TAG_At: {
        V v_s_2467 = heff_dup(heff_field(v_c_2465, 1));
        v_t_2468 = v_s_2467;
        break;
      }
      default: heff_nomatch(v_c_2465);
      }
      v_t_2470 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x2_240_24PiAnon, TAG_TChk, 1, (V[]){v_c_2465}), v_t_2468});
      break;
    }
    case TAG_IsType: {
      V v_t_2469 = heff_field(v_x1_2460, 0);
      heff_take_n(v_x1_2460, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24PiAnon, 1);
      v_t_2470 = v_t_2469;
      break;
    }
    default: heff_nomatch(v_x1_2460);
    }
    return heff_tag(TAG_PiAnon, 1, (V[]){v_t_2470});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2epresyntax_2epiBinderOf_24s113941090x157037166_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2epiBinderOf_24s113941090x157037166(a[0]);
}
Clo g_heff_2epresyntax_2efieldDeclOf_24s2049272031x2094854488_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2efieldDeclOf_24s2049272031x2094854488_entry, 1, 0};

V g_heff_2epresyntax_2efieldDeclOf_24s2049272031x2094854488(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclareField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_t_245 = heff_field(v_x21_241, 2);
      V v_d_246 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24DeclareField = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_x1_247 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_t_245));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_c_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_c_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_c_2412);
        }
        v_t_2417 = heff_tag_at(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2412}), v_t_2415});
        break;
      }
      case TAG_IsType: {
        V v_t_2416 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2417 = v_t_2416;
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      V v_t_2430;
      switch (heff_tag_of(v_d_246)) {
      case TAG_Nothing: {
        v_t_2430 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2418 = heff_field(v_d_246, 0);
        V v_ru_24d_246_24Just = heff_take_reuse_n(v_d_246, 1ULL, 1);
        V v_x1_2419 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_x_2418));
        V v_t_2429;
        switch (heff_tag_of(v_x1_2419)) {
        case TAG_IsInferable: {
          V v_i_2420 = heff_field(v_x1_2419, 0);
          heff_take_n(v_x1_2419, 1ULL, 1);
          V v_t_2423;
          switch (heff_tag_of(v_i_2420)) {
          case TAG_At: {
            V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
            v_t_2423 = v_s_2422;
            break;
          }
          default: heff_nomatch(v_i_2420);
          }
          v_t_2429 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24d_246_24Just, TAG_CInf, 1, (V[]){v_i_2420}), v_t_2423});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2424 = heff_field(v_x1_2419, 0);
          heff_take_n(v_x1_2419, 1ULL, 1);
          heff_drop_cell(v_ru_24d_246_24Just, 1);
          v_t_2429 = v_c_2424;
          break;
        }
        case TAG_IsType: {
          V v_t_2425 = heff_field(v_x1_2419, 0);
          heff_take_n(v_x1_2419, 1ULL, 1);
          V v_t_2428;
          switch (heff_tag_of(v_t_2425)) {
          case TAG_At: {
            V v_s_2427 = heff_dup(heff_field(v_t_2425, 1));
            v_t_2428 = v_s_2427;
            break;
          }
          default: heff_nomatch(v_t_2425);
          }
          v_t_2429 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24d_246_24Just, TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
          break;
        }
        default: heff_nomatch(v_x1_2419);
        }
        v_t_2430 = heff_tag(TAG_Just, 1, (V[]){v_t_2429});
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x21_241_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_243, v_xsp_244, v_t_2417, v_t_2430}), v_sp_242});
    }
    case TAG_BadFieldDecl: {
      V v_e_2431 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24BadFieldDecl = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_x1_2432 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_e_2431));
      V v_t_2442;
      switch (heff_tag_of(v_x1_2432)) {
      case TAG_IsInferable: {
        V v_i_2433 = heff_field(v_x1_2432, 0);
        heff_take_n(v_x1_2432, 1ULL, 1);
        V v_t_2436;
        switch (heff_tag_of(v_i_2433)) {
        case TAG_At: {
          V v_s_2435 = heff_dup(heff_field(v_i_2433, 1));
          v_t_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_i_2433);
        }
        v_t_2442 = heff_tag_at(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_2433}), v_t_2436});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2437 = heff_field(v_x1_2432, 0);
        heff_take_n(v_x1_2432, 1ULL, 1);
        V v_t_2440;
        switch (heff_tag_of(v_c_2437)) {
        case TAG_At: {
          V v_s_2439 = heff_dup(heff_field(v_c_2437, 1));
          v_t_2440 = v_s_2439;
          break;
        }
        default: heff_nomatch(v_c_2437);
        }
        v_t_2442 = heff_tag_at(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2437}), v_t_2440});
        break;
      }
      case TAG_IsType: {
        V v_t_2441 = heff_field(v_x1_2432, 0);
        heff_take_n(v_x1_2432, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2442 = v_t_2441;
        break;
      }
      default: heff_nomatch(v_x1_2432);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x21_241_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2442}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2epresyntax_2efieldDeclOf_24s2049272031x2094854488_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2efieldDeclOf_24s2049272031x2094854488(a[0]);
}
Clo g_heff_2epresyntax_2evariantOf_24s1987057975x582429604_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2evariantOf_24s1987057975x582429604_entry, 1, 0};

V g_heff_2epresyntax_2evariantOf_24s1987057975x582429604(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_TagVariant: {
      V v_t_243 = heff_field(v_x21_241, 0);
      V v_tsp_244 = heff_field(v_x21_241, 1);
      V v_args_245 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24TagVariant = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      V v_t_246 = heff_tag_at(v_ru_24x21_241_24TagVariant, TAG_TagVariant, 3, (V[]){v_t_243, v_tsp_244, (g_prelude_2emap_24s842967967x223843022(v_args_245))});
      return heff_tag_at(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_246, v_sp_242});
    }
    case TAG_BadVariant: {
      V v_e_247 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24BadVariant = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_x1_248 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_e_247));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_c_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_c_2413);
        }
        v_t_2418 = heff_tag_at(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
        break;
      }
      case TAG_IsType: {
        V v_t_2417 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2418 = v_t_2417;
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x21_241_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2418}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2epresyntax_2evariantOf_24s1987057975x582429604_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2evariantOf_24s1987057975x582429604(a[0]);
}
Clo g_heff_2epresyntax_2efieldSetOf_24s1980909823x69898947_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2efieldSetOf_24s1980909823x69898947_entry, 1, 0};

V g_heff_2epresyntax_2efieldSetOf_24s1980909823x69898947(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_SetField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_e_245 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24SetField = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      V v_x1_246 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_e_245));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2416 = v_c_2411;
        break;
      }
      case TAG_IsType: {
        V v_t_2412 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_t_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        v_t_2416 = heff_tag_at(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_2412}), v_t_2415});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x21_241_24SetField, TAG_SetField, 3, (V[]){v_x_243, v_xsp_244, v_t_2416}), v_sp_242});
    }
    case TAG_BadFieldSet: {
      V v_e_2417 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24BadFieldSet = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_x1_2418 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_e_2417));
      V v_t_2428;
      switch (heff_tag_of(v_x1_2418)) {
      case TAG_IsInferable: {
        V v_i_2419 = heff_field(v_x1_2418, 0);
        heff_take_n(v_x1_2418, 1ULL, 1);
        V v_t_2422;
        switch (heff_tag_of(v_i_2419)) {
        case TAG_At: {
          V v_s_2421 = heff_dup(heff_field(v_i_2419, 1));
          v_t_2422 = v_s_2421;
          break;
        }
        default: heff_nomatch(v_i_2419);
        }
        v_t_2428 = heff_tag_at(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_2419}), v_t_2422});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2423 = heff_field(v_x1_2418, 0);
        heff_take_n(v_x1_2418, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2428 = v_c_2423;
        break;
      }
      case TAG_IsType: {
        V v_t_2424 = heff_field(v_x1_2418, 0);
        heff_take_n(v_x1_2418, 1ULL, 1);
        V v_t_2427;
        switch (heff_tag_of(v_t_2424)) {
        case TAG_At: {
          V v_s_2426 = heff_dup(heff_field(v_t_2424, 1));
          v_t_2427 = v_s_2426;
          break;
        }
        default: heff_nomatch(v_t_2424);
        }
        v_t_2428 = heff_tag_at(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_2424}), v_t_2427});
        break;
      }
      default: heff_nomatch(v_x1_2418);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x21_241_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2428}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2epresyntax_2efieldSetOf_24s1980909823x69898947_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2efieldSetOf_24s1980909823x69898947(a[0]);
}
Clo g_heff_2epresyntax_2ealtOf_24s1311504944x45681609_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2ealtOf_24s1311504944x45681609_entry, 1, 0};

V g_heff_2epresyntax_2ealtOf_24s1311504944x45681609(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkAlt: {
      V v_p_243 = heff_field(v_x21_241, 0);
      V v_b_244 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24MkAlt = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_x1_245 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_b_244));
      V v_t_2415;
      switch (heff_tag_of(v_x1_245)) {
      case TAG_IsInferable: {
        V v_i_246 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_249;
        switch (heff_tag_of(v_i_246)) {
        case TAG_At: {
          V v_s_248 = heff_dup(heff_field(v_i_246, 1));
          v_t_249 = v_s_248;
          break;
        }
        default: heff_nomatch(v_i_246);
        }
        v_t_2415 = heff_tag_at(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_246}), v_t_249});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2410 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2415 = v_c_2410;
        break;
      }
      case TAG_IsType: {
        V v_t_2411 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_At: {
          V v_s_2413 = heff_dup(heff_field(v_t_2411, 1));
          v_t_2414 = v_s_2413;
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        v_t_2415 = heff_tag_at(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_2411}), v_t_2414});
        break;
      }
      default: heff_nomatch(v_x1_245);
      }
      return heff_tag_at(v_ru_24x21_241_24MkAlt, TAG_At, 2, (V[]){heff_tag(TAG_MkAlt, 2, (V[]){v_p_243, v_t_2415}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2epresyntax_2ealtOf_24s1311504944x45681609_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2ealtOf_24s1311504944x45681609(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823_str0 = {{0x80000000u, K_STR, 0}, 19, 19, {117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823_str1 = {{0x80000000u, K_STR, 0}, 19, 19, {117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823_str2 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 96, 100, 111, 96, 32, 98, 108, 111, 99, 107, 32, 101, 110, 100, 115, 32, 119, 105, 116, 104, 32, 97, 110, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823_str3 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 96, 100, 111, 96, 32, 98, 108, 111, 99, 107, 32, 101, 110, 100, 115, 32, 119, 105, 116, 104, 32, 97, 110, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110}};
Clo g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823_entry, 1, 0};

V g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_it1_241 = heff_field(v_e_240, 0);
    V v_sp_242 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24At = heff_take_reuse_n(v_e_240, 3ULL, 2);
    switch (heff_tag_of(v_it1_241)) {
    case TAG_EVar: {
      V v_x_243 = heff_field(v_it1_241, 0);
      V v_ru_24it1_241_24EVar = heff_take_reuse_n(v_it1_241, 1ULL, 1);
      V v_t_244 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_IVar, 1, (V[]){v_x_243}), v_sp_242});
      return heff_tag_at(v_ru_24it1_241_24EVar, TAG_IsInferable, 1, (V[]){v_t_244});
    }
    case TAG_EImplicitVar: {
      V v_x_245 = heff_field(v_it1_241, 0);
      V v_ru_24it1_241_24EImplicitVar = heff_take_reuse_n(v_it1_241, 1ULL, 1);
      V v_t_246 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_IVar, 1, (V[]){v_x_245}), v_sp_242});
      return heff_tag_at(v_ru_24it1_241_24EImplicitVar, TAG_IsInferable, 1, (V[]){v_t_246});
    }
    case TAG_ETag: {
      V v_t_247 = heff_field(v_it1_241, 0);
      V v_ru_24it1_241_24ETag = heff_take_reuse_n(v_it1_241, 1ULL, 1);
      V v_t_248 = heff_tag(TAG_CTag, 3, (V[]){v_t_247, heff_dup(v_sp_242), NTAG(TAG_Nil)});
      return heff_tag_at(v_ru_24it1_241_24ETag, TAG_IsCheckable, 1, (V[]){heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){v_t_248, v_sp_242})});
    }
    case TAG_EInt: {
      V v_i_249 = heff_field(v_it1_241, 0);
      V v_ru_24it1_241_24EInt = heff_take_reuse_n(v_it1_241, 1ULL, 1);
      V v_t_2410 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_IInt, 1, (V[]){v_i_249}), v_sp_242});
      return heff_tag_at(v_ru_24it1_241_24EInt, TAG_IsInferable, 1, (V[]){v_t_2410});
    }
    case TAG_EFloat: {
      V v_x_2411 = heff_field(v_it1_241, 0);
      V v_ru_24it1_241_24EFloat = heff_take_reuse_n(v_it1_241, 1ULL, 1);
      V v_t_2412 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_IFloat, 1, (V[]){v_x_2411}), v_sp_242});
      return heff_tag_at(v_ru_24it1_241_24EFloat, TAG_IsInferable, 1, (V[]){v_t_2412});
    }
    case TAG_EString: {
      V v_x_2413 = heff_field(v_it1_241, 0);
      V v_ru_24it1_241_24EString = heff_take_reuse_n(v_it1_241, 1ULL, 1);
      V v_t_2414 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_IString, 1, (V[]){v_x_2413}), v_sp_242});
      return heff_tag_at(v_ru_24it1_241_24EString, TAG_IsInferable, 1, (V[]){v_t_2414});
    }
    case TAG_EWord: {
      V v_w_2415 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_cell(v_ru_24e_240_24At, 2);
      return (g_heff_2epresyntax_2ewordOf(v_w_2415, v_sp_242));
    }
    case TAG_EApp: {
      V v_h_2416 = heff_field(v_it1_241, 0);
      V v_args_2417 = heff_field(v_it1_241, 1);
      heff_take_n(v_it1_241, 3ULL, 2);
      heff_drop_cell(v_ru_24e_240_24At, 2);
      return (g_heff_2epresyntax_2eappOf_24s269192126x2121543052(v_h_2416, v_args_2417, v_sp_242));
    }
    case TAG_EProject: {
      V v_ru_24it1_241_24EProject = heff_take_reuse_n(v_it1_241, 0ULL, 1);
      V v_t_2419 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(3LL), ((V)&g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823_str0)}), v_sp_242});
      return heff_tag_at(v_ru_24it1_241_24EProject, TAG_IsInferable, 1, (V[]){v_t_2419});
    }
    case TAG_ENamed: {
      heff_take_n(v_it1_241, 0ULL, 2);
      V v_t_2422 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(3LL), ((V)&g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823_str1)}), v_sp_242});
      return heff_tag(TAG_IsInferable, 1, (V[]){v_t_2422});
    }
    case TAG_EPi: {
      V v_b_2423 = heff_field(v_it1_241, 0);
      V v_cod_2424 = heff_field(v_it1_241, 1);
      V v_ru_24it1_241_24EPi = heff_take_reuse_n(v_it1_241, 3ULL, 2);
      V v_t_2425 = (g_heff_2epresyntax_2epiBinderOf_24s113941090x157037166(v_b_2423));
      V v_x1_2426 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_cod_2424));
      V v_t_2436;
      switch (heff_tag_of(v_x1_2426)) {
      case TAG_IsInferable: {
        V v_i_2427 = heff_field(v_x1_2426, 0);
        heff_take_n(v_x1_2426, 1ULL, 1);
        V v_t_2430;
        switch (heff_tag_of(v_i_2427)) {
        case TAG_At: {
          V v_s_2429 = heff_dup(heff_field(v_i_2427, 1));
          v_t_2430 = v_s_2429;
          break;
        }
        default: heff_nomatch(v_i_2427);
        }
        v_t_2436 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_2427}), v_t_2430});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2431 = heff_field(v_x1_2426, 0);
        heff_take_n(v_x1_2426, 1ULL, 1);
        V v_t_2434;
        switch (heff_tag_of(v_c_2431)) {
        case TAG_At: {
          V v_s_2433 = heff_dup(heff_field(v_c_2431, 1));
          v_t_2434 = v_s_2433;
          break;
        }
        default: heff_nomatch(v_c_2431);
        }
        v_t_2436 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2431}), v_t_2434});
        break;
      }
      case TAG_IsType: {
        V v_t_2435 = heff_field(v_x1_2426, 0);
        heff_take_n(v_x1_2426, 1ULL, 1);
        heff_drop_cell(v_ru_24e_240_24At, 2);
        v_t_2436 = v_t_2435;
        break;
      }
      default: heff_nomatch(v_x1_2426);
      }
      V v_t_2437 = heff_tag_at(v_ru_24it1_241_24EPi, TAG_At, 2, (V[]){heff_tag(TAG_TPi, 2, (V[]){v_t_2425, v_t_2436}), v_sp_242});
      return heff_tag(TAG_IsType, 1, (V[]){v_t_2437});
    }
    case TAG_ELam: {
      V v_it11_2438 = heff_field(v_it1_241, 0);
      V v_body_2439 = heff_field(v_it1_241, 1);
      V v_ru_24it1_241_24ELam = heff_take_reuse_n(v_it1_241, 3ULL, 2);
      switch (heff_tag_of(v_it11_2438)) {
      case TAG_LamName: {
        V v_x_2440 = heff_field(v_it11_2438, 0);
        V v_xsp_2441 = heff_field(v_it11_2438, 1);
        heff_take_n(v_it11_2438, 3ULL, 2);
        V v_x1_2442 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_body_2439));
        V v_t_2452;
        switch (heff_tag_of(v_x1_2442)) {
        case TAG_IsInferable: {
          V v_i_2443 = heff_field(v_x1_2442, 0);
          heff_take_n(v_x1_2442, 1ULL, 1);
          V v_t_2446;
          switch (heff_tag_of(v_i_2443)) {
          case TAG_At: {
            V v_s_2445 = heff_dup(heff_field(v_i_2443, 1));
            v_t_2446 = v_s_2445;
            break;
          }
          default: heff_nomatch(v_i_2443);
          }
          v_t_2452 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_2443}), v_t_2446});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2447 = heff_field(v_x1_2442, 0);
          heff_take_n(v_x1_2442, 1ULL, 1);
          heff_drop_cell(v_ru_24e_240_24At, 2);
          v_t_2452 = v_c_2447;
          break;
        }
        case TAG_IsType: {
          V v_t_2448 = heff_field(v_x1_2442, 0);
          heff_take_n(v_x1_2442, 1ULL, 1);
          V v_t_2451;
          switch (heff_tag_of(v_t_2448)) {
          case TAG_At: {
            V v_s_2450 = heff_dup(heff_field(v_t_2448, 1));
            v_t_2451 = v_s_2450;
            break;
          }
          default: heff_nomatch(v_t_2448);
          }
          v_t_2452 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_2448}), v_t_2451});
          break;
        }
        default: heff_nomatch(v_x1_2442);
        }
        V v_t_2453 = heff_tag_at(v_ru_24it1_241_24ELam, TAG_At, 2, (V[]){heff_tag(TAG_CLam, 3, (V[]){v_x_2440, v_xsp_2441, v_t_2452}), v_sp_242});
        return heff_tag(TAG_IsCheckable, 1, (V[]){v_t_2453});
      }
      case TAG_LamImplicit: {
        V v_x_2454 = heff_field(v_it11_2438, 0);
        V v_xsp_2455 = heff_field(v_it11_2438, 1);
        heff_take_n(v_it11_2438, 3ULL, 2);
        V v_x1_2456 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_body_2439));
        V v_t_2466;
        switch (heff_tag_of(v_x1_2456)) {
        case TAG_IsInferable: {
          V v_i_2457 = heff_field(v_x1_2456, 0);
          heff_take_n(v_x1_2456, 1ULL, 1);
          V v_t_2460;
          switch (heff_tag_of(v_i_2457)) {
          case TAG_At: {
            V v_s_2459 = heff_dup(heff_field(v_i_2457, 1));
            v_t_2460 = v_s_2459;
            break;
          }
          default: heff_nomatch(v_i_2457);
          }
          v_t_2466 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_2457}), v_t_2460});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2461 = heff_field(v_x1_2456, 0);
          heff_take_n(v_x1_2456, 1ULL, 1);
          heff_drop_cell(v_ru_24e_240_24At, 2);
          v_t_2466 = v_c_2461;
          break;
        }
        case TAG_IsType: {
          V v_t_2462 = heff_field(v_x1_2456, 0);
          heff_take_n(v_x1_2456, 1ULL, 1);
          V v_t_2465;
          switch (heff_tag_of(v_t_2462)) {
          case TAG_At: {
            V v_s_2464 = heff_dup(heff_field(v_t_2462, 1));
            v_t_2465 = v_s_2464;
            break;
          }
          default: heff_nomatch(v_t_2462);
          }
          v_t_2466 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_2462}), v_t_2465});
          break;
        }
        default: heff_nomatch(v_x1_2456);
        }
        V v_t_2467 = heff_tag_at(v_ru_24it1_241_24ELam, TAG_At, 2, (V[]){heff_tag(TAG_CImplicitLam, 3, (V[]){v_x_2454, v_xsp_2455, v_t_2466}), v_sp_242});
        return heff_tag(TAG_IsCheckable, 1, (V[]){v_t_2467});
      }
      case TAG_LamAnn: {
        V v_x_2468 = heff_field(v_it11_2438, 0);
        V v_xsp_2469 = heff_field(v_it11_2438, 1);
        V v_t_2470 = heff_field(v_it11_2438, 2);
        heff_take_n(v_it11_2438, 7ULL, 3);
        heff_drop_cell(v_ru_24it1_241_24ELam, 2);
        V v_x1_2471 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_t_2470));
        V v_t_2481;
        switch (heff_tag_of(v_x1_2471)) {
        case TAG_IsInferable: {
          V v_i_2472 = heff_field(v_x1_2471, 0);
          heff_take_n(v_x1_2471, 1ULL, 1);
          V v_t_2475;
          switch (heff_tag_of(v_i_2472)) {
          case TAG_At: {
            V v_s_2474 = heff_dup(heff_field(v_i_2472, 1));
            v_t_2475 = v_s_2474;
            break;
          }
          default: heff_nomatch(v_i_2472);
          }
          v_t_2481 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_2472}), v_t_2475});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2476 = heff_field(v_x1_2471, 0);
          heff_take_n(v_x1_2471, 1ULL, 1);
          V v_t_2479;
          switch (heff_tag_of(v_c_2476)) {
          case TAG_At: {
            V v_s_2478 = heff_dup(heff_field(v_c_2476, 1));
            v_t_2479 = v_s_2478;
            break;
          }
          default: heff_nomatch(v_c_2476);
          }
          v_t_2481 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2476}), v_t_2479});
          break;
        }
        case TAG_IsType: {
          V v_t_2480 = heff_field(v_x1_2471, 0);
          heff_take_n(v_x1_2471, 1ULL, 1);
          heff_drop_cell(v_ru_24e_240_24At, 2);
          v_t_2481 = v_t_2480;
          break;
        }
        default: heff_nomatch(v_x1_2471);
        }
        V v_t_2482 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_body_2439));
        return (g_heff_2epresyntax_2eannLamOf(v_x_2468, v_xsp_2469, v_t_2481, v_t_2482, v_sp_242));
      }
      default: return heff_nomatch(v_it11_2438);
      }
    }
    case TAG_EAnn: {
      V v_a_2483 = heff_field(v_it1_241, 0);
      V v_t_2484 = heff_field(v_it1_241, 1);
      V v_ru_24it1_241_24EAnn = heff_take_reuse_n(v_it1_241, 3ULL, 2);
      V v_x1_2485 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_a_2483));
      V v_t_2495;
      switch (heff_tag_of(v_x1_2485)) {
      case TAG_IsInferable: {
        V v_i_2486 = heff_field(v_x1_2485, 0);
        heff_take_n(v_x1_2485, 1ULL, 1);
        V v_t_2489;
        switch (heff_tag_of(v_i_2486)) {
        case TAG_At: {
          V v_s_2488 = heff_dup(heff_field(v_i_2486, 1));
          v_t_2489 = v_s_2488;
          break;
        }
        default: heff_nomatch(v_i_2486);
        }
        v_t_2495 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_2486}), v_t_2489});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2490 = heff_field(v_x1_2485, 0);
        heff_take_n(v_x1_2485, 1ULL, 1);
        heff_drop_cell(v_ru_24e_240_24At, 2);
        v_t_2495 = v_c_2490;
        break;
      }
      case TAG_IsType: {
        V v_t_2491 = heff_field(v_x1_2485, 0);
        heff_take_n(v_x1_2485, 1ULL, 1);
        V v_t_2494;
        switch (heff_tag_of(v_t_2491)) {
        case TAG_At: {
          V v_s_2493 = heff_dup(heff_field(v_t_2491, 1));
          v_t_2494 = v_s_2493;
          break;
        }
        default: heff_nomatch(v_t_2491);
        }
        v_t_2495 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_2491}), v_t_2494});
        break;
      }
      default: heff_nomatch(v_x1_2485);
      }
      V v_x1_2496 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_t_2484));
      V v_t_24106;
      switch (heff_tag_of(v_x1_2496)) {
      case TAG_IsInferable: {
        V v_i_2497 = heff_field(v_x1_2496, 0);
        heff_take_n(v_x1_2496, 1ULL, 1);
        V v_t_24100;
        switch (heff_tag_of(v_i_2497)) {
        case TAG_At: {
          V v_s_2499 = heff_dup(heff_field(v_i_2497, 1));
          v_t_24100 = v_s_2499;
          break;
        }
        default: heff_nomatch(v_i_2497);
        }
        v_t_24106 = heff_tag_at(v_ru_24it1_241_24EAnn, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_2497}), v_t_24100});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24101 = heff_field(v_x1_2496, 0);
        heff_take_n(v_x1_2496, 1ULL, 1);
        V v_t_24104;
        switch (heff_tag_of(v_c_24101)) {
        case TAG_At: {
          V v_s_24103 = heff_dup(heff_field(v_c_24101, 1));
          v_t_24104 = v_s_24103;
          break;
        }
        default: heff_nomatch(v_c_24101);
        }
        v_t_24106 = heff_tag_at(v_ru_24it1_241_24EAnn, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_24101}), v_t_24104});
        break;
      }
      case TAG_IsType: {
        V v_t_24105 = heff_field(v_x1_2496, 0);
        heff_take_n(v_x1_2496, 1ULL, 1);
        heff_drop_cell(v_ru_24it1_241_24EAnn, 2);
        v_t_24106 = v_t_24105;
        break;
      }
      default: heff_nomatch(v_x1_2496);
      }
      V v_t_24107 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IAnn, 2, (V[]){v_t_2495, v_t_24106}), v_sp_242});
      return heff_tag(TAG_IsInferable, 1, (V[]){v_t_24107});
    }
    case TAG_ESpec: {
      V v_a_24108 = heff_field(v_it1_241, 0);
      V v_x_24109 = heff_field(v_it1_241, 1);
      V v_fsp_24110 = heff_field(v_it1_241, 2);
      V v_v_24111 = heff_field(v_it1_241, 3);
      V v_ru_24it1_241_24ESpec = heff_take_reuse_n(v_it1_241, 15ULL, 4);
      V v_t_24112 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_a_24108));
      V v_t_24113 = ({ V a_0 = v_t_24112; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24112); r_; });
      V v_x1_24114 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_v_24111));
      V v_t_24124;
      switch (heff_tag_of(v_x1_24114)) {
      case TAG_IsInferable: {
        V v_i_24115 = heff_field(v_x1_24114, 0);
        heff_take_n(v_x1_24114, 1ULL, 1);
        V v_t_24118;
        switch (heff_tag_of(v_i_24115)) {
        case TAG_At: {
          V v_s_24117 = heff_dup(heff_field(v_i_24115, 1));
          v_t_24118 = v_s_24117;
          break;
        }
        default: heff_nomatch(v_i_24115);
        }
        v_t_24124 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24115}), v_t_24118});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24119 = heff_field(v_x1_24114, 0);
        heff_take_n(v_x1_24114, 1ULL, 1);
        heff_drop_cell(v_ru_24e_240_24At, 2);
        v_t_24124 = v_c_24119;
        break;
      }
      case TAG_IsType: {
        V v_t_24120 = heff_field(v_x1_24114, 0);
        heff_take_n(v_x1_24114, 1ULL, 1);
        V v_t_24123;
        switch (heff_tag_of(v_t_24120)) {
        case TAG_At: {
          V v_s_24122 = heff_dup(heff_field(v_t_24120, 1));
          v_t_24123 = v_s_24122;
          break;
        }
        default: heff_nomatch(v_t_24120);
        }
        v_t_24124 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24120}), v_t_24123});
        break;
      }
      default: heff_nomatch(v_x1_24114);
      }
      V v_t_24125 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_241_24ESpec, TAG_ISpec, 4, (V[]){v_t_24113, v_x_24109, v_fsp_24110, v_t_24124}), v_sp_242});
      return heff_tag(TAG_IsInferable, 1, (V[]){v_t_24125});
    }
    case TAG_ESig: {
      V v_fs_24126 = heff_field(v_it1_241, 0);
      V v_ru_24it1_241_24ESig = heff_take_reuse_n(v_it1_241, 1ULL, 1);
      V v_t_24127 = heff_tag_at(v_ru_24it1_241_24ESig, TAG_TSig, 1, (V[]){(g_prelude_2emap_24s354657900x1587558784(v_fs_24126))});
      return heff_tag(TAG_IsType, 1, (V[]){heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){v_t_24127, v_sp_242})});
    }
    case TAG_ESum: {
      V v_vs_24128 = heff_field(v_it1_241, 0);
      V v_ru_24it1_241_24ESum = heff_take_reuse_n(v_it1_241, 1ULL, 1);
      V v_t_24129 = heff_tag_at(v_ru_24it1_241_24ESum, TAG_TSum, 1, (V[]){(g_prelude_2emap_24s1491261851x220013917(v_vs_24128))});
      return heff_tag(TAG_IsType, 1, (V[]){heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){v_t_24129, v_sp_242})});
    }
    case TAG_EStruct: {
      V v_fs_24130 = heff_field(v_it1_241, 0);
      V v_ru_24it1_241_24EStruct = heff_take_reuse_n(v_it1_241, 1ULL, 1);
      V v_t_24131 = heff_tag_at(v_ru_24it1_241_24EStruct, TAG_CStruct, 1, (V[]){(g_prelude_2emap_24s1170054603x901729204(v_fs_24130))});
      return heff_tag(TAG_IsCheckable, 1, (V[]){heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){v_t_24131, v_sp_242})});
    }
    case TAG_EMatch: {
      V v_s_24132 = heff_field(v_it1_241, 0);
      V v_alts_24133 = heff_field(v_it1_241, 1);
      V v_ru_24it1_241_24EMatch = heff_take_reuse_n(v_it1_241, 3ULL, 2);
      V v_t_24134 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_s_24132));
      V v_t_24135 = ({ V a_0 = v_t_24134; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24134); r_; });
      V v_t_24136 = heff_tag_at(v_ru_24e_240_24At, TAG_CMatch, 2, (V[]){v_t_24135, (g_prelude_2emap_24s1472739944x318103388(v_alts_24133))});
      return heff_tag(TAG_IsCheckable, 1, (V[]){heff_tag_at(v_ru_24it1_241_24EMatch, TAG_At, 2, (V[]){v_t_24136, v_sp_242})});
    }
    case TAG_ELetIn: {
      V v_rhs_24137 = heff_field(v_it1_241, 0);
      V v_a_24138 = heff_field(v_it1_241, 1);
      V v_ru_24it1_241_24ELetIn = heff_take_reuse_n(v_it1_241, 3ULL, 2);
      V v_t_24139 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_rhs_24137));
      V v_t_24140 = ({ V a_0 = v_t_24139; V r_ = (g_heff_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24139); r_; });
      V v_t_24156;
      switch (heff_tag_of(v_a_24138)) {
      case TAG_At: {
        V v_x21_24141 = heff_field(v_a_24138, 0);
        V v_sp_24142 = heff_field(v_a_24138, 1);
        heff_take_n(v_a_24138, 3ULL, 2);
        switch (heff_tag_of(v_x21_24141)) {
        case TAG_MkAlt: {
          V v_p_24143 = heff_field(v_x21_24141, 0);
          V v_b_24144 = heff_field(v_x21_24141, 1);
          heff_take_n(v_x21_24141, 3ULL, 2);
          V v_x1_24145 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_b_24144));
          V v_t_24155;
          switch (heff_tag_of(v_x1_24145)) {
          case TAG_IsInferable: {
            V v_i_24146 = heff_field(v_x1_24145, 0);
            heff_take_n(v_x1_24145, 1ULL, 1);
            V v_t_24149;
            switch (heff_tag_of(v_i_24146)) {
            case TAG_At: {
              V v_s_24148 = heff_dup(heff_field(v_i_24146, 1));
              v_t_24149 = v_s_24148;
              break;
            }
            default: heff_nomatch(v_i_24146);
            }
            v_t_24155 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24146}), v_t_24149});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24150 = heff_field(v_x1_24145, 0);
            heff_take_n(v_x1_24145, 1ULL, 1);
            heff_drop_cell(v_ru_24e_240_24At, 2);
            v_t_24155 = v_c_24150;
            break;
          }
          case TAG_IsType: {
            V v_t_24151 = heff_field(v_x1_24145, 0);
            heff_take_n(v_x1_24145, 1ULL, 1);
            V v_t_24154;
            switch (heff_tag_of(v_t_24151)) {
            case TAG_At: {
              V v_s_24153 = heff_dup(heff_field(v_t_24151, 1));
              v_t_24154 = v_s_24153;
              break;
            }
            default: heff_nomatch(v_t_24151);
            }
            v_t_24155 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24151}), v_t_24154});
            break;
          }
          default: heff_nomatch(v_x1_24145);
          }
          v_t_24156 = heff_tag_at(v_ru_24it1_241_24ELetIn, TAG_At, 2, (V[]){heff_tag(TAG_MkAlt, 2, (V[]){v_p_24143, v_t_24155}), v_sp_24142});
          break;
        }
        default: heff_nomatch(v_x21_24141);
        }
        break;
      }
      default: heff_nomatch(v_a_24138);
      }
      V v_t_24157 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_CLetIn, 2, (V[]){v_t_24140, v_t_24156}), v_sp_242});
      return heff_tag(TAG_IsCheckable, 1, (V[]){v_t_24157});
    }
    case TAG_EDo: {
      V v_stmts_24158 = heff_field(v_it1_241, 0);
      V v_ru_24it1_241_24EDo = heff_take_reuse_n(v_it1_241, 1ULL, 1);
      V v_t_24159 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_stmts_24158));
      switch (heff_tag_of(v_t_24159)) {
      case TAG_Nil: {
        V v_t_24160 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(12LL), ((V)&g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823_str2)}), v_sp_242});
        return heff_tag_at(v_ru_24it1_241_24EDo, TAG_IsInferable, 1, (V[]){v_t_24160});
      }
      case TAG_Cons: {
        V v_last_24161 = heff_field(v_t_24159, 0);
        V v_init_24162 = heff_field(v_t_24159, 1);
        heff_take_n(v_t_24159, 3ULL, 2);
        V v_init_24163 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_init_24162));
        V v_t_24172;
        switch (heff_tag_of(v_last_24161)) {
        case TAG_At: {
          V v_x31_24164 = heff_field(v_last_24161, 0);
          heff_take_n(v_last_24161, 1ULL, 2);
          switch (heff_tag_of(v_x31_24164)) {
          case TAG_StmtBind: {
            heff_take_n(v_x31_24164, 0ULL, 3);
            heff_drop_cell(v_ru_24it1_241_24EDo, 1);
            heff_drop(v_init_24163);
            v_t_24172 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_StmtLet: {
            heff_take_n(v_x31_24164, 0ULL, 2);
            heff_drop_cell(v_ru_24it1_241_24EDo, 1);
            heff_drop(v_init_24163);
            v_t_24172 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_StmtExpr: {
            V v_e_24171 = heff_field(v_x31_24164, 0);
            heff_take_n(v_x31_24164, 1ULL, 1);
            v_t_24172 = heff_tag_at(v_ru_24it1_241_24EDo, TAG_Just, 1, (V[]){({ V a_0 = heff_dup(v_sp_242); V a_1 = v_init_24163; V a_2 = v_e_24171; V r_ = (g_heff_2epresyntax_2edoFrom(a_0, a_1, a_2)); heff_drop(v_init_24163); r_; })});
            break;
          }
          default: heff_nomatch(v_x31_24164);
          }
          break;
        }
        default: heff_nomatch(v_last_24161);
        }
        switch (heff_tag_of(v_t_24172)) {
        case TAG_Nothing: {
          V v_t_24173 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(12LL), ((V)&g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823_str3)}), v_sp_242});
          return heff_tag(TAG_IsInferable, 1, (V[]){v_t_24173});
        }
        case TAG_Just: {
          V v_e_27_24174 = heff_field(v_t_24172, 0);
          heff_take_n(v_t_24172, 1ULL, 1);
          heff_drop(v_sp_242);
          heff_drop_cell(v_ru_24e_240_24At, 2);
          V t_0 = v_e_27_24174;
          v_e_240 = t_0;
          goto top;
        }
        default: return heff_nomatch(v_t_24172);
        }
      }
      default: return heff_nomatch(v_t_24159);
      }
    }
    case TAG_ELocal: {
      V v_body_24175 = heff_field(v_it1_241, 0);
      V v_ds_24176 = heff_field(v_it1_241, 1);
      V v_ru_24it1_241_24ELocal = heff_take_reuse_n(v_it1_241, 3ULL, 2);
      V v_x1_24177 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_body_24175));
      V v_t_24187;
      switch (heff_tag_of(v_x1_24177)) {
      case TAG_IsInferable: {
        V v_i_24178 = heff_field(v_x1_24177, 0);
        heff_take_n(v_x1_24177, 1ULL, 1);
        V v_t_24181;
        switch (heff_tag_of(v_i_24178)) {
        case TAG_At: {
          V v_s_24180 = heff_dup(heff_field(v_i_24178, 1));
          v_t_24181 = v_s_24180;
          break;
        }
        default: heff_nomatch(v_i_24178);
        }
        v_t_24187 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_24178}), v_t_24181});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24182 = heff_field(v_x1_24177, 0);
        heff_take_n(v_x1_24177, 1ULL, 1);
        heff_drop_cell(v_ru_24e_240_24At, 2);
        v_t_24187 = v_c_24182;
        break;
      }
      case TAG_IsType: {
        V v_t_24183 = heff_field(v_x1_24177, 0);
        heff_take_n(v_x1_24177, 1ULL, 1);
        V v_t_24186;
        switch (heff_tag_of(v_t_24183)) {
        case TAG_At: {
          V v_s_24185 = heff_dup(heff_field(v_t_24183, 1));
          v_t_24186 = v_s_24185;
          break;
        }
        default: heff_nomatch(v_t_24183);
        }
        v_t_24187 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_24183}), v_t_24186});
        break;
      }
      default: heff_nomatch(v_x1_24177);
      }
      V v_t_24188 = heff_tag_at(v_ru_24it1_241_24ELocal, TAG_CLocal, 2, (V[]){v_t_24187, (g_prelude_2emap(heff_get(heff_dup(g_heff_2epresyntax_2eclassifier_get()), LBL_decl), v_ds_24176))});
      return heff_tag(TAG_IsCheckable, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24188, v_sp_242})});
    }
    case TAG_EInvalid: {
      V v_why_24189 = heff_field(v_it1_241, 0);
      V v_ru_24it1_241_24EInvalid = heff_take_reuse_n(v_it1_241, 1ULL, 1);
      V v_t_24190 = heff_tag_at(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(3LL), v_why_24189}), v_sp_242});
      return heff_tag_at(v_ru_24it1_241_24EInvalid, TAG_IsInferable, 1, (V[]){v_t_24190});
    }
    default: return heff_nomatch(v_it1_241);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(a[0]);
}
Clo g_heff_2epresyntax_2eequationOf_24s1475199660x271778313_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2eequationOf_24s1475199660x271778313_entry, 1, 0};

V g_heff_2epresyntax_2eequationOf_24s1475199660x271778313(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkEquation: {
      V v_f_243 = heff_field(v_x21_241, 0);
      V v_fsp_244 = heff_field(v_x21_241, 1);
      V v_ps_245 = heff_field(v_x21_241, 2);
      V v_rhs_246 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24MkEquation = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_x1_247 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_rhs_246));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2417 = v_c_2412;
        break;
      }
      case TAG_IsType: {
        V v_t_2413 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_t_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_t_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        v_t_2417 = heff_tag_at(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_2413}), v_t_2416});
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x21_241_24MkEquation, TAG_MkEquation, 4, (V[]){v_f_243, v_fsp_244, v_ps_245, v_t_2417}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2epresyntax_2eequationOf_24s1475199660x271778313_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2eequationOf_24s1475199660x271778313(a[0]);
}
Clo g_heff_2epresyntax_2eparamOf_24s1115423126x2093765648_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2eparamOf_24s1115423126x2093765648_entry, 1, 0};

V g_heff_2epresyntax_2eparamOf_24s1115423126x2093765648(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_ExplicitParam: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_t_245 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24ExplicitParam = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      V v_x1_246 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_t_245));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_c_2411)) {
        case TAG_At: {
          V v_s_2413 = heff_dup(heff_field(v_c_2411, 1));
          v_t_2414 = v_s_2413;
          break;
        }
        default: heff_nomatch(v_c_2411);
        }
        v_t_2416 = heff_tag_at(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2411}), v_t_2414});
        break;
      }
      case TAG_IsType: {
        V v_t_2415 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2416 = v_t_2415;
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x21_241_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_x_243, v_xsp_244, v_t_2416}), v_sp_242});
    }
    case TAG_ImplicitParam: {
      V v_x_2417 = heff_field(v_x21_241, 0);
      V v_xsp_2418 = heff_field(v_x21_241, 1);
      V v_t_2419 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24ImplicitParam = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      V v_x1_2420 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_t_2419));
      V v_t_2430;
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_IsInferable: {
        V v_i_2421 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2424;
        switch (heff_tag_of(v_i_2421)) {
        case TAG_At: {
          V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_i_2421);
        }
        v_t_2430 = heff_tag_at(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_2421}), v_t_2424});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2425 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2428;
        switch (heff_tag_of(v_c_2425)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_c_2425, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_c_2425);
        }
        v_t_2430 = heff_tag_at(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2425}), v_t_2428});
        break;
      }
      case TAG_IsType: {
        V v_t_2429 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2430 = v_t_2429;
        break;
      }
      default: heff_nomatch(v_x1_2420);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x21_241_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_x_2417, v_xsp_2418, v_t_2430}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2epresyntax_2eparamOf_24s1115423126x2093765648_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2eparamOf_24s1115423126x2093765648(a[0]);
}
Clo g_heff_2epresyntax_2eclassifyDeclF_24s1000182462x736866817_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2eclassifyDeclF_24s1000182462x736866817_entry, 1, 0};

V g_heff_2epresyntax_2eclassifyDeclF_24s1000182462x736866817(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_it1_241 = heff_field(v_d_240, 0);
    V v_sp_242 = heff_field(v_d_240, 1);
    V v_ru_24d_240_24At = heff_take_reuse_n(v_d_240, 3ULL, 2);
    switch (heff_tag_of(v_it1_241)) {
    case TAG_DeclEquations: {
      V v_f_243 = heff_field(v_it1_241, 0);
      V v_fsp_244 = heff_field(v_it1_241, 1);
      V v_ty_245 = heff_field(v_it1_241, 2);
      V v_eqs_246 = heff_field(v_it1_241, 3);
      V v_ru_24it1_241_24DeclEquations = heff_take_reuse_n(v_it1_241, 15ULL, 4);
      V v_x1_247 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_ty_245));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at(v_ru_24d_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_c_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_c_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_c_2412);
        }
        v_t_2417 = heff_tag_at(v_ru_24d_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2412}), v_t_2415});
        break;
      }
      case TAG_IsType: {
        V v_t_2416 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24d_240_24At, 2);
        v_t_2417 = v_t_2416;
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      V v_t_2418 = heff_tag_at(v_ru_24it1_241_24DeclEquations, TAG_DeclEquations, 4, (V[]){v_f_243, v_fsp_244, v_t_2417, (g_prelude_2emap_24s1340987657x1082998826(v_eqs_246))});
      return heff_tag(TAG_At, 2, (V[]){v_t_2418, v_sp_242});
    }
    case TAG_DeclDefine: {
      V v_x_2419 = heff_field(v_it1_241, 0);
      V v_xsp_2420 = heff_field(v_it1_241, 1);
      V v_ps_2421 = heff_field(v_it1_241, 2);
      V v_u_2422 = heff_field(v_it1_241, 3);
      V v_body_2423 = heff_field(v_it1_241, 4);
      V v_ru_24it1_241_24DeclDefine = heff_take_reuse_n(v_it1_241, 31ULL, 5);
      V v_t_2424 = (g_prelude_2emap_24s504509305x1309437118(v_ps_2421));
      V v_x1_2425 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_u_2422));
      V v_t_2435;
      switch (heff_tag_of(v_x1_2425)) {
      case TAG_IsInferable: {
        V v_i_2426 = heff_field(v_x1_2425, 0);
        heff_take_n(v_x1_2425, 1ULL, 1);
        V v_t_2429;
        switch (heff_tag_of(v_i_2426)) {
        case TAG_At: {
          V v_s_2428 = heff_dup(heff_field(v_i_2426, 1));
          v_t_2429 = v_s_2428;
          break;
        }
        default: heff_nomatch(v_i_2426);
        }
        v_t_2435 = heff_tag_at(v_ru_24d_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_2426}), v_t_2429});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2430 = heff_field(v_x1_2425, 0);
        heff_take_n(v_x1_2425, 1ULL, 1);
        V v_t_2433;
        switch (heff_tag_of(v_c_2430)) {
        case TAG_At: {
          V v_s_2432 = heff_dup(heff_field(v_c_2430, 1));
          v_t_2433 = v_s_2432;
          break;
        }
        default: heff_nomatch(v_c_2430);
        }
        v_t_2435 = heff_tag_at(v_ru_24d_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2430}), v_t_2433});
        break;
      }
      case TAG_IsType: {
        V v_t_2434 = heff_field(v_x1_2425, 0);
        heff_take_n(v_x1_2425, 1ULL, 1);
        heff_drop_cell(v_ru_24d_240_24At, 2);
        v_t_2435 = v_t_2434;
        break;
      }
      default: heff_nomatch(v_x1_2425);
      }
      V v_x1_2436 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_body_2423));
      V v_t_2446;
      switch (heff_tag_of(v_x1_2436)) {
      case TAG_IsInferable: {
        V v_i_2437 = heff_field(v_x1_2436, 0);
        V v_ru_24x1_2436_24IsInferable = heff_take_reuse_n(v_x1_2436, 1ULL, 1);
        V v_t_2440;
        switch (heff_tag_of(v_i_2437)) {
        case TAG_At: {
          V v_s_2439 = heff_dup(heff_field(v_i_2437, 1));
          v_t_2440 = v_s_2439;
          break;
        }
        default: heff_nomatch(v_i_2437);
        }
        v_t_2446 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_2436_24IsInferable, TAG_CInf, 1, (V[]){v_i_2437}), v_t_2440});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2441 = heff_field(v_x1_2436, 0);
        heff_take_n(v_x1_2436, 1ULL, 1);
        v_t_2446 = v_c_2441;
        break;
      }
      case TAG_IsType: {
        V v_t_2442 = heff_field(v_x1_2436, 0);
        V v_ru_24x1_2436_24IsType = heff_take_reuse_n(v_x1_2436, 1ULL, 1);
        V v_t_2445;
        switch (heff_tag_of(v_t_2442)) {
        case TAG_At: {
          V v_s_2444 = heff_dup(heff_field(v_t_2442, 1));
          v_t_2445 = v_s_2444;
          break;
        }
        default: heff_nomatch(v_t_2442);
        }
        v_t_2446 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_2436_24IsType, TAG_CType, 1, (V[]){v_t_2442}), v_t_2445});
        break;
      }
      default: heff_nomatch(v_x1_2436);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_241_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_2419, v_xsp_2420, v_t_2424, v_t_2435, v_t_2446}), v_sp_242});
    }
    case TAG_DeclTheory: {
      V v_x_2447 = heff_field(v_it1_241, 0);
      V v_xsp_2448 = heff_field(v_it1_241, 1);
      V v_ps_2449 = heff_field(v_it1_241, 2);
      V v_body_2450 = heff_field(v_it1_241, 3);
      V v_ru_24it1_241_24DeclTheory = heff_take_reuse_n(v_it1_241, 15ULL, 4);
      V v_t_2451 = (g_prelude_2emap_24s504509305x1309437118(v_ps_2449));
      V v_x1_2452 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_body_2450));
      V v_t_2462;
      switch (heff_tag_of(v_x1_2452)) {
      case TAG_IsInferable: {
        V v_i_2453 = heff_field(v_x1_2452, 0);
        heff_take_n(v_x1_2452, 1ULL, 1);
        V v_t_2456;
        switch (heff_tag_of(v_i_2453)) {
        case TAG_At: {
          V v_s_2455 = heff_dup(heff_field(v_i_2453, 1));
          v_t_2456 = v_s_2455;
          break;
        }
        default: heff_nomatch(v_i_2453);
        }
        v_t_2462 = heff_tag_at(v_ru_24d_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_i_2453}), v_t_2456});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2457 = heff_field(v_x1_2452, 0);
        heff_take_n(v_x1_2452, 1ULL, 1);
        heff_drop_cell(v_ru_24d_240_24At, 2);
        v_t_2462 = v_c_2457;
        break;
      }
      case TAG_IsType: {
        V v_t_2458 = heff_field(v_x1_2452, 0);
        heff_take_n(v_x1_2452, 1ULL, 1);
        V v_t_2461;
        switch (heff_tag_of(v_t_2458)) {
        case TAG_At: {
          V v_s_2460 = heff_dup(heff_field(v_t_2458, 1));
          v_t_2461 = v_s_2460;
          break;
        }
        default: heff_nomatch(v_t_2458);
        }
        v_t_2462 = heff_tag_at(v_ru_24d_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_t_2458}), v_t_2461});
        break;
      }
      default: heff_nomatch(v_x1_2452);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_241_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2447, v_xsp_2448, v_t_2451, v_t_2462}), v_sp_242});
    }
    case TAG_DeclPrimitive: {
      V v_x_2463 = heff_field(v_it1_241, 0);
      V v_xsp_2464 = heff_field(v_it1_241, 1);
      V v_t_2465 = heff_field(v_it1_241, 2);
      V v_ru_24it1_241_24DeclPrimitive = heff_take_reuse_n(v_it1_241, 7ULL, 3);
      V v_x1_2466 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_t_2465));
      V v_t_2476;
      switch (heff_tag_of(v_x1_2466)) {
      case TAG_IsInferable: {
        V v_i_2467 = heff_field(v_x1_2466, 0);
        heff_take_n(v_x1_2466, 1ULL, 1);
        V v_t_2470;
        switch (heff_tag_of(v_i_2467)) {
        case TAG_At: {
          V v_s_2469 = heff_dup(heff_field(v_i_2467, 1));
          v_t_2470 = v_s_2469;
          break;
        }
        default: heff_nomatch(v_i_2467);
        }
        v_t_2476 = heff_tag_at(v_ru_24d_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_i_2467}), v_t_2470});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2471 = heff_field(v_x1_2466, 0);
        heff_take_n(v_x1_2466, 1ULL, 1);
        V v_t_2474;
        switch (heff_tag_of(v_c_2471)) {
        case TAG_At: {
          V v_s_2473 = heff_dup(heff_field(v_c_2471, 1));
          v_t_2474 = v_s_2473;
          break;
        }
        default: heff_nomatch(v_c_2471);
        }
        v_t_2476 = heff_tag_at(v_ru_24d_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_c_2471}), v_t_2474});
        break;
      }
      case TAG_IsType: {
        V v_t_2475 = heff_field(v_x1_2466, 0);
        heff_take_n(v_x1_2466, 1ULL, 1);
        heff_drop_cell(v_ru_24d_240_24At, 2);
        v_t_2476 = v_t_2475;
        break;
      }
      default: heff_nomatch(v_x1_2466);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_241_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2463, v_xsp_2464, v_t_2476}), v_sp_242});
    }
    case TAG_DeclTest: {
      V v_x_2477 = heff_field(v_it1_241, 0);
      V v_xsp_2478 = heff_field(v_it1_241, 1);
      heff_take_n(v_it1_241, 3ULL, 2);
      return heff_tag_at(v_ru_24d_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_DeclTest, 2, (V[]){v_x_2477, v_xsp_2478}), v_sp_242});
    }
    case TAG_DeclWatch: {
      V v_e_2479 = heff_field(v_it1_241, 0);
      V v_ru_24it1_241_24DeclWatch = heff_take_reuse_n(v_it1_241, 1ULL, 1);
      V v_t_2480 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_e_2479));
      V v_t_2481 = heff_tag_at(v_ru_24it1_241_24DeclWatch, TAG_DeclWatch, 1, (V[]){(g_heff_2epresyntax_2ewatchOf(v_t_2480))});
      return heff_tag_at(v_ru_24d_240_24At, TAG_At, 2, (V[]){v_t_2481, v_sp_242});
    }
    default: return heff_nomatch(v_it1_241);
    }
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2epresyntax_2eclassifyDeclF_24s1000182462x736866817_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2eclassifyDeclF_24s1000182462x736866817(a[0]);
}

static V g_heff_2epresyntax_2eclassify_val;
static int g_heff_2epresyntax_2eclassify_st;
static V g_heff_2epresyntax_2eclassify_init(void) {
  return ((V)&g_heff_2epresyntax_2eclassifyDeclF_24s1000182462x736866817_clo);
}
V g_heff_2epresyntax_2eclassify_get(void) {
  if (g_heff_2epresyntax_2eclassify_st == 2) return g_heff_2epresyntax_2eclassify_val;
  if (g_heff_2epresyntax_2eclassify_st == 1) heff_fail("defined by itself");
  g_heff_2epresyntax_2eclassify_st = 1;
  g_heff_2epresyntax_2eclassify_val = heff_tr(g_heff_2epresyntax_2eclassify_init());
  g_heff_2epresyntax_2eclassify_st = 2;
  return g_heff_2epresyntax_2eclassify_val;
}
Clo g_heff_2epresyntax_2epiN_24s1811034599x1720743734_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2epiN_24s1811034599x1720743734_entry, 1, 0};

V g_heff_2epresyntax_2epiN_24s1811034599x1720743734(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24PiNamed = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_246;
    switch (heff_tag_of(v_t_243)) {
    case TAG_At: {
      V v_n_244 = heff_field(v_t_243, 0);
      V v_sp_245 = heff_field(v_t_243, 1);
      heff_take_n(v_t_243, 3ULL, 2);
      v_t_246 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_sp_245, v_n_244));
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_tag_at(v_ru_24x2_240_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_241, v_sp_242, v_t_246});
  }
  case TAG_PiImplicit: {
    V v_x_247 = heff_field(v_x2_240, 0);
    V v_sp_248 = heff_field(v_x2_240, 1);
    V v_sp2_249 = heff_field(v_x2_240, 2);
    V v_t_2410 = heff_field(v_x2_240, 3);
    V v_d_2411 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24PiImplicit = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_2414;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_At: {
      V v_n_2412 = heff_field(v_t_2410, 0);
      V v_sp_2413 = heff_field(v_t_2410, 1);
      heff_take_n(v_t_2410, 3ULL, 2);
      v_t_2414 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_sp_2413, v_n_2412));
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2420;
    switch (heff_tag_of(v_d_2411)) {
    case TAG_Nothing: {
      v_t_2420 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2415 = heff_field(v_d_2411, 0);
      V v_ru_24d_2411_24Just = heff_take_reuse_n(v_d_2411, 1ULL, 1);
      V v_t_2419;
      switch (heff_tag_of(v_x_2415)) {
      case TAG_At: {
        V v_n_2416 = heff_field(v_x_2415, 0);
        V v_sp_2417 = heff_field(v_x_2415, 1);
        V v_ru_24x_2415_24At = heff_take_reuse_n(v_x_2415, 3ULL, 2);
        V v_t_2418 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_2416));
        v_t_2419 = heff_tag_at(v_ru_24x_2415_24At, TAG_At, 2, (V[]){v_t_2418, v_sp_2417});
        break;
      }
      default: heff_nomatch(v_x_2415);
      }
      v_t_2420 = heff_tag_at(v_ru_24d_2411_24Just, TAG_Just, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_d_2411);
    }
    return heff_tag_at(v_ru_24x2_240_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_247, v_sp_248, v_sp2_249, v_t_2414, v_t_2420});
  }
  case TAG_PiInstance: {
    V v_x_2421 = heff_field(v_x2_240, 0);
    V v_sp_2422 = heff_field(v_x2_240, 1);
    V v_sp2_2423 = heff_field(v_x2_240, 2);
    V v_t_2424 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24PiInstance = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2427;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_At: {
      V v_n_2425 = heff_field(v_t_2424, 0);
      V v_sp_2426 = heff_field(v_t_2424, 1);
      heff_take_n(v_t_2424, 3ULL, 2);
      v_t_2427 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_sp_2426, v_n_2425));
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    return heff_tag_at(v_ru_24x2_240_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2421, v_sp_2422, v_sp2_2423, v_t_2427});
  }
  case TAG_PiAnon: {
    V v_t_2428 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24PiAnon = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2431;
    switch (heff_tag_of(v_t_2428)) {
    case TAG_At: {
      V v_n_2429 = heff_field(v_t_2428, 0);
      V v_sp_2430 = heff_field(v_t_2428, 1);
      heff_take_n(v_t_2428, 3ULL, 2);
      v_t_2431 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_sp_2430, v_n_2429));
      break;
    }
    default: heff_nomatch(v_t_2428);
    }
    return heff_tag_at(v_ru_24x2_240_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2431});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2epresyntax_2epiN_24s1811034599x1720743734_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2epiN_24s1811034599x1720743734(a[0]);
}
Clo g_heff_2epresyntax_2efieldDeclN_24s28815368x1200642142_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2efieldDeclN_24s28815368x1200642142_entry, 1, 0};

V g_heff_2epresyntax_2efieldDeclN_24s28815368x1200642142(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_DeclareField: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_d_244 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24DeclareField = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_247;
    switch (heff_tag_of(v_t_243)) {
    case TAG_At: {
      V v_n_245 = heff_field(v_t_243, 0);
      V v_sp_246 = heff_field(v_t_243, 1);
      heff_take_n(v_t_243, 3ULL, 2);
      v_t_247 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_sp_246, v_n_245));
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_t_2413;
    switch (heff_tag_of(v_d_244)) {
    case TAG_Nothing: {
      v_t_2413 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_d_244, 0);
      V v_ru_24d_244_24Just = heff_take_reuse_n(v_d_244, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_x_248)) {
      case TAG_At: {
        V v_n_249 = heff_field(v_x_248, 0);
        V v_sp_2410 = heff_field(v_x_248, 1);
        V v_ru_24x_248_24At = heff_take_reuse_n(v_x_248, 3ULL, 2);
        V v_t_2411 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_249));
        v_t_2412 = heff_tag_at(v_ru_24x_248_24At, TAG_At, 2, (V[]){v_t_2411, v_sp_2410});
        break;
      }
      default: heff_nomatch(v_x_248);
      }
      v_t_2413 = heff_tag_at(v_ru_24d_244_24Just, TAG_Just, 1, (V[]){v_t_2412});
      break;
    }
    default: heff_nomatch(v_d_244);
    }
    return heff_tag_at(v_ru_24x2_240_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_241, v_sp_242, v_t_247, v_t_2413});
  }
  case TAG_BadFieldDecl: {
    V v_e_2414 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24BadFieldDecl = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2417;
    switch (heff_tag_of(v_e_2414)) {
    case TAG_At: {
      V v_n_2415 = heff_field(v_e_2414, 0);
      V v_sp_2416 = heff_field(v_e_2414, 1);
      heff_take_n(v_e_2414, 3ULL, 2);
      v_t_2417 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_sp_2416, v_n_2415));
      break;
    }
    default: heff_nomatch(v_e_2414);
    }
    return heff_tag_at(v_ru_24x2_240_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2417});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2epresyntax_2efieldDeclN_24s28815368x1200642142_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2efieldDeclN_24s28815368x1200642142(a[0]);
}
Clo g_heff_2epresyntax_2etypNode_24s1488628894x2014562827_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2etypNode_24s1488628894x2014562827_entry, 1, 0};

V g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_TPi: {
    V v_b_241 = heff_field(v_n_240, 0);
    V v_cod_242 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24TPi = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2epiN_24s1811034599x1720743734(v_b_241));
    V v_t_246;
    switch (heff_tag_of(v_cod_242)) {
    case TAG_At: {
      V v_n_244 = heff_field(v_cod_242, 0);
      V v_sp_245 = heff_field(v_cod_242, 1);
      heff_take_n(v_cod_242, 3ULL, 2);
      v_t_246 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_sp_245, v_n_244));
      break;
    }
    default: heff_nomatch(v_cod_242);
    }
    return heff_tag_at(v_ru_24n_240_24TPi, TAG_TPi, 2, (V[]){v_t_243, v_t_246});
  }
  case TAG_TSig: {
    V v_fs_247 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TSig = heff_take_reuse_n(v_n_240, 1ULL, 1);
    return heff_tag_at(v_ru_24n_240_24TSig, TAG_TSig, 1, (V[]){(g_prelude_2emap_24s760761549x776536213(v_fs_247))});
  }
  case TAG_TSum: {
    V v_vs_248 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TSum = heff_take_reuse_n(v_n_240, 1ULL, 1);
    return heff_tag_at(v_ru_24n_240_24TSum, TAG_TSum, 1, (V[]){(g_prelude_2emap_24s271878692x1909813941(v_vs_248))});
  }
  case TAG_TType: {
    return v_n_240;
  }
  case TAG_TInt: {
    return v_n_240;
  }
  case TAG_TFloat: {
    return v_n_240;
  }
  case TAG_TString: {
    return v_n_240;
  }
  case TAG_TArray: {
    V v_a_249 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TArray = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2412;
    switch (heff_tag_of(v_a_249)) {
    case TAG_At: {
      V v_n_2410 = heff_field(v_a_249, 0);
      V v_sp_2411 = heff_field(v_a_249, 1);
      heff_take_n(v_a_249, 3ULL, 2);
      v_t_2412 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_sp_2411, v_n_2410));
      break;
    }
    default: heff_nomatch(v_a_249);
    }
    return heff_tag_at(v_ru_24n_240_24TArray, TAG_TArray, 1, (V[]){v_t_2412});
  }
  case TAG_TFixed: {
    return v_n_240;
  }
  case TAG_TInf: {
    V v_i_2414 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TInf = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2418;
    switch (heff_tag_of(v_i_2414)) {
    case TAG_At: {
      V v_n_2415 = heff_field(v_i_2414, 0);
      V v_sp_2416 = heff_field(v_i_2414, 1);
      V v_ru_24i_2414_24At = heff_take_reuse_n(v_i_2414, 3ULL, 2);
      V v_t_2417 = (g_heff_2epresyntax_2einfNode_24s226003340x1863664708(v_n_2415));
      v_t_2418 = heff_tag_at(v_ru_24i_2414_24At, TAG_At, 2, (V[]){v_t_2417, v_sp_2416});
      break;
    }
    default: heff_nomatch(v_i_2414);
    }
    return heff_tag_at(v_ru_24n_240_24TInf, TAG_TInf, 1, (V[]){v_t_2418});
  }
  case TAG_TChk: {
    V v_c_2419 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TChk = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2423;
    switch (heff_tag_of(v_c_2419)) {
    case TAG_At: {
      V v_n_2420 = heff_field(v_c_2419, 0);
      V v_sp_2421 = heff_field(v_c_2419, 1);
      V v_ru_24c_2419_24At = heff_take_reuse_n(v_c_2419, 3ULL, 2);
      V v_t_2422 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_2420));
      v_t_2423 = heff_tag_at(v_ru_24c_2419_24At, TAG_At, 2, (V[]){v_t_2422, v_sp_2421});
      break;
    }
    default: heff_nomatch(v_c_2419);
    }
    return heff_tag_at(v_ru_24n_240_24TChk, TAG_TChk, 1, (V[]){v_t_2423});
  }
  case TAG_TNominal: {
    return v_n_240;
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2epresyntax_2etypNode_24s1488628894x2014562827_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[49]; } g_heff_2epresyntax_2etypNom_24s2062588653x1022079868_str0 = {{0x80000000u, K_STR, 0}, 49, 49, {99, 97, 110, 110, 111, 116, 32, 117, 115, 101, 32, 100, 101, 115, 99, 114, 105, 112, 116, 105, 118, 101, 32, 115, 121, 110, 116, 97, 120, 32, 105, 110, 32, 110, 111, 109, 105, 110, 97, 108, 32, 112, 111, 115, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[49]; } g_heff_2epresyntax_2etypNom_24s2062588653x1022079868_str1 = {{0x80000000u, K_STR, 0}, 49, 49, {99, 97, 110, 110, 111, 116, 32, 117, 115, 101, 32, 100, 101, 115, 99, 114, 105, 112, 116, 105, 118, 101, 32, 115, 121, 110, 116, 97, 120, 32, 105, 110, 32, 110, 111, 109, 105, 110, 97, 108, 32, 112, 111, 115, 105, 116, 105, 111, 110}};
Clo g_heff_2epresyntax_2etypNom_24s2062588653x1022079868_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2etypNom_24s2062588653x1022079868_entry, 2, 0};

V g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_TPi: {
    V v_t_244 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(v_n_241));
    return heff_tag(TAG_At, 2, (V[]){v_t_244, v_sp_240});
  }
  case TAG_TSig: {
    V v_ru_24n_241_24TSig = heff_take_reuse_n(v_n_241, 0ULL, 1);
    V v_t_246 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(4LL), ((V)&g_heff_2epresyntax_2etypNom_24s2062588653x1022079868_str0)}), heff_dup(v_sp_240)});
    return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24n_241_24TSig, TAG_TInf, 1, (V[]){v_t_246}), v_sp_240});
  }
  case TAG_TSum: {
    V v_ru_24n_241_24TSum = heff_take_reuse_n(v_n_241, 0ULL, 1);
    V v_t_248 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){MK_INT(4LL), ((V)&g_heff_2epresyntax_2etypNom_24s2062588653x1022079868_str1)}), heff_dup(v_sp_240)});
    return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24n_241_24TSum, TAG_TInf, 1, (V[]){v_t_248}), v_sp_240});
  }
  case TAG_TType: {
    V v_t_249 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(v_n_241));
    return heff_tag(TAG_At, 2, (V[]){v_t_249, v_sp_240});
  }
  case TAG_TInt: {
    V v_t_2410 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(v_n_241));
    return heff_tag(TAG_At, 2, (V[]){v_t_2410, v_sp_240});
  }
  case TAG_TFloat: {
    V v_t_2411 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(v_n_241));
    return heff_tag(TAG_At, 2, (V[]){v_t_2411, v_sp_240});
  }
  case TAG_TString: {
    V v_t_2412 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(v_n_241));
    return heff_tag(TAG_At, 2, (V[]){v_t_2412, v_sp_240});
  }
  case TAG_TArray: {
    V v_t_2414 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(v_n_241));
    return heff_tag(TAG_At, 2, (V[]){v_t_2414, v_sp_240});
  }
  case TAG_TFixed: {
    V v_t_2416 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(v_n_241));
    return heff_tag(TAG_At, 2, (V[]){v_t_2416, v_sp_240});
  }
  case TAG_TInf: {
    V v_t_2418 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(v_n_241));
    return heff_tag(TAG_At, 2, (V[]){v_t_2418, v_sp_240});
  }
  case TAG_TChk: {
    V v_t_2420 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(v_n_241));
    return heff_tag(TAG_At, 2, (V[]){v_t_2420, v_sp_240});
  }
  case TAG_TNominal: {
    V v_t_2422 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(v_n_241));
    return heff_tag(TAG_At, 2, (V[]){v_t_2422, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2epresyntax_2etypNom_24s2062588653x1022079868_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(a[0], a[1]);
}
Clo g_heff_2epresyntax_2einfNode_24s226003340x1863664708_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2einfNode_24s226003340x1863664708_entry, 1, 0};

V g_heff_2epresyntax_2einfNode_24s226003340x1863664708(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_IVar: {
    return v_n_240;
  }
  case TAG_IInt: {
    return v_n_240;
  }
  case TAG_IFloat: {
    return v_n_240;
  }
  case TAG_IString: {
    return v_n_240;
  }
  case TAG_IApp: {
    V v_h_245 = heff_field(v_n_240, 0);
    V v_args_246 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24IApp = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_h_245)) {
    case TAG_At: {
      V v_n_247 = heff_field(v_h_245, 0);
      V v_sp_248 = heff_field(v_h_245, 1);
      heff_take_n(v_h_245, 3ULL, 2);
      V v_t_249 = (g_heff_2epresyntax_2einfNode_24s226003340x1863664708(v_n_247));
      v_t_2410 = heff_tag_at(v_ru_24n_240_24IApp, TAG_At, 2, (V[]){v_t_249, v_sp_248});
      break;
    }
    default: heff_nomatch(v_h_245);
    }
    return heff_tag(TAG_IApp, 2, (V[]){v_t_2410, (g_prelude_2emap_24s1449394102x85632237(v_args_246))});
  }
  case TAG_IAnn: {
    V v_c_2411 = heff_field(v_n_240, 0);
    V v_t_2412 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24IAnn = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_c_2411)) {
    case TAG_At: {
      V v_n_2413 = heff_field(v_c_2411, 0);
      V v_sp_2414 = heff_field(v_c_2411, 1);
      heff_take_n(v_c_2411, 3ULL, 2);
      V v_t_2415 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_2413));
      v_t_2416 = heff_tag_at(v_ru_24n_240_24IAnn, TAG_At, 2, (V[]){v_t_2415, v_sp_2414});
      break;
    }
    default: heff_nomatch(v_c_2411);
    }
    V v_t_2419;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_At: {
      V v_n_2417 = heff_field(v_t_2412, 0);
      V v_sp_2418 = heff_field(v_t_2412, 1);
      heff_take_n(v_t_2412, 3ULL, 2);
      v_t_2419 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_sp_2418, v_n_2417));
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    return heff_tag(TAG_IAnn, 2, (V[]){v_t_2416, v_t_2419});
  }
  case TAG_ISpec: {
    V v_a_2420 = heff_field(v_n_240, 0);
    V v_x_2421 = heff_field(v_n_240, 1);
    V v_sp_2422 = heff_field(v_n_240, 2);
    V v_v_2423 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24ISpec = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2427;
    switch (heff_tag_of(v_a_2420)) {
    case TAG_At: {
      V v_n_2424 = heff_field(v_a_2420, 0);
      V v_sp_2425 = heff_field(v_a_2420, 1);
      V v_ru_24a_2420_24At = heff_take_reuse_n(v_a_2420, 3ULL, 2);
      V v_t_2426 = (g_heff_2epresyntax_2einfNode_24s226003340x1863664708(v_n_2424));
      v_t_2427 = heff_tag_at(v_ru_24a_2420_24At, TAG_At, 2, (V[]){v_t_2426, v_sp_2425});
      break;
    }
    default: heff_nomatch(v_a_2420);
    }
    V v_t_2431;
    switch (heff_tag_of(v_v_2423)) {
    case TAG_At: {
      V v_n_2428 = heff_field(v_v_2423, 0);
      V v_sp_2429 = heff_field(v_v_2423, 1);
      V v_ru_24v_2423_24At = heff_take_reuse_n(v_v_2423, 3ULL, 2);
      V v_t_2430 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_2428));
      v_t_2431 = heff_tag_at(v_ru_24v_2423_24At, TAG_At, 2, (V[]){v_t_2430, v_sp_2429});
      break;
    }
    default: heff_nomatch(v_v_2423);
    }
    return heff_tag_at(v_ru_24n_240_24ISpec, TAG_ISpec, 4, (V[]){v_t_2427, v_x_2421, v_sp_2422, v_t_2431});
  }
  case TAG_IAnnLam: {
    V v_x_2432 = heff_field(v_n_240, 0);
    V v_sp_2433 = heff_field(v_n_240, 1);
    V v_t_2434 = heff_field(v_n_240, 2);
    V v_b_2435 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24IAnnLam = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2438;
    switch (heff_tag_of(v_t_2434)) {
    case TAG_At: {
      V v_n_2436 = heff_field(v_t_2434, 0);
      V v_sp_2437 = heff_field(v_t_2434, 1);
      heff_take_n(v_t_2434, 3ULL, 2);
      v_t_2438 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_sp_2437, v_n_2436));
      break;
    }
    default: heff_nomatch(v_t_2434);
    }
    V v_t_2442;
    switch (heff_tag_of(v_b_2435)) {
    case TAG_At: {
      V v_n_2439 = heff_field(v_b_2435, 0);
      V v_sp_2440 = heff_field(v_b_2435, 1);
      V v_ru_24b_2435_24At = heff_take_reuse_n(v_b_2435, 3ULL, 2);
      V v_t_2441 = (g_heff_2epresyntax_2einfNode_24s226003340x1863664708(v_n_2439));
      v_t_2442 = heff_tag_at(v_ru_24b_2435_24At, TAG_At, 2, (V[]){v_t_2441, v_sp_2440});
      break;
    }
    default: heff_nomatch(v_b_2435);
    }
    return heff_tag_at(v_ru_24n_240_24IAnnLam, TAG_IAnnLam, 4, (V[]){v_x_2432, v_sp_2433, v_t_2438, v_t_2442});
  }
  case TAG_IInvalid: {
    return v_n_240;
  }
  case TAG_INominal: {
    return v_n_240;
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2epresyntax_2einfNode_24s226003340x1863664708_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2einfNode_24s226003340x1863664708(a[0]);
}
Clo g_heff_2epresyntax_2edeclN_24s819476248x1348827013_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2edeclN_24s819476248x1348827013_entry, 1, 0};

V g_heff_2epresyntax_2edeclN_24s819476248x1348827013(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_DeclEquations: {
    V v_f_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ty_243 = heff_field(v_x2_240, 2);
    V v_eqs_244 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24DeclEquations = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_247;
    switch (heff_tag_of(v_ty_243)) {
    case TAG_At: {
      V v_n_245 = heff_field(v_ty_243, 0);
      V v_sp_246 = heff_field(v_ty_243, 1);
      heff_take_n(v_ty_243, 3ULL, 2);
      v_t_247 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_sp_246, v_n_245));
      break;
    }
    default: heff_nomatch(v_ty_243);
    }
    return heff_tag_at(v_ru_24x2_240_24DeclEquations, TAG_DeclEquations, 4, (V[]){v_f_241, v_sp_242, v_t_247, (g_prelude_2emap_24s1276521852x477277004(v_eqs_244))});
  }
  case TAG_DeclDefine: {
    V v_x_248 = heff_field(v_x2_240, 0);
    V v_sp_249 = heff_field(v_x2_240, 1);
    V v_ps_2410 = heff_field(v_x2_240, 2);
    V v_u_2411 = heff_field(v_x2_240, 3);
    V v_body_2412 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24DeclDefine = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_2413 = (g_prelude_2emap_24s1548800724x1090490128(v_ps_2410));
    V v_t_2416;
    switch (heff_tag_of(v_u_2411)) {
    case TAG_At: {
      V v_n_2414 = heff_field(v_u_2411, 0);
      V v_sp_2415 = heff_field(v_u_2411, 1);
      heff_take_n(v_u_2411, 3ULL, 2);
      v_t_2416 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_sp_2415, v_n_2414));
      break;
    }
    default: heff_nomatch(v_u_2411);
    }
    V v_t_2420;
    switch (heff_tag_of(v_body_2412)) {
    case TAG_At: {
      V v_n_2417 = heff_field(v_body_2412, 0);
      V v_sp_2418 = heff_field(v_body_2412, 1);
      V v_ru_24body_2412_24At = heff_take_reuse_n(v_body_2412, 3ULL, 2);
      V v_t_2419 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_2417));
      v_t_2420 = heff_tag_at(v_ru_24body_2412_24At, TAG_At, 2, (V[]){v_t_2419, v_sp_2418});
      break;
    }
    default: heff_nomatch(v_body_2412);
    }
    return heff_tag_at(v_ru_24x2_240_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_248, v_sp_249, v_t_2413, v_t_2416, v_t_2420});
  }
  case TAG_DeclTheory: {
    V v_x_2421 = heff_field(v_x2_240, 0);
    V v_sp_2422 = heff_field(v_x2_240, 1);
    V v_ps_2423 = heff_field(v_x2_240, 2);
    V v_body_2424 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24DeclTheory = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2425 = (g_prelude_2emap_24s1548800724x1090490128(v_ps_2423));
    V v_t_2429;
    switch (heff_tag_of(v_body_2424)) {
    case TAG_At: {
      V v_n_2426 = heff_field(v_body_2424, 0);
      V v_sp_2427 = heff_field(v_body_2424, 1);
      V v_ru_24body_2424_24At = heff_take_reuse_n(v_body_2424, 3ULL, 2);
      V v_t_2428 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_2426));
      v_t_2429 = heff_tag_at(v_ru_24body_2424_24At, TAG_At, 2, (V[]){v_t_2428, v_sp_2427});
      break;
    }
    default: heff_nomatch(v_body_2424);
    }
    return heff_tag_at(v_ru_24x2_240_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2421, v_sp_2422, v_t_2425, v_t_2429});
  }
  case TAG_DeclPrimitive: {
    V v_x_2430 = heff_field(v_x2_240, 0);
    V v_sp_2431 = heff_field(v_x2_240, 1);
    V v_t_2432 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24DeclPrimitive = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_2435;
    switch (heff_tag_of(v_t_2432)) {
    case TAG_At: {
      V v_n_2433 = heff_field(v_t_2432, 0);
      V v_sp_2434 = heff_field(v_t_2432, 1);
      heff_take_n(v_t_2432, 3ULL, 2);
      v_t_2435 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_sp_2434, v_n_2433));
      break;
    }
    default: heff_nomatch(v_t_2432);
    }
    return heff_tag_at(v_ru_24x2_240_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2430, v_sp_2431, v_t_2435});
  }
  case TAG_DeclTest: {
    V v_x_2436 = heff_field(v_x2_240, 0);
    V v_sp_2437 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24DeclTest = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24DeclTest, TAG_DeclTest, 2, (V[]){v_x_2436, v_sp_2437});
  }
  case TAG_DeclWatch: {
    V v_c_2438 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24DeclWatch = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2442;
    switch (heff_tag_of(v_c_2438)) {
    case TAG_At: {
      V v_n_2439 = heff_field(v_c_2438, 0);
      V v_sp_2440 = heff_field(v_c_2438, 1);
      V v_ru_24c_2438_24At = heff_take_reuse_n(v_c_2438, 3ULL, 2);
      V v_t_2441 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_2439));
      v_t_2442 = heff_tag_at(v_ru_24c_2438_24At, TAG_At, 2, (V[]){v_t_2441, v_sp_2440});
      break;
    }
    default: heff_nomatch(v_c_2438);
    }
    return heff_tag_at(v_ru_24x2_240_24DeclWatch, TAG_DeclWatch, 1, (V[]){v_t_2442});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2epresyntax_2edeclN_24s819476248x1348827013_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2edeclN_24s819476248x1348827013(a[0]);
}
Clo g_heff_2epresyntax_2echkNode_24s769858677x299167023_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2echkNode_24s769858677x299167023_entry, 1, 0};

V g_heff_2epresyntax_2echkNode_24s769858677x299167023(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_CInf: {
    V v_i_241 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CInf = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_245;
    switch (heff_tag_of(v_i_241)) {
    case TAG_At: {
      V v_n_242 = heff_field(v_i_241, 0);
      V v_sp_243 = heff_field(v_i_241, 1);
      V v_ru_24i_241_24At = heff_take_reuse_n(v_i_241, 3ULL, 2);
      V v_t_244 = (g_heff_2epresyntax_2einfNode_24s226003340x1863664708(v_n_242));
      v_t_245 = heff_tag_at(v_ru_24i_241_24At, TAG_At, 2, (V[]){v_t_244, v_sp_243});
      break;
    }
    default: heff_nomatch(v_i_241);
    }
    return heff_tag_at(v_ru_24n_240_24CInf, TAG_CInf, 1, (V[]){v_t_245});
  }
  case TAG_CType: {
    V v_t_246 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CType = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_At: {
      V v_n_247 = heff_field(v_t_246, 0);
      V v_sp_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 3ULL, 2);
      v_t_249 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_sp_248, v_n_247));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag_at(v_ru_24n_240_24CType, TAG_CType, 1, (V[]){v_t_249});
  }
  case TAG_CLam: {
    V v_x_2410 = heff_field(v_n_240, 0);
    V v_sp_2411 = heff_field(v_n_240, 1);
    V v_b_2412 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CLam = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2416;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_At: {
      V v_n_2413 = heff_field(v_b_2412, 0);
      V v_sp_2414 = heff_field(v_b_2412, 1);
      V v_ru_24b_2412_24At = heff_take_reuse_n(v_b_2412, 3ULL, 2);
      V v_t_2415 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_2413));
      v_t_2416 = heff_tag_at(v_ru_24b_2412_24At, TAG_At, 2, (V[]){v_t_2415, v_sp_2414});
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag_at(v_ru_24n_240_24CLam, TAG_CLam, 3, (V[]){v_x_2410, v_sp_2411, v_t_2416});
  }
  case TAG_CImplicitLam: {
    V v_x_2417 = heff_field(v_n_240, 0);
    V v_sp_2418 = heff_field(v_n_240, 1);
    V v_b_2419 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CImplicitLam = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2423;
    switch (heff_tag_of(v_b_2419)) {
    case TAG_At: {
      V v_n_2420 = heff_field(v_b_2419, 0);
      V v_sp_2421 = heff_field(v_b_2419, 1);
      V v_ru_24b_2419_24At = heff_take_reuse_n(v_b_2419, 3ULL, 2);
      V v_t_2422 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_2420));
      v_t_2423 = heff_tag_at(v_ru_24b_2419_24At, TAG_At, 2, (V[]){v_t_2422, v_sp_2421});
      break;
    }
    default: heff_nomatch(v_b_2419);
    }
    return heff_tag_at(v_ru_24n_240_24CImplicitLam, TAG_CImplicitLam, 3, (V[]){v_x_2417, v_sp_2418, v_t_2423});
  }
  case TAG_CAnnLam: {
    V v_x_2424 = heff_field(v_n_240, 0);
    V v_sp_2425 = heff_field(v_n_240, 1);
    V v_t_2426 = heff_field(v_n_240, 2);
    V v_b_2427 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24CAnnLam = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2430;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_At: {
      V v_n_2428 = heff_field(v_t_2426, 0);
      V v_sp_2429 = heff_field(v_t_2426, 1);
      heff_take_n(v_t_2426, 3ULL, 2);
      v_t_2430 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_sp_2429, v_n_2428));
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    V v_t_2434;
    switch (heff_tag_of(v_b_2427)) {
    case TAG_At: {
      V v_n_2431 = heff_field(v_b_2427, 0);
      V v_sp_2432 = heff_field(v_b_2427, 1);
      V v_ru_24b_2427_24At = heff_take_reuse_n(v_b_2427, 3ULL, 2);
      V v_t_2433 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_2431));
      v_t_2434 = heff_tag_at(v_ru_24b_2427_24At, TAG_At, 2, (V[]){v_t_2433, v_sp_2432});
      break;
    }
    default: heff_nomatch(v_b_2427);
    }
    return heff_tag_at(v_ru_24n_240_24CAnnLam, TAG_CAnnLam, 4, (V[]){v_x_2424, v_sp_2425, v_t_2430, v_t_2434});
  }
  case TAG_CTag: {
    V v_x_2435 = heff_field(v_n_240, 0);
    V v_sp_2436 = heff_field(v_n_240, 1);
    V v_args_2437 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CTag = heff_take_reuse_n(v_n_240, 7ULL, 3);
    return heff_tag_at(v_ru_24n_240_24CTag, TAG_CTag, 3, (V[]){v_x_2435, v_sp_2436, (g_prelude_2emap_24s1097491904x416138181(v_args_2437))});
  }
  case TAG_CStruct: {
    V v_fs_2438 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CStruct = heff_take_reuse_n(v_n_240, 1ULL, 1);
    return heff_tag_at(v_ru_24n_240_24CStruct, TAG_CStruct, 1, (V[]){(g_prelude_2emap_24s7771255x22951525(v_fs_2438))});
  }
  case TAG_CMatch: {
    V v_sc_2439 = heff_field(v_n_240, 0);
    V v_alts_2440 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CMatch = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2444;
    switch (heff_tag_of(v_sc_2439)) {
    case TAG_At: {
      V v_n_2441 = heff_field(v_sc_2439, 0);
      V v_sp_2442 = heff_field(v_sc_2439, 1);
      heff_take_n(v_sc_2439, 3ULL, 2);
      V v_t_2443 = (g_heff_2epresyntax_2einfNode_24s226003340x1863664708(v_n_2441));
      v_t_2444 = heff_tag_at(v_ru_24n_240_24CMatch, TAG_At, 2, (V[]){v_t_2443, v_sp_2442});
      break;
    }
    default: heff_nomatch(v_sc_2439);
    }
    return heff_tag(TAG_CMatch, 2, (V[]){v_t_2444, (g_prelude_2emap_24s1439972680x346961496(v_alts_2440))});
  }
  case TAG_CLetIn: {
    V v_rhs_2445 = heff_field(v_n_240, 0);
    V v_alt_2446 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CLetIn = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2450;
    switch (heff_tag_of(v_rhs_2445)) {
    case TAG_At: {
      V v_n_2447 = heff_field(v_rhs_2445, 0);
      V v_sp_2448 = heff_field(v_rhs_2445, 1);
      heff_take_n(v_rhs_2445, 3ULL, 2);
      V v_t_2449 = (g_heff_2epresyntax_2einfNode_24s226003340x1863664708(v_n_2447));
      v_t_2450 = heff_tag_at(v_ru_24n_240_24CLetIn, TAG_At, 2, (V[]){v_t_2449, v_sp_2448});
      break;
    }
    default: heff_nomatch(v_rhs_2445);
    }
    V v_t_2460;
    switch (heff_tag_of(v_alt_2446)) {
    case TAG_At: {
      V v_x_2451 = heff_field(v_alt_2446, 0);
      V v_sp_2452 = heff_field(v_alt_2446, 1);
      V v_ru_24alt_2446_24At = heff_take_reuse_n(v_alt_2446, 3ULL, 2);
      V v_t_2459;
      switch (heff_tag_of(v_x_2451)) {
      case TAG_MkAlt: {
        V v_p_2453 = heff_field(v_x_2451, 0);
        V v_b_2454 = heff_field(v_x_2451, 1);
        V v_ru_24x_2451_24MkAlt = heff_take_reuse_n(v_x_2451, 3ULL, 2);
        V v_t_2458;
        switch (heff_tag_of(v_b_2454)) {
        case TAG_At: {
          V v_n_2455 = heff_field(v_b_2454, 0);
          V v_sp_2456 = heff_field(v_b_2454, 1);
          heff_take_n(v_b_2454, 3ULL, 2);
          V v_t_2457 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_2455));
          v_t_2458 = heff_tag_at(v_ru_24alt_2446_24At, TAG_At, 2, (V[]){v_t_2457, v_sp_2456});
          break;
        }
        default: heff_nomatch(v_b_2454);
        }
        v_t_2459 = heff_tag_at(v_ru_24x_2451_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_2453, v_t_2458});
        break;
      }
      default: heff_nomatch(v_x_2451);
      }
      v_t_2460 = heff_tag(TAG_At, 2, (V[]){v_t_2459, v_sp_2452});
      break;
    }
    default: heff_nomatch(v_alt_2446);
    }
    return heff_tag(TAG_CLetIn, 2, (V[]){v_t_2450, v_t_2460});
  }
  case TAG_CLocal: {
    V v_body_2461 = heff_field(v_n_240, 0);
    V v_ds_2462 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CLocal = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2466;
    switch (heff_tag_of(v_body_2461)) {
    case TAG_At: {
      V v_n_2463 = heff_field(v_body_2461, 0);
      V v_sp_2464 = heff_field(v_body_2461, 1);
      heff_take_n(v_body_2461, 3ULL, 2);
      V v_t_2465 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_2463));
      v_t_2466 = heff_tag_at(v_ru_24n_240_24CLocal, TAG_At, 2, (V[]){v_t_2465, v_sp_2464});
      break;
    }
    default: heff_nomatch(v_body_2461);
    }
    return heff_tag(TAG_CLocal, 2, (V[]){v_t_2466, (g_prelude_2emap_24s914971304x1928750522(v_ds_2462))});
  }
  case TAG_CAbandon: {
    return v_n_240;
  }
  case TAG_CNominal: {
    return v_n_240;
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2epresyntax_2echkNode_24s769858677x299167023_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2echkNode_24s769858677x299167023(a[0]);
}
Clo g_heff_2epresyntax_2einfDe_24s1088488601x1677399249_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2einfDe_24s1088488601x1677399249_entry, 2, 0};

V g_heff_2epresyntax_2einfDe_24s1088488601x1677399249(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_IVar: {
    V v_t_243 = (g_heff_2epresyntax_2einfNode_24s226003340x1863664708(v_n_241));
    V v_t_244 = heff_tag(TAG_INominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_243, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_244, v_sp_240});
  }
  case TAG_IInt: {
    V v_t_246 = (g_heff_2epresyntax_2einfNode_24s226003340x1863664708(v_n_241));
    V v_t_247 = heff_tag(TAG_INominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_246, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_247, v_sp_240});
  }
  case TAG_IFloat: {
    V v_t_249 = (g_heff_2epresyntax_2einfNode_24s226003340x1863664708(v_n_241));
    V v_t_2410 = heff_tag(TAG_INominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_249, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2410, v_sp_240});
  }
  case TAG_IString: {
    V v_t_2412 = (g_heff_2epresyntax_2einfNode_24s226003340x1863664708(v_n_241));
    V v_t_2413 = heff_tag(TAG_INominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_IApp: {
    V v_t_2416 = (g_heff_2epresyntax_2einfNode_24s226003340x1863664708(v_n_241));
    V v_t_2417 = heff_tag(TAG_INominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2416, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2417, v_sp_240});
  }
  case TAG_IAnn: {
    V v_c_2418 = heff_field(v_n_241, 0);
    V v_t_2419 = heff_field(v_n_241, 1);
    V v_ru_24n_241_24IAnn = heff_take_reuse_n(v_n_241, 3ULL, 2);
    V v_t_2422;
    switch (heff_tag_of(v_c_2418)) {
    case TAG_At: {
      V v_n_2420 = heff_field(v_c_2418, 0);
      V v_sp_2421 = heff_field(v_c_2418, 1);
      heff_take_n(v_c_2418, 3ULL, 2);
      v_t_2422 = (g_heff_2epresyntax_2echkDe_24s1632343938x112901564(v_sp_2421, v_n_2420));
      break;
    }
    default: heff_nomatch(v_c_2418);
    }
    V v_t_2425;
    switch (heff_tag_of(v_t_2419)) {
    case TAG_At: {
      V v_n_2423 = heff_field(v_t_2419, 0);
      V v_sp_2424 = heff_field(v_t_2419, 1);
      heff_take_n(v_t_2419, 3ULL, 2);
      v_t_2425 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_sp_2424, v_n_2423));
      break;
    }
    default: heff_nomatch(v_t_2419);
    }
    return heff_tag_at(v_ru_24n_241_24IAnn, TAG_At, 2, (V[]){heff_tag(TAG_IAnn, 2, (V[]){v_t_2422, v_t_2425}), v_sp_240});
  }
  case TAG_ISpec: {
    V v_t_2430 = (g_heff_2epresyntax_2einfNode_24s226003340x1863664708(v_n_241));
    V v_t_2431 = heff_tag(TAG_INominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2430, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2431, v_sp_240});
  }
  case TAG_IAnnLam: {
    V v_t_2436 = (g_heff_2epresyntax_2einfNode_24s226003340x1863664708(v_n_241));
    V v_t_2437 = heff_tag(TAG_INominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2436, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2437, v_sp_240});
  }
  case TAG_IInvalid: {
    V v_code_2438 = heff_field(v_n_241, 0);
    V v_why_2439 = heff_field(v_n_241, 1);
    V v_ru_24n_241_24IInvalid = heff_take_reuse_n(v_n_241, 3ULL, 2);
    return heff_tag_at(v_ru_24n_241_24IInvalid, TAG_At, 2, (V[]){heff_tag(TAG_IInvalid, 2, (V[]){v_code_2438, v_why_2439}), v_sp_240});
  }
  case TAG_INominal: {
    V v_t_2441 = (g_heff_2epresyntax_2einfNode_24s226003340x1863664708(v_n_241));
    V v_t_2442 = heff_tag(TAG_INominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2441, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2442, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2epresyntax_2einfDe_24s1088488601x1677399249_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2einfDe_24s1088488601x1677399249(a[0], a[1]);
}
Clo g_heff_2epresyntax_2etypDe_24s203630508x1828297368_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2etypDe_24s203630508x1828297368_entry, 2, 0};

V g_heff_2epresyntax_2etypDe_24s203630508x1828297368(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_TPi: {
    V v_t_244 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(v_n_241));
    V v_t_245 = heff_tag(TAG_TNominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_244, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_245, v_sp_240});
  }
  case TAG_TSig: {
    V v_fs_246 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TSig = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_247 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(heff_tag_at(v_ru_24n_241_24TSig, TAG_TSig, 1, (V[]){v_fs_246})));
    return heff_tag(TAG_At, 2, (V[]){v_t_247, v_sp_240});
  }
  case TAG_TSum: {
    V v_vs_248 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TSum = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_249 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(heff_tag_at(v_ru_24n_241_24TSum, TAG_TSum, 1, (V[]){v_vs_248})));
    return heff_tag(TAG_At, 2, (V[]){v_t_249, v_sp_240});
  }
  case TAG_TType: {
    V v_t_2410 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(v_n_241));
    V v_t_2411 = heff_tag(TAG_TNominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2410, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2411, v_sp_240});
  }
  case TAG_TInt: {
    V v_t_2412 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(v_n_241));
    V v_t_2413 = heff_tag(TAG_TNominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_TFloat: {
    V v_t_2414 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(v_n_241));
    V v_t_2415 = heff_tag(TAG_TNominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2414, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2415, v_sp_240});
  }
  case TAG_TString: {
    V v_t_2416 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(v_n_241));
    V v_t_2417 = heff_tag(TAG_TNominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2416, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2417, v_sp_240});
  }
  case TAG_TArray: {
    V v_t_2419 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(v_n_241));
    V v_t_2420 = heff_tag(TAG_TNominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2419, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2420, v_sp_240});
  }
  case TAG_TFixed: {
    V v_t_2422 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(v_n_241));
    V v_t_2423 = heff_tag(TAG_TNominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2422, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2423, v_sp_240});
  }
  case TAG_TInf: {
    V v_i_2424 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TInf = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2427;
    switch (heff_tag_of(v_i_2424)) {
    case TAG_At: {
      V v_n_2425 = heff_field(v_i_2424, 0);
      V v_sp_2426 = heff_field(v_i_2424, 1);
      heff_take_n(v_i_2424, 3ULL, 2);
      v_t_2427 = (g_heff_2epresyntax_2einfDe_24s1088488601x1677399249(v_sp_2426, v_n_2425));
      break;
    }
    default: heff_nomatch(v_i_2424);
    }
    return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24n_241_24TInf, TAG_TInf, 1, (V[]){v_t_2427}), v_sp_240});
  }
  case TAG_TChk: {
    V v_c_2428 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TChk = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2431;
    switch (heff_tag_of(v_c_2428)) {
    case TAG_At: {
      V v_n_2429 = heff_field(v_c_2428, 0);
      V v_sp_2430 = heff_field(v_c_2428, 1);
      heff_take_n(v_c_2428, 3ULL, 2);
      v_t_2431 = (g_heff_2epresyntax_2echkDe_24s1632343938x112901564(v_sp_2430, v_n_2429));
      break;
    }
    default: heff_nomatch(v_c_2428);
    }
    return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24n_241_24TChk, TAG_TChk, 1, (V[]){v_t_2431}), v_sp_240});
  }
  case TAG_TNominal: {
    V v_t_2433 = (g_heff_2epresyntax_2etypNode_24s1488628894x2014562827(v_n_241));
    V v_t_2434 = heff_tag(TAG_TNominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2433, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2434, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2epresyntax_2etypDe_24s203630508x1828297368_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2etypDe_24s203630508x1828297368(a[0], a[1]);
}
Clo g_heff_2epresyntax_2echkDe_24s1632343938x112901564_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epresyntax_2echkDe_24s1632343938x112901564_entry, 2, 0};

V g_heff_2epresyntax_2echkDe_24s1632343938x112901564(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_CInf: {
    V v_i_242 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24CInf = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_245;
    switch (heff_tag_of(v_i_242)) {
    case TAG_At: {
      V v_n_243 = heff_field(v_i_242, 0);
      V v_sp_244 = heff_field(v_i_242, 1);
      heff_take_n(v_i_242, 3ULL, 2);
      v_t_245 = (g_heff_2epresyntax_2einfDe_24s1088488601x1677399249(v_sp_244, v_n_243));
      break;
    }
    default: heff_nomatch(v_i_242);
    }
    return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24n_241_24CInf, TAG_CInf, 1, (V[]){v_t_245}), v_sp_240});
  }
  case TAG_CType: {
    V v_t_246 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24CType = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_At: {
      V v_n_247 = heff_field(v_t_246, 0);
      V v_sp_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 3ULL, 2);
      v_t_249 = (g_heff_2epresyntax_2etypDe_24s203630508x1828297368(v_sp_248, v_n_247));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24n_241_24CType, TAG_CType, 1, (V[]){v_t_249}), v_sp_240});
  }
  case TAG_CLam: {
    V v_x_2410 = heff_field(v_n_241, 0);
    V v_xsp_2411 = heff_field(v_n_241, 1);
    V v_b_2412 = heff_field(v_n_241, 2);
    V v_ru_24n_241_24CLam = heff_take_reuse_n(v_n_241, 7ULL, 3);
    V v_t_2415;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_At: {
      V v_n_2413 = heff_field(v_b_2412, 0);
      V v_sp_2414 = heff_field(v_b_2412, 1);
      heff_take_n(v_b_2412, 3ULL, 2);
      v_t_2415 = (g_heff_2epresyntax_2echkDe_24s1632343938x112901564(v_sp_2414, v_n_2413));
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24n_241_24CLam, TAG_CLam, 3, (V[]){v_x_2410, v_xsp_2411, v_t_2415}), v_sp_240});
  }
  case TAG_CImplicitLam: {
    V v_x_2416 = heff_field(v_n_241, 0);
    V v_xsp_2417 = heff_field(v_n_241, 1);
    V v_b_2418 = heff_field(v_n_241, 2);
    V v_ru_24n_241_24CImplicitLam = heff_take_reuse_n(v_n_241, 7ULL, 3);
    V v_t_2421;
    switch (heff_tag_of(v_b_2418)) {
    case TAG_At: {
      V v_n_2419 = heff_field(v_b_2418, 0);
      V v_sp_2420 = heff_field(v_b_2418, 1);
      heff_take_n(v_b_2418, 3ULL, 2);
      v_t_2421 = (g_heff_2epresyntax_2echkDe_24s1632343938x112901564(v_sp_2420, v_n_2419));
      break;
    }
    default: heff_nomatch(v_b_2418);
    }
    return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24n_241_24CImplicitLam, TAG_CImplicitLam, 3, (V[]){v_x_2416, v_xsp_2417, v_t_2421}), v_sp_240});
  }
  case TAG_CAnnLam: {
    V v_t_2426 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_241));
    V v_t_2427 = heff_tag(TAG_CNominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2426, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2427, v_sp_240});
  }
  case TAG_CTag: {
    V v_t_2431 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_241));
    V v_t_2432 = heff_tag(TAG_CNominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2431, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2432, v_sp_240});
  }
  case TAG_CStruct: {
    V v_fs_2433 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24CStruct = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2434 = heff_tag_at(v_ru_24n_241_24CStruct, TAG_CStruct, 1, (V[]){(g_prelude_2emap_24s588898442x1763987159(v_fs_2433))});
    return heff_tag(TAG_At, 2, (V[]){v_t_2434, v_sp_240});
  }
  case TAG_CMatch: {
    V v_t_2437 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_241));
    V v_t_2438 = heff_tag(TAG_CNominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2437, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2438, v_sp_240});
  }
  case TAG_CLetIn: {
    V v_t_2441 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_241));
    V v_t_2442 = heff_tag(TAG_CNominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2441, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2442, v_sp_240});
  }
  case TAG_CLocal: {
    V v_t_2445 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_241));
    V v_t_2446 = heff_tag(TAG_CNominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2445, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2446, v_sp_240});
  }
  case TAG_CAbandon: {
    V v_t_2447 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_241));
    V v_t_2448 = heff_tag(TAG_CNominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2447, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2448, v_sp_240});
  }
  case TAG_CNominal: {
    V v_t_2450 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_n_241));
    V v_t_2451 = heff_tag(TAG_CNominal, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2450, heff_dup(v_sp_240)})});
    return heff_tag(TAG_At, 2, (V[]){v_t_2451, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2epresyntax_2echkDe_24s1632343938x112901564_entry(V self, V *a) {
  (void)self;
  return g_heff_2epresyntax_2echkDe_24s1632343938x112901564(a[0], a[1]);
}