// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_body 9524841
#define LBL_key 315609
V g_heff_2ecompile_2eborrow_2eborAll(V, V);
V g_heff_2ecompile_2eborrow_2eborAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborAll_clo;
V g_heff_2ecompile_2eborrow_2eborDef(V, V);
V g_heff_2ecompile_2eborrow_2eborDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborDef_clo;
V g_heff_2ecompile_2eborrow_2eborFix(V, V, V);
V g_heff_2ecompile_2eborrow_2eborFix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborFix_clo;
V g_heff_2ecompile_2eborrow_2ebuildsSize(V, V);
V g_heff_2ecompile_2eborrow_2ebuildsSize_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2ebuildsSize_clo;
V g_heff_2ecompile_2eborrow_2eelemI(V, V);
V g_heff_2ecompile_2eborrow_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eelemI_clo;
V g_heff_2ecompile_2eborrow_2eelemS(V, V);
V g_heff_2ecompile_2eborrow_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eelemS_clo;
V g_heff_2ecompile_2eborrow_2elentVars(V, V);
V g_heff_2ecompile_2eborrow_2elentVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2elentVars_clo;
V g_heff_2ecompile_2eborrow_2eloopLent(V, V, V, V);
V g_heff_2ecompile_2eborrow_2eloopLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eloopLent_clo;
V g_heff_2ecompile_2eborrow_2eonlyLent(V, V, V);
V g_heff_2ecompile_2eborrow_2eonlyLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eonlyLent_clo;
V g_heff_2ecompile_2eborrow_2ereuses(V, V);
V g_heff_2ecompile_2eborrow_2ereuses_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2ereuses_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1579866964x445286031(V, V);
V g_list_2eany_24s1579866964x445286031_entry(V self, V *a);
extern Clo g_list_2eany_24s1579866964x445286031_clo;
V g_list_2eany_24s361779565x1527579812(V);
V g_list_2eany_24s361779565x1527579812_entry(V self, V *a);
extern Clo g_list_2eany_24s361779565x1527579812_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1922461191x750914054(V, V, V, V);
V g_list_2efoldl_24f1922461191x750914054_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1922461191x750914054_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1416922510x485352908(V, V);
V g_list_2efoldl_24s1416922510x485352908_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1416922510x485352908_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2ecompile_2eborrow_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x_240), heff_dup(v_y_242))) {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2eelemS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eborrow_2eelemS(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eborrow_2eelemI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eelemI_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2eelemI(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_j_242 = heff_field(v_x2_241, 0);
    V v_js_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(v_i_240), heff_dup(v_j_242))) {
      heff_drop(v_i_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_i_240;
      V t_1 = v_js_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2eelemI_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eborrow_2eelemI(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam0(V self, V *args);
V g_heff_2ecompile_2eborrow_2eonlyLent_lam1(V self, V *args);
V g_heff_2ecompile_2eborrow_2eonlyLent_lam2(V self, V *args);
V g_heff_2ecompile_2eborrow_2eonlyLent_lam3(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2eonlyLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eonlyLent_entry, 3, 0};

V g_heff_2ecompile_2eborrow_2eonlyLent(V v_bor_240, V v_p_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    heff_drop(v_bor_240);
    if (heff_strEq_c(v_p_241, v_x_243)) {
      return NTAG(TAG_False);
    } else {
      return NTAG(TAG_True);
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    V v_b_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 2);
    V t_0 = v_bor_240;
    V t_1 = v_p_241;
    V t_2 = v_b_247;
    v_bor_240 = t_0;
    v_p_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_x3_242, 0);
    V v_as_249 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24EApp = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eonlyLent_clo), 2, (V[]){v_bor_240, v_p_241}));
    return ({ V a_0 = v_t_2410; V b_1 = heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_f_248, v_as_249}); V r_ = (g_list_2eall(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2412 = heff_field(v_x3_242, 1);
    V v_b_2413 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 6ULL, 3);
    V v_t_2414 = (g_heff_2ecompile_2eborrow_2eonlyLent(heff_dup(v_bor_240), heff_dup(v_p_241), v_a_2412));
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_t_2414);
      V t_0 = v_bor_240;
      V t_1 = v_p_241;
      V t_2 = v_b_2413;
      v_bor_240 = t_0;
      v_p_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_bor_240);
      heff_drop(v_p_241);
      heff_drop(v_b_2413);
      heff_drop(v_t_2414);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam0, 1, 2, (V[]){v_bor_240, v_p_241}); V a_1 = v_fs_2415; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_fs_2415); r_; });
  }
  case TAG_EProj: {
    V v_e_2421 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 4);
    V t_0 = v_bor_240;
    V t_1 = v_p_241;
    V t_2 = v_e_2421;
    v_bor_240 = t_0;
    v_p_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2426 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 3);
    V v_t_2428 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eonlyLent_clo), 2, (V[]){v_bor_240, v_p_241}));
    return ({ V a_0 = v_t_2428; V a_1 = v_as_2426; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2426); r_; });
  }
  case TAG_EMatch: {
    V v_s_2429 = heff_field(v_x3_242, 0);
    V v_arms_2430 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2465;
    switch (heff_tag_of(v_s_2429)) {
    case TAG_EVar: {
      V v_x_2431 = heff_dup(heff_field(v_s_2429, 0));
      v_t_2465 = heff_strEq(heff_dup(v_p_241), v_x_2431);
      break;
    }
    case TAG_EGlobal: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2429);
    }
    if ((heff_dup(v_t_2465) == NTAG(TAG_True))) {
      heff_drop(v_s_2429);
      heff_drop(v_t_2465);
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam1, 1, 2, (V[]){v_bor_240, v_p_241}); V a_1 = v_arms_2430; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2430); r_; });
    } else {
      heff_drop(v_t_2465);
      V v_t_2471 = (g_heff_2ecompile_2eborrow_2eonlyLent(heff_dup(v_bor_240), heff_dup(v_p_241), v_s_2429));
      if ((heff_dup(v_t_2471) == NTAG(TAG_True))) {
        heff_drop(v_t_2471);
        return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam2, 1, 2, (V[]){v_bor_240, v_p_241}); V a_1 = v_arms_2430; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2430); r_; });
      } else {
        heff_drop(v_bor_240);
        heff_drop(v_p_241);
        heff_drop(v_arms_2430);
        heff_drop(v_t_2471);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_as_2479 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 2);
    V v_t_2480 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eonlyLent_clo), 2, (V[]){v_bor_240, v_p_241}));
    return ({ V a_0 = v_t_2480; V a_1 = v_as_2479; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2479); r_; });
  }
  case TAG_ECall: {
    V v_g_2481 = heff_field(v_x3_242, 0);
    V v_as_2482 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2483 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2482));
    V v_t_2484 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2483, MK_INT(1LL))));
    V v_t_2485 = (g_list_2ezipWith_24s1876717925x1404326288(v_as_2482, v_t_2484));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam3, 1, 3, (V[]){v_p_241, v_g_2481, v_bor_240}); V a_1 = v_t_2485; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2485); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_take_na(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFix: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eborrow_2eonlyLent_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eborrow_2eonlyLent(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam0(V self, V *args) {
  V v_f_2417 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420;
  switch (heff_tag_of(v_f_2417)) {
  case TAG_MkPair: {
    V v_y_2419 = heff_field(v_f_2417, 1);
    heff_take_n(v_f_2417, 2ULL, 2);
    v_t_2420 = v_y_2419;
    break;
  }
  default: heff_nomatch(v_f_2417);
  }
  return (g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_t_2420));
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam1(V self, V *args) {
  V v_a_2466 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2470;
  switch (heff_tag_of(v_a_2466)) {
  case TAG_MkArm: {
    V v_b_2469 = heff_field(v_a_2466, 2);
    heff_take_n(v_a_2466, 4ULL, 3);
    v_t_2470 = v_b_2469;
    break;
  }
  default: heff_nomatch(v_a_2466);
  }
  return (g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_t_2470));
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam2(V self, V *args) {
  V v_a_2472 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2476;
  switch (heff_tag_of(v_a_2472)) {
  case TAG_MkArm: {
    V v_b_2475 = heff_field(v_a_2472, 2);
    heff_take_n(v_a_2472, 4ULL, 3);
    v_t_2476 = v_b_2475;
    break;
  }
  default: heff_nomatch(v_a_2472);
  }
  return (g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_t_2476));
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam3(V self, V *args) {
  V v_pr_2486 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_g_2481 = heff_env(self)[1];
  V v_bor_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2489;
  switch (heff_tag_of(v_pr_2486)) {
  case TAG_MkPair: {
    V v_x_2487 = heff_dup(heff_field(v_pr_2486, 0));
    v_t_2489 = v_x_2487;
    break;
  }
  default: heff_nomatch(v_pr_2486);
  }
  V v_t_24124;
  switch (heff_tag_of(v_t_2489)) {
  case TAG_EVar: {
    V v_x_2490 = heff_field(v_t_2489, 0);
    heff_take_n(v_t_2489, 1ULL, 1);
    v_t_24124 = heff_strEq(heff_dup(v_p_241), v_x_2490);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_2489, 0ULL, 1);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_t_2489, 0ULL, 2);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_t_2489, 0ULL, 2);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_t_2489, 0ULL, 3);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_2489, 0ULL, 2);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_t_2489, 0ULL, 4);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_t_2489, 0ULL, 3);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_2489, 0ULL, 2);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_2489, 0ULL, 1);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_2489, 0ULL, 2);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_t_2489, 0ULL, 2);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_t_2489, 0ULL, 1);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_na(v_t_2489, 0ULL, 1);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_t_2489, 0ULL, 1);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_2489, 0ULL, 1);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_2489, 0ULL, 2);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_2489, 0ULL, 1);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_t_2489, 0ULL, 2);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2489);
  }
  if ((heff_dup(v_t_24124) == NTAG(TAG_True))) {
    heff_drop(v_t_24124);
    V v_t_24127;
    switch (heff_tag_of(v_pr_2486)) {
    case TAG_MkPair: {
      V v_y_24126 = heff_dup(heff_field(v_pr_2486, 1));
      v_t_24127 = v_y_24126;
      break;
    }
    default: heff_nomatch(v_pr_2486);
    }
    V v_x2_24128 = (g_map_2elookup_24s1546226666x2146984184(v_g_2481, v_bor_240));
    V v_t_24130;
    switch (heff_tag_of(v_x2_24128)) {
    case TAG_Nothing: {
      v_t_24130 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_24129 = heff_field(v_x2_24128, 0);
      heff_take_n(v_x2_24128, 1ULL, 1);
      v_t_24130 = v_x_24129;
      break;
    }
    default: heff_nomatch(v_x2_24128);
    }
    V v_t_24131 = ({ V a_0 = v_t_24127; V a_1 = v_t_24130; V r_ = (g_heff_2ecompile_2eborrow_2eelemI(a_0, a_1)); heff_drop(v_t_24130); r_; });
    if ((heff_dup(v_t_24131) == NTAG(TAG_True))) {
      heff_drop(v_pr_2486);
      heff_drop(v_p_241);
      heff_drop(v_bor_240);
      heff_drop(v_t_24131);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_24131);
      V v_t_24134;
      switch (heff_tag_of(v_pr_2486)) {
      case TAG_MkPair: {
        V v_x_24132 = heff_field(v_pr_2486, 0);
        heff_take_n(v_pr_2486, 1ULL, 2);
        v_t_24134 = v_x_24132;
        break;
      }
      default: heff_nomatch(v_pr_2486);
      }
      return (g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_t_24134));
    }
  } else {
    heff_drop(v_g_2481);
    heff_drop(v_t_24124);
    V v_t_24137;
    switch (heff_tag_of(v_pr_2486)) {
    case TAG_MkPair: {
      V v_x_24135 = heff_field(v_pr_2486, 0);
      heff_take_n(v_pr_2486, 1ULL, 2);
      v_t_24137 = v_x_24135;
      break;
    }
    default: heff_nomatch(v_pr_2486);
    }
    return (g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_t_24137));
  }
}
V g_heff_2ecompile_2eborrow_2ebuildsSize_lam0(V self, V *args);
V g_heff_2ecompile_2eborrow_2ebuildsSize_lam1(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2ebuildsSize_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2ebuildsSize_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2ebuildsSize(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V t_0 = v_n_240;
    V t_1 = v_b_245;
    v_n_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x2_241, 0);
    V v_as_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    return ({ V a_0 = v_t_248; V b_1 = heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_f_246, v_as_247}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x2_241, 1);
    V v_b_2411 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2412 = (g_heff_2ecompile_2eborrow_2ebuildsSize(heff_dup(v_n_240), v_a_2410));
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_n_240);
      heff_drop(v_b_2411);
      heff_drop(v_t_2412);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2412);
      V t_0 = v_n_240;
      V t_1 = v_b_2411;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  case TAG_ERecord: {
    V v_fs_2413 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2ebuildsSize_lam0, 1, 1, (V[]){v_n_240}); V a_1 = v_fs_2413; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_fs_2413); r_; });
  }
  case TAG_EProj: {
    V v_e_2419 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 4);
    V t_0 = v_n_240;
    V t_1 = v_e_2419;
    v_n_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2424 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    V v_t_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2424));
    if (heff_intEq_c(v_t_2426, heff_dup(v_n_240))) {
      heff_drop(v_n_240);
      heff_drop(v_as_2424);
      return NTAG(TAG_True);
    } else {
      V v_t_2428 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ebuildsSize_clo), 1, (V[]){v_n_240}));
      return ({ V a_0 = v_t_2428; V a_1 = v_as_2424; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2424); r_; });
    }
  }
  case TAG_EMatch: {
    V v_s_2429 = heff_field(v_x2_241, 0);
    V v_arms_2430 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2431 = (g_heff_2ecompile_2eborrow_2ebuildsSize(heff_dup(v_n_240), v_s_2429));
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop(v_n_240);
      heff_drop(v_arms_2430);
      heff_drop(v_t_2431);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2431);
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2ebuildsSize_lam1, 1, 1, (V[]){v_n_240}); V a_1 = v_arms_2430; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_arms_2430); r_; });
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_as_2439 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2440 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    return ({ V a_0 = v_t_2440; V a_1 = v_as_2439; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2439); r_; });
  }
  case TAG_ECall: {
    V v_as_2442 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2443 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    return ({ V a_0 = v_t_2443; V a_1 = v_as_2442; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2442); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2ebuildsSize_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eborrow_2ebuildsSize(a[0], a[1]);
}
V g_heff_2ecompile_2eborrow_2ebuildsSize_lam0(V self, V *args) {
  V v_f_2415 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418;
  switch (heff_tag_of(v_f_2415)) {
  case TAG_MkPair: {
    V v_y_2417 = heff_field(v_f_2415, 1);
    heff_take_n(v_f_2415, 2ULL, 2);
    v_t_2418 = v_y_2417;
    break;
  }
  default: heff_nomatch(v_f_2415);
  }
  return (g_heff_2ecompile_2eborrow_2ebuildsSize(v_n_240, v_t_2418));
}
V g_heff_2ecompile_2eborrow_2ebuildsSize_lam1(V self, V *args) {
  V v_a_2432 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436;
  switch (heff_tag_of(v_a_2432)) {
  case TAG_MkArm: {
    V v_b_2435 = heff_field(v_a_2432, 2);
    heff_take_n(v_a_2432, 4ULL, 3);
    v_t_2436 = v_b_2435;
    break;
  }
  default: heff_nomatch(v_a_2432);
  }
  return (g_heff_2ecompile_2eborrow_2ebuildsSize(v_n_240, v_t_2436));
}
V g_heff_2ecompile_2eborrow_2ereuses_lam0(V self, V *args);
V g_heff_2ecompile_2eborrow_2ereuses_lam1(V self, V *args);
V g_heff_2ecompile_2eborrow_2ereuses_lam2(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2ereuses_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2ereuses_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2ereuses(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V t_0 = v_p_240;
    V t_1 = v_b_245;
    v_p_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x2_241, 0);
    V v_as_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_248; V b_1 = heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_f_246, v_as_247}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x2_241, 1);
    V v_b_2411 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2412 = (g_heff_2ecompile_2eborrow_2ereuses(heff_dup(v_p_240), v_a_2410));
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_b_2411);
      heff_drop(v_t_2412);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2412);
      V t_0 = v_p_240;
      V t_1 = v_b_2411;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  case TAG_ERecord: {
    V v_fs_2413 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2ereuses_lam0, 1, 1, (V[]){v_p_240}); V a_1 = v_fs_2413; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_fs_2413); r_; });
  }
  case TAG_EProj: {
    V v_e_2419 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 4);
    V t_0 = v_p_240;
    V t_1 = v_e_2419;
    v_p_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2424 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    V v_t_2426 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_2426; V a_1 = v_as_2424; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2424); r_; });
  }
  case TAG_EMatch: {
    V v_s_2427 = heff_field(v_x2_241, 0);
    V v_arms_2428 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2463;
    switch (heff_tag_of(v_s_2427)) {
    case TAG_EVar: {
      V v_x_2429 = heff_dup(heff_field(v_s_2427, 0));
      v_t_2463 = heff_strEq(heff_dup(v_p_240), v_x_2429);
      break;
    }
    case TAG_EGlobal: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2427);
    }
    if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
      heff_drop(v_t_2463);
      V v_t_2464 = (g_list_2eany_24s361779565x1527579812(v_arms_2428));
      if ((heff_dup(v_t_2464) == NTAG(TAG_True))) {
        heff_drop(v_p_240);
        heff_drop(v_s_2427);
        heff_drop(v_arms_2428);
        heff_drop(v_t_2464);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2464);
        V v_t_2465 = (g_heff_2ecompile_2eborrow_2ereuses(heff_dup(v_p_240), v_s_2427));
        if ((heff_dup(v_t_2465) == NTAG(TAG_True))) {
          heff_drop(v_p_240);
          heff_drop(v_arms_2428);
          heff_drop(v_t_2465);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2465);
          return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2ereuses_lam1, 1, 1, (V[]){v_p_240}); V a_1 = v_arms_2428; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_arms_2428); r_; });
        }
      }
    } else {
      heff_drop(v_t_2463);
      V v_t_2471 = (g_heff_2ecompile_2eborrow_2ereuses(heff_dup(v_p_240), v_s_2427));
      if ((heff_dup(v_t_2471) == NTAG(TAG_True))) {
        heff_drop(v_p_240);
        heff_drop(v_arms_2428);
        heff_drop(v_t_2471);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2471);
        return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2ereuses_lam2, 1, 1, (V[]){v_p_240}); V a_1 = v_arms_2428; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_arms_2428); r_; });
      }
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_as_2479 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2480 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_2480; V a_1 = v_as_2479; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2479); r_; });
  }
  case TAG_ECall: {
    V v_as_2482 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2483 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_2483; V a_1 = v_as_2482; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2482); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2ereuses_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eborrow_2ereuses(a[0], a[1]);
}
V g_heff_2ecompile_2eborrow_2ereuses_lam0(V self, V *args) {
  V v_f_2415 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418;
  switch (heff_tag_of(v_f_2415)) {
  case TAG_MkPair: {
    V v_y_2417 = heff_field(v_f_2415, 1);
    heff_take_n(v_f_2415, 2ULL, 2);
    v_t_2418 = v_y_2417;
    break;
  }
  default: heff_nomatch(v_f_2415);
  }
  return (g_heff_2ecompile_2eborrow_2ereuses(v_p_240, v_t_2418));
}
V g_heff_2ecompile_2eborrow_2ereuses_lam1(V self, V *args) {
  V v_a_2466 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2470;
  switch (heff_tag_of(v_a_2466)) {
  case TAG_MkArm: {
    V v_b_2469 = heff_field(v_a_2466, 2);
    heff_take_n(v_a_2466, 4ULL, 3);
    v_t_2470 = v_b_2469;
    break;
  }
  default: heff_nomatch(v_a_2466);
  }
  return (g_heff_2ecompile_2eborrow_2ereuses(v_p_240, v_t_2470));
}
V g_heff_2ecompile_2eborrow_2ereuses_lam2(V self, V *args) {
  V v_a_2472 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2476;
  switch (heff_tag_of(v_a_2472)) {
  case TAG_MkArm: {
    V v_b_2475 = heff_field(v_a_2472, 2);
    heff_take_n(v_a_2472, 4ULL, 3);
    v_t_2476 = v_b_2475;
    break;
  }
  default: heff_nomatch(v_a_2472);
  }
  return (g_heff_2ecompile_2eborrow_2ereuses(v_p_240, v_t_2476));
}
V g_heff_2ecompile_2eborrow_2elentVars_lam0(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2elentVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2elentVars_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2elentVars(V v_ds_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    V v_a_249 = heff_field(v_x2_241, 1);
    V v_b_2410 = heff_field(v_x2_241, 2);
    V v_t_2411 = (g_heff_2ecompile_2eborrow_2elentVars(heff_dup(v_ds_240), v_a_249));
    V v_t_2412 = (g_heff_2ecompile_2eborrow_2elentVars(v_ds_240, v_b_2410));
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2411, v_t_2412);
  }
  case TAG_ERecord: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    V v_s_2422 = heff_field(v_x2_241, 0);
    V v_arms_2423 = heff_field(v_x2_241, 1);
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2423)));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2elentVars_lam0, 2, 2, (V[]){heff_dup(v_s_2422), v_ds_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2424; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
  }
  case TAG_EPrim: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2elentVars_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eborrow_2elentVars(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eborrow_2elentVars_lam0(V self, V *args) {
  V v_acc_2425 = args[0];
  V v_x_2426 = args[1];
  V v_s_2422 = heff_env(self)[0];
  V v_ds_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2461;
  switch (heff_tag_of(v_s_2422)) {
  case TAG_EVar: {
    V v_x_2427 = heff_field(v_s_2422, 0);
    heff_take_n(v_s_2422, 1ULL, 1);
    v_t_2461 = (g_heff_2ecompile_2eborrow_2eelemS(v_x_2427, v_ds_240));
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_s_2422, 0ULL, 1);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_s_2422, 0ULL, 3);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_s_2422, 0ULL, 4);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_s_2422, 0ULL, 3);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_s_2422, 0ULL, 1);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_s_2422, 0ULL, 1);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_na(v_s_2422, 0ULL, 1);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_s_2422, 0ULL, 1);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_s_2422, 0ULL, 1);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_s_2422, 0ULL, 1);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_s_2422);
  }
  V v_t_2480;
  if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
    heff_drop(v_t_2461);
    V v_t_2465;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_MkArm: {
      V v_vs_2463 = heff_dup(heff_field(v_x_2426, 1));
      v_t_2465 = v_vs_2463;
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    V v_t_2469;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_MkArm: {
      V v_vs_2467 = heff_dup(heff_field(v_x_2426, 1));
      v_t_2469 = v_vs_2467;
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    V v_t_2470 = (g_prelude_2e_2b_2b(v_t_2469, v_ds_240));
    V v_t_2474;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_MkArm: {
      V v_b_2473 = heff_field(v_x_2426, 2);
      heff_take_n(v_x_2426, 4ULL, 3);
      v_t_2474 = v_b_2473;
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    V v_t_2475 = ({ V a_0 = v_t_2470; V a_1 = v_t_2474; V r_ = (g_heff_2ecompile_2eborrow_2elentVars(a_0, a_1)); heff_drop(v_t_2474); r_; });
    v_t_2480 = (g_prelude_2e_2b_2b(v_t_2465, v_t_2475));
  } else {
    heff_drop(v_t_2461);
    V v_t_2479;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_MkArm: {
      V v_b_2478 = heff_field(v_x_2426, 2);
      heff_take_n(v_x_2426, 4ULL, 3);
      v_t_2479 = v_b_2478;
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    v_t_2480 = ({ V a_0 = v_ds_240; V a_1 = v_t_2479; V r_ = (g_heff_2ecompile_2eborrow_2elentVars(a_0, a_1)); heff_drop(v_t_2479); r_; });
  }
  return (g_prelude_2e_2b_2b(v_t_2480, v_acc_2425));
}
V g_heff_2ecompile_2eborrow_2eloopLent_lam0(V self, V *args);
V g_heff_2ecompile_2eborrow_2eloopLent_lam1(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2eloopLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eloopLent_entry, 4, 0};

V g_heff_2ecompile_2eborrow_2eloopLent(V v_key_240, V v_i_241, V v_ds_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_EVar: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_x4_243, 0);
    V v_as_249 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24EApp = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
    return ({ V a_0 = v_t_2410; V b_1 = heff_tag_at_n(v_ru_24x4_243_24EApp, TAG_Cons, 2, (V[]){v_f_248, v_as_249}); V r_ = (g_list_2eall(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2412 = heff_field(v_x4_243, 1);
    V v_b_2413 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 6ULL, 3);
    V v_t_2414 = (g_heff_2ecompile_2eborrow_2eloopLent(heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242), v_a_2412));
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_t_2414);
      V t_0 = v_key_240;
      V t_1 = v_i_241;
      V t_2 = v_ds_242;
      V t_3 = v_b_2413;
      v_key_240 = t_0;
      v_i_241 = t_1;
      v_ds_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_key_240);
      heff_drop(v_i_241);
      heff_drop(v_ds_242);
      heff_drop(v_b_2413);
      heff_drop(v_t_2414);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EProj: {
    heff_take_n(v_x4_243, 0ULL, 4);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_ETag: {
    V v_as_2422 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 2ULL, 3);
    V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
    return ({ V a_0 = v_t_2424; V a_1 = v_as_2422; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2422); r_; });
  }
  case TAG_EMatch: {
    V v_s_2425 = heff_field(v_x4_243, 0);
    V v_arms_2426 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_2427 = (g_heff_2ecompile_2eborrow_2eloopLent(heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242), v_s_2425));
    if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
      heff_drop(v_t_2427);
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eloopLent_lam0, 1, 3, (V[]){v_key_240, v_i_241, v_ds_242}); V a_1 = v_arms_2426; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2426); r_; });
    } else {
      heff_drop(v_key_240);
      heff_drop(v_i_241);
      heff_drop(v_ds_242);
      heff_drop(v_arms_2426);
      heff_drop(v_t_2427);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_ECall: {
    V v_g_2436 = heff_field(v_x4_243, 0);
    V v_as_2437 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    if (heff_strEq_c(v_g_2436, heff_dup(v_key_240))) {
      V v_t_2439 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2437));
      V v_t_2440 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2439, MK_INT(1LL))));
      V v_t_2441 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_as_2437), v_t_2440));
      V v_t_2447 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eloopLent_lam1, 1, 2, (V[]){heff_dup(v_i_241), heff_dup(v_ds_242)}); V a_1 = v_t_2441; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2441); r_; });
      if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
        heff_drop(v_t_2447);
        V v_t_2448 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
        return ({ V a_0 = v_t_2448; V a_1 = v_as_2437; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2437); r_; });
      } else {
        heff_drop(v_key_240);
        heff_drop(v_i_241);
        heff_drop(v_ds_242);
        heff_drop(v_as_2437);
        heff_drop(v_t_2447);
        return NTAG(TAG_False);
      }
    } else {
      V v_t_2449 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
      return ({ V a_0 = v_t_2449; V a_1 = v_as_2437; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2437); r_; });
    }
  }
  case TAG_EInt: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_take_na(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFix: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eborrow_2eloopLent_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eborrow_2eloopLent(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eborrow_2eloopLent_lam0(V self, V *args) {
  V v_a_2428 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_ds_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2432;
  switch (heff_tag_of(v_a_2428)) {
  case TAG_MkArm: {
    V v_b_2431 = heff_field(v_a_2428, 2);
    heff_take_n(v_a_2428, 4ULL, 3);
    v_t_2432 = v_b_2431;
    break;
  }
  default: heff_nomatch(v_a_2428);
  }
  return (g_heff_2ecompile_2eborrow_2eloopLent(v_key_240, v_i_241, v_ds_242, v_t_2432));
}
V g_heff_2ecompile_2eborrow_2eloopLent_lam1(V self, V *args) {
  V v_pr_2442 = args[0];
  V v_i_241 = heff_env(self)[0];
  V v_ds_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2445;
  switch (heff_tag_of(v_pr_2442)) {
  case TAG_MkPair: {
    V v_y_2444 = heff_dup(heff_field(v_pr_2442, 1));
    v_t_2445 = v_y_2444;
    break;
  }
  default: heff_nomatch(v_pr_2442);
  }
  if (heff_intEq_c(v_t_2445, v_i_241)) {
    return ({ V a_0 = v_pr_2442; V a_1 = v_ds_242; V r_ = (g_list_2eany_24s1579866964x445286031(a_0, a_1)); heff_drop(v_pr_2442); heff_drop(v_ds_242); r_; });
  } else {
    heff_drop(v_pr_2442);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
}
V g_heff_2ecompile_2eborrow_2eborDef_lam0(V self, V *args);
V g_heff_2ecompile_2eborrow_2eborDef_lam1(V self, V *args);
V g_heff_2ecompile_2eborrow_2eborDef_lam2(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2eborDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eborDef_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2eborDef(V v_bor_240, V v_d_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_d_241, 2));
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    V v_b_246 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 3ULL, 2);
    V v_x2_247 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_bor_240));
    V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_245));
    V v_t_249 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_248, MK_INT(1LL))));
    V v_t_2410 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_245), v_t_249));
    V v_t_2417 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eborrow_2eborDef_lam0, 1, 1, (V[]){v_x2_247}), v_t_2410));
    V v_t_2418 = (g_list_2emap_24s1937570095x2110149801(v_t_2417));
    V v_x2_2419 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_bor_240));
    V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_245));
    V v_t_2421 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2420, MK_INT(1LL))));
    V v_t_2422 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_245), v_t_2421));
    V v_t_2429 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eborrow_2eborDef_lam1, 1, 1, (V[]){v_x2_2419}), v_t_2422));
    V v_t_2430 = (g_list_2emap_24s1937570095x2110149801(v_t_2429));
    V v_t_2431 = (g_heff_2ecompile_2eborrow_2elentVars(v_t_2430, v_b_246));
    V v_ds_2432 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2431));
    V v_x2_2433 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_bor_240));
    V v_t_2435;
    switch (heff_tag_of(v_x2_2433)) {
    case TAG_Nothing: {
      v_t_2435 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2434 = heff_field(v_x2_2433, 0);
      heff_take_n(v_x2_2433, 1ULL, 1);
      v_t_2435 = v_x_2434;
      break;
    }
    default: heff_nomatch(v_x2_2433);
    }
    V v_t_2442 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eborrow_2eborDef_lam2, 1, 5, (V[]){v_xs_245, heff_dup(v_bor_240), v_b_246, heff_dup(v_d_241), v_ds_2432}), v_t_2435));
    return (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_d_241, 0, 3), v_t_2442, v_bor_240));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 4);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EFloat: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eborrow_2eborDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eborrow_2eborDef(a[0], a[1]);
}
V g_heff_2ecompile_2eborrow_2eborDef_lam0(V self, V *args) {
  V v_p_2411 = args[0];
  V v_x2_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414;
  switch (heff_tag_of(v_p_2411)) {
  case TAG_MkPair: {
    V v_y_2413 = heff_field(v_p_2411, 1);
    heff_take_n(v_p_2411, 2ULL, 2);
    v_t_2414 = v_y_2413;
    break;
  }
  default: heff_nomatch(v_p_2411);
  }
  V v_t_2416;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_x2_247, 0);
    heff_take_n(v_x2_247, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  return ({ V a_0 = v_t_2414; V a_1 = v_t_2416; V r_ = (g_heff_2ecompile_2eborrow_2eelemI(a_0, a_1)); heff_drop(v_t_2416); r_; });
}
V g_heff_2ecompile_2eborrow_2eborDef_lam1(V self, V *args) {
  V v_p_2423 = args[0];
  V v_x2_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426;
  switch (heff_tag_of(v_p_2423)) {
  case TAG_MkPair: {
    V v_y_2425 = heff_field(v_p_2423, 1);
    heff_take_n(v_p_2423, 2ULL, 2);
    v_t_2426 = v_y_2425;
    break;
  }
  default: heff_nomatch(v_p_2423);
  }
  V v_t_2428;
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_Nothing: {
    v_t_2428 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2427 = heff_field(v_x2_2419, 0);
    heff_take_n(v_x2_2419, 1ULL, 1);
    v_t_2428 = v_x_2427;
    break;
  }
  default: heff_nomatch(v_x2_2419);
  }
  return ({ V a_0 = v_t_2426; V a_1 = v_t_2428; V r_ = (g_heff_2ecompile_2eborrow_2eelemI(a_0, a_1)); heff_drop(v_t_2428); r_; });
}
V g_heff_2ecompile_2eborrow_2eborDef_lam2(V self, V *args) {
  V v_i_2436 = args[0];
  V v_xs_245 = heff_env(self)[0];
  V v_bor_240 = heff_env(self)[1];
  V v_b_246 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_ds_2432 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2437 = (g_list_2edrop(heff_dup(v_i_2436), v_xs_245));
  switch (heff_tag_of(v_t_2437)) {
  case TAG_Nil: {
    heff_drop(v_i_2436);
    heff_drop(v_bor_240);
    heff_drop(v_b_246);
    heff_drop_rec(v_d_241, 3);
    heff_drop(v_ds_2432);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_2438 = heff_field(v_t_2437, 0);
    heff_take_n(v_t_2437, 1ULL, 2);
    V v_t_2440 = (g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, heff_dup(v_p_2438), heff_dup(v_b_246)));
    if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
      heff_drop(v_t_2440);
      V v_x1_2441 = (g_heff_2ecompile_2eborrow_2ereuses(v_p_2438, heff_dup(v_b_246)));
      if ((heff_dup(v_x1_2441) == NTAG(TAG_True))) {
        heff_drop(v_i_2436);
        heff_drop(v_b_246);
        heff_drop_rec(v_d_241, 3);
        heff_drop(v_ds_2432);
        heff_drop(v_x1_2441);
        return NTAG(TAG_False);
      } else {
        heff_drop(v_x1_2441);
        return (g_heff_2ecompile_2eborrow_2eloopLent(heff_get_n(v_d_241, 0, 3), v_i_2436, v_ds_2432, v_b_246));
      }
    } else {
      heff_drop(v_i_2436);
      heff_drop(v_b_246);
      heff_drop_rec(v_d_241, 3);
      heff_drop(v_ds_2432);
      heff_drop(v_p_2438);
      heff_drop(v_t_2440);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_t_2437);
  }
}
Clo g_heff_2ecompile_2eborrow_2eborFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eborFix_entry, 3, 0};

V g_heff_2ecompile_2eborrow_2eborFix(V v_defs_240, V v_size_241, V v_bor_242) {
top: ;
  V v_t_243 = (g_map_2etoListOnto(v_bor_242, NTAG(TAG_Nil)));
  V v_t_244 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(1LL); V a_2 = MK_INT(0LL); V a_3 = v_t_243; V r_ = (g_list_2efoldl_24f1922461191x750914054(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
  if (heff_intEq_c(v_t_244, v_size_241)) {
    return v_bor_242;
  } else {
    V v_t_246 = (g_map_2etoListOnto(v_bor_242, NTAG(TAG_Nil)));
    V v_t_247 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(1LL); V a_2 = MK_INT(0LL); V a_3 = v_t_246; V r_ = (g_list_2efoldl_24f1922461191x750914054(a_0, a_1, a_2, a_3)); heff_drop(v_t_246); r_; });
    V v_t_248 = (g_list_2efoldl_24s1416922510x485352908(v_bor_242, v_defs_240));
    V t_0 = v_defs_240;
    V t_1 = v_t_247;
    V t_2 = v_t_248;
    v_defs_240 = t_0;
    v_size_241 = t_1;
    v_bor_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eborrow_2eborFix_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eborrow_2eborFix(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eborrow_2eborAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eborAll_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2eborAll(V v_m_240, V v_d_241) {
top: ;
  V v_t_242 = heff_take_field(v_d_241, 2);
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_245; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    V v_t_248 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_247, MK_INT(1LL))));
    return (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_d_241, 0, 3), v_t_248, v_m_240));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 4);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eborrow_2eborAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eborrow_2eborAll(a[0], a[1]);
}