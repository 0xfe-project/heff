// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_body 9524841
#define LBL_key 315609
V g_heff_2ecompile_2eborrow_2eborAll(V, V);
V g_heff_2ecompile_2eborrow_2eborAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborAll_clo;
V g_heff_2ecompile_2eborrow_2eborDef(V, V);
V g_heff_2ecompile_2eborrow_2eborDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborDef_clo;
V g_heff_2ecompile_2eborrow_2eborFix(V, V, V);
V g_heff_2ecompile_2eborrow_2eborFix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborFix_clo;
V g_heff_2ecompile_2eborrow_2ebuildsSize(V, V);
V g_heff_2ecompile_2eborrow_2ebuildsSize_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2ebuildsSize_clo;
V g_heff_2ecompile_2eborrow_2eelemI(V, V);
V g_heff_2ecompile_2eborrow_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eelemI_clo;
V g_heff_2ecompile_2eborrow_2eelemS(V, V);
V g_heff_2ecompile_2eborrow_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eelemS_clo;
V g_heff_2ecompile_2eborrow_2elendingPrims_get(void);
V g_heff_2ecompile_2eborrow_2elentVars(V, V);
V g_heff_2ecompile_2eborrow_2elentVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2elentVars_clo;
V g_heff_2ecompile_2eborrow_2eloopLent(V, V, V, V);
V g_heff_2ecompile_2eborrow_2eloopLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eloopLent_clo;
V g_heff_2ecompile_2eborrow_2eonlyLent(V, V, V);
V g_heff_2ecompile_2eborrow_2eonlyLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eonlyLent_clo;
V g_heff_2ecompile_2eborrow_2eonlyLentCond(V, V, V);
V g_heff_2ecompile_2eborrow_2eonlyLentCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eonlyLentCond_clo;
V g_heff_2ecompile_2eborrow_2ereuses(V, V);
V g_heff_2ecompile_2eborrow_2ereuses_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2ereuses_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1672254115x651817494(V, V);
V g_list_2eany_24s1672254115x651817494_entry(V self, V *a);
extern Clo g_list_2eany_24s1672254115x651817494_clo;
V g_list_2eany_24s361779565x1527579812(V);
V g_list_2eany_24s361779565x1527579812_entry(V self, V *a);
extern Clo g_list_2eany_24s361779565x1527579812_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1922461191x750914054(V, V, V, V);
V g_list_2efoldl_24f1922461191x750914054_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1922461191x750914054_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1416922510x485352908(V, V);
V g_list_2efoldl_24s1416922510x485352908_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1416922510x485352908_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2ecompile_2eborrow_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2eelemS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eborrow_2eelemS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eborrow_2eelemI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eelemI_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2eelemI(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_j_242 = heff_field(v_x2_241, 0);
    V v_js_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c_lent(v_i_240, v_j_242, 0)) {
      heff_drop(v_i_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_i_240;
      V t_1 = v_js_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2eelemI_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eborrow_2eelemI(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str0, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str1, 7, "strHash");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str2, 11, "arrayLength");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str3, 9, "strRuneAt");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str4, 12, "strRuneWidth");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str5, 7, "strFind");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str6, 9, "strByteAt");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str7, 5, "strLt");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str8, 10, "strCompare");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str9, 8, "strSlice");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str10, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str11, 9, "strLength");

static V g_heff_2ecompile_2eborrow_2elendingPrims_val;
static HEFF_ONCE g_heff_2ecompile_2eborrow_2elendingPrims_st;
static V g_heff_2ecompile_2eborrow_2elendingPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str8), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str10), v_t_244})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str11), v_t_245});
}
V g_heff_2ecompile_2eborrow_2elendingPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eborrow_2elendingPrims_st)) return g_heff_2ecompile_2eborrow_2elendingPrims_val;
  return heff_global(&g_heff_2ecompile_2eborrow_2elendingPrims_val, &g_heff_2ecompile_2eborrow_2elendingPrims_st, g_heff_2ecompile_2eborrow_2elendingPrims_init);
}
V g_heff_2ecompile_2eborrow_2eonlyLentCond_lam0(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2eonlyLentCond_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eonlyLentCond_entry, 3, 0};

V g_heff_2ecompile_2eborrow_2eonlyLentCond(V v_go_240, V v_p_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_CTrue: {
    heff_drop(v_go_240);
    return NTAG(TAG_True);
  }
  case TAG_CFalse: {
    heff_drop(v_go_240);
    return NTAG(TAG_True);
  }
  case TAG_CRel: {
    V v_q_243 = heff_field(v_x3_242, 0);
    V v_a_244 = heff_field(v_x3_242, 1);
    V v_b_245 = heff_field(v_x3_242, 2);
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_245), NTAG(TAG_Nil)});
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLentCond_lam0, 1, 3, (V[]){heff_dup(v_p_241), heff_dup(v_q_243), v_go_240}); V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_244), v_t_246}); V r_ = (g_list_2eall(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_CTest: {
    V v_e_2448 = heff_field(v_x3_242, 0);
    V v_t_2488;
    switch (heff_tag_of(v_e_2448)) {
    case TAG_EVar: {
      V v_x_2449 = heff_field(v_e_2448, 0);
      v_t_2488 = heff_bool(heff_strEq_c_lent(v_p_241, v_x_2449, 0));
      break;
    }
    case TAG_EGlobal: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_2448);
    }
    if ((heff_dup(v_t_2488) == NTAG(TAG_True))) {
      heff_drop(v_go_240);
      heff_drop(v_t_2488);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2488);
      return heff_tail(v_go_240, 1, (V[]){heff_dup(v_e_2448)});
    }
  }
  case TAG_CNot: {
    V v_c_2489 = heff_field(v_x3_242, 0);
    V t_0 = v_go_240;
    V t_1 = v_p_241;
    V t_2 = v_c_2489;
    v_go_240 = t_0;
    v_p_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_CIf: {
    V v_a_2490 = heff_field(v_x3_242, 0);
    V v_b_2491 = heff_field(v_x3_242, 1);
    V v_c_2492 = heff_field(v_x3_242, 2);
    V v_t_2493 = heff_tr(g_heff_2ecompile_2eborrow_2eonlyLentCond(heff_dup(v_go_240), v_p_241, v_a_2490));
    if ((heff_dup(v_t_2493) == NTAG(TAG_True))) {
      heff_drop(v_t_2493);
      V v_t_2494 = heff_tr(g_heff_2ecompile_2eborrow_2eonlyLentCond(heff_dup(v_go_240), v_p_241, v_b_2491));
      if ((heff_dup(v_t_2494) == NTAG(TAG_True))) {
        heff_drop(v_t_2494);
        V t_0 = v_go_240;
        V t_1 = v_p_241;
        V t_2 = v_c_2492;
        v_go_240 = t_0;
        v_p_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_go_240);
        heff_drop(v_t_2494);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_go_240);
      heff_drop(v_t_2493);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eborrow_2eonlyLentCond_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eborrow_2eonlyLentCond(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eborrow_2eonlyLentCond_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_q_243 = heff_env(self)[1];
  V v_go_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2447;
  switch (heff_tag_of(v_x_247)) {
  case TAG_EVar: {
    V v_x_248 = heff_dup(heff_field(v_x_247, 0));
    if (heff_strEq_c(v_p_241, v_x_248)) {
      v_t_2447 = ({ V a_0 = v_q_243; V b_1 = heff_dup(g_heff_2ecompile_2eborrow_2elendingPrims_get()); V r_ = (g_heff_2ecompile_2eborrow_2eelemS(a_0, b_1)); heff_drop(v_q_243); heff_drop(b_1); r_; });
    } else {
      heff_drop(v_q_243);
      v_t_2447 = NTAG(TAG_False);
    }
    break;
  }
  case TAG_EGlobal: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_EBool: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_ESet: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_EValues: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_drop(v_p_241);
    heff_drop(v_q_243);
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
    heff_drop(v_x_247);
    heff_drop(v_go_240);
    heff_drop(v_t_2447);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2447);
    V f_ = v_go_240;
    args[0] = v_x_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam0(V self, V *args);
V g_heff_2ecompile_2eborrow_2eonlyLent_lam1(V self, V *args);
V g_heff_2ecompile_2eborrow_2eonlyLent_lam2(V self, V *args);
V g_heff_2ecompile_2eborrow_2eonlyLent_lam3(V self, V *args);
V g_heff_2ecompile_2eborrow_2eonlyLent_lam4(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2eonlyLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eonlyLent_entry, 3, 0};

V g_heff_2ecompile_2eborrow_2eonlyLent(V v_bor_240, V v_p_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    heff_drop(v_bor_240);
    V v_ret_24bool = heff_bool(!heff_strEq_c_lent(v_p_241, v_x_243, 0));
    heff_drop(v_p_241);
    heff_drop(v_x_243);
    return v_ret_24bool;
  }
  case TAG_EGlobal: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    V v_b_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 2);
    V t_0 = v_bor_240;
    V t_1 = v_p_241;
    V t_2 = v_b_246;
    v_bor_240 = t_0;
    v_p_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_EApp: {
    V v_f_247 = heff_field(v_x3_242, 0);
    V v_args_248 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24EApp = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_249 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eonlyLent_clo), 2, (V[]){v_bor_240, v_p_241}));
    return ({ V a_0 = v_t_249; V b_1 = heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_f_247, v_args_248}); V r_ = (g_list_2eall(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2411 = heff_field(v_x3_242, 1);
    V v_b_2412 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 6ULL, 3);
    V v_t_2413 = heff_tr(g_heff_2ecompile_2eborrow_2eonlyLent(heff_dup(v_bor_240), heff_dup(v_p_241), v_a_2411));
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_t_2413);
      V t_0 = v_bor_240;
      V t_1 = v_p_241;
      V t_2 = v_b_2412;
      v_bor_240 = t_0;
      v_p_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_bor_240);
      heff_drop(v_p_241);
      heff_drop(v_b_2412);
      heff_drop(v_t_2413);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    V v_fs_2414 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam0, 1, 2, (V[]){v_bor_240, v_p_241}); V a_1 = v_fs_2414; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_fs_2414); r_; });
  }
  case TAG_EProj: {
    V v_e_2420 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 4);
    V t_0 = v_bor_240;
    V t_1 = v_p_241;
    V t_2 = v_e_2420;
    v_bor_240 = t_0;
    v_p_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_args_2425 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 3);
    V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eonlyLent_clo), 2, (V[]){v_bor_240, v_p_241}));
    return ({ V a_0 = v_t_2427; V a_1 = v_args_2425; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_args_2425); r_; });
  }
  case TAG_EMatch: {
    V v_s_2428 = heff_field(v_x3_242, 0);
    V v_arms_2429 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2469;
    switch (heff_tag_of(v_s_2428)) {
    case TAG_EVar: {
      V v_x_2430 = heff_dup(heff_field(v_s_2428, 0));
      v_t_2469 = heff_bool(heff_strEq_c_lent(v_p_241, v_x_2430, 0));
      heff_drop(v_x_2430);
      break;
    }
    case TAG_EGlobal: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2428);
    }
    if ((heff_dup(v_t_2469) == NTAG(TAG_True))) {
      heff_drop(v_s_2428);
      heff_drop(v_t_2469);
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam1, 1, 2, (V[]){v_bor_240, v_p_241}); V a_1 = v_arms_2429; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2429); r_; });
    } else {
      heff_drop(v_t_2469);
      V v_t_2475 = heff_tr(g_heff_2ecompile_2eborrow_2eonlyLent(heff_dup(v_bor_240), heff_dup(v_p_241), v_s_2428));
      if ((heff_dup(v_t_2475) == NTAG(TAG_True))) {
        heff_drop(v_t_2475);
        return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam2, 1, 2, (V[]){v_bor_240, v_p_241}); V a_1 = v_arms_2429; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2429); r_; });
      } else {
        heff_drop(v_bor_240);
        heff_drop(v_p_241);
        heff_drop(v_arms_2429);
        heff_drop(v_t_2475);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_q_2482 = heff_field(v_x3_242, 0);
    V v_args_2483 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam3, 1, 3, (V[]){v_p_241, v_q_2482, v_bor_240}); V a_1 = v_args_2483; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_args_2483); r_; });
  }
  case TAG_ECall: {
    V v_g_24125 = heff_field(v_x3_242, 0);
    V v_args_24126 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_24127 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_24126));
    V v_t_24128 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_24127, MK_INT(1LL))));
    V v_t_24129 = (g_list_2ezipWith_24s1876717925x1404326288(v_args_24126, v_t_24128));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam4, 1, 3, (V[]){v_p_241, v_bor_240, v_g_24125}); V a_1 = v_t_24129; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24129); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_take_na(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EBool: {
    V v_c_24192 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_t_24193 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eonlyLent_clo), 2, (V[]){v_bor_240, heff_dup(v_p_241)}));
    return ({ V a_0 = v_t_24193; V a_1 = v_p_241; V a_2 = v_c_24192; V r_ = (g_heff_2ecompile_2eborrow_2eonlyLentCond(a_0, a_1, a_2)); heff_drop(v_p_241); heff_drop(v_c_24192); r_; });
  }
  case TAG_ESet: {
    V v_a_24195 = heff_field(v_x3_242, 1);
    V v_b_24196 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 6ULL, 3);
    V v_t_24197 = heff_tr(g_heff_2ecompile_2eborrow_2eonlyLent(heff_dup(v_bor_240), heff_dup(v_p_241), v_a_24195));
    if ((heff_dup(v_t_24197) == NTAG(TAG_True))) {
      heff_drop(v_t_24197);
      V t_0 = v_bor_240;
      V t_1 = v_p_241;
      V t_2 = v_b_24196;
      v_bor_240 = t_0;
      v_p_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_bor_240);
      heff_drop(v_p_241);
      heff_drop(v_b_24196);
      heff_drop(v_t_24197);
      return NTAG(TAG_False);
    }
  }
  case TAG_EValues: {
    V v_es_24198 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_t_24199 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eonlyLent_clo), 2, (V[]){v_bor_240, v_p_241}));
    return ({ V a_0 = v_t_24199; V a_1 = v_es_24198; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_es_24198); r_; });
  }
  case TAG_EFix: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eborrow_2eonlyLent_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eborrow_2eonlyLent(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam0(V self, V *args) {
  V v_f_2416 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419;
  switch (heff_tag_of(v_f_2416)) {
  case TAG_MkPair: {
    V v_y_2418 = heff_field(v_f_2416, 1);
    heff_take_n(v_f_2416, 2ULL, 2);
    v_t_2419 = v_y_2418;
    break;
  }
  default: heff_nomatch(v_f_2416);
  }
  return (g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_t_2419));
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam1(V self, V *args) {
  V v_a_2470 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2474;
  switch (heff_tag_of(v_a_2470)) {
  case TAG_MkArm: {
    V v_b_2473 = heff_field(v_a_2470, 2);
    heff_take_n(v_a_2470, 4ULL, 3);
    v_t_2474 = v_b_2473;
    break;
  }
  default: heff_nomatch(v_a_2470);
  }
  return (g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_t_2474));
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam2(V self, V *args) {
  V v_a_2476 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2480;
  switch (heff_tag_of(v_a_2476)) {
  case TAG_MkArm: {
    V v_b_2479 = heff_field(v_a_2476, 2);
    heff_take_n(v_a_2476, 4ULL, 3);
    v_t_2480 = v_b_2479;
    break;
  }
  default: heff_nomatch(v_a_2476);
  }
  return (g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_t_2480));
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam3(V self, V *args) {
  V v_a_2484 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_q_2482 = heff_env(self)[1];
  V v_bor_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24124;
  switch (heff_tag_of(v_a_2484)) {
  case TAG_EVar: {
    V v_x_2485 = heff_dup(heff_field(v_a_2484, 0));
    if (heff_strEq_c_lent(v_p_241, v_x_2485, 2)) {
      v_t_24124 = ({ V a_0 = v_q_2482; V b_1 = heff_dup(g_heff_2ecompile_2eborrow_2elendingPrims_get()); V r_ = (g_heff_2ecompile_2eborrow_2eelemS(a_0, b_1)); heff_drop(v_q_2482); heff_drop(b_1); r_; });
    } else {
      heff_drop(v_q_2482);
      v_t_24124 = NTAG(TAG_False);
    }
    break;
  }
  case TAG_EGlobal: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EBool: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_ESet: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EValues: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_drop(v_q_2482);
    v_t_24124 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_2484);
  }
  if ((heff_dup(v_t_24124) == NTAG(TAG_True))) {
    heff_drop(v_a_2484);
    heff_drop(v_p_241);
    heff_drop(v_bor_240);
    heff_drop(v_t_24124);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_24124);
    return (g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_a_2484));
  }
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam4(V self, V *args) {
  V v_pr_24130 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_bor_240 = heff_env(self)[1];
  V v_g_24125 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24133;
  switch (heff_tag_of(v_pr_24130)) {
  case TAG_MkPair: {
    V v_x_24131 = heff_dup(heff_field(v_pr_24130, 0));
    v_t_24133 = v_x_24131;
    break;
  }
  default: heff_nomatch(v_pr_24130);
  }
  V v_t_24181;
  switch (heff_tag_of(v_t_24133)) {
  case TAG_EVar: {
    V v_x_24134 = heff_field(v_t_24133, 0);
    heff_take_n(v_t_24133, 1ULL, 1);
    if (heff_strEq_c_lent(v_p_241, v_x_24134, 2)) {
      V v_t_24137;
      switch (heff_tag_of(v_pr_24130)) {
      case TAG_MkPair: {
        V v_y_24136 = heff_dup(heff_field(v_pr_24130, 1));
        v_t_24137 = v_y_24136;
        break;
      }
      default: heff_nomatch(v_pr_24130);
      }
      HeffT2 v_t_24138 = ({ V a_0 = v_bor_240; V a_1 = v_g_24125; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_g_24125); r_; });
      V v_t_24142;
      {
        V v_field_24140 = v_t_24138.f[1];
        int64_t v_tag_24139 = ((int64_t)v_t_24138.f[0]);
        if ((v_tag_24139 == ((int64_t)0ULL))) {
          V v_x_24141 = v_field_24140;
          v_t_24142 = v_x_24141;
        } else {
          heff_drop(v_field_24140);
          v_t_24142 = NTAG(TAG_Nil);
        }
      }
      v_t_24181 = ({ V a_0 = v_t_24137; V a_1 = v_t_24142; V r_ = (g_heff_2ecompile_2eborrow_2eelemI(a_0, a_1)); heff_drop(v_t_24142); r_; });
    } else {
      heff_drop(v_g_24125);
      v_t_24181 = NTAG(TAG_False);
    }
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_24133, 0ULL, 1);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_t_24133, 0ULL, 2);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_t_24133, 0ULL, 2);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_t_24133, 0ULL, 3);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_24133, 0ULL, 2);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_t_24133, 0ULL, 4);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_t_24133, 0ULL, 3);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_24133, 0ULL, 2);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_24133, 0ULL, 1);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_24133, 0ULL, 2);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_t_24133, 0ULL, 2);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_t_24133, 0ULL, 1);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_na(v_t_24133, 0ULL, 1);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_t_24133, 0ULL, 1);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_24133, 0ULL, 1);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_24133, 0ULL, 2);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_24133, 0ULL, 1);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_EBool: {
    heff_take_n(v_t_24133, 0ULL, 1);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_ESet: {
    heff_take_n(v_t_24133, 0ULL, 3);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_EValues: {
    heff_take_n(v_t_24133, 0ULL, 1);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_t_24133, 0ULL, 2);
    heff_drop(v_g_24125);
    v_t_24181 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_24133);
  }
  if ((heff_dup(v_t_24181) == NTAG(TAG_True))) {
    heff_drop(v_pr_24130);
    heff_drop(v_p_241);
    heff_drop(v_bor_240);
    heff_drop(v_t_24181);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_24181);
    V v_t_24184;
    switch (heff_tag_of(v_pr_24130)) {
    case TAG_MkPair: {
      V v_x_24182 = heff_field(v_pr_24130, 0);
      heff_take_n(v_pr_24130, 1ULL, 2);
      v_t_24184 = v_x_24182;
      break;
    }
    default: heff_nomatch(v_pr_24130);
    }
    return (g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_t_24184));
  }
}
V g_heff_2ecompile_2eborrow_2ebuildsSize_lam0(V self, V *args);
V g_heff_2ecompile_2eborrow_2ebuildsSize_lam1(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2ebuildsSize_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2ebuildsSize_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2ebuildsSize(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V t_0 = v_n_240;
    V t_1 = v_b_245;
    v_n_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x2_241, 0);
    V v_args_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    return ({ V a_0 = v_t_248; V b_1 = heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_f_246, v_args_247}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x2_241, 1);
    V v_b_2411 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2412 = (g_heff_2ecompile_2eborrow_2ebuildsSize(heff_dup(v_n_240), v_a_2410));
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_n_240);
      heff_drop(v_b_2411);
      heff_drop(v_t_2412);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2412);
      V t_0 = v_n_240;
      V t_1 = v_b_2411;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  case TAG_ERecord: {
    V v_fs_2413 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2ebuildsSize_lam0, 1, 1, (V[]){v_n_240}); V a_1 = v_fs_2413; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_fs_2413); r_; });
  }
  case TAG_EProj: {
    V v_e_2419 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 4);
    V t_0 = v_n_240;
    V t_1 = v_e_2419;
    v_n_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_args_2424 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    V v_t_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2424));
    if (heff_intEq_c_lent(v_t_2426, v_n_240, 1)) {
      heff_drop(v_n_240);
      heff_drop(v_args_2424);
      return NTAG(TAG_True);
    } else {
      V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ebuildsSize_clo), 1, (V[]){v_n_240}));
      return ({ V a_0 = v_t_2427; V a_1 = v_args_2424; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_args_2424); r_; });
    }
  }
  case TAG_EMatch: {
    V v_s_2428 = heff_field(v_x2_241, 0);
    V v_arms_2429 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2430 = (g_heff_2ecompile_2eborrow_2ebuildsSize(heff_dup(v_n_240), v_s_2428));
    if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
      heff_drop(v_n_240);
      heff_drop(v_arms_2429);
      heff_drop(v_t_2430);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2430);
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2ebuildsSize_lam1, 1, 1, (V[]){v_n_240}); V a_1 = v_arms_2429; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_arms_2429); r_; });
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_args_2438 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2439 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    return ({ V a_0 = v_t_2439; V a_1 = v_args_2438; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_args_2438); r_; });
  }
  case TAG_ECall: {
    V v_args_2441 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2442 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    return ({ V a_0 = v_t_2442; V a_1 = v_args_2441; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_args_2441); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    V v_c_2450 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_2451 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    V v_t_2452 = ({ V a_0 = v_c_2450; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2450); r_; });
    return ({ V a_0 = v_t_2451; V a_1 = v_t_2452; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2452); r_; });
  }
  case TAG_ESet: {
    V v_a_2454 = heff_field(v_x2_241, 1);
    V v_b_2455 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2456 = (g_heff_2ecompile_2eborrow_2ebuildsSize(heff_dup(v_n_240), v_a_2454));
    if ((heff_dup(v_t_2456) == NTAG(TAG_True))) {
      heff_drop(v_n_240);
      heff_drop(v_b_2455);
      heff_drop(v_t_2456);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2456);
      V t_0 = v_n_240;
      V t_1 = v_b_2455;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  case TAG_EValues: {
    V v_es_2457 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_2458 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    return ({ V a_0 = v_t_2458; V a_1 = v_es_2457; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_es_2457); r_; });
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2ebuildsSize_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eborrow_2ebuildsSize(a[0], a[1]);
}
V g_heff_2ecompile_2eborrow_2ebuildsSize_lam0(V self, V *args) {
  V v_f_2415 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418;
  switch (heff_tag_of(v_f_2415)) {
  case TAG_MkPair: {
    V v_y_2417 = heff_field(v_f_2415, 1);
    heff_take_n(v_f_2415, 2ULL, 2);
    v_t_2418 = v_y_2417;
    break;
  }
  default: heff_nomatch(v_f_2415);
  }
  return (g_heff_2ecompile_2eborrow_2ebuildsSize(v_n_240, v_t_2418));
}
V g_heff_2ecompile_2eborrow_2ebuildsSize_lam1(V self, V *args) {
  V v_a_2431 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435;
  switch (heff_tag_of(v_a_2431)) {
  case TAG_MkArm: {
    V v_b_2434 = heff_field(v_a_2431, 2);
    heff_take_n(v_a_2431, 4ULL, 3);
    v_t_2435 = v_b_2434;
    break;
  }
  default: heff_nomatch(v_a_2431);
  }
  return (g_heff_2ecompile_2eborrow_2ebuildsSize(v_n_240, v_t_2435));
}
V g_heff_2ecompile_2eborrow_2ereuses_lam0(V self, V *args);
V g_heff_2ecompile_2eborrow_2ereuses_lam1(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2ereuses_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2ereuses_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2ereuses(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V t_0 = v_p_240;
    V t_1 = v_b_245;
    v_p_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x2_241, 0);
    V v_args_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_248; V b_1 = heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_f_246, v_args_247}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x2_241, 1);
    V v_b_2411 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2412 = (g_heff_2ecompile_2eborrow_2ereuses(heff_dup(v_p_240), v_a_2410));
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_b_2411);
      heff_drop(v_t_2412);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2412);
      V t_0 = v_p_240;
      V t_1 = v_b_2411;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  case TAG_ERecord: {
    V v_fs_2413 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2ereuses_lam0, 1, 1, (V[]){v_p_240}); V a_1 = v_fs_2413; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_fs_2413); r_; });
  }
  case TAG_EProj: {
    V v_e_2419 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 4);
    V t_0 = v_p_240;
    V t_1 = v_e_2419;
    v_p_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_args_2424 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    V v_t_2426 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_2426; V a_1 = v_args_2424; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_args_2424); r_; });
  }
  case TAG_EMatch: {
    V v_s_2427 = heff_field(v_x2_241, 0);
    V v_arms_2428 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2468;
    switch (heff_tag_of(v_s_2427)) {
    case TAG_EVar: {
      V v_x_2429 = heff_dup(heff_field(v_s_2427, 0));
      if (heff_strEq_c_lent(v_p_240, v_x_2429, 2)) {
        v_t_2468 = (g_list_2eany_24s361779565x1527579812(v_arms_2428));
      } else {
        v_t_2468 = NTAG(TAG_False);
      }
      break;
    }
    case TAG_EGlobal: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2427);
    }
    if ((heff_dup(v_t_2468) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_s_2427);
      heff_drop(v_arms_2428);
      heff_drop(v_t_2468);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2468);
      V v_t_2469 = (g_heff_2ecompile_2eborrow_2ereuses(heff_dup(v_p_240), v_s_2427));
      if ((heff_dup(v_t_2469) == NTAG(TAG_True))) {
        heff_drop(v_p_240);
        heff_drop(v_arms_2428);
        heff_drop(v_t_2469);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2469);
        return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2ereuses_lam1, 1, 1, (V[]){v_p_240}); V a_1 = v_arms_2428; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_arms_2428); r_; });
      }
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_args_2477 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2478 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_2478; V a_1 = v_args_2477; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_args_2477); r_; });
  }
  case TAG_ECall: {
    V v_args_2480 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2481 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_2481; V a_1 = v_args_2480; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_args_2480); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    V v_c_2489 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_2490 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ereuses_clo), 1, (V[]){v_p_240}));
    V v_t_2491 = ({ V a_0 = v_c_2489; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2489); r_; });
    return ({ V a_0 = v_t_2490; V a_1 = v_t_2491; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2491); r_; });
  }
  case TAG_ESet: {
    V v_a_2493 = heff_field(v_x2_241, 1);
    V v_b_2494 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2495 = (g_heff_2ecompile_2eborrow_2ereuses(heff_dup(v_p_240), v_a_2493));
    if ((heff_dup(v_t_2495) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_b_2494);
      heff_drop(v_t_2495);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2495);
      V t_0 = v_p_240;
      V t_1 = v_b_2494;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  case TAG_EValues: {
    V v_es_2496 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_2497 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_2497; V a_1 = v_es_2496; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_es_2496); r_; });
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2ereuses_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eborrow_2ereuses(a[0], a[1]);
}
V g_heff_2ecompile_2eborrow_2ereuses_lam0(V self, V *args) {
  V v_f_2415 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418;
  switch (heff_tag_of(v_f_2415)) {
  case TAG_MkPair: {
    V v_y_2417 = heff_field(v_f_2415, 1);
    heff_take_n(v_f_2415, 2ULL, 2);
    v_t_2418 = v_y_2417;
    break;
  }
  default: heff_nomatch(v_f_2415);
  }
  return (g_heff_2ecompile_2eborrow_2ereuses(v_p_240, v_t_2418));
}
V g_heff_2ecompile_2eborrow_2ereuses_lam1(V self, V *args) {
  V v_a_2470 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2474;
  switch (heff_tag_of(v_a_2470)) {
  case TAG_MkArm: {
    V v_b_2473 = heff_field(v_a_2470, 2);
    heff_take_n(v_a_2470, 4ULL, 3);
    v_t_2474 = v_b_2473;
    break;
  }
  default: heff_nomatch(v_a_2470);
  }
  return (g_heff_2ecompile_2eborrow_2ereuses(v_p_240, v_t_2474));
}
V g_heff_2ecompile_2eborrow_2elentVars_lam0(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2elentVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2elentVars_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2elentVars(V v_ds_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    V v_a_249 = heff_field(v_x2_241, 1);
    V v_b_2410 = heff_field(v_x2_241, 2);
    V v_t_2411 = (g_heff_2ecompile_2eborrow_2elentVars(heff_dup(v_ds_240), v_a_249));
    V v_t_2412 = (g_heff_2ecompile_2eborrow_2elentVars(v_ds_240, v_b_2410));
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2411, v_t_2412);
  }
  case TAG_ERecord: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    V v_s_2422 = heff_field(v_x2_241, 0);
    V v_arms_2423 = heff_field(v_x2_241, 1);
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2423)));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2elentVars_lam0, 2, 2, (V[]){heff_dup(v_s_2422), v_ds_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2424; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
  }
  case TAG_EPrim: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EBool: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ESet: {
    V v_a_24100 = heff_field(v_x2_241, 1);
    V v_b_24101 = heff_field(v_x2_241, 2);
    V v_t_24102 = (g_heff_2ecompile_2eborrow_2elentVars(heff_dup(v_ds_240), v_a_24100));
    V v_t_24103 = (g_heff_2ecompile_2eborrow_2elentVars(v_ds_240, v_b_24101));
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_24102, v_t_24103);
  }
  case TAG_EValues: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2elentVars_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eborrow_2elentVars(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eborrow_2elentVars_lam0(V self, V *args) {
  V v_acc_2425 = args[0];
  V v_x_2426 = args[1];
  V v_s_2422 = heff_env(self)[0];
  V v_ds_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2466;
  switch (heff_tag_of(v_s_2422)) {
  case TAG_EVar: {
    V v_x_2427 = heff_field(v_s_2422, 0);
    heff_take_n(v_s_2422, 1ULL, 1);
    v_t_2466 = ({ V a_0 = v_x_2427; V a_1 = v_ds_240; V r_ = (g_heff_2ecompile_2eborrow_2eelemS(a_0, a_1)); heff_drop(v_x_2427); r_; });
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_s_2422, 0ULL, 1);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_s_2422, 0ULL, 3);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_s_2422, 0ULL, 4);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_s_2422, 0ULL, 3);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_s_2422, 0ULL, 1);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_s_2422, 0ULL, 1);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_na(v_s_2422, 0ULL, 1);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_s_2422, 0ULL, 1);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_s_2422, 0ULL, 1);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_s_2422, 0ULL, 1);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_EBool: {
    heff_take_n(v_s_2422, 0ULL, 1);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_ESet: {
    heff_take_n(v_s_2422, 0ULL, 3);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_EValues: {
    heff_take_n(v_s_2422, 0ULL, 1);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2466 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_s_2422);
  }
  V v_t_2485;
  if ((heff_dup(v_t_2466) == NTAG(TAG_True))) {
    heff_drop(v_t_2466);
    V v_t_2470;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_MkArm: {
      V v_vs_2468 = heff_dup(heff_field(v_x_2426, 1));
      v_t_2470 = v_vs_2468;
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    V v_t_2474;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_MkArm: {
      V v_vs_2472 = heff_dup(heff_field(v_x_2426, 1));
      v_t_2474 = v_vs_2472;
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    V v_t_2475 = (g_prelude_2e_2b_2b(v_t_2474, v_ds_240));
    V v_t_2479;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_MkArm: {
      V v_b_2478 = heff_field(v_x_2426, 2);
      heff_take_n(v_x_2426, 4ULL, 3);
      v_t_2479 = v_b_2478;
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    V v_t_2480 = ({ V a_0 = v_t_2475; V a_1 = v_t_2479; V r_ = (g_heff_2ecompile_2eborrow_2elentVars(a_0, a_1)); heff_drop(v_t_2479); r_; });
    v_t_2485 = (g_prelude_2e_2b_2b(v_t_2470, v_t_2480));
  } else {
    heff_drop(v_t_2466);
    V v_t_2484;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_MkArm: {
      V v_b_2483 = heff_field(v_x_2426, 2);
      heff_take_n(v_x_2426, 4ULL, 3);
      v_t_2484 = v_b_2483;
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    v_t_2485 = ({ V a_0 = v_ds_240; V a_1 = v_t_2484; V r_ = (g_heff_2ecompile_2eborrow_2elentVars(a_0, a_1)); heff_drop(v_t_2484); r_; });
  }
  return (g_prelude_2e_2b_2b(v_t_2485, v_acc_2425));
}
V g_heff_2ecompile_2eborrow_2eloopLent_lam0(V self, V *args);
V g_heff_2ecompile_2eborrow_2eloopLent_lam1(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2eloopLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eloopLent_entry, 4, 0};

V g_heff_2ecompile_2eborrow_2eloopLent(V v_key_240, V v_i_241, V v_ds_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_EVar: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_x4_243, 0);
    V v_args_249 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24EApp = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
    return ({ V a_0 = v_t_2410; V b_1 = heff_tag_at_n(v_ru_24x4_243_24EApp, TAG_Cons, 2, (V[]){v_f_248, v_args_249}); V r_ = (g_list_2eall(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2412 = heff_field(v_x4_243, 1);
    V v_b_2413 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 6ULL, 3);
    V v_t_2414 = (g_heff_2ecompile_2eborrow_2eloopLent(heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242), v_a_2412));
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_t_2414);
      V t_0 = v_key_240;
      V t_1 = v_i_241;
      V t_2 = v_ds_242;
      V t_3 = v_b_2413;
      v_key_240 = t_0;
      v_i_241 = t_1;
      v_ds_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_key_240);
      heff_drop(v_i_241);
      heff_drop(v_ds_242);
      heff_drop(v_b_2413);
      heff_drop(v_t_2414);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EProj: {
    heff_take_n(v_x4_243, 0ULL, 4);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_ETag: {
    V v_args_2422 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 2ULL, 3);
    V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
    return ({ V a_0 = v_t_2424; V a_1 = v_args_2422; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_args_2422); r_; });
  }
  case TAG_EMatch: {
    V v_s_2425 = heff_field(v_x4_243, 0);
    V v_arms_2426 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_2427 = (g_heff_2ecompile_2eborrow_2eloopLent(heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242), v_s_2425));
    if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
      heff_drop(v_t_2427);
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eloopLent_lam0, 1, 3, (V[]){v_key_240, v_i_241, v_ds_242}); V a_1 = v_arms_2426; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2426); r_; });
    } else {
      heff_drop(v_key_240);
      heff_drop(v_i_241);
      heff_drop(v_ds_242);
      heff_drop(v_arms_2426);
      heff_drop(v_t_2427);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_ECall: {
    V v_g_2436 = heff_field(v_x4_243, 0);
    V v_args_2437 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    if (!heff_strEq_c_lent(v_g_2436, v_key_240, 0)) {
      heff_drop(v_g_2436);
      V v_t_2438 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
      return ({ V a_0 = v_t_2438; V a_1 = v_args_2437; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_args_2437); r_; });
    } else {
      heff_drop(v_g_2436);
      V v_t_2439 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2437));
      V v_t_2440 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2439, MK_INT(1LL))));
      V v_t_2441 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_args_2437), v_t_2440));
      V v_t_2446 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eloopLent_lam1, 1, 2, (V[]){heff_dup(v_i_241), heff_dup(v_ds_242)}); V a_1 = v_t_2441; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2441); r_; });
      if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
        heff_drop(v_t_2446);
        V v_t_2447 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
        return ({ V a_0 = v_t_2447; V a_1 = v_args_2437; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_args_2437); r_; });
      } else {
        heff_drop(v_key_240);
        heff_drop(v_i_241);
        heff_drop(v_ds_242);
        heff_drop(v_args_2437);
        heff_drop(v_t_2446);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EInt: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_take_na(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EBool: {
    V v_c_2455 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_t_2456 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
    V v_t_2457 = ({ V a_0 = v_c_2455; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2455); r_; });
    return ({ V a_0 = v_t_2456; V a_1 = v_t_2457; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2457); r_; });
  }
  case TAG_ESet: {
    V v_a_2459 = heff_field(v_x4_243, 1);
    V v_b_2460 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 6ULL, 3);
    V v_t_2461 = (g_heff_2ecompile_2eborrow_2eloopLent(heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242), v_a_2459));
    if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
      heff_drop(v_t_2461);
      V t_0 = v_key_240;
      V t_1 = v_i_241;
      V t_2 = v_ds_242;
      V t_3 = v_b_2460;
      v_key_240 = t_0;
      v_i_241 = t_1;
      v_ds_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_key_240);
      heff_drop(v_i_241);
      heff_drop(v_ds_242);
      heff_drop(v_b_2460);
      heff_drop(v_t_2461);
      return NTAG(TAG_False);
    }
  }
  case TAG_EValues: {
    V v_es_2462 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_t_2463 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
    return ({ V a_0 = v_t_2463; V a_1 = v_es_2462; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_es_2462); r_; });
  }
  case TAG_EFix: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eborrow_2eloopLent_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eborrow_2eloopLent(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eborrow_2eloopLent_lam0(V self, V *args) {
  V v_a_2428 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_ds_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2432;
  switch (heff_tag_of(v_a_2428)) {
  case TAG_MkArm: {
    V v_b_2431 = heff_field(v_a_2428, 2);
    heff_take_n(v_a_2428, 4ULL, 3);
    v_t_2432 = v_b_2431;
    break;
  }
  default: heff_nomatch(v_a_2428);
  }
  return (g_heff_2ecompile_2eborrow_2eloopLent(v_key_240, v_i_241, v_ds_242, v_t_2432));
}
V g_heff_2ecompile_2eborrow_2eloopLent_lam1(V self, V *args) {
  V v_pr_2442 = args[0];
  V v_i_241 = heff_env(self)[0];
  V v_ds_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2445;
  switch (heff_tag_of(v_pr_2442)) {
  case TAG_MkPair: {
    V v_y_2444 = heff_dup(heff_field(v_pr_2442, 1));
    v_t_2445 = v_y_2444;
    break;
  }
  default: heff_nomatch(v_pr_2442);
  }
  if (!heff_intEq_c_lent(v_t_2445, v_i_241, 0)) {
    heff_drop(v_pr_2442);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    heff_drop(v_t_2445);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_i_241);
    heff_drop(v_t_2445);
    return ({ V a_0 = v_pr_2442; V a_1 = v_ds_242; V r_ = (g_list_2eany_24s1672254115x651817494(a_0, a_1)); heff_drop(v_pr_2442); heff_drop(v_ds_242); r_; });
  }
}
V g_heff_2ecompile_2eborrow_2eborDef_lam0(V self, V *args);
V g_heff_2ecompile_2eborrow_2eborDef_lam1(V self, V *args);
V g_heff_2ecompile_2eborrow_2eborDef_lam2(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2eborDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eborDef_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2eborDef(V v_bor_240, V v_d_241) {
top: ;
  V v_body_242 = heff_take_field(v_d_241, 2);
  V v_key_243 = heff_get_n(v_d_241, 0, 3);
  switch (heff_tag_of(v_body_242)) {
  case TAG_EVar: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_body_242, 0);
    V v_b_247 = heff_field(v_body_242, 1);
    V v_ru_24body_242_24ELam = heff_take_reuse_n(v_body_242, 3ULL, 2);
    HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_bor_240, v_key_243));
    V v_t_2421;
    {
      V v_field_2410 = v_t_248.f[1];
      V v_tag_249 = heff_box_i64(((int64_t)v_t_248.f[0]));
      V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_246));
      V v_t_2412 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2411, MK_INT(1LL))));
      V v_t_2413 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_246), v_t_2412));
      V v_t_2420 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2eborrow_2eborDef_lam0, 1, 2, (V[]){v_tag_249, v_field_2410}), v_t_2413));
      v_t_2421 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24body_242_24ELam, v_t_2420));
    }
    HeffT2 v_t_2422 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_bor_240, v_key_243));
    V v_t_2435;
    {
      V v_field_2424 = v_t_2422.f[1];
      V v_tag_2423 = heff_box_i64(((int64_t)v_t_2422.f[0]));
      V v_t_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_246));
      V v_t_2426 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2425, MK_INT(1LL))));
      V v_t_2427 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_246), v_t_2426));
      V v_t_2434 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2eborrow_2eborDef_lam1, 1, 2, (V[]){v_tag_2423, v_field_2424}), v_t_2427));
      v_t_2435 = (g_list_2emap_24s1937570095x2110149801(v_t_2434));
    }
    V v_t_2436 = (g_heff_2ecompile_2eborrow_2elentVars(v_t_2435, v_b_247));
    V v_ds_2437 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2436));
    HeffT2 v_t_2438 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_bor_240, v_key_243));
    V v_t_2442;
    {
      V v_field_2440 = v_t_2438.f[1];
      int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
      if ((v_tag_2439 == ((int64_t)0ULL))) {
        V v_x_2441 = v_field_2440;
        v_t_2442 = v_x_2441;
      } else {
        heff_drop(v_field_2440);
        v_t_2442 = NTAG(TAG_Nil);
      }
    }
    V v_t_2452 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2eborrow_2eborDef_lam2, 1, 5, (V[]){v_xs_246, heff_dup(v_bor_240), v_b_247, heff_dup(v_key_243), v_ds_2437}), v_t_2442));
    return (g_std_2emap_2einsert_24s93785294x875597928(v_bor_240, v_key_243, v_t_2452));
  }
  case TAG_EApp: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_ELet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EProj: {
    heff_take_n(v_body_242, 0ULL, 4);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_ETag: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_ECall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EInt: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EFloat: {
    heff_take_na(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EStr: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EAbandon: {
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EBool: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_ESet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EValues: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EFix: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  default: return heff_nomatch(v_body_242);
  }
}
V g_heff_2ecompile_2eborrow_2eborDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eborrow_2eborDef(a[0], a[1]);
}
V g_heff_2ecompile_2eborrow_2eborDef_lam0(V self, V *args) {
  V v_p_2414 = args[0];
  V v_tag_249 = heff_env(self)[0];
  V v_field_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417;
  switch (heff_tag_of(v_p_2414)) {
  case TAG_MkPair: {
    V v_y_2416 = heff_field(v_p_2414, 1);
    heff_take_n(v_p_2414, 2ULL, 2);
    v_t_2417 = v_y_2416;
    break;
  }
  default: heff_nomatch(v_p_2414);
  }
  V v_t_2419;
  if ((heff_unbox_i64(v_tag_249) == ((int64_t)0ULL))) {
    V v_x_2418 = v_field_2410;
    v_t_2419 = v_x_2418;
  } else {
    heff_drop(v_field_2410);
    v_t_2419 = NTAG(TAG_Nil);
  }
  return ({ V a_0 = v_t_2417; V a_1 = v_t_2419; V r_ = (g_heff_2ecompile_2eborrow_2eelemI(a_0, a_1)); heff_drop(v_t_2419); r_; });
}
V g_heff_2ecompile_2eborrow_2eborDef_lam1(V self, V *args) {
  V v_p_2428 = args[0];
  V v_tag_2423 = heff_env(self)[0];
  V v_field_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431;
  switch (heff_tag_of(v_p_2428)) {
  case TAG_MkPair: {
    V v_y_2430 = heff_field(v_p_2428, 1);
    heff_take_n(v_p_2428, 2ULL, 2);
    v_t_2431 = v_y_2430;
    break;
  }
  default: heff_nomatch(v_p_2428);
  }
  V v_t_2433;
  if ((heff_unbox_i64(v_tag_2423) == ((int64_t)0ULL))) {
    V v_x_2432 = v_field_2424;
    v_t_2433 = v_x_2432;
  } else {
    heff_drop(v_field_2424);
    v_t_2433 = NTAG(TAG_Nil);
  }
  return ({ V a_0 = v_t_2431; V a_1 = v_t_2433; V r_ = (g_heff_2ecompile_2eborrow_2eelemI(a_0, a_1)); heff_drop(v_t_2433); r_; });
}
V g_heff_2ecompile_2eborrow_2eborDef_lam2(V self, V *args) {
  V v_i_2443 = args[0];
  V v_xs_246 = heff_env(self)[0];
  V v_bor_240 = heff_env(self)[1];
  V v_b_247 = heff_env(self)[2];
  V v_key_243 = heff_env(self)[3];
  V v_ds_2437 = heff_env(self)[4];
  heff_clo_take(self, 5);
  HeffT3 v_t_2444 = ({ V a_0 = heff_dup(v_i_2443); V a_1 = v_xs_246; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_xs_246); r_; });
  {
    V v_field_2446 = v_t_2444.f[1];
    V v_field_2447 = v_t_2444.f[2];
    int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
    if ((v_tag_2445 == ((int64_t)0ULL))) {
      V v_p_2448 = v_field_2446;
      V v_x_2449 = v_field_2447;
      heff_drop(v_x_2449);
      V v_t_2450 = heff_tr(g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, heff_dup(v_p_2448), heff_dup(v_b_247)));
      if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
        heff_drop(v_t_2450);
        V v_x1_2451 = (g_heff_2ecompile_2eborrow_2ereuses(v_p_2448, heff_dup(v_b_247)));
        if (!(heff_dup(v_x1_2451) == NTAG(TAG_True))) {
          heff_drop(v_x1_2451);
          return (g_heff_2ecompile_2eborrow_2eloopLent(v_key_243, v_i_2443, v_ds_2437, v_b_247));
        } else {
          heff_drop(v_i_2443);
          heff_drop(v_b_247);
          heff_drop(v_key_243);
          heff_drop(v_ds_2437);
          heff_drop(v_x1_2451);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop(v_i_2443);
        heff_drop(v_b_247);
        heff_drop(v_key_243);
        heff_drop(v_ds_2437);
        heff_drop(v_p_2448);
        heff_drop(v_t_2450);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_i_2443);
      heff_drop(v_bor_240);
      heff_drop(v_b_247);
      heff_drop(v_key_243);
      heff_drop(v_ds_2437);
      heff_drop(v_field_2446);
      heff_drop(v_field_2447);
      return NTAG(TAG_False);
    }
  }
}
Clo g_heff_2ecompile_2eborrow_2eborFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eborFix_entry, 3, 0};

V g_heff_2ecompile_2eborrow_2eborFix(V v_defs_240, V v_size_241, V v_bor_242) {
top: ;
  V v_t_243 = (g_std_2emap_2etoListOnto(v_bor_242, NTAG(TAG_Nil)));
  V v_t_244 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(1LL); V a_2 = MK_INT(0LL); V a_3 = v_t_243; V r_ = (g_list_2efoldl_24f1922461191x750914054(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
  if (heff_intEq_c(v_t_244, v_size_241)) {
    return v_bor_242;
  } else {
    V v_t_245 = (g_std_2emap_2etoListOnto(v_bor_242, NTAG(TAG_Nil)));
    V v_t_246 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(1LL); V a_2 = MK_INT(0LL); V a_3 = v_t_245; V r_ = (g_list_2efoldl_24f1922461191x750914054(a_0, a_1, a_2, a_3)); heff_drop(v_t_245); r_; });
    V v_t_247 = (g_list_2efoldl_24s1416922510x485352908(v_bor_242, v_defs_240));
    V t_0 = v_defs_240;
    V t_1 = v_t_246;
    V t_2 = v_t_247;
    v_defs_240 = t_0;
    v_size_241 = t_1;
    v_bor_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eborrow_2eborFix_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eborrow_2eborFix(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eborrow_2eborAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eborAll_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2eborAll(V v_m_240, V v_d_241) {
top: ;
  V v_body_242 = heff_take_field(v_d_241, 2);
  V v_key_243 = heff_get_n(v_d_241, 0, 3);
  switch (heff_tag_of(v_body_242)) {
  case TAG_EVar: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 2);
    V v_t_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_246; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    V v_t_249 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_248, MK_INT(1LL))));
    return (g_std_2emap_2einsert_24s93785294x875597928(v_m_240, v_key_243, v_t_249));
  }
  case TAG_EApp: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_body_242, 0ULL, 4);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EInt: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFloat: {
    heff_take_na(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EBool: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ESet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EValues: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  default: return heff_nomatch(v_body_242);
  }
}
V g_heff_2ecompile_2eborrow_2eborAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eborrow_2eborAll(a[0], a[1]);
}