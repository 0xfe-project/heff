// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_body 9524841
#define LBL_key 315609
V g_heff_2ecompile_2eborrow_2eborAll(V, V);
V g_heff_2ecompile_2eborrow_2eborAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborAll_clo;
V g_heff_2ecompile_2eborrow_2eborDef(V, V);
V g_heff_2ecompile_2eborrow_2eborDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborDef_clo;
V g_heff_2ecompile_2eborrow_2eborFix(V, V, V);
V g_heff_2ecompile_2eborrow_2eborFix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborFix_clo;
V g_heff_2ecompile_2eborrow_2ebuildsSize(V, V);
V g_heff_2ecompile_2eborrow_2ebuildsSize_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2ebuildsSize_clo;
V g_heff_2ecompile_2eborrow_2eelemI(V, V);
V g_heff_2ecompile_2eborrow_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eelemI_clo;
V g_heff_2ecompile_2eborrow_2eelemS(V, V);
V g_heff_2ecompile_2eborrow_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eelemS_clo;
V g_heff_2ecompile_2eborrow_2elendingPrims_get(void);
V g_heff_2ecompile_2eborrow_2elentVars(V, V);
V g_heff_2ecompile_2eborrow_2elentVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2elentVars_clo;
V g_heff_2ecompile_2eborrow_2eloopLent(V, V, V, V);
V g_heff_2ecompile_2eborrow_2eloopLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eloopLent_clo;
V g_heff_2ecompile_2eborrow_2eonlyLent(V, V, V);
V g_heff_2ecompile_2eborrow_2eonlyLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eonlyLent_clo;
V g_heff_2ecompile_2eborrow_2ereuses(V, V);
V g_heff_2ecompile_2eborrow_2ereuses_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2ereuses_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1579866964x445286031(V, V);
V g_list_2eany_24s1579866964x445286031_entry(V self, V *a);
extern Clo g_list_2eany_24s1579866964x445286031_clo;
V g_list_2eany_24s361779565x1527579812(V);
V g_list_2eany_24s361779565x1527579812_entry(V self, V *a);
extern Clo g_list_2eany_24s361779565x1527579812_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1922461191x750914054(V, V, V, V);
V g_list_2efoldl_24f1922461191x750914054_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1922461191x750914054_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1416922510x485352908(V, V);
V g_list_2efoldl_24s1416922510x485352908_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1416922510x485352908_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2ecompile_2eborrow_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2eelemS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eborrow_2eelemS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eborrow_2eelemI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eelemI_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2eelemI(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_j_242 = heff_field(v_x2_241, 0);
    V v_js_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c_lent(v_i_240, v_j_242, 0)) {
      heff_drop(v_i_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_i_240;
      V t_1 = v_js_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2eelemI_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eborrow_2eelemI(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str0, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str1, 7, "strHash");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str2, 11, "arrayLength");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str3, 9, "strRuneAt");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str4, 12, "strRuneWidth");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str5, 7, "strFind");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str6, 9, "strByteAt");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str7, 5, "strLt");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str8, 10, "strCompare");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str9, 8, "strSlice");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str10, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2eborrow_2elendingPrims_str11, 9, "strLength");

static V g_heff_2ecompile_2eborrow_2elendingPrims_val;
static HEFF_ONCE g_heff_2ecompile_2eborrow_2elendingPrims_st;
static V g_heff_2ecompile_2eborrow_2elendingPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str8), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str10), v_t_244})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eborrow_2elendingPrims_str11), v_t_245});
}
V g_heff_2ecompile_2eborrow_2elendingPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eborrow_2elendingPrims_st)) return g_heff_2ecompile_2eborrow_2elendingPrims_val;
  return heff_global(&g_heff_2ecompile_2eborrow_2elendingPrims_val, &g_heff_2ecompile_2eborrow_2elendingPrims_st, g_heff_2ecompile_2eborrow_2elendingPrims_init);
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam0(V self, V *args);
V g_heff_2ecompile_2eborrow_2eonlyLent_lam1(V self, V *args);
V g_heff_2ecompile_2eborrow_2eonlyLent_lam2(V self, V *args);
V g_heff_2ecompile_2eborrow_2eonlyLent_lam3(V self, V *args);
V g_heff_2ecompile_2eborrow_2eonlyLent_lam4(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2eonlyLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eonlyLent_entry, 3, 0};

V g_heff_2ecompile_2eborrow_2eonlyLent(V v_bor_240, V v_p_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    heff_drop(v_bor_240);
    if (heff_strEq_c(v_p_241, v_x_243)) {
      return NTAG(TAG_False);
    } else {
      return NTAG(TAG_True);
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    V v_b_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 2);
    V t_0 = v_bor_240;
    V t_1 = v_p_241;
    V t_2 = v_b_247;
    v_bor_240 = t_0;
    v_p_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_x3_242, 0);
    V v_as_249 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24EApp = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eonlyLent_clo), 2, (V[]){v_bor_240, v_p_241}));
    return ({ V a_0 = v_t_2410; V b_1 = heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_f_248, v_as_249}); V r_ = (g_list_2eall(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2412 = heff_field(v_x3_242, 1);
    V v_b_2413 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 6ULL, 3);
    V v_t_2414 = (g_heff_2ecompile_2eborrow_2eonlyLent(heff_dup(v_bor_240), heff_dup(v_p_241), v_a_2412));
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_t_2414);
      V t_0 = v_bor_240;
      V t_1 = v_p_241;
      V t_2 = v_b_2413;
      v_bor_240 = t_0;
      v_p_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_bor_240);
      heff_drop(v_p_241);
      heff_drop(v_b_2413);
      heff_drop(v_t_2414);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam0, 1, 2, (V[]){v_bor_240, v_p_241}); V a_1 = v_fs_2415; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_fs_2415); r_; });
  }
  case TAG_EProj: {
    V v_e_2421 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 4);
    V t_0 = v_bor_240;
    V t_1 = v_p_241;
    V t_2 = v_e_2421;
    v_bor_240 = t_0;
    v_p_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2426 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 3);
    V v_t_2428 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eonlyLent_clo), 2, (V[]){v_bor_240, v_p_241}));
    return ({ V a_0 = v_t_2428; V a_1 = v_as_2426; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2426); r_; });
  }
  case TAG_EMatch: {
    V v_s_2429 = heff_field(v_x3_242, 0);
    V v_arms_2430 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2465;
    switch (heff_tag_of(v_s_2429)) {
    case TAG_EVar: {
      V v_x_2431 = heff_dup(heff_field(v_s_2429, 0));
      v_t_2465 = heff_strEq_lent(v_p_241, v_x_2431, 2);
      break;
    }
    case TAG_EGlobal: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2465 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2429);
    }
    if ((heff_dup(v_t_2465) == NTAG(TAG_True))) {
      heff_drop(v_s_2429);
      heff_drop(v_t_2465);
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam1, 1, 2, (V[]){v_bor_240, v_p_241}); V a_1 = v_arms_2430; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2430); r_; });
    } else {
      heff_drop(v_t_2465);
      V v_t_2471 = (g_heff_2ecompile_2eborrow_2eonlyLent(heff_dup(v_bor_240), heff_dup(v_p_241), v_s_2429));
      if ((heff_dup(v_t_2471) == NTAG(TAG_True))) {
        heff_drop(v_t_2471);
        return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam2, 1, 2, (V[]){v_bor_240, v_p_241}); V a_1 = v_arms_2430; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2430); r_; });
      } else {
        heff_drop(v_bor_240);
        heff_drop(v_p_241);
        heff_drop(v_arms_2430);
        heff_drop(v_t_2471);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_q_2478 = heff_field(v_x3_242, 0);
    V v_as_2479 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam3, 1, 3, (V[]){v_p_241, v_q_2478, v_bor_240}); V a_1 = v_as_2479; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2479); r_; });
  }
  case TAG_ECall: {
    V v_g_24117 = heff_field(v_x3_242, 0);
    V v_as_24118 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_24119 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_24118));
    V v_t_24120 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_24119, MK_INT(1LL))));
    V v_t_24121 = (g_list_2ezipWith_24s1876717925x1404326288(v_as_24118, v_t_24120));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam4, 1, 3, (V[]){v_p_241, v_bor_240, v_g_24117}); V a_1 = v_t_24121; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24121); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_take_na(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFix: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eborrow_2eonlyLent_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eborrow_2eonlyLent(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam0(V self, V *args) {
  V v_f_2417 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420;
  switch (heff_tag_of(v_f_2417)) {
  case TAG_MkPair: {
    V v_y_2419 = heff_field(v_f_2417, 1);
    heff_take_n(v_f_2417, 2ULL, 2);
    v_t_2420 = v_y_2419;
    break;
  }
  default: heff_nomatch(v_f_2417);
  }
  return (g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_t_2420));
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam1(V self, V *args) {
  V v_a_2466 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2470;
  switch (heff_tag_of(v_a_2466)) {
  case TAG_MkArm: {
    V v_b_2469 = heff_field(v_a_2466, 2);
    heff_take_n(v_a_2466, 4ULL, 3);
    v_t_2470 = v_b_2469;
    break;
  }
  default: heff_nomatch(v_a_2466);
  }
  return (g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_t_2470));
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam2(V self, V *args) {
  V v_a_2472 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2476;
  switch (heff_tag_of(v_a_2472)) {
  case TAG_MkArm: {
    V v_b_2475 = heff_field(v_a_2472, 2);
    heff_take_n(v_a_2472, 4ULL, 3);
    v_t_2476 = v_b_2475;
    break;
  }
  default: heff_nomatch(v_a_2472);
  }
  return (g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_t_2476));
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam3(V self, V *args) {
  V v_a_2480 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_q_2478 = heff_env(self)[1];
  V v_bor_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24115;
  switch (heff_tag_of(v_a_2480)) {
  case TAG_EVar: {
    V v_x_2481 = heff_dup(heff_field(v_a_2480, 0));
    v_t_24115 = heff_strEq_lent(v_p_241, v_x_2481, 2);
    break;
  }
  case TAG_EGlobal: {
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_24115 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_2480);
  }
  if ((heff_dup(v_t_24115) == NTAG(TAG_True))) {
    heff_drop(v_t_24115);
    V v_t_24116 = ({ V a_0 = v_q_2478; V b_1 = heff_dup(g_heff_2ecompile_2eborrow_2elendingPrims_get()); V r_ = (g_heff_2ecompile_2eborrow_2eelemS(a_0, b_1)); heff_drop(v_q_2478); heff_drop(b_1); r_; });
    if ((heff_dup(v_t_24116) == NTAG(TAG_True))) {
      heff_drop(v_a_2480);
      heff_drop(v_p_241);
      heff_drop(v_bor_240);
      heff_drop(v_t_24116);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_24116);
      return (g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_a_2480));
    }
  } else {
    heff_drop(v_q_2478);
    heff_drop(v_t_24115);
    return (g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_a_2480));
  }
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam4(V self, V *args) {
  V v_pr_24122 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_bor_240 = heff_env(self)[1];
  V v_g_24117 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24125;
  switch (heff_tag_of(v_pr_24122)) {
  case TAG_MkPair: {
    V v_x_24123 = heff_dup(heff_field(v_pr_24122, 0));
    v_t_24125 = v_x_24123;
    break;
  }
  default: heff_nomatch(v_pr_24122);
  }
  V v_t_24160;
  switch (heff_tag_of(v_t_24125)) {
  case TAG_EVar: {
    V v_x_24126 = heff_field(v_t_24125, 0);
    heff_take_n(v_t_24125, 1ULL, 1);
    v_t_24160 = heff_strEq_lent(v_p_241, v_x_24126, 2);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_24125, 0ULL, 1);
    v_t_24160 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_t_24125, 0ULL, 2);
    v_t_24160 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_t_24125, 0ULL, 2);
    v_t_24160 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_t_24125, 0ULL, 3);
    v_t_24160 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_24125, 0ULL, 2);
    v_t_24160 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_t_24125, 0ULL, 4);
    v_t_24160 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_t_24125, 0ULL, 3);
    v_t_24160 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_24125, 0ULL, 2);
    v_t_24160 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_24125, 0ULL, 1);
    v_t_24160 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_24125, 0ULL, 2);
    v_t_24160 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_t_24125, 0ULL, 2);
    v_t_24160 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_t_24125, 0ULL, 1);
    v_t_24160 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_na(v_t_24125, 0ULL, 1);
    v_t_24160 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_t_24125, 0ULL, 1);
    v_t_24160 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_24125, 0ULL, 1);
    v_t_24160 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_24125, 0ULL, 2);
    v_t_24160 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_24125, 0ULL, 1);
    v_t_24160 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_24160 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_t_24125, 0ULL, 2);
    v_t_24160 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_24125);
  }
  if ((heff_dup(v_t_24160) == NTAG(TAG_True))) {
    heff_drop(v_t_24160);
    V v_t_24163;
    switch (heff_tag_of(v_pr_24122)) {
    case TAG_MkPair: {
      V v_y_24162 = heff_dup(heff_field(v_pr_24122, 1));
      v_t_24163 = v_y_24162;
      break;
    }
    default: heff_nomatch(v_pr_24122);
    }
    HeffT2 v_t_24164 = ({ V a_0 = v_bor_240; V a_1 = v_g_24117; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_g_24117); r_; });
    V v_t_24169;
    {
      V v_field_24166 = v_t_24164.f[1];
      int64_t v_tag_24165 = ((int64_t)v_t_24164.f[0]);
      if ((v_tag_24165 == ((int64_t)0ULL))) {
        V v_x_24168 = v_field_24166;
        v_t_24169 = v_x_24168;
      } else {
        heff_drop(v_field_24166);
        v_t_24169 = NTAG(TAG_Nil);
      }
    }
    V v_t_24170 = ({ V a_0 = v_t_24163; V a_1 = v_t_24169; V r_ = (g_heff_2ecompile_2eborrow_2eelemI(a_0, a_1)); heff_drop(v_t_24169); r_; });
    if ((heff_dup(v_t_24170) == NTAG(TAG_True))) {
      heff_drop(v_pr_24122);
      heff_drop(v_p_241);
      heff_drop(v_bor_240);
      heff_drop(v_t_24170);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_24170);
      V v_t_24173;
      switch (heff_tag_of(v_pr_24122)) {
      case TAG_MkPair: {
        V v_x_24171 = heff_field(v_pr_24122, 0);
        heff_take_n(v_pr_24122, 1ULL, 2);
        v_t_24173 = v_x_24171;
        break;
      }
      default: heff_nomatch(v_pr_24122);
      }
      return (g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_t_24173));
    }
  } else {
    heff_drop(v_g_24117);
    heff_drop(v_t_24160);
    V v_t_24176;
    switch (heff_tag_of(v_pr_24122)) {
    case TAG_MkPair: {
      V v_x_24174 = heff_field(v_pr_24122, 0);
      heff_take_n(v_pr_24122, 1ULL, 2);
      v_t_24176 = v_x_24174;
      break;
    }
    default: heff_nomatch(v_pr_24122);
    }
    return (g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_t_24176));
  }
}
V g_heff_2ecompile_2eborrow_2ebuildsSize_lam0(V self, V *args);
V g_heff_2ecompile_2eborrow_2ebuildsSize_lam1(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2ebuildsSize_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2ebuildsSize_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2ebuildsSize(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V t_0 = v_n_240;
    V t_1 = v_b_245;
    v_n_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x2_241, 0);
    V v_as_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    return ({ V a_0 = v_t_248; V b_1 = heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_f_246, v_as_247}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x2_241, 1);
    V v_b_2411 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2412 = (g_heff_2ecompile_2eborrow_2ebuildsSize(heff_dup(v_n_240), v_a_2410));
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_n_240);
      heff_drop(v_b_2411);
      heff_drop(v_t_2412);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2412);
      V t_0 = v_n_240;
      V t_1 = v_b_2411;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  case TAG_ERecord: {
    V v_fs_2413 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2ebuildsSize_lam0, 1, 1, (V[]){v_n_240}); V a_1 = v_fs_2413; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_fs_2413); r_; });
  }
  case TAG_EProj: {
    V v_e_2419 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 4);
    V t_0 = v_n_240;
    V t_1 = v_e_2419;
    v_n_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2424 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    V v_t_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2424));
    if (heff_intEq_c_lent(v_t_2426, v_n_240, 1)) {
      heff_drop(v_n_240);
      heff_drop(v_as_2424);
      return NTAG(TAG_True);
    } else {
      V v_t_2428 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ebuildsSize_clo), 1, (V[]){v_n_240}));
      return ({ V a_0 = v_t_2428; V a_1 = v_as_2424; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2424); r_; });
    }
  }
  case TAG_EMatch: {
    V v_s_2429 = heff_field(v_x2_241, 0);
    V v_arms_2430 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2431 = (g_heff_2ecompile_2eborrow_2ebuildsSize(heff_dup(v_n_240), v_s_2429));
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop(v_n_240);
      heff_drop(v_arms_2430);
      heff_drop(v_t_2431);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2431);
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2ebuildsSize_lam1, 1, 1, (V[]){v_n_240}); V a_1 = v_arms_2430; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_arms_2430); r_; });
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_as_2439 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2440 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    return ({ V a_0 = v_t_2440; V a_1 = v_as_2439; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2439); r_; });
  }
  case TAG_ECall: {
    V v_as_2442 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2443 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    return ({ V a_0 = v_t_2443; V a_1 = v_as_2442; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2442); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2ebuildsSize_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eborrow_2ebuildsSize(a[0], a[1]);
}
V g_heff_2ecompile_2eborrow_2ebuildsSize_lam0(V self, V *args) {
  V v_f_2415 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418;
  switch (heff_tag_of(v_f_2415)) {
  case TAG_MkPair: {
    V v_y_2417 = heff_field(v_f_2415, 1);
    heff_take_n(v_f_2415, 2ULL, 2);
    v_t_2418 = v_y_2417;
    break;
  }
  default: heff_nomatch(v_f_2415);
  }
  return (g_heff_2ecompile_2eborrow_2ebuildsSize(v_n_240, v_t_2418));
}
V g_heff_2ecompile_2eborrow_2ebuildsSize_lam1(V self, V *args) {
  V v_a_2432 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436;
  switch (heff_tag_of(v_a_2432)) {
  case TAG_MkArm: {
    V v_b_2435 = heff_field(v_a_2432, 2);
    heff_take_n(v_a_2432, 4ULL, 3);
    v_t_2436 = v_b_2435;
    break;
  }
  default: heff_nomatch(v_a_2432);
  }
  return (g_heff_2ecompile_2eborrow_2ebuildsSize(v_n_240, v_t_2436));
}
V g_heff_2ecompile_2eborrow_2ereuses_lam0(V self, V *args);
V g_heff_2ecompile_2eborrow_2ereuses_lam1(V self, V *args);
V g_heff_2ecompile_2eborrow_2ereuses_lam2(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2ereuses_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2ereuses_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2ereuses(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V t_0 = v_p_240;
    V t_1 = v_b_245;
    v_p_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x2_241, 0);
    V v_as_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_248; V b_1 = heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_f_246, v_as_247}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x2_241, 1);
    V v_b_2411 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2412 = (g_heff_2ecompile_2eborrow_2ereuses(heff_dup(v_p_240), v_a_2410));
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_b_2411);
      heff_drop(v_t_2412);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2412);
      V t_0 = v_p_240;
      V t_1 = v_b_2411;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  case TAG_ERecord: {
    V v_fs_2413 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2ereuses_lam0, 1, 1, (V[]){v_p_240}); V a_1 = v_fs_2413; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_fs_2413); r_; });
  }
  case TAG_EProj: {
    V v_e_2419 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 4);
    V t_0 = v_p_240;
    V t_1 = v_e_2419;
    v_p_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2424 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    V v_t_2426 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_2426; V a_1 = v_as_2424; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2424); r_; });
  }
  case TAG_EMatch: {
    V v_s_2427 = heff_field(v_x2_241, 0);
    V v_arms_2428 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2463;
    switch (heff_tag_of(v_s_2427)) {
    case TAG_EVar: {
      V v_x_2429 = heff_dup(heff_field(v_s_2427, 0));
      v_t_2463 = heff_strEq_lent(v_p_240, v_x_2429, 2);
      break;
    }
    case TAG_EGlobal: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2463 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2427);
    }
    if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
      heff_drop(v_t_2463);
      V v_t_2464 = (g_list_2eany_24s361779565x1527579812(v_arms_2428));
      if ((heff_dup(v_t_2464) == NTAG(TAG_True))) {
        heff_drop(v_p_240);
        heff_drop(v_s_2427);
        heff_drop(v_arms_2428);
        heff_drop(v_t_2464);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2464);
        V v_t_2465 = (g_heff_2ecompile_2eborrow_2ereuses(heff_dup(v_p_240), v_s_2427));
        if ((heff_dup(v_t_2465) == NTAG(TAG_True))) {
          heff_drop(v_p_240);
          heff_drop(v_arms_2428);
          heff_drop(v_t_2465);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2465);
          return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2ereuses_lam1, 1, 1, (V[]){v_p_240}); V a_1 = v_arms_2428; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_arms_2428); r_; });
        }
      }
    } else {
      heff_drop(v_t_2463);
      V v_t_2471 = (g_heff_2ecompile_2eborrow_2ereuses(heff_dup(v_p_240), v_s_2427));
      if ((heff_dup(v_t_2471) == NTAG(TAG_True))) {
        heff_drop(v_p_240);
        heff_drop(v_arms_2428);
        heff_drop(v_t_2471);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2471);
        return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2ereuses_lam2, 1, 1, (V[]){v_p_240}); V a_1 = v_arms_2428; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_arms_2428); r_; });
      }
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_as_2479 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2480 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_2480; V a_1 = v_as_2479; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2479); r_; });
  }
  case TAG_ECall: {
    V v_as_2482 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2483 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_2483; V a_1 = v_as_2482; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2482); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2ereuses_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eborrow_2ereuses(a[0], a[1]);
}
V g_heff_2ecompile_2eborrow_2ereuses_lam0(V self, V *args) {
  V v_f_2415 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418;
  switch (heff_tag_of(v_f_2415)) {
  case TAG_MkPair: {
    V v_y_2417 = heff_field(v_f_2415, 1);
    heff_take_n(v_f_2415, 2ULL, 2);
    v_t_2418 = v_y_2417;
    break;
  }
  default: heff_nomatch(v_f_2415);
  }
  return (g_heff_2ecompile_2eborrow_2ereuses(v_p_240, v_t_2418));
}
V g_heff_2ecompile_2eborrow_2ereuses_lam1(V self, V *args) {
  V v_a_2466 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2470;
  switch (heff_tag_of(v_a_2466)) {
  case TAG_MkArm: {
    V v_b_2469 = heff_field(v_a_2466, 2);
    heff_take_n(v_a_2466, 4ULL, 3);
    v_t_2470 = v_b_2469;
    break;
  }
  default: heff_nomatch(v_a_2466);
  }
  return (g_heff_2ecompile_2eborrow_2ereuses(v_p_240, v_t_2470));
}
V g_heff_2ecompile_2eborrow_2ereuses_lam2(V self, V *args) {
  V v_a_2472 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2476;
  switch (heff_tag_of(v_a_2472)) {
  case TAG_MkArm: {
    V v_b_2475 = heff_field(v_a_2472, 2);
    heff_take_n(v_a_2472, 4ULL, 3);
    v_t_2476 = v_b_2475;
    break;
  }
  default: heff_nomatch(v_a_2472);
  }
  return (g_heff_2ecompile_2eborrow_2ereuses(v_p_240, v_t_2476));
}
V g_heff_2ecompile_2eborrow_2elentVars_lam0(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2elentVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2elentVars_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2elentVars(V v_ds_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    V v_a_249 = heff_field(v_x2_241, 1);
    V v_b_2410 = heff_field(v_x2_241, 2);
    V v_t_2411 = (g_heff_2ecompile_2eborrow_2elentVars(heff_dup(v_ds_240), v_a_249));
    V v_t_2412 = (g_heff_2ecompile_2eborrow_2elentVars(v_ds_240, v_b_2410));
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2411, v_t_2412);
  }
  case TAG_ERecord: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    V v_s_2422 = heff_field(v_x2_241, 0);
    V v_arms_2423 = heff_field(v_x2_241, 1);
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2423)));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2elentVars_lam0, 2, 2, (V[]){heff_dup(v_s_2422), v_ds_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2424; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
  }
  case TAG_EPrim: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2elentVars_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eborrow_2elentVars(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eborrow_2elentVars_lam0(V self, V *args) {
  V v_acc_2425 = args[0];
  V v_x_2426 = args[1];
  V v_s_2422 = heff_env(self)[0];
  V v_ds_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2461;
  switch (heff_tag_of(v_s_2422)) {
  case TAG_EVar: {
    V v_x_2427 = heff_field(v_s_2422, 0);
    heff_take_n(v_s_2422, 1ULL, 1);
    v_t_2461 = ({ V a_0 = v_x_2427; V a_1 = v_ds_240; V r_ = (g_heff_2ecompile_2eborrow_2eelemS(a_0, a_1)); heff_drop(v_x_2427); r_; });
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_s_2422, 0ULL, 1);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_s_2422, 0ULL, 3);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_s_2422, 0ULL, 4);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_s_2422, 0ULL, 3);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_s_2422, 0ULL, 1);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_s_2422, 0ULL, 1);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_na(v_s_2422, 0ULL, 1);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_s_2422, 0ULL, 1);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_s_2422, 0ULL, 1);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_s_2422, 0ULL, 1);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_s_2422, 0ULL, 2);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_s_2422);
  }
  V v_t_2480;
  if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
    heff_drop(v_t_2461);
    V v_t_2465;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_MkArm: {
      V v_vs_2463 = heff_dup(heff_field(v_x_2426, 1));
      v_t_2465 = v_vs_2463;
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    V v_t_2469;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_MkArm: {
      V v_vs_2467 = heff_dup(heff_field(v_x_2426, 1));
      v_t_2469 = v_vs_2467;
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    V v_t_2470 = (g_prelude_2e_2b_2b(v_t_2469, v_ds_240));
    V v_t_2474;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_MkArm: {
      V v_b_2473 = heff_field(v_x_2426, 2);
      heff_take_n(v_x_2426, 4ULL, 3);
      v_t_2474 = v_b_2473;
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    V v_t_2475 = ({ V a_0 = v_t_2470; V a_1 = v_t_2474; V r_ = (g_heff_2ecompile_2eborrow_2elentVars(a_0, a_1)); heff_drop(v_t_2474); r_; });
    v_t_2480 = (g_prelude_2e_2b_2b(v_t_2465, v_t_2475));
  } else {
    heff_drop(v_t_2461);
    V v_t_2479;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_MkArm: {
      V v_b_2478 = heff_field(v_x_2426, 2);
      heff_take_n(v_x_2426, 4ULL, 3);
      v_t_2479 = v_b_2478;
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    v_t_2480 = ({ V a_0 = v_ds_240; V a_1 = v_t_2479; V r_ = (g_heff_2ecompile_2eborrow_2elentVars(a_0, a_1)); heff_drop(v_t_2479); r_; });
  }
  return (g_prelude_2e_2b_2b(v_t_2480, v_acc_2425));
}
V g_heff_2ecompile_2eborrow_2eloopLent_lam0(V self, V *args);
V g_heff_2ecompile_2eborrow_2eloopLent_lam1(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2eloopLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eloopLent_entry, 4, 0};

V g_heff_2ecompile_2eborrow_2eloopLent(V v_key_240, V v_i_241, V v_ds_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_EVar: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_x4_243, 0);
    V v_as_249 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24EApp = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
    return ({ V a_0 = v_t_2410; V b_1 = heff_tag_at_n(v_ru_24x4_243_24EApp, TAG_Cons, 2, (V[]){v_f_248, v_as_249}); V r_ = (g_list_2eall(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2412 = heff_field(v_x4_243, 1);
    V v_b_2413 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 6ULL, 3);
    V v_t_2414 = (g_heff_2ecompile_2eborrow_2eloopLent(heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242), v_a_2412));
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_t_2414);
      V t_0 = v_key_240;
      V t_1 = v_i_241;
      V t_2 = v_ds_242;
      V t_3 = v_b_2413;
      v_key_240 = t_0;
      v_i_241 = t_1;
      v_ds_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_key_240);
      heff_drop(v_i_241);
      heff_drop(v_ds_242);
      heff_drop(v_b_2413);
      heff_drop(v_t_2414);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EProj: {
    heff_take_n(v_x4_243, 0ULL, 4);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_ETag: {
    V v_as_2422 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 2ULL, 3);
    V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
    return ({ V a_0 = v_t_2424; V a_1 = v_as_2422; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2422); r_; });
  }
  case TAG_EMatch: {
    V v_s_2425 = heff_field(v_x4_243, 0);
    V v_arms_2426 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_2427 = (g_heff_2ecompile_2eborrow_2eloopLent(heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242), v_s_2425));
    if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
      heff_drop(v_t_2427);
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eloopLent_lam0, 1, 3, (V[]){v_key_240, v_i_241, v_ds_242}); V a_1 = v_arms_2426; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2426); r_; });
    } else {
      heff_drop(v_key_240);
      heff_drop(v_i_241);
      heff_drop(v_ds_242);
      heff_drop(v_arms_2426);
      heff_drop(v_t_2427);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_ECall: {
    V v_g_2436 = heff_field(v_x4_243, 0);
    V v_as_2437 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    if (heff_strEq_c_lent(v_g_2436, v_key_240, 1)) {
      V v_t_2439 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2437));
      V v_t_2440 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2439, MK_INT(1LL))));
      V v_t_2441 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_as_2437), v_t_2440));
      V v_t_2447 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eloopLent_lam1, 1, 2, (V[]){heff_dup(v_i_241), heff_dup(v_ds_242)}); V a_1 = v_t_2441; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2441); r_; });
      if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
        heff_drop(v_t_2447);
        V v_t_2448 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
        return ({ V a_0 = v_t_2448; V a_1 = v_as_2437; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2437); r_; });
      } else {
        heff_drop(v_key_240);
        heff_drop(v_i_241);
        heff_drop(v_ds_242);
        heff_drop(v_as_2437);
        heff_drop(v_t_2447);
        return NTAG(TAG_False);
      }
    } else {
      V v_t_2449 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
      return ({ V a_0 = v_t_2449; V a_1 = v_as_2437; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2437); r_; });
    }
  }
  case TAG_EInt: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_take_na(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFix: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eborrow_2eloopLent_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eborrow_2eloopLent(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eborrow_2eloopLent_lam0(V self, V *args) {
  V v_a_2428 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_ds_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2432;
  switch (heff_tag_of(v_a_2428)) {
  case TAG_MkArm: {
    V v_b_2431 = heff_field(v_a_2428, 2);
    heff_take_n(v_a_2428, 4ULL, 3);
    v_t_2432 = v_b_2431;
    break;
  }
  default: heff_nomatch(v_a_2428);
  }
  return (g_heff_2ecompile_2eborrow_2eloopLent(v_key_240, v_i_241, v_ds_242, v_t_2432));
}
V g_heff_2ecompile_2eborrow_2eloopLent_lam1(V self, V *args) {
  V v_pr_2442 = args[0];
  V v_i_241 = heff_env(self)[0];
  V v_ds_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2445;
  switch (heff_tag_of(v_pr_2442)) {
  case TAG_MkPair: {
    V v_y_2444 = heff_dup(heff_field(v_pr_2442, 1));
    v_t_2445 = v_y_2444;
    break;
  }
  default: heff_nomatch(v_pr_2442);
  }
  if (heff_intEq_c(v_t_2445, v_i_241)) {
    return ({ V a_0 = v_pr_2442; V a_1 = v_ds_242; V r_ = (g_list_2eany_24s1579866964x445286031(a_0, a_1)); heff_drop(v_pr_2442); heff_drop(v_ds_242); r_; });
  } else {
    heff_drop(v_pr_2442);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
}
V g_heff_2ecompile_2eborrow_2eborDef_lam0(V self, V *args);
V g_heff_2ecompile_2eborrow_2eborDef_lam1(V self, V *args);
V g_heff_2ecompile_2eborrow_2eborDef_lam2(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2eborDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eborDef_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2eborDef(V v_bor_240, V v_d_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_d_241, 2));
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    V v_b_246 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 3ULL, 2);
    HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_bor_240, heff_rfield(v_d_241, 0)));
    V v_t_2421;
    {
      V v_field_249 = v_t_247.f[1];
      V v_tag_248 = heff_box_i64(((int64_t)v_t_247.f[0]));
      V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_245));
      V v_t_2411 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2410, MK_INT(1LL))));
      V v_t_2412 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_245), v_t_2411));
      V v_t_2420 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eborrow_2eborDef_lam0, 1, 2, (V[]){v_tag_248, v_field_249}), v_t_2412));
      v_t_2421 = (g_list_2emap_24s1937570095x2110149801(v_t_2420));
    }
    HeffT2 v_t_2422 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_bor_240, heff_rfield(v_d_241, 0)));
    V v_t_2436;
    {
      V v_field_2424 = v_t_2422.f[1];
      V v_tag_2423 = heff_box_i64(((int64_t)v_t_2422.f[0]));
      V v_t_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_245));
      V v_t_2426 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2425, MK_INT(1LL))));
      V v_t_2427 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_245), v_t_2426));
      V v_t_2435 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eborrow_2eborDef_lam1, 1, 2, (V[]){v_tag_2423, v_field_2424}), v_t_2427));
      v_t_2436 = (g_list_2emap_24s1937570095x2110149801(v_t_2435));
    }
    V v_t_2437 = (g_heff_2ecompile_2eborrow_2elentVars(v_t_2436, v_b_246));
    V v_ds_2438 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2437));
    HeffT2 v_t_2439 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_bor_240, heff_rfield(v_d_241, 0)));
    V v_t_2444;
    {
      V v_field_2441 = v_t_2439.f[1];
      int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
      if ((v_tag_2440 == ((int64_t)0ULL))) {
        V v_x_2443 = v_field_2441;
        v_t_2444 = v_x_2443;
      } else {
        heff_drop(v_field_2441);
        v_t_2444 = NTAG(TAG_Nil);
      }
    }
    V v_t_2455 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eborrow_2eborDef_lam2, 1, 5, (V[]){v_xs_245, heff_dup(v_bor_240), v_b_246, heff_dup(v_d_241), v_ds_2438}), v_t_2444));
    return (g_std_2emap_2einsert_24s1305793909x1049798133(v_bor_240, heff_get_n(v_d_241, 0, 3), v_t_2455));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 4);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EFloat: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_bor_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eborrow_2eborDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eborrow_2eborDef(a[0], a[1]);
}
V g_heff_2ecompile_2eborrow_2eborDef_lam0(V self, V *args) {
  V v_p_2413 = args[0];
  V v_tag_248 = heff_env(self)[0];
  V v_field_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416;
  switch (heff_tag_of(v_p_2413)) {
  case TAG_MkPair: {
    V v_y_2415 = heff_field(v_p_2413, 1);
    heff_take_n(v_p_2413, 2ULL, 2);
    v_t_2416 = v_y_2415;
    break;
  }
  default: heff_nomatch(v_p_2413);
  }
  V v_t_2419;
  if ((heff_unbox_i64(v_tag_248) == ((int64_t)0ULL))) {
    V v_x_2418 = v_field_249;
    v_t_2419 = v_x_2418;
  } else {
    heff_drop(v_field_249);
    v_t_2419 = NTAG(TAG_Nil);
  }
  return ({ V a_0 = v_t_2416; V a_1 = v_t_2419; V r_ = (g_heff_2ecompile_2eborrow_2eelemI(a_0, a_1)); heff_drop(v_t_2419); r_; });
}
V g_heff_2ecompile_2eborrow_2eborDef_lam1(V self, V *args) {
  V v_p_2428 = args[0];
  V v_tag_2423 = heff_env(self)[0];
  V v_field_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431;
  switch (heff_tag_of(v_p_2428)) {
  case TAG_MkPair: {
    V v_y_2430 = heff_field(v_p_2428, 1);
    heff_take_n(v_p_2428, 2ULL, 2);
    v_t_2431 = v_y_2430;
    break;
  }
  default: heff_nomatch(v_p_2428);
  }
  V v_t_2434;
  if ((heff_unbox_i64(v_tag_2423) == ((int64_t)0ULL))) {
    V v_x_2433 = v_field_2424;
    v_t_2434 = v_x_2433;
  } else {
    heff_drop(v_field_2424);
    v_t_2434 = NTAG(TAG_Nil);
  }
  return ({ V a_0 = v_t_2431; V a_1 = v_t_2434; V r_ = (g_heff_2ecompile_2eborrow_2eelemI(a_0, a_1)); heff_drop(v_t_2434); r_; });
}
V g_heff_2ecompile_2eborrow_2eborDef_lam2(V self, V *args) {
  V v_i_2445 = args[0];
  V v_xs_245 = heff_env(self)[0];
  V v_bor_240 = heff_env(self)[1];
  V v_b_246 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_ds_2438 = heff_env(self)[4];
  heff_clo_take(self, 5);
  HeffT3 v_t_2446 = ({ V a_0 = heff_dup(v_i_2445); V a_1 = v_xs_245; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_xs_245); r_; });
  {
    V v_field_2448 = v_t_2446.f[1];
    V v_field_2449 = v_t_2446.f[2];
    int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
    if ((v_tag_2447 == ((int64_t)0ULL))) {
      V v_p_2451 = v_field_2448;
      V v_x_2452 = v_field_2449;
      heff_drop(v_x_2452);
      V v_t_2453 = (g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, heff_dup(v_p_2451), heff_dup(v_b_246)));
      if ((heff_dup(v_t_2453) == NTAG(TAG_True))) {
        heff_drop(v_t_2453);
        V v_x1_2454 = (g_heff_2ecompile_2eborrow_2ereuses(v_p_2451, heff_dup(v_b_246)));
        if ((heff_dup(v_x1_2454) == NTAG(TAG_True))) {
          heff_drop(v_i_2445);
          heff_drop(v_b_246);
          heff_drop_rec(v_d_241, 3);
          heff_drop(v_ds_2438);
          heff_drop(v_x1_2454);
          return NTAG(TAG_False);
        } else {
          heff_drop(v_x1_2454);
          return (g_heff_2ecompile_2eborrow_2eloopLent(heff_get_n(v_d_241, 0, 3), v_i_2445, v_ds_2438, v_b_246));
        }
      } else {
        heff_drop(v_i_2445);
        heff_drop(v_b_246);
        heff_drop_rec(v_d_241, 3);
        heff_drop(v_ds_2438);
        heff_drop(v_p_2451);
        heff_drop(v_t_2453);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_i_2445);
      heff_drop(v_bor_240);
      heff_drop(v_b_246);
      heff_drop_rec(v_d_241, 3);
      heff_drop(v_ds_2438);
      heff_drop(v_field_2448);
      heff_drop(v_field_2449);
      return NTAG(TAG_False);
    }
  }
}
Clo g_heff_2ecompile_2eborrow_2eborFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eborFix_entry, 3, 0};

V g_heff_2ecompile_2eborrow_2eborFix(V v_defs_240, V v_size_241, V v_bor_242) {
top: ;
  V v_t_243 = (g_std_2emap_2etoListOnto(v_bor_242, NTAG(TAG_Nil)));
  V v_t_244 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(1LL); V a_2 = MK_INT(0LL); V a_3 = v_t_243; V r_ = (g_list_2efoldl_24f1922461191x750914054(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
  if (heff_intEq_c(v_t_244, v_size_241)) {
    return v_bor_242;
  } else {
    V v_t_246 = (g_std_2emap_2etoListOnto(v_bor_242, NTAG(TAG_Nil)));
    V v_t_247 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(1LL); V a_2 = MK_INT(0LL); V a_3 = v_t_246; V r_ = (g_list_2efoldl_24f1922461191x750914054(a_0, a_1, a_2, a_3)); heff_drop(v_t_246); r_; });
    V v_t_248 = (g_list_2efoldl_24s1416922510x485352908(v_bor_242, v_defs_240));
    V t_0 = v_defs_240;
    V t_1 = v_t_247;
    V t_2 = v_t_248;
    v_defs_240 = t_0;
    v_size_241 = t_1;
    v_bor_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eborrow_2eborFix_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eborrow_2eborFix(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eborrow_2eborAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eborAll_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2eborAll(V v_m_240, V v_d_241) {
top: ;
  V v_t_242 = heff_take_field(v_d_241, 2);
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_245; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    V v_t_248 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_247, MK_INT(1LL))));
    return (g_std_2emap_2einsert_24s1305793909x1049798133(v_m_240, heff_get_n(v_d_241, 0, 3), v_t_248));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 4);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eborrow_2eborAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eborrow_2eborAll(a[0], a[1]);
}