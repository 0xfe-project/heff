// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_body 9524841
#define LBL_key 315609
#define LBL_n 328
#define LBL_name 9869138
#define LBL_out 319944
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_out__n[] = {LBL_out, LBL_n};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2elift_2efreeGo(V, V, V);
V g_heff_2ecompile_2elift_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2efreeGo_clo;
V g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862(V, V, V, V);
V g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_clo;
V g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069(V, V, V, V);
V g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_clo;
V g_heff_2ecompile_2elift_2eliftFixDef_24s1197825217x45906855(V, V, V);
V g_heff_2ecompile_2elift_2eliftFixDef_24s1197825217x45906855_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eliftFixDef_24s1197825217x45906855_clo;
V g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(V, V, V);
V g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_clo;
V g_heff_2ecompile_2elift_2eliftGo_24s1117140028x479981506(V, V, V);
V g_heff_2ecompile_2elift_2eliftGo_24s1117140028x479981506_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eliftGo_24s1117140028x479981506_clo;
V g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(V, V, V);
V g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_clo;
V g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750(V, V, V, V, V);
V g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_clo;
V g_heff_2ecompile_2elift_2eliftedDef(V, V, V, V, V);
V g_heff_2ecompile_2elift_2eliftedDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eliftedDef_clo;
V g_heff_2ecompile_2elift_2eoneParam(V);
V g_heff_2ecompile_2elift_2eoneParam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eoneParam_clo;
V g_heff_2ecompile_2elift_2ereplaceGo(V, V, V);
V g_heff_2ecompile_2elift_2ereplaceGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2ereplaceGo_clo;
V g_heff_2ecompile_2elift_2ewithParams(V, V);
V g_heff_2ecompile_2elift_2ewithParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2ewithParams_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_list_2ezipWith_24s738847920x410598254(V, V);
V g_list_2ezipWith_24s738847920x410598254_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_clo;
V g_heff_2ecompile_2elift_2efreeGo_lam0(V self, V *args);
V g_heff_2ecompile_2elift_2efreeGo_lam1(V self, V *args);
V g_heff_2ecompile_2elift_2efreeGo_lam2(V self, V *args);
V g_heff_2ecompile_2elift_2efreeGo_lam3(V self, V *args);
V g_heff_2ecompile_2elift_2efreeGo_lam4(V self, V *args);
V g_heff_2ecompile_2elift_2efreeGo_lam5(V self, V *args);
Clo g_heff_2ecompile_2elift_2efreeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2efreeGo_entry, 3, 0};

V g_heff_2ecompile_2elift_2efreeGo(V v_bound_240, V v_e_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_t_244 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_243)}));
    V v_t_245 = ({ V a_0 = v_t_244; V a_1 = v_bound_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_bound_240); r_; });
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_x_243);
      return v_acc_242;
    }
    case TAG_False: {
      V v_t_246 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_243)}));
      V v_t_247 = (g_list_2eany(v_t_246, v_acc_242));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_x_243);
        return v_acc_242;
      }
      case TAG_False: {
        return heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_acc_242});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_ELam: {
    V v_xs_249 = heff_field(v_e_241, 0);
    V v_b_2410 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2411 = (g_heff_2ecompile_2eir_2eappendI(v_xs_249, v_bound_240));
    V t_0 = v_t_2411;
    V t_1 = v_b_2410;
    V t_2 = v_acc_242;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_e_241, 0);
    V v_as_2413 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2414 = (g_heff_2ecompile_2elift_2efreeGo(heff_dup(v_bound_240), v_f_2412, v_acc_242));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam0, 2, 1, (V[]){v_bound_240}); V a_1 = v_t_2414; V a_2 = v_as_2413; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_as_2413); r_; });
  }
  case TAG_ELet: {
    V v_x_2417 = heff_field(v_e_241, 0);
    V v_a_2418 = heff_field(v_e_241, 1);
    V v_b_2419 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_t_2420 = (g_heff_2ecompile_2elift_2efreeGo(heff_dup(v_bound_240), v_a_2418, v_acc_242));
    V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2417, v_bound_240});
    V t_1 = v_b_2419;
    V t_2 = v_t_2420;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2421 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam1, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_fs_2421; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2421); r_; });
  }
  case TAG_EProj: {
    V v_x_2427 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 3);
    V t_0 = v_bound_240;
    V t_1 = v_x_2427;
    V t_2 = v_acc_242;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_es_2431 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam2, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_es_2431; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_2431); r_; });
  }
  case TAG_EMatch: {
    V v_x_2434 = heff_field(v_e_241, 0);
    V v_arms_2435 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2436 = (g_heff_2ecompile_2elift_2efreeGo(heff_dup(v_bound_240), v_x_2434, v_acc_242));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam3, 2, 1, (V[]){v_bound_240}); V a_1 = v_t_2436; V a_2 = v_arms_2435; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_arms_2435); r_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EPrimCall: {
    V v_es_2450 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam4, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_es_2450; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_2450); r_; });
  }
  case TAG_ECall: {
    V v_es_2454 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam5, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_es_2454; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_2454); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EFloat: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EFloat32: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EAbandon: {
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EFix: {
    V v_f_2463 = heff_field(v_e_241, 0);
    V v_b_2464 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EFix = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V t_0 = heff_tag_at_n(v_ru_24e_241_24EFix, TAG_Cons, 2, (V[]){v_f_2463, v_bound_240});
    V t_1 = v_b_2464;
    V t_2 = v_acc_242;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2elift_2efreeGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2efreeGo(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2elift_2efreeGo_lam0(V self, V *args) {
  V v_a_2415 = args[0];
  V v_x_2416 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2elift_2efreeGo(v_bound_240, v_x_2416, v_a_2415));
}
V g_heff_2ecompile_2elift_2efreeGo_lam1(V self, V *args) {
  V v_a_2422 = args[0];
  V v_f_2423 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426;
  switch (heff_tag_of(v_f_2423)) {
  case TAG_MkPair: {
    V v_y_2425 = heff_field(v_f_2423, 1);
    heff_take_n(v_f_2423, 2ULL, 2);
    v_t_2426 = v_y_2425;
    break;
  }
  default: heff_nomatch(v_f_2423);
  }
  return (g_heff_2ecompile_2elift_2efreeGo(v_bound_240, v_t_2426, v_a_2422));
}
V g_heff_2ecompile_2elift_2efreeGo_lam2(V self, V *args) {
  V v_a_2432 = args[0];
  V v_x_2433 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2elift_2efreeGo(v_bound_240, v_x_2433, v_a_2432));
}
V g_heff_2ecompile_2elift_2efreeGo_lam3(V self, V *args) {
  V v_a_2437 = args[0];
  V v_arm_2438 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442;
  switch (heff_tag_of(v_arm_2438)) {
  case TAG_MkArm: {
    V v_vs_2440 = heff_dup(heff_field(v_arm_2438, 1));
    v_t_2442 = v_vs_2440;
    break;
  }
  default: heff_nomatch(v_arm_2438);
  }
  V v_t_2443 = (g_heff_2ecompile_2eir_2eappendI(v_t_2442, v_bound_240));
  V v_t_2447;
  switch (heff_tag_of(v_arm_2438)) {
  case TAG_MkArm: {
    V v_b_2446 = heff_field(v_arm_2438, 2);
    heff_take_n(v_arm_2438, 4ULL, 3);
    v_t_2447 = v_b_2446;
    break;
  }
  default: heff_nomatch(v_arm_2438);
  }
  return (g_heff_2ecompile_2elift_2efreeGo(v_t_2443, v_t_2447, v_a_2437));
}
V g_heff_2ecompile_2elift_2efreeGo_lam4(V self, V *args) {
  V v_a_2451 = args[0];
  V v_x_2452 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2elift_2efreeGo(v_bound_240, v_x_2452, v_a_2451));
}
V g_heff_2ecompile_2elift_2efreeGo_lam5(V self, V *args) {
  V v_a_2455 = args[0];
  V v_x_2456 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2elift_2efreeGo(v_bound_240, v_x_2456, v_a_2455));
}
V g_heff_2ecompile_2elift_2ereplaceGo_lam0(V self, V *args);
V g_heff_2ecompile_2elift_2ereplaceGo_lam1(V self, V *args);
Clo g_heff_2ecompile_2elift_2ereplaceGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2ereplaceGo_entry, 3, 0};

V g_heff_2ecompile_2elift_2ereplaceGo(V v_x_240, V v_r_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_dup(heff_field(v_e_242, 0));
    if (heff_strEq_c(v_y_243, v_x_240)) {
      heff_drop_tag(v_e_242, 1);
      return v_r_241;
    } else {
      heff_drop(v_r_241);
      return v_e_242;
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_242, 0);
    V v_b_247 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24e_242_24ELam, TAG_ELam, 2, (V[]){v_xs_246, (g_heff_2ecompile_2elift_2ereplaceGo(v_x_240, v_r_241, v_b_247))});
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_e_242, 0);
    V v_as_249 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2410 = (g_heff_2ecompile_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_f_248));
    V v_t_2411 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    return heff_tag_at_n(v_ru_24e_242_24EApp, TAG_EApp, 2, (V[]){v_t_2410, (g_list_2emap(v_t_2411, v_as_249))});
  }
  case TAG_ELet: {
    V v_y_2412 = heff_field(v_e_242, 0);
    V v_a_2413 = heff_field(v_e_242, 1);
    V v_b_2414 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2415 = (g_heff_2ecompile_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_a_2413));
    return heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_y_2412, v_t_2415, (g_heff_2ecompile_2elift_2ereplaceGo(v_x_240, v_r_241, v_b_2414))});
  }
  case TAG_ERecord: {
    V v_fs_2416 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24e_242_24ERecord, TAG_ERecord, 1, (V[]){(g_list_2emap(heff_clo_n(g_heff_2ecompile_2elift_2ereplaceGo_lam0, 1, 2, (V[]){v_x_240, v_r_241}), v_fs_2416))});
  }
  case TAG_EProj: {
    V v_y_2424 = heff_field(v_e_242, 0);
    V v_l_2425 = heff_field(v_e_242, 1);
    V v_sh_2426 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24EProj = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2427 = (g_heff_2ecompile_2elift_2ereplaceGo(v_x_240, v_r_241, v_y_2424));
    return heff_tag_at_n(v_ru_24e_242_24EProj, TAG_EProj, 3, (V[]){v_t_2427, v_l_2425, v_sh_2426});
  }
  case TAG_ETag: {
    V v_t_2428 = heff_field(v_e_242, 0);
    V v_es_2429 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2430 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    return heff_tag_at_n(v_ru_24e_242_24ETag, TAG_ETag, 2, (V[]){v_t_2428, (g_list_2emap(v_t_2430, v_es_2429))});
  }
  case TAG_EMatch: {
    V v_y_2431 = heff_field(v_e_242, 0);
    V v_arms_2432 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2433 = (g_heff_2ecompile_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_y_2431));
    return heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_t_2433, (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elift_2ereplaceGo_lam1, 1, 2, (V[]){v_x_240, v_r_241}), v_arms_2432))});
  }
  case TAG_EPrim: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EPrimCall: {
    V v_p_2448 = heff_field(v_e_242, 0);
    V v_es_2449 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2450 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    return heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2448, (g_list_2emap(v_t_2450, v_es_2449))});
  }
  case TAG_ECall: {
    V v_k_2451 = heff_field(v_e_242, 0);
    V v_es_2452 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2453 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    return heff_tag_at_n(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){v_k_2451, (g_list_2emap(v_t_2453, v_es_2452))});
  }
  case TAG_EInt: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EFloat: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EStr: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EFixed: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EFloat32: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EFix: {
    V v_f_2460 = heff_field(v_e_242, 0);
    V v_b_2461 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EFix = heff_take_reuse_n(v_e_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24e_242_24EFix, TAG_EFix, 2, (V[]){v_f_2460, (g_heff_2ecompile_2elift_2ereplaceGo(v_x_240, v_r_241, v_b_2461))});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2elift_2ereplaceGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2ereplaceGo(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2elift_2ereplaceGo_lam0(V self, V *args) {
  V v_f_2417 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_r_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420;
  switch (heff_tag_of(v_f_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_dup(heff_field(v_f_2417, 0));
    v_t_2420 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_f_2417);
  }
  V v_t_2423;
  switch (heff_tag_of(v_f_2417)) {
  case TAG_MkPair: {
    V v_y_2422 = heff_field(v_f_2417, 1);
    heff_take_n(v_f_2417, 2ULL, 2);
    v_t_2423 = v_y_2422;
    break;
  }
  default: heff_nomatch(v_f_2417);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2420, (g_heff_2ecompile_2elift_2ereplaceGo(v_x_240, v_r_241, v_t_2423))});
}
V g_heff_2ecompile_2elift_2ereplaceGo_lam1(V self, V *args) {
  V v_arm_2434 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_r_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2438;
  switch (heff_tag_of(v_arm_2434)) {
  case TAG_MkArm: {
    V v_t_2435 = heff_dup(heff_field(v_arm_2434, 0));
    v_t_2438 = v_t_2435;
    break;
  }
  default: heff_nomatch(v_arm_2434);
  }
  V v_t_2442;
  switch (heff_tag_of(v_arm_2434)) {
  case TAG_MkArm: {
    V v_vs_2440 = heff_dup(heff_field(v_arm_2434, 1));
    v_t_2442 = v_vs_2440;
    break;
  }
  default: heff_nomatch(v_arm_2434);
  }
  V v_t_2446;
  switch (heff_tag_of(v_arm_2434)) {
  case TAG_MkArm: {
    V v_b_2445 = heff_field(v_arm_2434, 2);
    heff_take_n(v_arm_2434, 4ULL, 3);
    v_t_2446 = v_b_2445;
    break;
  }
  default: heff_nomatch(v_arm_2434);
  }
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2438, v_t_2442, (g_heff_2ecompile_2elift_2ereplaceGo(v_x_240, v_r_241, v_t_2446))});
}
Clo g_heff_2ecompile_2elift_2ewithParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2ewithParams_entry, 2, 0};

V g_heff_2ecompile_2elift_2ewithParams(V v_fvs_240, V v_b_241) {
top: ;
  switch (heff_tag_of(v_fvs_240)) {
  case TAG_Nil: {
    return v_b_241;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_b_241)) {
    case TAG_EVar: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EGlobal: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_b_241, 0);
      V v_b2_247 = heff_field(v_b_241, 1);
      V v_ru_24b_241_24ELam = heff_take_reuse_n(v_b_241, 3ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2eir_2eappendI(v_fvs_240, v_xs_246));
      return heff_tag_at_n(v_ru_24b_241_24ELam, TAG_ELam, 2, (V[]){v_t_248, v_b2_247});
    }
    case TAG_EApp: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_ELet: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_ERecord: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EProj: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_ETag: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EMatch: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EPrim: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EPrimCall: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_ECall: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EInt: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EFloat: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EStr: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EFixed: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EFloat32: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EAbandon: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EFix: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  default: return heff_nomatch(v_fvs_240);
  }
}
V g_heff_2ecompile_2elift_2ewithParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2ewithParams(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2elift_2eliftedDef_str0, 1, (46));
HEFF_STRA(g_heff_2ecompile_2elift_2eliftedDef_str1, 1, (36));
HEFF_STRA(g_heff_2ecompile_2elift_2eliftedDef_str2, 1, (46));
HEFF_STRA(g_heff_2ecompile_2elift_2eliftedDef_str3, 1, (46));
HEFF_STRA(g_heff_2ecompile_2elift_2eliftedDef_str4, 1, (36));
Clo g_heff_2ecompile_2elift_2eliftedDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2eliftedDef_entry, 5, 0};

V g_heff_2ecompile_2elift_2eliftedDef(V v_d_240, V v_n_241, V v_f_242, V v_fvs_243, V v_body_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_f_242), MK_INT(0LL)));
  V v_key_246 = heff_strAppend(heff_dup(heff_rfield(v_d_240, 0)), heff_strAppend(((V)&g_heff_2ecompile_2elift_2eliftedDef_str0), heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ecompile_2elift_2eliftedDef_str1), heff_intShow(heff_dup(v_n_241))))));
  V v_name_247 = heff_strAppend(heff_take_field(v_d_240, 1), heff_strAppend(((V)&g_heff_2ecompile_2elift_2eliftedDef_str2), (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_f_242), MK_INT(0LL)))));
  V v_t_248 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_f_242), MK_INT(0LL)));
  V v_key_249 = heff_strAppend(heff_get_n(v_d_240, 0, 3), heff_strAppend(((V)&g_heff_2ecompile_2elift_2eliftedDef_str3), heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ecompile_2elift_2eliftedDef_str4), heff_intShow(v_n_241)))));
  V v_t_2412;
  switch (heff_tag_of(v_fvs_243)) {
  case TAG_Nil: {
    v_t_2412 = heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_249});
    break;
  }
  case TAG_Cons: {
    v_t_2412 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_249}), (g_list_2emap_24s1809017761x1063871171(heff_dup(v_fvs_243)))});
    break;
  }
  default: heff_nomatch(v_fvs_243);
  }
  V v_t_2413 = (g_heff_2ecompile_2elift_2ereplaceGo(v_f_242, v_t_2412, v_body_244));
  V v_body_2414 = (g_heff_2ecompile_2elift_2ewithParams(v_fvs_243, v_t_2413));
  return heff_rec_n(3, shape_key__name__body, (V[]){v_key_246, v_name_247, v_body_2414});
}
V g_heff_2ecompile_2elift_2eliftedDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2eliftedDef(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2elift_2eoneParam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2eoneParam_entry, 1, 0};

V g_heff_2ecompile_2elift_2eoneParam(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_e_240, 0);
    V v_b_244 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ELam = heff_take_reuse_n(v_e_240, 3ULL, 2);
    switch (heff_tag_of(v_xs_243)) {
    case TAG_Nil: {
      heff_drop(v_b_244);
      heff_drop_cell(v_ru_24e_240_24ELam, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_xs_243, 0);
      V v_it2_246 = heff_field(v_xs_243, 1);
      heff_take_n(v_xs_243, 3ULL, 2);
      switch (heff_tag_of(v_it2_246)) {
      case TAG_Nil: {
        return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24e_240_24ELam, TAG_MkPair, 2, (V[]){v_x_245, v_b_244})});
      }
      case TAG_Cons: {
        heff_take_n(v_it2_246, 0ULL, 2);
        heff_drop(v_b_244);
        heff_drop_cell(v_ru_24e_240_24ELam, 2);
        heff_drop(v_x_245);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_it2_246);
      }
    }
    default: return heff_nomatch(v_xs_243);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2elift_2eoneParam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2eoneParam(a[0]);
}
Clo g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_entry, 3, 0};

V g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(V v_d_240, V v_acc_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_d_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_acc_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_xs_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(heff_dup(v_d_240), v_acc_241, v_x_243));
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_x2_246 = heff_field(v_t_245, 0);
      V v_acc2_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 3ULL, 2);
      V v_x2_248 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(v_d_240, v_acc2_247, v_xs_244));
      switch (heff_tag_of(v_x2_248)) {
      case TAG_MkPair: {
        V v_xs_249 = heff_field(v_x2_248, 0);
        V v_acc_2410 = heff_field(v_x2_248, 1);
        heff_take_n(v_x2_248, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x2_246, v_xs_249}), v_acc_2410});
      }
      default: return heff_nomatch(v_x2_248);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2elift_2eliftFixDef_24s1197825217x45906855_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2eliftFixDef_24s1197825217x45906855_entry, 3, 0};

V g_heff_2ecompile_2elift_2eliftFixDef_24s1197825217x45906855(V v_acc_240, V v_fvs_241, V v_ld_242) {
top: ;
  V v_t_243 = heff_intAdd(heff_take_field(v_acc_240, 1), MK_INT(1LL));
  V v_t_244 = ({ V rv_1 = v_t_243; V rr_ = heff_rec_reuse_n(v_acc_240, 1ULL, 2, shape_out__n); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_245 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(heff_dup(v_ld_242), v_t_244, heff_dup(heff_rfield(v_ld_242, 2))));
  switch (heff_tag_of(v_t_245)) {
  case TAG_MkPair: {
    V v_b2_246 = heff_field(v_t_245, 0);
    V v_acc2_247 = heff_field(v_t_245, 1);
    V v_ru_24t_245_24MkPair = heff_take_reuse_n(v_t_245, 3ULL, 2);
    V v_key_248 = heff_dup(heff_rfield(v_ld_242, 0));
    V v_t_2411;
    switch (heff_tag_of(v_fvs_241)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24t_245_24MkPair, 2);
      v_t_2411 = heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_248});
      break;
    }
    case TAG_Cons: {
      v_t_2411 = heff_tag_at_n(v_ru_24t_245_24MkPair, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_248}), (g_list_2emap_24s1809017761x1063871171(v_fvs_241))});
      break;
    }
    default: heff_nomatch(v_fvs_241);
    }
    V v_t_2412 = ({ V rv_2 = v_b2_246; V rr_ = heff_rec_reuse_n(v_ld_242, 3ULL, 3, shape_key__name__body); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, heff_take_field(v_acc2_247, 0)});
    V v_t_2414 = ({ V rv_0 = v_t_2413; V rr_ = heff_rec_reuse_n(v_acc2_247, 2ULL, 2, shape_out__n); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_t_2414});
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ecompile_2elift_2eliftFixDef_24s1197825217x45906855_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2eliftFixDef_24s1197825217x45906855(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_entry, 4, 0};

V g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069(V v_d_240, V v_acc_241, V v_f_242, V v_body_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_f_242), NTAG(TAG_Nil)});
  V v_xs_245 = (g_heff_2ecompile_2elift_2efreeGo(v_t_244, heff_dup(v_body_243), NTAG(TAG_Nil)));
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_f_242), NTAG(TAG_Nil)});
  V v_xs_248 = (g_heff_2ecompile_2elift_2efreeGo(v_t_247, heff_dup(v_body_243), NTAG(TAG_Nil)));
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
  V v_t_2410 = (g_heff_2ecompile_2elift_2eliftedDef(v_d_240, heff_dup(heff_rfield(v_acc_241, 1)), v_f_242, v_t_249, v_body_243));
  return (g_heff_2ecompile_2elift_2eliftFixDef_24s1197825217x45906855(v_acc_241, v_t_246, v_t_2410));
}
V g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_entry, 5, 0};

V g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750(V v_d_240, V v_acc_241, V v_x_242, V v_b_243, V v_a_244) {
top: ;
  V v_it_2435;
  switch (heff_tag_of(v_a_244)) {
  case TAG_EVar: {
    v_it_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EGlobal: {
    v_it_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELam: {
    v_it_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EApp: {
    v_it_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELet: {
    v_it_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ERecord: {
    v_it_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EProj: {
    v_it_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ETag: {
    v_it_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EMatch: {
    v_it_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrim: {
    v_it_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrimCall: {
    v_it_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ECall: {
    v_it_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EInt: {
    v_it_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat: {
    v_it_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EStr: {
    v_it_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFixed: {
    v_it_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat32: {
    v_it_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EAbandon: {
    v_it_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFix: {
    V v_f_2433 = heff_dup(heff_field(v_a_244, 0));
    V v_b_2434 = heff_dup(heff_field(v_a_244, 1));
    v_it_2435 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_f_2433, v_b_2434})});
    break;
  }
  default: heff_nomatch(v_a_244);
  }
  switch (heff_tag_of(v_it_2435)) {
  case TAG_Nothing: {
    V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_242), NTAG(TAG_Nil)});
    V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_244), NTAG(TAG_Nil)});
    V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2436, heff_dup(v_b_243)}), v_t_2437});
    V v_it_2439 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(v_d_240, v_acc_241, v_t_2438));
    switch (heff_tag_of(v_it_2439)) {
    case TAG_MkPair: {
      V v_it1_2440 = heff_field(v_it_2439, 0);
      V v_acc2_2441 = heff_field(v_it_2439, 1);
      V v_ru_24it_2439_24MkPair = heff_take_reuse_n(v_it_2439, 3ULL, 2);
      switch (heff_tag_of(v_it1_2440)) {
      case TAG_Nil: {
        V v_t_2442 = heff_tag_at_n(v_ru_24it_2439_24MkPair, TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
        V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_244, NTAG(TAG_Nil)});
        V v_t_2444 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2442, v_b_243}), v_t_2443});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2444, v_acc2_2441});
      }
      case TAG_Cons: {
        V v_f2_2445 = heff_field(v_it1_2440, 0);
        V v_as2_2446 = heff_field(v_it1_2440, 1);
        heff_take_n(v_it1_2440, 3ULL, 2);
        heff_drop(v_x_242);
        heff_drop(v_b_243);
        heff_drop(v_a_244);
        return heff_tag_at_n(v_ru_24it_2439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f2_2445, v_as2_2446}), v_acc2_2441});
      }
      default: return heff_nomatch(v_it1_2440);
      }
    }
    default: return heff_nomatch(v_it_2439);
    }
  }
  case TAG_Just: {
    V v_it1_2447 = heff_field(v_it_2435, 0);
    heff_take_n(v_it_2435, 1ULL, 1);
    heff_drop(v_a_244);
    switch (heff_tag_of(v_it1_2447)) {
    case TAG_MkPair: {
      V v_f_2448 = heff_field(v_it1_2447, 0);
      V v_fb_2449 = heff_field(v_it1_2447, 1);
      heff_take_n(v_it1_2447, 3ULL, 2);
      V v_t_2450 = (g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069(heff_dup(v_d_240), v_acc_241, v_f_2448, v_fb_2449));
      switch (heff_tag_of(v_t_2450)) {
      case TAG_MkPair: {
        V v_call_2451 = heff_field(v_t_2450, 0);
        V v_acc2_2452 = heff_field(v_t_2450, 1);
        heff_take_n(v_t_2450, 3ULL, 2);
        V v_e_2453 = (g_heff_2ecompile_2elift_2ereplaceGo(v_x_242, v_call_2451, v_b_243));
        return (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(v_d_240, v_acc2_2452, v_e_2453));
      }
      default: return heff_nomatch(v_t_2450);
      }
    }
    default: return heff_nomatch(v_it1_2447);
    }
  }
  default: return heff_nomatch(v_it_2435);
  }
}
V g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_entry, 4, 0};

V g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862(V v_d_240, V v_acc_241, V v_f_242, V v_as_243) {
top: ;
  V v_it_244 = (g_heff_2ecompile_2elift_2eoneParam(heff_dup(v_f_242)));
  switch (heff_tag_of(v_it_244)) {
  case TAG_Nothing: {
    V v_it_245 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(v_d_240, v_acc_241, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_f_242), heff_dup(v_as_243)})));
    switch (heff_tag_of(v_it_245)) {
    case TAG_MkPair: {
      V v_it1_246 = heff_field(v_it_245, 0);
      V v_acc2_247 = heff_field(v_it_245, 1);
      V v_ru_24it_245_24MkPair = heff_take_reuse_n(v_it_245, 3ULL, 2);
      switch (heff_tag_of(v_it1_246)) {
      case TAG_Nil: {
        return heff_tag_at_n(v_ru_24it_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_242, v_as_243}), v_acc2_247});
      }
      case TAG_Cons: {
        V v_f2_248 = heff_field(v_it1_246, 0);
        V v_as2_249 = heff_field(v_it1_246, 1);
        heff_take_n(v_it1_246, 3ULL, 2);
        heff_drop(v_f_242);
        heff_drop(v_as_243);
        return heff_tag_at_n(v_ru_24it_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f2_248, v_as2_249}), v_acc2_247});
      }
      default: return heff_nomatch(v_it1_246);
      }
    }
    default: return heff_nomatch(v_it_245);
    }
  }
  case TAG_Just: {
    V v_it1_2410 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_it1_2410, 0);
      V v_b_2412 = heff_field(v_it1_2410, 1);
      V v_ru_24it1_2410_24MkPair = heff_take_reuse_n(v_it1_2410, 3ULL, 2);
      switch (heff_tag_of(v_as_243)) {
      case TAG_Nil: {
        heff_drop(v_x_2411);
        heff_drop(v_b_2412);
        V v_it_2413 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(v_d_240, v_acc_241, heff_tag_at_n(v_ru_24it1_2410_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_f_242), heff_dup(v_as_243)})));
        switch (heff_tag_of(v_it_2413)) {
        case TAG_MkPair: {
          V v_it1_2414 = heff_field(v_it_2413, 0);
          V v_acc2_2415 = heff_field(v_it_2413, 1);
          V v_ru_24it_2413_24MkPair = heff_take_reuse_n(v_it_2413, 3ULL, 2);
          switch (heff_tag_of(v_it1_2414)) {
          case TAG_Nil: {
            return heff_tag_at_n(v_ru_24it_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_242, v_as_243}), v_acc2_2415});
          }
          case TAG_Cons: {
            V v_f2_2416 = heff_field(v_it1_2414, 0);
            V v_as2_2417 = heff_field(v_it1_2414, 1);
            heff_take_n(v_it1_2414, 3ULL, 2);
            heff_drop(v_f_242);
            return heff_tag_at_n(v_ru_24it_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f2_2416, v_as2_2417}), v_acc2_2415});
          }
          default: return heff_nomatch(v_it1_2414);
          }
        }
        default: return heff_nomatch(v_it_2413);
        }
      }
      case TAG_Cons: {
        V v_a_2418 = heff_dup(heff_field(v_as_243, 0));
        V v_it2_2419 = heff_dup(heff_field(v_as_243, 1));
        switch (heff_tag_of(v_it2_2419)) {
        case TAG_Nil: {
          heff_drop(v_f_242);
          heff_drop_tag(v_as_243, 2);
          heff_drop_cell(v_ru_24it1_2410_24MkPair, 2);
          return (g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750(v_d_240, v_acc_241, v_x_2411, v_b_2412, v_a_2418));
        }
        case TAG_Cons: {
          V v_ru_24it2_2419_24Cons = heff_take_reuse_n(v_it2_2419, 0ULL, 2);
          heff_drop(v_x_2411);
          heff_drop(v_b_2412);
          heff_drop(v_a_2418);
          V v_it_2422 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(v_d_240, v_acc_241, heff_tag_at_n(v_ru_24it1_2410_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_f_242), heff_dup(v_as_243)})));
          switch (heff_tag_of(v_it_2422)) {
          case TAG_MkPair: {
            V v_it1_2423 = heff_field(v_it_2422, 0);
            V v_acc2_2424 = heff_field(v_it_2422, 1);
            heff_take_n(v_it_2422, 3ULL, 2);
            switch (heff_tag_of(v_it1_2423)) {
            case TAG_Nil: {
              return heff_tag_at_n(v_ru_24it2_2419_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_242, v_as_243}), v_acc2_2424});
            }
            case TAG_Cons: {
              V v_f2_2425 = heff_field(v_it1_2423, 0);
              V v_as2_2426 = heff_field(v_it1_2423, 1);
              heff_take_n(v_it1_2423, 3ULL, 2);
              heff_drop(v_f_242);
              heff_drop_tag(v_as_243, 2);
              return heff_tag_at_n(v_ru_24it2_2419_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f2_2425, v_as2_2426}), v_acc2_2424});
            }
            default: return heff_nomatch(v_it1_2423);
            }
          }
          default: return heff_nomatch(v_it_2422);
          }
        }
        default: return heff_nomatch(v_it2_2419);
        }
      }
      default: return heff_nomatch(v_as_243);
      }
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_entry, 3, 0};

V g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(V v_d_240, V v_acc_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_d_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_d_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_e_242, 0);
    V v_b_246 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(v_d_240, v_acc_241, v_b_246));
    switch (heff_tag_of(v_t_247)) {
    case TAG_MkPair: {
      V v_b2_248 = heff_field(v_t_247, 0);
      V v_acc2_249 = heff_field(v_t_247, 1);
      heff_take_n(v_t_247, 3ULL, 2);
      return heff_tag_at_n(v_ru_24e_242_24ELam, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_245, v_b2_248}), v_acc2_249});
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_EApp: {
    V v_f_2410 = heff_field(v_e_242, 0);
    V v_as_2411 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    return (g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862(v_d_240, v_acc_241, v_f_2410, v_as_2411));
  }
  case TAG_ELet: {
    V v_x_2412 = heff_dup(heff_field(v_e_242, 0));
    V v_a_2413 = heff_dup(heff_field(v_e_242, 1));
    V v_b_2414 = heff_dup(heff_field(v_e_242, 2));
    V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2414, NTAG(TAG_Nil)});
    V v_it_2416 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(v_d_240, v_acc_241, heff_tag_n(TAG_Cons, 2, (V[]){v_a_2413, v_t_2415})));
    switch (heff_tag_of(v_it_2416)) {
    case TAG_MkPair: {
      V v_it1_2417 = heff_field(v_it_2416, 0);
      V v_acc2_2418 = heff_field(v_it_2416, 1);
      V v_ru_24it_2416_24MkPair = heff_take_reuse_n(v_it_2416, 3ULL, 2);
      switch (heff_tag_of(v_it1_2417)) {
      case TAG_Nil: {
        heff_drop(v_x_2412);
        return heff_tag_at_n(v_ru_24it_2416_24MkPair, TAG_MkPair, 2, (V[]){v_e_242, v_acc2_2418});
      }
      case TAG_Cons: {
        V v_a2_2419 = heff_field(v_it1_2417, 0);
        V v_it12_2420 = heff_field(v_it1_2417, 1);
        heff_take_n(v_it1_2417, 3ULL, 2);
        switch (heff_tag_of(v_it12_2420)) {
        case TAG_Nil: {
          heff_drop(v_x_2412);
          heff_drop(v_a2_2419);
          return heff_tag_at_n(v_ru_24it_2416_24MkPair, TAG_MkPair, 2, (V[]){v_e_242, v_acc2_2418});
        }
        case TAG_Cons: {
          V v_b2_2421 = heff_field(v_it12_2420, 0);
          V v_it122_2422 = heff_field(v_it12_2420, 1);
          heff_take_n(v_it12_2420, 3ULL, 2);
          switch (heff_tag_of(v_it122_2422)) {
          case TAG_Nil: {
            heff_drop_tag(v_e_242, 3);
            return heff_tag_at_n(v_ru_24it_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2412, v_a2_2419, v_b2_2421}), v_acc2_2418});
          }
          case TAG_Cons: {
            heff_take_n(v_it122_2422, 0ULL, 2);
            heff_drop(v_x_2412);
            heff_drop(v_a2_2419);
            heff_drop(v_b2_2421);
            return heff_tag_at_n(v_ru_24it_2416_24MkPair, TAG_MkPair, 2, (V[]){v_e_242, v_acc2_2418});
          }
          default: return heff_nomatch(v_it122_2422);
          }
        }
        default: return heff_nomatch(v_it12_2420);
        }
      }
      default: return heff_nomatch(v_it1_2417);
      }
    }
    default: return heff_nomatch(v_it_2416);
    }
  }
  case TAG_ERecord: {
    V v_fs_2425 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 1ULL, 1);
    V v_t_2426 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2425)));
    V v_t_2427 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(v_d_240, v_acc_241, v_t_2426));
    switch (heff_tag_of(v_t_2427)) {
    case TAG_MkPair: {
      V v_es_2428 = heff_field(v_t_2427, 0);
      V v_acc2_2429 = heff_field(v_t_2427, 1);
      V v_ru_24t_2427_24MkPair = heff_take_reuse_n(v_t_2427, 3ULL, 2);
      V v_fs2_2430 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2425, v_es_2428));
      return heff_tag_at_n(v_ru_24t_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_242_24ERecord, TAG_ERecord, 1, (V[]){v_fs2_2430}), v_acc2_2429});
    }
    default: return heff_nomatch(v_t_2427);
    }
  }
  case TAG_EProj: {
    V v_x_2431 = heff_field(v_e_242, 0);
    V v_l_2432 = heff_field(v_e_242, 1);
    V v_sh_2433 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24EProj = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2434 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(v_d_240, v_acc_241, v_x_2431));
    switch (heff_tag_of(v_t_2434)) {
    case TAG_MkPair: {
      V v_x2_2435 = heff_field(v_t_2434, 0);
      V v_acc2_2436 = heff_field(v_t_2434, 1);
      V v_ru_24t_2434_24MkPair = heff_take_reuse_n(v_t_2434, 3ULL, 2);
      return heff_tag_at_n(v_ru_24t_2434_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_242_24EProj, TAG_EProj, 3, (V[]){v_x2_2435, v_l_2432, v_sh_2433}), v_acc2_2436});
    }
    default: return heff_nomatch(v_t_2434);
    }
  }
  case TAG_ETag: {
    V v_t_2437 = heff_field(v_e_242, 0);
    V v_es_2438 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2439 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(v_d_240, v_acc_241, v_es_2438));
    switch (heff_tag_of(v_t_2439)) {
    case TAG_MkPair: {
      V v_es2_2440 = heff_field(v_t_2439, 0);
      V v_acc2_2441 = heff_field(v_t_2439, 1);
      heff_take_n(v_t_2439, 3ULL, 2);
      return heff_tag_at_n(v_ru_24e_242_24ETag, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 2, (V[]){v_t_2437, v_es2_2440}), v_acc2_2441});
    }
    default: return heff_nomatch(v_t_2439);
    }
  }
  case TAG_EMatch: {
    V v_x_2442 = heff_field(v_e_242, 0);
    V v_arms_2443 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2444 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(heff_dup(v_d_240), v_acc_241, v_x_2442));
    switch (heff_tag_of(v_t_2444)) {
    case TAG_MkPair: {
      V v_x2_2445 = heff_field(v_t_2444, 0);
      V v_acc2_2446 = heff_field(v_t_2444, 1);
      heff_take_n(v_t_2444, 3ULL, 2);
      V v_t_2447 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_2443)));
      V v_t_2448 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(v_d_240, v_acc2_2446, v_t_2447));
      switch (heff_tag_of(v_t_2448)) {
      case TAG_MkPair: {
        V v_bs_2449 = heff_field(v_t_2448, 0);
        V v_acc2_2450 = heff_field(v_t_2448, 1);
        heff_take_n(v_t_2448, 3ULL, 2);
        V v_arms2_2451 = (g_list_2ezipWith_24s738847920x410598254(v_arms_2443, v_bs_2449));
        return heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x2_2445, v_arms2_2451}), v_acc2_2450});
      }
      default: return heff_nomatch(v_t_2448);
      }
    }
    default: return heff_nomatch(v_t_2444);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_d_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EPrimCall: {
    V v_p_2453 = heff_field(v_e_242, 0);
    V v_es_2454 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2455 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(v_d_240, v_acc_241, v_es_2454));
    switch (heff_tag_of(v_t_2455)) {
    case TAG_MkPair: {
      V v_es2_2456 = heff_field(v_t_2455, 0);
      V v_acc2_2457 = heff_field(v_t_2455, 1);
      heff_take_n(v_t_2455, 3ULL, 2);
      return heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2453, v_es2_2456}), v_acc2_2457});
    }
    default: return heff_nomatch(v_t_2455);
    }
  }
  case TAG_ECall: {
    V v_c_2458 = heff_field(v_e_242, 0);
    V v_es_2459 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2460 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(v_d_240, v_acc_241, v_es_2459));
    switch (heff_tag_of(v_t_2460)) {
    case TAG_MkPair: {
      V v_es2_2461 = heff_field(v_t_2460, 0);
      V v_acc2_2462 = heff_field(v_t_2460, 1);
      heff_take_n(v_t_2460, 3ULL, 2);
      return heff_tag_at_n(v_ru_24e_242_24ECall, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_c_2458, v_es2_2461}), v_acc2_2462});
    }
    default: return heff_nomatch(v_t_2460);
    }
  }
  case TAG_EInt: {
    heff_drop(v_d_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EFloat: {
    heff_drop(v_d_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EStr: {
    heff_drop(v_d_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EFixed: {
    heff_drop(v_d_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EFloat32: {
    heff_drop(v_d_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_d_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EFix: {
    V v_f_2469 = heff_field(v_e_242, 0);
    V v_b_2470 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    return (g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069(v_d_240, v_acc_241, v_f_2469, v_b_2470));
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2elift_2eliftGo_24s1117140028x479981506_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2eliftGo_24s1117140028x479981506_entry, 3, 0};

V g_heff_2ecompile_2elift_2eliftGo_24s1117140028x479981506(V v_lit_240, V v_d_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_d_241);
    V v_t_244 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_t_244});
  }
  case TAG_EGlobal: {
    heff_drop(v_d_241);
    V v_t_246 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_t_246});
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_e_242, 0);
    V v_b_248 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_249 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2410 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(v_d_241, v_t_249, v_b_248));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_MkPair: {
      V v_b2_2411 = heff_field(v_t_2410, 0);
      V v_acc2_2412 = heff_field(v_t_2410, 1);
      heff_take_n(v_t_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24e_242_24ELam, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_247, v_b2_2411}), v_acc2_2412});
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  case TAG_EApp: {
    V v_f_2413 = heff_field(v_e_242, 0);
    V v_as_2414 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2415 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return (g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862(v_d_241, v_t_2415, v_f_2413, v_as_2414));
  }
  case TAG_ELet: {
    V v_x_2416 = heff_dup(heff_field(v_e_242, 0));
    V v_a_2417 = heff_dup(heff_field(v_e_242, 1));
    V v_b_2418 = heff_dup(heff_field(v_e_242, 2));
    V v_t_2419 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2418, NTAG(TAG_Nil)});
    V v_it_2421 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(v_d_241, v_t_2419, heff_tag_n(TAG_Cons, 2, (V[]){v_a_2417, v_t_2420})));
    switch (heff_tag_of(v_it_2421)) {
    case TAG_MkPair: {
      V v_it1_2422 = heff_field(v_it_2421, 0);
      V v_acc2_2423 = heff_field(v_it_2421, 1);
      V v_ru_24it_2421_24MkPair = heff_take_reuse_n(v_it_2421, 3ULL, 2);
      switch (heff_tag_of(v_it1_2422)) {
      case TAG_Nil: {
        heff_drop(v_x_2416);
        return heff_tag_at_n(v_ru_24it_2421_24MkPair, TAG_MkPair, 2, (V[]){v_e_242, v_acc2_2423});
      }
      case TAG_Cons: {
        V v_a2_2424 = heff_field(v_it1_2422, 0);
        V v_it12_2425 = heff_field(v_it1_2422, 1);
        heff_take_n(v_it1_2422, 3ULL, 2);
        switch (heff_tag_of(v_it12_2425)) {
        case TAG_Nil: {
          heff_drop(v_x_2416);
          heff_drop(v_a2_2424);
          return heff_tag_at_n(v_ru_24it_2421_24MkPair, TAG_MkPair, 2, (V[]){v_e_242, v_acc2_2423});
        }
        case TAG_Cons: {
          V v_b2_2426 = heff_field(v_it12_2425, 0);
          V v_it122_2427 = heff_field(v_it12_2425, 1);
          heff_take_n(v_it12_2425, 3ULL, 2);
          switch (heff_tag_of(v_it122_2427)) {
          case TAG_Nil: {
            heff_drop_tag(v_e_242, 3);
            return heff_tag_at_n(v_ru_24it_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2416, v_a2_2424, v_b2_2426}), v_acc2_2423});
          }
          case TAG_Cons: {
            heff_take_n(v_it122_2427, 0ULL, 2);
            heff_drop(v_x_2416);
            heff_drop(v_a2_2424);
            heff_drop(v_b2_2426);
            return heff_tag_at_n(v_ru_24it_2421_24MkPair, TAG_MkPair, 2, (V[]){v_e_242, v_acc2_2423});
          }
          default: return heff_nomatch(v_it122_2427);
          }
        }
        default: return heff_nomatch(v_it12_2425);
        }
      }
      default: return heff_nomatch(v_it1_2422);
      }
    }
    default: return heff_nomatch(v_it_2421);
    }
  }
  case TAG_ERecord: {
    V v_fs_2430 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 1ULL, 1);
    V v_t_2431 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2432 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2430)));
    V v_t_2433 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(v_d_241, v_t_2431, v_t_2432));
    switch (heff_tag_of(v_t_2433)) {
    case TAG_MkPair: {
      V v_es_2434 = heff_field(v_t_2433, 0);
      V v_acc2_2435 = heff_field(v_t_2433, 1);
      V v_ru_24t_2433_24MkPair = heff_take_reuse_n(v_t_2433, 3ULL, 2);
      V v_fs2_2436 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2430, v_es_2434));
      return heff_tag_at_n(v_ru_24t_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_242_24ERecord, TAG_ERecord, 1, (V[]){v_fs2_2436}), v_acc2_2435});
    }
    default: return heff_nomatch(v_t_2433);
    }
  }
  case TAG_EProj: {
    V v_x_2437 = heff_field(v_e_242, 0);
    V v_l_2438 = heff_field(v_e_242, 1);
    V v_sh_2439 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24EProj = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2440 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2441 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(v_d_241, v_t_2440, v_x_2437));
    switch (heff_tag_of(v_t_2441)) {
    case TAG_MkPair: {
      V v_x2_2442 = heff_field(v_t_2441, 0);
      V v_acc2_2443 = heff_field(v_t_2441, 1);
      V v_ru_24t_2441_24MkPair = heff_take_reuse_n(v_t_2441, 3ULL, 2);
      return heff_tag_at_n(v_ru_24t_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_242_24EProj, TAG_EProj, 3, (V[]){v_x2_2442, v_l_2438, v_sh_2439}), v_acc2_2443});
    }
    default: return heff_nomatch(v_t_2441);
    }
  }
  case TAG_ETag: {
    V v_t_2444 = heff_field(v_e_242, 0);
    V v_es_2445 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2446 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2447 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(v_d_241, v_t_2446, v_es_2445));
    switch (heff_tag_of(v_t_2447)) {
    case TAG_MkPair: {
      V v_es2_2448 = heff_field(v_t_2447, 0);
      V v_acc2_2449 = heff_field(v_t_2447, 1);
      heff_take_n(v_t_2447, 3ULL, 2);
      return heff_tag_at_n(v_ru_24e_242_24ETag, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 2, (V[]){v_t_2444, v_es2_2448}), v_acc2_2449});
    }
    default: return heff_nomatch(v_t_2447);
    }
  }
  case TAG_EMatch: {
    V v_x_2450 = heff_field(v_e_242, 0);
    V v_arms_2451 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2452 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2453 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(heff_dup(v_d_241), v_t_2452, v_x_2450));
    switch (heff_tag_of(v_t_2453)) {
    case TAG_MkPair: {
      V v_x2_2454 = heff_field(v_t_2453, 0);
      V v_acc2_2455 = heff_field(v_t_2453, 1);
      heff_take_n(v_t_2453, 3ULL, 2);
      V v_t_2456 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_2451)));
      V v_t_2457 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(v_d_241, v_acc2_2455, v_t_2456));
      switch (heff_tag_of(v_t_2457)) {
      case TAG_MkPair: {
        V v_bs_2458 = heff_field(v_t_2457, 0);
        V v_acc2_2459 = heff_field(v_t_2457, 1);
        heff_take_n(v_t_2457, 3ULL, 2);
        V v_arms2_2460 = (g_list_2ezipWith_24s738847920x410598254(v_arms_2451, v_bs_2458));
        return heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x2_2454, v_arms2_2460}), v_acc2_2459});
      }
      default: return heff_nomatch(v_t_2457);
      }
    }
    default: return heff_nomatch(v_t_2453);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_d_241);
    V v_t_2462 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_t_2462});
  }
  case TAG_EPrimCall: {
    V v_p_2463 = heff_field(v_e_242, 0);
    V v_es_2464 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2465 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2466 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(v_d_241, v_t_2465, v_es_2464));
    switch (heff_tag_of(v_t_2466)) {
    case TAG_MkPair: {
      V v_es2_2467 = heff_field(v_t_2466, 0);
      V v_acc2_2468 = heff_field(v_t_2466, 1);
      heff_take_n(v_t_2466, 3ULL, 2);
      return heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2463, v_es2_2467}), v_acc2_2468});
    }
    default: return heff_nomatch(v_t_2466);
    }
  }
  case TAG_ECall: {
    V v_c_2469 = heff_field(v_e_242, 0);
    V v_es_2470 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2471 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2472 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404(v_d_241, v_t_2471, v_es_2470));
    switch (heff_tag_of(v_t_2472)) {
    case TAG_MkPair: {
      V v_es2_2473 = heff_field(v_t_2472, 0);
      V v_acc2_2474 = heff_field(v_t_2472, 1);
      heff_take_n(v_t_2472, 3ULL, 2);
      return heff_tag_at_n(v_ru_24e_242_24ECall, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_c_2469, v_es2_2473}), v_acc2_2474});
    }
    default: return heff_nomatch(v_t_2472);
    }
  }
  case TAG_EInt: {
    heff_drop(v_d_241);
    V v_t_2476 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_t_2476});
  }
  case TAG_EFloat: {
    heff_drop(v_d_241);
    V v_t_2478 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_t_2478});
  }
  case TAG_EStr: {
    heff_drop(v_d_241);
    V v_t_2480 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_t_2480});
  }
  case TAG_EFixed: {
    heff_drop(v_d_241);
    V v_t_2483 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_t_2483});
  }
  case TAG_EFloat32: {
    heff_drop(v_d_241);
    V v_t_2485 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_t_2485});
  }
  case TAG_EAbandon: {
    heff_drop(v_d_241);
    V v_t_2486 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_t_2486});
  }
  case TAG_EFix: {
    V v_f_2487 = heff_field(v_e_242, 0);
    V v_b_2488 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2489 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return (g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069(v_d_241, v_t_2489, v_f_2487, v_b_2488));
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2elift_2eliftGo_24s1117140028x479981506_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2eliftGo_24s1117140028x479981506(a[0], a[1], a[2]);
}