// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Enter_24heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876 60987
#define TAG_Enter_24heff_2ecompile_2elift_2ecalledWith_24s1395142400x2053340574 30503
#define TAG_Enter_24heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862 13135
#define TAG_Enter_24heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804 50048
#define LBL_body 9524841
#define LBL_key 315609
#define LBL_n 328
#define LBL_name 9869138
#define LBL_out 319944
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_out__n[] = {LBL_out, LBL_n};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012(V, V);
V g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2efoldParts(V, V, V);
V g_heff_2ecompile_2eir_2efoldParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldParts_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2emapParts(V, V);
V g_heff_2ecompile_2eir_2emapParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok1(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok1_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok2_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok3(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok3_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
HeffT2 g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2elift_2ecalledGo_24s1073939894x271972689_24cpr(V, V, V);
V g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876(V, V, V);
V g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_clo;
HeffT2 g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr(V, V, V, V, V, V, V, V, V);
HeffT2 g_heff_2ecompile_2elift_2ecalledWith_24s1395142400x2053340574_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2elift_2ecallsOf(V, V, V, V);
V g_heff_2ecompile_2elift_2ecallsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2ecallsOf_clo;
V g_heff_2ecompile_2elift_2ecallsW(V, V, V, V);
V g_heff_2ecompile_2elift_2ecallsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2ecallsW_clo;
V g_heff_2ecompile_2elift_2eearlyGo(V, V);
V g_heff_2ecompile_2elift_2eearlyGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eearlyGo_clo;
V g_heff_2ecompile_2elift_2efreeGo(V, V, V);
V g_heff_2ecompile_2elift_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2efreeGo_clo;
HeffT2 g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr(V, V, V, V);
V g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(V, V, V);
V g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_clo;
HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr(V, V, V, V, V, V, V, V);
HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(V, V, V);
V g_heff_2ecompile_2elift_2eonlyCalled(V, V, V);
V g_heff_2ecompile_2elift_2eonlyCalled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eonlyCalled_clo;
V g_heff_2ecompile_2elift_2eordered(V, V);
V g_heff_2ecompile_2elift_2eordered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eordered_clo;
V g_heff_2ecompile_2elift_2ereplaceGo(V, V, V);
V g_heff_2ecompile_2elift_2ereplaceGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2ereplaceGo_clo;
V g_heff_2ecompile_2elift_2ewithParams(V, V);
V g_heff_2ecompile_2elift_2ewithParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2ewithParams_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1793712833x1452468429(V, V);
V g_list_2eany_24s1793712833x1452468429_entry(V self, V *a);
extern Clo g_list_2eany_24s1793712833x1452468429_clo;
V g_list_2eany_24s477650497x932674259(V, V);
V g_list_2eany_24s477650497x932674259_entry(V self, V *a);
extern Clo g_list_2eany_24s477650497x932674259_clo;
V g_list_2efoldl_24f1428393365x1980555854(V, V, V);
V g_list_2efoldl_24f1428393365x1980555854_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1428393365x1980555854_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2etraverse_24s988656740x982054589(V, V);
V g_prelude_2etraverse_24s988656740x982054589_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s988656740x982054589_clo;
V g_heff_2ecompile_2elift_2efreeGo_lam0(V self, V *args);
Clo g_heff_2ecompile_2elift_2efreeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2efreeGo_entry, 3, 0};

V g_heff_2ecompile_2elift_2efreeGo(V v_bound_240, V v_e_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_t_244 = ({ V a_0 = v_x_243; V a_1 = v_bound_240; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_bound_240); r_; });
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_x_243);
      heff_drop(v_t_244);
      return v_acc_242;
    } else {
      heff_drop(v_t_244);
      V v_t_245 = (g_list_2eany_24s1006624359x760861690(v_x_243, v_acc_242));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_x_243);
        heff_drop(v_t_245);
        return v_acc_242;
      } else {
        heff_drop(v_t_245);
        return heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_acc_242});
      }
    }
  }
  default: {
    HEFF_LAST return g_heff_2ecompile_2eir_2efoldParts(heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam0, 3, 1, (V[]){v_bound_240}), v_e_241, v_acc_242);
  }
  }
}
V g_heff_2ecompile_2elift_2efreeGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2efreeGo(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2elift_2efreeGo_lam0(V self, V *args) {
  V v_xs_246 = args[0];
  V v_p_247 = args[1];
  V v_a_248 = args[2];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = (g_heff_2ecompile_2eir_2eappendI(v_xs_246, v_bound_240));
  return (g_heff_2ecompile_2elift_2efreeGo(v_t_249, v_p_247, v_a_248));
}
V g_heff_2ecompile_2elift_2ereplaceGo_lam0(V self, V *args);
Clo g_heff_2ecompile_2elift_2ereplaceGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2ereplaceGo_entry, 3, 0};

V g_heff_2ecompile_2elift_2ereplaceGo(V v_x_240, V v_r_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_dup(heff_field(v_e_242, 0));
    if (heff_strEq_c_lent(v_y_243, v_x_240, 1)) {
      heff_drop_tag(v_e_242, 1);
      return v_r_241;
    } else {
      heff_drop(v_r_241);
      return v_e_242;
    }
  }
  default: {
    return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2elift_2ereplaceGo_lam0, 2, 2, (V[]){heff_dup(v_x_240), v_r_241}), v_e_242));
  }
  }
}
V g_heff_2ecompile_2elift_2ereplaceGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2elift_2ereplaceGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2elift_2ereplaceGo_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_p_245 = args[1];
  V v_x_240 = heff_env(self)[0];
  V v_r_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_244);
  return ({ V a_0 = v_x_240; V a_1 = v_r_241; V a_2 = v_p_245; V r_ = (g_heff_2ecompile_2elift_2ereplaceGo(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
}
Clo g_heff_2ecompile_2elift_2ewithParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2ewithParams_entry, 2, 0};

V g_heff_2ecompile_2elift_2ewithParams(V v_fvs_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_fvs_240)) {
  case TAG_Nil: {
    return v_x2_241;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_EVar: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EGlobal: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_x2_241, 0);
      V v_b_247 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2eir_2eappendI(v_fvs_240, v_xs_246));
      return heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_ELam, 2, (V[]){v_t_248, v_b_247});
    }
    case TAG_EApp: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_ELet: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_ERecord: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EProj: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_ETag: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EMatch: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EPrim: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EPrimCall: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_ECall: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EInt: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EFloat: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EStr: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EBytes: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EFixed: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EFloat32: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EAbandon: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EBool: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_ESet: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EValues: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EFix: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_fvs_240);
  }
}
V g_heff_2ecompile_2elift_2ewithParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2ewithParams(a[0], a[1]);
}
Clo g_heff_2ecompile_2elift_2eearlyGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2eearlyGo_entry, 2, 0};

V g_heff_2ecompile_2elift_2eearlyGo(V v_keys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_keys_240;
  }
  case TAG_Cons: {
    V v_ld_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_list_2eany_24s477650497x932674259(heff_dup(v_ld_242), v_keys_240));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_t_245 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_take_field(v_ld_242, 2)));
      V v_t_246 = (g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012(v_keys_240, v_t_245));
      V v_t_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_ld_242, 0, 3), v_t_246});
      V t_0 = v_t_247;
      V t_1 = v_rest_243;
      v_keys_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V v_t_248 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_ld_242, 2))));
      V v_t_249 = (g_heff_2ecompile_2eir_2enubI(v_t_248));
      V v_t_2410 = ({ V a_0 = heff_rfield(v_ld_242, 0); V a_1 = v_t_249; V r_ = (g_list_2eany_24s1793712833x1452468429(a_0, a_1)); heff_drop(v_t_249); r_; });
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        V v_t_2411 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_take_field(v_ld_242, 2)));
        V v_t_2412 = (g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012(v_keys_240, v_t_2411));
        V v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_ld_242, 0, 3), v_t_2412});
        V t_0 = v_t_2413;
        V t_1 = v_rest_243;
        v_keys_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop_rec(v_ld_242, 3);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_2410);
        V t_0 = v_keys_240;
        V t_1 = v_rest_243;
        v_keys_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2elift_2eearlyGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2eearlyGo(a[0], a[1]);
}
V g_heff_2ecompile_2elift_2eordered_lam0(V self, V *args);
V g_heff_2ecompile_2elift_2eordered_lam1(V self, V *args);
Clo g_heff_2ecompile_2elift_2eordered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2eordered_entry, 2, 0};

V g_heff_2ecompile_2elift_2eordered(V v_out_240, V v_d_241) {
top: ;
  V v_keys_242 = (g_heff_2ecompile_2elift_2eearlyGo(NTAG(TAG_Nil), heff_dup(v_out_240)));
  V v_t_244 = (g_list_2efoldl_24f1428393365x1980555854(NTAG(TAG_Nil), heff_clo_n(g_heff_2ecompile_2elift_2eordered_lam0, 1, 1, (V[]){v_keys_242}), heff_dup(v_out_240)));
  V v_t_248 = (g_list_2efoldl_24f1428393365x1980555854(NTAG(TAG_Nil), heff_clo_n(g_heff_2ecompile_2elift_2eordered_lam1, 1, 1, (V[]){heff_dup(v_out_240)}), v_out_240));
  HEFF_LAST return g_heff_2ecompile_2eir_2eappendI(v_t_244, heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, v_t_248}));
}
V g_heff_2ecompile_2elift_2eordered_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2eordered(a[0], a[1]);
}
V g_heff_2ecompile_2elift_2eordered_lam0(V self, V *args) {
  V v_ld_243 = args[0];
  V v_keys_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_ld_243; V a_1 = v_keys_242; V r_ = (g_list_2eany_24s477650497x932674259(a_0, a_1)); heff_drop(v_keys_242); r_; });
}
V g_heff_2ecompile_2elift_2eordered_lam1(V self, V *args) {
  V v_ld_245 = args[0];
  V v_out_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_keys_246 = (g_heff_2ecompile_2elift_2eearlyGo(NTAG(TAG_Nil), v_out_240));
  V v_x1_247 = ({ V a_0 = v_ld_245; V a_1 = v_keys_246; V r_ = (g_list_2eany_24s477650497x932674259(a_0, a_1)); heff_drop(v_keys_246); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
  heff_drop(v_x1_247);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr_str1, 1, "$");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr_str2, 1, ".");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr_str3, 1, ".");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr_str4, 1, "$");

HeffT2 g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr(V v_d_240, V v_acc_241, V v_f_242, V v_body_243) {
top: ;
  V v_acc_244 = heff_dup(v_acc_241);
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_f_242), NTAG(TAG_Nil)});
  V v_xs_246 = heff_tr(g_heff_2ecompile_2elift_2efreeGo(v_t_245, heff_dup(v_body_243), NTAG(TAG_Nil)));
  V v_fvs_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
  V v_d_248 = v_d_240;
  V v_key_249 = heff_take_field(v_d_248, 0);
  V v_name_2410 = heff_get_n(v_d_248, 1, 3);
  V v_n_2411 = heff_get_n(v_acc_241, 1, 2);
  V v_f_2412 = heff_dup(v_f_242);
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_242, NTAG(TAG_Nil)});
  V v_xs_2414 = heff_tr(g_heff_2ecompile_2elift_2efreeGo(v_t_2413, heff_dup(v_body_243), NTAG(TAG_Nil)));
  V v_fvs_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2414));
  V v_body_2416 = v_body_243;
  V v_t_2417 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_f_2412), MK_INT(0LL)));
  V v_t_2418 = heff_strAppend(heff_strAppend(heff_dup(v_key_249), ((V)&g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr_str0)), v_t_2417);
  V v_key_2419 = heff_strAppend(heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr_str1)), heff_intShow(heff_dup(v_n_2411)));
  V v_t_2420 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_f_2412), MK_INT(0LL)));
  V v_name_2421 = heff_strAppend(heff_strAppend(v_name_2410, ((V)&g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr_str2)), v_t_2420);
  V v_t_2422 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_f_2412), MK_INT(0LL)));
  V v_t_2423 = heff_strAppend(heff_strAppend(v_key_249, ((V)&g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr_str3)), v_t_2422);
  V v_key_2424 = heff_strAppend(heff_strAppend(v_t_2423, ((V)&g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr_str4)), heff_intShow(v_n_2411));
  V v_t_2428;
  switch (heff_tag_of(v_fvs_2415)) {
  case TAG_Nil: {
    v_t_2428 = heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_2424});
    break;
  }
  case TAG_Cons: {
    V v_t_2427 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_fvs_2415)));
    v_t_2428 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_2424}), v_t_2427});
    break;
  }
  default: heff_nomatch(v_fvs_2415);
  }
  V v_t_2429 = ({ V a_0 = v_f_2412; V a_1 = v_t_2428; V a_2 = v_body_2416; V r_ = (g_heff_2ecompile_2elift_2ereplaceGo(a_0, a_1, a_2)); heff_drop(v_f_2412); r_; });
  V v_body_2430 = (g_heff_2ecompile_2elift_2ewithParams(v_fvs_2415, v_t_2429));
  V v_ld_2431 = heff_rec_n(3, shape_key__name__body, (V[]){v_key_2419, v_name_2421, v_body_2430});
  V v_t_2432 = heff_intAdd(heff_take_field(v_acc_244, 1), MK_INT(1LL));
  V v_t_2433 = ({ V rv_1 = v_t_2432; V rr_ = heff_rec_reuse_nf(v_acc_244, 1ULL, 2, shape_out__n, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  HeffT2 v_t_2434 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(heff_dup(v_ld_2431), v_t_2433, heff_dup(heff_rfield(v_ld_2431, 2))));
  {
    V v_field_2435 = v_t_2434.f[0];
    V v_field_2436 = v_t_2434.f[1];
    V v_b2_2437 = v_field_2435;
    V v_acc2_2438 = v_field_2436;
    V v_key_2439 = heff_dup(heff_rfield(v_ld_2431, 0));
    V v_f_2443;
    switch (heff_tag_of(v_fvs_247)) {
    case TAG_Nil: {
      v_f_2443 = heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_2439});
      break;
    }
    case TAG_Cons: {
      V v_t_2442 = (g_list_2emap_24s1809017761x1063871171(v_fvs_247));
      v_f_2443 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_2439}), v_t_2442});
      break;
    }
    default: heff_nomatch(v_fvs_247);
    }
    V v_t_2444 = ({ V rv_2 = v_b2_2437; V rr_ = heff_rec_reuse_nf(v_ld_2431, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2444, heff_take_field(v_acc2_2438, 0)});
    V v_f_2446 = ({ V rv_0 = v_t_2445; V rr_ = heff_rec_reuse_nf(v_acc2_2438, 2ULL, 2, shape_out__n, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return ((HeffT2){{v_f_2443, v_f_2446}});
  }
}
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_str6, 0, "");
V g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_lam1(V self, V *args);
V g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_lam2(V self, V *args);
V g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_lam3(V self, V *args);

HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr(V v_tag_240, V v_d_241, V v_acc_242, V v_e_243, V v_d_244, V v_acc_245, V v_f_246, V v_args_247) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804: {
    top_TAG_Enter_24heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804: ;
    heff_drop(v_d_244);
    heff_drop(v_acc_245);
    heff_drop(v_f_246);
    heff_drop(v_args_247);
    switch (heff_tag_of(v_e_243)) {
    case TAG_EApp: {
      V v_f_248 = heff_field(v_e_243, 0);
      V v_args_249 = heff_field(v_e_243, 1);
      heff_take_n(v_e_243, 3ULL, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862);
      V t_1 = ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_str0);
      V t_2 = ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_str1);
      V t_3 = ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_str2);
      V t_4 = v_d_241;
      V t_5 = v_acc_242;
      V t_6 = v_f_248;
      V t_7 = v_args_249;
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_acc_242 = t_2;
      v_e_243 = t_3;
      v_d_244 = t_4;
      v_acc_245 = t_5;
      v_f_246 = t_6;
      v_args_247 = t_7;
      goto top_TAG_Enter_24heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862;
    }
    case TAG_EFix: {
      V v_f_2410 = heff_field(v_e_243, 0);
      V v_b_2411 = heff_field(v_e_243, 1);
      heff_take_n(v_e_243, 3ULL, 2);
      return (g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr(v_d_241, v_acc_242, v_f_2410, v_b_2411));
    }
    default: {
      return (g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr(heff_clo_n(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_lam0, 3, 1, (V[]){v_d_241}), v_e_243, v_acc_242));
    }
    }
  }
  case TAG_Enter_24heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862: {
    top_TAG_Enter_24heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862: ;
    heff_drop(v_d_241);
    heff_drop(v_acc_242);
    heff_drop(v_e_243);
    V v_e_2415 = heff_dup(v_f_246);
    V v_it_2459;
    switch (heff_tag_of(v_e_2415)) {
    case TAG_EVar: {
      heff_take_n(v_e_2415, 0ULL, 1);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_e_2415, 0ULL, 1);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELam: {
      V v_xs_2418 = heff_field(v_e_2415, 0);
      V v_b_2419 = heff_field(v_e_2415, 1);
      V v_ru_24e_2415_24ELam = heff_take_reuse_n(v_e_2415, 3ULL, 2);
      switch (heff_tag_of(v_xs_2418)) {
      case TAG_Nil: {
        heff_drop(v_b_2419);
        heff_drop_cell(v_ru_24e_2415_24ELam, 2);
        v_it_2459 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2420 = heff_field(v_xs_2418, 0);
        V v_it2_2421 = heff_field(v_xs_2418, 1);
        heff_take_n(v_xs_2418, 3ULL, 2);
        switch (heff_tag_of(v_it2_2421)) {
        case TAG_Nil: {
          v_it_2459 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24e_2415_24ELam, TAG_MkPair, 2, (V[]){v_x_2420, v_b_2419})});
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_it2_2421, 0ULL, 2);
          heff_drop(v_b_2419);
          heff_drop_cell(v_ru_24e_2415_24ELam, 2);
          heff_drop(v_x_2420);
          v_it_2459 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_it2_2421);
        }
        break;
      }
      default: heff_nomatch(v_xs_2418);
      }
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_e_2415, 0ULL, 2);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_e_2415, 0ULL, 3);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_e_2415, 0ULL, 2);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_e_2415, 0ULL, 4);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_e_2415, 0ULL, 3);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_e_2415, 0ULL, 2);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_e_2415, 0ULL, 1);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e_2415, 0ULL, 2);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_e_2415, 0ULL, 2);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_e_2415, 0ULL, 1);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_e_2415, 0ULL, 1);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_e_2415, 0ULL, 1);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_e_2415, 0ULL, 1);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_e_2415, 0ULL, 2);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_e_2415, 0ULL, 1);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EAbandon: {
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_e_2415, 0ULL, 1);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_e_2415, 0ULL, 3);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_e_2415, 0ULL, 1);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_e_2415, 0ULL, 2);
      v_it_2459 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_e_2415);
    }
    switch (heff_tag_of(v_it_2459)) {
    case TAG_Nothing: {
      HeffT2 v_t_2460 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(heff_dup(v_d_244), v_acc_245, v_f_246));
      {
        V v_field_2461 = v_t_2460.f[0];
        V v_field_2462 = v_t_2460.f[1];
        V v_x_2463 = v_field_2461;
        V v_acc_2464 = v_field_2462;
        V v_m_2467 = (g_prelude_2etraverse_24s988656740x982054589(heff_clo_n(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_lam1, 2, 1, (V[]){v_d_244}), v_args_247));
        V v_x2_2468 = heff_tr(heff_call(v_m_2467, 1, (V[]){v_acc_2464}));
        switch (heff_tag_of(v_x2_2468)) {
        case TAG_MkPair: {
          V v_x_2469 = heff_field(v_x2_2468, 0);
          V v_acc_2470 = heff_field(v_x2_2468, 1);
          V v_ru_24x2_2468_24MkPair = heff_take_reuse_n(v_x2_2468, 3ULL, 2);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x2_2468_24MkPair, TAG_EApp, 2, (V[]){v_x_2463, v_x_2469}), v_acc_2470}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x2_2468)}});
        }
      }
    }
    case TAG_Just: {
      V v_it1_2471 = heff_field(v_it_2459, 0);
      V v_ru_24it_2459_24Just = heff_take_reuse_n(v_it_2459, 1ULL, 1);
      switch (heff_tag_of(v_it1_2471)) {
      case TAG_MkPair: {
        V v_x_2472 = heff_field(v_it1_2471, 0);
        V v_b_2473 = heff_field(v_it1_2471, 1);
        V v_ru_24it1_2471_24MkPair = heff_take_reuse_n(v_it1_2471, 3ULL, 2);
        switch (heff_tag_of(v_args_247)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24it_2459_24Just, 1);
          heff_drop(v_x_2472);
          heff_drop(v_b_2473);
          heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
          HeffT2 v_t_2474 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(heff_dup(v_d_244), v_acc_245, v_f_246));
          {
            V v_field_2475 = v_t_2474.f[0];
            V v_field_2476 = v_t_2474.f[1];
            V v_x_2477 = v_field_2475;
            V v_acc_2478 = v_field_2476;
            V v_m_2481 = (g_prelude_2etraverse_24s988656740x982054589(heff_clo_n(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_lam2, 2, 1, (V[]){v_d_244}), v_args_247));
            V v_x2_2482 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_acc_2478}));
            switch (heff_tag_of(v_x2_2482)) {
            case TAG_MkPair: {
              V v_x_2483 = heff_field(v_x2_2482, 0);
              V v_acc_2484 = heff_field(v_x2_2482, 1);
              V v_ru_24x2_2482_24MkPair = heff_take_reuse_n(v_x2_2482, 3ULL, 2);
              return ((HeffT2){{heff_tag_at_n(v_ru_24x2_2482_24MkPair, TAG_EApp, 2, (V[]){v_x_2477, v_x_2483}), v_acc_2484}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x2_2482)}});
            }
          }
        }
        case TAG_Cons: {
          V v_it2_2486 = heff_dup(heff_field(v_args_247, 1));
          switch (heff_tag_of(v_it2_2486)) {
          case TAG_Nil: {
            heff_drop(v_f_246);
            switch (heff_tag_of(v_args_247)) {
            case TAG_Cons: {
              V v_a_2487 = heff_field(v_args_247, 0);
              V v_ru_24args_247_24Cons = heff_take_reuse_n(v_args_247, 1ULL, 2);
              V v_d_2489 = v_d_244;
              V v_acc_2490 = v_acc_245;
              V v_x_2491 = v_x_2472;
              V v_b_2492 = v_b_2473;
              V v_a_2493 = v_a_2487;
              V v_e_2494 = heff_dup(v_a_2493);
              V v_t_24134;
              switch (heff_tag_of(v_e_2494)) {
              case TAG_EVar: {
                heff_take_n(v_e_2494, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_EGlobal: {
                heff_take_n(v_e_2494, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_ELam: {
                heff_take_n(v_e_2494, 0ULL, 2);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_EApp: {
                heff_take_n(v_e_2494, 0ULL, 2);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_ELet: {
                heff_take_n(v_e_2494, 0ULL, 3);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_ERecord: {
                heff_take_n(v_e_2494, 0ULL, 2);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_EProj: {
                heff_take_n(v_e_2494, 0ULL, 4);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_ETag: {
                heff_take_n(v_e_2494, 0ULL, 3);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_EMatch: {
                heff_take_n(v_e_2494, 0ULL, 2);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_EPrim: {
                heff_take_n(v_e_2494, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_EPrimCall: {
                heff_take_n(v_e_2494, 0ULL, 2);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_ECall: {
                heff_take_n(v_e_2494, 0ULL, 2);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_EInt: {
                heff_take_n(v_e_2494, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_EFloat: {
                heff_take_nf(v_e_2494, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_EStr: {
                heff_take_n(v_e_2494, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_EBytes: {
                heff_take_n(v_e_2494, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_EFixed: {
                heff_take_n(v_e_2494, 0ULL, 2);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_EFloat32: {
                heff_take_na(v_e_2494, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_EAbandon: {
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_EBool: {
                heff_take_n(v_e_2494, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_ESet: {
                heff_take_n(v_e_2494, 0ULL, 3);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_EValues: {
                heff_take_n(v_e_2494, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2459_24Just, 1);
                heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
                v_t_24134 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_EFix: {
                V v_f_24132 = heff_field(v_e_2494, 0);
                V v_b_24133 = heff_field(v_e_2494, 1);
                heff_take_n(v_e_2494, 3ULL, 2);
                v_t_24134 = heff_tag_at_n(v_ru_24it_2459_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24it1_2471_24MkPair, TAG_MkPair, 2, (V[]){v_f_24132, v_b_24133})});
                break;
              }
              default: heff_nomatch(v_e_2494);
              }
              switch (heff_tag_of(v_t_24134)) {
              case TAG_Nothing: {
                HeffT2 v_t_24135 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(heff_dup(v_d_2489), v_acc_2490, v_b_2492));
                {
                  V v_field_24136 = v_t_24135.f[0];
                  V v_field_24137 = v_t_24135.f[1];
                  V v_x_24138 = v_field_24136;
                  V v_acc_24139 = v_field_24137;
                  HeffT2 v_t_24140 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(v_d_2489, v_acc_24139, v_a_2493));
                  {
                    V v_field_24141 = v_t_24140.f[0];
                    V v_field_24142 = v_t_24140.f[1];
                    V v_x_24143 = v_field_24141;
                    V v_acc_24144 = v_field_24142;
                    V v_t_24145 = heff_tag_at_n(v_ru_24args_247_24Cons, TAG_Cons, 2, (V[]){v_x_2491, NTAG(TAG_Nil)});
                    V v_t_24146 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24143, NTAG(TAG_Nil)});
                    V v_t_24147 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_24145, v_x_24138}), v_t_24146});
                    return ((HeffT2){{v_t_24147, v_acc_24144}});
                  }
                }
              }
              case TAG_Just: {
                V v_it1_24148 = heff_field(v_t_24134, 0);
                heff_take_n(v_t_24134, 1ULL, 1);
                heff_drop_cell(v_ru_24args_247_24Cons, 2);
                heff_drop(v_a_2493);
                switch (heff_tag_of(v_it1_24148)) {
                case TAG_MkPair: {
                  V v_f_24149 = heff_field(v_it1_24148, 0);
                  V v_fb_24150 = heff_field(v_it1_24148, 1);
                  heff_take_n(v_it1_24148, 3ULL, 2);
                  HeffT2 v_t_24151 = (g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr(heff_dup(v_d_2489), v_acc_2490, v_f_24149, v_fb_24150));
                  {
                    V v_field_24152 = v_t_24151.f[0];
                    V v_field_24153 = v_t_24151.f[1];
                    V v_call_24154 = v_field_24152;
                    V v_acc2_24155 = v_field_24153;
                    V v_e_24156 = ({ V a_0 = v_x_2491; V a_1 = v_call_24154; V a_2 = v_b_2492; V r_ = (g_heff_2ecompile_2elift_2ereplaceGo(a_0, a_1, a_2)); heff_drop(v_x_2491); r_; });
                    V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804);
                    V t_1 = v_d_2489;
                    V t_2 = v_acc2_24155;
                    V t_3 = v_e_24156;
                    V t_4 = ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_str3);
                    V t_5 = ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_str4);
                    V t_6 = ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_str5);
                    V t_7 = ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_str6);
                    v_tag_240 = t_0;
                    v_d_241 = t_1;
                    v_acc_242 = t_2;
                    v_e_243 = t_3;
                    v_d_244 = t_4;
                    v_acc_245 = t_5;
                    v_f_246 = t_6;
                    v_args_247 = t_7;
                    goto top_TAG_Enter_24heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804;
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_it1_24148)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_t_24134)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_args_247)}});
            }
          }
          case TAG_Cons: {
            V v_ru_24it2_2486_24Cons = heff_take_reuse_n(v_it2_2486, 0ULL, 2);
            heff_drop_cell(v_ru_24it_2459_24Just, 1);
            heff_drop(v_x_2472);
            heff_drop(v_b_2473);
            heff_drop_cell(v_ru_24it1_2471_24MkPair, 2);
            HeffT2 v_t_24159 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(heff_dup(v_d_244), v_acc_245, v_f_246));
            {
              V v_field_24160 = v_t_24159.f[0];
              V v_field_24161 = v_t_24159.f[1];
              V v_x_24162 = v_field_24160;
              V v_acc_24163 = v_field_24161;
              V v_m_24166 = (g_prelude_2etraverse_24s988656740x982054589(heff_clo_n(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_lam3, 2, 1, (V[]){v_d_244}), v_args_247));
              V v_x2_24167 = heff_tr(heff_call(v_m_24166, 1, (V[]){v_acc_24163}));
              switch (heff_tag_of(v_x2_24167)) {
              case TAG_MkPair: {
                V v_x_24168 = heff_field(v_x2_24167, 0);
                V v_acc_24169 = heff_field(v_x2_24167, 1);
                heff_take_n(v_x2_24167, 3ULL, 2);
                return ((HeffT2){{heff_tag_at_n(v_ru_24it2_2486_24Cons, TAG_EApp, 2, (V[]){v_x_24162, v_x_24168}), v_acc_24169}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x2_24167)}});
              }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_it2_2486)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_args_247)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_2471)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_it_2459)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_tag_240)}});
  }
}
V g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_p_2413 = args[1];
  V v_a_2414 = args[2];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2412);
  return (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(v_d_241, v_a_2414, v_p_2413));
}
V g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_lam1(V self, V *args) {
  V v_p_2465 = args[0];
  V v_a_2466 = args[1];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(v_d_244, v_a_2466, v_p_2465));
}
V g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_lam2(V self, V *args) {
  V v_p_2479 = args[0];
  V v_a_2480 = args[1];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(v_d_244, v_a_2480, v_p_2479));
}
V g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr_lam3(V self, V *args) {
  V v_p_24164 = args[0];
  V v_a_24165 = args[1];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(v_d_244, v_a_24165, v_p_24164));
}
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str3, 0, "");

HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(V v_d_240, V v_acc_241, V v_e_242) {
top: ;
  return (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr(NTAG(TAG_Enter_24heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804), v_d_240, v_acc_241, v_e_242, ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str0), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str1), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str2), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str3)));
}
Clo g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_entry, 3, 0};

V g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(V v_d_240, V v_acc_241, V v_e_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(v_d_240, v_acc_241, v_e_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str2, 0, "");

HeffT2 g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr(V v_d_240, V v_acc_241, V v_f_242, V v_args_243) {
top: ;
  return (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cycle_24cpr(NTAG(TAG_Enter_24heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862), ((V)&g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str0), ((V)&g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str1), ((V)&g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str2), v_d_240, v_acc_241, v_f_242, v_args_243));
}
V g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(V v_lit_240, V v_d_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EApp: {
    V v_f_243 = heff_field(v_e_242, 0);
    V v_args_244 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_245 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return (g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr(v_d_241, v_t_245, v_f_243, v_args_244));
  }
  case TAG_EFix: {
    V v_f_246 = heff_field(v_e_242, 0);
    V v_b_247 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_248 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return (g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr(v_d_241, v_t_248, v_f_246, v_b_247));
  }
  default: {
    V v_t_249 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    HEFF_LAST return g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr(heff_clo_n(g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr_lam0, 3, 1, (V[]){v_d_241}), v_e_242, v_t_249);
  }
  }
}
V g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_p_2411 = args[1];
  V v_a_2412 = args[2];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2410);
  return (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804(v_d_241, v_a_2412, v_p_2411));
}
Clo g_heff_2ecompile_2elift_2ecallsW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2ecallsW_entry, 4, 0};

V g_heff_2ecompile_2elift_2ecallsW(V v_x_240, V v_k_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return v_n_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_EApp: {
      V v_x411_246 = heff_dup(heff_field(v_x41_244, 0));
      switch (heff_tag_of(v_x411_246)) {
      case TAG_EVar: {
        V v_y_248 = heff_field(v_x411_246, 0);
        heff_take_n(v_x411_246, 1ULL, 1);
        switch (heff_tag_of(v_x41_244)) {
        case TAG_EApp: {
          V v_args_2410 = heff_field(v_x41_244, 1);
          heff_take_n(v_x41_244, 2ULL, 2);
          V v_t_2411;
          if ((heff_strEq_c_lent(v_y_248, v_x_240, 0) && ({ V v_t_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2410)); int c_ = heff_intEq_c_lent(v_t_2415, v_k_241, 0); heff_drop(v_t_2415); c_; }))) {
            heff_drop(v_y_248);
            v_t_2411 = heff_intAdd(v_n_242, MK_INT(1LL));
          } else {
            heff_drop(v_y_248);
            v_t_2411 = v_n_242;
          }
          V v_t_2412 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x4_243_24Cons, v_args_2410, v_rest_245));
          V t_0 = v_x_240;
          V t_1 = v_k_241;
          V t_2 = v_t_2411;
          V t_3 = v_t_2412;
          v_x_240 = t_0;
          v_k_241 = t_1;
          v_n_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        default: return heff_nomatch(v_x41_244);
        }
      }
      default: {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_x411_246);
        V v_t_2413 = (g_heff_2ecompile_2eir_2epartsOnto(v_x41_244, v_rest_245));
        V t_0 = v_x_240;
        V t_1 = v_k_241;
        V t_2 = v_n_242;
        V t_3 = v_t_2413;
        v_x_240 = t_0;
        v_k_241 = t_1;
        v_n_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      }
    }
    default: {
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2414 = (g_heff_2ecompile_2eir_2epartsOnto(v_x41_244, v_rest_245));
      V t_0 = v_x_240;
      V t_1 = v_k_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2414;
      v_x_240 = t_0;
      v_k_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2elift_2ecallsW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2elift_2ecallsW(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2elift_2eonlyCalled_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2eonlyCalled_entry, 3, 0};

V g_heff_2ecompile_2elift_2eonlyCalled(V v_x_240, V v_k_241, V v_b_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
  V v_x_244 = (g_heff_2ecompile_2elift_2ecallsW(v_x_240, heff_dup(v_k_241), MK_INT(0LL), v_t_243));
  V v_t_245 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_244, 1));
  heff_drop(v_x_244);
  V v_ret_24bool = heff_bool(((heff_dup(v_t_245) == NTAG(TAG_True)) && ({ V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_248 = (g_heff_2ecompile_2elift_2ecallsW(v_x_240, heff_dup(v_k_241), MK_INT(0LL), heff_dup(v_t_246))); int c_ = ({ V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_249 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), heff_dup(v_t_247))); int c_ = heff_intEq_c_lent(v_t_248, v_t_249, 0); heff_drop(v_t_249); c_; }); heff_drop(v_t_247); c_; }); heff_drop(v_t_248); c_; }); heff_drop(v_t_246); c_; })));
  heff_drop(v_k_241);
  heff_drop(v_b_242);
  heff_drop(v_t_245);
  return v_ret_24bool;
}
V g_heff_2ecompile_2elift_2eonlyCalled_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2elift_2eonlyCalled(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2elift_2ecallsOf_lam0(V self, V *args);
V g_heff_2ecompile_2elift_2ecallsOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2elift_2ecallsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2ecallsOf_entry, 4, 0};

V g_heff_2ecompile_2elift_2ecallsOf(V v_x_240, V v_g_241, V v_fvs_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EApp: {
    V v_e1_244 = heff_dup(heff_field(v_e_243, 0));
    switch (heff_tag_of(v_e1_244)) {
    case TAG_EVar: {
      V v_y_246 = heff_field(v_e1_244, 0);
      V v_ru_24e1_244_24EVar = heff_take_reuse_n(v_e1_244, 1ULL, 1);
      switch (heff_tag_of(v_e_243)) {
      case TAG_EApp: {
        V v_args_248 = heff_field(v_e_243, 1);
        V v_ru_24e_243_24EApp = heff_take_reuse_n(v_e_243, 2ULL, 2);
        if (heff_strEq_c_lent(v_y_246, v_x_240, 0)) {
          heff_drop(v_y_246);
          heff_drop_cell(v_ru_24e1_244_24EVar, 1);
          V v_t_249 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ecallsOf_clo), 3, (V[]){v_x_240, heff_dup(v_g_241), heff_dup(v_fvs_242)}));
          V v_t_2410 = (g_list_2emap(v_t_249, v_args_248));
          V v_t_2411 = (g_heff_2ecompile_2eir_2eappendI(v_fvs_242, v_t_2410));
          return heff_tag_at_n(v_ru_24e_243_24EApp, TAG_EApp, 2, (V[]){v_g_241, v_t_2411});
        } else {
          V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ecallsOf_clo), 3, (V[]){v_x_240, v_g_241, v_fvs_242}));
          V v_t_2413 = (g_list_2emap(v_t_2412, v_args_248));
          return heff_tag_at_n(v_ru_24e_243_24EApp, TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24e1_244_24EVar, TAG_EVar, 1, (V[]){v_y_246}), v_t_2413});
        }
      }
      default: return heff_nomatch(v_e_243);
      }
    }
    default: {
      heff_drop(v_e1_244);
      return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2elift_2ecallsOf_lam0, 2, 3, (V[]){v_x_240, v_g_241, v_fvs_242}), v_e_243));
    }
    }
  }
  default: {
    return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2elift_2ecallsOf_lam1, 2, 3, (V[]){v_x_240, v_g_241, v_fvs_242}), v_e_243));
  }
  }
}
V g_heff_2ecompile_2elift_2ecallsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2ecallsOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2elift_2ecallsOf_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_p_2415 = args[1];
  V v_x_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_fvs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2414);
  return (g_heff_2ecompile_2elift_2ecallsOf(v_x_240, v_g_241, v_fvs_242, v_p_2415));
}
V g_heff_2ecompile_2elift_2ecallsOf_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_p_2417 = args[1];
  V v_x_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_fvs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2416);
  return (g_heff_2ecompile_2elift_2ecallsOf(v_x_240, v_g_241, v_fvs_242, v_p_2417));
}
HEFF_LIT(g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str3, 1, ".");
HEFF_LIT(g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str4, 2, "$l");
HEFF_LIT(g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str5, 1, ".");
HEFF_LIT(g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str10, 0, "");
V g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr(V v_tag_240, V v_d_241, V v_acc_242, V v_e_243, V v_d_244, V v_x_245, V v_ys_246, V v_rest_247, V v_x6_248) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876: {
    top_TAG_Enter_24heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876: ;
    heff_drop_rec(v_d_244, 3);
    heff_drop(v_x_245);
    heff_drop(v_ys_246);
    heff_drop(v_rest_247);
    heff_drop(v_x6_248);
    switch (heff_tag_of(v_e_243)) {
    case TAG_ELet: {
      V v_e2_2410 = heff_dup(heff_field(v_e_243, 1));
      switch (heff_tag_of(v_e2_2410)) {
      case TAG_ELam: {
        V v_ys_2412 = heff_field(v_e2_2410, 0);
        V v_body_2413 = heff_field(v_e2_2410, 1);
        V v_ru_24e2_2410_24ELam = heff_take_reuse_n(v_e2_2410, 3ULL, 2);
        switch (heff_tag_of(v_e_243)) {
        case TAG_ELet: {
          V v_x_2414 = heff_field(v_e_243, 0);
          V v_rest_2416 = heff_field(v_e_243, 2);
          V v_ru_24e_243_24ELet = heff_take_reuse_n(v_e_243, 5ULL, 3);
          V v_t_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_2412));
          V v_t_2418 = (g_heff_2ecompile_2elift_2eonlyCalled(v_x_2414, v_t_2417, heff_dup(v_rest_2416)));
          if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
            heff_drop_cell(v_ru_24e2_2410_24ELam, 2);
            heff_drop_cell(v_ru_24e_243_24ELet, 3);
            heff_drop(v_t_2418);
            V v_t_2419 = (g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876(heff_dup(v_d_241), v_acc_242, v_body_2413));
            V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2elift_2ecalledWith_24s1395142400x2053340574);
            V t_1 = ((V)&g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str0);
            V t_2 = ((V)&g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str1);
            V t_3 = ((V)&g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str2);
            V t_4 = v_d_241;
            V t_5 = v_x_2414;
            V t_6 = v_ys_2412;
            V t_7 = v_rest_2416;
            V t_8 = v_t_2419;
            v_tag_240 = t_0;
            v_d_241 = t_1;
            v_acc_242 = t_2;
            v_e_243 = t_3;
            v_d_244 = t_4;
            v_x_245 = t_5;
            v_ys_246 = t_6;
            v_rest_247 = t_7;
            v_x6_248 = t_8;
            goto top_TAG_Enter_24heff_2ecompile_2elift_2ecalledWith_24s1395142400x2053340574;
          } else {
            heff_drop(v_t_2418);
            HeffT2 v_t_2420 = (g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cpr(heff_dup(v_d_241), v_acc_242, v_body_2413));
            {
              V v_field_2421 = v_t_2420.f[0];
              V v_field_2422 = v_t_2420.f[1];
              V v_x_2423 = v_field_2421;
              V v_acc_2424 = v_field_2422;
              HeffT2 v_t_2425 = (g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cpr(v_d_241, v_acc_2424, v_rest_2416));
              {
                V v_field_2426 = v_t_2425.f[0];
                V v_field_2427 = v_t_2425.f[1];
                V v_x_2428 = v_field_2426;
                V v_acc_2429 = v_field_2427;
                V v_t_2430 = heff_tag_at_n(v_ru_24e_243_24ELet, TAG_ELet, 3, (V[]){v_x_2414, heff_tag_at_n(v_ru_24e2_2410_24ELam, TAG_ELam, 2, (V[]){v_ys_2412, v_x_2423}), v_x_2428});
                return ((HeffT2){{v_t_2430, v_acc_2429}});
              }
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_e_243)}});
        }
      }
      default: {
        heff_drop(v_e2_2410);
        return (g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr(heff_clo_n(g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_lam0, 3, 1, (V[]){v_d_241}), v_e_243, v_acc_242));
      }
      }
    }
    default: {
      return (g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr(heff_clo_n(g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_lam1, 3, 1, (V[]){v_d_241}), v_e_243, v_acc_242));
    }
    }
  }
  case TAG_Enter_24heff_2ecompile_2elift_2ecalledWith_24s1395142400x2053340574: {
    top_TAG_Enter_24heff_2ecompile_2elift_2ecalledWith_24s1395142400x2053340574: ;
    heff_drop(v_d_241);
    heff_drop(v_acc_242);
    heff_drop(v_e_243);
    switch (heff_tag_of(v_x6_248)) {
    case TAG_MkPair: {
      V v_body_2437 = heff_field(v_x6_248, 0);
      V v_acc_2438 = heff_field(v_x6_248, 1);
      V v_ru_24x6_248_24MkPair = heff_take_reuse_n(v_x6_248, 3ULL, 2);
      V v_d_2439 = heff_dup(v_d_244);
      V v_t_2440 = heff_strAppend(heff_get_n(v_d_244, 0, 3), ((V)&g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str3));
      V v_t_2441 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_245), MK_INT(0LL)));
      V v_t_2442 = heff_strAppend(heff_strAppend(v_t_2440, v_t_2441), ((V)&g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str4));
      V v_t_2443 = heff_intShow(heff_dup(heff_rfield(v_acc_2438, 1)));
      V v_key_2444 = heff_strAppend(v_t_2442, v_t_2443);
      V v_x_2445 = v_x_245;
      V v_ys_2446 = heff_dup(v_ys_246);
      V v_body_2447 = heff_dup(v_body_2437);
      V v_xs_2448 = heff_tr(g_heff_2ecompile_2elift_2efreeGo(v_ys_246, v_body_2437, NTAG(TAG_Nil)));
      V v_fvs_2449 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2448));
      V v_rest_2450 = v_rest_247;
      V v_acc_2451 = v_acc_2438;
      V v_out_2452 = heff_take_field(v_acc_2451, 0);
      V v_n_2453 = heff_get_n(v_acc_2451, 1, 2);
      V v_t_2454 = heff_strAppend(heff_dup(heff_rfield(v_d_2439, 1)), ((V)&g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str5));
      V v_t_2455 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_2445), MK_INT(0LL)));
      V v_name_2456 = heff_strAppend(v_t_2454, v_t_2455);
      V v_t_2457 = (g_heff_2ecompile_2eir_2eappendI(heff_dup(v_fvs_2449), v_ys_2446));
      V v_body_2458 = heff_tag_at_n(v_ru_24x6_248_24MkPair, TAG_ELam, 2, (V[]){v_t_2457, v_body_2447});
      V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_key_2444), v_name_2456, v_body_2458}), v_out_2452});
      V v_acc_2460 = heff_rec_n(2, shape_out__n, (V[]){v_t_2459, heff_intAdd(v_n_2453, MK_INT(1LL))});
      V v_t_2461 = (g_list_2emap_24s1809017761x1063871171(v_fvs_2449));
      V v_e_2462 = (g_heff_2ecompile_2elift_2ecallsOf(v_x_2445, heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_2444}), v_t_2461, v_rest_2450));
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876);
      V t_1 = v_d_2439;
      V t_2 = v_acc_2460;
      V t_3 = v_e_2462;
      V t_4 = ((V)&g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str6);
      V t_5 = ((V)&g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str7);
      V t_6 = ((V)&g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str8);
      V t_7 = ((V)&g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str9);
      V t_8 = ((V)&g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_str10);
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_acc_242 = t_2;
      v_e_243 = t_3;
      v_d_244 = t_4;
      v_x_245 = t_5;
      v_ys_246 = t_6;
      v_rest_247 = t_7;
      v_x6_248 = t_8;
      goto top_TAG_Enter_24heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876;
    }
    default: return ((HeffT2){{heff_nomatch(v_x6_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_tag_240)}});
  }
}
V g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_lam0(V self, V *args) {
  V v_x_2431 = args[0];
  V v_p_2432 = args[1];
  V v_a_2433 = args[2];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2431);
  return (g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876(v_d_241, v_a_2433, v_p_2432));
}
V g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr_lam1(V self, V *args) {
  V v_x_2434 = args[0];
  V v_p_2435 = args[1];
  V v_a_2436 = args[2];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2434);
  return (g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876(v_d_241, v_a_2436, v_p_2435));
}
HEFF_LIT(g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cpr_str4, 0, "");

HeffT2 g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cpr(V v_d_240, V v_acc_241, V v_e_242) {
top: ;
  return (g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr(NTAG(TAG_Enter_24heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876), v_d_240, v_acc_241, v_e_242, ((V)&g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cpr_str0), ((V)&g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cpr_str1), ((V)&g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cpr_str2), ((V)&g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cpr_str3), ((V)&g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cpr_str4)));
}
Clo g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_entry, 3, 0};

V g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876(V v_d_240, V v_acc_241, V v_e_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cpr(v_d_240, v_acc_241, v_e_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2elift_2ecalledWith_24s1395142400x2053340574_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2ecalledWith_24s1395142400x2053340574_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2ecalledWith_24s1395142400x2053340574_24cpr_str2, 0, "");

HeffT2 g_heff_2ecompile_2elift_2ecalledWith_24s1395142400x2053340574_24cpr(V v_d_240, V v_x_241, V v_ys_242, V v_rest_243, V v_x6_244) {
top: ;
  return (g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cycle_24cpr(NTAG(TAG_Enter_24heff_2ecompile_2elift_2ecalledWith_24s1395142400x2053340574), ((V)&g_heff_2ecompile_2elift_2ecalledWith_24s1395142400x2053340574_24cpr_str0), ((V)&g_heff_2ecompile_2elift_2ecalledWith_24s1395142400x2053340574_24cpr_str1), ((V)&g_heff_2ecompile_2elift_2ecalledWith_24s1395142400x2053340574_24cpr_str2), v_d_240, v_x_241, v_ys_242, v_rest_243, v_x6_244));
}
V g_heff_2ecompile_2elift_2ecalledGo_24s1073939894x271972689_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2elift_2ecalledGo_24s1073939894x271972689_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2ecompile_2elift_2ecalledGo_24s1073939894x271972689_24cpr(V v_lit_240, V v_d_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_ELet: {
    V v_e2_244 = heff_dup(heff_field(v_e_242, 1));
    switch (heff_tag_of(v_e2_244)) {
    case TAG_ELam: {
      V v_ys_246 = heff_field(v_e2_244, 0);
      V v_body_247 = heff_field(v_e2_244, 1);
      V v_ru_24e2_244_24ELam = heff_take_reuse_n(v_e2_244, 3ULL, 2);
      switch (heff_tag_of(v_e_242)) {
      case TAG_ELet: {
        V v_x_248 = heff_field(v_e_242, 0);
        V v_rest_2410 = heff_field(v_e_242, 2);
        V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 5ULL, 3);
        V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_246));
        V v_t_2412 = (g_heff_2ecompile_2elift_2eonlyCalled(v_x_248, v_t_2411, heff_dup(v_rest_2410)));
        if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24e2_244_24ELam, 2);
          heff_drop_cell(v_ru_24e_242_24ELet, 3);
          heff_drop(v_t_2412);
          V v_t_2413 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
          V v_t_2414 = (g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876(heff_dup(v_d_241), v_t_2413, v_body_247));
          return (g_heff_2ecompile_2elift_2ecalledWith_24s1395142400x2053340574_24cpr(v_d_241, v_x_248, v_ys_246, v_rest_2410, v_t_2414));
        } else {
          heff_drop(v_t_2412);
          V v_t_2415 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
          HeffT2 v_t_2416 = (g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cpr(heff_dup(v_d_241), v_t_2415, v_body_247));
          {
            V v_field_2417 = v_t_2416.f[0];
            V v_field_2418 = v_t_2416.f[1];
            V v_x_2419 = v_field_2417;
            V v_acc_2420 = v_field_2418;
            HeffT2 v_t_2421 = (g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876_24cpr(v_d_241, v_acc_2420, v_rest_2410));
            {
              V v_field_2422 = v_t_2421.f[0];
              V v_field_2423 = v_t_2421.f[1];
              V v_x_2424 = v_field_2422;
              V v_acc_2425 = v_field_2423;
              V v_t_2426 = heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_x_248, heff_tag_at_n(v_ru_24e2_244_24ELam, TAG_ELam, 2, (V[]){v_ys_246, v_x_2419}), v_x_2424});
              return ((HeffT2){{v_t_2426, v_acc_2425}});
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    default: {
      heff_drop(v_e2_244);
      V v_t_2427 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
      HEFF_LAST return g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr(heff_clo_n(g_heff_2ecompile_2elift_2ecalledGo_24s1073939894x271972689_24cpr_lam0, 3, 1, (V[]){v_d_241}), v_e_242, v_t_2427);
    }
    }
  }
  default: {
    V v_t_2431 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    HEFF_LAST return g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr(heff_clo_n(g_heff_2ecompile_2elift_2ecalledGo_24s1073939894x271972689_24cpr_lam1, 3, 1, (V[]){v_d_241}), v_e_242, v_t_2431);
  }
  }
}
V g_heff_2ecompile_2elift_2ecalledGo_24s1073939894x271972689_24cpr_lam0(V self, V *args) {
  V v_x_2428 = args[0];
  V v_p_2429 = args[1];
  V v_a_2430 = args[2];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2428);
  return (g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876(v_d_241, v_a_2430, v_p_2429));
}
V g_heff_2ecompile_2elift_2ecalledGo_24s1073939894x271972689_24cpr_lam1(V self, V *args) {
  V v_x_2432 = args[0];
  V v_p_2433 = args[1];
  V v_a_2434 = args[2];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2432);
  return (g_heff_2ecompile_2elift_2ecalledGo_24s1796702001x1901926876(v_d_241, v_a_2434, v_p_2433));
}