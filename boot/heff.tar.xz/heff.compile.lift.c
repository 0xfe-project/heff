// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_Enter_24heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862 13135
#define TAG_Enter_24heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804 50048
#define TAG_Enter_24heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750 8995
#define TAG_MkArm 55352
#define LBL_body 9524841
#define LBL_key 315609
#define LBL_n 328
#define LBL_name 9869138
#define LBL_out 319944
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_out__n[] = {LBL_out, LBL_n};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2elift_2efreeGo(V, V, V);
V g_heff_2ecompile_2elift_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2efreeGo_clo;
HeffT2 g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2elift_2eliftFixDef_24s1197825217x45906855_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2elift_2eliftedDef(V, V, V, V, V);
V g_heff_2ecompile_2elift_2eliftedDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eliftedDef_clo;
HeffT2 g_heff_2ecompile_2elift_2eoneParam_24cpr(V);
V g_heff_2ecompile_2elift_2ereplaceGo(V, V, V);
V g_heff_2ecompile_2elift_2ereplaceGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2ereplaceGo_clo;
V g_heff_2ecompile_2elift_2ereplaceGo_24dps(V, V, V, V, V);
V g_heff_2ecompile_2elift_2ereplaceGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2ereplaceGo_24dps_clo;
V g_heff_2ecompile_2elift_2ewithParams(V, V);
V g_heff_2ecompile_2elift_2ewithParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2ewithParams_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_list_2ezipWith_24s738847920x410598254(V, V);
V g_list_2ezipWith_24s738847920x410598254_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_clo;
V g_heff_2ecompile_2elift_2efreeGo_lam0(V self, V *args);
V g_heff_2ecompile_2elift_2efreeGo_lam1(V self, V *args);
V g_heff_2ecompile_2elift_2efreeGo_lam2(V self, V *args);
V g_heff_2ecompile_2elift_2efreeGo_lam3(V self, V *args);
V g_heff_2ecompile_2elift_2efreeGo_lam4(V self, V *args);
V g_heff_2ecompile_2elift_2efreeGo_lam5(V self, V *args);
Clo g_heff_2ecompile_2elift_2efreeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2efreeGo_entry, 3, 0};

V g_heff_2ecompile_2elift_2efreeGo(V v_bound_240, V v_e_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_243)}));
    V v_t_245 = ({ V a_0 = v_t_244; V a_1 = v_bound_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_bound_240); r_; });
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_x_243);
      heff_drop(v_t_245);
      return v_acc_242;
    } else {
      heff_drop(v_t_245);
      V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_243)}));
      V v_t_247 = (g_list_2eany(v_t_246, v_acc_242));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_x_243);
        heff_drop(v_t_247);
        return v_acc_242;
      } else {
        heff_drop(v_t_247);
        return heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_acc_242});
      }
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_ELam: {
    V v_xs_249 = heff_field(v_e_241, 0);
    V v_b_2410 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2411 = (g_heff_2ecompile_2eir_2eappendI(v_xs_249, v_bound_240));
    V t_0 = v_t_2411;
    V t_1 = v_b_2410;
    V t_2 = v_acc_242;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_e_241, 0);
    V v_args_2413 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2414 = (g_heff_2ecompile_2elift_2efreeGo(heff_dup(v_bound_240), v_f_2412, v_acc_242));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam0, 2, 1, (V[]){v_bound_240}); V a_1 = v_t_2414; V a_2 = v_args_2413; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_args_2413); r_; });
  }
  case TAG_ELet: {
    V v_x_2417 = heff_field(v_e_241, 0);
    V v_a_2418 = heff_field(v_e_241, 1);
    V v_b_2419 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_t_2420 = (g_heff_2ecompile_2elift_2efreeGo(heff_dup(v_bound_240), v_a_2418, v_acc_242));
    V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2417, v_bound_240});
    V t_1 = v_b_2419;
    V t_2 = v_t_2420;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2421 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam1, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_fs_2421; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2421); r_; });
  }
  case TAG_EProj: {
    V v_x_2428 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 4);
    V t_0 = v_bound_240;
    V t_1 = v_x_2428;
    V t_2 = v_acc_242;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_es_2433 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 3);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam2, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_es_2433; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_2433); r_; });
  }
  case TAG_EMatch: {
    V v_x_2437 = heff_field(v_e_241, 0);
    V v_arms_2438 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2439 = (g_heff_2ecompile_2elift_2efreeGo(heff_dup(v_bound_240), v_x_2437, v_acc_242));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam3, 2, 1, (V[]){v_bound_240}); V a_1 = v_t_2439; V a_2 = v_arms_2438; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_arms_2438); r_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EPrimCall: {
    V v_es_2453 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam4, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_es_2453; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_2453); r_; });
  }
  case TAG_ECall: {
    V v_es_2457 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam5, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_es_2457; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_2457); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EFloat: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EAbandon: {
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EFix: {
    V v_f_2467 = heff_field(v_e_241, 0);
    V v_b_2468 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EFix = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V t_0 = heff_tag_at_n(v_ru_24e_241_24EFix, TAG_Cons, 2, (V[]){v_f_2467, v_bound_240});
    V t_1 = v_b_2468;
    V t_2 = v_acc_242;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2elift_2efreeGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2efreeGo(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2elift_2efreeGo_lam0(V self, V *args) {
  V v_a_2415 = args[0];
  V v_x_2416 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2elift_2efreeGo(v_bound_240, v_x_2416, v_a_2415));
}
V g_heff_2ecompile_2elift_2efreeGo_lam1(V self, V *args) {
  V v_a_2423 = args[0];
  V v_f_2424 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427;
  switch (heff_tag_of(v_f_2424)) {
  case TAG_MkPair: {
    V v_y_2426 = heff_field(v_f_2424, 1);
    heff_take_n(v_f_2424, 2ULL, 2);
    v_t_2427 = v_y_2426;
    break;
  }
  default: heff_nomatch(v_f_2424);
  }
  return (g_heff_2ecompile_2elift_2efreeGo(v_bound_240, v_t_2427, v_a_2423));
}
V g_heff_2ecompile_2elift_2efreeGo_lam2(V self, V *args) {
  V v_a_2435 = args[0];
  V v_x_2436 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2elift_2efreeGo(v_bound_240, v_x_2436, v_a_2435));
}
V g_heff_2ecompile_2elift_2efreeGo_lam3(V self, V *args) {
  V v_a_2440 = args[0];
  V v_arm_2441 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2445;
  switch (heff_tag_of(v_arm_2441)) {
  case TAG_MkArm: {
    V v_vs_2443 = heff_dup(heff_field(v_arm_2441, 1));
    v_t_2445 = v_vs_2443;
    break;
  }
  default: heff_nomatch(v_arm_2441);
  }
  V v_t_2446 = (g_heff_2ecompile_2eir_2eappendI(v_t_2445, v_bound_240));
  V v_t_2450;
  switch (heff_tag_of(v_arm_2441)) {
  case TAG_MkArm: {
    V v_b_2449 = heff_field(v_arm_2441, 2);
    heff_take_n(v_arm_2441, 4ULL, 3);
    v_t_2450 = v_b_2449;
    break;
  }
  default: heff_nomatch(v_arm_2441);
  }
  return (g_heff_2ecompile_2elift_2efreeGo(v_t_2446, v_t_2450, v_a_2440));
}
V g_heff_2ecompile_2elift_2efreeGo_lam4(V self, V *args) {
  V v_a_2454 = args[0];
  V v_x_2455 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2elift_2efreeGo(v_bound_240, v_x_2455, v_a_2454));
}
V g_heff_2ecompile_2elift_2efreeGo_lam5(V self, V *args) {
  V v_a_2458 = args[0];
  V v_x_2459 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2elift_2efreeGo(v_bound_240, v_x_2459, v_a_2458));
}
V g_heff_2ecompile_2elift_2ereplaceGo_lam0(V self, V *args);
V g_heff_2ecompile_2elift_2ereplaceGo_lam1(V self, V *args);
Clo g_heff_2ecompile_2elift_2ereplaceGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2ereplaceGo_entry, 3, 0};

V g_heff_2ecompile_2elift_2ereplaceGo(V v_x_240, V v_r_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_dup(heff_field(v_e_242, 0));
    if (heff_strEq_c(v_y_243, v_x_240)) {
      heff_drop_tag(v_e_242, 1);
      return v_r_241;
    } else {
      heff_drop(v_r_241);
      return v_e_242;
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_242, 0);
    V v_b_247 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_cell_248 = heff_tag_at_n(v_ru_24e_242_24ELam, TAG_ELam, 2, (V[]){v_xs_246, heff_hole()});
    V v_u_249 = (g_heff_2ecompile_2elift_2ereplaceGo_24dps(v_x_240, v_r_241, v_b_247, heff_dup(v_cell_248), MK_INT(1LL)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  case TAG_EApp: {
    V v_f_2410 = heff_field(v_e_242, 0);
    V v_args_2411 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2412 = (g_heff_2ecompile_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_f_2410));
    V v_t_2413 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2414 = (g_list_2emap(v_t_2413, v_args_2411));
    return heff_tag_at_n(v_ru_24e_242_24EApp, TAG_EApp, 2, (V[]){v_t_2412, v_t_2414});
  }
  case TAG_ELet: {
    V v_y_2415 = heff_field(v_e_242, 0);
    V v_a_2416 = heff_field(v_e_242, 1);
    V v_b_2417 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2418 = (g_heff_2ecompile_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_a_2416));
    V v_cell_2419 = heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_y_2415, v_t_2418, heff_hole()});
    V v_u_2420 = (g_heff_2ecompile_2elift_2ereplaceGo_24dps(v_x_240, v_r_241, v_b_2417, heff_dup(v_cell_2419), MK_INT(2LL)));
    heff_drop(v_u_2420);
    return v_cell_2419;
  }
  case TAG_ERecord: {
    V v_fs_2421 = heff_field(v_e_242, 0);
    V v_ts_2422 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2431 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elift_2ereplaceGo_lam0, 1, 2, (V[]){v_x_240, v_r_241}), v_fs_2421));
    return heff_tag_at_n(v_ru_24e_242_24ERecord, TAG_ERecord, 2, (V[]){v_t_2431, v_ts_2422});
  }
  case TAG_EProj: {
    V v_y_2432 = heff_field(v_e_242, 0);
    V v_l_2433 = heff_field(v_e_242, 1);
    V v_sh_2434 = heff_field(v_e_242, 2);
    V v_t_2435 = heff_field(v_e_242, 3);
    V v_ru_24e_242_24EProj = heff_take_reuse_n(v_e_242, 15ULL, 4);
    V v_t_2436 = (g_heff_2ecompile_2elift_2ereplaceGo(v_x_240, v_r_241, v_y_2432));
    return heff_tag_at_n(v_ru_24e_242_24EProj, TAG_EProj, 4, (V[]){v_t_2436, v_l_2433, v_sh_2434, v_t_2435});
  }
  case TAG_ETag: {
    V v_t_2437 = heff_field(v_e_242, 0);
    V v_es_2438 = heff_field(v_e_242, 1);
    V v_ts_2439 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2440 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2441 = (g_list_2emap(v_t_2440, v_es_2438));
    return heff_tag_at_n(v_ru_24e_242_24ETag, TAG_ETag, 3, (V[]){v_t_2437, v_t_2441, v_ts_2439});
  }
  case TAG_EMatch: {
    V v_y_2442 = heff_field(v_e_242, 0);
    V v_arms_2443 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2444 = (g_heff_2ecompile_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_y_2442));
    V v_t_2459 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elift_2ereplaceGo_lam1, 1, 2, (V[]){v_x_240, v_r_241}), v_arms_2443));
    return heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_t_2444, v_t_2459});
  }
  case TAG_EPrim: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EPrimCall: {
    V v_p_2461 = heff_field(v_e_242, 0);
    V v_es_2462 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2463 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2464 = (g_list_2emap(v_t_2463, v_es_2462));
    return heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2461, v_t_2464});
  }
  case TAG_ECall: {
    V v_k_2465 = heff_field(v_e_242, 0);
    V v_es_2466 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2467 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2468 = (g_list_2emap(v_t_2467, v_es_2466));
    return heff_tag_at_n(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){v_k_2465, v_t_2468});
  }
  case TAG_EInt: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EFloat: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EStr: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EBytes: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EFixed: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EFloat32: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EFix: {
    V v_f_2476 = heff_field(v_e_242, 0);
    V v_b_2477 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EFix = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_cell_2478 = heff_tag_at_n(v_ru_24e_242_24EFix, TAG_EFix, 2, (V[]){v_f_2476, heff_hole()});
    V v_u_2479 = (g_heff_2ecompile_2elift_2ereplaceGo_24dps(v_x_240, v_r_241, v_b_2477, heff_dup(v_cell_2478), MK_INT(1LL)));
    heff_drop(v_u_2479);
    return v_cell_2478;
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2elift_2ereplaceGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2ereplaceGo(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2elift_2ereplaceGo_lam0(V self, V *args) {
  V v_f_2423 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_r_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426;
  switch (heff_tag_of(v_f_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_dup(heff_field(v_f_2423, 0));
    v_t_2426 = v_x_2424;
    break;
  }
  default: heff_nomatch(v_f_2423);
  }
  V v_t_2429;
  switch (heff_tag_of(v_f_2423)) {
  case TAG_MkPair: {
    V v_y_2428 = heff_field(v_f_2423, 1);
    heff_take_n(v_f_2423, 2ULL, 2);
    v_t_2429 = v_y_2428;
    break;
  }
  default: heff_nomatch(v_f_2423);
  }
  V v_t_2430 = (g_heff_2ecompile_2elift_2ereplaceGo(v_x_240, v_r_241, v_t_2429));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2426, v_t_2430});
}
V g_heff_2ecompile_2elift_2ereplaceGo_lam1(V self, V *args) {
  V v_arm_2445 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_r_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2449;
  switch (heff_tag_of(v_arm_2445)) {
  case TAG_MkArm: {
    V v_t_2446 = heff_dup(heff_field(v_arm_2445, 0));
    v_t_2449 = v_t_2446;
    break;
  }
  default: heff_nomatch(v_arm_2445);
  }
  V v_t_2453;
  switch (heff_tag_of(v_arm_2445)) {
  case TAG_MkArm: {
    V v_vs_2451 = heff_dup(heff_field(v_arm_2445, 1));
    v_t_2453 = v_vs_2451;
    break;
  }
  default: heff_nomatch(v_arm_2445);
  }
  V v_t_2457;
  switch (heff_tag_of(v_arm_2445)) {
  case TAG_MkArm: {
    V v_b_2456 = heff_field(v_arm_2445, 2);
    heff_take_n(v_arm_2445, 4ULL, 3);
    v_t_2457 = v_b_2456;
    break;
  }
  default: heff_nomatch(v_arm_2445);
  }
  V v_t_2458 = (g_heff_2ecompile_2elift_2ereplaceGo(v_x_240, v_r_241, v_t_2457));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2449, v_t_2453, v_t_2458});
}
V g_heff_2ecompile_2elift_2ereplaceGo_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2elift_2ereplaceGo_24dps_lam1(V self, V *args);
Clo g_heff_2ecompile_2elift_2ereplaceGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2ereplaceGo_24dps_entry, 5, 0};

V g_heff_2ecompile_2elift_2ereplaceGo_24dps(V v_x_240, V v_r_241, V v_e_242, V v_d_243, V v_i_244) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_y_245 = heff_dup(heff_field(v_e_242, 0));
    if (heff_strEq_c(v_y_245, v_x_240)) {
      heff_drop_tag(v_e_242, 1);
      return heff_setField(v_d_243, v_i_244, v_r_241);
    } else {
      heff_drop(v_r_241);
      return heff_setField(v_d_243, v_i_244, v_e_242);
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return heff_setField(v_d_243, v_i_244, v_e_242);
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_e_242, 0);
    V v_b_249 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_cell_2410 = heff_tag_at_n(v_ru_24e_242_24ELam, TAG_ELam, 2, (V[]){v_xs_248, heff_hole()});
    V v_u_2411 = heff_setField(v_d_243, v_i_244, heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_x_240;
    V t_1 = v_r_241;
    V t_2 = v_b_249;
    V t_3 = v_cell_2410;
    V t_4 = MK_INT(1LL);
    v_x_240 = t_0;
    v_r_241 = t_1;
    v_e_242 = t_2;
    v_d_243 = t_3;
    v_i_244 = t_4;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_e_242, 0);
    V v_args_2413 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2414 = (g_heff_2ecompile_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_f_2412));
    V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2416 = (g_list_2emap(v_t_2415, v_args_2413));
    return heff_setField(v_d_243, v_i_244, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2414, v_t_2416}));
  }
  case TAG_ELet: {
    V v_y_2417 = heff_field(v_e_242, 0);
    V v_a_2418 = heff_field(v_e_242, 1);
    V v_b_2419 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2420 = (g_heff_2ecompile_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_a_2418));
    V v_cell_2421 = heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_y_2417, v_t_2420, heff_hole()});
    V v_u_2422 = heff_setField(v_d_243, v_i_244, heff_dup(v_cell_2421));
    heff_drop(v_u_2422);
    V t_0 = v_x_240;
    V t_1 = v_r_241;
    V t_2 = v_b_2419;
    V t_3 = v_cell_2421;
    V t_4 = MK_INT(2LL);
    v_x_240 = t_0;
    v_r_241 = t_1;
    v_e_242 = t_2;
    v_d_243 = t_3;
    v_i_244 = t_4;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2423 = heff_field(v_e_242, 0);
    V v_ts_2424 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2433 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elift_2ereplaceGo_24dps_lam0, 1, 2, (V[]){v_x_240, v_r_241}), v_fs_2423));
    return heff_setField(v_d_243, v_i_244, heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2433, v_ts_2424}));
  }
  case TAG_EProj: {
    V v_y_2434 = heff_field(v_e_242, 0);
    V v_l_2435 = heff_field(v_e_242, 1);
    V v_sh_2436 = heff_field(v_e_242, 2);
    V v_t_2437 = heff_field(v_e_242, 3);
    heff_take_n(v_e_242, 15ULL, 4);
    V v_t_2438 = (g_heff_2ecompile_2elift_2ereplaceGo(v_x_240, v_r_241, v_y_2434));
    return heff_setField(v_d_243, v_i_244, heff_tag_n(TAG_EProj, 4, (V[]){v_t_2438, v_l_2435, v_sh_2436, v_t_2437}));
  }
  case TAG_ETag: {
    V v_t_2439 = heff_field(v_e_242, 0);
    V v_es_2440 = heff_field(v_e_242, 1);
    V v_ts_2441 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_2442 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2443 = (g_list_2emap(v_t_2442, v_es_2440));
    return heff_setField(v_d_243, v_i_244, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2439, v_t_2443, v_ts_2441}));
  }
  case TAG_EMatch: {
    V v_y_2444 = heff_field(v_e_242, 0);
    V v_arms_2445 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2446 = (g_heff_2ecompile_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_y_2444));
    V v_t_2461 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elift_2ereplaceGo_24dps_lam1, 1, 2, (V[]){v_x_240, v_r_241}), v_arms_2445));
    return heff_setField(v_d_243, v_i_244, heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2446, v_t_2461}));
  }
  case TAG_EPrim: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return heff_setField(v_d_243, v_i_244, v_e_242);
  }
  case TAG_EPrimCall: {
    V v_p_2463 = heff_field(v_e_242, 0);
    V v_es_2464 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2465 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2466 = (g_list_2emap(v_t_2465, v_es_2464));
    return heff_setField(v_d_243, v_i_244, heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2463, v_t_2466}));
  }
  case TAG_ECall: {
    V v_k_2467 = heff_field(v_e_242, 0);
    V v_es_2468 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2469 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2470 = (g_list_2emap(v_t_2469, v_es_2468));
    return heff_setField(v_d_243, v_i_244, heff_tag_n(TAG_ECall, 2, (V[]){v_k_2467, v_t_2470}));
  }
  case TAG_EInt: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return heff_setField(v_d_243, v_i_244, v_e_242);
  }
  case TAG_EFloat: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return heff_setField(v_d_243, v_i_244, v_e_242);
  }
  case TAG_EStr: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return heff_setField(v_d_243, v_i_244, v_e_242);
  }
  case TAG_EBytes: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return heff_setField(v_d_243, v_i_244, v_e_242);
  }
  case TAG_EFixed: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return heff_setField(v_d_243, v_i_244, v_e_242);
  }
  case TAG_EFloat32: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return heff_setField(v_d_243, v_i_244, v_e_242);
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return heff_setField(v_d_243, v_i_244, v_e_242);
  }
  case TAG_EFix: {
    V v_f_2478 = heff_field(v_e_242, 0);
    V v_b_2479 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EFix = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_cell_2480 = heff_tag_at_n(v_ru_24e_242_24EFix, TAG_EFix, 2, (V[]){v_f_2478, heff_hole()});
    V v_u_2481 = heff_setField(v_d_243, v_i_244, heff_dup(v_cell_2480));
    heff_drop(v_u_2481);
    V t_0 = v_x_240;
    V t_1 = v_r_241;
    V t_2 = v_b_2479;
    V t_3 = v_cell_2480;
    V t_4 = MK_INT(1LL);
    v_x_240 = t_0;
    v_r_241 = t_1;
    v_e_242 = t_2;
    v_d_243 = t_3;
    v_i_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2elift_2ereplaceGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2ereplaceGo_24dps(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2elift_2ereplaceGo_24dps_lam0(V self, V *args) {
  V v_f_2425 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_r_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2428;
  switch (heff_tag_of(v_f_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_dup(heff_field(v_f_2425, 0));
    v_t_2428 = v_x_2426;
    break;
  }
  default: heff_nomatch(v_f_2425);
  }
  V v_t_2431;
  switch (heff_tag_of(v_f_2425)) {
  case TAG_MkPair: {
    V v_y_2430 = heff_field(v_f_2425, 1);
    heff_take_n(v_f_2425, 2ULL, 2);
    v_t_2431 = v_y_2430;
    break;
  }
  default: heff_nomatch(v_f_2425);
  }
  V v_t_2432 = (g_heff_2ecompile_2elift_2ereplaceGo(v_x_240, v_r_241, v_t_2431));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2428, v_t_2432});
}
V g_heff_2ecompile_2elift_2ereplaceGo_24dps_lam1(V self, V *args) {
  V v_arm_2447 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_r_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451;
  switch (heff_tag_of(v_arm_2447)) {
  case TAG_MkArm: {
    V v_t_2448 = heff_dup(heff_field(v_arm_2447, 0));
    v_t_2451 = v_t_2448;
    break;
  }
  default: heff_nomatch(v_arm_2447);
  }
  V v_t_2455;
  switch (heff_tag_of(v_arm_2447)) {
  case TAG_MkArm: {
    V v_vs_2453 = heff_dup(heff_field(v_arm_2447, 1));
    v_t_2455 = v_vs_2453;
    break;
  }
  default: heff_nomatch(v_arm_2447);
  }
  V v_t_2459;
  switch (heff_tag_of(v_arm_2447)) {
  case TAG_MkArm: {
    V v_b_2458 = heff_field(v_arm_2447, 2);
    heff_take_n(v_arm_2447, 4ULL, 3);
    v_t_2459 = v_b_2458;
    break;
  }
  default: heff_nomatch(v_arm_2447);
  }
  V v_t_2460 = (g_heff_2ecompile_2elift_2ereplaceGo(v_x_240, v_r_241, v_t_2459));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2451, v_t_2455, v_t_2460});
}
Clo g_heff_2ecompile_2elift_2ewithParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2ewithParams_entry, 2, 0};

V g_heff_2ecompile_2elift_2ewithParams(V v_fvs_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_fvs_240)) {
  case TAG_Nil: {
    return v_x2_241;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_EVar: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EGlobal: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_x2_241, 0);
      V v_b_247 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2eir_2eappendI(v_fvs_240, v_xs_246));
      return heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_ELam, 2, (V[]){v_t_248, v_b_247});
    }
    case TAG_EApp: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_ELet: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_ERecord: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EProj: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_ETag: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EMatch: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EPrim: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EPrimCall: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_ECall: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EInt: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EFloat: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EStr: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EBytes: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EFixed: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EFloat32: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EAbandon: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EFix: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_fvs_240);
  }
}
V g_heff_2ecompile_2elift_2ewithParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2ewithParams(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2elift_2eliftedDef_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftedDef_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftedDef_str2, 1, ".");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftedDef_str3, 1, "$");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftedDef_str4, 1, ".");
Clo g_heff_2ecompile_2elift_2eliftedDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2eliftedDef_entry, 5, 0};

V g_heff_2ecompile_2elift_2eliftedDef(V v_d_240, V v_n_241, V v_f_242, V v_fvs_243, V v_body_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_f_242), MK_INT(0LL)));
  V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2elift_2eliftedDef_str0), heff_intShow(heff_dup(v_n_241)));
  V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2elift_2eliftedDef_str1), heff_strAppend(v_t_245, v_t_246));
  V v_key_248 = heff_strAppend(heff_dup(heff_rfield(v_d_240, 0)), v_t_247);
  V v_t_249 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_f_242), MK_INT(0LL)));
  V v_name_2410 = heff_strAppend(heff_take_field(v_d_240, 1), heff_strAppend(((V)&g_heff_2ecompile_2elift_2eliftedDef_str2), v_t_249));
  V v_t_2411 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_f_242), MK_INT(0LL)));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2elift_2eliftedDef_str3), heff_intShow(v_n_241));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2elift_2eliftedDef_str4), heff_strAppend(v_t_2411, v_t_2412));
  V v_key_2414 = heff_strAppend(heff_get_n(v_d_240, 0, 3), v_t_2413);
  V v_t_2418;
  switch (heff_tag_of(v_fvs_243)) {
  case TAG_Nil: {
    v_t_2418 = heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_2414});
    break;
  }
  case TAG_Cons: {
    V v_t_2417 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_fvs_243)));
    v_t_2418 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_2414}), v_t_2417});
    break;
  }
  default: heff_nomatch(v_fvs_243);
  }
  V v_t_2419 = (g_heff_2ecompile_2elift_2ereplaceGo(v_f_242, v_t_2418, v_body_244));
  V v_body_2420 = (g_heff_2ecompile_2elift_2ewithParams(v_fvs_243, v_t_2419));
  return heff_rec_n(3, shape_key__name__body, (V[]){v_key_248, v_name_2410, v_body_2420});
}
V g_heff_2ecompile_2elift_2eliftedDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2eliftedDef(a[0], a[1], a[2], a[3], a[4]);
}

HeffT2 g_heff_2ecompile_2elift_2eoneParam_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_e_240, 0);
    V v_b_244 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ELam = heff_take_reuse_n(v_e_240, 3ULL, 2);
    switch (heff_tag_of(v_xs_243)) {
    case TAG_Nil: {
      heff_drop(v_b_244);
      heff_drop_cell(v_ru_24e_240_24ELam, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_xs_243, 0);
      V v_it2_246 = heff_field(v_xs_243, 1);
      heff_take_n(v_xs_243, 3ULL, 2);
      switch (heff_tag_of(v_it2_246)) {
      case TAG_Nil: {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24e_240_24ELam, TAG_MkPair, 2, (V[]){v_x_245, v_b_244})}});
      }
      case TAG_Cons: {
        heff_take_n(v_it2_246, 0ULL, 2);
        heff_drop(v_b_244);
        heff_drop_cell(v_ru_24e_240_24ELam, 2);
        heff_drop(v_x_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it2_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_xs_243)}});
    }
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_e_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_take_na(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}

HeffT2 g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(V v_d_240, V v_acc_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_d_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_acc_241}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_xs_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(heff_dup(v_d_240), v_acc_241, v_x_243));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_x2_248 = v_field_246;
      V v_acc2_249 = v_field_247;
      HeffT2 v_t_2410 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_240, v_acc2_249, v_xs_244));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_xs_2413 = v_field_2411;
        V v_acc_2414 = v_field_2412;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_x2_248, v_xs_2413}), v_acc_2414}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}

HeffT2 g_heff_2ecompile_2elift_2eliftFixDef_24s1197825217x45906855_24cpr(V v_acc_240, V v_fvs_241, V v_ld_242) {
top: ;
  V v_t_243 = heff_intAdd(heff_take_field(v_acc_240, 1), MK_INT(1LL));
  V v_t_244 = ({ V rv_1 = v_t_243; V rr_ = heff_rec_reuse_nf(v_acc_240, 1ULL, 2, shape_out__n, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  HeffT2 v_t_245 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(heff_dup(v_ld_242), v_t_244, heff_dup(heff_rfield(v_ld_242, 2))));
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    V v_b2_248 = v_field_246;
    V v_acc2_249 = v_field_247;
    V v_key_2410 = heff_dup(heff_rfield(v_ld_242, 0));
    V v_f_2414;
    switch (heff_tag_of(v_fvs_241)) {
    case TAG_Nil: {
      v_f_2414 = heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_2410});
      break;
    }
    case TAG_Cons: {
      V v_t_2413 = (g_list_2emap_24s1809017761x1063871171(v_fvs_241));
      v_f_2414 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_2410}), v_t_2413});
      break;
    }
    default: heff_nomatch(v_fvs_241);
    }
    V v_t_2415 = ({ V rv_2 = v_b2_248; V rr_ = heff_rec_reuse_nf(v_ld_242, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_take_field(v_acc2_249, 0)});
    V v_f_2417 = ({ V rv_0 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_acc2_249, 2ULL, 2, shape_out__n, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return ((HeffT2){{v_f_2414, v_f_2417}});
  }
}

HeffT2 g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr(V v_d_240, V v_acc_241, V v_f_242, V v_body_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_f_242), NTAG(TAG_Nil)});
  V v_xs_245 = (g_heff_2ecompile_2elift_2efreeGo(v_t_244, heff_dup(v_body_243), NTAG(TAG_Nil)));
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_f_242), NTAG(TAG_Nil)});
  V v_xs_248 = (g_heff_2ecompile_2elift_2efreeGo(v_t_247, heff_dup(v_body_243), NTAG(TAG_Nil)));
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
  V v_t_2410 = (g_heff_2ecompile_2elift_2eliftedDef(v_d_240, heff_dup(heff_rfield(v_acc_241, 1)), v_f_242, v_t_249, v_body_243));
  return (g_heff_2ecompile_2elift_2eliftFixDef_24s1197825217x45906855_24cpr(v_acc_241, v_t_246, v_t_2410));
}
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str11, 0, "");

HeffT2 g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr(V v_tag_240, V v_d_241, V v_acc_242, V v_x_243, V v_b_244, V v_a_245, V v_d_246, V v_acc_247, V v_f_248, V v_args_249, V v_d_2410, V v_acc_2411, V v_e_2412) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750: {
    top_TAG_Enter_24heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750: ;
    heff_drop(v_d_2410);
    heff_drop(v_acc_2411);
    heff_drop(v_e_2412);
    V v_t_2447;
    switch (heff_tag_of(v_a_245)) {
    case TAG_EVar: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EGlobal: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELam: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EApp: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELet: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ERecord: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EProj: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ETag: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EMatch: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrim: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ECall: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EInt: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EStr: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBytes: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFixed: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat32: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EAbandon: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFix: {
      V v_f_2445 = heff_dup(heff_field(v_a_245, 0));
      V v_b_2446 = heff_dup(heff_field(v_a_245, 1));
      v_t_2447 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_f_2445, v_b_2446})});
      break;
    }
    default: heff_nomatch(v_a_245);
    }
    switch (heff_tag_of(v_t_2447)) {
    case TAG_Nothing: {
      heff_drop(v_d_246);
      heff_drop(v_acc_247);
      heff_drop(v_f_248);
      heff_drop(v_args_249);
      V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
      V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_245), NTAG(TAG_Nil)});
      V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2448, heff_dup(v_b_244)}), v_t_2449});
      HeffT2 v_t_2451 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_241, v_acc_242, v_t_2450));
      {
        V v_field_2452 = v_t_2451.f[0];
        V v_field_2453 = v_t_2451.f[1];
        V v_it1_2454 = v_field_2452;
        V v_acc2_2455 = v_field_2453;
        switch (heff_tag_of(v_it1_2454)) {
        case TAG_Nil: {
          V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
          V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_245, NTAG(TAG_Nil)});
          V v_t_2458 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2456, v_b_244}), v_t_2457});
          return ((HeffT2){{v_t_2458, v_acc2_2455}});
        }
        case TAG_Cons: {
          V v_f2_2459 = heff_field(v_it1_2454, 0);
          V v_as2_2460 = heff_field(v_it1_2454, 1);
          V v_ru_24it1_2454_24Cons = heff_take_reuse_n(v_it1_2454, 3ULL, 2);
          heff_drop(v_x_243);
          heff_drop(v_b_244);
          heff_drop(v_a_245);
          return ((HeffT2){{heff_tag_at_n(v_ru_24it1_2454_24Cons, TAG_EApp, 2, (V[]){v_f2_2459, v_as2_2460}), v_acc2_2455}});
        }
        default: return ((HeffT2){{heff_nomatch(v_it1_2454)}});
        }
      }
    }
    case TAG_Just: {
      V v_it1_2461 = heff_field(v_t_2447, 0);
      heff_take_n(v_t_2447, 1ULL, 1);
      heff_drop(v_a_245);
      switch (heff_tag_of(v_it1_2461)) {
      case TAG_MkPair: {
        V v_f_2462 = heff_field(v_it1_2461, 0);
        V v_fb_2463 = heff_field(v_it1_2461, 1);
        heff_take_n(v_it1_2461, 3ULL, 2);
        HeffT2 v_t_2464 = (g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr(heff_dup(v_d_241), v_acc_242, v_f_2462, v_fb_2463));
        {
          V v_field_2465 = v_t_2464.f[0];
          V v_field_2466 = v_t_2464.f[1];
          V v_call_2467 = v_field_2465;
          V v_acc2_2468 = v_field_2466;
          V v_e_2469 = (g_heff_2ecompile_2elift_2ereplaceGo(v_x_243, v_call_2467, v_b_244));
          V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804);
          V t_1 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str0);
          V t_2 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str1);
          V t_3 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str2);
          V t_4 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str3);
          V t_5 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str4);
          V t_6 = v_d_246;
          V t_7 = v_acc_247;
          V t_8 = v_f_248;
          V t_9 = v_args_249;
          V t_10 = v_d_241;
          V t_11 = v_acc2_2468;
          V t_12 = v_e_2469;
          v_tag_240 = t_0;
          v_d_241 = t_1;
          v_acc_242 = t_2;
          v_x_243 = t_3;
          v_b_244 = t_4;
          v_a_245 = t_5;
          v_d_246 = t_6;
          v_acc_247 = t_7;
          v_f_248 = t_8;
          v_args_249 = t_9;
          v_d_2410 = t_10;
          v_acc_2411 = t_11;
          v_e_2412 = t_12;
          goto top_TAG_Enter_24heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804;
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_2461)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2447)}});
    }
  }
  case TAG_Enter_24heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862: {
    top_TAG_Enter_24heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862: ;
    heff_drop(v_d_241);
    heff_drop(v_acc_242);
    heff_drop(v_x_243);
    heff_drop(v_b_244);
    heff_drop(v_a_245);
    HeffT2 v_t_2470 = (g_heff_2ecompile_2elift_2eoneParam_24cpr(heff_dup(v_f_248)));
    {
      V v_field_2472 = v_t_2470.f[1];
      int64_t v_tag_2471 = ((int64_t)v_t_2470.f[0]);
      if ((v_tag_2471 == ((int64_t)0ULL))) {
        V v_it1_2474 = v_field_2472;
        switch (heff_tag_of(v_it1_2474)) {
        case TAG_MkPair: {
          V v_x_2475 = heff_field(v_it1_2474, 0);
          V v_b_2476 = heff_field(v_it1_2474, 1);
          V v_ru_24it1_2474_24MkPair = heff_take_reuse_n(v_it1_2474, 3ULL, 2);
          switch (heff_tag_of(v_args_249)) {
          case TAG_Nil: {
            heff_drop(v_d_2410);
            heff_drop(v_acc_2411);
            heff_drop(v_e_2412);
            heff_drop(v_x_2475);
            heff_drop(v_b_2476);
            HeffT2 v_t_2477 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_246, v_acc_247, heff_tag_at_n(v_ru_24it1_2474_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_f_248), heff_dup(v_args_249)})));
            {
              V v_field_2478 = v_t_2477.f[0];
              V v_field_2479 = v_t_2477.f[1];
              V v_it1_2480 = v_field_2478;
              V v_acc2_2481 = v_field_2479;
              switch (heff_tag_of(v_it1_2480)) {
              case TAG_Nil: {
                return ((HeffT2){{heff_tag_n(TAG_EApp, 2, (V[]){v_f_248, v_args_249}), v_acc2_2481}});
              }
              case TAG_Cons: {
                V v_f2_2482 = heff_field(v_it1_2480, 0);
                V v_as2_2483 = heff_field(v_it1_2480, 1);
                V v_ru_24it1_2480_24Cons = heff_take_reuse_n(v_it1_2480, 3ULL, 2);
                heff_drop(v_f_248);
                return ((HeffT2){{heff_tag_at_n(v_ru_24it1_2480_24Cons, TAG_EApp, 2, (V[]){v_f2_2482, v_as2_2483}), v_acc2_2481}});
              }
              default: return ((HeffT2){{heff_nomatch(v_it1_2480)}});
              }
            }
          }
          case TAG_Cons: {
            V v_a_2484 = heff_dup(heff_field(v_args_249, 0));
            V v_it2_2485 = heff_dup(heff_field(v_args_249, 1));
            switch (heff_tag_of(v_it2_2485)) {
            case TAG_Nil: {
              heff_drop(v_f_248);
              heff_drop_tag(v_args_249, 2);
              heff_drop_cell(v_ru_24it1_2474_24MkPair, 2);
              V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750);
              V t_1 = v_d_246;
              V t_2 = v_acc_247;
              V t_3 = v_x_2475;
              V t_4 = v_b_2476;
              V t_5 = v_a_2484;
              V t_6 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str5);
              V t_7 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str6);
              V t_8 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str7);
              V t_9 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str8);
              V t_10 = v_d_2410;
              V t_11 = v_acc_2411;
              V t_12 = v_e_2412;
              v_tag_240 = t_0;
              v_d_241 = t_1;
              v_acc_242 = t_2;
              v_x_243 = t_3;
              v_b_244 = t_4;
              v_a_245 = t_5;
              v_d_246 = t_6;
              v_acc_247 = t_7;
              v_f_248 = t_8;
              v_args_249 = t_9;
              v_d_2410 = t_10;
              v_acc_2411 = t_11;
              v_e_2412 = t_12;
              goto top_TAG_Enter_24heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750;
            }
            case TAG_Cons: {
              V v_ru_24it2_2485_24Cons = heff_take_reuse_n(v_it2_2485, 0ULL, 2);
              heff_drop(v_d_2410);
              heff_drop(v_acc_2411);
              heff_drop(v_e_2412);
              heff_drop(v_x_2475);
              heff_drop(v_b_2476);
              heff_drop(v_a_2484);
              HeffT2 v_t_2488 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_246, v_acc_247, heff_tag_at_n(v_ru_24it1_2474_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_f_248), heff_dup(v_args_249)})));
              {
                V v_field_2489 = v_t_2488.f[0];
                V v_field_2490 = v_t_2488.f[1];
                V v_it1_2491 = v_field_2489;
                V v_acc2_2492 = v_field_2490;
                switch (heff_tag_of(v_it1_2491)) {
                case TAG_Nil: {
                  return ((HeffT2){{heff_tag_at_n(v_ru_24it2_2485_24Cons, TAG_EApp, 2, (V[]){v_f_248, v_args_249}), v_acc2_2492}});
                }
                case TAG_Cons: {
                  V v_f2_2493 = heff_field(v_it1_2491, 0);
                  V v_as2_2494 = heff_field(v_it1_2491, 1);
                  heff_take_n(v_it1_2491, 3ULL, 2);
                  heff_drop(v_f_248);
                  heff_drop_tag(v_args_249, 2);
                  return ((HeffT2){{heff_tag_at_n(v_ru_24it2_2485_24Cons, TAG_EApp, 2, (V[]){v_f2_2493, v_as2_2494}), v_acc2_2492}});
                }
                default: return ((HeffT2){{heff_nomatch(v_it1_2491)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_it2_2485)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_args_249)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it1_2474)}});
        }
      } else {
        heff_drop(v_d_2410);
        heff_drop(v_acc_2411);
        heff_drop(v_e_2412);
        heff_drop(v_field_2472);
        HeffT2 v_t_2495 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_246, v_acc_247, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_f_248), heff_dup(v_args_249)})));
        {
          V v_field_2496 = v_t_2495.f[0];
          V v_field_2497 = v_t_2495.f[1];
          V v_it1_2498 = v_field_2496;
          V v_acc2_2499 = v_field_2497;
          switch (heff_tag_of(v_it1_2498)) {
          case TAG_Nil: {
            return ((HeffT2){{heff_tag_n(TAG_EApp, 2, (V[]){v_f_248, v_args_249}), v_acc2_2499}});
          }
          case TAG_Cons: {
            V v_f2_24100 = heff_field(v_it1_2498, 0);
            V v_as2_24101 = heff_field(v_it1_2498, 1);
            V v_ru_24it1_2498_24Cons = heff_take_reuse_n(v_it1_2498, 3ULL, 2);
            heff_drop(v_f_248);
            heff_drop(v_args_249);
            return ((HeffT2){{heff_tag_at_n(v_ru_24it1_2498_24Cons, TAG_EApp, 2, (V[]){v_f2_24100, v_as2_24101}), v_acc2_2499}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it1_2498)}});
          }
        }
      }
    }
  }
  case TAG_Enter_24heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804: {
    top_TAG_Enter_24heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804: ;
    heff_drop(v_d_246);
    heff_drop(v_acc_247);
    heff_drop(v_f_248);
    heff_drop(v_args_249);
    switch (heff_tag_of(v_e_2412)) {
    case TAG_EVar: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_EGlobal: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_ELam: {
      V v_xs_24104 = heff_field(v_e_2412, 0);
      V v_b_24105 = heff_field(v_e_2412, 1);
      V v_ru_24e_2412_24ELam = heff_take_reuse_n(v_e_2412, 3ULL, 2);
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      HeffT2 v_t_24106 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(v_d_2410, v_acc_2411, v_b_24105));
      {
        V v_field_24107 = v_t_24106.f[0];
        V v_field_24108 = v_t_24106.f[1];
        V v_b2_24109 = v_field_24107;
        V v_acc2_24110 = v_field_24108;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_2412_24ELam, TAG_ELam, 2, (V[]){v_xs_24104, v_b2_24109}), v_acc2_24110}});
      }
    }
    case TAG_EApp: {
      V v_f_24111 = heff_field(v_e_2412, 0);
      V v_args_24112 = heff_field(v_e_2412, 1);
      heff_take_n(v_e_2412, 3ULL, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862);
      V t_1 = v_d_241;
      V t_2 = v_acc_242;
      V t_3 = v_x_243;
      V t_4 = v_b_244;
      V t_5 = v_a_245;
      V t_6 = v_d_2410;
      V t_7 = v_acc_2411;
      V t_8 = v_f_24111;
      V t_9 = v_args_24112;
      V t_10 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str9);
      V t_11 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str10);
      V t_12 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str11);
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_acc_242 = t_2;
      v_x_243 = t_3;
      v_b_244 = t_4;
      v_a_245 = t_5;
      v_d_246 = t_6;
      v_acc_247 = t_7;
      v_f_248 = t_8;
      v_args_249 = t_9;
      v_d_2410 = t_10;
      v_acc_2411 = t_11;
      v_e_2412 = t_12;
      goto top_TAG_Enter_24heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862;
    }
    case TAG_ELet: {
      V v_x_24113 = heff_dup(heff_field(v_e_2412, 0));
      V v_a_24114 = heff_dup(heff_field(v_e_2412, 1));
      V v_b_24115 = heff_dup(heff_field(v_e_2412, 2));
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      V v_t_24116 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_24115, NTAG(TAG_Nil)});
      HeffT2 v_t_24117 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_2410, v_acc_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_a_24114, v_t_24116})));
      {
        V v_field_24118 = v_t_24117.f[0];
        V v_field_24119 = v_t_24117.f[1];
        V v_it1_24120 = v_field_24118;
        V v_acc2_24121 = v_field_24119;
        switch (heff_tag_of(v_it1_24120)) {
        case TAG_Nil: {
          heff_drop(v_x_24113);
          return ((HeffT2){{v_e_2412, v_acc2_24121}});
        }
        case TAG_Cons: {
          V v_a2_24122 = heff_field(v_it1_24120, 0);
          V v_it12_24123 = heff_field(v_it1_24120, 1);
          heff_take_n(v_it1_24120, 3ULL, 2);
          switch (heff_tag_of(v_it12_24123)) {
          case TAG_Nil: {
            heff_drop(v_x_24113);
            heff_drop(v_a2_24122);
            return ((HeffT2){{v_e_2412, v_acc2_24121}});
          }
          case TAG_Cons: {
            V v_b2_24124 = heff_field(v_it12_24123, 0);
            V v_it122_24125 = heff_field(v_it12_24123, 1);
            heff_take_n(v_it12_24123, 3ULL, 2);
            switch (heff_tag_of(v_it122_24125)) {
            case TAG_Nil: {
              heff_drop_tag(v_e_2412, 3);
              return ((HeffT2){{heff_tag_n(TAG_ELet, 3, (V[]){v_x_24113, v_a2_24122, v_b2_24124}), v_acc2_24121}});
            }
            case TAG_Cons: {
              heff_take_n(v_it122_24125, 0ULL, 2);
              heff_drop(v_x_24113);
              heff_drop(v_a2_24122);
              heff_drop(v_b2_24124);
              return ((HeffT2){{v_e_2412, v_acc2_24121}});
            }
            default: return ((HeffT2){{heff_nomatch(v_it122_24125)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_it12_24123)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it1_24120)}});
        }
      }
    }
    case TAG_ERecord: {
      V v_fs_24128 = heff_field(v_e_2412, 0);
      V v_ts_24129 = heff_field(v_e_2412, 1);
      V v_ru_24e_2412_24ERecord = heff_take_reuse_n(v_e_2412, 3ULL, 2);
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      V v_t_24130 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_24128)));
      HeffT2 v_t_24131 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_2410, v_acc_2411, v_t_24130));
      {
        V v_field_24132 = v_t_24131.f[0];
        V v_field_24133 = v_t_24131.f[1];
        V v_es_24134 = v_field_24132;
        V v_acc2_24135 = v_field_24133;
        V v_fs2_24136 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_24128, v_es_24134));
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_2412_24ERecord, TAG_ERecord, 2, (V[]){v_fs2_24136, v_ts_24129}), v_acc2_24135}});
      }
    }
    case TAG_EProj: {
      V v_x_24137 = heff_field(v_e_2412, 0);
      V v_l_24138 = heff_field(v_e_2412, 1);
      V v_sh_24139 = heff_field(v_e_2412, 2);
      V v_t_24140 = heff_field(v_e_2412, 3);
      V v_ru_24e_2412_24EProj = heff_take_reuse_n(v_e_2412, 15ULL, 4);
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      HeffT2 v_t_24141 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(v_d_2410, v_acc_2411, v_x_24137));
      {
        V v_field_24142 = v_t_24141.f[0];
        V v_field_24143 = v_t_24141.f[1];
        V v_x2_24144 = v_field_24142;
        V v_acc2_24145 = v_field_24143;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_2412_24EProj, TAG_EProj, 4, (V[]){v_x2_24144, v_l_24138, v_sh_24139, v_t_24140}), v_acc2_24145}});
      }
    }
    case TAG_ETag: {
      V v_t_24146 = heff_field(v_e_2412, 0);
      V v_es_24147 = heff_field(v_e_2412, 1);
      V v_ts_24148 = heff_field(v_e_2412, 2);
      V v_ru_24e_2412_24ETag = heff_take_reuse_n(v_e_2412, 7ULL, 3);
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      HeffT2 v_t_24149 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_2410, v_acc_2411, v_es_24147));
      {
        V v_field_24150 = v_t_24149.f[0];
        V v_field_24151 = v_t_24149.f[1];
        V v_es2_24152 = v_field_24150;
        V v_acc2_24153 = v_field_24151;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_2412_24ETag, TAG_ETag, 3, (V[]){v_t_24146, v_es2_24152, v_ts_24148}), v_acc2_24153}});
      }
    }
    case TAG_EMatch: {
      V v_x_24154 = heff_field(v_e_2412, 0);
      V v_arms_24155 = heff_field(v_e_2412, 1);
      V v_ru_24e_2412_24EMatch = heff_take_reuse_n(v_e_2412, 3ULL, 2);
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      HeffT2 v_t_24156 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(heff_dup(v_d_2410), v_acc_2411, v_x_24154));
      {
        V v_field_24157 = v_t_24156.f[0];
        V v_field_24158 = v_t_24156.f[1];
        V v_x2_24159 = v_field_24157;
        V v_acc2_24160 = v_field_24158;
        V v_t_24161 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_24155)));
        HeffT2 v_t_24162 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_2410, v_acc2_24160, v_t_24161));
        {
          V v_field_24163 = v_t_24162.f[0];
          V v_field_24164 = v_t_24162.f[1];
          V v_bs_24165 = v_field_24163;
          V v_acc2_24166 = v_field_24164;
          V v_arms2_24167 = (g_list_2ezipWith_24s738847920x410598254(v_arms_24155, v_bs_24165));
          return ((HeffT2){{heff_tag_at_n(v_ru_24e_2412_24EMatch, TAG_EMatch, 2, (V[]){v_x2_24159, v_arms2_24167}), v_acc2_24166}});
        }
      }
    }
    case TAG_EPrim: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_EPrimCall: {
      V v_p_24169 = heff_field(v_e_2412, 0);
      V v_es_24170 = heff_field(v_e_2412, 1);
      V v_ru_24e_2412_24EPrimCall = heff_take_reuse_n(v_e_2412, 3ULL, 2);
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      HeffT2 v_t_24171 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_2410, v_acc_2411, v_es_24170));
      {
        V v_field_24172 = v_t_24171.f[0];
        V v_field_24173 = v_t_24171.f[1];
        V v_es2_24174 = v_field_24172;
        V v_acc2_24175 = v_field_24173;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_2412_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_24169, v_es2_24174}), v_acc2_24175}});
      }
    }
    case TAG_ECall: {
      V v_c_24176 = heff_field(v_e_2412, 0);
      V v_es_24177 = heff_field(v_e_2412, 1);
      V v_ru_24e_2412_24ECall = heff_take_reuse_n(v_e_2412, 3ULL, 2);
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      HeffT2 v_t_24178 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_2410, v_acc_2411, v_es_24177));
      {
        V v_field_24179 = v_t_24178.f[0];
        V v_field_24180 = v_t_24178.f[1];
        V v_es2_24181 = v_field_24179;
        V v_acc2_24182 = v_field_24180;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_2412_24ECall, TAG_ECall, 2, (V[]){v_c_24176, v_es2_24181}), v_acc2_24182}});
      }
    }
    case TAG_EInt: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_EFloat: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_EStr: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_EBytes: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_EFixed: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_EFloat32: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_EAbandon: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_EFix: {
      V v_f_24190 = heff_field(v_e_2412, 0);
      V v_b_24191 = heff_field(v_e_2412, 1);
      heff_take_n(v_e_2412, 3ULL, 2);
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      return (g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr(v_d_2410, v_acc_2411, v_f_24190, v_b_24191));
    }
    default: return ((HeffT2){{heff_nomatch(v_e_2412)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_tag_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str7, 0, "");

HeffT2 g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr(V v_d_240, V v_acc_241, V v_f_242, V v_args_243) {
top: ;
  return (g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr(NTAG(TAG_Enter_24heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862), ((V)&g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str0), ((V)&g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str1), ((V)&g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str2), ((V)&g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str3), ((V)&g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str4), v_d_240, v_acc_241, v_f_242, v_args_243, ((V)&g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str5), ((V)&g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str6), ((V)&g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str7)));
}
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str8, 0, "");

HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(V v_d_240, V v_acc_241, V v_e_242) {
top: ;
  return (g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr(NTAG(TAG_Enter_24heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str0), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str1), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str2), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str3), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str4), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str5), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str6), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str7), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str8), v_d_240, v_acc_241, v_e_242));
}

HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(V v_lit_240, V v_d_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_d_241);
    V v_t_244 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_244}});
  }
  case TAG_EGlobal: {
    heff_drop(v_d_241);
    V v_t_246 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_246}});
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_e_242, 0);
    V v_b_248 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_249 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    HeffT2 v_t_2410 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(v_d_241, v_t_249, v_b_248));
    {
      V v_field_2411 = v_t_2410.f[0];
      V v_field_2412 = v_t_2410.f[1];
      V v_b2_2413 = v_field_2411;
      V v_acc2_2414 = v_field_2412;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ELam, TAG_ELam, 2, (V[]){v_xs_247, v_b2_2413}), v_acc2_2414}});
    }
  }
  case TAG_EApp: {
    V v_f_2415 = heff_field(v_e_242, 0);
    V v_args_2416 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2417 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return (g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr(v_d_241, v_t_2417, v_f_2415, v_args_2416));
  }
  case TAG_ELet: {
    V v_x_2418 = heff_dup(heff_field(v_e_242, 0));
    V v_a_2419 = heff_dup(heff_field(v_e_242, 1));
    V v_b_2420 = heff_dup(heff_field(v_e_242, 2));
    V v_t_2421 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2420, NTAG(TAG_Nil)});
    HeffT2 v_t_2423 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_241, v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_a_2419, v_t_2422})));
    {
      V v_field_2424 = v_t_2423.f[0];
      V v_field_2425 = v_t_2423.f[1];
      V v_it1_2426 = v_field_2424;
      V v_acc2_2427 = v_field_2425;
      switch (heff_tag_of(v_it1_2426)) {
      case TAG_Nil: {
        heff_drop(v_x_2418);
        return ((HeffT2){{v_e_242, v_acc2_2427}});
      }
      case TAG_Cons: {
        V v_a2_2428 = heff_field(v_it1_2426, 0);
        V v_it12_2429 = heff_field(v_it1_2426, 1);
        heff_take_n(v_it1_2426, 3ULL, 2);
        switch (heff_tag_of(v_it12_2429)) {
        case TAG_Nil: {
          heff_drop(v_x_2418);
          heff_drop(v_a2_2428);
          return ((HeffT2){{v_e_242, v_acc2_2427}});
        }
        case TAG_Cons: {
          V v_b2_2430 = heff_field(v_it12_2429, 0);
          V v_it122_2431 = heff_field(v_it12_2429, 1);
          heff_take_n(v_it12_2429, 3ULL, 2);
          switch (heff_tag_of(v_it122_2431)) {
          case TAG_Nil: {
            heff_drop_tag(v_e_242, 3);
            return ((HeffT2){{heff_tag_n(TAG_ELet, 3, (V[]){v_x_2418, v_a2_2428, v_b2_2430}), v_acc2_2427}});
          }
          case TAG_Cons: {
            heff_take_n(v_it122_2431, 0ULL, 2);
            heff_drop(v_x_2418);
            heff_drop(v_a2_2428);
            heff_drop(v_b2_2430);
            return ((HeffT2){{v_e_242, v_acc2_2427}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it122_2431)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it12_2429)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_2426)}});
      }
    }
  }
  case TAG_ERecord: {
    V v_fs_2434 = heff_field(v_e_242, 0);
    V v_ts_2435 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2436 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2437 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2434)));
    HeffT2 v_t_2438 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_241, v_t_2436, v_t_2437));
    {
      V v_field_2439 = v_t_2438.f[0];
      V v_field_2440 = v_t_2438.f[1];
      V v_es_2441 = v_field_2439;
      V v_acc2_2442 = v_field_2440;
      V v_fs2_2443 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2434, v_es_2441));
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ERecord, TAG_ERecord, 2, (V[]){v_fs2_2443, v_ts_2435}), v_acc2_2442}});
    }
  }
  case TAG_EProj: {
    V v_x_2444 = heff_field(v_e_242, 0);
    V v_l_2445 = heff_field(v_e_242, 1);
    V v_sh_2446 = heff_field(v_e_242, 2);
    V v_t_2447 = heff_field(v_e_242, 3);
    V v_ru_24e_242_24EProj = heff_take_reuse_n(v_e_242, 15ULL, 4);
    V v_t_2448 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    HeffT2 v_t_2449 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(v_d_241, v_t_2448, v_x_2444));
    {
      V v_field_2450 = v_t_2449.f[0];
      V v_field_2451 = v_t_2449.f[1];
      V v_x2_2452 = v_field_2450;
      V v_acc2_2453 = v_field_2451;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EProj, TAG_EProj, 4, (V[]){v_x2_2452, v_l_2445, v_sh_2446, v_t_2447}), v_acc2_2453}});
    }
  }
  case TAG_ETag: {
    V v_t_2454 = heff_field(v_e_242, 0);
    V v_es_2455 = heff_field(v_e_242, 1);
    V v_ts_2456 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2457 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    HeffT2 v_t_2458 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_241, v_t_2457, v_es_2455));
    {
      V v_field_2459 = v_t_2458.f[0];
      V v_field_2460 = v_t_2458.f[1];
      V v_es2_2461 = v_field_2459;
      V v_acc2_2462 = v_field_2460;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ETag, TAG_ETag, 3, (V[]){v_t_2454, v_es2_2461, v_ts_2456}), v_acc2_2462}});
    }
  }
  case TAG_EMatch: {
    V v_x_2463 = heff_field(v_e_242, 0);
    V v_arms_2464 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2465 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    HeffT2 v_t_2466 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(heff_dup(v_d_241), v_t_2465, v_x_2463));
    {
      V v_field_2467 = v_t_2466.f[0];
      V v_field_2468 = v_t_2466.f[1];
      V v_x2_2469 = v_field_2467;
      V v_acc2_2470 = v_field_2468;
      V v_t_2471 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_2464)));
      HeffT2 v_t_2472 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_241, v_acc2_2470, v_t_2471));
      {
        V v_field_2473 = v_t_2472.f[0];
        V v_field_2474 = v_t_2472.f[1];
        V v_bs_2475 = v_field_2473;
        V v_acc2_2476 = v_field_2474;
        V v_arms2_2477 = (g_list_2ezipWith_24s738847920x410598254(v_arms_2464, v_bs_2475));
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_x2_2469, v_arms2_2477}), v_acc2_2476}});
      }
    }
  }
  case TAG_EPrim: {
    heff_drop(v_d_241);
    V v_t_2479 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_2479}});
  }
  case TAG_EPrimCall: {
    V v_p_2480 = heff_field(v_e_242, 0);
    V v_es_2481 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2482 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    HeffT2 v_t_2483 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_241, v_t_2482, v_es_2481));
    {
      V v_field_2484 = v_t_2483.f[0];
      V v_field_2485 = v_t_2483.f[1];
      V v_es2_2486 = v_field_2484;
      V v_acc2_2487 = v_field_2485;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2480, v_es2_2486}), v_acc2_2487}});
    }
  }
  case TAG_ECall: {
    V v_c_2488 = heff_field(v_e_242, 0);
    V v_es_2489 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2490 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    HeffT2 v_t_2491 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_241, v_t_2490, v_es_2489));
    {
      V v_field_2492 = v_t_2491.f[0];
      V v_field_2493 = v_t_2491.f[1];
      V v_es2_2494 = v_field_2492;
      V v_acc2_2495 = v_field_2493;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){v_c_2488, v_es2_2494}), v_acc2_2495}});
    }
  }
  case TAG_EInt: {
    heff_drop(v_d_241);
    V v_t_2497 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_2497}});
  }
  case TAG_EFloat: {
    heff_drop(v_d_241);
    V v_t_2499 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_2499}});
  }
  case TAG_EStr: {
    heff_drop(v_d_241);
    V v_t_24101 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_24101}});
  }
  case TAG_EBytes: {
    heff_drop(v_d_241);
    V v_t_24103 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_24103}});
  }
  case TAG_EFixed: {
    heff_drop(v_d_241);
    V v_t_24106 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_24106}});
  }
  case TAG_EFloat32: {
    heff_drop(v_d_241);
    V v_t_24108 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_24108}});
  }
  case TAG_EAbandon: {
    heff_drop(v_d_241);
    V v_t_24109 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_24109}});
  }
  case TAG_EFix: {
    V v_f_24110 = heff_field(v_e_242, 0);
    V v_b_24111 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_24112 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return (g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr(v_d_241, v_t_24112, v_f_24110, v_b_24111));
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}