// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Enter_24heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862 13135
#define TAG_Enter_24heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804 50048
#define TAG_Enter_24heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750 8995
#define TAG_MkArm 55352
#define LBL_body 9524841
#define LBL_key 315609
#define LBL_n 328
#define LBL_name 9869138
#define LBL_out 319944
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_out__n[] = {LBL_out, LBL_n};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
HeffT2 g_heff_2ecompile_2eir_2econdFillGo_24cpr(V, V);
V g_heff_2ecompile_2eir_2econdMap(V, V);
V g_heff_2ecompile_2eir_2econdMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
HeffT2 g_heff_2ecompile_2elift_2efixOf_24cpr(V);
V g_heff_2ecompile_2elift_2efreeGo(V, V, V);
V g_heff_2ecompile_2elift_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2efreeGo_clo;
HeffT2 g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2elift_2eliftFixDef_24s1197825217x45906855_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2elift_2eliftedDef(V, V, V, V, V);
V g_heff_2ecompile_2elift_2eliftedDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eliftedDef_clo;
HeffT2 g_heff_2ecompile_2elift_2eoneParam_24cpr(V);
V g_heff_2ecompile_2elift_2ereplaceGo(V, V, V);
V g_heff_2ecompile_2elift_2ereplaceGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2ereplaceGo_clo;
V g_heff_2ecompile_2elift_2ereplaceGo_24dps(V, V, V, V, V);
V g_heff_2ecompile_2elift_2ereplaceGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2ereplaceGo_24dps_clo;
V g_heff_2ecompile_2elift_2ewithParams(V, V);
V g_heff_2ecompile_2elift_2ewithParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2ewithParams_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_list_2ezipWith_24s738847920x410598254(V, V);
V g_list_2ezipWith_24s738847920x410598254_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_clo;
V g_heff_2ecompile_2elift_2efreeGo_lam0(V self, V *args);
V g_heff_2ecompile_2elift_2efreeGo_lam1(V self, V *args);
V g_heff_2ecompile_2elift_2efreeGo_lam2(V self, V *args);
V g_heff_2ecompile_2elift_2efreeGo_lam3(V self, V *args);
V g_heff_2ecompile_2elift_2efreeGo_lam4(V self, V *args);
V g_heff_2ecompile_2elift_2efreeGo_lam5(V self, V *args);
V g_heff_2ecompile_2elift_2efreeGo_lam6(V self, V *args);
V g_heff_2ecompile_2elift_2efreeGo_lam7(V self, V *args);
Clo g_heff_2ecompile_2elift_2efreeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2efreeGo_entry, 3, 0};

V g_heff_2ecompile_2elift_2efreeGo(V v_bound_240, V v_e_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_243)}));
    V v_t_245 = ({ V a_0 = v_t_244; V a_1 = v_bound_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_bound_240); r_; });
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_x_243);
      heff_drop(v_t_245);
      return v_acc_242;
    } else {
      heff_drop(v_t_245);
      V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_243)}));
      V v_t_247 = (g_list_2eany(v_t_246, v_acc_242));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_x_243);
        heff_drop(v_t_247);
        return v_acc_242;
      } else {
        heff_drop(v_t_247);
        return heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_acc_242});
      }
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_ELam: {
    V v_xs_249 = heff_field(v_e_241, 0);
    V v_b_2410 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2411 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24e_241_24ELam, v_xs_249, v_bound_240));
    V t_0 = v_t_2411;
    V t_1 = v_b_2410;
    V t_2 = v_acc_242;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_e_241, 0);
    V v_args_2413 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2414 = (g_heff_2ecompile_2elift_2efreeGo(heff_dup(v_bound_240), v_f_2412, v_acc_242));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam0, 2, 1, (V[]){v_bound_240}); V a_1 = v_t_2414; V a_2 = v_args_2413; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_args_2413); r_; });
  }
  case TAG_ELet: {
    V v_x_2417 = heff_field(v_e_241, 0);
    V v_a_2418 = heff_field(v_e_241, 1);
    V v_b_2419 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_t_2420 = (g_heff_2ecompile_2elift_2efreeGo(heff_dup(v_bound_240), v_a_2418, v_acc_242));
    V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2417, v_bound_240});
    V t_1 = v_b_2419;
    V t_2 = v_t_2420;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2421 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam1, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_fs_2421; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2421); r_; });
  }
  case TAG_EProj: {
    V v_x_2428 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 4);
    V t_0 = v_bound_240;
    V t_1 = v_x_2428;
    V t_2 = v_acc_242;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_es_2433 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 3);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam2, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_es_2433; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_2433); r_; });
  }
  case TAG_EMatch: {
    V v_x_2437 = heff_field(v_e_241, 0);
    V v_arms_2438 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2439 = (g_heff_2ecompile_2elift_2efreeGo(heff_dup(v_bound_240), v_x_2437, v_acc_242));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam3, 2, 1, (V[]){v_bound_240}); V a_1 = v_t_2439; V a_2 = v_arms_2438; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_arms_2438); r_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EPrimCall: {
    V v_es_2453 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam4, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_es_2453; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_2453); r_; });
  }
  case TAG_ECall: {
    V v_es_2457 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam5, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_es_2457; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_2457); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EFloat: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EAbandon: {
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EBool: {
    V v_c_2467 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_t_2468 = ({ V a_0 = v_c_2467; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2467); r_; });
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam6, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_t_2468; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2468); r_; });
  }
  case TAG_ESet: {
    V v_xs_2471 = heff_field(v_e_241, 0);
    V v_a_2472 = heff_field(v_e_241, 1);
    V v_b_2473 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_t_2474 = (g_heff_2ecompile_2eir_2eappendI(v_xs_2471, heff_dup(v_bound_240)));
    V v_t_2475 = (g_heff_2ecompile_2elift_2efreeGo(v_bound_240, v_a_2472, v_acc_242));
    V t_0 = v_t_2474;
    V t_1 = v_b_2473;
    V t_2 = v_t_2475;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  case TAG_EValues: {
    V v_es_2476 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elift_2efreeGo_lam7, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_es_2476; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_2476); r_; });
  }
  case TAG_EFix: {
    V v_f_2479 = heff_field(v_e_241, 0);
    V v_b_2480 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EFix = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V t_0 = heff_tag_at_n(v_ru_24e_241_24EFix, TAG_Cons, 2, (V[]){v_f_2479, v_bound_240});
    V t_1 = v_b_2480;
    V t_2 = v_acc_242;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2elift_2efreeGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2efreeGo(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2elift_2efreeGo_lam0(V self, V *args) {
  V v_a_2415 = args[0];
  V v_x_2416 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2elift_2efreeGo(v_bound_240, v_x_2416, v_a_2415));
}
V g_heff_2ecompile_2elift_2efreeGo_lam1(V self, V *args) {
  V v_a_2423 = args[0];
  V v_f_2424 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427;
  switch (heff_tag_of(v_f_2424)) {
  case TAG_MkPair: {
    V v_y_2426 = heff_field(v_f_2424, 1);
    heff_take_n(v_f_2424, 2ULL, 2);
    v_t_2427 = v_y_2426;
    break;
  }
  default: heff_nomatch(v_f_2424);
  }
  return (g_heff_2ecompile_2elift_2efreeGo(v_bound_240, v_t_2427, v_a_2423));
}
V g_heff_2ecompile_2elift_2efreeGo_lam2(V self, V *args) {
  V v_a_2435 = args[0];
  V v_x_2436 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2elift_2efreeGo(v_bound_240, v_x_2436, v_a_2435));
}
V g_heff_2ecompile_2elift_2efreeGo_lam3(V self, V *args) {
  V v_a_2440 = args[0];
  V v_arm_2441 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2445;
  switch (heff_tag_of(v_arm_2441)) {
  case TAG_MkArm: {
    V v_vs_2443 = heff_dup(heff_field(v_arm_2441, 1));
    v_t_2445 = v_vs_2443;
    break;
  }
  default: heff_nomatch(v_arm_2441);
  }
  V v_t_2446 = (g_heff_2ecompile_2eir_2eappendI(v_t_2445, v_bound_240));
  V v_t_2450;
  switch (heff_tag_of(v_arm_2441)) {
  case TAG_MkArm: {
    V v_b_2449 = heff_field(v_arm_2441, 2);
    heff_take_n(v_arm_2441, 4ULL, 3);
    v_t_2450 = v_b_2449;
    break;
  }
  default: heff_nomatch(v_arm_2441);
  }
  return (g_heff_2ecompile_2elift_2efreeGo(v_t_2446, v_t_2450, v_a_2440));
}
V g_heff_2ecompile_2elift_2efreeGo_lam4(V self, V *args) {
  V v_a_2454 = args[0];
  V v_x_2455 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2elift_2efreeGo(v_bound_240, v_x_2455, v_a_2454));
}
V g_heff_2ecompile_2elift_2efreeGo_lam5(V self, V *args) {
  V v_a_2458 = args[0];
  V v_x_2459 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2elift_2efreeGo(v_bound_240, v_x_2459, v_a_2458));
}
V g_heff_2ecompile_2elift_2efreeGo_lam6(V self, V *args) {
  V v_a_2469 = args[0];
  V v_x_2470 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2elift_2efreeGo(v_bound_240, v_x_2470, v_a_2469));
}
V g_heff_2ecompile_2elift_2efreeGo_lam7(V self, V *args) {
  V v_a_2477 = args[0];
  V v_x_2478 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2elift_2efreeGo(v_bound_240, v_x_2478, v_a_2477));
}
V g_heff_2ecompile_2elift_2ereplaceGo_lam0(V self, V *args);
V g_heff_2ecompile_2elift_2ereplaceGo_lam1(V self, V *args);
Clo g_heff_2ecompile_2elift_2ereplaceGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2ereplaceGo_entry, 3, 0};

V g_heff_2ecompile_2elift_2ereplaceGo(V v_x_240, V v_r_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_dup(heff_field(v_e_242, 0));
    if (heff_strEq_c(v_y_243, v_x_240)) {
      heff_drop_tag(v_e_242, 1);
      return v_r_241;
    } else {
      heff_drop(v_r_241);
      return v_e_242;
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_e_242, 0);
    V v_b_246 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_cell_247 = heff_tag_at_n(v_ru_24e_242_24ELam, TAG_ELam, 2, (V[]){v_xs_245, heff_hole()});
    V v_u_248 = (g_heff_2ecompile_2elift_2ereplaceGo_24dps(v_x_240, v_r_241, v_b_246, heff_dup(v_cell_247), MK_INT(1LL)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  case TAG_EApp: {
    V v_f_249 = heff_field(v_e_242, 0);
    V v_args_2410 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2411 = (g_heff_2ecompile_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_f_249));
    V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2413 = (g_list_2emap(v_t_2412, v_args_2410));
    return heff_tag_at_n(v_ru_24e_242_24EApp, TAG_EApp, 2, (V[]){v_t_2411, v_t_2413});
  }
  case TAG_ELet: {
    V v_y_2414 = heff_field(v_e_242, 0);
    V v_a_2415 = heff_field(v_e_242, 1);
    V v_b_2416 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2417 = (g_heff_2ecompile_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_a_2415));
    V v_cell_2418 = heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_y_2414, v_t_2417, heff_hole()});
    V v_u_2419 = (g_heff_2ecompile_2elift_2ereplaceGo_24dps(v_x_240, v_r_241, v_b_2416, heff_dup(v_cell_2418), MK_INT(2LL)));
    heff_drop(v_u_2419);
    return v_cell_2418;
  }
  case TAG_ERecord: {
    V v_fs_2420 = heff_field(v_e_242, 0);
    V v_ts_2421 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2430 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elift_2ereplaceGo_lam0, 1, 2, (V[]){v_x_240, v_r_241}), v_fs_2420));
    return heff_tag_at_n(v_ru_24e_242_24ERecord, TAG_ERecord, 2, (V[]){v_t_2430, v_ts_2421});
  }
  case TAG_EProj: {
    V v_y_2431 = heff_field(v_e_242, 0);
    V v_l_2432 = heff_field(v_e_242, 1);
    V v_sh_2433 = heff_field(v_e_242, 2);
    V v_t_2434 = heff_field(v_e_242, 3);
    V v_ru_24e_242_24EProj = heff_take_reuse_n(v_e_242, 15ULL, 4);
    V v_t_2435 = (g_heff_2ecompile_2elift_2ereplaceGo(v_x_240, v_r_241, v_y_2431));
    return heff_tag_at_n(v_ru_24e_242_24EProj, TAG_EProj, 4, (V[]){v_t_2435, v_l_2432, v_sh_2433, v_t_2434});
  }
  case TAG_ETag: {
    V v_t_2436 = heff_field(v_e_242, 0);
    V v_es_2437 = heff_field(v_e_242, 1);
    V v_ts_2438 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2439 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2440 = (g_list_2emap(v_t_2439, v_es_2437));
    return heff_tag_at_n(v_ru_24e_242_24ETag, TAG_ETag, 3, (V[]){v_t_2436, v_t_2440, v_ts_2438});
  }
  case TAG_EMatch: {
    V v_y_2441 = heff_field(v_e_242, 0);
    V v_arms_2442 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2443 = (g_heff_2ecompile_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_y_2441));
    V v_t_2458 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elift_2ereplaceGo_lam1, 1, 2, (V[]){v_x_240, v_r_241}), v_arms_2442));
    return heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_t_2443, v_t_2458});
  }
  case TAG_EPrim: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EPrimCall: {
    V v_p_2460 = heff_field(v_e_242, 0);
    V v_es_2461 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2462 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2463 = (g_list_2emap(v_t_2462, v_es_2461));
    return heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2460, v_t_2463});
  }
  case TAG_ECall: {
    V v_k_2464 = heff_field(v_e_242, 0);
    V v_es_2465 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2466 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2467 = (g_list_2emap(v_t_2466, v_es_2465));
    return heff_tag_at_n(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){v_k_2464, v_t_2467});
  }
  case TAG_EInt: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EFloat: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EStr: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EBytes: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EFixed: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EFloat32: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EBool: {
    V v_c_2475 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EBool = heff_take_reuse_n(v_e_242, 1ULL, 1);
    V v_t_2476 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2477 = (g_heff_2ecompile_2eir_2econdMap(v_t_2476, v_c_2475));
    return heff_tag_at_n(v_ru_24e_242_24EBool, TAG_EBool, 1, (V[]){v_t_2477});
  }
  case TAG_ESet: {
    V v_xs_2478 = heff_field(v_e_242, 0);
    V v_a_2479 = heff_field(v_e_242, 1);
    V v_b_2480 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ESet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2481 = (g_heff_2ecompile_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_a_2479));
    V v_cell_2482 = heff_tag_at_n(v_ru_24e_242_24ESet, TAG_ESet, 3, (V[]){v_xs_2478, v_t_2481, heff_hole()});
    V v_u_2483 = (g_heff_2ecompile_2elift_2ereplaceGo_24dps(v_x_240, v_r_241, v_b_2480, heff_dup(v_cell_2482), MK_INT(2LL)));
    heff_drop(v_u_2483);
    return v_cell_2482;
  }
  case TAG_EValues: {
    V v_es_2484 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EValues = heff_take_reuse_n(v_e_242, 1ULL, 1);
    V v_t_2485 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2486 = (g_list_2emap(v_t_2485, v_es_2484));
    return heff_tag_at_n(v_ru_24e_242_24EValues, TAG_EValues, 1, (V[]){v_t_2486});
  }
  case TAG_EFix: {
    V v_f_2487 = heff_field(v_e_242, 0);
    V v_b_2488 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EFix = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_cell_2489 = heff_tag_at_n(v_ru_24e_242_24EFix, TAG_EFix, 2, (V[]){v_f_2487, heff_hole()});
    V v_u_2490 = (g_heff_2ecompile_2elift_2ereplaceGo_24dps(v_x_240, v_r_241, v_b_2488, heff_dup(v_cell_2489), MK_INT(1LL)));
    heff_drop(v_u_2490);
    return v_cell_2489;
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2elift_2ereplaceGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2ereplaceGo(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2elift_2ereplaceGo_lam0(V self, V *args) {
  V v_f_2422 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_r_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425;
  switch (heff_tag_of(v_f_2422)) {
  case TAG_MkPair: {
    V v_x_2423 = heff_dup(heff_field(v_f_2422, 0));
    v_t_2425 = v_x_2423;
    break;
  }
  default: heff_nomatch(v_f_2422);
  }
  V v_t_2428;
  switch (heff_tag_of(v_f_2422)) {
  case TAG_MkPair: {
    V v_y_2427 = heff_field(v_f_2422, 1);
    heff_take_n(v_f_2422, 2ULL, 2);
    v_t_2428 = v_y_2427;
    break;
  }
  default: heff_nomatch(v_f_2422);
  }
  V v_t_2429 = (g_heff_2ecompile_2elift_2ereplaceGo(v_x_240, v_r_241, v_t_2428));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2425, v_t_2429});
}
V g_heff_2ecompile_2elift_2ereplaceGo_lam1(V self, V *args) {
  V v_arm_2444 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_r_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2448;
  switch (heff_tag_of(v_arm_2444)) {
  case TAG_MkArm: {
    V v_t_2445 = heff_dup(heff_field(v_arm_2444, 0));
    v_t_2448 = v_t_2445;
    break;
  }
  default: heff_nomatch(v_arm_2444);
  }
  V v_t_2452;
  switch (heff_tag_of(v_arm_2444)) {
  case TAG_MkArm: {
    V v_vs_2450 = heff_dup(heff_field(v_arm_2444, 1));
    v_t_2452 = v_vs_2450;
    break;
  }
  default: heff_nomatch(v_arm_2444);
  }
  V v_t_2456;
  switch (heff_tag_of(v_arm_2444)) {
  case TAG_MkArm: {
    V v_b_2455 = heff_field(v_arm_2444, 2);
    heff_take_n(v_arm_2444, 4ULL, 3);
    v_t_2456 = v_b_2455;
    break;
  }
  default: heff_nomatch(v_arm_2444);
  }
  V v_t_2457 = (g_heff_2ecompile_2elift_2ereplaceGo(v_x_240, v_r_241, v_t_2456));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2448, v_t_2452, v_t_2457});
}
V g_heff_2ecompile_2elift_2ereplaceGo_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2elift_2ereplaceGo_24dps_lam1(V self, V *args);
Clo g_heff_2ecompile_2elift_2ereplaceGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2ereplaceGo_24dps_entry, 5, 0};

V g_heff_2ecompile_2elift_2ereplaceGo_24dps(V v_x_240, V v_r_241, V v_e_242, V v_d_243, V v_i_244) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_y_245 = heff_dup(heff_field(v_e_242, 0));
    if (heff_strEq_c(v_y_245, v_x_240)) {
      heff_drop_tag(v_e_242, 1);
      return heff_setField(v_d_243, v_i_244, v_r_241);
    } else {
      heff_drop(v_r_241);
      return heff_setField(v_d_243, v_i_244, v_e_242);
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return heff_setField(v_d_243, v_i_244, v_e_242);
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_e_242, 0);
    V v_b_248 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_cell_249 = heff_tag_at_n(v_ru_24e_242_24ELam, TAG_ELam, 2, (V[]){v_xs_247, heff_hole()});
    V v_u_2410 = heff_setField(v_d_243, v_i_244, heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_x_240;
    V t_1 = v_r_241;
    V t_2 = v_b_248;
    V t_3 = v_cell_249;
    V t_4 = MK_INT(1LL);
    v_x_240 = t_0;
    v_r_241 = t_1;
    v_e_242 = t_2;
    v_d_243 = t_3;
    v_i_244 = t_4;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2411 = heff_field(v_e_242, 0);
    V v_args_2412 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2413 = (g_heff_2ecompile_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_f_2411));
    V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2415 = (g_list_2emap_24tok2(v_ru_24e_242_24EApp, v_t_2414, v_args_2412));
    return heff_setField(v_d_243, v_i_244, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2413, v_t_2415}));
  }
  case TAG_ELet: {
    V v_y_2416 = heff_field(v_e_242, 0);
    V v_a_2417 = heff_field(v_e_242, 1);
    V v_b_2418 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2419 = (g_heff_2ecompile_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_a_2417));
    V v_cell_2420 = heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_y_2416, v_t_2419, heff_hole()});
    V v_u_2421 = heff_setField(v_d_243, v_i_244, heff_dup(v_cell_2420));
    heff_drop(v_u_2421);
    V t_0 = v_x_240;
    V t_1 = v_r_241;
    V t_2 = v_b_2418;
    V t_3 = v_cell_2420;
    V t_4 = MK_INT(2LL);
    v_x_240 = t_0;
    v_r_241 = t_1;
    v_e_242 = t_2;
    v_d_243 = t_3;
    v_i_244 = t_4;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2422 = heff_field(v_e_242, 0);
    V v_ts_2423 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2432 = (g_list_2emap_24tok2(v_ru_24e_242_24ERecord, heff_clo_n(g_heff_2ecompile_2elift_2ereplaceGo_24dps_lam0, 1, 2, (V[]){v_x_240, v_r_241}), v_fs_2422));
    return heff_setField(v_d_243, v_i_244, heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2432, v_ts_2423}));
  }
  case TAG_EProj: {
    V v_y_2433 = heff_field(v_e_242, 0);
    V v_l_2434 = heff_field(v_e_242, 1);
    V v_sh_2435 = heff_field(v_e_242, 2);
    V v_t_2436 = heff_field(v_e_242, 3);
    heff_take_n(v_e_242, 15ULL, 4);
    V v_t_2437 = (g_heff_2ecompile_2elift_2ereplaceGo(v_x_240, v_r_241, v_y_2433));
    return heff_setField(v_d_243, v_i_244, heff_tag_n(TAG_EProj, 4, (V[]){v_t_2437, v_l_2434, v_sh_2435, v_t_2436}));
  }
  case TAG_ETag: {
    V v_t_2438 = heff_field(v_e_242, 0);
    V v_es_2439 = heff_field(v_e_242, 1);
    V v_ts_2440 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_2441 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2442 = (g_list_2emap(v_t_2441, v_es_2439));
    return heff_setField(v_d_243, v_i_244, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2438, v_t_2442, v_ts_2440}));
  }
  case TAG_EMatch: {
    V v_y_2443 = heff_field(v_e_242, 0);
    V v_arms_2444 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2445 = (g_heff_2ecompile_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_y_2443));
    V v_t_2460 = (g_list_2emap_24tok2(v_ru_24e_242_24EMatch, heff_clo_n(g_heff_2ecompile_2elift_2ereplaceGo_24dps_lam1, 1, 2, (V[]){v_x_240, v_r_241}), v_arms_2444));
    return heff_setField(v_d_243, v_i_244, heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2445, v_t_2460}));
  }
  case TAG_EPrim: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return heff_setField(v_d_243, v_i_244, v_e_242);
  }
  case TAG_EPrimCall: {
    V v_p_2462 = heff_field(v_e_242, 0);
    V v_es_2463 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2464 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2465 = (g_list_2emap_24tok2(v_ru_24e_242_24EPrimCall, v_t_2464, v_es_2463));
    return heff_setField(v_d_243, v_i_244, heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2462, v_t_2465}));
  }
  case TAG_ECall: {
    V v_k_2466 = heff_field(v_e_242, 0);
    V v_es_2467 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2468 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2469 = (g_list_2emap_24tok2(v_ru_24e_242_24ECall, v_t_2468, v_es_2467));
    return heff_setField(v_d_243, v_i_244, heff_tag_n(TAG_ECall, 2, (V[]){v_k_2466, v_t_2469}));
  }
  case TAG_EInt: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return heff_setField(v_d_243, v_i_244, v_e_242);
  }
  case TAG_EFloat: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return heff_setField(v_d_243, v_i_244, v_e_242);
  }
  case TAG_EStr: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return heff_setField(v_d_243, v_i_244, v_e_242);
  }
  case TAG_EBytes: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return heff_setField(v_d_243, v_i_244, v_e_242);
  }
  case TAG_EFixed: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return heff_setField(v_d_243, v_i_244, v_e_242);
  }
  case TAG_EFloat32: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return heff_setField(v_d_243, v_i_244, v_e_242);
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return heff_setField(v_d_243, v_i_244, v_e_242);
  }
  case TAG_EBool: {
    V v_c_2477 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_t_2478 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2479 = (g_heff_2ecompile_2eir_2econdMap(v_t_2478, v_c_2477));
    return heff_setField(v_d_243, v_i_244, heff_tag_n(TAG_EBool, 1, (V[]){v_t_2479}));
  }
  case TAG_ESet: {
    V v_xs_2480 = heff_field(v_e_242, 0);
    V v_a_2481 = heff_field(v_e_242, 1);
    V v_b_2482 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ESet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2483 = (g_heff_2ecompile_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_a_2481));
    V v_cell_2484 = heff_tag_at_n(v_ru_24e_242_24ESet, TAG_ESet, 3, (V[]){v_xs_2480, v_t_2483, heff_hole()});
    V v_u_2485 = heff_setField(v_d_243, v_i_244, heff_dup(v_cell_2484));
    heff_drop(v_u_2485);
    V t_0 = v_x_240;
    V t_1 = v_r_241;
    V t_2 = v_b_2482;
    V t_3 = v_cell_2484;
    V t_4 = MK_INT(2LL);
    v_x_240 = t_0;
    v_r_241 = t_1;
    v_e_242 = t_2;
    v_d_243 = t_3;
    v_i_244 = t_4;
    goto top;
  }
  case TAG_EValues: {
    V v_es_2486 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_t_2487 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    V v_t_2488 = (g_list_2emap(v_t_2487, v_es_2486));
    return heff_setField(v_d_243, v_i_244, heff_tag_n(TAG_EValues, 1, (V[]){v_t_2488}));
  }
  case TAG_EFix: {
    V v_f_2489 = heff_field(v_e_242, 0);
    V v_b_2490 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EFix = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_cell_2491 = heff_tag_at_n(v_ru_24e_242_24EFix, TAG_EFix, 2, (V[]){v_f_2489, heff_hole()});
    V v_u_2492 = heff_setField(v_d_243, v_i_244, heff_dup(v_cell_2491));
    heff_drop(v_u_2492);
    V t_0 = v_x_240;
    V t_1 = v_r_241;
    V t_2 = v_b_2490;
    V t_3 = v_cell_2491;
    V t_4 = MK_INT(1LL);
    v_x_240 = t_0;
    v_r_241 = t_1;
    v_e_242 = t_2;
    v_d_243 = t_3;
    v_i_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2elift_2ereplaceGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2ereplaceGo_24dps(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2elift_2ereplaceGo_24dps_lam0(V self, V *args) {
  V v_f_2424 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_r_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427;
  switch (heff_tag_of(v_f_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_dup(heff_field(v_f_2424, 0));
    v_t_2427 = v_x_2425;
    break;
  }
  default: heff_nomatch(v_f_2424);
  }
  V v_t_2430;
  switch (heff_tag_of(v_f_2424)) {
  case TAG_MkPair: {
    V v_y_2429 = heff_field(v_f_2424, 1);
    heff_take_n(v_f_2424, 2ULL, 2);
    v_t_2430 = v_y_2429;
    break;
  }
  default: heff_nomatch(v_f_2424);
  }
  V v_t_2431 = (g_heff_2ecompile_2elift_2ereplaceGo(v_x_240, v_r_241, v_t_2430));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2427, v_t_2431});
}
V g_heff_2ecompile_2elift_2ereplaceGo_24dps_lam1(V self, V *args) {
  V v_arm_2446 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_r_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2450;
  switch (heff_tag_of(v_arm_2446)) {
  case TAG_MkArm: {
    V v_t_2447 = heff_dup(heff_field(v_arm_2446, 0));
    v_t_2450 = v_t_2447;
    break;
  }
  default: heff_nomatch(v_arm_2446);
  }
  V v_t_2454;
  switch (heff_tag_of(v_arm_2446)) {
  case TAG_MkArm: {
    V v_vs_2452 = heff_dup(heff_field(v_arm_2446, 1));
    v_t_2454 = v_vs_2452;
    break;
  }
  default: heff_nomatch(v_arm_2446);
  }
  V v_t_2458;
  switch (heff_tag_of(v_arm_2446)) {
  case TAG_MkArm: {
    V v_b_2457 = heff_field(v_arm_2446, 2);
    heff_take_n(v_arm_2446, 4ULL, 3);
    v_t_2458 = v_b_2457;
    break;
  }
  default: heff_nomatch(v_arm_2446);
  }
  V v_t_2459 = (g_heff_2ecompile_2elift_2ereplaceGo(v_x_240, v_r_241, v_t_2458));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2450, v_t_2454, v_t_2459});
}
Clo g_heff_2ecompile_2elift_2ewithParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2ewithParams_entry, 2, 0};

V g_heff_2ecompile_2elift_2ewithParams(V v_fvs_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_fvs_240)) {
  case TAG_Nil: {
    return v_x2_241;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_EVar: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EGlobal: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_x2_241, 0);
      V v_b_247 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2eir_2eappendI(v_fvs_240, v_xs_246));
      return heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_ELam, 2, (V[]){v_t_248, v_b_247});
    }
    case TAG_EApp: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_ELet: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_ERecord: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EProj: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_ETag: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EMatch: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EPrim: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EPrimCall: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_ECall: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EInt: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EFloat: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EStr: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EBytes: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EFixed: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EFloat32: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EAbandon: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EBool: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_ESet: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EValues: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    case TAG_EFix: {
      return heff_tag_n(TAG_ELam, 2, (V[]){v_fvs_240, v_x2_241});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_fvs_240);
  }
}
V g_heff_2ecompile_2elift_2ewithParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2ewithParams(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2elift_2eliftedDef_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftedDef_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftedDef_str2, 1, ".");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftedDef_str3, 1, "$");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftedDef_str4, 1, ".");
Clo g_heff_2ecompile_2elift_2eliftedDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elift_2eliftedDef_entry, 5, 0};

V g_heff_2ecompile_2elift_2eliftedDef(V v_d_240, V v_n_241, V v_f_242, V v_fvs_243, V v_body_244) {
top: ;
  V v_key_245 = heff_take_field(v_d_240, 0);
  V v_name_246 = heff_get_n(v_d_240, 1, 3);
  V v_t_247 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_f_242), MK_INT(0LL)));
  V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2elift_2eliftedDef_str0), heff_intShow(heff_dup(v_n_241)));
  V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2elift_2eliftedDef_str1), heff_strAppend(v_t_247, v_t_248));
  V v_key_2410 = heff_strAppend(heff_dup(v_key_245), v_t_249);
  V v_t_2411 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_f_242), MK_INT(0LL)));
  V v_name_2412 = heff_strAppend(v_name_246, heff_strAppend(((V)&g_heff_2ecompile_2elift_2eliftedDef_str2), v_t_2411));
  V v_t_2413 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_f_242), MK_INT(0LL)));
  V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2elift_2eliftedDef_str3), heff_intShow(v_n_241));
  V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2elift_2eliftedDef_str4), heff_strAppend(v_t_2413, v_t_2414));
  V v_key_2416 = heff_strAppend(v_key_245, v_t_2415);
  V v_t_2420;
  switch (heff_tag_of(v_fvs_243)) {
  case TAG_Nil: {
    v_t_2420 = heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_2416});
    break;
  }
  case TAG_Cons: {
    V v_t_2419 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_fvs_243)));
    v_t_2420 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_2416}), v_t_2419});
    break;
  }
  default: heff_nomatch(v_fvs_243);
  }
  V v_t_2421 = (g_heff_2ecompile_2elift_2ereplaceGo(v_f_242, v_t_2420, v_body_244));
  V v_body_2422 = (g_heff_2ecompile_2elift_2ewithParams(v_fvs_243, v_t_2421));
  return heff_rec_n(3, shape_key__name__body, (V[]){v_key_2410, v_name_2412, v_body_2422});
}
V g_heff_2ecompile_2elift_2eliftedDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elift_2eliftedDef(a[0], a[1], a[2], a[3], a[4]);
}

HeffT2 g_heff_2ecompile_2elift_2efixOf_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_e_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_take_na(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    V v_f_2438 = heff_field(v_e_240, 0);
    V v_b_2439 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EFix = heff_take_reuse_n(v_e_240, 3ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24e_240_24EFix, TAG_MkPair, 2, (V[]){v_f_2438, v_b_2439})}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}

HeffT2 g_heff_2ecompile_2elift_2eoneParam_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_e_240, 0);
    V v_b_244 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ELam = heff_take_reuse_n(v_e_240, 3ULL, 2);
    switch (heff_tag_of(v_xs_243)) {
    case TAG_Nil: {
      heff_drop(v_b_244);
      heff_drop_cell(v_ru_24e_240_24ELam, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_xs_243, 0);
      V v_it2_246 = heff_field(v_xs_243, 1);
      heff_take_n(v_xs_243, 3ULL, 2);
      switch (heff_tag_of(v_it2_246)) {
      case TAG_Nil: {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24e_240_24ELam, TAG_MkPair, 2, (V[]){v_x_245, v_b_244})}});
      }
      case TAG_Cons: {
        heff_take_n(v_it2_246, 0ULL, 2);
        heff_drop(v_b_244);
        heff_drop_cell(v_ru_24e_240_24ELam, 2);
        heff_drop(v_x_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it2_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_xs_243)}});
    }
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_e_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_take_na(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}

HeffT2 g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(V v_d_240, V v_acc_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_d_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_acc_241}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_xs_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(heff_dup(v_d_240), v_acc_241, v_x_243));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_x2_248 = v_field_246;
      V v_acc2_249 = v_field_247;
      HeffT2 v_t_2410 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_240, v_acc2_249, v_xs_244));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_xs_2413 = v_field_2411;
        V v_acc_2414 = v_field_2412;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_x2_248, v_xs_2413}), v_acc_2414}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}

HeffT2 g_heff_2ecompile_2elift_2eliftFixDef_24s1197825217x45906855_24cpr(V v_acc_240, V v_fvs_241, V v_ld_242) {
top: ;
  V v_out_243 = heff_take_field(v_acc_240, 0);
  V v_n_244 = heff_get_n(v_acc_240, 1, 2);
  V v_t_245 = heff_rec_n(2, shape_out__n, (V[]){v_out_243, heff_intAdd(v_n_244, MK_INT(1LL))});
  HeffT2 v_t_246 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(heff_dup(v_ld_242), v_t_245, heff_dup(heff_rfield(v_ld_242, 2))));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    V v_b2_249 = v_field_247;
    V v_acc2_2410 = v_field_248;
    V v_out_2411 = heff_take_field(v_acc2_2410, 0);
    V v_n_2412 = heff_get_n(v_acc2_2410, 1, 2);
    V v_key_2413 = heff_dup(heff_rfield(v_ld_242, 0));
    V v_f_2417;
    switch (heff_tag_of(v_fvs_241)) {
    case TAG_Nil: {
      v_f_2417 = heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_2413});
      break;
    }
    case TAG_Cons: {
      V v_t_2416 = (g_list_2emap_24s1809017761x1063871171(v_fvs_241));
      v_f_2417 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_2413}), v_t_2416});
      break;
    }
    default: heff_nomatch(v_fvs_241);
    }
    V v_t_2418 = ({ V rv_2 = v_b2_249; V rr_ = heff_rec_reuse_nf(v_ld_242, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_f_2419 = heff_rec_n(2, shape_out__n, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_out_2411}), v_n_2412});
    return ((HeffT2){{v_f_2417, v_f_2419}});
  }
}

HeffT2 g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr(V v_d_240, V v_acc_241, V v_f_242, V v_body_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_f_242), NTAG(TAG_Nil)});
  V v_xs_245 = (g_heff_2ecompile_2elift_2efreeGo(v_t_244, heff_dup(v_body_243), NTAG(TAG_Nil)));
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_f_242), NTAG(TAG_Nil)});
  V v_xs_248 = (g_heff_2ecompile_2elift_2efreeGo(v_t_247, heff_dup(v_body_243), NTAG(TAG_Nil)));
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
  V v_t_2410 = (g_heff_2ecompile_2elift_2eliftedDef(v_d_240, heff_dup(heff_rfield(v_acc_241, 1)), v_f_242, v_t_249, v_body_243));
  return (g_heff_2ecompile_2elift_2eliftFixDef_24s1197825217x45906855_24cpr(v_acc_241, v_t_246, v_t_2410));
}
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str11, 0, "");

HeffT2 g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr(V v_tag_240, V v_d_241, V v_acc_242, V v_x_243, V v_b_244, V v_a_245, V v_d_246, V v_acc_247, V v_f_248, V v_args_249, V v_d_2410, V v_acc_2411, V v_e_2412) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750: {
    top_TAG_Enter_24heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750: ;
    heff_drop(v_d_2410);
    heff_drop(v_acc_2411);
    heff_drop(v_e_2412);
    HeffT2 v_t_2413 = (g_heff_2ecompile_2elift_2efixOf_24cpr(heff_dup(v_a_245)));
    {
      V v_field_2415 = v_t_2413.f[1];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        heff_drop(v_a_245);
        V v_it1_2416 = v_field_2415;
        switch (heff_tag_of(v_it1_2416)) {
        case TAG_MkPair: {
          V v_f_2417 = heff_field(v_it1_2416, 0);
          V v_fb_2418 = heff_field(v_it1_2416, 1);
          heff_take_n(v_it1_2416, 3ULL, 2);
          HeffT2 v_t_2419 = (g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr(heff_dup(v_d_241), v_acc_242, v_f_2417, v_fb_2418));
          {
            V v_field_2420 = v_t_2419.f[0];
            V v_field_2421 = v_t_2419.f[1];
            V v_call_2422 = v_field_2420;
            V v_acc2_2423 = v_field_2421;
            V v_e_2424 = (g_heff_2ecompile_2elift_2ereplaceGo(v_x_243, v_call_2422, v_b_244));
            V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804);
            V t_1 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str0);
            V t_2 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str1);
            V t_3 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str2);
            V t_4 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str3);
            V t_5 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str4);
            V t_6 = v_d_246;
            V t_7 = v_acc_247;
            V t_8 = v_f_248;
            V t_9 = v_args_249;
            V t_10 = v_d_241;
            V t_11 = v_acc2_2423;
            V t_12 = v_e_2424;
            v_tag_240 = t_0;
            v_d_241 = t_1;
            v_acc_242 = t_2;
            v_x_243 = t_3;
            v_b_244 = t_4;
            v_a_245 = t_5;
            v_d_246 = t_6;
            v_acc_247 = t_7;
            v_f_248 = t_8;
            v_args_249 = t_9;
            v_d_2410 = t_10;
            v_acc_2411 = t_11;
            v_e_2412 = t_12;
            goto top_TAG_Enter_24heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804;
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it1_2416)}});
        }
      } else {
        heff_drop(v_d_246);
        heff_drop(v_acc_247);
        heff_drop(v_f_248);
        heff_drop(v_args_249);
        heff_drop(v_field_2415);
        V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
        V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_245), NTAG(TAG_Nil)});
        V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2425, heff_dup(v_b_244)}), v_t_2426});
        HeffT2 v_t_2428 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_241, v_acc_242, v_t_2427));
        {
          V v_field_2429 = v_t_2428.f[0];
          V v_field_2430 = v_t_2428.f[1];
          V v_it1_2431 = v_field_2429;
          V v_acc2_2432 = v_field_2430;
          switch (heff_tag_of(v_it1_2431)) {
          case TAG_Nil: {
            V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
            V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_245, NTAG(TAG_Nil)});
            V v_t_2435 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2433, v_b_244}), v_t_2434});
            return ((HeffT2){{v_t_2435, v_acc2_2432}});
          }
          case TAG_Cons: {
            V v_f2_2436 = heff_field(v_it1_2431, 0);
            V v_as2_2437 = heff_field(v_it1_2431, 1);
            V v_ru_24it1_2431_24Cons = heff_take_reuse_n(v_it1_2431, 3ULL, 2);
            heff_drop(v_x_243);
            heff_drop(v_b_244);
            heff_drop(v_a_245);
            return ((HeffT2){{heff_tag_at_n(v_ru_24it1_2431_24Cons, TAG_EApp, 2, (V[]){v_f2_2436, v_as2_2437}), v_acc2_2432}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it1_2431)}});
          }
        }
      }
    }
  }
  case TAG_Enter_24heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862: {
    top_TAG_Enter_24heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862: ;
    heff_drop(v_d_241);
    heff_drop(v_acc_242);
    heff_drop(v_x_243);
    heff_drop(v_b_244);
    heff_drop(v_a_245);
    HeffT2 v_t_2438 = (g_heff_2ecompile_2elift_2eoneParam_24cpr(heff_dup(v_f_248)));
    {
      V v_field_2440 = v_t_2438.f[1];
      int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
      if ((v_tag_2439 == ((int64_t)0ULL))) {
        V v_it1_2441 = v_field_2440;
        switch (heff_tag_of(v_it1_2441)) {
        case TAG_MkPair: {
          V v_x_2442 = heff_field(v_it1_2441, 0);
          V v_b_2443 = heff_field(v_it1_2441, 1);
          V v_ru_24it1_2441_24MkPair = heff_take_reuse_n(v_it1_2441, 3ULL, 2);
          switch (heff_tag_of(v_args_249)) {
          case TAG_Nil: {
            heff_drop(v_d_2410);
            heff_drop(v_acc_2411);
            heff_drop(v_e_2412);
            heff_drop(v_x_2442);
            heff_drop(v_b_2443);
            HeffT2 v_t_2444 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_246, v_acc_247, heff_tag_at_n(v_ru_24it1_2441_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_f_248), heff_dup(v_args_249)})));
            {
              V v_field_2445 = v_t_2444.f[0];
              V v_field_2446 = v_t_2444.f[1];
              V v_it1_2447 = v_field_2445;
              V v_acc2_2448 = v_field_2446;
              switch (heff_tag_of(v_it1_2447)) {
              case TAG_Nil: {
                return ((HeffT2){{heff_tag_n(TAG_EApp, 2, (V[]){v_f_248, v_args_249}), v_acc2_2448}});
              }
              case TAG_Cons: {
                V v_f2_2449 = heff_field(v_it1_2447, 0);
                V v_as2_2450 = heff_field(v_it1_2447, 1);
                V v_ru_24it1_2447_24Cons = heff_take_reuse_n(v_it1_2447, 3ULL, 2);
                heff_drop(v_f_248);
                return ((HeffT2){{heff_tag_at_n(v_ru_24it1_2447_24Cons, TAG_EApp, 2, (V[]){v_f2_2449, v_as2_2450}), v_acc2_2448}});
              }
              default: return ((HeffT2){{heff_nomatch(v_it1_2447)}});
              }
            }
          }
          case TAG_Cons: {
            V v_it2_2452 = heff_dup(heff_field(v_args_249, 1));
            switch (heff_tag_of(v_it2_2452)) {
            case TAG_Nil: {
              heff_drop(v_f_248);
              heff_drop_cell(v_ru_24it1_2441_24MkPair, 2);
              switch (heff_tag_of(v_args_249)) {
              case TAG_Cons: {
                V v_a_2453 = heff_field(v_args_249, 0);
                heff_take_n(v_args_249, 1ULL, 2);
                V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750);
                V t_1 = v_d_246;
                V t_2 = v_acc_247;
                V t_3 = v_x_2442;
                V t_4 = v_b_2443;
                V t_5 = v_a_2453;
                V t_6 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str5);
                V t_7 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str6);
                V t_8 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str7);
                V t_9 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str8);
                V t_10 = v_d_2410;
                V t_11 = v_acc_2411;
                V t_12 = v_e_2412;
                v_tag_240 = t_0;
                v_d_241 = t_1;
                v_acc_242 = t_2;
                v_x_243 = t_3;
                v_b_244 = t_4;
                v_a_245 = t_5;
                v_d_246 = t_6;
                v_acc_247 = t_7;
                v_f_248 = t_8;
                v_args_249 = t_9;
                v_d_2410 = t_10;
                v_acc_2411 = t_11;
                v_e_2412 = t_12;
                goto top_TAG_Enter_24heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750;
              }
              default: return ((HeffT2){{heff_nomatch(v_args_249)}});
              }
            }
            case TAG_Cons: {
              V v_ru_24it2_2452_24Cons = heff_take_reuse_n(v_it2_2452, 0ULL, 2);
              heff_drop(v_d_2410);
              heff_drop(v_acc_2411);
              heff_drop(v_e_2412);
              heff_drop(v_x_2442);
              heff_drop(v_b_2443);
              HeffT2 v_t_2457 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_246, v_acc_247, heff_tag_at_n(v_ru_24it1_2441_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_f_248), heff_dup(v_args_249)})));
              {
                V v_field_2458 = v_t_2457.f[0];
                V v_field_2459 = v_t_2457.f[1];
                V v_it1_2460 = v_field_2458;
                V v_acc2_2461 = v_field_2459;
                switch (heff_tag_of(v_it1_2460)) {
                case TAG_Nil: {
                  return ((HeffT2){{heff_tag_at_n(v_ru_24it2_2452_24Cons, TAG_EApp, 2, (V[]){v_f_248, v_args_249}), v_acc2_2461}});
                }
                case TAG_Cons: {
                  V v_f2_2462 = heff_field(v_it1_2460, 0);
                  V v_as2_2463 = heff_field(v_it1_2460, 1);
                  heff_take_n(v_it1_2460, 3ULL, 2);
                  heff_drop(v_f_248);
                  heff_drop_tag(v_args_249, 2);
                  return ((HeffT2){{heff_tag_at_n(v_ru_24it2_2452_24Cons, TAG_EApp, 2, (V[]){v_f2_2462, v_as2_2463}), v_acc2_2461}});
                }
                default: return ((HeffT2){{heff_nomatch(v_it1_2460)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_it2_2452)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_args_249)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it1_2441)}});
        }
      } else {
        heff_drop(v_d_2410);
        heff_drop(v_acc_2411);
        heff_drop(v_e_2412);
        heff_drop(v_field_2440);
        HeffT2 v_t_2464 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_246, v_acc_247, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_f_248), heff_dup(v_args_249)})));
        {
          V v_field_2465 = v_t_2464.f[0];
          V v_field_2466 = v_t_2464.f[1];
          V v_it1_2467 = v_field_2465;
          V v_acc2_2468 = v_field_2466;
          switch (heff_tag_of(v_it1_2467)) {
          case TAG_Nil: {
            return ((HeffT2){{heff_tag_n(TAG_EApp, 2, (V[]){v_f_248, v_args_249}), v_acc2_2468}});
          }
          case TAG_Cons: {
            V v_f2_2469 = heff_field(v_it1_2467, 0);
            V v_as2_2470 = heff_field(v_it1_2467, 1);
            V v_ru_24it1_2467_24Cons = heff_take_reuse_n(v_it1_2467, 3ULL, 2);
            heff_drop(v_f_248);
            heff_drop(v_args_249);
            return ((HeffT2){{heff_tag_at_n(v_ru_24it1_2467_24Cons, TAG_EApp, 2, (V[]){v_f2_2469, v_as2_2470}), v_acc2_2468}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it1_2467)}});
          }
        }
      }
    }
  }
  case TAG_Enter_24heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804: {
    top_TAG_Enter_24heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804: ;
    heff_drop(v_d_246);
    heff_drop(v_acc_247);
    heff_drop(v_f_248);
    heff_drop(v_args_249);
    switch (heff_tag_of(v_e_2412)) {
    case TAG_EVar: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_EGlobal: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_ELam: {
      V v_xs_2473 = heff_field(v_e_2412, 0);
      V v_b_2474 = heff_field(v_e_2412, 1);
      V v_ru_24e_2412_24ELam = heff_take_reuse_n(v_e_2412, 3ULL, 2);
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      HeffT2 v_t_2475 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(v_d_2410, v_acc_2411, v_b_2474));
      {
        V v_field_2476 = v_t_2475.f[0];
        V v_field_2477 = v_t_2475.f[1];
        V v_b2_2478 = v_field_2476;
        V v_acc2_2479 = v_field_2477;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_2412_24ELam, TAG_ELam, 2, (V[]){v_xs_2473, v_b2_2478}), v_acc2_2479}});
      }
    }
    case TAG_EApp: {
      V v_f_2480 = heff_field(v_e_2412, 0);
      V v_args_2481 = heff_field(v_e_2412, 1);
      heff_take_n(v_e_2412, 3ULL, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862);
      V t_1 = v_d_241;
      V t_2 = v_acc_242;
      V t_3 = v_x_243;
      V t_4 = v_b_244;
      V t_5 = v_a_245;
      V t_6 = v_d_2410;
      V t_7 = v_acc_2411;
      V t_8 = v_f_2480;
      V t_9 = v_args_2481;
      V t_10 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str9);
      V t_11 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str10);
      V t_12 = ((V)&g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr_str11);
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_acc_242 = t_2;
      v_x_243 = t_3;
      v_b_244 = t_4;
      v_a_245 = t_5;
      v_d_246 = t_6;
      v_acc_247 = t_7;
      v_f_248 = t_8;
      v_args_249 = t_9;
      v_d_2410 = t_10;
      v_acc_2411 = t_11;
      v_e_2412 = t_12;
      goto top_TAG_Enter_24heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862;
    }
    case TAG_ELet: {
      V v_x_2482 = heff_dup(heff_field(v_e_2412, 0));
      V v_a_2483 = heff_dup(heff_field(v_e_2412, 1));
      V v_b_2484 = heff_dup(heff_field(v_e_2412, 2));
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2484, NTAG(TAG_Nil)});
      HeffT2 v_t_2486 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_2410, v_acc_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_a_2483, v_t_2485})));
      {
        V v_field_2487 = v_t_2486.f[0];
        V v_field_2488 = v_t_2486.f[1];
        V v_it1_2489 = v_field_2487;
        V v_acc2_2490 = v_field_2488;
        switch (heff_tag_of(v_it1_2489)) {
        case TAG_Nil: {
          heff_drop(v_x_2482);
          return ((HeffT2){{v_e_2412, v_acc2_2490}});
        }
        case TAG_Cons: {
          V v_a2_2491 = heff_field(v_it1_2489, 0);
          V v_it12_2492 = heff_field(v_it1_2489, 1);
          heff_take_n(v_it1_2489, 3ULL, 2);
          switch (heff_tag_of(v_it12_2492)) {
          case TAG_Nil: {
            heff_drop(v_x_2482);
            heff_drop(v_a2_2491);
            return ((HeffT2){{v_e_2412, v_acc2_2490}});
          }
          case TAG_Cons: {
            V v_b2_2493 = heff_field(v_it12_2492, 0);
            V v_it122_2494 = heff_field(v_it12_2492, 1);
            heff_take_n(v_it12_2492, 3ULL, 2);
            switch (heff_tag_of(v_it122_2494)) {
            case TAG_Nil: {
              heff_drop_tag(v_e_2412, 3);
              return ((HeffT2){{heff_tag_n(TAG_ELet, 3, (V[]){v_x_2482, v_a2_2491, v_b2_2493}), v_acc2_2490}});
            }
            case TAG_Cons: {
              heff_take_n(v_it122_2494, 0ULL, 2);
              heff_drop(v_x_2482);
              heff_drop(v_a2_2491);
              heff_drop(v_b2_2493);
              return ((HeffT2){{v_e_2412, v_acc2_2490}});
            }
            default: return ((HeffT2){{heff_nomatch(v_it122_2494)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_it12_2492)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it1_2489)}});
        }
      }
    }
    case TAG_ERecord: {
      V v_fs_2497 = heff_field(v_e_2412, 0);
      V v_ts_2498 = heff_field(v_e_2412, 1);
      V v_ru_24e_2412_24ERecord = heff_take_reuse_n(v_e_2412, 3ULL, 2);
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      V v_t_2499 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2497)));
      HeffT2 v_t_24100 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_2410, v_acc_2411, v_t_2499));
      {
        V v_field_24101 = v_t_24100.f[0];
        V v_field_24102 = v_t_24100.f[1];
        V v_es_24103 = v_field_24101;
        V v_acc2_24104 = v_field_24102;
        V v_fs2_24105 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2497, v_es_24103));
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_2412_24ERecord, TAG_ERecord, 2, (V[]){v_fs2_24105, v_ts_2498}), v_acc2_24104}});
      }
    }
    case TAG_EProj: {
      V v_x_24106 = heff_field(v_e_2412, 0);
      V v_l_24107 = heff_field(v_e_2412, 1);
      V v_sh_24108 = heff_field(v_e_2412, 2);
      V v_t_24109 = heff_field(v_e_2412, 3);
      V v_ru_24e_2412_24EProj = heff_take_reuse_n(v_e_2412, 15ULL, 4);
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      HeffT2 v_t_24110 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(v_d_2410, v_acc_2411, v_x_24106));
      {
        V v_field_24111 = v_t_24110.f[0];
        V v_field_24112 = v_t_24110.f[1];
        V v_x2_24113 = v_field_24111;
        V v_acc2_24114 = v_field_24112;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_2412_24EProj, TAG_EProj, 4, (V[]){v_x2_24113, v_l_24107, v_sh_24108, v_t_24109}), v_acc2_24114}});
      }
    }
    case TAG_ETag: {
      V v_t_24115 = heff_field(v_e_2412, 0);
      V v_es_24116 = heff_field(v_e_2412, 1);
      V v_ts_24117 = heff_field(v_e_2412, 2);
      V v_ru_24e_2412_24ETag = heff_take_reuse_n(v_e_2412, 7ULL, 3);
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      HeffT2 v_t_24118 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_2410, v_acc_2411, v_es_24116));
      {
        V v_field_24119 = v_t_24118.f[0];
        V v_field_24120 = v_t_24118.f[1];
        V v_es2_24121 = v_field_24119;
        V v_acc2_24122 = v_field_24120;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_2412_24ETag, TAG_ETag, 3, (V[]){v_t_24115, v_es2_24121, v_ts_24117}), v_acc2_24122}});
      }
    }
    case TAG_EMatch: {
      V v_x_24123 = heff_field(v_e_2412, 0);
      V v_arms_24124 = heff_field(v_e_2412, 1);
      V v_ru_24e_2412_24EMatch = heff_take_reuse_n(v_e_2412, 3ULL, 2);
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      HeffT2 v_t_24125 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(heff_dup(v_d_2410), v_acc_2411, v_x_24123));
      {
        V v_field_24126 = v_t_24125.f[0];
        V v_field_24127 = v_t_24125.f[1];
        V v_x2_24128 = v_field_24126;
        V v_acc2_24129 = v_field_24127;
        V v_t_24130 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_24124)));
        HeffT2 v_t_24131 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_2410, v_acc2_24129, v_t_24130));
        {
          V v_field_24132 = v_t_24131.f[0];
          V v_field_24133 = v_t_24131.f[1];
          V v_bs_24134 = v_field_24132;
          V v_acc2_24135 = v_field_24133;
          V v_arms2_24136 = (g_list_2ezipWith_24s738847920x410598254(v_arms_24124, v_bs_24134));
          return ((HeffT2){{heff_tag_at_n(v_ru_24e_2412_24EMatch, TAG_EMatch, 2, (V[]){v_x2_24128, v_arms2_24136}), v_acc2_24135}});
        }
      }
    }
    case TAG_EPrim: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_EPrimCall: {
      V v_p_24138 = heff_field(v_e_2412, 0);
      V v_es_24139 = heff_field(v_e_2412, 1);
      V v_ru_24e_2412_24EPrimCall = heff_take_reuse_n(v_e_2412, 3ULL, 2);
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      HeffT2 v_t_24140 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_2410, v_acc_2411, v_es_24139));
      {
        V v_field_24141 = v_t_24140.f[0];
        V v_field_24142 = v_t_24140.f[1];
        V v_es2_24143 = v_field_24141;
        V v_acc2_24144 = v_field_24142;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_2412_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_24138, v_es2_24143}), v_acc2_24144}});
      }
    }
    case TAG_ECall: {
      V v_c_24145 = heff_field(v_e_2412, 0);
      V v_es_24146 = heff_field(v_e_2412, 1);
      V v_ru_24e_2412_24ECall = heff_take_reuse_n(v_e_2412, 3ULL, 2);
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      HeffT2 v_t_24147 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_2410, v_acc_2411, v_es_24146));
      {
        V v_field_24148 = v_t_24147.f[0];
        V v_field_24149 = v_t_24147.f[1];
        V v_es2_24150 = v_field_24148;
        V v_acc2_24151 = v_field_24149;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_2412_24ECall, TAG_ECall, 2, (V[]){v_c_24145, v_es2_24150}), v_acc2_24151}});
      }
    }
    case TAG_EInt: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_EFloat: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_EStr: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_EBytes: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_EFixed: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_EFloat32: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_EAbandon: {
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      heff_drop(v_d_2410);
      return ((HeffT2){{v_e_2412, v_acc_2411}});
    }
    case TAG_EBool: {
      V v_c_24159 = heff_field(v_e_2412, 0);
      V v_ru_24e_2412_24EBool = heff_take_reuse_n(v_e_2412, 1ULL, 1);
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      V v_t_24160 = (g_heff_2ecompile_2eir_2econdOnto(v_c_24159, NTAG(TAG_Nil)));
      HeffT2 v_t_24161 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_2410, v_acc_2411, v_t_24160));
      {
        V v_field_24162 = v_t_24161.f[0];
        V v_field_24163 = v_t_24161.f[1];
        V v_es2_24164 = v_field_24162;
        V v_acc2_24165 = v_field_24163;
        HeffT2 v_t_24166 = (g_heff_2ecompile_2eir_2econdFillGo_24cpr(v_c_24159, v_es2_24164));
        V v_t_24172;
        {
          V v_field_24167 = v_t_24166.f[0];
          V v_field_24168 = v_t_24166.f[1];
          V v_it1_24169 = v_field_24167;
          V v_it2_24170 = v_field_24168;
          heff_drop(v_it2_24170);
          switch (heff_tag_of(v_it1_24169)) {
          case TAG_Nothing: {
            v_t_24172 = NTAG(TAG_CFalse);
            break;
          }
          case TAG_Just: {
            V v_c2_24171 = heff_field(v_it1_24169, 0);
            heff_take_n(v_it1_24169, 1ULL, 1);
            v_t_24172 = v_c2_24171;
            break;
          }
          default: heff_nomatch(v_it1_24169);
          }
        }
        V v_f_24173 = heff_tag_at_n(v_ru_24e_2412_24EBool, TAG_EBool, 1, (V[]){v_t_24172});
        return ((HeffT2){{v_f_24173, v_acc2_24165}});
      }
    }
    case TAG_ESet: {
      V v_xs_24174 = heff_dup(heff_field(v_e_2412, 0));
      V v_a_24175 = heff_dup(heff_field(v_e_2412, 1));
      V v_b_24176 = heff_dup(heff_field(v_e_2412, 2));
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      V v_t_24177 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_24176, NTAG(TAG_Nil)});
      HeffT2 v_t_24178 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_2410, v_acc_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_a_24175, v_t_24177})));
      {
        V v_field_24179 = v_t_24178.f[0];
        V v_field_24180 = v_t_24178.f[1];
        V v_it1_24181 = v_field_24179;
        V v_acc2_24182 = v_field_24180;
        switch (heff_tag_of(v_it1_24181)) {
        case TAG_Nil: {
          heff_drop(v_xs_24174);
          return ((HeffT2){{v_e_2412, v_acc2_24182}});
        }
        case TAG_Cons: {
          V v_a2_24183 = heff_field(v_it1_24181, 0);
          V v_it12_24184 = heff_field(v_it1_24181, 1);
          heff_take_n(v_it1_24181, 3ULL, 2);
          switch (heff_tag_of(v_it12_24184)) {
          case TAG_Nil: {
            heff_drop(v_xs_24174);
            heff_drop(v_a2_24183);
            return ((HeffT2){{v_e_2412, v_acc2_24182}});
          }
          case TAG_Cons: {
            V v_b2_24185 = heff_field(v_it12_24184, 0);
            V v_it122_24186 = heff_field(v_it12_24184, 1);
            heff_take_n(v_it12_24184, 3ULL, 2);
            switch (heff_tag_of(v_it122_24186)) {
            case TAG_Nil: {
              heff_drop_tag(v_e_2412, 3);
              return ((HeffT2){{heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24174, v_a2_24183, v_b2_24185}), v_acc2_24182}});
            }
            case TAG_Cons: {
              heff_take_n(v_it122_24186, 0ULL, 2);
              heff_drop(v_xs_24174);
              heff_drop(v_a2_24183);
              heff_drop(v_b2_24185);
              return ((HeffT2){{v_e_2412, v_acc2_24182}});
            }
            default: return ((HeffT2){{heff_nomatch(v_it122_24186)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_it12_24184)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it1_24181)}});
        }
      }
    }
    case TAG_EValues: {
      V v_es_24189 = heff_field(v_e_2412, 0);
      V v_ru_24e_2412_24EValues = heff_take_reuse_n(v_e_2412, 1ULL, 1);
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      HeffT2 v_t_24190 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_2410, v_acc_2411, v_es_24189));
      {
        V v_field_24191 = v_t_24190.f[0];
        V v_field_24192 = v_t_24190.f[1];
        V v_es2_24193 = v_field_24191;
        V v_acc2_24194 = v_field_24192;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_2412_24EValues, TAG_EValues, 1, (V[]){v_es2_24193}), v_acc2_24194}});
      }
    }
    case TAG_EFix: {
      V v_f_24195 = heff_field(v_e_2412, 0);
      V v_b_24196 = heff_field(v_e_2412, 1);
      heff_take_n(v_e_2412, 3ULL, 2);
      heff_drop(v_d_241);
      heff_drop(v_acc_242);
      heff_drop(v_x_243);
      heff_drop(v_b_244);
      heff_drop(v_a_245);
      return (g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr(v_d_2410, v_acc_2411, v_f_24195, v_b_24196));
    }
    default: return ((HeffT2){{heff_nomatch(v_e_2412)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_tag_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str7, 0, "");

HeffT2 g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr(V v_d_240, V v_acc_241, V v_f_242, V v_args_243) {
top: ;
  return (g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr(NTAG(TAG_Enter_24heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862), ((V)&g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str0), ((V)&g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str1), ((V)&g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str2), ((V)&g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str3), ((V)&g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str4), v_d_240, v_acc_241, v_f_242, v_args_243, ((V)&g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str5), ((V)&g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str6), ((V)&g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr_str7)));
}
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str8, 0, "");

HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(V v_d_240, V v_acc_241, V v_e_242) {
top: ;
  return (g_heff_2ecompile_2elift_2eliftRedex_24s899276347x1214300750_24cycle_24cpr(NTAG(TAG_Enter_24heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str0), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str1), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str2), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str3), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str4), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str5), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str6), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str7), ((V)&g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr_str8), v_d_240, v_acc_241, v_e_242));
}

HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(V v_lit_240, V v_d_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_d_241);
    V v_t_244 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_244}});
  }
  case TAG_EGlobal: {
    heff_drop(v_d_241);
    V v_t_246 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_246}});
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_e_242, 0);
    V v_b_248 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_249 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    HeffT2 v_t_2410 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(v_d_241, v_t_249, v_b_248));
    {
      V v_field_2411 = v_t_2410.f[0];
      V v_field_2412 = v_t_2410.f[1];
      V v_b2_2413 = v_field_2411;
      V v_acc2_2414 = v_field_2412;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ELam, TAG_ELam, 2, (V[]){v_xs_247, v_b2_2413}), v_acc2_2414}});
    }
  }
  case TAG_EApp: {
    V v_f_2415 = heff_field(v_e_242, 0);
    V v_args_2416 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2417 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return (g_heff_2ecompile_2elift_2eliftApp_24s609618110x1564201862_24cpr(v_d_241, v_t_2417, v_f_2415, v_args_2416));
  }
  case TAG_ELet: {
    V v_x_2418 = heff_dup(heff_field(v_e_242, 0));
    V v_a_2419 = heff_dup(heff_field(v_e_242, 1));
    V v_b_2420 = heff_dup(heff_field(v_e_242, 2));
    V v_t_2421 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2420, NTAG(TAG_Nil)});
    HeffT2 v_t_2423 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_241, v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_a_2419, v_t_2422})));
    {
      V v_field_2424 = v_t_2423.f[0];
      V v_field_2425 = v_t_2423.f[1];
      V v_it1_2426 = v_field_2424;
      V v_acc2_2427 = v_field_2425;
      switch (heff_tag_of(v_it1_2426)) {
      case TAG_Nil: {
        heff_drop(v_x_2418);
        return ((HeffT2){{v_e_242, v_acc2_2427}});
      }
      case TAG_Cons: {
        V v_a2_2428 = heff_field(v_it1_2426, 0);
        V v_it12_2429 = heff_field(v_it1_2426, 1);
        heff_take_n(v_it1_2426, 3ULL, 2);
        switch (heff_tag_of(v_it12_2429)) {
        case TAG_Nil: {
          heff_drop(v_x_2418);
          heff_drop(v_a2_2428);
          return ((HeffT2){{v_e_242, v_acc2_2427}});
        }
        case TAG_Cons: {
          V v_b2_2430 = heff_field(v_it12_2429, 0);
          V v_it122_2431 = heff_field(v_it12_2429, 1);
          heff_take_n(v_it12_2429, 3ULL, 2);
          switch (heff_tag_of(v_it122_2431)) {
          case TAG_Nil: {
            heff_drop_tag(v_e_242, 3);
            return ((HeffT2){{heff_tag_n(TAG_ELet, 3, (V[]){v_x_2418, v_a2_2428, v_b2_2430}), v_acc2_2427}});
          }
          case TAG_Cons: {
            heff_take_n(v_it122_2431, 0ULL, 2);
            heff_drop(v_x_2418);
            heff_drop(v_a2_2428);
            heff_drop(v_b2_2430);
            return ((HeffT2){{v_e_242, v_acc2_2427}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it122_2431)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it12_2429)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_2426)}});
      }
    }
  }
  case TAG_ERecord: {
    V v_fs_2434 = heff_field(v_e_242, 0);
    V v_ts_2435 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2436 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2437 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2434)));
    HeffT2 v_t_2438 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_241, v_t_2436, v_t_2437));
    {
      V v_field_2439 = v_t_2438.f[0];
      V v_field_2440 = v_t_2438.f[1];
      V v_es_2441 = v_field_2439;
      V v_acc2_2442 = v_field_2440;
      V v_fs2_2443 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2434, v_es_2441));
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ERecord, TAG_ERecord, 2, (V[]){v_fs2_2443, v_ts_2435}), v_acc2_2442}});
    }
  }
  case TAG_EProj: {
    V v_x_2444 = heff_field(v_e_242, 0);
    V v_l_2445 = heff_field(v_e_242, 1);
    V v_sh_2446 = heff_field(v_e_242, 2);
    V v_t_2447 = heff_field(v_e_242, 3);
    V v_ru_24e_242_24EProj = heff_take_reuse_n(v_e_242, 15ULL, 4);
    V v_t_2448 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    HeffT2 v_t_2449 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(v_d_241, v_t_2448, v_x_2444));
    {
      V v_field_2450 = v_t_2449.f[0];
      V v_field_2451 = v_t_2449.f[1];
      V v_x2_2452 = v_field_2450;
      V v_acc2_2453 = v_field_2451;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EProj, TAG_EProj, 4, (V[]){v_x2_2452, v_l_2445, v_sh_2446, v_t_2447}), v_acc2_2453}});
    }
  }
  case TAG_ETag: {
    V v_t_2454 = heff_field(v_e_242, 0);
    V v_es_2455 = heff_field(v_e_242, 1);
    V v_ts_2456 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2457 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    HeffT2 v_t_2458 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_241, v_t_2457, v_es_2455));
    {
      V v_field_2459 = v_t_2458.f[0];
      V v_field_2460 = v_t_2458.f[1];
      V v_es2_2461 = v_field_2459;
      V v_acc2_2462 = v_field_2460;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ETag, TAG_ETag, 3, (V[]){v_t_2454, v_es2_2461, v_ts_2456}), v_acc2_2462}});
    }
  }
  case TAG_EMatch: {
    V v_x_2463 = heff_field(v_e_242, 0);
    V v_arms_2464 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2465 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    HeffT2 v_t_2466 = (g_heff_2ecompile_2elift_2eliftGo_24s1076009169x1844065804_24cpr(heff_dup(v_d_241), v_t_2465, v_x_2463));
    {
      V v_field_2467 = v_t_2466.f[0];
      V v_field_2468 = v_t_2466.f[1];
      V v_x2_2469 = v_field_2467;
      V v_acc2_2470 = v_field_2468;
      V v_t_2471 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_2464)));
      HeffT2 v_t_2472 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_241, v_acc2_2470, v_t_2471));
      {
        V v_field_2473 = v_t_2472.f[0];
        V v_field_2474 = v_t_2472.f[1];
        V v_bs_2475 = v_field_2473;
        V v_acc2_2476 = v_field_2474;
        V v_arms2_2477 = (g_list_2ezipWith_24s738847920x410598254(v_arms_2464, v_bs_2475));
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_x2_2469, v_arms2_2477}), v_acc2_2476}});
      }
    }
  }
  case TAG_EPrim: {
    heff_drop(v_d_241);
    V v_t_2479 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_2479}});
  }
  case TAG_EPrimCall: {
    V v_p_2480 = heff_field(v_e_242, 0);
    V v_es_2481 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2482 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    HeffT2 v_t_2483 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_241, v_t_2482, v_es_2481));
    {
      V v_field_2484 = v_t_2483.f[0];
      V v_field_2485 = v_t_2483.f[1];
      V v_es2_2486 = v_field_2484;
      V v_acc2_2487 = v_field_2485;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2480, v_es2_2486}), v_acc2_2487}});
    }
  }
  case TAG_ECall: {
    V v_c_2488 = heff_field(v_e_242, 0);
    V v_es_2489 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2490 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    HeffT2 v_t_2491 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_241, v_t_2490, v_es_2489));
    {
      V v_field_2492 = v_t_2491.f[0];
      V v_field_2493 = v_t_2491.f[1];
      V v_es2_2494 = v_field_2492;
      V v_acc2_2495 = v_field_2493;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){v_c_2488, v_es2_2494}), v_acc2_2495}});
    }
  }
  case TAG_EInt: {
    heff_drop(v_d_241);
    V v_t_2497 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_2497}});
  }
  case TAG_EFloat: {
    heff_drop(v_d_241);
    V v_t_2499 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_2499}});
  }
  case TAG_EStr: {
    heff_drop(v_d_241);
    V v_t_24101 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_24101}});
  }
  case TAG_EBytes: {
    heff_drop(v_d_241);
    V v_t_24103 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_24103}});
  }
  case TAG_EFixed: {
    heff_drop(v_d_241);
    V v_t_24106 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_24106}});
  }
  case TAG_EFloat32: {
    heff_drop(v_d_241);
    V v_t_24108 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_24108}});
  }
  case TAG_EAbandon: {
    heff_drop(v_d_241);
    V v_t_24109 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return ((HeffT2){{v_e_242, v_t_24109}});
  }
  case TAG_EBool: {
    V v_c_24110 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EBool = heff_take_reuse_n(v_e_242, 1ULL, 1);
    V v_t_24111 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_24112 = (g_heff_2ecompile_2eir_2econdOnto(v_c_24110, NTAG(TAG_Nil)));
    HeffT2 v_t_24113 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_241, v_t_24111, v_t_24112));
    {
      V v_field_24114 = v_t_24113.f[0];
      V v_field_24115 = v_t_24113.f[1];
      V v_es2_24116 = v_field_24114;
      V v_acc2_24117 = v_field_24115;
      HeffT2 v_t_24118 = (g_heff_2ecompile_2eir_2econdFillGo_24cpr(v_c_24110, v_es2_24116));
      V v_t_24124;
      {
        V v_field_24119 = v_t_24118.f[0];
        V v_field_24120 = v_t_24118.f[1];
        V v_it1_24121 = v_field_24119;
        V v_it2_24122 = v_field_24120;
        heff_drop(v_it2_24122);
        switch (heff_tag_of(v_it1_24121)) {
        case TAG_Nothing: {
          v_t_24124 = NTAG(TAG_CFalse);
          break;
        }
        case TAG_Just: {
          V v_c2_24123 = heff_field(v_it1_24121, 0);
          heff_take_n(v_it1_24121, 1ULL, 1);
          v_t_24124 = v_c2_24123;
          break;
        }
        default: heff_nomatch(v_it1_24121);
        }
      }
      V v_f_24125 = heff_tag_at_n(v_ru_24e_242_24EBool, TAG_EBool, 1, (V[]){v_t_24124});
      return ((HeffT2){{v_f_24125, v_acc2_24117}});
    }
  }
  case TAG_ESet: {
    V v_xs_24126 = heff_dup(heff_field(v_e_242, 0));
    V v_a_24127 = heff_dup(heff_field(v_e_242, 1));
    V v_b_24128 = heff_dup(heff_field(v_e_242, 2));
    V v_t_24129 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_24130 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_24128, NTAG(TAG_Nil)});
    HeffT2 v_t_24131 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_241, v_t_24129, heff_tag_n(TAG_Cons, 2, (V[]){v_a_24127, v_t_24130})));
    {
      V v_field_24132 = v_t_24131.f[0];
      V v_field_24133 = v_t_24131.f[1];
      V v_it1_24134 = v_field_24132;
      V v_acc2_24135 = v_field_24133;
      switch (heff_tag_of(v_it1_24134)) {
      case TAG_Nil: {
        heff_drop(v_xs_24126);
        return ((HeffT2){{v_e_242, v_acc2_24135}});
      }
      case TAG_Cons: {
        V v_a2_24136 = heff_field(v_it1_24134, 0);
        V v_it12_24137 = heff_field(v_it1_24134, 1);
        heff_take_n(v_it1_24134, 3ULL, 2);
        switch (heff_tag_of(v_it12_24137)) {
        case TAG_Nil: {
          heff_drop(v_xs_24126);
          heff_drop(v_a2_24136);
          return ((HeffT2){{v_e_242, v_acc2_24135}});
        }
        case TAG_Cons: {
          V v_b2_24138 = heff_field(v_it12_24137, 0);
          V v_it122_24139 = heff_field(v_it12_24137, 1);
          heff_take_n(v_it12_24137, 3ULL, 2);
          switch (heff_tag_of(v_it122_24139)) {
          case TAG_Nil: {
            heff_drop_tag(v_e_242, 3);
            return ((HeffT2){{heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24126, v_a2_24136, v_b2_24138}), v_acc2_24135}});
          }
          case TAG_Cons: {
            heff_take_n(v_it122_24139, 0ULL, 2);
            heff_drop(v_xs_24126);
            heff_drop(v_a2_24136);
            heff_drop(v_b2_24138);
            return ((HeffT2){{v_e_242, v_acc2_24135}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it122_24139)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it12_24137)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_24134)}});
      }
    }
  }
  case TAG_EValues: {
    V v_es_24142 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EValues = heff_take_reuse_n(v_e_242, 1ULL, 1);
    V v_t_24143 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    HeffT2 v_t_24144 = (g_heff_2ecompile_2elift_2eliftMany_24s47285924x1916525404_24cpr(v_d_241, v_t_24143, v_es_24142));
    {
      V v_field_24145 = v_t_24144.f[0];
      V v_field_24146 = v_t_24144.f[1];
      V v_es2_24147 = v_field_24145;
      V v_acc2_24148 = v_field_24146;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EValues, TAG_EValues, 1, (V[]){v_es2_24147}), v_acc2_24148}});
    }
  }
  case TAG_EFix: {
    V v_f_24149 = heff_field(v_e_242, 0);
    V v_b_24150 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_24151 = heff_rec_n(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return (g_heff_2ecompile_2elift_2eliftFix_24s850714565x651191069_24cpr(v_d_241, v_t_24151, v_f_24149, v_b_24150));
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}