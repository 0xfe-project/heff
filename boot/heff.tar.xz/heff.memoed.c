// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_heff_2ememoed_2ecode_lam1(V self, V *args); static Clo g_heff_2ememoed_2ecode_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2ecode_lam1, 1, 0};
V g_heff_2ememoed_2ecode_lam0(V self, V *args);
Clo g_heff_2ememoed_2ecode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2ecode_entry, 1, 0};

V g_heff_2ememoed_2ecode(V v_g_240) {
top: ;
  V v_t_241 = heff_tag(TAG_SCode, 1, (V[]){heff_get(heff_dup(v_g_240), LBL_stx)});
  return heff_rec(2, shape_311_351, (V[]){v_t_241, heff_clo(g_heff_2ememoed_2ecode_lam0, 1, 1, (V[]){v_g_240})});
}
V g_heff_2ememoed_2ecode_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2ecode(a[0]);
}
V g_heff_2ememoed_2ecode_lam1(V self, V *args) {
  V v_t_243 = args[0];
  heff_drop(self);
  switch (heff_tag_of(v_t_243)) {
  case TAG_VU: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_243});
  }
  case TAG_VDecode: {
    V v_el_249 = heff_field(v_t_243, 4);
    heff_take(v_t_243, 16ULL);
    return heff_tail(v_el_249, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VFunction: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_243});
  }
  case TAG_VRecord: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_243});
  }
  case TAG_VSum: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_243});
  }
  case TAG_VPrimInt: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_243});
  }
  case TAG_VPrimFloat: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_243});
  }
  case TAG_VPrimString: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_243});
  }
  case TAG_VPrimArray: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_243});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ememoed_2ecode_lam0(V self, V *args) {
  V v_u_242 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_u_242);
  V v_f_2419 = ((V)&g_heff_2ememoed_2ecode_lam1_clo);
  V v_x2_2420 = heff_tr(heff_apply(heff_get(v_g_240, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_Nom: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_ru_24x2_2420_24Nom = heff_take_reuse(v_x2_2420, 1ULL);
    V v_t_2422 = heff_tr(heff_apply(v_f_2419, 1, (V[]){v_x_2421}));
    return heff_tag_at(v_ru_24x2_2420_24Nom, TAG_Nom, 1, (V[]){v_t_2422});
  }
  case TAG_Describe: {
    V v_x_2423 = heff_field(v_x2_2420, 0);
    V v_ru_24x2_2420_24Describe = heff_take_reuse(v_x2_2420, 1ULL);
    V v_t_2424 = heff_tr(heff_apply(v_f_2419, 1, (V[]){v_x_2423}));
    return heff_tag_at(v_ru_24x2_2420_24Describe, TAG_Describe, 1, (V[]){v_t_2424});
  }
  case TAG_Become: {
    V v_x_2425 = heff_field(v_x2_2420, 0);
    V v_ru_24x2_2420_24Become = heff_take_reuse(v_x2_2420, 1ULL);
    V v_t_2426 = heff_tr(heff_apply(v_f_2419, 1, (V[]){v_x_2425}));
    return heff_tag_at(v_ru_24x2_2420_24Become, TAG_Become, 1, (V[]){v_t_2426});
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2ememoed_2eapp_lam2(V self, V *args);
V g_heff_2ememoed_2eapp_lam1(V self, V *args);
V g_heff_2ememoed_2eapp_lam0(V self, V *args);
Clo g_heff_2ememoed_2eapp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2eapp_entry, 2, 0};

V g_heff_2ememoed_2eapp(V v_g0_240, V v_g1_241) {
top: ;
  V v_t_242 = heff_tag(TAG_SApp, 2, (V[]){heff_get(heff_dup(v_g0_240), LBL_stx), heff_get(heff_dup(v_g1_241), LBL_stx)});
  return heff_rec(2, shape_311_351, (V[]){v_t_242, heff_clo(g_heff_2ememoed_2eapp_lam0, 1, 2, (V[]){v_g1_241, v_g0_240})});
}
V g_heff_2ememoed_2eapp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2eapp(a[0], a[1]);
}
V g_heff_2ememoed_2eapp_lam2(V self, V *args) {
  V v_u2_245 = args[0];
  V v_g1_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_u2_245);
  V v_x1_246 = heff_tr(heff_apply(heff_get(v_g1_241, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_Nom: {
    V v_x_247 = heff_field(v_x1_246, 0);
    heff_take(v_x1_246, 1ULL);
    return v_x_247;
  }
  case TAG_Describe: {
    heff_take(v_x1_246, 0ULL);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_249 = heff_field(v_x1_246, 0);
    heff_take(v_x1_246, 1ULL);
    return v_x_249;
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2ememoed_2eapp_lam1(V self, V *args) {
  V v_f_244 = args[0];
  V v_g1_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2evalue_2eapp(v_f_244, heff_clo(g_heff_2ememoed_2eapp_lam2, 1, 1, (V[]){v_g1_241})));
}
V g_heff_2ememoed_2eapp_lam0(V self, V *args) {
  V v_u_243 = args[0];
  V v_g1_241 = heff_dup(heff_env(self)[0]);
  V v_g0_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_u_243);
  V v_f_2410 = heff_clo(g_heff_2ememoed_2eapp_lam1, 1, 1, (V[]){v_g1_241});
  V v_x2_2411 = heff_tr(heff_apply(heff_get(v_g0_240, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    heff_take(v_x2_2411, 1ULL);
    return heff_tail(v_f_2410, 1, (V[]){v_x_2412});
  }
  case TAG_Describe: {
    V v_x_2413 = heff_field(v_x2_2411, 0);
    heff_take(v_x2_2411, 1ULL);
    return heff_tail(v_f_2410, 1, (V[]){v_x_2413});
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x2_2411, 0);
    V v_ru_24x2_2411_24Become = heff_take_reuse(v_x2_2411, 1ULL);
    V v_x1_2415 = heff_tr(heff_apply(v_f_2410, 1, (V[]){v_x_2414}));
    V v_t_2419;
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_Nom: {
      V v_x_2416 = heff_field(v_x1_2415, 0);
      heff_take(v_x1_2415, 1ULL);
      v_t_2419 = v_x_2416;
      break;
    }
    case TAG_Describe: {
      heff_take(v_x1_2415, 0ULL);
      v_t_2419 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2418 = heff_field(v_x1_2415, 0);
      heff_take(v_x1_2415, 1ULL);
      v_t_2419 = v_x_2418;
      break;
    }
    default: heff_nomatch(v_x1_2415);
    }
    return heff_tag_at(v_ru_24x2_2411_24Become, TAG_Become, 1, (V[]){v_t_2419});
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2ememoed_2eiapp_lam2(V self, V *args);
V g_heff_2ememoed_2eiapp_lam1(V self, V *args);
V g_heff_2ememoed_2eiapp_lam0(V self, V *args);
Clo g_heff_2ememoed_2eiapp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2eiapp_entry, 3, 0};

V g_heff_2ememoed_2eiapp(V v_x_240, V v_g0_241, V v_g1_242) {
top: ;
  V v_t_243 = heff_tag(TAG_SImplicit, 2, (V[]){v_x_240, heff_get(heff_dup(v_g1_242), LBL_stx)});
  V v_t_244 = heff_tag(TAG_SApp, 2, (V[]){heff_get(heff_dup(v_g0_241), LBL_stx), v_t_243});
  return heff_rec(2, shape_311_351, (V[]){v_t_244, heff_clo(g_heff_2ememoed_2eiapp_lam0, 1, 2, (V[]){v_g1_242, v_g0_241})});
}
V g_heff_2ememoed_2eiapp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2eiapp(a[0], a[1], a[2]);
}
V g_heff_2ememoed_2eiapp_lam2(V self, V *args) {
  V v_u2_247 = args[0];
  V v_g1_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_u2_247);
  V v_x1_248 = heff_tr(heff_apply(heff_get(v_g1_242, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nom: {
    V v_x_249 = heff_field(v_x1_248, 0);
    heff_take(v_x1_248, 1ULL);
    return v_x_249;
  }
  case TAG_Describe: {
    heff_take(v_x1_248, 0ULL);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2411 = heff_field(v_x1_248, 0);
    heff_take(v_x1_248, 1ULL);
    return v_x_2411;
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2ememoed_2eiapp_lam1(V self, V *args) {
  V v_f_246 = args[0];
  V v_g1_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2evalue_2eapp(v_f_246, heff_clo(g_heff_2ememoed_2eiapp_lam2, 1, 1, (V[]){v_g1_242})));
}
V g_heff_2ememoed_2eiapp_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_g1_242 = heff_dup(heff_env(self)[0]);
  V v_g0_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_u_245);
  V v_f_2412 = heff_clo(g_heff_2ememoed_2eiapp_lam1, 1, 1, (V[]){v_g1_242});
  V v_x2_2413 = heff_tr(heff_apply(heff_get(v_g0_241, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nom: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    heff_take(v_x2_2413, 1ULL);
    return heff_tail(v_f_2412, 1, (V[]){v_x_2414});
  }
  case TAG_Describe: {
    V v_x_2415 = heff_field(v_x2_2413, 0);
    heff_take(v_x2_2413, 1ULL);
    return heff_tail(v_f_2412, 1, (V[]){v_x_2415});
  }
  case TAG_Become: {
    V v_x_2416 = heff_field(v_x2_2413, 0);
    V v_ru_24x2_2413_24Become = heff_take_reuse(v_x2_2413, 1ULL);
    V v_x1_2417 = heff_tr(heff_apply(v_f_2412, 1, (V[]){v_x_2416}));
    V v_t_2421;
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Nom: {
      V v_x_2418 = heff_field(v_x1_2417, 0);
      heff_take(v_x1_2417, 1ULL);
      v_t_2421 = v_x_2418;
      break;
    }
    case TAG_Describe: {
      heff_take(v_x1_2417, 0ULL);
      v_t_2421 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2420 = heff_field(v_x1_2417, 0);
      heff_take(v_x1_2417, 1ULL);
      v_t_2421 = v_x_2420;
      break;
    }
    default: heff_nomatch(v_x1_2417);
    }
    return heff_tag_at(v_ru_24x2_2413_24Become, TAG_Become, 1, (V[]){v_t_2421});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ememoed_2elam_lam1(V self, V *args);
V g_heff_2ememoed_2elam_lam2(V self, V *args);
V g_heff_2ememoed_2elam_lam0(V self, V *args);
V g_heff_2ememoed_2elam_lam4(V self, V *args);
V g_heff_2ememoed_2elam_lam3(V self, V *args);
Clo g_heff_2ememoed_2elam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2elam_entry, 5, 0};

V g_heff_2ememoed_2elam(V v_c_240, V v_g_241, V v_vs_242, V v_gdom_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkAbs: {
    V v_x_245 = heff_field(v_x5_244, 0);
    V v_gbody_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24MkAbs = heff_take_reuse(v_x5_244, 3ULL);
    V v_t_247 = heff_tag_at(v_ru_24x5_244_24MkAbs, TAG_MkAbs, 2, (V[]){heff_dup(v_x_245), heff_get(heff_dup(v_gbody_246), LBL_stx)});
    V v_t_248 = heff_tag(TAG_SLam, 2, (V[]){heff_get(heff_dup(v_gdom_243), LBL_stx), v_t_247});
    return heff_rec(2, shape_311_351, (V[]){v_t_248, heff_clo(g_heff_2ememoed_2elam_lam0, 1, 6, (V[]){v_gdom_243, v_x_245, v_vs_242, v_g_241, v_c_240, v_gbody_246})});
  }
  case TAG_AbsConst: {
    V v_gbody_2417 = heff_field(v_x5_244, 0);
    V v_ru_24x5_244_24AbsConst = heff_take_reuse(v_x5_244, 1ULL);
    heff_drop(v_g_241);
    heff_drop(v_vs_242);
    V v_t_2418 = heff_tag_at(v_ru_24x5_244_24AbsConst, TAG_AbsConst, 1, (V[]){heff_get(heff_dup(v_gbody_2417), LBL_stx)});
    V v_t_2419 = heff_tag(TAG_SLam, 2, (V[]){heff_get(heff_dup(v_gdom_243), LBL_stx), v_t_2418});
    return heff_rec(2, shape_311_351, (V[]){v_t_2419, heff_clo(g_heff_2ememoed_2elam_lam3, 1, 3, (V[]){v_gbody_2417, v_gdom_243, v_c_240})});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ememoed_2elam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2elam(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ememoed_2elam_lam1(V self, V *args) {
  V v_u2_2410 = args[0];
  V v_gdom_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_u2_2410);
  V v_x1_2411 = heff_tr(heff_apply(heff_get(v_gdom_243, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take(v_x1_2411, 1ULL);
    return v_x_2412;
  }
  case TAG_Describe: {
    heff_take(v_x1_2411, 0ULL);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take(v_x1_2411, 1ULL);
    return v_x_2414;
  }
  default: return heff_nomatch(v_x1_2411);
  }
}
V g_heff_2ememoed_2elam_lam2(V self, V *args) {
  V v_vs2_2415 = args[0];
  V v_g_241 = heff_dup(heff_env(self)[0]);
  V v_c_240 = heff_dup(heff_env(self)[1]);
  V v_gbody_246 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return (g_heff_2eeval_2eevalTermF_24s14(v_g_241, v_c_240, heff_get(v_gbody_246, LBL_stx), v_vs2_2415));
}
V g_heff_2ememoed_2elam_lam0(V self, V *args) {
  V v_u_249 = args[0];
  V v_gdom_243 = heff_dup(heff_env(self)[0]);
  V v_x_245 = heff_dup(heff_env(self)[1]);
  V v_vs_242 = heff_dup(heff_env(self)[2]);
  V v_g_241 = heff_dup(heff_env(self)[3]);
  V v_c_240 = heff_dup(heff_env(self)[4]);
  V v_gbody_246 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  heff_drop(v_u_249);
  V v_x_2416 = heff_tag(TAG_VLam, 2, (V[]){heff_clo(g_heff_2ememoed_2elam_lam1, 1, 1, (V[]){v_gdom_243}), heff_tag(TAG_MkClo, 3, (V[]){v_x_245, v_vs_242, heff_clo(g_heff_2ememoed_2elam_lam2, 1, 3, (V[]){v_g_241, heff_dup(v_c_240), v_gbody_246})})});
  switch (heff_tag_of(v_c_240)) {
  case TAG_N: {
    heff_drop(v_c_240);
    return heff_tag(TAG_Nom, 1, (V[]){v_x_2416});
  }
  case TAG_De: {
    heff_drop(v_c_240);
    return heff_tag(TAG_Describe, 1, (V[]){v_x_2416});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2ememoed_2elam_lam4(V self, V *args) {
  V v_u2_2422 = args[0];
  V v_gdom_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_u2_2422);
  V v_x1_2423 = heff_tr(heff_apply(heff_get(v_gdom_243, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2423)) {
  case TAG_Nom: {
    V v_x_2424 = heff_field(v_x1_2423, 0);
    heff_take(v_x1_2423, 1ULL);
    return v_x_2424;
  }
  case TAG_Describe: {
    heff_take(v_x1_2423, 0ULL);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2426 = heff_field(v_x1_2423, 0);
    heff_take(v_x1_2423, 1ULL);
    return v_x_2426;
  }
  default: return heff_nomatch(v_x1_2423);
  }
}
V g_heff_2ememoed_2elam_lam3(V self, V *args) {
  V v_u_2420 = args[0];
  V v_gbody_2417 = heff_dup(heff_env(self)[0]);
  V v_gdom_243 = heff_dup(heff_env(self)[1]);
  V v_c_240 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_u_2420);
  V v_t_2421 = heff_tr(heff_apply(heff_get(v_gbody_2417, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x_2427 = heff_tag(TAG_VLam, 2, (V[]){heff_clo(g_heff_2ememoed_2elam_lam4, 1, 1, (V[]){v_gdom_243}), heff_tag(TAG_CloConst, 1, (V[]){v_t_2421})});
  switch (heff_tag_of(v_c_240)) {
  case TAG_N: {
    heff_drop(v_c_240);
    return heff_tag(TAG_Nom, 1, (V[]){v_x_2427});
  }
  case TAG_De: {
    heff_drop(v_c_240);
    return heff_tag(TAG_Describe, 1, (V[]){v_x_2427});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2ememoed_2econs_lam0(V self, V *args);
V g_heff_2ememoed_2econs_lam2(V self, V *args);
V g_heff_2ememoed_2econs_lam1(V self, V *args);
Clo g_heff_2ememoed_2econs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2econs_entry, 2, 0};

V g_heff_2ememoed_2econs(V v_c_240, V v_d_241) {
top: ;
  V v_xs_242 = heff_get(heff_dup(v_d_241), LBL_values);
  V v_t_245 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_242)), heff_clo(g_heff_2ememoed_2econs_lam0, 1, 1, (V[]){v_xs_242}));
  V v_t_246 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_d_241), LBL_keys), heff_get(heff_dup(v_d_241), LBL_byName), v_t_245});
  return heff_rec(2, shape_311_351, (V[]){heff_tag(TAG_SCons, 1, (V[]){v_t_246}), heff_clo(g_heff_2ememoed_2econs_lam1, 1, 2, (V[]){v_d_241, heff_dup(v_c_240)})});
}
V g_heff_2ememoed_2econs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ememoed_2econs(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ememoed_2econs_lam0(V self, V *args) {
  V v_i_243 = args[0];
  V v_xs_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_m_244 = heff_arrayIndex(v_xs_242, v_i_243);
  return heff_get(v_m_244, LBL_stx);
}
V g_heff_2ememoed_2econs_lam2(V self, V *args) {
  V v_i_249 = args[0];
  V v_xs_248 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_m_2410 = heff_arrayIndex(v_xs_248, v_i_249);
  return heff_tail(heff_get(v_m_2410, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2ememoed_2econs_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_d_241 = heff_dup(heff_env(self)[0]);
  V v_c_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_u_247);
  V v_xs_248 = heff_get(heff_dup(v_d_241), LBL_values);
  V v_t_2411 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_248)), heff_clo(g_heff_2ememoed_2econs_lam2, 1, 1, (V[]){v_xs_248}));
  V v_t_2412 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_d_241), LBL_keys), heff_get(v_d_241, LBL_byName), v_t_2411});
  V v_x_2413 = heff_tag(TAG_VCons, 1, (V[]){v_t_2412});
  switch (heff_tag_of(v_c_240)) {
  case TAG_N: {
    heff_drop(v_c_240);
    return heff_tag(TAG_Nom, 1, (V[]){v_x_2413});
  }
  case TAG_De: {
    heff_drop(v_c_240);
    return heff_tag(TAG_Describe, 1, (V[]){v_x_2413});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2ememoed_2eproj_lam0(V self, V *args);
Clo g_heff_2ememoed_2eproj_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2eproj_entry, 2, 0};

V g_heff_2ememoed_2eproj(V v_g_240, V v_x_241) {
top: ;
  V v_t_242 = heff_tag(TAG_SProj, 2, (V[]){heff_get(heff_dup(v_g_240), LBL_stx), heff_dup(v_x_241)});
  return heff_rec(2, shape_311_351, (V[]){v_t_242, heff_clo(g_heff_2ememoed_2eproj_lam0, 1, 2, (V[]){v_g_240, v_x_241})});
}
V g_heff_2ememoed_2eproj_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2eproj(a[0], a[1]);
}
V g_heff_2ememoed_2eproj_lam0(V self, V *args) {
  V v_u_243 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_x_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_u_243);
  V v_x2_244 = heff_tr(heff_apply(heff_get(v_g_240, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nom: {
    V v_x_245 = heff_field(v_x2_244, 0);
    heff_take(v_x2_244, 1ULL);
    return (g_heff_2evalue_2eproj(v_x_245, v_x_241));
  }
  case TAG_Describe: {
    V v_x_246 = heff_field(v_x2_244, 0);
    heff_take(v_x2_244, 1ULL);
    return (g_heff_2evalue_2eproj(v_x_246, v_x_241));
  }
  case TAG_Become: {
    V v_x_247 = heff_field(v_x2_244, 0);
    V v_ru_24x2_244_24Become = heff_take_reuse(v_x2_244, 1ULL);
    V v_x1_248 = (g_heff_2evalue_2eproj(v_x_247, v_x_241));
    V v_t_2412;
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Nom: {
      V v_x_249 = heff_field(v_x1_248, 0);
      heff_take(v_x1_248, 1ULL);
      v_t_2412 = v_x_249;
      break;
    }
    case TAG_Describe: {
      heff_take(v_x1_248, 0ULL);
      v_t_2412 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2411 = heff_field(v_x1_248, 0);
      heff_take(v_x1_248, 1ULL);
      v_t_2412 = v_x_2411;
      break;
    }
    default: heff_nomatch(v_x1_248);
    }
    return heff_tag_at(v_ru_24x2_244_24Become, TAG_Become, 1, (V[]){v_t_2412});
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ememoed_2eprojAt_lam0(V self, V *args);
Clo g_heff_2ememoed_2eprojAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2eprojAt_entry, 3, 0};

V g_heff_2ememoed_2eprojAt(V v_g_240, V v_x_241, V v_a_242) {
top: ;
  V v_t_243 = heff_tag(TAG_SProj, 2, (V[]){heff_get(heff_dup(v_g_240), LBL_stx), heff_dup(v_x_241)});
  return heff_rec(2, shape_311_351, (V[]){v_t_243, heff_clo(g_heff_2ememoed_2eprojAt_lam0, 1, 3, (V[]){v_g_240, v_x_241, v_a_242})});
}
V g_heff_2ememoed_2eprojAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2eprojAt(a[0], a[1], a[2]);
}
V g_heff_2ememoed_2eprojAt_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_x_241 = heff_dup(heff_env(self)[1]);
  V v_a_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_u_244);
  V v_x2_245 = heff_tr(heff_apply(heff_get(v_g_240, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nom: {
    V v_x_246 = heff_field(v_x2_245, 0);
    heff_take(v_x2_245, 1ULL);
    return (g_heff_2evalue_2eprojAt(v_x_246, v_x_241, v_a_242));
  }
  case TAG_Describe: {
    V v_x_247 = heff_field(v_x2_245, 0);
    heff_take(v_x2_245, 1ULL);
    return (g_heff_2evalue_2eprojAt(v_x_247, v_x_241, v_a_242));
  }
  case TAG_Become: {
    V v_x_248 = heff_field(v_x2_245, 0);
    V v_ru_24x2_245_24Become = heff_take_reuse(v_x2_245, 1ULL);
    V v_x1_249 = (g_heff_2evalue_2eprojAt(v_x_248, v_x_241, v_a_242));
    V v_t_2413;
    switch (heff_tag_of(v_x1_249)) {
    case TAG_Nom: {
      V v_x_2410 = heff_field(v_x1_249, 0);
      heff_take(v_x1_249, 1ULL);
      v_t_2413 = v_x_2410;
      break;
    }
    case TAG_Describe: {
      heff_take(v_x1_249, 0ULL);
      v_t_2413 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2412 = heff_field(v_x1_249, 0);
      heff_take(v_x1_249, 1ULL);
      v_t_2413 = v_x_2412;
      break;
    }
    default: heff_nomatch(v_x1_249);
    }
    return heff_tag_at(v_ru_24x2_245_24Become, TAG_Become, 1, (V[]){v_t_2413});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ememoed_2especializeM_lam0(V self, V *args);
Clo g_heff_2ememoed_2especializeM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2especializeM_entry, 3, 0};

V g_heff_2ememoed_2especializeM(V v_g_240, V v_x_241, V v_g_27_242) {
top: ;
  V v_t_243 = heff_tag(TAG_SSpecialize, 3, (V[]){heff_get(heff_dup(v_g_240), LBL_stx), heff_dup(v_x_241), heff_get(heff_dup(v_g_27_242), LBL_stx)});
  return heff_rec(2, shape_311_351, (V[]){v_t_243, heff_clo(g_heff_2ememoed_2especializeM_lam0, 1, 3, (V[]){v_g_240, v_g_27_242, v_x_241})});
}
V g_heff_2ememoed_2especializeM_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2especializeM(a[0], a[1], a[2]);
}
V g_heff_2ememoed_2especializeM_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_g_27_242 = heff_dup(heff_env(self)[1]);
  V v_x_241 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_u_244);
  V v_x1_245 = heff_tr(heff_apply(heff_get(v_g_240, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_249;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Nom: {
    V v_x_246 = heff_field(v_x1_245, 0);
    heff_take(v_x1_245, 1ULL);
    v_t_249 = v_x_246;
    break;
  }
  case TAG_Describe: {
    heff_take(v_x1_245, 0ULL);
    v_t_249 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_248 = heff_field(v_x1_245, 0);
    heff_take(v_x1_245, 1ULL);
    v_t_249 = v_x_248;
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  V v_x1_2410 = heff_tr(heff_apply(heff_get(v_g_27_242, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2414;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nom: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take(v_x1_2410, 1ULL);
    v_t_2414 = v_x_2411;
    break;
  }
  case TAG_Describe: {
    heff_take(v_x1_2410, 0ULL);
    v_t_2414 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2413 = heff_field(v_x1_2410, 0);
    heff_take(v_x1_2410, 1ULL);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2especialize(v_t_249, v_x_241, v_t_2414))});
}
V g_heff_2ememoed_2eabandonM_lam0(V self, V *args); static Clo g_heff_2ememoed_2eabandonM_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2eabandonM_lam0, 1, 0};

static V g_heff_2ememoed_2eabandonM_val;
static int g_heff_2ememoed_2eabandonM_st;
static V g_heff_2ememoed_2eabandonM_init(void) {
  return heff_rec(2, shape_311_351, (V[]){NTAG(TAG_SAbandon), ((V)&g_heff_2ememoed_2eabandonM_lam0_clo)});
}
V g_heff_2ememoed_2eabandonM_get(void) {
  if (g_heff_2ememoed_2eabandonM_st == 2) return g_heff_2ememoed_2eabandonM_val;
  if (g_heff_2ememoed_2eabandonM_st == 1) heff_fail("defined by itself");
  g_heff_2ememoed_2eabandonM_st = 1;
  g_heff_2ememoed_2eabandonM_val = heff_tr(g_heff_2ememoed_2eabandonM_init());
  g_heff_2ememoed_2eabandonM_st = 2;
  return g_heff_2ememoed_2eabandonM_val;
}
V g_heff_2ememoed_2eabandonM_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(self);
  heff_drop(v_u_240);
  return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2ememoed_2edecode_lam0(V self, V *args);
Clo g_heff_2ememoed_2edecode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2edecode_entry, 1, 0};

V g_heff_2ememoed_2edecode(V v_g_240) {
top: ;
  V v_t_241 = heff_tag(TAG_SDecode, 1, (V[]){heff_get(heff_dup(v_g_240), LBL_stx)});
  return heff_rec(2, shape_311_351, (V[]){v_t_241, heff_clo(g_heff_2ememoed_2edecode_lam0, 1, 1, (V[]){v_g_240})});
}
V g_heff_2ememoed_2edecode_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2edecode(a[0]);
}
V g_heff_2ememoed_2edecode_lam0(V self, V *args) {
  V v_u_242 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_u_242);
  V v_x1_243 = heff_tr(heff_apply(heff_get(v_g_240, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nom: {
    V v_x_244 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24Nom = heff_take_reuse(v_x1_243, 1ULL);
    return heff_tag_at(v_ru_24x1_243_24Nom, TAG_Nom, 1, (V[]){({ V a_0 = v_x_244; V r_ = (g_heff_2evalue_2edecodeN(a_0)); heff_drop(v_x_244); r_; })});
  }
  case TAG_Describe: {
    V v_x_245 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24Describe = heff_take_reuse(v_x1_243, 1ULL);
    switch (heff_tag_of(v_x_245)) {
    case TAG_VNeu: {
      heff_take(v_x_245, 0ULL);
      heff_drop(v_ru_24x1_243_24Describe);
      return heff_abandon();
    }
    case TAG_VCode: {
      V v_a_2411 = heff_field(v_x_245, 0);
      heff_take(v_x_245, 1ULL);
      return heff_tag_at(v_ru_24x1_243_24Describe, TAG_Describe, 1, (V[]){v_a_2411});
    }
    case TAG_VLam: {
      heff_take(v_x_245, 0ULL);
      heff_drop(v_ru_24x1_243_24Describe);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_x_245, 0ULL);
      heff_drop(v_ru_24x1_243_24Describe);
      return heff_abandon();
    }
    case TAG_VOpaque: {
      heff_drop(v_x_245);
      heff_drop(v_ru_24x1_243_24Describe);
      return heff_abandon();
    }
    default: return heff_nomatch(v_x_245);
    }
  }
  case TAG_Become: {
    V v_x_2415 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24Become = heff_take_reuse(v_x1_243, 1ULL);
    return heff_tag_at(v_ru_24x1_243_24Become, TAG_Become, 1, (V[]){({ V a_0 = v_x_2415; V r_ = (g_heff_2evalue_2edecodeN(a_0)); heff_drop(v_x_2415); r_; })});
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2ememoed_2efunctionI_lam1(V self, V *args);
V g_heff_2ememoed_2efunctionI_lam0(V self, V *args);
V g_heff_2ememoed_2efunctionI_lam2(V self, V *args);
Clo g_heff_2ememoed_2efunctionI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2efunctionI_entry, 5, 0};

V g_heff_2ememoed_2efunctionI(V v_implicit_240, V v_g_241, V v_vs_242, V v_dom_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkAbs: {
    V v_x_245 = heff_field(v_x5_244, 0);
    V v_body_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24MkAbs = heff_take_reuse(v_x5_244, 3ULL);
    V v_x1_247 = heff_tr(heff_apply(heff_get(heff_dup(v_body_246), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2411;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nom: {
      V v_t_248 = heff_field(v_x1_247, 0);
      heff_take(v_x1_247, 1ULL);
      v_t_2411 = ({ V a_0 = v_t_248; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_248); r_; });
      break;
    }
    case TAG_Describe: {
      V v_t_249 = heff_field(v_x1_247, 0);
      heff_take(v_x1_247, 1ULL);
      v_t_2411 = ({ V a_0 = v_t_249; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_249); r_; });
      break;
    }
    case TAG_Become: {
      V v_t_2410 = heff_field(v_x1_247, 0);
      heff_take(v_x1_247, 1ULL);
      v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    V v_t_2412 = heff_tag_at(v_ru_24x5_244_24MkAbs, TAG_MkAbs, 2, (V[]){heff_dup(v_x_245), heff_get(heff_dup(v_body_246), LBL_stx)});
    V v_t_2413 = heff_tag(TAG_SFunction, 4, (V[]){v_t_2411, heff_get(heff_dup(v_dom_243), LBL_stx), v_t_2412, heff_dup(v_implicit_240)});
    return heff_rec(2, shape_311_351, (V[]){v_t_2413, heff_clo(g_heff_2ememoed_2efunctionI_lam0, 1, 6, (V[]){v_body_246, v_dom_243, v_x_245, v_vs_242, v_g_241, v_implicit_240})});
  }
  case TAG_AbsConst: {
    V v_body_2427 = heff_field(v_x5_244, 0);
    V v_ru_24x5_244_24AbsConst = heff_take_reuse(v_x5_244, 1ULL);
    heff_drop(v_g_241);
    heff_drop(v_vs_242);
    V v_x1_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_body_2427), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2432;
    switch (heff_tag_of(v_x1_2428)) {
    case TAG_Nom: {
      V v_t_2429 = heff_field(v_x1_2428, 0);
      heff_take(v_x1_2428, 1ULL);
      v_t_2432 = ({ V a_0 = v_t_2429; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2429); r_; });
      break;
    }
    case TAG_Describe: {
      V v_t_2430 = heff_field(v_x1_2428, 0);
      heff_take(v_x1_2428, 1ULL);
      v_t_2432 = ({ V a_0 = v_t_2430; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2430); r_; });
      break;
    }
    case TAG_Become: {
      V v_t_2431 = heff_field(v_x1_2428, 0);
      heff_take(v_x1_2428, 1ULL);
      v_t_2432 = ({ V a_0 = v_t_2431; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2431); r_; });
      break;
    }
    default: heff_nomatch(v_x1_2428);
    }
    V v_t_2433 = heff_tag_at(v_ru_24x5_244_24AbsConst, TAG_AbsConst, 1, (V[]){heff_get(heff_dup(v_body_2427), LBL_stx)});
    V v_t_2434 = heff_tag(TAG_SFunction, 4, (V[]){v_t_2432, heff_get(heff_dup(v_dom_243), LBL_stx), v_t_2433, heff_dup(v_implicit_240)});
    return heff_rec(2, shape_311_351, (V[]){v_t_2434, heff_clo(g_heff_2ememoed_2efunctionI_lam2, 1, 3, (V[]){v_body_2427, v_dom_243, v_implicit_240})});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ememoed_2efunctionI_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2efunctionI(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ememoed_2efunctionI_lam1(V self, V *args) {
  V v_vs2_2425 = args[0];
  V v_g_241 = heff_dup(heff_env(self)[0]);
  V v_body_246 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return (g_heff_2eeval_2eevalTypeF_24s15(v_g_241, NTAG(TAG_N), heff_get(v_body_246, LBL_stx), v_vs2_2425));
}
V g_heff_2ememoed_2efunctionI_lam0(V self, V *args) {
  V v_u_2414 = args[0];
  V v_body_246 = heff_dup(heff_env(self)[0]);
  V v_dom_243 = heff_dup(heff_env(self)[1]);
  V v_x_245 = heff_dup(heff_env(self)[2]);
  V v_vs_242 = heff_dup(heff_env(self)[3]);
  V v_g_241 = heff_dup(heff_env(self)[4]);
  V v_implicit_240 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  heff_drop(v_u_2414);
  V v_x1_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_body_246), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2419;
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_Nom: {
    V v_t_2416 = heff_field(v_x1_2415, 0);
    heff_take(v_x1_2415, 1ULL);
    v_t_2419 = ({ V a_0 = v_t_2416; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2416); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2417 = heff_field(v_x1_2415, 0);
    heff_take(v_x1_2415, 1ULL);
    v_t_2419 = ({ V a_0 = v_t_2417; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2417); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2418 = heff_field(v_x1_2415, 0);
    heff_take(v_x1_2415, 1ULL);
    v_t_2419 = ({ V a_0 = v_t_2418; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2418); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2415);
  }
  V v_x1_2420 = heff_tr(heff_apply(heff_get(v_dom_243, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2424;
  switch (heff_tag_of(v_x1_2420)) {
  case TAG_Nom: {
    V v_x_2421 = heff_field(v_x1_2420, 0);
    heff_take(v_x1_2420, 1ULL);
    v_t_2424 = v_x_2421;
    break;
  }
  case TAG_Describe: {
    heff_take(v_x1_2420, 0ULL);
    v_t_2424 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2423 = heff_field(v_x1_2420, 0);
    heff_take(v_x1_2420, 1ULL);
    v_t_2424 = v_x_2423;
    break;
  }
  default: heff_nomatch(v_x1_2420);
  }
  V v_t_2426 = heff_tag(TAG_VFunction, 4, (V[]){v_t_2419, v_t_2424, heff_tag(TAG_MkClo, 3, (V[]){v_x_245, v_vs_242, heff_clo(g_heff_2ememoed_2efunctionI_lam1, 1, 2, (V[]){v_g_241, v_body_246})}), v_implicit_240});
  return heff_tag(TAG_Nom, 1, (V[]){v_t_2426});
}
V g_heff_2ememoed_2efunctionI_lam2(V self, V *args) {
  V v_u_2435 = args[0];
  V v_body_2427 = heff_dup(heff_env(self)[0]);
  V v_dom_243 = heff_dup(heff_env(self)[1]);
  V v_implicit_240 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_u_2435);
  V v_x1_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_body_2427), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2440;
  switch (heff_tag_of(v_x1_2436)) {
  case TAG_Nom: {
    V v_t_2437 = heff_field(v_x1_2436, 0);
    heff_take(v_x1_2436, 1ULL);
    v_t_2440 = ({ V a_0 = v_t_2437; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2437); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2438 = heff_field(v_x1_2436, 0);
    heff_take(v_x1_2436, 1ULL);
    v_t_2440 = ({ V a_0 = v_t_2438; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2438); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2439 = heff_field(v_x1_2436, 0);
    heff_take(v_x1_2436, 1ULL);
    v_t_2440 = ({ V a_0 = v_t_2439; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2439); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2436);
  }
  V v_x1_2441 = heff_tr(heff_apply(heff_get(v_dom_243, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2445;
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_Nom: {
    V v_x_2442 = heff_field(v_x1_2441, 0);
    heff_take(v_x1_2441, 1ULL);
    v_t_2445 = v_x_2442;
    break;
  }
  case TAG_Describe: {
    heff_take(v_x1_2441, 0ULL);
    v_t_2445 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2444 = heff_field(v_x1_2441, 0);
    heff_take(v_x1_2441, 1ULL);
    v_t_2445 = v_x_2444;
    break;
  }
  default: heff_nomatch(v_x1_2441);
  }
  V v_t_2446 = heff_tr(heff_apply(heff_get(v_body_2427, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2447 = heff_tag(TAG_VFunction, 4, (V[]){v_t_2440, v_t_2445, heff_tag(TAG_CloConst, 1, (V[]){v_t_2446}), v_implicit_240});
  return heff_tag(TAG_Nom, 1, (V[]){v_t_2447});
}
V g_heff_2ememoed_2erecordM_lam2(V self, V *args);
V g_heff_2ememoed_2erecordM_lam1(V self, V *args);
V g_heff_2ememoed_2erecordM_lam0(V self, V *args);
Clo g_heff_2ememoed_2erecordM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2erecordM_entry, 4, 0};

V g_heff_2ememoed_2erecordM(V v_g_240, V v_vs_241, V v_level_242, V v_fieldTypes_243) {
top: ;
  return heff_rec(2, shape_311_351, (V[]){heff_tag(TAG_SRecord, 2, (V[]){heff_dup(v_level_242), heff_dup(v_fieldTypes_243)}), heff_clo(g_heff_2ememoed_2erecordM_lam0, 1, 4, (V[]){v_fieldTypes_243, v_g_240, v_level_242, v_vs_241})});
}
V g_heff_2ememoed_2erecordM_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2erecordM(a[0], a[1], a[2], a[3]);
}
V g_heff_2ememoed_2erecordM_lam2(V self, V *args) {
  V v_vs2_248 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_t_247 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_x1_249 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_t_247, v_vs2_248));
  V v_t_2413;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nom: {
    V v_x_2410 = heff_field(v_x1_249, 0);
    heff_take(v_x1_249, 1ULL);
    v_t_2413 = v_x_2410;
    break;
  }
  case TAG_Describe: {
    heff_take(v_x1_249, 0ULL);
    v_t_2413 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2412 = heff_field(v_x1_249, 0);
    heff_take(v_x1_249, 1ULL);
    v_t_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  return heff_tag(TAG_MkField, 2, (V[]){v_t_2413, NTAG(TAG_Nothing)});
}
V g_heff_2ememoed_2erecordM_lam1(V self, V *args) {
  V v_i_246 = args[0];
  V v_xs_245 = heff_dup(heff_env(self)[0]);
  V v_g_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_247 = heff_arrayIndex(v_xs_245, v_i_246);
  return heff_clo(g_heff_2ememoed_2erecordM_lam2, 1, 2, (V[]){v_g_240, v_t_247});
}
V g_heff_2ememoed_2erecordM_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_fieldTypes_243 = heff_dup(heff_env(self)[0]);
  V v_g_240 = heff_dup(heff_env(self)[1]);
  V v_level_242 = heff_dup(heff_env(self)[2]);
  V v_vs_241 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  heff_drop(v_u_244);
  V v_xs_245 = heff_get(heff_dup(v_fieldTypes_243), LBL_values);
  V v_t_2414 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_245)), heff_clo(g_heff_2ememoed_2erecordM_lam1, 1, 2, (V[]){v_xs_245, v_g_240}));
  V v_t_2415 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_fieldTypes_243), LBL_keys), heff_get(v_fieldTypes_243, LBL_byName), v_t_2414});
  return heff_tag(TAG_Describe, 1, (V[]){heff_tag(TAG_VRecord, 3, (V[]){v_level_242, v_vs_241, v_t_2415})});
}
V g_heff_2ememoed_2esumM_lam1(V self, V *args);
V g_heff_2ememoed_2esumM_lam0(V self, V *args);
V g_heff_2ememoed_2esumM_lam2(V self, V *args);
Clo g_heff_2ememoed_2esumM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2esumM_entry, 1, 0};

V g_heff_2ememoed_2esumM(V v_st_240) {
top: ;
  V v_xs_241 = heff_get(heff_dup(v_st_240), LBL_values);
  V v_t_246 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_241)), heff_clo(g_heff_2ememoed_2esumM_lam0, 1, 1, (V[]){v_xs_241}));
  V v_t_247 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_st_240), LBL_keys), heff_get(heff_dup(v_st_240), LBL_byName), v_t_246});
  return heff_rec(2, shape_311_351, (V[]){heff_tag(TAG_SSum, 1, (V[]){v_t_247}), heff_clo(g_heff_2ememoed_2esumM_lam2, 1, 1, (V[]){v_st_240})});
}
V g_heff_2ememoed_2esumM_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2esumM(a[0]);
}
V g_heff_2ememoed_2esumM_lam1(V self, V *args) {
  V v_i_244 = args[0];
  V v_xs_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_m_245 = heff_arrayIndex(v_xs_243, v_i_244);
  return heff_get(v_m_245, LBL_stx);
}
V g_heff_2ememoed_2esumM_lam0(V self, V *args) {
  V v_i_242 = args[0];
  V v_xs_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_xs_243 = heff_arrayIndex(v_xs_241, v_i_242);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_243)), heff_clo(g_heff_2ememoed_2esumM_lam1, 1, 1, (V[]){v_xs_243}));
}
V g_heff_2ememoed_2esumM_lam2(V self, V *args) {
  V v_u_248 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_u_248);
  V v_t_249 = heff_tag(TAG_VSum, 1, (V[]){(g_heff_2eparams_2evariantsMap_24s314(v_st_240))});
  return heff_tag(TAG_Describe, 1, (V[]){v_t_249});
}
V g_heff_2ememoed_2eprimInt_lam0(V self, V *args); static Clo g_heff_2ememoed_2eprimInt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2eprimInt_lam0, 1, 0};

static V g_heff_2ememoed_2eprimInt_val;
static int g_heff_2ememoed_2eprimInt_st;
static V g_heff_2ememoed_2eprimInt_init(void) {
  return heff_rec(2, shape_311_351, (V[]){NTAG(TAG_SPrimInt), ((V)&g_heff_2ememoed_2eprimInt_lam0_clo)});
}
V g_heff_2ememoed_2eprimInt_get(void) {
  if (g_heff_2ememoed_2eprimInt_st == 2) return g_heff_2ememoed_2eprimInt_val;
  if (g_heff_2ememoed_2eprimInt_st == 1) heff_fail("defined by itself");
  g_heff_2ememoed_2eprimInt_st = 1;
  g_heff_2ememoed_2eprimInt_val = heff_tr(g_heff_2ememoed_2eprimInt_init());
  g_heff_2ememoed_2eprimInt_st = 2;
  return g_heff_2ememoed_2eprimInt_val;
}
V g_heff_2ememoed_2eprimInt_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(self);
  heff_drop(v_u_240);
  return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimInt)});
}
V g_heff_2ememoed_2eprimFloat_lam0(V self, V *args); static Clo g_heff_2ememoed_2eprimFloat_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2eprimFloat_lam0, 1, 0};

static V g_heff_2ememoed_2eprimFloat_val;
static int g_heff_2ememoed_2eprimFloat_st;
static V g_heff_2ememoed_2eprimFloat_init(void) {
  return heff_rec(2, shape_311_351, (V[]){NTAG(TAG_SPrimFloat), ((V)&g_heff_2ememoed_2eprimFloat_lam0_clo)});
}
V g_heff_2ememoed_2eprimFloat_get(void) {
  if (g_heff_2ememoed_2eprimFloat_st == 2) return g_heff_2ememoed_2eprimFloat_val;
  if (g_heff_2ememoed_2eprimFloat_st == 1) heff_fail("defined by itself");
  g_heff_2ememoed_2eprimFloat_st = 1;
  g_heff_2ememoed_2eprimFloat_val = heff_tr(g_heff_2ememoed_2eprimFloat_init());
  g_heff_2ememoed_2eprimFloat_st = 2;
  return g_heff_2ememoed_2eprimFloat_val;
}
V g_heff_2ememoed_2eprimFloat_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(self);
  heff_drop(v_u_240);
  return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimFloat)});
}
V g_heff_2ememoed_2eprimString_lam0(V self, V *args); static Clo g_heff_2ememoed_2eprimString_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2eprimString_lam0, 1, 0};

static V g_heff_2ememoed_2eprimString_val;
static int g_heff_2ememoed_2eprimString_st;
static V g_heff_2ememoed_2eprimString_init(void) {
  return heff_rec(2, shape_311_351, (V[]){NTAG(TAG_SPrimString), ((V)&g_heff_2ememoed_2eprimString_lam0_clo)});
}
V g_heff_2ememoed_2eprimString_get(void) {
  if (g_heff_2ememoed_2eprimString_st == 2) return g_heff_2ememoed_2eprimString_val;
  if (g_heff_2ememoed_2eprimString_st == 1) heff_fail("defined by itself");
  g_heff_2ememoed_2eprimString_st = 1;
  g_heff_2ememoed_2eprimString_val = heff_tr(g_heff_2ememoed_2eprimString_init());
  g_heff_2ememoed_2eprimString_st = 2;
  return g_heff_2ememoed_2eprimString_val;
}
V g_heff_2ememoed_2eprimString_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(self);
  heff_drop(v_u_240);
  return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimString)});
}