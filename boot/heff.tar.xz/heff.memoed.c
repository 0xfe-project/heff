// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFunction 64505
#define TAG_SImplicit 59448
#define TAG_SLam 1658
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_byName 571997869
#define LBL_keys 9783995
#define LBL_stx 323761
#define LBL_val 326043
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eeval_2eevalTermF_clo;
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(V, V, V, V);
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_entry(V self, V *a);
extern Clo g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_clo;
V g_heff_2eeval_2eevaluator_get(void);
V g_heff_2ememoed_2eabandonM_get(void);
V g_heff_2ememoed_2eapp(V, V);
V g_heff_2ememoed_2eapp_entry(V self, V *a);
extern Clo g_heff_2ememoed_2eapp_clo;
V g_heff_2ememoed_2ecode(V);
V g_heff_2ememoed_2ecode_entry(V self, V *a);
extern Clo g_heff_2ememoed_2ecode_clo;
V g_heff_2ememoed_2econs(V, V);
V g_heff_2ememoed_2econs_entry(V self, V *a);
extern Clo g_heff_2ememoed_2econs_clo;
V g_heff_2ememoed_2edecode(V);
V g_heff_2ememoed_2edecode_entry(V self, V *a);
extern Clo g_heff_2ememoed_2edecode_clo;
V g_heff_2ememoed_2efunctionD(V, V, V, V, V, V);
V g_heff_2ememoed_2efunctionD_entry(V self, V *a);
extern Clo g_heff_2ememoed_2efunctionD_clo;
V g_heff_2ememoed_2eiapp(V, V, V);
V g_heff_2ememoed_2eiapp_entry(V self, V *a);
extern Clo g_heff_2ememoed_2eiapp_clo;
V g_heff_2ememoed_2elam(V, V, V, V, V);
V g_heff_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2ememoed_2elam_clo;
V g_heff_2ememoed_2eprimFloat_get(void);
V g_heff_2ememoed_2eprimInt_get(void);
V g_heff_2ememoed_2eprimRune_get(void);
V g_heff_2ememoed_2eprimString_get(void);
V g_heff_2ememoed_2eproj(V, V);
V g_heff_2ememoed_2eproj_entry(V self, V *a);
extern Clo g_heff_2ememoed_2eproj_clo;
V g_heff_2ememoed_2eprojAt(V, V, V);
V g_heff_2ememoed_2eprojAt_entry(V self, V *a);
extern Clo g_heff_2ememoed_2eprojAt_clo;
V g_heff_2ememoed_2erecordM(V, V, V, V, V);
V g_heff_2ememoed_2erecordM_entry(V self, V *a);
extern Clo g_heff_2ememoed_2erecordM_clo;
V g_heff_2ememoed_2especializeM(V, V, V);
V g_heff_2ememoed_2especializeM_entry(V self, V *a);
extern Clo g_heff_2ememoed_2especializeM_clo;
V g_heff_2ememoed_2esumM(V);
V g_heff_2ememoed_2esumM_entry(V self, V *a);
extern Clo g_heff_2ememoed_2esumM_clo;
V g_heff_2eparams_2evariantsMap_24s2065256000x17303345(V);
V g_heff_2eparams_2evariantsMap_24s2065256000x17303345_entry(V self, V *a);
extern Clo g_heff_2eparams_2evariantsMap_24s2065256000x17303345_clo;
V g_heff_2evalue_2eapp(V, V);
V g_heff_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2evalue_2eapp_clo;
V g_heff_2evalue_2edecodeN(V);
V g_heff_2evalue_2edecodeN_entry(V self, V *a);
extern Clo g_heff_2evalue_2edecodeN_clo;
V g_heff_2evalue_2elevelOf(V);
V g_heff_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2evalue_2elevelOf_clo;
V g_heff_2evalue_2eproj(V, V);
V g_heff_2evalue_2eproj_entry(V self, V *a);
extern Clo g_heff_2evalue_2eproj_clo;
V g_heff_2evalue_2eprojAt(V, V, V);
V g_heff_2evalue_2eprojAt_entry(V self, V *a);
extern Clo g_heff_2evalue_2eprojAt_clo;
V g_heff_2evalue_2especialize(V, V, V);
V g_heff_2evalue_2especialize_entry(V self, V *a);
extern Clo g_heff_2evalue_2especialize_clo;
V g_heff_2ememoed_2ecode_lam1(V self, V *args); static Clo g_heff_2ememoed_2ecode_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2ecode_lam1, 1, 0};
V g_heff_2ememoed_2ecode_lam0(V self, V *args);
Clo g_heff_2ememoed_2ecode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2ecode_entry, 1, 0};

V g_heff_2ememoed_2ecode(V v_g_240) {
top: ;
  V v_t_241 = heff_tag(TAG_SCode, 1, (V[]){heff_get(heff_dup(v_g_240), LBL_stx)});
  return heff_rec(2, shape_stx__val, (V[]){v_t_241, heff_clo(g_heff_2ememoed_2ecode_lam0, 1, 1, (V[]){v_g_240})});
}
V g_heff_2ememoed_2ecode_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2ecode(a[0]);
}
V g_heff_2ememoed_2ecode_lam1(V self, V *args) {
  V v_t_243 = args[0];
  switch (heff_tag_of(v_t_243)) {
  case TAG_VU: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_243});
  }
  case TAG_VDecode: {
    V v_el_249 = heff_field(v_t_243, 4);
    heff_take_n(v_t_243, 16ULL, 5);
    V f_ = v_el_249;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VFunction: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_243});
  }
  case TAG_VRecord: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_243});
  }
  case TAG_VSum: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_243});
  }
  case TAG_VPrimInt: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_243});
  }
  case TAG_VPrimFloat: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_243});
  }
  case TAG_VPrimString: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_243});
  }
  case TAG_VPrimRune: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_243});
  }
  case TAG_VPrimArray: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_243});
  }
  case TAG_VFixed: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_243});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ememoed_2ecode_lam0(V self, V *args) {
  V v_u_242 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_242);
  V v_f_2422 = ((V)&g_heff_2ememoed_2ecode_lam1_clo);
  V v_x2_2423 = heff_tr(heff_apply(heff_get(v_g_240, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_Nom: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_ru_24x2_2423_24Nom = heff_take_reuse_n(v_x2_2423, 1ULL, 1);
    V v_t_2425 = heff_tr(heff_apply(v_f_2422, 1, (V[]){v_x_2424}));
    return heff_tag_at(v_ru_24x2_2423_24Nom, TAG_Nom, 1, (V[]){v_t_2425});
  }
  case TAG_Describe: {
    V v_x_2426 = heff_field(v_x2_2423, 0);
    V v_ru_24x2_2423_24Describe = heff_take_reuse_n(v_x2_2423, 1ULL, 1);
    V v_t_2427 = heff_tr(heff_apply(v_f_2422, 1, (V[]){v_x_2426}));
    return heff_tag_at(v_ru_24x2_2423_24Describe, TAG_Describe, 1, (V[]){v_t_2427});
  }
  case TAG_Become: {
    V v_x_2428 = heff_field(v_x2_2423, 0);
    V v_ru_24x2_2423_24Become = heff_take_reuse_n(v_x2_2423, 1ULL, 1);
    V v_t_2429 = heff_tr(heff_apply(v_f_2422, 1, (V[]){v_x_2428}));
    return heff_tag_at(v_ru_24x2_2423_24Become, TAG_Become, 1, (V[]){v_t_2429});
  }
  default: return heff_nomatch(v_x2_2423);
  }
}
V g_heff_2ememoed_2eapp_lam2(V self, V *args);
V g_heff_2ememoed_2eapp_lam1(V self, V *args);
V g_heff_2ememoed_2eapp_lam0(V self, V *args);
Clo g_heff_2ememoed_2eapp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2eapp_entry, 2, 0};

V g_heff_2ememoed_2eapp(V v_g0_240, V v_g1_241) {
top: ;
  V v_t_242 = heff_tag(TAG_SApp, 2, (V[]){heff_get(heff_dup(v_g0_240), LBL_stx), heff_get(heff_dup(v_g1_241), LBL_stx)});
  return heff_rec(2, shape_stx__val, (V[]){v_t_242, heff_clo(g_heff_2ememoed_2eapp_lam0, 1, 2, (V[]){v_g1_241, v_g0_240})});
}
V g_heff_2ememoed_2eapp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2eapp(a[0], a[1]);
}
V g_heff_2ememoed_2eapp_lam2(V self, V *args) {
  V v_u2_245 = args[0];
  V v_g1_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_245);
  V v_x1_246 = heff_tr(heff_apply(heff_get(v_g1_241, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_Nom: {
    V v_x_247 = heff_field(v_x1_246, 0);
    heff_take_n(v_x1_246, 1ULL, 1);
    return v_x_247;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_246, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_249 = heff_field(v_x1_246, 0);
    heff_take_n(v_x1_246, 1ULL, 1);
    return v_x_249;
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2ememoed_2eapp_lam1(V self, V *args) {
  V v_f_244 = args[0];
  V v_g1_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2evalue_2eapp(v_f_244, heff_clo(g_heff_2ememoed_2eapp_lam2, 1, 1, (V[]){v_g1_241})));
}
V g_heff_2ememoed_2eapp_lam0(V self, V *args) {
  V v_u_243 = args[0];
  V v_g1_241 = heff_env(self)[0];
  V v_g0_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_243);
  V v_f_2410 = heff_clo(g_heff_2ememoed_2eapp_lam1, 1, 1, (V[]){v_g1_241});
  V v_x2_2411 = heff_tr(heff_apply(heff_get(v_g0_240, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    heff_take_n(v_x2_2411, 1ULL, 1);
    V f_ = v_f_2410;
    args[0] = v_x_2412;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Describe: {
    V v_x_2413 = heff_field(v_x2_2411, 0);
    heff_take_n(v_x2_2411, 1ULL, 1);
    V f_ = v_f_2410;
    args[0] = v_x_2413;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x2_2411, 0);
    V v_ru_24x2_2411_24Become = heff_take_reuse_n(v_x2_2411, 1ULL, 1);
    V v_x1_2415 = heff_tr(heff_apply(v_f_2410, 1, (V[]){v_x_2414}));
    V v_t_2419;
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_Nom: {
      V v_x_2416 = heff_field(v_x1_2415, 0);
      heff_take_n(v_x1_2415, 1ULL, 1);
      v_t_2419 = v_x_2416;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2415, 0ULL, 1);
      v_t_2419 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2418 = heff_field(v_x1_2415, 0);
      heff_take_n(v_x1_2415, 1ULL, 1);
      v_t_2419 = v_x_2418;
      break;
    }
    default: heff_nomatch(v_x1_2415);
    }
    return heff_tag_at(v_ru_24x2_2411_24Become, TAG_Become, 1, (V[]){v_t_2419});
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2ememoed_2eiapp_lam2(V self, V *args);
V g_heff_2ememoed_2eiapp_lam1(V self, V *args);
V g_heff_2ememoed_2eiapp_lam0(V self, V *args);
Clo g_heff_2ememoed_2eiapp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2eiapp_entry, 3, 0};

V g_heff_2ememoed_2eiapp(V v_x_240, V v_g0_241, V v_g1_242) {
top: ;
  V v_t_243 = heff_tag(TAG_SImplicit, 2, (V[]){v_x_240, heff_get(heff_dup(v_g1_242), LBL_stx)});
  V v_t_244 = heff_tag(TAG_SApp, 2, (V[]){heff_get(heff_dup(v_g0_241), LBL_stx), v_t_243});
  return heff_rec(2, shape_stx__val, (V[]){v_t_244, heff_clo(g_heff_2ememoed_2eiapp_lam0, 1, 2, (V[]){v_g1_242, v_g0_241})});
}
V g_heff_2ememoed_2eiapp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2eiapp(a[0], a[1], a[2]);
}
V g_heff_2ememoed_2eiapp_lam2(V self, V *args) {
  V v_u2_247 = args[0];
  V v_g1_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_247);
  V v_x1_248 = heff_tr(heff_apply(heff_get(v_g1_242, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nom: {
    V v_x_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    return v_x_249;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_248, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2411 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    return v_x_2411;
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2ememoed_2eiapp_lam1(V self, V *args) {
  V v_f_246 = args[0];
  V v_g1_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2evalue_2eapp(v_f_246, heff_clo(g_heff_2ememoed_2eiapp_lam2, 1, 1, (V[]){v_g1_242})));
}
V g_heff_2ememoed_2eiapp_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_g1_242 = heff_env(self)[0];
  V v_g0_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_245);
  V v_f_2412 = heff_clo(g_heff_2ememoed_2eiapp_lam1, 1, 1, (V[]){v_g1_242});
  V v_x2_2413 = heff_tr(heff_apply(heff_get(v_g0_241, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nom: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    heff_take_n(v_x2_2413, 1ULL, 1);
    V f_ = v_f_2412;
    args[0] = v_x_2414;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Describe: {
    V v_x_2415 = heff_field(v_x2_2413, 0);
    heff_take_n(v_x2_2413, 1ULL, 1);
    V f_ = v_f_2412;
    args[0] = v_x_2415;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Become: {
    V v_x_2416 = heff_field(v_x2_2413, 0);
    V v_ru_24x2_2413_24Become = heff_take_reuse_n(v_x2_2413, 1ULL, 1);
    V v_x1_2417 = heff_tr(heff_apply(v_f_2412, 1, (V[]){v_x_2416}));
    V v_t_2421;
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Nom: {
      V v_x_2418 = heff_field(v_x1_2417, 0);
      heff_take_n(v_x1_2417, 1ULL, 1);
      v_t_2421 = v_x_2418;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2417, 0ULL, 1);
      v_t_2421 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2420 = heff_field(v_x1_2417, 0);
      heff_take_n(v_x1_2417, 1ULL, 1);
      v_t_2421 = v_x_2420;
      break;
    }
    default: heff_nomatch(v_x1_2417);
    }
    return heff_tag_at(v_ru_24x2_2413_24Become, TAG_Become, 1, (V[]){v_t_2421});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ememoed_2elam_lam1(V self, V *args);
V g_heff_2ememoed_2elam_lam2(V self, V *args);
V g_heff_2ememoed_2elam_lam0(V self, V *args);
V g_heff_2ememoed_2elam_lam4(V self, V *args);
V g_heff_2ememoed_2elam_lam3(V self, V *args);
Clo g_heff_2ememoed_2elam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2elam_entry, 5, 0};

V g_heff_2ememoed_2elam(V v_c_240, V v_g_241, V v_vs_242, V v_gdom_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkAbs: {
    V v_x_245 = heff_field(v_x5_244, 0);
    V v_gbody_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24MkAbs = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_247 = heff_tag_at(v_ru_24x5_244_24MkAbs, TAG_MkAbs, 2, (V[]){heff_dup(v_x_245), heff_get(heff_dup(v_gbody_246), LBL_stx)});
    V v_t_248 = heff_tag(TAG_SLam, 2, (V[]){heff_get(heff_dup(v_gdom_243), LBL_stx), v_t_247});
    return heff_rec(2, shape_stx__val, (V[]){v_t_248, heff_clo(g_heff_2ememoed_2elam_lam0, 1, 6, (V[]){v_gdom_243, v_x_245, v_vs_242, v_g_241, v_c_240, v_gbody_246})});
  }
  case TAG_AbsConst: {
    V v_gbody_2417 = heff_field(v_x5_244, 0);
    V v_ru_24x5_244_24AbsConst = heff_take_reuse_n(v_x5_244, 1ULL, 1);
    heff_drop(v_g_241);
    heff_drop(v_vs_242);
    V v_t_2418 = heff_tag_at(v_ru_24x5_244_24AbsConst, TAG_AbsConst, 1, (V[]){heff_get(heff_dup(v_gbody_2417), LBL_stx)});
    V v_t_2419 = heff_tag(TAG_SLam, 2, (V[]){heff_get(heff_dup(v_gdom_243), LBL_stx), v_t_2418});
    return heff_rec(2, shape_stx__val, (V[]){v_t_2419, heff_clo(g_heff_2ememoed_2elam_lam3, 1, 3, (V[]){v_gbody_2417, v_gdom_243, v_c_240})});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ememoed_2elam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2elam(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ememoed_2elam_lam1(V self, V *args) {
  V v_u2_2410 = args[0];
  V v_gdom_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_2410);
  V v_x1_2411 = heff_tr(heff_apply(heff_get(v_gdom_243, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    return v_x_2412;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    return v_x_2414;
  }
  default: return heff_nomatch(v_x1_2411);
  }
}
V g_heff_2ememoed_2elam_lam2(V self, V *args) {
  V v_vs2_2415 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_gbody_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eeval_2eevalTermF(heff_dup(g_heff_2eeval_2eevaluator_get()), v_g_241, v_c_240, heff_get(v_gbody_246, LBL_stx), v_vs2_2415));
}
V g_heff_2ememoed_2elam_lam0(V self, V *args) {
  V v_u_249 = args[0];
  V v_gdom_243 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  V v_c_240 = heff_env(self)[4];
  V v_gbody_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_u_249);
  V v_x_2416 = heff_tag(TAG_VLam, 2, (V[]){heff_clo(g_heff_2ememoed_2elam_lam1, 1, 1, (V[]){v_gdom_243}), heff_tag(TAG_MkClo, 3, (V[]){v_x_245, v_vs_242, heff_clo(g_heff_2ememoed_2elam_lam2, 1, 3, (V[]){v_g_241, heff_dup(v_c_240), v_gbody_246})})});
  switch (heff_tag_of(v_c_240)) {
  case TAG_N: {
    return heff_tag(TAG_Nom, 1, (V[]){v_x_2416});
  }
  case TAG_De: {
    return heff_tag(TAG_Describe, 1, (V[]){v_x_2416});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2ememoed_2elam_lam4(V self, V *args) {
  V v_u2_2422 = args[0];
  V v_gdom_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_2422);
  V v_x1_2423 = heff_tr(heff_apply(heff_get(v_gdom_243, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2423)) {
  case TAG_Nom: {
    V v_x_2424 = heff_field(v_x1_2423, 0);
    heff_take_n(v_x1_2423, 1ULL, 1);
    return v_x_2424;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2423, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2426 = heff_field(v_x1_2423, 0);
    heff_take_n(v_x1_2423, 1ULL, 1);
    return v_x_2426;
  }
  default: return heff_nomatch(v_x1_2423);
  }
}
V g_heff_2ememoed_2elam_lam3(V self, V *args) {
  V v_u_2420 = args[0];
  V v_gbody_2417 = heff_env(self)[0];
  V v_gdom_243 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2420);
  V v_t_2421 = heff_tr(heff_apply(heff_get(v_gbody_2417, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x_2427 = heff_tag(TAG_VLam, 2, (V[]){heff_clo(g_heff_2ememoed_2elam_lam4, 1, 1, (V[]){v_gdom_243}), heff_tag(TAG_CloConst, 1, (V[]){v_t_2421})});
  switch (heff_tag_of(v_c_240)) {
  case TAG_N: {
    return heff_tag(TAG_Nom, 1, (V[]){v_x_2427});
  }
  case TAG_De: {
    return heff_tag(TAG_Describe, 1, (V[]){v_x_2427});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2ememoed_2econs_lam0(V self, V *args);
V g_heff_2ememoed_2econs_lam2(V self, V *args);
V g_heff_2ememoed_2econs_lam1(V self, V *args);
Clo g_heff_2ememoed_2econs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2econs_entry, 2, 0};

V g_heff_2ememoed_2econs(V v_c_240, V v_d_241) {
top: ;
  V v_xs_242 = heff_get(heff_dup(v_d_241), LBL_values);
  V v_t_245 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_242)), heff_clo(g_heff_2ememoed_2econs_lam0, 1, 1, (V[]){v_xs_242}));
  V v_t_246 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_d_241), LBL_keys), heff_get(heff_dup(v_d_241), LBL_byName), v_t_245});
  return heff_rec(2, shape_stx__val, (V[]){heff_tag(TAG_SCons, 1, (V[]){v_t_246}), heff_clo(g_heff_2ememoed_2econs_lam1, 1, 2, (V[]){v_d_241, heff_dup(v_c_240)})});
}
V g_heff_2ememoed_2econs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ememoed_2econs(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ememoed_2econs_lam0(V self, V *args) {
  V v_i_243 = args[0];
  V v_xs_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_244 = heff_arrayIndex(v_xs_242, v_i_243);
  return heff_get(v_m_244, LBL_stx);
}
V g_heff_2ememoed_2econs_lam2(V self, V *args) {
  V v_i_249 = args[0];
  V v_xs_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2410 = heff_arrayIndex(v_xs_248, v_i_249);
  V f_ = heff_get(v_m_2410, LBL_val);
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ememoed_2econs_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_d_241 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_247);
  V v_xs_248 = heff_get(heff_dup(v_d_241), LBL_values);
  V v_t_2411 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_248)), heff_clo(g_heff_2ememoed_2econs_lam2, 1, 1, (V[]){v_xs_248}));
  V v_t_2412 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_d_241), LBL_keys), heff_get(v_d_241, LBL_byName), v_t_2411});
  V v_x_2413 = heff_tag(TAG_VCons, 1, (V[]){v_t_2412});
  switch (heff_tag_of(v_c_240)) {
  case TAG_N: {
    return heff_tag(TAG_Nom, 1, (V[]){v_x_2413});
  }
  case TAG_De: {
    return heff_tag(TAG_Describe, 1, (V[]){v_x_2413});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2ememoed_2eproj_lam0(V self, V *args);
Clo g_heff_2ememoed_2eproj_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2eproj_entry, 2, 0};

V g_heff_2ememoed_2eproj(V v_g_240, V v_x_241) {
top: ;
  V v_t_242 = heff_tag(TAG_SProj, 2, (V[]){heff_get(heff_dup(v_g_240), LBL_stx), heff_dup(v_x_241)});
  return heff_rec(2, shape_stx__val, (V[]){v_t_242, heff_clo(g_heff_2ememoed_2eproj_lam0, 1, 2, (V[]){v_g_240, v_x_241})});
}
V g_heff_2ememoed_2eproj_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2eproj(a[0], a[1]);
}
V g_heff_2ememoed_2eproj_lam0(V self, V *args) {
  V v_u_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_243);
  V v_x2_244 = heff_tr(heff_apply(heff_get(v_g_240, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nom: {
    V v_x_245 = heff_field(v_x2_244, 0);
    heff_take_n(v_x2_244, 1ULL, 1);
    return (g_heff_2evalue_2eproj(v_x_245, v_x_241));
  }
  case TAG_Describe: {
    V v_x_246 = heff_field(v_x2_244, 0);
    heff_take_n(v_x2_244, 1ULL, 1);
    return (g_heff_2evalue_2eproj(v_x_246, v_x_241));
  }
  case TAG_Become: {
    V v_x_247 = heff_field(v_x2_244, 0);
    V v_ru_24x2_244_24Become = heff_take_reuse_n(v_x2_244, 1ULL, 1);
    V v_x1_248 = (g_heff_2evalue_2eproj(v_x_247, v_x_241));
    V v_t_2412;
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Nom: {
      V v_x_249 = heff_field(v_x1_248, 0);
      heff_take_n(v_x1_248, 1ULL, 1);
      v_t_2412 = v_x_249;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_248, 0ULL, 1);
      v_t_2412 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2411 = heff_field(v_x1_248, 0);
      heff_take_n(v_x1_248, 1ULL, 1);
      v_t_2412 = v_x_2411;
      break;
    }
    default: heff_nomatch(v_x1_248);
    }
    return heff_tag_at(v_ru_24x2_244_24Become, TAG_Become, 1, (V[]){v_t_2412});
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ememoed_2eprojAt_lam0(V self, V *args);
Clo g_heff_2ememoed_2eprojAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2eprojAt_entry, 3, 0};

V g_heff_2ememoed_2eprojAt(V v_g_240, V v_x_241, V v_a_242) {
top: ;
  V v_t_243 = heff_tag(TAG_SProj, 2, (V[]){heff_get(heff_dup(v_g_240), LBL_stx), heff_dup(v_x_241)});
  return heff_rec(2, shape_stx__val, (V[]){v_t_243, heff_clo(g_heff_2ememoed_2eprojAt_lam0, 1, 3, (V[]){v_g_240, v_x_241, v_a_242})});
}
V g_heff_2ememoed_2eprojAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2eprojAt(a[0], a[1], a[2]);
}
V g_heff_2ememoed_2eprojAt_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_244);
  V v_x2_245 = heff_tr(heff_apply(heff_get(v_g_240, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nom: {
    V v_x_246 = heff_field(v_x2_245, 0);
    heff_take_n(v_x2_245, 1ULL, 1);
    return (g_heff_2evalue_2eprojAt(v_x_246, v_x_241, v_a_242));
  }
  case TAG_Describe: {
    V v_x_247 = heff_field(v_x2_245, 0);
    heff_take_n(v_x2_245, 1ULL, 1);
    return (g_heff_2evalue_2eprojAt(v_x_247, v_x_241, v_a_242));
  }
  case TAG_Become: {
    V v_x_248 = heff_field(v_x2_245, 0);
    V v_ru_24x2_245_24Become = heff_take_reuse_n(v_x2_245, 1ULL, 1);
    V v_x1_249 = (g_heff_2evalue_2eprojAt(v_x_248, v_x_241, v_a_242));
    V v_t_2413;
    switch (heff_tag_of(v_x1_249)) {
    case TAG_Nom: {
      V v_x_2410 = heff_field(v_x1_249, 0);
      heff_take_n(v_x1_249, 1ULL, 1);
      v_t_2413 = v_x_2410;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_249, 0ULL, 1);
      v_t_2413 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2412 = heff_field(v_x1_249, 0);
      heff_take_n(v_x1_249, 1ULL, 1);
      v_t_2413 = v_x_2412;
      break;
    }
    default: heff_nomatch(v_x1_249);
    }
    return heff_tag_at(v_ru_24x2_245_24Become, TAG_Become, 1, (V[]){v_t_2413});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ememoed_2especializeM_lam0(V self, V *args);
Clo g_heff_2ememoed_2especializeM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2especializeM_entry, 3, 0};

V g_heff_2ememoed_2especializeM(V v_g_240, V v_x_241, V v_g_27_242) {
top: ;
  V v_t_243 = heff_tag(TAG_SSpecialize, 3, (V[]){heff_get(heff_dup(v_g_240), LBL_stx), heff_dup(v_x_241), heff_get(heff_dup(v_g_27_242), LBL_stx)});
  return heff_rec(2, shape_stx__val, (V[]){v_t_243, heff_clo(g_heff_2ememoed_2especializeM_lam0, 1, 3, (V[]){v_g_240, v_g_27_242, v_x_241})});
}
V g_heff_2ememoed_2especializeM_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2especializeM(a[0], a[1], a[2]);
}
V g_heff_2ememoed_2especializeM_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_g_27_242 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_244);
  V v_x1_245 = heff_tr(heff_apply(heff_get(v_g_240, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_249;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Nom: {
    V v_x_246 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 1);
    v_t_249 = v_x_246;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_245, 0ULL, 1);
    v_t_249 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_248 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 1);
    v_t_249 = v_x_248;
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  V v_x1_2410 = heff_tr(heff_apply(heff_get(v_g_27_242, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2414;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nom: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2411;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2410, 0ULL, 1);
    v_t_2414 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2413 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2especialize(v_t_249, v_x_241, v_t_2414))});
}
V g_heff_2ememoed_2eabandonM_lam0(V self, V *args); static Clo g_heff_2ememoed_2eabandonM_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2eabandonM_lam0, 1, 0};

static V g_heff_2ememoed_2eabandonM_val;
static int g_heff_2ememoed_2eabandonM_st;
static V g_heff_2ememoed_2eabandonM_init(void) {
  return heff_rec(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), ((V)&g_heff_2ememoed_2eabandonM_lam0_clo)});
}
V g_heff_2ememoed_2eabandonM_get(void) {
  if (g_heff_2ememoed_2eabandonM_st == 2) return g_heff_2ememoed_2eabandonM_val;
  if (g_heff_2ememoed_2eabandonM_st == 1) heff_fail("defined by itself");
  g_heff_2ememoed_2eabandonM_st = 1;
  g_heff_2ememoed_2eabandonM_val = heff_tr(g_heff_2ememoed_2eabandonM_init());
  g_heff_2ememoed_2eabandonM_st = 2;
  return g_heff_2ememoed_2eabandonM_val;
}
V g_heff_2ememoed_2eabandonM_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(v_u_240);
  return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2ememoed_2edecode_lam0(V self, V *args);
Clo g_heff_2ememoed_2edecode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2edecode_entry, 1, 0};

V g_heff_2ememoed_2edecode(V v_g_240) {
top: ;
  V v_t_241 = heff_tag(TAG_SDecode, 1, (V[]){heff_get(heff_dup(v_g_240), LBL_stx)});
  return heff_rec(2, shape_stx__val, (V[]){v_t_241, heff_clo(g_heff_2ememoed_2edecode_lam0, 1, 1, (V[]){v_g_240})});
}
V g_heff_2ememoed_2edecode_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2edecode(a[0]);
}
V g_heff_2ememoed_2edecode_lam0(V self, V *args) {
  V v_u_242 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_242);
  V v_x1_243 = heff_tr(heff_apply(heff_get(v_g_240, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nom: {
    V v_x_244 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24Nom = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    return heff_tag_at(v_ru_24x1_243_24Nom, TAG_Nom, 1, (V[]){({ V a_0 = v_x_244; V r_ = (g_heff_2evalue_2edecodeN(a_0)); heff_drop(v_x_244); r_; })});
  }
  case TAG_Describe: {
    V v_x_245 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24Describe = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    switch (heff_tag_of(v_x_245)) {
    case TAG_VNeu: {
      heff_take_n(v_x_245, 0ULL, 5);
      heff_drop_cell(v_ru_24x1_243_24Describe, 1);
      return heff_abandon();
    }
    case TAG_VCode: {
      V v_a_2411 = heff_field(v_x_245, 0);
      heff_take_n(v_x_245, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_243_24Describe, TAG_Describe, 1, (V[]){v_a_2411});
    }
    case TAG_VLam: {
      heff_take_n(v_x_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_243_24Describe, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_x_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_243_24Describe, 1);
      return heff_abandon();
    }
    case TAG_VOpaque: {
      heff_drop_cell(v_ru_24x1_243_24Describe, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_x_245);
    }
  }
  case TAG_Become: {
    V v_x_2415 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24Become = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    return heff_tag_at(v_ru_24x1_243_24Become, TAG_Become, 1, (V[]){({ V a_0 = v_x_2415; V r_ = (g_heff_2evalue_2edecodeN(a_0)); heff_drop(v_x_2415); r_; })});
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2ememoed_2efunctionD_lam1(V self, V *args);
V g_heff_2ememoed_2efunctionD_lam0(V self, V *args);
V g_heff_2ememoed_2efunctionD_lam2(V self, V *args);
Clo g_heff_2ememoed_2efunctionD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2efunctionD_entry, 6, 0};

V g_heff_2ememoed_2efunctionD(V v_implicit_240, V v_dflt_241, V v_g_242, V v_vs_243, V v_dom_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_MkAbs: {
    V v_x_246 = heff_field(v_x6_245, 0);
    V v_body_247 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24MkAbs = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    V v_x1_248 = heff_tr(heff_apply(heff_get(heff_dup(v_body_247), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2412;
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Nom: {
      V v_t_249 = heff_field(v_x1_248, 0);
      heff_take_n(v_x1_248, 1ULL, 1);
      v_t_2412 = ({ V a_0 = v_t_249; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_249); r_; });
      break;
    }
    case TAG_Describe: {
      V v_t_2410 = heff_field(v_x1_248, 0);
      heff_take_n(v_x1_248, 1ULL, 1);
      v_t_2412 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2410); r_; });
      break;
    }
    case TAG_Become: {
      V v_t_2411 = heff_field(v_x1_248, 0);
      heff_take_n(v_x1_248, 1ULL, 1);
      v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2411); r_; });
      break;
    }
    default: heff_nomatch(v_x1_248);
    }
    V v_t_2413 = heff_tag_at(v_ru_24x6_245_24MkAbs, TAG_MkAbs, 2, (V[]){heff_dup(v_x_246), heff_get(heff_dup(v_body_247), LBL_stx)});
    V v_t_2414 = heff_tag(TAG_SFunction, 5, (V[]){v_t_2412, heff_get(heff_dup(v_dom_244), LBL_stx), v_t_2413, heff_dup(v_implicit_240), heff_dup(v_dflt_241)});
    return heff_rec(2, shape_stx__val, (V[]){v_t_2414, heff_clo(g_heff_2ememoed_2efunctionD_lam0, 1, 7, (V[]){v_body_247, v_dom_244, v_x_246, v_vs_243, v_g_242, v_implicit_240, v_dflt_241})});
  }
  case TAG_AbsConst: {
    V v_body_2428 = heff_field(v_x6_245, 0);
    V v_ru_24x6_245_24AbsConst = heff_take_reuse_n(v_x6_245, 1ULL, 1);
    heff_drop(v_g_242);
    heff_drop(v_vs_243);
    V v_x1_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_body_2428), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2433;
    switch (heff_tag_of(v_x1_2429)) {
    case TAG_Nom: {
      V v_t_2430 = heff_field(v_x1_2429, 0);
      heff_take_n(v_x1_2429, 1ULL, 1);
      v_t_2433 = ({ V a_0 = v_t_2430; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2430); r_; });
      break;
    }
    case TAG_Describe: {
      V v_t_2431 = heff_field(v_x1_2429, 0);
      heff_take_n(v_x1_2429, 1ULL, 1);
      v_t_2433 = ({ V a_0 = v_t_2431; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2431); r_; });
      break;
    }
    case TAG_Become: {
      V v_t_2432 = heff_field(v_x1_2429, 0);
      heff_take_n(v_x1_2429, 1ULL, 1);
      v_t_2433 = ({ V a_0 = v_t_2432; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2432); r_; });
      break;
    }
    default: heff_nomatch(v_x1_2429);
    }
    V v_t_2434 = heff_tag_at(v_ru_24x6_245_24AbsConst, TAG_AbsConst, 1, (V[]){heff_get(heff_dup(v_body_2428), LBL_stx)});
    V v_t_2435 = heff_tag(TAG_SFunction, 5, (V[]){v_t_2433, heff_get(heff_dup(v_dom_244), LBL_stx), v_t_2434, heff_dup(v_implicit_240), heff_dup(v_dflt_241)});
    return heff_rec(2, shape_stx__val, (V[]){v_t_2435, heff_clo(g_heff_2ememoed_2efunctionD_lam2, 1, 4, (V[]){v_body_2428, v_dom_244, v_implicit_240, v_dflt_241})});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ememoed_2efunctionD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2efunctionD(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ememoed_2efunctionD_lam1(V self, V *args) {
  V v_vs2_2426 = args[0];
  V v_g_242 = heff_env(self)[0];
  V v_body_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(v_g_242, NTAG(TAG_N), heff_get(v_body_247, LBL_stx), v_vs2_2426));
}
V g_heff_2ememoed_2efunctionD_lam0(V self, V *args) {
  V v_u_2415 = args[0];
  V v_body_247 = heff_env(self)[0];
  V v_dom_244 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_vs_243 = heff_env(self)[3];
  V v_g_242 = heff_env(self)[4];
  V v_implicit_240 = heff_env(self)[5];
  V v_dflt_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_u_2415);
  V v_x1_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_body_247), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2420;
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_Nom: {
    V v_t_2417 = heff_field(v_x1_2416, 0);
    heff_take_n(v_x1_2416, 1ULL, 1);
    v_t_2420 = ({ V a_0 = v_t_2417; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2417); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2418 = heff_field(v_x1_2416, 0);
    heff_take_n(v_x1_2416, 1ULL, 1);
    v_t_2420 = ({ V a_0 = v_t_2418; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2418); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2419 = heff_field(v_x1_2416, 0);
    heff_take_n(v_x1_2416, 1ULL, 1);
    v_t_2420 = ({ V a_0 = v_t_2419; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2419); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2416);
  }
  V v_x1_2421 = heff_tr(heff_apply(heff_get(v_dom_244, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2425;
  switch (heff_tag_of(v_x1_2421)) {
  case TAG_Nom: {
    V v_x_2422 = heff_field(v_x1_2421, 0);
    heff_take_n(v_x1_2421, 1ULL, 1);
    v_t_2425 = v_x_2422;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2421, 0ULL, 1);
    v_t_2425 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2424 = heff_field(v_x1_2421, 0);
    heff_take_n(v_x1_2421, 1ULL, 1);
    v_t_2425 = v_x_2424;
    break;
  }
  default: heff_nomatch(v_x1_2421);
  }
  V v_t_2427 = heff_tag(TAG_VFunction, 5, (V[]){v_t_2420, v_t_2425, heff_tag(TAG_MkClo, 3, (V[]){v_x_246, v_vs_243, heff_clo(g_heff_2ememoed_2efunctionD_lam1, 1, 2, (V[]){v_g_242, v_body_247})}), v_implicit_240, v_dflt_241});
  return heff_tag(TAG_Nom, 1, (V[]){v_t_2427});
}
V g_heff_2ememoed_2efunctionD_lam2(V self, V *args) {
  V v_u_2436 = args[0];
  V v_body_2428 = heff_env(self)[0];
  V v_dom_244 = heff_env(self)[1];
  V v_implicit_240 = heff_env(self)[2];
  V v_dflt_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2436);
  V v_x1_2437 = heff_tr(heff_apply(heff_get(heff_dup(v_body_2428), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2441;
  switch (heff_tag_of(v_x1_2437)) {
  case TAG_Nom: {
    V v_t_2438 = heff_field(v_x1_2437, 0);
    heff_take_n(v_x1_2437, 1ULL, 1);
    v_t_2441 = ({ V a_0 = v_t_2438; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2438); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2439 = heff_field(v_x1_2437, 0);
    heff_take_n(v_x1_2437, 1ULL, 1);
    v_t_2441 = ({ V a_0 = v_t_2439; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2439); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2440 = heff_field(v_x1_2437, 0);
    heff_take_n(v_x1_2437, 1ULL, 1);
    v_t_2441 = ({ V a_0 = v_t_2440; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2440); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2437);
  }
  V v_x1_2442 = heff_tr(heff_apply(heff_get(v_dom_244, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2446;
  switch (heff_tag_of(v_x1_2442)) {
  case TAG_Nom: {
    V v_x_2443 = heff_field(v_x1_2442, 0);
    heff_take_n(v_x1_2442, 1ULL, 1);
    v_t_2446 = v_x_2443;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2442, 0ULL, 1);
    v_t_2446 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2445 = heff_field(v_x1_2442, 0);
    heff_take_n(v_x1_2442, 1ULL, 1);
    v_t_2446 = v_x_2445;
    break;
  }
  default: heff_nomatch(v_x1_2442);
  }
  V v_t_2447 = heff_tr(heff_apply(heff_get(v_body_2428, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2448 = heff_tag(TAG_VFunction, 5, (V[]){v_t_2441, v_t_2446, heff_tag(TAG_CloConst, 1, (V[]){v_t_2447}), v_implicit_240, v_dflt_241});
  return heff_tag(TAG_Nom, 1, (V[]){v_t_2448});
}
V g_heff_2ememoed_2erecordM_lam2(V self, V *args);
V g_heff_2ememoed_2erecordM_lam1(V self, V *args);
V g_heff_2ememoed_2erecordM_lam0(V self, V *args);
Clo g_heff_2ememoed_2erecordM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2erecordM_entry, 5, 0};

V g_heff_2ememoed_2erecordM(V v_g_240, V v_vs_241, V v_level_242, V v_fieldTypes_243, V v_defaults_244) {
top: ;
  return heff_rec(2, shape_stx__val, (V[]){heff_tag(TAG_SRecord, 3, (V[]){heff_dup(v_level_242), heff_dup(v_fieldTypes_243), heff_dup(v_defaults_244)}), heff_clo(g_heff_2ememoed_2erecordM_lam0, 1, 5, (V[]){v_fieldTypes_243, v_g_240, v_level_242, v_vs_241, v_defaults_244})});
}
V g_heff_2ememoed_2erecordM_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2erecordM(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ememoed_2erecordM_lam2(V self, V *args) {
  V v_vs2_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2410 = (g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(v_g_240, NTAG(TAG_N), v_t_248, v_vs2_249));
  V v_t_2414;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nom: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2411;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2410, 0ULL, 1);
    v_t_2414 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2413 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  return heff_tag(TAG_MkField, 2, (V[]){v_t_2414, NTAG(TAG_Nothing)});
}
V g_heff_2ememoed_2erecordM_lam1(V self, V *args) {
  V v_i_247 = args[0];
  V v_xs_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_arrayIndex(v_xs_246, v_i_247);
  return heff_clo(g_heff_2ememoed_2erecordM_lam2, 1, 2, (V[]){v_g_240, v_t_248});
}
V g_heff_2ememoed_2erecordM_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_fieldTypes_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_level_242 = heff_env(self)[2];
  V v_vs_241 = heff_env(self)[3];
  V v_defaults_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_245);
  V v_xs_246 = heff_get(heff_dup(v_fieldTypes_243), LBL_values);
  V v_t_2415 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_246)), heff_clo(g_heff_2ememoed_2erecordM_lam1, 1, 2, (V[]){v_xs_246, v_g_240}));
  V v_t_2416 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_fieldTypes_243), LBL_keys), heff_get(v_fieldTypes_243, LBL_byName), v_t_2415});
  return heff_tag(TAG_Describe, 1, (V[]){heff_tag(TAG_VRecord, 4, (V[]){v_level_242, v_vs_241, v_t_2416, v_defaults_244})});
}
V g_heff_2ememoed_2esumM_lam1(V self, V *args);
V g_heff_2ememoed_2esumM_lam0(V self, V *args);
V g_heff_2ememoed_2esumM_lam2(V self, V *args);
Clo g_heff_2ememoed_2esumM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2esumM_entry, 1, 0};

V g_heff_2ememoed_2esumM(V v_st_240) {
top: ;
  V v_xs_241 = heff_get(heff_dup(v_st_240), LBL_values);
  V v_t_246 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_241)), heff_clo(g_heff_2ememoed_2esumM_lam0, 1, 1, (V[]){v_xs_241}));
  V v_t_247 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_st_240), LBL_keys), heff_get(heff_dup(v_st_240), LBL_byName), v_t_246});
  return heff_rec(2, shape_stx__val, (V[]){heff_tag(TAG_SSum, 1, (V[]){v_t_247}), heff_clo(g_heff_2ememoed_2esumM_lam2, 1, 1, (V[]){v_st_240})});
}
V g_heff_2ememoed_2esumM_entry(V self, V *a) {
  (void)self;
  return g_heff_2ememoed_2esumM(a[0]);
}
V g_heff_2ememoed_2esumM_lam1(V self, V *args) {
  V v_i_244 = args[0];
  V v_xs_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_245 = heff_arrayIndex(v_xs_243, v_i_244);
  return heff_get(v_m_245, LBL_stx);
}
V g_heff_2ememoed_2esumM_lam0(V self, V *args) {
  V v_i_242 = args[0];
  V v_xs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_243 = heff_arrayIndex(v_xs_241, v_i_242);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_243)), heff_clo(g_heff_2ememoed_2esumM_lam1, 1, 1, (V[]){v_xs_243}));
}
V g_heff_2ememoed_2esumM_lam2(V self, V *args) {
  V v_u_248 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  V v_t_249 = heff_tag(TAG_VSum, 1, (V[]){(g_heff_2eparams_2evariantsMap_24s2065256000x17303345(v_st_240))});
  return heff_tag(TAG_Describe, 1, (V[]){v_t_249});
}
V g_heff_2ememoed_2eprimInt_lam0(V self, V *args); static Clo g_heff_2ememoed_2eprimInt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2eprimInt_lam0, 1, 0};

static V g_heff_2ememoed_2eprimInt_val;
static int g_heff_2ememoed_2eprimInt_st;
static V g_heff_2ememoed_2eprimInt_init(void) {
  return heff_rec(2, shape_stx__val, (V[]){NTAG(TAG_SPrimInt), ((V)&g_heff_2ememoed_2eprimInt_lam0_clo)});
}
V g_heff_2ememoed_2eprimInt_get(void) {
  if (g_heff_2ememoed_2eprimInt_st == 2) return g_heff_2ememoed_2eprimInt_val;
  if (g_heff_2ememoed_2eprimInt_st == 1) heff_fail("defined by itself");
  g_heff_2ememoed_2eprimInt_st = 1;
  g_heff_2ememoed_2eprimInt_val = heff_tr(g_heff_2ememoed_2eprimInt_init());
  g_heff_2ememoed_2eprimInt_st = 2;
  return g_heff_2ememoed_2eprimInt_val;
}
V g_heff_2ememoed_2eprimInt_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(v_u_240);
  return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimInt)});
}
V g_heff_2ememoed_2eprimFloat_lam0(V self, V *args); static Clo g_heff_2ememoed_2eprimFloat_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2eprimFloat_lam0, 1, 0};

static V g_heff_2ememoed_2eprimFloat_val;
static int g_heff_2ememoed_2eprimFloat_st;
static V g_heff_2ememoed_2eprimFloat_init(void) {
  return heff_rec(2, shape_stx__val, (V[]){NTAG(TAG_SPrimFloat), ((V)&g_heff_2ememoed_2eprimFloat_lam0_clo)});
}
V g_heff_2ememoed_2eprimFloat_get(void) {
  if (g_heff_2ememoed_2eprimFloat_st == 2) return g_heff_2ememoed_2eprimFloat_val;
  if (g_heff_2ememoed_2eprimFloat_st == 1) heff_fail("defined by itself");
  g_heff_2ememoed_2eprimFloat_st = 1;
  g_heff_2ememoed_2eprimFloat_val = heff_tr(g_heff_2ememoed_2eprimFloat_init());
  g_heff_2ememoed_2eprimFloat_st = 2;
  return g_heff_2ememoed_2eprimFloat_val;
}
V g_heff_2ememoed_2eprimFloat_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(v_u_240);
  return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimFloat)});
}
V g_heff_2ememoed_2eprimString_lam0(V self, V *args); static Clo g_heff_2ememoed_2eprimString_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2eprimString_lam0, 1, 0};

static V g_heff_2ememoed_2eprimString_val;
static int g_heff_2ememoed_2eprimString_st;
static V g_heff_2ememoed_2eprimString_init(void) {
  return heff_rec(2, shape_stx__val, (V[]){NTAG(TAG_SPrimString), ((V)&g_heff_2ememoed_2eprimString_lam0_clo)});
}
V g_heff_2ememoed_2eprimString_get(void) {
  if (g_heff_2ememoed_2eprimString_st == 2) return g_heff_2ememoed_2eprimString_val;
  if (g_heff_2ememoed_2eprimString_st == 1) heff_fail("defined by itself");
  g_heff_2ememoed_2eprimString_st = 1;
  g_heff_2ememoed_2eprimString_val = heff_tr(g_heff_2ememoed_2eprimString_init());
  g_heff_2ememoed_2eprimString_st = 2;
  return g_heff_2ememoed_2eprimString_val;
}
V g_heff_2ememoed_2eprimString_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(v_u_240);
  return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimString)});
}
V g_heff_2ememoed_2eprimRune_lam0(V self, V *args); static Clo g_heff_2ememoed_2eprimRune_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ememoed_2eprimRune_lam0, 1, 0};

static V g_heff_2ememoed_2eprimRune_val;
static int g_heff_2ememoed_2eprimRune_st;
static V g_heff_2ememoed_2eprimRune_init(void) {
  return heff_rec(2, shape_stx__val, (V[]){NTAG(TAG_SPrimRune), ((V)&g_heff_2ememoed_2eprimRune_lam0_clo)});
}
V g_heff_2ememoed_2eprimRune_get(void) {
  if (g_heff_2ememoed_2eprimRune_st == 2) return g_heff_2ememoed_2eprimRune_val;
  if (g_heff_2ememoed_2eprimRune_st == 1) heff_fail("defined by itself");
  g_heff_2ememoed_2eprimRune_st = 1;
  g_heff_2ememoed_2eprimRune_val = heff_tr(g_heff_2ememoed_2eprimRune_init());
  g_heff_2ememoed_2eprimRune_st = 2;
  return g_heff_2ememoed_2eprimRune_val;
}
V g_heff_2ememoed_2eprimRune_lam0(V self, V *args) {
  V v_u_240 = args[0];
  heff_drop(v_u_240);
  return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimRune)});
}