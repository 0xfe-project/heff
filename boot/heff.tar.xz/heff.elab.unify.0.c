// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Get 18914
#define TAG_HLocal 25864
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkClo 57090
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define LBL_arity 294440695
#define LBL_bind 9519364
#define LBL_el 9998
#define LBL_infos 301706655
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_selfKey 62480824
#define LBL_sol 323594
#define LBL_solStx 1050338738
#define LBL_span 10032145
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_ubare 312426689
#define LBL_uel 325206
#define LBL_uty 325684
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_ty__sol__solStx__arity__name__span[] = {LBL_ty, LBL_sol, LBL_solStx, LBL_arity, LBL_name, LBL_span};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_heff_2eelab_2eunify_2ecatMaybes(V);
V g_heff_2eelab_2eunify_2ecatMaybes_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ecatMaybes_clo;
V g_heff_2eelab_2eunify_2ecatMaybes_24dps(V, V);
V g_heff_2eelab_2eunify_2ecatMaybes_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ecatMaybes_24dps_clo;
V g_heff_2eelab_2eunify_2eforU(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2eforU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eforU_clo;
V g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179(V, V, V, V, V);
V g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_clo;
V g_heff_2eelab_2eunify_2enewMetaIn(V, V, V, V);
V g_heff_2eelab_2eunify_2enewMetaIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enewMetaIn_clo;
V g_heff_2eelab_2eunify_2espineRev(V);
V g_heff_2eelab_2eunify_2espineRev_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2espineRev_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102(V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102_clo;
V g_heff_2eelab_2eunify_2esubstOf(V);
V g_heff_2eelab_2eunify_2esubstOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstOf_clo;
V g_heff_2eelab_2eunify_2esubstTermF(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTermF_clo;
V g_heff_2eelab_2eunify_2esubstTypeF(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTypeF_clo;
V g_heff_2eelab_2eunify_2euAlg(V, V);
V g_heff_2eelab_2eunify_2euAlg_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euAlg_clo;
V g_heff_2eelab_2eunify_2euElRigid(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euElRigid_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euElRigid_clo;
V g_heff_2eelab_2eunify_2euH_get(void);
V g_heff_2eelab_2eunify_2ezipL(V, V);
V g_heff_2eelab_2eunify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezipL_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
Clo g_heff_2eelab_2eunify_2ecatMaybes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ecatMaybes_entry, 1, 0};

V g_heff_2eelab_2eunify_2ecatMaybes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2eelab_2eunify_2ecatMaybes_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2ecatMaybes_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2ecatMaybes(a[0]);
}
V g_heff_2eelab_2eunify_2esubstOf_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2esubstOf_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2esubstOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstOf_entry, 1, 0};

V g_heff_2eelab_2eunify_2esubstOf(V v_idxs_240) {
top: ;
  return heff_rec_n(2, shape_el__ty, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2esubstOf_lam0, 2, 1, (V[]){heff_dup(v_idxs_240)}), heff_clo_n(g_heff_2eelab_2eunify_2esubstOf_lam1, 2, 1, (V[]){v_idxs_240})});
}
V g_heff_2eelab_2eunify_2esubstOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esubstOf(a[0]);
}
V g_heff_2eelab_2eunify_2esubstOf_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_t_242 = args[1];
  V v_idxs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2eelab_2eunify_2esubstOf(heff_dup(v_idxs_240)));
  return (g_heff_2eelab_2eunify_2esubstTermF(v_t_243, v_idxs_240, v_d_241, v_t_242));
}
V g_heff_2eelab_2eunify_2esubstOf_lam1(V self, V *args) {
  V v_d_244 = args[0];
  V v_t_245 = args[1];
  V v_idxs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_heff_2eelab_2eunify_2esubstOf(heff_dup(v_idxs_240)));
  return ({ V a_0 = v_t_246; V a_1 = v_idxs_240; V a_2 = v_d_244; V a_3 = v_t_245; V r_ = (g_heff_2eelab_2eunify_2esubstTypeF(a_0, a_1, a_2, a_3)); heff_drop(v_idxs_240); r_; });
}
HEFF_LIT(g_heff_2eelab_2eunify_2euElRigid_str0, 1, "x");
V g_heff_2eelab_2eunify_2euElRigid_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euElRigid_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2euElRigid_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euElRigid_lam3(V self, V *args);
Clo g_heff_2eelab_2eunify_2euElRigid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euElRigid_entry, 12, 0};

V g_heff_2eelab_2eunify_2euElRigid(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_x4_246, V v_cb_247, V v_a_248, V v_b_249, V v_z_2410, V v_z_2411) {
top: ;
  switch (heff_tag_of(v_x4_246)) {
  case TAG_VNeu: {
    V v_h_2412 = heff_field(v_x4_246, 0);
    V v_sp_2413 = heff_field(v_x4_246, 1);
    heff_take_n(v_x4_246, 3ULL, 5);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      V v_h_27_2417 = heff_field(v_cb_247, 0);
      V v_sp_27_2418 = heff_field(v_cb_247, 1);
      heff_take_n(v_cb_247, 3ULL, 5);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      return heff_tail(heff_get_n(v_r_243, 2, 9), 8, (V[]){v_g_244, v_cs_245, v_h_2412, v_sp_2413, v_h_27_2417, v_sp_27_2418, v_z_2410, v_z_2411});
    }
    case TAG_VCode: {
      V v_ru_24cb_247_24VCode = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_h_2412);
      heff_drop(v_sp_2413);
      V v_t_2423 = heff_tag_at_n(v_ru_24cb_247_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2424 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2423}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2424, v_z_2410, v_z_2411));
    }
    case TAG_VLam: {
      heff_take_n(v_cb_247, 0ULL, 2);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_h_2412);
      heff_drop(v_sp_2413);
      V v_t_2427 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2428 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2427}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2428, v_z_2410, v_z_2411));
    }
    case TAG_VCons: {
      V v_ru_24cb_247_24VCons = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_h_2412);
      heff_drop(v_sp_2413);
      V v_t_2430 = heff_tag_at_n(v_ru_24cb_247_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2431 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2430}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2431, v_z_2410, v_z_2411));
    }
    case TAG_VOpaque: {
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_h_2412);
      heff_drop(v_sp_2413);
      V v_t_2432 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2433 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2432}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2433, v_z_2410, v_z_2411));
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VCode: {
    V v_t_2434 = heff_field(v_x4_246, 0);
    V v_ru_24x4_246_24VCode = heff_take_reuse_n(v_x4_246, 1ULL, 1);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_247, 0ULL, 5);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_t_2434);
      V v_t_2440 = heff_tag_at_n(v_ru_24x4_246_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2441 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2440}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2441, v_z_2410, v_z_2411));
    }
    case TAG_VCode: {
      V v_t_27_2442 = heff_field(v_cb_247, 0);
      heff_take_n(v_cb_247, 1ULL, 1);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      heff_drop_cell(v_ru_24x4_246_24VCode, 1);
      return heff_tail(heff_get_n(v_r_243, 0, 9), 6, (V[]){v_g_244, v_cs_245, v_t_2434, v_t_27_2442, v_z_2410, v_z_2411});
    }
    case TAG_VLam: {
      heff_take_n(v_cb_247, 0ULL, 2);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_t_2434);
      V v_t_2445 = heff_tag_at_n(v_ru_24x4_246_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2446 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2445}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2446, v_z_2410, v_z_2411));
    }
    case TAG_VCons: {
      heff_take_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_t_2434);
      V v_t_2448 = heff_tag_at_n(v_ru_24x4_246_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2449 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2448}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2449, v_z_2410, v_z_2411));
    }
    case TAG_VOpaque: {
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_t_2434);
      V v_t_2450 = heff_tag_at_n(v_ru_24x4_246_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2451 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2450}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2451, v_z_2410, v_z_2411));
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VLam: {
    V v_d_2452 = heff_field(v_x4_246, 0);
    V v_c_2453 = heff_field(v_x4_246, 1);
    V v_ru_24x4_246_24VLam = heff_take_reuse_n(v_x4_246, 3ULL, 2);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_247, 0ULL, 5);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_d_2452);
      heff_drop(v_c_2453);
      heff_drop_cell(v_ru_24x4_246_24VLam, 2);
      V v_t_2459 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2460 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2459}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2460, v_z_2410, v_z_2411));
    }
    case TAG_VCode: {
      V v_ru_24cb_247_24VCode = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_d_2452);
      heff_drop(v_c_2453);
      heff_drop_cell(v_ru_24x4_246_24VLam, 2);
      V v_t_2462 = heff_tag_at_n(v_ru_24cb_247_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2463 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2462}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2463, v_z_2410, v_z_2411));
    }
    case TAG_VLam: {
      V v_c_27_2465 = heff_field(v_cb_247, 1);
      heff_take_n(v_cb_247, 2ULL, 2);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      V v_t_2466 = heff_tr(heff_call(v_d_2452, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_t_2467 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2466)));
      V v_a_2479;
      switch (heff_tag_of(v_t_2467)) {
      case TAG_LikeU: {
        heff_take_n(v_t_2467, 0ULL, 1);
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeFunction: {
        V v_dom_2470 = heff_field(v_t_2467, 1);
        heff_take_n(v_t_2467, 2ULL, 4);
        heff_drop(v_t_2466);
        v_a_2479 = v_dom_2470;
        break;
      }
      case TAG_LikeRecord: {
        heff_take_n(v_t_2467, 0ULL, 3);
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeSum: {
        heff_take_n(v_t_2467, 0ULL, 1);
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeInt: {
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeFloat: {
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeString: {
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeRune: {
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_2467, 0ULL, 1);
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeFixed: {
        heff_take_n(v_t_2467, 0ULL, 1);
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_NoRules: {
        v_a_2479 = v_t_2466;
        break;
      }
      default: heff_nomatch(v_t_2467);
      }
      V v_t_2480 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_cs_245, 0))});
      V v_v_2482 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2480, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_lam0, 1, 1, (V[]){v_a_2479}), NTAG(TAG_Nothing)));
      V v_t_2483 = heff_intAdd(heff_take_field(v_cs_245, 0), MK_INT(1LL));
      V v_t_2488;
      switch (heff_tag_of(v_c_2453)) {
      case TAG_MkClo: {
        V v_n_2484 = heff_dup(heff_field(v_c_2453, 0));
        v_t_2488 = v_n_2484;
        break;
      }
      case TAG_CloConst: {
        v_t_2488 = ((V)&g_heff_2eelab_2eunify_2euElRigid_str0);
        break;
      }
      default: heff_nomatch(v_c_2453);
      }
      V v_t_2489 = heff_tag_at_n(v_ru_24x4_246_24VLam, TAG_Cons, 2, (V[]){v_t_2488, heff_get_n(v_cs_245, 1, 2)});
      V v_x1_2495;
      switch (heff_tag_of(v_c_2453)) {
      case TAG_MkClo: {
        V v_vs_2491 = heff_field(v_c_2453, 1);
        V v_body_2492 = heff_field(v_c_2453, 2);
        heff_take_n(v_c_2453, 6ULL, 3);
        v_x1_2495 = heff_tr(heff_call(v_body_2492, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2491, heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_lam1, 1, 1, (V[]){heff_dup(v_v_2482)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2494 = heff_field(v_c_2453, 0);
        heff_take_n(v_c_2453, 1ULL, 1);
        v_x1_2495 = v_body_2494;
        break;
      }
      default: heff_nomatch(v_c_2453);
      }
      V v_t_2499;
      switch (heff_tag_of(v_x1_2495)) {
      case TAG_Nom: {
        V v_x_2496 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        v_t_2499 = v_x_2496;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2495, 0ULL, 1);
        v_t_2499 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2498 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        v_t_2499 = v_x_2498;
        break;
      }
      default: heff_nomatch(v_x1_2495);
      }
      V v_x1_24105;
      switch (heff_tag_of(v_c_27_2465)) {
      case TAG_MkClo: {
        V v_vs_24101 = heff_field(v_c_27_2465, 1);
        V v_body_24102 = heff_field(v_c_27_2465, 2);
        heff_take_n(v_c_27_2465, 6ULL, 3);
        v_x1_24105 = heff_tr(heff_call(v_body_24102, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_24101, heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_lam2, 1, 1, (V[]){v_v_2482})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_24104 = heff_field(v_c_27_2465, 0);
        heff_take_n(v_c_27_2465, 1ULL, 1);
        heff_drop(v_v_2482);
        v_x1_24105 = v_body_24104;
        break;
      }
      default: heff_nomatch(v_c_27_2465);
      }
      V v_t_24109;
      switch (heff_tag_of(v_x1_24105)) {
      case TAG_Nom: {
        V v_x_24106 = heff_field(v_x1_24105, 0);
        heff_take_n(v_x1_24105, 1ULL, 1);
        v_t_24109 = v_x_24106;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_24105, 0ULL, 1);
        v_t_24109 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24108 = heff_field(v_x1_24105, 0);
        heff_take_n(v_x1_24105, 1ULL, 1);
        v_t_24109 = v_x_24108;
        break;
      }
      default: heff_nomatch(v_x1_24105);
      }
      return heff_tail(heff_get_n(v_r_243, 1, 9), 6, (V[]){v_g_244, heff_rec_n(2, shape_len__names, (V[]){v_t_2483, v_t_2489}), v_t_2499, v_t_24109, v_z_2410, v_z_2411});
    }
    case TAG_VCons: {
      V v_ru_24cb_247_24VCons = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_d_2452);
      heff_drop(v_c_2453);
      heff_drop_cell(v_ru_24x4_246_24VLam, 2);
      V v_t_24111 = heff_tag_at_n(v_ru_24cb_247_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24112 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_24111}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_24112, v_z_2410, v_z_2411));
    }
    case TAG_VOpaque: {
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_d_2452);
      heff_drop(v_c_2453);
      heff_drop_cell(v_ru_24x4_246_24VLam, 2);
      V v_t_24113 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24114 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_24113}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_24114, v_z_2410, v_z_2411));
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VCons: {
    V v_d_24115 = heff_field(v_x4_246, 0);
    V v_ru_24x4_246_24VCons = heff_take_reuse_n(v_x4_246, 1ULL, 1);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_247, 0ULL, 5);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop_rec(v_d_24115, 3);
      V v_t_24121 = heff_tag_at_n(v_ru_24x4_246_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24122 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_24121}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_24122, v_z_2410, v_z_2411));
    }
    case TAG_VCode: {
      heff_take_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop_rec(v_d_24115, 3);
      V v_t_24124 = heff_tag_at_n(v_ru_24x4_246_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24125 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_24124}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_24125, v_z_2410, v_z_2411));
    }
    case TAG_VLam: {
      heff_take_n(v_cb_247, 0ULL, 2);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop_rec(v_d_24115, 3);
      V v_t_24128 = heff_tag_at_n(v_ru_24x4_246_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24129 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_24128}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_24129, v_z_2410, v_z_2411));
    }
    case TAG_VCons: {
      V v_d_27_24130 = heff_field(v_cb_247, 0);
      heff_take_n(v_cb_247, 1ULL, 1);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      heff_drop_cell(v_ru_24x4_246_24VCons, 1);
      V v_t_24131 = heff_arrayToList(heff_get_n(v_d_24115, 2, 3));
      V v_t_24132 = heff_arrayToList(heff_get_n(v_d_27_24130, 2, 3));
      V v_t_24133 = (g_heff_2eelab_2eunify_2ezipL(v_t_24131, v_t_24132));
      return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_t_24133; V a_4 = heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_lam3, 1, 3, (V[]){v_r_243, v_g_244, v_cs_245}); V a_5 = v_z_2410; V a_6 = v_z_2411; V r_ = (g_heff_2eelab_2eunify_2eforU(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_w_240); heff_drop(v_uf_242); heff_drop(v_t_24133); r_; });
    }
    case TAG_VOpaque: {
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop_rec(v_d_24115, 3);
      V v_t_24145 = heff_tag_at_n(v_ru_24x4_246_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24146 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_24145}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_24146, v_z_2410, v_z_2411));
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VOpaque: {
    heff_drop(v_w_240);
    heff_drop(v_uf_242);
    heff_drop_rec(v_r_243, 9);
    heff_drop(v_g_244);
    heff_drop_rec(v_cs_245, 2);
    heff_drop(v_cb_247);
    heff_drop(v_a_248);
    heff_drop(v_b_249);
    heff_drop(v_z_2410);
    return heff_tail(v_z_2411, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  default: return heff_nomatch(v_x4_246);
  }
}
V g_heff_2eelab_2eunify_2euElRigid_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2euElRigid(a[0], a1, a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2euElRigid_lam0(V self, V *args) {
  V v_u_2481 = args[0];
  V v_a_2479 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2481);
  return v_a_2479;
}
V g_heff_2eelab_2eunify_2euElRigid_lam1(V self, V *args) {
  V v_w_2493 = args[0];
  V v_v_2482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_2493);
  return v_v_2482;
}
V g_heff_2eelab_2eunify_2euElRigid_lam2(V self, V *args) {
  V v_w_24103 = args[0];
  V v_v_2482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24103);
  return v_v_2482;
}
V g_heff_2eelab_2eunify_2euElRigid_lam3(V self, V *args) {
  V v_p_24134 = args[0];
  V v_r_243 = heff_env(self)[0];
  V v_g_244 = heff_env(self)[1];
  V v_cs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_24134)) {
  case TAG_MkPair: {
    V v_x_24135 = heff_field(v_p_24134, 0);
    V v_y_24136 = heff_field(v_p_24134, 1);
    heff_take_n(v_p_24134, 3ULL, 2);
    V v_t_24140;
    switch (heff_tag_of(v_x_24135)) {
    case TAG_Nom: {
      V v_x_24137 = heff_field(v_x_24135, 0);
      heff_take_n(v_x_24135, 1ULL, 1);
      v_t_24140 = v_x_24137;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x_24135, 0ULL, 1);
      v_t_24140 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24139 = heff_field(v_x_24135, 0);
      heff_take_n(v_x_24135, 1ULL, 1);
      v_t_24140 = v_x_24139;
      break;
    }
    default: heff_nomatch(v_x_24135);
    }
    V v_t_24144;
    switch (heff_tag_of(v_y_24136)) {
    case TAG_Nom: {
      V v_x_24141 = heff_field(v_y_24136, 0);
      heff_take_n(v_y_24136, 1ULL, 1);
      v_t_24144 = v_x_24141;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_y_24136, 0ULL, 1);
      v_t_24144 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24143 = heff_field(v_y_24136, 0);
      heff_take_n(v_y_24136, 1ULL, 1);
      v_t_24144 = v_x_24143;
      break;
    }
    default: heff_nomatch(v_y_24136);
    }
    V f_ = heff_get_n(v_r_243, 1, 9);
    heff_room[0] = v_g_244;
    heff_room[1] = v_cs_245;
    heff_room[2] = v_t_24140;
    heff_room[3] = v_t_24144;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_p_24134);
  }
}
Clo g_heff_2eelab_2eunify_2espineRev_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2espineRev_entry, 1, 0};

V g_heff_2eelab_2eunify_2espineRev(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_SpId);
  }
  case TAG_Cons: {
    V v_a_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eelab_2eunify_2espineRev(v_rest_242));
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_SpApp, 2, (V[]){v_t_243, v_a_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2espineRev_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2espineRev(a[0]);
}
V g_heff_2eelab_2eunify_2euH_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euH_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euH_lam0, 2, 0};
V g_heff_2eelab_2eunify_2euH_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2euH_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euH_lam1, 3, 0};

static V g_heff_2eelab_2eunify_2euH_val;
static HEFF_ONCE g_heff_2eelab_2eunify_2euH_st;
static V g_heff_2eelab_2eunify_2euH_init(void) {
  return heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_heff_2eelab_2eunify_2euH_lam0_clo), ((V)&g_heff_2eelab_2eunify_2euH_lam1_clo), ((V)&g_heff_2eelab_2eunify_2euAlg_clo)});
}
V g_heff_2eelab_2eunify_2euH_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eunify_2euH_st)) return g_heff_2eelab_2eunify_2euH_val;
  return heff_global(&g_heff_2eelab_2eunify_2euH_val, &g_heff_2eelab_2eunify_2euH_st, g_heff_2eelab_2eunify_2euH_init);
}
V g_heff_2eelab_2eunify_2euH_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_c_241 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_240}), v_c_241});
}
V g_heff_2eelab_2eunify_2euH_lam1(V self, V *args) {
  V v_m_242 = args[0];
  V v_k_243 = args[1];
  V v_c_244 = args[2];
  V v_x1_245 = heff_tr(heff_call(v_m_242, 1, (V[]){v_c_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop(v_k_243);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
      V f_ = v_k_243;
      args[0] = v_x_249;
      args[1] = v_st_247;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_lam0, 1, 0};
V g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_entry, 5, 0};

V g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179(V v_entry_240, V v_arity_241, V v_ty_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_lam0_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_lam1, 1, 5, (V[]){v_entry_240, v_arity_241, v_ty_242, v_hd_243, v_k_244})});
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_lam0(V self, V *args) {
  V v_c_245 = args[0];
  return heff_get_n(v_c_245, 4, 8);
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2415);
  V f_ = v_k_244;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2412, NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tr(heff_call(heff_take_field(v_hd_243, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})}));
  V f_ = heff_get_n(v_hd_243, 1, 3);
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_lam3, 1, 2, (V[]){v_k_244, v_x_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_entry_240 = heff_env(self)[0];
  V v_arity_241 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2enewMetaIn_clo), 3, (V[]){v_entry_240, v_arity_241, v_ty_242}));
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2411;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_lam2, 1, 3, (V[]){v_hd_243, v_k_244, v_x_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102_entry, 5, 0};

V g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102(V v_m_240, V v_sol_241, V v_stx_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102_lam0, 1, 3, (V[]){v_m_240, v_sol_241, v_stx_242})})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2413}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_2414, heff_clo_n(g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102_lam1, 1, 2, (V[]){v_hd_243, v_k_244})});
}
V g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_sol_241 = heff_env(self)[1];
  V v_stx_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_246 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_c_245, 3), heff_dup(v_m_240)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_e_2410 = v_field_248;
      V v_t_2411 = ({ V rv_1 = heff_tag_n(TAG_Just, 1, (V[]){v_sol_241}); V rv_2 = heff_tag_n(TAG_Just, 1, (V[]){v_stx_242}); V rr_ = heff_rec_reuse_nf(v_e_2410, 57ULL, 6, shape_ty__sol__solStx__arity__name__span, 4035u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_mc_2412 = (g_std_2emap_2einsert_24s170109517x1206653089(heff_take_field(v_c_245, 3), v_m_240, v_t_2411));
      return ({ V rv_3 = v_mc_2412; V rr_ = heff_rec_reuse_nf(v_c_245, 247ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 65343u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      heff_drop(v_m_240);
      heff_drop(v_sol_241);
      heff_drop(v_stx_242);
      heff_drop(v_field_248);
      return v_c_245;
    }
  }
}
V g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2415, NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_243, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})}));
  V f_ = heff_get_n(v_hd_243, 1, 3);
  heff_room[0] = v_t_2417;
  heff_room[1] = v_k_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}