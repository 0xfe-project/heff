// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_Catch 6517
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Escapes 7836
#define TAG_Expl 20488
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MentionsError 719
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SDecode 30927
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SIs 29577
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SRecord 16932
#define TAG_SSum 9005
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_UnequalNeus 2652
#define TAG_UnequalTys 2248
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_arity 294440695
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_cod 308210
#define LBL_dom 309180
#define LBL_el 9998
#define LBL_infos 301706655
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_mel 317518
#define LBL_metas 305145640
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ren 322325
#define LBL_ret 322331
#define LBL_selfKey 62480824
#define LBL_sol 323594
#define LBL_solStx 1050338738
#define LBL_span 10032145
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_ubare 312426689
#define LBL_uel 325206
#define LBL_uty 325684
#define LBL_values 1123329101
static uint32_t shape_dom__cod__ren[] = {LBL_dom, LBL_cod, LBL_ren};
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_ty__sol__solStx__arity__name__span[] = {LBL_ty, LBL_sol, LBL_solStx, LBL_arity, LBL_name, LBL_span};
V g_co_2e_3c_2b_3e_24s419270740x1449981722_get(void);
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_heff_2eelab_2econversion_2eeqHead(V, V);
V g_heff_2eelab_2econversion_2eeqHead_entry(V self, V *a);
extern Clo g_heff_2eelab_2econversion_2eeqHead_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eparams_2eeqLevel(V, V);
V g_heff_2eelab_2eparams_2eeqLevel_entry(V self, V *a);
extern Clo g_heff_2eelab_2eparams_2eeqLevel_clo;
V g_heff_2eelab_2eunify_2ecatMaybes(V);
V g_heff_2eelab_2eunify_2ecatMaybes_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ecatMaybes_clo;
V g_heff_2eelab_2eunify_2ecatMaybes_24dps(V, V);
V g_heff_2eelab_2eunify_2ecatMaybes_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ecatMaybes_24dps_clo;
V g_heff_2eelab_2eunify_2edistinct(V);
V g_heff_2eelab_2eunify_2edistinct_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2edistinct_clo;
V g_heff_2eelab_2eunify_2eeqPatArgs(V, V);
V g_heff_2eelab_2eunify_2eeqPatArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eeqPatArgs_clo;
V g_heff_2eelab_2eunify_2eforU(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2eforU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eforU_clo;
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876(V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_clo;
V g_heff_2eelab_2eunify_2emetasK(V);
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasK_clo;
V g_heff_2eelab_2eunify_2emsEv(V);
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emsEv_clo;
HeffT2 g_heff_2eelab_2eunify_2epatSpine_24cpr(V, V, V);
V g_heff_2eelab_2eunify_2epatVarsOf(V);
V g_heff_2eelab_2eunify_2epatVarsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatVarsOf_clo;
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_clo;
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253(V, V, V, V, V);
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_clo;
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_clo;
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_clo;
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_clo;
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(V, V);
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_clo;
V g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_clo;
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo;
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_clo;
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_clo;
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_clo;
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_clo;
V g_heff_2eelab_2eunify_2espineRev(V);
V g_heff_2eelab_2eunify_2espineRev_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2espineRev_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531(V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_clo;
V g_heff_2eelab_2eunify_2esubstOf(V);
V g_heff_2eelab_2eunify_2esubstOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstOf_clo;
V g_heff_2eelab_2eunify_2esubstTermF(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTermF_clo;
V g_heff_2eelab_2eunify_2esubstTypeF(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTypeF_clo;
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046(V, V, V, V);
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_clo;
V g_heff_2eelab_2eunify_2euAlg(V, V);
V g_heff_2eelab_2eunify_2euAlg_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euAlg_clo;
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_clo;
V g_heff_2eelab_2eunify_2euElRigid(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euElRigid_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euElRigid_clo;
V g_heff_2eelab_2eunify_2euH_get(void);
V g_heff_2eelab_2eunify_2euTermF(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_clo;
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo;
V g_heff_2eelab_2eunify_2eufEv(V);
V g_heff_2eelab_2eunify_2eufEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eufEv_clo;
V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_get(void);
V g_heff_2eelab_2eunify_2ezipL(V, V);
V g_heff_2eelab_2eunify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezipL_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2eisFixed(V, V);
V g_heff_2eelab_2evalue_2eisFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eisFixed_clo;
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(V, V, V);
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1583117218x1471782720(V, V);
V g_list_2efoldl_24s1583117218x1471782720_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1583117218x1471782720_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s868530262x539343671(V, V);
V g_list_2efoldl_24s868530262x539343671_entry(V self, V *a);
extern Clo g_list_2efoldl_24s868530262x539343671_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
HeffT2 g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
Clo g_heff_2eelab_2eunify_2ecatMaybes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ecatMaybes_entry, 1, 0};

V g_heff_2eelab_2eunify_2ecatMaybes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2eelab_2eunify_2ecatMaybes_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2ecatMaybes_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2ecatMaybes(a[0]);
}
V g_heff_2eelab_2eunify_2esubstOf_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2esubstOf_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2esubstOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstOf_entry, 1, 0};

V g_heff_2eelab_2eunify_2esubstOf(V v_idxs_240) {
top: ;
  return heff_rec_n(2, shape_el__ty, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2esubstOf_lam0, 2, 1, (V[]){heff_dup(v_idxs_240)}), heff_clo_n(g_heff_2eelab_2eunify_2esubstOf_lam1, 2, 1, (V[]){v_idxs_240})});
}
V g_heff_2eelab_2eunify_2esubstOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esubstOf(a[0]);
}
V g_heff_2eelab_2eunify_2esubstOf_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_t_242 = args[1];
  V v_idxs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2eelab_2eunify_2esubstOf(heff_dup(v_idxs_240)));
  return (g_heff_2eelab_2eunify_2esubstTermF(v_t_243, v_idxs_240, v_d_241, v_t_242));
}
V g_heff_2eelab_2eunify_2esubstOf_lam1(V self, V *args) {
  V v_d_244 = args[0];
  V v_t_245 = args[1];
  V v_idxs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_heff_2eelab_2eunify_2esubstOf(heff_dup(v_idxs_240)));
  return ({ V a_0 = v_t_246; V a_1 = v_idxs_240; V a_2 = v_d_244; V a_3 = v_t_245; V r_ = (g_heff_2eelab_2eunify_2esubstTypeF(a_0, a_1, a_2, a_3)); heff_drop(v_idxs_240); r_; });
}
HEFF_LIT(g_heff_2eelab_2eunify_2euElRigid_str0, 1, "x");
V g_heff_2eelab_2eunify_2euElRigid_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euElRigid_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2euElRigid_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euElRigid_lam3(V self, V *args);
Clo g_heff_2eelab_2eunify_2euElRigid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euElRigid_entry, 12, 0};

V g_heff_2eelab_2eunify_2euElRigid(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_x4_246, V v_cb_247, V v_a_248, V v_b_249, V v_z_2410, V v_z_2411) {
top: ;
  switch (heff_tag_of(v_x4_246)) {
  case TAG_VNeu: {
    V v_h_2412 = heff_field(v_x4_246, 0);
    V v_sp_2413 = heff_field(v_x4_246, 1);
    heff_take_n(v_x4_246, 3ULL, 5);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      V v_h_27_2417 = heff_field(v_cb_247, 0);
      V v_sp_27_2418 = heff_field(v_cb_247, 1);
      heff_take_n(v_cb_247, 3ULL, 5);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      return heff_tail(heff_get_n(v_r_243, 2, 9), 8, (V[]){v_g_244, v_cs_245, v_h_2412, v_sp_2413, v_h_27_2417, v_sp_27_2418, v_z_2410, v_z_2411});
    }
    case TAG_VCode: {
      V v_ru_24cb_247_24VCode = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_h_2412);
      heff_drop(v_sp_2413);
      V v_t_2423 = heff_tag_at_n(v_ru_24cb_247_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2424 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2423}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2424, v_z_2410, v_z_2411));
    }
    case TAG_VLam: {
      heff_take_n(v_cb_247, 0ULL, 2);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_h_2412);
      heff_drop(v_sp_2413);
      V v_t_2427 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2428 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2427}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2428, v_z_2410, v_z_2411));
    }
    case TAG_VCons: {
      V v_ru_24cb_247_24VCons = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_h_2412);
      heff_drop(v_sp_2413);
      V v_t_2430 = heff_tag_at_n(v_ru_24cb_247_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2431 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2430}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2431, v_z_2410, v_z_2411));
    }
    case TAG_VOpaque: {
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_h_2412);
      heff_drop(v_sp_2413);
      V v_t_2432 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2433 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2432}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2433, v_z_2410, v_z_2411));
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VCode: {
    V v_t_2434 = heff_field(v_x4_246, 0);
    V v_ru_24x4_246_24VCode = heff_take_reuse_n(v_x4_246, 1ULL, 1);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_247, 0ULL, 5);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_t_2434);
      V v_t_2440 = heff_tag_at_n(v_ru_24x4_246_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2441 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2440}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2441, v_z_2410, v_z_2411));
    }
    case TAG_VCode: {
      V v_t_27_2442 = heff_field(v_cb_247, 0);
      heff_take_n(v_cb_247, 1ULL, 1);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      heff_drop_cell(v_ru_24x4_246_24VCode, 1);
      return heff_tail(heff_get_n(v_r_243, 0, 9), 6, (V[]){v_g_244, v_cs_245, v_t_2434, v_t_27_2442, v_z_2410, v_z_2411});
    }
    case TAG_VLam: {
      heff_take_n(v_cb_247, 0ULL, 2);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_t_2434);
      V v_t_2445 = heff_tag_at_n(v_ru_24x4_246_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2446 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2445}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2446, v_z_2410, v_z_2411));
    }
    case TAG_VCons: {
      heff_take_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_t_2434);
      V v_t_2448 = heff_tag_at_n(v_ru_24x4_246_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2449 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2448}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2449, v_z_2410, v_z_2411));
    }
    case TAG_VOpaque: {
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_t_2434);
      V v_t_2450 = heff_tag_at_n(v_ru_24x4_246_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2451 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2450}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2451, v_z_2410, v_z_2411));
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VLam: {
    V v_d_2452 = heff_field(v_x4_246, 0);
    V v_c_2453 = heff_field(v_x4_246, 1);
    V v_ru_24x4_246_24VLam = heff_take_reuse_n(v_x4_246, 3ULL, 2);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_247, 0ULL, 5);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_d_2452);
      heff_drop(v_c_2453);
      heff_drop_cell(v_ru_24x4_246_24VLam, 2);
      V v_t_2459 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2460 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2459}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2460, v_z_2410, v_z_2411));
    }
    case TAG_VCode: {
      V v_ru_24cb_247_24VCode = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_d_2452);
      heff_drop(v_c_2453);
      heff_drop_cell(v_ru_24x4_246_24VLam, 2);
      V v_t_2462 = heff_tag_at_n(v_ru_24cb_247_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2463 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2462}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2463, v_z_2410, v_z_2411));
    }
    case TAG_VLam: {
      V v_c_27_2465 = heff_field(v_cb_247, 1);
      heff_take_n(v_cb_247, 2ULL, 2);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      V v_t_2466 = heff_tr(heff_call(v_d_2452, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_t_2467 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2466)));
      V v_a_2479;
      switch (heff_tag_of(v_t_2467)) {
      case TAG_LikeU: {
        heff_take_n(v_t_2467, 0ULL, 1);
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeFunction: {
        V v_dom_2470 = heff_field(v_t_2467, 1);
        heff_take_n(v_t_2467, 2ULL, 4);
        heff_drop(v_t_2466);
        v_a_2479 = v_dom_2470;
        break;
      }
      case TAG_LikeRecord: {
        heff_take_n(v_t_2467, 0ULL, 3);
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeSum: {
        heff_take_n(v_t_2467, 0ULL, 1);
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeInt: {
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeFloat: {
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeString: {
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeRune: {
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_2467, 0ULL, 1);
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeFixed: {
        heff_take_n(v_t_2467, 0ULL, 1);
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_NoRules: {
        v_a_2479 = v_t_2466;
        break;
      }
      default: heff_nomatch(v_t_2467);
      }
      V v_t_2480 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_cs_245, 0))});
      V v_v_2482 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(v_t_2480, heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_lam0, 1, 1, (V[]){v_a_2479}), NTAG(TAG_Nothing)));
      V v_t_2483 = heff_intAdd(heff_take_field(v_cs_245, 0), MK_INT(1LL));
      V v_t_2488;
      switch (heff_tag_of(v_c_2453)) {
      case TAG_MkClo: {
        V v_n_2484 = heff_dup(heff_field(v_c_2453, 0));
        v_t_2488 = v_n_2484;
        break;
      }
      case TAG_CloConst: {
        v_t_2488 = ((V)&g_heff_2eelab_2eunify_2euElRigid_str0);
        break;
      }
      default: heff_nomatch(v_c_2453);
      }
      V v_t_2489 = heff_tag_at_n(v_ru_24x4_246_24VLam, TAG_Cons, 2, (V[]){v_t_2488, heff_get_n(v_cs_245, 1, 2)});
      V v_x1_2495;
      switch (heff_tag_of(v_c_2453)) {
      case TAG_MkClo: {
        V v_vs_2491 = heff_field(v_c_2453, 1);
        V v_body_2492 = heff_field(v_c_2453, 2);
        heff_take_n(v_c_2453, 6ULL, 3);
        v_x1_2495 = heff_tr(heff_call(v_body_2492, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2491, heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_lam1, 1, 1, (V[]){heff_dup(v_v_2482)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2494 = heff_field(v_c_2453, 0);
        heff_take_n(v_c_2453, 1ULL, 1);
        v_x1_2495 = v_body_2494;
        break;
      }
      default: heff_nomatch(v_c_2453);
      }
      V v_t_2499;
      switch (heff_tag_of(v_x1_2495)) {
      case TAG_Nom: {
        V v_x_2496 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        v_t_2499 = v_x_2496;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2495, 0ULL, 1);
        v_t_2499 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2498 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        v_t_2499 = v_x_2498;
        break;
      }
      default: heff_nomatch(v_x1_2495);
      }
      V v_x1_24105;
      switch (heff_tag_of(v_c_27_2465)) {
      case TAG_MkClo: {
        V v_vs_24101 = heff_field(v_c_27_2465, 1);
        V v_body_24102 = heff_field(v_c_27_2465, 2);
        heff_take_n(v_c_27_2465, 6ULL, 3);
        v_x1_24105 = heff_tr(heff_call(v_body_24102, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_24101, heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_lam2, 1, 1, (V[]){v_v_2482})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_24104 = heff_field(v_c_27_2465, 0);
        heff_take_n(v_c_27_2465, 1ULL, 1);
        heff_drop(v_v_2482);
        v_x1_24105 = v_body_24104;
        break;
      }
      default: heff_nomatch(v_c_27_2465);
      }
      V v_t_24109;
      switch (heff_tag_of(v_x1_24105)) {
      case TAG_Nom: {
        V v_x_24106 = heff_field(v_x1_24105, 0);
        heff_take_n(v_x1_24105, 1ULL, 1);
        v_t_24109 = v_x_24106;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_24105, 0ULL, 1);
        v_t_24109 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24108 = heff_field(v_x1_24105, 0);
        heff_take_n(v_x1_24105, 1ULL, 1);
        v_t_24109 = v_x_24108;
        break;
      }
      default: heff_nomatch(v_x1_24105);
      }
      return heff_tail(heff_get_n(v_r_243, 1, 9), 6, (V[]){v_g_244, heff_rec_n(2, shape_len__names, (V[]){v_t_2483, v_t_2489}), v_t_2499, v_t_24109, v_z_2410, v_z_2411});
    }
    case TAG_VCons: {
      V v_ru_24cb_247_24VCons = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_d_2452);
      heff_drop(v_c_2453);
      heff_drop_cell(v_ru_24x4_246_24VLam, 2);
      V v_t_24111 = heff_tag_at_n(v_ru_24cb_247_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24112 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_24111}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_24112, v_z_2410, v_z_2411));
    }
    case TAG_VOpaque: {
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_d_2452);
      heff_drop(v_c_2453);
      heff_drop_cell(v_ru_24x4_246_24VLam, 2);
      V v_t_24113 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24114 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_24113}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_24114, v_z_2410, v_z_2411));
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VCons: {
    V v_d_24115 = heff_field(v_x4_246, 0);
    V v_ru_24x4_246_24VCons = heff_take_reuse_n(v_x4_246, 1ULL, 1);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_247, 0ULL, 5);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop_rec(v_d_24115, 3);
      V v_t_24121 = heff_tag_at_n(v_ru_24x4_246_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24122 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_24121}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_24122, v_z_2410, v_z_2411));
    }
    case TAG_VCode: {
      heff_take_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop_rec(v_d_24115, 3);
      V v_t_24124 = heff_tag_at_n(v_ru_24x4_246_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24125 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_24124}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_24125, v_z_2410, v_z_2411));
    }
    case TAG_VLam: {
      heff_take_n(v_cb_247, 0ULL, 2);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop_rec(v_d_24115, 3);
      V v_t_24128 = heff_tag_at_n(v_ru_24x4_246_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24129 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_24128}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_24129, v_z_2410, v_z_2411));
    }
    case TAG_VCons: {
      V v_d_27_24130 = heff_field(v_cb_247, 0);
      heff_take_n(v_cb_247, 1ULL, 1);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      heff_drop_cell(v_ru_24x4_246_24VCons, 1);
      V v_t_24131 = heff_arrayToList(heff_get_n(v_d_24115, 2, 3));
      V v_t_24132 = heff_arrayToList(heff_get_n(v_d_27_24130, 2, 3));
      V v_t_24133 = (g_heff_2eelab_2eunify_2ezipL(v_t_24131, v_t_24132));
      return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_t_24133; V a_4 = heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_lam3, 1, 3, (V[]){v_r_243, v_g_244, v_cs_245}); V a_5 = v_z_2410; V a_6 = v_z_2411; V r_ = (g_heff_2eelab_2eunify_2eforU(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_w_240); heff_drop(v_uf_242); heff_drop(v_t_24133); r_; });
    }
    case TAG_VOpaque: {
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop_rec(v_d_24115, 3);
      V v_t_24145 = heff_tag_at_n(v_ru_24x4_246_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24146 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_24145}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_24146, v_z_2410, v_z_2411));
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VOpaque: {
    heff_drop(v_w_240);
    heff_drop(v_uf_242);
    heff_drop_rec(v_r_243, 9);
    heff_drop(v_g_244);
    heff_drop_rec(v_cs_245, 2);
    heff_drop(v_cb_247);
    heff_drop(v_a_248);
    heff_drop(v_b_249);
    heff_drop(v_z_2410);
    return heff_tail(v_z_2411, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  default: return heff_nomatch(v_x4_246);
  }
}
V g_heff_2eelab_2eunify_2euElRigid_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2euElRigid(a[0], a1, a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2euElRigid_lam0(V self, V *args) {
  V v_u_2481 = args[0];
  V v_a_2479 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2481);
  return v_a_2479;
}
V g_heff_2eelab_2eunify_2euElRigid_lam1(V self, V *args) {
  V v_w_2493 = args[0];
  V v_v_2482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_2493);
  return v_v_2482;
}
V g_heff_2eelab_2eunify_2euElRigid_lam2(V self, V *args) {
  V v_w_24103 = args[0];
  V v_v_2482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24103);
  return v_v_2482;
}
V g_heff_2eelab_2eunify_2euElRigid_lam3(V self, V *args) {
  V v_p_24134 = args[0];
  V v_r_243 = heff_env(self)[0];
  V v_g_244 = heff_env(self)[1];
  V v_cs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_24134)) {
  case TAG_MkPair: {
    V v_x_24135 = heff_field(v_p_24134, 0);
    V v_y_24136 = heff_field(v_p_24134, 1);
    heff_take_n(v_p_24134, 3ULL, 2);
    V v_t_24140;
    switch (heff_tag_of(v_x_24135)) {
    case TAG_Nom: {
      V v_x_24137 = heff_field(v_x_24135, 0);
      heff_take_n(v_x_24135, 1ULL, 1);
      v_t_24140 = v_x_24137;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x_24135, 0ULL, 1);
      v_t_24140 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24139 = heff_field(v_x_24135, 0);
      heff_take_n(v_x_24135, 1ULL, 1);
      v_t_24140 = v_x_24139;
      break;
    }
    default: heff_nomatch(v_x_24135);
    }
    V v_t_24144;
    switch (heff_tag_of(v_y_24136)) {
    case TAG_Nom: {
      V v_x_24141 = heff_field(v_y_24136, 0);
      heff_take_n(v_y_24136, 1ULL, 1);
      v_t_24144 = v_x_24141;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_y_24136, 0ULL, 1);
      v_t_24144 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24143 = heff_field(v_y_24136, 0);
      heff_take_n(v_y_24136, 1ULL, 1);
      v_t_24144 = v_x_24143;
      break;
    }
    default: heff_nomatch(v_y_24136);
    }
    V f_ = heff_get_n(v_r_243, 1, 9);
    heff_room[0] = v_g_244;
    heff_room[1] = v_cs_245;
    heff_room[2] = v_t_24140;
    heff_room[3] = v_t_24144;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_p_24134);
  }
}
Clo g_heff_2eelab_2eunify_2espineRev_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2espineRev_entry, 1, 0};

V g_heff_2eelab_2eunify_2espineRev(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_SpId);
  }
  case TAG_Cons: {
    V v_a_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eelab_2eunify_2espineRev(v_rest_242));
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_SpApp, 2, (V[]){v_t_243, v_a_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2espineRev_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2espineRev(a[0]);
}
V g_heff_2eelab_2eunify_2euH_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euH_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euH_lam0, 2, 0};
V g_heff_2eelab_2eunify_2euH_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2euH_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euH_lam1, 3, 0};

static V g_heff_2eelab_2eunify_2euH_val;
static HEFF_ONCE g_heff_2eelab_2eunify_2euH_st;
static V g_heff_2eelab_2eunify_2euH_init(void) {
  return heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_heff_2eelab_2eunify_2euH_lam0_clo), ((V)&g_heff_2eelab_2eunify_2euH_lam1_clo), ((V)&g_heff_2eelab_2eunify_2euAlg_clo)});
}
V g_heff_2eelab_2eunify_2euH_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eunify_2euH_st)) return g_heff_2eelab_2eunify_2euH_val;
  return heff_global(&g_heff_2eelab_2eunify_2euH_val, &g_heff_2eelab_2eunify_2euH_st, g_heff_2eelab_2eunify_2euH_init);
}
V g_heff_2eelab_2eunify_2euH_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_c_241 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_240}), v_c_241});
}
V g_heff_2eelab_2eunify_2euH_lam1(V self, V *args) {
  V v_m_242 = args[0];
  V v_k_243 = args[1];
  V v_c_244 = args[2];
  V v_x1_245 = heff_tr(heff_call(v_m_242, 1, (V[]){v_c_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop(v_k_243);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
      V f_ = v_k_243;
      args[0] = v_x_249;
      args[1] = v_st_247;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_entry, 3, 0};

V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(V v_ms_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_lam0, 1, 1, (V[]){heff_dup(v_ms_240)})})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_lam1, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_lam0(V self, V *args) {
  V v_c_243 = args[0];
  V v_ms_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ps_244 = ({ V a_0 = heff_take_field(v_c_243, 2); V a_1 = v_ms_240; V r_ = (g_list_2efoldl_24s1583117218x1471782720(a_0, a_1)); heff_drop(v_ms_240); r_; });
  return ({ V rv_2 = v_ps_244; V rr_ = heff_rec_reuse_nf(v_c_243, 251ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 65487u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tag_n(TAG_Put, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})}));
  V f_ = heff_get_n(v_hd_241, 1, 3);
  heff_room[0] = v_t_249;
  heff_room[1] = v_k_242;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_entry, 5, 0};

V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531(V v_m_240, V v_sol_241, V v_stx_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_lam0, 1, 3, (V[]){v_m_240, v_sol_241, v_stx_242})})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2413}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_2414, heff_clo_n(g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_lam1, 1, 2, (V[]){v_hd_243, v_k_244})});
}
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_sol_241 = heff_env(self)[1];
  V v_stx_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_246 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_c_245, 3), heff_dup(v_m_240)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_e_2410 = v_field_248;
      V v_t_2411 = ({ V rv_1 = heff_tag_n(TAG_Just, 1, (V[]){v_sol_241}); V rv_2 = heff_tag_n(TAG_Just, 1, (V[]){v_stx_242}); V rr_ = heff_rec_reuse_nf(v_e_2410, 57ULL, 6, shape_ty__sol__solStx__arity__name__span, 4035u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_mc_2412 = (g_std_2emap_2einsert_24s170109517x1206653089(heff_take_field(v_c_245, 3), v_m_240, v_t_2411));
      return ({ V rv_3 = v_mc_2412; V rr_ = heff_rec_reuse_nf(v_c_245, 247ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 65343u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      heff_drop(v_m_240);
      heff_drop(v_sol_241);
      heff_drop(v_stx_242);
      heff_drop(v_field_248);
      return v_c_245;
    }
  }
}
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2415, NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_243, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})}));
  V f_ = heff_get_n(v_hd_243, 1, 3);
  heff_room[0] = v_t_2417;
  heff_room[1] = v_k_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam0, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam2, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam6(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam6, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_entry, 8, 0};

V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929(V v_g_240, V v_cs_241, V v_m_242, V v_sp_243, V v_rhs_244, V v_self_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam0_clo)})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam1, 1, 8, (V[]){v_hd_246, v_sp_243, v_rhs_244, v_g_240, v_cs_241, v_m_242, v_k_247, v_self_245})});
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get_n(v_c_248, 3, 8);
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam2(V self, V *args) {
  V v_c_2412 = args[0];
  return heff_get_n(v_c_2412, 7, 8);
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam5(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2450);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam4(V self, V *args) {
  V v_x_2445 = args[0];
  V v_args_2423 = heff_env(self)[0];
  V v_args_27_2440 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2446 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2423));
  V v_t_2447 = (g_heff_2eelab_2eunify_2ezipL(v_args_2423, v_args_27_2440));
  V v_t_2448 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876(MK_INT(0LL), v_t_2447));
  V v_t_2449 = (g_heff_2eelab_2eunify_2ecatMaybes(v_t_2448));
  return (g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529(v_g_240, heff_dup(v_m_242), v_m_242, v_x_2445, v_t_2446, v_t_2449, v_hd_246, heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam5, 1, 1, (V[]){v_k_247})));
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam6(V self, V *args) {
  V v_c_2452 = args[0];
  return heff_get_n(v_c_2452, 3, 8);
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam7(V self, V *args) {
  V v_x_2455 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_k_2451 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2456 = ({ V a_0 = v_x_2455; V a_1 = v_m_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(a_0, a_1)); heff_drop(v_x_2455); r_; });
  {
    V v_field_2458 = v_t_2456.f[1];
    int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
    if ((v_tag_2457 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_246, 3);
      V v_e_2460 = v_field_2458;
      V f_ = v_k_2451;
      args[0] = v_e_2460;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2458);
      V v_t_2461 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2462 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2461})});
      V v_t_2463 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2462}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_2463;
      heff_room[1] = v_k_2451;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_rhs_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  V v_m_242 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  V v_self_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  HeffT2 v_t_2416 = (g_heff_2eelab_2eunify_2epatSpine_24cpr(v_x_2415, v_x_2411, v_sp_243));
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_items_2420 = v_field_2418;
      V v_t_2421 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2420)));
      V v_t_2422 = ({ V a_0 = v_t_2421; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2421); r_; });
      if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
        heff_drop(v_t_2422);
        V v_args_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2420));
        switch (heff_tag_of(v_rhs_244)) {
        case TAG_VNeu: {
          V v_v1_2424 = heff_dup(heff_field(v_rhs_244, 0));
          V v_sp_2425 = heff_dup(heff_field(v_rhs_244, 1));
          switch (heff_tag_of(v_v1_2424)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_2424, 0ULL, 1);
            heff_drop(v_x_2415);
            heff_drop(v_x_2411);
            heff_drop(v_self_245);
            heff_drop(v_sp_2425);
            return (g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_2424, 0ULL, 1);
            heff_drop(v_x_2415);
            heff_drop(v_x_2411);
            heff_drop(v_self_245);
            heff_drop(v_sp_2425);
            return (g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
          }
          case TAG_HMeta: {
            V v_m_2431 = heff_field(v_v1_2424, 0);
            V v_ru_24v1_2424_24HMeta = heff_take_reuse_n(v_v1_2424, 1ULL, 1);
            if (heff_intEq_c_lent(v_m_2431, v_m_242, 1)) {
              HeffT2 v_t_2433 = ({ V a_0 = v_x_2415; V a_1 = v_x_2411; V a_2 = v_sp_2425; HeffT2 r_ = (g_heff_2eelab_2eunify_2epatSpine_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2415); heff_drop(v_x_2411); r_; });
              {
                V v_field_2435 = v_t_2433.f[1];
                int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
                if ((v_tag_2434 == ((int64_t)0ULL))) {
                  V v_items_2437 = v_field_2435;
                  V v_t_2438 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2437)));
                  V v_t_2439 = ({ V a_0 = v_t_2438; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2438); r_; });
                  if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
                    heff_drop(v_t_2439);
                    V v_args_27_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2437));
                    V v_t_2441 = (g_heff_2eelab_2eunify_2eeqPatArgs(v_args_27_2440, v_args_2423));
                    if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
                      heff_drop_tag(v_rhs_244, 5);
                      heff_drop(v_g_240);
                      heff_drop(v_cs_241);
                      heff_drop(v_m_242);
                      heff_drop_rec(v_hd_246, 3);
                      heff_drop(v_self_245);
                      heff_drop(v_args_2423);
                      heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
                      heff_drop(v_args_27_2440);
                      heff_drop(v_t_2441);
                      V f_ = v_k_247;
                      args[0] = NTAG(TAG_MkUnit);
                      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                      return heff_tail(f_, 1, args);
                    } else {
                      heff_drop(v_t_2441);
                      V v_t_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_27_2440));
                      V v_t_2443 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2423));
                      if (heff_intEq_c(v_t_2442, v_t_2443)) {
                        heff_drop_tag(v_rhs_244, 5);
                        heff_drop(v_cs_241);
                        heff_drop(v_self_245);
                        V v_k_2451 = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam4, 1, 6, (V[]){v_args_2423, v_args_27_2440, v_g_240, heff_dup(v_m_242), heff_dup(v_hd_246), v_k_247});
                        V v_t_2453 = heff_tag_at_n(v_ru_24v1_2424_24HMeta, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam6_clo)})});
                        V v_t_2454 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2453}));
                        V f_ = heff_dup(heff_rfield(v_hd_246, 1));
                        heff_room[0] = v_t_2454;
                        heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam7, 1, 3, (V[]){v_m_242, v_k_2451, v_hd_246});
                        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
                      } else {
                        heff_drop(v_g_240);
                        heff_drop(v_m_242);
                        heff_drop(v_args_2423);
                        heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
                        heff_drop(v_args_27_2440);
                        return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
                      }
                    }
                  } else {
                    heff_drop(v_g_240);
                    heff_drop(v_m_242);
                    heff_drop(v_args_2423);
                    heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
                    heff_drop(v_items_2437);
                    heff_drop(v_t_2439);
                    return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
                  }
                } else {
                  heff_drop(v_g_240);
                  heff_drop(v_m_242);
                  heff_drop(v_args_2423);
                  heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
                  heff_drop(v_field_2435);
                  return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
                }
              }
            } else {
              heff_drop(v_x_2415);
              heff_drop(v_x_2411);
              heff_drop(v_self_245);
              heff_drop(v_sp_2425);
              heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
              return (g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
            }
          }
          case TAG_HError: {
            heff_drop(v_x_2415);
            heff_drop(v_x_2411);
            heff_drop(v_self_245);
            heff_drop(v_sp_2425);
            return (g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
          }
          default: return heff_nomatch(v_v1_2424);
          }
        }
        case TAG_VCode: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
        }
        case TAG_VLam: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
        }
        case TAG_VCons: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
        }
        case TAG_VOpaque: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
        }
        default: return heff_nomatch(v_rhs_244);
        }
      } else {
        heff_drop(v_x_2415);
        heff_drop(v_x_2411);
        heff_drop(v_g_240);
        heff_drop(v_m_242);
        heff_drop(v_items_2420);
        heff_drop(v_t_2422);
        return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
      }
    } else {
      heff_drop(v_x_2415);
      heff_drop(v_x_2411);
      heff_drop(v_g_240);
      heff_drop(v_m_242);
      heff_drop(v_field_2418);
      return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
    }
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_rhs_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  V v_m_242 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_self_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam2_clo)})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2413}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam3, 1, 9, (V[]){v_x_2411, v_sp_243, v_rhs_244, v_g_240, v_cs_241, v_m_242, v_hd_246, v_k_247, v_self_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam0, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam1, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam14(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam15(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam17(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam18(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam21(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam21, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam22(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam23(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam20(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam19(V self, V *args);
Clo g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_entry, 6, 0};

V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095(V v_g_240, V v_cs_241, V v_h_242, V v_sp_243, V v_h_27_244, V v_sp_27_245) {
top: ;
  V v_t_2418;
  switch (heff_tag_of(v_h_242)) {
  case TAG_HLocal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HGlobal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HMeta: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HError: {
    v_t_2418 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_h_242);
  }
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_g_240);
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop(v_sp_243);
    heff_drop(v_h_27_244);
    heff_drop(v_sp_27_245);
    heff_drop(v_t_2418);
    return ((V)&g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam0_clo);
  } else {
    heff_drop(v_t_2418);
    switch (heff_tag_of(v_sp_243)) {
    case TAG_SpId: {
      heff_drop(v_g_240);
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        V v_t_2421 = (g_heff_2eelab_2econversion_2eeqHead(v_h_242, v_h_27_244));
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_cs_241);
          heff_drop(v_h_242);
          heff_drop(v_h_27_244);
          heff_drop(v_t_2421);
          return ((V)&g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam1_clo);
        } else {
          heff_drop(v_t_2421);
          return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam2, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
        }
      }
      case TAG_SpApp: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam3, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam4, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam5, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpApp: {
      V v_sq_2447 = heff_dup(heff_field(v_sp_243, 0));
      V v_v_2448 = heff_dup(heff_field(v_sp_243, 1));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2447);
        heff_drop(v_v_2448);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam6, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        V v_sq_27_2453 = heff_field(v_sp_27_245, 0);
        V v_v_27_2454 = heff_field(v_sp_27_245, 1);
        heff_take_n(v_sp_27_245, 3ULL, 2);
        heff_drop_tag(v_sp_243, 2);
        V v_c_2455 = (g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095(heff_dup(v_g_240), heff_dup(v_cs_241), v_h_242, v_sq_2447, v_h_27_244, v_sq_27_2453));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam7, 2, 5, (V[]){v_c_2455, v_g_240, v_cs_241, v_v_2448, v_v_27_2454});
      }
      case TAG_SpProj: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2447);
        heff_drop(v_v_2448);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam9, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2447);
        heff_drop(v_v_2448);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam10, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpProj: {
      V v_sq_2473 = heff_dup(heff_field(v_sp_243, 0));
      V v_x_2474 = heff_dup(heff_field(v_sp_243, 1));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2473);
        heff_drop(v_x_2474);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam11, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2473);
        heff_drop(v_x_2474);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam12, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        V v_sq_27_2485 = heff_dup(heff_field(v_sp_27_245, 0));
        V v_x_27_2486 = heff_dup(heff_field(v_sp_27_245, 1));
        V v_c_2487 = (g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095(v_g_240, heff_dup(v_cs_241), heff_dup(v_h_242), v_sq_2473, heff_dup(v_h_27_244), v_sq_27_2485));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam13, 2, 8, (V[]){v_c_2487, v_x_2474, v_x_27_2486, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2473);
        heff_drop(v_x_2474);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam15, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpSpec: {
      V v_sq_24101 = heff_dup(heff_field(v_sp_243, 0));
      V v_x_24102 = heff_dup(heff_field(v_sp_243, 1));
      V v_v_24103 = heff_dup(heff_field(v_sp_243, 2));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24101);
        heff_drop(v_x_24102);
        heff_drop(v_v_24103);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam16, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24101);
        heff_drop(v_x_24102);
        heff_drop(v_v_24103);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam17, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24101);
        heff_drop(v_x_24102);
        heff_drop(v_v_24103);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam18, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        V v_sq_27_24120 = heff_dup(heff_field(v_sp_27_245, 0));
        V v_x_27_24121 = heff_dup(heff_field(v_sp_27_245, 1));
        V v_v_27_24122 = heff_dup(heff_field(v_sp_27_245, 2));
        V v_c_24123 = (g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_h_242), v_sq_24101, heff_dup(v_h_27_244), v_sq_27_24120));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam19, 2, 11, (V[]){v_c_24123, v_x_24102, v_x_27_24121, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_g_240, v_v_24103, v_v_27_24122});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    default: return heff_nomatch(v_sp_243);
    }
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam0(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam1(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2426 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2427 = heff_tr(heff_call(heff_take_field(v_hd_2424, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})}));
  V f_ = heff_get_n(v_hd_2424, 1, 3);
  args[0] = v_t_2427;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam3(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k2_2431 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2432 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2433 = heff_tr(heff_call(heff_take_field(v_hd_2430, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})}));
  V f_ = heff_get_n(v_hd_2430, 1, 3);
  args[0] = v_t_2433;
  args[1] = v_k2_2431;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam4(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k2_2437 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2438 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2439 = heff_tr(heff_call(heff_take_field(v_hd_2436, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})}));
  V f_ = heff_get_n(v_hd_2436, 1, 3);
  args[0] = v_t_2439;
  args[1] = v_k2_2437;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k2_2444 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2445 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2446 = heff_tr(heff_call(heff_take_field(v_hd_2443, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})}));
  V f_ = heff_get_n(v_hd_2443, 1, 3);
  args[0] = v_t_2446;
  args[1] = v_k2_2444;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam6(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k2_2450 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2451 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2452 = heff_tr(heff_call(heff_take_field(v_hd_2449, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})}));
  V f_ = heff_get_n(v_hd_2449, 1, 3);
  args[0] = v_t_2452;
  args[1] = v_k2_2450;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam8(V self, V *args) {
  V v_x_2458 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_2448 = heff_env(self)[2];
  V v_v_27_2454 = heff_env(self)[3];
  V v_hd_2456 = heff_env(self)[4];
  V v_k_2457 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2458);
  V v_t_2459 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2e_3c_2b_3e_24s419270740x1449981722_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_get()), v_g_240, v_cs_241, v_v_2448, v_v_27_2454));
  V f_ = v_t_2459;
  heff_room[0] = v_hd_2456;
  heff_room[1] = v_k_2457;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam7(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_v_2448 = heff_env(self)[3];
  V v_v_27_2454 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2455;
  args[0] = heff_dup(v_hd_2456);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam8, 1, 6, (V[]){v_g_240, v_cs_241, v_v_2448, v_v_27_2454, v_hd_2456, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam9(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k2_2463 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2464 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2465 = heff_tr(heff_call(heff_take_field(v_hd_2462, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2464})}));
  V f_ = heff_get_n(v_hd_2462, 1, 3);
  args[0] = v_t_2465;
  args[1] = v_k2_2463;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam10(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k2_2470 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2471 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2472 = heff_tr(heff_call(heff_take_field(v_hd_2469, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2471})}));
  V f_ = heff_get_n(v_hd_2469, 1, 3);
  args[0] = v_t_2472;
  args[1] = v_k2_2470;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam11(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k2_2476 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2477 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2478 = heff_tr(heff_call(heff_take_field(v_hd_2475, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})}));
  V f_ = heff_get_n(v_hd_2475, 1, 3);
  args[0] = v_t_2478;
  args[1] = v_k2_2476;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam12(V self, V *args) {
  V v_hd_2481 = args[0];
  V v_k2_2482 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2483 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2484 = heff_tr(heff_call(heff_take_field(v_hd_2481, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})}));
  V f_ = heff_get_n(v_hd_2481, 1, 3);
  args[0] = v_t_2484;
  args[1] = v_k2_2482;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam14(V self, V *args) {
  V v_x_2490 = args[0];
  V v_x_2474 = heff_env(self)[0];
  V v_x_27_2486 = heff_env(self)[1];
  V v_k_2489 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  V v_hd_2488 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2490);
  if (heff_strEq_c(v_x_2474, v_x_27_2486)) {
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop_tag(v_sp_243, 2);
    heff_drop(v_h_27_244);
    heff_drop_tag(v_sp_27_245, 2);
    heff_drop_rec(v_hd_2488, 3);
    V f_ = v_k_2489;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_2492 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
    V v_t_2493 = heff_tr(heff_call(heff_take_field(v_hd_2488, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2492})}));
    V f_ = heff_get_n(v_hd_2488, 1, 3);
    heff_room[0] = v_t_2493;
    heff_room[1] = v_k_2489;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam13(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k_2489 = args[1];
  V v_c_2487 = heff_env(self)[0];
  V v_x_2474 = heff_env(self)[1];
  V v_x_27_2486 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2487;
  args[0] = heff_dup(v_hd_2488);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam14, 1, 9, (V[]){v_x_2474, v_x_27_2486, v_k_2489, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_2488});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam15(V self, V *args) {
  V v_hd_2497 = args[0];
  V v_k2_2498 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2499 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24100 = heff_tr(heff_call(heff_take_field(v_hd_2497, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2499})}));
  V f_ = heff_get_n(v_hd_2497, 1, 3);
  args[0] = v_t_24100;
  args[1] = v_k2_2498;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam16(V self, V *args) {
  V v_hd_24104 = args[0];
  V v_k2_24105 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24106 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24107 = heff_tr(heff_call(heff_take_field(v_hd_24104, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24106})}));
  V f_ = heff_get_n(v_hd_24104, 1, 3);
  args[0] = v_t_24107;
  args[1] = v_k2_24105;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam17(V self, V *args) {
  V v_hd_24110 = args[0];
  V v_k2_24111 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24112 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24113 = heff_tr(heff_call(heff_take_field(v_hd_24110, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24112})}));
  V f_ = heff_get_n(v_hd_24110, 1, 3);
  args[0] = v_t_24113;
  args[1] = v_k2_24111;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam18(V self, V *args) {
  V v_hd_24116 = args[0];
  V v_k2_24117 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24118 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24119 = heff_tr(heff_call(heff_take_field(v_hd_24116, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24118})}));
  V f_ = heff_get_n(v_hd_24116, 1, 3);
  args[0] = v_t_24119;
  args[1] = v_k2_24117;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam21(V self, V *args) {
  V v_hd_24128 = args[0];
  V v_k_24129 = args[1];
  heff_drop(v_hd_24128);
  V f_ = v_k_24129;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam22(V self, V *args) {
  V v_hd_24130 = args[0];
  V v_k2_24131 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24132 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24133 = heff_tr(heff_call(heff_take_field(v_hd_24130, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24132})}));
  V f_ = heff_get_n(v_hd_24130, 1, 3);
  args[0] = v_t_24133;
  args[1] = v_k2_24131;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam23(V self, V *args) {
  V v_x_24135 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_24103 = heff_env(self)[2];
  V v_v_27_24122 = heff_env(self)[3];
  V v_hd_24124 = heff_env(self)[4];
  V v_k_24125 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24135);
  V v_t_24136 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2e_3c_2b_3e_24s419270740x1449981722_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_get()), v_g_240, v_cs_241, v_v_24103, v_v_27_24122));
  V f_ = v_t_24136;
  heff_room[0] = v_hd_24124;
  heff_room[1] = v_k_24125;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam20(V self, V *args) {
  V v_x_24126 = args[0];
  V v_x_24102 = heff_env(self)[0];
  V v_x_27_24121 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_h_242 = heff_env(self)[3];
  V v_sp_243 = heff_env(self)[4];
  V v_h_27_244 = heff_env(self)[5];
  V v_sp_27_245 = heff_env(self)[6];
  V v_hd_24124 = heff_env(self)[7];
  V v_g_240 = heff_env(self)[8];
  V v_v_24103 = heff_env(self)[9];
  V v_v_27_24122 = heff_env(self)[10];
  V v_k_24125 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_24126);
  V v_t_24134;
  if (heff_strEq_c(v_x_24102, v_x_27_24121)) {
    heff_drop(v_h_242);
    heff_drop_tag(v_sp_243, 3);
    heff_drop(v_h_27_244);
    heff_drop_tag(v_sp_27_245, 3);
    v_t_24134 = ((V)&g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam21_clo);
  } else {
    v_t_24134 = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam22, 2, 5, (V[]){heff_dup(v_cs_241), v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
  }
  V f_ = v_t_24134;
  heff_room[0] = heff_dup(v_hd_24124);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam23, 1, 6, (V[]){v_g_240, v_cs_241, v_v_24103, v_v_27_24122, v_hd_24124, v_k_24125});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam19(V self, V *args) {
  V v_hd_24124 = args[0];
  V v_k_24125 = args[1];
  V v_c_24123 = heff_env(self)[0];
  V v_x_24102 = heff_env(self)[1];
  V v_x_27_24121 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  V v_g_240 = heff_env(self)[8];
  V v_v_24103 = heff_env(self)[9];
  V v_v_27_24122 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_24123;
  args[0] = heff_dup(v_hd_24124);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam20, 1, 12, (V[]){v_x_24102, v_x_27_24121, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_24124, v_g_240, v_v_24103, v_v_27_24122, v_k_24125});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_str0, 1, "x");
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_entry, 6, 0};

V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634(V v_g_240, V v_cs_241, V v_a_242, V v_b_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    V v_u_246 = heff_dup(heff_field(v_a_242, 0));
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_u_27_247 = heff_dup(heff_field(v_b_243, 0));
      switch (heff_tag_of(v_u_246)) {
      case TAG_SmallU: {
        switch (heff_tag_of(v_u_27_247)) {
        case TAG_SmallU: {
          heff_drop_rec(v_cs_241, 2);
          heff_drop_tag(v_a_242, 1);
          heff_drop_tag(v_b_243, 1);
          heff_drop_rec(v_z_244, 3);
          return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
        }
        case TAG_LargeU: {
          V v_t_248 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
          V v_t_249 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})}));
          return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_249, v_z_245});
        }
        default: return heff_nomatch(v_u_27_247);
        }
      }
      case TAG_LargeU: {
        switch (heff_tag_of(v_u_27_247)) {
        case TAG_SmallU: {
          V v_t_2410 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
          V v_t_2411 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})}));
          return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2411, v_z_245});
        }
        case TAG_LargeU: {
          heff_drop_rec(v_cs_241, 2);
          heff_drop_tag(v_a_242, 1);
          heff_drop_tag(v_b_243, 1);
          heff_drop_rec(v_z_244, 3);
          return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
        }
        default: return heff_nomatch(v_u_27_247);
        }
      }
      default: return heff_nomatch(v_u_246);
      }
    }
    case TAG_VDecode: {
      heff_drop(v_u_246);
      V v_t_2417 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2418 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2418, v_z_245});
    }
    case TAG_VFunction: {
      heff_drop(v_u_246);
      V v_t_2425 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2426 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2426, v_z_245});
    }
    case TAG_VRecord: {
      heff_drop(v_u_246);
      V v_t_2431 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2432 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2432, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_u_246);
      V v_t_2434 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2435 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2435, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_u_246);
      V v_t_2436 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2437 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2437, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_u_246);
      V v_t_2438 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2439 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2439, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_u_246);
      V v_t_2440 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2441 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2441, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_u_246);
      V v_t_2442 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2443 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2443, v_z_245});
    }
    case TAG_VPrimArray: {
      heff_drop(v_u_246);
      V v_t_2445 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2446 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2446, v_z_245});
    }
    case TAG_VFixed: {
      heff_drop(v_u_246);
      V v_t_2448 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2449 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2449, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VDecode: {
    V v_h_2450 = heff_dup(heff_field(v_a_242, 0));
    V v_sp_2451 = heff_dup(heff_field(v_a_242, 1));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2456 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2457 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2457, v_z_245});
    }
    case TAG_VDecode: {
      V v_h_27_2458 = heff_field(v_b_243, 0);
      V v_sp_27_2459 = heff_field(v_b_243, 1);
      heff_take_n(v_b_243, 3ULL, 5);
      heff_drop_tag(v_a_242, 5);
      V v_t_2463 = (g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095(v_g_240, v_cs_241, v_h_2450, v_sp_2451, v_h_27_2458, v_sp_27_2459));
      return heff_tail(v_t_2463, 2, (V[]){v_z_244, v_z_245});
    }
    case TAG_VFunction: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2470 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2471 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2471, v_z_245});
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2476 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2477 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2477, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2479 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2480 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2480, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2481 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2482 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2482, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2483 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2484 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2484, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2485 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2486 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2485})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2486, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2487 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2488 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2487})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2488, v_z_245});
    }
    case TAG_VPrimArray: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2490 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2491 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2491, v_z_245});
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2493 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2494 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2493})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2494, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VFunction: {
    V v_level_2495 = heff_dup(heff_field(v_a_242, 0));
    V v_dom_2496 = heff_dup(heff_field(v_a_242, 1));
    V v_cod_2497 = heff_dup(heff_field(v_a_242, 2));
    V v_implicit_2498 = heff_dup(heff_field(v_a_242, 3));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24102 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24103 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24102})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24103, v_z_245});
    }
    case TAG_VDecode: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24109 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24110 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24109})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24110, v_z_245});
    }
    case TAG_VFunction: {
      V v_level_27_24111 = heff_dup(heff_field(v_b_243, 0));
      V v_dom_27_24112 = heff_dup(heff_field(v_b_243, 1));
      V v_cod_27_24113 = heff_dup(heff_field(v_b_243, 2));
      V v_implicit_27_24114 = heff_dup(heff_field(v_b_243, 3));
      V v_t_24117 = ({ V a_0 = v_level_2495; V a_1 = v_level_27_24111; V r_ = (g_heff_2eelab_2eparams_2eeqLevel(a_0, a_1)); heff_drop(v_level_2495); heff_drop(v_level_27_24111); r_; });
      V v_t_24118;
      if ((heff_dup(v_t_24117) == NTAG(TAG_True))) {
        heff_drop(v_t_24117);
        switch (heff_tag_of(v_implicit_2498)) {
        case TAG_Expl: {
          switch (heff_tag_of(v_implicit_27_24114)) {
          case TAG_Expl: {
            v_t_24118 = NTAG(TAG_True);
            break;
          }
          case TAG_Impl: {
            v_t_24118 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_24118 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_24114);
          }
          break;
        }
        case TAG_Impl: {
          switch (heff_tag_of(v_implicit_27_24114)) {
          case TAG_Expl: {
            v_t_24118 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_24118 = NTAG(TAG_True);
            break;
          }
          case TAG_Inst: {
            v_t_24118 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_24114);
          }
          break;
        }
        case TAG_Inst: {
          switch (heff_tag_of(v_implicit_27_24114)) {
          case TAG_Expl: {
            v_t_24118 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_24118 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_24118 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_implicit_27_24114);
          }
          break;
        }
        default: heff_nomatch(v_implicit_2498);
        }
      } else {
        heff_drop(v_implicit_2498);
        heff_drop(v_implicit_27_24114);
        heff_drop(v_t_24117);
        v_t_24118 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_24118) == NTAG(TAG_True))) {
        heff_drop_tag(v_a_242, 6);
        heff_drop_tag(v_b_243, 6);
        heff_drop(v_t_24118);
        HEFF_LAST return g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_dom_2496), v_dom_27_24112, heff_dup(v_z_244), heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam0, 1, 7, (V[]){v_cs_241, v_dom_2496, v_cod_2497, v_cod_27_24113, v_g_240, v_z_244, v_z_245}));
      } else {
        heff_drop(v_g_240);
        heff_drop(v_dom_2496);
        heff_drop(v_cod_2497);
        heff_drop(v_dom_27_24112);
        heff_drop(v_cod_27_24113);
        heff_drop(v_t_24118);
        V v_t_24150 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
        V v_t_24151 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24150})}));
        return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24151, v_z_245});
      }
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24156 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24157 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24156})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24157, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24159 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24160 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24159})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24160, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24161 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24162 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24161})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24162, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24163 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24164 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24163})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24164, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24165 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24166 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24165})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24166, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24167 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24168 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24167})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24168, v_z_245});
    }
    case TAG_VPrimArray: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24170 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24171 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24170})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24171, v_z_245});
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24173 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24174 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24173})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24174, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VRecord: {
    heff_drop(v_g_240);
    V v_t_24179 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
    V v_t_24180 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24179})}));
    return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24180, v_z_245});
  }
  case TAG_VSum: {
    heff_drop(v_g_240);
    V v_t_24182 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
    V v_t_24183 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24182})}));
    return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24183, v_z_245});
  }
  case TAG_VPrimInt: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24185 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24186 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24185})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24186, v_z_245});
    }
    case TAG_VDecode: {
      V v_t_24192 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24193 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24192})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24193, v_z_245});
    }
    case TAG_VFunction: {
      V v_t_24200 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24201 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24200})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24201, v_z_245});
    }
    case TAG_VRecord: {
      V v_t_24206 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24207 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24206})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24207, v_z_245});
    }
    case TAG_VSum: {
      V v_t_24209 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24210 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24209})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24210, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_VPrimFloat: {
      V v_t_24211 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24212 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24211})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24212, v_z_245});
    }
    case TAG_VPrimString: {
      V v_t_24213 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24214 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24213})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24214, v_z_245});
    }
    case TAG_VPrimRune: {
      V v_t_24215 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24216 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24215})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24216, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_t_24218 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24219 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24218})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24219, v_z_245});
    }
    case TAG_VFixed: {
      V v_t_24221 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24222 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24221})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24222, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimFloat: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24224 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24225 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24224})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24225, v_z_245});
    }
    case TAG_VDecode: {
      V v_t_24231 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24232 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24231})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24232, v_z_245});
    }
    case TAG_VFunction: {
      V v_t_24239 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24240 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24239})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24240, v_z_245});
    }
    case TAG_VRecord: {
      V v_t_24245 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24246 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24245})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24246, v_z_245});
    }
    case TAG_VSum: {
      V v_t_24248 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24249 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24248})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24249, v_z_245});
    }
    case TAG_VPrimInt: {
      V v_t_24250 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24251 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24250})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24251, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_VPrimString: {
      V v_t_24252 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24253 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24252})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24253, v_z_245});
    }
    case TAG_VPrimRune: {
      V v_t_24254 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24255 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24254})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24255, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_t_24257 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24258 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24257})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24258, v_z_245});
    }
    case TAG_VFixed: {
      V v_t_24260 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24261 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24260})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24261, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimString: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24263 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24264 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24263})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24264, v_z_245});
    }
    case TAG_VDecode: {
      V v_t_24270 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24271 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24270})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24271, v_z_245});
    }
    case TAG_VFunction: {
      V v_t_24278 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24279 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24278})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24279, v_z_245});
    }
    case TAG_VRecord: {
      V v_t_24284 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24285 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24284})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24285, v_z_245});
    }
    case TAG_VSum: {
      V v_t_24287 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24288 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24287})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24288, v_z_245});
    }
    case TAG_VPrimInt: {
      V v_t_24289 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24290 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24289})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24290, v_z_245});
    }
    case TAG_VPrimFloat: {
      V v_t_24291 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24292 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24291})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24292, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_VPrimRune: {
      V v_t_24293 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24294 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24293})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24294, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_t_24296 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24297 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24296})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24297, v_z_245});
    }
    case TAG_VFixed: {
      V v_t_24299 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24300 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24299})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24300, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimRune: {
    heff_drop(v_g_240);
    V v_t_24320;
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    case TAG_VFunction: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24320 = NTAG(TAG_True);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_b_243);
    }
    if ((heff_dup(v_t_24320) == NTAG(TAG_True))) {
      heff_drop_rec(v_cs_241, 2);
      heff_drop(v_b_243);
      heff_drop_rec(v_z_244, 3);
      heff_drop(v_t_24320);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    } else {
      heff_drop(v_t_24320);
      V v_t_24321 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24322 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24321})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24322, v_z_245});
    }
  }
  case TAG_VPrimArray: {
    V v_x_24323 = heff_dup(heff_field(v_a_242, 0));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24325 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24326 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24325})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24326, v_z_245});
    }
    case TAG_VDecode: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24332 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24333 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24332})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24333, v_z_245});
    }
    case TAG_VFunction: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24340 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24341 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24340})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24341, v_z_245});
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24346 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24347 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24346})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24347, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24349 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24350 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24349})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24350, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24351 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24352 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24351})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24352, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24353 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24354 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24353})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24354, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24355 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24356 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24355})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24356, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24357 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24358 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24357})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24358, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_y_24359 = heff_field(v_b_243, 0);
      heff_take_n(v_b_243, 1ULL, 1);
      heff_drop_tag(v_a_242, 1);
      HEFF_LAST return g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(v_g_240, v_cs_241, v_x_24323, v_y_24359, v_z_244, v_z_245);
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24361 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24362 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24361})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24362, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VFixed: {
    V v_w_24363 = heff_dup(heff_field(v_a_242, 0));
    heff_drop(v_g_240);
    V v_t_24364 = ({ V a_0 = v_w_24363; V a_1 = v_b_243; V r_ = (g_heff_2eelab_2evalue_2eisFixed(a_0, a_1)); heff_drop(v_w_24363); r_; });
    if ((heff_dup(v_t_24364) == NTAG(TAG_True))) {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_tag(v_a_242, 1);
      heff_drop(v_b_243);
      heff_drop_rec(v_z_244, 3);
      heff_drop(v_t_24364);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    } else {
      heff_drop(v_t_24364);
      V v_t_24365 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24366 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24365})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24366, v_z_245});
    }
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam1(V self, V *args) {
  V v_u_24121 = args[0];
  V v_dom_2496 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24121);
  return v_dom_2496;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam2(V self, V *args) {
  V v_w_24126 = args[0];
  V v_v_24122 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24126);
  return v_v_24122;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam3(V self, V *args) {
  V v_w_24136 = args[0];
  V v_v_24122 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24136);
  return v_v_24122;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam0(V self, V *args) {
  V v_x_24119 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_dom_2496 = heff_env(self)[1];
  V v_cod_2497 = heff_env(self)[2];
  V v_cod_27_24113 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_24119);
  V v_t_24120 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_cs_241, 0))});
  V v_v_24122 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(v_t_24120, heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam1, 1, 1, (V[]){v_dom_2496}), NTAG(TAG_Nothing)));
  V v_x1_24128;
  switch (heff_tag_of(v_cod_2497)) {
  case TAG_MkClo: {
    V v_vs_24124 = heff_dup(heff_field(v_cod_2497, 1));
    V v_body_24125 = heff_dup(heff_field(v_cod_2497, 2));
    v_x1_24128 = heff_tr(heff_call(v_body_24125, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_24124, heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam2, 1, 1, (V[]){heff_dup(v_v_24122)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24127 = heff_dup(heff_field(v_cod_2497, 0));
    v_x1_24128 = v_body_24127;
    break;
  }
  default: heff_nomatch(v_cod_2497);
  }
  V v_a_24132;
  switch (heff_tag_of(v_x1_24128)) {
  case TAG_Nom: {
    V v_x_24129 = heff_field(v_x1_24128, 0);
    heff_take_n(v_x1_24128, 1ULL, 1);
    v_a_24132 = v_x_24129;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24128, 0ULL, 1);
    v_a_24132 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24131 = heff_field(v_x1_24128, 0);
    heff_take_n(v_x1_24128, 1ULL, 1);
    v_a_24132 = v_x_24131;
    break;
  }
  default: heff_nomatch(v_x1_24128);
  }
  V v_x1_24138;
  switch (heff_tag_of(v_cod_27_24113)) {
  case TAG_MkClo: {
    V v_vs_24134 = heff_field(v_cod_27_24113, 1);
    V v_body_24135 = heff_field(v_cod_27_24113, 2);
    heff_take_n(v_cod_27_24113, 6ULL, 3);
    v_x1_24138 = heff_tr(heff_call(v_body_24135, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_24134, heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam3, 1, 1, (V[]){v_v_24122})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24137 = heff_field(v_cod_27_24113, 0);
    heff_take_n(v_cod_27_24113, 1ULL, 1);
    heff_drop(v_v_24122);
    v_x1_24138 = v_body_24137;
    break;
  }
  default: heff_nomatch(v_cod_27_24113);
  }
  V v_b_24142;
  switch (heff_tag_of(v_x1_24138)) {
  case TAG_Nom: {
    V v_x_24139 = heff_field(v_x1_24138, 0);
    heff_take_n(v_x1_24138, 1ULL, 1);
    v_b_24142 = v_x_24139;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24138, 0ULL, 1);
    v_b_24142 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24141 = heff_field(v_x1_24138, 0);
    heff_take_n(v_x1_24138, 1ULL, 1);
    v_b_24142 = v_x_24141;
    break;
  }
  default: heff_nomatch(v_x1_24138);
  }
  V v_t_24143 = heff_intAdd(heff_take_field(v_cs_241, 0), MK_INT(1LL));
  V v_t_24148;
  switch (heff_tag_of(v_cod_2497)) {
  case TAG_MkClo: {
    V v_n_24144 = heff_field(v_cod_2497, 0);
    heff_take_n(v_cod_2497, 1ULL, 3);
    v_t_24148 = v_n_24144;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2497, 0ULL, 1);
    v_t_24148 = ((V)&g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_str0);
    break;
  }
  default: heff_nomatch(v_cod_2497);
  }
  V v_t_24149 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24148, heff_get_n(v_cs_241, 1, 2)});
  return (g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(v_g_240, heff_rec_n(2, shape_len__names, (V[]){v_t_24143, v_t_24149}), v_a_24132, v_b_24142, v_z_244, v_z_245));
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam6(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_245 = heff_field(v_x6_244, 0);
    V v_l_246 = heff_field(v_x6_244, 1);
    V v_f_247 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_248 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), MK_INT(1LL));
    V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 1)), MK_INT(1LL));
    V v_t_2410 = (g_std_2emap_2einsert_24s170109517x1206653089(heff_take_field(v_pr_242, 2), heff_dup(heff_rfield(v_pr_242, 0)), heff_take_field(v_pr_242, 1)));
    V v_pr_2411 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_248, v_t_249, v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_pr_242, 0, 3)});
    V v_v_2414 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(v_t_2412, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_v_2416 = heff_tr(heff_call(v_f_247, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_246, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam1, 1, 1, (V[]){v_v_2414})})}));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam2, 2, 5, (V[]){v_v_2416, v_g_240, v_m_241, v_pr_2411, v_x_245});
  }
  case TAG_CloConst: {
    V v_t_2427 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam6, 2, 4, (V[]){v_t_2427, v_g_240, v_m_241, v_pr_242});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_dom_243;
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_v_2414;
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2411 = heff_env(self)[2];
  V v_v_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(v_g_240, v_m_241, v_pr_2411, v_v_2421, v_hd_2422, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam4, 1, 1, (V[]){v_k_2423})));
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_245, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_v_2416 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_2411 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2425;
  switch (heff_tag_of(v_v_2416)) {
  case TAG_Nom: {
    V v_v_2419 = heff_field(v_v_2416, 0);
    heff_take_n(v_v_2416, 1ULL, 1);
    v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2419}));
    break;
  }
  case TAG_Describe: {
    V v_v_2420 = heff_field(v_v_2416, 0);
    heff_take_n(v_v_2416, 1ULL, 1);
    v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2420}));
    break;
  }
  case TAG_Become: {
    V v_v_2421 = heff_field(v_v_2416, 0);
    heff_take_n(v_v_2416, 1ULL, 1);
    v_t_2425 = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam3, 2, 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2421});
    break;
  }
  default: heff_nomatch(v_v_2416);
  }
  V f_ = v_t_2425;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam5, 1, 2, (V[]){v_k_2418, v_x_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam8(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2434;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam7(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_v_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(v_g_240, v_m_241, v_pr_242, v_v_2432, v_hd_2433, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam8, 1, 1, (V[]){v_k_2434})));
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2429;
  args[0] = heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam6(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_t_2427 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2436;
  switch (heff_tag_of(v_t_2427)) {
  case TAG_Nom: {
    V v_v_2430 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2430}));
    break;
  }
  case TAG_Describe: {
    V v_v_2431 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2431}));
    break;
  }
  case TAG_Become: {
    V v_v_2432 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam7, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2432});
    break;
  }
  default: heff_nomatch(v_t_2427);
  }
  V f_ = v_t_2436;
  args[0] = v_hd_2428;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam9, 1, 1, (V[]){v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam15(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam14(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam17(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(V v_g_240, V v_m_241, V v_pr_242, V v_t0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam0, 1, 1, (V[]){v_t0_243})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam1, 1, 5, (V[]){v_k_245, v_pr_242, v_hd_244, v_g_240, v_m_241})});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_t0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_t0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2419 = (g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2418));
  V f_ = v_c_2419;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam3, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2424 = (g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2423));
  V f_ = v_c_2424;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam5, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2431});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam8(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2434 = (g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2433));
  V f_ = v_c_2434;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam8, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam10(V self, V *args) {
  V v_x_2444 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_level_2436 = heff_env(self)[1];
  V v_x_2442 = heff_env(self)[2];
  V v_implicit_2439 = heff_env(self)[3];
  V v_dflt_2440 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SFunction, 5, (V[]){v_level_2436, v_x_2442, v_x_2444, v_implicit_2439, v_dflt_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam9(V self, V *args) {
  V v_x_2442 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_dom_2437 = heff_env(self)[3];
  V v_cod_2438 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_level_2436 = heff_env(self)[7];
  V v_implicit_2439 = heff_env(self)[8];
  V v_dflt_2440 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2443 = (g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735(v_g_240, v_m_241, v_pr_242, v_dom_2437, v_cod_2438));
  V f_ = v_c_2443;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam10, 1, 5, (V[]){v_k_245, v_level_2436, v_x_2442, v_implicit_2439, v_dflt_2440});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam11(V self, V *args) {
  V v_x_2451 = args[0];
  V v_fieldTypes_2447 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_level_2445 = heff_env(self)[2];
  V v_defaults_2448 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2452 = ({ V rv_2 = heff_arrayFromList(v_x_2451); V rr_ = heff_rec_reuse_nf(v_fieldTypes_2447, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SRecord, 3, (V[]){v_level_2445, v_t_2452, v_defaults_2448});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam13(V self, V *args) {
  V v_a_2460 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2461 = heff_tr(heff_call(v_a_2460, 1, (V[]){NTAG(TAG_MkUnit)}));
  V f_ = ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo);
  heff_room[0] = v_g_240;
  heff_room[1] = v_m_241;
  heff_room[2] = v_pr_242;
  heff_room[3] = v_t_2461;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam15(V self, V *args) {
  V v_x_2465 = args[0];
  V v_k_2458 = heff_env(self)[0];
  V v_k_2464 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2466 = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2458, heff_arrayFromList(v_x_2465)});
  V f_ = v_k_2464;
  args[0] = v_t_2466;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam14(V self, V *args) {
  V v_hd_2463 = args[0];
  V v_k_2464 = args[1];
  V v_c_2462 = heff_env(self)[0];
  V v_k_2458 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2462;
  args[0] = v_hd_2463;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam15, 1, 2, (V[]){v_k_2458, v_k_2464});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam12(V self, V *args) {
  V v_p_2457 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2457)) {
  case TAG_MkPair: {
    V v_k_2458 = heff_field(v_p_2457, 0);
    V v_args_2459 = heff_field(v_p_2457, 1);
    heff_take_n(v_p_2457, 3ULL, 2);
    V v_c_2462 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam13, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), heff_arrayToList(v_args_2459)));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam14, 2, 2, (V[]){v_c_2462, v_k_2458});
  }
  default: return heff_nomatch(v_p_2457);
  }
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam16(V self, V *args) {
  V v_x_2468 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2468)));
  V v_t_2470 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2468));
  V v_t_2471 = (g_list_2emap_24s1173914895x100384474(v_x_2468));
  V v_t_2472 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2469), v_t_2470, heff_arrayFromList(v_t_2471)});
  V v_x_2473 = heff_tag_n(TAG_SSum, 1, (V[]){v_t_2472});
  V f_ = v_k_245;
  args[0] = v_x_2473;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam17(V self, V *args) {
  V v_x_2475 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SPrimArray, 1, (V[]){v_x_2475});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_249)) {
  case TAG_VU: {
    V v_u_2410 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_SU, 1, (V[]){v_u_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VDecode: {
    V v_it1_2411 = heff_field(v_x_249, 0);
    V v_sp_2412 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 5);
    switch (heff_tag_of(v_it1_2411)) {
    case TAG_HLocal: {
      V v_c_2417 = (g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(heff_dup(v_pr_242), v_it1_2411));
      V f_ = v_c_2417;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HGlobal: {
      V v_c_2422 = (g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(heff_dup(v_pr_242), v_it1_2411));
      V f_ = v_c_2422;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HMeta: {
      V v_m_27_2426 = heff_field(v_it1_2411, 0);
      V v_ru_24it1_2411_24HMeta = heff_take_reuse_n(v_it1_2411, 1ULL, 1);
      if (heff_intEq_c_lent(v_m_27_2426, v_m_241, 0)) {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2412);
        heff_drop(v_m_27_2426);
        V v_t_2428 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2429 = heff_tag_at_n(v_ru_24it1_2411_24HMeta, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2428})});
        V v_t_2430 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2429}));
        V f_ = heff_get_n(v_hd_244, 1, 3);
        heff_room[0] = v_t_2430;
        heff_room[1] = v_k_245;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_cell(v_ru_24it1_2411_24HMeta, 1);
        return (g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338(v_g_240, v_m_241, v_pr_242, v_m_27_2426, v_sp_2412, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam6, 1, 1, (V[]){v_k_245})));
      }
    }
    case TAG_HError: {
      V v_c_2432 = (g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(heff_dup(v_pr_242), v_it1_2411));
      V f_ = v_c_2432;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam7, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_it1_2411);
    }
  }
  case TAG_VFunction: {
    V v_level_2436 = heff_field(v_x_249, 0);
    V v_dom_2437 = heff_field(v_x_249, 1);
    V v_cod_2438 = heff_field(v_x_249, 2);
    V v_implicit_2439 = heff_field(v_x_249, 3);
    V v_dflt_2440 = heff_field(v_x_249, 4);
    heff_take_n(v_x_249, 31ULL, 6);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), heff_dup(v_dom_2437), heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam9, 1, 10, (V[]){v_g_240, v_m_241, v_pr_242, v_dom_2437, v_cod_2438, v_hd_244, v_k_245, v_level_2436, v_implicit_2439, v_dflt_2440})));
  }
  case TAG_VRecord: {
    V v_level_2445 = heff_field(v_x_249, 0);
    V v_capture_2446 = heff_field(v_x_249, 1);
    V v_fieldTypes_2447 = heff_field(v_x_249, 2);
    V v_defaults_2448 = heff_field(v_x_249, 3);
    heff_take_n(v_x_249, 15ULL, 4);
    V v_t_2449 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2447, 2)));
    V v_c_2450 = (g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051(v_g_240, v_m_241, v_pr_242, MK_INT(0LL), v_capture_2446, v_t_2449));
    V f_ = v_c_2450;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam11, 1, 4, (V[]){v_fieldTypes_2447, v_k_245, v_level_2445, v_defaults_2448});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VSum: {
    V v_vs_2453 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2454 = heff_arrayToList(heff_take_field(v_vs_2453, 0));
    V v_t_2455 = heff_arrayToList(heff_get_n(v_vs_2453, 2, 3));
    V v_t_2456 = (g_heff_2eutil_2edict_2ezipKV(v_t_2454, v_t_2455));
    V v_c_2467 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam12, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2456));
    V f_ = v_c_2467;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam16, 1, 1, (V[]){v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VPrimInt: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimInt);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimFloat: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimFloat);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimString: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimString);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimRune: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimRune);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimArray: {
    V v_a_2474 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(v_g_240, v_m_241, v_pr_242, v_a_2474, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam17, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VFixed: {
    V v_w_2476 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_SFixed, 1, (V[]){v_w_2476});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam5(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam5, 2, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam12(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam12, 1, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam14(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam14, 2, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam15(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam7(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_entry, 7, 0};

V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(V v_g_240, V v_cs_241, V v_m_242, V v_args_243, V v_rhs_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_243));
  V v_t_248 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(MK_INT(0LL), heff_dup(v_args_243)));
  V v_t_249 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s868530262x539343671(a_0, a_1)); heff_drop(v_t_248); r_; });
  V v_pr_2410 = heff_rec_n(3, shape_dom__cod__ren, (V[]){heff_get_n(v_cs_241, 0, 2), v_t_247, v_t_249});
  V v_t_2412 = heff_tr(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(heff_dup(v_g_240), heff_dup(v_m_242), v_pr_2410, v_rhs_244, heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam0, 1, 1, (V[]){heff_dup(v_z_245)})));
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2412, heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam1, 1, 1, (V[]){heff_dup(v_z_245)})})});
  V v_t_2446 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2445}));
  return heff_tail(heff_dup(heff_rfield(v_z_245, 1)), 2, (V[]){v_t_2446, heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam7, 1, 5, (V[]){v_z_246, v_args_243, v_g_240, v_m_242, v_z_245})});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_z_245, 0, 3);
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k2_2418 = args[1];
  V v_s_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2413})});
  V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_2417, 2), 1, (V[]){v_t_2419}));
  V f_ = heff_get_n(v_hd_2417, 1, 3);
  args[0] = v_t_2420;
  args[1] = v_k2_2418;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam3(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_s_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2413})});
  V v_t_2427 = heff_tr(heff_call(heff_take_field(v_hd_2424, 2), 1, (V[]){v_t_2426}));
  V f_ = heff_get_n(v_hd_2424, 1, 3);
  args[0] = v_t_2427;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam4(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k2_2434 = args[1];
  V v_s_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2413})});
  V v_t_2436 = heff_tr(heff_call(heff_take_field(v_hd_2433, 2), 1, (V[]){v_t_2435}));
  V f_ = heff_get_n(v_hd_2433, 1, 3);
  args[0] = v_t_2436;
  args[1] = v_k2_2434;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam5(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  heff_drop(v_hd_2437);
  V f_ = v_k_2438;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam6(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k2_2441 = args[1];
  V v_s_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2413})});
  V v_t_2443 = heff_tr(heff_call(heff_take_field(v_hd_2440, 2), 1, (V[]){v_t_2442}));
  V f_ = heff_get_n(v_hd_2440, 1, 3);
  args[0] = v_t_2443;
  args[1] = v_k2_2441;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam1(V self, V *args) {
  V v_s_2413 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2444;
  switch (heff_tag_of(v_s_2413)) {
  case TAG_UnequalTys: {
    v_t_2444 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam2, 2, 1, (V[]){v_s_2413});
    break;
  }
  case TAG_UnequalEls: {
    v_t_2444 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam3, 2, 1, (V[]){v_s_2413});
    break;
  }
  case TAG_UnequalNeus: {
    v_t_2444 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam4, 2, 1, (V[]){v_s_2413});
    break;
  }
  case TAG_MentionsError: {
    v_t_2444 = ((V)&g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam5_clo);
    break;
  }
  case TAG_Escapes: {
    v_t_2444 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam6, 2, 1, (V[]){v_s_2413});
    break;
  }
  default: heff_nomatch(v_s_2413);
  }
  V f_ = v_t_2444;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_get_n(v_z_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam9(V self, V *args) {
  V v_c_2457 = args[0];
  V v_m_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2458 = ({ V b_0 = heff_get_n(v_c_2457, 2, 8); V a_1 = v_m_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2460 = v_t_2458.f[1];
    int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2459 == ((int64_t)0ULL)) && ({ V v_x_2462 = heff_dup(v_field_2460); int c_ = 1; heff_drop(v_x_2462); c_; })));
    heff_drop(v_field_2460);
    return v_ret_24bool;
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam12(V self, V *args) {
  V v_c_2468 = args[0];
  return heff_get_n(v_c_2468, 3, 8);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam13(V self, V *args) {
  V v_x_2471 = args[0];
  V v_v_2455 = heff_env(self)[0];
  V v_hd_2466 = heff_env(self)[1];
  V v_k_2467 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2472 = ({ V a_0 = v_x_2471; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2471); r_; });
  V v_t_2473 = heff_tr(heff_call(heff_get_n(v_t_2472, 0, 3), 3, (V[]){MK_INT(20LL), MK_INT(0LL), v_v_2455}));
  return ({ V a_0 = v_t_2473; V a_1 = v_hd_2466; V a_2 = v_k_2467; V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(a_0, a_1, a_2)); heff_drop(v_t_2473); r_; });
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam11(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k_2467 = args[1];
  V v_v_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam12_clo)})});
  V v_t_2470 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2466, 2)), 1, (V[]){v_t_2469}));
  V f_ = heff_dup(heff_rfield(v_hd_2466, 1));
  args[0] = v_t_2470;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam13, 1, 3, (V[]){v_v_2455, v_hd_2466, v_k_2467});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam14(V self, V *args) {
  V v_hd_2474 = args[0];
  V v_k_2475 = args[1];
  heff_drop(v_hd_2474);
  V f_ = v_k_2475;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam15(V self, V *args) {
  V v_x_2477 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_t_2450 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2477);
  return (g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046(v_m_242, v_t_2450, v_z_245, v_z_246));
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam10(V self, V *args) {
  V v_x_2465 = args[0];
  V v_v_2455 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_m_242 = heff_env(self)[2];
  V v_t_2450 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2476;
  if ((heff_dup(v_x_2465) == NTAG(TAG_True))) {
    heff_drop(v_x_2465);
    v_t_2476 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam11, 2, 1, (V[]){v_v_2455});
  } else {
    heff_drop(v_x_2465);
    heff_drop(v_v_2455);
    v_t_2476 = ((V)&g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam14_clo);
  }
  V f_ = v_t_2476;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam15, 1, 4, (V[]){v_m_242, v_t_2450, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam8(V self, V *args) {
  V v_x_2456 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_v_2455 = heff_env(self)[2];
  V v_t_2450 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2456);
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam9, 1, 1, (V[]){heff_dup(v_m_242)})})});
  V v_t_2464 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2463}));
  V f_ = heff_dup(heff_rfield(v_z_245, 1));
  heff_room[0] = v_t_2464;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam10, 1, 5, (V[]){v_v_2455, v_z_245, v_m_242, v_t_2450, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam7(V self, V *args) {
  V v_x_2447 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_args_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2447)) {
  case TAG_Nothing: {
    heff_drop(v_args_243);
    heff_drop(v_g_240);
    heff_drop(v_m_242);
    heff_drop_rec(v_z_245, 3);
    V f_ = v_z_246;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_body_2448 = heff_field(v_x_2447, 0);
    heff_take_n(v_x_2447, 1ULL, 1);
    V v_t_2449 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_243); r_; });
    V v_t_2450 = (g_heff_2eelab_2eunify_2elamsU(v_t_2449, v_body_2448));
    V v_x1_2451 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_N), heff_dup(v_t_2450), NTAG(TAG_LNil)));
    V v_v_2455;
    switch (heff_tag_of(v_x1_2451)) {
    case TAG_Nom: {
      V v_x_2452 = heff_field(v_x1_2451, 0);
      heff_take_n(v_x1_2451, 1ULL, 1);
      v_v_2455 = v_x_2452;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2451, 0ULL, 1);
      v_v_2455 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2454 = heff_field(v_x1_2451, 0);
      heff_take_n(v_x1_2451, 1ULL, 1);
      v_v_2455 = v_x_2454;
      break;
    }
    default: heff_nomatch(v_x1_2451);
    }
    return (g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531(heff_dup(v_m_242), heff_dup(v_v_2455), heff_dup(v_t_2450), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam8, 1, 5, (V[]){v_m_242, v_z_245, v_v_2455, v_t_2450, v_z_246})));
  }
  default: return heff_nomatch(v_x_2447);
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam0, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam2, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam6(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam6, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_entry, 8, 0};

V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577(V v_g_240, V v_cs_241, V v_m_242, V v_sp_243, V v_rhs_244, V v_self_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam0_clo)})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam1, 1, 8, (V[]){v_hd_246, v_sp_243, v_rhs_244, v_g_240, v_cs_241, v_m_242, v_k_247, v_self_245})});
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get_n(v_c_248, 3, 8);
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam2(V self, V *args) {
  V v_c_2412 = args[0];
  return heff_get_n(v_c_2412, 7, 8);
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam5(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2450);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam4(V self, V *args) {
  V v_x_2445 = args[0];
  V v_args_2423 = heff_env(self)[0];
  V v_args_27_2440 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2446 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2423));
  V v_t_2447 = (g_heff_2eelab_2eunify_2ezipL(v_args_2423, v_args_27_2440));
  V v_t_2448 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876(MK_INT(0LL), v_t_2447));
  V v_t_2449 = (g_heff_2eelab_2eunify_2ecatMaybes(v_t_2448));
  return (g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050(v_g_240, heff_dup(v_m_242), v_m_242, v_x_2445, v_t_2446, v_t_2449, v_hd_246, heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam5, 1, 1, (V[]){v_k_247})));
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam6(V self, V *args) {
  V v_c_2452 = args[0];
  return heff_get_n(v_c_2452, 3, 8);
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam7(V self, V *args) {
  V v_x_2455 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_k_2451 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2456 = ({ V a_0 = v_x_2455; V a_1 = v_m_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(a_0, a_1)); heff_drop(v_x_2455); r_; });
  {
    V v_field_2458 = v_t_2456.f[1];
    int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
    if ((v_tag_2457 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_246, 3);
      V v_e_2460 = v_field_2458;
      V f_ = v_k_2451;
      args[0] = v_e_2460;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2458);
      V v_t_2461 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2462 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2461})});
      V v_t_2463 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2462}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_2463;
      heff_room[1] = v_k_2451;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_rhs_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  V v_m_242 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  V v_self_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  HeffT2 v_t_2416 = (g_heff_2eelab_2eunify_2epatSpine_24cpr(v_x_2415, v_x_2411, v_sp_243));
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_items_2420 = v_field_2418;
      V v_t_2421 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2420)));
      V v_t_2422 = ({ V a_0 = v_t_2421; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2421); r_; });
      if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
        heff_drop(v_t_2422);
        V v_args_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2420));
        switch (heff_tag_of(v_rhs_244)) {
        case TAG_VNeu: {
          V v_v1_2424 = heff_dup(heff_field(v_rhs_244, 0));
          V v_sp_2425 = heff_dup(heff_field(v_rhs_244, 1));
          switch (heff_tag_of(v_v1_2424)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_2424, 0ULL, 1);
            heff_drop(v_x_2415);
            heff_drop(v_x_2411);
            heff_drop(v_self_245);
            heff_drop(v_sp_2425);
            return (g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_2424, 0ULL, 1);
            heff_drop(v_x_2415);
            heff_drop(v_x_2411);
            heff_drop(v_self_245);
            heff_drop(v_sp_2425);
            return (g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
          }
          case TAG_HMeta: {
            V v_m_2431 = heff_field(v_v1_2424, 0);
            V v_ru_24v1_2424_24HMeta = heff_take_reuse_n(v_v1_2424, 1ULL, 1);
            if (heff_intEq_c_lent(v_m_2431, v_m_242, 1)) {
              HeffT2 v_t_2433 = ({ V a_0 = v_x_2415; V a_1 = v_x_2411; V a_2 = v_sp_2425; HeffT2 r_ = (g_heff_2eelab_2eunify_2epatSpine_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2415); heff_drop(v_x_2411); r_; });
              {
                V v_field_2435 = v_t_2433.f[1];
                int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
                if ((v_tag_2434 == ((int64_t)0ULL))) {
                  V v_items_2437 = v_field_2435;
                  V v_t_2438 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2437)));
                  V v_t_2439 = ({ V a_0 = v_t_2438; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2438); r_; });
                  if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
                    heff_drop(v_t_2439);
                    V v_args_27_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2437));
                    V v_t_2441 = (g_heff_2eelab_2eunify_2eeqPatArgs(v_args_27_2440, v_args_2423));
                    if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
                      heff_drop_tag(v_rhs_244, 5);
                      heff_drop(v_g_240);
                      heff_drop(v_cs_241);
                      heff_drop(v_m_242);
                      heff_drop_rec(v_hd_246, 3);
                      heff_drop(v_self_245);
                      heff_drop(v_args_2423);
                      heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
                      heff_drop(v_args_27_2440);
                      heff_drop(v_t_2441);
                      V f_ = v_k_247;
                      args[0] = NTAG(TAG_MkUnit);
                      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                      return heff_tail(f_, 1, args);
                    } else {
                      heff_drop(v_t_2441);
                      V v_t_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_27_2440));
                      V v_t_2443 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2423));
                      if (heff_intEq_c(v_t_2442, v_t_2443)) {
                        heff_drop_tag(v_rhs_244, 5);
                        heff_drop(v_cs_241);
                        heff_drop(v_self_245);
                        V v_k_2451 = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam4, 1, 6, (V[]){v_args_2423, v_args_27_2440, v_g_240, heff_dup(v_m_242), heff_dup(v_hd_246), v_k_247});
                        V v_t_2453 = heff_tag_at_n(v_ru_24v1_2424_24HMeta, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam6_clo)})});
                        V v_t_2454 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2453}));
                        V f_ = heff_dup(heff_rfield(v_hd_246, 1));
                        heff_room[0] = v_t_2454;
                        heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam7, 1, 3, (V[]){v_m_242, v_k_2451, v_hd_246});
                        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
                      } else {
                        heff_drop(v_g_240);
                        heff_drop(v_m_242);
                        heff_drop(v_args_2423);
                        heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
                        heff_drop(v_args_27_2440);
                        return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
                      }
                    }
                  } else {
                    heff_drop(v_g_240);
                    heff_drop(v_m_242);
                    heff_drop(v_args_2423);
                    heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
                    heff_drop(v_items_2437);
                    heff_drop(v_t_2439);
                    return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
                  }
                } else {
                  heff_drop(v_g_240);
                  heff_drop(v_m_242);
                  heff_drop(v_args_2423);
                  heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
                  heff_drop(v_field_2435);
                  return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
                }
              }
            } else {
              heff_drop(v_x_2415);
              heff_drop(v_x_2411);
              heff_drop(v_self_245);
              heff_drop(v_sp_2425);
              heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
              return (g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
            }
          }
          case TAG_HError: {
            heff_drop(v_x_2415);
            heff_drop(v_x_2411);
            heff_drop(v_self_245);
            heff_drop(v_sp_2425);
            return (g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
          }
          default: return heff_nomatch(v_v1_2424);
          }
        }
        case TAG_VCode: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
        }
        case TAG_VLam: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
        }
        case TAG_VCons: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
        }
        case TAG_VOpaque: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
        }
        default: return heff_nomatch(v_rhs_244);
        }
      } else {
        heff_drop(v_x_2415);
        heff_drop(v_x_2411);
        heff_drop(v_g_240);
        heff_drop(v_m_242);
        heff_drop(v_items_2420);
        heff_drop(v_t_2422);
        return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
      }
    } else {
      heff_drop(v_x_2415);
      heff_drop(v_x_2411);
      heff_drop(v_g_240);
      heff_drop(v_m_242);
      heff_drop(v_field_2418);
      return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
    }
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_rhs_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  V v_m_242 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_self_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam2_clo)})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2413}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam3, 1, 9, (V[]){v_x_2411, v_sp_243, v_rhs_244, v_g_240, v_cs_241, v_m_242, v_hd_246, v_k_247, v_self_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}