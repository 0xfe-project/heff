// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"

static V g_heff_2einterp_2edeepest_val;
static int g_heff_2einterp_2edeepest_st;
static V g_heff_2einterp_2edeepest_init(void) {
  return MK_INT(1000000LL);
}
V g_heff_2einterp_2edeepest_get(void) {
  if (g_heff_2einterp_2edeepest_st == 2) return g_heff_2einterp_2edeepest_val;
  if (g_heff_2einterp_2edeepest_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2edeepest_st = 1;
  g_heff_2einterp_2edeepest_val = heff_tr(g_heff_2einterp_2edeepest_init());
  g_heff_2einterp_2edeepest_st = 2;
  return g_heff_2einterp_2edeepest_val;
}
Clo g_heff_2einterp_2eprojV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprojV_entry, 2, 0};

V g_heff_2einterp_2eprojV(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_take(v_x1_240, 0ULL);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VCons: {
    V v_fs_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24VCons = heff_take_reuse(v_x1_240, 1ULL);
    V v_t_244 = ({ V a_0 = v_x2_241; V b_1 = heff_get(heff_dup(v_fs_243), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2410;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop(v_fs_243);
      heff_drop(v_t_244);
      v_t_2410 = heff_abandon();
      break;
    }
    case TAG_Just: {
      V v_i_245 = heff_field(v_t_244, 0);
      heff_take(v_t_244, 1ULL);
      V v_xs_246 = heff_get(v_fs_243, LBL_values);
      V v_t_247 = heff_intLe(MK_INT(0LL), heff_dup(v_i_245));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_t_247);
        V v_t_248 = heff_intLt(heff_dup(v_i_245), heff_arrayLength(heff_dup(v_xs_246)));
        switch (heff_tag_of(v_t_248)) {
        case TAG_True: {
          heff_drop(v_t_248);
          V v_v_249 = heff_arrayIndex(v_xs_246, v_i_245);
          v_t_2410 = v_v_249;
          break;
        }
        case TAG_False: {
          heff_drop(v_i_245);
          heff_drop(v_xs_246);
          heff_drop(v_t_248);
          v_t_2410 = heff_abandon();
          break;
        }
        default: heff_nomatch(v_t_248);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_i_245);
        heff_drop(v_xs_246);
        heff_drop(v_t_247);
        v_t_2410 = heff_abandon();
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    return heff_tag_at(v_ru_24x1_240_24VCons, TAG_Ok, 1, (V[]){v_t_2410});
  }
  case TAG_VTag: {
    heff_take(v_x1_240, 0ULL);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VInt: {
    heff_take(v_x1_240, 0ULL);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VFloat: {
    heff_take(v_x1_240, 0ULL);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VStr: {
    heff_take(v_x1_240, 0ULL);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VArr: {
    heff_take(v_x1_240, 0ULL);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VErased: {
    heff_drop(v_x1_240);
    heff_drop(v_x2_241);
    return heff_tag(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2eprojV_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eprojV(a[0], a[1]);
}
Clo g_heff_2einterp_2esetAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2esetAt_entry, 3, 0};

V g_heff_2einterp_2esetAt(V v_x1_240, V v_i_241, V v_x_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    heff_drop(v_i_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x1_240, 0);
    V v_ys_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_245 = heff_intEq(heff_dup(v_i_241), MK_INT(0LL));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_i_241);
      heff_drop(v_y_243);
      heff_drop(v_t_245);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_ys_244});
    }
    case TAG_False: {
      heff_drop(v_t_245);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_y_243, (g_heff_2einterp_2esetAt(v_ys_244, heff_intSub(v_i_241, MK_INT(1LL)), v_x_242))});
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2esetAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2esetAt(a[0], a[1], a[2]);
}
V g_heff_2einterp_2egenGo_lam0(V self, V *args);
V g_heff_2einterp_2egenGo_lam1(V self, V *args);
Clo g_heff_2einterp_2egenGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2egenGo_entry, 5, 0};

V g_heff_2einterp_2egenGo(V v_d_240, V v_j_241, V v_n_242, V v_f_243, V v_k_244) {
top: ;
  V v_t_245 = heff_intLe(heff_dup(v_n_242), heff_dup(v_j_241));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_d_240);
    heff_drop(v_j_241);
    heff_drop(v_n_242);
    heff_drop(v_f_243);
    heff_drop(v_t_245);
    return heff_tail(v_k_244, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_False: {
    heff_drop(v_t_245);
    V v_x1_2415;
    switch (heff_tag_of(v_f_243)) {
    case TAG_VFun: {
      V v_f_246 = heff_dup(heff_field(v_f_243, 0));
      v_x1_2415 = heff_tr(heff_apply(v_f_246, 2, (V[]){heff_dup(v_d_240), heff_clo(g_heff_2einterp_2egenGo_lam0, 1, 1, (V[]){heff_dup(v_j_241)})}));
      break;
    }
    case TAG_VCons: {
      v_x1_2415 = heff_abandon();
      break;
    }
    case TAG_VTag: {
      v_x1_2415 = heff_abandon();
      break;
    }
    case TAG_VInt: {
      v_x1_2415 = heff_abandon();
      break;
    }
    case TAG_VFloat: {
      v_x1_2415 = heff_abandon();
      break;
    }
    case TAG_VStr: {
      v_x1_2415 = heff_abandon();
      break;
    }
    case TAG_VArr: {
      v_x1_2415 = heff_abandon();
      break;
    }
    case TAG_VErased: {
      v_x1_2415 = heff_tag(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
      break;
    }
    default: heff_nomatch(v_f_243);
    }
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_Ok: {
      V v_v_2416 = heff_field(v_x1_2415, 0);
      heff_take(v_x1_2415, 1ULL);
      V t_0 = v_d_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
      V t_2 = v_n_242;
      V t_3 = v_f_243;
      V t_4 = heff_clo(g_heff_2einterp_2egenGo_lam1, 1, 2, (V[]){v_k_244, v_v_2416});
      v_d_240 = t_0;
      v_j_241 = t_1;
      v_n_242 = t_2;
      v_f_243 = t_3;
      v_k_244 = t_4;
      goto top;
    }
    case TAG_Abn: {
      heff_drop(v_d_240);
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      heff_drop(v_f_243);
      heff_drop(v_k_244);
      heff_drop(v_x1_2415);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_d_240);
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      heff_drop(v_f_243);
      heff_drop(v_k_244);
      heff_drop(v_x1_2415);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_2415);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2einterp_2egenGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2egenGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2einterp_2egenGo_lam0(V self, V *args) {
  V v_d_247 = args[0];
  V v_j_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_d_247);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_j_241})});
}
V g_heff_2einterp_2egenGo_lam1(V self, V *args) {
  V v_vs_2417 = args[0];
  V v_k_244 = heff_dup(heff_env(self)[0]);
  V v_v_2416 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_k_244, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_v_2416, v_vs_2417})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2efromListV_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {67, 111, 110, 115}};
Clo g_heff_2einterp_2efromListV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efromListV_entry, 2, 0};

V g_heff_2einterp_2efromListV(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_take(v_x1_240, 0ULL);
    return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_241));
  }
  case TAG_VCons: {
    heff_take(v_x1_240, 0ULL);
    return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_241));
  }
  case TAG_VTag: {
    V v_x11_244 = heff_field(v_x1_240, 0);
    V v_x12_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24VTag = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_246 = heff_strEq(v_x11_244, ((V)&g_heff_2einterp_2efromListV_str0));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_t_246);
      switch (heff_tag_of(v_x12_245)) {
      case TAG_Nil: {
        heff_drop(v_x12_245);
        heff_drop(v_ru_24x1_240_24VTag);
        return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_241));
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x12_245, 0);
        V v_x122_248 = heff_field(v_x12_245, 1);
        heff_take(v_x12_245, 3ULL);
        switch (heff_tag_of(v_x122_248)) {
        case TAG_Nil: {
          heff_drop(v_ru_24x1_240_24VTag);
          heff_drop(v_x_247);
          heff_drop(v_x122_248);
          return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_241));
        }
        case TAG_Cons: {
          V v_rest_249 = heff_field(v_x122_248, 0);
          V v_x1222_2410 = heff_field(v_x122_248, 1);
          heff_take(v_x122_248, 3ULL);
          switch (heff_tag_of(v_x1222_2410)) {
          case TAG_Nil: {
            heff_drop(v_x1222_2410);
            V t_0 = v_rest_249;
            V t_1 = heff_tag_at(v_ru_24x1_240_24VTag, TAG_Cons, 2, (V[]){v_x_247, v_acc_241});
            v_x1_240 = t_0;
            v_acc_241 = t_1;
            goto top;
          }
          case TAG_Cons: {
            heff_take(v_x1222_2410, 0ULL);
            heff_drop(v_ru_24x1_240_24VTag);
            heff_drop(v_x_247);
            heff_drop(v_rest_249);
            return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_241));
          }
          default: return heff_nomatch(v_x1222_2410);
          }
        }
        default: return heff_nomatch(v_x122_248);
        }
      }
      default: return heff_nomatch(v_x12_245);
      }
    }
    case TAG_False: {
      heff_drop(v_x12_245);
      heff_drop(v_ru_24x1_240_24VTag);
      heff_drop(v_t_246);
      return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_241));
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_VInt: {
    heff_take(v_x1_240, 0ULL);
    return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_241));
  }
  case TAG_VFloat: {
    heff_take(v_x1_240, 0ULL);
    return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_241));
  }
  case TAG_VStr: {
    heff_take(v_x1_240, 0ULL);
    return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_241));
  }
  case TAG_VArr: {
    heff_take(v_x1_240, 0ULL);
    return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_241));
  }
  case TAG_VErased: {
    heff_drop(v_x1_240);
    return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2efromListV_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2efromListV(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2einterp_2etoListV_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {78, 105, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2etoListV_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {67, 111, 110, 115}};
Clo g_heff_2einterp_2etoListV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2etoListV_entry, 1, 0};

V g_heff_2einterp_2etoListV(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return heff_tag(TAG_VTag, 2, (V[]){((V)&g_heff_2einterp_2etoListV_str0), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_243 = (g_heff_2einterp_2etoListV(v_xs_242));
    V v_t_244 = heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
    return heff_tag(TAG_VTag, 2, (V[]){((V)&g_heff_2einterp_2etoListV_str1), heff_tag(TAG_Cons, 2, (V[]){v_x_241, v_t_244})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2etoListV_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2etoListV(a[0]);
}
Clo g_heff_2einterp_2enthV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2enthV_entry, 2, 0};

V g_heff_2einterp_2enthV(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_intEq(heff_dup(v_i_241), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_i_241);
      heff_drop(v_t_244);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    }
    case TAG_False: {
      heff_drop(v_t_244);
      V t_0 = v_xs_243;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2enthV_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2enthV(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2einterp_2eint2_24s23_lam1(V self, V *args);
V g_heff_2einterp_2eint2_24s23_lam0(V self, V *args); static Clo g_heff_2einterp_2eint2_24s23_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eint2_24s23_lam0, 2, 0};

static V g_heff_2einterp_2eint2_24s23_val;
static int g_heff_2einterp_2eint2_24s23_st;
static V g_heff_2einterp_2eint2_24s23_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eint2_24s23_lam0_clo)});
}
V g_heff_2einterp_2eint2_24s23_get(void) {
  if (g_heff_2einterp_2eint2_24s23_st == 2) return g_heff_2einterp_2eint2_24s23_val;
  if (g_heff_2einterp_2eint2_24s23_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2eint2_24s23_st = 1;
  g_heff_2einterp_2eint2_24s23_val = heff_tr(g_heff_2einterp_2eint2_24s23_init());
  g_heff_2einterp_2eint2_24s23_st = 2;
  return g_heff_2einterp_2eint2_24s23_val;
}
V g_heff_2einterp_2eint2_24s23_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse(v_x1_244, 1ULL);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse(v_x1_246, 1ULL);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take(v_v_245, 1ULL);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take(v_v_247, 1ULL);
          V v_t_2418 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VInt, 1, (V[]){heff_intAdd(v_a_2412, v_b_2417)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2418});
        }
        case TAG_VFloat: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_v_247);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_v_245);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2eint2_24s23_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(self);
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eint2_24s23_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2eint2_24s24_lam1(V self, V *args);
V g_heff_2einterp_2eint2_24s24_lam0(V self, V *args); static Clo g_heff_2einterp_2eint2_24s24_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eint2_24s24_lam0, 2, 0};

static V g_heff_2einterp_2eint2_24s24_val;
static int g_heff_2einterp_2eint2_24s24_st;
static V g_heff_2einterp_2eint2_24s24_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eint2_24s24_lam0_clo)});
}
V g_heff_2einterp_2eint2_24s24_get(void) {
  if (g_heff_2einterp_2eint2_24s24_st == 2) return g_heff_2einterp_2eint2_24s24_val;
  if (g_heff_2einterp_2eint2_24s24_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2eint2_24s24_st = 1;
  g_heff_2einterp_2eint2_24s24_val = heff_tr(g_heff_2einterp_2eint2_24s24_init());
  g_heff_2einterp_2eint2_24s24_st = 2;
  return g_heff_2einterp_2eint2_24s24_val;
}
V g_heff_2einterp_2eint2_24s24_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse(v_x1_244, 1ULL);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse(v_x1_246, 1ULL);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take(v_v_245, 1ULL);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take(v_v_247, 1ULL);
          V v_t_2418 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VInt, 1, (V[]){heff_intSub(v_a_2412, v_b_2417)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2418});
        }
        case TAG_VFloat: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_v_247);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_v_245);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2eint2_24s24_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(self);
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eint2_24s24_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2eint2_24s25_lam1(V self, V *args);
V g_heff_2einterp_2eint2_24s25_lam0(V self, V *args); static Clo g_heff_2einterp_2eint2_24s25_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eint2_24s25_lam0, 2, 0};

static V g_heff_2einterp_2eint2_24s25_val;
static int g_heff_2einterp_2eint2_24s25_st;
static V g_heff_2einterp_2eint2_24s25_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eint2_24s25_lam0_clo)});
}
V g_heff_2einterp_2eint2_24s25_get(void) {
  if (g_heff_2einterp_2eint2_24s25_st == 2) return g_heff_2einterp_2eint2_24s25_val;
  if (g_heff_2einterp_2eint2_24s25_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2eint2_24s25_st = 1;
  g_heff_2einterp_2eint2_24s25_val = heff_tr(g_heff_2einterp_2eint2_24s25_init());
  g_heff_2einterp_2eint2_24s25_st = 2;
  return g_heff_2einterp_2eint2_24s25_val;
}
V g_heff_2einterp_2eint2_24s25_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse(v_x1_244, 1ULL);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse(v_x1_246, 1ULL);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take(v_v_245, 1ULL);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take(v_v_247, 1ULL);
          V v_t_2418 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VInt, 1, (V[]){heff_intMul(v_a_2412, v_b_2417)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2418});
        }
        case TAG_VFloat: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_v_247);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_v_245);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2eint2_24s25_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(self);
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eint2_24s25_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2eint2_24s26_lam1(V self, V *args);
V g_heff_2einterp_2eint2_24s26_lam0(V self, V *args); static Clo g_heff_2einterp_2eint2_24s26_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eint2_24s26_lam0, 2, 0};

static V g_heff_2einterp_2eint2_24s26_val;
static int g_heff_2einterp_2eint2_24s26_st;
static V g_heff_2einterp_2eint2_24s26_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eint2_24s26_lam0_clo)});
}
V g_heff_2einterp_2eint2_24s26_get(void) {
  if (g_heff_2einterp_2eint2_24s26_st == 2) return g_heff_2einterp_2eint2_24s26_val;
  if (g_heff_2einterp_2eint2_24s26_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2eint2_24s26_st = 1;
  g_heff_2einterp_2eint2_24s26_val = heff_tr(g_heff_2einterp_2eint2_24s26_init());
  g_heff_2einterp_2eint2_24s26_st = 2;
  return g_heff_2einterp_2eint2_24s26_val;
}
V g_heff_2einterp_2eint2_24s26_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse(v_x1_244, 1ULL);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      heff_take(v_x1_246, 1ULL);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take(v_v_245, 1ULL);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take(v_v_247, 1ULL);
          V v_t_2418 = heff_intEq(heff_dup(v_b_2417), MK_INT(0LL));
          switch (heff_tag_of(v_t_2418)) {
          case TAG_True: {
            heff_drop(v_ru_24x1_244_24Ok);
            heff_drop(v_a_2412);
            heff_drop(v_b_2417);
            heff_drop(v_t_2418);
            return NTAG(TAG_Abn);
          }
          case TAG_False: {
            heff_drop(v_t_2418);
            V v_t_2419 = heff_intDiv(v_a_2412, v_b_2417);
            return heff_tag_at(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_t_2419})});
          }
          default: return heff_nomatch(v_t_2418);
          }
        }
        case TAG_VFloat: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_v_247);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_v_245);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2eint2_24s26_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(self);
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eint2_24s26_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2eint2_24s27_lam1(V self, V *args);
V g_heff_2einterp_2eint2_24s27_lam0(V self, V *args); static Clo g_heff_2einterp_2eint2_24s27_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eint2_24s27_lam0, 2, 0};

static V g_heff_2einterp_2eint2_24s27_val;
static int g_heff_2einterp_2eint2_24s27_st;
static V g_heff_2einterp_2eint2_24s27_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eint2_24s27_lam0_clo)});
}
V g_heff_2einterp_2eint2_24s27_get(void) {
  if (g_heff_2einterp_2eint2_24s27_st == 2) return g_heff_2einterp_2eint2_24s27_val;
  if (g_heff_2einterp_2eint2_24s27_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2eint2_24s27_st = 1;
  g_heff_2einterp_2eint2_24s27_val = heff_tr(g_heff_2einterp_2eint2_24s27_init());
  g_heff_2einterp_2eint2_24s27_st = 2;
  return g_heff_2einterp_2eint2_24s27_val;
}
V g_heff_2einterp_2eint2_24s27_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse(v_x1_244, 1ULL);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      heff_take(v_x1_246, 1ULL);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take(v_v_245, 1ULL);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take(v_v_247, 1ULL);
          V v_t_2418 = heff_intEq(heff_dup(v_b_2417), MK_INT(0LL));
          switch (heff_tag_of(v_t_2418)) {
          case TAG_True: {
            heff_drop(v_ru_24x1_244_24Ok);
            heff_drop(v_a_2412);
            heff_drop(v_b_2417);
            heff_drop(v_t_2418);
            return NTAG(TAG_Abn);
          }
          case TAG_False: {
            heff_drop(v_t_2418);
            V v_t_2419 = heff_intMod(v_a_2412, v_b_2417);
            return heff_tag_at(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_t_2419})});
          }
          default: return heff_nomatch(v_t_2418);
          }
        }
        case TAG_VFloat: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_v_247);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_v_245);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2eint2_24s27_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(self);
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eint2_24s27_lam1, 2, 1, (V[]){v_a_241})})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eint2_24s28_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eint2_24s28_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
V g_heff_2einterp_2eint2_24s28_lam1(V self, V *args);
V g_heff_2einterp_2eint2_24s28_lam0(V self, V *args); static Clo g_heff_2einterp_2eint2_24s28_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eint2_24s28_lam0, 2, 0};

static V g_heff_2einterp_2eint2_24s28_val;
static int g_heff_2einterp_2eint2_24s28_st;
static V g_heff_2einterp_2eint2_24s28_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eint2_24s28_lam0_clo)});
}
V g_heff_2einterp_2eint2_24s28_get(void) {
  if (g_heff_2einterp_2eint2_24s28_st == 2) return g_heff_2einterp_2eint2_24s28_val;
  if (g_heff_2einterp_2eint2_24s28_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2eint2_24s28_st = 1;
  g_heff_2einterp_2eint2_24s28_val = heff_tr(g_heff_2einterp_2eint2_24s28_init());
  g_heff_2einterp_2eint2_24s28_st = 2;
  return g_heff_2einterp_2eint2_24s28_val;
}
V g_heff_2einterp_2eint2_24s28_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse(v_x1_244, 1ULL);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      heff_take(v_x1_246, 1ULL);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take(v_v_245, 1ULL);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take(v_v_247, 1ULL);
          V v_t_2418 = heff_intEq(v_a_2412, v_b_2417);
          V v_t_2419;
          switch (heff_tag_of(v_t_2418)) {
          case TAG_True: {
            heff_drop(v_t_2418);
            v_t_2419 = ((V)&g_heff_2einterp_2eint2_24s28_str0);
            break;
          }
          case TAG_False: {
            heff_drop(v_t_2418);
            v_t_2419 = ((V)&g_heff_2einterp_2eint2_24s28_str1);
            break;
          }
          default: heff_nomatch(v_t_2418);
          }
          V v_t_2420 = heff_tag(TAG_VTag, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
          return heff_tag_at(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_v_247);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_v_245);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2eint2_24s28_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(self);
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eint2_24s28_lam1, 2, 1, (V[]){v_a_241})})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eint2_24s29_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eint2_24s29_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
V g_heff_2einterp_2eint2_24s29_lam1(V self, V *args);
V g_heff_2einterp_2eint2_24s29_lam0(V self, V *args); static Clo g_heff_2einterp_2eint2_24s29_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eint2_24s29_lam0, 2, 0};

static V g_heff_2einterp_2eint2_24s29_val;
static int g_heff_2einterp_2eint2_24s29_st;
static V g_heff_2einterp_2eint2_24s29_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eint2_24s29_lam0_clo)});
}
V g_heff_2einterp_2eint2_24s29_get(void) {
  if (g_heff_2einterp_2eint2_24s29_st == 2) return g_heff_2einterp_2eint2_24s29_val;
  if (g_heff_2einterp_2eint2_24s29_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2eint2_24s29_st = 1;
  g_heff_2einterp_2eint2_24s29_val = heff_tr(g_heff_2einterp_2eint2_24s29_init());
  g_heff_2einterp_2eint2_24s29_st = 2;
  return g_heff_2einterp_2eint2_24s29_val;
}
V g_heff_2einterp_2eint2_24s29_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse(v_x1_244, 1ULL);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      heff_take(v_x1_246, 1ULL);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take(v_v_245, 1ULL);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take(v_v_247, 1ULL);
          V v_t_2418 = heff_intLt(v_a_2412, v_b_2417);
          V v_t_2419;
          switch (heff_tag_of(v_t_2418)) {
          case TAG_True: {
            heff_drop(v_t_2418);
            v_t_2419 = ((V)&g_heff_2einterp_2eint2_24s29_str0);
            break;
          }
          case TAG_False: {
            heff_drop(v_t_2418);
            v_t_2419 = ((V)&g_heff_2einterp_2eint2_24s29_str1);
            break;
          }
          default: heff_nomatch(v_t_2418);
          }
          V v_t_2420 = heff_tag(TAG_VTag, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
          return heff_tag_at(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_v_247);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_v_245);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2eint2_24s29_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(self);
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eint2_24s29_lam1, 2, 1, (V[]){v_a_241})})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eint2_24s30_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eint2_24s30_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
V g_heff_2einterp_2eint2_24s30_lam1(V self, V *args);
V g_heff_2einterp_2eint2_24s30_lam0(V self, V *args); static Clo g_heff_2einterp_2eint2_24s30_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eint2_24s30_lam0, 2, 0};

static V g_heff_2einterp_2eint2_24s30_val;
static int g_heff_2einterp_2eint2_24s30_st;
static V g_heff_2einterp_2eint2_24s30_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eint2_24s30_lam0_clo)});
}
V g_heff_2einterp_2eint2_24s30_get(void) {
  if (g_heff_2einterp_2eint2_24s30_st == 2) return g_heff_2einterp_2eint2_24s30_val;
  if (g_heff_2einterp_2eint2_24s30_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2eint2_24s30_st = 1;
  g_heff_2einterp_2eint2_24s30_val = heff_tr(g_heff_2einterp_2eint2_24s30_init());
  g_heff_2einterp_2eint2_24s30_st = 2;
  return g_heff_2einterp_2eint2_24s30_val;
}
V g_heff_2einterp_2eint2_24s30_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse(v_x1_244, 1ULL);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      heff_take(v_x1_246, 1ULL);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take(v_v_245, 1ULL);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take(v_v_247, 1ULL);
          V v_t_2418 = heff_intLe(v_a_2412, v_b_2417);
          V v_t_2419;
          switch (heff_tag_of(v_t_2418)) {
          case TAG_True: {
            heff_drop(v_t_2418);
            v_t_2419 = ((V)&g_heff_2einterp_2eint2_24s30_str0);
            break;
          }
          case TAG_False: {
            heff_drop(v_t_2418);
            v_t_2419 = ((V)&g_heff_2einterp_2eint2_24s30_str1);
            break;
          }
          default: heff_nomatch(v_t_2418);
          }
          V v_t_2420 = heff_tag(TAG_VTag, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
          return heff_tag_at(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_v_247);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_v_245);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2eint2_24s30_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(self);
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eint2_24s30_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2efloat2_24s31_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_24s31_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat2_24s31_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_24s31_lam0, 2, 0};

static V g_heff_2einterp_2efloat2_24s31_val;
static int g_heff_2einterp_2efloat2_24s31_st;
static V g_heff_2einterp_2efloat2_24s31_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat2_24s31_lam0_clo)});
}
V g_heff_2einterp_2efloat2_24s31_get(void) {
  if (g_heff_2einterp_2efloat2_24s31_st == 2) return g_heff_2einterp_2efloat2_24s31_val;
  if (g_heff_2einterp_2efloat2_24s31_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2efloat2_24s31_st = 1;
  g_heff_2einterp_2efloat2_24s31_val = heff_tr(g_heff_2einterp_2efloat2_24s31_init());
  g_heff_2einterp_2efloat2_24s31_st = 2;
  return g_heff_2einterp_2efloat2_24s31_val;
}
V g_heff_2einterp_2efloat2_24s31_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse(v_x1_244, 1ULL);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse(v_x1_246, 1ULL);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take(v_v_245, 1ULL);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take(v_v_247, 1ULL);
          V v_t_2420 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VFloat, 1, (V[]){heff_floatAdd(v_a_2413, v_b_2419)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VStr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_v_247);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_v_245);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2efloat2_24s31_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(self);
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_24s31_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2efloat2_24s32_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_24s32_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat2_24s32_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_24s32_lam0, 2, 0};

static V g_heff_2einterp_2efloat2_24s32_val;
static int g_heff_2einterp_2efloat2_24s32_st;
static V g_heff_2einterp_2efloat2_24s32_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat2_24s32_lam0_clo)});
}
V g_heff_2einterp_2efloat2_24s32_get(void) {
  if (g_heff_2einterp_2efloat2_24s32_st == 2) return g_heff_2einterp_2efloat2_24s32_val;
  if (g_heff_2einterp_2efloat2_24s32_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2efloat2_24s32_st = 1;
  g_heff_2einterp_2efloat2_24s32_val = heff_tr(g_heff_2einterp_2efloat2_24s32_init());
  g_heff_2einterp_2efloat2_24s32_st = 2;
  return g_heff_2einterp_2efloat2_24s32_val;
}
V g_heff_2einterp_2efloat2_24s32_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse(v_x1_244, 1ULL);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse(v_x1_246, 1ULL);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take(v_v_245, 1ULL);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take(v_v_247, 1ULL);
          V v_t_2420 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VFloat, 1, (V[]){heff_floatSub(v_a_2413, v_b_2419)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VStr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_v_247);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_v_245);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2efloat2_24s32_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(self);
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_24s32_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2efloat2_24s33_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_24s33_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat2_24s33_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_24s33_lam0, 2, 0};

static V g_heff_2einterp_2efloat2_24s33_val;
static int g_heff_2einterp_2efloat2_24s33_st;
static V g_heff_2einterp_2efloat2_24s33_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat2_24s33_lam0_clo)});
}
V g_heff_2einterp_2efloat2_24s33_get(void) {
  if (g_heff_2einterp_2efloat2_24s33_st == 2) return g_heff_2einterp_2efloat2_24s33_val;
  if (g_heff_2einterp_2efloat2_24s33_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2efloat2_24s33_st = 1;
  g_heff_2einterp_2efloat2_24s33_val = heff_tr(g_heff_2einterp_2efloat2_24s33_init());
  g_heff_2einterp_2efloat2_24s33_st = 2;
  return g_heff_2einterp_2efloat2_24s33_val;
}
V g_heff_2einterp_2efloat2_24s33_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse(v_x1_244, 1ULL);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse(v_x1_246, 1ULL);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take(v_v_245, 1ULL);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take(v_v_247, 1ULL);
          V v_t_2420 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VFloat, 1, (V[]){heff_floatMul(v_a_2413, v_b_2419)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VStr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_v_247);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_v_245);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2efloat2_24s33_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(self);
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_24s33_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2efloat2_24s34_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_24s34_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat2_24s34_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_24s34_lam0, 2, 0};

static V g_heff_2einterp_2efloat2_24s34_val;
static int g_heff_2einterp_2efloat2_24s34_st;
static V g_heff_2einterp_2efloat2_24s34_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat2_24s34_lam0_clo)});
}
V g_heff_2einterp_2efloat2_24s34_get(void) {
  if (g_heff_2einterp_2efloat2_24s34_st == 2) return g_heff_2einterp_2efloat2_24s34_val;
  if (g_heff_2einterp_2efloat2_24s34_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2efloat2_24s34_st = 1;
  g_heff_2einterp_2efloat2_24s34_val = heff_tr(g_heff_2einterp_2efloat2_24s34_init());
  g_heff_2einterp_2efloat2_24s34_st = 2;
  return g_heff_2einterp_2efloat2_24s34_val;
}
V g_heff_2einterp_2efloat2_24s34_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse(v_x1_244, 1ULL);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse(v_x1_246, 1ULL);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take(v_v_245, 1ULL);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take(v_v_247, 1ULL);
          V v_t_2420 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VFloat, 1, (V[]){heff_floatDiv(v_a_2413, v_b_2419)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VStr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_v_247);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_v_245);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2efloat2_24s34_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(self);
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_24s34_lam1, 2, 1, (V[]){v_a_241})})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2efloat2_24s35_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2efloat2_24s35_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
V g_heff_2einterp_2efloat2_24s35_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_24s35_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat2_24s35_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_24s35_lam0, 2, 0};

static V g_heff_2einterp_2efloat2_24s35_val;
static int g_heff_2einterp_2efloat2_24s35_st;
static V g_heff_2einterp_2efloat2_24s35_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat2_24s35_lam0_clo)});
}
V g_heff_2einterp_2efloat2_24s35_get(void) {
  if (g_heff_2einterp_2efloat2_24s35_st == 2) return g_heff_2einterp_2efloat2_24s35_val;
  if (g_heff_2einterp_2efloat2_24s35_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2efloat2_24s35_st = 1;
  g_heff_2einterp_2efloat2_24s35_val = heff_tr(g_heff_2einterp_2efloat2_24s35_init());
  g_heff_2einterp_2efloat2_24s35_st = 2;
  return g_heff_2einterp_2efloat2_24s35_val;
}
V g_heff_2einterp_2efloat2_24s35_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse(v_x1_244, 1ULL);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      heff_take(v_x1_246, 1ULL);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take(v_v_245, 1ULL);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take(v_v_247, 1ULL);
          V v_t_2420 = heff_floatEq(v_a_2413, v_b_2419);
          V v_t_2421;
          switch (heff_tag_of(v_t_2420)) {
          case TAG_True: {
            heff_drop(v_t_2420);
            v_t_2421 = ((V)&g_heff_2einterp_2efloat2_24s35_str0);
            break;
          }
          case TAG_False: {
            heff_drop(v_t_2420);
            v_t_2421 = ((V)&g_heff_2einterp_2efloat2_24s35_str1);
            break;
          }
          default: heff_nomatch(v_t_2420);
          }
          V v_t_2422 = heff_tag(TAG_VTag, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
          return heff_tag_at(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_v_247);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_v_245);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2efloat2_24s35_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(self);
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_24s35_lam1, 2, 1, (V[]){v_a_241})})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2efloat2_24s36_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2efloat2_24s36_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
V g_heff_2einterp_2efloat2_24s36_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_24s36_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat2_24s36_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_24s36_lam0, 2, 0};

static V g_heff_2einterp_2efloat2_24s36_val;
static int g_heff_2einterp_2efloat2_24s36_st;
static V g_heff_2einterp_2efloat2_24s36_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat2_24s36_lam0_clo)});
}
V g_heff_2einterp_2efloat2_24s36_get(void) {
  if (g_heff_2einterp_2efloat2_24s36_st == 2) return g_heff_2einterp_2efloat2_24s36_val;
  if (g_heff_2einterp_2efloat2_24s36_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2efloat2_24s36_st = 1;
  g_heff_2einterp_2efloat2_24s36_val = heff_tr(g_heff_2einterp_2efloat2_24s36_init());
  g_heff_2einterp_2efloat2_24s36_st = 2;
  return g_heff_2einterp_2efloat2_24s36_val;
}
V g_heff_2einterp_2efloat2_24s36_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse(v_x1_244, 1ULL);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      heff_take(v_x1_246, 1ULL);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take(v_v_245, 1ULL);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take(v_v_247, 1ULL);
          V v_t_2420 = heff_floatLt(v_a_2413, v_b_2419);
          V v_t_2421;
          switch (heff_tag_of(v_t_2420)) {
          case TAG_True: {
            heff_drop(v_t_2420);
            v_t_2421 = ((V)&g_heff_2einterp_2efloat2_24s36_str0);
            break;
          }
          case TAG_False: {
            heff_drop(v_t_2420);
            v_t_2421 = ((V)&g_heff_2einterp_2efloat2_24s36_str1);
            break;
          }
          default: heff_nomatch(v_t_2420);
          }
          V v_t_2422 = heff_tag(TAG_VTag, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
          return heff_tag_at(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_v_247);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_v_245);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2efloat2_24s36_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(self);
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_24s36_lam1, 2, 1, (V[]){v_a_241})})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2efloat2_24s37_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2efloat2_24s37_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
V g_heff_2einterp_2efloat2_24s37_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_24s37_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat2_24s37_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_24s37_lam0, 2, 0};

static V g_heff_2einterp_2efloat2_24s37_val;
static int g_heff_2einterp_2efloat2_24s37_st;
static V g_heff_2einterp_2efloat2_24s37_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat2_24s37_lam0_clo)});
}
V g_heff_2einterp_2efloat2_24s37_get(void) {
  if (g_heff_2einterp_2efloat2_24s37_st == 2) return g_heff_2einterp_2efloat2_24s37_val;
  if (g_heff_2einterp_2efloat2_24s37_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2efloat2_24s37_st = 1;
  g_heff_2einterp_2efloat2_24s37_val = heff_tr(g_heff_2einterp_2efloat2_24s37_init());
  g_heff_2einterp_2efloat2_24s37_st = 2;
  return g_heff_2einterp_2efloat2_24s37_val;
}
V g_heff_2einterp_2efloat2_24s37_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse(v_x1_244, 1ULL);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      heff_take(v_x1_246, 1ULL);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take(v_v_245, 1ULL);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take(v_v_247, 1ULL);
          V v_t_2420 = heff_floatLe(v_a_2413, v_b_2419);
          V v_t_2421;
          switch (heff_tag_of(v_t_2420)) {
          case TAG_True: {
            heff_drop(v_t_2420);
            v_t_2421 = ((V)&g_heff_2einterp_2efloat2_24s37_str0);
            break;
          }
          case TAG_False: {
            heff_drop(v_t_2420);
            v_t_2421 = ((V)&g_heff_2einterp_2efloat2_24s37_str1);
            break;
          }
          default: heff_nomatch(v_t_2420);
          }
          V v_t_2422 = heff_tag(TAG_VTag, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
          return heff_tag_at(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_v_247);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_v_245);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2efloat2_24s37_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(self);
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_24s37_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2estr2_24s38_lam1(V self, V *args);
V g_heff_2einterp_2estr2_24s38_lam0(V self, V *args); static Clo g_heff_2einterp_2estr2_24s38_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2estr2_24s38_lam0, 2, 0};

static V g_heff_2einterp_2estr2_24s38_val;
static int g_heff_2einterp_2estr2_24s38_st;
static V g_heff_2einterp_2estr2_24s38_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2estr2_24s38_lam0_clo)});
}
V g_heff_2einterp_2estr2_24s38_get(void) {
  if (g_heff_2einterp_2estr2_24s38_st == 2) return g_heff_2einterp_2estr2_24s38_val;
  if (g_heff_2einterp_2estr2_24s38_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2estr2_24s38_st = 1;
  g_heff_2einterp_2estr2_24s38_val = heff_tr(g_heff_2einterp_2estr2_24s38_init());
  g_heff_2einterp_2estr2_24s38_st = 2;
  return g_heff_2einterp_2estr2_24s38_val;
}
V g_heff_2einterp_2estr2_24s38_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse(v_x1_244, 1ULL);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse(v_x1_246, 1ULL);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VFloat: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VStr: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take(v_v_245, 1ULL);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VFloat: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VStr: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take(v_v_247, 1ULL);
          V v_t_2422 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VStr, 1, (V[]){heff_strAppend(v_a_2414, v_b_2421)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VArr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_v_247);
          heff_drop(v_ru_24x1_246_24Ok);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VArr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_v_245);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        heff_drop(v_ru_24x1_246_24Ok);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2estr2_24s38_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(self);
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2estr2_24s38_lam1, 2, 1, (V[]){v_a_241})})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2estr2_24s39_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2estr2_24s39_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
V g_heff_2einterp_2estr2_24s39_lam1(V self, V *args);
V g_heff_2einterp_2estr2_24s39_lam0(V self, V *args); static Clo g_heff_2einterp_2estr2_24s39_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2estr2_24s39_lam0, 2, 0};

static V g_heff_2einterp_2estr2_24s39_val;
static int g_heff_2einterp_2estr2_24s39_st;
static V g_heff_2einterp_2estr2_24s39_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2estr2_24s39_lam0_clo)});
}
V g_heff_2einterp_2estr2_24s39_get(void) {
  if (g_heff_2einterp_2estr2_24s39_st == 2) return g_heff_2einterp_2estr2_24s39_val;
  if (g_heff_2einterp_2estr2_24s39_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2estr2_24s39_st = 1;
  g_heff_2einterp_2estr2_24s39_val = heff_tr(g_heff_2einterp_2estr2_24s39_init());
  g_heff_2einterp_2estr2_24s39_st = 2;
  return g_heff_2einterp_2estr2_24s39_val;
}
V g_heff_2einterp_2estr2_24s39_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse(v_x1_244, 1ULL);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      heff_take(v_x1_246, 1ULL);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VFloat: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VStr: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take(v_v_245, 1ULL);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VFloat: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VStr: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take(v_v_247, 1ULL);
          V v_t_2422 = heff_strEq(v_a_2414, v_b_2421);
          V v_t_2423;
          switch (heff_tag_of(v_t_2422)) {
          case TAG_True: {
            heff_drop(v_t_2422);
            v_t_2423 = ((V)&g_heff_2einterp_2estr2_24s39_str0);
            break;
          }
          case TAG_False: {
            heff_drop(v_t_2422);
            v_t_2423 = ((V)&g_heff_2einterp_2estr2_24s39_str1);
            break;
          }
          default: heff_nomatch(v_t_2422);
          }
          V v_t_2424 = heff_tag(TAG_VTag, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
          return heff_tag_at(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2424});
        }
        case TAG_VArr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_v_247);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VArr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_v_245);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2estr2_24s39_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(self);
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2estr2_24s39_lam1, 2, 1, (V[]){v_a_241})})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2estr2_24s40_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2estr2_24s40_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
V g_heff_2einterp_2estr2_24s40_lam1(V self, V *args);
V g_heff_2einterp_2estr2_24s40_lam0(V self, V *args); static Clo g_heff_2einterp_2estr2_24s40_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2estr2_24s40_lam0, 2, 0};

static V g_heff_2einterp_2estr2_24s40_val;
static int g_heff_2einterp_2estr2_24s40_st;
static V g_heff_2einterp_2estr2_24s40_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2estr2_24s40_lam0_clo)});
}
V g_heff_2einterp_2estr2_24s40_get(void) {
  if (g_heff_2einterp_2estr2_24s40_st == 2) return g_heff_2einterp_2estr2_24s40_val;
  if (g_heff_2einterp_2estr2_24s40_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2estr2_24s40_st = 1;
  g_heff_2einterp_2estr2_24s40_val = heff_tr(g_heff_2einterp_2estr2_24s40_init());
  g_heff_2einterp_2estr2_24s40_st = 2;
  return g_heff_2einterp_2estr2_24s40_val;
}
V g_heff_2einterp_2estr2_24s40_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse(v_x1_244, 1ULL);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      heff_take(v_x1_246, 1ULL);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VFloat: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VStr: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take(v_v_245, 1ULL);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VFloat: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VStr: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take(v_v_247, 1ULL);
          V v_t_2422 = heff_strLt(v_a_2414, v_b_2421);
          V v_t_2423;
          switch (heff_tag_of(v_t_2422)) {
          case TAG_True: {
            heff_drop(v_t_2422);
            v_t_2423 = ((V)&g_heff_2einterp_2estr2_24s40_str0);
            break;
          }
          case TAG_False: {
            heff_drop(v_t_2422);
            v_t_2423 = ((V)&g_heff_2einterp_2estr2_24s40_str1);
            break;
          }
          default: heff_nomatch(v_t_2422);
          }
          V v_t_2424 = heff_tag(TAG_VTag, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
          return heff_tag_at(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2424});
        }
        case TAG_VArr: {
          heff_take(v_v_247, 0ULL);
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_ru_24x1_244_24Ok);
          heff_drop(v_v_247);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VArr: {
        heff_take(v_v_245, 0ULL);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_v_245);
        heff_drop(v_ru_24x1_244_24Ok);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop(v_ru_24x1_244_24Ok);
      heff_drop(v_x1_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    heff_drop(v_x1_244);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2estr2_24s40_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(self);
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2estr2_24s40_lam1, 2, 1, (V[]){v_a_241})})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 65, 100, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 83, 117, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 77, 117, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str3 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 68, 105, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 77, 111, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eprim_str8 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 110, 116, 83, 104, 111, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str9 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 65, 100, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str10 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 83, 117, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str11 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 77, 117, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str12 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 68, 105, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eprim_str13 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eprim_str14 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eprim_str15 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2einterp_2eprim_str16 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 83, 104, 111, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2einterp_2eprim_str17 = {{0x80000000u, K_STR, 0}, 12, 12, {102, 108, 111, 97, 116, 70, 114, 111, 109, 73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2einterp_2eprim_str18 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 83, 113, 114, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2einterp_2eprim_str19 = {{0x80000000u, K_STR, 0}, 10, 10, {102, 108, 111, 97, 116, 70, 108, 111, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2einterp_2eprim_str20 = {{0x80000000u, K_STR, 0}, 11, 11, {97, 114, 114, 97, 121, 76, 101, 110, 103, 116, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2einterp_2eprim_str21 = {{0x80000000u, K_STR, 0}, 10, 10, {97, 114, 114, 97, 121, 73, 110, 100, 101, 120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str22 = {{0x80000000u, K_STR, 0}, 8, 8, {97, 114, 114, 97, 121, 83, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2einterp_2eprim_str23 = {{0x80000000u, K_STR, 0}, 13, 13, {97, 114, 114, 97, 121, 71, 101, 110, 101, 114, 97, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2einterp_2eprim_str24 = {{0x80000000u, K_STR, 0}, 13, 13, {97, 114, 114, 97, 121, 70, 114, 111, 109, 76, 105, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2einterp_2eprim_str25 = {{0x80000000u, K_STR, 0}, 11, 11, {97, 114, 114, 97, 121, 84, 111, 76, 105, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2einterp_2eprim_str26 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 65, 112, 112, 101, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2einterp_2eprim_str27 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 76, 101, 110, 103, 116, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str28 = {{0x80000000u, K_STR, 0}, 8, 8, {115, 116, 114, 83, 108, 105, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str29 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 114, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str30 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 114, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2einterp_2eprim_str31 = {{0x80000000u, K_STR, 0}, 11, 11, {115, 116, 114, 67, 104, 97, 114, 67, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2einterp_2eprim_str32 = {{0x80000000u, K_STR, 0}, 15, 15, {115, 116, 114, 70, 114, 111, 109, 67, 104, 97, 114, 67, 111, 100, 101}};
V g_heff_2einterp_2eprim_lam0(V self, V *args); static Clo g_heff_2einterp_2eprim_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam0, 2, 0};
V g_heff_2einterp_2eprim_lam1(V self, V *args); static Clo g_heff_2einterp_2eprim_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam1, 2, 0};
V g_heff_2einterp_2eprim_lam2(V self, V *args); static Clo g_heff_2einterp_2eprim_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam2, 2, 0};
V g_heff_2einterp_2eprim_lam3(V self, V *args); static Clo g_heff_2einterp_2eprim_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam3, 2, 0};
V g_heff_2einterp_2eprim_lam4(V self, V *args); static Clo g_heff_2einterp_2eprim_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam4, 2, 0};
V g_heff_2einterp_2eprim_lam6(V self, V *args); static Clo g_heff_2einterp_2eprim_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam6, 2, 0};
V g_heff_2einterp_2eprim_lam5(V self, V *args); static Clo g_heff_2einterp_2eprim_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam5, 2, 0};
V g_heff_2einterp_2eprim_lam9(V self, V *args);
V g_heff_2einterp_2eprim_lam8(V self, V *args); static Clo g_heff_2einterp_2eprim_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam8, 2, 0};
V g_heff_2einterp_2eprim_lam7(V self, V *args); static Clo g_heff_2einterp_2eprim_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam7, 2, 0};
V g_heff_2einterp_2eprim_lam13(V self, V *args);
V g_heff_2einterp_2eprim_lam12(V self, V *args);
V g_heff_2einterp_2eprim_lam11(V self, V *args); static Clo g_heff_2einterp_2eprim_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam11, 2, 0};
V g_heff_2einterp_2eprim_lam10(V self, V *args); static Clo g_heff_2einterp_2eprim_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam10, 2, 0};
V g_heff_2einterp_2eprim_lam17(V self, V *args); static Clo g_heff_2einterp_2eprim_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam17, 1, 0};
V g_heff_2einterp_2eprim_lam16(V self, V *args);
V g_heff_2einterp_2eprim_lam15(V self, V *args); static Clo g_heff_2einterp_2eprim_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam15, 2, 0};
V g_heff_2einterp_2eprim_lam14(V self, V *args); static Clo g_heff_2einterp_2eprim_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam14, 2, 0};
V g_heff_2einterp_2eprim_lam19(V self, V *args); static Clo g_heff_2einterp_2eprim_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam19, 2, 0};
V g_heff_2einterp_2eprim_lam18(V self, V *args); static Clo g_heff_2einterp_2eprim_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam18, 2, 0};
V g_heff_2einterp_2eprim_lam21(V self, V *args); static Clo g_heff_2einterp_2eprim_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam21, 2, 0};
V g_heff_2einterp_2eprim_lam20(V self, V *args); static Clo g_heff_2einterp_2eprim_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam20, 2, 0};
V g_heff_2einterp_2eprim_lam22(V self, V *args); static Clo g_heff_2einterp_2eprim_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam22, 2, 0};
V g_heff_2einterp_2eprim_lam25(V self, V *args);
V g_heff_2einterp_2eprim_lam24(V self, V *args);
V g_heff_2einterp_2eprim_lam23(V self, V *args); static Clo g_heff_2einterp_2eprim_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam23, 2, 0};
V g_heff_2einterp_2eprim_lam27(V self, V *args);
V g_heff_2einterp_2eprim_lam26(V self, V *args); static Clo g_heff_2einterp_2eprim_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam26, 2, 0};
V g_heff_2einterp_2eprim_lam28(V self, V *args); static Clo g_heff_2einterp_2eprim_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam28, 2, 0};
Clo g_heff_2einterp_2eprim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_entry, 1, 0};

V g_heff_2einterp_2eprim(V v_p_240) {
top: ;
  V v_t_241 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_p_240);
    heff_drop(v_t_241);
    return heff_dup(g_heff_2einterp_2eint2_24s23_get());
  }
  case TAG_False: {
    heff_drop(v_t_241);
    V v_t_242 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str1));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      heff_drop(v_p_240);
      heff_drop(v_t_242);
      return heff_dup(g_heff_2einterp_2eint2_24s24_get());
    }
    case TAG_False: {
      heff_drop(v_t_242);
      V v_t_243 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str2));
      switch (heff_tag_of(v_t_243)) {
      case TAG_True: {
        heff_drop(v_p_240);
        heff_drop(v_t_243);
        return heff_dup(g_heff_2einterp_2eint2_24s25_get());
      }
      case TAG_False: {
        heff_drop(v_t_243);
        V v_t_244 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str3));
        switch (heff_tag_of(v_t_244)) {
        case TAG_True: {
          heff_drop(v_p_240);
          heff_drop(v_t_244);
          return heff_dup(g_heff_2einterp_2eint2_24s26_get());
        }
        case TAG_False: {
          heff_drop(v_t_244);
          V v_t_245 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str4));
          switch (heff_tag_of(v_t_245)) {
          case TAG_True: {
            heff_drop(v_p_240);
            heff_drop(v_t_245);
            return heff_dup(g_heff_2einterp_2eint2_24s27_get());
          }
          case TAG_False: {
            heff_drop(v_t_245);
            V v_t_246 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str5));
            switch (heff_tag_of(v_t_246)) {
            case TAG_True: {
              heff_drop(v_p_240);
              heff_drop(v_t_246);
              return heff_dup(g_heff_2einterp_2eint2_24s28_get());
            }
            case TAG_False: {
              heff_drop(v_t_246);
              V v_t_247 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str6));
              switch (heff_tag_of(v_t_247)) {
              case TAG_True: {
                heff_drop(v_p_240);
                heff_drop(v_t_247);
                return heff_dup(g_heff_2einterp_2eint2_24s29_get());
              }
              case TAG_False: {
                heff_drop(v_t_247);
                V v_t_248 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str7));
                switch (heff_tag_of(v_t_248)) {
                case TAG_True: {
                  heff_drop(v_p_240);
                  heff_drop(v_t_248);
                  return heff_dup(g_heff_2einterp_2eint2_24s30_get());
                }
                case TAG_False: {
                  heff_drop(v_t_248);
                  V v_t_249 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str8));
                  switch (heff_tag_of(v_t_249)) {
                  case TAG_True: {
                    heff_drop(v_p_240);
                    heff_drop(v_t_249);
                    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam0_clo)});
                  }
                  case TAG_False: {
                    heff_drop(v_t_249);
                    V v_t_2423 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str9));
                    switch (heff_tag_of(v_t_2423)) {
                    case TAG_True: {
                      heff_drop(v_p_240);
                      heff_drop(v_t_2423);
                      return heff_dup(g_heff_2einterp_2efloat2_24s31_get());
                    }
                    case TAG_False: {
                      heff_drop(v_t_2423);
                      V v_t_2424 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str10));
                      switch (heff_tag_of(v_t_2424)) {
                      case TAG_True: {
                        heff_drop(v_p_240);
                        heff_drop(v_t_2424);
                        return heff_dup(g_heff_2einterp_2efloat2_24s32_get());
                      }
                      case TAG_False: {
                        heff_drop(v_t_2424);
                        V v_t_2425 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str11));
                        switch (heff_tag_of(v_t_2425)) {
                        case TAG_True: {
                          heff_drop(v_p_240);
                          heff_drop(v_t_2425);
                          return heff_dup(g_heff_2einterp_2efloat2_24s33_get());
                        }
                        case TAG_False: {
                          heff_drop(v_t_2425);
                          V v_t_2426 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str12));
                          switch (heff_tag_of(v_t_2426)) {
                          case TAG_True: {
                            heff_drop(v_p_240);
                            heff_drop(v_t_2426);
                            return heff_dup(g_heff_2einterp_2efloat2_24s34_get());
                          }
                          case TAG_False: {
                            heff_drop(v_t_2426);
                            V v_t_2427 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str13));
                            switch (heff_tag_of(v_t_2427)) {
                            case TAG_True: {
                              heff_drop(v_p_240);
                              heff_drop(v_t_2427);
                              return heff_dup(g_heff_2einterp_2efloat2_24s35_get());
                            }
                            case TAG_False: {
                              heff_drop(v_t_2427);
                              V v_t_2428 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str14));
                              switch (heff_tag_of(v_t_2428)) {
                              case TAG_True: {
                                heff_drop(v_p_240);
                                heff_drop(v_t_2428);
                                return heff_dup(g_heff_2einterp_2efloat2_24s36_get());
                              }
                              case TAG_False: {
                                heff_drop(v_t_2428);
                                V v_t_2429 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str15));
                                switch (heff_tag_of(v_t_2429)) {
                                case TAG_True: {
                                  heff_drop(v_p_240);
                                  heff_drop(v_t_2429);
                                  return heff_dup(g_heff_2einterp_2efloat2_24s37_get());
                                }
                                case TAG_False: {
                                  heff_drop(v_t_2429);
                                  V v_t_2430 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str16));
                                  switch (heff_tag_of(v_t_2430)) {
                                  case TAG_True: {
                                    heff_drop(v_p_240);
                                    heff_drop(v_t_2430);
                                    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam1_clo)});
                                  }
                                  case TAG_False: {
                                    heff_drop(v_t_2430);
                                    V v_t_2444 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str17));
                                    switch (heff_tag_of(v_t_2444)) {
                                    case TAG_True: {
                                      heff_drop(v_p_240);
                                      heff_drop(v_t_2444);
                                      return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam2_clo)});
                                    }
                                    case TAG_False: {
                                      heff_drop(v_t_2444);
                                      V v_t_2458 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str18));
                                      switch (heff_tag_of(v_t_2458)) {
                                      case TAG_True: {
                                        heff_drop(v_p_240);
                                        heff_drop(v_t_2458);
                                        return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam3_clo)});
                                      }
                                      case TAG_False: {
                                        heff_drop(v_t_2458);
                                        V v_t_2472 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str19));
                                        switch (heff_tag_of(v_t_2472)) {
                                        case TAG_True: {
                                          heff_drop(v_p_240);
                                          heff_drop(v_t_2472);
                                          return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam4_clo)});
                                        }
                                        case TAG_False: {
                                          heff_drop(v_t_2472);
                                          V v_t_2487 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str20));
                                          switch (heff_tag_of(v_t_2487)) {
                                          case TAG_True: {
                                            heff_drop(v_p_240);
                                            heff_drop(v_t_2487);
                                            return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam5_clo)});
                                          }
                                          case TAG_False: {
                                            heff_drop(v_t_2487);
                                            V v_t_24103 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str21));
                                            switch (heff_tag_of(v_t_24103)) {
                                            case TAG_True: {
                                              heff_drop(v_p_240);
                                              heff_drop(v_t_24103);
                                              return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam7_clo)});
                                            }
                                            case TAG_False: {
                                              heff_drop(v_t_24103);
                                              V v_t_24135 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str22));
                                              switch (heff_tag_of(v_t_24135)) {
                                              case TAG_True: {
                                                heff_drop(v_p_240);
                                                heff_drop(v_t_24135);
                                                return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam10_clo)});
                                              }
                                              case TAG_False: {
                                                heff_drop(v_t_24135);
                                                V v_t_24171 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str23));
                                                switch (heff_tag_of(v_t_24171)) {
                                                case TAG_True: {
                                                  heff_drop(v_p_240);
                                                  heff_drop(v_t_24171);
                                                  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam14_clo)});
                                                }
                                                case TAG_False: {
                                                  heff_drop(v_t_24171);
                                                  V v_t_24192 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str24));
                                                  switch (heff_tag_of(v_t_24192)) {
                                                  case TAG_True: {
                                                    heff_drop(v_p_240);
                                                    heff_drop(v_t_24192);
                                                    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam18_clo)});
                                                  }
                                                  case TAG_False: {
                                                    heff_drop(v_t_24192);
                                                    V v_t_24201 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str25));
                                                    switch (heff_tag_of(v_t_24201)) {
                                                    case TAG_True: {
                                                      heff_drop(v_p_240);
                                                      heff_drop(v_t_24201);
                                                      return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam20_clo)});
                                                    }
                                                    case TAG_False: {
                                                      heff_drop(v_t_24201);
                                                      V v_t_24216 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str26));
                                                      switch (heff_tag_of(v_t_24216)) {
                                                      case TAG_True: {
                                                        heff_drop(v_p_240);
                                                        heff_drop(v_t_24216);
                                                        return heff_dup(g_heff_2einterp_2estr2_24s38_get());
                                                      }
                                                      case TAG_False: {
                                                        heff_drop(v_t_24216);
                                                        V v_t_24217 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str27));
                                                        switch (heff_tag_of(v_t_24217)) {
                                                        case TAG_True: {
                                                          heff_drop(v_p_240);
                                                          heff_drop(v_t_24217);
                                                          return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam22_clo)});
                                                        }
                                                        case TAG_False: {
                                                          heff_drop(v_t_24217);
                                                          V v_t_24231 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str28));
                                                          switch (heff_tag_of(v_t_24231)) {
                                                          case TAG_True: {
                                                            heff_drop(v_p_240);
                                                            heff_drop(v_t_24231);
                                                            return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam23_clo)});
                                                          }
                                                          case TAG_False: {
                                                            heff_drop(v_t_24231);
                                                            V v_t_24269 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str29));
                                                            switch (heff_tag_of(v_t_24269)) {
                                                            case TAG_True: {
                                                              heff_drop(v_p_240);
                                                              heff_drop(v_t_24269);
                                                              return heff_dup(g_heff_2einterp_2estr2_24s39_get());
                                                            }
                                                            case TAG_False: {
                                                              heff_drop(v_t_24269);
                                                              V v_t_24270 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str30));
                                                              switch (heff_tag_of(v_t_24270)) {
                                                              case TAG_True: {
                                                                heff_drop(v_p_240);
                                                                heff_drop(v_t_24270);
                                                                return heff_dup(g_heff_2einterp_2estr2_24s40_get());
                                                              }
                                                              case TAG_False: {
                                                                heff_drop(v_t_24270);
                                                                V v_t_24271 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str31));
                                                                switch (heff_tag_of(v_t_24271)) {
                                                                case TAG_True: {
                                                                  heff_drop(v_p_240);
                                                                  heff_drop(v_t_24271);
                                                                  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam26_clo)});
                                                                }
                                                                case TAG_False: {
                                                                  heff_drop(v_t_24271);
                                                                  V v_t_24297 = heff_strEq(v_p_240, ((V)&g_heff_2einterp_2eprim_str32));
                                                                  switch (heff_tag_of(v_t_24297)) {
                                                                  case TAG_True: {
                                                                    heff_drop(v_t_24297);
                                                                    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam28_clo)});
                                                                  }
                                                                  case TAG_False: {
                                                                    heff_drop(v_t_24297);
                                                                    return heff_abandon();
                                                                  }
                                                                  default: return heff_nomatch(v_t_24297);
                                                                  }
                                                                }
                                                                default: return heff_nomatch(v_t_24271);
                                                                }
                                                              }
                                                              default: return heff_nomatch(v_t_24270);
                                                              }
                                                            }
                                                            default: return heff_nomatch(v_t_24269);
                                                            }
                                                          }
                                                          default: return heff_nomatch(v_t_24231);
                                                          }
                                                        }
                                                        default: return heff_nomatch(v_t_24217);
                                                        }
                                                      }
                                                      default: return heff_nomatch(v_t_24216);
                                                      }
                                                    }
                                                    default: return heff_nomatch(v_t_24201);
                                                    }
                                                  }
                                                  default: return heff_nomatch(v_t_24192);
                                                  }
                                                }
                                                default: return heff_nomatch(v_t_24171);
                                                }
                                              }
                                              default: return heff_nomatch(v_t_24135);
                                              }
                                            }
                                            default: return heff_nomatch(v_t_24103);
                                            }
                                          }
                                          default: return heff_nomatch(v_t_2487);
                                          }
                                        }
                                        default: return heff_nomatch(v_t_2472);
                                        }
                                      }
                                      default: return heff_nomatch(v_t_2458);
                                      }
                                    }
                                    default: return heff_nomatch(v_t_2444);
                                    }
                                  }
                                  default: return heff_nomatch(v_t_2430);
                                  }
                                }
                                default: return heff_nomatch(v_t_2429);
                                }
                              }
                              default: return heff_nomatch(v_t_2428);
                              }
                            }
                            default: return heff_nomatch(v_t_2427);
                            }
                          }
                          default: return heff_nomatch(v_t_2426);
                          }
                        }
                        default: return heff_nomatch(v_t_2425);
                        }
                      }
                      default: return heff_nomatch(v_t_2424);
                      }
                    }
                    default: return heff_nomatch(v_t_2423);
                    }
                  }
                  default: return heff_nomatch(v_t_249);
                  }
                }
                default: return heff_nomatch(v_t_248);
                }
              }
              default: return heff_nomatch(v_t_247);
              }
            }
            default: return heff_nomatch(v_t_246);
            }
          }
          default: return heff_nomatch(v_t_245);
          }
        }
        default: return heff_nomatch(v_t_244);
        }
      }
      default: return heff_nomatch(v_t_243);
      }
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2einterp_2eprim_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eprim(a[0]);
}
V g_heff_2einterp_2eprim_lam0(V self, V *args) {
  V v_d_2410 = args[0];
  V v_a_2411 = args[1];
  heff_drop(self);
  V v_x1_2412 = heff_tr(heff_apply(v_a_2411, 1, (V[]){v_d_2410}));
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Ok: {
    V v_v_2413 = heff_field(v_x1_2412, 0);
    V v_ru_24x1_2412_24Ok = heff_take_reuse(v_x1_2412, 1ULL);
    switch (heff_tag_of(v_v_2413)) {
    case TAG_VFun: {
      heff_take(v_v_2413, 0ULL);
      heff_drop(v_ru_24x1_2412_24Ok);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_v_2413, 0ULL);
      heff_drop(v_ru_24x1_2412_24Ok);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take(v_v_2413, 0ULL);
      heff_drop(v_ru_24x1_2412_24Ok);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_2418 = heff_field(v_v_2413, 0);
      V v_ru_24v_2413_24VInt = heff_take_reuse(v_v_2413, 1ULL);
      V v_t_2419 = heff_tag_at(v_ru_24x1_2412_24Ok, TAG_VStr, 1, (V[]){heff_intShow(v_a_2418)});
      return heff_tag_at(v_ru_24v_2413_24VInt, TAG_Ok, 1, (V[]){v_t_2419});
    }
    case TAG_VFloat: {
      heff_take(v_v_2413, 0ULL);
      heff_drop(v_ru_24x1_2412_24Ok);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take(v_v_2413, 0ULL);
      heff_drop(v_ru_24x1_2412_24Ok);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take(v_v_2413, 0ULL);
      heff_drop(v_ru_24x1_2412_24Ok);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_v_2413);
      heff_drop(v_ru_24x1_2412_24Ok);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_2413);
    }
  }
  case TAG_Abn: {
    heff_drop(v_x1_2412);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_x1_2412);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_2412);
  }
}
V g_heff_2einterp_2eprim_lam1(V self, V *args) {
  V v_d_2431 = args[0];
  V v_a_2432 = args[1];
  heff_drop(self);
  V v_x1_2433 = heff_tr(heff_apply(v_a_2432, 1, (V[]){v_d_2431}));
  switch (heff_tag_of(v_x1_2433)) {
  case TAG_Ok: {
    V v_v_2434 = heff_field(v_x1_2433, 0);
    V v_ru_24x1_2433_24Ok = heff_take_reuse(v_x1_2433, 1ULL);
    switch (heff_tag_of(v_v_2434)) {
    case TAG_VFun: {
      heff_take(v_v_2434, 0ULL);
      heff_drop(v_ru_24x1_2433_24Ok);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_v_2434, 0ULL);
      heff_drop(v_ru_24x1_2433_24Ok);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take(v_v_2434, 0ULL);
      heff_drop(v_ru_24x1_2433_24Ok);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take(v_v_2434, 0ULL);
      heff_drop(v_ru_24x1_2433_24Ok);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_2440 = heff_field(v_v_2434, 0);
      V v_ru_24v_2434_24VFloat = heff_take_reuse(v_v_2434, 1ULL);
      V v_t_2441 = heff_tag_at(v_ru_24x1_2433_24Ok, TAG_VStr, 1, (V[]){heff_floatShow(v_a_2440)});
      return heff_tag_at(v_ru_24v_2434_24VFloat, TAG_Ok, 1, (V[]){v_t_2441});
    }
    case TAG_VStr: {
      heff_take(v_v_2434, 0ULL);
      heff_drop(v_ru_24x1_2433_24Ok);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take(v_v_2434, 0ULL);
      heff_drop(v_ru_24x1_2433_24Ok);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_v_2434);
      heff_drop(v_ru_24x1_2433_24Ok);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_2434);
    }
  }
  case TAG_Abn: {
    heff_drop(v_x1_2433);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_x1_2433);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_2433);
  }
}
V g_heff_2einterp_2eprim_lam2(V self, V *args) {
  V v_d_2445 = args[0];
  V v_a_2446 = args[1];
  heff_drop(self);
  V v_x1_2447 = heff_tr(heff_apply(v_a_2446, 1, (V[]){v_d_2445}));
  switch (heff_tag_of(v_x1_2447)) {
  case TAG_Ok: {
    V v_v_2448 = heff_field(v_x1_2447, 0);
    V v_ru_24x1_2447_24Ok = heff_take_reuse(v_x1_2447, 1ULL);
    switch (heff_tag_of(v_v_2448)) {
    case TAG_VFun: {
      heff_take(v_v_2448, 0ULL);
      heff_drop(v_ru_24x1_2447_24Ok);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_v_2448, 0ULL);
      heff_drop(v_ru_24x1_2447_24Ok);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take(v_v_2448, 0ULL);
      heff_drop(v_ru_24x1_2447_24Ok);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_2453 = heff_field(v_v_2448, 0);
      V v_ru_24v_2448_24VInt = heff_take_reuse(v_v_2448, 1ULL);
      V v_t_2454 = heff_tag_at(v_ru_24x1_2447_24Ok, TAG_VFloat, 1, (V[]){heff_floatFromInt(v_a_2453)});
      return heff_tag_at(v_ru_24v_2448_24VInt, TAG_Ok, 1, (V[]){v_t_2454});
    }
    case TAG_VFloat: {
      heff_take(v_v_2448, 0ULL);
      heff_drop(v_ru_24x1_2447_24Ok);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take(v_v_2448, 0ULL);
      heff_drop(v_ru_24x1_2447_24Ok);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take(v_v_2448, 0ULL);
      heff_drop(v_ru_24x1_2447_24Ok);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_v_2448);
      heff_drop(v_ru_24x1_2447_24Ok);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_2448);
    }
  }
  case TAG_Abn: {
    heff_drop(v_x1_2447);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_x1_2447);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_2447);
  }
}
V g_heff_2einterp_2eprim_lam3(V self, V *args) {
  V v_d_2459 = args[0];
  V v_a_2460 = args[1];
  heff_drop(self);
  V v_x1_2461 = heff_tr(heff_apply(v_a_2460, 1, (V[]){v_d_2459}));
  switch (heff_tag_of(v_x1_2461)) {
  case TAG_Ok: {
    V v_v_2462 = heff_field(v_x1_2461, 0);
    V v_ru_24x1_2461_24Ok = heff_take_reuse(v_x1_2461, 1ULL);
    switch (heff_tag_of(v_v_2462)) {
    case TAG_VFun: {
      heff_take(v_v_2462, 0ULL);
      heff_drop(v_ru_24x1_2461_24Ok);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_v_2462, 0ULL);
      heff_drop(v_ru_24x1_2461_24Ok);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take(v_v_2462, 0ULL);
      heff_drop(v_ru_24x1_2461_24Ok);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take(v_v_2462, 0ULL);
      heff_drop(v_ru_24x1_2461_24Ok);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_2468 = heff_field(v_v_2462, 0);
      V v_ru_24v_2462_24VFloat = heff_take_reuse(v_v_2462, 1ULL);
      V v_t_2469 = heff_tag_at(v_ru_24x1_2461_24Ok, TAG_VFloat, 1, (V[]){heff_floatSqrt(v_a_2468)});
      return heff_tag_at(v_ru_24v_2462_24VFloat, TAG_Ok, 1, (V[]){v_t_2469});
    }
    case TAG_VStr: {
      heff_take(v_v_2462, 0ULL);
      heff_drop(v_ru_24x1_2461_24Ok);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take(v_v_2462, 0ULL);
      heff_drop(v_ru_24x1_2461_24Ok);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_v_2462);
      heff_drop(v_ru_24x1_2461_24Ok);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_2462);
    }
  }
  case TAG_Abn: {
    heff_drop(v_x1_2461);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_x1_2461);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_2461);
  }
}
V g_heff_2einterp_2eprim_lam4(V self, V *args) {
  V v_d_2473 = args[0];
  V v_a_2474 = args[1];
  heff_drop(self);
  V v_x1_2475 = heff_tr(heff_apply(v_a_2474, 1, (V[]){v_d_2473}));
  switch (heff_tag_of(v_x1_2475)) {
  case TAG_Ok: {
    V v_v_2476 = heff_field(v_x1_2475, 0);
    V v_ru_24x1_2475_24Ok = heff_take_reuse(v_x1_2475, 1ULL);
    switch (heff_tag_of(v_v_2476)) {
    case TAG_VFun: {
      heff_take(v_v_2476, 0ULL);
      heff_drop(v_ru_24x1_2475_24Ok);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_v_2476, 0ULL);
      heff_drop(v_ru_24x1_2475_24Ok);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take(v_v_2476, 0ULL);
      heff_drop(v_ru_24x1_2475_24Ok);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take(v_v_2476, 0ULL);
      heff_drop(v_ru_24x1_2475_24Ok);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_2482 = heff_field(v_v_2476, 0);
      heff_take(v_v_2476, 1ULL);
      V v_t_2483 = heff_floatEq(heff_floatSub(heff_dup(v_a_2482), heff_dup(v_a_2482)), heff_flt(0.0));
      switch (heff_tag_of(v_t_2483)) {
      case TAG_True: {
        heff_drop(v_t_2483);
        V v_t_2484 = heff_floatFloor(v_a_2482);
        return heff_tag_at(v_ru_24x1_2475_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_t_2484})});
      }
      case TAG_False: {
        heff_drop(v_ru_24x1_2475_24Ok);
        heff_drop(v_a_2482);
        heff_drop(v_t_2483);
        return NTAG(TAG_Abn);
      }
      default: return heff_nomatch(v_t_2483);
      }
    }
    case TAG_VStr: {
      heff_take(v_v_2476, 0ULL);
      heff_drop(v_ru_24x1_2475_24Ok);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take(v_v_2476, 0ULL);
      heff_drop(v_ru_24x1_2475_24Ok);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_v_2476);
      heff_drop(v_ru_24x1_2475_24Ok);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_2476);
    }
  }
  case TAG_Abn: {
    heff_drop(v_x1_2475);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_x1_2475);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_2475);
  }
}
V g_heff_2einterp_2eprim_lam6(V self, V *args) {
  V v_d_2490 = args[0];
  V v_a_2491 = args[1];
  heff_drop(self);
  V v_x1_2492 = heff_tr(heff_apply(v_a_2491, 1, (V[]){v_d_2490}));
  switch (heff_tag_of(v_x1_2492)) {
  case TAG_Ok: {
    V v_v_2493 = heff_field(v_x1_2492, 0);
    V v_ru_24x1_2492_24Ok = heff_take_reuse(v_x1_2492, 1ULL);
    switch (heff_tag_of(v_v_2493)) {
    case TAG_VFun: {
      heff_take(v_v_2493, 0ULL);
      heff_drop(v_ru_24x1_2492_24Ok);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_v_2493, 0ULL);
      heff_drop(v_ru_24x1_2492_24Ok);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take(v_v_2493, 0ULL);
      heff_drop(v_ru_24x1_2492_24Ok);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take(v_v_2493, 0ULL);
      heff_drop(v_ru_24x1_2492_24Ok);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take(v_v_2493, 0ULL);
      heff_drop(v_ru_24x1_2492_24Ok);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take(v_v_2493, 0ULL);
      heff_drop(v_ru_24x1_2492_24Ok);
      return heff_abandon();
    }
    case TAG_VArr: {
      V v_xs_24101 = heff_field(v_v_2493, 0);
      V v_ru_24v_2493_24VArr = heff_take_reuse(v_v_2493, 1ULL);
      V v_t_24102 = heff_tag_at(v_ru_24x1_2492_24Ok, TAG_VInt, 1, (V[]){({ V a_0 = MK_INT(0LL); V b_1 = heff_arrayToList(v_xs_24101); V r_ = (g_prelude_2efoldl_24s1(a_0, b_1)); heff_drop(b_1); r_; })});
      return heff_tag_at(v_ru_24v_2493_24VArr, TAG_Ok, 1, (V[]){v_t_24102});
    }
    case TAG_VErased: {
      heff_drop(v_v_2493);
      heff_drop(v_ru_24x1_2492_24Ok);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_2493);
    }
  }
  case TAG_Abn: {
    heff_drop(v_x1_2492);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_x1_2492);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_2492);
  }
}
V g_heff_2einterp_2eprim_lam5(V self, V *args) {
  V v_d_2488 = args[0];
  V v_u_2489 = args[1];
  heff_drop(self);
  heff_drop(v_d_2488);
  heff_drop(v_u_2489);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam6_clo)})});
}
V g_heff_2einterp_2eprim_lam9(V self, V *args) {
  V v_d_24118 = args[0];
  V v_a_24119 = args[1];
  V v_xs_24117 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_24120 = heff_tr(heff_apply(v_a_24119, 1, (V[]){v_d_24118}));
  switch (heff_tag_of(v_x1_24120)) {
  case TAG_Ok: {
    V v_v_24121 = heff_field(v_x1_24120, 0);
    V v_ru_24x1_24120_24Ok = heff_take_reuse(v_x1_24120, 1ULL);
    switch (heff_tag_of(v_v_24121)) {
    case TAG_VFun: {
      heff_take(v_v_24121, 0ULL);
      heff_drop(v_xs_24117);
      heff_drop(v_ru_24x1_24120_24Ok);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_v_24121, 0ULL);
      heff_drop(v_xs_24117);
      heff_drop(v_ru_24x1_24120_24Ok);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take(v_v_24121, 0ULL);
      heff_drop(v_xs_24117);
      heff_drop(v_ru_24x1_24120_24Ok);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24126 = heff_field(v_v_24121, 0);
      heff_take(v_v_24121, 1ULL);
      V v_t_24127 = heff_intLe(MK_INT(0LL), heff_dup(v_a_24126));
      switch (heff_tag_of(v_t_24127)) {
      case TAG_True: {
        heff_drop(v_t_24127);
        V v_t_24128 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_arrayToList(heff_dup(v_xs_24117)); V r_ = (g_prelude_2efoldl_24s1(a_0, b_1)); heff_drop(b_1); r_; });
        V v_t_24129 = heff_intLt(heff_dup(v_a_24126), v_t_24128);
        switch (heff_tag_of(v_t_24129)) {
        case TAG_True: {
          heff_drop(v_t_24129);
          V v_t_24130 = ({ V b_0 = heff_arrayToList(v_xs_24117); V a_1 = v_a_24126; V r_ = (g_heff_2einterp_2enthV(b_0, a_1)); heff_drop(b_0); r_; });
          switch (heff_tag_of(v_t_24130)) {
          case TAG_Nothing: {
            heff_drop(v_ru_24x1_24120_24Ok);
            heff_drop(v_t_24130);
            return NTAG(TAG_Abn);
          }
          case TAG_Just: {
            V v_v_24131 = heff_field(v_t_24130, 0);
            heff_take(v_t_24130, 1ULL);
            return heff_tag_at(v_ru_24x1_24120_24Ok, TAG_Ok, 1, (V[]){v_v_24131});
          }
          default: return heff_nomatch(v_t_24130);
          }
        }
        case TAG_False: {
          heff_drop(v_xs_24117);
          heff_drop(v_ru_24x1_24120_24Ok);
          heff_drop(v_a_24126);
          heff_drop(v_t_24129);
          return NTAG(TAG_Abn);
        }
        default: return heff_nomatch(v_t_24129);
        }
      }
      case TAG_False: {
        heff_drop(v_xs_24117);
        heff_drop(v_ru_24x1_24120_24Ok);
        heff_drop(v_a_24126);
        heff_drop(v_t_24127);
        return NTAG(TAG_Abn);
      }
      default: return heff_nomatch(v_t_24127);
      }
    }
    case TAG_VFloat: {
      heff_take(v_v_24121, 0ULL);
      heff_drop(v_xs_24117);
      heff_drop(v_ru_24x1_24120_24Ok);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take(v_v_24121, 0ULL);
      heff_drop(v_xs_24117);
      heff_drop(v_ru_24x1_24120_24Ok);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take(v_v_24121, 0ULL);
      heff_drop(v_xs_24117);
      heff_drop(v_ru_24x1_24120_24Ok);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_xs_24117);
      heff_drop(v_v_24121);
      heff_drop(v_ru_24x1_24120_24Ok);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24121);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24117);
    heff_drop(v_x1_24120);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24117);
    heff_drop(v_x1_24120);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24120);
  }
}
V g_heff_2einterp_2eprim_lam8(V self, V *args) {
  V v_d_24106 = args[0];
  V v_a_24107 = args[1];
  heff_drop(self);
  V v_x1_24108 = heff_tr(heff_apply(v_a_24107, 1, (V[]){v_d_24106}));
  switch (heff_tag_of(v_x1_24108)) {
  case TAG_Ok: {
    V v_v_24109 = heff_field(v_x1_24108, 0);
    V v_ru_24x1_24108_24Ok = heff_take_reuse(v_x1_24108, 1ULL);
    switch (heff_tag_of(v_v_24109)) {
    case TAG_VFun: {
      heff_take(v_v_24109, 0ULL);
      heff_drop(v_ru_24x1_24108_24Ok);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_v_24109, 0ULL);
      heff_drop(v_ru_24x1_24108_24Ok);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take(v_v_24109, 0ULL);
      heff_drop(v_ru_24x1_24108_24Ok);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take(v_v_24109, 0ULL);
      heff_drop(v_ru_24x1_24108_24Ok);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take(v_v_24109, 0ULL);
      heff_drop(v_ru_24x1_24108_24Ok);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take(v_v_24109, 0ULL);
      heff_drop(v_ru_24x1_24108_24Ok);
      return heff_abandon();
    }
    case TAG_VArr: {
      V v_xs_24117 = heff_field(v_v_24109, 0);
      heff_take(v_v_24109, 1ULL);
      return heff_tag_at(v_ru_24x1_24108_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam9, 2, 1, (V[]){v_xs_24117})})});
    }
    case TAG_VErased: {
      heff_drop(v_v_24109);
      heff_drop(v_ru_24x1_24108_24Ok);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24109);
    }
  }
  case TAG_Abn: {
    heff_drop(v_x1_24108);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_x1_24108);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24108);
  }
}
V g_heff_2einterp_2eprim_lam7(V self, V *args) {
  V v_d_24104 = args[0];
  V v_u_24105 = args[1];
  heff_drop(self);
  heff_drop(v_d_24104);
  heff_drop(v_u_24105);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam8_clo)})});
}
V g_heff_2einterp_2eprim_lam13(V self, V *args) {
  V v_d_24159 = args[0];
  V v_x_24160 = args[1];
  V v_a_24158 = heff_dup(heff_env(self)[0]);
  V v_xs_24149 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_x1_24161 = heff_tr(heff_apply(v_x_24160, 1, (V[]){v_d_24159}));
  switch (heff_tag_of(v_x1_24161)) {
  case TAG_Ok: {
    V v_v_24162 = heff_field(v_x1_24161, 0);
    V v_ru_24x1_24161_24Ok = heff_take_reuse(v_x1_24161, 1ULL);
    V v_t_24163 = heff_intLe(MK_INT(0LL), heff_dup(v_a_24158));
    switch (heff_tag_of(v_t_24163)) {
    case TAG_True: {
      heff_drop(v_t_24163);
      V v_t_24164 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_arrayToList(heff_dup(v_xs_24149)); V r_ = (g_prelude_2efoldl_24s1(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_24165 = heff_intLt(heff_dup(v_a_24158), v_t_24164);
      switch (heff_tag_of(v_t_24165)) {
      case TAG_True: {
        heff_drop(v_t_24165);
        V v_t_24166 = (g_heff_2einterp_2esetAt(heff_arrayToList(v_xs_24149), v_a_24158, v_v_24162));
        V v_t_24167 = heff_tag_at(v_ru_24x1_24161_24Ok, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24166)});
        return heff_tag(TAG_Ok, 1, (V[]){v_t_24167});
      }
      case TAG_False: {
        heff_drop(v_a_24158);
        heff_drop(v_xs_24149);
        heff_drop(v_v_24162);
        heff_drop(v_ru_24x1_24161_24Ok);
        heff_drop(v_t_24165);
        return NTAG(TAG_Abn);
      }
      default: return heff_nomatch(v_t_24165);
      }
    }
    case TAG_False: {
      heff_drop(v_a_24158);
      heff_drop(v_xs_24149);
      heff_drop(v_v_24162);
      heff_drop(v_ru_24x1_24161_24Ok);
      heff_drop(v_t_24163);
      return NTAG(TAG_Abn);
    }
    default: return heff_nomatch(v_t_24163);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24158);
    heff_drop(v_xs_24149);
    heff_drop(v_x1_24161);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24158);
    heff_drop(v_xs_24149);
    heff_drop(v_x1_24161);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24161);
  }
}
V g_heff_2einterp_2eprim_lam12(V self, V *args) {
  V v_d_24150 = args[0];
  V v_a_24151 = args[1];
  V v_xs_24149 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_24152 = heff_tr(heff_apply(v_a_24151, 1, (V[]){v_d_24150}));
  switch (heff_tag_of(v_x1_24152)) {
  case TAG_Ok: {
    V v_v_24153 = heff_field(v_x1_24152, 0);
    V v_ru_24x1_24152_24Ok = heff_take_reuse(v_x1_24152, 1ULL);
    switch (heff_tag_of(v_v_24153)) {
    case TAG_VFun: {
      heff_take(v_v_24153, 0ULL);
      heff_drop(v_xs_24149);
      heff_drop(v_ru_24x1_24152_24Ok);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_v_24153, 0ULL);
      heff_drop(v_xs_24149);
      heff_drop(v_ru_24x1_24152_24Ok);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take(v_v_24153, 0ULL);
      heff_drop(v_xs_24149);
      heff_drop(v_ru_24x1_24152_24Ok);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24158 = heff_field(v_v_24153, 0);
      heff_take(v_v_24153, 1ULL);
      return heff_tag_at(v_ru_24x1_24152_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam13, 2, 2, (V[]){v_a_24158, v_xs_24149})})});
    }
    case TAG_VFloat: {
      heff_take(v_v_24153, 0ULL);
      heff_drop(v_xs_24149);
      heff_drop(v_ru_24x1_24152_24Ok);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take(v_v_24153, 0ULL);
      heff_drop(v_xs_24149);
      heff_drop(v_ru_24x1_24152_24Ok);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take(v_v_24153, 0ULL);
      heff_drop(v_xs_24149);
      heff_drop(v_ru_24x1_24152_24Ok);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_xs_24149);
      heff_drop(v_v_24153);
      heff_drop(v_ru_24x1_24152_24Ok);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24153);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24149);
    heff_drop(v_x1_24152);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24149);
    heff_drop(v_x1_24152);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24152);
  }
}
V g_heff_2einterp_2eprim_lam11(V self, V *args) {
  V v_d_24138 = args[0];
  V v_a_24139 = args[1];
  heff_drop(self);
  V v_x1_24140 = heff_tr(heff_apply(v_a_24139, 1, (V[]){v_d_24138}));
  switch (heff_tag_of(v_x1_24140)) {
  case TAG_Ok: {
    V v_v_24141 = heff_field(v_x1_24140, 0);
    V v_ru_24x1_24140_24Ok = heff_take_reuse(v_x1_24140, 1ULL);
    switch (heff_tag_of(v_v_24141)) {
    case TAG_VFun: {
      heff_take(v_v_24141, 0ULL);
      heff_drop(v_ru_24x1_24140_24Ok);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_v_24141, 0ULL);
      heff_drop(v_ru_24x1_24140_24Ok);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take(v_v_24141, 0ULL);
      heff_drop(v_ru_24x1_24140_24Ok);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take(v_v_24141, 0ULL);
      heff_drop(v_ru_24x1_24140_24Ok);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take(v_v_24141, 0ULL);
      heff_drop(v_ru_24x1_24140_24Ok);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take(v_v_24141, 0ULL);
      heff_drop(v_ru_24x1_24140_24Ok);
      return heff_abandon();
    }
    case TAG_VArr: {
      V v_xs_24149 = heff_field(v_v_24141, 0);
      heff_take(v_v_24141, 1ULL);
      return heff_tag_at(v_ru_24x1_24140_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam12, 2, 1, (V[]){v_xs_24149})})});
    }
    case TAG_VErased: {
      heff_drop(v_v_24141);
      heff_drop(v_ru_24x1_24140_24Ok);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24141);
    }
  }
  case TAG_Abn: {
    heff_drop(v_x1_24140);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_x1_24140);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24140);
  }
}
V g_heff_2einterp_2eprim_lam10(V self, V *args) {
  V v_d_24136 = args[0];
  V v_u_24137 = args[1];
  heff_drop(self);
  heff_drop(v_d_24136);
  heff_drop(v_u_24137);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam11_clo)})});
}
V g_heff_2einterp_2eprim_lam17(V self, V *args) {
  V v_vs_24187 = args[0];
  heff_drop(self);
  V v_t_24188 = heff_tag(TAG_VArr, 1, (V[]){heff_arrayFromList(v_vs_24187)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_24188});
}
V g_heff_2einterp_2eprim_lam16(V self, V *args) {
  V v_d_24183 = args[0];
  V v_f_24184 = args[1];
  V v_a_24182 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_24185 = heff_tr(heff_apply(v_f_24184, 1, (V[]){heff_dup(v_d_24183)}));
  switch (heff_tag_of(v_x1_24185)) {
  case TAG_Ok: {
    V v_v_24186 = heff_field(v_x1_24185, 0);
    heff_take(v_x1_24185, 1ULL);
    return (g_heff_2einterp_2egenGo(v_d_24183, MK_INT(0LL), v_a_24182, v_v_24186, ((V)&g_heff_2einterp_2eprim_lam17_clo)));
  }
  case TAG_Abn: {
    heff_drop(v_d_24183);
    heff_drop(v_a_24182);
    heff_drop(v_x1_24185);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_24183);
    heff_drop(v_a_24182);
    heff_drop(v_x1_24185);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24185);
  }
}
V g_heff_2einterp_2eprim_lam15(V self, V *args) {
  V v_d_24174 = args[0];
  V v_a_24175 = args[1];
  heff_drop(self);
  V v_x1_24176 = heff_tr(heff_apply(v_a_24175, 1, (V[]){v_d_24174}));
  switch (heff_tag_of(v_x1_24176)) {
  case TAG_Ok: {
    V v_v_24177 = heff_field(v_x1_24176, 0);
    V v_ru_24x1_24176_24Ok = heff_take_reuse(v_x1_24176, 1ULL);
    switch (heff_tag_of(v_v_24177)) {
    case TAG_VFun: {
      heff_take(v_v_24177, 0ULL);
      heff_drop(v_ru_24x1_24176_24Ok);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_v_24177, 0ULL);
      heff_drop(v_ru_24x1_24176_24Ok);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take(v_v_24177, 0ULL);
      heff_drop(v_ru_24x1_24176_24Ok);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24182 = heff_field(v_v_24177, 0);
      heff_take(v_v_24177, 1ULL);
      return heff_tag_at(v_ru_24x1_24176_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam16, 2, 1, (V[]){v_a_24182})})});
    }
    case TAG_VFloat: {
      heff_take(v_v_24177, 0ULL);
      heff_drop(v_ru_24x1_24176_24Ok);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take(v_v_24177, 0ULL);
      heff_drop(v_ru_24x1_24176_24Ok);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take(v_v_24177, 0ULL);
      heff_drop(v_ru_24x1_24176_24Ok);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_v_24177);
      heff_drop(v_ru_24x1_24176_24Ok);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24177);
    }
  }
  case TAG_Abn: {
    heff_drop(v_x1_24176);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_x1_24176);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24176);
  }
}
V g_heff_2einterp_2eprim_lam14(V self, V *args) {
  V v_d_24172 = args[0];
  V v_u_24173 = args[1];
  heff_drop(self);
  heff_drop(v_d_24172);
  heff_drop(v_u_24173);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam15_clo)})});
}
V g_heff_2einterp_2eprim_lam19(V self, V *args) {
  V v_d_24195 = args[0];
  V v_l_24196 = args[1];
  heff_drop(self);
  V v_x1_24197 = heff_tr(heff_apply(v_l_24196, 1, (V[]){v_d_24195}));
  switch (heff_tag_of(v_x1_24197)) {
  case TAG_Ok: {
    V v_v_24198 = heff_field(v_x1_24197, 0);
    V v_ru_24x1_24197_24Ok = heff_take_reuse(v_x1_24197, 1ULL);
    V v_t_24199 = (g_heff_2einterp_2efromListV(v_v_24198, NTAG(TAG_Nil)));
    V v_t_24200 = heff_tag_at(v_ru_24x1_24197_24Ok, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24199)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_24200});
  }
  case TAG_Abn: {
    heff_drop(v_x1_24197);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_x1_24197);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24197);
  }
}
V g_heff_2einterp_2eprim_lam18(V self, V *args) {
  V v_d_24193 = args[0];
  V v_u_24194 = args[1];
  heff_drop(self);
  heff_drop(v_d_24193);
  heff_drop(v_u_24194);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam19_clo)})});
}
V g_heff_2einterp_2eprim_lam21(V self, V *args) {
  V v_d_24204 = args[0];
  V v_a_24205 = args[1];
  heff_drop(self);
  V v_x1_24206 = heff_tr(heff_apply(v_a_24205, 1, (V[]){v_d_24204}));
  switch (heff_tag_of(v_x1_24206)) {
  case TAG_Ok: {
    V v_v_24207 = heff_field(v_x1_24206, 0);
    V v_ru_24x1_24206_24Ok = heff_take_reuse(v_x1_24206, 1ULL);
    switch (heff_tag_of(v_v_24207)) {
    case TAG_VFun: {
      heff_take(v_v_24207, 0ULL);
      heff_drop(v_ru_24x1_24206_24Ok);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_v_24207, 0ULL);
      heff_drop(v_ru_24x1_24206_24Ok);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take(v_v_24207, 0ULL);
      heff_drop(v_ru_24x1_24206_24Ok);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take(v_v_24207, 0ULL);
      heff_drop(v_ru_24x1_24206_24Ok);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take(v_v_24207, 0ULL);
      heff_drop(v_ru_24x1_24206_24Ok);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take(v_v_24207, 0ULL);
      heff_drop(v_ru_24x1_24206_24Ok);
      return heff_abandon();
    }
    case TAG_VArr: {
      V v_xs_24215 = heff_field(v_v_24207, 0);
      heff_take(v_v_24207, 1ULL);
      return heff_tag_at(v_ru_24x1_24206_24Ok, TAG_Ok, 1, (V[]){(g_heff_2einterp_2etoListV(heff_arrayToList(v_xs_24215)))});
    }
    case TAG_VErased: {
      heff_drop(v_v_24207);
      heff_drop(v_ru_24x1_24206_24Ok);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24207);
    }
  }
  case TAG_Abn: {
    heff_drop(v_x1_24206);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_x1_24206);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24206);
  }
}
V g_heff_2einterp_2eprim_lam20(V self, V *args) {
  V v_d_24202 = args[0];
  V v_u_24203 = args[1];
  heff_drop(self);
  heff_drop(v_d_24202);
  heff_drop(v_u_24203);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam21_clo)})});
}
V g_heff_2einterp_2eprim_lam22(V self, V *args) {
  V v_d_24218 = args[0];
  V v_a_24219 = args[1];
  heff_drop(self);
  V v_x1_24220 = heff_tr(heff_apply(v_a_24219, 1, (V[]){v_d_24218}));
  switch (heff_tag_of(v_x1_24220)) {
  case TAG_Ok: {
    V v_v_24221 = heff_field(v_x1_24220, 0);
    V v_ru_24x1_24220_24Ok = heff_take_reuse(v_x1_24220, 1ULL);
    switch (heff_tag_of(v_v_24221)) {
    case TAG_VFun: {
      heff_take(v_v_24221, 0ULL);
      heff_drop(v_ru_24x1_24220_24Ok);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_v_24221, 0ULL);
      heff_drop(v_ru_24x1_24220_24Ok);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take(v_v_24221, 0ULL);
      heff_drop(v_ru_24x1_24220_24Ok);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take(v_v_24221, 0ULL);
      heff_drop(v_ru_24x1_24220_24Ok);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take(v_v_24221, 0ULL);
      heff_drop(v_ru_24x1_24220_24Ok);
      return heff_abandon();
    }
    case TAG_VStr: {
      V v_a_24228 = heff_field(v_v_24221, 0);
      V v_ru_24v_24221_24VStr = heff_take_reuse(v_v_24221, 1ULL);
      V v_t_24229 = heff_tag_at(v_ru_24x1_24220_24Ok, TAG_VInt, 1, (V[]){heff_strLength(v_a_24228)});
      return heff_tag_at(v_ru_24v_24221_24VStr, TAG_Ok, 1, (V[]){v_t_24229});
    }
    case TAG_VArr: {
      heff_take(v_v_24221, 0ULL);
      heff_drop(v_ru_24x1_24220_24Ok);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_v_24221);
      heff_drop(v_ru_24x1_24220_24Ok);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24221);
    }
  }
  case TAG_Abn: {
    heff_drop(v_x1_24220);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_x1_24220);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24220);
  }
}
V g_heff_2einterp_2eprim_lam25(V self, V *args) {
  V v_d_24252 = args[0];
  V v_a_24253 = args[1];
  V v_a_24242 = heff_dup(heff_env(self)[0]);
  V v_a_24251 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_x1_24254 = heff_tr(heff_apply(v_a_24253, 1, (V[]){v_d_24252}));
  switch (heff_tag_of(v_x1_24254)) {
  case TAG_Ok: {
    V v_v_24255 = heff_field(v_x1_24254, 0);
    V v_ru_24x1_24254_24Ok = heff_take_reuse(v_x1_24254, 1ULL);
    switch (heff_tag_of(v_v_24255)) {
    case TAG_VFun: {
      heff_take(v_v_24255, 0ULL);
      heff_drop(v_a_24242);
      heff_drop(v_a_24251);
      heff_drop(v_ru_24x1_24254_24Ok);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_v_24255, 0ULL);
      heff_drop(v_a_24242);
      heff_drop(v_a_24251);
      heff_drop(v_ru_24x1_24254_24Ok);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take(v_v_24255, 0ULL);
      heff_drop(v_a_24242);
      heff_drop(v_a_24251);
      heff_drop(v_ru_24x1_24254_24Ok);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24260 = heff_field(v_v_24255, 0);
      V v_ru_24v_24255_24VInt = heff_take_reuse(v_v_24255, 1ULL);
      V v_t_24261 = heff_tag_at(v_ru_24x1_24254_24Ok, TAG_VStr, 1, (V[]){heff_strSlice(v_a_24242, v_a_24251, v_a_24260)});
      return heff_tag_at(v_ru_24v_24255_24VInt, TAG_Ok, 1, (V[]){v_t_24261});
    }
    case TAG_VFloat: {
      heff_take(v_v_24255, 0ULL);
      heff_drop(v_a_24242);
      heff_drop(v_a_24251);
      heff_drop(v_ru_24x1_24254_24Ok);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take(v_v_24255, 0ULL);
      heff_drop(v_a_24242);
      heff_drop(v_a_24251);
      heff_drop(v_ru_24x1_24254_24Ok);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take(v_v_24255, 0ULL);
      heff_drop(v_a_24242);
      heff_drop(v_a_24251);
      heff_drop(v_ru_24x1_24254_24Ok);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_a_24242);
      heff_drop(v_a_24251);
      heff_drop(v_v_24255);
      heff_drop(v_ru_24x1_24254_24Ok);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24255);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24242);
    heff_drop(v_a_24251);
    heff_drop(v_x1_24254);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24242);
    heff_drop(v_a_24251);
    heff_drop(v_x1_24254);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24254);
  }
}
V g_heff_2einterp_2eprim_lam24(V self, V *args) {
  V v_d_24243 = args[0];
  V v_a_24244 = args[1];
  V v_a_24242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_24245 = heff_tr(heff_apply(v_a_24244, 1, (V[]){v_d_24243}));
  switch (heff_tag_of(v_x1_24245)) {
  case TAG_Ok: {
    V v_v_24246 = heff_field(v_x1_24245, 0);
    V v_ru_24x1_24245_24Ok = heff_take_reuse(v_x1_24245, 1ULL);
    switch (heff_tag_of(v_v_24246)) {
    case TAG_VFun: {
      heff_take(v_v_24246, 0ULL);
      heff_drop(v_a_24242);
      heff_drop(v_ru_24x1_24245_24Ok);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_v_24246, 0ULL);
      heff_drop(v_a_24242);
      heff_drop(v_ru_24x1_24245_24Ok);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take(v_v_24246, 0ULL);
      heff_drop(v_a_24242);
      heff_drop(v_ru_24x1_24245_24Ok);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24251 = heff_field(v_v_24246, 0);
      heff_take(v_v_24246, 1ULL);
      return heff_tag_at(v_ru_24x1_24245_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam25, 2, 2, (V[]){v_a_24242, v_a_24251})})});
    }
    case TAG_VFloat: {
      heff_take(v_v_24246, 0ULL);
      heff_drop(v_a_24242);
      heff_drop(v_ru_24x1_24245_24Ok);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take(v_v_24246, 0ULL);
      heff_drop(v_a_24242);
      heff_drop(v_ru_24x1_24245_24Ok);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take(v_v_24246, 0ULL);
      heff_drop(v_a_24242);
      heff_drop(v_ru_24x1_24245_24Ok);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_a_24242);
      heff_drop(v_v_24246);
      heff_drop(v_ru_24x1_24245_24Ok);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24242);
    heff_drop(v_x1_24245);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24242);
    heff_drop(v_x1_24245);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24245);
  }
}
V g_heff_2einterp_2eprim_lam23(V self, V *args) {
  V v_d_24232 = args[0];
  V v_a_24233 = args[1];
  heff_drop(self);
  V v_x1_24234 = heff_tr(heff_apply(v_a_24233, 1, (V[]){v_d_24232}));
  switch (heff_tag_of(v_x1_24234)) {
  case TAG_Ok: {
    V v_v_24235 = heff_field(v_x1_24234, 0);
    V v_ru_24x1_24234_24Ok = heff_take_reuse(v_x1_24234, 1ULL);
    switch (heff_tag_of(v_v_24235)) {
    case TAG_VFun: {
      heff_take(v_v_24235, 0ULL);
      heff_drop(v_ru_24x1_24234_24Ok);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_v_24235, 0ULL);
      heff_drop(v_ru_24x1_24234_24Ok);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take(v_v_24235, 0ULL);
      heff_drop(v_ru_24x1_24234_24Ok);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take(v_v_24235, 0ULL);
      heff_drop(v_ru_24x1_24234_24Ok);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take(v_v_24235, 0ULL);
      heff_drop(v_ru_24x1_24234_24Ok);
      return heff_abandon();
    }
    case TAG_VStr: {
      V v_a_24242 = heff_field(v_v_24235, 0);
      heff_take(v_v_24235, 1ULL);
      return heff_tag_at(v_ru_24x1_24234_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam24, 2, 1, (V[]){v_a_24242})})});
    }
    case TAG_VArr: {
      heff_take(v_v_24235, 0ULL);
      heff_drop(v_ru_24x1_24234_24Ok);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_v_24235);
      heff_drop(v_ru_24x1_24234_24Ok);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24235);
    }
  }
  case TAG_Abn: {
    heff_drop(v_x1_24234);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_x1_24234);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24234);
  }
}
V g_heff_2einterp_2eprim_lam27(V self, V *args) {
  V v_d_24283 = args[0];
  V v_a_24284 = args[1];
  V v_a_24282 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_24285 = heff_tr(heff_apply(v_a_24284, 1, (V[]){v_d_24283}));
  switch (heff_tag_of(v_x1_24285)) {
  case TAG_Ok: {
    V v_v_24286 = heff_field(v_x1_24285, 0);
    V v_ru_24x1_24285_24Ok = heff_take_reuse(v_x1_24285, 1ULL);
    switch (heff_tag_of(v_v_24286)) {
    case TAG_VFun: {
      heff_take(v_v_24286, 0ULL);
      heff_drop(v_a_24282);
      heff_drop(v_ru_24x1_24285_24Ok);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_v_24286, 0ULL);
      heff_drop(v_a_24282);
      heff_drop(v_ru_24x1_24285_24Ok);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take(v_v_24286, 0ULL);
      heff_drop(v_a_24282);
      heff_drop(v_ru_24x1_24285_24Ok);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24291 = heff_field(v_v_24286, 0);
      V v_ru_24v_24286_24VInt = heff_take_reuse(v_v_24286, 1ULL);
      V v_t_24292 = heff_tag_at(v_ru_24x1_24285_24Ok, TAG_VInt, 1, (V[]){heff_strCharCode(v_a_24282, v_a_24291)});
      return heff_tag_at(v_ru_24v_24286_24VInt, TAG_Ok, 1, (V[]){v_t_24292});
    }
    case TAG_VFloat: {
      heff_take(v_v_24286, 0ULL);
      heff_drop(v_a_24282);
      heff_drop(v_ru_24x1_24285_24Ok);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take(v_v_24286, 0ULL);
      heff_drop(v_a_24282);
      heff_drop(v_ru_24x1_24285_24Ok);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take(v_v_24286, 0ULL);
      heff_drop(v_a_24282);
      heff_drop(v_ru_24x1_24285_24Ok);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_a_24282);
      heff_drop(v_v_24286);
      heff_drop(v_ru_24x1_24285_24Ok);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24286);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24282);
    heff_drop(v_x1_24285);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24282);
    heff_drop(v_x1_24285);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24285);
  }
}
V g_heff_2einterp_2eprim_lam26(V self, V *args) {
  V v_d_24272 = args[0];
  V v_a_24273 = args[1];
  heff_drop(self);
  V v_x1_24274 = heff_tr(heff_apply(v_a_24273, 1, (V[]){v_d_24272}));
  switch (heff_tag_of(v_x1_24274)) {
  case TAG_Ok: {
    V v_v_24275 = heff_field(v_x1_24274, 0);
    V v_ru_24x1_24274_24Ok = heff_take_reuse(v_x1_24274, 1ULL);
    switch (heff_tag_of(v_v_24275)) {
    case TAG_VFun: {
      heff_take(v_v_24275, 0ULL);
      heff_drop(v_ru_24x1_24274_24Ok);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_v_24275, 0ULL);
      heff_drop(v_ru_24x1_24274_24Ok);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take(v_v_24275, 0ULL);
      heff_drop(v_ru_24x1_24274_24Ok);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take(v_v_24275, 0ULL);
      heff_drop(v_ru_24x1_24274_24Ok);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take(v_v_24275, 0ULL);
      heff_drop(v_ru_24x1_24274_24Ok);
      return heff_abandon();
    }
    case TAG_VStr: {
      V v_a_24282 = heff_field(v_v_24275, 0);
      heff_take(v_v_24275, 1ULL);
      return heff_tag_at(v_ru_24x1_24274_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam27, 2, 1, (V[]){v_a_24282})})});
    }
    case TAG_VArr: {
      heff_take(v_v_24275, 0ULL);
      heff_drop(v_ru_24x1_24274_24Ok);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_v_24275);
      heff_drop(v_ru_24x1_24274_24Ok);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24275);
    }
  }
  case TAG_Abn: {
    heff_drop(v_x1_24274);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_x1_24274);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24274);
  }
}
V g_heff_2einterp_2eprim_lam28(V self, V *args) {
  V v_d_24298 = args[0];
  V v_a_24299 = args[1];
  heff_drop(self);
  V v_x1_24300 = heff_tr(heff_apply(v_a_24299, 1, (V[]){v_d_24298}));
  switch (heff_tag_of(v_x1_24300)) {
  case TAG_Ok: {
    V v_v_24301 = heff_field(v_x1_24300, 0);
    V v_ru_24x1_24300_24Ok = heff_take_reuse(v_x1_24300, 1ULL);
    switch (heff_tag_of(v_v_24301)) {
    case TAG_VFun: {
      heff_take(v_v_24301, 0ULL);
      heff_drop(v_ru_24x1_24300_24Ok);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take(v_v_24301, 0ULL);
      heff_drop(v_ru_24x1_24300_24Ok);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take(v_v_24301, 0ULL);
      heff_drop(v_ru_24x1_24300_24Ok);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24306 = heff_field(v_v_24301, 0);
      V v_ru_24v_24301_24VInt = heff_take_reuse(v_v_24301, 1ULL);
      V v_t_24307 = heff_tag_at(v_ru_24x1_24300_24Ok, TAG_VStr, 1, (V[]){heff_strFromCharCode(v_a_24306)});
      return heff_tag_at(v_ru_24v_24301_24VInt, TAG_Ok, 1, (V[]){v_t_24307});
    }
    case TAG_VFloat: {
      heff_take(v_v_24301, 0ULL);
      heff_drop(v_ru_24x1_24300_24Ok);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take(v_v_24301, 0ULL);
      heff_drop(v_ru_24x1_24300_24Ok);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take(v_v_24301, 0ULL);
      heff_drop(v_ru_24x1_24300_24Ok);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_v_24301);
      heff_drop(v_ru_24x1_24300_24Ok);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24301);
    }
  }
  case TAG_Abn: {
    heff_drop(v_x1_24300);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_x1_24300);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24300);
  }
}
Clo g_heff_2einterp_2enthTh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2enthTh_entry, 2, 0};

V g_heff_2einterp_2enthTh(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_intEq(heff_dup(v_i_241), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_i_241);
      heff_drop(v_t_244);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    }
    case TAG_False: {
      heff_drop(v_t_244);
      V v_t_245 = heff_intLt(heff_dup(v_i_241), MK_INT(0LL));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        heff_drop(v_i_241);
        heff_drop(v_t_245);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        heff_drop(v_t_245);
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2enthTh_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2enthTh(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2einterp_2eevalEach_lam0(V self, V *args);
Clo g_heff_2einterp_2eevalEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eevalEach_entry, 3, 0};

V g_heff_2einterp_2eevalEach(V v_ev_240, V v_x2_241, V v_k_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ev_240);
    heff_drop(v_x2_241);
    return heff_tail(v_k_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_t_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take(v_x2_241, 3ULL);
    V v_x1_245 = heff_tr(heff_apply(heff_dup(v_ev_240), 1, (V[]){v_t_243}));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_Ok: {
      V v_v_246 = heff_field(v_x1_245, 0);
      heff_take(v_x1_245, 1ULL);
      V t_0 = v_ev_240;
      V t_1 = v_rest_244;
      V t_2 = heff_clo(g_heff_2einterp_2eevalEach_lam0, 1, 2, (V[]){v_k_242, v_v_246});
      v_ev_240 = t_0;
      v_x2_241 = t_1;
      v_k_242 = t_2;
      goto top;
    }
    case TAG_Abn: {
      heff_drop(v_ev_240);
      heff_drop(v_k_242);
      heff_drop(v_rest_244);
      heff_drop(v_x1_245);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_ev_240);
      heff_drop(v_k_242);
      heff_drop(v_rest_244);
      heff_drop(v_x1_245);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2einterp_2eevalEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eevalEach(a[0], a[1], a[2]);
}
V g_heff_2einterp_2eevalEach_lam0(V self, V *args) {
  V v_vs_247 = args[0];
  V v_k_242 = heff_dup(heff_env(self)[0]);
  V v_v_246 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_k_242, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_v_246, v_vs_247})});
}
V g_heff_2einterp_2eevalFields_lam0(V self, V *args);
Clo g_heff_2einterp_2eevalFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eevalFields_entry, 3, 0};

V g_heff_2einterp_2eevalFields(V v_ev_240, V v_x2_241, V v_k_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ev_240);
    heff_drop(v_x2_241);
    return heff_tail(v_k_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take(v_x2_241, 3ULL);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkPair: {
      V v_l_245 = heff_field(v_x21_243, 0);
      V v_t_246 = heff_field(v_x21_243, 1);
      heff_take(v_x21_243, 3ULL);
      V v_x1_247 = heff_tr(heff_apply(heff_dup(v_ev_240), 1, (V[]){v_t_246}));
      switch (heff_tag_of(v_x1_247)) {
      case TAG_Ok: {
        V v_v_248 = heff_field(v_x1_247, 0);
        heff_take(v_x1_247, 1ULL);
        V t_0 = v_ev_240;
        V t_1 = v_rest_244;
        V t_2 = heff_clo(g_heff_2einterp_2eevalFields_lam0, 1, 3, (V[]){v_l_245, v_v_248, v_k_242});
        v_ev_240 = t_0;
        v_x2_241 = t_1;
        v_k_242 = t_2;
        goto top;
      }
      case TAG_Abn: {
        heff_drop(v_ev_240);
        heff_drop(v_k_242);
        heff_drop(v_rest_244);
        heff_drop(v_l_245);
        heff_drop(v_x1_247);
        return NTAG(TAG_Abn);
      }
      case TAG_Div: {
        heff_drop(v_ev_240);
        heff_drop(v_k_242);
        heff_drop(v_rest_244);
        heff_drop(v_l_245);
        heff_drop(v_x1_247);
        return NTAG(TAG_Div);
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2einterp_2eevalFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eevalFields(a[0], a[1], a[2]);
}
V g_heff_2einterp_2eevalFields_lam0(V self, V *args) {
  V v_vs_249 = args[0];
  V v_l_245 = heff_dup(heff_env(self)[0]);
  V v_v_248 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_l_245, v_v_248}), v_vs_249});
  return heff_tail(v_k_242, 1, (V[]){v_t_2410});
}
V g_heff_2einterp_2eevalIn_lam0(V self, V *args);
V g_heff_2einterp_2eevalIn_lam1(V self, V *args);
V g_heff_2einterp_2eevalIn_lam2(V self, V *args);
V g_heff_2einterp_2eevalIn_lam3(V self, V *args);
V g_heff_2einterp_2eevalIn_lam4(V self, V *args); static Clo g_heff_2einterp_2eevalIn_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eevalIn_lam4, 1, 0};
V g_heff_2einterp_2eevalIn_lam5(V self, V *args);
V g_heff_2einterp_2eevalIn_lam6(V self, V *args);
V g_heff_2einterp_2eevalIn_lam7(V self, V *args);
Clo g_heff_2einterp_2eevalIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eevalIn_entry, 3, 0};

V g_heff_2einterp_2eevalIn(V v_d_240, V v_e_241, V v_t_242) {
top: ;
  V v_t_243 = heff_intLt(heff_dup(g_heff_2einterp_2edeepest_get()), heff_dup(v_d_240));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_d_240);
    heff_drop(v_e_241);
    heff_drop(v_t_242);
    heff_drop(v_t_243);
    return NTAG(TAG_Div);
  }
  case TAG_False: {
    heff_drop(v_t_243);
    switch (heff_tag_of(v_t_242)) {
    case TAG_SLocal: {
      V v_i_244 = heff_field(v_t_242, 0);
      heff_take(v_t_242, 1ULL);
      V v_t_245 = ({ V b_0 = heff_get(v_e_241, LBL_local); V a_1 = v_i_244; V r_ = (g_heff_2einterp_2enthTh(b_0, a_1)); heff_drop(b_0); r_; });
      switch (heff_tag_of(v_t_245)) {
      case TAG_Nothing: {
        heff_drop(v_d_240);
        heff_drop(v_t_245);
        return heff_abandon();
      }
      case TAG_Just: {
        V v_v_246 = heff_field(v_t_245, 0);
        heff_take(v_t_245, 1ULL);
        return heff_tail(v_v_246, 1, (V[]){v_d_240});
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    case TAG_SGlobal: {
      V v_x_247 = heff_field(v_t_242, 0);
      heff_take(v_t_242, 1ULL);
      V v_t_248 = ({ V a_0 = v_x_247; V b_1 = heff_get(v_e_241, LBL_global); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nothing: {
        heff_drop(v_d_240);
        heff_drop(v_t_248);
        return heff_abandon();
      }
      case TAG_Just: {
        V v_v_249 = heff_field(v_t_248, 0);
        heff_take(v_t_248, 1ULL);
        return heff_tail(v_v_249, 1, (V[]){v_d_240});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    case TAG_SCode: {
      V v_ru_24t_242_24SCode = heff_take_reuse(v_t_242, 0ULL);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag_at(v_ru_24t_242_24SCode, TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
    }
    case TAG_SApp: {
      V v_t1_2411 = heff_field(v_t_242, 0);
      V v_t2_2412 = heff_field(v_t_242, 1);
      heff_take(v_t_242, 3ULL);
      V v_x1_2413 = heff_tr(g_heff_2einterp_2eevalIn(heff_intAdd(heff_dup(v_d_240), MK_INT(1LL)), heff_dup(v_e_241), v_t1_2411));
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_Ok: {
        V v_v_2414 = heff_field(v_x1_2413, 0);
        V v_ru_24x1_2413_24Ok = heff_take_reuse(v_x1_2413, 1ULL);
        V v_x1_2415 = heff_tr(g_heff_2einterp_2eevalIn(heff_intAdd(heff_dup(v_d_240), MK_INT(1LL)), v_e_241, v_t2_2412));
        switch (heff_tag_of(v_x1_2415)) {
        case TAG_Ok: {
          V v_v_2416 = heff_field(v_x1_2415, 0);
          heff_take(v_x1_2415, 1ULL);
          switch (heff_tag_of(v_v_2414)) {
          case TAG_VFun: {
            V v_f_2417 = heff_field(v_v_2414, 0);
            heff_take(v_v_2414, 1ULL);
            heff_drop(v_ru_24x1_2413_24Ok);
            return heff_tail(v_f_2417, 2, (V[]){v_d_240, heff_clo(g_heff_2einterp_2eevalIn_lam0, 1, 1, (V[]){v_v_2416})});
          }
          case TAG_VCons: {
            heff_take(v_v_2414, 0ULL);
            heff_drop(v_d_240);
            heff_drop(v_ru_24x1_2413_24Ok);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VTag: {
            heff_take(v_v_2414, 0ULL);
            heff_drop(v_d_240);
            heff_drop(v_ru_24x1_2413_24Ok);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VInt: {
            heff_take(v_v_2414, 0ULL);
            heff_drop(v_d_240);
            heff_drop(v_ru_24x1_2413_24Ok);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VFloat: {
            heff_take(v_v_2414, 0ULL);
            heff_drop(v_d_240);
            heff_drop(v_ru_24x1_2413_24Ok);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VStr: {
            heff_take(v_v_2414, 0ULL);
            heff_drop(v_d_240);
            heff_drop(v_ru_24x1_2413_24Ok);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VArr: {
            heff_take(v_v_2414, 0ULL);
            heff_drop(v_d_240);
            heff_drop(v_ru_24x1_2413_24Ok);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VErased: {
            heff_drop(v_d_240);
            heff_drop(v_v_2414);
            heff_drop(v_v_2416);
            return heff_tag_at(v_ru_24x1_2413_24Ok, TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
          }
          default: return heff_nomatch(v_v_2414);
          }
        }
        case TAG_Abn: {
          heff_drop(v_d_240);
          heff_drop(v_v_2414);
          heff_drop(v_ru_24x1_2413_24Ok);
          heff_drop(v_x1_2415);
          return NTAG(TAG_Abn);
        }
        case TAG_Div: {
          heff_drop(v_d_240);
          heff_drop(v_v_2414);
          heff_drop(v_ru_24x1_2413_24Ok);
          heff_drop(v_x1_2415);
          return NTAG(TAG_Div);
        }
        default: return heff_nomatch(v_x1_2415);
        }
      }
      case TAG_Abn: {
        heff_drop(v_d_240);
        heff_drop(v_e_241);
        heff_drop(v_t2_2412);
        heff_drop(v_x1_2413);
        return NTAG(TAG_Abn);
      }
      case TAG_Div: {
        heff_drop(v_d_240);
        heff_drop(v_e_241);
        heff_drop(v_t2_2412);
        heff_drop(v_x1_2413);
        return NTAG(TAG_Div);
      }
      default: return heff_nomatch(v_x1_2413);
      }
    }
    case TAG_SLam: {
      V v_it2_2427 = heff_field(v_t_242, 1);
      heff_take(v_t_242, 2ULL);
      heff_drop(v_d_240);
      switch (heff_tag_of(v_it2_2427)) {
      case TAG_MkAbs: {
        V v_body_2429 = heff_field(v_it2_2427, 1);
        heff_take(v_it2_2427, 2ULL);
        return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eevalIn_lam1, 2, 2, (V[]){v_e_241, v_body_2429})})});
      }
      case TAG_AbsConst: {
        V v_body_2434 = heff_field(v_it2_2427, 0);
        V v_ru_24it2_2427_24AbsConst = heff_take_reuse(v_it2_2427, 1ULL);
        return heff_tag_at(v_ru_24it2_2427_24AbsConst, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eevalIn_lam2, 2, 2, (V[]){v_e_241, v_body_2434})})});
      }
      default: return heff_nomatch(v_it2_2427);
      }
    }
    case TAG_SCons: {
      V v_fs_2437 = heff_field(v_t_242, 0);
      heff_take(v_t_242, 1ULL);
      V v_t_2438 = heff_arrayToList(heff_get(heff_dup(v_fs_2437), LBL_keys));
      V v_t_2439 = heff_arrayToList(heff_get(v_fs_2437, LBL_values));
      V v_t_2440 = (g_heff_2edict_2ezipKV(v_t_2438, v_t_2439));
      return (g_heff_2einterp_2eevalFields(heff_clo(g_heff_2einterp_2eevalIn_lam3, 1, 2, (V[]){v_d_240, v_e_241}), v_t_2440, ((V)&g_heff_2einterp_2eevalIn_lam4_clo)));
    }
    case TAG_SProj: {
      V v_t2_2447 = heff_field(v_t_242, 0);
      V v_x_2448 = heff_field(v_t_242, 1);
      heff_take(v_t_242, 3ULL);
      V v_x1_2449 = heff_tr(g_heff_2einterp_2eevalIn(heff_intAdd(v_d_240, MK_INT(1LL)), v_e_241, v_t2_2447));
      switch (heff_tag_of(v_x1_2449)) {
      case TAG_Ok: {
        V v_v_2450 = heff_field(v_x1_2449, 0);
        heff_take(v_x1_2449, 1ULL);
        return (g_heff_2einterp_2eprojV(v_v_2450, v_x_2448));
      }
      case TAG_Abn: {
        heff_drop(v_x_2448);
        heff_drop(v_x1_2449);
        return NTAG(TAG_Abn);
      }
      case TAG_Div: {
        heff_drop(v_x_2448);
        heff_drop(v_x1_2449);
        return NTAG(TAG_Div);
      }
      default: return heff_nomatch(v_x1_2449);
      }
    }
    case TAG_STag: {
      V v_x_2451 = heff_field(v_t_242, 0);
      V v_ts_2452 = heff_field(v_t_242, 1);
      heff_take(v_t_242, 3ULL);
      return (g_heff_2einterp_2eevalEach(heff_clo(g_heff_2einterp_2eevalIn_lam5, 1, 2, (V[]){v_d_240, v_e_241}), heff_arrayToList(v_ts_2452), heff_clo(g_heff_2einterp_2eevalIn_lam6, 1, 1, (V[]){v_x_2451})));
    }
    case TAG_SMatch: {
      V v_scrut_2455 = heff_field(v_t_242, 0);
      V v_cases_2456 = heff_field(v_t_242, 1);
      heff_take(v_t_242, 3ULL);
      V v_x1_2457 = heff_tr(g_heff_2einterp_2eevalIn(heff_intAdd(heff_dup(v_d_240), MK_INT(1LL)), heff_dup(v_e_241), v_scrut_2455));
      switch (heff_tag_of(v_x1_2457)) {
      case TAG_Ok: {
        V v_v_2458 = heff_field(v_x1_2457, 0);
        V v_ru_24x1_2457_24Ok = heff_take_reuse(v_x1_2457, 1ULL);
        switch (heff_tag_of(v_v_2458)) {
        case TAG_VFun: {
          heff_take(v_v_2458, 0ULL);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2456);
          heff_drop(v_ru_24x1_2457_24Ok);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take(v_v_2458, 0ULL);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2456);
          heff_drop(v_ru_24x1_2457_24Ok);
          return heff_abandon();
        }
        case TAG_VTag: {
          V v_x_2461 = heff_field(v_v_2458, 0);
          V v_vs_2462 = heff_field(v_v_2458, 1);
          heff_take(v_v_2458, 3ULL);
          V v_t_2463 = ({ V a_0 = v_x_2461; V b_1 = heff_get(heff_dup(v_cases_2456), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
          V v_it_2469;
          switch (heff_tag_of(v_t_2463)) {
          case TAG_Nothing: {
            heff_drop(v_cases_2456);
            heff_drop(v_ru_24x1_2457_24Ok);
            heff_drop(v_t_2463);
            v_it_2469 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_i_2464 = heff_field(v_t_2463, 0);
            heff_take(v_t_2463, 1ULL);
            V v_xs_2465 = heff_get(v_cases_2456, LBL_values);
            V v_t_2466 = heff_intLe(MK_INT(0LL), heff_dup(v_i_2464));
            switch (heff_tag_of(v_t_2466)) {
            case TAG_True: {
              heff_drop(v_t_2466);
              V v_t_2467 = heff_intLt(heff_dup(v_i_2464), heff_arrayLength(heff_dup(v_xs_2465)));
              switch (heff_tag_of(v_t_2467)) {
              case TAG_True: {
                heff_drop(v_t_2467);
                V v_t_2468 = heff_arrayIndex(v_xs_2465, v_i_2464);
                v_it_2469 = heff_tag_at(v_ru_24x1_2457_24Ok, TAG_Just, 1, (V[]){v_t_2468});
                break;
              }
              case TAG_False: {
                heff_drop(v_ru_24x1_2457_24Ok);
                heff_drop(v_i_2464);
                heff_drop(v_xs_2465);
                heff_drop(v_t_2467);
                v_it_2469 = NTAG(TAG_Nothing);
                break;
              }
              default: heff_nomatch(v_t_2467);
              }
              break;
            }
            case TAG_False: {
              heff_drop(v_ru_24x1_2457_24Ok);
              heff_drop(v_i_2464);
              heff_drop(v_xs_2465);
              heff_drop(v_t_2466);
              v_it_2469 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_t_2466);
            }
            break;
          }
          default: heff_nomatch(v_t_2463);
          }
          switch (heff_tag_of(v_it_2469)) {
          case TAG_Nothing: {
            heff_drop(v_d_240);
            heff_drop(v_e_241);
            heff_drop(v_vs_2462);
            heff_drop(v_it_2469);
            return heff_abandon();
          }
          case TAG_Just: {
            V v_it1_2470 = heff_field(v_it_2469, 0);
            heff_take(v_it_2469, 1ULL);
            switch (heff_tag_of(v_it1_2470)) {
            case TAG_MkPair: {
              V v_body_2472 = heff_field(v_it1_2470, 1);
              heff_take(v_it1_2470, 2ULL);
              V v_t_2473 = (g_prelude_2efoldl_24s41(v_e_241, v_vs_2462));
              V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
              V t_1 = v_t_2473;
              V t_2 = v_body_2472;
              v_d_240 = t_0;
              v_e_241 = t_1;
              v_t_242 = t_2;
              goto top;
            }
            default: return heff_nomatch(v_it1_2470);
            }
          }
          default: return heff_nomatch(v_it_2469);
          }
        }
        case TAG_VInt: {
          heff_take(v_v_2458, 0ULL);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2456);
          heff_drop(v_ru_24x1_2457_24Ok);
          return heff_abandon();
        }
        case TAG_VFloat: {
          heff_take(v_v_2458, 0ULL);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2456);
          heff_drop(v_ru_24x1_2457_24Ok);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take(v_v_2458, 0ULL);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2456);
          heff_drop(v_ru_24x1_2457_24Ok);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take(v_v_2458, 0ULL);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2456);
          heff_drop(v_ru_24x1_2457_24Ok);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2456);
          heff_drop(v_v_2458);
          return heff_tag_at(v_ru_24x1_2457_24Ok, TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
        }
        default: return heff_nomatch(v_v_2458);
        }
      }
      case TAG_Abn: {
        heff_drop(v_d_240);
        heff_drop(v_e_241);
        heff_drop(v_cases_2456);
        heff_drop(v_x1_2457);
        return NTAG(TAG_Abn);
      }
      case TAG_Div: {
        heff_drop(v_d_240);
        heff_drop(v_e_241);
        heff_drop(v_cases_2456);
        heff_drop(v_x1_2457);
        return NTAG(TAG_Div);
      }
      default: return heff_nomatch(v_x1_2457);
      }
    }
    case TAG_SSpecialize: {
      heff_take(v_t_242, 0ULL);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
    }
    case TAG_SIs: {
      V v_t2_2481 = heff_field(v_t_242, 0);
      heff_take(v_t_242, 1ULL);
      V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
      V t_1 = v_e_241;
      V t_2 = v_t2_2481;
      v_d_240 = t_0;
      v_e_241 = t_1;
      v_t_242 = t_2;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      heff_drop(v_t_242);
      return heff_abandon();
    }
    case TAG_SAbandon: {
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      heff_drop(v_t_242);
      return NTAG(TAG_Abn);
    }
    case TAG_SRec: {
      V v_t2_2482 = heff_field(v_t_242, 0);
      heff_take(v_t_242, 1ULL);
      V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
      V t_1 = v_e_241;
      V t_2 = v_t2_2482;
      v_d_240 = t_0;
      v_e_241 = t_1;
      v_t_242 = t_2;
      goto top;
    }
    case TAG_SFix: {
      V v_ty_2483 = heff_field(v_t_242, 0);
      V v_it2_2484 = heff_field(v_t_242, 1);
      V v_ru_24t_242_24SFix = heff_take_reuse(v_t_242, 3ULL);
      switch (heff_tag_of(v_it2_2484)) {
      case TAG_MkAbs: {
        V v_x_2485 = heff_field(v_it2_2484, 0);
        V v_body_2486 = heff_field(v_it2_2484, 1);
        heff_take(v_it2_2484, 3ULL);
        V v_t_2489 = heff_tag_at(v_ru_24t_242_24SFix, TAG_Cons, 2, (V[]){heff_clo(g_heff_2einterp_2eevalIn_lam7, 1, 4, (V[]){v_ty_2483, v_x_2485, heff_dup(v_body_2486), heff_dup(v_e_241)}), heff_get(heff_dup(v_e_241), LBL_local)});
        V v_t_2490 = heff_rec(2, shape_170_109, (V[]){v_t_2489, heff_get(v_e_241, LBL_global)});
        V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
        V t_1 = v_t_2490;
        V t_2 = v_body_2486;
        v_d_240 = t_0;
        v_e_241 = t_1;
        v_t_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_body_2491 = heff_field(v_it2_2484, 0);
        heff_take(v_it2_2484, 1ULL);
        heff_drop(v_ty_2483);
        heff_drop(v_ru_24t_242_24SFix);
        V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
        V t_1 = v_e_241;
        V t_2 = v_body_2491;
        v_d_240 = t_0;
        v_e_241 = t_1;
        v_t_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_it2_2484);
      }
    }
    case TAG_SImplicit: {
      V v_t2_2493 = heff_field(v_t_242, 1);
      heff_take(v_t_242, 2ULL);
      V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
      V t_1 = v_e_241;
      V t_2 = v_t2_2493;
      v_d_240 = t_0;
      v_e_241 = t_1;
      v_t_242 = t_2;
      goto top;
    }
    case TAG_SPrim: {
      V v_x_2494 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SPrim = heff_take_reuse(v_t_242, 1ULL);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag_at(v_ru_24t_242_24SPrim, TAG_Ok, 1, (V[]){(g_heff_2einterp_2eprim(v_x_2494))});
    }
    case TAG_SMetaApp: {
      heff_take(v_t_242, 0ULL);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_abandon();
    }
    case TAG_SLitInt: {
      V v_i_2498 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SLitInt = heff_take_reuse(v_t_242, 1ULL);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag_at(v_ru_24t_242_24SLitInt, TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_i_2498})});
    }
    case TAG_SLitFloat: {
      V v_x_2499 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SLitFloat = heff_take_reuse(v_t_242, 1ULL);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag_at(v_ru_24t_242_24SLitFloat, TAG_Ok, 1, (V[]){heff_tag(TAG_VFloat, 1, (V[]){v_x_2499})});
    }
    case TAG_SLitString: {
      V v_s_24100 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SLitString = heff_take_reuse(v_t_242, 1ULL);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag_at(v_ru_24t_242_24SLitString, TAG_Ok, 1, (V[]){heff_tag(TAG_VStr, 1, (V[]){v_s_24100})});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2einterp_2eevalIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eevalIn(a[0], a[1], a[2]);
}
V g_heff_2einterp_2eevalIn_lam0(V self, V *args) {
  V v_d_2418 = args[0];
  V v_v_2416 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_d_2418);
  return heff_tag(TAG_Ok, 1, (V[]){v_v_2416});
}
V g_heff_2einterp_2eevalIn_lam1(V self, V *args) {
  V v_dc_2430 = args[0];
  V v_v_2431 = args[1];
  V v_e_241 = heff_dup(heff_env(self)[0]);
  V v_body_2429 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2432 = heff_tag(TAG_Cons, 2, (V[]){v_v_2431, heff_get(heff_dup(v_e_241), LBL_local)});
  V v_t_2433 = heff_rec(2, shape_170_109, (V[]){v_t_2432, heff_get(v_e_241, LBL_global)});
  return (g_heff_2einterp_2eevalIn(heff_intAdd(v_dc_2430, MK_INT(1LL)), v_t_2433, v_body_2429));
}
V g_heff_2einterp_2eevalIn_lam2(V self, V *args) {
  V v_dc_2435 = args[0];
  V v_u_2436 = args[1];
  V v_e_241 = heff_dup(heff_env(self)[0]);
  V v_body_2434 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_u_2436);
  return (g_heff_2einterp_2eevalIn(heff_intAdd(v_dc_2435, MK_INT(1LL)), v_e_241, v_body_2434));
}
V g_heff_2einterp_2eevalIn_lam3(V self, V *args) {
  V v_t2_2441 = args[0];
  V v_d_240 = heff_dup(heff_env(self)[0]);
  V v_e_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return (g_heff_2einterp_2eevalIn(heff_intAdd(v_d_240, MK_INT(1LL)), v_e_241, v_t2_2441));
}
V g_heff_2einterp_2eevalIn_lam4(V self, V *args) {
  V v_vs_2442 = args[0];
  heff_drop(self);
  V v_t_2443 = (g_prelude_2emap_24s5(heff_dup(v_vs_2442)));
  V v_t_2444 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_vs_2442));
  V v_t_2445 = (g_prelude_2emap_24s6(v_vs_2442));
  V v_t_2446 = heff_rec(3, shape_146_32_353, (V[]){heff_arrayFromList(v_t_2443), v_t_2444, heff_arrayFromList(v_t_2445)});
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VCons, 1, (V[]){v_t_2446})});
}
V g_heff_2einterp_2eevalIn_lam5(V self, V *args) {
  V v_t2_2453 = args[0];
  V v_d_240 = heff_dup(heff_env(self)[0]);
  V v_e_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return (g_heff_2einterp_2eevalIn(heff_intAdd(v_d_240, MK_INT(1LL)), v_e_241, v_t2_2453));
}
V g_heff_2einterp_2eevalIn_lam6(V self, V *args) {
  V v_vs_2454 = args[0];
  V v_x_2451 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VTag, 2, (V[]){v_x_2451, v_vs_2454})});
}
V g_heff_2einterp_2eevalIn_lam7(V self, V *args) {
  V v_dc_2487 = args[0];
  V v_ty_2483 = heff_dup(heff_env(self)[0]);
  V v_x_2485 = heff_dup(heff_env(self)[1]);
  V v_body_2486 = heff_dup(heff_env(self)[2]);
  V v_e_241 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2488 = heff_tag(TAG_SFix, 2, (V[]){v_ty_2483, heff_tag(TAG_MkAbs, 2, (V[]){v_x_2485, v_body_2486})});
  return (g_heff_2einterp_2eevalIn(v_dc_2487, v_e_241, v_t_2488));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eescAt_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eescAt_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eescAt_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eescAt_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eescAt_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 116}};
Clo g_heff_2einterp_2eescAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eescAt_entry, 2, 0};

V g_heff_2einterp_2eescAt(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(34LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    heff_drop(v_t_242);
    return ((V)&g_heff_2einterp_2eescAt_str0);
  }
  case TAG_False: {
    heff_drop(v_t_242);
    V v_t_243 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(92LL));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      heff_drop(v_t_243);
      return ((V)&g_heff_2einterp_2eescAt_str1);
    }
    case TAG_False: {
      heff_drop(v_t_243);
      V v_t_244 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(10LL));
      switch (heff_tag_of(v_t_244)) {
      case TAG_True: {
        heff_drop(v_s_240);
        heff_drop(v_i_241);
        heff_drop(v_t_244);
        return ((V)&g_heff_2einterp_2eescAt_str2);
      }
      case TAG_False: {
        heff_drop(v_t_244);
        V v_t_245 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(13LL));
        switch (heff_tag_of(v_t_245)) {
        case TAG_True: {
          heff_drop(v_s_240);
          heff_drop(v_i_241);
          heff_drop(v_t_245);
          return ((V)&g_heff_2einterp_2eescAt_str3);
        }
        case TAG_False: {
          heff_drop(v_t_245);
          V v_t_246 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(9LL));
          switch (heff_tag_of(v_t_246)) {
          case TAG_True: {
            heff_drop(v_s_240);
            heff_drop(v_i_241);
            heff_drop(v_t_246);
            return ((V)&g_heff_2einterp_2eescAt_str4);
          }
          case TAG_False: {
            heff_drop(v_t_246);
            return heff_strSlice(v_s_240, heff_dup(v_i_241), heff_intAdd(v_i_241, MK_INT(1LL)));
          }
          default: return heff_nomatch(v_t_246);
          }
        }
        default: return heff_nomatch(v_t_245);
        }
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2einterp_2eescAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eescAt(a[0], a[1]);
}
Clo g_heff_2einterp_2equoteGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2equoteGo_entry, 3, 0};

V g_heff_2einterp_2equoteGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  V v_t_243 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    heff_drop(v_t_243);
    return v_acc_242;
  }
  case TAG_False: {
    heff_drop(v_t_243);
    V v_t_244 = heff_strAppend(v_acc_242, (g_heff_2einterp_2eescAt(heff_dup(v_s_240), heff_dup(v_i_241))));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_244;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2einterp_2equoteGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2equoteGo(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str6 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str7 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str10 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str11 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str15 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str16 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str19 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str20 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str21 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str22 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str25 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str26 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str27 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eshowValGo_str28 = {{0x80000000u, K_STR, 0}, 2, 2, {123, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eshowValGo_str29 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {39}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {39}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {39}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {39}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str34 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str36 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str37 = {{0x80000000u, K_STR, 0}, 1, 1, {39}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str38 = {{0x80000000u, K_STR, 0}, 1, 1, {39}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str39 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str40 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str41 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str42 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str43 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str44 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str45 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str46 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str47 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str48 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str49 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str50 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str51 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str52 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str53 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str54 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str55 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str56 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str57 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str58 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str59 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str60 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str61 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str62 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str63 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str64 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str65 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str66 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str67 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str68 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str69 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str70 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str71 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str72 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str73 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str74 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str75 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str76 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str77 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str78 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str79 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str80 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str81 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str82 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str83 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str84 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str85 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str86 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str87 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str88 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str89 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str90 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str91 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str92 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str93 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str94 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str95 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str96 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str97 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str98 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str99 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str100 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str101 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str102 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str103 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str104 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str105 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str106 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str107 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str108 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str109 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str110 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str111 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str112 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str113 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str114 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str115 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str116 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str117 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str118 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str119 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str120 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str121 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str122 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str123 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str124 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str125 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str126 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str127 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str128 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str129 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str130 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str131 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str132 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str133 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str134 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str135 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str136 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str137 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str138 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str139 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str140 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str141 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str142 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str143 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str144 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str145 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str146 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str147 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str148 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str149 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str150 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
Clo g_heff_2einterp_2eshowValGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eshowValGo_entry, 2, 0};

V g_heff_2einterp_2eshowValGo(V v_inArg_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_VFun: {
    V v_t_2413;
    switch (heff_tag_of(v_inArg_240)) {
    case TAG_True: {
      V v_s_2412;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_s_2412 = ((V)&g_heff_2einterp_2eshowValGo_str0);
        break;
      }
      case TAG_VCons: {
        v_s_2412 = ((V)&g_heff_2einterp_2eshowValGo_str1);
        break;
      }
      case TAG_VTag: {
        v_s_2412 = ((V)&g_heff_2einterp_2eshowValGo_str2);
        break;
      }
      case TAG_VInt: {
        V v_i_247 = heff_field(v_v_241, 0);
        v_s_2412 = heff_intShow(heff_dup(v_i_247));
        break;
      }
      case TAG_VFloat: {
        V v_x_248 = heff_field(v_v_241, 0);
        v_s_2412 = heff_floatShow(heff_dup(v_x_248));
        break;
      }
      case TAG_VStr: {
        V v_s_249 = heff_field(v_v_241, 0);
        V v_t_2410 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_249), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str3)));
        v_s_2412 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str4), heff_strAppend(v_t_2410, ((V)&g_heff_2einterp_2eshowValGo_str5)));
        break;
      }
      case TAG_VArr: {
        v_s_2412 = ((V)&g_heff_2einterp_2eshowValGo_str6);
        break;
      }
      case TAG_VErased: {
        v_s_2412 = ((V)&g_heff_2einterp_2eshowValGo_str7);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      v_t_2413 = heff_strEq(heff_strSlice(v_s_2412, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2einterp_2eshowValGo_str8));
      break;
    }
    case TAG_False: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_inArg_240);
    }
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      heff_drop(v_t_2413);
      V v_t_2423;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_t_2423 = ((V)&g_heff_2einterp_2eshowValGo_str9);
        break;
      }
      case TAG_VCons: {
        v_t_2423 = ((V)&g_heff_2einterp_2eshowValGo_str10);
        break;
      }
      case TAG_VTag: {
        v_t_2423 = ((V)&g_heff_2einterp_2eshowValGo_str11);
        break;
      }
      case TAG_VInt: {
        V v_i_2418 = heff_field(v_v_241, 0);
        v_t_2423 = heff_intShow(heff_dup(v_i_2418));
        break;
      }
      case TAG_VFloat: {
        V v_x_2419 = heff_field(v_v_241, 0);
        v_t_2423 = heff_floatShow(heff_dup(v_x_2419));
        break;
      }
      case TAG_VStr: {
        V v_s_2420 = heff_field(v_v_241, 0);
        V v_t_2421 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_2420), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str12)));
        v_t_2423 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str13), heff_strAppend(v_t_2421, ((V)&g_heff_2einterp_2eshowValGo_str14)));
        break;
      }
      case TAG_VArr: {
        v_t_2423 = ((V)&g_heff_2einterp_2eshowValGo_str15);
        break;
      }
      case TAG_VErased: {
        v_t_2423 = ((V)&g_heff_2einterp_2eshowValGo_str16);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str17), heff_strAppend(v_t_2423, ((V)&g_heff_2einterp_2eshowValGo_str18)));
    }
    case TAG_False: {
      heff_drop(v_t_2413);
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        return ((V)&g_heff_2einterp_2eshowValGo_str19);
      }
      case TAG_VCons: {
        return ((V)&g_heff_2einterp_2eshowValGo_str20);
      }
      case TAG_VTag: {
        return ((V)&g_heff_2einterp_2eshowValGo_str21);
      }
      case TAG_VInt: {
        V v_i_2428 = heff_field(v_v_241, 0);
        return heff_intShow(heff_dup(v_i_2428));
      }
      case TAG_VFloat: {
        V v_x_2429 = heff_field(v_v_241, 0);
        return heff_floatShow(heff_dup(v_x_2429));
      }
      case TAG_VStr: {
        V v_s_2430 = heff_field(v_v_241, 0);
        V v_t_2431 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_2430), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str22)));
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str23), heff_strAppend(v_t_2431, ((V)&g_heff_2einterp_2eshowValGo_str24)));
      }
      case TAG_VArr: {
        return ((V)&g_heff_2einterp_2eshowValGo_str25);
      }
      case TAG_VErased: {
        return ((V)&g_heff_2einterp_2eshowValGo_str26);
      }
      default: return heff_nomatch(v_v_241);
      }
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  case TAG_VCons: {
    V v_fs_2433 = heff_field(v_v_241, 0);
    V v_t_2434 = heff_arrayToList(heff_get(heff_dup(v_fs_2433), LBL_keys));
    V v_t_2435 = heff_arrayToList(heff_get(heff_dup(v_fs_2433), LBL_values));
    V v_t_2436 = (g_heff_2edict_2ezipKV(v_t_2434, v_t_2435));
    V v_x2_2437 = (g_prelude_2emap_24s42(v_t_2436));
    V v_t_2440;
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_Nil: {
      heff_drop(v_x2_2437);
      v_t_2440 = ((V)&g_heff_2einterp_2eshowValGo_str27);
      break;
    }
    case TAG_Cons: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_xs_2439 = heff_field(v_x2_2437, 1);
      heff_take(v_x2_2437, 3ULL);
      v_t_2440 = ({ V a_0 = v_x_2438; V a_1 = v_xs_2439; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2439); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2437);
    }
    return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str28), heff_strAppend(v_t_2440, ((V)&g_heff_2einterp_2eshowValGo_str29)));
  }
  case TAG_VTag: {
    V v_x_2441 = heff_field(v_v_241, 0);
    V v_vs_2442 = heff_field(v_v_241, 1);
    V v_t_2445;
    switch (heff_tag_of(v_vs_2442)) {
    case TAG_Nil: {
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_vs_2442);
    }
    switch (heff_tag_of(v_t_2445)) {
    case TAG_True: {
      heff_drop(v_t_2445);
      V v_t_2446 = heff_intLe(MK_INT(65LL), heff_strCharCode(heff_dup(v_x_2441), MK_INT(0LL)));
      switch (heff_tag_of(v_t_2446)) {
      case TAG_True: {
        heff_drop(v_t_2446);
        V v_t_2447 = heff_intLe(heff_strCharCode(heff_dup(v_x_2441), MK_INT(0LL)), MK_INT(90LL));
        switch (heff_tag_of(v_t_2447)) {
        case TAG_True: {
          heff_drop(v_t_2447);
          return heff_dup(v_x_2441);
        }
        case TAG_False: {
          heff_drop(v_t_2447);
          return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str30), heff_dup(v_x_2441));
        }
        default: return heff_nomatch(v_t_2447);
        }
      }
      case TAG_False: {
        heff_drop(v_t_2446);
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str31), heff_dup(v_x_2441));
      }
      default: return heff_nomatch(v_t_2446);
      }
    }
    case TAG_False: {
      heff_drop(v_t_2445);
      switch (heff_tag_of(v_inArg_240)) {
      case TAG_True: {
        V v_t_2448 = heff_intLe(MK_INT(65LL), heff_strCharCode(heff_dup(v_x_2441), MK_INT(0LL)));
        V v_t_2450;
        switch (heff_tag_of(v_t_2448)) {
        case TAG_True: {
          heff_drop(v_t_2448);
          V v_t_2449 = heff_intLe(heff_strCharCode(heff_dup(v_x_2441), MK_INT(0LL)), MK_INT(90LL));
          switch (heff_tag_of(v_t_2449)) {
          case TAG_True: {
            heff_drop(v_t_2449);
            v_t_2450 = heff_dup(v_x_2441);
            break;
          }
          case TAG_False: {
            heff_drop(v_t_2449);
            v_t_2450 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str32), heff_dup(v_x_2441));
            break;
          }
          default: heff_nomatch(v_t_2449);
          }
          break;
        }
        case TAG_False: {
          heff_drop(v_t_2448);
          v_t_2450 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str33), heff_dup(v_x_2441));
          break;
        }
        default: heff_nomatch(v_t_2448);
        }
        V v_x2_2451 = (g_prelude_2emap_24s43(heff_dup(v_vs_2442)));
        V v_t_2454;
        switch (heff_tag_of(v_x2_2451)) {
        case TAG_Nil: {
          heff_drop(v_x2_2451);
          v_t_2454 = ((V)&g_heff_2einterp_2eshowValGo_str34);
          break;
        }
        case TAG_Cons: {
          V v_x_2452 = heff_field(v_x2_2451, 0);
          V v_xs_2453 = heff_field(v_x2_2451, 1);
          heff_take(v_x2_2451, 3ULL);
          v_t_2454 = ({ V a_0 = v_x_2452; V a_1 = v_xs_2453; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2453); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2451);
        }
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str35), heff_strAppend(v_t_2450, heff_strAppend(v_t_2454, ((V)&g_heff_2einterp_2eshowValGo_str36))));
      }
      case TAG_False: {
        V v_t_2455 = heff_intLe(MK_INT(65LL), heff_strCharCode(heff_dup(v_x_2441), MK_INT(0LL)));
        V v_t_2457;
        switch (heff_tag_of(v_t_2455)) {
        case TAG_True: {
          heff_drop(v_t_2455);
          V v_t_2456 = heff_intLe(heff_strCharCode(heff_dup(v_x_2441), MK_INT(0LL)), MK_INT(90LL));
          switch (heff_tag_of(v_t_2456)) {
          case TAG_True: {
            heff_drop(v_t_2456);
            v_t_2457 = heff_dup(v_x_2441);
            break;
          }
          case TAG_False: {
            heff_drop(v_t_2456);
            v_t_2457 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str37), heff_dup(v_x_2441));
            break;
          }
          default: heff_nomatch(v_t_2456);
          }
          break;
        }
        case TAG_False: {
          heff_drop(v_t_2455);
          v_t_2457 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str38), heff_dup(v_x_2441));
          break;
        }
        default: heff_nomatch(v_t_2455);
        }
        V v_x2_2458 = (g_prelude_2emap_24s43(heff_dup(v_vs_2442)));
        V v_t_2461;
        switch (heff_tag_of(v_x2_2458)) {
        case TAG_Nil: {
          heff_drop(v_x2_2458);
          v_t_2461 = ((V)&g_heff_2einterp_2eshowValGo_str39);
          break;
        }
        case TAG_Cons: {
          V v_x_2459 = heff_field(v_x2_2458, 0);
          V v_xs_2460 = heff_field(v_x2_2458, 1);
          heff_take(v_x2_2458, 3ULL);
          v_t_2461 = ({ V a_0 = v_x_2459; V a_1 = v_xs_2460; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2460); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2458);
        }
        return heff_strAppend(v_t_2457, v_t_2461);
      }
      default: return heff_nomatch(v_inArg_240);
      }
    }
    default: return heff_nomatch(v_t_2445);
    }
  }
  case TAG_VInt: {
    V v_t_2473;
    switch (heff_tag_of(v_inArg_240)) {
    case TAG_True: {
      V v_s_2472;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_s_2472 = ((V)&g_heff_2einterp_2eshowValGo_str40);
        break;
      }
      case TAG_VCons: {
        v_s_2472 = ((V)&g_heff_2einterp_2eshowValGo_str41);
        break;
      }
      case TAG_VTag: {
        v_s_2472 = ((V)&g_heff_2einterp_2eshowValGo_str42);
        break;
      }
      case TAG_VInt: {
        V v_i_2467 = heff_field(v_v_241, 0);
        v_s_2472 = heff_intShow(heff_dup(v_i_2467));
        break;
      }
      case TAG_VFloat: {
        V v_x_2468 = heff_field(v_v_241, 0);
        v_s_2472 = heff_floatShow(heff_dup(v_x_2468));
        break;
      }
      case TAG_VStr: {
        V v_s_2469 = heff_field(v_v_241, 0);
        V v_t_2470 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_2469), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str43)));
        v_s_2472 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str44), heff_strAppend(v_t_2470, ((V)&g_heff_2einterp_2eshowValGo_str45)));
        break;
      }
      case TAG_VArr: {
        v_s_2472 = ((V)&g_heff_2einterp_2eshowValGo_str46);
        break;
      }
      case TAG_VErased: {
        v_s_2472 = ((V)&g_heff_2einterp_2eshowValGo_str47);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      v_t_2473 = heff_strEq(heff_strSlice(v_s_2472, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2einterp_2eshowValGo_str48));
      break;
    }
    case TAG_False: {
      v_t_2473 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_inArg_240);
    }
    switch (heff_tag_of(v_t_2473)) {
    case TAG_True: {
      heff_drop(v_t_2473);
      V v_t_2483;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_t_2483 = ((V)&g_heff_2einterp_2eshowValGo_str49);
        break;
      }
      case TAG_VCons: {
        v_t_2483 = ((V)&g_heff_2einterp_2eshowValGo_str50);
        break;
      }
      case TAG_VTag: {
        v_t_2483 = ((V)&g_heff_2einterp_2eshowValGo_str51);
        break;
      }
      case TAG_VInt: {
        V v_i_2478 = heff_field(v_v_241, 0);
        v_t_2483 = heff_intShow(heff_dup(v_i_2478));
        break;
      }
      case TAG_VFloat: {
        V v_x_2479 = heff_field(v_v_241, 0);
        v_t_2483 = heff_floatShow(heff_dup(v_x_2479));
        break;
      }
      case TAG_VStr: {
        V v_s_2480 = heff_field(v_v_241, 0);
        V v_t_2481 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_2480), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str52)));
        v_t_2483 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str53), heff_strAppend(v_t_2481, ((V)&g_heff_2einterp_2eshowValGo_str54)));
        break;
      }
      case TAG_VArr: {
        v_t_2483 = ((V)&g_heff_2einterp_2eshowValGo_str55);
        break;
      }
      case TAG_VErased: {
        v_t_2483 = ((V)&g_heff_2einterp_2eshowValGo_str56);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str57), heff_strAppend(v_t_2483, ((V)&g_heff_2einterp_2eshowValGo_str58)));
    }
    case TAG_False: {
      heff_drop(v_t_2473);
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        return ((V)&g_heff_2einterp_2eshowValGo_str59);
      }
      case TAG_VCons: {
        return ((V)&g_heff_2einterp_2eshowValGo_str60);
      }
      case TAG_VTag: {
        return ((V)&g_heff_2einterp_2eshowValGo_str61);
      }
      case TAG_VInt: {
        V v_i_2488 = heff_field(v_v_241, 0);
        return heff_intShow(heff_dup(v_i_2488));
      }
      case TAG_VFloat: {
        V v_x_2489 = heff_field(v_v_241, 0);
        return heff_floatShow(heff_dup(v_x_2489));
      }
      case TAG_VStr: {
        V v_s_2490 = heff_field(v_v_241, 0);
        V v_t_2491 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_2490), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str62)));
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str63), heff_strAppend(v_t_2491, ((V)&g_heff_2einterp_2eshowValGo_str64)));
      }
      case TAG_VArr: {
        return ((V)&g_heff_2einterp_2eshowValGo_str65);
      }
      case TAG_VErased: {
        return ((V)&g_heff_2einterp_2eshowValGo_str66);
      }
      default: return heff_nomatch(v_v_241);
      }
    }
    default: return heff_nomatch(v_t_2473);
    }
  }
  case TAG_VFloat: {
    V v_t_24104;
    switch (heff_tag_of(v_inArg_240)) {
    case TAG_True: {
      V v_s_24103;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_s_24103 = ((V)&g_heff_2einterp_2eshowValGo_str67);
        break;
      }
      case TAG_VCons: {
        v_s_24103 = ((V)&g_heff_2einterp_2eshowValGo_str68);
        break;
      }
      case TAG_VTag: {
        v_s_24103 = ((V)&g_heff_2einterp_2eshowValGo_str69);
        break;
      }
      case TAG_VInt: {
        V v_i_2498 = heff_field(v_v_241, 0);
        v_s_24103 = heff_intShow(heff_dup(v_i_2498));
        break;
      }
      case TAG_VFloat: {
        V v_x_2499 = heff_field(v_v_241, 0);
        v_s_24103 = heff_floatShow(heff_dup(v_x_2499));
        break;
      }
      case TAG_VStr: {
        V v_s_24100 = heff_field(v_v_241, 0);
        V v_t_24101 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_24100), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str70)));
        v_s_24103 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str71), heff_strAppend(v_t_24101, ((V)&g_heff_2einterp_2eshowValGo_str72)));
        break;
      }
      case TAG_VArr: {
        v_s_24103 = ((V)&g_heff_2einterp_2eshowValGo_str73);
        break;
      }
      case TAG_VErased: {
        v_s_24103 = ((V)&g_heff_2einterp_2eshowValGo_str74);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      v_t_24104 = heff_strEq(heff_strSlice(v_s_24103, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2einterp_2eshowValGo_str75));
      break;
    }
    case TAG_False: {
      v_t_24104 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_inArg_240);
    }
    switch (heff_tag_of(v_t_24104)) {
    case TAG_True: {
      heff_drop(v_t_24104);
      V v_t_24114;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_t_24114 = ((V)&g_heff_2einterp_2eshowValGo_str76);
        break;
      }
      case TAG_VCons: {
        v_t_24114 = ((V)&g_heff_2einterp_2eshowValGo_str77);
        break;
      }
      case TAG_VTag: {
        v_t_24114 = ((V)&g_heff_2einterp_2eshowValGo_str78);
        break;
      }
      case TAG_VInt: {
        V v_i_24109 = heff_field(v_v_241, 0);
        v_t_24114 = heff_intShow(heff_dup(v_i_24109));
        break;
      }
      case TAG_VFloat: {
        V v_x_24110 = heff_field(v_v_241, 0);
        v_t_24114 = heff_floatShow(heff_dup(v_x_24110));
        break;
      }
      case TAG_VStr: {
        V v_s_24111 = heff_field(v_v_241, 0);
        V v_t_24112 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_24111), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str79)));
        v_t_24114 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str80), heff_strAppend(v_t_24112, ((V)&g_heff_2einterp_2eshowValGo_str81)));
        break;
      }
      case TAG_VArr: {
        v_t_24114 = ((V)&g_heff_2einterp_2eshowValGo_str82);
        break;
      }
      case TAG_VErased: {
        v_t_24114 = ((V)&g_heff_2einterp_2eshowValGo_str83);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str84), heff_strAppend(v_t_24114, ((V)&g_heff_2einterp_2eshowValGo_str85)));
    }
    case TAG_False: {
      heff_drop(v_t_24104);
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        return ((V)&g_heff_2einterp_2eshowValGo_str86);
      }
      case TAG_VCons: {
        return ((V)&g_heff_2einterp_2eshowValGo_str87);
      }
      case TAG_VTag: {
        return ((V)&g_heff_2einterp_2eshowValGo_str88);
      }
      case TAG_VInt: {
        V v_i_24119 = heff_field(v_v_241, 0);
        return heff_intShow(heff_dup(v_i_24119));
      }
      case TAG_VFloat: {
        V v_x_24120 = heff_field(v_v_241, 0);
        return heff_floatShow(heff_dup(v_x_24120));
      }
      case TAG_VStr: {
        V v_s_24121 = heff_field(v_v_241, 0);
        V v_t_24122 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_24121), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str89)));
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str90), heff_strAppend(v_t_24122, ((V)&g_heff_2einterp_2eshowValGo_str91)));
      }
      case TAG_VArr: {
        return ((V)&g_heff_2einterp_2eshowValGo_str92);
      }
      case TAG_VErased: {
        return ((V)&g_heff_2einterp_2eshowValGo_str93);
      }
      default: return heff_nomatch(v_v_241);
      }
    }
    default: return heff_nomatch(v_t_24104);
    }
  }
  case TAG_VStr: {
    V v_t_24135;
    switch (heff_tag_of(v_inArg_240)) {
    case TAG_True: {
      V v_s_24134;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_s_24134 = ((V)&g_heff_2einterp_2eshowValGo_str94);
        break;
      }
      case TAG_VCons: {
        v_s_24134 = ((V)&g_heff_2einterp_2eshowValGo_str95);
        break;
      }
      case TAG_VTag: {
        v_s_24134 = ((V)&g_heff_2einterp_2eshowValGo_str96);
        break;
      }
      case TAG_VInt: {
        V v_i_24129 = heff_field(v_v_241, 0);
        v_s_24134 = heff_intShow(heff_dup(v_i_24129));
        break;
      }
      case TAG_VFloat: {
        V v_x_24130 = heff_field(v_v_241, 0);
        v_s_24134 = heff_floatShow(heff_dup(v_x_24130));
        break;
      }
      case TAG_VStr: {
        V v_s_24131 = heff_field(v_v_241, 0);
        V v_t_24132 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_24131), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str97)));
        v_s_24134 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str98), heff_strAppend(v_t_24132, ((V)&g_heff_2einterp_2eshowValGo_str99)));
        break;
      }
      case TAG_VArr: {
        v_s_24134 = ((V)&g_heff_2einterp_2eshowValGo_str100);
        break;
      }
      case TAG_VErased: {
        v_s_24134 = ((V)&g_heff_2einterp_2eshowValGo_str101);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      v_t_24135 = heff_strEq(heff_strSlice(v_s_24134, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2einterp_2eshowValGo_str102));
      break;
    }
    case TAG_False: {
      v_t_24135 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_inArg_240);
    }
    switch (heff_tag_of(v_t_24135)) {
    case TAG_True: {
      heff_drop(v_t_24135);
      V v_t_24145;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_t_24145 = ((V)&g_heff_2einterp_2eshowValGo_str103);
        break;
      }
      case TAG_VCons: {
        v_t_24145 = ((V)&g_heff_2einterp_2eshowValGo_str104);
        break;
      }
      case TAG_VTag: {
        v_t_24145 = ((V)&g_heff_2einterp_2eshowValGo_str105);
        break;
      }
      case TAG_VInt: {
        V v_i_24140 = heff_field(v_v_241, 0);
        v_t_24145 = heff_intShow(heff_dup(v_i_24140));
        break;
      }
      case TAG_VFloat: {
        V v_x_24141 = heff_field(v_v_241, 0);
        v_t_24145 = heff_floatShow(heff_dup(v_x_24141));
        break;
      }
      case TAG_VStr: {
        V v_s_24142 = heff_field(v_v_241, 0);
        V v_t_24143 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_24142), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str106)));
        v_t_24145 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str107), heff_strAppend(v_t_24143, ((V)&g_heff_2einterp_2eshowValGo_str108)));
        break;
      }
      case TAG_VArr: {
        v_t_24145 = ((V)&g_heff_2einterp_2eshowValGo_str109);
        break;
      }
      case TAG_VErased: {
        v_t_24145 = ((V)&g_heff_2einterp_2eshowValGo_str110);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str111), heff_strAppend(v_t_24145, ((V)&g_heff_2einterp_2eshowValGo_str112)));
    }
    case TAG_False: {
      heff_drop(v_t_24135);
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        return ((V)&g_heff_2einterp_2eshowValGo_str113);
      }
      case TAG_VCons: {
        return ((V)&g_heff_2einterp_2eshowValGo_str114);
      }
      case TAG_VTag: {
        return ((V)&g_heff_2einterp_2eshowValGo_str115);
      }
      case TAG_VInt: {
        V v_i_24150 = heff_field(v_v_241, 0);
        return heff_intShow(heff_dup(v_i_24150));
      }
      case TAG_VFloat: {
        V v_x_24151 = heff_field(v_v_241, 0);
        return heff_floatShow(heff_dup(v_x_24151));
      }
      case TAG_VStr: {
        V v_s_24152 = heff_field(v_v_241, 0);
        V v_t_24153 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_24152), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str116)));
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str117), heff_strAppend(v_t_24153, ((V)&g_heff_2einterp_2eshowValGo_str118)));
      }
      case TAG_VArr: {
        return ((V)&g_heff_2einterp_2eshowValGo_str119);
      }
      case TAG_VErased: {
        return ((V)&g_heff_2einterp_2eshowValGo_str120);
      }
      default: return heff_nomatch(v_v_241);
      }
    }
    default: return heff_nomatch(v_t_24135);
    }
  }
  case TAG_VArr: {
    V v_xs_24155 = heff_field(v_v_241, 0);
    V v_x2_24156 = (g_prelude_2emap_24s44(heff_arrayToList(heff_dup(v_xs_24155))));
    V v_t_24159;
    switch (heff_tag_of(v_x2_24156)) {
    case TAG_Nil: {
      heff_drop(v_x2_24156);
      v_t_24159 = ((V)&g_heff_2einterp_2eshowValGo_str121);
      break;
    }
    case TAG_Cons: {
      V v_x_24157 = heff_field(v_x2_24156, 0);
      V v_xs_24158 = heff_field(v_x2_24156, 1);
      heff_take(v_x2_24156, 3ULL);
      v_t_24159 = ({ V a_0 = v_x_24157; V a_1 = v_xs_24158; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_24158); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24156);
    }
    return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str122), heff_strAppend(v_t_24159, ((V)&g_heff_2einterp_2eshowValGo_str123)));
  }
  case TAG_VErased: {
    V v_t_24170;
    switch (heff_tag_of(v_inArg_240)) {
    case TAG_True: {
      V v_s_24169;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_s_24169 = ((V)&g_heff_2einterp_2eshowValGo_str124);
        break;
      }
      case TAG_VCons: {
        v_s_24169 = ((V)&g_heff_2einterp_2eshowValGo_str125);
        break;
      }
      case TAG_VTag: {
        v_s_24169 = ((V)&g_heff_2einterp_2eshowValGo_str126);
        break;
      }
      case TAG_VInt: {
        V v_i_24164 = heff_field(v_v_241, 0);
        v_s_24169 = heff_intShow(heff_dup(v_i_24164));
        break;
      }
      case TAG_VFloat: {
        V v_x_24165 = heff_field(v_v_241, 0);
        v_s_24169 = heff_floatShow(heff_dup(v_x_24165));
        break;
      }
      case TAG_VStr: {
        V v_s_24166 = heff_field(v_v_241, 0);
        V v_t_24167 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_24166), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str127)));
        v_s_24169 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str128), heff_strAppend(v_t_24167, ((V)&g_heff_2einterp_2eshowValGo_str129)));
        break;
      }
      case TAG_VArr: {
        v_s_24169 = ((V)&g_heff_2einterp_2eshowValGo_str130);
        break;
      }
      case TAG_VErased: {
        v_s_24169 = ((V)&g_heff_2einterp_2eshowValGo_str131);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      v_t_24170 = heff_strEq(heff_strSlice(v_s_24169, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2einterp_2eshowValGo_str132));
      break;
    }
    case TAG_False: {
      v_t_24170 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_inArg_240);
    }
    switch (heff_tag_of(v_t_24170)) {
    case TAG_True: {
      heff_drop(v_t_24170);
      V v_t_24180;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_t_24180 = ((V)&g_heff_2einterp_2eshowValGo_str133);
        break;
      }
      case TAG_VCons: {
        v_t_24180 = ((V)&g_heff_2einterp_2eshowValGo_str134);
        break;
      }
      case TAG_VTag: {
        v_t_24180 = ((V)&g_heff_2einterp_2eshowValGo_str135);
        break;
      }
      case TAG_VInt: {
        V v_i_24175 = heff_field(v_v_241, 0);
        v_t_24180 = heff_intShow(heff_dup(v_i_24175));
        break;
      }
      case TAG_VFloat: {
        V v_x_24176 = heff_field(v_v_241, 0);
        v_t_24180 = heff_floatShow(heff_dup(v_x_24176));
        break;
      }
      case TAG_VStr: {
        V v_s_24177 = heff_field(v_v_241, 0);
        V v_t_24178 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_24177), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str136)));
        v_t_24180 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str137), heff_strAppend(v_t_24178, ((V)&g_heff_2einterp_2eshowValGo_str138)));
        break;
      }
      case TAG_VArr: {
        v_t_24180 = ((V)&g_heff_2einterp_2eshowValGo_str139);
        break;
      }
      case TAG_VErased: {
        v_t_24180 = ((V)&g_heff_2einterp_2eshowValGo_str140);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str141), heff_strAppend(v_t_24180, ((V)&g_heff_2einterp_2eshowValGo_str142)));
    }
    case TAG_False: {
      heff_drop(v_t_24170);
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        return ((V)&g_heff_2einterp_2eshowValGo_str143);
      }
      case TAG_VCons: {
        return ((V)&g_heff_2einterp_2eshowValGo_str144);
      }
      case TAG_VTag: {
        return ((V)&g_heff_2einterp_2eshowValGo_str145);
      }
      case TAG_VInt: {
        V v_i_24185 = heff_field(v_v_241, 0);
        return heff_intShow(heff_dup(v_i_24185));
      }
      case TAG_VFloat: {
        V v_x_24186 = heff_field(v_v_241, 0);
        return heff_floatShow(heff_dup(v_x_24186));
      }
      case TAG_VStr: {
        V v_s_24187 = heff_field(v_v_241, 0);
        V v_t_24188 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_24187), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str146)));
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str147), heff_strAppend(v_t_24188, ((V)&g_heff_2einterp_2eshowValGo_str148)));
      }
      case TAG_VArr: {
        return ((V)&g_heff_2einterp_2eshowValGo_str149);
      }
      case TAG_VErased: {
        return ((V)&g_heff_2einterp_2eshowValGo_str150);
      }
      default: return heff_nomatch(v_v_241);
      }
    }
    default: return heff_nomatch(v_t_24170);
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2einterp_2eshowValGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2eshowValGo(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2einterp_2efixThunk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efixThunk_entry, 3, 0};

V g_heff_2einterp_2efixThunk(V v_g_240, V v_t_241, V v_d_242) {
top: ;
  V v_t_243 = heff_tr(heff_apply(((V)&g_heff_2einterp_2efixThunk_clo), 2, (V[]){heff_dup(v_g_240), heff_dup(v_t_241)}));
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  return (g_heff_2einterp_2eevalIn(heff_intAdd(v_d_242, MK_INT(1LL)), heff_rec(2, shape_170_109, (V[]){v_t_244, v_g_240}), v_t_241));
}
V g_heff_2einterp_2efixThunk_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2efixThunk(a[0], a[1], a[2]);
}
V g_heff_2einterp_2eevalGlobalsGo_lam0(V self, V *args);
Clo g_heff_2einterp_2eevalGlobalsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eevalGlobalsGo_entry, 4, 0};

V g_heff_2einterp_2eevalGlobalsGo(V v_wanted_240, V v_ge_241, V v_x3_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_wanted_240);
    heff_drop(v_ge_241);
    heff_drop(v_x3_242);
    return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_243));
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse(v_x3_242, 3ULL);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x31_244, 0);
      V v_entry_247 = heff_field(v_x31_244, 1);
      heff_take(v_x31_244, 3ULL);
      V v_r_248 = heff_tr(g_heff_2einterp_2efixThunk(heff_dup(v_ge_241), heff_get(v_entry_247, LBL_syntax), MK_INT(0LL)));
      V v_t_2410 = (g_map_2einsert_24s7(heff_dup(v_x_246), heff_clo(g_heff_2einterp_2eevalGlobalsGo_lam0, 1, 1, (V[]){heff_dup(v_r_248)}), v_ge_241));
      V v_t_2411 = heff_tr(heff_apply(heff_dup(v_wanted_240), 1, (V[]){heff_dup(v_x_246)}));
      V v_t_2414;
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        heff_drop(v_t_2411);
        V v_t_2413;
        switch (heff_tag_of(v_r_248)) {
        case TAG_Ok: {
          V v_v_2412 = heff_field(v_r_248, 0);
          V v_ru_24r_248_24Ok = heff_take_reuse(v_r_248, 1ULL);
          v_t_2413 = heff_tag_at(v_ru_24r_248_24Ok, TAG_RSucceeded, 1, (V[]){v_v_2412});
          break;
        }
        case TAG_Abn: {
          heff_drop(v_r_248);
          v_t_2413 = NTAG(TAG_RAbandoned);
          break;
        }
        case TAG_Div: {
          heff_drop(v_r_248);
          v_t_2413 = NTAG(TAG_RDiverged);
          break;
        }
        default: heff_nomatch(v_r_248);
        }
        v_t_2414 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_246, v_t_2413}), v_acc_243});
        break;
      }
      case TAG_False: {
        heff_drop(v_ru_24x3_242_24Cons);
        heff_drop(v_x_246);
        heff_drop(v_r_248);
        heff_drop(v_t_2411);
        v_t_2414 = v_acc_243;
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
      V t_0 = v_wanted_240;
      V t_1 = v_t_2410;
      V t_2 = v_rest_245;
      V t_3 = v_t_2414;
      v_wanted_240 = t_0;
      v_ge_241 = t_1;
      v_x3_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2einterp_2eevalGlobalsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eevalGlobalsGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2einterp_2eevalGlobalsGo_lam0(V self, V *args) {
  V v_d_249 = args[0];
  V v_r_248 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_d_249);
  return v_r_248;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eevalGlobalsGo_24s518_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {62, 32, 116, 101, 115, 116, 32}};
V g_heff_2einterp_2eevalGlobalsGo_24s518_lam0(V self, V *args);
Clo g_heff_2einterp_2eevalGlobalsGo_24s518_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eevalGlobalsGo_24s518_entry, 3, 0};

V g_heff_2einterp_2eevalGlobalsGo_24s518(V v_ge_240, V v_x3_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_ge_240);
    heff_drop(v_x3_241);
    return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_242));
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_241, 0);
    V v_rest_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse(v_x3_241, 3ULL);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_243, 0);
      V v_entry_246 = heff_field(v_x31_243, 1);
      heff_take(v_x31_243, 3ULL);
      V v_r_247 = heff_tr(g_heff_2einterp_2efixThunk(heff_dup(v_ge_240), heff_get(v_entry_246, LBL_syntax), MK_INT(0LL)));
      V v_t_249 = (g_map_2einsert_24s7(heff_dup(v_x_245), heff_clo(g_heff_2einterp_2eevalGlobalsGo_24s518_lam0, 1, 1, (V[]){heff_dup(v_r_247)}), v_ge_240));
      V v_t_2410 = heff_strEq(heff_strSlice(heff_dup(v_x_245), MK_INT(0LL), MK_INT(7LL)), ((V)&g_heff_2einterp_2eevalGlobalsGo_24s518_str0));
      V v_t_2413;
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        heff_drop(v_t_2410);
        V v_t_2412;
        switch (heff_tag_of(v_r_247)) {
        case TAG_Ok: {
          V v_v_2411 = heff_field(v_r_247, 0);
          V v_ru_24r_247_24Ok = heff_take_reuse(v_r_247, 1ULL);
          v_t_2412 = heff_tag_at(v_ru_24r_247_24Ok, TAG_RSucceeded, 1, (V[]){v_v_2411});
          break;
        }
        case TAG_Abn: {
          heff_drop(v_r_247);
          v_t_2412 = NTAG(TAG_RAbandoned);
          break;
        }
        case TAG_Div: {
          heff_drop(v_r_247);
          v_t_2412 = NTAG(TAG_RDiverged);
          break;
        }
        default: heff_nomatch(v_r_247);
        }
        v_t_2413 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_245, v_t_2412}), v_acc_242});
        break;
      }
      case TAG_False: {
        heff_drop(v_ru_24x3_241_24Cons);
        heff_drop(v_x_245);
        heff_drop(v_r_247);
        heff_drop(v_t_2410);
        v_t_2413 = v_acc_242;
        break;
      }
      default: heff_nomatch(v_t_2410);
      }
      V t_0 = v_t_249;
      V t_1 = v_rest_244;
      V t_2 = v_t_2413;
      v_ge_240 = t_0;
      v_x3_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2einterp_2eevalGlobalsGo_24s518_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eevalGlobalsGo_24s518(a[0], a[1], a[2]);
}
V g_heff_2einterp_2eevalGlobalsGo_24s518_lam0(V self, V *args) {
  V v_d_248 = args[0];
  V v_r_247 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_d_248);
  return v_r_247;
}