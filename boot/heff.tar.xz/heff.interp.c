// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_AbsConst 8406
#define TAG_Div 16157
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkAbs 54862
#define TAG_Ok 9325
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_RAbandoned 16367
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VArr 15466
#define TAG_VCons 11629
#define TAG_VErased 42634
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_byName 571997869
#define LBL_fixed 298804110
#define LBL_global 704121550
#define LBL_keys 9783995
#define LBL_local 304503685
#define LBL_op 10312
#define LBL_syntax 1059664654
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_local__global[] = {LBL_local, LBL_global};
V g_heff_2edict_2eindexed(V, V);
V g_heff_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2edict_2eindexed_clo;
V g_heff_2edict_2ezipKV(V, V);
V g_heff_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2edict_2ezipKV_clo;
V g_heff_2efixed_2efixedMin(V);
V g_heff_2efixed_2efixedMin_entry(V self, V *a);
extern Clo g_heff_2efixed_2efixedMin_clo;
V g_heff_2efixed_2efixedPrimOf(V);
V g_heff_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2efixed_2efixedPrimOf_clo;
V g_heff_2efixed_2etwoTo(V);
V g_heff_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2efixed_2etwoTo_clo;
V g_heff_2einterp_2ebitsOf_24s1458520709x2132426067(V, V, V, V);
V g_heff_2einterp_2ebitsOf_24s1458520709x2132426067_entry(V self, V *a);
extern Clo g_heff_2einterp_2ebitsOf_24s1458520709x2132426067_clo;
V g_heff_2einterp_2ebitsOf_24s2122496700x1608419743(V, V, V);
V g_heff_2einterp_2ebitsOf_24s2122496700x1608419743_entry(V self, V *a);
extern Clo g_heff_2einterp_2ebitsOf_24s2122496700x1608419743_clo;
V g_heff_2einterp_2ebitsOf_24s277023746x1062825997(V, V, V, V, V, V);
V g_heff_2einterp_2ebitsOf_24s277023746x1062825997_entry(V self, V *a);
extern Clo g_heff_2einterp_2ebitsOf_24s277023746x1062825997_clo;
V g_heff_2einterp_2ebitwise(V, V, V, V);
V g_heff_2einterp_2ebitwise_entry(V self, V *a);
extern Clo g_heff_2einterp_2ebitwise_clo;
V g_heff_2einterp_2ebitwise_24s348840635x1130995754(V, V, V);
V g_heff_2einterp_2ebitwise_24s348840635x1130995754_entry(V self, V *a);
extern Clo g_heff_2einterp_2ebitwise_24s348840635x1130995754_clo;
V g_heff_2einterp_2edeepest_get(void);
V g_heff_2einterp_2eescAt(V, V);
V g_heff_2einterp_2eescAt_entry(V self, V *a);
extern Clo g_heff_2einterp_2eescAt_clo;
V g_heff_2einterp_2eevalEach(V, V, V);
V g_heff_2einterp_2eevalEach_entry(V self, V *a);
extern Clo g_heff_2einterp_2eevalEach_clo;
V g_heff_2einterp_2eevalFields(V, V, V);
V g_heff_2einterp_2eevalFields_entry(V self, V *a);
extern Clo g_heff_2einterp_2eevalFields_clo;
V g_heff_2einterp_2eevalGlobalsGo(V, V, V, V);
V g_heff_2einterp_2eevalGlobalsGo_entry(V self, V *a);
extern Clo g_heff_2einterp_2eevalGlobalsGo_clo;
V g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986(V, V, V, V, V, V);
V g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986_entry(V self, V *a);
extern Clo g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986_clo;
V g_heff_2einterp_2eevalIn(V, V, V);
V g_heff_2einterp_2eevalIn_entry(V self, V *a);
extern Clo g_heff_2einterp_2eevalIn_clo;
V g_heff_2einterp_2ef32V1_24s1317596417x824260503_get(void);
V g_heff_2einterp_2ef32V2(V);
V g_heff_2einterp_2ef32V2_entry(V self, V *a);
extern Clo g_heff_2einterp_2ef32V2_clo;
V g_heff_2einterp_2ef32V2_24s2125509355x867594919_get(void);
V g_heff_2einterp_2ef32V2_24s408265061x438630957_get(void);
V g_heff_2einterp_2ef32V2_24s950619608x1678710457_get(void);
V g_heff_2einterp_2ef32V2_24s987891065x1106715032_get(void);
V g_heff_2einterp_2efixThunk(V, V, V);
V g_heff_2einterp_2efixThunk_entry(V self, V *a);
extern Clo g_heff_2einterp_2efixThunk_clo;
V g_heff_2einterp_2efixedInt1(V, V, V);
V g_heff_2einterp_2efixedInt1_entry(V self, V *a);
extern Clo g_heff_2einterp_2efixedInt1_clo;
V g_heff_2einterp_2efixedInt2(V, V, V, V);
V g_heff_2einterp_2efixedInt2_entry(V self, V *a);
extern Clo g_heff_2einterp_2efixedInt2_clo;
V g_heff_2einterp_2efixedPrimV(V);
V g_heff_2einterp_2efixedPrimV_entry(V self, V *a);
extern Clo g_heff_2einterp_2efixedPrimV_clo;
V g_heff_2einterp_2efloat2(V);
V g_heff_2einterp_2efloat2_entry(V self, V *a);
extern Clo g_heff_2einterp_2efloat2_clo;
V g_heff_2einterp_2efloat2_24s1423458924x1394741838_get(void);
V g_heff_2einterp_2efloat2_24s1759709581x228229611_get(void);
V g_heff_2einterp_2efloat2_24s1965813471x487337709_get(void);
V g_heff_2einterp_2efloat2_24s2003084928x2062825913_get(void);
V g_heff_2einterp_2efloat2_24s205358756x116382871_get(void);
V g_heff_2einterp_2efloat2_24s615196179x236480627_get(void);
V g_heff_2einterp_2efloat32V(V);
V g_heff_2einterp_2efloat32V_entry(V self, V *a);
extern Clo g_heff_2einterp_2efloat32V_clo;
V g_heff_2einterp_2efromListV(V, V);
V g_heff_2einterp_2efromListV_entry(V self, V *a);
extern Clo g_heff_2einterp_2efromListV_clo;
V g_heff_2einterp_2egenGo(V, V, V, V, V);
V g_heff_2einterp_2egenGo_entry(V self, V *a);
extern Clo g_heff_2einterp_2egenGo_clo;
V g_heff_2einterp_2eint2(V);
V g_heff_2einterp_2eint2_entry(V self, V *a);
extern Clo g_heff_2einterp_2eint2_clo;
V g_heff_2einterp_2eint2_24s1207713422x150104894_get(void);
V g_heff_2einterp_2eint2_24s1323720283x607104012_get(void);
V g_heff_2einterp_2eint2_24s1750067969x1390184394_get(void);
V g_heff_2einterp_2eint2_24s1787339426x818188969_get(void);
V g_heff_2einterp_2eintBits_24s1759121966x190002670(V, V);
V g_heff_2einterp_2eintBits_24s1759121966x190002670_entry(V self, V *a);
extern Clo g_heff_2einterp_2eintBits_24s1759121966x190002670_clo;
V g_heff_2einterp_2eintBits_24s522074386x924975132(V, V, V, V, V);
V g_heff_2einterp_2eintBits_24s522074386x924975132_entry(V self, V *a);
extern Clo g_heff_2einterp_2eintBits_24s522074386x924975132_clo;
V g_heff_2einterp_2eintBits_24s715749050x314660754(V, V, V);
V g_heff_2einterp_2eintBits_24s715749050x314660754_entry(V self, V *a);
extern Clo g_heff_2einterp_2eintBits_24s715749050x314660754_clo;
V g_heff_2einterp_2enthTh(V, V);
V g_heff_2einterp_2enthTh_entry(V self, V *a);
extern Clo g_heff_2einterp_2enthTh_clo;
V g_heff_2einterp_2enthV(V, V);
V g_heff_2einterp_2enthV_entry(V self, V *a);
extern Clo g_heff_2einterp_2enthV_clo;
V g_heff_2einterp_2eprim(V);
V g_heff_2einterp_2eprim_entry(V self, V *a);
extern Clo g_heff_2einterp_2eprim_clo;
V g_heff_2einterp_2eprojV(V, V);
V g_heff_2einterp_2eprojV_entry(V self, V *a);
extern Clo g_heff_2einterp_2eprojV_clo;
V g_heff_2einterp_2equoteGo(V, V, V);
V g_heff_2einterp_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2einterp_2equoteGo_clo;
V g_heff_2einterp_2erune2(V);
V g_heff_2einterp_2erune2_entry(V self, V *a);
extern Clo g_heff_2einterp_2erune2_clo;
V g_heff_2einterp_2eruneCodes(V);
V g_heff_2einterp_2eruneCodes_entry(V self, V *a);
extern Clo g_heff_2einterp_2eruneCodes_clo;
V g_heff_2einterp_2escalarV(V);
V g_heff_2einterp_2escalarV_entry(V self, V *a);
extern Clo g_heff_2einterp_2escalarV_clo;
V g_heff_2einterp_2esetAt(V, V, V);
V g_heff_2einterp_2esetAt_entry(V self, V *a);
extern Clo g_heff_2einterp_2esetAt_clo;
V g_heff_2einterp_2eshowValGo(V, V);
V g_heff_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2einterp_2eshowValGo_clo;
V g_heff_2einterp_2estr2(V);
V g_heff_2einterp_2estr2_entry(V self, V *a);
extern Clo g_heff_2einterp_2estr2_clo;
V g_heff_2einterp_2estr2_24s1802929932x1594371566_get(void);
V g_heff_2einterp_2etoListV(V);
V g_heff_2einterp_2etoListV_entry(V self, V *a);
extern Clo g_heff_2einterp_2etoListV_clo;
V g_heff_2einterp_2etruncDiv(V, V);
V g_heff_2einterp_2etruncDiv_entry(V self, V *a);
extern Clo g_heff_2einterp_2etruncDiv_clo;
V g_heff_2erune_2edecodeFrom(V, V, V);
V g_heff_2erune_2edecodeFrom_entry(V self, V *a);
extern Clo g_heff_2erune_2edecodeFrom_clo;
V g_heff_2erune_2equoted(V);
V g_heff_2erune_2equoted_entry(V self, V *a);
extern Clo g_heff_2erune_2equoted_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2049334416x2039919674(V, V);
V g_list_2efoldl_24s2049334416x2039919674_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2049334416x2039919674_clo;
V g_list_2emap_24s1070305723x611506852(V, V);
V g_list_2emap_24s1070305723x611506852_entry(V self, V *a);
extern Clo g_list_2emap_24s1070305723x611506852_clo;
V g_list_2emap_24s115901570x2012684568(V);
V g_list_2emap_24s115901570x2012684568_entry(V self, V *a);
extern Clo g_list_2emap_24s115901570x2012684568_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1474012528x87063660(V);
V g_list_2emap_24s1474012528x87063660_entry(V self, V *a);
extern Clo g_list_2emap_24s1474012528x87063660_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s517793000x1987655475(V, V);
V g_list_2emap_24s517793000x1987655475_entry(V self, V *a);
extern Clo g_list_2emap_24s517793000x1987655475_clo;
V g_list_2emap_24s687660682x965950040(V);
V g_list_2emap_24s687660682x965950040_entry(V self, V *a);
extern Clo g_list_2emap_24s687660682x965950040_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;

static V g_heff_2einterp_2edeepest_val;
static int g_heff_2einterp_2edeepest_st;
static V g_heff_2einterp_2edeepest_init(void) {
  return MK_INT(1000000LL);
}
V g_heff_2einterp_2edeepest_get(void) {
  if (g_heff_2einterp_2edeepest_st == 2) return g_heff_2einterp_2edeepest_val;
  if (g_heff_2einterp_2edeepest_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2edeepest_st = 1;
  g_heff_2einterp_2edeepest_val = heff_tr(g_heff_2einterp_2edeepest_init());
  g_heff_2einterp_2edeepest_st = 2;
  return g_heff_2einterp_2edeepest_val;
}
Clo g_heff_2einterp_2eprojV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprojV_entry, 2, 0};

V g_heff_2einterp_2eprojV(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VCons: {
    V v_fs_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24VCons = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_244 = ({ V a_0 = v_x2_241; V b_1 = heff_get(heff_dup(v_fs_243), LBL_byName); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2410;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop(v_fs_243);
      v_t_2410 = heff_abandon();
      break;
    }
    case TAG_Just: {
      V v_i_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V v_xs_246 = heff_get(v_fs_243, LBL_values);
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_245))) {
        if (heff_intLt_c(heff_dup(v_i_245), heff_arrayLength(heff_dup(v_xs_246)))) {
          V v_v_249 = heff_arrayIndex(v_xs_246, v_i_245);
          v_t_2410 = v_v_249;
        } else {
          heff_drop(v_i_245);
          heff_drop(v_xs_246);
          v_t_2410 = heff_abandon();
        }
      } else {
        heff_drop(v_i_245);
        heff_drop(v_xs_246);
        v_t_2410 = heff_abandon();
      }
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    return heff_tag_at(v_ru_24x1_240_24VCons, TAG_Ok, 1, (V[]){v_t_2410});
  }
  case TAG_VTag: {
    heff_take_n(v_x1_240, 0ULL, 2);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VArr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VErased: {
    heff_drop(v_x2_241);
    return heff_tag(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2eprojV_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eprojV(a[0], a[1]);
}
V g_heff_2einterp_2eint2_lam1(V self, V *args);
V g_heff_2einterp_2eint2_lam0(V self, V *args);
Clo g_heff_2einterp_2eint2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eint2_entry, 1, 0};

V g_heff_2einterp_2eint2(V v_f_240) {
top: ;
  return heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eint2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2einterp_2eint2_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eint2(a[0]);
}
V g_heff_2einterp_2eint2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_apply(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_apply(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      switch (heff_tag_of(v_v_246)) {
      case TAG_VFun: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_246, 0ULL, 2);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VInt: {
        V v_a_2413 = heff_field(v_v_246, 0);
        heff_take_n(v_v_246, 1ULL, 1);
        switch (heff_tag_of(v_v_248)) {
        case TAG_VFun: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_248, 0ULL, 2);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          V v_b_2418 = heff_field(v_v_248, 0);
          heff_take_n(v_v_248, 1ULL, 1);
          V f_ = v_f_240;
          args[0] = v_a_2413;
          args[1] = v_b_2418;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        case TAG_VFloat: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VRune: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_248);
        }
      }
      case TAG_VFloat: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VRune: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_246);
      }
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2einterp_2eint2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eint2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
V g_heff_2einterp_2efloat2_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_lam0(V self, V *args);
Clo g_heff_2einterp_2efloat2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_entry, 1, 0};

V g_heff_2einterp_2efloat2(V v_f_240) {
top: ;
  return heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2einterp_2efloat2_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2efloat2(a[0]);
}
V g_heff_2einterp_2efloat2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_apply(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_apply(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      switch (heff_tag_of(v_v_246)) {
      case TAG_VFun: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_246, 0ULL, 2);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2414 = heff_field(v_v_246, 0);
        heff_take_n(v_v_246, 1ULL, 1);
        switch (heff_tag_of(v_v_248)) {
        case TAG_VFun: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_248, 0ULL, 2);
          heff_drop(v_f_240);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2420 = heff_field(v_v_248, 0);
          heff_take_n(v_v_248, 1ULL, 1);
          V f_ = v_f_240;
          args[0] = v_a_2414;
          args[1] = v_b_2420;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VRune: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_f_240);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_248);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VRune: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_246);
      }
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2einterp_2efloat2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
V g_heff_2einterp_2estr2_lam1(V self, V *args);
V g_heff_2einterp_2estr2_lam0(V self, V *args);
Clo g_heff_2einterp_2estr2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2estr2_entry, 1, 0};

V g_heff_2einterp_2estr2(V v_f_240) {
top: ;
  return heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2estr2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2einterp_2estr2_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2estr2(a[0]);
}
V g_heff_2einterp_2estr2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_apply(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_apply(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      switch (heff_tag_of(v_v_246)) {
      case TAG_VFun: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_246, 0ULL, 2);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VFloat: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VStr: {
        V v_a_2416 = heff_field(v_v_246, 0);
        heff_take_n(v_v_246, 1ULL, 1);
        switch (heff_tag_of(v_v_248)) {
        case TAG_VFun: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2416);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2416);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_248, 0ULL, 2);
          heff_drop(v_f_240);
          heff_drop(v_a_2416);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2416);
          return heff_abandon();
        }
        case TAG_VFloat: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2416);
          return heff_abandon();
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2416);
          return heff_abandon();
        }
        case TAG_VStr: {
          V v_b_2424 = heff_field(v_v_248, 0);
          heff_take_n(v_v_248, 1ULL, 1);
          V f_ = v_f_240;
          args[0] = v_a_2416;
          args[1] = v_b_2424;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        case TAG_VRune: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2416);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2416);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_f_240);
          heff_drop(v_a_2416);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_248);
        }
      }
      case TAG_VRune: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_246);
      }
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2einterp_2estr2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2estr2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
V g_heff_2einterp_2erune2_lam1(V self, V *args);
V g_heff_2einterp_2erune2_lam0(V self, V *args);
Clo g_heff_2einterp_2erune2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2erune2_entry, 1, 0};

V g_heff_2einterp_2erune2(V v_f_240) {
top: ;
  return heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2erune2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2einterp_2erune2_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2erune2(a[0]);
}
V g_heff_2einterp_2erune2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_apply(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_apply(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      switch (heff_tag_of(v_v_246)) {
      case TAG_VFun: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_246, 0ULL, 2);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VFloat: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VRune: {
        V v_a_2417 = heff_field(v_v_246, 0);
        heff_take_n(v_v_246, 1ULL, 1);
        switch (heff_tag_of(v_v_248)) {
        case TAG_VFun: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2417);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2417);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_248, 0ULL, 2);
          heff_drop(v_f_240);
          heff_drop(v_a_2417);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2417);
          return heff_abandon();
        }
        case TAG_VFloat: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2417);
          return heff_abandon();
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2417);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2417);
          return heff_abandon();
        }
        case TAG_VRune: {
          V v_b_2426 = heff_field(v_v_248, 0);
          heff_take_n(v_v_248, 1ULL, 1);
          V f_ = v_f_240;
          args[0] = v_a_2417;
          args[1] = v_b_2426;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        case TAG_VArr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2417);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_f_240);
          heff_drop(v_a_2417);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_248);
        }
      }
      case TAG_VArr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_246);
      }
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2einterp_2erune2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2erune2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
Clo g_heff_2einterp_2eruneCodes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eruneCodes_entry, 1, 0};

V g_heff_2einterp_2eruneCodes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_VFun: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VCons: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VTag: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VFloat: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VStr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VRune: {
      V v_c_2411 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_2411, (g_heff_2einterp_2eruneCodes(v_rest_242))});
    }
    case TAG_VArr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2eruneCodes_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eruneCodes(a[0]);
}
Clo g_heff_2einterp_2esetAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2esetAt_entry, 3, 0};

V g_heff_2einterp_2esetAt(V v_x1_240, V v_i_241, V v_x_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x1_240, 0);
    V v_ys_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      heff_drop(v_y_243);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_ys_244});
    } else {
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_y_243, (g_heff_2einterp_2esetAt(v_ys_244, heff_intSub(v_i_241, MK_INT(1LL)), v_x_242))});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2esetAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2esetAt(a[0], a[1], a[2]);
}
V g_heff_2einterp_2egenGo_lam0(V self, V *args);
V g_heff_2einterp_2egenGo_lam1(V self, V *args);
Clo g_heff_2einterp_2egenGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2egenGo_entry, 5, 0};

V g_heff_2einterp_2egenGo(V v_d_240, V v_j_241, V v_n_242, V v_f_243, V v_k_244) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_242), heff_dup(v_j_241))) {
    heff_drop(v_d_240);
    heff_drop(v_j_241);
    heff_drop(v_n_242);
    heff_drop(v_f_243);
    return heff_tail(v_k_244, 1, (V[]){NTAG(TAG_Nil)});
  } else {
    V v_x1_2417;
    switch (heff_tag_of(v_f_243)) {
    case TAG_VFun: {
      V v_f_246 = heff_dup(heff_field(v_f_243, 0));
      v_x1_2417 = heff_tr(heff_apply(v_f_246, 2, (V[]){heff_dup(v_d_240), heff_clo(g_heff_2einterp_2egenGo_lam0, 1, 1, (V[]){heff_dup(v_j_241)})}));
      break;
    }
    case TAG_VCons: {
      v_x1_2417 = heff_abandon();
      break;
    }
    case TAG_VTag: {
      v_x1_2417 = heff_abandon();
      break;
    }
    case TAG_VInt: {
      v_x1_2417 = heff_abandon();
      break;
    }
    case TAG_VFloat: {
      v_x1_2417 = heff_abandon();
      break;
    }
    case TAG_VFloat32: {
      v_x1_2417 = heff_abandon();
      break;
    }
    case TAG_VStr: {
      v_x1_2417 = heff_abandon();
      break;
    }
    case TAG_VRune: {
      v_x1_2417 = heff_abandon();
      break;
    }
    case TAG_VArr: {
      v_x1_2417 = heff_abandon();
      break;
    }
    case TAG_VErased: {
      v_x1_2417 = heff_tag(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
      break;
    }
    default: heff_nomatch(v_f_243);
    }
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Ok: {
      V v_v_2418 = heff_field(v_x1_2417, 0);
      heff_take_n(v_x1_2417, 1ULL, 1);
      V t_0 = v_d_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
      V t_2 = v_n_242;
      V t_3 = v_f_243;
      V t_4 = heff_clo(g_heff_2einterp_2egenGo_lam1, 1, 2, (V[]){v_k_244, v_v_2418});
      v_d_240 = t_0;
      v_j_241 = t_1;
      v_n_242 = t_2;
      v_f_243 = t_3;
      v_k_244 = t_4;
      goto top;
    }
    case TAG_Abn: {
      heff_drop(v_d_240);
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      heff_drop(v_f_243);
      heff_drop(v_k_244);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_d_240);
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      heff_drop(v_f_243);
      heff_drop(v_k_244);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_2417);
    }
  }
}
V g_heff_2einterp_2egenGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2egenGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2einterp_2egenGo_lam0(V self, V *args) {
  V v_d_247 = args[0];
  V v_j_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_247);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_j_241})});
}
V g_heff_2einterp_2egenGo_lam1(V self, V *args) {
  V v_vs_2419 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_v_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_244;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_v_2418, v_vs_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2efromListV_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {67, 111, 110, 115}};
Clo g_heff_2einterp_2efromListV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efromListV_entry, 2, 0};

V g_heff_2einterp_2efromListV(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VTag: {
    V v_x11_244 = heff_field(v_x1_240, 0);
    V v_x12_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24VTag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(v_x11_244, ((V)&g_heff_2einterp_2efromListV_str0))) {
      switch (heff_tag_of(v_x12_245)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24VTag, 2);
        HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x12_245, 0);
        V v_x122_248 = heff_field(v_x12_245, 1);
        heff_take_n(v_x12_245, 3ULL, 2);
        switch (heff_tag_of(v_x122_248)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
          heff_drop(v_x_247);
          HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
        }
        case TAG_Cons: {
          V v_rest_249 = heff_field(v_x122_248, 0);
          V v_x1222_2410 = heff_field(v_x122_248, 1);
          heff_take_n(v_x122_248, 3ULL, 2);
          switch (heff_tag_of(v_x1222_2410)) {
          case TAG_Nil: {
            V t_0 = v_rest_249;
            V t_1 = heff_tag_at(v_ru_24x1_240_24VTag, TAG_Cons, 2, (V[]){v_x_247, v_acc_241});
            v_x1_240 = t_0;
            v_acc_241 = t_1;
            goto top;
          }
          case TAG_Cons: {
            heff_take_n(v_x1222_2410, 0ULL, 2);
            heff_drop_cell(v_ru_24x1_240_24VTag, 2);
            heff_drop(v_x_247);
            heff_drop(v_rest_249);
            HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
          }
          default: return heff_nomatch(v_x1222_2410);
          }
        }
        default: return heff_nomatch(v_x122_248);
        }
      }
      default: return heff_nomatch(v_x12_245);
      }
    } else {
      heff_drop(v_x12_245);
      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
      HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
    }
  }
  case TAG_VInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VArr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VErased: {
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2efromListV_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2efromListV(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2einterp_2etoListV_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {78, 105, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2etoListV_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {67, 111, 110, 115}};
Clo g_heff_2einterp_2etoListV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2etoListV_entry, 1, 0};

V g_heff_2einterp_2etoListV(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag(TAG_VTag, 2, (V[]){((V)&g_heff_2einterp_2etoListV_str0), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_heff_2einterp_2etoListV(v_xs_242));
    V v_t_244 = heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
    return heff_tag(TAG_VTag, 2, (V[]){((V)&g_heff_2einterp_2etoListV_str1), heff_tag(TAG_Cons, 2, (V[]){v_x_241, v_t_244})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2etoListV_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2etoListV(a[0]);
}
Clo g_heff_2einterp_2enthV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2enthV_entry, 2, 0};

V g_heff_2einterp_2enthV(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_xs_243;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2enthV_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2enthV(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2einterp_2etruncDiv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2etruncDiv_entry, 2, 0};

V g_heff_2einterp_2etruncDiv(V v_a_240, V v_b_241) {
top: ;
  V v_a_242 = heff_intMod(heff_dup(v_a_240), heff_dup(v_b_241));
  if (heff_intEq_c(v_a_242, MK_INT(0LL))) {
    return heff_intDiv(v_a_240, v_b_241);
  } else {
    V v_t_245;
    if (heff_intLt_c(heff_dup(v_a_240), MK_INT(0LL))) {
      v_t_245 = heff_intLe(MK_INT(0LL), heff_dup(v_b_241));
    } else {
      v_t_245 = heff_intLt(heff_dup(v_b_241), MK_INT(0LL));
    }
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      V v_t_246 = heff_intDiv(v_a_240, v_b_241);
      return heff_intAdd(v_t_246, MK_INT(1LL));
    }
    case TAG_False: {
      return heff_intDiv(v_a_240, v_b_241);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
}
V g_heff_2einterp_2etruncDiv_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2etruncDiv(a[0], a[1]);
}
Clo g_heff_2einterp_2ebitwise_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2ebitwise_entry, 4, 0};

V g_heff_2einterp_2ebitwise(V v_f_240, V v_n_241, V v_a_242, V v_b_243) {
top: ;
  if (heff_intEq_c(heff_dup(v_n_241), MK_INT(0LL))) {
    heff_drop(v_f_240);
    heff_drop(v_n_241);
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return MK_INT(0LL);
  } else {
    V v_t_245 = heff_intMod(heff_dup(v_a_242), MK_INT(2LL));
    V v_t_246 = heff_intMod(heff_dup(v_b_243), MK_INT(2LL));
    V v_t_247 = heff_tr(heff_apply(heff_dup(v_f_240), 2, (V[]){v_t_245, v_t_246}));
    V v_t_248 = heff_intDiv(v_a_242, MK_INT(2LL));
    V v_t_249 = heff_intDiv(v_b_243, MK_INT(2LL));
    V v_t_2410 = (g_heff_2einterp_2ebitwise(v_f_240, heff_intSub(v_n_241, MK_INT(1LL)), v_t_248, v_t_249));
    return heff_intAdd(v_t_247, heff_intMul(MK_INT(2LL), v_t_2410));
  }
}
V g_heff_2einterp_2ebitwise_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2ebitwise(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2einterp_2ebitwise_24s348840635x1130995754_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2ebitwise_24s348840635x1130995754_entry, 3, 0};

V g_heff_2einterp_2ebitwise_24s348840635x1130995754(V v_n_240, V v_a_241, V v_b_242) {
top: ;
  if (heff_intEq_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return MK_INT(0LL);
  } else {
    V v_a_244 = heff_intMod(heff_dup(v_a_241), MK_INT(2LL));
    V v_a_245 = heff_intMod(heff_dup(v_b_242), MK_INT(2LL));
    V v_t_246 = heff_intDiv(v_a_241, MK_INT(2LL));
    V v_t_247 = heff_intDiv(v_b_242, MK_INT(2LL));
    V v_t_248 = (g_heff_2einterp_2ebitwise_24s348840635x1130995754(heff_intSub(v_n_240, MK_INT(1LL)), v_t_246, v_t_247));
    return heff_intAdd(heff_intMul(v_a_244, v_a_245), heff_intMul(MK_INT(2LL), v_t_248));
  }
}
V g_heff_2einterp_2ebitwise_24s348840635x1130995754_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2ebitwise_24s348840635x1130995754(a[0], a[1], a[2]);
}
Clo g_heff_2einterp_2ebitsOf_24s2122496700x1608419743_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2ebitsOf_24s2122496700x1608419743_entry, 3, 0};

V g_heff_2einterp_2ebitsOf_24s2122496700x1608419743(V v_w_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_243 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_243 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_243 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_243 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_243 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_243 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_243 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_243 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_243 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_244;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_244 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_244 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_244 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_244 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_244 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_244 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_245 = (g_heff_2efixed_2etwoTo(v_t_244));
  V v_t_246 = heff_intMod(v_a_241, v_t_245);
  V v_t_247;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_247 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_247 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_247 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_247 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_247 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_247 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_247 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_247 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_247 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_248 = (g_heff_2efixed_2etwoTo(v_t_247));
  V v_t_249 = heff_intMod(v_b_242, v_t_248);
  V v_n_2410 = (g_heff_2einterp_2ebitwise_24s348840635x1130995754(v_t_243, v_t_246, v_t_249));
  V v_t_2411 = (g_heff_2efixed_2efixedMin(v_w_240));
  V v_t_2412 = (g_heff_2efixed_2efixedMin(v_w_240));
  V v_t_2413;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_2413 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_2413 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_2413 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_2413 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_2413 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_2413 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_2413 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_2413 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_2413 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_2414 = (g_heff_2efixed_2etwoTo(v_t_2413));
  V v_t_2415 = heff_intMod(heff_intSub(v_n_2410, v_t_2412), v_t_2414);
  V v_t_2416 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2411, v_t_2415)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2416});
}
V g_heff_2einterp_2ebitsOf_24s2122496700x1608419743_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2ebitsOf_24s2122496700x1608419743(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2einterp_2ebitsOf_24s277023746x1062825997_lam0(V self, V *args);
Clo g_heff_2einterp_2ebitsOf_24s277023746x1062825997_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2ebitsOf_24s277023746x1062825997_entry, 6, 0};

V g_heff_2einterp_2ebitsOf_24s277023746x1062825997(V v_lit_240, V v_lit_241, V v_lit_242, V v_w_243, V v_a_244, V v_b_245) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_w_243)) {
  case TAG_I8: {
    v_t_246 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_246 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_246 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_246 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_246 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_246 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_246 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_246 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_246 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_243);
  }
  V v_t_247;
  switch (heff_tag_of(v_w_243)) {
  case TAG_I8: {
    v_t_247 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_247 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_247 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_247 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_247 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_247 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_247 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_247 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_247 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_243);
  }
  V v_t_248 = (g_heff_2efixed_2etwoTo(v_t_247));
  V v_t_249 = heff_intMod(v_a_244, v_t_248);
  V v_t_2410;
  switch (heff_tag_of(v_w_243)) {
  case TAG_I8: {
    v_t_2410 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_2410 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_2410 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_2410 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_2410 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_2410 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_2410 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_2410 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_2410 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_243);
  }
  V v_t_2411 = (g_heff_2efixed_2etwoTo(v_t_2410));
  V v_t_2412 = heff_intMod(v_b_245, v_t_2411);
  V v_n_2416 = (g_heff_2einterp_2ebitwise(heff_clo(g_heff_2einterp_2ebitsOf_24s277023746x1062825997_lam0, 2, 3, (V[]){v_lit_240, v_lit_241, v_lit_242}), v_t_246, v_t_249, v_t_2412));
  V v_t_2417 = (g_heff_2efixed_2efixedMin(v_w_243));
  V v_t_2418 = (g_heff_2efixed_2efixedMin(v_w_243));
  V v_t_2419;
  switch (heff_tag_of(v_w_243)) {
  case TAG_I8: {
    v_t_2419 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_2419 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_2419 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_2419 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_2419 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_2419 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_2419 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_2419 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_2419 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_243);
  }
  V v_t_2420 = (g_heff_2efixed_2etwoTo(v_t_2419));
  V v_t_2421 = heff_intMod(heff_intSub(v_n_2416, v_t_2418), v_t_2420);
  V v_t_2422 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2417, v_t_2421)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2422});
}
V g_heff_2einterp_2ebitsOf_24s277023746x1062825997_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2ebitsOf_24s277023746x1062825997(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[3]); return r;
}
V g_heff_2einterp_2ebitsOf_24s277023746x1062825997_lam0(V self, V *args) {
  V v_a_2413 = args[0];
  V v_a_2414 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_intLt_c(v_lit_240, heff_intAdd(v_a_2413, v_a_2414))) {
    heff_drop(v_lit_242);
    return v_lit_241;
  } else {
    heff_drop(v_lit_241);
    return v_lit_242;
  }
}
V g_heff_2einterp_2ebitsOf_24s1458520709x2132426067_lam0(V self, V *args);
Clo g_heff_2einterp_2ebitsOf_24s1458520709x2132426067_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2ebitsOf_24s1458520709x2132426067_entry, 4, 0};

V g_heff_2einterp_2ebitsOf_24s1458520709x2132426067(V v_lit_240, V v_w_241, V v_a_242, V v_b_243) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_244 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_244 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_244 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_244 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_244 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_244 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  V v_t_245;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_245 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_245 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_245 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_245 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_245 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_245 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_245 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_245 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_245 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  V v_t_246 = (g_heff_2efixed_2etwoTo(v_t_245));
  V v_t_247 = heff_intMod(v_a_242, v_t_246);
  V v_t_248;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_248 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_248 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_248 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_248 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_248 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_248 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_248 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_248 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_248 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  V v_t_249 = (g_heff_2efixed_2etwoTo(v_t_248));
  V v_t_2410 = heff_intMod(v_b_243, v_t_249);
  V v_n_2413 = (g_heff_2einterp_2ebitwise(heff_clo(g_heff_2einterp_2ebitsOf_24s1458520709x2132426067_lam0, 2, 1, (V[]){v_lit_240}), v_t_244, v_t_247, v_t_2410));
  V v_t_2414 = (g_heff_2efixed_2efixedMin(v_w_241));
  V v_t_2415 = (g_heff_2efixed_2efixedMin(v_w_241));
  V v_t_2416;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_2416 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_2416 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_2416 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_2416 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_2416 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_2416 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_2416 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_2416 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_2416 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  V v_t_2417 = (g_heff_2efixed_2etwoTo(v_t_2416));
  V v_t_2418 = heff_intMod(heff_intSub(v_n_2413, v_t_2415), v_t_2417);
  V v_t_2419 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2414, v_t_2418)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2419});
}
V g_heff_2einterp_2ebitsOf_24s1458520709x2132426067_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2ebitsOf_24s1458520709x2132426067(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2einterp_2ebitsOf_24s1458520709x2132426067_lam0(V self, V *args) {
  V v_a_2411 = args[0];
  V v_a_2412 = args[1];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intMod(heff_intAdd(v_a_2411, v_a_2412), v_lit_240);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2efixedInt2_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2efixedInt2_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2efixedInt2_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2efixedInt2_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2efixedInt2_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2efixedInt2_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
Clo g_heff_2einterp_2efixedInt2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efixedInt2_entry, 4, 0};

V g_heff_2einterp_2efixedInt2(V v_w_240, V v_x2_241, V v_a_242, V v_b_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_OpAdd: {
    V v_t_244 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_245 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_246 = heff_intSub(heff_intAdd(v_a_242, v_b_243), v_t_245);
    V v_t_247;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_247 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_247 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_247 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_247 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_247 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_247 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_247 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_247 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_247 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_248 = (g_heff_2efixed_2etwoTo(v_t_247));
    V v_t_249 = heff_intMod(v_t_246, v_t_248);
    V v_t_2410 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_244, v_t_249)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_2410});
  }
  case TAG_OpSub: {
    V v_t_2411 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_2412 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_2413 = heff_intSub(heff_intSub(v_a_242, v_b_243), v_t_2412);
    V v_t_2414;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2414 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2414 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2414 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2414 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2414 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2414 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2414 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2414 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2414 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2415 = (g_heff_2efixed_2etwoTo(v_t_2414));
    V v_t_2416 = heff_intMod(v_t_2413, v_t_2415);
    V v_t_2417 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2411, v_t_2416)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_2417});
  }
  case TAG_OpMul: {
    V v_t_2418 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_2419 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_2420 = heff_intSub(heff_intMul(v_a_242, v_b_243), v_t_2419);
    V v_t_2421;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2421 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2421 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2421 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2421 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2421 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2421 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2421 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2421 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2421 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2422 = (g_heff_2efixed_2etwoTo(v_t_2421));
    V v_t_2423 = heff_intMod(v_t_2420, v_t_2422);
    V v_t_2424 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2418, v_t_2423)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_2424});
  }
  case TAG_OpDiv: {
    if (heff_intEq_c(heff_dup(v_b_243), MK_INT(0LL))) {
      heff_drop(v_a_242);
      heff_drop(v_b_243);
      return NTAG(TAG_Abn);
    } else {
      V v_n_2426 = (g_heff_2einterp_2etruncDiv(v_a_242, v_b_243));
      V v_t_2427 = (g_heff_2efixed_2efixedMin(v_w_240));
      V v_t_2428 = (g_heff_2efixed_2efixedMin(v_w_240));
      V v_t_2429;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2429 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_2429 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_2429 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_2429 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_2429 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_2429 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_2429 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_2429 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_2429 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_2430 = (g_heff_2efixed_2etwoTo(v_t_2429));
      V v_t_2431 = heff_intMod(heff_intSub(v_n_2426, v_t_2428), v_t_2430);
      V v_t_2432 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2427, v_t_2431)});
      return heff_tag(TAG_Ok, 1, (V[]){v_t_2432});
    }
  }
  case TAG_OpRem: {
    if (heff_intEq_c(heff_dup(v_b_243), MK_INT(0LL))) {
      heff_drop(v_a_242);
      heff_drop(v_b_243);
      return NTAG(TAG_Abn);
    } else {
      V v_t_2434 = (g_heff_2einterp_2etruncDiv(heff_dup(v_a_242), heff_dup(v_b_243)));
      V v_n_2435 = heff_intSub(v_a_242, heff_intMul(v_b_243, v_t_2434));
      V v_t_2436 = (g_heff_2efixed_2efixedMin(v_w_240));
      V v_t_2437 = (g_heff_2efixed_2efixedMin(v_w_240));
      V v_t_2438;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2438 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_2438 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_2438 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_2438 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_2438 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_2438 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_2438 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_2438 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_2438 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_2439 = (g_heff_2efixed_2etwoTo(v_t_2438));
      V v_t_2440 = heff_intMod(heff_intSub(v_n_2435, v_t_2437), v_t_2439);
      V v_t_2441 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2436, v_t_2440)});
      return heff_tag(TAG_Ok, 1, (V[]){v_t_2441});
    }
  }
  case TAG_OpEq: {
    V v_t_2443;
    if (heff_intEq_c(v_a_242, v_b_243)) {
      v_t_2443 = ((V)&g_heff_2einterp_2efixedInt2_str0);
    } else {
      v_t_2443 = ((V)&g_heff_2einterp_2efixedInt2_str1);
    }
    V v_t_2444 = heff_tag(TAG_VTag, 2, (V[]){v_t_2443, NTAG(TAG_Nil)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_2444});
  }
  case TAG_OpLt: {
    V v_t_2446;
    if (heff_intLt_c(v_a_242, v_b_243)) {
      v_t_2446 = ((V)&g_heff_2einterp_2efixedInt2_str2);
    } else {
      v_t_2446 = ((V)&g_heff_2einterp_2efixedInt2_str3);
    }
    V v_t_2447 = heff_tag(TAG_VTag, 2, (V[]){v_t_2446, NTAG(TAG_Nil)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_2447});
  }
  case TAG_OpLe: {
    V v_t_2449;
    if (heff_intLe_c(v_a_242, v_b_243)) {
      v_t_2449 = ((V)&g_heff_2einterp_2efixedInt2_str4);
    } else {
      v_t_2449 = ((V)&g_heff_2einterp_2efixedInt2_str5);
    }
    V v_t_2450 = heff_tag(TAG_VTag, 2, (V[]){v_t_2449, NTAG(TAG_Nil)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_2450});
  }
  case TAG_OpAnd: {
    return (g_heff_2einterp_2ebitsOf_24s2122496700x1608419743(v_w_240, v_a_242, v_b_243));
  }
  case TAG_OpOr: {
    return (g_heff_2einterp_2ebitsOf_24s277023746x1062825997(MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), v_w_240, v_a_242, v_b_243));
  }
  case TAG_OpXor: {
    HEFF_LAST return g_heff_2einterp_2ebitsOf_24s1458520709x2132426067(MK_INT(2LL), v_w_240, v_a_242, v_b_243);
  }
  case TAG_OpShl: {
    V v_t_2451;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2451 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2451 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2451 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2451 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2451 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2451 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2451 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2451 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2451 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2452 = heff_intMod(v_b_243, v_t_2451);
    V v_t_2453 = (g_heff_2efixed_2etwoTo(v_t_2452));
    V v_n_2454 = heff_intMul(v_a_242, v_t_2453);
    V v_t_2455 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_2456 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_2457;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2457 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2457 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2457 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2457 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2457 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2457 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2457 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2457 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2457 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2458 = (g_heff_2efixed_2etwoTo(v_t_2457));
    V v_t_2459 = heff_intMod(heff_intSub(v_n_2454, v_t_2456), v_t_2458);
    V v_t_2460 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2455, v_t_2459)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_2460});
  }
  case TAG_OpShr: {
    V v_t_2461;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2461 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2461 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2461 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2461 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2461 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2461 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2461 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2461 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2461 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2462 = heff_intMod(v_b_243, v_t_2461);
    V v_t_2463 = (g_heff_2efixed_2etwoTo(v_t_2462));
    V v_t_2464 = heff_intDiv(v_a_242, v_t_2463);
    return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_t_2464})});
  }
  case TAG_OpShow: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_OpFromInt: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_OpToInt: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_OpSqrt: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_OpFromFloat: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_OpToFloat: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_OpFloor: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2einterp_2efixedInt2_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2efixedInt2(a[0], a[1], a[2], a[3]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2einterp_2efixedInt1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efixedInt1_entry, 3, 0};

V g_heff_2einterp_2efixedInt1(V v_w_240, V v_x2_241, V v_a_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_OpAdd: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpSub: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpMul: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpDiv: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpRem: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpEq: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpLt: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpLe: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpAnd: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpOr: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpXor: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpShl: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpShr: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpShow: {
    V v_t_243 = heff_tag(TAG_VStr, 1, (V[]){heff_intShow(v_a_242)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_243});
  }
  case TAG_OpFromInt: {
    V v_t_244 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_245 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_246;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_246 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_246 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_246 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_246 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_246 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_246 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_246 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_246 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_246 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_247 = (g_heff_2efixed_2etwoTo(v_t_246));
    V v_t_248 = heff_intMod(heff_intSub(v_a_242, v_t_245), v_t_247);
    V v_t_249 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_244, v_t_248)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_249});
  }
  case TAG_OpToInt: {
    return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_a_242})});
  }
  case TAG_OpSqrt: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpFromFloat: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpToFloat: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpFloor: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2einterp_2efixedInt1_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2efixedInt1(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2einterp_2ef32V2_lam1(V self, V *args);
V g_heff_2einterp_2ef32V2_lam0(V self, V *args);
Clo g_heff_2einterp_2ef32V2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2ef32V2_entry, 1, 0};

V g_heff_2einterp_2ef32V2(V v_f_240) {
top: ;
  return heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2ef32V2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2einterp_2ef32V2_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2ef32V2(a[0]);
}
V g_heff_2einterp_2ef32V2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_apply(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_apply(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      switch (heff_tag_of(v_v_246)) {
      case TAG_VFun: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_246, 0ULL, 2);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VFloat: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VFloat32: {
        V v_a_2415 = heff_field(v_v_246, 0);
        heff_take_n(v_v_246, 1ULL, 1);
        switch (heff_tag_of(v_v_248)) {
        case TAG_VFun: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_248, 0ULL, 2);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VFloat: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VFloat32: {
          V v_b_2422 = heff_field(v_v_248, 0);
          heff_take_n(v_v_248, 1ULL, 1);
          V f_ = v_f_240;
          args[0] = v_a_2415;
          args[1] = v_b_2422;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        case TAG_VStr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VRune: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_248);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VRune: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_246);
      }
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2einterp_2ef32V2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2ef32V2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
V g_heff_2einterp_2ef32V2_24s950619608x1678710457_lam1(V self, V *args);
V g_heff_2einterp_2ef32V2_24s950619608x1678710457_lam0(V self, V *args); static Clo g_heff_2einterp_2ef32V2_24s950619608x1678710457_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2ef32V2_24s950619608x1678710457_lam0, 2, 0};

static V g_heff_2einterp_2ef32V2_24s950619608x1678710457_val;
static int g_heff_2einterp_2ef32V2_24s950619608x1678710457_st;
static V g_heff_2einterp_2ef32V2_24s950619608x1678710457_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2ef32V2_24s950619608x1678710457_lam0_clo)});
}
V g_heff_2einterp_2ef32V2_24s950619608x1678710457_get(void) {
  if (g_heff_2einterp_2ef32V2_24s950619608x1678710457_st == 2) return g_heff_2einterp_2ef32V2_24s950619608x1678710457_val;
  if (g_heff_2einterp_2ef32V2_24s950619608x1678710457_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2ef32V2_24s950619608x1678710457_st = 1;
  g_heff_2einterp_2ef32V2_24s950619608x1678710457_val = heff_tr(g_heff_2einterp_2ef32V2_24s950619608x1678710457_init());
  g_heff_2einterp_2ef32V2_24s950619608x1678710457_st = 2;
  return g_heff_2einterp_2ef32V2_24s950619608x1678710457_val;
}
V g_heff_2einterp_2ef32V2_24s950619608x1678710457_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat32: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VFloat: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VFloat32: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2422 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VFloat32, 1, (V[]){heff_float32Add(v_a_2414, v_b_2421)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2ef32V2_24s950619608x1678710457_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2ef32V2_24s950619608x1678710457_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2ef32V2_24s987891065x1106715032_lam1(V self, V *args);
V g_heff_2einterp_2ef32V2_24s987891065x1106715032_lam0(V self, V *args); static Clo g_heff_2einterp_2ef32V2_24s987891065x1106715032_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2ef32V2_24s987891065x1106715032_lam0, 2, 0};

static V g_heff_2einterp_2ef32V2_24s987891065x1106715032_val;
static int g_heff_2einterp_2ef32V2_24s987891065x1106715032_st;
static V g_heff_2einterp_2ef32V2_24s987891065x1106715032_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2ef32V2_24s987891065x1106715032_lam0_clo)});
}
V g_heff_2einterp_2ef32V2_24s987891065x1106715032_get(void) {
  if (g_heff_2einterp_2ef32V2_24s987891065x1106715032_st == 2) return g_heff_2einterp_2ef32V2_24s987891065x1106715032_val;
  if (g_heff_2einterp_2ef32V2_24s987891065x1106715032_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2ef32V2_24s987891065x1106715032_st = 1;
  g_heff_2einterp_2ef32V2_24s987891065x1106715032_val = heff_tr(g_heff_2einterp_2ef32V2_24s987891065x1106715032_init());
  g_heff_2einterp_2ef32V2_24s987891065x1106715032_st = 2;
  return g_heff_2einterp_2ef32V2_24s987891065x1106715032_val;
}
V g_heff_2einterp_2ef32V2_24s987891065x1106715032_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat32: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VFloat: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VFloat32: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2422 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VFloat32, 1, (V[]){heff_float32Sub(v_a_2414, v_b_2421)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2ef32V2_24s987891065x1106715032_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2ef32V2_24s987891065x1106715032_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2ef32V2_24s408265061x438630957_lam1(V self, V *args);
V g_heff_2einterp_2ef32V2_24s408265061x438630957_lam0(V self, V *args); static Clo g_heff_2einterp_2ef32V2_24s408265061x438630957_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2ef32V2_24s408265061x438630957_lam0, 2, 0};

static V g_heff_2einterp_2ef32V2_24s408265061x438630957_val;
static int g_heff_2einterp_2ef32V2_24s408265061x438630957_st;
static V g_heff_2einterp_2ef32V2_24s408265061x438630957_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2ef32V2_24s408265061x438630957_lam0_clo)});
}
V g_heff_2einterp_2ef32V2_24s408265061x438630957_get(void) {
  if (g_heff_2einterp_2ef32V2_24s408265061x438630957_st == 2) return g_heff_2einterp_2ef32V2_24s408265061x438630957_val;
  if (g_heff_2einterp_2ef32V2_24s408265061x438630957_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2ef32V2_24s408265061x438630957_st = 1;
  g_heff_2einterp_2ef32V2_24s408265061x438630957_val = heff_tr(g_heff_2einterp_2ef32V2_24s408265061x438630957_init());
  g_heff_2einterp_2ef32V2_24s408265061x438630957_st = 2;
  return g_heff_2einterp_2ef32V2_24s408265061x438630957_val;
}
V g_heff_2einterp_2ef32V2_24s408265061x438630957_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat32: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VFloat: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VFloat32: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2422 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VFloat32, 1, (V[]){heff_float32Mul(v_a_2414, v_b_2421)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2ef32V2_24s408265061x438630957_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2ef32V2_24s408265061x438630957_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2ef32V2_24s2125509355x867594919_lam1(V self, V *args);
V g_heff_2einterp_2ef32V2_24s2125509355x867594919_lam0(V self, V *args); static Clo g_heff_2einterp_2ef32V2_24s2125509355x867594919_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2ef32V2_24s2125509355x867594919_lam0, 2, 0};

static V g_heff_2einterp_2ef32V2_24s2125509355x867594919_val;
static int g_heff_2einterp_2ef32V2_24s2125509355x867594919_st;
static V g_heff_2einterp_2ef32V2_24s2125509355x867594919_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2ef32V2_24s2125509355x867594919_lam0_clo)});
}
V g_heff_2einterp_2ef32V2_24s2125509355x867594919_get(void) {
  if (g_heff_2einterp_2ef32V2_24s2125509355x867594919_st == 2) return g_heff_2einterp_2ef32V2_24s2125509355x867594919_val;
  if (g_heff_2einterp_2ef32V2_24s2125509355x867594919_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2ef32V2_24s2125509355x867594919_st = 1;
  g_heff_2einterp_2ef32V2_24s2125509355x867594919_val = heff_tr(g_heff_2einterp_2ef32V2_24s2125509355x867594919_init());
  g_heff_2einterp_2ef32V2_24s2125509355x867594919_st = 2;
  return g_heff_2einterp_2ef32V2_24s2125509355x867594919_val;
}
V g_heff_2einterp_2ef32V2_24s2125509355x867594919_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VFloat: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VFloat32: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VFloat: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VFloat32: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_a_2422 = heff_float32Div(v_a_2414, v_b_2421);
          return heff_tag_at(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFloat32, 1, (V[]){v_a_2422})});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2ef32V2_24s2125509355x867594919_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2ef32V2_24s2125509355x867594919_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2ef32V1_24s1317596417x824260503_lam0(V self, V *args); static Clo g_heff_2einterp_2ef32V1_24s1317596417x824260503_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2ef32V1_24s1317596417x824260503_lam0, 2, 0};

static V g_heff_2einterp_2ef32V1_24s1317596417x824260503_val;
static int g_heff_2einterp_2ef32V1_24s1317596417x824260503_st;
static V g_heff_2einterp_2ef32V1_24s1317596417x824260503_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2ef32V1_24s1317596417x824260503_lam0_clo)});
}
V g_heff_2einterp_2ef32V1_24s1317596417x824260503_get(void) {
  if (g_heff_2einterp_2ef32V1_24s1317596417x824260503_st == 2) return g_heff_2einterp_2ef32V1_24s1317596417x824260503_val;
  if (g_heff_2einterp_2ef32V1_24s1317596417x824260503_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2ef32V1_24s1317596417x824260503_st = 1;
  g_heff_2einterp_2ef32V1_24s1317596417x824260503_val = heff_tr(g_heff_2einterp_2ef32V1_24s1317596417x824260503_init());
  g_heff_2einterp_2ef32V1_24s1317596417x824260503_st = 2;
  return g_heff_2einterp_2ef32V1_24s1317596417x824260503_val;
}
V g_heff_2einterp_2ef32V1_24s1317596417x824260503_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  V v_x1_242 = heff_tr(heff_apply(v_a_241, 1, (V[]){v_d_240}));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Ok: {
    V v_v_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Ok = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    switch (heff_tag_of(v_v_243)) {
    case TAG_VFun: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      V v_a_2410 = heff_field(v_v_243, 0);
      heff_take_n(v_v_243, 1ULL, 1);
      V v_x_2411 = heff_float32ToFloat(heff_dup(v_a_2410));
      if (heff_floatEq_c(heff_floatSub(heff_dup(v_x_2411), v_x_2411), heff_flt(0.0))) {
        V v_t_2413 = heff_float32Floor(v_a_2410);
        return heff_tag_at(v_ru_24x1_242_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_t_2413})});
      } else {
        heff_drop_cell(v_ru_24x1_242_24Ok, 1);
        heff_drop(v_a_2410);
        return NTAG(TAG_Abn);
      }
    }
    case TAG_VStr: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_243);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_242);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2efloat32V_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2efloat32V_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2efloat32V_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2efloat32V_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2efloat32V_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2efloat32V_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
V g_heff_2einterp_2efloat32V_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat32V_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat32V_lam0, 2, 0};
V g_heff_2einterp_2efloat32V_lam1(V self, V *args); static Clo g_heff_2einterp_2efloat32V_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat32V_lam1, 2, 0};
V g_heff_2einterp_2efloat32V_lam2(V self, V *args); static Clo g_heff_2einterp_2efloat32V_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat32V_lam2, 2, 0};
V g_heff_2einterp_2efloat32V_lam3(V self, V *args); static Clo g_heff_2einterp_2efloat32V_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat32V_lam3, 2, 0};
V g_heff_2einterp_2efloat32V_lam4(V self, V *args); static Clo g_heff_2einterp_2efloat32V_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat32V_lam4, 2, 0};
V g_heff_2einterp_2efloat32V_lam5(V self, V *args); static Clo g_heff_2einterp_2efloat32V_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat32V_lam5, 2, 0};
V g_heff_2einterp_2efloat32V_lam6(V self, V *args); static Clo g_heff_2einterp_2efloat32V_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat32V_lam6, 2, 0};
V g_heff_2einterp_2efloat32V_lam7(V self, V *args); static Clo g_heff_2einterp_2efloat32V_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat32V_lam7, 2, 0};
V g_heff_2einterp_2efloat32V_lam8(V self, V *args); static Clo g_heff_2einterp_2efloat32V_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat32V_lam8, 2, 0};
V g_heff_2einterp_2efloat32V_lam9(V self, V *args); static Clo g_heff_2einterp_2efloat32V_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat32V_lam9, 2, 0};
V g_heff_2einterp_2efloat32V_lam10(V self, V *args); static Clo g_heff_2einterp_2efloat32V_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat32V_lam10, 2, 0};
V g_heff_2einterp_2efloat32V_lam11(V self, V *args); static Clo g_heff_2einterp_2efloat32V_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat32V_lam11, 2, 0};
V g_heff_2einterp_2efloat32V_lam12(V self, V *args); static Clo g_heff_2einterp_2efloat32V_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat32V_lam12, 2, 0};
V g_heff_2einterp_2efloat32V_lam13(V self, V *args); static Clo g_heff_2einterp_2efloat32V_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat32V_lam13, 2, 0};
V g_heff_2einterp_2efloat32V_lam14(V self, V *args); static Clo g_heff_2einterp_2efloat32V_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat32V_lam14, 2, 0};
Clo g_heff_2einterp_2efloat32V_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat32V_entry, 1, 0};

V g_heff_2einterp_2efloat32V(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_OpAdd: {
    return heff_dup(g_heff_2einterp_2ef32V2_24s950619608x1678710457_get());
  }
  case TAG_OpSub: {
    return heff_dup(g_heff_2einterp_2ef32V2_24s987891065x1106715032_get());
  }
  case TAG_OpMul: {
    return heff_dup(g_heff_2einterp_2ef32V2_24s408265061x438630957_get());
  }
  case TAG_OpDiv: {
    return heff_dup(g_heff_2einterp_2ef32V2_24s2125509355x867594919_get());
  }
  case TAG_OpRem: {
    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat32V_lam0_clo)});
  }
  case TAG_OpEq: {
    HEFF_LAST return g_heff_2einterp_2ef32V2(((V)&g_heff_2einterp_2efloat32V_lam1_clo));
  }
  case TAG_OpLt: {
    HEFF_LAST return g_heff_2einterp_2ef32V2(((V)&g_heff_2einterp_2efloat32V_lam2_clo));
  }
  case TAG_OpLe: {
    HEFF_LAST return g_heff_2einterp_2ef32V2(((V)&g_heff_2einterp_2efloat32V_lam3_clo));
  }
  case TAG_OpAnd: {
    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat32V_lam4_clo)});
  }
  case TAG_OpOr: {
    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat32V_lam5_clo)});
  }
  case TAG_OpXor: {
    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat32V_lam6_clo)});
  }
  case TAG_OpShl: {
    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat32V_lam7_clo)});
  }
  case TAG_OpShr: {
    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat32V_lam8_clo)});
  }
  case TAG_OpShow: {
    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat32V_lam9_clo)});
  }
  case TAG_OpFromInt: {
    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat32V_lam10_clo)});
  }
  case TAG_OpToInt: {
    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat32V_lam11_clo)});
  }
  case TAG_OpSqrt: {
    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat32V_lam12_clo)});
  }
  case TAG_OpFromFloat: {
    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat32V_lam13_clo)});
  }
  case TAG_OpToFloat: {
    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat32V_lam14_clo)});
  }
  case TAG_OpFloor: {
    return heff_dup(g_heff_2einterp_2ef32V1_24s1317596417x824260503_get());
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2efloat32V_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2efloat32V(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2einterp_2efloat32V_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  heff_drop(v_d_241);
  heff_drop(v_a_242);
  return NTAG(TAG_Abn);
}
V g_heff_2einterp_2efloat32V_lam1(V self, V *args) {
  V v_a_243 = args[0];
  V v_b_244 = args[1];
  V v_t_246;
  if (heff_float32Eq_c(v_a_243, v_b_244)) {
    v_t_246 = ((V)&g_heff_2einterp_2efloat32V_str0);
  } else {
    v_t_246 = ((V)&g_heff_2einterp_2efloat32V_str1);
  }
  V v_t_247 = heff_tag(TAG_VTag, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_247});
}
V g_heff_2einterp_2efloat32V_lam2(V self, V *args) {
  V v_a_248 = args[0];
  V v_b_249 = args[1];
  V v_t_2411;
  if (heff_float32Lt_c(v_a_248, v_b_249)) {
    v_t_2411 = ((V)&g_heff_2einterp_2efloat32V_str2);
  } else {
    v_t_2411 = ((V)&g_heff_2einterp_2efloat32V_str3);
  }
  V v_t_2412 = heff_tag(TAG_VTag, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2412});
}
V g_heff_2einterp_2efloat32V_lam3(V self, V *args) {
  V v_a_2413 = args[0];
  V v_b_2414 = args[1];
  V v_t_2416;
  if (heff_float32Le_c(v_a_2413, v_b_2414)) {
    v_t_2416 = ((V)&g_heff_2einterp_2efloat32V_str4);
  } else {
    v_t_2416 = ((V)&g_heff_2einterp_2efloat32V_str5);
  }
  V v_t_2417 = heff_tag(TAG_VTag, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2417});
}
V g_heff_2einterp_2efloat32V_lam4(V self, V *args) {
  V v_d_2418 = args[0];
  V v_a_2419 = args[1];
  heff_drop(v_d_2418);
  heff_drop(v_a_2419);
  return NTAG(TAG_Abn);
}
V g_heff_2einterp_2efloat32V_lam5(V self, V *args) {
  V v_d_2420 = args[0];
  V v_a_2421 = args[1];
  heff_drop(v_d_2420);
  heff_drop(v_a_2421);
  return NTAG(TAG_Abn);
}
V g_heff_2einterp_2efloat32V_lam6(V self, V *args) {
  V v_d_2422 = args[0];
  V v_a_2423 = args[1];
  heff_drop(v_d_2422);
  heff_drop(v_a_2423);
  return NTAG(TAG_Abn);
}
V g_heff_2einterp_2efloat32V_lam7(V self, V *args) {
  V v_d_2424 = args[0];
  V v_a_2425 = args[1];
  heff_drop(v_d_2424);
  heff_drop(v_a_2425);
  return NTAG(TAG_Abn);
}
V g_heff_2einterp_2efloat32V_lam8(V self, V *args) {
  V v_d_2426 = args[0];
  V v_a_2427 = args[1];
  heff_drop(v_d_2426);
  heff_drop(v_a_2427);
  return NTAG(TAG_Abn);
}
V g_heff_2einterp_2efloat32V_lam9(V self, V *args) {
  V v_d_2428 = args[0];
  V v_a_2429 = args[1];
  V v_x1_2430 = heff_tr(heff_apply(v_a_2429, 1, (V[]){v_d_2428}));
  switch (heff_tag_of(v_x1_2430)) {
  case TAG_Ok: {
    V v_v_2431 = heff_field(v_x1_2430, 0);
    V v_ru_24x1_2430_24Ok = heff_take_reuse_n(v_x1_2430, 1ULL, 1);
    switch (heff_tag_of(v_v_2431)) {
    case TAG_VFun: {
      heff_take_n(v_v_2431, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2430_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_2431, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2430_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_2431, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2430_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_2431, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2430_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_2431, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2430_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      V v_a_2438 = heff_field(v_v_2431, 0);
      V v_ru_24v_2431_24VFloat32 = heff_take_reuse_n(v_v_2431, 1ULL, 1);
      V v_t_2439 = heff_tag_at(v_ru_24x1_2430_24Ok, TAG_VStr, 1, (V[]){heff_float32Show(v_a_2438)});
      return heff_tag_at(v_ru_24v_2431_24VFloat32, TAG_Ok, 1, (V[]){v_t_2439});
    }
    case TAG_VStr: {
      heff_take_n(v_v_2431, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2430_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_2431, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2430_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_2431, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2430_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2430_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_2431);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_2430);
  }
}
V g_heff_2einterp_2efloat32V_lam10(V self, V *args) {
  V v_d_2443 = args[0];
  V v_a_2444 = args[1];
  V v_x1_2445 = heff_tr(heff_apply(v_a_2444, 1, (V[]){v_d_2443}));
  switch (heff_tag_of(v_x1_2445)) {
  case TAG_Ok: {
    V v_v_2446 = heff_field(v_x1_2445, 0);
    V v_ru_24x1_2445_24Ok = heff_take_reuse_n(v_x1_2445, 1ULL, 1);
    switch (heff_tag_of(v_v_2446)) {
    case TAG_VFun: {
      heff_take_n(v_v_2446, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2445_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_2446, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2445_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_2446, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2445_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_2451 = heff_field(v_v_2446, 0);
      V v_ru_24v_2446_24VInt = heff_take_reuse_n(v_v_2446, 1ULL, 1);
      V v_t_2452 = heff_tag_at(v_ru_24x1_2445_24Ok, TAG_VFloat32, 1, (V[]){heff_float32FromInt(v_a_2451)});
      return heff_tag_at(v_ru_24v_2446_24VInt, TAG_Ok, 1, (V[]){v_t_2452});
    }
    case TAG_VFloat: {
      heff_take_n(v_v_2446, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2445_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2446, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2445_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_2446, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2445_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_2446, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2445_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_2446, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2445_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2445_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_2446);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_2445);
  }
}
V g_heff_2einterp_2efloat32V_lam11(V self, V *args) {
  V v_d_2458 = args[0];
  V v_a_2459 = args[1];
  heff_drop(v_d_2458);
  heff_drop(v_a_2459);
  return NTAG(TAG_Abn);
}
V g_heff_2einterp_2efloat32V_lam12(V self, V *args) {
  V v_d_2460 = args[0];
  V v_a_2461 = args[1];
  V v_x1_2462 = heff_tr(heff_apply(v_a_2461, 1, (V[]){v_d_2460}));
  switch (heff_tag_of(v_x1_2462)) {
  case TAG_Ok: {
    V v_v_2463 = heff_field(v_x1_2462, 0);
    V v_ru_24x1_2462_24Ok = heff_take_reuse_n(v_x1_2462, 1ULL, 1);
    switch (heff_tag_of(v_v_2463)) {
    case TAG_VFun: {
      heff_take_n(v_v_2463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2462_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_2463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2462_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_2463, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2462_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_2463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2462_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_2463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2462_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      V v_a_2470 = heff_field(v_v_2463, 0);
      V v_ru_24v_2463_24VFloat32 = heff_take_reuse_n(v_v_2463, 1ULL, 1);
      V v_t_2471 = heff_tag_at(v_ru_24x1_2462_24Ok, TAG_VFloat32, 1, (V[]){heff_float32Sqrt(v_a_2470)});
      return heff_tag_at(v_ru_24v_2463_24VFloat32, TAG_Ok, 1, (V[]){v_t_2471});
    }
    case TAG_VStr: {
      heff_take_n(v_v_2463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2462_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_2463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2462_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_2463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2462_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2462_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_2463);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_2462);
  }
}
V g_heff_2einterp_2efloat32V_lam13(V self, V *args) {
  V v_d_2475 = args[0];
  V v_a_2476 = args[1];
  V v_x1_2477 = heff_tr(heff_apply(v_a_2476, 1, (V[]){v_d_2475}));
  switch (heff_tag_of(v_x1_2477)) {
  case TAG_Ok: {
    V v_v_2478 = heff_field(v_x1_2477, 0);
    V v_ru_24x1_2477_24Ok = heff_take_reuse_n(v_x1_2477, 1ULL, 1);
    switch (heff_tag_of(v_v_2478)) {
    case TAG_VFun: {
      heff_take_n(v_v_2478, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_2478, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_2478, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_2478, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_2484 = heff_field(v_v_2478, 0);
      V v_ru_24v_2478_24VFloat = heff_take_reuse_n(v_v_2478, 1ULL, 1);
      V v_t_2485 = heff_tag_at(v_ru_24x1_2477_24Ok, TAG_VFloat32, 1, (V[]){heff_float32FromFloat(v_a_2484)});
      return heff_tag_at(v_ru_24v_2478_24VFloat, TAG_Ok, 1, (V[]){v_t_2485});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2478, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_2478, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_2478, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_2478, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_2478);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_2477);
  }
}
V g_heff_2einterp_2efloat32V_lam14(V self, V *args) {
  V v_d_2490 = args[0];
  V v_a_2491 = args[1];
  V v_x1_2492 = heff_tr(heff_apply(v_a_2491, 1, (V[]){v_d_2490}));
  switch (heff_tag_of(v_x1_2492)) {
  case TAG_Ok: {
    V v_v_2493 = heff_field(v_x1_2492, 0);
    V v_ru_24x1_2492_24Ok = heff_take_reuse_n(v_x1_2492, 1ULL, 1);
    switch (heff_tag_of(v_v_2493)) {
    case TAG_VFun: {
      heff_take_n(v_v_2493, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2492_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_2493, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2492_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_2493, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2492_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_2493, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2492_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_2493, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2492_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      V v_a_24100 = heff_field(v_v_2493, 0);
      V v_ru_24v_2493_24VFloat32 = heff_take_reuse_n(v_v_2493, 1ULL, 1);
      V v_t_24101 = heff_tag_at(v_ru_24x1_2492_24Ok, TAG_VFloat, 1, (V[]){heff_float32ToFloat(v_a_24100)});
      return heff_tag_at(v_ru_24v_2493_24VFloat32, TAG_Ok, 1, (V[]){v_t_24101});
    }
    case TAG_VStr: {
      heff_take_n(v_v_2493, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2492_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_2493, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2492_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_2493, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2492_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2492_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_2493);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_2492);
  }
}
V g_heff_2einterp_2efixedPrimV_lam0(V self, V *args);
Clo g_heff_2einterp_2efixedPrimV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efixedPrimV_entry, 1, 0};

V g_heff_2einterp_2efixedPrimV(V v_p_240) {
top: ;
  V v_t_241 = heff_get(heff_dup(v_p_240), LBL_fixed);
  V v_t_242;
  switch (heff_tag_of(v_t_241)) {
  case TAG_I8: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_242 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    return ({ V b_0 = heff_get(v_p_240, LBL_op); V r_ = (g_heff_2einterp_2efloat32V(b_0)); heff_drop(b_0); r_; });
  }
  case TAG_False: {
    V v_t_243 = heff_get(heff_dup(v_p_240), LBL_op);
    V v_t_244;
    switch (heff_tag_of(v_t_243)) {
    case TAG_OpAdd: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpSub: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpMul: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpDiv: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpRem: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpEq: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpLt: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpLe: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpAnd: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpOr: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpXor: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpShl: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpShr: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpShow: {
      v_t_244 = MK_INT(1LL);
      break;
    }
    case TAG_OpFromInt: {
      v_t_244 = MK_INT(1LL);
      break;
    }
    case TAG_OpToInt: {
      v_t_244 = MK_INT(1LL);
      break;
    }
    case TAG_OpSqrt: {
      v_t_244 = MK_INT(1LL);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_244 = MK_INT(1LL);
      break;
    }
    case TAG_OpToFloat: {
      v_t_244 = MK_INT(1LL);
      break;
    }
    case TAG_OpFloor: {
      v_t_244 = MK_INT(1LL);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    if (heff_intEq_c(v_t_244, MK_INT(2LL))) {
      V v_t_246 = heff_tr(heff_apply(((V)&g_heff_2einterp_2efixedInt2_clo), 2, (V[]){heff_get(heff_dup(v_p_240), LBL_fixed), heff_get(v_p_240, LBL_op)}));
      HEFF_LAST return g_heff_2einterp_2eint2(v_t_246);
    } else {
      return heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efixedPrimV_lam0, 2, 1, (V[]){v_p_240})});
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2einterp_2efixedPrimV_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2efixedPrimV(a[0]);
}
V g_heff_2einterp_2efixedPrimV_lam0(V self, V *args) {
  V v_d_247 = args[0];
  V v_a_248 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = heff_tr(heff_apply(v_a_248, 1, (V[]){v_d_247}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Ok: {
    V v_v_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    switch (heff_tag_of(v_v_2410)) {
    case TAG_VFun: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop(v_p_240);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop(v_p_240);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_2410, 0ULL, 2);
      heff_drop(v_p_240);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_2415 = heff_field(v_v_2410, 0);
      heff_take_n(v_v_2410, 1ULL, 1);
      return ({ V b_0 = heff_get(heff_dup(v_p_240), LBL_fixed); V b_1 = heff_get(v_p_240, LBL_op); V a_2 = v_a_2415; V r_ = (g_heff_2einterp_2efixedInt1(b_0, b_1, a_2)); heff_drop(b_0); heff_drop(b_1); r_; });
    }
    case TAG_VFloat: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop(v_p_240);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop(v_p_240);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop(v_p_240);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop(v_p_240);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop(v_p_240);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_p_240);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_2410);
    }
  }
  case TAG_Abn: {
    heff_drop(v_p_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_p_240);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_249);
  }
}
V g_heff_2einterp_2eint2_24s1750067969x1390184394_lam1(V self, V *args);
V g_heff_2einterp_2eint2_24s1750067969x1390184394_lam0(V self, V *args); static Clo g_heff_2einterp_2eint2_24s1750067969x1390184394_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eint2_24s1750067969x1390184394_lam0, 2, 0};

static V g_heff_2einterp_2eint2_24s1750067969x1390184394_val;
static int g_heff_2einterp_2eint2_24s1750067969x1390184394_st;
static V g_heff_2einterp_2eint2_24s1750067969x1390184394_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eint2_24s1750067969x1390184394_lam0_clo)});
}
V g_heff_2einterp_2eint2_24s1750067969x1390184394_get(void) {
  if (g_heff_2einterp_2eint2_24s1750067969x1390184394_st == 2) return g_heff_2einterp_2eint2_24s1750067969x1390184394_val;
  if (g_heff_2einterp_2eint2_24s1750067969x1390184394_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2eint2_24s1750067969x1390184394_st = 1;
  g_heff_2einterp_2eint2_24s1750067969x1390184394_val = heff_tr(g_heff_2einterp_2eint2_24s1750067969x1390184394_init());
  g_heff_2einterp_2eint2_24s1750067969x1390184394_st = 2;
  return g_heff_2einterp_2eint2_24s1750067969x1390184394_val;
}
V g_heff_2einterp_2eint2_24s1750067969x1390184394_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VInt, 1, (V[]){heff_intAdd(v_a_2412, v_b_2417)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2418});
        }
        case TAG_VFloat: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2eint2_24s1750067969x1390184394_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eint2_24s1750067969x1390184394_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2eint2_24s1787339426x818188969_lam1(V self, V *args);
V g_heff_2einterp_2eint2_24s1787339426x818188969_lam0(V self, V *args); static Clo g_heff_2einterp_2eint2_24s1787339426x818188969_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eint2_24s1787339426x818188969_lam0, 2, 0};

static V g_heff_2einterp_2eint2_24s1787339426x818188969_val;
static int g_heff_2einterp_2eint2_24s1787339426x818188969_st;
static V g_heff_2einterp_2eint2_24s1787339426x818188969_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eint2_24s1787339426x818188969_lam0_clo)});
}
V g_heff_2einterp_2eint2_24s1787339426x818188969_get(void) {
  if (g_heff_2einterp_2eint2_24s1787339426x818188969_st == 2) return g_heff_2einterp_2eint2_24s1787339426x818188969_val;
  if (g_heff_2einterp_2eint2_24s1787339426x818188969_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2eint2_24s1787339426x818188969_st = 1;
  g_heff_2einterp_2eint2_24s1787339426x818188969_val = heff_tr(g_heff_2einterp_2eint2_24s1787339426x818188969_init());
  g_heff_2einterp_2eint2_24s1787339426x818188969_st = 2;
  return g_heff_2einterp_2eint2_24s1787339426x818188969_val;
}
V g_heff_2einterp_2eint2_24s1787339426x818188969_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VInt, 1, (V[]){heff_intSub(v_a_2412, v_b_2417)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2418});
        }
        case TAG_VFloat: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2eint2_24s1787339426x818188969_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eint2_24s1787339426x818188969_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2eint2_24s1207713422x150104894_lam1(V self, V *args);
V g_heff_2einterp_2eint2_24s1207713422x150104894_lam0(V self, V *args); static Clo g_heff_2einterp_2eint2_24s1207713422x150104894_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eint2_24s1207713422x150104894_lam0, 2, 0};

static V g_heff_2einterp_2eint2_24s1207713422x150104894_val;
static int g_heff_2einterp_2eint2_24s1207713422x150104894_st;
static V g_heff_2einterp_2eint2_24s1207713422x150104894_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eint2_24s1207713422x150104894_lam0_clo)});
}
V g_heff_2einterp_2eint2_24s1207713422x150104894_get(void) {
  if (g_heff_2einterp_2eint2_24s1207713422x150104894_st == 2) return g_heff_2einterp_2eint2_24s1207713422x150104894_val;
  if (g_heff_2einterp_2eint2_24s1207713422x150104894_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2eint2_24s1207713422x150104894_st = 1;
  g_heff_2einterp_2eint2_24s1207713422x150104894_val = heff_tr(g_heff_2einterp_2eint2_24s1207713422x150104894_init());
  g_heff_2einterp_2eint2_24s1207713422x150104894_st = 2;
  return g_heff_2einterp_2eint2_24s1207713422x150104894_val;
}
V g_heff_2einterp_2eint2_24s1207713422x150104894_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VInt, 1, (V[]){heff_intMul(v_a_2412, v_b_2417)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2418});
        }
        case TAG_VFloat: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2eint2_24s1207713422x150104894_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eint2_24s1207713422x150104894_lam1, 2, 1, (V[]){v_a_241})})});
}
Clo g_heff_2einterp_2eintBits_24s1759121966x190002670_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eintBits_24s1759121966x190002670_entry, 2, 0};

V g_heff_2einterp_2eintBits_24s1759121966x190002670(V v_a_240, V v_b_241) {
top: ;
  V v_t_246;
  if (heff_intEq_c(heff_dup(v_a_240), MK_INT(0LL))) {
    if (heff_intEq_c(heff_dup(v_b_241), MK_INT(0LL))) {
      v_t_246 = NTAG(TAG_True);
    } else {
      v_t_246 = heff_intEq(heff_dup(v_b_241), MK_INT(-1LL));
    }
  } else {
    if (heff_intEq_c(heff_dup(v_a_240), MK_INT(-1LL))) {
      if (heff_intEq_c(heff_dup(v_b_241), MK_INT(0LL))) {
        v_t_246 = NTAG(TAG_True);
      } else {
        v_t_246 = heff_intEq(heff_dup(v_b_241), MK_INT(-1LL));
      }
    } else {
      v_t_246 = NTAG(TAG_False);
    }
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    V v_a_247 = heff_intMod(v_a_240, MK_INT(2LL));
    V v_a_248 = heff_intMod(v_b_241, MK_INT(2LL));
    return heff_intSub(MK_INT(0LL), heff_intMul(v_a_247, v_a_248));
  }
  case TAG_False: {
    V v_a_249 = heff_intMod(heff_dup(v_a_240), MK_INT(2LL));
    V v_a_2410 = heff_intMod(heff_dup(v_b_241), MK_INT(2LL));
    V v_t_2411 = heff_intDiv(v_a_240, MK_INT(2LL));
    V v_t_2412 = heff_intDiv(v_b_241, MK_INT(2LL));
    V v_t_2413 = (g_heff_2einterp_2eintBits_24s1759121966x190002670(v_t_2411, v_t_2412));
    return heff_intAdd(heff_intMul(v_a_249, v_a_2410), heff_intMul(MK_INT(2LL), v_t_2413));
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2einterp_2eintBits_24s1759121966x190002670_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eintBits_24s1759121966x190002670(a[0], a[1]);
}
V g_heff_2einterp_2eint2_24s1323720283x607104012_lam1(V self, V *args);
V g_heff_2einterp_2eint2_24s1323720283x607104012_lam0(V self, V *args); static Clo g_heff_2einterp_2eint2_24s1323720283x607104012_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eint2_24s1323720283x607104012_lam0, 2, 0};

static V g_heff_2einterp_2eint2_24s1323720283x607104012_val;
static int g_heff_2einterp_2eint2_24s1323720283x607104012_st;
static V g_heff_2einterp_2eint2_24s1323720283x607104012_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eint2_24s1323720283x607104012_lam0_clo)});
}
V g_heff_2einterp_2eint2_24s1323720283x607104012_get(void) {
  if (g_heff_2einterp_2eint2_24s1323720283x607104012_st == 2) return g_heff_2einterp_2eint2_24s1323720283x607104012_val;
  if (g_heff_2einterp_2eint2_24s1323720283x607104012_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2eint2_24s1323720283x607104012_st = 1;
  g_heff_2einterp_2eint2_24s1323720283x607104012_val = heff_tr(g_heff_2einterp_2eint2_24s1323720283x607104012_init());
  g_heff_2einterp_2eint2_24s1323720283x607104012_st = 2;
  return g_heff_2einterp_2eint2_24s1323720283x607104012_val;
}
V g_heff_2einterp_2eint2_24s1323720283x607104012_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VInt, 1, (V[]){(g_heff_2einterp_2eintBits_24s1759121966x190002670(v_a_2412, v_b_2417))});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2418});
        }
        case TAG_VFloat: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2eint2_24s1323720283x607104012_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eint2_24s1323720283x607104012_lam1, 2, 1, (V[]){v_a_241})})});
}
Clo g_heff_2einterp_2eintBits_24s522074386x924975132_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eintBits_24s522074386x924975132_entry, 5, 0};

V g_heff_2einterp_2eintBits_24s522074386x924975132(V v_lit_240, V v_lit_241, V v_lit_242, V v_a_243, V v_b_244) {
top: ;
  V v_t_249;
  if (heff_intEq_c(heff_dup(v_a_243), MK_INT(0LL))) {
    if (heff_intEq_c(heff_dup(v_b_244), MK_INT(0LL))) {
      v_t_249 = NTAG(TAG_True);
    } else {
      v_t_249 = heff_intEq(heff_dup(v_b_244), MK_INT(-1LL));
    }
  } else {
    if (heff_intEq_c(heff_dup(v_a_243), MK_INT(-1LL))) {
      if (heff_intEq_c(heff_dup(v_b_244), MK_INT(0LL))) {
        v_t_249 = NTAG(TAG_True);
      } else {
        v_t_249 = heff_intEq(heff_dup(v_b_244), MK_INT(-1LL));
      }
    } else {
      v_t_249 = NTAG(TAG_False);
    }
  }
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    V v_a_2410 = heff_intMod(v_a_243, MK_INT(2LL));
    V v_a_2411 = heff_intMod(v_b_244, MK_INT(2LL));
    V v_t_2413;
    if (heff_intLt_c(v_lit_240, heff_intAdd(v_a_2410, v_a_2411))) {
      heff_drop(v_lit_242);
      v_t_2413 = v_lit_241;
    } else {
      heff_drop(v_lit_241);
      v_t_2413 = v_lit_242;
    }
    return heff_intSub(MK_INT(0LL), v_t_2413);
  }
  case TAG_False: {
    V v_a_2414 = heff_intMod(heff_dup(v_a_243), MK_INT(2LL));
    V v_a_2415 = heff_intMod(heff_dup(v_b_244), MK_INT(2LL));
    V v_t_2417;
    if (heff_intLt_c(heff_dup(v_lit_240), heff_intAdd(v_a_2414, v_a_2415))) {
      v_t_2417 = heff_dup(v_lit_241);
    } else {
      v_t_2417 = heff_dup(v_lit_242);
    }
    V v_t_2418 = heff_intDiv(v_a_243, MK_INT(2LL));
    V v_t_2419 = heff_intDiv(v_b_244, MK_INT(2LL));
    V v_t_2420 = (g_heff_2einterp_2eintBits_24s522074386x924975132(v_lit_240, v_lit_241, v_lit_242, v_t_2418, v_t_2419));
    return heff_intAdd(v_t_2417, heff_intMul(MK_INT(2LL), v_t_2420));
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2einterp_2eintBits_24s522074386x924975132_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eintBits_24s522074386x924975132(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2einterp_2eintBits_24s715749050x314660754_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eintBits_24s715749050x314660754_entry, 3, 0};

V g_heff_2einterp_2eintBits_24s715749050x314660754(V v_lit_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_247;
  if (heff_intEq_c(heff_dup(v_a_241), MK_INT(0LL))) {
    if (heff_intEq_c(heff_dup(v_b_242), MK_INT(0LL))) {
      v_t_247 = NTAG(TAG_True);
    } else {
      v_t_247 = heff_intEq(heff_dup(v_b_242), MK_INT(-1LL));
    }
  } else {
    if (heff_intEq_c(heff_dup(v_a_241), MK_INT(-1LL))) {
      if (heff_intEq_c(heff_dup(v_b_242), MK_INT(0LL))) {
        v_t_247 = NTAG(TAG_True);
      } else {
        v_t_247 = heff_intEq(heff_dup(v_b_242), MK_INT(-1LL));
      }
    } else {
      v_t_247 = NTAG(TAG_False);
    }
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    V v_a_248 = heff_intMod(v_a_241, MK_INT(2LL));
    V v_a_249 = heff_intMod(v_b_242, MK_INT(2LL));
    V v_t_2410 = heff_intMod(heff_intAdd(v_a_248, v_a_249), v_lit_240);
    return heff_intSub(MK_INT(0LL), v_t_2410);
  }
  case TAG_False: {
    V v_a_2411 = heff_intMod(heff_dup(v_a_241), MK_INT(2LL));
    V v_a_2412 = heff_intMod(heff_dup(v_b_242), MK_INT(2LL));
    V v_t_2413 = heff_intMod(heff_intAdd(v_a_2411, v_a_2412), heff_dup(v_lit_240));
    V v_t_2414 = heff_intDiv(v_a_241, MK_INT(2LL));
    V v_t_2415 = heff_intDiv(v_b_242, MK_INT(2LL));
    V v_t_2416 = (g_heff_2einterp_2eintBits_24s715749050x314660754(v_lit_240, v_t_2414, v_t_2415));
    return heff_intAdd(v_t_2413, heff_intMul(MK_INT(2LL), v_t_2416));
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2einterp_2eintBits_24s715749050x314660754_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eintBits_24s715749050x314660754(a[0], a[1], a[2]);
}
V g_heff_2einterp_2efloat2_24s1965813471x487337709_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_24s1965813471x487337709_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat2_24s1965813471x487337709_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_24s1965813471x487337709_lam0, 2, 0};

static V g_heff_2einterp_2efloat2_24s1965813471x487337709_val;
static int g_heff_2einterp_2efloat2_24s1965813471x487337709_st;
static V g_heff_2einterp_2efloat2_24s1965813471x487337709_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat2_24s1965813471x487337709_lam0_clo)});
}
V g_heff_2einterp_2efloat2_24s1965813471x487337709_get(void) {
  if (g_heff_2einterp_2efloat2_24s1965813471x487337709_st == 2) return g_heff_2einterp_2efloat2_24s1965813471x487337709_val;
  if (g_heff_2einterp_2efloat2_24s1965813471x487337709_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2efloat2_24s1965813471x487337709_st = 1;
  g_heff_2einterp_2efloat2_24s1965813471x487337709_val = heff_tr(g_heff_2einterp_2efloat2_24s1965813471x487337709_init());
  g_heff_2einterp_2efloat2_24s1965813471x487337709_st = 2;
  return g_heff_2einterp_2efloat2_24s1965813471x487337709_val;
}
V g_heff_2einterp_2efloat2_24s1965813471x487337709_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2420 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VFloat, 1, (V[]){heff_floatAdd(v_a_2413, v_b_2419)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2efloat2_24s1965813471x487337709_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_24s1965813471x487337709_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2efloat2_24s2003084928x2062825913_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_24s2003084928x2062825913_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat2_24s2003084928x2062825913_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_24s2003084928x2062825913_lam0, 2, 0};

static V g_heff_2einterp_2efloat2_24s2003084928x2062825913_val;
static int g_heff_2einterp_2efloat2_24s2003084928x2062825913_st;
static V g_heff_2einterp_2efloat2_24s2003084928x2062825913_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat2_24s2003084928x2062825913_lam0_clo)});
}
V g_heff_2einterp_2efloat2_24s2003084928x2062825913_get(void) {
  if (g_heff_2einterp_2efloat2_24s2003084928x2062825913_st == 2) return g_heff_2einterp_2efloat2_24s2003084928x2062825913_val;
  if (g_heff_2einterp_2efloat2_24s2003084928x2062825913_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2efloat2_24s2003084928x2062825913_st = 1;
  g_heff_2einterp_2efloat2_24s2003084928x2062825913_val = heff_tr(g_heff_2einterp_2efloat2_24s2003084928x2062825913_init());
  g_heff_2einterp_2efloat2_24s2003084928x2062825913_st = 2;
  return g_heff_2einterp_2efloat2_24s2003084928x2062825913_val;
}
V g_heff_2einterp_2efloat2_24s2003084928x2062825913_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2420 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VFloat, 1, (V[]){heff_floatSub(v_a_2413, v_b_2419)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2efloat2_24s2003084928x2062825913_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_24s2003084928x2062825913_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2efloat2_24s1423458924x1394741838_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_24s1423458924x1394741838_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat2_24s1423458924x1394741838_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_24s1423458924x1394741838_lam0, 2, 0};

static V g_heff_2einterp_2efloat2_24s1423458924x1394741838_val;
static int g_heff_2einterp_2efloat2_24s1423458924x1394741838_st;
static V g_heff_2einterp_2efloat2_24s1423458924x1394741838_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat2_24s1423458924x1394741838_lam0_clo)});
}
V g_heff_2einterp_2efloat2_24s1423458924x1394741838_get(void) {
  if (g_heff_2einterp_2efloat2_24s1423458924x1394741838_st == 2) return g_heff_2einterp_2efloat2_24s1423458924x1394741838_val;
  if (g_heff_2einterp_2efloat2_24s1423458924x1394741838_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2efloat2_24s1423458924x1394741838_st = 1;
  g_heff_2einterp_2efloat2_24s1423458924x1394741838_val = heff_tr(g_heff_2einterp_2efloat2_24s1423458924x1394741838_init());
  g_heff_2einterp_2efloat2_24s1423458924x1394741838_st = 2;
  return g_heff_2einterp_2efloat2_24s1423458924x1394741838_val;
}
V g_heff_2einterp_2efloat2_24s1423458924x1394741838_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2420 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VFloat, 1, (V[]){heff_floatMul(v_a_2413, v_b_2419)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2efloat2_24s1423458924x1394741838_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_24s1423458924x1394741838_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2efloat2_24s205358756x116382871_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_24s205358756x116382871_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat2_24s205358756x116382871_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_24s205358756x116382871_lam0, 2, 0};

static V g_heff_2einterp_2efloat2_24s205358756x116382871_val;
static int g_heff_2einterp_2efloat2_24s205358756x116382871_st;
static V g_heff_2einterp_2efloat2_24s205358756x116382871_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat2_24s205358756x116382871_lam0_clo)});
}
V g_heff_2einterp_2efloat2_24s205358756x116382871_get(void) {
  if (g_heff_2einterp_2efloat2_24s205358756x116382871_st == 2) return g_heff_2einterp_2efloat2_24s205358756x116382871_val;
  if (g_heff_2einterp_2efloat2_24s205358756x116382871_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2efloat2_24s205358756x116382871_st = 1;
  g_heff_2einterp_2efloat2_24s205358756x116382871_val = heff_tr(g_heff_2einterp_2efloat2_24s205358756x116382871_init());
  g_heff_2einterp_2efloat2_24s205358756x116382871_st = 2;
  return g_heff_2einterp_2efloat2_24s205358756x116382871_val;
}
V g_heff_2einterp_2efloat2_24s205358756x116382871_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2420 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VFloat, 1, (V[]){heff_floatDiv(v_a_2413, v_b_2419)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2efloat2_24s205358756x116382871_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_24s205358756x116382871_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2efloat2_24s1759709581x228229611_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_24s1759709581x228229611_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat2_24s1759709581x228229611_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_24s1759709581x228229611_lam0, 2, 0};

static V g_heff_2einterp_2efloat2_24s1759709581x228229611_val;
static int g_heff_2einterp_2efloat2_24s1759709581x228229611_st;
static V g_heff_2einterp_2efloat2_24s1759709581x228229611_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat2_24s1759709581x228229611_lam0_clo)});
}
V g_heff_2einterp_2efloat2_24s1759709581x228229611_get(void) {
  if (g_heff_2einterp_2efloat2_24s1759709581x228229611_st == 2) return g_heff_2einterp_2efloat2_24s1759709581x228229611_val;
  if (g_heff_2einterp_2efloat2_24s1759709581x228229611_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2efloat2_24s1759709581x228229611_st = 1;
  g_heff_2einterp_2efloat2_24s1759709581x228229611_val = heff_tr(g_heff_2einterp_2efloat2_24s1759709581x228229611_init());
  g_heff_2einterp_2efloat2_24s1759709581x228229611_st = 2;
  return g_heff_2einterp_2efloat2_24s1759709581x228229611_val;
}
V g_heff_2einterp_2efloat2_24s1759709581x228229611_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2420 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VFloat, 1, (V[]){heff_floatAtan2(v_a_2413, v_b_2419)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2efloat2_24s1759709581x228229611_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_24s1759709581x228229611_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2efloat2_24s615196179x236480627_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_24s615196179x236480627_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat2_24s615196179x236480627_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_24s615196179x236480627_lam0, 2, 0};

static V g_heff_2einterp_2efloat2_24s615196179x236480627_val;
static int g_heff_2einterp_2efloat2_24s615196179x236480627_st;
static V g_heff_2einterp_2efloat2_24s615196179x236480627_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat2_24s615196179x236480627_lam0_clo)});
}
V g_heff_2einterp_2efloat2_24s615196179x236480627_get(void) {
  if (g_heff_2einterp_2efloat2_24s615196179x236480627_st == 2) return g_heff_2einterp_2efloat2_24s615196179x236480627_val;
  if (g_heff_2einterp_2efloat2_24s615196179x236480627_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2efloat2_24s615196179x236480627_st = 1;
  g_heff_2einterp_2efloat2_24s615196179x236480627_val = heff_tr(g_heff_2einterp_2efloat2_24s615196179x236480627_init());
  g_heff_2einterp_2efloat2_24s615196179x236480627_st = 2;
  return g_heff_2einterp_2efloat2_24s615196179x236480627_val;
}
V g_heff_2einterp_2efloat2_24s615196179x236480627_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2420 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VFloat, 1, (V[]){heff_floatPow(v_a_2413, v_b_2419)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2efloat2_24s615196179x236480627_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_24s615196179x236480627_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2estr2_24s1802929932x1594371566_lam1(V self, V *args);
V g_heff_2einterp_2estr2_24s1802929932x1594371566_lam0(V self, V *args); static Clo g_heff_2einterp_2estr2_24s1802929932x1594371566_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2estr2_24s1802929932x1594371566_lam0, 2, 0};

static V g_heff_2einterp_2estr2_24s1802929932x1594371566_val;
static int g_heff_2einterp_2estr2_24s1802929932x1594371566_st;
static V g_heff_2einterp_2estr2_24s1802929932x1594371566_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2estr2_24s1802929932x1594371566_lam0_clo)});
}
V g_heff_2einterp_2estr2_24s1802929932x1594371566_get(void) {
  if (g_heff_2einterp_2estr2_24s1802929932x1594371566_st == 2) return g_heff_2einterp_2estr2_24s1802929932x1594371566_val;
  if (g_heff_2einterp_2estr2_24s1802929932x1594371566_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2estr2_24s1802929932x1594371566_st = 1;
  g_heff_2einterp_2estr2_24s1802929932x1594371566_val = heff_tr(g_heff_2einterp_2estr2_24s1802929932x1594371566_init());
  g_heff_2einterp_2estr2_24s1802929932x1594371566_st = 2;
  return g_heff_2einterp_2estr2_24s1802929932x1594371566_val;
}
V g_heff_2einterp_2estr2_24s1802929932x1594371566_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VStr: {
        V v_a_2415 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VFloat: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VStr: {
          V v_b_2423 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2424 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VStr, 1, (V[]){heff_strAppend(v_a_2415, v_b_2423)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2424});
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2estr2_24s1802929932x1594371566_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2estr2_24s1802929932x1594371566_lam1, 2, 1, (V[]){v_a_241})})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 65, 100, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 83, 117, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 77, 117, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str3 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 68, 105, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 77, 111, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eprim_str6 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str8 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eprim_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str10 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str11 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eprim_str12 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str13 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eprim_str14 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 110, 116, 83, 104, 111, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str15 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 65, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str16 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 79, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str17 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 88, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str18 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 83, 104, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str19 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 83, 104, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str20 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 65, 100, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str21 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 83, 117, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str22 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 77, 117, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str23 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 68, 105, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eprim_str24 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eprim_str25 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str26 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eprim_str27 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eprim_str28 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str29 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eprim_str30 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eprim_str31 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str32 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2einterp_2eprim_str33 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 83, 104, 111, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2einterp_2eprim_str34 = {{0x80000000u, K_STR, 0}, 12, 12, {102, 108, 111, 97, 116, 70, 114, 111, 109, 73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2einterp_2eprim_str35 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 83, 113, 114, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2einterp_2eprim_str36 = {{0x80000000u, K_STR, 0}, 10, 10, {102, 108, 111, 97, 116, 70, 108, 111, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str37 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 83, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str38 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 67, 111, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str39 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 84, 97, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2einterp_2eprim_str40 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 65, 115, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2einterp_2eprim_str41 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 65, 99, 111, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2einterp_2eprim_str42 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 65, 116, 97, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2einterp_2eprim_str43 = {{0x80000000u, K_STR, 0}, 10, 10, {102, 108, 111, 97, 116, 65, 116, 97, 110, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str44 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 69, 120, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str45 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 76, 111, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str46 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 80, 111, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2einterp_2eprim_str47 = {{0x80000000u, K_STR, 0}, 11, 11, {97, 114, 114, 97, 121, 76, 101, 110, 103, 116, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2einterp_2eprim_str48 = {{0x80000000u, K_STR, 0}, 10, 10, {97, 114, 114, 97, 121, 73, 110, 100, 101, 120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str49 = {{0x80000000u, K_STR, 0}, 8, 8, {97, 114, 114, 97, 121, 83, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2einterp_2eprim_str50 = {{0x80000000u, K_STR, 0}, 13, 13, {97, 114, 114, 97, 121, 71, 101, 110, 101, 114, 97, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2einterp_2eprim_str51 = {{0x80000000u, K_STR, 0}, 13, 13, {97, 114, 114, 97, 121, 70, 114, 111, 109, 76, 105, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2einterp_2eprim_str52 = {{0x80000000u, K_STR, 0}, 11, 11, {97, 114, 114, 97, 121, 84, 111, 76, 105, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2einterp_2eprim_str53 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 65, 112, 112, 101, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2einterp_2eprim_str54 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 76, 101, 110, 103, 116, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str55 = {{0x80000000u, K_STR, 0}, 8, 8, {115, 116, 114, 83, 108, 105, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str56 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 114, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eprim_str57 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str58 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str59 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 114, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eprim_str60 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str61 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2einterp_2eprim_str62 = {{0x80000000u, K_STR, 0}, 11, 11, {115, 116, 114, 67, 104, 97, 114, 67, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2einterp_2eprim_str63 = {{0x80000000u, K_STR, 0}, 15, 15, {115, 116, 114, 70, 114, 111, 109, 67, 104, 97, 114, 67, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str64 = {{0x80000000u, K_STR, 0}, 6, 6, {114, 117, 110, 101, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eprim_str65 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str66 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str67 = {{0x80000000u, K_STR, 0}, 6, 6, {114, 117, 110, 101, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eprim_str68 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str69 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str70 = {{0x80000000u, K_STR, 0}, 6, 6, {114, 117, 110, 101, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eprim_str71 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str72 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2einterp_2eprim_str73 = {{0x80000000u, K_STR, 0}, 9, 9, {114, 117, 110, 101, 84, 111, 73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2einterp_2eprim_str74 = {{0x80000000u, K_STR, 0}, 11, 11, {114, 117, 110, 101, 70, 114, 111, 109, 73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str75 = {{0x80000000u, K_STR, 0}, 8, 8, {115, 116, 114, 82, 117, 110, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2einterp_2eprim_str76 = {{0x80000000u, K_STR, 0}, 10, 10, {115, 116, 114, 79, 102, 82, 117, 110, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eprim_str77 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eprim_str78 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2einterp_2eprim_lam0(V self, V *args); static Clo g_heff_2einterp_2eprim_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam0, 2, 0};
V g_heff_2einterp_2eprim_lam1(V self, V *args); static Clo g_heff_2einterp_2eprim_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam1, 2, 0};
V g_heff_2einterp_2eprim_lam2(V self, V *args); static Clo g_heff_2einterp_2eprim_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam2, 2, 0};
V g_heff_2einterp_2eprim_lam3(V self, V *args); static Clo g_heff_2einterp_2eprim_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam3, 2, 0};
V g_heff_2einterp_2eprim_lam4(V self, V *args); static Clo g_heff_2einterp_2eprim_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam4, 2, 0};
V g_heff_2einterp_2eprim_lam5(V self, V *args); static Clo g_heff_2einterp_2eprim_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam5, 2, 0};
V g_heff_2einterp_2eprim_lam6(V self, V *args); static Clo g_heff_2einterp_2eprim_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam6, 2, 0};
V g_heff_2einterp_2eprim_lam7(V self, V *args); static Clo g_heff_2einterp_2eprim_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam7, 2, 0};
V g_heff_2einterp_2eprim_lam8(V self, V *args); static Clo g_heff_2einterp_2eprim_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam8, 2, 0};
V g_heff_2einterp_2eprim_lam9(V self, V *args); static Clo g_heff_2einterp_2eprim_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam9, 2, 0};
V g_heff_2einterp_2eprim_lam10(V self, V *args); static Clo g_heff_2einterp_2eprim_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam10, 2, 0};
V g_heff_2einterp_2eprim_lam11(V self, V *args); static Clo g_heff_2einterp_2eprim_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam11, 2, 0};
V g_heff_2einterp_2eprim_lam12(V self, V *args); static Clo g_heff_2einterp_2eprim_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam12, 2, 0};
V g_heff_2einterp_2eprim_lam13(V self, V *args); static Clo g_heff_2einterp_2eprim_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam13, 2, 0};
V g_heff_2einterp_2eprim_lam14(V self, V *args); static Clo g_heff_2einterp_2eprim_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam14, 2, 0};
V g_heff_2einterp_2eprim_lam15(V self, V *args); static Clo g_heff_2einterp_2eprim_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam15, 2, 0};
V g_heff_2einterp_2eprim_lam16(V self, V *args); static Clo g_heff_2einterp_2eprim_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam16, 2, 0};
V g_heff_2einterp_2eprim_lam17(V self, V *args); static Clo g_heff_2einterp_2eprim_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam17, 2, 0};
V g_heff_2einterp_2eprim_lam18(V self, V *args); static Clo g_heff_2einterp_2eprim_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam18, 2, 0};
V g_heff_2einterp_2eprim_lam19(V self, V *args); static Clo g_heff_2einterp_2eprim_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam19, 2, 0};
V g_heff_2einterp_2eprim_lam20(V self, V *args); static Clo g_heff_2einterp_2eprim_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam20, 2, 0};
V g_heff_2einterp_2eprim_lam21(V self, V *args); static Clo g_heff_2einterp_2eprim_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam21, 2, 0};
V g_heff_2einterp_2eprim_lam22(V self, V *args); static Clo g_heff_2einterp_2eprim_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam22, 2, 0};
V g_heff_2einterp_2eprim_lam23(V self, V *args); static Clo g_heff_2einterp_2eprim_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam23, 2, 0};
V g_heff_2einterp_2eprim_lam24(V self, V *args); static Clo g_heff_2einterp_2eprim_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam24, 2, 0};
V g_heff_2einterp_2eprim_lam26(V self, V *args); static Clo g_heff_2einterp_2eprim_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam26, 2, 0};
V g_heff_2einterp_2eprim_lam25(V self, V *args); static Clo g_heff_2einterp_2eprim_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam25, 2, 0};
V g_heff_2einterp_2eprim_lam29(V self, V *args);
V g_heff_2einterp_2eprim_lam28(V self, V *args); static Clo g_heff_2einterp_2eprim_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam28, 2, 0};
V g_heff_2einterp_2eprim_lam27(V self, V *args); static Clo g_heff_2einterp_2eprim_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam27, 2, 0};
V g_heff_2einterp_2eprim_lam33(V self, V *args);
V g_heff_2einterp_2eprim_lam32(V self, V *args);
V g_heff_2einterp_2eprim_lam31(V self, V *args); static Clo g_heff_2einterp_2eprim_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam31, 2, 0};
V g_heff_2einterp_2eprim_lam30(V self, V *args); static Clo g_heff_2einterp_2eprim_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam30, 2, 0};
V g_heff_2einterp_2eprim_lam37(V self, V *args); static Clo g_heff_2einterp_2eprim_lam37_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam37, 1, 0};
V g_heff_2einterp_2eprim_lam36(V self, V *args);
V g_heff_2einterp_2eprim_lam35(V self, V *args); static Clo g_heff_2einterp_2eprim_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam35, 2, 0};
V g_heff_2einterp_2eprim_lam34(V self, V *args); static Clo g_heff_2einterp_2eprim_lam34_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam34, 2, 0};
V g_heff_2einterp_2eprim_lam39(V self, V *args); static Clo g_heff_2einterp_2eprim_lam39_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam39, 2, 0};
V g_heff_2einterp_2eprim_lam38(V self, V *args); static Clo g_heff_2einterp_2eprim_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam38, 2, 0};
V g_heff_2einterp_2eprim_lam41(V self, V *args); static Clo g_heff_2einterp_2eprim_lam41_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam41, 2, 0};
V g_heff_2einterp_2eprim_lam40(V self, V *args); static Clo g_heff_2einterp_2eprim_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam40, 2, 0};
V g_heff_2einterp_2eprim_lam42(V self, V *args); static Clo g_heff_2einterp_2eprim_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam42, 2, 0};
V g_heff_2einterp_2eprim_lam45(V self, V *args);
V g_heff_2einterp_2eprim_lam44(V self, V *args);
V g_heff_2einterp_2eprim_lam43(V self, V *args); static Clo g_heff_2einterp_2eprim_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam43, 2, 0};
V g_heff_2einterp_2eprim_lam46(V self, V *args); static Clo g_heff_2einterp_2eprim_lam46_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam46, 2, 0};
V g_heff_2einterp_2eprim_lam47(V self, V *args); static Clo g_heff_2einterp_2eprim_lam47_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam47, 2, 0};
V g_heff_2einterp_2eprim_lam49(V self, V *args);
V g_heff_2einterp_2eprim_lam48(V self, V *args); static Clo g_heff_2einterp_2eprim_lam48_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam48, 2, 0};
V g_heff_2einterp_2eprim_lam50(V self, V *args); static Clo g_heff_2einterp_2eprim_lam50_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam50, 2, 0};
V g_heff_2einterp_2eprim_lam51(V self, V *args); static Clo g_heff_2einterp_2eprim_lam51_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam51, 2, 0};
V g_heff_2einterp_2eprim_lam52(V self, V *args); static Clo g_heff_2einterp_2eprim_lam52_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam52, 2, 0};
V g_heff_2einterp_2eprim_lam53(V self, V *args); static Clo g_heff_2einterp_2eprim_lam53_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam53, 2, 0};
V g_heff_2einterp_2eprim_lam54(V self, V *args); static Clo g_heff_2einterp_2eprim_lam54_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam54, 2, 0};
V g_heff_2einterp_2eprim_lam55(V self, V *args); static Clo g_heff_2einterp_2eprim_lam55_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam55, 2, 0};
V g_heff_2einterp_2eprim_lam56(V self, V *args); static Clo g_heff_2einterp_2eprim_lam56_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam56, 2, 0};
V g_heff_2einterp_2eprim_lam57(V self, V *args); static Clo g_heff_2einterp_2eprim_lam57_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam57, 2, 0};
Clo g_heff_2einterp_2eprim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_entry, 1, 0};

V g_heff_2einterp_2eprim(V v_p_240) {
top: ;
  if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str0))) {
    heff_drop(v_p_240);
    return heff_dup(g_heff_2einterp_2eint2_24s1750067969x1390184394_get());
  } else {
    if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str1))) {
      heff_drop(v_p_240);
      return heff_dup(g_heff_2einterp_2eint2_24s1787339426x818188969_get());
    } else {
      if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str2))) {
        heff_drop(v_p_240);
        return heff_dup(g_heff_2einterp_2eint2_24s1207713422x150104894_get());
      } else {
        if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str3))) {
          heff_drop(v_p_240);
          HEFF_LAST return g_heff_2einterp_2eint2(((V)&g_heff_2einterp_2eprim_lam0_clo));
        } else {
          if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str4))) {
            heff_drop(v_p_240);
            HEFF_LAST return g_heff_2einterp_2eint2(((V)&g_heff_2einterp_2eprim_lam1_clo));
          } else {
            if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str5))) {
              heff_drop(v_p_240);
              HEFF_LAST return g_heff_2einterp_2eint2(((V)&g_heff_2einterp_2eprim_lam2_clo));
            } else {
              if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str8))) {
                heff_drop(v_p_240);
                HEFF_LAST return g_heff_2einterp_2eint2(((V)&g_heff_2einterp_2eprim_lam3_clo));
              } else {
                if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str11))) {
                  heff_drop(v_p_240);
                  HEFF_LAST return g_heff_2einterp_2eint2(((V)&g_heff_2einterp_2eprim_lam4_clo));
                } else {
                  if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str14))) {
                    heff_drop(v_p_240);
                    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam5_clo)});
                  } else {
                    if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str15))) {
                      heff_drop(v_p_240);
                      return heff_dup(g_heff_2einterp_2eint2_24s1323720283x607104012_get());
                    } else {
                      if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str16))) {
                        heff_drop(v_p_240);
                        HEFF_LAST return g_heff_2einterp_2eint2(((V)&g_heff_2einterp_2eprim_lam6_clo));
                      } else {
                        if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str17))) {
                          heff_drop(v_p_240);
                          HEFF_LAST return g_heff_2einterp_2eint2(((V)&g_heff_2einterp_2eprim_lam7_clo));
                        } else {
                          if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str18))) {
                            heff_drop(v_p_240);
                            HEFF_LAST return g_heff_2einterp_2eint2(((V)&g_heff_2einterp_2eprim_lam8_clo));
                          } else {
                            if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str19))) {
                              heff_drop(v_p_240);
                              HEFF_LAST return g_heff_2einterp_2eint2(((V)&g_heff_2einterp_2eprim_lam9_clo));
                            } else {
                              if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str20))) {
                                heff_drop(v_p_240);
                                return heff_dup(g_heff_2einterp_2efloat2_24s1965813471x487337709_get());
                              } else {
                                if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str21))) {
                                  heff_drop(v_p_240);
                                  return heff_dup(g_heff_2einterp_2efloat2_24s2003084928x2062825913_get());
                                } else {
                                  if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str22))) {
                                    heff_drop(v_p_240);
                                    return heff_dup(g_heff_2einterp_2efloat2_24s1423458924x1394741838_get());
                                  } else {
                                    if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str23))) {
                                      heff_drop(v_p_240);
                                      return heff_dup(g_heff_2einterp_2efloat2_24s205358756x116382871_get());
                                    } else {
                                      if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str24))) {
                                        heff_drop(v_p_240);
                                        HEFF_LAST return g_heff_2einterp_2efloat2(((V)&g_heff_2einterp_2eprim_lam10_clo));
                                      } else {
                                        if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str27))) {
                                          heff_drop(v_p_240);
                                          HEFF_LAST return g_heff_2einterp_2efloat2(((V)&g_heff_2einterp_2eprim_lam11_clo));
                                        } else {
                                          if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str30))) {
                                            heff_drop(v_p_240);
                                            HEFF_LAST return g_heff_2einterp_2efloat2(((V)&g_heff_2einterp_2eprim_lam12_clo));
                                          } else {
                                            if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str33))) {
                                              heff_drop(v_p_240);
                                              return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam13_clo)});
                                            } else {
                                              if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str34))) {
                                                heff_drop(v_p_240);
                                                return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam14_clo)});
                                              } else {
                                                if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str35))) {
                                                  heff_drop(v_p_240);
                                                  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam15_clo)});
                                                } else {
                                                  if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str36))) {
                                                    heff_drop(v_p_240);
                                                    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam16_clo)});
                                                  } else {
                                                    if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str37))) {
                                                      heff_drop(v_p_240);
                                                      return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam17_clo)});
                                                    } else {
                                                      if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str38))) {
                                                        heff_drop(v_p_240);
                                                        return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam18_clo)});
                                                      } else {
                                                        if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str39))) {
                                                          heff_drop(v_p_240);
                                                          return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam19_clo)});
                                                        } else {
                                                          if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str40))) {
                                                            heff_drop(v_p_240);
                                                            return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam20_clo)});
                                                          } else {
                                                            if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str41))) {
                                                              heff_drop(v_p_240);
                                                              return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam21_clo)});
                                                            } else {
                                                              if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str42))) {
                                                                heff_drop(v_p_240);
                                                                return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam22_clo)});
                                                              } else {
                                                                if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str43))) {
                                                                  heff_drop(v_p_240);
                                                                  return heff_dup(g_heff_2einterp_2efloat2_24s1759709581x228229611_get());
                                                                } else {
                                                                  if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str44))) {
                                                                    heff_drop(v_p_240);
                                                                    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam23_clo)});
                                                                  } else {
                                                                    if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str45))) {
                                                                      heff_drop(v_p_240);
                                                                      return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam24_clo)});
                                                                    } else {
                                                                      if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str46))) {
                                                                        heff_drop(v_p_240);
                                                                        return heff_dup(g_heff_2einterp_2efloat2_24s615196179x236480627_get());
                                                                      } else {
                                                                        if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str47))) {
                                                                          heff_drop(v_p_240);
                                                                          return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam25_clo)});
                                                                        } else {
                                                                          if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str48))) {
                                                                            heff_drop(v_p_240);
                                                                            return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam27_clo)});
                                                                          } else {
                                                                            if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str49))) {
                                                                              heff_drop(v_p_240);
                                                                              return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam30_clo)});
                                                                            } else {
                                                                              if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str50))) {
                                                                                heff_drop(v_p_240);
                                                                                return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam34_clo)});
                                                                              } else {
                                                                                if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str51))) {
                                                                                  heff_drop(v_p_240);
                                                                                  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam38_clo)});
                                                                                } else {
                                                                                  if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str52))) {
                                                                                    heff_drop(v_p_240);
                                                                                    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam40_clo)});
                                                                                  } else {
                                                                                    if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str53))) {
                                                                                      heff_drop(v_p_240);
                                                                                      return heff_dup(g_heff_2einterp_2estr2_24s1802929932x1594371566_get());
                                                                                    } else {
                                                                                      if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str54))) {
                                                                                        heff_drop(v_p_240);
                                                                                        return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam42_clo)});
                                                                                      } else {
                                                                                        if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str55))) {
                                                                                          heff_drop(v_p_240);
                                                                                          return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam43_clo)});
                                                                                        } else {
                                                                                          if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str56))) {
                                                                                            heff_drop(v_p_240);
                                                                                            HEFF_LAST return g_heff_2einterp_2estr2(((V)&g_heff_2einterp_2eprim_lam46_clo));
                                                                                          } else {
                                                                                            if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str59))) {
                                                                                              heff_drop(v_p_240);
                                                                                              HEFF_LAST return g_heff_2einterp_2estr2(((V)&g_heff_2einterp_2eprim_lam47_clo));
                                                                                            } else {
                                                                                              if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str62))) {
                                                                                                heff_drop(v_p_240);
                                                                                                return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam48_clo)});
                                                                                              } else {
                                                                                                if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str63))) {
                                                                                                  heff_drop(v_p_240);
                                                                                                  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam50_clo)});
                                                                                                } else {
                                                                                                  if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str64))) {
                                                                                                    heff_drop(v_p_240);
                                                                                                    HEFF_LAST return g_heff_2einterp_2erune2(((V)&g_heff_2einterp_2eprim_lam51_clo));
                                                                                                  } else {
                                                                                                    if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str67))) {
                                                                                                      heff_drop(v_p_240);
                                                                                                      HEFF_LAST return g_heff_2einterp_2erune2(((V)&g_heff_2einterp_2eprim_lam52_clo));
                                                                                                    } else {
                                                                                                      if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str70))) {
                                                                                                        heff_drop(v_p_240);
                                                                                                        HEFF_LAST return g_heff_2einterp_2erune2(((V)&g_heff_2einterp_2eprim_lam53_clo));
                                                                                                      } else {
                                                                                                        if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str73))) {
                                                                                                          heff_drop(v_p_240);
                                                                                                          return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam54_clo)});
                                                                                                        } else {
                                                                                                          if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str74))) {
                                                                                                            heff_drop(v_p_240);
                                                                                                            return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam55_clo)});
                                                                                                          } else {
                                                                                                            if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str75))) {
                                                                                                              heff_drop(v_p_240);
                                                                                                              return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam56_clo)});
                                                                                                            } else {
                                                                                                              if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str76))) {
                                                                                                                heff_drop(v_p_240);
                                                                                                                return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam57_clo)});
                                                                                                              } else {
                                                                                                                V v_t_24630 = (g_heff_2efixed_2efixedPrimOf(v_p_240));
                                                                                                                switch (heff_tag_of(v_t_24630)) {
                                                                                                                case TAG_Nothing: {
                                                                                                                  return heff_abandon();
                                                                                                                }
                                                                                                                case TAG_Just: {
                                                                                                                  V v_fp_24631 = heff_field(v_t_24630, 0);
                                                                                                                  heff_take_n(v_t_24630, 1ULL, 1);
                                                                                                                  HEFF_LAST return g_heff_2einterp_2efixedPrimV(v_fp_24631);
                                                                                                                }
                                                                                                                default: return heff_nomatch(v_t_24630);
                                                                                                                }
                                                                                                              }
                                                                                                            }
                                                                                                          }
                                                                                                        }
                                                                                                      }
                                                                                                    }
                                                                                                  }
                                                                                                }
                                                                                              }
                                                                                            }
                                                                                          }
                                                                                        }
                                                                                      }
                                                                                    }
                                                                                  }
                                                                                }
                                                                              }
                                                                            }
                                                                          }
                                                                        }
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2einterp_2eprim_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eprim(a[0]);
}
V g_heff_2einterp_2eprim_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_b_246 = args[1];
  if (heff_intEq_c(heff_dup(v_b_246), MK_INT(0LL))) {
    heff_drop(v_a_245);
    heff_drop(v_b_246);
    return NTAG(TAG_Abn);
  } else {
    V v_t_248 = heff_intDiv(v_a_245, v_b_246);
    return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_t_248})});
  }
}
V g_heff_2einterp_2eprim_lam1(V self, V *args) {
  V v_a_2410 = args[0];
  V v_b_2411 = args[1];
  if (heff_intEq_c(heff_dup(v_b_2411), MK_INT(0LL))) {
    heff_drop(v_a_2410);
    heff_drop(v_b_2411);
    return NTAG(TAG_Abn);
  } else {
    V v_t_2413 = heff_intMod(v_a_2410, v_b_2411);
    return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_t_2413})});
  }
}
V g_heff_2einterp_2eprim_lam2(V self, V *args) {
  V v_a_2415 = args[0];
  V v_b_2416 = args[1];
  V v_t_2418;
  if (heff_intEq_c(v_a_2415, v_b_2416)) {
    v_t_2418 = ((V)&g_heff_2einterp_2eprim_str6);
  } else {
    v_t_2418 = ((V)&g_heff_2einterp_2eprim_str7);
  }
  V v_t_2419 = heff_tag(TAG_VTag, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2419});
}
V g_heff_2einterp_2eprim_lam3(V self, V *args) {
  V v_a_2421 = args[0];
  V v_b_2422 = args[1];
  V v_t_2424;
  if (heff_intLt_c(v_a_2421, v_b_2422)) {
    v_t_2424 = ((V)&g_heff_2einterp_2eprim_str9);
  } else {
    v_t_2424 = ((V)&g_heff_2einterp_2eprim_str10);
  }
  V v_t_2425 = heff_tag(TAG_VTag, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2425});
}
V g_heff_2einterp_2eprim_lam4(V self, V *args) {
  V v_a_2427 = args[0];
  V v_b_2428 = args[1];
  V v_t_2430;
  if (heff_intLe_c(v_a_2427, v_b_2428)) {
    v_t_2430 = ((V)&g_heff_2einterp_2eprim_str12);
  } else {
    v_t_2430 = ((V)&g_heff_2einterp_2eprim_str13);
  }
  V v_t_2431 = heff_tag(TAG_VTag, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2431});
}
V g_heff_2einterp_2eprim_lam5(V self, V *args) {
  V v_d_2433 = args[0];
  V v_a_2434 = args[1];
  V v_x1_2435 = heff_tr(heff_apply(v_a_2434, 1, (V[]){v_d_2433}));
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_Ok: {
    V v_v_2436 = heff_field(v_x1_2435, 0);
    V v_ru_24x1_2435_24Ok = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
    switch (heff_tag_of(v_v_2436)) {
    case TAG_VFun: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_2436, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_2441 = heff_field(v_v_2436, 0);
      V v_ru_24v_2436_24VInt = heff_take_reuse_n(v_v_2436, 1ULL, 1);
      V v_t_2442 = heff_tag_at(v_ru_24x1_2435_24Ok, TAG_VStr, 1, (V[]){heff_intShow(v_a_2441)});
      return heff_tag_at(v_ru_24v_2436_24VInt, TAG_Ok, 1, (V[]){v_t_2442});
    }
    case TAG_VFloat: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_2436);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_2435);
  }
}
V g_heff_2einterp_2eprim_lam6(V self, V *args) {
  V v_a_2450 = args[0];
  V v_b_2451 = args[1];
  V v_t_2452 = heff_tag(TAG_VInt, 1, (V[]){(g_heff_2einterp_2eintBits_24s522074386x924975132(MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), v_a_2450, v_b_2451))});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2452});
}
V g_heff_2einterp_2eprim_lam7(V self, V *args) {
  V v_a_2454 = args[0];
  V v_b_2455 = args[1];
  V v_t_2456 = heff_tag(TAG_VInt, 1, (V[]){(g_heff_2einterp_2eintBits_24s715749050x314660754(MK_INT(2LL), v_a_2454, v_b_2455))});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2456});
}
V g_heff_2einterp_2eprim_lam8(V self, V *args) {
  V v_a_2458 = args[0];
  V v_b_2459 = args[1];
  if (heff_intLt_c(heff_dup(v_b_2459), MK_INT(0LL))) {
    heff_drop(v_a_2458);
    heff_drop(v_b_2459);
    return NTAG(TAG_Abn);
  } else {
    V v_k_2461 = (g_heff_2efixed_2etwoTo(v_b_2459));
    V v_t_2462 = heff_tag(TAG_VInt, 1, (V[]){heff_intMul(v_a_2458, v_k_2461)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_2462});
  }
}
V g_heff_2einterp_2eprim_lam9(V self, V *args) {
  V v_a_2464 = args[0];
  V v_b_2465 = args[1];
  if (heff_intLt_c(heff_dup(v_b_2465), MK_INT(0LL))) {
    heff_drop(v_a_2464);
    heff_drop(v_b_2465);
    return NTAG(TAG_Abn);
  } else {
    V v_k_2467 = (g_heff_2efixed_2etwoTo(v_b_2465));
    V v_t_2468 = heff_intDiv(v_a_2464, v_k_2467);
    return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_t_2468})});
  }
}
V g_heff_2einterp_2eprim_lam10(V self, V *args) {
  V v_a_2474 = args[0];
  V v_b_2475 = args[1];
  V v_t_2477;
  if (heff_floatEq_c(v_a_2474, v_b_2475)) {
    v_t_2477 = ((V)&g_heff_2einterp_2eprim_str25);
  } else {
    v_t_2477 = ((V)&g_heff_2einterp_2eprim_str26);
  }
  V v_t_2478 = heff_tag(TAG_VTag, 2, (V[]){v_t_2477, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2478});
}
V g_heff_2einterp_2eprim_lam11(V self, V *args) {
  V v_a_2480 = args[0];
  V v_b_2481 = args[1];
  V v_t_2483;
  if (heff_floatLt_c(v_a_2480, v_b_2481)) {
    v_t_2483 = ((V)&g_heff_2einterp_2eprim_str28);
  } else {
    v_t_2483 = ((V)&g_heff_2einterp_2eprim_str29);
  }
  V v_t_2484 = heff_tag(TAG_VTag, 2, (V[]){v_t_2483, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2484});
}
V g_heff_2einterp_2eprim_lam12(V self, V *args) {
  V v_a_2486 = args[0];
  V v_b_2487 = args[1];
  V v_t_2489;
  if (heff_floatLe_c(v_a_2486, v_b_2487)) {
    v_t_2489 = ((V)&g_heff_2einterp_2eprim_str31);
  } else {
    v_t_2489 = ((V)&g_heff_2einterp_2eprim_str32);
  }
  V v_t_2490 = heff_tag(TAG_VTag, 2, (V[]){v_t_2489, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2490});
}
V g_heff_2einterp_2eprim_lam13(V self, V *args) {
  V v_d_2492 = args[0];
  V v_a_2493 = args[1];
  V v_x1_2494 = heff_tr(heff_apply(v_a_2493, 1, (V[]){v_d_2492}));
  switch (heff_tag_of(v_x1_2494)) {
  case TAG_Ok: {
    V v_v_2495 = heff_field(v_x1_2494, 0);
    V v_ru_24x1_2494_24Ok = heff_take_reuse_n(v_x1_2494, 1ULL, 1);
    switch (heff_tag_of(v_v_2495)) {
    case TAG_VFun: {
      heff_take_n(v_v_2495, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_2495, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_2495, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_2495, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24101 = heff_field(v_v_2495, 0);
      V v_ru_24v_2495_24VFloat = heff_take_reuse_n(v_v_2495, 1ULL, 1);
      V v_t_24102 = heff_tag_at(v_ru_24x1_2494_24Ok, TAG_VStr, 1, (V[]){heff_floatShow(v_a_24101)});
      return heff_tag_at(v_ru_24v_2495_24VFloat, TAG_Ok, 1, (V[]){v_t_24102});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2495, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_2495, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_2495, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_2495, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_2495);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_2494);
  }
}
V g_heff_2einterp_2eprim_lam14(V self, V *args) {
  V v_d_24108 = args[0];
  V v_a_24109 = args[1];
  V v_x1_24110 = heff_tr(heff_apply(v_a_24109, 1, (V[]){v_d_24108}));
  switch (heff_tag_of(v_x1_24110)) {
  case TAG_Ok: {
    V v_v_24111 = heff_field(v_x1_24110, 0);
    V v_ru_24x1_24110_24Ok = heff_take_reuse_n(v_x1_24110, 1ULL, 1);
    switch (heff_tag_of(v_v_24111)) {
    case TAG_VFun: {
      heff_take_n(v_v_24111, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24110_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24111, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24110_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24111, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24110_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24116 = heff_field(v_v_24111, 0);
      V v_ru_24v_24111_24VInt = heff_take_reuse_n(v_v_24111, 1ULL, 1);
      V v_t_24117 = heff_tag_at(v_ru_24x1_24110_24Ok, TAG_VFloat, 1, (V[]){heff_floatFromInt(v_a_24116)});
      return heff_tag_at(v_ru_24v_24111_24VInt, TAG_Ok, 1, (V[]){v_t_24117});
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24111, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24110_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24111, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24110_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24111, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24110_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24111, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24110_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24111, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24110_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24110_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24111);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24110);
  }
}
V g_heff_2einterp_2eprim_lam15(V self, V *args) {
  V v_d_24124 = args[0];
  V v_a_24125 = args[1];
  V v_x1_24126 = heff_tr(heff_apply(v_a_24125, 1, (V[]){v_d_24124}));
  switch (heff_tag_of(v_x1_24126)) {
  case TAG_Ok: {
    V v_v_24127 = heff_field(v_x1_24126, 0);
    V v_ru_24x1_24126_24Ok = heff_take_reuse_n(v_x1_24126, 1ULL, 1);
    switch (heff_tag_of(v_v_24127)) {
    case TAG_VFun: {
      heff_take_n(v_v_24127, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24127, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24127, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24127, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24133 = heff_field(v_v_24127, 0);
      V v_ru_24v_24127_24VFloat = heff_take_reuse_n(v_v_24127, 1ULL, 1);
      V v_t_24134 = heff_tag_at(v_ru_24x1_24126_24Ok, TAG_VFloat, 1, (V[]){heff_floatSqrt(v_a_24133)});
      return heff_tag_at(v_ru_24v_24127_24VFloat, TAG_Ok, 1, (V[]){v_t_24134});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24127, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24127, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24127, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24127, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24127);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24126);
  }
}
V g_heff_2einterp_2eprim_lam16(V self, V *args) {
  V v_d_24140 = args[0];
  V v_a_24141 = args[1];
  V v_x1_24142 = heff_tr(heff_apply(v_a_24141, 1, (V[]){v_d_24140}));
  switch (heff_tag_of(v_x1_24142)) {
  case TAG_Ok: {
    V v_v_24143 = heff_field(v_x1_24142, 0);
    V v_ru_24x1_24142_24Ok = heff_take_reuse_n(v_x1_24142, 1ULL, 1);
    switch (heff_tag_of(v_v_24143)) {
    case TAG_VFun: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24143, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24149 = heff_field(v_v_24143, 0);
      heff_take_n(v_v_24143, 1ULL, 1);
      if (heff_floatEq_c(heff_floatSub(heff_dup(v_a_24149), heff_dup(v_a_24149)), heff_flt(0.0))) {
        V v_t_24151 = heff_floatFloor(v_a_24149);
        return heff_tag_at(v_ru_24x1_24142_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_t_24151})});
      } else {
        heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
        heff_drop(v_a_24149);
        return NTAG(TAG_Abn);
      }
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24143);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24142);
  }
}
V g_heff_2einterp_2eprim_lam17(V self, V *args) {
  V v_d_24157 = args[0];
  V v_a_24158 = args[1];
  V v_x1_24159 = heff_tr(heff_apply(v_a_24158, 1, (V[]){v_d_24157}));
  switch (heff_tag_of(v_x1_24159)) {
  case TAG_Ok: {
    V v_v_24160 = heff_field(v_x1_24159, 0);
    V v_ru_24x1_24159_24Ok = heff_take_reuse_n(v_x1_24159, 1ULL, 1);
    switch (heff_tag_of(v_v_24160)) {
    case TAG_VFun: {
      heff_take_n(v_v_24160, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24159_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24160, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24159_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24160, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24159_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24160, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24159_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24166 = heff_field(v_v_24160, 0);
      V v_ru_24v_24160_24VFloat = heff_take_reuse_n(v_v_24160, 1ULL, 1);
      V v_t_24167 = heff_tag_at(v_ru_24x1_24159_24Ok, TAG_VFloat, 1, (V[]){heff_floatSin(v_a_24166)});
      return heff_tag_at(v_ru_24v_24160_24VFloat, TAG_Ok, 1, (V[]){v_t_24167});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24160, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24159_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24160, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24159_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24160, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24159_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24160, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24159_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24159_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24160);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24159);
  }
}
V g_heff_2einterp_2eprim_lam18(V self, V *args) {
  V v_d_24173 = args[0];
  V v_a_24174 = args[1];
  V v_x1_24175 = heff_tr(heff_apply(v_a_24174, 1, (V[]){v_d_24173}));
  switch (heff_tag_of(v_x1_24175)) {
  case TAG_Ok: {
    V v_v_24176 = heff_field(v_x1_24175, 0);
    V v_ru_24x1_24175_24Ok = heff_take_reuse_n(v_x1_24175, 1ULL, 1);
    switch (heff_tag_of(v_v_24176)) {
    case TAG_VFun: {
      heff_take_n(v_v_24176, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24175_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24176, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24175_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24176, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24175_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24176, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24175_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24182 = heff_field(v_v_24176, 0);
      V v_ru_24v_24176_24VFloat = heff_take_reuse_n(v_v_24176, 1ULL, 1);
      V v_t_24183 = heff_tag_at(v_ru_24x1_24175_24Ok, TAG_VFloat, 1, (V[]){heff_floatCos(v_a_24182)});
      return heff_tag_at(v_ru_24v_24176_24VFloat, TAG_Ok, 1, (V[]){v_t_24183});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24176, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24175_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24176, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24175_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24176, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24175_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24176, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24175_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24175_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24176);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24175);
  }
}
V g_heff_2einterp_2eprim_lam19(V self, V *args) {
  V v_d_24189 = args[0];
  V v_a_24190 = args[1];
  V v_x1_24191 = heff_tr(heff_apply(v_a_24190, 1, (V[]){v_d_24189}));
  switch (heff_tag_of(v_x1_24191)) {
  case TAG_Ok: {
    V v_v_24192 = heff_field(v_x1_24191, 0);
    V v_ru_24x1_24191_24Ok = heff_take_reuse_n(v_x1_24191, 1ULL, 1);
    switch (heff_tag_of(v_v_24192)) {
    case TAG_VFun: {
      heff_take_n(v_v_24192, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24191_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24192, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24191_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24192, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24191_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24192, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24191_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24198 = heff_field(v_v_24192, 0);
      V v_ru_24v_24192_24VFloat = heff_take_reuse_n(v_v_24192, 1ULL, 1);
      V v_t_24199 = heff_tag_at(v_ru_24x1_24191_24Ok, TAG_VFloat, 1, (V[]){heff_floatTan(v_a_24198)});
      return heff_tag_at(v_ru_24v_24192_24VFloat, TAG_Ok, 1, (V[]){v_t_24199});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24192, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24191_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24192, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24191_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24192, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24191_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24192, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24191_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24191_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24192);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24191);
  }
}
V g_heff_2einterp_2eprim_lam20(V self, V *args) {
  V v_d_24205 = args[0];
  V v_a_24206 = args[1];
  V v_x1_24207 = heff_tr(heff_apply(v_a_24206, 1, (V[]){v_d_24205}));
  switch (heff_tag_of(v_x1_24207)) {
  case TAG_Ok: {
    V v_v_24208 = heff_field(v_x1_24207, 0);
    V v_ru_24x1_24207_24Ok = heff_take_reuse_n(v_x1_24207, 1ULL, 1);
    switch (heff_tag_of(v_v_24208)) {
    case TAG_VFun: {
      heff_take_n(v_v_24208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24208, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24214 = heff_field(v_v_24208, 0);
      V v_ru_24v_24208_24VFloat = heff_take_reuse_n(v_v_24208, 1ULL, 1);
      V v_t_24215 = heff_tag_at(v_ru_24x1_24207_24Ok, TAG_VFloat, 1, (V[]){heff_floatAsin(v_a_24214)});
      return heff_tag_at(v_ru_24v_24208_24VFloat, TAG_Ok, 1, (V[]){v_t_24215});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24208);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24207);
  }
}
V g_heff_2einterp_2eprim_lam21(V self, V *args) {
  V v_d_24221 = args[0];
  V v_a_24222 = args[1];
  V v_x1_24223 = heff_tr(heff_apply(v_a_24222, 1, (V[]){v_d_24221}));
  switch (heff_tag_of(v_x1_24223)) {
  case TAG_Ok: {
    V v_v_24224 = heff_field(v_x1_24223, 0);
    V v_ru_24x1_24223_24Ok = heff_take_reuse_n(v_x1_24223, 1ULL, 1);
    switch (heff_tag_of(v_v_24224)) {
    case TAG_VFun: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24224, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24230 = heff_field(v_v_24224, 0);
      V v_ru_24v_24224_24VFloat = heff_take_reuse_n(v_v_24224, 1ULL, 1);
      V v_t_24231 = heff_tag_at(v_ru_24x1_24223_24Ok, TAG_VFloat, 1, (V[]){heff_floatAcos(v_a_24230)});
      return heff_tag_at(v_ru_24v_24224_24VFloat, TAG_Ok, 1, (V[]){v_t_24231});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24224);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24223);
  }
}
V g_heff_2einterp_2eprim_lam22(V self, V *args) {
  V v_d_24237 = args[0];
  V v_a_24238 = args[1];
  V v_x1_24239 = heff_tr(heff_apply(v_a_24238, 1, (V[]){v_d_24237}));
  switch (heff_tag_of(v_x1_24239)) {
  case TAG_Ok: {
    V v_v_24240 = heff_field(v_x1_24239, 0);
    V v_ru_24x1_24239_24Ok = heff_take_reuse_n(v_x1_24239, 1ULL, 1);
    switch (heff_tag_of(v_v_24240)) {
    case TAG_VFun: {
      heff_take_n(v_v_24240, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24239_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24240, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24239_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24240, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24239_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24240, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24239_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24246 = heff_field(v_v_24240, 0);
      V v_ru_24v_24240_24VFloat = heff_take_reuse_n(v_v_24240, 1ULL, 1);
      V v_t_24247 = heff_tag_at(v_ru_24x1_24239_24Ok, TAG_VFloat, 1, (V[]){heff_floatAtan(v_a_24246)});
      return heff_tag_at(v_ru_24v_24240_24VFloat, TAG_Ok, 1, (V[]){v_t_24247});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24240, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24239_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24240, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24239_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24240, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24239_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24240, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24239_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24239_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24240);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24239);
  }
}
V g_heff_2einterp_2eprim_lam23(V self, V *args) {
  V v_d_24254 = args[0];
  V v_a_24255 = args[1];
  V v_x1_24256 = heff_tr(heff_apply(v_a_24255, 1, (V[]){v_d_24254}));
  switch (heff_tag_of(v_x1_24256)) {
  case TAG_Ok: {
    V v_v_24257 = heff_field(v_x1_24256, 0);
    V v_ru_24x1_24256_24Ok = heff_take_reuse_n(v_x1_24256, 1ULL, 1);
    switch (heff_tag_of(v_v_24257)) {
    case TAG_VFun: {
      heff_take_n(v_v_24257, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24256_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24257, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24256_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24257, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24256_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24257, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24256_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24263 = heff_field(v_v_24257, 0);
      V v_ru_24v_24257_24VFloat = heff_take_reuse_n(v_v_24257, 1ULL, 1);
      V v_t_24264 = heff_tag_at(v_ru_24x1_24256_24Ok, TAG_VFloat, 1, (V[]){heff_floatExp(v_a_24263)});
      return heff_tag_at(v_ru_24v_24257_24VFloat, TAG_Ok, 1, (V[]){v_t_24264});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24257, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24256_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24257, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24256_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24257, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24256_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24257, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24256_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24256_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24257);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24256);
  }
}
V g_heff_2einterp_2eprim_lam24(V self, V *args) {
  V v_d_24270 = args[0];
  V v_a_24271 = args[1];
  V v_x1_24272 = heff_tr(heff_apply(v_a_24271, 1, (V[]){v_d_24270}));
  switch (heff_tag_of(v_x1_24272)) {
  case TAG_Ok: {
    V v_v_24273 = heff_field(v_x1_24272, 0);
    V v_ru_24x1_24272_24Ok = heff_take_reuse_n(v_x1_24272, 1ULL, 1);
    switch (heff_tag_of(v_v_24273)) {
    case TAG_VFun: {
      heff_take_n(v_v_24273, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24272_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24273, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24272_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24273, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24272_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24273, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24272_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24279 = heff_field(v_v_24273, 0);
      V v_ru_24v_24273_24VFloat = heff_take_reuse_n(v_v_24273, 1ULL, 1);
      V v_t_24280 = heff_tag_at(v_ru_24x1_24272_24Ok, TAG_VFloat, 1, (V[]){heff_floatLog(v_a_24279)});
      return heff_tag_at(v_ru_24v_24273_24VFloat, TAG_Ok, 1, (V[]){v_t_24280});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24273, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24272_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24273, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24272_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24273, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24272_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24273, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24272_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24272_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24273);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24272);
  }
}
V g_heff_2einterp_2eprim_lam26(V self, V *args) {
  V v_d_24289 = args[0];
  V v_a_24290 = args[1];
  V v_x1_24291 = heff_tr(heff_apply(v_a_24290, 1, (V[]){v_d_24289}));
  switch (heff_tag_of(v_x1_24291)) {
  case TAG_Ok: {
    V v_v_24292 = heff_field(v_x1_24291, 0);
    V v_ru_24x1_24291_24Ok = heff_take_reuse_n(v_x1_24291, 1ULL, 1);
    switch (heff_tag_of(v_v_24292)) {
    case TAG_VFun: {
      heff_take_n(v_v_24292, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24291_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24292, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24291_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24292, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24291_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24292, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24291_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24292, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24291_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24292, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24291_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24292, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24291_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24292, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24291_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      V v_xs_24302 = heff_field(v_v_24292, 0);
      V v_ru_24v_24292_24VArr = heff_take_reuse_n(v_v_24292, 1ULL, 1);
      V v_t_24303 = heff_tag_at(v_ru_24x1_24291_24Ok, TAG_VInt, 1, (V[]){({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(v_xs_24302); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; })});
      return heff_tag_at(v_ru_24v_24292_24VArr, TAG_Ok, 1, (V[]){v_t_24303});
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24291_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24292);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24291);
  }
}
V g_heff_2einterp_2eprim_lam25(V self, V *args) {
  V v_d_24287 = args[0];
  V v_u_24288 = args[1];
  heff_drop(v_d_24287);
  heff_drop(v_u_24288);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam26_clo)})});
}
V g_heff_2einterp_2eprim_lam29(V self, V *args) {
  V v_d_24321 = args[0];
  V v_a_24322 = args[1];
  V v_xs_24320 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24323 = heff_tr(heff_apply(v_a_24322, 1, (V[]){v_d_24321}));
  switch (heff_tag_of(v_x1_24323)) {
  case TAG_Ok: {
    V v_v_24324 = heff_field(v_x1_24323, 0);
    V v_ru_24x1_24323_24Ok = heff_take_reuse_n(v_x1_24323, 1ULL, 1);
    switch (heff_tag_of(v_v_24324)) {
    case TAG_VFun: {
      heff_take_n(v_v_24324, 0ULL, 1);
      heff_drop(v_xs_24320);
      heff_drop_cell(v_ru_24x1_24323_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24324, 0ULL, 1);
      heff_drop(v_xs_24320);
      heff_drop_cell(v_ru_24x1_24323_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24324, 0ULL, 2);
      heff_drop(v_xs_24320);
      heff_drop_cell(v_ru_24x1_24323_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24329 = heff_field(v_v_24324, 0);
      heff_take_n(v_v_24324, 1ULL, 1);
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_a_24329))) {
        V v_t_24331 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24320)); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        if (heff_intLt_c(heff_dup(v_a_24329), v_t_24331)) {
          V v_t_24333 = ({ V b_0 = heff_arrayToList(v_xs_24320); V a_1 = v_a_24329; V r_ = (g_heff_2einterp_2enthV(b_0, a_1)); heff_drop(b_0); r_; });
          switch (heff_tag_of(v_t_24333)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x1_24323_24Ok, 1);
            return NTAG(TAG_Abn);
          }
          case TAG_Just: {
            V v_v_24334 = heff_field(v_t_24333, 0);
            heff_take_n(v_t_24333, 1ULL, 1);
            return heff_tag_at(v_ru_24x1_24323_24Ok, TAG_Ok, 1, (V[]){v_v_24334});
          }
          default: return heff_nomatch(v_t_24333);
          }
        } else {
          heff_drop(v_xs_24320);
          heff_drop_cell(v_ru_24x1_24323_24Ok, 1);
          heff_drop(v_a_24329);
          return NTAG(TAG_Abn);
        }
      } else {
        heff_drop(v_xs_24320);
        heff_drop_cell(v_ru_24x1_24323_24Ok, 1);
        heff_drop(v_a_24329);
        return NTAG(TAG_Abn);
      }
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24324, 0ULL, 1);
      heff_drop(v_xs_24320);
      heff_drop_cell(v_ru_24x1_24323_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24324, 0ULL, 1);
      heff_drop(v_xs_24320);
      heff_drop_cell(v_ru_24x1_24323_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24324, 0ULL, 1);
      heff_drop(v_xs_24320);
      heff_drop_cell(v_ru_24x1_24323_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24324, 0ULL, 1);
      heff_drop(v_xs_24320);
      heff_drop_cell(v_ru_24x1_24323_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24324, 0ULL, 1);
      heff_drop(v_xs_24320);
      heff_drop_cell(v_ru_24x1_24323_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_xs_24320);
      heff_drop_cell(v_ru_24x1_24323_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24324);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24320);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24320);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24323);
  }
}
V g_heff_2einterp_2eprim_lam28(V self, V *args) {
  V v_d_24307 = args[0];
  V v_a_24308 = args[1];
  V v_x1_24309 = heff_tr(heff_apply(v_a_24308, 1, (V[]){v_d_24307}));
  switch (heff_tag_of(v_x1_24309)) {
  case TAG_Ok: {
    V v_v_24310 = heff_field(v_x1_24309, 0);
    V v_ru_24x1_24309_24Ok = heff_take_reuse_n(v_x1_24309, 1ULL, 1);
    switch (heff_tag_of(v_v_24310)) {
    case TAG_VFun: {
      heff_take_n(v_v_24310, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24309_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24310, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24309_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24310, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24309_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24310, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24309_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24310, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24309_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24310, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24309_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24310, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24309_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24310, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24309_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      V v_xs_24320 = heff_field(v_v_24310, 0);
      heff_take_n(v_v_24310, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_24309_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam29, 2, 1, (V[]){v_xs_24320})})});
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24309_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24310);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24309);
  }
}
V g_heff_2einterp_2eprim_lam27(V self, V *args) {
  V v_d_24305 = args[0];
  V v_u_24306 = args[1];
  heff_drop(v_d_24305);
  heff_drop(v_u_24306);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam28_clo)})});
}
V g_heff_2einterp_2eprim_lam33(V self, V *args) {
  V v_d_24366 = args[0];
  V v_x_24367 = args[1];
  V v_a_24365 = heff_env(self)[0];
  V v_xs_24356 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24368 = heff_tr(heff_apply(v_x_24367, 1, (V[]){v_d_24366}));
  switch (heff_tag_of(v_x1_24368)) {
  case TAG_Ok: {
    V v_v_24369 = heff_field(v_x1_24368, 0);
    V v_ru_24x1_24368_24Ok = heff_take_reuse_n(v_x1_24368, 1ULL, 1);
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_a_24365))) {
      V v_t_24371 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24356)); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      if (heff_intLt_c(heff_dup(v_a_24365), v_t_24371)) {
        V v_t_24373 = (g_heff_2einterp_2esetAt(heff_arrayToList(v_xs_24356), v_a_24365, v_v_24369));
        V v_t_24374 = heff_tag_at(v_ru_24x1_24368_24Ok, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24373)});
        return heff_tag(TAG_Ok, 1, (V[]){v_t_24374});
      } else {
        heff_drop(v_a_24365);
        heff_drop(v_xs_24356);
        heff_drop(v_v_24369);
        heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
        return NTAG(TAG_Abn);
      }
    } else {
      heff_drop(v_a_24365);
      heff_drop(v_xs_24356);
      heff_drop(v_v_24369);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return NTAG(TAG_Abn);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24365);
    heff_drop(v_xs_24356);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24365);
    heff_drop(v_xs_24356);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24368);
  }
}
V g_heff_2einterp_2eprim_lam32(V self, V *args) {
  V v_d_24357 = args[0];
  V v_a_24358 = args[1];
  V v_xs_24356 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24359 = heff_tr(heff_apply(v_a_24358, 1, (V[]){v_d_24357}));
  switch (heff_tag_of(v_x1_24359)) {
  case TAG_Ok: {
    V v_v_24360 = heff_field(v_x1_24359, 0);
    V v_ru_24x1_24359_24Ok = heff_take_reuse_n(v_x1_24359, 1ULL, 1);
    switch (heff_tag_of(v_v_24360)) {
    case TAG_VFun: {
      heff_take_n(v_v_24360, 0ULL, 1);
      heff_drop(v_xs_24356);
      heff_drop_cell(v_ru_24x1_24359_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24360, 0ULL, 1);
      heff_drop(v_xs_24356);
      heff_drop_cell(v_ru_24x1_24359_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24360, 0ULL, 2);
      heff_drop(v_xs_24356);
      heff_drop_cell(v_ru_24x1_24359_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24365 = heff_field(v_v_24360, 0);
      heff_take_n(v_v_24360, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_24359_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam33, 2, 2, (V[]){v_a_24365, v_xs_24356})})});
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24360, 0ULL, 1);
      heff_drop(v_xs_24356);
      heff_drop_cell(v_ru_24x1_24359_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24360, 0ULL, 1);
      heff_drop(v_xs_24356);
      heff_drop_cell(v_ru_24x1_24359_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24360, 0ULL, 1);
      heff_drop(v_xs_24356);
      heff_drop_cell(v_ru_24x1_24359_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24360, 0ULL, 1);
      heff_drop(v_xs_24356);
      heff_drop_cell(v_ru_24x1_24359_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24360, 0ULL, 1);
      heff_drop(v_xs_24356);
      heff_drop_cell(v_ru_24x1_24359_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_xs_24356);
      heff_drop_cell(v_ru_24x1_24359_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24360);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24356);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24356);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24359);
  }
}
V g_heff_2einterp_2eprim_lam31(V self, V *args) {
  V v_d_24343 = args[0];
  V v_a_24344 = args[1];
  V v_x1_24345 = heff_tr(heff_apply(v_a_24344, 1, (V[]){v_d_24343}));
  switch (heff_tag_of(v_x1_24345)) {
  case TAG_Ok: {
    V v_v_24346 = heff_field(v_x1_24345, 0);
    V v_ru_24x1_24345_24Ok = heff_take_reuse_n(v_x1_24345, 1ULL, 1);
    switch (heff_tag_of(v_v_24346)) {
    case TAG_VFun: {
      heff_take_n(v_v_24346, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24345_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24346, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24345_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24346, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24345_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24346, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24345_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24346, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24345_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24346, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24345_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24346, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24345_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24346, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24345_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      V v_xs_24356 = heff_field(v_v_24346, 0);
      heff_take_n(v_v_24346, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_24345_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam32, 2, 1, (V[]){v_xs_24356})})});
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24345_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24346);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24345);
  }
}
V g_heff_2einterp_2eprim_lam30(V self, V *args) {
  V v_d_24341 = args[0];
  V v_u_24342 = args[1];
  heff_drop(v_d_24341);
  heff_drop(v_u_24342);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam31_clo)})});
}
V g_heff_2einterp_2eprim_lam37(V self, V *args) {
  V v_vs_24396 = args[0];
  V v_t_24397 = heff_tag(TAG_VArr, 1, (V[]){heff_arrayFromList(v_vs_24396)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_24397});
}
V g_heff_2einterp_2eprim_lam36(V self, V *args) {
  V v_d_24392 = args[0];
  V v_f_24393 = args[1];
  V v_a_24391 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24394 = heff_tr(heff_apply(v_f_24393, 1, (V[]){heff_dup(v_d_24392)}));
  switch (heff_tag_of(v_x1_24394)) {
  case TAG_Ok: {
    V v_v_24395 = heff_field(v_x1_24394, 0);
    heff_take_n(v_x1_24394, 1ULL, 1);
    return (g_heff_2einterp_2egenGo(v_d_24392, MK_INT(0LL), v_a_24391, v_v_24395, ((V)&g_heff_2einterp_2eprim_lam37_clo)));
  }
  case TAG_Abn: {
    heff_drop(v_d_24392);
    heff_drop(v_a_24391);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_24392);
    heff_drop(v_a_24391);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24394);
  }
}
V g_heff_2einterp_2eprim_lam35(V self, V *args) {
  V v_d_24383 = args[0];
  V v_a_24384 = args[1];
  V v_x1_24385 = heff_tr(heff_apply(v_a_24384, 1, (V[]){v_d_24383}));
  switch (heff_tag_of(v_x1_24385)) {
  case TAG_Ok: {
    V v_v_24386 = heff_field(v_x1_24385, 0);
    V v_ru_24x1_24385_24Ok = heff_take_reuse_n(v_x1_24385, 1ULL, 1);
    switch (heff_tag_of(v_v_24386)) {
    case TAG_VFun: {
      heff_take_n(v_v_24386, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24385_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24386, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24385_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24386, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24385_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24391 = heff_field(v_v_24386, 0);
      heff_take_n(v_v_24386, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_24385_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam36, 2, 1, (V[]){v_a_24391})})});
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24386, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24385_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24386, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24385_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24386, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24385_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24386, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24385_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24386, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24385_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24385_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24386);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24385);
  }
}
V g_heff_2einterp_2eprim_lam34(V self, V *args) {
  V v_d_24381 = args[0];
  V v_u_24382 = args[1];
  heff_drop(v_d_24381);
  heff_drop(v_u_24382);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam35_clo)})});
}
V g_heff_2einterp_2eprim_lam39(V self, V *args) {
  V v_d_24406 = args[0];
  V v_l_24407 = args[1];
  V v_x1_24408 = heff_tr(heff_apply(v_l_24407, 1, (V[]){v_d_24406}));
  switch (heff_tag_of(v_x1_24408)) {
  case TAG_Ok: {
    V v_v_24409 = heff_field(v_x1_24408, 0);
    V v_ru_24x1_24408_24Ok = heff_take_reuse_n(v_x1_24408, 1ULL, 1);
    V v_t_24410 = (g_heff_2einterp_2efromListV(v_v_24409, NTAG(TAG_Nil)));
    V v_t_24411 = heff_tag_at(v_ru_24x1_24408_24Ok, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24410)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_24411});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24408);
  }
}
V g_heff_2einterp_2eprim_lam38(V self, V *args) {
  V v_d_24404 = args[0];
  V v_u_24405 = args[1];
  heff_drop(v_d_24404);
  heff_drop(v_u_24405);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam39_clo)})});
}
V g_heff_2einterp_2eprim_lam41(V self, V *args) {
  V v_d_24415 = args[0];
  V v_a_24416 = args[1];
  V v_x1_24417 = heff_tr(heff_apply(v_a_24416, 1, (V[]){v_d_24415}));
  switch (heff_tag_of(v_x1_24417)) {
  case TAG_Ok: {
    V v_v_24418 = heff_field(v_x1_24417, 0);
    V v_ru_24x1_24417_24Ok = heff_take_reuse_n(v_x1_24417, 1ULL, 1);
    switch (heff_tag_of(v_v_24418)) {
    case TAG_VFun: {
      heff_take_n(v_v_24418, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24417_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24418, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24417_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24418, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24417_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24418, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24417_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24418, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24417_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24418, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24417_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24418, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24417_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24418, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24417_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      V v_xs_24428 = heff_field(v_v_24418, 0);
      heff_take_n(v_v_24418, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_24417_24Ok, TAG_Ok, 1, (V[]){(g_heff_2einterp_2etoListV(heff_arrayToList(v_xs_24428)))});
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24417_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24418);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24417);
  }
}
V g_heff_2einterp_2eprim_lam40(V self, V *args) {
  V v_d_24413 = args[0];
  V v_u_24414 = args[1];
  heff_drop(v_d_24413);
  heff_drop(v_u_24414);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam41_clo)})});
}
V g_heff_2einterp_2eprim_lam42(V self, V *args) {
  V v_d_24431 = args[0];
  V v_a_24432 = args[1];
  V v_x1_24433 = heff_tr(heff_apply(v_a_24432, 1, (V[]){v_d_24431}));
  switch (heff_tag_of(v_x1_24433)) {
  case TAG_Ok: {
    V v_v_24434 = heff_field(v_x1_24433, 0);
    V v_ru_24x1_24433_24Ok = heff_take_reuse_n(v_x1_24433, 1ULL, 1);
    switch (heff_tag_of(v_v_24434)) {
    case TAG_VFun: {
      heff_take_n(v_v_24434, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24433_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24434, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24433_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24434, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24433_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24434, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24433_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24434, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24433_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24434, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24433_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      V v_a_24442 = heff_field(v_v_24434, 0);
      V v_ru_24v_24434_24VStr = heff_take_reuse_n(v_v_24434, 1ULL, 1);
      V v_t_24443 = heff_tag_at(v_ru_24x1_24433_24Ok, TAG_VInt, 1, (V[]){heff_strLength(v_a_24442)});
      return heff_tag_at(v_ru_24v_24434_24VStr, TAG_Ok, 1, (V[]){v_t_24443});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24434, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24433_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24434, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24433_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24433_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24434);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24433);
  }
}
V g_heff_2einterp_2eprim_lam45(V self, V *args) {
  V v_d_24468 = args[0];
  V v_a_24469 = args[1];
  V v_a_24458 = heff_env(self)[0];
  V v_a_24467 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24470 = heff_tr(heff_apply(v_a_24469, 1, (V[]){v_d_24468}));
  switch (heff_tag_of(v_x1_24470)) {
  case TAG_Ok: {
    V v_v_24471 = heff_field(v_x1_24470, 0);
    V v_ru_24x1_24470_24Ok = heff_take_reuse_n(v_x1_24470, 1ULL, 1);
    switch (heff_tag_of(v_v_24471)) {
    case TAG_VFun: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop(v_a_24458);
      heff_drop(v_a_24467);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop(v_a_24458);
      heff_drop(v_a_24467);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24471, 0ULL, 2);
      heff_drop(v_a_24458);
      heff_drop(v_a_24467);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24476 = heff_field(v_v_24471, 0);
      V v_ru_24v_24471_24VInt = heff_take_reuse_n(v_v_24471, 1ULL, 1);
      V v_t_24477 = heff_tag_at(v_ru_24x1_24470_24Ok, TAG_VStr, 1, (V[]){heff_strSlice(v_a_24458, v_a_24467, v_a_24476)});
      return heff_tag_at(v_ru_24v_24471_24VInt, TAG_Ok, 1, (V[]){v_t_24477});
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop(v_a_24458);
      heff_drop(v_a_24467);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop(v_a_24458);
      heff_drop(v_a_24467);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop(v_a_24458);
      heff_drop(v_a_24467);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop(v_a_24458);
      heff_drop(v_a_24467);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop(v_a_24458);
      heff_drop(v_a_24467);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_a_24458);
      heff_drop(v_a_24467);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24471);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24458);
    heff_drop(v_a_24467);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24458);
    heff_drop(v_a_24467);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24470);
  }
}
V g_heff_2einterp_2eprim_lam44(V self, V *args) {
  V v_d_24459 = args[0];
  V v_a_24460 = args[1];
  V v_a_24458 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24461 = heff_tr(heff_apply(v_a_24460, 1, (V[]){v_d_24459}));
  switch (heff_tag_of(v_x1_24461)) {
  case TAG_Ok: {
    V v_v_24462 = heff_field(v_x1_24461, 0);
    V v_ru_24x1_24461_24Ok = heff_take_reuse_n(v_x1_24461, 1ULL, 1);
    switch (heff_tag_of(v_v_24462)) {
    case TAG_VFun: {
      heff_take_n(v_v_24462, 0ULL, 1);
      heff_drop(v_a_24458);
      heff_drop_cell(v_ru_24x1_24461_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24462, 0ULL, 1);
      heff_drop(v_a_24458);
      heff_drop_cell(v_ru_24x1_24461_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24462, 0ULL, 2);
      heff_drop(v_a_24458);
      heff_drop_cell(v_ru_24x1_24461_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24467 = heff_field(v_v_24462, 0);
      heff_take_n(v_v_24462, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_24461_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam45, 2, 2, (V[]){v_a_24458, v_a_24467})})});
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24462, 0ULL, 1);
      heff_drop(v_a_24458);
      heff_drop_cell(v_ru_24x1_24461_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24462, 0ULL, 1);
      heff_drop(v_a_24458);
      heff_drop_cell(v_ru_24x1_24461_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24462, 0ULL, 1);
      heff_drop(v_a_24458);
      heff_drop_cell(v_ru_24x1_24461_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24462, 0ULL, 1);
      heff_drop(v_a_24458);
      heff_drop_cell(v_ru_24x1_24461_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24462, 0ULL, 1);
      heff_drop(v_a_24458);
      heff_drop_cell(v_ru_24x1_24461_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_a_24458);
      heff_drop_cell(v_ru_24x1_24461_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24462);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24458);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24458);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24461);
  }
}
V g_heff_2einterp_2eprim_lam43(V self, V *args) {
  V v_d_24447 = args[0];
  V v_a_24448 = args[1];
  V v_x1_24449 = heff_tr(heff_apply(v_a_24448, 1, (V[]){v_d_24447}));
  switch (heff_tag_of(v_x1_24449)) {
  case TAG_Ok: {
    V v_v_24450 = heff_field(v_x1_24449, 0);
    V v_ru_24x1_24449_24Ok = heff_take_reuse_n(v_x1_24449, 1ULL, 1);
    switch (heff_tag_of(v_v_24450)) {
    case TAG_VFun: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24450, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      V v_a_24458 = heff_field(v_v_24450, 0);
      heff_take_n(v_v_24450, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_24449_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam44, 2, 1, (V[]){v_a_24458})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24450);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24449);
  }
}
V g_heff_2einterp_2eprim_lam46(V self, V *args) {
  V v_a_24491 = args[0];
  V v_b_24492 = args[1];
  V v_t_24494;
  if (heff_strEq_c(v_a_24491, v_b_24492)) {
    v_t_24494 = ((V)&g_heff_2einterp_2eprim_str57);
  } else {
    v_t_24494 = ((V)&g_heff_2einterp_2eprim_str58);
  }
  V v_t_24495 = heff_tag(TAG_VTag, 2, (V[]){v_t_24494, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_24495});
}
V g_heff_2einterp_2eprim_lam47(V self, V *args) {
  V v_a_24497 = args[0];
  V v_b_24498 = args[1];
  V v_t_24500;
  if (heff_strLt_c(v_a_24497, v_b_24498)) {
    v_t_24500 = ((V)&g_heff_2einterp_2eprim_str60);
  } else {
    v_t_24500 = ((V)&g_heff_2einterp_2eprim_str61);
  }
  V v_t_24501 = heff_tag(TAG_VTag, 2, (V[]){v_t_24500, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_24501});
}
V g_heff_2einterp_2eprim_lam49(V self, V *args) {
  V v_d_24515 = args[0];
  V v_a_24516 = args[1];
  V v_a_24514 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24517 = heff_tr(heff_apply(v_a_24516, 1, (V[]){v_d_24515}));
  switch (heff_tag_of(v_x1_24517)) {
  case TAG_Ok: {
    V v_v_24518 = heff_field(v_x1_24517, 0);
    V v_ru_24x1_24517_24Ok = heff_take_reuse_n(v_x1_24517, 1ULL, 1);
    switch (heff_tag_of(v_v_24518)) {
    case TAG_VFun: {
      heff_take_n(v_v_24518, 0ULL, 1);
      heff_drop(v_a_24514);
      heff_drop_cell(v_ru_24x1_24517_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24518, 0ULL, 1);
      heff_drop(v_a_24514);
      heff_drop_cell(v_ru_24x1_24517_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24518, 0ULL, 2);
      heff_drop(v_a_24514);
      heff_drop_cell(v_ru_24x1_24517_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24523 = heff_field(v_v_24518, 0);
      V v_ru_24v_24518_24VInt = heff_take_reuse_n(v_v_24518, 1ULL, 1);
      V v_t_24524 = heff_tag_at(v_ru_24x1_24517_24Ok, TAG_VInt, 1, (V[]){heff_strCharCode(v_a_24514, v_a_24523)});
      return heff_tag_at(v_ru_24v_24518_24VInt, TAG_Ok, 1, (V[]){v_t_24524});
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24518, 0ULL, 1);
      heff_drop(v_a_24514);
      heff_drop_cell(v_ru_24x1_24517_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24518, 0ULL, 1);
      heff_drop(v_a_24514);
      heff_drop_cell(v_ru_24x1_24517_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24518, 0ULL, 1);
      heff_drop(v_a_24514);
      heff_drop_cell(v_ru_24x1_24517_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24518, 0ULL, 1);
      heff_drop(v_a_24514);
      heff_drop_cell(v_ru_24x1_24517_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24518, 0ULL, 1);
      heff_drop(v_a_24514);
      heff_drop_cell(v_ru_24x1_24517_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_a_24514);
      heff_drop_cell(v_ru_24x1_24517_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24518);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24514);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24514);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24517);
  }
}
V g_heff_2einterp_2eprim_lam48(V self, V *args) {
  V v_d_24503 = args[0];
  V v_a_24504 = args[1];
  V v_x1_24505 = heff_tr(heff_apply(v_a_24504, 1, (V[]){v_d_24503}));
  switch (heff_tag_of(v_x1_24505)) {
  case TAG_Ok: {
    V v_v_24506 = heff_field(v_x1_24505, 0);
    V v_ru_24x1_24505_24Ok = heff_take_reuse_n(v_x1_24505, 1ULL, 1);
    switch (heff_tag_of(v_v_24506)) {
    case TAG_VFun: {
      heff_take_n(v_v_24506, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24505_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24506, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24505_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24506, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24505_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24506, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24505_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24506, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24505_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24506, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24505_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      V v_a_24514 = heff_field(v_v_24506, 0);
      heff_take_n(v_v_24506, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_24505_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam49, 2, 1, (V[]){v_a_24514})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24506, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24505_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24506, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24505_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24505_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24506);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24505);
  }
}
V g_heff_2einterp_2eprim_lam50(V self, V *args) {
  V v_d_24533 = args[0];
  V v_a_24534 = args[1];
  V v_x1_24535 = heff_tr(heff_apply(v_a_24534, 1, (V[]){v_d_24533}));
  switch (heff_tag_of(v_x1_24535)) {
  case TAG_Ok: {
    V v_v_24536 = heff_field(v_x1_24535, 0);
    V v_ru_24x1_24535_24Ok = heff_take_reuse_n(v_x1_24535, 1ULL, 1);
    switch (heff_tag_of(v_v_24536)) {
    case TAG_VFun: {
      heff_take_n(v_v_24536, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24535_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24536, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24535_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24536, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24535_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24541 = heff_field(v_v_24536, 0);
      V v_ru_24v_24536_24VInt = heff_take_reuse_n(v_v_24536, 1ULL, 1);
      V v_t_24542 = heff_tag_at(v_ru_24x1_24535_24Ok, TAG_VStr, 1, (V[]){heff_strFromCharCode(v_a_24541)});
      return heff_tag_at(v_ru_24v_24536_24VInt, TAG_Ok, 1, (V[]){v_t_24542});
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24536, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24535_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24536, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24535_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24536, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24535_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24536, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24535_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24536, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24535_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24535_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24536);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24535);
  }
}
V g_heff_2einterp_2eprim_lam51(V self, V *args) {
  V v_a_24549 = args[0];
  V v_b_24550 = args[1];
  V v_t_24552;
  if (heff_intEq_c(v_a_24549, v_b_24550)) {
    v_t_24552 = ((V)&g_heff_2einterp_2eprim_str65);
  } else {
    v_t_24552 = ((V)&g_heff_2einterp_2eprim_str66);
  }
  V v_t_24553 = heff_tag(TAG_VTag, 2, (V[]){v_t_24552, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_24553});
}
V g_heff_2einterp_2eprim_lam52(V self, V *args) {
  V v_a_24555 = args[0];
  V v_b_24556 = args[1];
  V v_t_24558;
  if (heff_intLt_c(v_a_24555, v_b_24556)) {
    v_t_24558 = ((V)&g_heff_2einterp_2eprim_str68);
  } else {
    v_t_24558 = ((V)&g_heff_2einterp_2eprim_str69);
  }
  V v_t_24559 = heff_tag(TAG_VTag, 2, (V[]){v_t_24558, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_24559});
}
V g_heff_2einterp_2eprim_lam53(V self, V *args) {
  V v_a_24561 = args[0];
  V v_b_24562 = args[1];
  V v_t_24564;
  if (heff_intLe_c(v_a_24561, v_b_24562)) {
    v_t_24564 = ((V)&g_heff_2einterp_2eprim_str71);
  } else {
    v_t_24564 = ((V)&g_heff_2einterp_2eprim_str72);
  }
  V v_t_24565 = heff_tag(TAG_VTag, 2, (V[]){v_t_24564, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_24565});
}
V g_heff_2einterp_2eprim_lam54(V self, V *args) {
  V v_d_24567 = args[0];
  V v_a_24568 = args[1];
  V v_x1_24569 = heff_tr(heff_apply(v_a_24568, 1, (V[]){v_d_24567}));
  switch (heff_tag_of(v_x1_24569)) {
  case TAG_Ok: {
    V v_v_24570 = heff_field(v_x1_24569, 0);
    V v_ru_24x1_24569_24Ok = heff_take_reuse_n(v_x1_24569, 1ULL, 1);
    switch (heff_tag_of(v_v_24570)) {
    case TAG_VFun: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24570, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      V v_a_24579 = heff_field(v_v_24570, 0);
      heff_take_n(v_v_24570, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_24569_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_a_24579})});
    }
    case TAG_VArr: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24570);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24569);
  }
}
V g_heff_2einterp_2eprim_lam55(V self, V *args) {
  V v_d_24582 = args[0];
  V v_a_24583 = args[1];
  V v_x1_24584 = heff_tr(heff_apply(v_a_24583, 1, (V[]){v_d_24582}));
  switch (heff_tag_of(v_x1_24584)) {
  case TAG_Ok: {
    V v_v_24585 = heff_field(v_x1_24584, 0);
    V v_ru_24x1_24584_24Ok = heff_take_reuse_n(v_x1_24584, 1ULL, 1);
    switch (heff_tag_of(v_v_24585)) {
    case TAG_VFun: {
      heff_take_n(v_v_24585, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24584_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24585, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24584_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24585, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24584_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24590 = heff_field(v_v_24585, 0);
      heff_take_n(v_v_24585, 1ULL, 1);
      V v_t_24591 = (g_heff_2efixed_2etwoTo(MK_INT(31LL)));
      V v_t_24592 = (g_heff_2efixed_2etwoTo(MK_INT(31LL)));
      V v_t_24593 = heff_intSub(v_a_24590, heff_intSub(MK_INT(0LL), v_t_24592));
      V v_t_24594 = (g_heff_2efixed_2etwoTo(MK_INT(32LL)));
      V v_t_24595 = heff_intMod(v_t_24593, v_t_24594);
      V v_t_24596 = heff_intAdd(heff_intSub(MK_INT(0LL), v_t_24591), v_t_24595);
      return heff_tag_at(v_ru_24x1_24584_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VRune, 1, (V[]){v_t_24596})});
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24585, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24584_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24585, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24584_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24585, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24584_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VRune: {
      heff_take_n(v_v_24585, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24584_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24585, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24584_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24584_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24585);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24584);
  }
}
V g_heff_2einterp_2eprim_lam56(V self, V *args) {
  V v_d_24603 = args[0];
  V v_a_24604 = args[1];
  V v_x1_24605 = heff_tr(heff_apply(v_a_24604, 1, (V[]){v_d_24603}));
  switch (heff_tag_of(v_x1_24605)) {
  case TAG_Ok: {
    V v_v_24606 = heff_field(v_x1_24605, 0);
    V v_ru_24x1_24605_24Ok = heff_take_reuse_n(v_x1_24605, 1ULL, 1);
    switch (heff_tag_of(v_v_24606)) {
    case TAG_VFun: {
      heff_take_n(v_v_24606, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24605_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24606, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24605_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24606, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24605_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24606, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24605_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24606, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24605_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24606, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24605_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      V v_a_24614 = heff_field(v_v_24606, 0);
      heff_take_n(v_v_24606, 1ULL, 1);
      V v_t_24615 = (g_heff_2erune_2edecodeFrom(v_a_24614, MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_24616 = (g_list_2emap_24s687660682x965950040(v_t_24615));
      return heff_tag_at(v_ru_24x1_24605_24Ok, TAG_Ok, 1, (V[]){(g_heff_2einterp_2etoListV(v_t_24616))});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24606, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24605_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24606, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24605_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24605_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24606);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24605);
  }
}
V g_heff_2einterp_2eprim_lam57(V self, V *args) {
  V v_d_24620 = args[0];
  V v_l_24621 = args[1];
  V v_x1_24622 = heff_tr(heff_apply(v_l_24621, 1, (V[]){v_d_24620}));
  switch (heff_tag_of(v_x1_24622)) {
  case TAG_Ok: {
    V v_v_24623 = heff_field(v_x1_24622, 0);
    V v_ru_24x1_24622_24Ok = heff_take_reuse_n(v_x1_24622, 1ULL, 1);
    V v_t_24624 = (g_heff_2einterp_2efromListV(v_v_24623, NTAG(TAG_Nil)));
    V v_cs_24625 = (g_heff_2einterp_2eruneCodes(v_t_24624));
    V v_x2_24626 = (g_list_2emap_24s1474012528x87063660(v_cs_24625));
    V v_t_24629;
    switch (heff_tag_of(v_x2_24626)) {
    case TAG_Nil: {
      v_t_24629 = ((V)&g_heff_2einterp_2eprim_str77);
      break;
    }
    case TAG_Cons: {
      V v_x_24627 = heff_field(v_x2_24626, 0);
      V v_xs_24628 = heff_field(v_x2_24626, 1);
      heff_take_n(v_x2_24626, 3ULL, 2);
      v_t_24629 = ({ V a_0 = ((V)&g_heff_2einterp_2eprim_str78); V a_1 = v_x_24627; V a_2 = v_xs_24628; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24628); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24626);
    }
    return heff_tag_at(v_ru_24x1_24622_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VStr, 1, (V[]){v_t_24629})});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24622);
  }
}
Clo g_heff_2einterp_2enthTh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2enthTh_entry, 2, 0};

V g_heff_2einterp_2enthTh(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      if (heff_intLt_c(heff_dup(v_i_241), MK_INT(0LL))) {
        heff_drop(v_i_241);
        return NTAG(TAG_Nothing);
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2enthTh_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2enthTh(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2einterp_2eevalEach_lam0(V self, V *args);
Clo g_heff_2einterp_2eevalEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eevalEach_entry, 3, 0};

V g_heff_2einterp_2eevalEach(V v_ev_240, V v_x2_241, V v_k_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ev_240);
    return heff_tail(v_k_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_t_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_x1_245 = heff_tr(heff_apply(heff_dup(v_ev_240), 1, (V[]){v_t_243}));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_Ok: {
      V v_v_246 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      V t_0 = v_ev_240;
      V t_1 = v_rest_244;
      V t_2 = heff_clo(g_heff_2einterp_2eevalEach_lam0, 1, 2, (V[]){v_k_242, v_v_246});
      v_ev_240 = t_0;
      v_x2_241 = t_1;
      v_k_242 = t_2;
      goto top;
    }
    case TAG_Abn: {
      heff_drop(v_ev_240);
      heff_drop(v_k_242);
      heff_drop(v_rest_244);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_ev_240);
      heff_drop(v_k_242);
      heff_drop(v_rest_244);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2einterp_2eevalEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eevalEach(a[0], a[1], a[2]);
}
V g_heff_2einterp_2eevalEach_lam0(V self, V *args) {
  V v_vs_247 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_v_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_242;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_v_246, v_vs_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2einterp_2eevalFields_lam0(V self, V *args);
Clo g_heff_2einterp_2eevalFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eevalFields_entry, 3, 0};

V g_heff_2einterp_2eevalFields(V v_ev_240, V v_x2_241, V v_k_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ev_240);
    return heff_tail(v_k_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkPair: {
      V v_l_245 = heff_field(v_x21_243, 0);
      V v_t_246 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      V v_x1_247 = heff_tr(heff_apply(heff_dup(v_ev_240), 1, (V[]){v_t_246}));
      switch (heff_tag_of(v_x1_247)) {
      case TAG_Ok: {
        V v_v_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V t_0 = v_ev_240;
        V t_1 = v_rest_244;
        V t_2 = heff_clo(g_heff_2einterp_2eevalFields_lam0, 1, 3, (V[]){v_l_245, v_v_248, v_k_242});
        v_ev_240 = t_0;
        v_x2_241 = t_1;
        v_k_242 = t_2;
        goto top;
      }
      case TAG_Abn: {
        heff_drop(v_ev_240);
        heff_drop(v_k_242);
        heff_drop(v_rest_244);
        heff_drop(v_l_245);
        return NTAG(TAG_Abn);
      }
      case TAG_Div: {
        heff_drop(v_ev_240);
        heff_drop(v_k_242);
        heff_drop(v_rest_244);
        heff_drop(v_l_245);
        return NTAG(TAG_Div);
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2einterp_2eevalFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eevalFields(a[0], a[1], a[2]);
}
V g_heff_2einterp_2eevalFields_lam0(V self, V *args) {
  V v_vs_249 = args[0];
  V v_l_245 = heff_env(self)[0];
  V v_v_248 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_l_245, v_v_248}), v_vs_249});
  V f_ = v_k_242;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2einterp_2eevalIn_lam0(V self, V *args);
V g_heff_2einterp_2eevalIn_lam1(V self, V *args);
V g_heff_2einterp_2eevalIn_lam2(V self, V *args);
V g_heff_2einterp_2eevalIn_lam3(V self, V *args);
V g_heff_2einterp_2eevalIn_lam4(V self, V *args); static Clo g_heff_2einterp_2eevalIn_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eevalIn_lam4, 1, 0};
V g_heff_2einterp_2eevalIn_lam5(V self, V *args);
V g_heff_2einterp_2eevalIn_lam6(V self, V *args);
V g_heff_2einterp_2eevalIn_lam7(V self, V *args);
Clo g_heff_2einterp_2eevalIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eevalIn_entry, 3, 0};

V g_heff_2einterp_2eevalIn(V v_d_240, V v_e_241, V v_t_242) {
top: ;
  if (heff_intLt_c(heff_dup(g_heff_2einterp_2edeepest_get()), heff_dup(v_d_240))) {
    heff_drop(v_d_240);
    heff_drop(v_e_241);
    heff_drop(v_t_242);
    return NTAG(TAG_Div);
  } else {
    switch (heff_tag_of(v_t_242)) {
    case TAG_SLocal: {
      V v_i_244 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V v_t_245 = ({ V b_0 = heff_get(v_e_241, LBL_local); V a_1 = v_i_244; V r_ = (g_heff_2einterp_2enthTh(b_0, a_1)); heff_drop(b_0); r_; });
      switch (heff_tag_of(v_t_245)) {
      case TAG_Nothing: {
        heff_drop(v_d_240);
        return heff_abandon();
      }
      case TAG_Just: {
        V v_v_246 = heff_field(v_t_245, 0);
        heff_take_n(v_t_245, 1ULL, 1);
        return heff_tail(v_v_246, 1, (V[]){v_d_240});
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    case TAG_SGlobal: {
      V v_x_247 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V v_t_248 = ({ V a_0 = v_x_247; V b_1 = heff_get(v_e_241, LBL_global); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nothing: {
        heff_drop(v_d_240);
        return heff_abandon();
      }
      case TAG_Just: {
        V v_v_249 = heff_field(v_t_248, 0);
        heff_take_n(v_t_248, 1ULL, 1);
        return heff_tail(v_v_249, 1, (V[]){v_d_240});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    case TAG_SCode: {
      V v_ru_24t_242_24SCode = heff_take_reuse_n(v_t_242, 0ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag_at(v_ru_24t_242_24SCode, TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
    }
    case TAG_SApp: {
      V v_t1_2411 = heff_field(v_t_242, 0);
      V v_t2_2412 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      V v_x1_2413 = heff_tr(g_heff_2einterp_2eevalIn(heff_intAdd(heff_dup(v_d_240), MK_INT(1LL)), heff_dup(v_e_241), v_t1_2411));
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_Ok: {
        V v_v_2414 = heff_field(v_x1_2413, 0);
        V v_ru_24x1_2413_24Ok = heff_take_reuse_n(v_x1_2413, 1ULL, 1);
        V v_x1_2415 = heff_tr(g_heff_2einterp_2eevalIn(heff_intAdd(heff_dup(v_d_240), MK_INT(1LL)), v_e_241, v_t2_2412));
        switch (heff_tag_of(v_x1_2415)) {
        case TAG_Ok: {
          V v_v_2416 = heff_field(v_x1_2415, 0);
          heff_take_n(v_x1_2415, 1ULL, 1);
          switch (heff_tag_of(v_v_2414)) {
          case TAG_VFun: {
            V v_f_2417 = heff_field(v_v_2414, 0);
            heff_take_n(v_v_2414, 1ULL, 1);
            heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
            return heff_tail(v_f_2417, 2, (V[]){v_d_240, heff_clo(g_heff_2einterp_2eevalIn_lam0, 1, 1, (V[]){v_v_2416})});
          }
          case TAG_VCons: {
            heff_take_n(v_v_2414, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VTag: {
            heff_take_n(v_v_2414, 0ULL, 2);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VInt: {
            heff_take_n(v_v_2414, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VFloat: {
            heff_take_n(v_v_2414, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VFloat32: {
            heff_take_n(v_v_2414, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VStr: {
            heff_take_n(v_v_2414, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VRune: {
            heff_take_n(v_v_2414, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VArr: {
            heff_take_n(v_v_2414, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VErased: {
            heff_drop(v_d_240);
            heff_drop(v_v_2416);
            return heff_tag_at(v_ru_24x1_2413_24Ok, TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
          }
          default: return heff_nomatch(v_v_2414);
          }
        }
        case TAG_Abn: {
          heff_drop(v_d_240);
          heff_drop(v_v_2414);
          heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
          return NTAG(TAG_Abn);
        }
        case TAG_Div: {
          heff_drop(v_d_240);
          heff_drop(v_v_2414);
          heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
          return NTAG(TAG_Div);
        }
        default: return heff_nomatch(v_x1_2415);
        }
      }
      case TAG_Abn: {
        heff_drop(v_d_240);
        heff_drop(v_e_241);
        heff_drop(v_t2_2412);
        return NTAG(TAG_Abn);
      }
      case TAG_Div: {
        heff_drop(v_d_240);
        heff_drop(v_e_241);
        heff_drop(v_t2_2412);
        return NTAG(TAG_Div);
      }
      default: return heff_nomatch(v_x1_2413);
      }
    }
    case TAG_SLam: {
      V v_it2_2429 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 2ULL, 2);
      heff_drop(v_d_240);
      switch (heff_tag_of(v_it2_2429)) {
      case TAG_MkAbs: {
        V v_body_2431 = heff_field(v_it2_2429, 1);
        heff_take_n(v_it2_2429, 2ULL, 2);
        return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eevalIn_lam1, 2, 2, (V[]){v_e_241, v_body_2431})})});
      }
      case TAG_AbsConst: {
        V v_body_2436 = heff_field(v_it2_2429, 0);
        V v_ru_24it2_2429_24AbsConst = heff_take_reuse_n(v_it2_2429, 1ULL, 1);
        return heff_tag_at(v_ru_24it2_2429_24AbsConst, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eevalIn_lam2, 2, 2, (V[]){v_e_241, v_body_2436})})});
      }
      default: return heff_nomatch(v_it2_2429);
      }
    }
    case TAG_SCons: {
      V v_fs_2439 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V v_t_2440 = heff_arrayToList(heff_get(heff_dup(v_fs_2439), LBL_keys));
      V v_t_2441 = heff_arrayToList(heff_get(v_fs_2439, LBL_values));
      V v_t_2442 = (g_heff_2edict_2ezipKV(v_t_2440, v_t_2441));
      HEFF_LAST return g_heff_2einterp_2eevalFields(heff_clo(g_heff_2einterp_2eevalIn_lam3, 1, 2, (V[]){v_d_240, v_e_241}), v_t_2442, ((V)&g_heff_2einterp_2eevalIn_lam4_clo));
    }
    case TAG_SProj: {
      V v_t2_2449 = heff_field(v_t_242, 0);
      V v_x_2450 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      V v_x1_2451 = heff_tr(g_heff_2einterp_2eevalIn(heff_intAdd(v_d_240, MK_INT(1LL)), v_e_241, v_t2_2449));
      switch (heff_tag_of(v_x1_2451)) {
      case TAG_Ok: {
        V v_v_2452 = heff_field(v_x1_2451, 0);
        heff_take_n(v_x1_2451, 1ULL, 1);
        return (g_heff_2einterp_2eprojV(v_v_2452, v_x_2450));
      }
      case TAG_Abn: {
        heff_drop(v_x_2450);
        return NTAG(TAG_Abn);
      }
      case TAG_Div: {
        heff_drop(v_x_2450);
        return NTAG(TAG_Div);
      }
      default: return heff_nomatch(v_x1_2451);
      }
    }
    case TAG_STag: {
      V v_x_2453 = heff_field(v_t_242, 0);
      V v_ts_2454 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      HEFF_LAST return g_heff_2einterp_2eevalEach(heff_clo(g_heff_2einterp_2eevalIn_lam5, 1, 2, (V[]){v_d_240, v_e_241}), heff_arrayToList(v_ts_2454), heff_clo(g_heff_2einterp_2eevalIn_lam6, 1, 1, (V[]){v_x_2453}));
    }
    case TAG_SMatch: {
      V v_scrut_2457 = heff_field(v_t_242, 0);
      V v_cases_2458 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      V v_x1_2459 = heff_tr(g_heff_2einterp_2eevalIn(heff_intAdd(heff_dup(v_d_240), MK_INT(1LL)), heff_dup(v_e_241), v_scrut_2457));
      switch (heff_tag_of(v_x1_2459)) {
      case TAG_Ok: {
        V v_v_2460 = heff_field(v_x1_2459, 0);
        V v_ru_24x1_2459_24Ok = heff_take_reuse_n(v_x1_2459, 1ULL, 1);
        switch (heff_tag_of(v_v_2460)) {
        case TAG_VFun: {
          heff_take_n(v_v_2460, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2458);
          heff_drop_cell(v_ru_24x1_2459_24Ok, 1);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_2460, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2458);
          heff_drop_cell(v_ru_24x1_2459_24Ok, 1);
          return heff_abandon();
        }
        case TAG_VTag: {
          V v_x_2463 = heff_field(v_v_2460, 0);
          V v_vs_2464 = heff_field(v_v_2460, 1);
          heff_take_n(v_v_2460, 3ULL, 2);
          V v_t_2465 = ({ V a_0 = v_x_2463; V b_1 = heff_get(heff_dup(v_cases_2458), LBL_byName); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
          V v_it_2471;
          switch (heff_tag_of(v_t_2465)) {
          case TAG_Nothing: {
            heff_drop(v_cases_2458);
            heff_drop_cell(v_ru_24x1_2459_24Ok, 1);
            v_it_2471 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_i_2466 = heff_field(v_t_2465, 0);
            heff_take_n(v_t_2465, 1ULL, 1);
            V v_xs_2467 = heff_get(v_cases_2458, LBL_values);
            if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_2466))) {
              if (heff_intLt_c(heff_dup(v_i_2466), heff_arrayLength(heff_dup(v_xs_2467)))) {
                V v_t_2470 = heff_arrayIndex(v_xs_2467, v_i_2466);
                v_it_2471 = heff_tag_at(v_ru_24x1_2459_24Ok, TAG_Just, 1, (V[]){v_t_2470});
              } else {
                heff_drop_cell(v_ru_24x1_2459_24Ok, 1);
                heff_drop(v_i_2466);
                heff_drop(v_xs_2467);
                v_it_2471 = NTAG(TAG_Nothing);
              }
            } else {
              heff_drop_cell(v_ru_24x1_2459_24Ok, 1);
              heff_drop(v_i_2466);
              heff_drop(v_xs_2467);
              v_it_2471 = NTAG(TAG_Nothing);
            }
            break;
          }
          default: heff_nomatch(v_t_2465);
          }
          switch (heff_tag_of(v_it_2471)) {
          case TAG_Nothing: {
            heff_drop(v_d_240);
            heff_drop(v_e_241);
            heff_drop(v_vs_2464);
            return heff_abandon();
          }
          case TAG_Just: {
            V v_it1_2472 = heff_field(v_it_2471, 0);
            heff_take_n(v_it_2471, 1ULL, 1);
            switch (heff_tag_of(v_it1_2472)) {
            case TAG_MkPair: {
              V v_body_2474 = heff_field(v_it1_2472, 1);
              heff_take_n(v_it1_2472, 2ULL, 2);
              V v_t_2475 = (g_list_2efoldl_24s2049334416x2039919674(v_e_241, v_vs_2464));
              V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
              V t_1 = v_t_2475;
              V t_2 = v_body_2474;
              v_d_240 = t_0;
              v_e_241 = t_1;
              v_t_242 = t_2;
              goto top;
            }
            default: return heff_nomatch(v_it1_2472);
            }
          }
          default: return heff_nomatch(v_it_2471);
          }
        }
        case TAG_VInt: {
          heff_take_n(v_v_2460, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2458);
          heff_drop_cell(v_ru_24x1_2459_24Ok, 1);
          return heff_abandon();
        }
        case TAG_VFloat: {
          heff_take_n(v_v_2460, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2458);
          heff_drop_cell(v_ru_24x1_2459_24Ok, 1);
          return heff_abandon();
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_2460, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2458);
          heff_drop_cell(v_ru_24x1_2459_24Ok, 1);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take_n(v_v_2460, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2458);
          heff_drop_cell(v_ru_24x1_2459_24Ok, 1);
          return heff_abandon();
        }
        case TAG_VRune: {
          heff_take_n(v_v_2460, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2458);
          heff_drop_cell(v_ru_24x1_2459_24Ok, 1);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_2460, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2458);
          heff_drop_cell(v_ru_24x1_2459_24Ok, 1);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2458);
          return heff_tag_at(v_ru_24x1_2459_24Ok, TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
        }
        default: return heff_nomatch(v_v_2460);
        }
      }
      case TAG_Abn: {
        heff_drop(v_d_240);
        heff_drop(v_e_241);
        heff_drop(v_cases_2458);
        return NTAG(TAG_Abn);
      }
      case TAG_Div: {
        heff_drop(v_d_240);
        heff_drop(v_e_241);
        heff_drop(v_cases_2458);
        return NTAG(TAG_Div);
      }
      default: return heff_nomatch(v_x1_2459);
      }
    }
    case TAG_SSpecialize: {
      heff_take_n(v_t_242, 0ULL, 3);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
    }
    case TAG_SIs: {
      V v_t2_2485 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
      V t_1 = v_e_241;
      V t_2 = v_t2_2485;
      v_d_240 = t_0;
      v_e_241 = t_1;
      v_t_242 = t_2;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_abandon();
    }
    case TAG_SAbandon: {
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return NTAG(TAG_Abn);
    }
    case TAG_SRec: {
      V v_t2_2486 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
      V t_1 = v_e_241;
      V t_2 = v_t2_2486;
      v_d_240 = t_0;
      v_e_241 = t_1;
      v_t_242 = t_2;
      goto top;
    }
    case TAG_SFix: {
      V v_ty_2487 = heff_field(v_t_242, 0);
      V v_it2_2488 = heff_field(v_t_242, 1);
      V v_ru_24t_242_24SFix = heff_take_reuse_n(v_t_242, 3ULL, 2);
      switch (heff_tag_of(v_it2_2488)) {
      case TAG_MkAbs: {
        V v_x_2489 = heff_field(v_it2_2488, 0);
        V v_body_2490 = heff_field(v_it2_2488, 1);
        heff_take_n(v_it2_2488, 3ULL, 2);
        V v_t_2493 = heff_tag_at(v_ru_24t_242_24SFix, TAG_Cons, 2, (V[]){heff_clo(g_heff_2einterp_2eevalIn_lam7, 1, 4, (V[]){v_ty_2487, v_x_2489, heff_dup(v_body_2490), heff_dup(v_e_241)}), heff_get(heff_dup(v_e_241), LBL_local)});
        V v_t_2494 = heff_rec(2, shape_local__global, (V[]){v_t_2493, heff_get(v_e_241, LBL_global)});
        V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
        V t_1 = v_t_2494;
        V t_2 = v_body_2490;
        v_d_240 = t_0;
        v_e_241 = t_1;
        v_t_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_body_2495 = heff_field(v_it2_2488, 0);
        heff_take_n(v_it2_2488, 1ULL, 1);
        heff_drop(v_ty_2487);
        heff_drop_cell(v_ru_24t_242_24SFix, 2);
        V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
        V t_1 = v_e_241;
        V t_2 = v_body_2495;
        v_d_240 = t_0;
        v_e_241 = t_1;
        v_t_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_it2_2488);
      }
    }
    case TAG_SImplicit: {
      V v_t2_2497 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 2ULL, 2);
      V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
      V t_1 = v_e_241;
      V t_2 = v_t2_2497;
      v_d_240 = t_0;
      v_e_241 = t_1;
      v_t_242 = t_2;
      goto top;
    }
    case TAG_SPrim: {
      V v_x_2498 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SPrim = heff_take_reuse_n(v_t_242, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag_at(v_ru_24t_242_24SPrim, TAG_Ok, 1, (V[]){(g_heff_2einterp_2eprim(v_x_2498))});
    }
    case TAG_SMetaApp: {
      heff_take_n(v_t_242, 0ULL, 3);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_abandon();
    }
    case TAG_SLitInt: {
      V v_i_24102 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SLitInt = heff_take_reuse_n(v_t_242, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag_at(v_ru_24t_242_24SLitInt, TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_i_24102})});
    }
    case TAG_SLitFloat: {
      V v_x_24103 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SLitFloat = heff_take_reuse_n(v_t_242, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag_at(v_ru_24t_242_24SLitFloat, TAG_Ok, 1, (V[]){heff_tag(TAG_VFloat, 1, (V[]){v_x_24103})});
    }
    case TAG_SLitString: {
      V v_s_24104 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SLitString = heff_take_reuse_n(v_t_242, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag_at(v_ru_24t_242_24SLitString, TAG_Ok, 1, (V[]){heff_tag(TAG_VStr, 1, (V[]){v_s_24104})});
    }
    case TAG_SLitRune: {
      V v_c_24105 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SLitRune = heff_take_reuse_n(v_t_242, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag_at(v_ru_24t_242_24SLitRune, TAG_Ok, 1, (V[]){heff_tag(TAG_VRune, 1, (V[]){v_c_24105})});
    }
    case TAG_SLitFixed: {
      V v_i_24107 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 2ULL, 2);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_i_24107})});
    }
    case TAG_SLitFloat32: {
      V v_x_24108 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SLitFloat32 = heff_take_reuse_n(v_t_242, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      V v_t_24109 = heff_tag_at(v_ru_24t_242_24SLitFloat32, TAG_VFloat32, 1, (V[]){heff_float32FromFloat(v_x_24108)});
      return heff_tag(TAG_Ok, 1, (V[]){v_t_24109});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
}
V g_heff_2einterp_2eevalIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eevalIn(a[0], a[1], a[2]);
}
V g_heff_2einterp_2eevalIn_lam0(V self, V *args) {
  V v_d_2418 = args[0];
  V v_v_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_2418);
  return heff_tag(TAG_Ok, 1, (V[]){v_v_2416});
}
V g_heff_2einterp_2eevalIn_lam1(V self, V *args) {
  V v_dc_2432 = args[0];
  V v_v_2433 = args[1];
  V v_e_241 = heff_env(self)[0];
  V v_body_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_tag(TAG_Cons, 2, (V[]){v_v_2433, heff_get(heff_dup(v_e_241), LBL_local)});
  V v_t_2435 = heff_rec(2, shape_local__global, (V[]){v_t_2434, heff_get(v_e_241, LBL_global)});
  return (g_heff_2einterp_2eevalIn(heff_intAdd(v_dc_2432, MK_INT(1LL)), v_t_2435, v_body_2431));
}
V g_heff_2einterp_2eevalIn_lam2(V self, V *args) {
  V v_dc_2437 = args[0];
  V v_u_2438 = args[1];
  V v_e_241 = heff_env(self)[0];
  V v_body_2436 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2438);
  return (g_heff_2einterp_2eevalIn(heff_intAdd(v_dc_2437, MK_INT(1LL)), v_e_241, v_body_2436));
}
V g_heff_2einterp_2eevalIn_lam3(V self, V *args) {
  V v_t2_2443 = args[0];
  V v_d_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2einterp_2eevalIn(heff_intAdd(v_d_240, MK_INT(1LL)), v_e_241, v_t2_2443));
}
V g_heff_2einterp_2eevalIn_lam4(V self, V *args) {
  V v_vs_2444 = args[0];
  V v_t_2445 = (g_list_2emap_24s1415906091x1371825187(heff_dup(v_vs_2444)));
  V v_t_2446 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_vs_2444));
  V v_t_2447 = (g_list_2emap_24s366344330x1145113647(v_vs_2444));
  V v_t_2448 = heff_rec(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2445), v_t_2446, heff_arrayFromList(v_t_2447)});
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VCons, 1, (V[]){v_t_2448})});
}
V g_heff_2einterp_2eevalIn_lam5(V self, V *args) {
  V v_t2_2455 = args[0];
  V v_d_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2einterp_2eevalIn(heff_intAdd(v_d_240, MK_INT(1LL)), v_e_241, v_t2_2455));
}
V g_heff_2einterp_2eevalIn_lam6(V self, V *args) {
  V v_vs_2456 = args[0];
  V v_x_2453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VTag, 2, (V[]){v_x_2453, v_vs_2456})});
}
V g_heff_2einterp_2eevalIn_lam7(V self, V *args) {
  V v_dc_2491 = args[0];
  V v_ty_2487 = heff_env(self)[0];
  V v_x_2489 = heff_env(self)[1];
  V v_body_2490 = heff_env(self)[2];
  V v_e_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2492 = heff_tag(TAG_SFix, 2, (V[]){v_ty_2487, heff_tag(TAG_MkAbs, 2, (V[]){v_x_2489, v_body_2490})});
  return (g_heff_2einterp_2eevalIn(v_dc_2491, v_e_241, v_t_2492));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eescAt_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eescAt_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eescAt_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eescAt_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eescAt_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 116}};
Clo g_heff_2einterp_2eescAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eescAt_entry, 2, 0};

V g_heff_2einterp_2eescAt(V v_s_240, V v_i_241) {
top: ;
  if (heff_intEq_c(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(34LL))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return ((V)&g_heff_2einterp_2eescAt_str0);
  } else {
    if (heff_intEq_c(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(92LL))) {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      return ((V)&g_heff_2einterp_2eescAt_str1);
    } else {
      if (heff_intEq_c(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(10LL))) {
        heff_drop(v_s_240);
        heff_drop(v_i_241);
        return ((V)&g_heff_2einterp_2eescAt_str2);
      } else {
        if (heff_intEq_c(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(13LL))) {
          heff_drop(v_s_240);
          heff_drop(v_i_241);
          return ((V)&g_heff_2einterp_2eescAt_str3);
        } else {
          if (heff_intEq_c(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(9LL))) {
            heff_drop(v_s_240);
            heff_drop(v_i_241);
            return ((V)&g_heff_2einterp_2eescAt_str4);
          } else {
            return heff_strSlice(v_s_240, heff_dup(v_i_241), heff_intAdd(v_i_241, MK_INT(1LL)));
          }
        }
      }
    }
  }
}
V g_heff_2einterp_2eescAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eescAt(a[0], a[1]);
}
Clo g_heff_2einterp_2equoteGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2equoteGo_entry, 3, 0};

V g_heff_2einterp_2equoteGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return v_acc_242;
  } else {
    V v_t_244 = heff_strAppend(v_acc_242, (g_heff_2einterp_2eescAt(heff_dup(v_s_240), heff_dup(v_i_241))));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_244;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2einterp_2equoteGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2equoteGo(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2escalarV_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2escalarV_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2escalarV_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2escalarV_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2escalarV_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2escalarV_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2escalarV_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {39}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2escalarV_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {39}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2escalarV_str8 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2escalarV_str9 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
Clo g_heff_2einterp_2escalarV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2escalarV_entry, 1, 0};

V g_heff_2einterp_2escalarV(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    return ((V)&g_heff_2einterp_2escalarV_str0);
  }
  case TAG_VCons: {
    return ((V)&g_heff_2einterp_2escalarV_str1);
  }
  case TAG_VTag: {
    return ((V)&g_heff_2einterp_2escalarV_str2);
  }
  case TAG_VInt: {
    V v_i_245 = heff_field(v_x1_240, 0);
    return heff_intShow(heff_dup(v_i_245));
  }
  case TAG_VFloat: {
    V v_x_246 = heff_field(v_x1_240, 0);
    return heff_floatShow(heff_dup(v_x_246));
  }
  case TAG_VFloat32: {
    V v_x_247 = heff_field(v_x1_240, 0);
    return heff_float32Show(heff_dup(v_x_247));
  }
  case TAG_VStr: {
    V v_s_248 = heff_field(v_x1_240, 0);
    V v_t_249 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_248), MK_INT(0LL), ((V)&g_heff_2einterp_2escalarV_str3)));
    return heff_strAppend(((V)&g_heff_2einterp_2escalarV_str4), heff_strAppend(v_t_249, ((V)&g_heff_2einterp_2escalarV_str5)));
  }
  case TAG_VRune: {
    V v_c_2410 = heff_field(v_x1_240, 0);
    V v_t_2411 = (g_heff_2erune_2equoted(heff_dup(v_c_2410)));
    return heff_strAppend(((V)&g_heff_2einterp_2escalarV_str6), heff_strAppend(v_t_2411, ((V)&g_heff_2einterp_2escalarV_str7)));
  }
  case TAG_VArr: {
    return ((V)&g_heff_2einterp_2escalarV_str8);
  }
  case TAG_VErased: {
    return ((V)&g_heff_2einterp_2escalarV_str9);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2escalarV_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2escalarV(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2einterp_2eshowValGo_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eshowValGo_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eshowValGo_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {123, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eshowValGo_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str14 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str15 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str31 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eshowValGo_str32 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str36 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str37 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2einterp_2eshowValGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eshowValGo_entry, 2, 0};

V g_heff_2einterp_2eshowValGo(V v_inArg_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_VFun: {
    switch (heff_tag_of(v_inArg_240)) {
    case TAG_True: {
      V v_s_243 = (g_heff_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_243, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2einterp_2eshowValGo_str0))) {
        V v_t_245 = (g_heff_2einterp_2escalarV(v_v_241));
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str1), heff_strAppend(v_t_245, ((V)&g_heff_2einterp_2eshowValGo_str2)));
      } else {
        return (g_heff_2einterp_2escalarV(v_v_241));
      }
    }
    case TAG_False: {
      return (g_heff_2einterp_2escalarV(v_v_241));
    }
    default: return heff_nomatch(v_inArg_240);
    }
  }
  case TAG_VCons: {
    V v_fs_246 = heff_field(v_v_241, 0);
    V v_t_247 = heff_arrayToList(heff_get(heff_dup(v_fs_246), LBL_keys));
    V v_t_248 = heff_arrayToList(heff_get(heff_dup(v_fs_246), LBL_values));
    V v_t_249 = (g_heff_2edict_2ezipKV(v_t_247, v_t_248));
    V v_x2_2410 = (g_list_2emap_24s1070305723x611506852(((V)&g_heff_2einterp_2eshowValGo_str3), v_t_249));
    V v_t_2413;
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2einterp_2eshowValGo_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_xs_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      v_t_2413 = ({ V a_0 = ((V)&g_heff_2einterp_2eshowValGo_str5); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2410);
    }
    return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str6), heff_strAppend(v_t_2413, ((V)&g_heff_2einterp_2eshowValGo_str7)));
  }
  case TAG_VTag: {
    V v_x_2414 = heff_field(v_v_241, 0);
    V v_vs_2415 = heff_field(v_v_241, 1);
    switch (heff_tag_of(v_vs_2415)) {
    case TAG_Nil: {
      return heff_dup(v_x_2414);
    }
    case TAG_Cons: {
      switch (heff_tag_of(v_inArg_240)) {
      case TAG_True: {
        V v_x2_2418 = (g_list_2emap_24s517793000x1987655475(((V)&g_heff_2einterp_2eshowValGo_str8), heff_dup(v_vs_2415)));
        V v_t_2421;
        switch (heff_tag_of(v_x2_2418)) {
        case TAG_Nil: {
          v_t_2421 = ((V)&g_heff_2einterp_2eshowValGo_str9);
          break;
        }
        case TAG_Cons: {
          V v_x_2419 = heff_field(v_x2_2418, 0);
          V v_xs_2420 = heff_field(v_x2_2418, 1);
          heff_take_n(v_x2_2418, 3ULL, 2);
          v_t_2421 = ({ V a_0 = ((V)&g_heff_2einterp_2eshowValGo_str10); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2418);
        }
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str11), heff_strAppend(heff_dup(v_x_2414), heff_strAppend(v_t_2421, ((V)&g_heff_2einterp_2eshowValGo_str12))));
      }
      case TAG_False: {
        V v_x2_2422 = (g_list_2emap_24s517793000x1987655475(((V)&g_heff_2einterp_2eshowValGo_str13), heff_dup(v_vs_2415)));
        V v_t_2425;
        switch (heff_tag_of(v_x2_2422)) {
        case TAG_Nil: {
          v_t_2425 = ((V)&g_heff_2einterp_2eshowValGo_str14);
          break;
        }
        case TAG_Cons: {
          V v_x_2423 = heff_field(v_x2_2422, 0);
          V v_xs_2424 = heff_field(v_x2_2422, 1);
          heff_take_n(v_x2_2422, 3ULL, 2);
          v_t_2425 = ({ V a_0 = ((V)&g_heff_2einterp_2eshowValGo_str15); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2422);
        }
        return heff_strAppend(heff_dup(v_x_2414), v_t_2425);
      }
      default: return heff_nomatch(v_inArg_240);
      }
    }
    default: return heff_nomatch(v_vs_2415);
    }
  }
  case TAG_VInt: {
    switch (heff_tag_of(v_inArg_240)) {
    case TAG_True: {
      V v_s_2427 = (g_heff_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2427, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2einterp_2eshowValGo_str16))) {
        V v_t_2429 = (g_heff_2einterp_2escalarV(v_v_241));
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str17), heff_strAppend(v_t_2429, ((V)&g_heff_2einterp_2eshowValGo_str18)));
      } else {
        return (g_heff_2einterp_2escalarV(v_v_241));
      }
    }
    case TAG_False: {
      return (g_heff_2einterp_2escalarV(v_v_241));
    }
    default: return heff_nomatch(v_inArg_240);
    }
  }
  case TAG_VFloat: {
    switch (heff_tag_of(v_inArg_240)) {
    case TAG_True: {
      V v_s_2431 = (g_heff_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2431, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2einterp_2eshowValGo_str19))) {
        V v_t_2433 = (g_heff_2einterp_2escalarV(v_v_241));
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str20), heff_strAppend(v_t_2433, ((V)&g_heff_2einterp_2eshowValGo_str21)));
      } else {
        return (g_heff_2einterp_2escalarV(v_v_241));
      }
    }
    case TAG_False: {
      return (g_heff_2einterp_2escalarV(v_v_241));
    }
    default: return heff_nomatch(v_inArg_240);
    }
  }
  case TAG_VFloat32: {
    switch (heff_tag_of(v_inArg_240)) {
    case TAG_True: {
      V v_s_2435 = (g_heff_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2435, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2einterp_2eshowValGo_str22))) {
        V v_t_2437 = (g_heff_2einterp_2escalarV(v_v_241));
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str23), heff_strAppend(v_t_2437, ((V)&g_heff_2einterp_2eshowValGo_str24)));
      } else {
        return (g_heff_2einterp_2escalarV(v_v_241));
      }
    }
    case TAG_False: {
      return (g_heff_2einterp_2escalarV(v_v_241));
    }
    default: return heff_nomatch(v_inArg_240);
    }
  }
  case TAG_VStr: {
    switch (heff_tag_of(v_inArg_240)) {
    case TAG_True: {
      V v_s_2439 = (g_heff_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2439, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2einterp_2eshowValGo_str25))) {
        V v_t_2441 = (g_heff_2einterp_2escalarV(v_v_241));
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str26), heff_strAppend(v_t_2441, ((V)&g_heff_2einterp_2eshowValGo_str27)));
      } else {
        return (g_heff_2einterp_2escalarV(v_v_241));
      }
    }
    case TAG_False: {
      return (g_heff_2einterp_2escalarV(v_v_241));
    }
    default: return heff_nomatch(v_inArg_240);
    }
  }
  case TAG_VRune: {
    switch (heff_tag_of(v_inArg_240)) {
    case TAG_True: {
      V v_s_2443 = (g_heff_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2443, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2einterp_2eshowValGo_str28))) {
        V v_t_2445 = (g_heff_2einterp_2escalarV(v_v_241));
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str29), heff_strAppend(v_t_2445, ((V)&g_heff_2einterp_2eshowValGo_str30)));
      } else {
        return (g_heff_2einterp_2escalarV(v_v_241));
      }
    }
    case TAG_False: {
      return (g_heff_2einterp_2escalarV(v_v_241));
    }
    default: return heff_nomatch(v_inArg_240);
    }
  }
  case TAG_VArr: {
    V v_xs_2446 = heff_field(v_v_241, 0);
    V v_x2_2447 = (g_list_2emap_24s115901570x2012684568(heff_arrayToList(heff_dup(v_xs_2446))));
    V v_t_2450;
    switch (heff_tag_of(v_x2_2447)) {
    case TAG_Nil: {
      v_t_2450 = ((V)&g_heff_2einterp_2eshowValGo_str31);
      break;
    }
    case TAG_Cons: {
      V v_x_2448 = heff_field(v_x2_2447, 0);
      V v_xs_2449 = heff_field(v_x2_2447, 1);
      heff_take_n(v_x2_2447, 3ULL, 2);
      v_t_2450 = ({ V a_0 = ((V)&g_heff_2einterp_2eshowValGo_str32); V a_1 = v_x_2448; V a_2 = v_xs_2449; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2449); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2447);
    }
    return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str33), heff_strAppend(v_t_2450, ((V)&g_heff_2einterp_2eshowValGo_str34)));
  }
  case TAG_VErased: {
    switch (heff_tag_of(v_inArg_240)) {
    case TAG_True: {
      V v_s_2451 = (g_heff_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2451, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2einterp_2eshowValGo_str35))) {
        V v_t_2453 = (g_heff_2einterp_2escalarV(v_v_241));
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str36), heff_strAppend(v_t_2453, ((V)&g_heff_2einterp_2eshowValGo_str37)));
      } else {
        return (g_heff_2einterp_2escalarV(v_v_241));
      }
    }
    case TAG_False: {
      return (g_heff_2einterp_2escalarV(v_v_241));
    }
    default: return heff_nomatch(v_inArg_240);
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2einterp_2eshowValGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2eshowValGo(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2einterp_2efixThunk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efixThunk_entry, 3, 0};

V g_heff_2einterp_2efixThunk(V v_g_240, V v_t_241, V v_d_242) {
top: ;
  V v_t_243 = heff_tr(heff_apply(((V)&g_heff_2einterp_2efixThunk_clo), 2, (V[]){heff_dup(v_g_240), heff_dup(v_t_241)}));
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  HEFF_LAST return g_heff_2einterp_2eevalIn(heff_intAdd(v_d_242, MK_INT(1LL)), heff_rec(2, shape_local__global, (V[]){v_t_244, v_g_240}), v_t_241);
}
V g_heff_2einterp_2efixThunk_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2efixThunk(a[0], a[1], a[2]);
}
V g_heff_2einterp_2eevalGlobalsGo_lam0(V self, V *args);
Clo g_heff_2einterp_2eevalGlobalsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eevalGlobalsGo_entry, 4, 0};

V g_heff_2einterp_2eevalGlobalsGo(V v_wanted_240, V v_ge_241, V v_x3_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_wanted_240);
    heff_drop(v_ge_241);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x31_244, 0);
      V v_entry_247 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      V v_r_248 = heff_tr(g_heff_2einterp_2efixThunk(heff_dup(v_ge_241), heff_get(v_entry_247, LBL_syntax), MK_INT(0LL)));
      V v_t_2410 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_246), heff_clo(g_heff_2einterp_2eevalGlobalsGo_lam0, 1, 1, (V[]){heff_dup(v_r_248)}), v_ge_241));
      V v_t_2411 = heff_tr(heff_apply(heff_dup(v_wanted_240), 1, (V[]){heff_dup(v_x_246)}));
      V v_t_2414;
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        V v_t_2413;
        switch (heff_tag_of(v_r_248)) {
        case TAG_Ok: {
          V v_v_2412 = heff_field(v_r_248, 0);
          V v_ru_24r_248_24Ok = heff_take_reuse_n(v_r_248, 1ULL, 1);
          v_t_2413 = heff_tag_at(v_ru_24r_248_24Ok, TAG_RSucceeded, 1, (V[]){v_v_2412});
          break;
        }
        case TAG_Abn: {
          v_t_2413 = NTAG(TAG_RAbandoned);
          break;
        }
        case TAG_Div: {
          v_t_2413 = NTAG(TAG_RDiverged);
          break;
        }
        default: heff_nomatch(v_r_248);
        }
        v_t_2414 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_246, v_t_2413}), v_acc_243});
        break;
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_x_246);
        heff_drop(v_r_248);
        v_t_2414 = v_acc_243;
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
      V t_0 = v_wanted_240;
      V t_1 = v_t_2410;
      V t_2 = v_rest_245;
      V t_3 = v_t_2414;
      v_wanted_240 = t_0;
      v_ge_241 = t_1;
      v_x3_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2einterp_2eevalGlobalsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eevalGlobalsGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2einterp_2eevalGlobalsGo_lam0(V self, V *args) {
  V v_d_249 = args[0];
  V v_r_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_249);
  return v_r_248;
}
V g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986_lam0(V self, V *args);
Clo g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986_entry, 6, 0};

V g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986(V v_lit_240, V v_lit_241, V v_lit_242, V v_ge_243, V v_x3_244, V v_acc_245) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_ge_243);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_245));
  }
  case TAG_Cons: {
    V v_x31_246 = heff_field(v_x3_244, 0);
    V v_rest_247 = heff_field(v_x3_244, 1);
    V v_ru_24x3_244_24Cons = heff_take_reuse_n(v_x3_244, 3ULL, 2);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x31_246, 0);
      V v_entry_249 = heff_field(v_x31_246, 1);
      heff_take_n(v_x31_246, 3ULL, 2);
      V v_r_2410 = heff_tr(g_heff_2einterp_2efixThunk(heff_dup(v_ge_243), heff_get(v_entry_249, LBL_syntax), MK_INT(0LL)));
      V v_t_2412 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_248), heff_clo(g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986_lam0, 1, 1, (V[]){heff_dup(v_r_2410)}), v_ge_243));
      V v_t_2416;
      if (heff_strEq_c(heff_strSlice(heff_dup(v_x_248), heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_lit_242))) {
        V v_t_2415;
        switch (heff_tag_of(v_r_2410)) {
        case TAG_Ok: {
          V v_v_2414 = heff_field(v_r_2410, 0);
          V v_ru_24r_2410_24Ok = heff_take_reuse_n(v_r_2410, 1ULL, 1);
          v_t_2415 = heff_tag_at(v_ru_24r_2410_24Ok, TAG_RSucceeded, 1, (V[]){v_v_2414});
          break;
        }
        case TAG_Abn: {
          v_t_2415 = NTAG(TAG_RAbandoned);
          break;
        }
        case TAG_Div: {
          v_t_2415 = NTAG(TAG_RDiverged);
          break;
        }
        default: heff_nomatch(v_r_2410);
        }
        v_t_2416 = heff_tag_at(v_ru_24x3_244_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_248, v_t_2415}), v_acc_245});
      } else {
        heff_drop_cell(v_ru_24x3_244_24Cons, 2);
        heff_drop(v_x_248);
        heff_drop(v_r_2410);
        v_t_2416 = v_acc_245;
      }
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_t_2412;
      V t_4 = v_rest_247;
      V t_5 = v_t_2416;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_ge_243 = t_3;
      v_x3_244 = t_4;
      v_acc_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x31_246);
    }
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986_lam0(V self, V *args) {
  V v_d_2411 = args[0];
  V v_r_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_2411);
  return v_r_2410;
}