// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_AbsConst 8406
#define TAG_Div 16157
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkAbs 54862
#define TAG_Ok 9325
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_RAbandoned 16367
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VArr 15466
#define TAG_VCons 11629
#define TAG_VErased 42634
#define TAG_VFloat 27713
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_byName 571997869
#define LBL_fixed 298804110
#define LBL_global 704121550
#define LBL_keys 9783995
#define LBL_local 304503685
#define LBL_op 10312
#define LBL_syntax 1059664654
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_local__global[] = {LBL_local, LBL_global};
V g_heff_2edict_2eindexed(V, V);
V g_heff_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2edict_2eindexed_clo;
V g_heff_2edict_2ezipKV(V, V);
V g_heff_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2edict_2ezipKV_clo;
V g_heff_2efixed_2efixedMin(V);
V g_heff_2efixed_2efixedMin_entry(V self, V *a);
extern Clo g_heff_2efixed_2efixedMin_clo;
V g_heff_2efixed_2efixedPrimOf(V);
V g_heff_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2efixed_2efixedPrimOf_clo;
V g_heff_2efixed_2etwoTo(V);
V g_heff_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2efixed_2etwoTo_clo;
V g_heff_2einterp_2ebitsOf_24s1458520709x2132426067(V, V, V, V);
V g_heff_2einterp_2ebitsOf_24s1458520709x2132426067_entry(V self, V *a);
extern Clo g_heff_2einterp_2ebitsOf_24s1458520709x2132426067_clo;
V g_heff_2einterp_2ebitsOf_24s2122496700x1608419743(V, V, V);
V g_heff_2einterp_2ebitsOf_24s2122496700x1608419743_entry(V self, V *a);
extern Clo g_heff_2einterp_2ebitsOf_24s2122496700x1608419743_clo;
V g_heff_2einterp_2ebitsOf_24s277023746x1062825997(V, V, V, V, V, V);
V g_heff_2einterp_2ebitsOf_24s277023746x1062825997_entry(V self, V *a);
extern Clo g_heff_2einterp_2ebitsOf_24s277023746x1062825997_clo;
V g_heff_2einterp_2ebitwise(V, V, V, V);
V g_heff_2einterp_2ebitwise_entry(V self, V *a);
extern Clo g_heff_2einterp_2ebitwise_clo;
V g_heff_2einterp_2ebitwise_24s348840635x1130995754(V, V, V);
V g_heff_2einterp_2ebitwise_24s348840635x1130995754_entry(V self, V *a);
extern Clo g_heff_2einterp_2ebitwise_24s348840635x1130995754_clo;
V g_heff_2einterp_2edeepest_get(void);
V g_heff_2einterp_2eescAt(V, V);
V g_heff_2einterp_2eescAt_entry(V self, V *a);
extern Clo g_heff_2einterp_2eescAt_clo;
V g_heff_2einterp_2eevalEach(V, V, V);
V g_heff_2einterp_2eevalEach_entry(V self, V *a);
extern Clo g_heff_2einterp_2eevalEach_clo;
V g_heff_2einterp_2eevalFields(V, V, V);
V g_heff_2einterp_2eevalFields_entry(V self, V *a);
extern Clo g_heff_2einterp_2eevalFields_clo;
V g_heff_2einterp_2eevalGlobalsGo(V, V, V, V);
V g_heff_2einterp_2eevalGlobalsGo_entry(V self, V *a);
extern Clo g_heff_2einterp_2eevalGlobalsGo_clo;
V g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986(V, V, V, V, V, V);
V g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986_entry(V self, V *a);
extern Clo g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986_clo;
V g_heff_2einterp_2eevalIn(V, V, V);
V g_heff_2einterp_2eevalIn_entry(V self, V *a);
extern Clo g_heff_2einterp_2eevalIn_clo;
V g_heff_2einterp_2efixThunk(V, V, V);
V g_heff_2einterp_2efixThunk_entry(V self, V *a);
extern Clo g_heff_2einterp_2efixThunk_clo;
V g_heff_2einterp_2efixedInt1(V, V, V);
V g_heff_2einterp_2efixedInt1_entry(V self, V *a);
extern Clo g_heff_2einterp_2efixedInt1_clo;
V g_heff_2einterp_2efixedInt2(V, V, V, V);
V g_heff_2einterp_2efixedInt2_entry(V self, V *a);
extern Clo g_heff_2einterp_2efixedInt2_clo;
V g_heff_2einterp_2efixedPrimV(V);
V g_heff_2einterp_2efixedPrimV_entry(V self, V *a);
extern Clo g_heff_2einterp_2efixedPrimV_clo;
V g_heff_2einterp_2efloat2(V);
V g_heff_2einterp_2efloat2_entry(V self, V *a);
extern Clo g_heff_2einterp_2efloat2_clo;
V g_heff_2einterp_2efloat2_24s1423458924x1394741838_get(void);
V g_heff_2einterp_2efloat2_24s1759709581x228229611_get(void);
V g_heff_2einterp_2efloat2_24s1965813471x487337709_get(void);
V g_heff_2einterp_2efloat2_24s2003084928x2062825913_get(void);
V g_heff_2einterp_2efloat2_24s205358756x116382871_get(void);
V g_heff_2einterp_2efloat2_24s615196179x236480627_get(void);
V g_heff_2einterp_2efromListV(V, V);
V g_heff_2einterp_2efromListV_entry(V self, V *a);
extern Clo g_heff_2einterp_2efromListV_clo;
V g_heff_2einterp_2egenGo(V, V, V, V, V);
V g_heff_2einterp_2egenGo_entry(V self, V *a);
extern Clo g_heff_2einterp_2egenGo_clo;
V g_heff_2einterp_2eint2(V);
V g_heff_2einterp_2eint2_entry(V self, V *a);
extern Clo g_heff_2einterp_2eint2_clo;
V g_heff_2einterp_2eint2_24s1207713422x150104894_get(void);
V g_heff_2einterp_2eint2_24s1750067969x1390184394_get(void);
V g_heff_2einterp_2eint2_24s1787339426x818188969_get(void);
V g_heff_2einterp_2enthTh(V, V);
V g_heff_2einterp_2enthTh_entry(V self, V *a);
extern Clo g_heff_2einterp_2enthTh_clo;
V g_heff_2einterp_2enthV(V, V);
V g_heff_2einterp_2enthV_entry(V self, V *a);
extern Clo g_heff_2einterp_2enthV_clo;
V g_heff_2einterp_2eprim(V);
V g_heff_2einterp_2eprim_entry(V self, V *a);
extern Clo g_heff_2einterp_2eprim_clo;
V g_heff_2einterp_2eprojV(V, V);
V g_heff_2einterp_2eprojV_entry(V self, V *a);
extern Clo g_heff_2einterp_2eprojV_clo;
V g_heff_2einterp_2equoteGo(V, V, V);
V g_heff_2einterp_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2einterp_2equoteGo_clo;
V g_heff_2einterp_2esetAt(V, V, V);
V g_heff_2einterp_2esetAt_entry(V self, V *a);
extern Clo g_heff_2einterp_2esetAt_clo;
V g_heff_2einterp_2eshowValGo(V, V);
V g_heff_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2einterp_2eshowValGo_clo;
V g_heff_2einterp_2estr2(V);
V g_heff_2einterp_2estr2_entry(V self, V *a);
extern Clo g_heff_2einterp_2estr2_clo;
V g_heff_2einterp_2estr2_24s1802929932x1594371566_get(void);
V g_heff_2einterp_2etoListV(V);
V g_heff_2einterp_2etoListV_entry(V self, V *a);
extern Clo g_heff_2einterp_2etoListV_clo;
V g_heff_2einterp_2etruncDiv(V, V);
V g_heff_2einterp_2etruncDiv_entry(V self, V *a);
extern Clo g_heff_2einterp_2etruncDiv_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_prelude_2efoldl_24s1226147011x367015740(V, V, V);
V g_prelude_2efoldl_24s1226147011x367015740_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1226147011x367015740_clo;
V g_prelude_2efoldl_24s1546929672x1472202881(V, V);
V g_prelude_2efoldl_24s1546929672x1472202881_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1546929672x1472202881_clo;
V g_prelude_2efoldl_24s1939305664x1902528268(V, V, V);
V g_prelude_2efoldl_24s1939305664x1902528268_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1939305664x1902528268_clo;
V g_prelude_2efoldl_24s680066967x839815107(V, V);
V g_prelude_2efoldl_24s680066967x839815107_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s680066967x839815107_clo;
V g_prelude_2emap_24s1581021428x1223114127(V);
V g_prelude_2emap_24s1581021428x1223114127_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1581021428x1223114127_clo;
V g_prelude_2emap_24s1670578341x1649699234(V, V);
V g_prelude_2emap_24s1670578341x1649699234_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1670578341x1649699234_clo;
V g_prelude_2emap_24s265029017x1822716883(V);
V g_prelude_2emap_24s265029017x1822716883_entry(V self, V *a);
extern Clo g_prelude_2emap_24s265029017x1822716883_clo;
V g_prelude_2emap_24s531459667x996402587(V);
V g_prelude_2emap_24s531459667x996402587_entry(V self, V *a);
extern Clo g_prelude_2emap_24s531459667x996402587_clo;
V g_prelude_2emap_24s615600838x450168446(V, V);
V g_prelude_2emap_24s615600838x450168446_entry(V self, V *a);
extern Clo g_prelude_2emap_24s615600838x450168446_clo;

static V g_heff_2einterp_2edeepest_val;
static int g_heff_2einterp_2edeepest_st;
static V g_heff_2einterp_2edeepest_init(void) {
  return MK_INT(1000000LL);
}
V g_heff_2einterp_2edeepest_get(void) {
  if (g_heff_2einterp_2edeepest_st == 2) return g_heff_2einterp_2edeepest_val;
  if (g_heff_2einterp_2edeepest_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2edeepest_st = 1;
  g_heff_2einterp_2edeepest_val = heff_tr(g_heff_2einterp_2edeepest_init());
  g_heff_2einterp_2edeepest_st = 2;
  return g_heff_2einterp_2edeepest_val;
}
Clo g_heff_2einterp_2eprojV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprojV_entry, 2, 0};

V g_heff_2einterp_2eprojV(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VCons: {
    V v_fs_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24VCons = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_244 = ({ V a_0 = v_x2_241; V b_1 = heff_get(heff_dup(v_fs_243), LBL_byName); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2410;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop(v_fs_243);
      v_t_2410 = heff_abandon();
      break;
    }
    case TAG_Just: {
      V v_i_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V v_xs_246 = heff_get(v_fs_243, LBL_values);
      V v_t_247 = heff_intLe(MK_INT(0LL), heff_dup(v_i_245));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        V v_t_248 = heff_intLt(heff_dup(v_i_245), heff_arrayLength(heff_dup(v_xs_246)));
        switch (heff_tag_of(v_t_248)) {
        case TAG_True: {
          V v_v_249 = heff_arrayIndex(v_xs_246, v_i_245);
          v_t_2410 = v_v_249;
          break;
        }
        case TAG_False: {
          heff_drop(v_i_245);
          heff_drop(v_xs_246);
          v_t_2410 = heff_abandon();
          break;
        }
        default: heff_nomatch(v_t_248);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_i_245);
        heff_drop(v_xs_246);
        v_t_2410 = heff_abandon();
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    return heff_tag_at(v_ru_24x1_240_24VCons, TAG_Ok, 1, (V[]){v_t_2410});
  }
  case TAG_VTag: {
    heff_take_n(v_x1_240, 0ULL, 2);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VArr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_x2_241);
    return heff_abandon();
  }
  case TAG_VErased: {
    heff_drop(v_x2_241);
    return heff_tag(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2eprojV_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eprojV(a[0], a[1]);
}
V g_heff_2einterp_2eint2_lam1(V self, V *args);
V g_heff_2einterp_2eint2_lam0(V self, V *args);
Clo g_heff_2einterp_2eint2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eint2_entry, 1, 0};

V g_heff_2einterp_2eint2(V v_f_240) {
top: ;
  return heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eint2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2einterp_2eint2_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eint2(a[0]);
}
V g_heff_2einterp_2eint2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_apply(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_apply(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      switch (heff_tag_of(v_v_246)) {
      case TAG_VFun: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_246, 0ULL, 2);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VInt: {
        V v_a_2413 = heff_field(v_v_246, 0);
        heff_take_n(v_v_246, 1ULL, 1);
        switch (heff_tag_of(v_v_248)) {
        case TAG_VFun: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_248, 0ULL, 2);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          V v_b_2418 = heff_field(v_v_248, 0);
          heff_take_n(v_v_248, 1ULL, 1);
          V f_ = v_f_240;
          args[0] = v_a_2413;
          args[1] = v_b_2418;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        case TAG_VFloat: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_248);
        }
      }
      case TAG_VFloat: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_246);
      }
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2einterp_2eint2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eint2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
V g_heff_2einterp_2efloat2_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_lam0(V self, V *args);
Clo g_heff_2einterp_2efloat2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_entry, 1, 0};

V g_heff_2einterp_2efloat2(V v_f_240) {
top: ;
  return heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2einterp_2efloat2_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2efloat2(a[0]);
}
V g_heff_2einterp_2efloat2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_apply(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_apply(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      switch (heff_tag_of(v_v_246)) {
      case TAG_VFun: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_246, 0ULL, 2);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2414 = heff_field(v_v_246, 0);
        heff_take_n(v_v_246, 1ULL, 1);
        switch (heff_tag_of(v_v_248)) {
        case TAG_VFun: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_248, 0ULL, 2);
          heff_drop(v_f_240);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2420 = heff_field(v_v_248, 0);
          heff_take_n(v_v_248, 1ULL, 1);
          V f_ = v_f_240;
          args[0] = v_a_2414;
          args[1] = v_b_2420;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        case TAG_VStr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_f_240);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_248);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_246);
      }
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2einterp_2efloat2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
V g_heff_2einterp_2estr2_lam1(V self, V *args);
V g_heff_2einterp_2estr2_lam0(V self, V *args);
Clo g_heff_2einterp_2estr2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2estr2_entry, 1, 0};

V g_heff_2einterp_2estr2(V v_f_240) {
top: ;
  return heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2estr2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2einterp_2estr2_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2estr2(a[0]);
}
V g_heff_2einterp_2estr2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_apply(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_apply(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      switch (heff_tag_of(v_v_246)) {
      case TAG_VFun: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_246, 0ULL, 2);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VFloat: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VStr: {
        V v_a_2415 = heff_field(v_v_246, 0);
        heff_take_n(v_v_246, 1ULL, 1);
        switch (heff_tag_of(v_v_248)) {
        case TAG_VFun: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_248, 0ULL, 2);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VFloat: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VStr: {
          V v_b_2422 = heff_field(v_v_248, 0);
          heff_take_n(v_v_248, 1ULL, 1);
          V f_ = v_f_240;
          args[0] = v_a_2415;
          args[1] = v_b_2422;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        case TAG_VArr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_248);
        }
      }
      case TAG_VArr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_246);
      }
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2einterp_2estr2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2estr2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
Clo g_heff_2einterp_2esetAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2esetAt_entry, 3, 0};

V g_heff_2einterp_2esetAt(V v_x1_240, V v_i_241, V v_x_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x1_240, 0);
    V v_ys_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_intEq(heff_dup(v_i_241), MK_INT(0LL));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_i_241);
      heff_drop(v_y_243);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_ys_244});
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_y_243, (g_heff_2einterp_2esetAt(v_ys_244, heff_intSub(v_i_241, MK_INT(1LL)), v_x_242))});
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2esetAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2esetAt(a[0], a[1], a[2]);
}
V g_heff_2einterp_2egenGo_lam0(V self, V *args);
V g_heff_2einterp_2egenGo_lam1(V self, V *args);
Clo g_heff_2einterp_2egenGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2egenGo_entry, 5, 0};

V g_heff_2einterp_2egenGo(V v_d_240, V v_j_241, V v_n_242, V v_f_243, V v_k_244) {
top: ;
  V v_t_245 = heff_intLe(heff_dup(v_n_242), heff_dup(v_j_241));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_d_240);
    heff_drop(v_j_241);
    heff_drop(v_n_242);
    heff_drop(v_f_243);
    return heff_tail(v_k_244, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_False: {
    V v_x1_2415;
    switch (heff_tag_of(v_f_243)) {
    case TAG_VFun: {
      V v_f_246 = heff_dup(heff_field(v_f_243, 0));
      v_x1_2415 = heff_tr(heff_apply(v_f_246, 2, (V[]){heff_dup(v_d_240), heff_clo(g_heff_2einterp_2egenGo_lam0, 1, 1, (V[]){heff_dup(v_j_241)})}));
      break;
    }
    case TAG_VCons: {
      v_x1_2415 = heff_abandon();
      break;
    }
    case TAG_VTag: {
      v_x1_2415 = heff_abandon();
      break;
    }
    case TAG_VInt: {
      v_x1_2415 = heff_abandon();
      break;
    }
    case TAG_VFloat: {
      v_x1_2415 = heff_abandon();
      break;
    }
    case TAG_VStr: {
      v_x1_2415 = heff_abandon();
      break;
    }
    case TAG_VArr: {
      v_x1_2415 = heff_abandon();
      break;
    }
    case TAG_VErased: {
      v_x1_2415 = heff_tag(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
      break;
    }
    default: heff_nomatch(v_f_243);
    }
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_Ok: {
      V v_v_2416 = heff_field(v_x1_2415, 0);
      heff_take_n(v_x1_2415, 1ULL, 1);
      V t_0 = v_d_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
      V t_2 = v_n_242;
      V t_3 = v_f_243;
      V t_4 = heff_clo(g_heff_2einterp_2egenGo_lam1, 1, 2, (V[]){v_k_244, v_v_2416});
      v_d_240 = t_0;
      v_j_241 = t_1;
      v_n_242 = t_2;
      v_f_243 = t_3;
      v_k_244 = t_4;
      goto top;
    }
    case TAG_Abn: {
      heff_drop(v_d_240);
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      heff_drop(v_f_243);
      heff_drop(v_k_244);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_d_240);
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      heff_drop(v_f_243);
      heff_drop(v_k_244);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_2415);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2einterp_2egenGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2egenGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2einterp_2egenGo_lam0(V self, V *args) {
  V v_d_247 = args[0];
  V v_j_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_247);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_j_241})});
}
V g_heff_2einterp_2egenGo_lam1(V self, V *args) {
  V v_vs_2417 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_v_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_244;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_v_2416, v_vs_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2efromListV_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {67, 111, 110, 115}};
Clo g_heff_2einterp_2efromListV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efromListV_entry, 2, 0};

V g_heff_2einterp_2efromListV(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VTag: {
    V v_x11_244 = heff_field(v_x1_240, 0);
    V v_x12_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24VTag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_246 = heff_strEq(v_x11_244, ((V)&g_heff_2einterp_2efromListV_str0));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      switch (heff_tag_of(v_x12_245)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24VTag, 2);
        HEFF_LAST return g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_241);
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x12_245, 0);
        V v_x122_248 = heff_field(v_x12_245, 1);
        heff_take_n(v_x12_245, 3ULL, 2);
        switch (heff_tag_of(v_x122_248)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
          heff_drop(v_x_247);
          HEFF_LAST return g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_241);
        }
        case TAG_Cons: {
          V v_rest_249 = heff_field(v_x122_248, 0);
          V v_x1222_2410 = heff_field(v_x122_248, 1);
          heff_take_n(v_x122_248, 3ULL, 2);
          switch (heff_tag_of(v_x1222_2410)) {
          case TAG_Nil: {
            V t_0 = v_rest_249;
            V t_1 = heff_tag_at(v_ru_24x1_240_24VTag, TAG_Cons, 2, (V[]){v_x_247, v_acc_241});
            v_x1_240 = t_0;
            v_acc_241 = t_1;
            goto top;
          }
          case TAG_Cons: {
            heff_take_n(v_x1222_2410, 0ULL, 2);
            heff_drop_cell(v_ru_24x1_240_24VTag, 2);
            heff_drop(v_x_247);
            heff_drop(v_rest_249);
            HEFF_LAST return g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_241);
          }
          default: return heff_nomatch(v_x1222_2410);
          }
        }
        default: return heff_nomatch(v_x122_248);
        }
      }
      default: return heff_nomatch(v_x12_245);
      }
    }
    case TAG_False: {
      heff_drop(v_x12_245);
      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
      HEFF_LAST return g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_241);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_VInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VArr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VErased: {
    HEFF_LAST return g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_241);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2efromListV_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2efromListV(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2einterp_2etoListV_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {78, 105, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2etoListV_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {67, 111, 110, 115}};
Clo g_heff_2einterp_2etoListV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2etoListV_entry, 1, 0};

V g_heff_2einterp_2etoListV(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag(TAG_VTag, 2, (V[]){((V)&g_heff_2einterp_2etoListV_str0), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_heff_2einterp_2etoListV(v_xs_242));
    V v_t_244 = heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
    return heff_tag(TAG_VTag, 2, (V[]){((V)&g_heff_2einterp_2etoListV_str1), heff_tag(TAG_Cons, 2, (V[]){v_x_241, v_t_244})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2etoListV_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2etoListV(a[0]);
}
Clo g_heff_2einterp_2enthV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2enthV_entry, 2, 0};

V g_heff_2einterp_2enthV(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_intEq(heff_dup(v_i_241), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_i_241);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    }
    case TAG_False: {
      V t_0 = v_xs_243;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2enthV_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2enthV(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2einterp_2etruncDiv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2etruncDiv_entry, 2, 0};

V g_heff_2einterp_2etruncDiv(V v_a_240, V v_b_241) {
top: ;
  V v_a_242 = heff_intMod(heff_dup(v_a_240), heff_dup(v_b_241));
  V v_t_243 = heff_intEq(v_a_242, MK_INT(0LL));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    return heff_intDiv(v_a_240, v_b_241);
  }
  case TAG_False: {
    V v_t_244 = heff_intLt(heff_dup(v_a_240), MK_INT(0LL));
    V v_t_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      v_t_245 = heff_intLe(MK_INT(0LL), heff_dup(v_b_241));
      break;
    }
    case TAG_False: {
      v_t_245 = heff_intLt(heff_dup(v_b_241), MK_INT(0LL));
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      V v_t_246 = heff_intDiv(v_a_240, v_b_241);
      return heff_intAdd(v_t_246, MK_INT(1LL));
    }
    case TAG_False: {
      return heff_intDiv(v_a_240, v_b_241);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2einterp_2etruncDiv_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2etruncDiv(a[0], a[1]);
}
Clo g_heff_2einterp_2ebitwise_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2ebitwise_entry, 4, 0};

V g_heff_2einterp_2ebitwise(V v_f_240, V v_n_241, V v_a_242, V v_b_243) {
top: ;
  V v_t_244 = heff_intEq(heff_dup(v_n_241), MK_INT(0LL));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_f_240);
    heff_drop(v_n_241);
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return MK_INT(0LL);
  }
  case TAG_False: {
    V v_t_245 = heff_intMod(heff_dup(v_a_242), MK_INT(2LL));
    V v_t_246 = heff_intMod(heff_dup(v_b_243), MK_INT(2LL));
    V v_t_247 = heff_tr(heff_apply(heff_dup(v_f_240), 2, (V[]){v_t_245, v_t_246}));
    V v_t_248 = heff_intDiv(v_a_242, MK_INT(2LL));
    V v_t_249 = heff_intDiv(v_b_243, MK_INT(2LL));
    V v_t_2410 = (g_heff_2einterp_2ebitwise(v_f_240, heff_intSub(v_n_241, MK_INT(1LL)), v_t_248, v_t_249));
    return heff_intAdd(v_t_247, heff_intMul(MK_INT(2LL), v_t_2410));
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2einterp_2ebitwise_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2ebitwise(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2einterp_2ebitwise_24s348840635x1130995754_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2ebitwise_24s348840635x1130995754_entry, 3, 0};

V g_heff_2einterp_2ebitwise_24s348840635x1130995754(V v_n_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_243 = heff_intEq(heff_dup(v_n_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_n_240);
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return MK_INT(0LL);
  }
  case TAG_False: {
    V v_a_244 = heff_intMod(heff_dup(v_a_241), MK_INT(2LL));
    V v_a_245 = heff_intMod(heff_dup(v_b_242), MK_INT(2LL));
    V v_t_246 = heff_intDiv(v_a_241, MK_INT(2LL));
    V v_t_247 = heff_intDiv(v_b_242, MK_INT(2LL));
    V v_t_248 = (g_heff_2einterp_2ebitwise_24s348840635x1130995754(heff_intSub(v_n_240, MK_INT(1LL)), v_t_246, v_t_247));
    return heff_intAdd(heff_intMul(v_a_244, v_a_245), heff_intMul(MK_INT(2LL), v_t_248));
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2einterp_2ebitwise_24s348840635x1130995754_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2ebitwise_24s348840635x1130995754(a[0], a[1], a[2]);
}
Clo g_heff_2einterp_2ebitsOf_24s2122496700x1608419743_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2ebitsOf_24s2122496700x1608419743_entry, 3, 0};

V g_heff_2einterp_2ebitsOf_24s2122496700x1608419743(V v_w_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_243 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_243 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_243 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_243 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_243 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_243 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_243 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_243 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_243 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_244;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_244 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_244 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_244 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_244 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_244 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_244 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_245 = (g_heff_2efixed_2etwoTo(v_t_244));
  V v_t_246 = heff_intMod(v_a_241, v_t_245);
  V v_t_247;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_247 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_247 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_247 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_247 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_247 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_247 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_247 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_247 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_247 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_248 = (g_heff_2efixed_2etwoTo(v_t_247));
  V v_t_249 = heff_intMod(v_b_242, v_t_248);
  V v_n_2410 = (g_heff_2einterp_2ebitwise_24s348840635x1130995754(v_t_243, v_t_246, v_t_249));
  V v_t_2411 = (g_heff_2efixed_2efixedMin(v_w_240));
  V v_t_2412 = (g_heff_2efixed_2efixedMin(v_w_240));
  V v_t_2413;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_2413 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_2413 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_2413 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_2413 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_2413 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_2413 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_2413 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_2413 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_2413 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_2414 = (g_heff_2efixed_2etwoTo(v_t_2413));
  V v_t_2415 = heff_intMod(heff_intSub(v_n_2410, v_t_2412), v_t_2414);
  V v_t_2416 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2411, v_t_2415)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2416});
}
V g_heff_2einterp_2ebitsOf_24s2122496700x1608419743_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2ebitsOf_24s2122496700x1608419743(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2einterp_2ebitsOf_24s277023746x1062825997_lam0(V self, V *args);
Clo g_heff_2einterp_2ebitsOf_24s277023746x1062825997_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2ebitsOf_24s277023746x1062825997_entry, 6, 0};

V g_heff_2einterp_2ebitsOf_24s277023746x1062825997(V v_lit_240, V v_lit_241, V v_lit_242, V v_w_243, V v_a_244, V v_b_245) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_w_243)) {
  case TAG_I8: {
    v_t_246 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_246 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_246 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_246 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_246 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_246 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_246 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_246 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_246 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_243);
  }
  V v_t_247;
  switch (heff_tag_of(v_w_243)) {
  case TAG_I8: {
    v_t_247 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_247 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_247 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_247 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_247 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_247 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_247 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_247 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_247 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_243);
  }
  V v_t_248 = (g_heff_2efixed_2etwoTo(v_t_247));
  V v_t_249 = heff_intMod(v_a_244, v_t_248);
  V v_t_2410;
  switch (heff_tag_of(v_w_243)) {
  case TAG_I8: {
    v_t_2410 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_2410 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_2410 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_2410 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_2410 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_2410 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_2410 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_2410 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_2410 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_243);
  }
  V v_t_2411 = (g_heff_2efixed_2etwoTo(v_t_2410));
  V v_t_2412 = heff_intMod(v_b_245, v_t_2411);
  V v_n_2416 = (g_heff_2einterp_2ebitwise(heff_clo(g_heff_2einterp_2ebitsOf_24s277023746x1062825997_lam0, 2, 3, (V[]){v_lit_240, v_lit_241, v_lit_242}), v_t_246, v_t_249, v_t_2412));
  V v_t_2417 = (g_heff_2efixed_2efixedMin(v_w_243));
  V v_t_2418 = (g_heff_2efixed_2efixedMin(v_w_243));
  V v_t_2419;
  switch (heff_tag_of(v_w_243)) {
  case TAG_I8: {
    v_t_2419 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_2419 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_2419 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_2419 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_2419 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_2419 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_2419 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_2419 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_2419 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_243);
  }
  V v_t_2420 = (g_heff_2efixed_2etwoTo(v_t_2419));
  V v_t_2421 = heff_intMod(heff_intSub(v_n_2416, v_t_2418), v_t_2420);
  V v_t_2422 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2417, v_t_2421)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2422});
}
V g_heff_2einterp_2ebitsOf_24s277023746x1062825997_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2ebitsOf_24s277023746x1062825997(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[3]); return r;
}
V g_heff_2einterp_2ebitsOf_24s277023746x1062825997_lam0(V self, V *args) {
  V v_a_2413 = args[0];
  V v_a_2414 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_intLt(v_lit_240, heff_intAdd(v_a_2413, v_a_2414));
  switch (heff_tag_of(v_t_2415)) {
  case TAG_True: {
    heff_drop(v_lit_242);
    return v_lit_241;
  }
  case TAG_False: {
    heff_drop(v_lit_241);
    return v_lit_242;
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2einterp_2ebitsOf_24s1458520709x2132426067_lam0(V self, V *args);
Clo g_heff_2einterp_2ebitsOf_24s1458520709x2132426067_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2ebitsOf_24s1458520709x2132426067_entry, 4, 0};

V g_heff_2einterp_2ebitsOf_24s1458520709x2132426067(V v_lit_240, V v_w_241, V v_a_242, V v_b_243) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_244 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_244 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_244 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_244 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_244 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_244 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  V v_t_245;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_245 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_245 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_245 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_245 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_245 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_245 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_245 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_245 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_245 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  V v_t_246 = (g_heff_2efixed_2etwoTo(v_t_245));
  V v_t_247 = heff_intMod(v_a_242, v_t_246);
  V v_t_248;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_248 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_248 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_248 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_248 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_248 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_248 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_248 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_248 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_248 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  V v_t_249 = (g_heff_2efixed_2etwoTo(v_t_248));
  V v_t_2410 = heff_intMod(v_b_243, v_t_249);
  V v_n_2413 = (g_heff_2einterp_2ebitwise(heff_clo(g_heff_2einterp_2ebitsOf_24s1458520709x2132426067_lam0, 2, 1, (V[]){v_lit_240}), v_t_244, v_t_247, v_t_2410));
  V v_t_2414 = (g_heff_2efixed_2efixedMin(v_w_241));
  V v_t_2415 = (g_heff_2efixed_2efixedMin(v_w_241));
  V v_t_2416;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_2416 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_2416 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_2416 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_2416 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_2416 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_2416 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_2416 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_2416 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_2416 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  V v_t_2417 = (g_heff_2efixed_2etwoTo(v_t_2416));
  V v_t_2418 = heff_intMod(heff_intSub(v_n_2413, v_t_2415), v_t_2417);
  V v_t_2419 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2414, v_t_2418)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2419});
}
V g_heff_2einterp_2ebitsOf_24s1458520709x2132426067_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2ebitsOf_24s1458520709x2132426067(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2einterp_2ebitsOf_24s1458520709x2132426067_lam0(V self, V *args) {
  V v_a_2411 = args[0];
  V v_a_2412 = args[1];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intMod(heff_intAdd(v_a_2411, v_a_2412), v_lit_240);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2efixedInt2_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2efixedInt2_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2efixedInt2_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2efixedInt2_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2efixedInt2_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2efixedInt2_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
Clo g_heff_2einterp_2efixedInt2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efixedInt2_entry, 4, 0};

V g_heff_2einterp_2efixedInt2(V v_w_240, V v_x2_241, V v_a_242, V v_b_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_OpAdd: {
    V v_t_244 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_245 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_246 = heff_intSub(heff_intAdd(v_a_242, v_b_243), v_t_245);
    V v_t_247;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_247 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_247 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_247 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_247 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_247 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_247 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_247 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_247 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_247 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_248 = (g_heff_2efixed_2etwoTo(v_t_247));
    V v_t_249 = heff_intMod(v_t_246, v_t_248);
    V v_t_2410 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_244, v_t_249)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_2410});
  }
  case TAG_OpSub: {
    V v_t_2411 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_2412 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_2413 = heff_intSub(heff_intSub(v_a_242, v_b_243), v_t_2412);
    V v_t_2414;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2414 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2414 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2414 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2414 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2414 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2414 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2414 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2414 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2414 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2415 = (g_heff_2efixed_2etwoTo(v_t_2414));
    V v_t_2416 = heff_intMod(v_t_2413, v_t_2415);
    V v_t_2417 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2411, v_t_2416)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_2417});
  }
  case TAG_OpMul: {
    V v_t_2418 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_2419 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_2420 = heff_intSub(heff_intMul(v_a_242, v_b_243), v_t_2419);
    V v_t_2421;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2421 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2421 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2421 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2421 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2421 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2421 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2421 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2421 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2421 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2422 = (g_heff_2efixed_2etwoTo(v_t_2421));
    V v_t_2423 = heff_intMod(v_t_2420, v_t_2422);
    V v_t_2424 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2418, v_t_2423)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_2424});
  }
  case TAG_OpDiv: {
    V v_t_2425 = heff_intEq(heff_dup(v_b_243), MK_INT(0LL));
    switch (heff_tag_of(v_t_2425)) {
    case TAG_True: {
      heff_drop(v_a_242);
      heff_drop(v_b_243);
      return NTAG(TAG_Abn);
    }
    case TAG_False: {
      V v_n_2426 = (g_heff_2einterp_2etruncDiv(v_a_242, v_b_243));
      V v_t_2427 = (g_heff_2efixed_2efixedMin(v_w_240));
      V v_t_2428 = (g_heff_2efixed_2efixedMin(v_w_240));
      V v_t_2429;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2429 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_2429 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_2429 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_2429 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_2429 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_2429 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_2429 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_2429 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_2429 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_2430 = (g_heff_2efixed_2etwoTo(v_t_2429));
      V v_t_2431 = heff_intMod(heff_intSub(v_n_2426, v_t_2428), v_t_2430);
      V v_t_2432 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2427, v_t_2431)});
      return heff_tag(TAG_Ok, 1, (V[]){v_t_2432});
    }
    default: return heff_nomatch(v_t_2425);
    }
  }
  case TAG_OpRem: {
    V v_t_2433 = heff_intEq(heff_dup(v_b_243), MK_INT(0LL));
    switch (heff_tag_of(v_t_2433)) {
    case TAG_True: {
      heff_drop(v_a_242);
      heff_drop(v_b_243);
      return NTAG(TAG_Abn);
    }
    case TAG_False: {
      V v_t_2434 = (g_heff_2einterp_2etruncDiv(heff_dup(v_a_242), heff_dup(v_b_243)));
      V v_n_2435 = heff_intSub(v_a_242, heff_intMul(v_b_243, v_t_2434));
      V v_t_2436 = (g_heff_2efixed_2efixedMin(v_w_240));
      V v_t_2437 = (g_heff_2efixed_2efixedMin(v_w_240));
      V v_t_2438;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2438 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_2438 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_2438 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_2438 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_2438 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_2438 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_2438 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_2438 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_2438 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_2439 = (g_heff_2efixed_2etwoTo(v_t_2438));
      V v_t_2440 = heff_intMod(heff_intSub(v_n_2435, v_t_2437), v_t_2439);
      V v_t_2441 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2436, v_t_2440)});
      return heff_tag(TAG_Ok, 1, (V[]){v_t_2441});
    }
    default: return heff_nomatch(v_t_2433);
    }
  }
  case TAG_OpEq: {
    V v_t_2442 = heff_intEq(v_a_242, v_b_243);
    V v_t_2443;
    switch (heff_tag_of(v_t_2442)) {
    case TAG_True: {
      v_t_2443 = ((V)&g_heff_2einterp_2efixedInt2_str0);
      break;
    }
    case TAG_False: {
      v_t_2443 = ((V)&g_heff_2einterp_2efixedInt2_str1);
      break;
    }
    default: heff_nomatch(v_t_2442);
    }
    V v_t_2444 = heff_tag(TAG_VTag, 2, (V[]){v_t_2443, NTAG(TAG_Nil)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_2444});
  }
  case TAG_OpLt: {
    V v_t_2445 = heff_intLt(v_a_242, v_b_243);
    V v_t_2446;
    switch (heff_tag_of(v_t_2445)) {
    case TAG_True: {
      v_t_2446 = ((V)&g_heff_2einterp_2efixedInt2_str2);
      break;
    }
    case TAG_False: {
      v_t_2446 = ((V)&g_heff_2einterp_2efixedInt2_str3);
      break;
    }
    default: heff_nomatch(v_t_2445);
    }
    V v_t_2447 = heff_tag(TAG_VTag, 2, (V[]){v_t_2446, NTAG(TAG_Nil)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_2447});
  }
  case TAG_OpLe: {
    V v_t_2448 = heff_intLe(v_a_242, v_b_243);
    V v_t_2449;
    switch (heff_tag_of(v_t_2448)) {
    case TAG_True: {
      v_t_2449 = ((V)&g_heff_2einterp_2efixedInt2_str4);
      break;
    }
    case TAG_False: {
      v_t_2449 = ((V)&g_heff_2einterp_2efixedInt2_str5);
      break;
    }
    default: heff_nomatch(v_t_2448);
    }
    V v_t_2450 = heff_tag(TAG_VTag, 2, (V[]){v_t_2449, NTAG(TAG_Nil)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_2450});
  }
  case TAG_OpAnd: {
    return (g_heff_2einterp_2ebitsOf_24s2122496700x1608419743(v_w_240, v_a_242, v_b_243));
  }
  case TAG_OpOr: {
    return (g_heff_2einterp_2ebitsOf_24s277023746x1062825997(MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), v_w_240, v_a_242, v_b_243));
  }
  case TAG_OpXor: {
    HEFF_LAST return g_heff_2einterp_2ebitsOf_24s1458520709x2132426067(MK_INT(2LL), v_w_240, v_a_242, v_b_243);
  }
  case TAG_OpShl: {
    V v_t_2451;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2451 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2451 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2451 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2451 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2451 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2451 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2451 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2451 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2451 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2452 = heff_intMod(v_b_243, v_t_2451);
    V v_t_2453 = (g_heff_2efixed_2etwoTo(v_t_2452));
    V v_n_2454 = heff_intMul(v_a_242, v_t_2453);
    V v_t_2455 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_2456 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_2457;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2457 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2457 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2457 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2457 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2457 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2457 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2457 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2457 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2457 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2458 = (g_heff_2efixed_2etwoTo(v_t_2457));
    V v_t_2459 = heff_intMod(heff_intSub(v_n_2454, v_t_2456), v_t_2458);
    V v_t_2460 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2455, v_t_2459)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_2460});
  }
  case TAG_OpShr: {
    V v_t_2461;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2461 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2461 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2461 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2461 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2461 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2461 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2461 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2461 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2461 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2462 = heff_intMod(v_b_243, v_t_2461);
    V v_t_2463 = (g_heff_2efixed_2etwoTo(v_t_2462));
    V v_t_2464 = heff_intDiv(v_a_242, v_t_2463);
    return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_t_2464})});
  }
  case TAG_OpShow: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_OpFromInt: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_OpToInt: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_OpSqrt: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_OpFromFloat: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_OpToFloat: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_OpFloor: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2einterp_2efixedInt2_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2efixedInt2(a[0], a[1], a[2], a[3]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2einterp_2efixedInt1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efixedInt1_entry, 3, 0};

V g_heff_2einterp_2efixedInt1(V v_w_240, V v_x2_241, V v_a_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_OpAdd: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpSub: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpMul: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpDiv: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpRem: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpEq: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpLt: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpLe: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpAnd: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpOr: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpXor: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpShl: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpShr: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpShow: {
    V v_t_243 = heff_tag(TAG_VStr, 1, (V[]){heff_intShow(v_a_242)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_243});
  }
  case TAG_OpFromInt: {
    V v_t_244 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_245 = (g_heff_2efixed_2efixedMin(v_w_240));
    V v_t_246;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_246 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_246 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_246 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_246 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_246 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_246 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_246 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_246 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_246 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_247 = (g_heff_2efixed_2etwoTo(v_t_246));
    V v_t_248 = heff_intMod(heff_intSub(v_a_242, v_t_245), v_t_247);
    V v_t_249 = heff_tag(TAG_VInt, 1, (V[]){heff_intAdd(v_t_244, v_t_248)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_249});
  }
  case TAG_OpToInt: {
    return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_a_242})});
  }
  case TAG_OpSqrt: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpFromFloat: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpToFloat: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  case TAG_OpFloor: {
    heff_drop(v_a_242);
    return NTAG(TAG_Abn);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2einterp_2efixedInt1_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2efixedInt1(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2einterp_2efixedPrimV_lam0(V self, V *args); static Clo g_heff_2einterp_2efixedPrimV_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efixedPrimV_lam0, 2, 0};
V g_heff_2einterp_2efixedPrimV_lam1(V self, V *args);
Clo g_heff_2einterp_2efixedPrimV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efixedPrimV_entry, 1, 0};

V g_heff_2einterp_2efixedPrimV(V v_p_240) {
top: ;
  V v_t_241 = heff_get(heff_dup(v_p_240), LBL_fixed);
  V v_t_242;
  switch (heff_tag_of(v_t_241)) {
  case TAG_I8: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_242 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_p_240);
    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efixedPrimV_lam0_clo)});
  }
  case TAG_False: {
    V v_t_245 = heff_get(heff_dup(v_p_240), LBL_op);
    V v_t_246;
    switch (heff_tag_of(v_t_245)) {
    case TAG_OpAdd: {
      v_t_246 = MK_INT(2LL);
      break;
    }
    case TAG_OpSub: {
      v_t_246 = MK_INT(2LL);
      break;
    }
    case TAG_OpMul: {
      v_t_246 = MK_INT(2LL);
      break;
    }
    case TAG_OpDiv: {
      v_t_246 = MK_INT(2LL);
      break;
    }
    case TAG_OpRem: {
      v_t_246 = MK_INT(2LL);
      break;
    }
    case TAG_OpEq: {
      v_t_246 = MK_INT(2LL);
      break;
    }
    case TAG_OpLt: {
      v_t_246 = MK_INT(2LL);
      break;
    }
    case TAG_OpLe: {
      v_t_246 = MK_INT(2LL);
      break;
    }
    case TAG_OpAnd: {
      v_t_246 = MK_INT(2LL);
      break;
    }
    case TAG_OpOr: {
      v_t_246 = MK_INT(2LL);
      break;
    }
    case TAG_OpXor: {
      v_t_246 = MK_INT(2LL);
      break;
    }
    case TAG_OpShl: {
      v_t_246 = MK_INT(2LL);
      break;
    }
    case TAG_OpShr: {
      v_t_246 = MK_INT(2LL);
      break;
    }
    case TAG_OpShow: {
      v_t_246 = MK_INT(1LL);
      break;
    }
    case TAG_OpFromInt: {
      v_t_246 = MK_INT(1LL);
      break;
    }
    case TAG_OpToInt: {
      v_t_246 = MK_INT(1LL);
      break;
    }
    case TAG_OpSqrt: {
      v_t_246 = MK_INT(1LL);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_246 = MK_INT(1LL);
      break;
    }
    case TAG_OpToFloat: {
      v_t_246 = MK_INT(1LL);
      break;
    }
    case TAG_OpFloor: {
      v_t_246 = MK_INT(1LL);
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_247 = heff_intEq(v_t_246, MK_INT(2LL));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      V v_t_248 = heff_tr(heff_apply(((V)&g_heff_2einterp_2efixedInt2_clo), 2, (V[]){heff_get(heff_dup(v_p_240), LBL_fixed), heff_get(v_p_240, LBL_op)}));
      HEFF_LAST return g_heff_2einterp_2eint2(v_t_248);
    }
    case TAG_False: {
      return heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efixedPrimV_lam1, 2, 1, (V[]){v_p_240})});
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2einterp_2efixedPrimV_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2efixedPrimV(a[0]);
}
V g_heff_2einterp_2efixedPrimV_lam0(V self, V *args) {
  V v_d_243 = args[0];
  V v_a_244 = args[1];
  heff_drop(v_d_243);
  heff_drop(v_a_244);
  return NTAG(TAG_Abn);
}
V g_heff_2einterp_2efixedPrimV_lam1(V self, V *args) {
  V v_d_249 = args[0];
  V v_a_2410 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2411 = heff_tr(heff_apply(v_a_2410, 1, (V[]){v_d_249}));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Ok: {
    V v_v_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    switch (heff_tag_of(v_v_2412)) {
    case TAG_VFun: {
      heff_take_n(v_v_2412, 0ULL, 1);
      heff_drop(v_p_240);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_2412, 0ULL, 1);
      heff_drop(v_p_240);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_2412, 0ULL, 2);
      heff_drop(v_p_240);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_2417 = heff_field(v_v_2412, 0);
      heff_take_n(v_v_2412, 1ULL, 1);
      return ({ V b_0 = heff_get(heff_dup(v_p_240), LBL_fixed); V b_1 = heff_get(v_p_240, LBL_op); V a_2 = v_a_2417; V r_ = (g_heff_2einterp_2efixedInt1(b_0, b_1, a_2)); heff_drop(b_0); heff_drop(b_1); r_; });
    }
    case TAG_VFloat: {
      heff_take_n(v_v_2412, 0ULL, 1);
      heff_drop(v_p_240);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_2412, 0ULL, 1);
      heff_drop(v_p_240);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_2412, 0ULL, 1);
      heff_drop(v_p_240);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_p_240);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_2412);
    }
  }
  case TAG_Abn: {
    heff_drop(v_p_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_p_240);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_2411);
  }
}
V g_heff_2einterp_2eint2_24s1750067969x1390184394_lam1(V self, V *args);
V g_heff_2einterp_2eint2_24s1750067969x1390184394_lam0(V self, V *args); static Clo g_heff_2einterp_2eint2_24s1750067969x1390184394_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eint2_24s1750067969x1390184394_lam0, 2, 0};

static V g_heff_2einterp_2eint2_24s1750067969x1390184394_val;
static int g_heff_2einterp_2eint2_24s1750067969x1390184394_st;
static V g_heff_2einterp_2eint2_24s1750067969x1390184394_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eint2_24s1750067969x1390184394_lam0_clo)});
}
V g_heff_2einterp_2eint2_24s1750067969x1390184394_get(void) {
  if (g_heff_2einterp_2eint2_24s1750067969x1390184394_st == 2) return g_heff_2einterp_2eint2_24s1750067969x1390184394_val;
  if (g_heff_2einterp_2eint2_24s1750067969x1390184394_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2eint2_24s1750067969x1390184394_st = 1;
  g_heff_2einterp_2eint2_24s1750067969x1390184394_val = heff_tr(g_heff_2einterp_2eint2_24s1750067969x1390184394_init());
  g_heff_2einterp_2eint2_24s1750067969x1390184394_st = 2;
  return g_heff_2einterp_2eint2_24s1750067969x1390184394_val;
}
V g_heff_2einterp_2eint2_24s1750067969x1390184394_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VInt, 1, (V[]){heff_intAdd(v_a_2412, v_b_2417)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2418});
        }
        case TAG_VFloat: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2eint2_24s1750067969x1390184394_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eint2_24s1750067969x1390184394_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2eint2_24s1787339426x818188969_lam1(V self, V *args);
V g_heff_2einterp_2eint2_24s1787339426x818188969_lam0(V self, V *args); static Clo g_heff_2einterp_2eint2_24s1787339426x818188969_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eint2_24s1787339426x818188969_lam0, 2, 0};

static V g_heff_2einterp_2eint2_24s1787339426x818188969_val;
static int g_heff_2einterp_2eint2_24s1787339426x818188969_st;
static V g_heff_2einterp_2eint2_24s1787339426x818188969_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eint2_24s1787339426x818188969_lam0_clo)});
}
V g_heff_2einterp_2eint2_24s1787339426x818188969_get(void) {
  if (g_heff_2einterp_2eint2_24s1787339426x818188969_st == 2) return g_heff_2einterp_2eint2_24s1787339426x818188969_val;
  if (g_heff_2einterp_2eint2_24s1787339426x818188969_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2eint2_24s1787339426x818188969_st = 1;
  g_heff_2einterp_2eint2_24s1787339426x818188969_val = heff_tr(g_heff_2einterp_2eint2_24s1787339426x818188969_init());
  g_heff_2einterp_2eint2_24s1787339426x818188969_st = 2;
  return g_heff_2einterp_2eint2_24s1787339426x818188969_val;
}
V g_heff_2einterp_2eint2_24s1787339426x818188969_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VInt, 1, (V[]){heff_intSub(v_a_2412, v_b_2417)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2418});
        }
        case TAG_VFloat: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2eint2_24s1787339426x818188969_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eint2_24s1787339426x818188969_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2eint2_24s1207713422x150104894_lam1(V self, V *args);
V g_heff_2einterp_2eint2_24s1207713422x150104894_lam0(V self, V *args); static Clo g_heff_2einterp_2eint2_24s1207713422x150104894_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eint2_24s1207713422x150104894_lam0, 2, 0};

static V g_heff_2einterp_2eint2_24s1207713422x150104894_val;
static int g_heff_2einterp_2eint2_24s1207713422x150104894_st;
static V g_heff_2einterp_2eint2_24s1207713422x150104894_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eint2_24s1207713422x150104894_lam0_clo)});
}
V g_heff_2einterp_2eint2_24s1207713422x150104894_get(void) {
  if (g_heff_2einterp_2eint2_24s1207713422x150104894_st == 2) return g_heff_2einterp_2eint2_24s1207713422x150104894_val;
  if (g_heff_2einterp_2eint2_24s1207713422x150104894_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2eint2_24s1207713422x150104894_st = 1;
  g_heff_2einterp_2eint2_24s1207713422x150104894_val = heff_tr(g_heff_2einterp_2eint2_24s1207713422x150104894_init());
  g_heff_2einterp_2eint2_24s1207713422x150104894_st = 2;
  return g_heff_2einterp_2eint2_24s1207713422x150104894_val;
}
V g_heff_2einterp_2eint2_24s1207713422x150104894_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VInt, 1, (V[]){heff_intMul(v_a_2412, v_b_2417)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2418});
        }
        case TAG_VFloat: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2eint2_24s1207713422x150104894_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eint2_24s1207713422x150104894_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2efloat2_24s1965813471x487337709_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_24s1965813471x487337709_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat2_24s1965813471x487337709_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_24s1965813471x487337709_lam0, 2, 0};

static V g_heff_2einterp_2efloat2_24s1965813471x487337709_val;
static int g_heff_2einterp_2efloat2_24s1965813471x487337709_st;
static V g_heff_2einterp_2efloat2_24s1965813471x487337709_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat2_24s1965813471x487337709_lam0_clo)});
}
V g_heff_2einterp_2efloat2_24s1965813471x487337709_get(void) {
  if (g_heff_2einterp_2efloat2_24s1965813471x487337709_st == 2) return g_heff_2einterp_2efloat2_24s1965813471x487337709_val;
  if (g_heff_2einterp_2efloat2_24s1965813471x487337709_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2efloat2_24s1965813471x487337709_st = 1;
  g_heff_2einterp_2efloat2_24s1965813471x487337709_val = heff_tr(g_heff_2einterp_2efloat2_24s1965813471x487337709_init());
  g_heff_2einterp_2efloat2_24s1965813471x487337709_st = 2;
  return g_heff_2einterp_2efloat2_24s1965813471x487337709_val;
}
V g_heff_2einterp_2efloat2_24s1965813471x487337709_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2420 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VFloat, 1, (V[]){heff_floatAdd(v_a_2413, v_b_2419)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2efloat2_24s1965813471x487337709_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_24s1965813471x487337709_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2efloat2_24s2003084928x2062825913_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_24s2003084928x2062825913_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat2_24s2003084928x2062825913_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_24s2003084928x2062825913_lam0, 2, 0};

static V g_heff_2einterp_2efloat2_24s2003084928x2062825913_val;
static int g_heff_2einterp_2efloat2_24s2003084928x2062825913_st;
static V g_heff_2einterp_2efloat2_24s2003084928x2062825913_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat2_24s2003084928x2062825913_lam0_clo)});
}
V g_heff_2einterp_2efloat2_24s2003084928x2062825913_get(void) {
  if (g_heff_2einterp_2efloat2_24s2003084928x2062825913_st == 2) return g_heff_2einterp_2efloat2_24s2003084928x2062825913_val;
  if (g_heff_2einterp_2efloat2_24s2003084928x2062825913_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2efloat2_24s2003084928x2062825913_st = 1;
  g_heff_2einterp_2efloat2_24s2003084928x2062825913_val = heff_tr(g_heff_2einterp_2efloat2_24s2003084928x2062825913_init());
  g_heff_2einterp_2efloat2_24s2003084928x2062825913_st = 2;
  return g_heff_2einterp_2efloat2_24s2003084928x2062825913_val;
}
V g_heff_2einterp_2efloat2_24s2003084928x2062825913_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2420 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VFloat, 1, (V[]){heff_floatSub(v_a_2413, v_b_2419)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2efloat2_24s2003084928x2062825913_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_24s2003084928x2062825913_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2efloat2_24s1423458924x1394741838_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_24s1423458924x1394741838_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat2_24s1423458924x1394741838_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_24s1423458924x1394741838_lam0, 2, 0};

static V g_heff_2einterp_2efloat2_24s1423458924x1394741838_val;
static int g_heff_2einterp_2efloat2_24s1423458924x1394741838_st;
static V g_heff_2einterp_2efloat2_24s1423458924x1394741838_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat2_24s1423458924x1394741838_lam0_clo)});
}
V g_heff_2einterp_2efloat2_24s1423458924x1394741838_get(void) {
  if (g_heff_2einterp_2efloat2_24s1423458924x1394741838_st == 2) return g_heff_2einterp_2efloat2_24s1423458924x1394741838_val;
  if (g_heff_2einterp_2efloat2_24s1423458924x1394741838_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2efloat2_24s1423458924x1394741838_st = 1;
  g_heff_2einterp_2efloat2_24s1423458924x1394741838_val = heff_tr(g_heff_2einterp_2efloat2_24s1423458924x1394741838_init());
  g_heff_2einterp_2efloat2_24s1423458924x1394741838_st = 2;
  return g_heff_2einterp_2efloat2_24s1423458924x1394741838_val;
}
V g_heff_2einterp_2efloat2_24s1423458924x1394741838_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2420 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VFloat, 1, (V[]){heff_floatMul(v_a_2413, v_b_2419)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2efloat2_24s1423458924x1394741838_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_24s1423458924x1394741838_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2efloat2_24s205358756x116382871_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_24s205358756x116382871_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat2_24s205358756x116382871_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_24s205358756x116382871_lam0, 2, 0};

static V g_heff_2einterp_2efloat2_24s205358756x116382871_val;
static int g_heff_2einterp_2efloat2_24s205358756x116382871_st;
static V g_heff_2einterp_2efloat2_24s205358756x116382871_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat2_24s205358756x116382871_lam0_clo)});
}
V g_heff_2einterp_2efloat2_24s205358756x116382871_get(void) {
  if (g_heff_2einterp_2efloat2_24s205358756x116382871_st == 2) return g_heff_2einterp_2efloat2_24s205358756x116382871_val;
  if (g_heff_2einterp_2efloat2_24s205358756x116382871_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2efloat2_24s205358756x116382871_st = 1;
  g_heff_2einterp_2efloat2_24s205358756x116382871_val = heff_tr(g_heff_2einterp_2efloat2_24s205358756x116382871_init());
  g_heff_2einterp_2efloat2_24s205358756x116382871_st = 2;
  return g_heff_2einterp_2efloat2_24s205358756x116382871_val;
}
V g_heff_2einterp_2efloat2_24s205358756x116382871_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2420 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VFloat, 1, (V[]){heff_floatDiv(v_a_2413, v_b_2419)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2efloat2_24s205358756x116382871_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_24s205358756x116382871_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2efloat2_24s1759709581x228229611_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_24s1759709581x228229611_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat2_24s1759709581x228229611_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_24s1759709581x228229611_lam0, 2, 0};

static V g_heff_2einterp_2efloat2_24s1759709581x228229611_val;
static int g_heff_2einterp_2efloat2_24s1759709581x228229611_st;
static V g_heff_2einterp_2efloat2_24s1759709581x228229611_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat2_24s1759709581x228229611_lam0_clo)});
}
V g_heff_2einterp_2efloat2_24s1759709581x228229611_get(void) {
  if (g_heff_2einterp_2efloat2_24s1759709581x228229611_st == 2) return g_heff_2einterp_2efloat2_24s1759709581x228229611_val;
  if (g_heff_2einterp_2efloat2_24s1759709581x228229611_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2efloat2_24s1759709581x228229611_st = 1;
  g_heff_2einterp_2efloat2_24s1759709581x228229611_val = heff_tr(g_heff_2einterp_2efloat2_24s1759709581x228229611_init());
  g_heff_2einterp_2efloat2_24s1759709581x228229611_st = 2;
  return g_heff_2einterp_2efloat2_24s1759709581x228229611_val;
}
V g_heff_2einterp_2efloat2_24s1759709581x228229611_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2420 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VFloat, 1, (V[]){heff_floatAtan2(v_a_2413, v_b_2419)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2efloat2_24s1759709581x228229611_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_24s1759709581x228229611_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2efloat2_24s615196179x236480627_lam1(V self, V *args);
V g_heff_2einterp_2efloat2_24s615196179x236480627_lam0(V self, V *args); static Clo g_heff_2einterp_2efloat2_24s615196179x236480627_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efloat2_24s615196179x236480627_lam0, 2, 0};

static V g_heff_2einterp_2efloat2_24s615196179x236480627_val;
static int g_heff_2einterp_2efloat2_24s615196179x236480627_st;
static V g_heff_2einterp_2efloat2_24s615196179x236480627_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2efloat2_24s615196179x236480627_lam0_clo)});
}
V g_heff_2einterp_2efloat2_24s615196179x236480627_get(void) {
  if (g_heff_2einterp_2efloat2_24s615196179x236480627_st == 2) return g_heff_2einterp_2efloat2_24s615196179x236480627_val;
  if (g_heff_2einterp_2efloat2_24s615196179x236480627_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2efloat2_24s615196179x236480627_st = 1;
  g_heff_2einterp_2efloat2_24s615196179x236480627_val = heff_tr(g_heff_2einterp_2efloat2_24s615196179x236480627_init());
  g_heff_2einterp_2efloat2_24s615196179x236480627_st = 2;
  return g_heff_2einterp_2efloat2_24s615196179x236480627_val;
}
V g_heff_2einterp_2efloat2_24s615196179x236480627_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2420 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VFloat, 1, (V[]){heff_floatPow(v_a_2413, v_b_2419)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2efloat2_24s615196179x236480627_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2efloat2_24s615196179x236480627_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2einterp_2estr2_24s1802929932x1594371566_lam1(V self, V *args);
V g_heff_2einterp_2estr2_24s1802929932x1594371566_lam0(V self, V *args); static Clo g_heff_2einterp_2estr2_24s1802929932x1594371566_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2estr2_24s1802929932x1594371566_lam0, 2, 0};

static V g_heff_2einterp_2estr2_24s1802929932x1594371566_val;
static int g_heff_2einterp_2estr2_24s1802929932x1594371566_st;
static V g_heff_2einterp_2estr2_24s1802929932x1594371566_init(void) {
  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2estr2_24s1802929932x1594371566_lam0_clo)});
}
V g_heff_2einterp_2estr2_24s1802929932x1594371566_get(void) {
  if (g_heff_2einterp_2estr2_24s1802929932x1594371566_st == 2) return g_heff_2einterp_2estr2_24s1802929932x1594371566_val;
  if (g_heff_2einterp_2estr2_24s1802929932x1594371566_st == 1) heff_fail("defined by itself");
  g_heff_2einterp_2estr2_24s1802929932x1594371566_st = 1;
  g_heff_2einterp_2estr2_24s1802929932x1594371566_val = heff_tr(g_heff_2einterp_2estr2_24s1802929932x1594371566_init());
  g_heff_2einterp_2estr2_24s1802929932x1594371566_st = 2;
  return g_heff_2einterp_2estr2_24s1802929932x1594371566_val;
}
V g_heff_2einterp_2estr2_24s1802929932x1594371566_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_apply(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VFloat: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VStr: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VFloat: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VStr: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2422 = heff_tag_at(v_ru_24x1_244_24Ok, TAG_VStr, 1, (V[]){heff_strAppend(v_a_2414, v_b_2421)});
          return heff_tag_at(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_abandon();
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2einterp_2estr2_24s1802929932x1594371566_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2estr2_24s1802929932x1594371566_lam1, 2, 1, (V[]){v_a_241})})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 65, 100, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 83, 117, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 77, 117, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str3 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 68, 105, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eprim_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 77, 111, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eprim_str6 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str8 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eprim_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str10 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str11 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eprim_str12 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str13 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eprim_str14 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 110, 116, 83, 104, 111, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str15 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 65, 100, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str16 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 83, 117, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str17 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 77, 117, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str18 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 68, 105, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eprim_str19 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eprim_str20 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str21 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eprim_str22 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eprim_str23 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str24 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eprim_str25 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eprim_str26 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str27 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2einterp_2eprim_str28 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 83, 104, 111, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2einterp_2eprim_str29 = {{0x80000000u, K_STR, 0}, 12, 12, {102, 108, 111, 97, 116, 70, 114, 111, 109, 73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2einterp_2eprim_str30 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 83, 113, 114, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2einterp_2eprim_str31 = {{0x80000000u, K_STR, 0}, 10, 10, {102, 108, 111, 97, 116, 70, 108, 111, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str32 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 83, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str33 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 67, 111, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str34 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 84, 97, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2einterp_2eprim_str35 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 65, 115, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2einterp_2eprim_str36 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 65, 99, 111, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2einterp_2eprim_str37 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 65, 116, 97, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2einterp_2eprim_str38 = {{0x80000000u, K_STR, 0}, 10, 10, {102, 108, 111, 97, 116, 65, 116, 97, 110, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str39 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 69, 120, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str40 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 76, 111, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str41 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 80, 111, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2einterp_2eprim_str42 = {{0x80000000u, K_STR, 0}, 11, 11, {97, 114, 114, 97, 121, 76, 101, 110, 103, 116, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2einterp_2eprim_str43 = {{0x80000000u, K_STR, 0}, 10, 10, {97, 114, 114, 97, 121, 73, 110, 100, 101, 120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str44 = {{0x80000000u, K_STR, 0}, 8, 8, {97, 114, 114, 97, 121, 83, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2einterp_2eprim_str45 = {{0x80000000u, K_STR, 0}, 13, 13, {97, 114, 114, 97, 121, 71, 101, 110, 101, 114, 97, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2einterp_2eprim_str46 = {{0x80000000u, K_STR, 0}, 13, 13, {97, 114, 114, 97, 121, 70, 114, 111, 109, 76, 105, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2einterp_2eprim_str47 = {{0x80000000u, K_STR, 0}, 11, 11, {97, 114, 114, 97, 121, 84, 111, 76, 105, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2einterp_2eprim_str48 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 65, 112, 112, 101, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2einterp_2eprim_str49 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 76, 101, 110, 103, 116, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2einterp_2eprim_str50 = {{0x80000000u, K_STR, 0}, 8, 8, {115, 116, 114, 83, 108, 105, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str51 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 114, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eprim_str52 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str53 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str54 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 114, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eprim_str55 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2einterp_2eprim_str56 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2einterp_2eprim_str57 = {{0x80000000u, K_STR, 0}, 11, 11, {115, 116, 114, 67, 104, 97, 114, 67, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2einterp_2eprim_str58 = {{0x80000000u, K_STR, 0}, 15, 15, {115, 116, 114, 70, 114, 111, 109, 67, 104, 97, 114, 67, 111, 100, 101}};
V g_heff_2einterp_2eprim_lam0(V self, V *args); static Clo g_heff_2einterp_2eprim_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam0, 2, 0};
V g_heff_2einterp_2eprim_lam1(V self, V *args); static Clo g_heff_2einterp_2eprim_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam1, 2, 0};
V g_heff_2einterp_2eprim_lam2(V self, V *args); static Clo g_heff_2einterp_2eprim_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam2, 2, 0};
V g_heff_2einterp_2eprim_lam3(V self, V *args); static Clo g_heff_2einterp_2eprim_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam3, 2, 0};
V g_heff_2einterp_2eprim_lam4(V self, V *args); static Clo g_heff_2einterp_2eprim_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam4, 2, 0};
V g_heff_2einterp_2eprim_lam5(V self, V *args); static Clo g_heff_2einterp_2eprim_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam5, 2, 0};
V g_heff_2einterp_2eprim_lam6(V self, V *args); static Clo g_heff_2einterp_2eprim_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam6, 2, 0};
V g_heff_2einterp_2eprim_lam7(V self, V *args); static Clo g_heff_2einterp_2eprim_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam7, 2, 0};
V g_heff_2einterp_2eprim_lam8(V self, V *args); static Clo g_heff_2einterp_2eprim_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam8, 2, 0};
V g_heff_2einterp_2eprim_lam9(V self, V *args); static Clo g_heff_2einterp_2eprim_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam9, 2, 0};
V g_heff_2einterp_2eprim_lam10(V self, V *args); static Clo g_heff_2einterp_2eprim_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam10, 2, 0};
V g_heff_2einterp_2eprim_lam11(V self, V *args); static Clo g_heff_2einterp_2eprim_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam11, 2, 0};
V g_heff_2einterp_2eprim_lam12(V self, V *args); static Clo g_heff_2einterp_2eprim_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam12, 2, 0};
V g_heff_2einterp_2eprim_lam13(V self, V *args); static Clo g_heff_2einterp_2eprim_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam13, 2, 0};
V g_heff_2einterp_2eprim_lam14(V self, V *args); static Clo g_heff_2einterp_2eprim_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam14, 2, 0};
V g_heff_2einterp_2eprim_lam15(V self, V *args); static Clo g_heff_2einterp_2eprim_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam15, 2, 0};
V g_heff_2einterp_2eprim_lam16(V self, V *args); static Clo g_heff_2einterp_2eprim_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam16, 2, 0};
V g_heff_2einterp_2eprim_lam17(V self, V *args); static Clo g_heff_2einterp_2eprim_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam17, 2, 0};
V g_heff_2einterp_2eprim_lam18(V self, V *args); static Clo g_heff_2einterp_2eprim_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam18, 2, 0};
V g_heff_2einterp_2eprim_lam19(V self, V *args); static Clo g_heff_2einterp_2eprim_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam19, 2, 0};
V g_heff_2einterp_2eprim_lam20(V self, V *args); static Clo g_heff_2einterp_2eprim_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam20, 2, 0};
V g_heff_2einterp_2eprim_lam22(V self, V *args); static Clo g_heff_2einterp_2eprim_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam22, 2, 0};
V g_heff_2einterp_2eprim_lam21(V self, V *args); static Clo g_heff_2einterp_2eprim_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam21, 2, 0};
V g_heff_2einterp_2eprim_lam25(V self, V *args);
V g_heff_2einterp_2eprim_lam24(V self, V *args); static Clo g_heff_2einterp_2eprim_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam24, 2, 0};
V g_heff_2einterp_2eprim_lam23(V self, V *args); static Clo g_heff_2einterp_2eprim_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam23, 2, 0};
V g_heff_2einterp_2eprim_lam29(V self, V *args);
V g_heff_2einterp_2eprim_lam28(V self, V *args);
V g_heff_2einterp_2eprim_lam27(V self, V *args); static Clo g_heff_2einterp_2eprim_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam27, 2, 0};
V g_heff_2einterp_2eprim_lam26(V self, V *args); static Clo g_heff_2einterp_2eprim_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam26, 2, 0};
V g_heff_2einterp_2eprim_lam33(V self, V *args); static Clo g_heff_2einterp_2eprim_lam33_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam33, 1, 0};
V g_heff_2einterp_2eprim_lam32(V self, V *args);
V g_heff_2einterp_2eprim_lam31(V self, V *args); static Clo g_heff_2einterp_2eprim_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam31, 2, 0};
V g_heff_2einterp_2eprim_lam30(V self, V *args); static Clo g_heff_2einterp_2eprim_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam30, 2, 0};
V g_heff_2einterp_2eprim_lam35(V self, V *args); static Clo g_heff_2einterp_2eprim_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam35, 2, 0};
V g_heff_2einterp_2eprim_lam34(V self, V *args); static Clo g_heff_2einterp_2eprim_lam34_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam34, 2, 0};
V g_heff_2einterp_2eprim_lam37(V self, V *args); static Clo g_heff_2einterp_2eprim_lam37_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam37, 2, 0};
V g_heff_2einterp_2eprim_lam36(V self, V *args); static Clo g_heff_2einterp_2eprim_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam36, 2, 0};
V g_heff_2einterp_2eprim_lam38(V self, V *args); static Clo g_heff_2einterp_2eprim_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam38, 2, 0};
V g_heff_2einterp_2eprim_lam41(V self, V *args);
V g_heff_2einterp_2eprim_lam40(V self, V *args);
V g_heff_2einterp_2eprim_lam39(V self, V *args); static Clo g_heff_2einterp_2eprim_lam39_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam39, 2, 0};
V g_heff_2einterp_2eprim_lam42(V self, V *args); static Clo g_heff_2einterp_2eprim_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam42, 2, 0};
V g_heff_2einterp_2eprim_lam43(V self, V *args); static Clo g_heff_2einterp_2eprim_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam43, 2, 0};
V g_heff_2einterp_2eprim_lam45(V self, V *args);
V g_heff_2einterp_2eprim_lam44(V self, V *args); static Clo g_heff_2einterp_2eprim_lam44_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam44, 2, 0};
V g_heff_2einterp_2eprim_lam46(V self, V *args); static Clo g_heff_2einterp_2eprim_lam46_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_lam46, 2, 0};
Clo g_heff_2einterp_2eprim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eprim_entry, 1, 0};

V g_heff_2einterp_2eprim(V v_p_240) {
top: ;
  V v_t_241 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_p_240);
    return heff_dup(g_heff_2einterp_2eint2_24s1750067969x1390184394_get());
  }
  case TAG_False: {
    V v_t_242 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str1));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return heff_dup(g_heff_2einterp_2eint2_24s1787339426x818188969_get());
    }
    case TAG_False: {
      V v_t_243 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str2));
      switch (heff_tag_of(v_t_243)) {
      case TAG_True: {
        heff_drop(v_p_240);
        return heff_dup(g_heff_2einterp_2eint2_24s1207713422x150104894_get());
      }
      case TAG_False: {
        V v_t_244 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str3));
        switch (heff_tag_of(v_t_244)) {
        case TAG_True: {
          heff_drop(v_p_240);
          HEFF_LAST return g_heff_2einterp_2eint2(((V)&g_heff_2einterp_2eprim_lam0_clo));
        }
        case TAG_False: {
          V v_t_249 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str4));
          switch (heff_tag_of(v_t_249)) {
          case TAG_True: {
            heff_drop(v_p_240);
            HEFF_LAST return g_heff_2einterp_2eint2(((V)&g_heff_2einterp_2eprim_lam1_clo));
          }
          case TAG_False: {
            V v_t_2414 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str5));
            switch (heff_tag_of(v_t_2414)) {
            case TAG_True: {
              heff_drop(v_p_240);
              HEFF_LAST return g_heff_2einterp_2eint2(((V)&g_heff_2einterp_2eprim_lam2_clo));
            }
            case TAG_False: {
              V v_t_2420 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str8));
              switch (heff_tag_of(v_t_2420)) {
              case TAG_True: {
                heff_drop(v_p_240);
                HEFF_LAST return g_heff_2einterp_2eint2(((V)&g_heff_2einterp_2eprim_lam3_clo));
              }
              case TAG_False: {
                V v_t_2426 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str11));
                switch (heff_tag_of(v_t_2426)) {
                case TAG_True: {
                  heff_drop(v_p_240);
                  HEFF_LAST return g_heff_2einterp_2eint2(((V)&g_heff_2einterp_2eprim_lam4_clo));
                }
                case TAG_False: {
                  V v_t_2432 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str14));
                  switch (heff_tag_of(v_t_2432)) {
                  case TAG_True: {
                    heff_drop(v_p_240);
                    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam5_clo)});
                  }
                  case TAG_False: {
                    V v_t_2446 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str15));
                    switch (heff_tag_of(v_t_2446)) {
                    case TAG_True: {
                      heff_drop(v_p_240);
                      return heff_dup(g_heff_2einterp_2efloat2_24s1965813471x487337709_get());
                    }
                    case TAG_False: {
                      V v_t_2447 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str16));
                      switch (heff_tag_of(v_t_2447)) {
                      case TAG_True: {
                        heff_drop(v_p_240);
                        return heff_dup(g_heff_2einterp_2efloat2_24s2003084928x2062825913_get());
                      }
                      case TAG_False: {
                        V v_t_2448 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str17));
                        switch (heff_tag_of(v_t_2448)) {
                        case TAG_True: {
                          heff_drop(v_p_240);
                          return heff_dup(g_heff_2einterp_2efloat2_24s1423458924x1394741838_get());
                        }
                        case TAG_False: {
                          V v_t_2449 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str18));
                          switch (heff_tag_of(v_t_2449)) {
                          case TAG_True: {
                            heff_drop(v_p_240);
                            return heff_dup(g_heff_2einterp_2efloat2_24s205358756x116382871_get());
                          }
                          case TAG_False: {
                            V v_t_2450 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str19));
                            switch (heff_tag_of(v_t_2450)) {
                            case TAG_True: {
                              heff_drop(v_p_240);
                              HEFF_LAST return g_heff_2einterp_2efloat2(((V)&g_heff_2einterp_2eprim_lam6_clo));
                            }
                            case TAG_False: {
                              V v_t_2456 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str22));
                              switch (heff_tag_of(v_t_2456)) {
                              case TAG_True: {
                                heff_drop(v_p_240);
                                HEFF_LAST return g_heff_2einterp_2efloat2(((V)&g_heff_2einterp_2eprim_lam7_clo));
                              }
                              case TAG_False: {
                                V v_t_2462 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str25));
                                switch (heff_tag_of(v_t_2462)) {
                                case TAG_True: {
                                  heff_drop(v_p_240);
                                  HEFF_LAST return g_heff_2einterp_2efloat2(((V)&g_heff_2einterp_2eprim_lam8_clo));
                                }
                                case TAG_False: {
                                  V v_t_2468 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str28));
                                  switch (heff_tag_of(v_t_2468)) {
                                  case TAG_True: {
                                    heff_drop(v_p_240);
                                    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam9_clo)});
                                  }
                                  case TAG_False: {
                                    V v_t_2482 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str29));
                                    switch (heff_tag_of(v_t_2482)) {
                                    case TAG_True: {
                                      heff_drop(v_p_240);
                                      return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam10_clo)});
                                    }
                                    case TAG_False: {
                                      V v_t_2496 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str30));
                                      switch (heff_tag_of(v_t_2496)) {
                                      case TAG_True: {
                                        heff_drop(v_p_240);
                                        return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam11_clo)});
                                      }
                                      case TAG_False: {
                                        V v_t_24110 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str31));
                                        switch (heff_tag_of(v_t_24110)) {
                                        case TAG_True: {
                                          heff_drop(v_p_240);
                                          return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam12_clo)});
                                        }
                                        case TAG_False: {
                                          V v_t_24125 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str32));
                                          switch (heff_tag_of(v_t_24125)) {
                                          case TAG_True: {
                                            heff_drop(v_p_240);
                                            return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam13_clo)});
                                          }
                                          case TAG_False: {
                                            V v_t_24139 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str33));
                                            switch (heff_tag_of(v_t_24139)) {
                                            case TAG_True: {
                                              heff_drop(v_p_240);
                                              return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam14_clo)});
                                            }
                                            case TAG_False: {
                                              V v_t_24153 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str34));
                                              switch (heff_tag_of(v_t_24153)) {
                                              case TAG_True: {
                                                heff_drop(v_p_240);
                                                return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam15_clo)});
                                              }
                                              case TAG_False: {
                                                V v_t_24167 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str35));
                                                switch (heff_tag_of(v_t_24167)) {
                                                case TAG_True: {
                                                  heff_drop(v_p_240);
                                                  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam16_clo)});
                                                }
                                                case TAG_False: {
                                                  V v_t_24181 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str36));
                                                  switch (heff_tag_of(v_t_24181)) {
                                                  case TAG_True: {
                                                    heff_drop(v_p_240);
                                                    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam17_clo)});
                                                  }
                                                  case TAG_False: {
                                                    V v_t_24195 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str37));
                                                    switch (heff_tag_of(v_t_24195)) {
                                                    case TAG_True: {
                                                      heff_drop(v_p_240);
                                                      return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam18_clo)});
                                                    }
                                                    case TAG_False: {
                                                      V v_t_24209 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str38));
                                                      switch (heff_tag_of(v_t_24209)) {
                                                      case TAG_True: {
                                                        heff_drop(v_p_240);
                                                        return heff_dup(g_heff_2einterp_2efloat2_24s1759709581x228229611_get());
                                                      }
                                                      case TAG_False: {
                                                        V v_t_24210 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str39));
                                                        switch (heff_tag_of(v_t_24210)) {
                                                        case TAG_True: {
                                                          heff_drop(v_p_240);
                                                          return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam19_clo)});
                                                        }
                                                        case TAG_False: {
                                                          V v_t_24224 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str40));
                                                          switch (heff_tag_of(v_t_24224)) {
                                                          case TAG_True: {
                                                            heff_drop(v_p_240);
                                                            return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam20_clo)});
                                                          }
                                                          case TAG_False: {
                                                            V v_t_24238 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str41));
                                                            switch (heff_tag_of(v_t_24238)) {
                                                            case TAG_True: {
                                                              heff_drop(v_p_240);
                                                              return heff_dup(g_heff_2einterp_2efloat2_24s615196179x236480627_get());
                                                            }
                                                            case TAG_False: {
                                                              V v_t_24239 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str42));
                                                              switch (heff_tag_of(v_t_24239)) {
                                                              case TAG_True: {
                                                                heff_drop(v_p_240);
                                                                return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam21_clo)});
                                                              }
                                                              case TAG_False: {
                                                                V v_t_24255 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str43));
                                                                switch (heff_tag_of(v_t_24255)) {
                                                                case TAG_True: {
                                                                  heff_drop(v_p_240);
                                                                  return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam23_clo)});
                                                                }
                                                                case TAG_False: {
                                                                  V v_t_24287 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str44));
                                                                  switch (heff_tag_of(v_t_24287)) {
                                                                  case TAG_True: {
                                                                    heff_drop(v_p_240);
                                                                    return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam26_clo)});
                                                                  }
                                                                  case TAG_False: {
                                                                    V v_t_24323 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str45));
                                                                    switch (heff_tag_of(v_t_24323)) {
                                                                    case TAG_True: {
                                                                      heff_drop(v_p_240);
                                                                      return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam30_clo)});
                                                                    }
                                                                    case TAG_False: {
                                                                      V v_t_24344 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str46));
                                                                      switch (heff_tag_of(v_t_24344)) {
                                                                      case TAG_True: {
                                                                        heff_drop(v_p_240);
                                                                        return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam34_clo)});
                                                                      }
                                                                      case TAG_False: {
                                                                        V v_t_24353 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str47));
                                                                        switch (heff_tag_of(v_t_24353)) {
                                                                        case TAG_True: {
                                                                          heff_drop(v_p_240);
                                                                          return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam36_clo)});
                                                                        }
                                                                        case TAG_False: {
                                                                          V v_t_24368 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str48));
                                                                          switch (heff_tag_of(v_t_24368)) {
                                                                          case TAG_True: {
                                                                            heff_drop(v_p_240);
                                                                            return heff_dup(g_heff_2einterp_2estr2_24s1802929932x1594371566_get());
                                                                          }
                                                                          case TAG_False: {
                                                                            V v_t_24369 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str49));
                                                                            switch (heff_tag_of(v_t_24369)) {
                                                                            case TAG_True: {
                                                                              heff_drop(v_p_240);
                                                                              return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam38_clo)});
                                                                            }
                                                                            case TAG_False: {
                                                                              V v_t_24383 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str50));
                                                                              switch (heff_tag_of(v_t_24383)) {
                                                                              case TAG_True: {
                                                                                heff_drop(v_p_240);
                                                                                return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam39_clo)});
                                                                              }
                                                                              case TAG_False: {
                                                                                V v_t_24421 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str51));
                                                                                switch (heff_tag_of(v_t_24421)) {
                                                                                case TAG_True: {
                                                                                  heff_drop(v_p_240);
                                                                                  HEFF_LAST return g_heff_2einterp_2estr2(((V)&g_heff_2einterp_2eprim_lam42_clo));
                                                                                }
                                                                                case TAG_False: {
                                                                                  V v_t_24427 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str54));
                                                                                  switch (heff_tag_of(v_t_24427)) {
                                                                                  case TAG_True: {
                                                                                    heff_drop(v_p_240);
                                                                                    HEFF_LAST return g_heff_2einterp_2estr2(((V)&g_heff_2einterp_2eprim_lam43_clo));
                                                                                  }
                                                                                  case TAG_False: {
                                                                                    V v_t_24433 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str57));
                                                                                    switch (heff_tag_of(v_t_24433)) {
                                                                                    case TAG_True: {
                                                                                      heff_drop(v_p_240);
                                                                                      return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam44_clo)});
                                                                                    }
                                                                                    case TAG_False: {
                                                                                      V v_t_24459 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2einterp_2eprim_str58));
                                                                                      switch (heff_tag_of(v_t_24459)) {
                                                                                      case TAG_True: {
                                                                                        heff_drop(v_p_240);
                                                                                        return heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam46_clo)});
                                                                                      }
                                                                                      case TAG_False: {
                                                                                        V v_t_24473 = (g_heff_2efixed_2efixedPrimOf(v_p_240));
                                                                                        switch (heff_tag_of(v_t_24473)) {
                                                                                        case TAG_Nothing: {
                                                                                          return heff_abandon();
                                                                                        }
                                                                                        case TAG_Just: {
                                                                                          V v_fp_24474 = heff_field(v_t_24473, 0);
                                                                                          heff_take_n(v_t_24473, 1ULL, 1);
                                                                                          HEFF_LAST return g_heff_2einterp_2efixedPrimV(v_fp_24474);
                                                                                        }
                                                                                        default: return heff_nomatch(v_t_24473);
                                                                                        }
                                                                                      }
                                                                                      default: return heff_nomatch(v_t_24459);
                                                                                      }
                                                                                    }
                                                                                    default: return heff_nomatch(v_t_24433);
                                                                                    }
                                                                                  }
                                                                                  default: return heff_nomatch(v_t_24427);
                                                                                  }
                                                                                }
                                                                                default: return heff_nomatch(v_t_24421);
                                                                                }
                                                                              }
                                                                              default: return heff_nomatch(v_t_24383);
                                                                              }
                                                                            }
                                                                            default: return heff_nomatch(v_t_24369);
                                                                            }
                                                                          }
                                                                          default: return heff_nomatch(v_t_24368);
                                                                          }
                                                                        }
                                                                        default: return heff_nomatch(v_t_24353);
                                                                        }
                                                                      }
                                                                      default: return heff_nomatch(v_t_24344);
                                                                      }
                                                                    }
                                                                    default: return heff_nomatch(v_t_24323);
                                                                    }
                                                                  }
                                                                  default: return heff_nomatch(v_t_24287);
                                                                  }
                                                                }
                                                                default: return heff_nomatch(v_t_24255);
                                                                }
                                                              }
                                                              default: return heff_nomatch(v_t_24239);
                                                              }
                                                            }
                                                            default: return heff_nomatch(v_t_24238);
                                                            }
                                                          }
                                                          default: return heff_nomatch(v_t_24224);
                                                          }
                                                        }
                                                        default: return heff_nomatch(v_t_24210);
                                                        }
                                                      }
                                                      default: return heff_nomatch(v_t_24209);
                                                      }
                                                    }
                                                    default: return heff_nomatch(v_t_24195);
                                                    }
                                                  }
                                                  default: return heff_nomatch(v_t_24181);
                                                  }
                                                }
                                                default: return heff_nomatch(v_t_24167);
                                                }
                                              }
                                              default: return heff_nomatch(v_t_24153);
                                              }
                                            }
                                            default: return heff_nomatch(v_t_24139);
                                            }
                                          }
                                          default: return heff_nomatch(v_t_24125);
                                          }
                                        }
                                        default: return heff_nomatch(v_t_24110);
                                        }
                                      }
                                      default: return heff_nomatch(v_t_2496);
                                      }
                                    }
                                    default: return heff_nomatch(v_t_2482);
                                    }
                                  }
                                  default: return heff_nomatch(v_t_2468);
                                  }
                                }
                                default: return heff_nomatch(v_t_2462);
                                }
                              }
                              default: return heff_nomatch(v_t_2456);
                              }
                            }
                            default: return heff_nomatch(v_t_2450);
                            }
                          }
                          default: return heff_nomatch(v_t_2449);
                          }
                        }
                        default: return heff_nomatch(v_t_2448);
                        }
                      }
                      default: return heff_nomatch(v_t_2447);
                      }
                    }
                    default: return heff_nomatch(v_t_2446);
                    }
                  }
                  default: return heff_nomatch(v_t_2432);
                  }
                }
                default: return heff_nomatch(v_t_2426);
                }
              }
              default: return heff_nomatch(v_t_2420);
              }
            }
            default: return heff_nomatch(v_t_2414);
            }
          }
          default: return heff_nomatch(v_t_249);
          }
        }
        default: return heff_nomatch(v_t_244);
        }
      }
      default: return heff_nomatch(v_t_243);
      }
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2einterp_2eprim_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eprim(a[0]);
}
V g_heff_2einterp_2eprim_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_b_246 = args[1];
  V v_t_247 = heff_intEq(heff_dup(v_b_246), MK_INT(0LL));
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_a_245);
    heff_drop(v_b_246);
    return NTAG(TAG_Abn);
  }
  case TAG_False: {
    V v_t_248 = heff_intDiv(v_a_245, v_b_246);
    return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_t_248})});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2einterp_2eprim_lam1(V self, V *args) {
  V v_a_2410 = args[0];
  V v_b_2411 = args[1];
  V v_t_2412 = heff_intEq(heff_dup(v_b_2411), MK_INT(0LL));
  switch (heff_tag_of(v_t_2412)) {
  case TAG_True: {
    heff_drop(v_a_2410);
    heff_drop(v_b_2411);
    return NTAG(TAG_Abn);
  }
  case TAG_False: {
    V v_t_2413 = heff_intMod(v_a_2410, v_b_2411);
    return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_t_2413})});
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2einterp_2eprim_lam2(V self, V *args) {
  V v_a_2415 = args[0];
  V v_b_2416 = args[1];
  V v_t_2417 = heff_intEq(v_a_2415, v_b_2416);
  V v_t_2418;
  switch (heff_tag_of(v_t_2417)) {
  case TAG_True: {
    v_t_2418 = ((V)&g_heff_2einterp_2eprim_str6);
    break;
  }
  case TAG_False: {
    v_t_2418 = ((V)&g_heff_2einterp_2eprim_str7);
    break;
  }
  default: heff_nomatch(v_t_2417);
  }
  V v_t_2419 = heff_tag(TAG_VTag, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2419});
}
V g_heff_2einterp_2eprim_lam3(V self, V *args) {
  V v_a_2421 = args[0];
  V v_b_2422 = args[1];
  V v_t_2423 = heff_intLt(v_a_2421, v_b_2422);
  V v_t_2424;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_True: {
    v_t_2424 = ((V)&g_heff_2einterp_2eprim_str9);
    break;
  }
  case TAG_False: {
    v_t_2424 = ((V)&g_heff_2einterp_2eprim_str10);
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  V v_t_2425 = heff_tag(TAG_VTag, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2425});
}
V g_heff_2einterp_2eprim_lam4(V self, V *args) {
  V v_a_2427 = args[0];
  V v_b_2428 = args[1];
  V v_t_2429 = heff_intLe(v_a_2427, v_b_2428);
  V v_t_2430;
  switch (heff_tag_of(v_t_2429)) {
  case TAG_True: {
    v_t_2430 = ((V)&g_heff_2einterp_2eprim_str12);
    break;
  }
  case TAG_False: {
    v_t_2430 = ((V)&g_heff_2einterp_2eprim_str13);
    break;
  }
  default: heff_nomatch(v_t_2429);
  }
  V v_t_2431 = heff_tag(TAG_VTag, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2431});
}
V g_heff_2einterp_2eprim_lam5(V self, V *args) {
  V v_d_2433 = args[0];
  V v_a_2434 = args[1];
  V v_x1_2435 = heff_tr(heff_apply(v_a_2434, 1, (V[]){v_d_2433}));
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_Ok: {
    V v_v_2436 = heff_field(v_x1_2435, 0);
    V v_ru_24x1_2435_24Ok = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
    switch (heff_tag_of(v_v_2436)) {
    case TAG_VFun: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_2436, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_2441 = heff_field(v_v_2436, 0);
      V v_ru_24v_2436_24VInt = heff_take_reuse_n(v_v_2436, 1ULL, 1);
      V v_t_2442 = heff_tag_at(v_ru_24x1_2435_24Ok, TAG_VStr, 1, (V[]){heff_intShow(v_a_2441)});
      return heff_tag_at(v_ru_24v_2436_24VInt, TAG_Ok, 1, (V[]){v_t_2442});
    }
    case TAG_VFloat: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_2436);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_2435);
  }
}
V g_heff_2einterp_2eprim_lam6(V self, V *args) {
  V v_a_2451 = args[0];
  V v_b_2452 = args[1];
  V v_t_2453 = heff_floatEq(v_a_2451, v_b_2452);
  V v_t_2454;
  switch (heff_tag_of(v_t_2453)) {
  case TAG_True: {
    v_t_2454 = ((V)&g_heff_2einterp_2eprim_str20);
    break;
  }
  case TAG_False: {
    v_t_2454 = ((V)&g_heff_2einterp_2eprim_str21);
    break;
  }
  default: heff_nomatch(v_t_2453);
  }
  V v_t_2455 = heff_tag(TAG_VTag, 2, (V[]){v_t_2454, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2455});
}
V g_heff_2einterp_2eprim_lam7(V self, V *args) {
  V v_a_2457 = args[0];
  V v_b_2458 = args[1];
  V v_t_2459 = heff_floatLt(v_a_2457, v_b_2458);
  V v_t_2460;
  switch (heff_tag_of(v_t_2459)) {
  case TAG_True: {
    v_t_2460 = ((V)&g_heff_2einterp_2eprim_str23);
    break;
  }
  case TAG_False: {
    v_t_2460 = ((V)&g_heff_2einterp_2eprim_str24);
    break;
  }
  default: heff_nomatch(v_t_2459);
  }
  V v_t_2461 = heff_tag(TAG_VTag, 2, (V[]){v_t_2460, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2461});
}
V g_heff_2einterp_2eprim_lam8(V self, V *args) {
  V v_a_2463 = args[0];
  V v_b_2464 = args[1];
  V v_t_2465 = heff_floatLe(v_a_2463, v_b_2464);
  V v_t_2466;
  switch (heff_tag_of(v_t_2465)) {
  case TAG_True: {
    v_t_2466 = ((V)&g_heff_2einterp_2eprim_str26);
    break;
  }
  case TAG_False: {
    v_t_2466 = ((V)&g_heff_2einterp_2eprim_str27);
    break;
  }
  default: heff_nomatch(v_t_2465);
  }
  V v_t_2467 = heff_tag(TAG_VTag, 2, (V[]){v_t_2466, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_2467});
}
V g_heff_2einterp_2eprim_lam9(V self, V *args) {
  V v_d_2469 = args[0];
  V v_a_2470 = args[1];
  V v_x1_2471 = heff_tr(heff_apply(v_a_2470, 1, (V[]){v_d_2469}));
  switch (heff_tag_of(v_x1_2471)) {
  case TAG_Ok: {
    V v_v_2472 = heff_field(v_x1_2471, 0);
    V v_ru_24x1_2471_24Ok = heff_take_reuse_n(v_x1_2471, 1ULL, 1);
    switch (heff_tag_of(v_v_2472)) {
    case TAG_VFun: {
      heff_take_n(v_v_2472, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2471_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_2472, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2471_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_2472, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2471_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_2472, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2471_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_2478 = heff_field(v_v_2472, 0);
      V v_ru_24v_2472_24VFloat = heff_take_reuse_n(v_v_2472, 1ULL, 1);
      V v_t_2479 = heff_tag_at(v_ru_24x1_2471_24Ok, TAG_VStr, 1, (V[]){heff_floatShow(v_a_2478)});
      return heff_tag_at(v_ru_24v_2472_24VFloat, TAG_Ok, 1, (V[]){v_t_2479});
    }
    case TAG_VStr: {
      heff_take_n(v_v_2472, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2471_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_2472, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2471_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2471_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_2472);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_2471);
  }
}
V g_heff_2einterp_2eprim_lam10(V self, V *args) {
  V v_d_2483 = args[0];
  V v_a_2484 = args[1];
  V v_x1_2485 = heff_tr(heff_apply(v_a_2484, 1, (V[]){v_d_2483}));
  switch (heff_tag_of(v_x1_2485)) {
  case TAG_Ok: {
    V v_v_2486 = heff_field(v_x1_2485, 0);
    V v_ru_24x1_2485_24Ok = heff_take_reuse_n(v_x1_2485, 1ULL, 1);
    switch (heff_tag_of(v_v_2486)) {
    case TAG_VFun: {
      heff_take_n(v_v_2486, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2485_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_2486, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2485_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_2486, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2485_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_2491 = heff_field(v_v_2486, 0);
      V v_ru_24v_2486_24VInt = heff_take_reuse_n(v_v_2486, 1ULL, 1);
      V v_t_2492 = heff_tag_at(v_ru_24x1_2485_24Ok, TAG_VFloat, 1, (V[]){heff_floatFromInt(v_a_2491)});
      return heff_tag_at(v_ru_24v_2486_24VInt, TAG_Ok, 1, (V[]){v_t_2492});
    }
    case TAG_VFloat: {
      heff_take_n(v_v_2486, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2485_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_2486, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2485_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_2486, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2485_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2485_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_2486);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_2485);
  }
}
V g_heff_2einterp_2eprim_lam11(V self, V *args) {
  V v_d_2497 = args[0];
  V v_a_2498 = args[1];
  V v_x1_2499 = heff_tr(heff_apply(v_a_2498, 1, (V[]){v_d_2497}));
  switch (heff_tag_of(v_x1_2499)) {
  case TAG_Ok: {
    V v_v_24100 = heff_field(v_x1_2499, 0);
    V v_ru_24x1_2499_24Ok = heff_take_reuse_n(v_x1_2499, 1ULL, 1);
    switch (heff_tag_of(v_v_24100)) {
    case TAG_VFun: {
      heff_take_n(v_v_24100, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2499_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24100, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2499_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24100, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2499_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24100, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2499_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24106 = heff_field(v_v_24100, 0);
      V v_ru_24v_24100_24VFloat = heff_take_reuse_n(v_v_24100, 1ULL, 1);
      V v_t_24107 = heff_tag_at(v_ru_24x1_2499_24Ok, TAG_VFloat, 1, (V[]){heff_floatSqrt(v_a_24106)});
      return heff_tag_at(v_ru_24v_24100_24VFloat, TAG_Ok, 1, (V[]){v_t_24107});
    }
    case TAG_VStr: {
      heff_take_n(v_v_24100, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2499_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24100, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2499_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2499_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24100);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_2499);
  }
}
V g_heff_2einterp_2eprim_lam12(V self, V *args) {
  V v_d_24111 = args[0];
  V v_a_24112 = args[1];
  V v_x1_24113 = heff_tr(heff_apply(v_a_24112, 1, (V[]){v_d_24111}));
  switch (heff_tag_of(v_x1_24113)) {
  case TAG_Ok: {
    V v_v_24114 = heff_field(v_x1_24113, 0);
    V v_ru_24x1_24113_24Ok = heff_take_reuse_n(v_x1_24113, 1ULL, 1);
    switch (heff_tag_of(v_v_24114)) {
    case TAG_VFun: {
      heff_take_n(v_v_24114, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24113_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24114, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24113_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24114, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24113_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24114, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24113_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24120 = heff_field(v_v_24114, 0);
      heff_take_n(v_v_24114, 1ULL, 1);
      V v_t_24121 = heff_floatEq(heff_floatSub(heff_dup(v_a_24120), heff_dup(v_a_24120)), heff_flt(0.0));
      switch (heff_tag_of(v_t_24121)) {
      case TAG_True: {
        V v_t_24122 = heff_floatFloor(v_a_24120);
        return heff_tag_at(v_ru_24x1_24113_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_t_24122})});
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x1_24113_24Ok, 1);
        heff_drop(v_a_24120);
        return NTAG(TAG_Abn);
      }
      default: return heff_nomatch(v_t_24121);
      }
    }
    case TAG_VStr: {
      heff_take_n(v_v_24114, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24113_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24114, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24113_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24113_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24114);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24113);
  }
}
V g_heff_2einterp_2eprim_lam13(V self, V *args) {
  V v_d_24126 = args[0];
  V v_a_24127 = args[1];
  V v_x1_24128 = heff_tr(heff_apply(v_a_24127, 1, (V[]){v_d_24126}));
  switch (heff_tag_of(v_x1_24128)) {
  case TAG_Ok: {
    V v_v_24129 = heff_field(v_x1_24128, 0);
    V v_ru_24x1_24128_24Ok = heff_take_reuse_n(v_x1_24128, 1ULL, 1);
    switch (heff_tag_of(v_v_24129)) {
    case TAG_VFun: {
      heff_take_n(v_v_24129, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24128_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24129, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24128_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24129, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24128_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24129, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24128_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24135 = heff_field(v_v_24129, 0);
      V v_ru_24v_24129_24VFloat = heff_take_reuse_n(v_v_24129, 1ULL, 1);
      V v_t_24136 = heff_tag_at(v_ru_24x1_24128_24Ok, TAG_VFloat, 1, (V[]){heff_floatSin(v_a_24135)});
      return heff_tag_at(v_ru_24v_24129_24VFloat, TAG_Ok, 1, (V[]){v_t_24136});
    }
    case TAG_VStr: {
      heff_take_n(v_v_24129, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24128_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24129, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24128_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24128_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24129);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24128);
  }
}
V g_heff_2einterp_2eprim_lam14(V self, V *args) {
  V v_d_24140 = args[0];
  V v_a_24141 = args[1];
  V v_x1_24142 = heff_tr(heff_apply(v_a_24141, 1, (V[]){v_d_24140}));
  switch (heff_tag_of(v_x1_24142)) {
  case TAG_Ok: {
    V v_v_24143 = heff_field(v_x1_24142, 0);
    V v_ru_24x1_24142_24Ok = heff_take_reuse_n(v_x1_24142, 1ULL, 1);
    switch (heff_tag_of(v_v_24143)) {
    case TAG_VFun: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24143, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24149 = heff_field(v_v_24143, 0);
      V v_ru_24v_24143_24VFloat = heff_take_reuse_n(v_v_24143, 1ULL, 1);
      V v_t_24150 = heff_tag_at(v_ru_24x1_24142_24Ok, TAG_VFloat, 1, (V[]){heff_floatCos(v_a_24149)});
      return heff_tag_at(v_ru_24v_24143_24VFloat, TAG_Ok, 1, (V[]){v_t_24150});
    }
    case TAG_VStr: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24143);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24142);
  }
}
V g_heff_2einterp_2eprim_lam15(V self, V *args) {
  V v_d_24154 = args[0];
  V v_a_24155 = args[1];
  V v_x1_24156 = heff_tr(heff_apply(v_a_24155, 1, (V[]){v_d_24154}));
  switch (heff_tag_of(v_x1_24156)) {
  case TAG_Ok: {
    V v_v_24157 = heff_field(v_x1_24156, 0);
    V v_ru_24x1_24156_24Ok = heff_take_reuse_n(v_x1_24156, 1ULL, 1);
    switch (heff_tag_of(v_v_24157)) {
    case TAG_VFun: {
      heff_take_n(v_v_24157, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24156_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24157, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24156_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24157, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24156_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24157, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24156_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24163 = heff_field(v_v_24157, 0);
      V v_ru_24v_24157_24VFloat = heff_take_reuse_n(v_v_24157, 1ULL, 1);
      V v_t_24164 = heff_tag_at(v_ru_24x1_24156_24Ok, TAG_VFloat, 1, (V[]){heff_floatTan(v_a_24163)});
      return heff_tag_at(v_ru_24v_24157_24VFloat, TAG_Ok, 1, (V[]){v_t_24164});
    }
    case TAG_VStr: {
      heff_take_n(v_v_24157, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24156_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24157, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24156_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24156_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24157);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24156);
  }
}
V g_heff_2einterp_2eprim_lam16(V self, V *args) {
  V v_d_24168 = args[0];
  V v_a_24169 = args[1];
  V v_x1_24170 = heff_tr(heff_apply(v_a_24169, 1, (V[]){v_d_24168}));
  switch (heff_tag_of(v_x1_24170)) {
  case TAG_Ok: {
    V v_v_24171 = heff_field(v_x1_24170, 0);
    V v_ru_24x1_24170_24Ok = heff_take_reuse_n(v_x1_24170, 1ULL, 1);
    switch (heff_tag_of(v_v_24171)) {
    case TAG_VFun: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24171, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24177 = heff_field(v_v_24171, 0);
      V v_ru_24v_24171_24VFloat = heff_take_reuse_n(v_v_24171, 1ULL, 1);
      V v_t_24178 = heff_tag_at(v_ru_24x1_24170_24Ok, TAG_VFloat, 1, (V[]){heff_floatAsin(v_a_24177)});
      return heff_tag_at(v_ru_24v_24171_24VFloat, TAG_Ok, 1, (V[]){v_t_24178});
    }
    case TAG_VStr: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24171);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24170);
  }
}
V g_heff_2einterp_2eprim_lam17(V self, V *args) {
  V v_d_24182 = args[0];
  V v_a_24183 = args[1];
  V v_x1_24184 = heff_tr(heff_apply(v_a_24183, 1, (V[]){v_d_24182}));
  switch (heff_tag_of(v_x1_24184)) {
  case TAG_Ok: {
    V v_v_24185 = heff_field(v_x1_24184, 0);
    V v_ru_24x1_24184_24Ok = heff_take_reuse_n(v_x1_24184, 1ULL, 1);
    switch (heff_tag_of(v_v_24185)) {
    case TAG_VFun: {
      heff_take_n(v_v_24185, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24184_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24185, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24184_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24185, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24184_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24185, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24184_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24191 = heff_field(v_v_24185, 0);
      V v_ru_24v_24185_24VFloat = heff_take_reuse_n(v_v_24185, 1ULL, 1);
      V v_t_24192 = heff_tag_at(v_ru_24x1_24184_24Ok, TAG_VFloat, 1, (V[]){heff_floatAcos(v_a_24191)});
      return heff_tag_at(v_ru_24v_24185_24VFloat, TAG_Ok, 1, (V[]){v_t_24192});
    }
    case TAG_VStr: {
      heff_take_n(v_v_24185, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24184_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24185, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24184_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24184_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24185);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24184);
  }
}
V g_heff_2einterp_2eprim_lam18(V self, V *args) {
  V v_d_24196 = args[0];
  V v_a_24197 = args[1];
  V v_x1_24198 = heff_tr(heff_apply(v_a_24197, 1, (V[]){v_d_24196}));
  switch (heff_tag_of(v_x1_24198)) {
  case TAG_Ok: {
    V v_v_24199 = heff_field(v_x1_24198, 0);
    V v_ru_24x1_24198_24Ok = heff_take_reuse_n(v_x1_24198, 1ULL, 1);
    switch (heff_tag_of(v_v_24199)) {
    case TAG_VFun: {
      heff_take_n(v_v_24199, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24198_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24199, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24198_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24199, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24198_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24199, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24198_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24205 = heff_field(v_v_24199, 0);
      V v_ru_24v_24199_24VFloat = heff_take_reuse_n(v_v_24199, 1ULL, 1);
      V v_t_24206 = heff_tag_at(v_ru_24x1_24198_24Ok, TAG_VFloat, 1, (V[]){heff_floatAtan(v_a_24205)});
      return heff_tag_at(v_ru_24v_24199_24VFloat, TAG_Ok, 1, (V[]){v_t_24206});
    }
    case TAG_VStr: {
      heff_take_n(v_v_24199, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24198_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24199, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24198_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24198_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24199);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24198);
  }
}
V g_heff_2einterp_2eprim_lam19(V self, V *args) {
  V v_d_24211 = args[0];
  V v_a_24212 = args[1];
  V v_x1_24213 = heff_tr(heff_apply(v_a_24212, 1, (V[]){v_d_24211}));
  switch (heff_tag_of(v_x1_24213)) {
  case TAG_Ok: {
    V v_v_24214 = heff_field(v_x1_24213, 0);
    V v_ru_24x1_24213_24Ok = heff_take_reuse_n(v_x1_24213, 1ULL, 1);
    switch (heff_tag_of(v_v_24214)) {
    case TAG_VFun: {
      heff_take_n(v_v_24214, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24213_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24214, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24213_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24214, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24213_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24214, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24213_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24220 = heff_field(v_v_24214, 0);
      V v_ru_24v_24214_24VFloat = heff_take_reuse_n(v_v_24214, 1ULL, 1);
      V v_t_24221 = heff_tag_at(v_ru_24x1_24213_24Ok, TAG_VFloat, 1, (V[]){heff_floatExp(v_a_24220)});
      return heff_tag_at(v_ru_24v_24214_24VFloat, TAG_Ok, 1, (V[]){v_t_24221});
    }
    case TAG_VStr: {
      heff_take_n(v_v_24214, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24213_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24214, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24213_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24213_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24214);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24213);
  }
}
V g_heff_2einterp_2eprim_lam20(V self, V *args) {
  V v_d_24225 = args[0];
  V v_a_24226 = args[1];
  V v_x1_24227 = heff_tr(heff_apply(v_a_24226, 1, (V[]){v_d_24225}));
  switch (heff_tag_of(v_x1_24227)) {
  case TAG_Ok: {
    V v_v_24228 = heff_field(v_x1_24227, 0);
    V v_ru_24x1_24227_24Ok = heff_take_reuse_n(v_x1_24227, 1ULL, 1);
    switch (heff_tag_of(v_v_24228)) {
    case TAG_VFun: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24228, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      V v_a_24234 = heff_field(v_v_24228, 0);
      V v_ru_24v_24228_24VFloat = heff_take_reuse_n(v_v_24228, 1ULL, 1);
      V v_t_24235 = heff_tag_at(v_ru_24x1_24227_24Ok, TAG_VFloat, 1, (V[]){heff_floatLog(v_a_24234)});
      return heff_tag_at(v_ru_24v_24228_24VFloat, TAG_Ok, 1, (V[]){v_t_24235});
    }
    case TAG_VStr: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24228);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24227);
  }
}
V g_heff_2einterp_2eprim_lam22(V self, V *args) {
  V v_d_24242 = args[0];
  V v_a_24243 = args[1];
  V v_x1_24244 = heff_tr(heff_apply(v_a_24243, 1, (V[]){v_d_24242}));
  switch (heff_tag_of(v_x1_24244)) {
  case TAG_Ok: {
    V v_v_24245 = heff_field(v_x1_24244, 0);
    V v_ru_24x1_24244_24Ok = heff_take_reuse_n(v_x1_24244, 1ULL, 1);
    switch (heff_tag_of(v_v_24245)) {
    case TAG_VFun: {
      heff_take_n(v_v_24245, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24244_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24245, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24244_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24245, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24244_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24245, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24244_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24245, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24244_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24245, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24244_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      V v_xs_24253 = heff_field(v_v_24245, 0);
      V v_ru_24v_24245_24VArr = heff_take_reuse_n(v_v_24245, 1ULL, 1);
      V v_t_24254 = heff_tag_at(v_ru_24x1_24244_24Ok, TAG_VInt, 1, (V[]){({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(v_xs_24253); V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, b_2)); heff_drop(b_2); r_; })});
      return heff_tag_at(v_ru_24v_24245_24VArr, TAG_Ok, 1, (V[]){v_t_24254});
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24244_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24245);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24244);
  }
}
V g_heff_2einterp_2eprim_lam21(V self, V *args) {
  V v_d_24240 = args[0];
  V v_u_24241 = args[1];
  heff_drop(v_d_24240);
  heff_drop(v_u_24241);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam22_clo)})});
}
V g_heff_2einterp_2eprim_lam25(V self, V *args) {
  V v_d_24270 = args[0];
  V v_a_24271 = args[1];
  V v_xs_24269 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24272 = heff_tr(heff_apply(v_a_24271, 1, (V[]){v_d_24270}));
  switch (heff_tag_of(v_x1_24272)) {
  case TAG_Ok: {
    V v_v_24273 = heff_field(v_x1_24272, 0);
    V v_ru_24x1_24272_24Ok = heff_take_reuse_n(v_x1_24272, 1ULL, 1);
    switch (heff_tag_of(v_v_24273)) {
    case TAG_VFun: {
      heff_take_n(v_v_24273, 0ULL, 1);
      heff_drop(v_xs_24269);
      heff_drop_cell(v_ru_24x1_24272_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24273, 0ULL, 1);
      heff_drop(v_xs_24269);
      heff_drop_cell(v_ru_24x1_24272_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24273, 0ULL, 2);
      heff_drop(v_xs_24269);
      heff_drop_cell(v_ru_24x1_24272_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24278 = heff_field(v_v_24273, 0);
      heff_take_n(v_v_24273, 1ULL, 1);
      V v_t_24279 = heff_intLe(MK_INT(0LL), heff_dup(v_a_24278));
      switch (heff_tag_of(v_t_24279)) {
      case TAG_True: {
        V v_t_24280 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24269)); V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        V v_t_24281 = heff_intLt(heff_dup(v_a_24278), v_t_24280);
        switch (heff_tag_of(v_t_24281)) {
        case TAG_True: {
          V v_t_24282 = ({ V b_0 = heff_arrayToList(v_xs_24269); V a_1 = v_a_24278; V r_ = (g_heff_2einterp_2enthV(b_0, a_1)); heff_drop(b_0); r_; });
          switch (heff_tag_of(v_t_24282)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x1_24272_24Ok, 1);
            return NTAG(TAG_Abn);
          }
          case TAG_Just: {
            V v_v_24283 = heff_field(v_t_24282, 0);
            heff_take_n(v_t_24282, 1ULL, 1);
            return heff_tag_at(v_ru_24x1_24272_24Ok, TAG_Ok, 1, (V[]){v_v_24283});
          }
          default: return heff_nomatch(v_t_24282);
          }
        }
        case TAG_False: {
          heff_drop(v_xs_24269);
          heff_drop_cell(v_ru_24x1_24272_24Ok, 1);
          heff_drop(v_a_24278);
          return NTAG(TAG_Abn);
        }
        default: return heff_nomatch(v_t_24281);
        }
      }
      case TAG_False: {
        heff_drop(v_xs_24269);
        heff_drop_cell(v_ru_24x1_24272_24Ok, 1);
        heff_drop(v_a_24278);
        return NTAG(TAG_Abn);
      }
      default: return heff_nomatch(v_t_24279);
      }
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24273, 0ULL, 1);
      heff_drop(v_xs_24269);
      heff_drop_cell(v_ru_24x1_24272_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24273, 0ULL, 1);
      heff_drop(v_xs_24269);
      heff_drop_cell(v_ru_24x1_24272_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24273, 0ULL, 1);
      heff_drop(v_xs_24269);
      heff_drop_cell(v_ru_24x1_24272_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_xs_24269);
      heff_drop_cell(v_ru_24x1_24272_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24273);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24269);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24269);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24272);
  }
}
V g_heff_2einterp_2eprim_lam24(V self, V *args) {
  V v_d_24258 = args[0];
  V v_a_24259 = args[1];
  V v_x1_24260 = heff_tr(heff_apply(v_a_24259, 1, (V[]){v_d_24258}));
  switch (heff_tag_of(v_x1_24260)) {
  case TAG_Ok: {
    V v_v_24261 = heff_field(v_x1_24260, 0);
    V v_ru_24x1_24260_24Ok = heff_take_reuse_n(v_x1_24260, 1ULL, 1);
    switch (heff_tag_of(v_v_24261)) {
    case TAG_VFun: {
      heff_take_n(v_v_24261, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24260_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24261, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24260_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24261, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24260_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24261, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24260_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24261, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24260_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24261, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24260_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      V v_xs_24269 = heff_field(v_v_24261, 0);
      heff_take_n(v_v_24261, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_24260_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam25, 2, 1, (V[]){v_xs_24269})})});
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24260_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24261);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24260);
  }
}
V g_heff_2einterp_2eprim_lam23(V self, V *args) {
  V v_d_24256 = args[0];
  V v_u_24257 = args[1];
  heff_drop(v_d_24256);
  heff_drop(v_u_24257);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam24_clo)})});
}
V g_heff_2einterp_2eprim_lam29(V self, V *args) {
  V v_d_24311 = args[0];
  V v_x_24312 = args[1];
  V v_a_24310 = heff_env(self)[0];
  V v_xs_24301 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24313 = heff_tr(heff_apply(v_x_24312, 1, (V[]){v_d_24311}));
  switch (heff_tag_of(v_x1_24313)) {
  case TAG_Ok: {
    V v_v_24314 = heff_field(v_x1_24313, 0);
    V v_ru_24x1_24313_24Ok = heff_take_reuse_n(v_x1_24313, 1ULL, 1);
    V v_t_24315 = heff_intLe(MK_INT(0LL), heff_dup(v_a_24310));
    switch (heff_tag_of(v_t_24315)) {
    case TAG_True: {
      V v_t_24316 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24301)); V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_24317 = heff_intLt(heff_dup(v_a_24310), v_t_24316);
      switch (heff_tag_of(v_t_24317)) {
      case TAG_True: {
        V v_t_24318 = (g_heff_2einterp_2esetAt(heff_arrayToList(v_xs_24301), v_a_24310, v_v_24314));
        V v_t_24319 = heff_tag_at(v_ru_24x1_24313_24Ok, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24318)});
        return heff_tag(TAG_Ok, 1, (V[]){v_t_24319});
      }
      case TAG_False: {
        heff_drop(v_a_24310);
        heff_drop(v_xs_24301);
        heff_drop(v_v_24314);
        heff_drop_cell(v_ru_24x1_24313_24Ok, 1);
        return NTAG(TAG_Abn);
      }
      default: return heff_nomatch(v_t_24317);
      }
    }
    case TAG_False: {
      heff_drop(v_a_24310);
      heff_drop(v_xs_24301);
      heff_drop(v_v_24314);
      heff_drop_cell(v_ru_24x1_24313_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    default: return heff_nomatch(v_t_24315);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24310);
    heff_drop(v_xs_24301);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24310);
    heff_drop(v_xs_24301);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24313);
  }
}
V g_heff_2einterp_2eprim_lam28(V self, V *args) {
  V v_d_24302 = args[0];
  V v_a_24303 = args[1];
  V v_xs_24301 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24304 = heff_tr(heff_apply(v_a_24303, 1, (V[]){v_d_24302}));
  switch (heff_tag_of(v_x1_24304)) {
  case TAG_Ok: {
    V v_v_24305 = heff_field(v_x1_24304, 0);
    V v_ru_24x1_24304_24Ok = heff_take_reuse_n(v_x1_24304, 1ULL, 1);
    switch (heff_tag_of(v_v_24305)) {
    case TAG_VFun: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop(v_xs_24301);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop(v_xs_24301);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24305, 0ULL, 2);
      heff_drop(v_xs_24301);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24310 = heff_field(v_v_24305, 0);
      heff_take_n(v_v_24305, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_24304_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam29, 2, 2, (V[]){v_a_24310, v_xs_24301})})});
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop(v_xs_24301);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop(v_xs_24301);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop(v_xs_24301);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_xs_24301);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24305);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24301);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24301);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24304);
  }
}
V g_heff_2einterp_2eprim_lam27(V self, V *args) {
  V v_d_24290 = args[0];
  V v_a_24291 = args[1];
  V v_x1_24292 = heff_tr(heff_apply(v_a_24291, 1, (V[]){v_d_24290}));
  switch (heff_tag_of(v_x1_24292)) {
  case TAG_Ok: {
    V v_v_24293 = heff_field(v_x1_24292, 0);
    V v_ru_24x1_24292_24Ok = heff_take_reuse_n(v_x1_24292, 1ULL, 1);
    switch (heff_tag_of(v_v_24293)) {
    case TAG_VFun: {
      heff_take_n(v_v_24293, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24292_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24293, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24292_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24293, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24292_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24293, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24292_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24293, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24292_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24293, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24292_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      V v_xs_24301 = heff_field(v_v_24293, 0);
      heff_take_n(v_v_24293, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_24292_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam28, 2, 1, (V[]){v_xs_24301})})});
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24292_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24293);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24292);
  }
}
V g_heff_2einterp_2eprim_lam26(V self, V *args) {
  V v_d_24288 = args[0];
  V v_u_24289 = args[1];
  heff_drop(v_d_24288);
  heff_drop(v_u_24289);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam27_clo)})});
}
V g_heff_2einterp_2eprim_lam33(V self, V *args) {
  V v_vs_24339 = args[0];
  V v_t_24340 = heff_tag(TAG_VArr, 1, (V[]){heff_arrayFromList(v_vs_24339)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_24340});
}
V g_heff_2einterp_2eprim_lam32(V self, V *args) {
  V v_d_24335 = args[0];
  V v_f_24336 = args[1];
  V v_a_24334 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24337 = heff_tr(heff_apply(v_f_24336, 1, (V[]){heff_dup(v_d_24335)}));
  switch (heff_tag_of(v_x1_24337)) {
  case TAG_Ok: {
    V v_v_24338 = heff_field(v_x1_24337, 0);
    heff_take_n(v_x1_24337, 1ULL, 1);
    return (g_heff_2einterp_2egenGo(v_d_24335, MK_INT(0LL), v_a_24334, v_v_24338, ((V)&g_heff_2einterp_2eprim_lam33_clo)));
  }
  case TAG_Abn: {
    heff_drop(v_d_24335);
    heff_drop(v_a_24334);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_24335);
    heff_drop(v_a_24334);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24337);
  }
}
V g_heff_2einterp_2eprim_lam31(V self, V *args) {
  V v_d_24326 = args[0];
  V v_a_24327 = args[1];
  V v_x1_24328 = heff_tr(heff_apply(v_a_24327, 1, (V[]){v_d_24326}));
  switch (heff_tag_of(v_x1_24328)) {
  case TAG_Ok: {
    V v_v_24329 = heff_field(v_x1_24328, 0);
    V v_ru_24x1_24328_24Ok = heff_take_reuse_n(v_x1_24328, 1ULL, 1);
    switch (heff_tag_of(v_v_24329)) {
    case TAG_VFun: {
      heff_take_n(v_v_24329, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24328_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24329, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24328_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24329, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24328_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24334 = heff_field(v_v_24329, 0);
      heff_take_n(v_v_24329, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_24328_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam32, 2, 1, (V[]){v_a_24334})})});
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24329, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24328_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24329, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24328_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24329, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24328_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24328_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24329);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24328);
  }
}
V g_heff_2einterp_2eprim_lam30(V self, V *args) {
  V v_d_24324 = args[0];
  V v_u_24325 = args[1];
  heff_drop(v_d_24324);
  heff_drop(v_u_24325);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam31_clo)})});
}
V g_heff_2einterp_2eprim_lam35(V self, V *args) {
  V v_d_24347 = args[0];
  V v_l_24348 = args[1];
  V v_x1_24349 = heff_tr(heff_apply(v_l_24348, 1, (V[]){v_d_24347}));
  switch (heff_tag_of(v_x1_24349)) {
  case TAG_Ok: {
    V v_v_24350 = heff_field(v_x1_24349, 0);
    V v_ru_24x1_24349_24Ok = heff_take_reuse_n(v_x1_24349, 1ULL, 1);
    V v_t_24351 = (g_heff_2einterp_2efromListV(v_v_24350, NTAG(TAG_Nil)));
    V v_t_24352 = heff_tag_at(v_ru_24x1_24349_24Ok, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24351)});
    return heff_tag(TAG_Ok, 1, (V[]){v_t_24352});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24349);
  }
}
V g_heff_2einterp_2eprim_lam34(V self, V *args) {
  V v_d_24345 = args[0];
  V v_u_24346 = args[1];
  heff_drop(v_d_24345);
  heff_drop(v_u_24346);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam35_clo)})});
}
V g_heff_2einterp_2eprim_lam37(V self, V *args) {
  V v_d_24356 = args[0];
  V v_a_24357 = args[1];
  V v_x1_24358 = heff_tr(heff_apply(v_a_24357, 1, (V[]){v_d_24356}));
  switch (heff_tag_of(v_x1_24358)) {
  case TAG_Ok: {
    V v_v_24359 = heff_field(v_x1_24358, 0);
    V v_ru_24x1_24358_24Ok = heff_take_reuse_n(v_x1_24358, 1ULL, 1);
    switch (heff_tag_of(v_v_24359)) {
    case TAG_VFun: {
      heff_take_n(v_v_24359, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24358_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24359, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24358_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24359, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24358_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24359, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24358_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24359, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24358_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24359, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24358_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      V v_xs_24367 = heff_field(v_v_24359, 0);
      heff_take_n(v_v_24359, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_24358_24Ok, TAG_Ok, 1, (V[]){(g_heff_2einterp_2etoListV(heff_arrayToList(v_xs_24367)))});
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24358_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24359);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24358);
  }
}
V g_heff_2einterp_2eprim_lam36(V self, V *args) {
  V v_d_24354 = args[0];
  V v_u_24355 = args[1];
  heff_drop(v_d_24354);
  heff_drop(v_u_24355);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){((V)&g_heff_2einterp_2eprim_lam37_clo)})});
}
V g_heff_2einterp_2eprim_lam38(V self, V *args) {
  V v_d_24370 = args[0];
  V v_a_24371 = args[1];
  V v_x1_24372 = heff_tr(heff_apply(v_a_24371, 1, (V[]){v_d_24370}));
  switch (heff_tag_of(v_x1_24372)) {
  case TAG_Ok: {
    V v_v_24373 = heff_field(v_x1_24372, 0);
    V v_ru_24x1_24372_24Ok = heff_take_reuse_n(v_x1_24372, 1ULL, 1);
    switch (heff_tag_of(v_v_24373)) {
    case TAG_VFun: {
      heff_take_n(v_v_24373, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24372_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24373, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24372_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24373, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24372_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24373, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24372_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24373, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24372_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      V v_a_24380 = heff_field(v_v_24373, 0);
      V v_ru_24v_24373_24VStr = heff_take_reuse_n(v_v_24373, 1ULL, 1);
      V v_t_24381 = heff_tag_at(v_ru_24x1_24372_24Ok, TAG_VInt, 1, (V[]){heff_strLength(v_a_24380)});
      return heff_tag_at(v_ru_24v_24373_24VStr, TAG_Ok, 1, (V[]){v_t_24381});
    }
    case TAG_VArr: {
      heff_take_n(v_v_24373, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24372_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24372_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24373);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24372);
  }
}
V g_heff_2einterp_2eprim_lam41(V self, V *args) {
  V v_d_24404 = args[0];
  V v_a_24405 = args[1];
  V v_a_24394 = heff_env(self)[0];
  V v_a_24403 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24406 = heff_tr(heff_apply(v_a_24405, 1, (V[]){v_d_24404}));
  switch (heff_tag_of(v_x1_24406)) {
  case TAG_Ok: {
    V v_v_24407 = heff_field(v_x1_24406, 0);
    V v_ru_24x1_24406_24Ok = heff_take_reuse_n(v_x1_24406, 1ULL, 1);
    switch (heff_tag_of(v_v_24407)) {
    case TAG_VFun: {
      heff_take_n(v_v_24407, 0ULL, 1);
      heff_drop(v_a_24394);
      heff_drop(v_a_24403);
      heff_drop_cell(v_ru_24x1_24406_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24407, 0ULL, 1);
      heff_drop(v_a_24394);
      heff_drop(v_a_24403);
      heff_drop_cell(v_ru_24x1_24406_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24407, 0ULL, 2);
      heff_drop(v_a_24394);
      heff_drop(v_a_24403);
      heff_drop_cell(v_ru_24x1_24406_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24412 = heff_field(v_v_24407, 0);
      V v_ru_24v_24407_24VInt = heff_take_reuse_n(v_v_24407, 1ULL, 1);
      V v_t_24413 = heff_tag_at(v_ru_24x1_24406_24Ok, TAG_VStr, 1, (V[]){heff_strSlice(v_a_24394, v_a_24403, v_a_24412)});
      return heff_tag_at(v_ru_24v_24407_24VInt, TAG_Ok, 1, (V[]){v_t_24413});
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24407, 0ULL, 1);
      heff_drop(v_a_24394);
      heff_drop(v_a_24403);
      heff_drop_cell(v_ru_24x1_24406_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24407, 0ULL, 1);
      heff_drop(v_a_24394);
      heff_drop(v_a_24403);
      heff_drop_cell(v_ru_24x1_24406_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24407, 0ULL, 1);
      heff_drop(v_a_24394);
      heff_drop(v_a_24403);
      heff_drop_cell(v_ru_24x1_24406_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_a_24394);
      heff_drop(v_a_24403);
      heff_drop_cell(v_ru_24x1_24406_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24407);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24394);
    heff_drop(v_a_24403);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24394);
    heff_drop(v_a_24403);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24406);
  }
}
V g_heff_2einterp_2eprim_lam40(V self, V *args) {
  V v_d_24395 = args[0];
  V v_a_24396 = args[1];
  V v_a_24394 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24397 = heff_tr(heff_apply(v_a_24396, 1, (V[]){v_d_24395}));
  switch (heff_tag_of(v_x1_24397)) {
  case TAG_Ok: {
    V v_v_24398 = heff_field(v_x1_24397, 0);
    V v_ru_24x1_24397_24Ok = heff_take_reuse_n(v_x1_24397, 1ULL, 1);
    switch (heff_tag_of(v_v_24398)) {
    case TAG_VFun: {
      heff_take_n(v_v_24398, 0ULL, 1);
      heff_drop(v_a_24394);
      heff_drop_cell(v_ru_24x1_24397_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24398, 0ULL, 1);
      heff_drop(v_a_24394);
      heff_drop_cell(v_ru_24x1_24397_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24398, 0ULL, 2);
      heff_drop(v_a_24394);
      heff_drop_cell(v_ru_24x1_24397_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24403 = heff_field(v_v_24398, 0);
      heff_take_n(v_v_24398, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_24397_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam41, 2, 2, (V[]){v_a_24394, v_a_24403})})});
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24398, 0ULL, 1);
      heff_drop(v_a_24394);
      heff_drop_cell(v_ru_24x1_24397_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24398, 0ULL, 1);
      heff_drop(v_a_24394);
      heff_drop_cell(v_ru_24x1_24397_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24398, 0ULL, 1);
      heff_drop(v_a_24394);
      heff_drop_cell(v_ru_24x1_24397_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_a_24394);
      heff_drop_cell(v_ru_24x1_24397_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24398);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24394);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24394);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24397);
  }
}
V g_heff_2einterp_2eprim_lam39(V self, V *args) {
  V v_d_24384 = args[0];
  V v_a_24385 = args[1];
  V v_x1_24386 = heff_tr(heff_apply(v_a_24385, 1, (V[]){v_d_24384}));
  switch (heff_tag_of(v_x1_24386)) {
  case TAG_Ok: {
    V v_v_24387 = heff_field(v_x1_24386, 0);
    V v_ru_24x1_24386_24Ok = heff_take_reuse_n(v_x1_24386, 1ULL, 1);
    switch (heff_tag_of(v_v_24387)) {
    case TAG_VFun: {
      heff_take_n(v_v_24387, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24386_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24387, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24386_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24387, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24386_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24387, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24386_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24387, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24386_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      V v_a_24394 = heff_field(v_v_24387, 0);
      heff_take_n(v_v_24387, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_24386_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam40, 2, 1, (V[]){v_a_24394})})});
    }
    case TAG_VArr: {
      heff_take_n(v_v_24387, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24386_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24386_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24387);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24386);
  }
}
V g_heff_2einterp_2eprim_lam42(V self, V *args) {
  V v_a_24422 = args[0];
  V v_b_24423 = args[1];
  V v_t_24424 = heff_strEq(v_a_24422, v_b_24423);
  V v_t_24425;
  switch (heff_tag_of(v_t_24424)) {
  case TAG_True: {
    v_t_24425 = ((V)&g_heff_2einterp_2eprim_str52);
    break;
  }
  case TAG_False: {
    v_t_24425 = ((V)&g_heff_2einterp_2eprim_str53);
    break;
  }
  default: heff_nomatch(v_t_24424);
  }
  V v_t_24426 = heff_tag(TAG_VTag, 2, (V[]){v_t_24425, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_24426});
}
V g_heff_2einterp_2eprim_lam43(V self, V *args) {
  V v_a_24428 = args[0];
  V v_b_24429 = args[1];
  V v_t_24430 = heff_strLt(v_a_24428, v_b_24429);
  V v_t_24431;
  switch (heff_tag_of(v_t_24430)) {
  case TAG_True: {
    v_t_24431 = ((V)&g_heff_2einterp_2eprim_str55);
    break;
  }
  case TAG_False: {
    v_t_24431 = ((V)&g_heff_2einterp_2eprim_str56);
    break;
  }
  default: heff_nomatch(v_t_24430);
  }
  V v_t_24432 = heff_tag(TAG_VTag, 2, (V[]){v_t_24431, NTAG(TAG_Nil)});
  return heff_tag(TAG_Ok, 1, (V[]){v_t_24432});
}
V g_heff_2einterp_2eprim_lam45(V self, V *args) {
  V v_d_24445 = args[0];
  V v_a_24446 = args[1];
  V v_a_24444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24447 = heff_tr(heff_apply(v_a_24446, 1, (V[]){v_d_24445}));
  switch (heff_tag_of(v_x1_24447)) {
  case TAG_Ok: {
    V v_v_24448 = heff_field(v_x1_24447, 0);
    V v_ru_24x1_24447_24Ok = heff_take_reuse_n(v_x1_24447, 1ULL, 1);
    switch (heff_tag_of(v_v_24448)) {
    case TAG_VFun: {
      heff_take_n(v_v_24448, 0ULL, 1);
      heff_drop(v_a_24444);
      heff_drop_cell(v_ru_24x1_24447_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24448, 0ULL, 1);
      heff_drop(v_a_24444);
      heff_drop_cell(v_ru_24x1_24447_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24448, 0ULL, 2);
      heff_drop(v_a_24444);
      heff_drop_cell(v_ru_24x1_24447_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24453 = heff_field(v_v_24448, 0);
      V v_ru_24v_24448_24VInt = heff_take_reuse_n(v_v_24448, 1ULL, 1);
      V v_t_24454 = heff_tag_at(v_ru_24x1_24447_24Ok, TAG_VInt, 1, (V[]){heff_strCharCode(v_a_24444, v_a_24453)});
      return heff_tag_at(v_ru_24v_24448_24VInt, TAG_Ok, 1, (V[]){v_t_24454});
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24448, 0ULL, 1);
      heff_drop(v_a_24444);
      heff_drop_cell(v_ru_24x1_24447_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24448, 0ULL, 1);
      heff_drop(v_a_24444);
      heff_drop_cell(v_ru_24x1_24447_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24448, 0ULL, 1);
      heff_drop(v_a_24444);
      heff_drop_cell(v_ru_24x1_24447_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop(v_a_24444);
      heff_drop_cell(v_ru_24x1_24447_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24448);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24444);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24444);
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24447);
  }
}
V g_heff_2einterp_2eprim_lam44(V self, V *args) {
  V v_d_24434 = args[0];
  V v_a_24435 = args[1];
  V v_x1_24436 = heff_tr(heff_apply(v_a_24435, 1, (V[]){v_d_24434}));
  switch (heff_tag_of(v_x1_24436)) {
  case TAG_Ok: {
    V v_v_24437 = heff_field(v_x1_24436, 0);
    V v_ru_24x1_24436_24Ok = heff_take_reuse_n(v_x1_24436, 1ULL, 1);
    switch (heff_tag_of(v_v_24437)) {
    case TAG_VFun: {
      heff_take_n(v_v_24437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24436_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24436_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24437, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24436_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      heff_take_n(v_v_24437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24436_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24436_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      V v_a_24444 = heff_field(v_v_24437, 0);
      heff_take_n(v_v_24437, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_24436_24Ok, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eprim_lam45, 2, 1, (V[]){v_a_24444})})});
    }
    case TAG_VArr: {
      heff_take_n(v_v_24437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24436_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24436_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24437);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24436);
  }
}
V g_heff_2einterp_2eprim_lam46(V self, V *args) {
  V v_d_24460 = args[0];
  V v_a_24461 = args[1];
  V v_x1_24462 = heff_tr(heff_apply(v_a_24461, 1, (V[]){v_d_24460}));
  switch (heff_tag_of(v_x1_24462)) {
  case TAG_Ok: {
    V v_v_24463 = heff_field(v_x1_24462, 0);
    V v_ru_24x1_24462_24Ok = heff_take_reuse_n(v_x1_24462, 1ULL, 1);
    switch (heff_tag_of(v_v_24463)) {
    case TAG_VFun: {
      heff_take_n(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VCons: {
      heff_take_n(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VTag: {
      heff_take_n(v_v_24463, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VInt: {
      V v_a_24468 = heff_field(v_v_24463, 0);
      V v_ru_24v_24463_24VInt = heff_take_reuse_n(v_v_24463, 1ULL, 1);
      V v_t_24469 = heff_tag_at(v_ru_24x1_24462_24Ok, TAG_VStr, 1, (V[]){heff_strFromCharCode(v_a_24468)});
      return heff_tag_at(v_ru_24v_24463_24VInt, TAG_Ok, 1, (V[]){v_t_24469});
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VStr: {
      heff_take_n(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VArr: {
      heff_take_n(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_abandon();
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_v_24463);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  default: return heff_nomatch(v_x1_24462);
  }
}
Clo g_heff_2einterp_2enthTh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2enthTh_entry, 2, 0};

V g_heff_2einterp_2enthTh(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_intEq(heff_dup(v_i_241), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_i_241);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    }
    case TAG_False: {
      V v_t_245 = heff_intLt(heff_dup(v_i_241), MK_INT(0LL));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        heff_drop(v_i_241);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2einterp_2enthTh_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2enthTh(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2einterp_2eevalEach_lam0(V self, V *args);
Clo g_heff_2einterp_2eevalEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eevalEach_entry, 3, 0};

V g_heff_2einterp_2eevalEach(V v_ev_240, V v_x2_241, V v_k_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ev_240);
    return heff_tail(v_k_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_t_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_x1_245 = heff_tr(heff_apply(heff_dup(v_ev_240), 1, (V[]){v_t_243}));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_Ok: {
      V v_v_246 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      V t_0 = v_ev_240;
      V t_1 = v_rest_244;
      V t_2 = heff_clo(g_heff_2einterp_2eevalEach_lam0, 1, 2, (V[]){v_k_242, v_v_246});
      v_ev_240 = t_0;
      v_x2_241 = t_1;
      v_k_242 = t_2;
      goto top;
    }
    case TAG_Abn: {
      heff_drop(v_ev_240);
      heff_drop(v_k_242);
      heff_drop(v_rest_244);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_ev_240);
      heff_drop(v_k_242);
      heff_drop(v_rest_244);
      return NTAG(TAG_Div);
    }
    default: return heff_nomatch(v_x1_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2einterp_2eevalEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eevalEach(a[0], a[1], a[2]);
}
V g_heff_2einterp_2eevalEach_lam0(V self, V *args) {
  V v_vs_247 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_v_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_242;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_v_246, v_vs_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2einterp_2eevalFields_lam0(V self, V *args);
Clo g_heff_2einterp_2eevalFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eevalFields_entry, 3, 0};

V g_heff_2einterp_2eevalFields(V v_ev_240, V v_x2_241, V v_k_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ev_240);
    return heff_tail(v_k_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkPair: {
      V v_l_245 = heff_field(v_x21_243, 0);
      V v_t_246 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      V v_x1_247 = heff_tr(heff_apply(heff_dup(v_ev_240), 1, (V[]){v_t_246}));
      switch (heff_tag_of(v_x1_247)) {
      case TAG_Ok: {
        V v_v_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V t_0 = v_ev_240;
        V t_1 = v_rest_244;
        V t_2 = heff_clo(g_heff_2einterp_2eevalFields_lam0, 1, 3, (V[]){v_l_245, v_v_248, v_k_242});
        v_ev_240 = t_0;
        v_x2_241 = t_1;
        v_k_242 = t_2;
        goto top;
      }
      case TAG_Abn: {
        heff_drop(v_ev_240);
        heff_drop(v_k_242);
        heff_drop(v_rest_244);
        heff_drop(v_l_245);
        return NTAG(TAG_Abn);
      }
      case TAG_Div: {
        heff_drop(v_ev_240);
        heff_drop(v_k_242);
        heff_drop(v_rest_244);
        heff_drop(v_l_245);
        return NTAG(TAG_Div);
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2einterp_2eevalFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eevalFields(a[0], a[1], a[2]);
}
V g_heff_2einterp_2eevalFields_lam0(V self, V *args) {
  V v_vs_249 = args[0];
  V v_l_245 = heff_env(self)[0];
  V v_v_248 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_l_245, v_v_248}), v_vs_249});
  V f_ = v_k_242;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2einterp_2eevalIn_lam0(V self, V *args);
V g_heff_2einterp_2eevalIn_lam1(V self, V *args);
V g_heff_2einterp_2eevalIn_lam2(V self, V *args);
V g_heff_2einterp_2eevalIn_lam3(V self, V *args);
V g_heff_2einterp_2eevalIn_lam4(V self, V *args); static Clo g_heff_2einterp_2eevalIn_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eevalIn_lam4, 1, 0};
V g_heff_2einterp_2eevalIn_lam5(V self, V *args);
V g_heff_2einterp_2eevalIn_lam6(V self, V *args);
V g_heff_2einterp_2eevalIn_lam7(V self, V *args);
Clo g_heff_2einterp_2eevalIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eevalIn_entry, 3, 0};

V g_heff_2einterp_2eevalIn(V v_d_240, V v_e_241, V v_t_242) {
top: ;
  V v_t_243 = heff_intLt(heff_dup(g_heff_2einterp_2edeepest_get()), heff_dup(v_d_240));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_d_240);
    heff_drop(v_e_241);
    heff_drop(v_t_242);
    return NTAG(TAG_Div);
  }
  case TAG_False: {
    switch (heff_tag_of(v_t_242)) {
    case TAG_SLocal: {
      V v_i_244 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V v_t_245 = ({ V b_0 = heff_get(v_e_241, LBL_local); V a_1 = v_i_244; V r_ = (g_heff_2einterp_2enthTh(b_0, a_1)); heff_drop(b_0); r_; });
      switch (heff_tag_of(v_t_245)) {
      case TAG_Nothing: {
        heff_drop(v_d_240);
        return heff_abandon();
      }
      case TAG_Just: {
        V v_v_246 = heff_field(v_t_245, 0);
        heff_take_n(v_t_245, 1ULL, 1);
        return heff_tail(v_v_246, 1, (V[]){v_d_240});
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    case TAG_SGlobal: {
      V v_x_247 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V v_t_248 = ({ V a_0 = v_x_247; V b_1 = heff_get(v_e_241, LBL_global); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nothing: {
        heff_drop(v_d_240);
        return heff_abandon();
      }
      case TAG_Just: {
        V v_v_249 = heff_field(v_t_248, 0);
        heff_take_n(v_t_248, 1ULL, 1);
        return heff_tail(v_v_249, 1, (V[]){v_d_240});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    case TAG_SCode: {
      V v_ru_24t_242_24SCode = heff_take_reuse_n(v_t_242, 0ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag_at(v_ru_24t_242_24SCode, TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
    }
    case TAG_SApp: {
      V v_t1_2411 = heff_field(v_t_242, 0);
      V v_t2_2412 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      V v_x1_2413 = heff_tr(g_heff_2einterp_2eevalIn(heff_intAdd(heff_dup(v_d_240), MK_INT(1LL)), heff_dup(v_e_241), v_t1_2411));
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_Ok: {
        V v_v_2414 = heff_field(v_x1_2413, 0);
        V v_ru_24x1_2413_24Ok = heff_take_reuse_n(v_x1_2413, 1ULL, 1);
        V v_x1_2415 = heff_tr(g_heff_2einterp_2eevalIn(heff_intAdd(heff_dup(v_d_240), MK_INT(1LL)), v_e_241, v_t2_2412));
        switch (heff_tag_of(v_x1_2415)) {
        case TAG_Ok: {
          V v_v_2416 = heff_field(v_x1_2415, 0);
          heff_take_n(v_x1_2415, 1ULL, 1);
          switch (heff_tag_of(v_v_2414)) {
          case TAG_VFun: {
            V v_f_2417 = heff_field(v_v_2414, 0);
            heff_take_n(v_v_2414, 1ULL, 1);
            heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
            return heff_tail(v_f_2417, 2, (V[]){v_d_240, heff_clo(g_heff_2einterp_2eevalIn_lam0, 1, 1, (V[]){v_v_2416})});
          }
          case TAG_VCons: {
            heff_take_n(v_v_2414, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VTag: {
            heff_take_n(v_v_2414, 0ULL, 2);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VInt: {
            heff_take_n(v_v_2414, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VFloat: {
            heff_take_n(v_v_2414, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VStr: {
            heff_take_n(v_v_2414, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VArr: {
            heff_take_n(v_v_2414, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
            heff_drop(v_v_2416);
            return heff_abandon();
          }
          case TAG_VErased: {
            heff_drop(v_d_240);
            heff_drop(v_v_2416);
            return heff_tag_at(v_ru_24x1_2413_24Ok, TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
          }
          default: return heff_nomatch(v_v_2414);
          }
        }
        case TAG_Abn: {
          heff_drop(v_d_240);
          heff_drop(v_v_2414);
          heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
          return NTAG(TAG_Abn);
        }
        case TAG_Div: {
          heff_drop(v_d_240);
          heff_drop(v_v_2414);
          heff_drop_cell(v_ru_24x1_2413_24Ok, 1);
          return NTAG(TAG_Div);
        }
        default: return heff_nomatch(v_x1_2415);
        }
      }
      case TAG_Abn: {
        heff_drop(v_d_240);
        heff_drop(v_e_241);
        heff_drop(v_t2_2412);
        return NTAG(TAG_Abn);
      }
      case TAG_Div: {
        heff_drop(v_d_240);
        heff_drop(v_e_241);
        heff_drop(v_t2_2412);
        return NTAG(TAG_Div);
      }
      default: return heff_nomatch(v_x1_2413);
      }
    }
    case TAG_SLam: {
      V v_it2_2427 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 2ULL, 2);
      heff_drop(v_d_240);
      switch (heff_tag_of(v_it2_2427)) {
      case TAG_MkAbs: {
        V v_body_2429 = heff_field(v_it2_2427, 1);
        heff_take_n(v_it2_2427, 2ULL, 2);
        return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eevalIn_lam1, 2, 2, (V[]){v_e_241, v_body_2429})})});
      }
      case TAG_AbsConst: {
        V v_body_2434 = heff_field(v_it2_2427, 0);
        V v_ru_24it2_2427_24AbsConst = heff_take_reuse_n(v_it2_2427, 1ULL, 1);
        return heff_tag_at(v_ru_24it2_2427_24AbsConst, TAG_Ok, 1, (V[]){heff_tag(TAG_VFun, 1, (V[]){heff_clo(g_heff_2einterp_2eevalIn_lam2, 2, 2, (V[]){v_e_241, v_body_2434})})});
      }
      default: return heff_nomatch(v_it2_2427);
      }
    }
    case TAG_SCons: {
      V v_fs_2437 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V v_t_2438 = heff_arrayToList(heff_get(heff_dup(v_fs_2437), LBL_keys));
      V v_t_2439 = heff_arrayToList(heff_get(v_fs_2437, LBL_values));
      V v_t_2440 = (g_heff_2edict_2ezipKV(v_t_2438, v_t_2439));
      HEFF_LAST return g_heff_2einterp_2eevalFields(heff_clo(g_heff_2einterp_2eevalIn_lam3, 1, 2, (V[]){v_d_240, v_e_241}), v_t_2440, ((V)&g_heff_2einterp_2eevalIn_lam4_clo));
    }
    case TAG_SProj: {
      V v_t2_2447 = heff_field(v_t_242, 0);
      V v_x_2448 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      V v_x1_2449 = heff_tr(g_heff_2einterp_2eevalIn(heff_intAdd(v_d_240, MK_INT(1LL)), v_e_241, v_t2_2447));
      switch (heff_tag_of(v_x1_2449)) {
      case TAG_Ok: {
        V v_v_2450 = heff_field(v_x1_2449, 0);
        heff_take_n(v_x1_2449, 1ULL, 1);
        return (g_heff_2einterp_2eprojV(v_v_2450, v_x_2448));
      }
      case TAG_Abn: {
        heff_drop(v_x_2448);
        return NTAG(TAG_Abn);
      }
      case TAG_Div: {
        heff_drop(v_x_2448);
        return NTAG(TAG_Div);
      }
      default: return heff_nomatch(v_x1_2449);
      }
    }
    case TAG_STag: {
      V v_x_2451 = heff_field(v_t_242, 0);
      V v_ts_2452 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      HEFF_LAST return g_heff_2einterp_2eevalEach(heff_clo(g_heff_2einterp_2eevalIn_lam5, 1, 2, (V[]){v_d_240, v_e_241}), heff_arrayToList(v_ts_2452), heff_clo(g_heff_2einterp_2eevalIn_lam6, 1, 1, (V[]){v_x_2451}));
    }
    case TAG_SMatch: {
      V v_scrut_2455 = heff_field(v_t_242, 0);
      V v_cases_2456 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      V v_x1_2457 = heff_tr(g_heff_2einterp_2eevalIn(heff_intAdd(heff_dup(v_d_240), MK_INT(1LL)), heff_dup(v_e_241), v_scrut_2455));
      switch (heff_tag_of(v_x1_2457)) {
      case TAG_Ok: {
        V v_v_2458 = heff_field(v_x1_2457, 0);
        V v_ru_24x1_2457_24Ok = heff_take_reuse_n(v_x1_2457, 1ULL, 1);
        switch (heff_tag_of(v_v_2458)) {
        case TAG_VFun: {
          heff_take_n(v_v_2458, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2456);
          heff_drop_cell(v_ru_24x1_2457_24Ok, 1);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_v_2458, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2456);
          heff_drop_cell(v_ru_24x1_2457_24Ok, 1);
          return heff_abandon();
        }
        case TAG_VTag: {
          V v_x_2461 = heff_field(v_v_2458, 0);
          V v_vs_2462 = heff_field(v_v_2458, 1);
          heff_take_n(v_v_2458, 3ULL, 2);
          V v_t_2463 = ({ V a_0 = v_x_2461; V b_1 = heff_get(heff_dup(v_cases_2456), LBL_byName); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
          V v_it_2469;
          switch (heff_tag_of(v_t_2463)) {
          case TAG_Nothing: {
            heff_drop(v_cases_2456);
            heff_drop_cell(v_ru_24x1_2457_24Ok, 1);
            v_it_2469 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_i_2464 = heff_field(v_t_2463, 0);
            heff_take_n(v_t_2463, 1ULL, 1);
            V v_xs_2465 = heff_get(v_cases_2456, LBL_values);
            V v_t_2466 = heff_intLe(MK_INT(0LL), heff_dup(v_i_2464));
            switch (heff_tag_of(v_t_2466)) {
            case TAG_True: {
              V v_t_2467 = heff_intLt(heff_dup(v_i_2464), heff_arrayLength(heff_dup(v_xs_2465)));
              switch (heff_tag_of(v_t_2467)) {
              case TAG_True: {
                V v_t_2468 = heff_arrayIndex(v_xs_2465, v_i_2464);
                v_it_2469 = heff_tag_at(v_ru_24x1_2457_24Ok, TAG_Just, 1, (V[]){v_t_2468});
                break;
              }
              case TAG_False: {
                heff_drop_cell(v_ru_24x1_2457_24Ok, 1);
                heff_drop(v_i_2464);
                heff_drop(v_xs_2465);
                v_it_2469 = NTAG(TAG_Nothing);
                break;
              }
              default: heff_nomatch(v_t_2467);
              }
              break;
            }
            case TAG_False: {
              heff_drop_cell(v_ru_24x1_2457_24Ok, 1);
              heff_drop(v_i_2464);
              heff_drop(v_xs_2465);
              v_it_2469 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_t_2466);
            }
            break;
          }
          default: heff_nomatch(v_t_2463);
          }
          switch (heff_tag_of(v_it_2469)) {
          case TAG_Nothing: {
            heff_drop(v_d_240);
            heff_drop(v_e_241);
            heff_drop(v_vs_2462);
            return heff_abandon();
          }
          case TAG_Just: {
            V v_it1_2470 = heff_field(v_it_2469, 0);
            heff_take_n(v_it_2469, 1ULL, 1);
            switch (heff_tag_of(v_it1_2470)) {
            case TAG_MkPair: {
              V v_body_2472 = heff_field(v_it1_2470, 1);
              heff_take_n(v_it1_2470, 2ULL, 2);
              V v_t_2473 = (g_prelude_2efoldl_24s680066967x839815107(v_e_241, v_vs_2462));
              V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
              V t_1 = v_t_2473;
              V t_2 = v_body_2472;
              v_d_240 = t_0;
              v_e_241 = t_1;
              v_t_242 = t_2;
              goto top;
            }
            default: return heff_nomatch(v_it1_2470);
            }
          }
          default: return heff_nomatch(v_it_2469);
          }
        }
        case TAG_VInt: {
          heff_take_n(v_v_2458, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2456);
          heff_drop_cell(v_ru_24x1_2457_24Ok, 1);
          return heff_abandon();
        }
        case TAG_VFloat: {
          heff_take_n(v_v_2458, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2456);
          heff_drop_cell(v_ru_24x1_2457_24Ok, 1);
          return heff_abandon();
        }
        case TAG_VStr: {
          heff_take_n(v_v_2458, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2456);
          heff_drop_cell(v_ru_24x1_2457_24Ok, 1);
          return heff_abandon();
        }
        case TAG_VArr: {
          heff_take_n(v_v_2458, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2456);
          heff_drop_cell(v_ru_24x1_2457_24Ok, 1);
          return heff_abandon();
        }
        case TAG_VErased: {
          heff_drop(v_d_240);
          heff_drop(v_e_241);
          heff_drop(v_cases_2456);
          return heff_tag_at(v_ru_24x1_2457_24Ok, TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
        }
        default: return heff_nomatch(v_v_2458);
        }
      }
      case TAG_Abn: {
        heff_drop(v_d_240);
        heff_drop(v_e_241);
        heff_drop(v_cases_2456);
        return NTAG(TAG_Abn);
      }
      case TAG_Div: {
        heff_drop(v_d_240);
        heff_drop(v_e_241);
        heff_drop(v_cases_2456);
        return NTAG(TAG_Div);
      }
      default: return heff_nomatch(v_x1_2457);
      }
    }
    case TAG_SSpecialize: {
      heff_take_n(v_t_242, 0ULL, 3);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
    }
    case TAG_SIs: {
      V v_t2_2481 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
      V t_1 = v_e_241;
      V t_2 = v_t2_2481;
      v_d_240 = t_0;
      v_e_241 = t_1;
      v_t_242 = t_2;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_abandon();
    }
    case TAG_SAbandon: {
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return NTAG(TAG_Abn);
    }
    case TAG_SRec: {
      V v_t2_2482 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
      V t_1 = v_e_241;
      V t_2 = v_t2_2482;
      v_d_240 = t_0;
      v_e_241 = t_1;
      v_t_242 = t_2;
      goto top;
    }
    case TAG_SFix: {
      V v_ty_2483 = heff_field(v_t_242, 0);
      V v_it2_2484 = heff_field(v_t_242, 1);
      V v_ru_24t_242_24SFix = heff_take_reuse_n(v_t_242, 3ULL, 2);
      switch (heff_tag_of(v_it2_2484)) {
      case TAG_MkAbs: {
        V v_x_2485 = heff_field(v_it2_2484, 0);
        V v_body_2486 = heff_field(v_it2_2484, 1);
        heff_take_n(v_it2_2484, 3ULL, 2);
        V v_t_2489 = heff_tag_at(v_ru_24t_242_24SFix, TAG_Cons, 2, (V[]){heff_clo(g_heff_2einterp_2eevalIn_lam7, 1, 4, (V[]){v_ty_2483, v_x_2485, heff_dup(v_body_2486), heff_dup(v_e_241)}), heff_get(heff_dup(v_e_241), LBL_local)});
        V v_t_2490 = heff_rec(2, shape_local__global, (V[]){v_t_2489, heff_get(v_e_241, LBL_global)});
        V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
        V t_1 = v_t_2490;
        V t_2 = v_body_2486;
        v_d_240 = t_0;
        v_e_241 = t_1;
        v_t_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_body_2491 = heff_field(v_it2_2484, 0);
        heff_take_n(v_it2_2484, 1ULL, 1);
        heff_drop(v_ty_2483);
        heff_drop_cell(v_ru_24t_242_24SFix, 2);
        V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
        V t_1 = v_e_241;
        V t_2 = v_body_2491;
        v_d_240 = t_0;
        v_e_241 = t_1;
        v_t_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_it2_2484);
      }
    }
    case TAG_SImplicit: {
      V v_t2_2493 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 2ULL, 2);
      V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
      V t_1 = v_e_241;
      V t_2 = v_t2_2493;
      v_d_240 = t_0;
      v_e_241 = t_1;
      v_t_242 = t_2;
      goto top;
    }
    case TAG_SPrim: {
      V v_x_2494 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SPrim = heff_take_reuse_n(v_t_242, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag_at(v_ru_24t_242_24SPrim, TAG_Ok, 1, (V[]){(g_heff_2einterp_2eprim(v_x_2494))});
    }
    case TAG_SMetaApp: {
      heff_take_n(v_t_242, 0ULL, 3);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_abandon();
    }
    case TAG_SLitInt: {
      V v_i_2498 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SLitInt = heff_take_reuse_n(v_t_242, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag_at(v_ru_24t_242_24SLitInt, TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_i_2498})});
    }
    case TAG_SLitFloat: {
      V v_x_2499 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SLitFloat = heff_take_reuse_n(v_t_242, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag_at(v_ru_24t_242_24SLitFloat, TAG_Ok, 1, (V[]){heff_tag(TAG_VFloat, 1, (V[]){v_x_2499})});
    }
    case TAG_SLitString: {
      V v_s_24100 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SLitString = heff_take_reuse_n(v_t_242, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag_at(v_ru_24t_242_24SLitString, TAG_Ok, 1, (V[]){heff_tag(TAG_VStr, 1, (V[]){v_s_24100})});
    }
    case TAG_SLitFixed: {
      V v_i_24102 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 2ULL, 2);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VInt, 1, (V[]){v_i_24102})});
    }
    case TAG_SLitFloat32: {
      V v_x_24103 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SLitFloat32 = heff_take_reuse_n(v_t_242, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_e_241);
      return heff_tag_at(v_ru_24t_242_24SLitFloat32, TAG_Ok, 1, (V[]){heff_tag(TAG_VFloat, 1, (V[]){v_x_24103})});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2einterp_2eevalIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eevalIn(a[0], a[1], a[2]);
}
V g_heff_2einterp_2eevalIn_lam0(V self, V *args) {
  V v_d_2418 = args[0];
  V v_v_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_2418);
  return heff_tag(TAG_Ok, 1, (V[]){v_v_2416});
}
V g_heff_2einterp_2eevalIn_lam1(V self, V *args) {
  V v_dc_2430 = args[0];
  V v_v_2431 = args[1];
  V v_e_241 = heff_env(self)[0];
  V v_body_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_tag(TAG_Cons, 2, (V[]){v_v_2431, heff_get(heff_dup(v_e_241), LBL_local)});
  V v_t_2433 = heff_rec(2, shape_local__global, (V[]){v_t_2432, heff_get(v_e_241, LBL_global)});
  return (g_heff_2einterp_2eevalIn(heff_intAdd(v_dc_2430, MK_INT(1LL)), v_t_2433, v_body_2429));
}
V g_heff_2einterp_2eevalIn_lam2(V self, V *args) {
  V v_dc_2435 = args[0];
  V v_u_2436 = args[1];
  V v_e_241 = heff_env(self)[0];
  V v_body_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2436);
  return (g_heff_2einterp_2eevalIn(heff_intAdd(v_dc_2435, MK_INT(1LL)), v_e_241, v_body_2434));
}
V g_heff_2einterp_2eevalIn_lam3(V self, V *args) {
  V v_t2_2441 = args[0];
  V v_d_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2einterp_2eevalIn(heff_intAdd(v_d_240, MK_INT(1LL)), v_e_241, v_t2_2441));
}
V g_heff_2einterp_2eevalIn_lam4(V self, V *args) {
  V v_vs_2442 = args[0];
  V v_t_2443 = (g_prelude_2emap_24s1581021428x1223114127(heff_dup(v_vs_2442)));
  V v_t_2444 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_vs_2442));
  V v_t_2445 = (g_prelude_2emap_24s531459667x996402587(v_vs_2442));
  V v_t_2446 = heff_rec(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2443), v_t_2444, heff_arrayFromList(v_t_2445)});
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VCons, 1, (V[]){v_t_2446})});
}
V g_heff_2einterp_2eevalIn_lam5(V self, V *args) {
  V v_t2_2453 = args[0];
  V v_d_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2einterp_2eevalIn(heff_intAdd(v_d_240, MK_INT(1LL)), v_e_241, v_t2_2453));
}
V g_heff_2einterp_2eevalIn_lam6(V self, V *args) {
  V v_vs_2454 = args[0];
  V v_x_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_Ok, 1, (V[]){heff_tag(TAG_VTag, 2, (V[]){v_x_2451, v_vs_2454})});
}
V g_heff_2einterp_2eevalIn_lam7(V self, V *args) {
  V v_dc_2487 = args[0];
  V v_ty_2483 = heff_env(self)[0];
  V v_x_2485 = heff_env(self)[1];
  V v_body_2486 = heff_env(self)[2];
  V v_e_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2488 = heff_tag(TAG_SFix, 2, (V[]){v_ty_2483, heff_tag(TAG_MkAbs, 2, (V[]){v_x_2485, v_body_2486})});
  return (g_heff_2einterp_2eevalIn(v_dc_2487, v_e_241, v_t_2488));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eescAt_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eescAt_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eescAt_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eescAt_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eescAt_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 116}};
Clo g_heff_2einterp_2eescAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eescAt_entry, 2, 0};

V g_heff_2einterp_2eescAt(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(34LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return ((V)&g_heff_2einterp_2eescAt_str0);
  }
  case TAG_False: {
    V v_t_243 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(92LL));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      return ((V)&g_heff_2einterp_2eescAt_str1);
    }
    case TAG_False: {
      V v_t_244 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(10LL));
      switch (heff_tag_of(v_t_244)) {
      case TAG_True: {
        heff_drop(v_s_240);
        heff_drop(v_i_241);
        return ((V)&g_heff_2einterp_2eescAt_str2);
      }
      case TAG_False: {
        V v_t_245 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(13LL));
        switch (heff_tag_of(v_t_245)) {
        case TAG_True: {
          heff_drop(v_s_240);
          heff_drop(v_i_241);
          return ((V)&g_heff_2einterp_2eescAt_str3);
        }
        case TAG_False: {
          V v_t_246 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(9LL));
          switch (heff_tag_of(v_t_246)) {
          case TAG_True: {
            heff_drop(v_s_240);
            heff_drop(v_i_241);
            return ((V)&g_heff_2einterp_2eescAt_str4);
          }
          case TAG_False: {
            return heff_strSlice(v_s_240, heff_dup(v_i_241), heff_intAdd(v_i_241, MK_INT(1LL)));
          }
          default: return heff_nomatch(v_t_246);
          }
        }
        default: return heff_nomatch(v_t_245);
        }
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2einterp_2eescAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eescAt(a[0], a[1]);
}
Clo g_heff_2einterp_2equoteGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2equoteGo_entry, 3, 0};

V g_heff_2einterp_2equoteGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  V v_t_243 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return v_acc_242;
  }
  case TAG_False: {
    V v_t_244 = heff_strAppend(v_acc_242, (g_heff_2einterp_2eescAt(heff_dup(v_s_240), heff_dup(v_i_241))));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_244;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2einterp_2equoteGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2equoteGo(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str6 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str7 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str10 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str11 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str15 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str16 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str19 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str20 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str21 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str22 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str25 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str26 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2einterp_2eshowValGo_str27 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str28 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eshowValGo_str29 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eshowValGo_str30 = {{0x80000000u, K_STR, 0}, 2, 2, {123, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eshowValGo_str31 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str33 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str34 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str36 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str37 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str38 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str39 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str40 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str41 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str42 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str43 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str44 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str45 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str46 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str47 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str48 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str49 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str50 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str51 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str52 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str53 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str54 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str55 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str56 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str57 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str58 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str59 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str60 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str61 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str62 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str63 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str64 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str65 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str66 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str67 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str68 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str69 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str70 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str71 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str72 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str73 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str74 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str75 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str76 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str77 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str78 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str79 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str80 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str81 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str82 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str83 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str84 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str85 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str86 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str87 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str88 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str89 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str90 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str91 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str92 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str93 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str94 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str95 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str96 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str97 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str98 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str99 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str100 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str101 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str102 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str103 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str104 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str105 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str106 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str107 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str108 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str109 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str110 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str111 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str112 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str113 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str114 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str115 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str116 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str117 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str118 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str119 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str120 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str121 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2einterp_2eshowValGo_str122 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str123 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str124 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str125 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str126 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str127 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str128 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str129 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str130 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str131 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str132 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str133 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str134 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str135 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str136 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str137 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str138 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str139 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str140 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str141 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str142 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str143 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2einterp_2eshowValGo_str144 = {{0x80000000u, K_STR, 0}, 4, 4, {35, 102, 117, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str145 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str146 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str147 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str148 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2einterp_2eshowValGo_str149 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2einterp_2eshowValGo_str150 = {{0x80000000u, K_STR, 0}, 6, 6, {35, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2einterp_2eshowValGo_str151 = {{0x80000000u, K_STR, 0}, 7, 7, {35, 101, 114, 97, 115, 101, 100}};
Clo g_heff_2einterp_2eshowValGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eshowValGo_entry, 2, 0};

V g_heff_2einterp_2eshowValGo(V v_inArg_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_VFun: {
    V v_t_2413;
    switch (heff_tag_of(v_inArg_240)) {
    case TAG_True: {
      V v_s_2412;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_s_2412 = ((V)&g_heff_2einterp_2eshowValGo_str0);
        break;
      }
      case TAG_VCons: {
        v_s_2412 = ((V)&g_heff_2einterp_2eshowValGo_str1);
        break;
      }
      case TAG_VTag: {
        v_s_2412 = ((V)&g_heff_2einterp_2eshowValGo_str2);
        break;
      }
      case TAG_VInt: {
        V v_i_247 = heff_field(v_v_241, 0);
        v_s_2412 = heff_intShow(heff_dup(v_i_247));
        break;
      }
      case TAG_VFloat: {
        V v_x_248 = heff_field(v_v_241, 0);
        v_s_2412 = heff_floatShow(heff_dup(v_x_248));
        break;
      }
      case TAG_VStr: {
        V v_s_249 = heff_field(v_v_241, 0);
        V v_t_2410 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_249), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str3)));
        v_s_2412 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str4), heff_strAppend(v_t_2410, ((V)&g_heff_2einterp_2eshowValGo_str5)));
        break;
      }
      case TAG_VArr: {
        v_s_2412 = ((V)&g_heff_2einterp_2eshowValGo_str6);
        break;
      }
      case TAG_VErased: {
        v_s_2412 = ((V)&g_heff_2einterp_2eshowValGo_str7);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      v_t_2413 = heff_strEq(heff_strSlice(v_s_2412, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2einterp_2eshowValGo_str8));
      break;
    }
    case TAG_False: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_inArg_240);
    }
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      V v_t_2423;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_t_2423 = ((V)&g_heff_2einterp_2eshowValGo_str9);
        break;
      }
      case TAG_VCons: {
        v_t_2423 = ((V)&g_heff_2einterp_2eshowValGo_str10);
        break;
      }
      case TAG_VTag: {
        v_t_2423 = ((V)&g_heff_2einterp_2eshowValGo_str11);
        break;
      }
      case TAG_VInt: {
        V v_i_2418 = heff_field(v_v_241, 0);
        v_t_2423 = heff_intShow(heff_dup(v_i_2418));
        break;
      }
      case TAG_VFloat: {
        V v_x_2419 = heff_field(v_v_241, 0);
        v_t_2423 = heff_floatShow(heff_dup(v_x_2419));
        break;
      }
      case TAG_VStr: {
        V v_s_2420 = heff_field(v_v_241, 0);
        V v_t_2421 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_2420), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str12)));
        v_t_2423 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str13), heff_strAppend(v_t_2421, ((V)&g_heff_2einterp_2eshowValGo_str14)));
        break;
      }
      case TAG_VArr: {
        v_t_2423 = ((V)&g_heff_2einterp_2eshowValGo_str15);
        break;
      }
      case TAG_VErased: {
        v_t_2423 = ((V)&g_heff_2einterp_2eshowValGo_str16);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str17), heff_strAppend(v_t_2423, ((V)&g_heff_2einterp_2eshowValGo_str18)));
    }
    case TAG_False: {
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        return ((V)&g_heff_2einterp_2eshowValGo_str19);
      }
      case TAG_VCons: {
        return ((V)&g_heff_2einterp_2eshowValGo_str20);
      }
      case TAG_VTag: {
        return ((V)&g_heff_2einterp_2eshowValGo_str21);
      }
      case TAG_VInt: {
        V v_i_2428 = heff_field(v_v_241, 0);
        return heff_intShow(heff_dup(v_i_2428));
      }
      case TAG_VFloat: {
        V v_x_2429 = heff_field(v_v_241, 0);
        return heff_floatShow(heff_dup(v_x_2429));
      }
      case TAG_VStr: {
        V v_s_2430 = heff_field(v_v_241, 0);
        V v_t_2431 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_2430), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str22)));
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str23), heff_strAppend(v_t_2431, ((V)&g_heff_2einterp_2eshowValGo_str24)));
      }
      case TAG_VArr: {
        return ((V)&g_heff_2einterp_2eshowValGo_str25);
      }
      case TAG_VErased: {
        return ((V)&g_heff_2einterp_2eshowValGo_str26);
      }
      default: return heff_nomatch(v_v_241);
      }
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  case TAG_VCons: {
    V v_fs_2433 = heff_field(v_v_241, 0);
    V v_t_2434 = heff_arrayToList(heff_get(heff_dup(v_fs_2433), LBL_keys));
    V v_t_2435 = heff_arrayToList(heff_get(heff_dup(v_fs_2433), LBL_values));
    V v_t_2436 = (g_heff_2edict_2ezipKV(v_t_2434, v_t_2435));
    V v_x2_2437 = (g_prelude_2emap_24s1670578341x1649699234(((V)&g_heff_2einterp_2eshowValGo_str27), v_t_2436));
    V v_t_2440;
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_Nil: {
      v_t_2440 = ((V)&g_heff_2einterp_2eshowValGo_str28);
      break;
    }
    case TAG_Cons: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_xs_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      v_t_2440 = ({ V a_0 = ((V)&g_heff_2einterp_2eshowValGo_str29); V a_1 = v_x_2438; V a_2 = v_xs_2439; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2437);
    }
    return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str30), heff_strAppend(v_t_2440, ((V)&g_heff_2einterp_2eshowValGo_str31)));
  }
  case TAG_VTag: {
    V v_x_2441 = heff_field(v_v_241, 0);
    V v_vs_2442 = heff_field(v_v_241, 1);
    switch (heff_tag_of(v_vs_2442)) {
    case TAG_Nil: {
      return heff_dup(v_x_2441);
    }
    case TAG_Cons: {
      switch (heff_tag_of(v_inArg_240)) {
      case TAG_True: {
        V v_x2_2445 = (g_prelude_2emap_24s615600838x450168446(((V)&g_heff_2einterp_2eshowValGo_str32), heff_dup(v_vs_2442)));
        V v_t_2448;
        switch (heff_tag_of(v_x2_2445)) {
        case TAG_Nil: {
          v_t_2448 = ((V)&g_heff_2einterp_2eshowValGo_str33);
          break;
        }
        case TAG_Cons: {
          V v_x_2446 = heff_field(v_x2_2445, 0);
          V v_xs_2447 = heff_field(v_x2_2445, 1);
          heff_take_n(v_x2_2445, 3ULL, 2);
          v_t_2448 = ({ V a_0 = ((V)&g_heff_2einterp_2eshowValGo_str34); V a_1 = v_x_2446; V a_2 = v_xs_2447; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2447); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2445);
        }
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str35), heff_strAppend(heff_dup(v_x_2441), heff_strAppend(v_t_2448, ((V)&g_heff_2einterp_2eshowValGo_str36))));
      }
      case TAG_False: {
        V v_x2_2449 = (g_prelude_2emap_24s615600838x450168446(((V)&g_heff_2einterp_2eshowValGo_str37), heff_dup(v_vs_2442)));
        V v_t_2452;
        switch (heff_tag_of(v_x2_2449)) {
        case TAG_Nil: {
          v_t_2452 = ((V)&g_heff_2einterp_2eshowValGo_str38);
          break;
        }
        case TAG_Cons: {
          V v_x_2450 = heff_field(v_x2_2449, 0);
          V v_xs_2451 = heff_field(v_x2_2449, 1);
          heff_take_n(v_x2_2449, 3ULL, 2);
          v_t_2452 = ({ V a_0 = ((V)&g_heff_2einterp_2eshowValGo_str39); V a_1 = v_x_2450; V a_2 = v_xs_2451; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2451); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2449);
        }
        return heff_strAppend(heff_dup(v_x_2441), v_t_2452);
      }
      default: return heff_nomatch(v_inArg_240);
      }
    }
    default: return heff_nomatch(v_vs_2442);
    }
  }
  case TAG_VInt: {
    V v_t_2464;
    switch (heff_tag_of(v_inArg_240)) {
    case TAG_True: {
      V v_s_2463;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_s_2463 = ((V)&g_heff_2einterp_2eshowValGo_str40);
        break;
      }
      case TAG_VCons: {
        v_s_2463 = ((V)&g_heff_2einterp_2eshowValGo_str41);
        break;
      }
      case TAG_VTag: {
        v_s_2463 = ((V)&g_heff_2einterp_2eshowValGo_str42);
        break;
      }
      case TAG_VInt: {
        V v_i_2458 = heff_field(v_v_241, 0);
        v_s_2463 = heff_intShow(heff_dup(v_i_2458));
        break;
      }
      case TAG_VFloat: {
        V v_x_2459 = heff_field(v_v_241, 0);
        v_s_2463 = heff_floatShow(heff_dup(v_x_2459));
        break;
      }
      case TAG_VStr: {
        V v_s_2460 = heff_field(v_v_241, 0);
        V v_t_2461 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_2460), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str43)));
        v_s_2463 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str44), heff_strAppend(v_t_2461, ((V)&g_heff_2einterp_2eshowValGo_str45)));
        break;
      }
      case TAG_VArr: {
        v_s_2463 = ((V)&g_heff_2einterp_2eshowValGo_str46);
        break;
      }
      case TAG_VErased: {
        v_s_2463 = ((V)&g_heff_2einterp_2eshowValGo_str47);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      v_t_2464 = heff_strEq(heff_strSlice(v_s_2463, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2einterp_2eshowValGo_str48));
      break;
    }
    case TAG_False: {
      v_t_2464 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_inArg_240);
    }
    switch (heff_tag_of(v_t_2464)) {
    case TAG_True: {
      V v_t_2474;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_t_2474 = ((V)&g_heff_2einterp_2eshowValGo_str49);
        break;
      }
      case TAG_VCons: {
        v_t_2474 = ((V)&g_heff_2einterp_2eshowValGo_str50);
        break;
      }
      case TAG_VTag: {
        v_t_2474 = ((V)&g_heff_2einterp_2eshowValGo_str51);
        break;
      }
      case TAG_VInt: {
        V v_i_2469 = heff_field(v_v_241, 0);
        v_t_2474 = heff_intShow(heff_dup(v_i_2469));
        break;
      }
      case TAG_VFloat: {
        V v_x_2470 = heff_field(v_v_241, 0);
        v_t_2474 = heff_floatShow(heff_dup(v_x_2470));
        break;
      }
      case TAG_VStr: {
        V v_s_2471 = heff_field(v_v_241, 0);
        V v_t_2472 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_2471), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str52)));
        v_t_2474 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str53), heff_strAppend(v_t_2472, ((V)&g_heff_2einterp_2eshowValGo_str54)));
        break;
      }
      case TAG_VArr: {
        v_t_2474 = ((V)&g_heff_2einterp_2eshowValGo_str55);
        break;
      }
      case TAG_VErased: {
        v_t_2474 = ((V)&g_heff_2einterp_2eshowValGo_str56);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str57), heff_strAppend(v_t_2474, ((V)&g_heff_2einterp_2eshowValGo_str58)));
    }
    case TAG_False: {
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        return ((V)&g_heff_2einterp_2eshowValGo_str59);
      }
      case TAG_VCons: {
        return ((V)&g_heff_2einterp_2eshowValGo_str60);
      }
      case TAG_VTag: {
        return ((V)&g_heff_2einterp_2eshowValGo_str61);
      }
      case TAG_VInt: {
        V v_i_2479 = heff_field(v_v_241, 0);
        return heff_intShow(heff_dup(v_i_2479));
      }
      case TAG_VFloat: {
        V v_x_2480 = heff_field(v_v_241, 0);
        return heff_floatShow(heff_dup(v_x_2480));
      }
      case TAG_VStr: {
        V v_s_2481 = heff_field(v_v_241, 0);
        V v_t_2482 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_2481), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str62)));
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str63), heff_strAppend(v_t_2482, ((V)&g_heff_2einterp_2eshowValGo_str64)));
      }
      case TAG_VArr: {
        return ((V)&g_heff_2einterp_2eshowValGo_str65);
      }
      case TAG_VErased: {
        return ((V)&g_heff_2einterp_2eshowValGo_str66);
      }
      default: return heff_nomatch(v_v_241);
      }
    }
    default: return heff_nomatch(v_t_2464);
    }
  }
  case TAG_VFloat: {
    V v_t_2495;
    switch (heff_tag_of(v_inArg_240)) {
    case TAG_True: {
      V v_s_2494;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_s_2494 = ((V)&g_heff_2einterp_2eshowValGo_str67);
        break;
      }
      case TAG_VCons: {
        v_s_2494 = ((V)&g_heff_2einterp_2eshowValGo_str68);
        break;
      }
      case TAG_VTag: {
        v_s_2494 = ((V)&g_heff_2einterp_2eshowValGo_str69);
        break;
      }
      case TAG_VInt: {
        V v_i_2489 = heff_field(v_v_241, 0);
        v_s_2494 = heff_intShow(heff_dup(v_i_2489));
        break;
      }
      case TAG_VFloat: {
        V v_x_2490 = heff_field(v_v_241, 0);
        v_s_2494 = heff_floatShow(heff_dup(v_x_2490));
        break;
      }
      case TAG_VStr: {
        V v_s_2491 = heff_field(v_v_241, 0);
        V v_t_2492 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_2491), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str70)));
        v_s_2494 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str71), heff_strAppend(v_t_2492, ((V)&g_heff_2einterp_2eshowValGo_str72)));
        break;
      }
      case TAG_VArr: {
        v_s_2494 = ((V)&g_heff_2einterp_2eshowValGo_str73);
        break;
      }
      case TAG_VErased: {
        v_s_2494 = ((V)&g_heff_2einterp_2eshowValGo_str74);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      v_t_2495 = heff_strEq(heff_strSlice(v_s_2494, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2einterp_2eshowValGo_str75));
      break;
    }
    case TAG_False: {
      v_t_2495 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_inArg_240);
    }
    switch (heff_tag_of(v_t_2495)) {
    case TAG_True: {
      V v_t_24105;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_t_24105 = ((V)&g_heff_2einterp_2eshowValGo_str76);
        break;
      }
      case TAG_VCons: {
        v_t_24105 = ((V)&g_heff_2einterp_2eshowValGo_str77);
        break;
      }
      case TAG_VTag: {
        v_t_24105 = ((V)&g_heff_2einterp_2eshowValGo_str78);
        break;
      }
      case TAG_VInt: {
        V v_i_24100 = heff_field(v_v_241, 0);
        v_t_24105 = heff_intShow(heff_dup(v_i_24100));
        break;
      }
      case TAG_VFloat: {
        V v_x_24101 = heff_field(v_v_241, 0);
        v_t_24105 = heff_floatShow(heff_dup(v_x_24101));
        break;
      }
      case TAG_VStr: {
        V v_s_24102 = heff_field(v_v_241, 0);
        V v_t_24103 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_24102), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str79)));
        v_t_24105 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str80), heff_strAppend(v_t_24103, ((V)&g_heff_2einterp_2eshowValGo_str81)));
        break;
      }
      case TAG_VArr: {
        v_t_24105 = ((V)&g_heff_2einterp_2eshowValGo_str82);
        break;
      }
      case TAG_VErased: {
        v_t_24105 = ((V)&g_heff_2einterp_2eshowValGo_str83);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str84), heff_strAppend(v_t_24105, ((V)&g_heff_2einterp_2eshowValGo_str85)));
    }
    case TAG_False: {
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        return ((V)&g_heff_2einterp_2eshowValGo_str86);
      }
      case TAG_VCons: {
        return ((V)&g_heff_2einterp_2eshowValGo_str87);
      }
      case TAG_VTag: {
        return ((V)&g_heff_2einterp_2eshowValGo_str88);
      }
      case TAG_VInt: {
        V v_i_24110 = heff_field(v_v_241, 0);
        return heff_intShow(heff_dup(v_i_24110));
      }
      case TAG_VFloat: {
        V v_x_24111 = heff_field(v_v_241, 0);
        return heff_floatShow(heff_dup(v_x_24111));
      }
      case TAG_VStr: {
        V v_s_24112 = heff_field(v_v_241, 0);
        V v_t_24113 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_24112), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str89)));
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str90), heff_strAppend(v_t_24113, ((V)&g_heff_2einterp_2eshowValGo_str91)));
      }
      case TAG_VArr: {
        return ((V)&g_heff_2einterp_2eshowValGo_str92);
      }
      case TAG_VErased: {
        return ((V)&g_heff_2einterp_2eshowValGo_str93);
      }
      default: return heff_nomatch(v_v_241);
      }
    }
    default: return heff_nomatch(v_t_2495);
    }
  }
  case TAG_VStr: {
    V v_t_24126;
    switch (heff_tag_of(v_inArg_240)) {
    case TAG_True: {
      V v_s_24125;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_s_24125 = ((V)&g_heff_2einterp_2eshowValGo_str94);
        break;
      }
      case TAG_VCons: {
        v_s_24125 = ((V)&g_heff_2einterp_2eshowValGo_str95);
        break;
      }
      case TAG_VTag: {
        v_s_24125 = ((V)&g_heff_2einterp_2eshowValGo_str96);
        break;
      }
      case TAG_VInt: {
        V v_i_24120 = heff_field(v_v_241, 0);
        v_s_24125 = heff_intShow(heff_dup(v_i_24120));
        break;
      }
      case TAG_VFloat: {
        V v_x_24121 = heff_field(v_v_241, 0);
        v_s_24125 = heff_floatShow(heff_dup(v_x_24121));
        break;
      }
      case TAG_VStr: {
        V v_s_24122 = heff_field(v_v_241, 0);
        V v_t_24123 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_24122), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str97)));
        v_s_24125 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str98), heff_strAppend(v_t_24123, ((V)&g_heff_2einterp_2eshowValGo_str99)));
        break;
      }
      case TAG_VArr: {
        v_s_24125 = ((V)&g_heff_2einterp_2eshowValGo_str100);
        break;
      }
      case TAG_VErased: {
        v_s_24125 = ((V)&g_heff_2einterp_2eshowValGo_str101);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      v_t_24126 = heff_strEq(heff_strSlice(v_s_24125, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2einterp_2eshowValGo_str102));
      break;
    }
    case TAG_False: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_inArg_240);
    }
    switch (heff_tag_of(v_t_24126)) {
    case TAG_True: {
      V v_t_24136;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_t_24136 = ((V)&g_heff_2einterp_2eshowValGo_str103);
        break;
      }
      case TAG_VCons: {
        v_t_24136 = ((V)&g_heff_2einterp_2eshowValGo_str104);
        break;
      }
      case TAG_VTag: {
        v_t_24136 = ((V)&g_heff_2einterp_2eshowValGo_str105);
        break;
      }
      case TAG_VInt: {
        V v_i_24131 = heff_field(v_v_241, 0);
        v_t_24136 = heff_intShow(heff_dup(v_i_24131));
        break;
      }
      case TAG_VFloat: {
        V v_x_24132 = heff_field(v_v_241, 0);
        v_t_24136 = heff_floatShow(heff_dup(v_x_24132));
        break;
      }
      case TAG_VStr: {
        V v_s_24133 = heff_field(v_v_241, 0);
        V v_t_24134 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_24133), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str106)));
        v_t_24136 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str107), heff_strAppend(v_t_24134, ((V)&g_heff_2einterp_2eshowValGo_str108)));
        break;
      }
      case TAG_VArr: {
        v_t_24136 = ((V)&g_heff_2einterp_2eshowValGo_str109);
        break;
      }
      case TAG_VErased: {
        v_t_24136 = ((V)&g_heff_2einterp_2eshowValGo_str110);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str111), heff_strAppend(v_t_24136, ((V)&g_heff_2einterp_2eshowValGo_str112)));
    }
    case TAG_False: {
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        return ((V)&g_heff_2einterp_2eshowValGo_str113);
      }
      case TAG_VCons: {
        return ((V)&g_heff_2einterp_2eshowValGo_str114);
      }
      case TAG_VTag: {
        return ((V)&g_heff_2einterp_2eshowValGo_str115);
      }
      case TAG_VInt: {
        V v_i_24141 = heff_field(v_v_241, 0);
        return heff_intShow(heff_dup(v_i_24141));
      }
      case TAG_VFloat: {
        V v_x_24142 = heff_field(v_v_241, 0);
        return heff_floatShow(heff_dup(v_x_24142));
      }
      case TAG_VStr: {
        V v_s_24143 = heff_field(v_v_241, 0);
        V v_t_24144 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_24143), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str116)));
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str117), heff_strAppend(v_t_24144, ((V)&g_heff_2einterp_2eshowValGo_str118)));
      }
      case TAG_VArr: {
        return ((V)&g_heff_2einterp_2eshowValGo_str119);
      }
      case TAG_VErased: {
        return ((V)&g_heff_2einterp_2eshowValGo_str120);
      }
      default: return heff_nomatch(v_v_241);
      }
    }
    default: return heff_nomatch(v_t_24126);
    }
  }
  case TAG_VArr: {
    V v_xs_24146 = heff_field(v_v_241, 0);
    V v_x2_24147 = (g_prelude_2emap_24s265029017x1822716883(heff_arrayToList(heff_dup(v_xs_24146))));
    V v_t_24150;
    switch (heff_tag_of(v_x2_24147)) {
    case TAG_Nil: {
      v_t_24150 = ((V)&g_heff_2einterp_2eshowValGo_str121);
      break;
    }
    case TAG_Cons: {
      V v_x_24148 = heff_field(v_x2_24147, 0);
      V v_xs_24149 = heff_field(v_x2_24147, 1);
      heff_take_n(v_x2_24147, 3ULL, 2);
      v_t_24150 = ({ V a_0 = ((V)&g_heff_2einterp_2eshowValGo_str122); V a_1 = v_x_24148; V a_2 = v_xs_24149; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_24149); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24147);
    }
    return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str123), heff_strAppend(v_t_24150, ((V)&g_heff_2einterp_2eshowValGo_str124)));
  }
  case TAG_VErased: {
    V v_t_24161;
    switch (heff_tag_of(v_inArg_240)) {
    case TAG_True: {
      V v_s_24160;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_s_24160 = ((V)&g_heff_2einterp_2eshowValGo_str125);
        break;
      }
      case TAG_VCons: {
        v_s_24160 = ((V)&g_heff_2einterp_2eshowValGo_str126);
        break;
      }
      case TAG_VTag: {
        v_s_24160 = ((V)&g_heff_2einterp_2eshowValGo_str127);
        break;
      }
      case TAG_VInt: {
        V v_i_24155 = heff_field(v_v_241, 0);
        v_s_24160 = heff_intShow(heff_dup(v_i_24155));
        break;
      }
      case TAG_VFloat: {
        V v_x_24156 = heff_field(v_v_241, 0);
        v_s_24160 = heff_floatShow(heff_dup(v_x_24156));
        break;
      }
      case TAG_VStr: {
        V v_s_24157 = heff_field(v_v_241, 0);
        V v_t_24158 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_24157), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str128)));
        v_s_24160 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str129), heff_strAppend(v_t_24158, ((V)&g_heff_2einterp_2eshowValGo_str130)));
        break;
      }
      case TAG_VArr: {
        v_s_24160 = ((V)&g_heff_2einterp_2eshowValGo_str131);
        break;
      }
      case TAG_VErased: {
        v_s_24160 = ((V)&g_heff_2einterp_2eshowValGo_str132);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      v_t_24161 = heff_strEq(heff_strSlice(v_s_24160, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2einterp_2eshowValGo_str133));
      break;
    }
    case TAG_False: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_inArg_240);
    }
    switch (heff_tag_of(v_t_24161)) {
    case TAG_True: {
      V v_t_24171;
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        v_t_24171 = ((V)&g_heff_2einterp_2eshowValGo_str134);
        break;
      }
      case TAG_VCons: {
        v_t_24171 = ((V)&g_heff_2einterp_2eshowValGo_str135);
        break;
      }
      case TAG_VTag: {
        v_t_24171 = ((V)&g_heff_2einterp_2eshowValGo_str136);
        break;
      }
      case TAG_VInt: {
        V v_i_24166 = heff_field(v_v_241, 0);
        v_t_24171 = heff_intShow(heff_dup(v_i_24166));
        break;
      }
      case TAG_VFloat: {
        V v_x_24167 = heff_field(v_v_241, 0);
        v_t_24171 = heff_floatShow(heff_dup(v_x_24167));
        break;
      }
      case TAG_VStr: {
        V v_s_24168 = heff_field(v_v_241, 0);
        V v_t_24169 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_24168), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str137)));
        v_t_24171 = heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str138), heff_strAppend(v_t_24169, ((V)&g_heff_2einterp_2eshowValGo_str139)));
        break;
      }
      case TAG_VArr: {
        v_t_24171 = ((V)&g_heff_2einterp_2eshowValGo_str140);
        break;
      }
      case TAG_VErased: {
        v_t_24171 = ((V)&g_heff_2einterp_2eshowValGo_str141);
        break;
      }
      default: heff_nomatch(v_v_241);
      }
      return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str142), heff_strAppend(v_t_24171, ((V)&g_heff_2einterp_2eshowValGo_str143)));
    }
    case TAG_False: {
      switch (heff_tag_of(v_v_241)) {
      case TAG_VFun: {
        return ((V)&g_heff_2einterp_2eshowValGo_str144);
      }
      case TAG_VCons: {
        return ((V)&g_heff_2einterp_2eshowValGo_str145);
      }
      case TAG_VTag: {
        return ((V)&g_heff_2einterp_2eshowValGo_str146);
      }
      case TAG_VInt: {
        V v_i_24176 = heff_field(v_v_241, 0);
        return heff_intShow(heff_dup(v_i_24176));
      }
      case TAG_VFloat: {
        V v_x_24177 = heff_field(v_v_241, 0);
        return heff_floatShow(heff_dup(v_x_24177));
      }
      case TAG_VStr: {
        V v_s_24178 = heff_field(v_v_241, 0);
        V v_t_24179 = (g_heff_2einterp_2equoteGo(heff_dup(v_s_24178), MK_INT(0LL), ((V)&g_heff_2einterp_2eshowValGo_str147)));
        return heff_strAppend(((V)&g_heff_2einterp_2eshowValGo_str148), heff_strAppend(v_t_24179, ((V)&g_heff_2einterp_2eshowValGo_str149)));
      }
      case TAG_VArr: {
        return ((V)&g_heff_2einterp_2eshowValGo_str150);
      }
      case TAG_VErased: {
        return ((V)&g_heff_2einterp_2eshowValGo_str151);
      }
      default: return heff_nomatch(v_v_241);
      }
    }
    default: return heff_nomatch(v_t_24161);
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2einterp_2eshowValGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2einterp_2eshowValGo(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2einterp_2efixThunk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2efixThunk_entry, 3, 0};

V g_heff_2einterp_2efixThunk(V v_g_240, V v_t_241, V v_d_242) {
top: ;
  V v_t_243 = heff_tr(heff_apply(((V)&g_heff_2einterp_2efixThunk_clo), 2, (V[]){heff_dup(v_g_240), heff_dup(v_t_241)}));
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  HEFF_LAST return g_heff_2einterp_2eevalIn(heff_intAdd(v_d_242, MK_INT(1LL)), heff_rec(2, shape_local__global, (V[]){v_t_244, v_g_240}), v_t_241);
}
V g_heff_2einterp_2efixThunk_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2efixThunk(a[0], a[1], a[2]);
}
V g_heff_2einterp_2eevalGlobalsGo_lam0(V self, V *args);
Clo g_heff_2einterp_2eevalGlobalsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eevalGlobalsGo_entry, 4, 0};

V g_heff_2einterp_2eevalGlobalsGo(V v_wanted_240, V v_ge_241, V v_x3_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_wanted_240);
    heff_drop(v_ge_241);
    return (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_243));
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x31_244, 0);
      V v_entry_247 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      V v_r_248 = heff_tr(g_heff_2einterp_2efixThunk(heff_dup(v_ge_241), heff_get(v_entry_247, LBL_syntax), MK_INT(0LL)));
      V v_t_2410 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_246), heff_clo(g_heff_2einterp_2eevalGlobalsGo_lam0, 1, 1, (V[]){heff_dup(v_r_248)}), v_ge_241));
      V v_t_2411 = heff_tr(heff_apply(heff_dup(v_wanted_240), 1, (V[]){heff_dup(v_x_246)}));
      V v_t_2414;
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        V v_t_2413;
        switch (heff_tag_of(v_r_248)) {
        case TAG_Ok: {
          V v_v_2412 = heff_field(v_r_248, 0);
          V v_ru_24r_248_24Ok = heff_take_reuse_n(v_r_248, 1ULL, 1);
          v_t_2413 = heff_tag_at(v_ru_24r_248_24Ok, TAG_RSucceeded, 1, (V[]){v_v_2412});
          break;
        }
        case TAG_Abn: {
          v_t_2413 = NTAG(TAG_RAbandoned);
          break;
        }
        case TAG_Div: {
          v_t_2413 = NTAG(TAG_RDiverged);
          break;
        }
        default: heff_nomatch(v_r_248);
        }
        v_t_2414 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_246, v_t_2413}), v_acc_243});
        break;
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_x_246);
        heff_drop(v_r_248);
        v_t_2414 = v_acc_243;
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
      V t_0 = v_wanted_240;
      V t_1 = v_t_2410;
      V t_2 = v_rest_245;
      V t_3 = v_t_2414;
      v_wanted_240 = t_0;
      v_ge_241 = t_1;
      v_x3_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2einterp_2eevalGlobalsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eevalGlobalsGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2einterp_2eevalGlobalsGo_lam0(V self, V *args) {
  V v_d_249 = args[0];
  V v_r_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_249);
  return v_r_248;
}
V g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986_lam0(V self, V *args);
Clo g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986_clo = {{0x80000000u, K_CLO, 0}, g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986_entry, 6, 0};

V g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986(V v_lit_240, V v_lit_241, V v_lit_242, V v_ge_243, V v_x3_244, V v_acc_245) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_ge_243);
    return (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_245));
  }
  case TAG_Cons: {
    V v_x31_246 = heff_field(v_x3_244, 0);
    V v_rest_247 = heff_field(v_x3_244, 1);
    V v_ru_24x3_244_24Cons = heff_take_reuse_n(v_x3_244, 3ULL, 2);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x31_246, 0);
      V v_entry_249 = heff_field(v_x31_246, 1);
      heff_take_n(v_x31_246, 3ULL, 2);
      V v_r_2410 = heff_tr(g_heff_2einterp_2efixThunk(heff_dup(v_ge_243), heff_get(v_entry_249, LBL_syntax), MK_INT(0LL)));
      V v_t_2412 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_248), heff_clo(g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986_lam0, 1, 1, (V[]){heff_dup(v_r_2410)}), v_ge_243));
      V v_t_2413 = heff_strEq(heff_strSlice(heff_dup(v_x_248), heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_lit_242));
      V v_t_2416;
      switch (heff_tag_of(v_t_2413)) {
      case TAG_True: {
        V v_t_2415;
        switch (heff_tag_of(v_r_2410)) {
        case TAG_Ok: {
          V v_v_2414 = heff_field(v_r_2410, 0);
          V v_ru_24r_2410_24Ok = heff_take_reuse_n(v_r_2410, 1ULL, 1);
          v_t_2415 = heff_tag_at(v_ru_24r_2410_24Ok, TAG_RSucceeded, 1, (V[]){v_v_2414});
          break;
        }
        case TAG_Abn: {
          v_t_2415 = NTAG(TAG_RAbandoned);
          break;
        }
        case TAG_Div: {
          v_t_2415 = NTAG(TAG_RDiverged);
          break;
        }
        default: heff_nomatch(v_r_2410);
        }
        v_t_2416 = heff_tag_at(v_ru_24x3_244_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_248, v_t_2415}), v_acc_245});
        break;
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x3_244_24Cons, 2);
        heff_drop(v_x_248);
        heff_drop(v_r_2410);
        v_t_2416 = v_acc_245;
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_t_2412;
      V t_4 = v_rest_247;
      V t_5 = v_t_2416;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_ge_243 = t_3;
      v_x3_244 = t_4;
      v_acc_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x31_246);
    }
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986_entry(V self, V *a) {
  (void)self;
  return g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2einterp_2eevalGlobalsGo_24s1931677434x706595986_lam0(V self, V *args) {
  V v_d_2411 = args[0];
  V v_r_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_2411);
  return v_r_2410;
}