// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_above 293969847
#define LBL_infinity 918311944
#define LBL_least 304204419
#define LBL_precision 248287675
#define LBL_under 312786674
static uint32_t shape_precision__least__infinity__above__under[] = {LBL_precision, LBL_least, LBL_infinity, LBL_above, LBL_under};
V g_std_2emath_2ebitLength_2ebitsOfSize_240(V, V);
V g_std_2emath_2ebitLength_2ebitsOfSize_240_entry(V self, V *a);
extern Clo g_std_2emath_2ebitLength_2ebitsOfSize_240_clo;
V g_std_2emath_2ebitsAt_24s1259326885x1340549617(V, V, V);
V g_std_2emath_2ebitsAt_24s1259326885x1340549617_entry(V self, V *a);
extern Clo g_std_2emath_2ebitsAt_24s1259326885x1340549617_clo;
V g_std_2emath_2ebitsAt_24s788696364x166928227(V, V, V);
V g_std_2emath_2ebitsAt_24s788696364x166928227_entry(V self, V *a);
extern Clo g_std_2emath_2ebitsAt_24s788696364x166928227_clo;
V g_std_2emath_2ebitsBelow(V, V, V);
V g_std_2emath_2ebitsBelow_entry(V self, V *a);
extern Clo g_std_2emath_2ebitsBelow_clo;
V g_std_2emath_2ebitsOf_24s1121577270x198570061(V, V, V, V);
V g_std_2emath_2ebitsOf_24s1121577270x198570061_entry(V self, V *a);
extern Clo g_std_2emath_2ebitsOf_24s1121577270x198570061_clo;
V g_std_2emath_2ebitsOf_24s1803888623x733876950(V, V, V, V);
V g_std_2emath_2ebitsOf_24s1803888623x733876950_entry(V self, V *a);
extern Clo g_std_2emath_2ebitsOf_24s1803888623x733876950_clo;
double g_std_2emath_2efromDecimal_w(V, V);
V g_std_2emath_2efromDecimal(V, V);
V g_std_2emath_2efromDecimal_entry(V self, V *a);
extern Clo g_std_2emath_2efromDecimal_clo;
V g_std_2emath_2enearestBits_24s226419449x1689653652(V, V);
V g_std_2emath_2enearestBits_24s226419449x1689653652_entry(V self, V *a);
extern Clo g_std_2emath_2enearestBits_24s226419449x1689653652_clo;
V g_std_2emath_2enearestBits_24s705918251x1654869085(V, V);
V g_std_2emath_2enearestBits_24s705918251x1654869085_entry(V self, V *a);
extern Clo g_std_2emath_2enearestBits_24s705918251x1654869085_clo;
V g_std_2emath_2etenTo(V);
V g_std_2emath_2etenTo_entry(V self, V *a);
extern Clo g_std_2emath_2etenTo_clo;
double g_std_2emath_2etenToFloat_w(V);
V g_std_2emath_2etenToFloat(V);
V g_std_2emath_2etenToFloat_entry(V self, V *a);
extern Clo g_std_2emath_2etenToFloat_clo;
Clo g_std_2emath_2etenToFloat_clo = {{0x80000000u, K_CLO, 0}, g_std_2emath_2etenToFloat_entry, 1, 0};

double g_std_2emath_2etenToFloat_w(V v_box_24k_240) {
  int64_t v_k_240 = heff_unbox_word(v_box_24k_240);
top: ;
  if ((v_k_240 == ((int64_t)0ULL))) {
    return (1.0);
  } else {
    if (((v_k_240 % ((int64_t)2ULL)) == ((int64_t)1ULL))) {
      double v_t_241 = (g_std_2emath_2etenToFloat_w(heff_box_word((v_k_240 - ((int64_t)1ULL)))));
      return ((10.0) * v_t_241);
    } else {
      double v_h_242 = (g_std_2emath_2etenToFloat_w(heff_box_word((v_k_240 / ((int64_t)2ULL)))));
      return (v_h_242 * v_h_242);
    }
  }
}
V g_std_2emath_2etenToFloat(V v_box_24k_240) {
  return heff_box_f64((g_std_2emath_2etenToFloat_w(v_box_24k_240)));
}
V g_std_2emath_2etenToFloat_entry(V self, V *a) {
  (void)self;
  return g_std_2emath_2etenToFloat(a[0]);
}
Clo g_std_2emath_2etenTo_clo = {{0x80000000u, K_CLO, 0}, g_std_2emath_2etenTo_entry, 1, 0};

V g_std_2emath_2etenTo(V v_k_240) {
top: ;
  if (heff_intEq_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    return MK_INT(1LL);
  } else {
    if ((heff_unbox_word(heff_intMod(heff_dup(v_k_240), MK_INT(2LL))) == ((int64_t)1ULL))) {
      V v_t_241 = (g_std_2emath_2etenTo(heff_intSub(v_k_240, MK_INT(1LL))));
      return heff_intMul(MK_INT(10LL), v_t_241);
    } else {
      V v_h_242 = (g_std_2emath_2etenTo(heff_intDiv(v_k_240, MK_INT(2LL))));
      return heff_intMul(heff_dup(v_h_242), v_h_242);
    }
  }
}
V g_std_2emath_2etenTo_entry(V self, V *a) {
  (void)self;
  return g_std_2emath_2etenTo(a[0]);
}
Clo g_std_2emath_2ebitsBelow_clo = {{0x80000000u, K_CLO, 0}, g_std_2emath_2ebitsBelow_entry, 3, 0};

V g_std_2emath_2ebitsBelow(V v_n_240, V v_acc_241, V v_box_24k_242) {
  int64_t v_k_242 = heff_unbox_word(v_box_24k_242);
top: ;
  if ((v_k_242 == ((int64_t)0ULL))) {
    return heff_intAdd(v_acc_241, v_n_240);
  } else {
    V v_y_243 = heff_intShl(MK_INT(1LL), heff_box_word(v_k_242));
    if (heff_intLe_c_lent(v_y_243, v_n_240, 1)) {
      V v_t_244 = heff_intShr(v_n_240, heff_box_word(v_k_242));
      V t_0 = v_t_244;
      V t_1 = heff_intAdd(v_acc_241, heff_box_word(v_k_242));
      int64_t t_2 = (v_k_242 / ((int64_t)2ULL));
      v_n_240 = t_0;
      v_acc_241 = t_1;
      v_k_242 = t_2;
      goto top;
    } else {
      V t_0 = v_n_240;
      V t_1 = v_acc_241;
      int64_t t_2 = (v_k_242 / ((int64_t)2ULL));
      v_n_240 = t_0;
      v_acc_241 = t_1;
      v_k_242 = t_2;
      goto top;
    }
  }
}
V g_std_2emath_2ebitsBelow_entry(V self, V *a) {
  (void)self;
  return g_std_2emath_2ebitsBelow(a[0], a[1], a[2]);
}
Clo g_std_2emath_2ebitsOf_24s1121577270x198570061_clo = {{0x80000000u, K_CLO, 0}, g_std_2emath_2ebitsOf_24s1121577270x198570061_entry, 4, 0};

V g_std_2emath_2ebitsOf_24s1121577270x198570061(V v_b_240, V v_q_241, V v_r_242, V v_d_243) {
top: ;
  V v_t_244 = heff_intShl(MK_INT(1LL), MK_INT(52LL));
  V v_t_245 = heff_rec_n(5, shape_precision__least__infinity__above__under, (V[]){MK_INT(53LL), MK_INT(-1074LL), heff_intMul(MK_INT(2047LL), v_t_244), MK_INT(309LL), MK_INT(-324LL)});
  V v_t_246 = heff_intSub(v_b_240, heff_get_n(v_t_245, 1, 5));
  V v_t_247 = heff_intShl(MK_INT(1LL), MK_INT(52LL));
  V v_t_248 = heff_rec_n(5, shape_precision__least__infinity__above__under, (V[]){MK_INT(53LL), MK_INT(-1074LL), heff_intMul(MK_INT(2047LL), v_t_247), MK_INT(309LL), MK_INT(-324LL)});
  V v_t_249 = heff_intSub(heff_get_n(v_t_248, 0, 5), MK_INT(1LL));
  V v_t_2410 = heff_intShl(MK_INT(1LL), v_t_249);
  V v_t_2411;
  if ((heff_intLt_c(heff_dup(v_d_243), heff_intMul(MK_INT(2LL), heff_dup(v_r_242))) || (heff_intEq_c(heff_intMul(MK_INT(2LL), heff_dup(v_r_242)), heff_dup(v_d_243)) && (heff_unbox_word(heff_intMod(heff_dup(v_q_241), MK_INT(2LL))) == ((int64_t)1ULL))))) {
    heff_drop(v_r_242);
    heff_drop(v_d_243);
    v_t_2411 = heff_intAdd(v_q_241, MK_INT(1LL));
  } else {
    heff_drop(v_r_242);
    heff_drop(v_d_243);
    v_t_2411 = v_q_241;
  }
  V v_x_2412 = heff_intAdd(heff_intMul(v_t_246, v_t_2410), v_t_2411);
  V v_t_2413 = heff_intShl(MK_INT(1LL), MK_INT(52LL));
  V v_y_2414 = heff_intMul(MK_INT(2047LL), v_t_2413);
  if (heff_intLe_c_lent(v_x_2412, v_y_2414, 0)) {
    heff_drop(v_y_2414);
    return v_x_2412;
  } else {
    heff_drop(v_x_2412);
    return v_y_2414;
  }
}
V g_std_2emath_2ebitsOf_24s1121577270x198570061_entry(V self, V *a) {
  (void)self;
  return g_std_2emath_2ebitsOf_24s1121577270x198570061(a[0], a[1], a[2], a[3]);
}
Clo g_std_2emath_2ebitsAt_24s1259326885x1340549617_clo = {{0x80000000u, K_CLO, 0}, g_std_2emath_2ebitsAt_24s1259326885x1340549617_entry, 3, 0};

V g_std_2emath_2ebitsAt_24s1259326885x1340549617(V v_num_240, V v_den_241, V v_b_242) {
top: ;
  V v_y_243 = heff_intSub(MK_INT(0LL), heff_dup(v_b_242));
  V v_t_244;
  if (heff_intLe_c_lent(MK_INT(0LL), v_y_243, 1)) {
    v_t_244 = v_y_243;
  } else {
    heff_drop(v_y_243);
    v_t_244 = MK_INT(0LL);
  }
  V v_n_245 = heff_intShl(v_num_240, v_t_244);
  V v_t_246;
  if (heff_intLe_c_lent(MK_INT(0LL), v_b_242, 1)) {
    v_t_246 = heff_dup(v_b_242);
  } else {
    v_t_246 = MK_INT(0LL);
  }
  V v_d_247 = heff_intShl(v_den_241, v_t_246);
  V v_q_248 = heff_intDiv(heff_dup(v_n_245), heff_dup(v_d_247));
  V v_t_249 = heff_intShl(MK_INT(1LL), MK_INT(52LL));
  V v_t_2410 = heff_rec_n(5, shape_precision__least__infinity__above__under, (V[]){MK_INT(53LL), MK_INT(-1074LL), heff_intMul(MK_INT(2047LL), v_t_249), MK_INT(309LL), MK_INT(-324LL)});
  V v_y_2411 = heff_intShl(MK_INT(1LL), heff_get_n(v_t_2410, 0, 5));
  if (heff_intLe_c_lent(v_y_2411, v_q_248, 1)) {
    V v_t_2412 = heff_intMul(heff_intMod(heff_dup(v_q_248), MK_INT(2LL)), heff_dup(v_d_247));
    V v_t_2413 = heff_intSub(v_n_245, heff_intMul(heff_dup(v_q_248), heff_dup(v_d_247)));
    return (g_std_2emath_2ebitsOf_24s1121577270x198570061(heff_intAdd(v_b_242, MK_INT(1LL)), heff_intDiv(v_q_248, MK_INT(2LL)), heff_intAdd(v_t_2412, v_t_2413), heff_intMul(MK_INT(2LL), v_d_247)));
  } else {
    V v_t_2414 = heff_intSub(v_n_245, heff_intMul(heff_dup(v_q_248), heff_dup(v_d_247)));
    return (g_std_2emath_2ebitsOf_24s1121577270x198570061(v_b_242, v_q_248, v_t_2414, v_d_247));
  }
}
V g_std_2emath_2ebitsAt_24s1259326885x1340549617_entry(V self, V *a) {
  (void)self;
  return g_std_2emath_2ebitsAt_24s1259326885x1340549617(a[0], a[1], a[2]);
}
Clo g_std_2emath_2enearestBits_24s705918251x1654869085_clo = {{0x80000000u, K_CLO, 0}, g_std_2emath_2enearestBits_24s705918251x1654869085_entry, 2, 0};

V g_std_2emath_2enearestBits_24s705918251x1654869085(V v_m_240, V v_e_241) {
top: ;
  V v_t_242 = heff_intShl(MK_INT(1LL), MK_INT(52LL));
  V v_t_243 = heff_rec_n(5, shape_precision__least__infinity__above__under, (V[]){MK_INT(53LL), MK_INT(-1074LL), heff_intMul(MK_INT(2047LL), v_t_242), MK_INT(309LL), MK_INT(-324LL)});
  if (heff_intLt_c(heff_get_n(v_t_243, 3, 5), heff_dup(v_e_241))) {
    heff_drop(v_m_240);
    heff_drop(v_e_241);
    V v_t_244 = heff_intShl(MK_INT(1LL), MK_INT(52LL));
    return heff_intMul(MK_INT(2047LL), v_t_244);
  } else {
    V v_t_245;
    if (heff_intLt_c_lent(v_m_240, MK_INT(0LL), 2)) {
      v_t_245 = heff_intSub(MK_INT(0LL), heff_dup(v_m_240));
    } else {
      v_t_245 = heff_dup(v_m_240);
    }
    V v_t_246 = (g_std_2emath_2ebitLength_2ebitsOfSize_240(v_t_245, MK_INT(0LL)));
    V v_t_247 = heff_intDiv(heff_intMul(v_t_246, MK_INT(302LL)), MK_INT(1000LL));
    V v_t_248 = heff_intAdd(heff_intAdd(v_t_247, MK_INT(1LL)), heff_dup(v_e_241));
    V v_t_249 = heff_intShl(MK_INT(1LL), MK_INT(52LL));
    V v_t_2410 = heff_rec_n(5, shape_precision__least__infinity__above__under, (V[]){MK_INT(53LL), MK_INT(-1074LL), heff_intMul(MK_INT(2047LL), v_t_249), MK_INT(309LL), MK_INT(-324LL)});
    if (heff_intLt_c(v_t_248, heff_get_n(v_t_2410, 4, 5))) {
      heff_drop(v_m_240);
      heff_drop(v_e_241);
      return MK_INT(0LL);
    } else {
      V v_num_2412;
      if (heff_intLt_c_lent(MK_INT(0LL), v_e_241, 1)) {
        V v_t_2411 = (g_std_2emath_2etenTo(heff_dup(v_e_241)));
        v_num_2412 = heff_intMul(v_m_240, v_t_2411);
      } else {
        v_num_2412 = v_m_240;
      }
      V v_den_2413;
      if (heff_intLt_c_lent(v_e_241, MK_INT(0LL), 2)) {
        v_den_2413 = (g_std_2emath_2etenTo(heff_intSub(MK_INT(0LL), v_e_241)));
      } else {
        heff_drop(v_e_241);
        v_den_2413 = MK_INT(1LL);
      }
      V v_t_2414;
      if (heff_intLt_c_lent(v_num_2412, MK_INT(0LL), 2)) {
        v_t_2414 = heff_intSub(MK_INT(0LL), heff_dup(v_num_2412));
      } else {
        v_t_2414 = heff_dup(v_num_2412);
      }
      V v_t_2415 = (g_std_2emath_2ebitLength_2ebitsOfSize_240(v_t_2414, MK_INT(0LL)));
      V v_t_2416;
      if (heff_intLt_c_lent(v_den_2413, MK_INT(0LL), 2)) {
        v_t_2416 = heff_intSub(MK_INT(0LL), heff_dup(v_den_2413));
      } else {
        v_t_2416 = heff_dup(v_den_2413);
      }
      V v_t_2417 = (g_std_2emath_2ebitLength_2ebitsOfSize_240(v_t_2416, MK_INT(0LL)));
      V v_t_2418 = heff_intShl(MK_INT(1LL), MK_INT(52LL));
      V v_t_2419 = heff_rec_n(5, shape_precision__least__infinity__above__under, (V[]){MK_INT(53LL), MK_INT(-1074LL), heff_intMul(MK_INT(2047LL), v_t_2418), MK_INT(309LL), MK_INT(-324LL)});
      V v_x_2420 = heff_intSub(heff_intSub(v_t_2415, v_t_2417), heff_get_n(v_t_2419, 0, 5));
      V v_t_2421 = heff_intShl(MK_INT(1LL), MK_INT(52LL));
      V v_t_2422 = heff_rec_n(5, shape_precision__least__infinity__above__under, (V[]){MK_INT(53LL), MK_INT(-1074LL), heff_intMul(MK_INT(2047LL), v_t_2421), MK_INT(309LL), MK_INT(-324LL)});
      V v_y_2423 = heff_get_n(v_t_2422, 1, 5);
      V v_t_2424;
      if (heff_intLe_c_lent(v_x_2420, v_y_2423, 0)) {
        heff_drop(v_x_2420);
        v_t_2424 = v_y_2423;
      } else {
        heff_drop(v_y_2423);
        v_t_2424 = v_x_2420;
      }
      return (g_std_2emath_2ebitsAt_24s1259326885x1340549617(v_num_2412, v_den_2413, v_t_2424));
    }
  }
}
V g_std_2emath_2enearestBits_24s705918251x1654869085_entry(V self, V *a) {
  (void)self;
  return g_std_2emath_2enearestBits_24s705918251x1654869085(a[0], a[1]);
}
Clo g_std_2emath_2efromDecimal_clo = {{0x80000000u, K_CLO, 0}, g_std_2emath_2efromDecimal_entry, 2, 0};

double g_std_2emath_2efromDecimal_w(V v_m_240, V v_e_241) {
top: ;
  if (heff_intLt_c_lent(v_m_240, MK_INT(0LL), 2)) {
    double v_x_242 = (g_std_2emath_2efromDecimal_w(heff_intSub(MK_INT(0LL), v_m_240), v_e_241));
    return ((-1.0) * v_x_242);
  } else {
    if (heff_intEq_c_lent(v_m_240, MK_INT(0LL), 2)) {
      heff_drop(v_m_240);
      heff_drop(v_e_241);
      return (0.0);
    } else {
      V v_t_243 = heff_intShl(MK_INT(1LL), MK_INT(53LL));
      if ((heff_intLt_c_lent(v_m_240, v_t_243, 0) && (heff_intLe_c_lent(MK_INT(0LL), v_e_241, 1) && heff_intLe_c_lent(v_e_241, MK_INT(22LL), 2)))) {
        heff_drop(v_t_243);
        double v_t_244 = (g_std_2emath_2etenToFloat_w(v_e_241));
        return (heff_from_int_f64(v_m_240) * v_t_244);
      } else {
        heff_drop(v_t_243);
        V v_t_245 = heff_intShl(MK_INT(1LL), MK_INT(53LL));
        if ((heff_intLt_c_lent(v_m_240, v_t_245, 0) && (heff_intLe_c_lent(MK_INT(-22LL), v_e_241, 1) && heff_intLt_c_lent(v_e_241, MK_INT(0LL), 2)))) {
          heff_drop(v_t_245);
          double v_t_246 = (g_std_2emath_2etenToFloat_w(heff_box_word((((int64_t)0ULL) - heff_unbox_word(v_e_241)))));
          return (heff_from_int_f64(v_m_240) / v_t_246);
        } else {
          heff_drop(v_t_245);
          V v_t_247 = (g_std_2emath_2enearestBits_24s705918251x1654869085(v_m_240, v_e_241));
          return heff_unbox_f64(heff_floatOfBits(MK_INT(64LL), v_t_247));
        }
      }
    }
  }
}
V g_std_2emath_2efromDecimal(V v_m_240, V v_e_241) {
  return heff_box_f64((g_std_2emath_2efromDecimal_w(v_m_240, v_e_241)));
}
V g_std_2emath_2efromDecimal_entry(V self, V *a) {
  (void)self;
  return g_std_2emath_2efromDecimal(a[0], a[1]);
}
Clo g_std_2emath_2ebitsOf_24s1803888623x733876950_clo = {{0x80000000u, K_CLO, 0}, g_std_2emath_2ebitsOf_24s1803888623x733876950_entry, 4, 0};

V g_std_2emath_2ebitsOf_24s1803888623x733876950(V v_b_240, V v_q_241, V v_r_242, V v_d_243) {
top: ;
  V v_t_244 = heff_intShl(MK_INT(1LL), MK_INT(23LL));
  V v_t_245 = heff_rec_n(5, shape_precision__least__infinity__above__under, (V[]){MK_INT(24LL), MK_INT(-149LL), heff_intMul(MK_INT(255LL), v_t_244), MK_INT(39LL), MK_INT(-45LL)});
  V v_t_246 = heff_intSub(v_b_240, heff_get_n(v_t_245, 1, 5));
  V v_t_247 = heff_intShl(MK_INT(1LL), MK_INT(23LL));
  V v_t_248 = heff_rec_n(5, shape_precision__least__infinity__above__under, (V[]){MK_INT(24LL), MK_INT(-149LL), heff_intMul(MK_INT(255LL), v_t_247), MK_INT(39LL), MK_INT(-45LL)});
  V v_t_249 = heff_intSub(heff_get_n(v_t_248, 0, 5), MK_INT(1LL));
  V v_t_2410 = heff_intShl(MK_INT(1LL), v_t_249);
  V v_t_2411;
  if ((heff_intLt_c(heff_dup(v_d_243), heff_intMul(MK_INT(2LL), heff_dup(v_r_242))) || (heff_intEq_c(heff_intMul(MK_INT(2LL), heff_dup(v_r_242)), heff_dup(v_d_243)) && (heff_unbox_word(heff_intMod(heff_dup(v_q_241), MK_INT(2LL))) == ((int64_t)1ULL))))) {
    heff_drop(v_r_242);
    heff_drop(v_d_243);
    v_t_2411 = heff_intAdd(v_q_241, MK_INT(1LL));
  } else {
    heff_drop(v_r_242);
    heff_drop(v_d_243);
    v_t_2411 = v_q_241;
  }
  V v_x_2412 = heff_intAdd(heff_intMul(v_t_246, v_t_2410), v_t_2411);
  V v_t_2413 = heff_intShl(MK_INT(1LL), MK_INT(23LL));
  V v_y_2414 = heff_intMul(MK_INT(255LL), v_t_2413);
  if (heff_intLe_c_lent(v_x_2412, v_y_2414, 0)) {
    heff_drop(v_y_2414);
    return v_x_2412;
  } else {
    heff_drop(v_x_2412);
    return v_y_2414;
  }
}
V g_std_2emath_2ebitsOf_24s1803888623x733876950_entry(V self, V *a) {
  (void)self;
  return g_std_2emath_2ebitsOf_24s1803888623x733876950(a[0], a[1], a[2], a[3]);
}
Clo g_std_2emath_2ebitsAt_24s788696364x166928227_clo = {{0x80000000u, K_CLO, 0}, g_std_2emath_2ebitsAt_24s788696364x166928227_entry, 3, 0};

V g_std_2emath_2ebitsAt_24s788696364x166928227(V v_num_240, V v_den_241, V v_b_242) {
top: ;
  V v_y_243 = heff_intSub(MK_INT(0LL), heff_dup(v_b_242));
  V v_t_244;
  if (heff_intLe_c_lent(MK_INT(0LL), v_y_243, 1)) {
    v_t_244 = v_y_243;
  } else {
    heff_drop(v_y_243);
    v_t_244 = MK_INT(0LL);
  }
  V v_n_245 = heff_intShl(v_num_240, v_t_244);
  V v_t_246;
  if (heff_intLe_c_lent(MK_INT(0LL), v_b_242, 1)) {
    v_t_246 = heff_dup(v_b_242);
  } else {
    v_t_246 = MK_INT(0LL);
  }
  V v_d_247 = heff_intShl(v_den_241, v_t_246);
  V v_q_248 = heff_intDiv(heff_dup(v_n_245), heff_dup(v_d_247));
  V v_t_249 = heff_intShl(MK_INT(1LL), MK_INT(23LL));
  V v_t_2410 = heff_rec_n(5, shape_precision__least__infinity__above__under, (V[]){MK_INT(24LL), MK_INT(-149LL), heff_intMul(MK_INT(255LL), v_t_249), MK_INT(39LL), MK_INT(-45LL)});
  V v_y_2411 = heff_intShl(MK_INT(1LL), heff_get_n(v_t_2410, 0, 5));
  if (heff_intLe_c_lent(v_y_2411, v_q_248, 1)) {
    V v_t_2412 = heff_intMul(heff_intMod(heff_dup(v_q_248), MK_INT(2LL)), heff_dup(v_d_247));
    V v_t_2413 = heff_intSub(v_n_245, heff_intMul(heff_dup(v_q_248), heff_dup(v_d_247)));
    return (g_std_2emath_2ebitsOf_24s1803888623x733876950(heff_intAdd(v_b_242, MK_INT(1LL)), heff_intDiv(v_q_248, MK_INT(2LL)), heff_intAdd(v_t_2412, v_t_2413), heff_intMul(MK_INT(2LL), v_d_247)));
  } else {
    V v_t_2414 = heff_intSub(v_n_245, heff_intMul(heff_dup(v_q_248), heff_dup(v_d_247)));
    return (g_std_2emath_2ebitsOf_24s1803888623x733876950(v_b_242, v_q_248, v_t_2414, v_d_247));
  }
}
V g_std_2emath_2ebitsAt_24s788696364x166928227_entry(V self, V *a) {
  (void)self;
  return g_std_2emath_2ebitsAt_24s788696364x166928227(a[0], a[1], a[2]);
}
Clo g_std_2emath_2enearestBits_24s226419449x1689653652_clo = {{0x80000000u, K_CLO, 0}, g_std_2emath_2enearestBits_24s226419449x1689653652_entry, 2, 0};

V g_std_2emath_2enearestBits_24s226419449x1689653652(V v_m_240, V v_e_241) {
top: ;
  V v_t_242 = heff_intShl(MK_INT(1LL), MK_INT(23LL));
  V v_t_243 = heff_rec_n(5, shape_precision__least__infinity__above__under, (V[]){MK_INT(24LL), MK_INT(-149LL), heff_intMul(MK_INT(255LL), v_t_242), MK_INT(39LL), MK_INT(-45LL)});
  if (heff_intLt_c(heff_get_n(v_t_243, 3, 5), heff_dup(v_e_241))) {
    heff_drop(v_m_240);
    heff_drop(v_e_241);
    V v_t_244 = heff_intShl(MK_INT(1LL), MK_INT(23LL));
    return heff_intMul(MK_INT(255LL), v_t_244);
  } else {
    V v_t_245;
    if (heff_intLt_c_lent(v_m_240, MK_INT(0LL), 2)) {
      v_t_245 = heff_intSub(MK_INT(0LL), heff_dup(v_m_240));
    } else {
      v_t_245 = heff_dup(v_m_240);
    }
    V v_t_246 = (g_std_2emath_2ebitLength_2ebitsOfSize_240(v_t_245, MK_INT(0LL)));
    V v_t_247 = heff_intDiv(heff_intMul(v_t_246, MK_INT(302LL)), MK_INT(1000LL));
    V v_t_248 = heff_intAdd(heff_intAdd(v_t_247, MK_INT(1LL)), heff_dup(v_e_241));
    V v_t_249 = heff_intShl(MK_INT(1LL), MK_INT(23LL));
    V v_t_2410 = heff_rec_n(5, shape_precision__least__infinity__above__under, (V[]){MK_INT(24LL), MK_INT(-149LL), heff_intMul(MK_INT(255LL), v_t_249), MK_INT(39LL), MK_INT(-45LL)});
    if (heff_intLt_c(v_t_248, heff_get_n(v_t_2410, 4, 5))) {
      heff_drop(v_m_240);
      heff_drop(v_e_241);
      return MK_INT(0LL);
    } else {
      V v_num_2412;
      if (heff_intLt_c_lent(MK_INT(0LL), v_e_241, 1)) {
        V v_t_2411 = (g_std_2emath_2etenTo(heff_dup(v_e_241)));
        v_num_2412 = heff_intMul(v_m_240, v_t_2411);
      } else {
        v_num_2412 = v_m_240;
      }
      V v_den_2413;
      if (heff_intLt_c_lent(v_e_241, MK_INT(0LL), 2)) {
        v_den_2413 = (g_std_2emath_2etenTo(heff_intSub(MK_INT(0LL), v_e_241)));
      } else {
        heff_drop(v_e_241);
        v_den_2413 = MK_INT(1LL);
      }
      V v_t_2414;
      if (heff_intLt_c_lent(v_num_2412, MK_INT(0LL), 2)) {
        v_t_2414 = heff_intSub(MK_INT(0LL), heff_dup(v_num_2412));
      } else {
        v_t_2414 = heff_dup(v_num_2412);
      }
      V v_t_2415 = (g_std_2emath_2ebitLength_2ebitsOfSize_240(v_t_2414, MK_INT(0LL)));
      V v_t_2416;
      if (heff_intLt_c_lent(v_den_2413, MK_INT(0LL), 2)) {
        v_t_2416 = heff_intSub(MK_INT(0LL), heff_dup(v_den_2413));
      } else {
        v_t_2416 = heff_dup(v_den_2413);
      }
      V v_t_2417 = (g_std_2emath_2ebitLength_2ebitsOfSize_240(v_t_2416, MK_INT(0LL)));
      V v_t_2418 = heff_intShl(MK_INT(1LL), MK_INT(23LL));
      V v_t_2419 = heff_rec_n(5, shape_precision__least__infinity__above__under, (V[]){MK_INT(24LL), MK_INT(-149LL), heff_intMul(MK_INT(255LL), v_t_2418), MK_INT(39LL), MK_INT(-45LL)});
      V v_x_2420 = heff_intSub(heff_intSub(v_t_2415, v_t_2417), heff_get_n(v_t_2419, 0, 5));
      V v_t_2421 = heff_intShl(MK_INT(1LL), MK_INT(23LL));
      V v_t_2422 = heff_rec_n(5, shape_precision__least__infinity__above__under, (V[]){MK_INT(24LL), MK_INT(-149LL), heff_intMul(MK_INT(255LL), v_t_2421), MK_INT(39LL), MK_INT(-45LL)});
      V v_y_2423 = heff_get_n(v_t_2422, 1, 5);
      V v_t_2424;
      if (heff_intLe_c_lent(v_x_2420, v_y_2423, 0)) {
        heff_drop(v_x_2420);
        v_t_2424 = v_y_2423;
      } else {
        heff_drop(v_y_2423);
        v_t_2424 = v_x_2420;
      }
      return (g_std_2emath_2ebitsAt_24s788696364x166928227(v_num_2412, v_den_2413, v_t_2424));
    }
  }
}
V g_std_2emath_2enearestBits_24s226419449x1689653652_entry(V self, V *a) {
  (void)self;
  return g_std_2emath_2enearestBits_24s226419449x1689653652(a[0], a[1]);
}