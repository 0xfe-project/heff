// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Binds 36386
#define TAG_Boxed 28180
#define TAG_BoxedWord 41718
#define TAG_Element 14172
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_IAny 21222
#define TAG_IBind 27068
#define TAG_IOp 20150
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_Kept 49931
#define TAG_Literal 34173
#define TAG_Merge 54398
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_Often 32846
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_Pinned 8573
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_RetAs 20415
#define TAG_RetClass 33382
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Unboxed 46787
#define TAG_Wants 58903
#define LBL_args 9498020
#define LBL_big 307066
#define LBL_boxedIn 304670893
#define LBL_boxedOut 854869195
#define LBL_kept 9783717
#define LBL_params 951713969
#define LBL_pinned 958995203
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_unboxedIn 1261597312
#define LBL_unboxedOut 454817126
static uint32_t shape_args__result[] = {LBL_args, LBL_result};
static uint32_t shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big[] = {LBL_reprs, LBL_boxedIn, LBL_unboxedIn, LBL_boxedOut, LBL_unboxedOut, LBL_pinned, LBL_kept, LBL_big};
V g_heff_2ecompile_2erepr_2easTheyCome(V);
V g_heff_2ecompile_2erepr_2easTheyCome_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2easTheyCome_clo;
V g_heff_2ecompile_2erepr_2edecideOf(V, V);
V g_heff_2ecompile_2erepr_2edecideOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edecideOf_clo;
V g_heff_2ecompile_2erepr_2edecidedIn(V, V, V);
V g_heff_2ecompile_2erepr_2edecidedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edecidedIn_clo;
V g_heff_2ecompile_2erepr_2eeventName(V);
V g_heff_2ecompile_2erepr_2eeventName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eeventName_clo;
V g_heff_2ecompile_2erepr_2efloat2Prims_get(void);
V g_heff_2ecompile_2erepr_2efloatRelPrims_get(void);
V g_heff_2ecompile_2erepr_2efourTo(V);
V g_heff_2ecompile_2erepr_2efourTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2efourTo_clo;
V g_heff_2ecompile_2erepr_2ehope(V);
V g_heff_2ecompile_2erepr_2ehope_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ehope_clo;
HeffT2 g_heff_2ecompile_2erepr_2ehopeSig_24cpr(V, V, V, V);
V g_heff_2ecompile_2erepr_2eindexOfL(V, V, V);
V g_heff_2ecompile_2erepr_2eindexOfL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eindexOfL_clo;
V g_heff_2ecompile_2erepr_2eloops(V);
V g_heff_2ecompile_2erepr_2eloops_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eloops_clo;
V g_heff_2ecompile_2erepr_2ementionedBy(V);
V g_heff_2ecompile_2erepr_2ementionedBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ementionedBy_clo;
V g_heff_2ecompile_2erepr_2enoStats_get(void);
HeffT2 g_heff_2ecompile_2erepr_2eopShape_24cpr(V, V);
HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V);
HeffT2 g_heff_2ecompile_2erepr_2eproposalIn_24s1922589859x1920127656_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2erepr_2eproposeSig_24cpr(V, V, V, V);
V g_heff_2ecompile_2erepr_2epushPrim(V, V, V);
V g_heff_2ecompile_2erepr_2epushPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2epushPrim_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2erepr_2ereprOfName(V);
V g_heff_2ecompile_2erepr_2ereprOfName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprOfName_clo;
V g_heff_2ecompile_2erepr_2eretName_get(void);
V g_heff_2ecompile_2erepr_2ereturned(V, V, V);
V g_heff_2ecompile_2erepr_2ereturned_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereturned_clo;
V g_heff_2ecompile_2erepr_2erootFrom(V, V, V);
V g_heff_2ecompile_2erepr_2erootFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2erootFrom_clo;
V g_heff_2ecompile_2erepr_2eseen(V, V);
V g_heff_2ecompile_2erepr_2eseen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eseen_clo;
V g_heff_2ecompile_2erepr_2esigName(V);
V g_heff_2ecompile_2erepr_2esigName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2esigName_clo;
V g_heff_2ecompile_2erepr_2eslotRepr(V, V);
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eslotRepr_clo;
V g_heff_2ecompile_2erepr_2estatsOf(V, V);
V g_heff_2ecompile_2erepr_2estatsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2estatsOf_clo;
V g_heff_2ecompile_2erepr_2estepGives(V, V, V, V);
V g_heff_2ecompile_2erepr_2estepGives_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2estepGives_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_heff_2ecompile_2erepr_2eunite(V, V, V);
V g_heff_2ecompile_2erepr_2eunite_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eunite_clo;
V g_heff_2ecompile_2erepr_2eunpinOne(V, V);
V g_heff_2ecompile_2erepr_2eunpinOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eunpinOne_clo;
V g_heff_2ecompile_2erepr_2ewalk(V, V, V, V);
V g_heff_2ecompile_2erepr_2ewalk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ewalk_clo;
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_list_2eany_24s52266323x652150664(V);
V g_list_2eany_24s52266323x652150664_entry(V self, V *a);
extern Clo g_list_2eany_24s52266323x652150664_clo;
V g_list_2eany_24s688114072x773797180(V, V);
V g_list_2eany_24s688114072x773797180_entry(V self, V *a);
extern Clo g_list_2eany_24s688114072x773797180_clo;
HeffT2 g_list_2efind_24s1896676244x1358329894_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1070132730x1847213213(V, V);
V g_list_2efoldl_24f1070132730x1847213213_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1070132730x1847213213_clo;
V g_list_2efoldl_24s1134919403x2060330530(V, V);
V g_list_2efoldl_24s1134919403x2060330530_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1134919403x2060330530_clo;
V g_list_2efoldl_24s1275727578x1654209034(V, V);
V g_list_2efoldl_24s1275727578x1654209034_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1275727578x1654209034_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1310249268x749995235(V, V, V);
V g_list_2emap_24s1310249268x749995235_entry(V self, V *a);
extern Clo g_list_2emap_24s1310249268x749995235_clo;
V g_list_2emap_24s1598879313x231311047(V);
V g_list_2emap_24s1598879313x231311047_entry(V self, V *a);
extern Clo g_list_2emap_24s1598879313x231311047_clo;
V g_list_2emap_24s2090270526x1588636862(V);
V g_list_2emap_24s2090270526x1588636862_entry(V self, V *a);
extern Clo g_list_2emap_24s2090270526x1588636862_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1583460153x999201201(V, V, V, V);
V g_prelude_2e_2b_2b_24f1583460153x999201201_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1583460153x999201201_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str0, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str1, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str2, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str3, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str4, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str5, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str6, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str7, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str8, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str9, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str10, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str11, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str12, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str13, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str14, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str15, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str16, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str17, 7, "Float32");
Clo g_heff_2ecompile_2erepr_2ereprEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereprEq_entry, 2, 0};

V g_heff_2ecompile_2erepr_2ereprEq(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RepV: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_RepV: {
      return NTAG(TAG_True);
    }
    case TAG_RepFix: {
      return NTAG(TAG_False);
    }
    case TAG_RepF64: {
      return NTAG(TAG_False);
    }
    case TAG_RepInt: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_RepFix: {
    V v_a_243 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_RepV: {
      return NTAG(TAG_False);
    }
    case TAG_RepFix: {
      V v_b_244 = heff_field(v_x2_241, 0);
      V v_t_245;
      switch (heff_tag_of(v_a_243)) {
      case TAG_I8: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str0);
        break;
      }
      case TAG_I16: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str1);
        break;
      }
      case TAG_I32: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str2);
        break;
      }
      case TAG_I64: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str3);
        break;
      }
      case TAG_U8: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str4);
        break;
      }
      case TAG_U16: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str5);
        break;
      }
      case TAG_U32: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str6);
        break;
      }
      case TAG_U64: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str7);
        break;
      }
      case TAG_F32: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str8);
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      V v_t_246;
      switch (heff_tag_of(v_b_244)) {
      case TAG_I8: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str9);
        break;
      }
      case TAG_I16: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str10);
        break;
      }
      case TAG_I32: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str11);
        break;
      }
      case TAG_I64: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str12);
        break;
      }
      case TAG_U8: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str13);
        break;
      }
      case TAG_U16: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str14);
        break;
      }
      case TAG_U32: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str15);
        break;
      }
      case TAG_U64: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str16);
        break;
      }
      case TAG_F32: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str17);
        break;
      }
      default: heff_nomatch(v_b_244);
      }
      V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_245, v_t_246, 0));
      heff_drop(v_t_245);
      heff_drop(v_t_246);
      return v_ret_24bool;
    }
    case TAG_RepF64: {
      return NTAG(TAG_False);
    }
    case TAG_RepInt: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_RepF64: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_RepV: {
      return NTAG(TAG_False);
    }
    case TAG_RepFix: {
      return NTAG(TAG_False);
    }
    case TAG_RepF64: {
      return NTAG(TAG_True);
    }
    case TAG_RepInt: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_RepInt: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_RepV: {
      return NTAG(TAG_False);
    }
    case TAG_RepFix: {
      return NTAG(TAG_False);
    }
    case TAG_RepF64: {
      return NTAG(TAG_False);
    }
    case TAG_RepInt: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2ereprEq(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str1, 1, ",");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str2, 1, "_");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str3, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str4, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str5, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str6, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str7, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str8, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str9, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str10, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str11, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str12, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str13, 3, "Int");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str14, 2, "->");
Clo g_heff_2ecompile_2erepr_2esigName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2esigName_entry, 1, 0};

V g_heff_2ecompile_2erepr_2esigName(V v_s_240) {
top: ;
  V v_params_241 = heff_take_field(v_s_240, 0);
  V v_result_242 = heff_get_n(v_s_240, 1, 2);
  V v_x2_243 = (g_list_2emap_24s2090270526x1588636862(v_params_241));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2erepr_2esigName_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2erepr_2esigName_str1); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_248;
  switch (heff_tag_of(v_result_242)) {
  case TAG_RepV: {
    v_t_248 = ((V)&g_heff_2ecompile_2erepr_2esigName_str2);
    break;
  }
  case TAG_RepFix: {
    V v_w_247 = heff_field(v_result_242, 0);
    heff_take_n(v_result_242, 1ULL, 1);
    switch (heff_tag_of(v_w_247)) {
    case TAG_I8: {
      v_t_248 = ((V)&g_heff_2ecompile_2erepr_2esigName_str3);
      break;
    }
    case TAG_I16: {
      v_t_248 = ((V)&g_heff_2ecompile_2erepr_2esigName_str4);
      break;
    }
    case TAG_I32: {
      v_t_248 = ((V)&g_heff_2ecompile_2erepr_2esigName_str5);
      break;
    }
    case TAG_I64: {
      v_t_248 = ((V)&g_heff_2ecompile_2erepr_2esigName_str6);
      break;
    }
    case TAG_U8: {
      v_t_248 = ((V)&g_heff_2ecompile_2erepr_2esigName_str7);
      break;
    }
    case TAG_U16: {
      v_t_248 = ((V)&g_heff_2ecompile_2erepr_2esigName_str8);
      break;
    }
    case TAG_U32: {
      v_t_248 = ((V)&g_heff_2ecompile_2erepr_2esigName_str9);
      break;
    }
    case TAG_U64: {
      v_t_248 = ((V)&g_heff_2ecompile_2erepr_2esigName_str10);
      break;
    }
    case TAG_F32: {
      v_t_248 = ((V)&g_heff_2ecompile_2erepr_2esigName_str11);
      break;
    }
    default: heff_nomatch(v_w_247);
    }
    break;
  }
  case TAG_RepF64: {
    v_t_248 = ((V)&g_heff_2ecompile_2erepr_2esigName_str12);
    break;
  }
  case TAG_RepInt: {
    v_t_248 = ((V)&g_heff_2ecompile_2erepr_2esigName_str13);
    break;
  }
  default: heff_nomatch(v_result_242);
  }
  return heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2erepr_2esigName_str14), v_t_248));
}
V g_heff_2ecompile_2erepr_2esigName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2esigName(a[0]);
}

HeffT2 g_heff_2ecompile_2erepr_2eopShape_24cpr(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_OpAdd: {
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_243 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_242}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  }
  case TAG_OpSub: {
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_245 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_244}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_245}});
  }
  case TAG_OpMul: {
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_247 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_246}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_247}});
  }
  case TAG_OpDiv: {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_249 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_248}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_249}});
  }
  case TAG_OpRem: {
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2411 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2410}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2411}});
  }
  case TAG_OpEq: {
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2413 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_t_2412}), NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2413}});
  }
  case TAG_OpLt: {
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2415 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_t_2414}), NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2415}});
  }
  case TAG_OpLe: {
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2417 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_t_2416}), NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2417}});
  }
  case TAG_OpAnd: {
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2419 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2418}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2419}});
  }
  case TAG_OpOr: {
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2421 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2420}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2421}});
  }
  case TAG_OpXor: {
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2423 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2422}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2423}});
  }
  case TAG_OpShl: {
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2425 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2424}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2425}});
  }
  case TAG_OpShr: {
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2427 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2426}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2427}});
  }
  case TAG_OpShow: {
    heff_drop(v_r_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_OpFromInt: {
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepV), NTAG(TAG_Nil)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_args__result, (V[]){v_t_2428, v_r_240})}});
  }
  case TAG_OpToInt: {
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, NTAG(TAG_Nil)});
    V v_t_2430 = heff_rec_n(2, shape_args__result, (V[]){v_t_2429, NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2430}});
  }
  case TAG_OpSqrt: {
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_args__result, (V[]){v_t_2431, v_r_240})}});
  }
  case TAG_OpFromFloat: {
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_args__result, (V[]){v_t_2432, v_r_240})}});
  }
  case TAG_OpToFloat: {
    V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, NTAG(TAG_Nil)});
    V v_t_2434 = heff_rec_n(2, shape_args__result, (V[]){v_t_2433, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2434}});
  }
  case TAG_OpFloor: {
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, NTAG(TAG_Nil)});
    V v_t_2436 = heff_rec_n(2, shape_args__result, (V[]){v_t_2435, NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2436}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat2Prims_str0, 8, "floatPow");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat2Prims_str1, 8, "floatDiv");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat2Prims_str2, 10, "floatAtan2");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat2Prims_str3, 8, "floatSub");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat2Prims_str4, 8, "floatMul");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat2Prims_str5, 8, "floatAdd");

static V g_heff_2ecompile_2erepr_2efloat2Prims_val;
static HEFF_ONCE g_heff_2ecompile_2erepr_2efloat2Prims_st;
static V g_heff_2ecompile_2erepr_2efloat2Prims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat2Prims_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat2Prims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat2Prims_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat2Prims_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat2Prims_str4), v_t_241})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat2Prims_str5), v_t_242});
}
V g_heff_2ecompile_2erepr_2efloat2Prims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erepr_2efloat2Prims_st)) return g_heff_2ecompile_2erepr_2efloat2Prims_val;
  return heff_global(&g_heff_2ecompile_2erepr_2efloat2Prims_val, &g_heff_2ecompile_2erepr_2efloat2Prims_st, g_heff_2ecompile_2erepr_2efloat2Prims_init);
}
HEFF_LIT(g_heff_2ecompile_2erepr_2efloatRelPrims_str0, 7, "floatLe");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloatRelPrims_str1, 7, "floatEq");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloatRelPrims_str2, 7, "floatLt");

static V g_heff_2ecompile_2erepr_2efloatRelPrims_val;
static HEFF_ONCE g_heff_2ecompile_2erepr_2efloatRelPrims_st;
static V g_heff_2ecompile_2erepr_2efloatRelPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloatRelPrims_str0), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloatRelPrims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloatRelPrims_str2), v_t_240})});
}
V g_heff_2ecompile_2erepr_2efloatRelPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erepr_2efloatRelPrims_st)) return g_heff_2ecompile_2erepr_2efloatRelPrims_val;
  return heff_global(&g_heff_2ecompile_2erepr_2efloatRelPrims_val, &g_heff_2ecompile_2erepr_2efloatRelPrims_st, g_heff_2ecompile_2erepr_2efloatRelPrims_init);
}
Clo g_heff_2ecompile_2erepr_2eslotRepr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eslotRepr_entry, 2, 0};

V g_heff_2ecompile_2erepr_2eslotRepr(V v_i_240, V v_t_241) {
top: ;
  if (heff_intLt_c(v_i_240, MK_INT(16LL))) {
    switch (heff_tag_of(v_t_241)) {
    case TAG_FtFloat: {
      return NTAG(TAG_RepF64);
    }
    case TAG_FtFixed: {
      V v_w_242 = heff_field(v_t_241, 0);
      V v_ru_24t_241_24FtFixed = heff_take_reuse_n(v_t_241, 1ULL, 1);
      int64_t v_t_243;
      switch (heff_tag_of(v_w_242)) {
      case TAG_I8: {
        v_t_243 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_243 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_243 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_243 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_243 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_243 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_243 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_243 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_243 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_242);
      }
      if ((v_t_243 == ((int64_t)64ULL))) {
        return heff_tag_at_n(v_ru_24t_241_24FtFixed, TAG_RepFix, 1, (V[]){v_w_242});
      } else {
        heff_drop(v_w_242);
        heff_drop_cell(v_ru_24t_241_24FtFixed, 1);
        return NTAG(TAG_RepV);
      }
    }
    case TAG_FtOther: {
      return NTAG(TAG_RepV);
    }
    case TAG_FtAny: {
      return NTAG(TAG_RepV);
    }
    default: return heff_nomatch(v_t_241);
    }
  } else {
    heff_drop(v_t_241);
    return NTAG(TAG_RepV);
  }
}
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2eslotRepr(a[0], a[1]);
}
Clo g_heff_2ecompile_2erepr_2efourTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2efourTo_entry, 1, 0};

V g_heff_2ecompile_2erepr_2efourTo(V v_i_240) {
top: ;
  if (heff_intLe_c_lent(v_i_240, MK_INT(0LL), 2)) {
    heff_drop(v_i_240);
    return MK_INT(1LL);
  } else {
    V v_t_241 = (g_heff_2ecompile_2erepr_2efourTo(heff_intSub(v_i_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(4LL), v_t_241);
  }
}
V g_heff_2ecompile_2erepr_2efourTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2efourTo(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str0, 1, "_");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str1, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str2, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str3, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str4, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str5, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str6, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str7, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str8, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str9, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str10, 7, "Float32");
Clo g_heff_2ecompile_2erepr_2ereprOfName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereprOfName_entry, 1, 0};

V g_heff_2ecompile_2erepr_2ereprOfName(V v_x_240) {
top: ;
  if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str0), 2)) {
    return NTAG(TAG_RepV);
  } else {
    if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str1), 2)) {
      return NTAG(TAG_RepF64);
    } else {
      HeffT2 v_t_241 = (g_list_2efind_24s1896676244x1358329894_24cpr(((V)&g_heff_2ecompile_2erepr_2ereprOfName_str2), ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str3), ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str4), ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str5), ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str6), ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str7), ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str8), ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str9), ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str10), v_x_240, heff_dup(g_heff_2eelab_2efixed_2eallFixed_get())));
      {
        V v_field_243 = v_t_241.f[1];
        int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
        if ((v_tag_242 == ((int64_t)0ULL))) {
          V v_x_244 = v_field_243;
          return heff_tag_n(TAG_RepFix, 1, (V[]){v_x_244});
        } else {
          heff_drop(v_field_243);
          return NTAG(TAG_RepV);
        }
      }
    }
  }
}
V g_heff_2ecompile_2erepr_2ereprOfName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2ereprOfName(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erepr_2etyIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2etyIn_entry, 2, 0};

V g_heff_2ecompile_2erepr_2etyIn(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_FtAny);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_ts_243 = heff_field(v_x2_241, 1);
    if (heff_intLe_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      return heff_dup(v_t_242);
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_ts_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2etyIn(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erepr_2epushPrim_lam0(V self, V *args);
Clo g_heff_2ecompile_2erepr_2epushPrim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2epushPrim_entry, 3, 0};

V g_heff_2ecompile_2erepr_2epushPrim(V v_p_240, V v_vs_241, V v_rest_242) {
top: ;
  V v_ks_243 = (g_heff_2ecompile_2erepr_2easTheyCome(v_p_240));
  HeffT2 v_t_244 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_240));
  V v_t_248;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_s_247 = v_field_246;
      v_t_248 = heff_get_n(v_s_247, 0, 2);
    } else {
      heff_drop(v_field_246);
      v_t_248 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_vs_241)));
    }
  }
  V v_t_249 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_248, heff_dup(v_vs_241)));
  V v_t_2410 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_241; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_vs_241); r_; });
  V v_t_2411 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2410, MK_INT(1LL))));
  return (g_prelude_2e_2b_2b_24f1583460153x999201201(v_rest_242, heff_clo_n(g_heff_2ecompile_2erepr_2epushPrim_lam0, 2, 1, (V[]){v_ks_243}), v_t_249, v_t_2411));
}
V g_heff_2ecompile_2erepr_2epushPrim_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2epushPrim(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2erepr_2epushPrim_lam0(V self, V *args) {
  V v_x2_2412 = args[0];
  V v_i_2413 = args[1];
  V v_ks_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_r_2414 = heff_field(v_x2_2412, 0);
    V v_v_2415 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    V v_t_2416 = ({ V a_0 = v_i_2413; V a_1 = v_ks_243; V r_ = (g_list_2eany_24s688114072x773797180(a_0, a_1)); heff_drop(v_ks_243); r_; });
    if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
      heff_drop(v_r_2414);
      heff_drop_cell(v_ru_24x2_2412_24MkPair, 2);
      heff_drop(v_t_2416);
      return heff_tag_n(TAG_IAny, 1, (V[]){v_v_2415});
    } else {
      heff_drop(v_t_2416);
      return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_IVal, 2, (V[]){v_r_2414, v_v_2415});
    }
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
HEFF_LIT(g_heff_2ecompile_2erepr_2estepGives_str0, 10, "arrayIndex");
Clo g_heff_2ecompile_2erepr_2estepGives_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2estepGives_entry, 4, 0};

V g_heff_2ecompile_2erepr_2estepGives(V v_lp_240, V v_x_241, V v_o_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_o_242)) {
  case TAG_OSimple: {
    V v_ru_24o_242_24OSimple = heff_take_reuse_n(v_o_242, 0ULL, 1);
    V v_t_245;
    if ((heff_dup(v_lp_240) == NTAG(TAG_True))) {
      v_t_245 = heff_tag_at_n(v_ru_24o_242_24OSimple, TAG_Often, 1, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241})});
    } else {
      v_t_245 = heff_tag_at_n(v_ru_24o_242_24OSimple, TAG_Boxed, 1, (V[]){v_x_241});
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_acc_243});
  }
  case TAG_OCall: {
    V v_ru_24o_242_24OCall = heff_take_reuse_n(v_o_242, 0ULL, 2);
    V v_t_248;
    if ((heff_dup(v_lp_240) == NTAG(TAG_True))) {
      v_t_248 = heff_tag_n(TAG_Often, 1, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241})});
    } else {
      v_t_248 = heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241});
    }
    return heff_tag_at_n(v_ru_24o_242_24OCall, TAG_Cons, 2, (V[]){v_t_248, v_acc_243});
  }
  case TAG_OApply: {
    V v_ru_24o_242_24OApply = heff_take_reuse_n(v_o_242, 0ULL, 2);
    V v_t_2411;
    if ((heff_dup(v_lp_240) == NTAG(TAG_True))) {
      v_t_2411 = heff_tag_n(TAG_Often, 1, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241})});
    } else {
      v_t_2411 = heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241});
    }
    return heff_tag_at_n(v_ru_24o_242_24OApply, TAG_Cons, 2, (V[]){v_t_2411, v_acc_243});
  }
  case TAG_OPrim: {
    V v_p_2412 = heff_field(v_o_242, 0);
    V v_ru_24o_242_24OPrim = heff_take_reuse_n(v_o_242, 1ULL, 2);
    if (heff_strEq_c(v_p_2412, ((V)&g_heff_2ecompile_2erepr_2estepGives_str0))) {
      V v_t_2414;
      if ((heff_dup(v_lp_240) == NTAG(TAG_True))) {
        v_t_2414 = heff_tag_n(TAG_Often, 1, (V[]){heff_tag_n(TAG_Element, 1, (V[]){v_x_241})});
      } else {
        v_t_2414 = heff_tag_n(TAG_Element, 1, (V[]){v_x_241});
      }
      return heff_tag_at_n(v_ru_24o_242_24OPrim, TAG_Cons, 2, (V[]){v_t_2414, v_acc_243});
    } else {
      V v_t_2415;
      if ((heff_dup(v_lp_240) == NTAG(TAG_True))) {
        v_t_2415 = heff_tag_n(TAG_Often, 1, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241})});
      } else {
        v_t_2415 = heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241});
      }
      return heff_tag_at_n(v_ru_24o_242_24OPrim, TAG_Cons, 2, (V[]){v_t_2415, v_acc_243});
    }
  }
  case TAG_OAbandon: {
    V v_t_2416;
    if ((heff_dup(v_lp_240) == NTAG(TAG_True))) {
      v_t_2416 = heff_tag_n(TAG_Often, 1, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241})});
    } else {
      v_t_2416 = heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241});
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_acc_243});
  }
  case TAG_OBool: {
    V v_ru_24o_242_24OBool = heff_take_reuse_n(v_o_242, 0ULL, 1);
    V v_t_2418;
    if ((heff_dup(v_lp_240) == NTAG(TAG_True))) {
      v_t_2418 = heff_tag_at_n(v_ru_24o_242_24OBool, TAG_Often, 1, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241})});
    } else {
      v_t_2418 = heff_tag_at_n(v_ru_24o_242_24OBool, TAG_Boxed, 1, (V[]){v_x_241});
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_acc_243});
  }
  default: return heff_nomatch(v_o_242);
  }
}
V g_heff_2ecompile_2erepr_2estepGives_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2estepGives(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erepr_2eindexOfL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eindexOfL_entry, 3, 0};

V g_heff_2ecompile_2erepr_2eindexOfL(V v_l_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_ks_244 = heff_field(v_x3_242, 1);
    if (heff_strEq_c_lent(v_l_240, v_k_243, 0)) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
    } else {
      V t_0 = v_l_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_ks_244;
      v_l_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erepr_2eindexOfL_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2erepr_2eindexOfL(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erepr_2ementionedBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ementionedBy_entry, 1, 0};

V g_heff_2ecompile_2erepr_2ementionedBy(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Merge: {
    V v_y_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Merge = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Merge, TAG_Cons, 2, (V[]){v_y_242, NTAG(TAG_Nil)});
  }
  case TAG_Boxed: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_BoxedWord: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_Element: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_Unboxed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Literal: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Wants: {
    V v_x_2410 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Wants = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Wants, TAG_Cons, 2, (V[]){v_x_2410, NTAG(TAG_Nil)});
  }
  case TAG_Binds: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_Pinned: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_Kept: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Often: {
    V v_e_2416 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_e_2416;
    v_x1_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2ementionedBy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ementionedBy(a[0]);
}
Clo g_heff_2ecompile_2erepr_2ereturned_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereturned_entry, 3, 0};

V g_heff_2ecompile_2erepr_2ereturned(V v_x1_240, V v_o_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RetAs: {
    V v_r_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24RetAs = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_o_241)) {
    case TAG_OSimple: {
      V v_v_244 = heff_field(v_o_241, 0);
      heff_take_n(v_o_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24RetAs, 1);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 2, (V[]){v_r_243, v_v_244}), v_rest_242});
    }
    case TAG_OCall: {
      heff_drop(v_r_243);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24RetAs, TAG_IOp, 1, (V[]){v_o_241}), v_rest_242});
    }
    case TAG_OApply: {
      heff_drop(v_r_243);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24RetAs, TAG_IOp, 1, (V[]){v_o_241}), v_rest_242});
    }
    case TAG_OPrim: {
      heff_drop(v_r_243);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24RetAs, TAG_IOp, 1, (V[]){v_o_241}), v_rest_242});
    }
    case TAG_OAbandon: {
      heff_drop(v_r_243);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24RetAs, TAG_IOp, 1, (V[]){v_o_241}), v_rest_242});
    }
    case TAG_OBool: {
      heff_drop(v_r_243);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24RetAs, TAG_IOp, 1, (V[]){v_o_241}), v_rest_242});
    }
    default: return heff_nomatch(v_o_241);
    }
  }
  case TAG_RetClass: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IBind, 2, (V[]){heff_dup(g_heff_2ecompile_2erepr_2eretName_get()), v_o_241}), v_rest_242});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2ereturned_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ereturned(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erepr_2eloops_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eloops_entry, 1, 0};

V g_heff_2ecompile_2erepr_2eloops(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_TSeq: {
    V v_t_242 = heff_field(v_x1_240, 1);
    V t_0 = v_t_242;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_TReturn: {
    return NTAG(TAG_False);
  }
  case TAG_TLoop: {
    return NTAG(TAG_True);
  }
  case TAG_TIf: {
    V v_t_246 = heff_field(v_x1_240, 1);
    V v_e_247 = heff_field(v_x1_240, 2);
    V v_t_248 = (g_heff_2ecompile_2erepr_2eloops(v_t_246));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_248);
      V t_0 = v_e_247;
      v_x1_240 = t_0;
      goto top;
    }
  }
  case TAG_TCase: {
    V v_arms_2410 = heff_field(v_x1_240, 1);
    HEFF_LAST return g_list_2eany_24s52266323x652150664(v_arms_2410);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2eloops_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2eloops(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erepr_2erootFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2erootFrom_entry, 3, 0};

V g_heff_2ecompile_2erepr_2erootFrom(V v_parent_240, V v_x_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return v_x_241;
  }
  case TAG_Just: {
    V v_y_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    if (heff_strEq_c_lent(v_x_241, v_y_243, 0)) {
      heff_drop(v_y_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return v_x_241;
    } else {
      heff_drop(v_x_241);
      V v_t_244 = (g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(v_ru_24x3_242_24Just, v_parent_240, v_y_243));
      V t_0 = v_parent_240;
      V t_1 = v_y_243;
      V t_2 = v_t_244;
      v_parent_240 = t_0;
      v_x_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erepr_2erootFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2erootFrom(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erepr_2eunite_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eunite_entry, 3, 0};

V g_heff_2ecompile_2erepr_2eunite(V v_parent_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_243 = (g_std_2emap_2elookup_24s1930949324x2078207031(v_parent_240, v_a_241));
  V v_t_244 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, heff_dup(v_a_241), v_t_243));
  V v_t_245 = (g_std_2emap_2elookup_24s1930949324x2078207031(v_parent_240, v_b_242));
  V v_t_246 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, heff_dup(v_b_242), v_t_245));
  if (heff_strEq_c(v_t_244, v_t_246)) {
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return v_parent_240;
  } else {
    V v_t_247 = (g_std_2emap_2elookup_24s1930949324x2078207031(v_parent_240, v_a_241));
    V v_t_248 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, v_a_241, v_t_247));
    V v_t_249 = (g_std_2emap_2elookup_24s1930949324x2078207031(v_parent_240, v_b_242));
    V v_t_2410 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, v_b_242, v_t_249));
    HEFF_LAST return g_std_2emap_2einsert_24s93785294x875597928(v_parent_240, v_t_248, v_t_2410);
  }
}
V g_heff_2ecompile_2erepr_2eunite_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2eunite(a[0], a[1], a[2]);
}

static V g_heff_2ecompile_2erepr_2enoStats_val;
static HEFF_ONCE g_heff_2ecompile_2erepr_2enoStats_st;
static V g_heff_2ecompile_2erepr_2enoStats_init(void) {
  return heff_rec_n(8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, (V[]){NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False)});
}
V g_heff_2ecompile_2erepr_2enoStats_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erepr_2enoStats_st)) return g_heff_2ecompile_2erepr_2enoStats_val;
  return heff_global(&g_heff_2ecompile_2erepr_2enoStats_val, &g_heff_2ecompile_2erepr_2enoStats_st, g_heff_2ecompile_2erepr_2enoStats_init);
}
V g_heff_2ecompile_2erepr_2estatsOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2erepr_2estatsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2estatsOf_entry, 2, 0};

V g_heff_2ecompile_2erepr_2estatsOf(V v_parent_240, V v_evs_241) {
top: ;
  return (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2erepr_2estatsOf_lam0, 2, 1, (V[]){heff_dup(v_parent_240)}), heff_dup(g_std_2emap_2eempty_get()), v_evs_241));
}
V g_heff_2ecompile_2erepr_2estatsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2estatsOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erepr_2estatsOf_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_e_243 = args[1];
  V v_parent_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_244 = (g_heff_2ecompile_2erepr_2eeventName(v_e_243));
  V v_t_245 = (g_std_2emap_2elookup_24s1930949324x2078207031(v_parent_240, v_x_244));
  V v_root_246 = ({ V a_0 = v_parent_240; V a_1 = v_x_244; V a_2 = v_t_245; V r_ = (g_heff_2ecompile_2erepr_2erootFrom(a_0, a_1, a_2)); heff_drop(v_parent_240); r_; });
  HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_m_242, v_root_246));
  V v_t_2411;
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2410 = v_field_249;
      v_t_2411 = v_x_2410;
    } else {
      heff_drop(v_field_249);
      v_t_2411 = heff_dup(g_heff_2ecompile_2erepr_2enoStats_get());
    }
  }
  V v_t_2412 = ({ V a_0 = v_e_243; V a_1 = v_t_2411; V r_ = (g_heff_2ecompile_2erepr_2eseen(a_0, a_1)); heff_drop(v_e_243); r_; });
  return (g_std_2emap_2einsert_24s93785294x875597928(v_m_242, v_root_246, v_t_2412));
}
Clo g_heff_2ecompile_2erepr_2edecideOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2edecideOf_entry, 2, 0};

V g_heff_2ecompile_2erepr_2edecideOf(V v_s_240, V v_rs_241) {
top: ;
  V v_boxedIn_242 = heff_take_field(v_s_240, 1);
  V v_boxedOut_243 = heff_take_field(v_s_240, 3);
  V v_unboxedIn_244 = heff_take_field(v_s_240, 2);
  V v_unboxedOut_245 = heff_get_n(v_s_240, 4, 8);
  switch (heff_tag_of(v_rs_241)) {
  case TAG_Nil: {
    heff_drop(v_boxedIn_242);
    heff_drop(v_boxedOut_243);
    heff_drop(v_unboxedIn_244);
    heff_drop(v_unboxedOut_245);
    return NTAG(TAG_RepV);
  }
  case TAG_Cons: {
    V v_r_246 = heff_field(v_rs_241, 0);
    V v_rs2_247 = heff_field(v_rs_241, 1);
    switch (heff_tag_of(v_rs2_247)) {
    case TAG_Nil: {
      V v_t_249;
      switch (heff_tag_of(v_r_246)) {
      case TAG_RepV: {
        v_t_249 = MK_INT(1LL);
        break;
      }
      case TAG_RepFix: {
        v_t_249 = MK_INT(1LL);
        break;
      }
      case TAG_RepF64: {
        v_t_249 = MK_INT(2LL);
        break;
      }
      case TAG_RepInt: {
        v_t_249 = MK_INT(1LL);
        break;
      }
      default: heff_nomatch(v_r_246);
      }
      V v_t_2412;
      switch (heff_tag_of(v_r_246)) {
      case TAG_RepV: {
        v_t_2412 = MK_INT(0LL);
        break;
      }
      case TAG_RepFix: {
        V v_w_2410 = heff_field(v_r_246, 0);
        int64_t v_t_2411;
        switch (heff_tag_of(v_w_2410)) {
        case TAG_I8: {
          v_t_2411 = ((int64_t)8ULL);
          break;
        }
        case TAG_I16: {
          v_t_2411 = ((int64_t)16ULL);
          break;
        }
        case TAG_I32: {
          v_t_2411 = ((int64_t)32ULL);
          break;
        }
        case TAG_I64: {
          v_t_2411 = ((int64_t)64ULL);
          break;
        }
        case TAG_U8: {
          v_t_2411 = ((int64_t)8ULL);
          break;
        }
        case TAG_U16: {
          v_t_2411 = ((int64_t)16ULL);
          break;
        }
        case TAG_U32: {
          v_t_2411 = ((int64_t)32ULL);
          break;
        }
        case TAG_U64: {
          v_t_2411 = ((int64_t)64ULL);
          break;
        }
        case TAG_F32: {
          v_t_2411 = ((int64_t)32ULL);
          break;
        }
        default: heff_nomatch(v_w_2410);
        }
        if ((v_t_2411 == ((int64_t)64ULL))) {
          v_t_2412 = MK_INT(2LL);
        } else {
          v_t_2412 = MK_INT(1LL);
        }
        break;
      }
      case TAG_RepF64: {
        v_t_2412 = MK_INT(3LL);
        break;
      }
      case TAG_RepInt: {
        v_t_2412 = MK_INT(1LL);
        break;
      }
      default: heff_nomatch(v_r_246);
      }
      V v_t_2413 = heff_intAdd(heff_intMul(v_boxedIn_242, v_t_249), heff_intMul(v_boxedOut_243, v_t_2412));
      V v_t_2416;
      switch (heff_tag_of(v_r_246)) {
      case TAG_RepV: {
        v_t_2416 = MK_INT(0LL);
        break;
      }
      case TAG_RepFix: {
        V v_w_2414 = heff_field(v_r_246, 0);
        int64_t v_t_2415;
        switch (heff_tag_of(v_w_2414)) {
        case TAG_I8: {
          v_t_2415 = ((int64_t)8ULL);
          break;
        }
        case TAG_I16: {
          v_t_2415 = ((int64_t)16ULL);
          break;
        }
        case TAG_I32: {
          v_t_2415 = ((int64_t)32ULL);
          break;
        }
        case TAG_I64: {
          v_t_2415 = ((int64_t)64ULL);
          break;
        }
        case TAG_U8: {
          v_t_2415 = ((int64_t)8ULL);
          break;
        }
        case TAG_U16: {
          v_t_2415 = ((int64_t)16ULL);
          break;
        }
        case TAG_U32: {
          v_t_2415 = ((int64_t)32ULL);
          break;
        }
        case TAG_U64: {
          v_t_2415 = ((int64_t)64ULL);
          break;
        }
        case TAG_F32: {
          v_t_2415 = ((int64_t)32ULL);
          break;
        }
        default: heff_nomatch(v_w_2414);
        }
        if ((v_t_2415 == ((int64_t)64ULL))) {
          v_t_2416 = MK_INT(2LL);
        } else {
          v_t_2416 = MK_INT(1LL);
        }
        break;
      }
      case TAG_RepF64: {
        v_t_2416 = MK_INT(3LL);
        break;
      }
      case TAG_RepInt: {
        v_t_2416 = MK_INT(1LL);
        break;
      }
      default: heff_nomatch(v_r_246);
      }
      V v_t_2418;
      switch (heff_tag_of(v_r_246)) {
      case TAG_RepV: {
        v_t_2418 = MK_INT(1LL);
        break;
      }
      case TAG_RepFix: {
        v_t_2418 = MK_INT(1LL);
        break;
      }
      case TAG_RepF64: {
        v_t_2418 = MK_INT(2LL);
        break;
      }
      case TAG_RepInt: {
        v_t_2418 = MK_INT(1LL);
        break;
      }
      default: heff_nomatch(v_r_246);
      }
      V v_t_2419 = heff_intAdd(heff_intMul(v_unboxedIn_244, v_t_2416), heff_intMul(v_unboxedOut_245, v_t_2418));
      if (heff_intLe_c(v_t_2413, v_t_2419)) {
        return heff_dup(v_r_246);
      } else {
        return NTAG(TAG_RepV);
      }
    }
    case TAG_Cons: {
      heff_drop(v_boxedIn_242);
      heff_drop(v_boxedOut_243);
      heff_drop(v_unboxedIn_244);
      heff_drop(v_unboxedOut_245);
      return NTAG(TAG_RepV);
    }
    default: return heff_nomatch(v_rs2_247);
    }
  }
  default: return heff_nomatch(v_rs_241);
  }
}
V g_heff_2ecompile_2erepr_2edecideOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2edecideOf(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erepr_2ehope_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ehope_entry, 1, 0};

V g_heff_2ecompile_2erepr_2ehope(V v_s_240) {
top: ;
  V v_kept_241 = heff_take_field(v_s_240, 6);
  V v_pinned_242 = heff_take_field(v_s_240, 5);
  V v_reprs_243 = heff_take_field(v_s_240, 0);
  V v_big_244 = heff_get_n(v_s_240, 7, 8);
  switch (heff_tag_of(v_kept_241)) {
  case TAG_Nothing: {
    if ((heff_dup(v_pinned_242) == NTAG(TAG_True))) {
      heff_drop(v_pinned_242);
      heff_drop(v_reprs_243);
      heff_drop(v_big_244);
      return NTAG(TAG_RepV);
    } else {
      heff_drop(v_pinned_242);
      V v_r_249;
      switch (heff_tag_of(v_reprs_243)) {
      case TAG_Nil: {
        v_r_249 = NTAG(TAG_RepV);
        break;
      }
      case TAG_Cons: {
        V v_r_245 = heff_field(v_reprs_243, 0);
        V v_rs2_246 = heff_field(v_reprs_243, 1);
        heff_take_n(v_reprs_243, 3ULL, 2);
        switch (heff_tag_of(v_rs2_246)) {
        case TAG_Nil: {
          v_r_249 = v_r_245;
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_rs2_246, 0ULL, 2);
          heff_drop(v_r_245);
          v_r_249 = NTAG(TAG_RepV);
          break;
        }
        default: heff_nomatch(v_rs2_246);
        }
        break;
      }
      default: heff_nomatch(v_reprs_243);
      }
      switch (heff_tag_of(v_r_249)) {
      case TAG_RepV: {
        heff_drop(v_big_244);
        return v_r_249;
      }
      case TAG_RepFix: {
        heff_drop(v_big_244);
        return v_r_249;
      }
      case TAG_RepF64: {
        heff_drop(v_big_244);
        return v_r_249;
      }
      case TAG_RepInt: {
        if ((heff_dup(v_big_244) == NTAG(TAG_True))) {
          heff_drop(v_big_244);
          return NTAG(TAG_RepV);
        } else {
          heff_drop(v_big_244);
          return NTAG(TAG_RepInt);
        }
      }
      default: return heff_nomatch(v_r_249);
      }
    }
  }
  case TAG_Just: {
    V v_r_2411 = heff_field(v_kept_241, 0);
    heff_take_n(v_kept_241, 1ULL, 1);
    heff_drop(v_pinned_242);
    heff_drop(v_reprs_243);
    heff_drop(v_big_244);
    return v_r_2411;
  }
  default: return heff_nomatch(v_kept_241);
  }
}
V g_heff_2ecompile_2erepr_2ehope_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ehope(a[0]);
}
V g_heff_2ecompile_2erepr_2eproposeSig_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2erepr_2eproposeSig_24cpr(V v_sg_240, V v_bounces_241, V v_xs_242, V v_t_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Wants, 2, (V[]){heff_dup(g_heff_2ecompile_2erepr_2eretName_get()), NTAG(TAG_RepV)});
  V v_t_245 = (g_list_2efoldl_24f1070132730x1847213213(NTAG(TAG_Nil), heff_dup(v_xs_242)));
  V v_t_246 = heff_tag_n(TAG_ITl, 3, (V[]){heff_dup(v_xs_242), NTAG(TAG_RetClass), v_t_243});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = (g_heff_2ecompile_2erepr_2ewalk(v_sg_240, NTAG(TAG_False), v_t_245, v_t_247));
  V v_evs_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_248});
  V v_pins_2410 = (g_list_2efoldl_24s1134919403x2060330530(heff_dup(g_std_2emap_2eempty_get()), v_evs_249));
  V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_evs_249));
  V v_evs_2415 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erepr_2eproposeSig_24cpr_lam0, 2, 1, (V[]){v_pins_2410}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2411; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
  V v_parent_2416 = (g_list_2efoldl_24s1275727578x1654209034(heff_dup(g_std_2emap_2eempty_get()), v_evs_2415));
  V v_t_2417 = (g_heff_2ecompile_2erepr_2estatsOf(v_parent_2416, v_evs_2415));
  V v_f_2418 = ({ V a_0 = v_parent_2416; V a_1 = v_t_2417; V a_2 = v_xs_242; V r_ = (g_list_2emap_24s1310249268x749995235(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
  V v_f_2420;
  if ((heff_dup(v_bounces_241) == NTAG(TAG_True))) {
    heff_drop(v_evs_2415);
    heff_drop(v_parent_2416);
    v_f_2420 = NTAG(TAG_RepV);
  } else {
    V v_t_2419 = ({ V a_0 = v_parent_2416; V a_1 = v_evs_2415; V r_ = (g_heff_2ecompile_2erepr_2estatsOf(a_0, a_1)); heff_drop(v_evs_2415); r_; });
    v_f_2420 = ({ V a_0 = v_parent_2416; V a_1 = v_t_2419; V a_2 = heff_dup(g_heff_2ecompile_2erepr_2eretName_get()); V r_ = (g_heff_2ecompile_2erepr_2edecidedIn(a_0, a_1, a_2)); heff_drop(v_parent_2416); heff_drop(v_t_2419); r_; });
  }
  return ((HeffT2){{v_f_2418, v_f_2420}});
}
V g_heff_2ecompile_2erepr_2eproposeSig_24cpr_lam0(V self, V *args) {
  V v_acc_2412 = args[0];
  V v_x_2413 = args[1];
  V v_pins_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = ({ V a_0 = v_pins_2410; V a_1 = v_x_2413; V r_ = (g_heff_2ecompile_2erepr_2eunpinOne(a_0, a_1)); heff_drop(v_pins_2410); r_; });
  return (g_prelude_2e_2b_2b(v_t_2414, v_acc_2412));
}
V g_heff_2ecompile_2erepr_2eproposalIn_24s1922589859x1920127656_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2erepr_2eproposalIn_24s1922589859x1920127656_24cpr(V v_parent_240, V v_evs_241, V v_bounces_242, V v_xs_243) {
top: ;
  V v_stats_244 = (g_heff_2ecompile_2erepr_2estatsOf(v_parent_240, v_evs_241));
  V v_f_2413 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erepr_2eproposalIn_24s1922589859x1920127656_24cpr_lam0, 1, 2, (V[]){heff_dup(v_parent_240), v_stats_244}), v_xs_243));
  V v_f_2422;
  if ((heff_dup(v_bounces_242) == NTAG(TAG_True))) {
    v_f_2422 = NTAG(TAG_RepV);
  } else {
    V v_stats_2414 = (g_heff_2ecompile_2erepr_2estatsOf(v_parent_240, v_evs_241));
    V v_t_2415 = ({ V a_0 = v_parent_240; V b_1 = heff_dup(g_heff_2ecompile_2erepr_2eretName_get()); V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2416 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, heff_dup(g_heff_2ecompile_2erepr_2eretName_get()), v_t_2415));
    HeffT2 v_t_2417 = ({ V a_0 = v_stats_2414; V a_1 = v_t_2416; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_stats_2414); heff_drop(v_t_2416); r_; });
    V v_t_2421;
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      if ((v_tag_2418 == ((int64_t)0ULL))) {
        V v_x_2420 = v_field_2419;
        v_t_2421 = v_x_2420;
      } else {
        heff_drop(v_field_2419);
        v_t_2421 = heff_dup(g_heff_2ecompile_2erepr_2enoStats_get());
      }
    }
    v_f_2422 = (g_heff_2ecompile_2erepr_2ehope(v_t_2421));
  }
  return ((HeffT2){{v_f_2413, v_f_2422}});
}
V g_heff_2ecompile_2erepr_2eproposalIn_24s1922589859x1920127656_24cpr_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_parent_240 = heff_env(self)[0];
  V v_stats_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = (g_std_2emap_2elookup_24s1930949324x2078207031(v_parent_240, v_x_245));
  V v_t_247 = ({ V a_0 = v_parent_240; V a_1 = v_x_245; V a_2 = v_t_246; V r_ = (g_heff_2ecompile_2erepr_2erootFrom(a_0, a_1, a_2)); heff_drop(v_parent_240); r_; });
  HeffT2 v_t_248 = ({ V a_0 = v_stats_244; V a_1 = v_t_247; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_stats_244); heff_drop(v_t_247); r_; });
  V v_t_2412;
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_x_2411 = v_field_2410;
      v_t_2412 = v_x_2411;
    } else {
      heff_drop(v_field_2410);
      v_t_2412 = heff_dup(g_heff_2ecompile_2erepr_2enoStats_get());
    }
  }
  return (g_heff_2ecompile_2erepr_2ehope(v_t_2412));
}
V g_heff_2ecompile_2erepr_2ehopeSig_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2erepr_2ehopeSig_24cpr(V v_sg_240, V v_bounces_241, V v_xs_242, V v_t_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Wants, 2, (V[]){heff_dup(g_heff_2ecompile_2erepr_2eretName_get()), NTAG(TAG_RepV)});
  V v_t_245 = (g_list_2efoldl_24f1070132730x1847213213(NTAG(TAG_Nil), heff_dup(v_xs_242)));
  V v_t_246 = heff_tag_n(TAG_ITl, 3, (V[]){heff_dup(v_xs_242), NTAG(TAG_RetClass), v_t_243});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = (g_heff_2ecompile_2erepr_2ewalk(v_sg_240, NTAG(TAG_False), v_t_245, v_t_247));
  V v_evs_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_248});
  V v_pins_2410 = (g_list_2efoldl_24s1134919403x2060330530(heff_dup(g_std_2emap_2eempty_get()), v_evs_249));
  V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_evs_249));
  V v_evs_2415 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erepr_2ehopeSig_24cpr_lam0, 2, 1, (V[]){v_pins_2410}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2411; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
  V v_t_2416 = (g_list_2efoldl_24s1275727578x1654209034(heff_dup(g_std_2emap_2eempty_get()), v_evs_2415));
  return ({ V a_0 = v_t_2416; V a_1 = v_evs_2415; V a_2 = v_bounces_241; V a_3 = v_xs_242; HeffT2 r_ = (g_heff_2ecompile_2erepr_2eproposalIn_24s1922589859x1920127656_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2416); heff_drop(v_evs_2415); r_; });
}
V g_heff_2ecompile_2erepr_2ehopeSig_24cpr_lam0(V self, V *args) {
  V v_acc_2412 = args[0];
  V v_x_2413 = args[1];
  V v_pins_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = ({ V a_0 = v_pins_2410; V a_1 = v_x_2413; V r_ = (g_heff_2ecompile_2erepr_2eunpinOne(a_0, a_1)); heff_drop(v_pins_2410); r_; });
  return (g_prelude_2e_2b_2b(v_t_2414, v_acc_2412));
}