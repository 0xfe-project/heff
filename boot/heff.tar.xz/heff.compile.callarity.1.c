// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define LBL_ar 9880
#define LBL_body 9524841
#define LBL_calls 295783919
#define LBL_defs 9574869
#define LBL_dirty 296951788
#define LBL_globals 352931696
#define LBL_key 315609
#define LBL_known 303562589
#define LBL_many 9839398
#define LBL_name 9869138
#define LBL_pa 10328
#define LBL_params 951713969
#define LBL_supply 1056026650
#define LBL_tables 1065764240
#define LBL_takes 311482598
#define LBL_uses 10094739
#define LBL_vars 10107635
static uint32_t shape_calls__uses__takes[] = {LBL_calls, LBL_uses, LBL_takes};
static uint32_t shape_defs__supply[] = {LBL_defs, LBL_supply};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_key__params__many__ar[] = {LBL_key, LBL_params, LBL_many, LBL_ar};
static uint32_t shape_known__defs__supply[] = {LBL_known, LBL_defs, LBL_supply};
static uint32_t shape_pa[] = {LBL_pa};
static uint32_t shape_tables__globals[] = {LBL_tables, LBL_globals};
static uint32_t shape_vars__globals__dirty[] = {LBL_vars, LBL_globals, LBL_dirty};
V g_heff_2ecompile_2ecallarity_2eafterRound(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eafterRound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eafterRound_clo;
V g_heff_2ecompile_2ecallarity_2eappNote(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eappNote_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eappNote_clo;
V g_heff_2ecompile_2ecallarity_2eappPush(V, V, V);
V g_heff_2ecompile_2ecallarity_2eappPush_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eappPush_clo;
V g_heff_2ecompile_2ecallarity_2eargsNote(V, V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eargsNote_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eargsNote_clo;
V g_heff_2ecompile_2ecallarity_2earityOne(V, V);
V g_heff_2ecompile_2ecallarity_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2earityOne_clo;
V g_heff_2ecompile_2ecallarity_2edefNotes(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2edefNotes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2edefNotes_clo;
V g_heff_2ecompile_2ecallarity_2eexpandApp(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandApp_clo;
V g_heff_2ecompile_2ecallarity_2eexpandArg(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandArg_clo;
V g_heff_2ecompile_2ecallarity_2eexpandArgs(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandArgs_clo;
V g_heff_2ecompile_2ecallarity_2eexpandGo(V, V);
V g_heff_2ecompile_2ecallarity_2eexpandGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandGo_clo;
V g_heff_2ecompile_2ecallarity_2eextend(V, V);
V g_heff_2ecompile_2ecallarity_2eextend_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eextend_clo;
V g_heff_2ecompile_2ecallarity_2efreshMany(V, V);
V g_heff_2ecompile_2ecallarity_2efreshMany_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2efreshMany_clo;
HeffT2 g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(V, V);
V g_heff_2ecompile_2ecallarity_2ehanded(V, V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2ehanded_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2ehanded_clo;
V g_heff_2ecompile_2ecallarity_2eknownAdd(V, V, V);
V g_heff_2ecompile_2ecallarity_2eknownAdd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eknownAdd_clo;
V g_heff_2ecompile_2ecallarity_2enoteUse(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2enoteUse_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2enoteUse_clo;
V g_heff_2ecompile_2ecallarity_2enotedThen(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2enotedThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2enotedThen_clo;
V g_heff_2ecompile_2ecallarity_2enthOr(V, V, V);
V g_heff_2ecompile_2ecallarity_2enthOr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2enthOr_clo;
V g_heff_2ecompile_2ecallarity_2epushNonVars(V, V);
V g_heff_2ecompile_2ecallarity_2epushNonVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2epushNonVars_clo;
HeffT2 g_heff_2ecompile_2ecallarity_2eraiseDef_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2erounds(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2erounds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2erounds_clo;
V g_heff_2ecompile_2ecallarity_2esameAll(V, V);
V g_heff_2ecompile_2ecallarity_2esameAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2esameAll_clo;
V g_heff_2ecompile_2ecallarity_2esameInts(V, V);
V g_heff_2ecompile_2ecallarity_2esameInts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2esameInts_clo;
V g_heff_2ecompile_2ecallarity_2esameTables(V, V);
V g_heff_2ecompile_2ecallarity_2esameTables_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2esameTables_clo;
V g_heff_2ecompile_2ecallarity_2eusesW(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eusesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eusesW_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s445268946x679229867(V, V);
V g_list_2efoldl_24s445268946x679229867_entry(V self, V *a);
extern Clo g_list_2efoldl_24s445268946x679229867_clo;
V g_list_2efoldl_24s634541619x737135667(V, V, V);
V g_list_2efoldl_24s634541619x737135667_entry(V self, V *a);
extern Clo g_list_2efoldl_24s634541619x737135667_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_prelude_2etraverse_24s740446701x774604387(V, V);
V g_prelude_2etraverse_24s740446701x774604387_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s740446701x774604387_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
HEFF_LIT(g_heff_2ecompile_2ecallarity_2efreshMany_24cpr_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2ecallarity_2efreshMany_24cpr_str1, 1, "z");

HeffT2 g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(V v_k_240, V v_p_241) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  } else {
    V v_m_242 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2efreshMany_clo), 1, (V[]){heff_intSub(v_k_240, MK_INT(1LL))}));
    V v_x2_243 = heff_tr(heff_call(v_m_242, 1, (V[]){heff_intAdd(heff_dup(v_p_241), MK_INT(1LL))}));
    switch (heff_tag_of(v_x2_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_n_245 = heff_field(v_x2_243, 1);
      V v_ru_24x2_243_24MkPair = heff_take_reuse_n(v_x2_243, 3ULL, 2);
      V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2ecallarity_2efreshMany_24cpr_str0), heff_intShow(v_p_241));
      V v_f_247 = heff_tag_at_n(v_ru_24x2_243_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2ecallarity_2efreshMany_24cpr_str1), v_t_246), v_x_244});
      return ((HeffT2){{v_f_247, v_n_245}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_243)}});
    }
  }
}
Clo g_heff_2ecompile_2ecallarity_2enthOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2enthOr_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2enthOr(V v_d_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return v_d_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_d_240);
      heff_drop(v_i_241);
      return heff_dup(v_x_243);
    } else {
      V t_0 = v_d_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      V t_2 = v_xs_244;
      v_d_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecallarity_2enthOr_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecallarity_2enthOr(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecallarity_2enoteUse_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2enoteUse_entry, 5, 0};

V g_heff_2ecompile_2ecallarity_2enoteUse(V v_here_240, V v_g_241, V v_k_242, V v_x4_243, V v_n_244) {
top: ;
  V v_many_245 = heff_take_field(v_here_240, 2);
  V v_ar_246 = heff_get_n(v_here_240, 3, 4);
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    V v_t_247;
    if ((heff_dup(v_many_245) == NTAG(TAG_True))) {
      heff_drop(v_many_245);
      v_t_247 = MK_INT(2LL);
    } else {
      heff_drop(v_many_245);
      v_t_247 = MK_INT(1LL);
    }
    HeffT2 v_t_248 = ({ V a_0 = v_ar_246; V a_1 = v_g_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_ar_246); r_; });
    V v_t_2412;
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_x_2411 = v_field_2410;
        v_t_2412 = v_x_2411;
      } else {
        heff_drop(v_field_2410);
        v_t_2412 = MK_INT(0LL);
      }
    }
    V v_u_2413 = heff_rec_n(3, shape_calls__uses__takes, (V[]){v_k_242, v_t_247, v_t_2412});
    V v_t_2414 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_n_244, 1), v_g_241, v_u_2413));
    return ({ V rv_1 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_n_244, 5ULL, 3, shape_vars__globals__dirty, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Just: {
    V v_u_2415 = heff_field(v_x4_243, 0);
    heff_drop(v_ar_246);
    V v_takes_2416 = heff_dup(heff_rfield(v_u_2415, 2));
    V v_calls_2417 = heff_dup(heff_rfield(v_u_2415, 0));
    V v_uses_2418 = heff_dup(heff_rfield(v_u_2415, 1));
    if ((heff_intLt_c_lent(MK_INT(0LL), v_takes_2416, 1) ? heff_intLe_c_lent(v_calls_2417, v_takes_2416, 0) : (heff_intLe_c_lent(MK_INT(2LL), v_uses_2418, 1) || heff_intEq_c_lent(v_calls_2417, MK_INT(0LL), 2)))) {
      heff_drop(v_g_241);
      heff_drop(v_k_242);
      heff_drop(v_many_245);
      heff_drop(v_takes_2416);
      heff_drop(v_calls_2417);
      heff_drop(v_uses_2418);
      return v_n_244;
    } else {
      V v_t_2419;
      if (heff_intLt_c_lent(v_k_242, v_calls_2417, 0)) {
        heff_drop(v_calls_2417);
        v_t_2419 = v_k_242;
      } else {
        heff_drop(v_k_242);
        v_t_2419 = v_calls_2417;
      }
      V v_t_2420;
      if ((heff_dup(v_many_245) == NTAG(TAG_True))) {
        heff_drop(v_many_245);
        v_t_2420 = MK_INT(2LL);
      } else {
        heff_drop(v_many_245);
        v_t_2420 = MK_INT(1LL);
      }
      V v_t_2421 = heff_rec_n(3, shape_calls__uses__takes, (V[]){v_t_2419, heff_intAdd(v_uses_2418, v_t_2420), v_takes_2416});
      V v_t_2422 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_n_244, 1), v_g_241, v_t_2421));
      return ({ V rv_1 = v_t_2422; V rr_ = heff_rec_reuse_nf(v_n_244, 5ULL, 3, shape_vars__globals__dirty, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecallarity_2enoteUse_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2ecallarity_2enoteUse(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2ecallarity_2eargsNote_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eargsNote_entry, 6, 0};

V g_heff_2ecompile_2ecallarity_2eargsNote(V v_t_240, V v_here_241, V v_h_242, V v_j_243, V v_x5_244, V v_n_245) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_here_241);
    heff_drop(v_j_243);
    return v_n_245;
  }
  case TAG_Cons: {
    V v_x51_246 = heff_field(v_x5_244, 0);
    V v_args_247 = heff_field(v_x5_244, 1);
    switch (heff_tag_of(v_x51_246)) {
    case TAG_EVar: {
      V v_x_248 = heff_field(v_x51_246, 0);
      V v_t_249 = (g_heff_2ecompile_2ecallarity_2ehanded(heff_dup(v_t_240), heff_dup(v_here_241), v_h_242, heff_dup(v_j_243), heff_dup(v_x_248), v_n_245));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_t_249;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EGlobal: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_ELam: {
      V v_ys_2411 = heff_field(v_x51_246, 0);
      HeffT2 v_t_2413 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_t_240, 0), v_h_242));
      V v_t_2419;
      {
        V v_field_2415 = v_t_2413.f[1];
        int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
        V v_x_2417;
        if ((v_tag_2414 == ((int64_t)0ULL))) {
          V v_ps_2416 = v_field_2415;
          v_x_2417 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_j_243); V a_2 = v_ps_2416; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_2416); r_; });
        } else {
          heff_drop(v_field_2415);
          v_x_2417 = MK_INT(0LL);
        }
        V v_y_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_2411));
        if (heff_intLt_c(v_y_2418, v_x_2417)) {
          v_t_2419 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_n_245, 3ULL, 3, shape_vars__globals__dirty, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        } else {
          v_t_2419 = v_n_245;
        }
      }
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_t_2419;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EApp: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_ELet: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_ERecord: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EProj: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_ETag: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EMatch: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EPrim: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EPrimCall: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_ECall: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EInt: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EFloat: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EStr: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EBytes: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EFixed: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EFloat32: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EAbandon: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EBool: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_ESet: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EValues: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EFix: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x51_246);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2ecallarity_2eargsNote_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a4 = a[4]; V r = g_heff_2ecompile_2ecallarity_2eargsNote(a[0], a[1], a2, a[3], a4, a[5]); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_heff_2ecompile_2ecallarity_2eappNote_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eappNote_entry, 5, 0};

V g_heff_2ecompile_2ecallarity_2eappNote(V v_t_240, V v_here_241, V v_f_242, V v_args_243, V v_n_244) {
top: ;
  switch (heff_tag_of(v_f_242)) {
  case TAG_EVar: {
    V v_x_245 = heff_field(v_f_242, 0);
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    V v_k_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_243));
    HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_n_244, 0), v_x_245));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_k0_2410 = v_field_249;
        if (heff_intLt_c_lent(v_k_246, v_k0_2410, 2)) {
          V v_t_2411 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_n_244, 0), heff_dup(v_x_245), v_k_246));
          return ({ V rv_0 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_n_244, 6ULL, 3, shape_vars__globals__dirty, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        } else {
          heff_drop(v_k_246);
          return v_n_244;
        }
      } else {
        heff_drop(v_k_246);
        heff_drop(v_field_249);
        return v_n_244;
      }
    }
  }
  case TAG_EGlobal: {
    V v_g_2412 = heff_field(v_f_242, 0);
    V v_k_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_243));
    V v_t_2414 = (g_std_2emap_2elookup_24s1930949324x2078207031(heff_rfield(v_n_244, 1), v_g_2412));
    V v_t_2415 = ({ V a_0 = heff_dup(v_here_241); V a_1 = heff_dup(v_g_2412); V a_2 = v_k_2413; V a_3 = v_t_2414; V a_4 = v_n_244; V r_ = (g_heff_2ecompile_2ecallarity_2enoteUse(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2414); r_; });
    return (g_heff_2ecompile_2ecallarity_2eargsNote(v_t_240, v_here_241, v_g_2412, MK_INT(0LL), v_args_243, v_t_2415));
  }
  case TAG_ELam: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EApp: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_ELet: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_ERecord: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EProj: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_ETag: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EMatch: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EPrim: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EPrimCall: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_ECall: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EInt: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EFloat: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EStr: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EBytes: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EFixed: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EFloat32: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EAbandon: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EBool: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_ESet: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EValues: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EFix: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  default: return heff_nomatch(v_f_242);
  }
}
V g_heff_2ecompile_2ecallarity_2eappNote_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2ecallarity_2eappNote(a[0], a[1], a2, a3, a[4]); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2ecallarity_2eappPush_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eappPush_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2eappPush(V v_f_240, V v_args_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_f_240)) {
  case TAG_EVar: {
    heff_take_n(v_f_240, 0ULL, 1);
    return (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
  }
  case TAG_EGlobal: {
    heff_take_n(v_f_240, 0ULL, 1);
    return (g_heff_2ecompile_2ecallarity_2epushNonVars(v_args_241, v_rest_242));
  }
  case TAG_ELam: {
    V v_t_247 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_247});
  }
  case TAG_EApp: {
    V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2410});
  }
  case TAG_ELet: {
    V v_t_2414 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2414});
  }
  case TAG_ERecord: {
    V v_t_2417 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2417});
  }
  case TAG_EProj: {
    V v_t_2422 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2422});
  }
  case TAG_ETag: {
    V v_t_2426 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2426});
  }
  case TAG_EMatch: {
    V v_t_2429 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2429});
  }
  case TAG_EPrim: {
    V v_t_2431 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2431});
  }
  case TAG_EPrimCall: {
    V v_t_2434 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2434});
  }
  case TAG_ECall: {
    V v_t_2437 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2437});
  }
  case TAG_EInt: {
    V v_t_2439 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2439});
  }
  case TAG_EFloat: {
    V v_t_2441 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2441});
  }
  case TAG_EStr: {
    V v_t_2443 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2443});
  }
  case TAG_EBytes: {
    V v_t_2445 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2445});
  }
  case TAG_EFixed: {
    V v_t_2448 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2448});
  }
  case TAG_EFloat32: {
    V v_t_2450 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2450});
  }
  case TAG_EAbandon: {
    V v_t_2451 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2451});
  }
  case TAG_EBool: {
    V v_t_2453 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2453});
  }
  case TAG_ESet: {
    V v_t_2457 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2457});
  }
  case TAG_EValues: {
    V v_t_2459 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2459});
  }
  case TAG_EFix: {
    V v_t_2462 = (g_heff_2ecompile_2eir_2eappendI(v_args_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2462});
  }
  default: return heff_nomatch(v_f_240);
  }
}
V g_heff_2ecompile_2ecallarity_2eappPush_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eappPush(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2ecallarity_2eusesW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eusesW_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2eusesW(V v_t_240, V v_here_241, V v_x3_242, V v_n_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    heff_drop_rec(v_here_241, 4);
    return v_n_243;
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_EVar: {
      V v_x_246 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_n_243, 0), v_x_246));
      V v_t_2412;
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_k0_2410 = v_field_249;
          if (heff_intLt_c(MK_INT(0LL), v_k0_2410)) {
            V v_t_2411 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_n_243, 0), v_x_246, MK_INT(0LL)));
            v_t_2412 = ({ V rv_0 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_n_243, 6ULL, 3, shape_vars__globals__dirty, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          } else {
            heff_drop(v_x_246);
            v_t_2412 = v_n_243;
          }
        } else {
          heff_drop(v_x_246);
          heff_drop(v_field_249);
          v_t_2412 = v_n_243;
        }
      }
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_t_2412;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EGlobal: {
      V v_g_2413 = heff_field(v_x31_244, 0);
      V v_ru_24x31_244_24EGlobal = heff_take_reuse_n(v_x31_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2414 = (g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(v_ru_24x31_244_24EGlobal, heff_rfield(v_n_243, 1), v_g_2413));
      V v_t_2415 = ({ V a_0 = heff_dup(v_here_241); V a_1 = v_g_2413; V a_2 = MK_INT(0LL); V a_3 = v_t_2414; V a_4 = v_n_243; V r_ = (g_heff_2ecompile_2ecallarity_2enoteUse(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2414); r_; });
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_t_2415;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_ELam: {
      V v_b_2417 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 2ULL, 2);
      V v_t_2418 = heff_rec_n(4, shape_key__params__many__ar, (V[]){heff_dup(heff_rfield(v_here_241, 0)), heff_dup(heff_rfield(v_here_241, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_here_241, 3))});
      V v_t_2419 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_2417, NTAG(TAG_Nil)});
      V v_t_2420 = (g_heff_2ecompile_2ecallarity_2eusesW(heff_dup(v_t_240), v_t_2418, v_t_2419, v_n_243));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_t_2420;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2421 = heff_field(v_x31_244, 0);
      V v_args_2422 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2423 = (g_heff_2ecompile_2ecallarity_2eappPush(heff_dup(v_f_2421), heff_dup(v_args_2422), v_rest_245));
      V v_t_2424 = ({ V a_0 = heff_dup(v_t_240); V a_1 = heff_dup(v_here_241); V a_2 = v_f_2421; V a_3 = v_args_2422; V a_4 = v_n_243; V r_ = (g_heff_2ecompile_2ecallarity_2eappNote(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_f_2421); heff_drop(v_args_2422); r_; });
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2423;
      V t_3 = v_t_2424;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2426 = heff_field(v_x31_244, 1);
      V v_b_2427 = heff_field(v_x31_244, 2);
      heff_take_n(v_x31_244, 6ULL, 3);
      V v_t_2428 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2426, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2427, v_rest_245})});
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2428;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2429 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 2);
      V v_t_2431 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x3_242_24Cons, v_fs_2429, v_rest_245));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2431;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2432 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 4);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2432, v_rest_245});
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_ETag: {
      V v_args_2437 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 2ULL, 3);
      V v_t_2439 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_args_2437, v_rest_245));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2439;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2440 = heff_field(v_x31_244, 0);
      V v_arms_2441 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      V v_t_2442 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2441, v_rest_245));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2440, v_t_2442});
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_args_2445 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 2ULL, 2);
      V v_t_2446 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_args_2445, v_rest_245));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2446;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_ECall: {
      V v_g_2447 = heff_field(v_x31_244, 0);
      V v_args_2448 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2449 = (g_heff_2ecompile_2ecallarity_2eappPush(heff_tag_n(TAG_EGlobal, 1, (V[]){heff_dup(v_g_2447)}), heff_dup(v_args_2448), v_rest_245));
      V v_t_2450 = ({ V a_0 = heff_dup(v_t_240); V a_1 = heff_dup(v_here_241); V b_2 = heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2447}); V a_3 = v_args_2448; V a_4 = v_n_243; V r_ = (g_heff_2ecompile_2ecallarity_2eappNote(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); heff_drop(v_args_2448); r_; });
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2449;
      V t_3 = v_t_2450;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2458 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2459 = ({ V a_0 = v_c_2458; V a_1 = v_rest_245; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2458); r_; });
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2459;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2461 = heff_field(v_x31_244, 1);
      V v_b_2462 = heff_field(v_x31_244, 2);
      heff_take_n(v_x31_244, 6ULL, 3);
      V v_t_2463 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2461, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2462, v_rest_245})});
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2463;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2464 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 1);
      V v_t_2465 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_es_2464, v_rest_245));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2465;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecallarity_2eusesW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eusesW(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2ecallarity_2edefNotes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2edefNotes_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2edefNotes(V v_t_240, V v_ar_241, V v_gl_242, V v_d_243) {
top: ;
  V v_key_244 = heff_take_field(v_d_243, 0);
  V v_body_245 = heff_get_n(v_d_243, 2, 3);
  V v_t_2445;
  switch (heff_tag_of(v_body_245)) {
  case TAG_EVar: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EGlobal: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ELam: {
    V v_xs_248 = heff_dup(heff_field(v_body_245, 0));
    v_t_2445 = v_xs_248;
    break;
  }
  case TAG_EApp: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ELet: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ERecord: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EProj: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ETag: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EMatch: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EPrim: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ECall: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EInt: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFloat: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EStr: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EBytes: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFixed: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFloat32: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EAbandon: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EBool: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ESet: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EValues: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFix: {
    v_t_2445 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_body_245);
  }
  V v_t_2446 = heff_rec_n(4, shape_key__params__many__ar, (V[]){v_key_244, v_t_2445, NTAG(TAG_False), v_ar_241});
  V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_body_245), NTAG(TAG_Nil)});
  V v_t_2487;
  switch (heff_tag_of(v_body_245)) {
  case TAG_EVar: {
    heff_take_n(v_body_245, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_body_245, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ELam: {
    V v_xs_2450 = heff_field(v_body_245, 0);
    heff_take_n(v_body_245, 1ULL, 2);
    v_t_2487 = v_xs_2450;
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_body_245, 0ULL, 2);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_body_245, 0ULL, 3);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_body_245, 0ULL, 2);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_body_245, 0ULL, 4);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_body_245, 0ULL, 3);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_body_245, 0ULL, 2);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_body_245, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_body_245, 0ULL, 2);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_body_245, 0ULL, 2);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_body_245, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFloat: {
    heff_take_na(v_body_245, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_body_245, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_body_245, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_body_245, 0ULL, 2);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_body_245, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EAbandon: {
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EBool: {
    heff_take_n(v_body_245, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ESet: {
    heff_take_n(v_body_245, 0ULL, 3);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EValues: {
    heff_take_n(v_body_245, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_body_245, 0ULL, 2);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_body_245);
  }
  V v_t_2488 = ({ V a_0 = MK_INT(1000000LL); V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_t_2487; V r_ = (g_list_2efoldl_24s634541619x737135667(a_0, a_1, a_2)); heff_drop(v_t_2487); r_; });
  V v_t_2489 = heff_rec_n(3, shape_vars__globals__dirty, (V[]){v_t_2488, v_gl_242, NTAG(TAG_False)});
  HEFF_LAST return g_heff_2ecompile_2ecallarity_2eusesW(v_t_240, v_t_2446, v_t_2447, v_t_2489);
}
V g_heff_2ecompile_2ecallarity_2edefNotes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2edefNotes(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2ecallarity_2earityOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2earityOne_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2earityOne(V v_m_240, V v_d_241) {
top: ;
  V v_body_242 = heff_take_field(v_d_241, 2);
  V v_key_243 = heff_get_n(v_d_241, 0, 3);
  switch (heff_tag_of(v_body_242)) {
  case TAG_EVar: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 2);
    V v_t_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_246; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    return (g_std_2emap_2einsert_24s93785294x875597928(v_m_240, v_key_243, v_t_248));
  }
  case TAG_EApp: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_body_242, 0ULL, 4);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EInt: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFloat: {
    heff_take_na(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EBool: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ESet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EValues: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  default: return heff_nomatch(v_body_242);
  }
}
V g_heff_2ecompile_2ecallarity_2earityOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2earityOne(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(V v_d_240, V v_calls_241, V v_uses_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_calls_241)) {
  case TAG_Nothing: {
    return ((HeffT2){{v_d_240, v_p_243}});
  }
  case TAG_Just: {
    V v_m_244 = heff_field(v_calls_241, 0);
    switch (heff_tag_of(v_uses_242)) {
    case TAG_Nothing: {
      return ((HeffT2){{v_d_240, v_p_243}});
    }
    case TAG_Just: {
      V v_uses1_245 = heff_field(v_uses_242, 0);
      if (heff_intEq_c_lent(v_uses1_245, MK_INT(1LL), 2)) {
        if (heff_intLt_c_lent(MK_INT(0LL), v_m_244, 1)) {
          HeffT2 v_t_246 = (g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(heff_dup(v_m_244), v_p_243));
          {
            V v_field_247 = v_t_246.f[0];
            V v_field_248 = v_t_246.f[1];
            V v_x_249 = v_field_247;
            V v_n_2410 = v_field_248;
            V v_t_2411 = (g_heff_2ecompile_2ecallarity_2eextend(heff_dup(v_x_249), heff_take_field(v_d_240, 2)));
            V v_body_2412 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_249, v_t_2411});
            V v_f_2413 = ({ V rv_2 = v_body_2412; V rr_ = heff_rec_reuse_nf(v_d_240, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
            return ((HeffT2){{v_f_2413, v_n_2410}});
          }
        } else {
          return ((HeffT2){{v_d_240, v_p_243}});
        }
      } else {
        return ((HeffT2){{v_d_240, v_p_243}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_uses_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_calls_241)}});
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0(V self, V *args); static Clo g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0, 1, 0};
V g_heff_2ecompile_2ecallarity_2eexpandArgs_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eexpandArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandArgs_entry, 5, 0};

V g_heff_2ecompile_2ecallarity_2eexpandArgs(V v_go_240, V v_t_241, V v_h_242, V v_j_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    heff_drop(v_t_241);
    heff_drop(v_j_243);
    return ((V)&g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0_clo);
  }
  case TAG_Cons: {
    V v_a_246 = heff_field(v_x5_244, 0);
    V v_args_247 = heff_field(v_x5_244, 1);
    heff_take_n(v_x5_244, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_a_246}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArgs_lam1, 1, 6, (V[]){v_m_248, v_t_241, heff_dup(v_h_242), v_j_243, v_go_240, v_args_247});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandArgs_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecallarity_2eexpandArgs(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0(V self, V *args) {
  V v_n_245 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_245});
}
V g_heff_2ecompile_2ecallarity_2eexpandArgs_lam1(V self, V *args) {
  V v_n_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_h_242 = heff_env(self)[2];
  V v_j_243 = heff_env(self)[3];
  V v_go_240 = heff_env(self)[4];
  V v_args_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_m_2413 = (g_heff_2ecompile_2ecallarity_2eexpandArg(heff_dup(v_t_241), v_h_242, heff_dup(v_j_243), v_x_2411));
    V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2412}));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_MkPair: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_n_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      V v_m_2417 = ({ V a_0 = v_go_240; V a_1 = v_t_241; V a_2 = v_h_242; V a_3 = heff_intAdd(v_j_243, MK_INT(1LL)); V a_4 = v_args_247; V r_ = (g_heff_2ecompile_2ecallarity_2eexpandArgs(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_h_242); r_; });
      V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2416}));
      switch (heff_tag_of(v_x2_2418)) {
      case TAG_MkPair: {
        V v_x_2419 = heff_field(v_x2_2418, 0);
        V v_n_2420 = heff_field(v_x2_2418, 1);
        heff_take_n(v_x2_2418, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_x_2419}), v_n_2420});
      }
      default: return heff_nomatch(v_x2_2418);
      }
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam0(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam1(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam2(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam3(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam4(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam5(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam6(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam7(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam8(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam9(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam10(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam11(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam12(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam13(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam14(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam15(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam16(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam17(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam18(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam19(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam20(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam21(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam22(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eexpandApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandApp_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2eexpandApp(V v_go_240, V v_t_241, V v_f_242, V v_args_243) {
top: ;
  switch (heff_tag_of(v_f_242)) {
  case TAG_EVar: {
    heff_drop(v_t_241);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam0, 1, 3, (V[]){v_m_245, v_go_240, v_args_243});
  }
  case TAG_EGlobal: {
    V v_g_2414 = heff_field(v_f_242, 0);
    heff_take_n(v_f_242, 1ULL, 1);
    V v_m_2415 = (g_heff_2ecompile_2ecallarity_2eexpandArgs(v_go_240, v_t_241, v_g_2414, MK_INT(0LL), v_args_243));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam1, 1, 2, (V[]){v_m_2415, v_g_2414});
  }
  case TAG_ELam: {
    heff_drop(v_t_241);
    V v_m_2423 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam2, 1, 3, (V[]){v_m_2423, v_go_240, v_args_243});
  }
  case TAG_EApp: {
    heff_drop(v_t_241);
    V v_m_2434 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam3, 1, 3, (V[]){v_m_2434, v_go_240, v_args_243});
  }
  case TAG_ELet: {
    heff_drop(v_t_241);
    V v_m_2446 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam4, 1, 3, (V[]){v_m_2446, v_go_240, v_args_243});
  }
  case TAG_ERecord: {
    heff_drop(v_t_241);
    V v_m_2457 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam5, 1, 3, (V[]){v_m_2457, v_go_240, v_args_243});
  }
  case TAG_EProj: {
    heff_drop(v_t_241);
    V v_m_2470 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam6, 1, 3, (V[]){v_m_2470, v_go_240, v_args_243});
  }
  case TAG_ETag: {
    heff_drop(v_t_241);
    V v_m_2482 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam7, 1, 3, (V[]){v_m_2482, v_go_240, v_args_243});
  }
  case TAG_EMatch: {
    heff_drop(v_t_241);
    V v_m_2493 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam8, 1, 3, (V[]){v_m_2493, v_go_240, v_args_243});
  }
  case TAG_EPrim: {
    heff_drop(v_t_241);
    V v_m_24103 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam9, 1, 3, (V[]){v_m_24103, v_go_240, v_args_243});
  }
  case TAG_EPrimCall: {
    heff_drop(v_t_241);
    V v_m_24114 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam10, 1, 3, (V[]){v_m_24114, v_go_240, v_args_243});
  }
  case TAG_ECall: {
    heff_drop(v_t_241);
    V v_m_24125 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam11, 1, 3, (V[]){v_m_24125, v_go_240, v_args_243});
  }
  case TAG_EInt: {
    heff_drop(v_t_241);
    V v_m_24135 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam12, 1, 3, (V[]){v_m_24135, v_go_240, v_args_243});
  }
  case TAG_EFloat: {
    heff_drop(v_t_241);
    V v_m_24145 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam13, 1, 3, (V[]){v_m_24145, v_go_240, v_args_243});
  }
  case TAG_EStr: {
    heff_drop(v_t_241);
    V v_m_24155 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam14, 1, 3, (V[]){v_m_24155, v_go_240, v_args_243});
  }
  case TAG_EBytes: {
    heff_drop(v_t_241);
    V v_m_24165 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam15, 1, 3, (V[]){v_m_24165, v_go_240, v_args_243});
  }
  case TAG_EFixed: {
    heff_drop(v_t_241);
    V v_m_24176 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam16, 1, 3, (V[]){v_m_24176, v_go_240, v_args_243});
  }
  case TAG_EFloat32: {
    heff_drop(v_t_241);
    V v_m_24186 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam17, 1, 3, (V[]){v_m_24186, v_go_240, v_args_243});
  }
  case TAG_EAbandon: {
    heff_drop(v_t_241);
    V v_m_24195 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam18, 1, 3, (V[]){v_m_24195, v_go_240, v_args_243});
  }
  case TAG_EBool: {
    heff_drop(v_t_241);
    V v_m_24205 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam19, 1, 3, (V[]){v_m_24205, v_go_240, v_args_243});
  }
  case TAG_ESet: {
    heff_drop(v_t_241);
    V v_m_24217 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam20, 1, 3, (V[]){v_m_24217, v_go_240, v_args_243});
  }
  case TAG_EValues: {
    heff_drop(v_t_241);
    V v_m_24227 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam21, 1, 3, (V[]){v_m_24227, v_go_240, v_args_243});
  }
  case TAG_EFix: {
    heff_drop(v_t_241);
    V v_m_24238 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam22, 1, 3, (V[]){v_m_24238, v_go_240, v_args_243});
  }
  default: return heff_nomatch(v_f_242);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eexpandApp(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam1(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_g_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_t_2420 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2414}), v_x_2418});
    return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_t_2420, v_n_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam2(V self, V *args) {
  V v_n_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_n_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_n_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    V v_m_2428 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_2429 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_n_2427}));
    switch (heff_tag_of(v_x2_2429)) {
    case TAG_MkPair: {
      V v_x_2430 = heff_field(v_x2_2429, 0);
      V v_n_2431 = heff_field(v_x2_2429, 1);
      heff_take_n(v_x2_2429, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2426, v_x_2430}), v_n_2431});
    }
    default: return heff_nomatch(v_x2_2429);
    }
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam3(V self, V *args) {
  V v_n_2435 = args[0];
  V v_m_2434 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2436 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_n_2435}));
  switch (heff_tag_of(v_x2_2436)) {
  case TAG_MkPair: {
    V v_x_2437 = heff_field(v_x2_2436, 0);
    V v_n_2438 = heff_field(v_x2_2436, 1);
    V v_ru_24x2_2436_24MkPair = heff_take_reuse_n(v_x2_2436, 3ULL, 2);
    V v_m_2439 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_2440 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_n_2438}));
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_MkPair: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_n_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2437, v_x_2441}), v_n_2442});
    }
    default: return heff_nomatch(v_x2_2440);
    }
  }
  default: return heff_nomatch(v_x2_2436);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam4(V self, V *args) {
  V v_n_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2448 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_n_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_n_2450 = heff_field(v_x2_2448, 1);
    V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
    V v_m_2451 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_2452 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_n_2450}));
    switch (heff_tag_of(v_x2_2452)) {
    case TAG_MkPair: {
      V v_x_2453 = heff_field(v_x2_2452, 0);
      V v_n_2454 = heff_field(v_x2_2452, 1);
      heff_take_n(v_x2_2452, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2448_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2449, v_x_2453}), v_n_2454});
    }
    default: return heff_nomatch(v_x2_2452);
    }
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam5(V self, V *args) {
  V v_n_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_n_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_n_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    V v_m_2462 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_2463 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_n_2461}));
    switch (heff_tag_of(v_x2_2463)) {
    case TAG_MkPair: {
      V v_x_2464 = heff_field(v_x2_2463, 0);
      V v_n_2465 = heff_field(v_x2_2463, 1);
      heff_take_n(v_x2_2463, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2460, v_x_2464}), v_n_2465});
    }
    default: return heff_nomatch(v_x2_2463);
    }
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam6(V self, V *args) {
  V v_n_2471 = args[0];
  V v_m_2470 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2472 = heff_tr(heff_call(v_m_2470, 1, (V[]){v_n_2471}));
  switch (heff_tag_of(v_x2_2472)) {
  case TAG_MkPair: {
    V v_x_2473 = heff_field(v_x2_2472, 0);
    V v_n_2474 = heff_field(v_x2_2472, 1);
    V v_ru_24x2_2472_24MkPair = heff_take_reuse_n(v_x2_2472, 3ULL, 2);
    V v_m_2475 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_2476 = heff_tr(heff_call(v_m_2475, 1, (V[]){v_n_2474}));
    switch (heff_tag_of(v_x2_2476)) {
    case TAG_MkPair: {
      V v_x_2477 = heff_field(v_x2_2476, 0);
      V v_n_2478 = heff_field(v_x2_2476, 1);
      heff_take_n(v_x2_2476, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2473, v_x_2477}), v_n_2478});
    }
    default: return heff_nomatch(v_x2_2476);
    }
  }
  default: return heff_nomatch(v_x2_2472);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam7(V self, V *args) {
  V v_n_2483 = args[0];
  V v_m_2482 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2484 = heff_tr(heff_call(v_m_2482, 1, (V[]){v_n_2483}));
  switch (heff_tag_of(v_x2_2484)) {
  case TAG_MkPair: {
    V v_x_2485 = heff_field(v_x2_2484, 0);
    V v_n_2486 = heff_field(v_x2_2484, 1);
    V v_ru_24x2_2484_24MkPair = heff_take_reuse_n(v_x2_2484, 3ULL, 2);
    V v_m_2487 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_2488 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_n_2486}));
    switch (heff_tag_of(v_x2_2488)) {
    case TAG_MkPair: {
      V v_x_2489 = heff_field(v_x2_2488, 0);
      V v_n_2490 = heff_field(v_x2_2488, 1);
      heff_take_n(v_x2_2488, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2484_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2485, v_x_2489}), v_n_2490});
    }
    default: return heff_nomatch(v_x2_2488);
    }
  }
  default: return heff_nomatch(v_x2_2484);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam8(V self, V *args) {
  V v_n_2494 = args[0];
  V v_m_2493 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2495 = heff_tr(heff_call(v_m_2493, 1, (V[]){v_n_2494}));
  switch (heff_tag_of(v_x2_2495)) {
  case TAG_MkPair: {
    V v_x_2496 = heff_field(v_x2_2495, 0);
    V v_n_2497 = heff_field(v_x2_2495, 1);
    V v_ru_24x2_2495_24MkPair = heff_take_reuse_n(v_x2_2495, 3ULL, 2);
    V v_m_2498 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_2499 = heff_tr(heff_call(v_m_2498, 1, (V[]){v_n_2497}));
    switch (heff_tag_of(v_x2_2499)) {
    case TAG_MkPair: {
      V v_x_24100 = heff_field(v_x2_2499, 0);
      V v_n_24101 = heff_field(v_x2_2499, 1);
      heff_take_n(v_x2_2499, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2496, v_x_24100}), v_n_24101});
    }
    default: return heff_nomatch(v_x2_2499);
    }
  }
  default: return heff_nomatch(v_x2_2495);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam9(V self, V *args) {
  V v_n_24104 = args[0];
  V v_m_24103 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24105 = heff_tr(heff_call(v_m_24103, 1, (V[]){v_n_24104}));
  switch (heff_tag_of(v_x2_24105)) {
  case TAG_MkPair: {
    V v_x_24106 = heff_field(v_x2_24105, 0);
    V v_n_24107 = heff_field(v_x2_24105, 1);
    V v_ru_24x2_24105_24MkPair = heff_take_reuse_n(v_x2_24105, 3ULL, 2);
    V v_m_24108 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_24109 = heff_tr(heff_call(v_m_24108, 1, (V[]){v_n_24107}));
    switch (heff_tag_of(v_x2_24109)) {
    case TAG_MkPair: {
      V v_x_24110 = heff_field(v_x2_24109, 0);
      V v_n_24111 = heff_field(v_x2_24109, 1);
      heff_take_n(v_x2_24109, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24105_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24106, v_x_24110}), v_n_24111});
    }
    default: return heff_nomatch(v_x2_24109);
    }
  }
  default: return heff_nomatch(v_x2_24105);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam10(V self, V *args) {
  V v_n_24115 = args[0];
  V v_m_24114 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24116 = heff_tr(heff_call(v_m_24114, 1, (V[]){v_n_24115}));
  switch (heff_tag_of(v_x2_24116)) {
  case TAG_MkPair: {
    V v_x_24117 = heff_field(v_x2_24116, 0);
    V v_n_24118 = heff_field(v_x2_24116, 1);
    V v_ru_24x2_24116_24MkPair = heff_take_reuse_n(v_x2_24116, 3ULL, 2);
    V v_m_24119 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_24120 = heff_tr(heff_call(v_m_24119, 1, (V[]){v_n_24118}));
    switch (heff_tag_of(v_x2_24120)) {
    case TAG_MkPair: {
      V v_x_24121 = heff_field(v_x2_24120, 0);
      V v_n_24122 = heff_field(v_x2_24120, 1);
      heff_take_n(v_x2_24120, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24116_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24117, v_x_24121}), v_n_24122});
    }
    default: return heff_nomatch(v_x2_24120);
    }
  }
  default: return heff_nomatch(v_x2_24116);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam11(V self, V *args) {
  V v_n_24126 = args[0];
  V v_m_24125 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24127 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_n_24126}));
  switch (heff_tag_of(v_x2_24127)) {
  case TAG_MkPair: {
    V v_x_24128 = heff_field(v_x2_24127, 0);
    V v_n_24129 = heff_field(v_x2_24127, 1);
    V v_ru_24x2_24127_24MkPair = heff_take_reuse_n(v_x2_24127, 3ULL, 2);
    V v_m_24130 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_24131 = heff_tr(heff_call(v_m_24130, 1, (V[]){v_n_24129}));
    switch (heff_tag_of(v_x2_24131)) {
    case TAG_MkPair: {
      V v_x_24132 = heff_field(v_x2_24131, 0);
      V v_n_24133 = heff_field(v_x2_24131, 1);
      heff_take_n(v_x2_24131, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24127_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24128, v_x_24132}), v_n_24133});
    }
    default: return heff_nomatch(v_x2_24131);
    }
  }
  default: return heff_nomatch(v_x2_24127);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam12(V self, V *args) {
  V v_n_24136 = args[0];
  V v_m_24135 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24137 = heff_tr(heff_call(v_m_24135, 1, (V[]){v_n_24136}));
  switch (heff_tag_of(v_x2_24137)) {
  case TAG_MkPair: {
    V v_x_24138 = heff_field(v_x2_24137, 0);
    V v_n_24139 = heff_field(v_x2_24137, 1);
    V v_ru_24x2_24137_24MkPair = heff_take_reuse_n(v_x2_24137, 3ULL, 2);
    V v_m_24140 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_24141 = heff_tr(heff_call(v_m_24140, 1, (V[]){v_n_24139}));
    switch (heff_tag_of(v_x2_24141)) {
    case TAG_MkPair: {
      V v_x_24142 = heff_field(v_x2_24141, 0);
      V v_n_24143 = heff_field(v_x2_24141, 1);
      heff_take_n(v_x2_24141, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24137_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24138, v_x_24142}), v_n_24143});
    }
    default: return heff_nomatch(v_x2_24141);
    }
  }
  default: return heff_nomatch(v_x2_24137);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam13(V self, V *args) {
  V v_n_24146 = args[0];
  V v_m_24145 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24147 = heff_tr(heff_call(v_m_24145, 1, (V[]){v_n_24146}));
  switch (heff_tag_of(v_x2_24147)) {
  case TAG_MkPair: {
    V v_x_24148 = heff_field(v_x2_24147, 0);
    V v_n_24149 = heff_field(v_x2_24147, 1);
    V v_ru_24x2_24147_24MkPair = heff_take_reuse_n(v_x2_24147, 3ULL, 2);
    V v_m_24150 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_24151 = heff_tr(heff_call(v_m_24150, 1, (V[]){v_n_24149}));
    switch (heff_tag_of(v_x2_24151)) {
    case TAG_MkPair: {
      V v_x_24152 = heff_field(v_x2_24151, 0);
      V v_n_24153 = heff_field(v_x2_24151, 1);
      heff_take_n(v_x2_24151, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24147_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24148, v_x_24152}), v_n_24153});
    }
    default: return heff_nomatch(v_x2_24151);
    }
  }
  default: return heff_nomatch(v_x2_24147);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam14(V self, V *args) {
  V v_n_24156 = args[0];
  V v_m_24155 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24157 = heff_tr(heff_call(v_m_24155, 1, (V[]){v_n_24156}));
  switch (heff_tag_of(v_x2_24157)) {
  case TAG_MkPair: {
    V v_x_24158 = heff_field(v_x2_24157, 0);
    V v_n_24159 = heff_field(v_x2_24157, 1);
    V v_ru_24x2_24157_24MkPair = heff_take_reuse_n(v_x2_24157, 3ULL, 2);
    V v_m_24160 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_24161 = heff_tr(heff_call(v_m_24160, 1, (V[]){v_n_24159}));
    switch (heff_tag_of(v_x2_24161)) {
    case TAG_MkPair: {
      V v_x_24162 = heff_field(v_x2_24161, 0);
      V v_n_24163 = heff_field(v_x2_24161, 1);
      heff_take_n(v_x2_24161, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24157_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24158, v_x_24162}), v_n_24163});
    }
    default: return heff_nomatch(v_x2_24161);
    }
  }
  default: return heff_nomatch(v_x2_24157);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam15(V self, V *args) {
  V v_n_24166 = args[0];
  V v_m_24165 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24167 = heff_tr(heff_call(v_m_24165, 1, (V[]){v_n_24166}));
  switch (heff_tag_of(v_x2_24167)) {
  case TAG_MkPair: {
    V v_x_24168 = heff_field(v_x2_24167, 0);
    V v_n_24169 = heff_field(v_x2_24167, 1);
    V v_ru_24x2_24167_24MkPair = heff_take_reuse_n(v_x2_24167, 3ULL, 2);
    V v_m_24170 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_24171 = heff_tr(heff_call(v_m_24170, 1, (V[]){v_n_24169}));
    switch (heff_tag_of(v_x2_24171)) {
    case TAG_MkPair: {
      V v_x_24172 = heff_field(v_x2_24171, 0);
      V v_n_24173 = heff_field(v_x2_24171, 1);
      heff_take_n(v_x2_24171, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24167_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24168, v_x_24172}), v_n_24173});
    }
    default: return heff_nomatch(v_x2_24171);
    }
  }
  default: return heff_nomatch(v_x2_24167);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam16(V self, V *args) {
  V v_n_24177 = args[0];
  V v_m_24176 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24178 = heff_tr(heff_call(v_m_24176, 1, (V[]){v_n_24177}));
  switch (heff_tag_of(v_x2_24178)) {
  case TAG_MkPair: {
    V v_x_24179 = heff_field(v_x2_24178, 0);
    V v_n_24180 = heff_field(v_x2_24178, 1);
    V v_ru_24x2_24178_24MkPair = heff_take_reuse_n(v_x2_24178, 3ULL, 2);
    V v_m_24181 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_24182 = heff_tr(heff_call(v_m_24181, 1, (V[]){v_n_24180}));
    switch (heff_tag_of(v_x2_24182)) {
    case TAG_MkPair: {
      V v_x_24183 = heff_field(v_x2_24182, 0);
      V v_n_24184 = heff_field(v_x2_24182, 1);
      heff_take_n(v_x2_24182, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24178_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24179, v_x_24183}), v_n_24184});
    }
    default: return heff_nomatch(v_x2_24182);
    }
  }
  default: return heff_nomatch(v_x2_24178);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam17(V self, V *args) {
  V v_n_24187 = args[0];
  V v_m_24186 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24188 = heff_tr(heff_call(v_m_24186, 1, (V[]){v_n_24187}));
  switch (heff_tag_of(v_x2_24188)) {
  case TAG_MkPair: {
    V v_x_24189 = heff_field(v_x2_24188, 0);
    V v_n_24190 = heff_field(v_x2_24188, 1);
    V v_ru_24x2_24188_24MkPair = heff_take_reuse_n(v_x2_24188, 3ULL, 2);
    V v_m_24191 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_24192 = heff_tr(heff_call(v_m_24191, 1, (V[]){v_n_24190}));
    switch (heff_tag_of(v_x2_24192)) {
    case TAG_MkPair: {
      V v_x_24193 = heff_field(v_x2_24192, 0);
      V v_n_24194 = heff_field(v_x2_24192, 1);
      heff_take_n(v_x2_24192, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24188_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24189, v_x_24193}), v_n_24194});
    }
    default: return heff_nomatch(v_x2_24192);
    }
  }
  default: return heff_nomatch(v_x2_24188);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam18(V self, V *args) {
  V v_n_24196 = args[0];
  V v_m_24195 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24197 = heff_tr(heff_call(v_m_24195, 1, (V[]){v_n_24196}));
  switch (heff_tag_of(v_x2_24197)) {
  case TAG_MkPair: {
    V v_x_24198 = heff_field(v_x2_24197, 0);
    V v_n_24199 = heff_field(v_x2_24197, 1);
    V v_ru_24x2_24197_24MkPair = heff_take_reuse_n(v_x2_24197, 3ULL, 2);
    V v_m_24200 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_24201 = heff_tr(heff_call(v_m_24200, 1, (V[]){v_n_24199}));
    switch (heff_tag_of(v_x2_24201)) {
    case TAG_MkPair: {
      V v_x_24202 = heff_field(v_x2_24201, 0);
      V v_n_24203 = heff_field(v_x2_24201, 1);
      heff_take_n(v_x2_24201, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24197_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24198, v_x_24202}), v_n_24203});
    }
    default: return heff_nomatch(v_x2_24201);
    }
  }
  default: return heff_nomatch(v_x2_24197);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam19(V self, V *args) {
  V v_n_24206 = args[0];
  V v_m_24205 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24207 = heff_tr(heff_call(v_m_24205, 1, (V[]){v_n_24206}));
  switch (heff_tag_of(v_x2_24207)) {
  case TAG_MkPair: {
    V v_x_24208 = heff_field(v_x2_24207, 0);
    V v_n_24209 = heff_field(v_x2_24207, 1);
    V v_ru_24x2_24207_24MkPair = heff_take_reuse_n(v_x2_24207, 3ULL, 2);
    V v_m_24210 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_24211 = heff_tr(heff_call(v_m_24210, 1, (V[]){v_n_24209}));
    switch (heff_tag_of(v_x2_24211)) {
    case TAG_MkPair: {
      V v_x_24212 = heff_field(v_x2_24211, 0);
      V v_n_24213 = heff_field(v_x2_24211, 1);
      heff_take_n(v_x2_24211, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24207_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24208, v_x_24212}), v_n_24213});
    }
    default: return heff_nomatch(v_x2_24211);
    }
  }
  default: return heff_nomatch(v_x2_24207);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam20(V self, V *args) {
  V v_n_24218 = args[0];
  V v_m_24217 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24219 = heff_tr(heff_call(v_m_24217, 1, (V[]){v_n_24218}));
  switch (heff_tag_of(v_x2_24219)) {
  case TAG_MkPair: {
    V v_x_24220 = heff_field(v_x2_24219, 0);
    V v_n_24221 = heff_field(v_x2_24219, 1);
    V v_ru_24x2_24219_24MkPair = heff_take_reuse_n(v_x2_24219, 3ULL, 2);
    V v_m_24222 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_24223 = heff_tr(heff_call(v_m_24222, 1, (V[]){v_n_24221}));
    switch (heff_tag_of(v_x2_24223)) {
    case TAG_MkPair: {
      V v_x_24224 = heff_field(v_x2_24223, 0);
      V v_n_24225 = heff_field(v_x2_24223, 1);
      heff_take_n(v_x2_24223, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24219_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24220, v_x_24224}), v_n_24225});
    }
    default: return heff_nomatch(v_x2_24223);
    }
  }
  default: return heff_nomatch(v_x2_24219);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam21(V self, V *args) {
  V v_n_24228 = args[0];
  V v_m_24227 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24229 = heff_tr(heff_call(v_m_24227, 1, (V[]){v_n_24228}));
  switch (heff_tag_of(v_x2_24229)) {
  case TAG_MkPair: {
    V v_x_24230 = heff_field(v_x2_24229, 0);
    V v_n_24231 = heff_field(v_x2_24229, 1);
    V v_ru_24x2_24229_24MkPair = heff_take_reuse_n(v_x2_24229, 3ULL, 2);
    V v_m_24232 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_24233 = heff_tr(heff_call(v_m_24232, 1, (V[]){v_n_24231}));
    switch (heff_tag_of(v_x2_24233)) {
    case TAG_MkPair: {
      V v_x_24234 = heff_field(v_x2_24233, 0);
      V v_n_24235 = heff_field(v_x2_24233, 1);
      heff_take_n(v_x2_24233, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24229_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24230, v_x_24234}), v_n_24235});
    }
    default: return heff_nomatch(v_x2_24233);
    }
  }
  default: return heff_nomatch(v_x2_24229);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam22(V self, V *args) {
  V v_n_24239 = args[0];
  V v_m_24238 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_args_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24240 = heff_tr(heff_call(v_m_24238, 1, (V[]){v_n_24239}));
  switch (heff_tag_of(v_x2_24240)) {
  case TAG_MkPair: {
    V v_x_24241 = heff_field(v_x2_24240, 0);
    V v_n_24242 = heff_field(v_x2_24240, 1);
    V v_ru_24x2_24240_24MkPair = heff_take_reuse_n(v_x2_24240, 3ULL, 2);
    V v_m_24243 = (g_prelude_2etraverse_24s740446701x774604387(v_go_240, v_args_243));
    V v_x2_24244 = heff_tr(heff_call(v_m_24243, 1, (V[]){v_n_24242}));
    switch (heff_tag_of(v_x2_24244)) {
    case TAG_MkPair: {
      V v_x_24245 = heff_field(v_x2_24244, 0);
      V v_n_24246 = heff_field(v_x2_24244, 1);
      heff_take_n(v_x2_24244, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24240_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24241, v_x_24245}), v_n_24246});
    }
    default: return heff_nomatch(v_x2_24244);
    }
  }
  default: return heff_nomatch(v_x2_24240);
  }
}
Clo g_heff_2ecompile_2ecallarity_2enotedThen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2enotedThen_entry, 5, 0};

V g_heff_2ecompile_2ecallarity_2enotedThen(V v_ar_240, V v_acc_241, V v_d_242, V v_n_243, V v_notes_244) {
top: ;
  V v_known_245 = heff_take_field(v_acc_241, 0);
  V v_defs_246 = heff_get_n(v_acc_241, 1, 3);
  V v_t_247 = heff_dup(heff_rfield(v_notes_244, 2));
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop_rec(v_notes_244, 3);
    heff_drop(v_t_247);
    V v_m_248 = (g_heff_2ecompile_2ecallarity_2eexpandGo(heff_dup(heff_rfield(v_known_245, 0)), heff_take_field(v_d_242, 2)));
    V v_x2_249 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_243}));
    switch (heff_tag_of(v_x2_249)) {
    case TAG_MkPair: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      V v_n_2411 = heff_field(v_x2_249, 1);
      heff_take_n(v_x2_249, 3ULL, 2);
      V v_d_2412 = ({ V rv_2 = v_x_2410; V rr_ = heff_rec_reuse_nf(v_d_242, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2413 = (g_heff_2ecompile_2ecallarity_2edefNotes(heff_dup(heff_rfield(v_known_245, 0)), v_ar_240, heff_dup(heff_rfield(v_known_245, 1)), heff_dup(v_d_2412)));
      V v_k_2414 = (g_heff_2ecompile_2ecallarity_2eknownAdd(v_known_245, heff_dup(v_d_2412), v_t_2413));
      return heff_rec_n(3, shape_known__defs__supply, (V[]){v_k_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_d_2412, v_defs_246}), v_n_2411});
    }
    default: return heff_nomatch(v_x2_249);
    }
  } else {
    heff_drop(v_ar_240);
    heff_drop(v_t_247);
    V v_k_2415 = (g_heff_2ecompile_2ecallarity_2eknownAdd(v_known_245, heff_dup(v_d_242), v_notes_244));
    return heff_rec_n(3, shape_known__defs__supply, (V[]){v_k_2415, heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, v_defs_246}), v_n_243});
  }
}
V g_heff_2ecompile_2ecallarity_2enotedThen_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2enotedThen(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2ecallarity_2esameInts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2esameInts_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2esameInts(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      if (heff_intEq_c_lent(v_x_244, v_y_246, 0)) {
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2esameInts_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecallarity_2esameInts(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2ecallarity_2esameAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2esameAll_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2esameAll(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      V v_t_248 = (g_heff_2ecompile_2ecallarity_2esameInts(v_x_244, v_y_246));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_248);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2esameAll_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecallarity_2esameAll(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2ecallarity_2esameTables_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2esameTables_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2esameTables(V v_a_240, V v_b_241) {
top: ;
  V v_t_242 = (g_std_2emap_2esize(heff_rfield(v_a_240, 0)));
  V v_t_243 = (g_std_2emap_2esize(heff_rfield(v_b_241, 0)));
  if (heff_intEq_c(v_t_242, v_t_243)) {
    V v_t_244 = ({ V b_0 = heff_get_n(v_a_240, 0, 1); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_245 = (g_list_2emap_24s366344330x1145113647(v_t_244));
    V v_t_246 = ({ V b_0 = heff_get_n(v_b_241, 0, 1); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_247 = (g_list_2emap_24s366344330x1145113647(v_t_246));
    return ({ V a_0 = v_t_245; V a_1 = v_t_247; V r_ = (g_heff_2ecompile_2ecallarity_2esameAll(a_0, a_1)); heff_drop(v_t_245); heff_drop(v_t_247); r_; });
  } else {
    heff_drop_rec(v_a_240, 1);
    heff_drop_rec(v_b_241, 1);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2ecallarity_2esameTables_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2esameTables(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecallarity_2eafterRound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eafterRound_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2eafterRound(V v_more_240, V v_before_241, V v_n_242, V v_acc_243) {
top: ;
  V v_supply_244 = heff_take_field(v_acc_243, 2);
  V v_known_245 = heff_take_field(v_acc_243, 0);
  V v_defs_246 = heff_get_n(v_acc_243, 1, 3);
  if (heff_intEq_c_lent(v_supply_244, v_n_242, 0)) {
    V v_t_247 = (g_heff_2ecompile_2ecallarity_2esameTables(heff_get_n(v_before_241, 0, 2), heff_dup(heff_rfield(v_known_245, 0))));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_more_240);
      heff_drop(v_supply_244);
      heff_drop_rec(v_known_245, 2);
      heff_drop(v_t_247);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_246));
      return heff_rec_n(2, shape_defs__supply, (V[]){v_t_248, v_n_242});
    } else {
      heff_drop(v_n_242);
      heff_drop(v_t_247);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_246));
      return heff_tail(v_more_240, 3, (V[]){v_known_245, v_t_249, v_supply_244});
    }
  } else {
    heff_drop_rec(v_before_241, 2);
    heff_drop(v_n_242);
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_246));
    return heff_tail(v_more_240, 3, (V[]){v_known_245, v_t_2410, v_supply_244});
  }
}
V g_heff_2ecompile_2ecallarity_2eafterRound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eafterRound(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ecallarity_2erounds_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2erounds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2erounds_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2erounds(V v_left_240, V v_before_241, V v_defs_242, V v_n_243) {
top: ;
  if (heff_intLe_c_lent(v_left_240, MK_INT(0LL), 2)) {
    heff_drop(v_left_240);
    heff_drop_rec(v_before_241, 2);
    return heff_rec_n(2, shape_defs__supply, (V[]){v_defs_242, v_n_243});
  } else {
    V v_t_244 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2erounds_clo), 1, (V[]){heff_intSub(v_left_240, MK_INT(1LL))}));
    V v_ar_245 = (g_list_2efoldl_24s445268946x679229867(heff_dup(g_std_2emap_2eempty_get()), v_defs_242));
    V v_t_246 = heff_rec_n(2, shape_tables__globals, (V[]){heff_rec_n(1, shape_pa, (V[]){heff_dup(g_std_2emap_2eempty_get())}), heff_dup(g_std_2emap_2eempty_get())});
    V v_t_247 = heff_rec_n(3, shape_known__defs__supply, (V[]){v_t_246, NTAG(TAG_Nil), heff_dup(v_n_243)});
    V v_t_2418 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecallarity_2erounds_lam0, 2, 2, (V[]){heff_dup(v_before_241), v_ar_245}); V a_1 = v_t_247; V a_2 = v_defs_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_defs_242); r_; });
    HEFF_LAST return g_heff_2ecompile_2ecallarity_2eafterRound(v_t_244, v_before_241, v_n_243, v_t_2418);
  }
}
V g_heff_2ecompile_2ecallarity_2erounds_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2erounds(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ecallarity_2erounds_lam0(V self, V *args) {
  V v_acc_248 = args[0];
  V v_d_249 = args[1];
  V v_before_241 = heff_env(self)[0];
  V v_ar_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2410 = ({ V b_0 = heff_get_n(v_before_241, 1, 2); V a_1 = v_d_249; V a_2 = heff_dup(heff_rfield(v_acc_248, 2)); HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseDef_24cpr(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  {
    V v_field_2411 = v_t_2410.f[0];
    V v_field_2412 = v_t_2410.f[1];
    V v_d_2413 = v_field_2411;
    V v_n_2414 = v_field_2412;
    V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_acc_248, 0)), 0, 2);
    V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_acc_248, 0)), 1, 2);
    V v_t_2417 = (g_heff_2ecompile_2ecallarity_2edefNotes(v_t_2415, heff_dup(v_ar_245), v_t_2416, heff_dup(v_d_2413)));
    return (g_heff_2ecompile_2ecallarity_2enotedThen(v_ar_245, v_acc_248, v_d_2413, v_n_2414, v_t_2417));
  }
}