// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define LBL_ar 9880
#define LBL_body 9524841
#define LBL_calls 295783919
#define LBL_defs 9574869
#define LBL_dirty 296951788
#define LBL_globals 352931696
#define LBL_key 315609
#define LBL_known 303562589
#define LBL_many 9839398
#define LBL_name 9869138
#define LBL_pa 10328
#define LBL_params 951713969
#define LBL_supply 1056026650
#define LBL_tables 1065764240
#define LBL_takes 311482598
#define LBL_uses 10094739
#define LBL_vars 10107635
static uint32_t shape_calls__uses__takes[] = {LBL_calls, LBL_uses, LBL_takes};
static uint32_t shape_defs__supply[] = {LBL_defs, LBL_supply};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_key__params__many__ar[] = {LBL_key, LBL_params, LBL_many, LBL_ar};
static uint32_t shape_known__defs__supply[] = {LBL_known, LBL_defs, LBL_supply};
static uint32_t shape_pa[] = {LBL_pa};
static uint32_t shape_tables__globals[] = {LBL_tables, LBL_globals};
static uint32_t shape_vars__globals__dirty[] = {LBL_vars, LBL_globals, LBL_dirty};
V g_heff_2ecompile_2ecallarity_2eafterRound(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eafterRound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eafterRound_clo;
V g_heff_2ecompile_2ecallarity_2eappNote(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eappNote_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eappNote_clo;
V g_heff_2ecompile_2ecallarity_2eappPush(V, V, V);
V g_heff_2ecompile_2ecallarity_2eappPush_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eappPush_clo;
V g_heff_2ecompile_2ecallarity_2eargsNote(V, V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eargsNote_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eargsNote_clo;
V g_heff_2ecompile_2ecallarity_2earityOne(V, V);
V g_heff_2ecompile_2ecallarity_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2earityOne_clo;
V g_heff_2ecompile_2ecallarity_2edefNotes(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2edefNotes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2edefNotes_clo;
V g_heff_2ecompile_2ecallarity_2eexpandApp(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandApp_clo;
V g_heff_2ecompile_2ecallarity_2eexpandArg(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandArg_clo;
V g_heff_2ecompile_2ecallarity_2eexpandArgs(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandArgs_clo;
V g_heff_2ecompile_2ecallarity_2eexpandGo(V, V);
V g_heff_2ecompile_2ecallarity_2eexpandGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandGo_clo;
V g_heff_2ecompile_2ecallarity_2eextend(V, V);
V g_heff_2ecompile_2ecallarity_2eextend_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eextend_clo;
V g_heff_2ecompile_2ecallarity_2efreshMany(V, V);
V g_heff_2ecompile_2ecallarity_2efreshMany_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2efreshMany_clo;
HeffT2 g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(V, V);
V g_heff_2ecompile_2ecallarity_2ehanded(V, V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2ehanded_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2ehanded_clo;
V g_heff_2ecompile_2ecallarity_2eknownAdd(V, V, V);
V g_heff_2ecompile_2ecallarity_2eknownAdd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eknownAdd_clo;
V g_heff_2ecompile_2ecallarity_2enoteUse(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2enoteUse_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2enoteUse_clo;
V g_heff_2ecompile_2ecallarity_2enotedThen(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2enotedThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2enotedThen_clo;
V g_heff_2ecompile_2ecallarity_2enthOr(V, V, V);
V g_heff_2ecompile_2ecallarity_2enthOr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2enthOr_clo;
V g_heff_2ecompile_2ecallarity_2epushNonVars(V, V);
V g_heff_2ecompile_2ecallarity_2epushNonVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2epushNonVars_clo;
HeffT2 g_heff_2ecompile_2ecallarity_2eraiseDef_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2erounds(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2erounds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2erounds_clo;
V g_heff_2ecompile_2ecallarity_2esameAll(V, V);
V g_heff_2ecompile_2ecallarity_2esameAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2esameAll_clo;
V g_heff_2ecompile_2ecallarity_2esameInts(V, V);
V g_heff_2ecompile_2ecallarity_2esameInts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2esameInts_clo;
V g_heff_2ecompile_2ecallarity_2esameTables(V, V);
V g_heff_2ecompile_2ecallarity_2esameTables_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2esameTables_clo;
V g_heff_2ecompile_2ecallarity_2etraverseS(V, V);
V g_heff_2ecompile_2ecallarity_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2etraverseS_clo;
V g_heff_2ecompile_2ecallarity_2eusesW(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eusesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eusesW_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2063565291x1181877757(V, V, V);
V g_list_2efoldl_24s2063565291x1181877757_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2063565291x1181877757_clo;
V g_list_2efoldl_24s445268946x679229867(V, V);
V g_list_2efoldl_24s445268946x679229867_entry(V self, V *a);
extern Clo g_list_2efoldl_24s445268946x679229867_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
HeffT2 g_map_2elookup_24s1546226666x2146984184_24cpr(V, V);
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_heff_2ecompile_2ecallarity_2etraverseS_lam0(V self, V *args); static Clo g_heff_2ecompile_2ecallarity_2etraverseS_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2etraverseS_lam0, 1, 0};
V g_heff_2ecompile_2ecallarity_2etraverseS_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2etraverseS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2etraverseS_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2etraverseS(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2ecallarity_2etraverseS_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2etraverseS_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecallarity_2etraverseS_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2etraverseS(a[0], a[1]);
}
V g_heff_2ecompile_2ecallarity_2etraverseS_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
}
V g_heff_2ecompile_2ecallarity_2etraverseS_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
HEFF_LIT(g_heff_2ecompile_2ecallarity_2efreshMany_24cpr_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2ecallarity_2efreshMany_24cpr_str1, 1, "z");

HeffT2 g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(V v_k_240, V v_p_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_k_240), MK_INT(0LL))) {
    heff_drop(v_k_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  } else {
    V v_m_243 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2efreshMany_clo), 1, (V[]){heff_intSub(v_k_240, MK_INT(1LL))}));
    V v_x2_244 = heff_tr(heff_call(v_m_243, 1, (V[]){heff_intAdd(heff_dup(v_p_241), MK_INT(1LL))}));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_n_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2ecallarity_2efreshMany_24cpr_str0), heff_intShow(v_p_241));
      V v_f_248 = heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2ecallarity_2efreshMany_24cpr_str1), v_t_247), v_x_245});
      return ((HeffT2){{v_f_248, v_n_246}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_244)}});
    }
  }
}
Clo g_heff_2ecompile_2ecallarity_2enthOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2enthOr_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2enthOr(V v_d_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return v_d_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_d_240);
      heff_drop(v_i_241);
      return heff_dup(v_x_243);
    } else {
      V t_0 = v_d_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      V t_2 = v_xs_244;
      v_d_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecallarity_2enthOr_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecallarity_2enthOr(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecallarity_2enoteUse_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2enoteUse_entry, 5, 0};

V g_heff_2ecompile_2ecallarity_2enoteUse(V v_here_240, V v_g_241, V v_k_242, V v_x4_243, V v_n_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    V v_t_245 = heff_take_field(v_here_240, 2);
    V v_t_246;
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      v_t_246 = MK_INT(2LL);
    } else {
      heff_drop(v_t_245);
      v_t_246 = MK_INT(1LL);
    }
    HeffT2 v_t_247 = ({ V a_0 = heff_dup(v_g_241); V b_1 = heff_get_n(v_here_240, 3, 4); HeffT2 r_ = (g_map_2elookup_24s1546226666x2146984184_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2412;
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_x_2411 = v_field_249;
        v_t_2412 = v_x_2411;
      } else {
        heff_drop(v_field_249);
        v_t_2412 = MK_INT(0LL);
      }
    }
    V v_u_2413 = heff_rec_n(3, shape_calls__uses__takes, (V[]){v_k_242, v_t_246, v_t_2412});
    V v_t_2414 = (g_map_2einsert_24s1341440536x470972936(v_g_241, v_u_2413, heff_take_field(v_n_244, 1)));
    return ({ V rv_1 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_n_244, 5ULL, 3, shape_vars__globals__dirty, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Just: {
    V v_u_2415 = heff_field(v_x4_243, 0);
    V v_t_2418 = heff_bool((heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_u_2415, 2))) ? heff_intLe_c(heff_dup(heff_rfield(v_u_2415, 0)), heff_dup(heff_rfield(v_u_2415, 2))) : (heff_intLe_c(MK_INT(2LL), heff_dup(heff_rfield(v_u_2415, 1))) || heff_intEq_c(heff_dup(heff_rfield(v_u_2415, 0)), MK_INT(0LL)))));
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop_rec(v_here_240, 4);
      heff_drop(v_g_241);
      heff_drop(v_k_242);
      heff_drop(v_t_2418);
      return v_n_244;
    } else {
      heff_drop(v_t_2418);
      V v_t_2420;
      if (heff_intLt_c(heff_dup(v_k_242), heff_dup(heff_rfield(v_u_2415, 0)))) {
        v_t_2420 = v_k_242;
      } else {
        heff_drop(v_k_242);
        v_t_2420 = heff_dup(heff_rfield(v_u_2415, 0));
      }
      V v_t_2421 = heff_get_n(v_here_240, 2, 4);
      V v_t_2422;
      if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
        heff_drop(v_t_2421);
        v_t_2422 = MK_INT(2LL);
      } else {
        heff_drop(v_t_2421);
        v_t_2422 = MK_INT(1LL);
      }
      V v_t_2423 = heff_intAdd(heff_dup(heff_rfield(v_u_2415, 1)), v_t_2422);
      V v_t_2424 = heff_rec_n(3, shape_calls__uses__takes, (V[]){v_t_2420, v_t_2423, heff_dup(heff_rfield(v_u_2415, 2))});
      V v_t_2425 = (g_map_2einsert_24s1341440536x470972936(v_g_241, v_t_2424, heff_take_field(v_n_244, 1)));
      return ({ V rv_1 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_n_244, 5ULL, 3, shape_vars__globals__dirty, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecallarity_2enoteUse_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2ecallarity_2enoteUse(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2ecallarity_2eargsNote_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eargsNote_entry, 6, 0};

V g_heff_2ecompile_2ecallarity_2eargsNote(V v_t_240, V v_here_241, V v_h_242, V v_j_243, V v_x5_244, V v_n_245) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_here_241);
    heff_drop(v_h_242);
    heff_drop(v_j_243);
    return v_n_245;
  }
  case TAG_Cons: {
    V v_x51_246 = heff_field(v_x5_244, 0);
    V v_as_247 = heff_field(v_x5_244, 1);
    switch (heff_tag_of(v_x51_246)) {
    case TAG_EVar: {
      V v_x_248 = heff_field(v_x51_246, 0);
      V v_t_249 = (g_heff_2ecompile_2ecallarity_2ehanded(heff_dup(v_t_240), heff_dup(v_here_241), heff_dup(v_h_242), heff_dup(v_j_243), heff_dup(v_x_248), v_n_245));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_t_249;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EGlobal: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_ELam: {
      V v_ys_2411 = heff_field(v_x51_246, 0);
      HeffT2 v_t_2413 = (g_map_2elookup_24s1546226666x2146984184_24cpr(heff_dup(v_h_242), heff_rfield(v_t_240, 0)));
      V v_t_2421;
      {
        V v_field_2415 = v_t_2413.f[1];
        int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
        V v_x_2418;
        if ((v_tag_2414 == ((int64_t)0ULL))) {
          V v_ps_2417 = v_field_2415;
          v_x_2418 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_j_243); V a_2 = v_ps_2417; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_2417); r_; });
        } else {
          heff_drop(v_field_2415);
          v_x_2418 = MK_INT(0LL);
        }
        V v_y_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_2411));
        if (heff_intLt_c(v_y_2419, v_x_2418)) {
          v_t_2421 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_n_245, 3ULL, 3, shape_vars__globals__dirty, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        } else {
          v_t_2421 = v_n_245;
        }
      }
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_t_2421;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EApp: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_ELet: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_ERecord: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EProj: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_ETag: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EMatch: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EPrim: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EPrimCall: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_ECall: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EInt: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EFloat: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EStr: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EBytes: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EFixed: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EFloat32: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EAbandon: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EFix: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x51_246);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2ecallarity_2eargsNote_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2ecallarity_2eargsNote(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
Clo g_heff_2ecompile_2ecallarity_2eappNote_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eappNote_entry, 5, 0};

V g_heff_2ecompile_2ecallarity_2eappNote(V v_t_240, V v_here_241, V v_f_242, V v_as_243, V v_n_244) {
top: ;
  switch (heff_tag_of(v_f_242)) {
  case TAG_EVar: {
    V v_x_245 = heff_field(v_f_242, 0);
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    V v_k_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_243));
    HeffT2 v_t_247 = (g_map_2elookup_24s1546226666x2146984184_24cpr(heff_dup(v_x_245), heff_rfield(v_n_244, 0)));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_k0_2411 = v_field_249;
        if (heff_intLt_c(heff_dup(v_k_246), v_k0_2411)) {
          V v_t_2413 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_245), v_k_246, heff_take_field(v_n_244, 0)));
          return ({ V rv_0 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_n_244, 6ULL, 3, shape_vars__globals__dirty, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        } else {
          heff_drop(v_k_246);
          return v_n_244;
        }
      } else {
        heff_drop(v_k_246);
        heff_drop(v_field_249);
        return v_n_244;
      }
    }
  }
  case TAG_EGlobal: {
    V v_g_2414 = heff_field(v_f_242, 0);
    V v_k_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_243));
    V v_t_2416 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_2414), heff_rfield(v_n_244, 1)));
    V v_t_2417 = ({ V a_0 = heff_dup(v_here_241); V a_1 = heff_dup(v_g_2414); V a_2 = v_k_2415; V a_3 = v_t_2416; V a_4 = v_n_244; V r_ = (g_heff_2ecompile_2ecallarity_2enoteUse(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2416); r_; });
    return (g_heff_2ecompile_2ecallarity_2eargsNote(v_t_240, v_here_241, heff_dup(v_g_2414), MK_INT(0LL), v_as_243, v_t_2417));
  }
  case TAG_ELam: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EApp: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_ELet: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_ERecord: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EProj: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_ETag: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EMatch: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EPrim: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EPrimCall: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_ECall: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EInt: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EFloat: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EStr: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EBytes: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EFixed: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EFloat32: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EAbandon: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EFix: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  default: return heff_nomatch(v_f_242);
  }
}
V g_heff_2ecompile_2ecallarity_2eappNote_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2ecallarity_2eappNote(a[0], a[1], a2, a3, a[4]); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2ecallarity_2eappPush_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eappPush_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2eappPush(V v_f_240, V v_as_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_f_240)) {
  case TAG_EVar: {
    heff_take_n(v_f_240, 0ULL, 1);
    return (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
  }
  case TAG_EGlobal: {
    heff_take_n(v_f_240, 0ULL, 1);
    return (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_241, v_rest_242));
  }
  case TAG_ELam: {
    V v_t_247 = (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_247});
  }
  case TAG_EApp: {
    V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2410});
  }
  case TAG_ELet: {
    V v_t_2414 = (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2414});
  }
  case TAG_ERecord: {
    V v_t_2417 = (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2417});
  }
  case TAG_EProj: {
    V v_t_2422 = (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2422});
  }
  case TAG_ETag: {
    V v_t_2426 = (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2426});
  }
  case TAG_EMatch: {
    V v_t_2429 = (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2429});
  }
  case TAG_EPrim: {
    V v_t_2431 = (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2431});
  }
  case TAG_EPrimCall: {
    V v_t_2434 = (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2434});
  }
  case TAG_ECall: {
    V v_t_2437 = (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2437});
  }
  case TAG_EInt: {
    V v_t_2439 = (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2439});
  }
  case TAG_EFloat: {
    V v_t_2441 = (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2441});
  }
  case TAG_EStr: {
    V v_t_2443 = (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2443});
  }
  case TAG_EBytes: {
    V v_t_2445 = (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2445});
  }
  case TAG_EFixed: {
    V v_t_2448 = (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2448});
  }
  case TAG_EFloat32: {
    V v_t_2450 = (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2450});
  }
  case TAG_EAbandon: {
    V v_t_2451 = (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2451});
  }
  case TAG_EFix: {
    V v_t_2454 = (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, v_t_2454});
  }
  default: return heff_nomatch(v_f_240);
  }
}
V g_heff_2ecompile_2ecallarity_2eappPush_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eappPush(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2ecallarity_2eusesW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eusesW_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2eusesW(V v_t_240, V v_here_241, V v_x3_242, V v_n_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    heff_drop_rec(v_here_241, 4);
    return v_n_243;
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_EVar: {
      V v_x_246 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      HeffT2 v_t_247 = (g_map_2elookup_24s1546226666x2146984184_24cpr(heff_dup(v_x_246), heff_rfield(v_n_243, 0)));
      V v_t_2414;
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_k0_2411 = v_field_249;
          if (heff_intLt_c(MK_INT(0LL), v_k0_2411)) {
            V v_t_2413 = (g_map_2einsert_24s1341440536x470972936(v_x_246, MK_INT(0LL), heff_take_field(v_n_243, 0)));
            v_t_2414 = ({ V rv_0 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_n_243, 6ULL, 3, shape_vars__globals__dirty, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          } else {
            heff_drop(v_x_246);
            v_t_2414 = v_n_243;
          }
        } else {
          heff_drop(v_x_246);
          heff_drop(v_field_249);
          v_t_2414 = v_n_243;
        }
      }
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_t_2414;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EGlobal: {
      V v_g_2415 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2416 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_2415), heff_rfield(v_n_243, 1)));
      V v_t_2417 = ({ V a_0 = heff_dup(v_here_241); V a_1 = v_g_2415; V a_2 = MK_INT(0LL); V a_3 = v_t_2416; V a_4 = v_n_243; V r_ = (g_heff_2ecompile_2ecallarity_2enoteUse(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2416); r_; });
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_t_2417;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_ELam: {
      V v_b_2419 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 2ULL, 2);
      V v_t_2420 = heff_rec_n(4, shape_key__params__many__ar, (V[]){heff_dup(heff_rfield(v_here_241, 0)), heff_dup(heff_rfield(v_here_241, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_here_241, 3))});
      V v_t_2421 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_2419, NTAG(TAG_Nil)});
      V v_t_2422 = (g_heff_2ecompile_2ecallarity_2eusesW(heff_dup(v_t_240), v_t_2420, v_t_2421, v_n_243));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_t_2422;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2423 = heff_field(v_x31_244, 0);
      V v_as_2424 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2425 = (g_heff_2ecompile_2ecallarity_2eappPush(heff_dup(v_f_2423), heff_dup(v_as_2424), v_rest_245));
      V v_t_2426 = ({ V a_0 = heff_dup(v_t_240); V a_1 = heff_dup(v_here_241); V a_2 = v_f_2423; V a_3 = v_as_2424; V a_4 = v_n_243; V r_ = (g_heff_2ecompile_2ecallarity_2eappNote(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_f_2423); heff_drop(v_as_2424); r_; });
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2425;
      V t_3 = v_t_2426;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2428 = heff_field(v_x31_244, 1);
      V v_b_2429 = heff_field(v_x31_244, 2);
      heff_take_n(v_x31_244, 6ULL, 3);
      V v_t_2430 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2428, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2429, v_rest_245})});
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2430;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2431 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2433 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2431, v_rest_245));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2433;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2434 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 4);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2434, v_rest_245});
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2439 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 2ULL, 3);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2441 = (g_heff_2ecompile_2eir_2eappendI(v_as_2439, v_rest_245));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2441;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2442 = heff_field(v_x31_244, 0);
      V v_arms_2443 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      V v_t_2444 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2443, v_rest_245));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2442, v_t_2444});
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2447 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2448 = (g_heff_2ecompile_2eir_2eappendI(v_as_2447, v_rest_245));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2448;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_ECall: {
      V v_g_2449 = heff_field(v_x31_244, 0);
      V v_as_2450 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2451 = (g_heff_2ecompile_2ecallarity_2eappPush(heff_tag_n(TAG_EGlobal, 1, (V[]){heff_dup(v_g_2449)}), heff_dup(v_as_2450), v_rest_245));
      V v_t_2452 = ({ V a_0 = heff_dup(v_t_240); V a_1 = heff_dup(v_here_241); V b_2 = heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2449}); V a_3 = v_as_2450; V a_4 = v_n_243; V r_ = (g_heff_2ecompile_2ecallarity_2eappNote(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); heff_drop(v_as_2450); r_; });
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2451;
      V t_3 = v_t_2452;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecallarity_2eusesW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eusesW(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2ecallarity_2edefNotes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2edefNotes_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2edefNotes(V v_t_240, V v_ar_241, V v_gl_242, V v_d_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_d_243, 2));
  V v_t_2439;
  switch (heff_tag_of(v_t_244)) {
  case TAG_EVar: {
    heff_take_n(v_t_244, 0ULL, 1);
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_244, 0ULL, 1);
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 2);
    v_t_2439 = v_xs_247;
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_t_244, 0ULL, 2);
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_t_244, 0ULL, 3);
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_244, 0ULL, 2);
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_t_244, 0ULL, 4);
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_t_244, 0ULL, 3);
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_244, 0ULL, 2);
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_244, 0ULL, 1);
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_244, 0ULL, 2);
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_t_244, 0ULL, 2);
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_t_244, 0ULL, 1);
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFloat: {
    heff_take_na(v_t_244, 0ULL, 1);
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_t_244, 0ULL, 1);
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_244, 0ULL, 1);
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_244, 0ULL, 2);
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_244, 0ULL, 1);
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EAbandon: {
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_t_244, 0ULL, 2);
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_2440 = heff_rec_n(4, shape_key__params__many__ar, (V[]){heff_take_field(v_d_243, 0), v_t_2439, NTAG(TAG_False), v_ar_241});
  V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_d_243, 2)), NTAG(TAG_Nil)});
  V v_t_2442 = heff_get_n(v_d_243, 2, 3);
  V v_t_2477;
  switch (heff_tag_of(v_t_2442)) {
  case TAG_EVar: {
    heff_take_n(v_t_2442, 0ULL, 1);
    v_t_2477 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_2442, 0ULL, 1);
    v_t_2477 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ELam: {
    V v_xs_2445 = heff_field(v_t_2442, 0);
    heff_take_n(v_t_2442, 1ULL, 2);
    v_t_2477 = v_xs_2445;
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_t_2442, 0ULL, 2);
    v_t_2477 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_t_2442, 0ULL, 3);
    v_t_2477 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_2442, 0ULL, 2);
    v_t_2477 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_t_2442, 0ULL, 4);
    v_t_2477 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_t_2442, 0ULL, 3);
    v_t_2477 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_2442, 0ULL, 2);
    v_t_2477 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_2442, 0ULL, 1);
    v_t_2477 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_2442, 0ULL, 2);
    v_t_2477 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_t_2442, 0ULL, 2);
    v_t_2477 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_t_2442, 0ULL, 1);
    v_t_2477 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFloat: {
    heff_take_na(v_t_2442, 0ULL, 1);
    v_t_2477 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_t_2442, 0ULL, 1);
    v_t_2477 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_2442, 0ULL, 1);
    v_t_2477 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_2442, 0ULL, 2);
    v_t_2477 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_2442, 0ULL, 1);
    v_t_2477 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EAbandon: {
    v_t_2477 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_t_2442, 0ULL, 2);
    v_t_2477 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_t_2442);
  }
  V v_t_2478 = ({ V a_0 = MK_INT(1000000LL); V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_t_2477; V r_ = (g_list_2efoldl_24s2063565291x1181877757(a_0, a_1, a_2)); heff_drop(v_t_2477); r_; });
  V v_t_2479 = heff_rec_n(3, shape_vars__globals__dirty, (V[]){v_t_2478, v_gl_242, NTAG(TAG_False)});
  HEFF_LAST return g_heff_2ecompile_2ecallarity_2eusesW(v_t_240, v_t_2440, v_t_2441, v_t_2479);
}
V g_heff_2ecompile_2ecallarity_2edefNotes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2edefNotes(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2ecallarity_2earityOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2earityOne_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2earityOne(V v_m_240, V v_d_241) {
top: ;
  V v_t_242 = heff_take_field(v_d_241, 2);
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_245; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    return (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_d_241, 0, 3), v_t_247, v_m_240));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 4);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2ecallarity_2earityOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2earityOne(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(V v_d_240, V v_calls_241, V v_uses_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_calls_241)) {
  case TAG_Nothing: {
    return ((HeffT2){{v_d_240, v_p_243}});
  }
  case TAG_Just: {
    V v_m_244 = heff_field(v_calls_241, 0);
    switch (heff_tag_of(v_uses_242)) {
    case TAG_Nothing: {
      return ((HeffT2){{v_d_240, v_p_243}});
    }
    case TAG_Just: {
      V v_uses1_245 = heff_field(v_uses_242, 0);
      if (heff_intEq_c(heff_dup(v_uses1_245), MK_INT(1LL))) {
        if (heff_intLt_c(MK_INT(0LL), heff_dup(v_m_244))) {
          HeffT2 v_t_248 = (g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(heff_dup(v_m_244), v_p_243));
          {
            V v_field_249 = v_t_248.f[0];
            V v_field_2410 = v_t_248.f[1];
            V v_x_2411 = v_field_249;
            V v_n_2412 = v_field_2410;
            V v_t_2413 = (g_heff_2ecompile_2ecallarity_2eextend(heff_dup(v_x_2411), heff_take_field(v_d_240, 2)));
            V v_body_2414 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2411, v_t_2413});
            V v_f_2415 = ({ V rv_2 = v_body_2414; V rr_ = heff_rec_reuse_nf(v_d_240, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
            return ((HeffT2){{v_f_2415, v_n_2412}});
          }
        } else {
          return ((HeffT2){{v_d_240, v_p_243}});
        }
      } else {
        return ((HeffT2){{v_d_240, v_p_243}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_uses_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_calls_241)}});
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0(V self, V *args); static Clo g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0, 1, 0};
V g_heff_2ecompile_2ecallarity_2eexpandArgs_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eexpandArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandArgs_entry, 5, 0};

V g_heff_2ecompile_2ecallarity_2eexpandArgs(V v_go_240, V v_t_241, V v_h_242, V v_j_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    heff_drop(v_t_241);
    heff_drop(v_h_242);
    heff_drop(v_j_243);
    return ((V)&g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0_clo);
  }
  case TAG_Cons: {
    V v_a_246 = heff_field(v_x5_244, 0);
    V v_as_247 = heff_field(v_x5_244, 1);
    heff_take_n(v_x5_244, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_a_246}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArgs_lam1, 1, 6, (V[]){v_m_248, v_t_241, v_h_242, v_j_243, v_go_240, v_as_247});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eexpandArgs(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0(V self, V *args) {
  V v_n_245 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_245});
}
V g_heff_2ecompile_2ecallarity_2eexpandArgs_lam1(V self, V *args) {
  V v_n_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_h_242 = heff_env(self)[2];
  V v_j_243 = heff_env(self)[3];
  V v_go_240 = heff_env(self)[4];
  V v_as_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_m_2413 = (g_heff_2ecompile_2ecallarity_2eexpandArg(heff_dup(v_t_241), heff_dup(v_h_242), heff_dup(v_j_243), v_x_2411));
    V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2412}));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_MkPair: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_n_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      V v_m_2417 = (g_heff_2ecompile_2ecallarity_2eexpandArgs(v_go_240, v_t_241, v_h_242, heff_intAdd(v_j_243, MK_INT(1LL)), v_as_247));
      V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2416}));
      switch (heff_tag_of(v_x2_2418)) {
      case TAG_MkPair: {
        V v_x_2419 = heff_field(v_x2_2418, 0);
        V v_n_2420 = heff_field(v_x2_2418, 1);
        heff_take_n(v_x2_2418, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_x_2419}), v_n_2420});
      }
      default: return heff_nomatch(v_x2_2418);
      }
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam0(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam1(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam2(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam3(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam4(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam5(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam6(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam7(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam8(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam9(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam10(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam11(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam12(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam13(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam14(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam15(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam16(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam17(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam18(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam19(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eexpandApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandApp_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2eexpandApp(V v_go_240, V v_t_241, V v_f_242, V v_as_243) {
top: ;
  switch (heff_tag_of(v_f_242)) {
  case TAG_EVar: {
    heff_drop(v_t_241);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam0, 1, 3, (V[]){v_m_245, v_go_240, v_as_243});
  }
  case TAG_EGlobal: {
    V v_g_2414 = heff_field(v_f_242, 0);
    heff_take_n(v_f_242, 1ULL, 1);
    V v_m_2415 = (g_heff_2ecompile_2ecallarity_2eexpandArgs(v_go_240, v_t_241, heff_dup(v_g_2414), MK_INT(0LL), v_as_243));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam1, 1, 2, (V[]){v_m_2415, v_g_2414});
  }
  case TAG_ELam: {
    heff_drop(v_t_241);
    V v_m_2423 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam2, 1, 3, (V[]){v_m_2423, v_go_240, v_as_243});
  }
  case TAG_EApp: {
    heff_drop(v_t_241);
    V v_m_2434 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam3, 1, 3, (V[]){v_m_2434, v_go_240, v_as_243});
  }
  case TAG_ELet: {
    heff_drop(v_t_241);
    V v_m_2446 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam4, 1, 3, (V[]){v_m_2446, v_go_240, v_as_243});
  }
  case TAG_ERecord: {
    heff_drop(v_t_241);
    V v_m_2457 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam5, 1, 3, (V[]){v_m_2457, v_go_240, v_as_243});
  }
  case TAG_EProj: {
    heff_drop(v_t_241);
    V v_m_2470 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam6, 1, 3, (V[]){v_m_2470, v_go_240, v_as_243});
  }
  case TAG_ETag: {
    heff_drop(v_t_241);
    V v_m_2482 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam7, 1, 3, (V[]){v_m_2482, v_go_240, v_as_243});
  }
  case TAG_EMatch: {
    heff_drop(v_t_241);
    V v_m_2493 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam8, 1, 3, (V[]){v_m_2493, v_go_240, v_as_243});
  }
  case TAG_EPrim: {
    heff_drop(v_t_241);
    V v_m_24103 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam9, 1, 3, (V[]){v_m_24103, v_go_240, v_as_243});
  }
  case TAG_EPrimCall: {
    heff_drop(v_t_241);
    V v_m_24114 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam10, 1, 3, (V[]){v_m_24114, v_go_240, v_as_243});
  }
  case TAG_ECall: {
    heff_drop(v_t_241);
    V v_m_24125 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam11, 1, 3, (V[]){v_m_24125, v_go_240, v_as_243});
  }
  case TAG_EInt: {
    heff_drop(v_t_241);
    V v_m_24135 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam12, 1, 3, (V[]){v_m_24135, v_go_240, v_as_243});
  }
  case TAG_EFloat: {
    heff_drop(v_t_241);
    V v_m_24145 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam13, 1, 3, (V[]){v_m_24145, v_go_240, v_as_243});
  }
  case TAG_EStr: {
    heff_drop(v_t_241);
    V v_m_24155 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam14, 1, 3, (V[]){v_m_24155, v_go_240, v_as_243});
  }
  case TAG_EBytes: {
    heff_drop(v_t_241);
    V v_m_24165 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam15, 1, 3, (V[]){v_m_24165, v_go_240, v_as_243});
  }
  case TAG_EFixed: {
    heff_drop(v_t_241);
    V v_m_24176 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam16, 1, 3, (V[]){v_m_24176, v_go_240, v_as_243});
  }
  case TAG_EFloat32: {
    heff_drop(v_t_241);
    V v_m_24186 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam17, 1, 3, (V[]){v_m_24186, v_go_240, v_as_243});
  }
  case TAG_EAbandon: {
    heff_drop(v_t_241);
    V v_m_24195 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam18, 1, 3, (V[]){v_m_24195, v_go_240, v_as_243});
  }
  case TAG_EFix: {
    heff_drop(v_t_241);
    V v_m_24206 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam19, 1, 3, (V[]){v_m_24206, v_go_240, v_as_243});
  }
  default: return heff_nomatch(v_f_242);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eexpandApp(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam1(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_g_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_t_2420 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2414}), v_x_2418});
    return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_t_2420, v_n_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam2(V self, V *args) {
  V v_n_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_n_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_n_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    V v_m_2428 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_2429 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_n_2427}));
    switch (heff_tag_of(v_x2_2429)) {
    case TAG_MkPair: {
      V v_x_2430 = heff_field(v_x2_2429, 0);
      V v_n_2431 = heff_field(v_x2_2429, 1);
      heff_take_n(v_x2_2429, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2426, v_x_2430}), v_n_2431});
    }
    default: return heff_nomatch(v_x2_2429);
    }
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam3(V self, V *args) {
  V v_n_2435 = args[0];
  V v_m_2434 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2436 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_n_2435}));
  switch (heff_tag_of(v_x2_2436)) {
  case TAG_MkPair: {
    V v_x_2437 = heff_field(v_x2_2436, 0);
    V v_n_2438 = heff_field(v_x2_2436, 1);
    V v_ru_24x2_2436_24MkPair = heff_take_reuse_n(v_x2_2436, 3ULL, 2);
    V v_m_2439 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_2440 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_n_2438}));
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_MkPair: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_n_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2437, v_x_2441}), v_n_2442});
    }
    default: return heff_nomatch(v_x2_2440);
    }
  }
  default: return heff_nomatch(v_x2_2436);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam4(V self, V *args) {
  V v_n_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2448 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_n_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_n_2450 = heff_field(v_x2_2448, 1);
    V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
    V v_m_2451 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_2452 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_n_2450}));
    switch (heff_tag_of(v_x2_2452)) {
    case TAG_MkPair: {
      V v_x_2453 = heff_field(v_x2_2452, 0);
      V v_n_2454 = heff_field(v_x2_2452, 1);
      heff_take_n(v_x2_2452, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2448_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2449, v_x_2453}), v_n_2454});
    }
    default: return heff_nomatch(v_x2_2452);
    }
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam5(V self, V *args) {
  V v_n_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_n_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_n_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    V v_m_2462 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_2463 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_n_2461}));
    switch (heff_tag_of(v_x2_2463)) {
    case TAG_MkPair: {
      V v_x_2464 = heff_field(v_x2_2463, 0);
      V v_n_2465 = heff_field(v_x2_2463, 1);
      heff_take_n(v_x2_2463, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2460, v_x_2464}), v_n_2465});
    }
    default: return heff_nomatch(v_x2_2463);
    }
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam6(V self, V *args) {
  V v_n_2471 = args[0];
  V v_m_2470 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2472 = heff_tr(heff_call(v_m_2470, 1, (V[]){v_n_2471}));
  switch (heff_tag_of(v_x2_2472)) {
  case TAG_MkPair: {
    V v_x_2473 = heff_field(v_x2_2472, 0);
    V v_n_2474 = heff_field(v_x2_2472, 1);
    V v_ru_24x2_2472_24MkPair = heff_take_reuse_n(v_x2_2472, 3ULL, 2);
    V v_m_2475 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_2476 = heff_tr(heff_call(v_m_2475, 1, (V[]){v_n_2474}));
    switch (heff_tag_of(v_x2_2476)) {
    case TAG_MkPair: {
      V v_x_2477 = heff_field(v_x2_2476, 0);
      V v_n_2478 = heff_field(v_x2_2476, 1);
      heff_take_n(v_x2_2476, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2473, v_x_2477}), v_n_2478});
    }
    default: return heff_nomatch(v_x2_2476);
    }
  }
  default: return heff_nomatch(v_x2_2472);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam7(V self, V *args) {
  V v_n_2483 = args[0];
  V v_m_2482 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2484 = heff_tr(heff_call(v_m_2482, 1, (V[]){v_n_2483}));
  switch (heff_tag_of(v_x2_2484)) {
  case TAG_MkPair: {
    V v_x_2485 = heff_field(v_x2_2484, 0);
    V v_n_2486 = heff_field(v_x2_2484, 1);
    V v_ru_24x2_2484_24MkPair = heff_take_reuse_n(v_x2_2484, 3ULL, 2);
    V v_m_2487 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_2488 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_n_2486}));
    switch (heff_tag_of(v_x2_2488)) {
    case TAG_MkPair: {
      V v_x_2489 = heff_field(v_x2_2488, 0);
      V v_n_2490 = heff_field(v_x2_2488, 1);
      heff_take_n(v_x2_2488, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2484_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2485, v_x_2489}), v_n_2490});
    }
    default: return heff_nomatch(v_x2_2488);
    }
  }
  default: return heff_nomatch(v_x2_2484);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam8(V self, V *args) {
  V v_n_2494 = args[0];
  V v_m_2493 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2495 = heff_tr(heff_call(v_m_2493, 1, (V[]){v_n_2494}));
  switch (heff_tag_of(v_x2_2495)) {
  case TAG_MkPair: {
    V v_x_2496 = heff_field(v_x2_2495, 0);
    V v_n_2497 = heff_field(v_x2_2495, 1);
    V v_ru_24x2_2495_24MkPair = heff_take_reuse_n(v_x2_2495, 3ULL, 2);
    V v_m_2498 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_2499 = heff_tr(heff_call(v_m_2498, 1, (V[]){v_n_2497}));
    switch (heff_tag_of(v_x2_2499)) {
    case TAG_MkPair: {
      V v_x_24100 = heff_field(v_x2_2499, 0);
      V v_n_24101 = heff_field(v_x2_2499, 1);
      heff_take_n(v_x2_2499, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2496, v_x_24100}), v_n_24101});
    }
    default: return heff_nomatch(v_x2_2499);
    }
  }
  default: return heff_nomatch(v_x2_2495);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam9(V self, V *args) {
  V v_n_24104 = args[0];
  V v_m_24103 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24105 = heff_tr(heff_call(v_m_24103, 1, (V[]){v_n_24104}));
  switch (heff_tag_of(v_x2_24105)) {
  case TAG_MkPair: {
    V v_x_24106 = heff_field(v_x2_24105, 0);
    V v_n_24107 = heff_field(v_x2_24105, 1);
    V v_ru_24x2_24105_24MkPair = heff_take_reuse_n(v_x2_24105, 3ULL, 2);
    V v_m_24108 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24109 = heff_tr(heff_call(v_m_24108, 1, (V[]){v_n_24107}));
    switch (heff_tag_of(v_x2_24109)) {
    case TAG_MkPair: {
      V v_x_24110 = heff_field(v_x2_24109, 0);
      V v_n_24111 = heff_field(v_x2_24109, 1);
      heff_take_n(v_x2_24109, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24105_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24106, v_x_24110}), v_n_24111});
    }
    default: return heff_nomatch(v_x2_24109);
    }
  }
  default: return heff_nomatch(v_x2_24105);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam10(V self, V *args) {
  V v_n_24115 = args[0];
  V v_m_24114 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24116 = heff_tr(heff_call(v_m_24114, 1, (V[]){v_n_24115}));
  switch (heff_tag_of(v_x2_24116)) {
  case TAG_MkPair: {
    V v_x_24117 = heff_field(v_x2_24116, 0);
    V v_n_24118 = heff_field(v_x2_24116, 1);
    V v_ru_24x2_24116_24MkPair = heff_take_reuse_n(v_x2_24116, 3ULL, 2);
    V v_m_24119 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24120 = heff_tr(heff_call(v_m_24119, 1, (V[]){v_n_24118}));
    switch (heff_tag_of(v_x2_24120)) {
    case TAG_MkPair: {
      V v_x_24121 = heff_field(v_x2_24120, 0);
      V v_n_24122 = heff_field(v_x2_24120, 1);
      heff_take_n(v_x2_24120, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24116_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24117, v_x_24121}), v_n_24122});
    }
    default: return heff_nomatch(v_x2_24120);
    }
  }
  default: return heff_nomatch(v_x2_24116);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam11(V self, V *args) {
  V v_n_24126 = args[0];
  V v_m_24125 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24127 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_n_24126}));
  switch (heff_tag_of(v_x2_24127)) {
  case TAG_MkPair: {
    V v_x_24128 = heff_field(v_x2_24127, 0);
    V v_n_24129 = heff_field(v_x2_24127, 1);
    V v_ru_24x2_24127_24MkPair = heff_take_reuse_n(v_x2_24127, 3ULL, 2);
    V v_m_24130 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24131 = heff_tr(heff_call(v_m_24130, 1, (V[]){v_n_24129}));
    switch (heff_tag_of(v_x2_24131)) {
    case TAG_MkPair: {
      V v_x_24132 = heff_field(v_x2_24131, 0);
      V v_n_24133 = heff_field(v_x2_24131, 1);
      heff_take_n(v_x2_24131, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24127_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24128, v_x_24132}), v_n_24133});
    }
    default: return heff_nomatch(v_x2_24131);
    }
  }
  default: return heff_nomatch(v_x2_24127);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam12(V self, V *args) {
  V v_n_24136 = args[0];
  V v_m_24135 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24137 = heff_tr(heff_call(v_m_24135, 1, (V[]){v_n_24136}));
  switch (heff_tag_of(v_x2_24137)) {
  case TAG_MkPair: {
    V v_x_24138 = heff_field(v_x2_24137, 0);
    V v_n_24139 = heff_field(v_x2_24137, 1);
    V v_ru_24x2_24137_24MkPair = heff_take_reuse_n(v_x2_24137, 3ULL, 2);
    V v_m_24140 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24141 = heff_tr(heff_call(v_m_24140, 1, (V[]){v_n_24139}));
    switch (heff_tag_of(v_x2_24141)) {
    case TAG_MkPair: {
      V v_x_24142 = heff_field(v_x2_24141, 0);
      V v_n_24143 = heff_field(v_x2_24141, 1);
      heff_take_n(v_x2_24141, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24137_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24138, v_x_24142}), v_n_24143});
    }
    default: return heff_nomatch(v_x2_24141);
    }
  }
  default: return heff_nomatch(v_x2_24137);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam13(V self, V *args) {
  V v_n_24146 = args[0];
  V v_m_24145 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24147 = heff_tr(heff_call(v_m_24145, 1, (V[]){v_n_24146}));
  switch (heff_tag_of(v_x2_24147)) {
  case TAG_MkPair: {
    V v_x_24148 = heff_field(v_x2_24147, 0);
    V v_n_24149 = heff_field(v_x2_24147, 1);
    V v_ru_24x2_24147_24MkPair = heff_take_reuse_n(v_x2_24147, 3ULL, 2);
    V v_m_24150 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24151 = heff_tr(heff_call(v_m_24150, 1, (V[]){v_n_24149}));
    switch (heff_tag_of(v_x2_24151)) {
    case TAG_MkPair: {
      V v_x_24152 = heff_field(v_x2_24151, 0);
      V v_n_24153 = heff_field(v_x2_24151, 1);
      heff_take_n(v_x2_24151, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24147_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24148, v_x_24152}), v_n_24153});
    }
    default: return heff_nomatch(v_x2_24151);
    }
  }
  default: return heff_nomatch(v_x2_24147);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam14(V self, V *args) {
  V v_n_24156 = args[0];
  V v_m_24155 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24157 = heff_tr(heff_call(v_m_24155, 1, (V[]){v_n_24156}));
  switch (heff_tag_of(v_x2_24157)) {
  case TAG_MkPair: {
    V v_x_24158 = heff_field(v_x2_24157, 0);
    V v_n_24159 = heff_field(v_x2_24157, 1);
    V v_ru_24x2_24157_24MkPair = heff_take_reuse_n(v_x2_24157, 3ULL, 2);
    V v_m_24160 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24161 = heff_tr(heff_call(v_m_24160, 1, (V[]){v_n_24159}));
    switch (heff_tag_of(v_x2_24161)) {
    case TAG_MkPair: {
      V v_x_24162 = heff_field(v_x2_24161, 0);
      V v_n_24163 = heff_field(v_x2_24161, 1);
      heff_take_n(v_x2_24161, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24157_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24158, v_x_24162}), v_n_24163});
    }
    default: return heff_nomatch(v_x2_24161);
    }
  }
  default: return heff_nomatch(v_x2_24157);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam15(V self, V *args) {
  V v_n_24166 = args[0];
  V v_m_24165 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24167 = heff_tr(heff_call(v_m_24165, 1, (V[]){v_n_24166}));
  switch (heff_tag_of(v_x2_24167)) {
  case TAG_MkPair: {
    V v_x_24168 = heff_field(v_x2_24167, 0);
    V v_n_24169 = heff_field(v_x2_24167, 1);
    V v_ru_24x2_24167_24MkPair = heff_take_reuse_n(v_x2_24167, 3ULL, 2);
    V v_m_24170 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24171 = heff_tr(heff_call(v_m_24170, 1, (V[]){v_n_24169}));
    switch (heff_tag_of(v_x2_24171)) {
    case TAG_MkPair: {
      V v_x_24172 = heff_field(v_x2_24171, 0);
      V v_n_24173 = heff_field(v_x2_24171, 1);
      heff_take_n(v_x2_24171, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24167_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24168, v_x_24172}), v_n_24173});
    }
    default: return heff_nomatch(v_x2_24171);
    }
  }
  default: return heff_nomatch(v_x2_24167);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam16(V self, V *args) {
  V v_n_24177 = args[0];
  V v_m_24176 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24178 = heff_tr(heff_call(v_m_24176, 1, (V[]){v_n_24177}));
  switch (heff_tag_of(v_x2_24178)) {
  case TAG_MkPair: {
    V v_x_24179 = heff_field(v_x2_24178, 0);
    V v_n_24180 = heff_field(v_x2_24178, 1);
    V v_ru_24x2_24178_24MkPair = heff_take_reuse_n(v_x2_24178, 3ULL, 2);
    V v_m_24181 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24182 = heff_tr(heff_call(v_m_24181, 1, (V[]){v_n_24180}));
    switch (heff_tag_of(v_x2_24182)) {
    case TAG_MkPair: {
      V v_x_24183 = heff_field(v_x2_24182, 0);
      V v_n_24184 = heff_field(v_x2_24182, 1);
      heff_take_n(v_x2_24182, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24178_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24179, v_x_24183}), v_n_24184});
    }
    default: return heff_nomatch(v_x2_24182);
    }
  }
  default: return heff_nomatch(v_x2_24178);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam17(V self, V *args) {
  V v_n_24187 = args[0];
  V v_m_24186 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24188 = heff_tr(heff_call(v_m_24186, 1, (V[]){v_n_24187}));
  switch (heff_tag_of(v_x2_24188)) {
  case TAG_MkPair: {
    V v_x_24189 = heff_field(v_x2_24188, 0);
    V v_n_24190 = heff_field(v_x2_24188, 1);
    V v_ru_24x2_24188_24MkPair = heff_take_reuse_n(v_x2_24188, 3ULL, 2);
    V v_m_24191 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24192 = heff_tr(heff_call(v_m_24191, 1, (V[]){v_n_24190}));
    switch (heff_tag_of(v_x2_24192)) {
    case TAG_MkPair: {
      V v_x_24193 = heff_field(v_x2_24192, 0);
      V v_n_24194 = heff_field(v_x2_24192, 1);
      heff_take_n(v_x2_24192, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24188_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24189, v_x_24193}), v_n_24194});
    }
    default: return heff_nomatch(v_x2_24192);
    }
  }
  default: return heff_nomatch(v_x2_24188);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam18(V self, V *args) {
  V v_n_24196 = args[0];
  V v_m_24195 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24197 = heff_tr(heff_call(v_m_24195, 1, (V[]){v_n_24196}));
  switch (heff_tag_of(v_x2_24197)) {
  case TAG_MkPair: {
    V v_x_24198 = heff_field(v_x2_24197, 0);
    V v_n_24199 = heff_field(v_x2_24197, 1);
    V v_ru_24x2_24197_24MkPair = heff_take_reuse_n(v_x2_24197, 3ULL, 2);
    V v_m_24200 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24201 = heff_tr(heff_call(v_m_24200, 1, (V[]){v_n_24199}));
    switch (heff_tag_of(v_x2_24201)) {
    case TAG_MkPair: {
      V v_x_24202 = heff_field(v_x2_24201, 0);
      V v_n_24203 = heff_field(v_x2_24201, 1);
      heff_take_n(v_x2_24201, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24197_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24198, v_x_24202}), v_n_24203});
    }
    default: return heff_nomatch(v_x2_24201);
    }
  }
  default: return heff_nomatch(v_x2_24197);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam19(V self, V *args) {
  V v_n_24207 = args[0];
  V v_m_24206 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24208 = heff_tr(heff_call(v_m_24206, 1, (V[]){v_n_24207}));
  switch (heff_tag_of(v_x2_24208)) {
  case TAG_MkPair: {
    V v_x_24209 = heff_field(v_x2_24208, 0);
    V v_n_24210 = heff_field(v_x2_24208, 1);
    V v_ru_24x2_24208_24MkPair = heff_take_reuse_n(v_x2_24208, 3ULL, 2);
    V v_m_24211 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24212 = heff_tr(heff_call(v_m_24211, 1, (V[]){v_n_24210}));
    switch (heff_tag_of(v_x2_24212)) {
    case TAG_MkPair: {
      V v_x_24213 = heff_field(v_x2_24212, 0);
      V v_n_24214 = heff_field(v_x2_24212, 1);
      heff_take_n(v_x2_24212, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24208_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24209, v_x_24213}), v_n_24214});
    }
    default: return heff_nomatch(v_x2_24212);
    }
  }
  default: return heff_nomatch(v_x2_24208);
  }
}
Clo g_heff_2ecompile_2ecallarity_2enotedThen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2enotedThen_entry, 5, 0};

V g_heff_2ecompile_2ecallarity_2enotedThen(V v_ar_240, V v_acc_241, V v_d_242, V v_n_243, V v_notes_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_notes_244, 2));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop_rec(v_notes_244, 3);
    heff_drop(v_t_245);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_acc_241, 0)), 0, 2);
    V v_m_247 = (g_heff_2ecompile_2ecallarity_2eexpandGo(v_t_246, heff_take_field(v_d_242, 2)));
    V v_x2_248 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_243}));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_n_2410 = heff_field(v_x2_248, 1);
      V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
      V v_d_2411 = ({ V rv_2 = v_x_249; V rr_ = heff_rec_reuse_nf(v_d_242, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_acc_241, 0)), 0, 2);
      V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_acc_241, 0)), 1, 2);
      V v_t_2414 = (g_heff_2ecompile_2ecallarity_2edefNotes(v_t_2412, v_ar_240, v_t_2413, heff_dup(v_d_2411)));
      V v_k_2415 = (g_heff_2ecompile_2ecallarity_2eknownAdd(heff_take_field(v_acc_241, 0), heff_dup(v_d_2411), v_t_2414));
      V v_t_2416 = heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_Cons, 2, (V[]){v_d_2411, heff_get_n(v_acc_241, 1, 3)});
      return heff_rec_n(3, shape_known__defs__supply, (V[]){v_k_2415, v_t_2416, v_n_2410});
    }
    default: return heff_nomatch(v_x2_248);
    }
  } else {
    heff_drop(v_ar_240);
    heff_drop(v_t_245);
    V v_k_2417 = (g_heff_2ecompile_2ecallarity_2eknownAdd(heff_take_field(v_acc_241, 0), heff_dup(v_d_242), v_notes_244));
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, heff_get_n(v_acc_241, 1, 3)});
    return heff_rec_n(3, shape_known__defs__supply, (V[]){v_k_2417, v_t_2418, v_n_243});
  }
}
V g_heff_2ecompile_2ecallarity_2enotedThen_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2enotedThen(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2ecallarity_2esameInts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2esameInts_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2esameInts(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      if (heff_intEq_c(heff_dup(v_x_244), heff_dup(v_y_246))) {
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2esameInts_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecallarity_2esameInts(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2ecallarity_2esameAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2esameAll_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2esameAll(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      V v_t_248 = (g_heff_2ecompile_2ecallarity_2esameInts(v_x_244, v_y_246));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_248);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2esameAll_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecallarity_2esameAll(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2ecallarity_2esameTables_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2esameTables_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2esameTables(V v_a_240, V v_b_241) {
top: ;
  V v_t_242 = (g_map_2esize(heff_rfield(v_a_240, 0)));
  V v_t_243 = (g_map_2esize(heff_rfield(v_b_241, 0)));
  if (heff_intEq_c(v_t_242, v_t_243)) {
    V v_t_245 = ({ V b_0 = heff_get_n(v_a_240, 0, 1); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_246 = (g_list_2emap_24s366344330x1145113647(v_t_245));
    V v_t_247 = ({ V b_0 = heff_get_n(v_b_241, 0, 1); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_248 = (g_list_2emap_24s366344330x1145113647(v_t_247));
    return ({ V a_0 = v_t_246; V a_1 = v_t_248; V r_ = (g_heff_2ecompile_2ecallarity_2esameAll(a_0, a_1)); heff_drop(v_t_246); heff_drop(v_t_248); r_; });
  } else {
    heff_drop_rec(v_a_240, 1);
    heff_drop_rec(v_b_241, 1);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2ecallarity_2esameTables_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2esameTables(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecallarity_2eafterRound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eafterRound_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2eafterRound(V v_more_240, V v_before_241, V v_n_242, V v_acc_243) {
top: ;
  if (heff_intEq_c(heff_dup(heff_rfield(v_acc_243, 2)), heff_dup(v_n_242))) {
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_acc_243, 0)), 0, 2);
    V v_t_246 = (g_heff_2ecompile_2ecallarity_2esameTables(heff_get_n(v_before_241, 0, 2), v_t_245));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_more_240);
      heff_drop(v_t_246);
      V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_acc_243, 1, 3)));
      return heff_rec_n(2, shape_defs__supply, (V[]){v_t_247, v_n_242});
    } else {
      heff_drop(v_n_242);
      heff_drop(v_t_246);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_243, 1)));
      return heff_tail(v_more_240, 3, (V[]){heff_dup(heff_rfield(v_acc_243, 0)), v_t_248, heff_get_n(v_acc_243, 2, 3)});
    }
  } else {
    heff_drop_rec(v_before_241, 2);
    heff_drop(v_n_242);
    V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_243, 1)));
    return heff_tail(v_more_240, 3, (V[]){heff_dup(heff_rfield(v_acc_243, 0)), v_t_249, heff_get_n(v_acc_243, 2, 3)});
  }
}
V g_heff_2ecompile_2ecallarity_2eafterRound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eafterRound(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ecallarity_2erounds_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2erounds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2erounds_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2erounds(V v_left_240, V v_before_241, V v_defs_242, V v_n_243) {
top: ;
  if (heff_intLe_c(heff_dup(v_left_240), MK_INT(0LL))) {
    heff_drop(v_left_240);
    heff_drop_rec(v_before_241, 2);
    return heff_rec_n(2, shape_defs__supply, (V[]){v_defs_242, v_n_243});
  } else {
    V v_t_245 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2erounds_clo), 1, (V[]){heff_intSub(v_left_240, MK_INT(1LL))}));
    V v_ar_246 = (g_list_2efoldl_24s445268946x679229867(heff_dup(g_map_2eempty_get()), v_defs_242));
    V v_t_247 = heff_rec_n(2, shape_tables__globals, (V[]){heff_rec_n(1, shape_pa, (V[]){heff_dup(g_map_2eempty_get())}), heff_dup(g_map_2eempty_get())});
    V v_t_248 = heff_rec_n(3, shape_known__defs__supply, (V[]){v_t_247, NTAG(TAG_Nil), heff_dup(v_n_243)});
    V v_t_2419 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecallarity_2erounds_lam0, 2, 2, (V[]){heff_dup(v_before_241), v_ar_246}); V a_1 = v_t_248; V a_2 = v_defs_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_defs_242); r_; });
    HEFF_LAST return g_heff_2ecompile_2ecallarity_2eafterRound(v_t_245, v_before_241, v_n_243, v_t_2419);
  }
}
V g_heff_2ecompile_2ecallarity_2erounds_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2erounds(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ecallarity_2erounds_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_d_2410 = args[1];
  V v_before_241 = heff_env(self)[0];
  V v_ar_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2411 = ({ V b_0 = heff_get_n(v_before_241, 1, 2); V a_1 = v_d_2410; V a_2 = heff_dup(heff_rfield(v_acc_249, 2)); HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseDef_24cpr(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  {
    V v_field_2412 = v_t_2411.f[0];
    V v_field_2413 = v_t_2411.f[1];
    V v_d_2414 = v_field_2412;
    V v_n_2415 = v_field_2413;
    V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_acc_249, 0)), 0, 2);
    V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_acc_249, 0)), 1, 2);
    V v_t_2418 = (g_heff_2ecompile_2ecallarity_2edefNotes(v_t_2416, heff_dup(v_ar_246), v_t_2417, heff_dup(v_d_2414)));
    return (g_heff_2ecompile_2ecallarity_2enotedThen(v_ar_246, v_acc_249, v_d_2414, v_n_2415, v_t_2418));
  }
}