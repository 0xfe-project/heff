// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_At 8900
#define TAG_Become 65038
#define TAG_Describe 2650
#define TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135 24780
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HLocal 25864
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_LChunkSnoc 25233
#define TAG_LargeU 29057
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkChk 56962
#define TAG_MkField 62648
#define TAG_MkSyn 7342
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_PartArg 21785
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_SApp 57081
#define TAG_SError 24172
#define TAG_SProj 55716
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_Trace 9637
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Wake 10253
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_dflt 9576017
#define LBL_digits 615232529
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_exponent 966452320
#define LBL_globals 352931696
#define LBL_instances 1653559473
#define LBL_insts 301719303
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_matched 1072719718
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_mty 317996
#define LBL_name 9869138
#define LBL_nameSpan 438211216
#define LBL_negative 1666250321
#define LBL_note 9882809
#define LBL_rest 9992347
#define LBL_root 10001833
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_steps 311119681
#define LBL_stx 323761
#define LBL_tags 10047712
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_val 326043
#define LBL_values 1123329101
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_el__span__dflt__rest[] = {LBL_el, LBL_span, LBL_dflt, LBL_rest};
static uint32_t shape_root__steps[] = {LBL_root, LBL_steps};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
float g_float32_2efromDecimal_w(V, V);
V g_float32_2efromDecimal(V, V);
V g_float32_2efromDecimal_entry(V self, V *a);
extern Clo g_float32_2efromDecimal_clo;
HeffT2 g_heff_2eelab_2eenvironment_2ematchedTagsAt_24cpr(V, V);
HeffT2 g_heff_2eelab_2ememoed_2efunctionD_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
V g_heff_2eelab_2erules_2eappendP_24tok2(V, V, V);
V g_heff_2eelab_2erules_2eappendP_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24tok2_clo;
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
V g_heff_2eelab_2erules_2eatFloat32(V, V, V);
V g_heff_2eelab_2erules_2eatFloat32_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat32_clo;
V g_heff_2eelab_2erules_2ecatMaybesR(V);
V g_heff_2eelab_2erules_2ecatMaybesR_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecatMaybesR_clo;
V g_heff_2eelab_2erules_2ecoerced(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecoerced_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecoerced_clo;
HeffT2 g_heff_2eelab_2erules_2efieldTyAt_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efindPrim(V, V);
V g_heff_2eelab_2erules_2efindPrim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efindPrim_clo;
V g_heff_2eelab_2erules_2efirstElab(V, V, V);
V g_heff_2eelab_2erules_2efirstElab_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efirstElab_clo;
V g_heff_2eelab_2erules_2efracAtFixed(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efracAtFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efracAtFixed_clo;
V g_heff_2eelab_2erules_2efreshMeta(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efreshMeta_clo;
V g_heff_2eelab_2erules_2efunctionElimC(V, V, V, V, V);
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionElimC_clo;
HeffT1 g_heff_2eelab_2erules_2efunctionElimC_24cpr(V, V, V, V, V);
V g_heff_2eelab_2erules_2eguessedFunction(V, V, V);
V g_heff_2eelab_2erules_2eguessedFunction_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eguessedFunction_clo;
V g_heff_2eelab_2erules_2einstGlobal(V, V);
V g_heff_2eelab_2erules_2einstGlobal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstGlobal_clo;
V g_heff_2eelab_2erules_2einstLocals(V);
V g_heff_2eelab_2erules_2einstLocals_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstLocals_clo;
V g_heff_2eelab_2erules_2einstShown(V, V, V);
V g_heff_2eelab_2erules_2einstShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstShown_clo;
V g_heff_2eelab_2erules_2elazyOther(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2elazyOther_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elazyOther_clo;
V g_heff_2eelab_2erules_2eliteralLeft_get(void);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle(V, V, V, V, V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_clo;
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(V, V);
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_clo;
V g_heff_2eelab_2erules_2emetaOf(V);
V g_heff_2eelab_2erules_2emetaOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emetaOf_clo;
V g_heff_2eelab_2erules_2emisfit(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2emisfit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emisfit_clo;
V g_heff_2eelab_2erules_2emismatch(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2emismatch_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emismatch_clo;
V g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_clo;
HeffT1 g_heff_2eelab_2erules_2enumLitChk_24s578050171x2045645742_24cpr(V, V);
V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672(V, V);
V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_clo;
V g_heff_2eelab_2erules_2enumbered(V, V);
V g_heff_2eelab_2erules_2enumbered_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumbered_clo;
HeffT2 g_heff_2eelab_2erules_2eotherTag_24cpr(V, V);
V g_heff_2eelab_2erules_2epatternCanFail(V, V, V, V);
V g_heff_2eelab_2erules_2epatternCanFail_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2epatternCanFail_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2erecordName(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecordName_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordName_clo;
V g_heff_2eelab_2erules_2eresolveWanted(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresolveWanted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresolveWanted_clo;
V g_heff_2eelab_2erules_2esumIntroNow_24generate0(V, V, V);
V g_heff_2eelab_2erules_2esumIntroNow_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumIntroNow_24generate0_clo;
V g_heff_2eelab_2erules_2etopSearch_get(void);
V g_heff_2eelab_2erules_2eunspecForced(V);
V g_heff_2eelab_2erules_2eunspecForced_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eunspecForced_clo;
V g_heff_2eelab_2erules_2ewitnessMatches(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ewitnessMatches_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ewitnessMatches_clo;
V g_heff_2eelab_2erules_2ewritten(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ewritten_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ewritten_clo;
HeffT2 g_heff_2eelab_2erules_2ewrittenAt_24cpr(V, V);
V g_heff_2eelab_2eunify_2emetasK(V);
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasK_clo;
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
V g_heff_2eelab_2evalue_2edecodeNeuOf(V, V, V, V, V);
V g_heff_2eelab_2evalue_2edecodeNeuOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeNeuOf_clo;
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5(V, V, V, V, V, V);
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_clo;
V g_heff_2eelab_2evalue_2eebind(V, V);
V g_heff_2eelab_2evalue_2eebind_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eebind_clo;
V g_heff_2eelab_2evalue_2eebind_24tok1(V, V, V);
V g_heff_2eelab_2evalue_2eebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eebind_24tok1_clo;
V g_heff_2eelab_2evalue_2efieldIn(V, V);
V g_heff_2eelab_2evalue_2efieldIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2efieldIn_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2eunspecialize(V);
V g_heff_2eelab_2evalue_2eunspecialize_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eunspecialize_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
double g_std_2emath_2efromDecimal_w(V, V);
V g_std_2emath_2efromDecimal(V, V);
V g_std_2emath_2efromDecimal_entry(V self, V *a);
extern Clo g_std_2emath_2efromDecimal_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_str1, 0, "");
Clo g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_entry, 2, 0};

V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(V v_d_240, V v_t_241) {
top: ;
  return (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle(NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135), ((V)&g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_str0), ((V)&g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_str1), v_d_240, v_t_241));
}
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(a[0], a[1]);
}
V g_heff_2eelab_2erules_2eunspecForced_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eunspecForced_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eunspecForced_lam0, 1, 0};
V g_heff_2eelab_2erules_2eunspecForced_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2eunspecForced_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eunspecForced_lam1, 1, 0};
Clo g_heff_2eelab_2erules_2eunspecForced_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eunspecForced_entry, 1, 0};

V g_heff_2eelab_2erules_2eunspecForced(V v_t_240) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_VU: {
    return v_t_240;
  }
  case TAG_VDecode: {
    V v_t2_243 = heff_dup(heff_field(v_t_240, 1));
    switch (heff_tag_of(v_t2_243)) {
    case TAG_SpId: {
      return v_t_240;
    }
    case TAG_SpApp: {
      heff_take_n(v_t2_243, 0ULL, 2);
      return v_t_240;
    }
    case TAG_SpProj: {
      heff_take_n(v_t2_243, 0ULL, 2);
      return v_t_240;
    }
    case TAG_SpSpec: {
      heff_take_n(v_t2_243, 0ULL, 3);
      switch (heff_tag_of(v_t_240)) {
      case TAG_VDecode: {
        V v_el_2418 = heff_field(v_t_240, 4);
        V v_ru_24t_240_24VDecode = heff_take_reuse_n(v_t_240, 16ULL, 5);
        V v_t_2419 = heff_tr(heff_call(v_el_2418, 1, (V[]){NTAG(TAG_MkUnit)}));
        V v_x1_2420 = (g_heff_2eelab_2evalue_2eunspecialize(v_t_2419));
        switch (heff_tag_of(v_x1_2420)) {
        case TAG_VNeu: {
          V v_h_2421 = heff_field(v_x1_2420, 0);
          V v_sp_2422 = heff_field(v_x1_2420, 1);
          V v_ty_2423 = heff_field(v_x1_2420, 2);
          V v_expansion_2424 = heff_field(v_x1_2420, 3);
          V v_desc_2425 = heff_field(v_x1_2420, 4);
          heff_take_n(v_x1_2420, 31ULL, 5);
          return (g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5(v_ru_24t_240_24VDecode, v_h_2421, v_sp_2422, v_ty_2423, v_expansion_2424, v_desc_2425));
        }
        case TAG_VCode: {
          V v_a_2426 = heff_field(v_x1_2420, 0);
          heff_take_n(v_x1_2420, 1ULL, 1);
          heff_drop_cell(v_ru_24t_240_24VDecode, 5);
          return v_a_2426;
        }
        case TAG_VLam: {
          heff_take_n(v_x1_2420, 0ULL, 2);
          heff_drop_cell(v_ru_24t_240_24VDecode, 5);
          return heff_abandon();
        }
        case TAG_VCons: {
          heff_take_n(v_x1_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24t_240_24VDecode, 5);
          return heff_abandon();
        }
        case TAG_VOpaque: {
          return heff_tag_at_n(v_ru_24t_240_24VDecode, TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2eunspecForced_lam0_clo), ((V)&g_heff_2eelab_2erules_2eunspecForced_lam1_clo)});
        }
        default: return heff_nomatch(v_x1_2420);
        }
      }
      default: return heff_nomatch(v_t_240);
      }
    }
    default: return heff_nomatch(v_t2_243);
    }
  }
  case TAG_VFunction: {
    return v_t_240;
  }
  case TAG_VRecord: {
    return v_t_240;
  }
  case TAG_VSum: {
    return v_t_240;
  }
  case TAG_VPrimInt: {
    return v_t_240;
  }
  case TAG_VPrimFloat: {
    return v_t_240;
  }
  case TAG_VPrimString: {
    return v_t_240;
  }
  case TAG_VPrimRune: {
    return v_t_240;
  }
  case TAG_VPrimArray: {
    return v_t_240;
  }
  case TAG_VFixed: {
    return v_t_240;
  }
  default: return heff_nomatch(v_t_240);
  }
}
V g_heff_2eelab_2erules_2eunspecForced_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eunspecForced(a[0]);
}
V g_heff_2eelab_2erules_2eunspecForced_lam0(V self, V *args) {
  V v_x_2430 = args[0];
  heff_drop(v_x_2430);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2eunspecForced_lam1(V self, V *args) {
  V v_x_2431 = args[0];
  heff_drop(v_x_2431);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
HEFF_LIT(g_heff_2eelab_2erules_2emisfit_str0, 20, "the instance found, ");
HEFF_LIT(g_heff_2eelab_2erules_2emisfit_str1, 19, ", does not fit here");
Clo g_heff_2eelab_2erules_2emisfit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2emisfit_entry, 6, 0};

V g_heff_2eelab_2erules_2emisfit(V v_e_240, V v_sp_241, V v_w_242, V v_err_243, V v_z_244, V v_z_245) {
top: ;
  V v_bind_246 = heff_take_field(v_z_244, 1);
  V v_malg_247 = heff_get_n(v_z_244, 2, 3);
  V v_t_248 = heff_tr(heff_call(heff_get_n(v_w_242, 0, 6), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_msg_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2emisfit_str0), v_t_248), ((V)&g_heff_2eelab_2erules_2emisfit_str1));
  V v_note_2410 = (g_heff_2eelab_2erules_2eprettyEqErr(heff_get_n(v_e_240, 1, 6), v_err_243));
  V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_msg_249, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_call(v_malg_247, 1, (V[]){v_t_2413}));
  return heff_tail(v_bind_246, 2, (V[]){v_t_2414, v_z_245});
}
V g_heff_2eelab_2erules_2emisfit_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2emisfit(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2eguessedFunction_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eguessedFunction_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eguessedFunction_lam0, 1, 0};
V g_heff_2eelab_2erules_2eguessedFunction_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2eguessedFunction_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eguessedFunction_lam1, 1, 0};
V g_heff_2eelab_2erules_2eguessedFunction_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eguessedFunction_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2eguessedFunction_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eguessedFunction_lam3, 1, 0};
V g_heff_2eelab_2erules_2eguessedFunction_lam4(V self, V *args); static Clo g_heff_2eelab_2erules_2eguessedFunction_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eguessedFunction_lam4, 1, 0};
V g_heff_2eelab_2erules_2eguessedFunction_lam5(V self, V *args);
Clo g_heff_2eelab_2erules_2eguessedFunction_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eguessedFunction_entry, 3, 0};

V g_heff_2eelab_2erules_2eguessedFunction(V v_e_240, V v_dom_241, V v_cod_242) {
top: ;
  V v_scope_243 = heff_take_field(v_e_240, 0);
  V v_globals_244 = heff_get_n(v_e_240, 1, 6);
  V v_t_245 = heff_get_n(v_dom_241, 1, 2);
  V v_v_2417;
  switch (heff_tag_of(v_t_245)) {
  case TAG_VNeu: {
    V v_h_246 = heff_field(v_t_245, 0);
    V v_sp_247 = heff_field(v_t_245, 1);
    V v_ty_248 = heff_field(v_t_245, 2);
    V v_expansion_249 = heff_field(v_t_245, 3);
    V v_desc_2410 = heff_field(v_t_245, 4);
    V v_ru_24t_245_24VNeu = heff_take_reuse_n(v_t_245, 31ULL, 5);
    v_v_2417 = (g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5(v_ru_24t_245_24VNeu, v_h_246, v_sp_247, v_ty_248, v_expansion_249, v_desc_2410));
    break;
  }
  case TAG_VCode: {
    V v_a_2411 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    v_v_2417 = v_a_2411;
    break;
  }
  case TAG_VLam: {
    heff_take_n(v_t_245, 0ULL, 2);
    v_v_2417 = heff_abandon();
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_t_245, 0ULL, 1);
    v_v_2417 = heff_abandon();
    break;
  }
  case TAG_VOpaque: {
    v_v_2417 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2eguessedFunction_lam0_clo), ((V)&g_heff_2eelab_2erules_2eguessedFunction_lam1_clo)});
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_2418 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_dup(heff_rfield(v_scope_243, 0)), heff_dup(v_v_2417)));
  V v_dom_2420 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2418, heff_clo_n(g_heff_2eelab_2erules_2eguessedFunction_lam2, 1, 1, (V[]){v_v_2417})});
  V v_t_2421 = heff_get_n(v_cod_242, 1, 2);
  V v_v_2433;
  switch (heff_tag_of(v_t_2421)) {
  case TAG_VNeu: {
    V v_h_2422 = heff_field(v_t_2421, 0);
    V v_sp_2423 = heff_field(v_t_2421, 1);
    V v_ty_2424 = heff_field(v_t_2421, 2);
    V v_expansion_2425 = heff_field(v_t_2421, 3);
    V v_desc_2426 = heff_field(v_t_2421, 4);
    V v_ru_24t_2421_24VNeu = heff_take_reuse_n(v_t_2421, 31ULL, 5);
    v_v_2433 = (g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5(v_ru_24t_2421_24VNeu, v_h_2422, v_sp_2423, v_ty_2424, v_expansion_2425, v_desc_2426));
    break;
  }
  case TAG_VCode: {
    V v_a_2427 = heff_field(v_t_2421, 0);
    heff_take_n(v_t_2421, 1ULL, 1);
    v_v_2433 = v_a_2427;
    break;
  }
  case TAG_VLam: {
    heff_take_n(v_t_2421, 0ULL, 2);
    v_v_2433 = heff_abandon();
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_t_2421, 0ULL, 1);
    v_v_2433 = heff_abandon();
    break;
  }
  case TAG_VOpaque: {
    v_v_2433 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2eguessedFunction_lam3_clo), ((V)&g_heff_2eelab_2erules_2eguessedFunction_lam4_clo)});
    break;
  }
  default: heff_nomatch(v_t_2421);
  }
  V v_t_2434 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_take_field(v_scope_243, 0), heff_dup(v_v_2433)));
  V v_cod_2436 = heff_tag_n(TAG_AbsConst, 1, (V[]){heff_rec_n(2, shape_stx__val, (V[]){v_t_2434, heff_clo_n(g_heff_2eelab_2erules_2eguessedFunction_lam5, 1, 1, (V[]){v_v_2433})})});
  HeffT2 v_t_2437 = (g_heff_2eelab_2ememoed_2efunctionD_24cpr(NTAG(TAG_Expl), NTAG(TAG_Nothing), v_globals_244, heff_get_n(v_scope_243, 2, 5), v_dom_2420, v_cod_2436));
  {
    V v_field_2439 = v_t_2437.f[1];
    heff_drop(v_t_2437.f[0]);
    V v_x1_2440 = heff_tr(heff_call(v_field_2439, 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_x1_2440)) {
    case TAG_Nom: {
      V v_x_2441 = heff_field(v_x1_2440, 0);
      heff_take_n(v_x1_2440, 1ULL, 1);
      return v_x_2441;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2440, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_Become: {
      V v_x_2443 = heff_field(v_x1_2440, 0);
      heff_take_n(v_x1_2440, 1ULL, 1);
      return v_x_2443;
    }
    default: return heff_nomatch(v_x1_2440);
    }
  }
}
V g_heff_2eelab_2erules_2eguessedFunction_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eguessedFunction(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eguessedFunction_lam0(V self, V *args) {
  V v_x_2415 = args[0];
  heff_drop(v_x_2415);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2eguessedFunction_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  heff_drop(v_x_2416);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2eguessedFunction_lam2(V self, V *args) {
  V v_u_2419 = args[0];
  V v_v_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2419);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_v_2417});
}
V g_heff_2eelab_2erules_2eguessedFunction_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  heff_drop(v_x_2431);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2eguessedFunction_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  heff_drop(v_x_2432);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2eguessedFunction_lam5(V self, V *args) {
  V v_u_2435 = args[0];
  V v_v_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2435);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_v_2433});
}
HEFF_LIT(g_heff_2eelab_2erules_2ecoerced_str0, 3, "coe");
HEFF_LIT(g_heff_2eelab_2erules_2ecoerced_str1, 6, "coerce");
HEFF_LIT(g_heff_2eelab_2erules_2ecoerced_str2, 6, "  ~>  ");
HEFF_LIT(g_heff_2eelab_2erules_2ecoerced_str3, 3, "coe");
HEFF_LIT(g_heff_2eelab_2erules_2ecoerced_str4, 3, "coe");
HEFF_LIT(g_heff_2eelab_2erules_2ecoerced_str5, 3, "coe");
HEFF_LIT(g_heff_2eelab_2erules_2ecoerced_str6, 3, "coe");
HEFF_LIT(g_heff_2eelab_2erules_2ecoerced_str7, 3, "coe");
V g_heff_2eelab_2erules_2ecoerced_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2ecoerced_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecoerced_lam0, 1, 0};
V g_heff_2eelab_2erules_2ecoerced_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam6(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam11(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam10(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam9(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam8(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam7(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ecoerced_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecoerced_entry, 9, 0};

V g_heff_2eelab_2erules_2ecoerced(V v_e_240, V v_sp_241, V v_a_242, V v_a_27_243, V v_m_244, V v_err_245, V v_x7_246, V v_z_247, V v_z_248) {
top: ;
  V v_stx_249 = heff_take_field(v_m_244, 0);
  V v_val_2410 = heff_get_n(v_m_244, 1, 2);
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Nothing: {
    heff_drop(v_stx_249);
    heff_drop(v_val_2410);
    return (g_heff_2eelab_2erules_2emismatch(v_e_240, v_sp_241, v_a_242, v_a_27_243, v_err_245, v_z_247, v_z_248));
  }
  case TAG_Just: {
    V v_goal_2411 = heff_field(v_x7_246, 0);
    V v_ru_24x7_246_24Just = heff_take_reuse_n(v_x7_246, 1ULL, 1);
    V v_t_2413 = heff_tag_at_n(v_ru_24x7_246_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2ecoerced_lam0_clo)})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_247, 2)), 1, (V[]){v_t_2414}));
    return heff_tail(heff_dup(heff_rfield(v_z_247, 1)), 2, (V[]){v_t_2415, heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam1, 1, 10, (V[]){v_e_240, v_a_242, v_a_27_243, v_sp_241, v_goal_2411, v_z_247, heff_dup(v_err_245), v_z_248, v_stx_249, v_val_2410})});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2eelab_2erules_2ecoerced_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2eelab_2erules_2ecoerced(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7], a[8]); heff_drop(a5); return r;
}
V g_heff_2eelab_2erules_2ecoerced_lam0(V self, V *args) {
  V v_c_2412 = args[0];
  return heff_get_n(v_c_2412, 3, 9);
}
V g_heff_2eelab_2erules_2ecoerced_lam2(V self, V *args) {
  V v_i_2426 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2erules_2einstGlobal(v_e_240, v_i_2426));
}
V g_heff_2eelab_2erules_2ecoerced_lam6(V self, V *args) {
  V v_u_2440 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_a_27_243 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2440);
  V v_t_2441 = (g_heff_2eelab_2erules_2einstShown(heff_dup(v_e_240), v_x_2416, v_a_27_243));
  V v_t_2442 = ({ V a_0 = v_e_240; V a_1 = v_x_2416; V a_2 = v_a_242; V r_ = (g_heff_2eelab_2erules_2einstShown(a_0, a_1, a_2)); heff_drop(v_x_2416); r_; });
  return heff_strAppend(heff_strAppend(v_t_2441, ((V)&g_heff_2eelab_2erules_2ecoerced_str2)), v_t_2442);
}
V g_heff_2eelab_2erules_2ecoerced_lam11(V self, V *args) {
  V v_u2_2468 = args[0];
  V v_val_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_2468);
  V v_x1_2469 = heff_tr(heff_call(v_val_2410, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2469)) {
  case TAG_Nom: {
    V v_x_2470 = heff_field(v_x1_2469, 0);
    heff_take_n(v_x1_2469, 1ULL, 1);
    return v_x_2470;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2469, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2472 = heff_field(v_x1_2469, 0);
    heff_take_n(v_x1_2469, 1ULL, 1);
    return v_x_2472;
  }
  default: return heff_nomatch(v_x1_2469);
  }
}
V g_heff_2eelab_2erules_2ecoerced_lam10(V self, V *args) {
  V v_f_2467 = args[0];
  V v_val_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2467, heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam11, 1, 1, (V[]){v_val_2410})));
}
V g_heff_2eelab_2erules_2ecoerced_lam9(V self, V *args) {
  V v_u_2451 = args[0];
  V v_val_2437 = heff_env(self)[0];
  V v_val_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2451);
  V v_t_2452 = v_val_2437;
  V v_t_2466;
  switch (heff_tag_of(v_t_2452)) {
  case TAG_VNeu: {
    V v_t_2458 = ({ V a_0 = v_t_2452; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_t_2452, 5); r_; });
    v_t_2466 = ({ V a_0 = v_t_2458; V b_1 = ((V)&g_heff_2eelab_2erules_2ecoerced_str4); V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, b_1)); heff_drop(b_1); r_; });
    break;
  }
  case TAG_VCode: {
    V v_t_2460 = ({ V a_0 = v_t_2452; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_t_2452, 1); r_; });
    v_t_2466 = ({ V a_0 = v_t_2460; V b_1 = ((V)&g_heff_2eelab_2erules_2ecoerced_str5); V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, b_1)); heff_drop(b_1); r_; });
    break;
  }
  case TAG_VLam: {
    V v_t_2463 = ({ V a_0 = v_t_2452; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_t_2452, 2); r_; });
    v_t_2466 = ({ V a_0 = v_t_2463; V b_1 = ((V)&g_heff_2eelab_2erules_2ecoerced_str6); V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, b_1)); heff_drop(b_1); r_; });
    break;
  }
  case TAG_VCons: {
    V v_t_2465 = ({ V a_0 = v_t_2452; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_t_2452, 1); r_; });
    v_t_2466 = ({ V a_0 = v_t_2465; V b_1 = ((V)&g_heff_2eelab_2erules_2ecoerced_str7); V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, b_1)); heff_drop(b_1); r_; });
    break;
  }
  case TAG_VOpaque: {
    v_t_2466 = heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
    break;
  }
  default: heff_nomatch(v_t_2452);
  }
  return (g_heff_2eelab_2evalue_2eebind(heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam10, 1, 1, (V[]){v_val_2410}), v_t_2466));
}
V g_heff_2eelab_2erules_2ecoerced_lam8(V self, V *args) {
  V v_x_2449 = args[0];
  V v_stx_2436 = heff_env(self)[0];
  V v_stx_249 = heff_env(self)[1];
  V v_val_2437 = heff_env(self)[2];
  V v_val_2410 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  V v_z_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2449);
  V v_t_2450 = heff_tag_n(TAG_SApp, 2, (V[]){heff_tag_n(TAG_SProj, 2, (V[]){v_stx_2436, ((V)&g_heff_2eelab_2erules_2ecoerced_str3)}), v_stx_249});
  V v_x_2473 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2450, heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam9, 1, 2, (V[]){v_val_2437, v_val_2410})});
  V v_hd_2474 = v_z_247;
  heff_drop(v_hd_2474);
  V v_k_2475 = v_z_248;
  V f_ = v_k_2475;
  args[0] = v_x_2473;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecoerced_lam7(V self, V *args) {
  V v_x_2445 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_stx_2436 = heff_env(self)[1];
  V v_stx_249 = heff_env(self)[2];
  V v_val_2437 = heff_env(self)[3];
  V v_val_2410 = heff_env(self)[4];
  V v_z_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2445);
  V v_t_2446 = heff_tag_n(TAG_Wake, 2, (V[]){NTAG(TAG_False), NTAG(TAG_MkUnit)});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_247, 2)), 1, (V[]){v_t_2447}));
  V f_ = heff_dup(heff_rfield(v_z_247, 1));
  heff_room[0] = v_t_2448;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam8, 1, 6, (V[]){v_stx_2436, v_stx_249, v_val_2437, v_val_2410, v_z_247, v_z_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ecoerced_lam5(V self, V *args) {
  V v_x_2439 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  V v_a_27_243 = heff_env(self)[3];
  V v_a_242 = heff_env(self)[4];
  V v_z_247 = heff_env(self)[5];
  V v_stx_2436 = heff_env(self)[6];
  V v_stx_249 = heff_env(self)[7];
  V v_val_2437 = heff_env(self)[8];
  V v_val_2410 = heff_env(self)[9];
  V v_z_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2439);
  V v_t_2443 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){v_sp_241, ((V)&g_heff_2eelab_2erules_2ecoerced_str1), heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam6, 1, 4, (V[]){v_e_240, v_x_2416, v_a_27_243, v_a_242})}), NTAG(TAG_MkUnit)});
  V v_t_2444 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_247, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})}));
  V f_ = heff_dup(heff_rfield(v_z_247, 1));
  heff_room[0] = v_t_2444;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam7, 1, 6, (V[]){v_z_247, v_stx_2436, v_stx_249, v_val_2437, v_val_2410, v_z_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ecoerced_lam4(V self, V *args) {
  V v_x_2435 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_goal_2411 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  V v_a_27_243 = heff_env(self)[5];
  V v_a_242 = heff_env(self)[6];
  V v_stx_249 = heff_env(self)[7];
  V v_val_2410 = heff_env(self)[8];
  V v_z_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_stx_2436 = heff_take_field(v_x_2435, 0);
  V v_val_2437 = heff_get_n(v_x_2435, 1, 2);
  V v_t_2438 = (g_heff_2eelab_2erules_2emetaOf(v_stx_2436));
  return (g_heff_2eelab_2erules_2eresolveWanted(heff_dup(v_e_240), heff_dup(v_sp_241), heff_dup(g_heff_2eelab_2erules_2etopSearch_get()), v_t_2438, heff_dup(v_val_2437), v_goal_2411, NTAG(TAG_True), heff_dup(v_z_247), heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam5, 1, 11, (V[]){v_sp_241, v_e_240, v_x_2416, v_a_27_243, v_a_242, v_z_247, v_stx_2436, v_stx_249, v_val_2437, v_val_2410, v_z_248})));
}
V g_heff_2eelab_2erules_2ecoerced_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_243 = heff_env(self)[3];
  V v_err_245 = heff_env(self)[4];
  V v_z_247 = heff_env(self)[5];
  V v_z_248 = heff_env(self)[6];
  V v_goal_2411 = heff_env(self)[7];
  V v_x_2416 = heff_env(self)[8];
  V v_stx_249 = heff_env(self)[9];
  V v_val_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Nil: {
    heff_drop(v_goal_2411);
    heff_drop(v_x_2416);
    heff_drop(v_stx_249);
    heff_drop(v_val_2410);
    return ({ V a_0 = v_e_240; V a_1 = v_sp_241; V a_2 = v_a_242; V a_3 = v_a_27_243; V a_4 = v_err_245; V a_5 = v_z_247; V a_6 = v_z_248; V r_ = (g_heff_2eelab_2erules_2emismatch(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_err_245); r_; });
  }
  case TAG_Cons: {
    heff_take_n(v_x_2430, 0ULL, 2);
    heff_drop(v_err_245);
    V v_t_2433 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 5);
    V v_t_2434 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 2, 5);
    return ({ V a_0 = v_t_2433; V a_1 = v_t_2434; V a_2 = heff_dup(v_goal_2411); V a_3 = ((V)&g_heff_2eelab_2erules_2ecoerced_str0); V a_4 = heff_dup(v_sp_241); V a_5 = heff_dup(v_z_247); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam4, 1, 10, (V[]){v_e_240, v_sp_241, v_goal_2411, v_z_247, v_x_2416, v_a_27_243, v_a_242, v_stx_249, v_val_2410, v_z_248}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2434); r_; });
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2eelab_2erules_2ecoerced_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_a_242 = heff_env(self)[1];
  V v_a_27_243 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_goal_2411 = heff_env(self)[4];
  V v_z_247 = heff_env(self)[5];
  V v_err_245 = heff_env(self)[6];
  V v_z_248 = heff_env(self)[7];
  V v_stx_249 = heff_env(self)[8];
  V v_val_2410 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2417 = (g_heff_2eelab_2eunify_2emetasK(heff_dup(v_x_2416)));
  V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 5);
  V v_x1_2419 = heff_tr(heff_call(heff_get_n(v_t_2417, 1, 3), 3, (V[]){MK_INT(20LL), v_t_2418, heff_dup(v_a_242)}));
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_Nil: {
    V v_t_2420 = (g_heff_2eelab_2eunify_2emetasK(heff_dup(v_x_2416)));
    V v_t_2421 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 5);
    V v_x1_2422 = heff_tr(heff_call(heff_get_n(v_t_2420, 1, 3), 3, (V[]){MK_INT(20LL), v_t_2421, heff_dup(v_a_27_243)}));
    switch (heff_tag_of(v_x1_2422)) {
    case TAG_Nil: {
      V v_t_2423 = (g_heff_2eelab_2erules_2einstLocals(heff_dup(v_e_240)));
      V v_t_2424 = heff_get_n(heff_dup(heff_rfield(v_e_240, 1)), 7, 8);
      V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2424));
      V v_t_2427 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam2, 1, 1, (V[]){heff_dup(v_e_240)}), v_t_2425));
      V v_t_2428 = (g_heff_2eelab_2erules_2ecatMaybesR(v_t_2427));
      V v_t_2429 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2428));
      return (g_heff_2eelab_2erules_2ewitnessMatches(heff_dup(v_e_240), heff_dup(v_sp_241), heff_dup(v_goal_2411), v_t_2429, heff_dup(v_z_247), heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam3, 1, 11, (V[]){v_e_240, v_sp_241, v_a_242, v_a_27_243, v_err_245, v_z_247, v_z_248, v_goal_2411, v_x_2416, v_stx_249, v_val_2410})));
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2422, 0ULL, 2);
      heff_drop(v_x_2416);
      heff_drop(v_goal_2411);
      heff_drop(v_stx_249);
      heff_drop(v_val_2410);
      return ({ V a_0 = v_e_240; V a_1 = v_sp_241; V a_2 = v_a_242; V a_3 = v_a_27_243; V a_4 = v_err_245; V a_5 = v_z_247; V a_6 = v_z_248; V r_ = (g_heff_2eelab_2erules_2emismatch(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_err_245); r_; });
    }
    default: return heff_nomatch(v_x1_2422);
    }
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2419, 0ULL, 2);
    heff_drop(v_x_2416);
    heff_drop(v_goal_2411);
    heff_drop(v_stx_249);
    heff_drop(v_val_2410);
    return ({ V a_0 = v_e_240; V a_1 = v_sp_241; V a_2 = v_a_242; V a_3 = v_a_27_243; V a_4 = v_err_245; V a_5 = v_z_247; V a_6 = v_z_248; V r_ = (g_heff_2eelab_2erules_2emismatch(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_err_245); r_; });
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
Clo g_heff_2eelab_2erules_2efunctionElimC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionElimC_entry, 5, 0};

V g_heff_2eelab_2erules_2efunctionElimC(V v_checksOnly_240, V v_lambda_241, V v_sp_242, V v_callee_243, V v_arg_244) {
top: ;
  HeffT1 v_t_245 = (g_heff_2eelab_2erules_2efunctionElimC_24cpr(v_checksOnly_240, v_lambda_241, v_sp_242, v_callee_243, v_arg_244));
  {
    V v_field_246 = v_t_245.f[0];
    return heff_tag_n(TAG_MkSyn, 1, (V[]){v_field_246});
  }
}
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2efunctionElimC(a0, a1, a[2], a3, a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2efracAtFixed_str0, 11, "the literal");
Clo g_heff_2eelab_2erules_2efracAtFixed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efracAtFixed_entry, 7, 0};

V g_heff_2eelab_2erules_2efracAtFixed(V v_sp_240, V v_e_241, V v_a_242, V v_w_243, V v_d_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247;
  switch (heff_tag_of(v_w_243)) {
  case TAG_I8: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_247 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_243);
  }
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_e_241);
    heff_drop(v_a_242);
    heff_drop(v_t_247);
    V v_t_248 = heff_dup(heff_rfield(v_d_244, 0));
    double v_x_2410;
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      double v_x_249 = (g_std_2emath_2efromDecimal_w(heff_dup(heff_rfield(v_d_244, 1)), heff_dup(heff_rfield(v_d_244, 2))));
      v_x_2410 = ((-1.0) * v_x_249);
    } else {
      heff_drop(v_t_248);
      v_x_2410 = (g_std_2emath_2efromDecimal_w(heff_dup(heff_rfield(v_d_244, 1)), heff_dup(heff_rfield(v_d_244, 2))));
    }
    V v_t_2411;
    if (((v_x_2410 - v_x_2410) == (0.0))) {
      v_t_2411 = heff_floatShow(heff_box_f64(v_x_2410));
    } else {
      v_t_2411 = ((V)&g_heff_2eelab_2erules_2efracAtFixed_str0);
    }
    V v_t_2412 = heff_take_field(v_d_244, 0);
    float v_t_2414;
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      float v_x_2413 = (g_float32_2efromDecimal_w(heff_take_field(v_d_244, 1), heff_get_n(v_d_244, 2, 3)));
      v_t_2414 = ((float)(((float)(-1.0)) * v_x_2413));
    } else {
      heff_drop(v_t_2412);
      v_t_2414 = (g_float32_2efromDecimal_w(heff_dup(heff_rfield(v_d_244, 1)), heff_get_n(v_d_244, 2, 3)));
    }
    V v_t_2415 = (g_heff_2eelab_2erules_2eatFloat32(v_sp_240, v_t_2411, heff_box_f64(((double)v_t_2414))));
    return heff_tail(v_t_2415, 2, (V[]){v_z_245, v_z_246});
  } else {
    heff_drop(v_t_247);
    return (g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(v_d_244, v_sp_240, v_e_241, v_a_242, v_z_245, v_z_246));
  }
}
V g_heff_2eelab_2erules_2efracAtFixed_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2efracAtFixed(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2ewritten_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ewritten_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ewritten_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ewritten_entry, 8, 0};

V g_heff_2eelab_2erules_2ewritten(V v_e_240, V v_it_241, V v_x_242, V v_fty_243, V v_fs_244, V v_rest_245, V v_hd_246, V v_k_247) {
top: ;
  V v_name_248 = heff_take_field(v_fs_244, 0);
  V v_nameSpan_249 = heff_take_field(v_fs_244, 3);
  V v_chk_2410 = heff_take_field(v_fs_244, 1);
  V v_span_2411 = heff_get_n(v_fs_244, 2, 4);
  return ({ V a_0 = heff_dup(v_e_240); V b_1 = heff_get_n(v_it_241, 1, 5); V a_2 = v_name_248; V a_3 = v_nameSpan_249; V a_4 = heff_dup(v_fty_243); V a_5 = heff_dup(v_hd_246); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2ewritten_lam0, 1, 8, (V[]){v_chk_2410, v_e_240, v_x_242, v_fty_243, v_hd_246, v_span_2411, v_rest_245, v_k_247}); V r_ = (g_heff_2eelab_2erules_2erecordName(a_0, b_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(b_1); r_; });
}
V g_heff_2eelab_2erules_2ewritten_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ewritten(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2ewritten_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_span_2411 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2421 = heff_rec_n(4, shape_el__span__dflt__rest, (V[]){v_x_2420, v_span_2411, NTAG(TAG_False), v_rest_245});
  V f_ = v_k_247;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ewritten_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_chk_2410 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_fty_243 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_span_2411 = heff_env(self)[5];
  V v_rest_245 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2412);
  V v_c_2419;
  switch (heff_tag_of(v_chk_2410)) {
  case TAG_MkChk: {
    V v_f_2413 = heff_field(v_chk_2410, 0);
    heff_take_n(v_chk_2410, 1ULL, 1);
    V v_t_2414 = heff_take_field(v_e_240, 2);
    V v_t_2417;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_ForNominative: {
      heff_drop(v_x_242);
      v_t_2417 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_2415 = heff_field(v_t_2414, 0);
      V v_sp_2416 = heff_field(v_t_2414, 1);
      V v_ru_24t_2414_24ForDescriptive = heff_take_reuse_n(v_t_2414, 3ULL, 2);
      v_t_2417 = heff_tag_at_n(v_ru_24t_2414_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2415, heff_tag_n(TAG_SpProj, 2, (V[]){v_sp_2416, v_x_242})});
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_t_2418 = ({ V rv_2 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_e_240, 59ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4047u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_c_2419 = heff_tr(heff_call(v_f_2413, 2, (V[]){v_t_2418, v_fty_243}));
    break;
  }
  default: heff_nomatch(v_chk_2410);
  }
  V f_ = v_c_2419;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ewritten_lam1, 1, 3, (V[]){v_span_2411, v_rest_245, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efieldTyAt_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2erules_2efieldTyAt_24cpr(V v_len_240, V v_capture_241, V v_fieldTypes_242, V v_i_243, V v_before_244, V v_j_245) {
top: ;
  if (heff_intLt_c_lent(v_j_245, v_i_243, 0)) {
    V v_xs_246 = heff_dup(heff_rfield(v_fieldTypes_242, 2));
    V v_t_248;
    if ((heff_intLe_c_lent(MK_INT(0LL), v_j_245, 1) && heff_intLt_c(heff_dup(v_j_245), heff_arrayLength_lent(v_xs_246, 0)))) {
      V v_v_247 = heff_arrayIndex_lent(v_xs_246, v_j_245, 1);
      v_t_248 = v_v_247;
    } else {
      heff_drop(v_xs_246);
      v_t_248 = heff_abandon();
    }
    V v_t_249 = heff_tr(heff_call(v_t_248, 1, (V[]){heff_tag_n(TAG_LChunkSnoc, 2, (V[]){heff_dup(v_capture_241), heff_dup(v_before_244)})}));
    switch (heff_tag_of(v_t_249)) {
    case TAG_MkField: {
      V v_fty_2410 = heff_field(v_t_249, 0);
      V v_fvalue_2411 = heff_field(v_t_249, 1);
      V v_ru_24t_249_24MkField = heff_take_reuse_n(v_t_249, 3ULL, 2);
      V v_t_2415;
      switch (heff_tag_of(v_fvalue_2411)) {
      case TAG_Nothing: {
        V v_t_2412 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_intAdd(heff_dup(v_len_240), heff_dup(v_j_245))});
        v_t_2415 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2412, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2efieldTyAt_24cpr_lam0, 1, 1, (V[]){v_fty_2410}), NTAG(TAG_Nothing)));
        break;
      }
      case TAG_Just: {
        V v_v_2414 = heff_field(v_fvalue_2411, 0);
        heff_take_n(v_fvalue_2411, 1ULL, 1);
        heff_drop(v_fty_2410);
        v_t_2415 = v_v_2414;
        break;
      }
      default: heff_nomatch(v_fvalue_2411);
      }
      V v_t_2416 = heff_tag_at_n(v_ru_24t_249_24MkField, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
      V v_t_2417 = (g_heff_2eelab_2erules_2eappendP(heff_arrayToList(v_before_244), v_t_2416));
      V t_0 = v_len_240;
      V t_1 = v_capture_241;
      V t_2 = v_fieldTypes_242;
      V t_3 = v_i_243;
      V t_4 = heff_arrayFromList(v_t_2417);
      V t_5 = heff_intAdd(v_j_245, MK_INT(1LL));
      v_len_240 = t_0;
      v_capture_241 = t_1;
      v_fieldTypes_242 = t_2;
      v_i_243 = t_3;
      v_before_244 = t_4;
      v_j_245 = t_5;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_t_249)}});
    }
  } else {
    heff_drop(v_j_245);
    V v_xs_2418 = heff_get_n(v_fieldTypes_242, 2, 3);
    V v_t_2420;
    if ((heff_intLe_c_lent(MK_INT(0LL), v_i_243, 1) && heff_intLt_c(heff_dup(v_i_243), heff_arrayLength_lent(v_xs_2418, 0)))) {
      V v_v_2419 = heff_arrayIndex_lent(v_xs_2418, v_i_243, 1);
      v_t_2420 = v_v_2419;
    } else {
      heff_drop(v_xs_2418);
      v_t_2420 = heff_abandon();
    }
    V v_t_2421 = heff_tr(heff_call(v_t_2420, 1, (V[]){heff_tag_n(TAG_LChunkSnoc, 2, (V[]){v_capture_241, v_before_244})}));
    switch (heff_tag_of(v_t_2421)) {
    case TAG_MkField: {
      V v_fty_2422 = heff_field(v_t_2421, 0);
      heff_take_n(v_t_2421, 1ULL, 2);
      V v_t_2424 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_len_240, v_i_243), heff_dup(v_fty_2422)));
      V v_t_2425 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(MK_INT(0LL), v_t_2424));
      if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
        heff_drop(v_fty_2422);
        heff_drop(v_t_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        heff_drop(v_t_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_fty_2422}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2421)}});
    }
  }
}
V g_heff_2eelab_2erules_2efieldTyAt_24cpr_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_fty_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_fty_2410;
}
Clo g_heff_2eelab_2erules_2esumIntroNow_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumIntroNow_24generate0_entry, 3, 0};

V g_heff_2eelab_2erules_2esumIntroNow_24generate0(V v_gs_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if (((((int64_t)0ULL) <= v_i_241) && (heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_gs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_m_243 = heff_arrayIndexIn_lent(v_gs_240, heff_box_word(v_i_241), 2);
      V v_t_244 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), heff_get_n(v_m_243, 0, 2));
      V t_0 = v_gs_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = v_t_244;
      v_gs_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_m_243 = heff_arrayIndex_lent(v_gs_240, heff_box_word(v_i_241), 2);
    V v_t_244 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), heff_get_n(v_m_243, 0, 2));
    V t_0 = v_gs_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = v_t_244;
    v_gs_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2erules_2esumIntroNow_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2esumIntroNow_24generate0(a0, a[1], a[2]); heff_drop(a0); return r;
}

HeffT2 g_heff_2eelab_2erules_2ewrittenAt_24cpr(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x11_242, 0);
      V v_sp_245 = heff_field(v_x11_242, 1);
      if (heff_strEq_c_lent(v_x_241, v_y_244, 0)) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_sp_245)}});
      } else {
        V t_0 = v_rest_243;
        V t_1 = v_x_241;
        v_x1_240 = t_0;
        v_x_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2epatternCanFail_str0, 4, "tag ");
V g_heff_2eelab_2erules_2epatternCanFail_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2epatternCanFail_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2epatternCanFail_lam0, 2, 0};
V g_heff_2eelab_2erules_2epatternCanFail_lam2(V self, V *args);
V g_heff_2eelab_2erules_2epatternCanFail_lam4(V self, V *args);
V g_heff_2eelab_2erules_2epatternCanFail_lam5(V self, V *args);
V g_heff_2eelab_2erules_2epatternCanFail_lam3(V self, V *args);
V g_heff_2eelab_2erules_2epatternCanFail_lam1(V self, V *args);
V g_heff_2eelab_2erules_2epatternCanFail_lam6(V self, V *args); static Clo g_heff_2eelab_2erules_2epatternCanFail_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2epatternCanFail_lam6, 2, 0};
V g_heff_2eelab_2erules_2epatternCanFail_lam7(V self, V *args);
V g_heff_2eelab_2erules_2epatternCanFail_lam8(V self, V *args);
V g_heff_2eelab_2erules_2epatternCanFail_lam9(V self, V *args);
V g_heff_2eelab_2erules_2epatternCanFail_lam10(V self, V *args);
V g_heff_2eelab_2erules_2epatternCanFail_lam11(V self, V *args);
V g_heff_2eelab_2erules_2epatternCanFail_lam12(V self, V *args); static Clo g_heff_2eelab_2erules_2epatternCanFail_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2epatternCanFail_lam12, 2, 0};
V g_heff_2eelab_2erules_2epatternCanFail_lam13(V self, V *args); static Clo g_heff_2eelab_2erules_2epatternCanFail_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2epatternCanFail_lam13, 2, 0};
Clo g_heff_2eelab_2erules_2epatternCanFail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2epatternCanFail_entry, 4, 0};

V g_heff_2eelab_2erules_2epatternCanFail(V v_sc_240, V v_part_241, V v_x3_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_At: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_x42_245 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_PatVar: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_rec(v_sc_240, 5);
      heff_drop(v_part_241);
      heff_drop(v_x3_242);
      heff_drop(v_x42_245);
      return ((V)&g_heff_2eelab_2erules_2epatternCanFail_lam0_clo);
    }
    case TAG_PatTag: {
      V v_x_249 = heff_field(v_x41_244, 0);
      V v_ps_2411 = heff_field(v_x41_244, 2);
      heff_take_n(v_x41_244, 5ULL, 3);
      return heff_clo_n(g_heff_2eelab_2erules_2epatternCanFail_lam1, 2, 6, (V[]){v_x3_242, v_x_249, v_part_241, v_sc_240, v_x42_245, v_ps_2411});
    }
    case TAG_PatOp: {
      heff_take_n(v_x41_244, 0ULL, 3);
      heff_drop_rec(v_sc_240, 5);
      heff_drop(v_part_241);
      heff_drop(v_x3_242);
      heff_drop(v_x42_245);
      return ((V)&g_heff_2eelab_2erules_2epatternCanFail_lam6_clo);
    }
    case TAG_PatInt: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_rec(v_sc_240, 5);
      heff_drop(v_part_241);
      heff_drop(v_x3_242);
      return heff_clo_n(g_heff_2eelab_2erules_2epatternCanFail_lam7, 2, 1, (V[]){v_x42_245});
    }
    case TAG_PatFloat: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_rec(v_sc_240, 5);
      heff_drop(v_part_241);
      heff_drop(v_x3_242);
      return heff_clo_n(g_heff_2eelab_2erules_2epatternCanFail_lam8, 2, 1, (V[]){v_x42_245});
    }
    case TAG_PatString: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_rec(v_sc_240, 5);
      heff_drop(v_part_241);
      heff_drop(v_x3_242);
      return heff_clo_n(g_heff_2eelab_2erules_2epatternCanFail_lam9, 2, 1, (V[]){v_x42_245});
    }
    case TAG_PatBinary: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_rec(v_sc_240, 5);
      heff_drop(v_part_241);
      heff_drop(v_x3_242);
      return heff_clo_n(g_heff_2eelab_2erules_2epatternCanFail_lam10, 2, 1, (V[]){v_x42_245});
    }
    case TAG_PatRune: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_rec(v_sc_240, 5);
      heff_drop(v_part_241);
      heff_drop(v_x3_242);
      return heff_clo_n(g_heff_2eelab_2erules_2epatternCanFail_lam11, 2, 1, (V[]){v_x42_245});
    }
    case TAG_PatRecord: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_rec(v_sc_240, 5);
      heff_drop(v_part_241);
      heff_drop(v_x3_242);
      heff_drop(v_x42_245);
      return ((V)&g_heff_2eelab_2erules_2epatternCanFail_lam12_clo);
    }
    case TAG_PatWord: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_rec(v_sc_240, 5);
      heff_drop(v_part_241);
      heff_drop(v_x3_242);
      heff_drop(v_x42_245);
      return ((V)&g_heff_2eelab_2erules_2epatternCanFail_lam13_clo);
    }
    case TAG_PatAs: {
      V v_p_24103 = heff_field(v_x41_244, 2);
      heff_take_n(v_x41_244, 4ULL, 3);
      heff_drop(v_x42_245);
      V t_0 = v_sc_240;
      V t_1 = v_part_241;
      V t_2 = v_x3_242;
      V t_3 = v_p_24103;
      v_sc_240 = t_0;
      v_part_241 = t_1;
      v_x3_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2epatternCanFail_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2epatternCanFail(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2epatternCanFail_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2epatternCanFail_lam2(V self, V *args) {
  V v_c_2414 = args[0];
  V v_x3_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2414, 3, 9); V a_1 = v_x3_242; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2epatternCanFail_lam4(V self, V *args) {
  V v_x_2446 = args[0];
  V v_ys_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2446; V a_1 = v_ys_2445; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_x_2446); heff_drop(v_ys_2445); r_; });
}
V g_heff_2eelab_2erules_2epatternCanFail_lam5(V self, V *args) {
  V v_q_2454 = args[0];
  V v_it_2455 = args[1];
  V v_part_241 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_sc_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2462;
  switch (heff_tag_of(v_part_241)) {
  case TAG_Nothing: {
    heff_drop(v_x_249);
    v_t_2462 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_p_2456 = heff_field(v_part_241, 0);
    V v_ru_24part_241_24Just = heff_take_reuse_n(v_part_241, 1ULL, 1);
    V v_t_2459;
    switch (heff_tag_of(v_it_2455)) {
    case TAG_MkPair: {
      V v_x_2457 = heff_dup(heff_field(v_it_2455, 0));
      v_t_2459 = v_x_2457;
      break;
    }
    default: heff_nomatch(v_it_2455);
    }
    V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartArg, 2, (V[]){v_x_249, v_t_2459}), heff_take_field(v_p_2456, 1)});
    V v_t_2461 = ({ V rv_1 = v_t_2460; V rr_ = heff_rec_reuse_nf(v_p_2456, 1ULL, 2, shape_root__steps, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    v_t_2462 = heff_tag_at_n(v_ru_24part_241_24Just, TAG_Just, 1, (V[]){v_t_2461});
    break;
  }
  default: heff_nomatch(v_part_241);
  }
  V v_t_2465;
  switch (heff_tag_of(v_it_2455)) {
  case TAG_MkPair: {
    V v_y_2464 = heff_field(v_it_2455, 1);
    heff_take_n(v_it_2455, 2ULL, 2);
    v_t_2465 = v_y_2464;
    break;
  }
  default: heff_nomatch(v_it_2455);
  }
  V v_t_2466 = heff_tr(heff_call(v_t_2465, 1, (V[]){NTAG(TAG_MkUnit)}));
  return (g_heff_2eelab_2erules_2epatternCanFail(v_sc_240, v_t_2462, v_t_2466, v_q_2454));
}
V g_heff_2eelab_2erules_2epatternCanFail_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_part_241 = heff_env(self)[2];
  V v_sc_240 = heff_env(self)[3];
  V v_x42_245 = heff_env(self)[4];
  V v_ps_2411 = heff_env(self)[5];
  V v_hd_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2419 = (g_heff_2eelab_2evalue_2ebehavior(v_x_2418));
  switch (heff_tag_of(v_t_2419)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2419, 0ULL, 1);
    heff_drop(v_x_249);
    heff_drop(v_part_241);
    heff_drop_rec(v_sc_240, 5);
    heff_drop(v_x42_245);
    heff_drop(v_ps_2411);
    heff_drop_rec(v_hd_2412, 3);
    V f_ = v_k_2413;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2419, 0ULL, 4);
    heff_drop(v_x_249);
    heff_drop(v_part_241);
    heff_drop_rec(v_sc_240, 5);
    heff_drop(v_x42_245);
    heff_drop(v_ps_2411);
    heff_drop_rec(v_hd_2412, 3);
    V f_ = v_k_2413;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2419, 0ULL, 3);
    heff_drop(v_x_249);
    heff_drop(v_part_241);
    heff_drop_rec(v_sc_240, 5);
    heff_drop(v_x42_245);
    heff_drop(v_ps_2411);
    heff_drop_rec(v_hd_2412, 3);
    V f_ = v_k_2413;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeSum: {
    V v_vs_2428 = heff_field(v_t_2419, 0);
    heff_take_n(v_t_2419, 1ULL, 1);
    V v_byName_2429 = heff_take_field(v_vs_2428, 1);
    V v_values_2430 = heff_take_field(v_vs_2428, 2);
    V v_keys_2431 = heff_get_n(v_vs_2428, 0, 3);
    HeffT2 v_t_2432 = ({ V a_0 = v_byName_2429; V a_1 = v_x_249; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byName_2429); r_; });
    {
      V v_field_2434 = v_t_2432.f[1];
      int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
      if ((v_tag_2433 == ((int64_t)0ULL))) {
        V v_i_2435 = v_field_2434;
        V v_xs_2436 = heff_dup(v_values_2430);
        if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2435, 1) && heff_intLt_c(heff_dup(v_i_2435), heff_arrayLength_lent(v_xs_2436, 0)))) {
          V v_ts_2437 = heff_arrayIndex(v_xs_2436, v_i_2435);
          V v_t_2438 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2431), heff_arrayToList(v_values_2430)));
          V v_xs_2439 = (g_list_2emap_24s1937570095x2110149801(v_t_2438));
          V v_t_2447;
          switch (heff_tag_of(v_part_241)) {
          case TAG_Nothing: {
            v_t_2447 = v_xs_2439;
            break;
          }
          case TAG_Just: {
            V v_p_2440 = heff_dup(heff_field(v_part_241, 0));
            V v_t_2441 = heff_get_n(heff_dup(heff_rfield(v_sc_240, 4)), 1, 2);
            HeffT2 v_t_2442 = ({ V a_0 = v_t_2441; V a_1 = v_p_2440; HeffT2 r_ = (g_heff_2eelab_2eenvironment_2ematchedTagsAt_24cpr(a_0, a_1)); heff_drop(v_t_2441); r_; });
            {
              V v_field_2444 = v_t_2442.f[1];
              int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
              if ((v_tag_2443 == ((int64_t)0ULL))) {
                V v_ys_2445 = v_field_2444;
                v_t_2447 = (g_list_2ekeepIf(heff_clo_n(g_heff_2eelab_2erules_2epatternCanFail_lam4, 1, 1, (V[]){v_ys_2445}), v_xs_2439));
              } else {
                heff_drop(v_field_2444);
                v_t_2447 = v_xs_2439;
              }
            }
            break;
          }
          default: heff_nomatch(v_part_241);
          }
          HeffT2 v_t_2448 = ({ V a_0 = v_x_249; V a_1 = v_t_2447; HeffT2 r_ = (g_heff_2eelab_2erules_2eotherTag_24cpr(a_0, a_1)); heff_drop(v_t_2447); r_; });
          {
            V v_field_2450 = v_t_2448.f[1];
            int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
            if ((v_tag_2449 == ((int64_t)0ULL))) {
              heff_drop(v_x_249);
              heff_drop(v_part_241);
              heff_drop_rec(v_sc_240, 5);
              heff_drop(v_ps_2411);
              heff_drop_rec(v_hd_2412, 3);
              heff_drop(v_ts_2437);
              V v_y_2451 = v_field_2450;
              V v_t_2452 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x42_245, heff_strAppend(((V)&g_heff_2eelab_2erules_2epatternCanFail_str0), v_y_2451)});
              V f_ = v_k_2413;
              args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2452});
              if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 1, args);
            } else {
              heff_drop(v_x42_245);
              heff_drop(v_field_2450);
              V v_t_2453 = (g_heff_2eelab_2erules_2enumbered(MK_INT(0LL), heff_arrayToList(v_ts_2437)));
              V v_t_2467 = (g_list_2ezipWith(heff_clo_n(g_heff_2eelab_2erules_2epatternCanFail_lam5, 2, 3, (V[]){v_part_241, v_x_249, v_sc_240}), v_ps_2411, v_t_2453));
              return ({ V a_0 = v_t_2467; V a_1 = v_hd_2412; V a_2 = v_k_2413; V r_ = (g_heff_2eelab_2erules_2efirstElab(a_0, a_1, a_2)); heff_drop(v_t_2467); r_; });
            }
          }
        } else {
          heff_drop(v_x_249);
          heff_drop(v_part_241);
          heff_drop_rec(v_sc_240, 5);
          heff_drop(v_x42_245);
          heff_drop(v_ps_2411);
          heff_drop_rec(v_hd_2412, 3);
          heff_drop(v_values_2430);
          heff_drop(v_keys_2431);
          heff_drop(v_i_2435);
          heff_drop(v_xs_2436);
          V f_ = v_k_2413;
          args[0] = NTAG(TAG_Nothing);
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
      } else {
        heff_drop(v_x_249);
        heff_drop(v_part_241);
        heff_drop_rec(v_sc_240, 5);
        heff_drop(v_x42_245);
        heff_drop(v_ps_2411);
        heff_drop_rec(v_hd_2412, 3);
        heff_drop(v_values_2430);
        heff_drop(v_keys_2431);
        heff_drop(v_field_2434);
        V f_ = v_k_2413;
        args[0] = NTAG(TAG_Nothing);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  case TAG_LikeInt: {
    heff_drop(v_x_249);
    heff_drop(v_part_241);
    heff_drop_rec(v_sc_240, 5);
    heff_drop(v_x42_245);
    heff_drop(v_ps_2411);
    heff_drop_rec(v_hd_2412, 3);
    V f_ = v_k_2413;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_249);
    heff_drop(v_part_241);
    heff_drop_rec(v_sc_240, 5);
    heff_drop(v_x42_245);
    heff_drop(v_ps_2411);
    heff_drop_rec(v_hd_2412, 3);
    V f_ = v_k_2413;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeString: {
    heff_drop(v_x_249);
    heff_drop(v_part_241);
    heff_drop_rec(v_sc_240, 5);
    heff_drop(v_x42_245);
    heff_drop(v_ps_2411);
    heff_drop_rec(v_hd_2412, 3);
    V f_ = v_k_2413;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeRune: {
    heff_drop(v_x_249);
    heff_drop(v_part_241);
    heff_drop_rec(v_sc_240, 5);
    heff_drop(v_x42_245);
    heff_drop(v_ps_2411);
    heff_drop_rec(v_hd_2412, 3);
    V f_ = v_k_2413;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2419, 0ULL, 1);
    heff_drop(v_x_249);
    heff_drop(v_part_241);
    heff_drop_rec(v_sc_240, 5);
    heff_drop(v_x42_245);
    heff_drop(v_ps_2411);
    heff_drop_rec(v_hd_2412, 3);
    V f_ = v_k_2413;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2419, 0ULL, 1);
    heff_drop(v_x_249);
    heff_drop(v_part_241);
    heff_drop_rec(v_sc_240, 5);
    heff_drop(v_x42_245);
    heff_drop(v_ps_2411);
    heff_drop_rec(v_hd_2412, 3);
    V f_ = v_k_2413;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_NoRules: {
    heff_drop(v_x_249);
    heff_drop(v_part_241);
    heff_drop_rec(v_sc_240, 5);
    heff_drop(v_x42_245);
    heff_drop(v_ps_2411);
    heff_drop_rec(v_hd_2412, 3);
    V f_ = v_k_2413;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2419);
  }
}
V g_heff_2eelab_2erules_2epatternCanFail_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_x3_242 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_part_241 = heff_env(self)[2];
  V v_sc_240 = heff_env(self)[3];
  V v_x42_245 = heff_env(self)[4];
  V v_ps_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2epatternCanFail_lam2, 1, 1, (V[]){v_x3_242})})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2412, 2)), 1, (V[]){v_t_2416}));
  V f_ = heff_dup(heff_rfield(v_hd_2412, 1));
  args[0] = v_t_2417;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2epatternCanFail_lam3, 1, 7, (V[]){v_k_2413, v_x_249, v_part_241, v_sc_240, v_x42_245, v_ps_2411, v_hd_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2epatternCanFail_lam6(V self, V *args) {
  V v_hd_2473 = args[0];
  V v_k_2474 = args[1];
  heff_drop(v_hd_2473);
  V f_ = v_k_2474;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2epatternCanFail_lam7(V self, V *args) {
  V v_hd_2476 = args[0];
  V v_k_2477 = args[1];
  V v_x42_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2476);
  V v_t_2478 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x42_245, heff_dup(g_heff_2eelab_2erules_2eliteralLeft_get())})});
  V f_ = v_k_2477;
  args[0] = v_t_2478;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2epatternCanFail_lam8(V self, V *args) {
  V v_hd_2480 = args[0];
  V v_k_2481 = args[1];
  V v_x42_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2480);
  V v_t_2482 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x42_245, heff_dup(g_heff_2eelab_2erules_2eliteralLeft_get())})});
  V f_ = v_k_2481;
  args[0] = v_t_2482;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2epatternCanFail_lam9(V self, V *args) {
  V v_hd_2484 = args[0];
  V v_k_2485 = args[1];
  V v_x42_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2484);
  V v_t_2486 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x42_245, heff_dup(g_heff_2eelab_2erules_2eliteralLeft_get())})});
  V f_ = v_k_2485;
  args[0] = v_t_2486;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2epatternCanFail_lam10(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k_2489 = args[1];
  V v_x42_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2488);
  V v_t_2490 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x42_245, heff_dup(g_heff_2eelab_2erules_2eliteralLeft_get())})});
  V f_ = v_k_2489;
  args[0] = v_t_2490;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2epatternCanFail_lam11(V self, V *args) {
  V v_hd_2492 = args[0];
  V v_k_2493 = args[1];
  V v_x42_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2492);
  V v_t_2494 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x42_245, heff_dup(g_heff_2eelab_2erules_2eliteralLeft_get())})});
  V f_ = v_k_2493;
  args[0] = v_t_2494;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2epatternCanFail_lam12(V self, V *args) {
  V v_hd_2496 = args[0];
  V v_k_2497 = args[1];
  heff_drop(v_hd_2496);
  V f_ = v_k_2497;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2epatternCanFail_lam13(V self, V *args) {
  V v_hd_2499 = args[0];
  V v_k_24100 = args[1];
  heff_drop(v_hd_2499);
  V f_ = v_k_24100;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2elazyOther_str0, 12, "builtin.Lazy");
Clo g_heff_2eelab_2erules_2elazyOther_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elazyOther_entry, 7, 0};

V g_heff_2eelab_2erules_2elazyOther(V v_sp_240, V v_c_241, V v_s_242, V v_e_243, V v_a_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_244)));
  switch (heff_tag_of(v_t_247)) {
  case TAG_LikeU: {
    heff_take_n(v_t_247, 0ULL, 1);
    V v_callee_249 = (g_heff_2eelab_2erules_2efindPrim(heff_dup(v_sp_240), ((V)&g_heff_2eelab_2erules_2elazyOther_str0)));
    V v_t_2410 = ({ V b_0 = NTAG(TAG_False); V b_1 = NTAG(TAG_False); V a_2 = heff_dup(v_sp_240); V a_3 = v_callee_249; V a_4 = v_c_241; V r_ = (g_heff_2eelab_2erules_2efunctionElimC(b_0, b_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(b_1); heff_drop(v_callee_249); r_; });
    HeffT1 v_t_2411 = ({ V a_0 = v_sp_240; V a_1 = v_t_2410; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_t_2410); r_; });
    {
      V v_field_2412 = v_t_2411.f[0];
      V v_f_2413 = v_field_2412;
      return heff_tail(v_f_2413, 4, (V[]){v_e_243, v_a_244, v_z_245, v_z_246});
    }
  }
  default: {
    heff_drop(v_c_241);
    heff_drop(v_t_247);
    HeffT1 v_t_2414 = (g_heff_2eelab_2erules_2eapply_24cpr(v_sp_240, v_s_242));
    {
      V v_field_2415 = v_t_2414.f[0];
      V v_f_2416 = v_field_2415;
      return heff_tail(v_f_2416, 4, (V[]){v_e_243, v_a_244, v_z_245, v_z_246});
    }
  }
  }
}
V g_heff_2eelab_2erules_2elazyOther_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2elazyOther(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_str0, 7, "literal");
V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam2, 1, 0};
V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam3, 1, 0};
V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam5, 1, 0};
V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam6(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam6, 1, 0};
V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam4(V self, V *args);
V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_entry, 2, 0};

V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672(V v_lit_240, V v_sp_241) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam0, 3, 2, (V[]){v_sp_241, v_lit_240})});
}
V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672(a[0], a[1]);
}
V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  heff_drop(v_x_2419);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  heff_drop(v_x_2420);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam5(V self, V *args) {
  V v_x_2437 = args[0];
  heff_drop(v_x_2437);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam6(V self, V *args) {
  V v_x_2438 = args[0];
  heff_drop(v_x_2438);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_get_n(v_x_248, 1, 2);
  V v_t_2439;
  switch (heff_tag_of(v_t_2427)) {
  case TAG_VNeu: {
    V v_h_2428 = heff_field(v_t_2427, 0);
    V v_sp_2429 = heff_field(v_t_2427, 1);
    V v_ty_2430 = heff_field(v_t_2427, 2);
    V v_expansion_2431 = heff_field(v_t_2427, 3);
    V v_desc_2432 = heff_field(v_t_2427, 4);
    V v_ru_24t_2427_24VNeu = heff_take_reuse_n(v_t_2427, 31ULL, 5);
    v_t_2439 = (g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5(v_ru_24t_2427_24VNeu, v_h_2428, v_sp_2429, v_ty_2430, v_expansion_2431, v_desc_2432));
    break;
  }
  case TAG_VCode: {
    V v_a_2433 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2439 = v_a_2433;
    break;
  }
  case TAG_VLam: {
    heff_take_n(v_t_2427, 0ULL, 2);
    v_t_2439 = heff_abandon();
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_t_2427, 0ULL, 1);
    v_t_2439 = heff_abandon();
    break;
  }
  case TAG_VOpaque: {
    v_t_2439 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam5_clo), ((V)&g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam6_clo)});
    break;
  }
  default: heff_nomatch(v_t_2427);
  }
  V v_x_2440 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2426, v_t_2439});
  V f_ = v_k_244;
  args[0] = v_x_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = heff_dup(heff_rfield(v_x_248, 1));
  V v_a_2421;
  switch (heff_tag_of(v_t_249)) {
  case TAG_VNeu: {
    V v_h_2410 = heff_field(v_t_249, 0);
    V v_sp_2411 = heff_field(v_t_249, 1);
    V v_ty_2412 = heff_field(v_t_249, 2);
    V v_expansion_2413 = heff_field(v_t_249, 3);
    V v_desc_2414 = heff_field(v_t_249, 4);
    V v_ru_24t_249_24VNeu = heff_take_reuse_n(v_t_249, 31ULL, 5);
    v_a_2421 = (g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5(v_ru_24t_249_24VNeu, v_h_2410, v_sp_2411, v_ty_2412, v_expansion_2413, v_desc_2414));
    break;
  }
  case TAG_VCode: {
    V v_a_2415 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    v_a_2421 = v_a_2415;
    break;
  }
  case TAG_VLam: {
    heff_take_n(v_t_249, 0ULL, 2);
    v_a_2421 = heff_abandon();
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_t_249, 0ULL, 1);
    v_a_2421 = heff_abandon();
    break;
  }
  case TAG_VOpaque: {
    v_a_2421 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam2_clo), ((V)&g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam3_clo)});
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  HeffT1 v_t_2422 = (g_heff_2eelab_2erules_2enumLitChk_24s578050171x2045645742_24cpr(v_lit_240, v_sp_241));
  V v_c_2425;
  {
    V v_field_2423 = v_t_2422.f[0];
    V v_f_2424 = v_field_2423;
    v_c_2425 = heff_tr(heff_call(v_f_2424, 2, (V[]){v_e_242, v_a_2421}));
  }
  V f_ = v_c_2425;
  heff_room[0] = v_hd_243;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam4, 1, 2, (V[]){v_x_248, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_hd_243 = args[1];
  V v_k_244 = args[2];
  V v_sp_241 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 0, 5);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 2, 5);
  V v_t_247 = heff_tag_n(TAG_VU, 1, (V[]){NTAG(TAG_SmallU)});
  return ({ V a_0 = v_t_245; V a_1 = v_t_246; V a_2 = v_t_247; V a_3 = ((V)&g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_str0); V a_4 = heff_dup(v_sp_241); V a_5 = heff_dup(v_hd_243); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_lam1, 1, 5, (V[]){v_lit_240, v_sp_241, v_e_242, v_hd_243, v_k_244}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_246); r_; });
}