// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135 24780
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LChunkSnoc 25233
#define TAG_Large 60129
#define TAG_MkChk 56962
#define TAG_MkField 62648
#define TAG_MkSyn 7342
#define TAG_Nom 25944
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_Small 51389
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_Throw 56084
#define TAG_TopL 65516
#define TAG_Trace 9637
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Wake 10253
#define LBL_bind 9519364
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_dflt 9576017
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_instances 1653559473
#define LBL_insts 301719303
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_mty 317996
#define LBL_name 9869138
#define LBL_nameSpan 438211216
#define LBL_note 9882809
#define LBL_rest 9992347
#define LBL_scheme 1039154384
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_v 336
#define LBL_val 326043
#define LBL_values 1123329101
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_el__span__dflt__rest[] = {LBL_el, LBL_span, LBL_dflt, LBL_rest};
static uint32_t shape_name__from__scheme__ty__stx__val[] = {LBL_name, LBL_from, LBL_scheme, LBL_ty, LBL_stx, LBL_val};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eelab_2ememoed_2eabandonM_get(void);
V g_heff_2eelab_2ememoed_2eapp(V, V);
V g_heff_2eelab_2ememoed_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eapp_clo;
V g_heff_2eelab_2ememoed_2eproj(V, V);
V g_heff_2eelab_2ememoed_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eproj_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erules_2eabandonChk(V);
V g_heff_2eelab_2erules_2eabandonChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eabandonChk_clo;
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
V g_heff_2eelab_2erules_2ecatMaybesR(V);
V g_heff_2eelab_2erules_2ecatMaybesR_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecatMaybesR_clo;
V g_heff_2eelab_2erules_2ecoerced(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecoerced_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecoerced_clo;
HeffT2 g_heff_2eelab_2erules_2efieldTyAt_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efreshMeta_clo;
V g_heff_2eelab_2erules_2efunctionElimC(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionElimC_clo;
HeffT1 g_heff_2eelab_2erules_2efunctionElimC_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2eheldIn(V, V);
V g_heff_2eelab_2erules_2eheldIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eheldIn_clo;
V g_heff_2eelab_2erules_2einstGlobal(V, V);
V g_heff_2eelab_2erules_2einstGlobal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstGlobal_clo;
V g_heff_2eelab_2erules_2einstShown(V, V, V);
V g_heff_2eelab_2erules_2einstShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstShown_clo;
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle(V, V, V, V, V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_clo;
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(V, V);
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_clo;
V g_heff_2eelab_2erules_2emisfit(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2emisfit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emisfit_clo;
V g_heff_2eelab_2erules_2emismatch(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2emismatch_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emismatch_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2erecordName(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecordName_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordName_clo;
V g_heff_2eelab_2erules_2eresolveWanted(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresolveWanted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresolveWanted_clo;
V g_heff_2eelab_2erules_2espineHasLocal(V, V);
V g_heff_2eelab_2erules_2espineHasLocal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2espineHasLocal_clo;
V g_heff_2eelab_2erules_2etopSearch_get(void);
V g_heff_2eelab_2erules_2ewitnessMatches(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ewitnessMatches_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ewitnessMatches_clo;
V g_heff_2eelab_2erules_2ewritten(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ewritten_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ewritten_clo;
V g_heff_2eelab_2eunify_2emetasK(V);
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasK_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_str1, 0, "");
Clo g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_entry, 2, 0};

V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(V v_d_240, V v_t_241) {
top: ;
  return (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle(NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135), ((V)&g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_str0), ((V)&g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_str1), v_d_240, v_t_241));
}
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2erules_2emisfit_str0, 20, "the instance found, ");
HEFF_LIT(g_heff_2eelab_2erules_2emisfit_str1, 19, ", does not fit here");
Clo g_heff_2eelab_2erules_2emisfit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2emisfit_entry, 6, 0};

V g_heff_2eelab_2erules_2emisfit(V v_e_240, V v_sp_241, V v_w_242, V v_err_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = heff_tr(heff_call(heff_get_n(v_w_242, 0, 6), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_msg_247 = heff_strAppend(((V)&g_heff_2eelab_2erules_2emisfit_str0), heff_strAppend(v_t_246, ((V)&g_heff_2eelab_2erules_2emisfit_str1)));
  V v_note_248 = (g_heff_2eelab_2erules_2eprettyEqErr(heff_get_n(v_e_240, 1, 6), v_err_243));
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_msg_247, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){v_t_2411}));
  return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2412, v_z_245});
}
V g_heff_2eelab_2erules_2emisfit_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2emisfit(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
Clo g_heff_2eelab_2erules_2efunctionElimC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionElimC_entry, 4, 0};

V g_heff_2eelab_2erules_2efunctionElimC(V v_checksOnly_240, V v_sp_241, V v_callee_242, V v_arg_243) {
top: ;
  HeffT1 v_t_244 = (g_heff_2eelab_2erules_2efunctionElimC_24cpr(v_checksOnly_240, v_sp_241, v_callee_242, v_arg_243));
  {
    V v_field_245 = v_t_244.f[0];
    return heff_tag_n(TAG_MkSyn, 1, (V[]){v_field_245});
  }
}
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2efunctionElimC(a0, a[1], a2, a3); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2eheldIn_str0, 4, "With");
HEFF_LIT(g_heff_2eelab_2erules_2eheldIn_str1, 5, ".With");
Clo g_heff_2eelab_2erules_2eheldIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eheldIn_entry, 2, 0};

V g_heff_2eelab_2erules_2eheldIn(V v_l_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_VU: {
    heff_drop(v_l_240);
    return NTAG(TAG_False);
  }
  case TAG_VDecode: {
    V v_t1_243 = heff_field(v_t_241, 0);
    V v_sp_244 = heff_field(v_t_241, 1);
    switch (heff_tag_of(v_t1_243)) {
    case TAG_HLocal: {
      heff_drop(v_l_240);
      return NTAG(TAG_False);
    }
    case TAG_HGlobal: {
      V v_k_249 = heff_field(v_t1_243, 0);
      if (heff_strEq_c_lent(v_k_249, ((V)&g_heff_2eelab_2erules_2eheldIn_str0), 2)) {
        HEFF_LAST return g_heff_2eelab_2erules_2espineHasLocal(v_l_240, v_sp_244);
      } else {
        int64_t v_t_2411 = (heff_unbox_word(heff_strLength_lent(v_k_249, 0)) - ((int64_t)5ULL));
        V v_t_2412 = heff_strSlice(heff_dup(v_k_249), heff_box_word(v_t_2411), heff_strLength_lent(v_k_249, 0));
        if (heff_strEq_c(v_t_2412, ((V)&g_heff_2eelab_2erules_2eheldIn_str1))) {
          HEFF_LAST return g_heff_2eelab_2erules_2espineHasLocal(v_l_240, v_sp_244);
        } else {
          heff_drop(v_l_240);
          return NTAG(TAG_False);
        }
      }
    }
    case TAG_HMeta: {
      heff_drop(v_l_240);
      return NTAG(TAG_False);
    }
    case TAG_HError: {
      heff_drop(v_l_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t1_243);
    }
  }
  case TAG_VFunction: {
    heff_drop(v_l_240);
    return NTAG(TAG_False);
  }
  case TAG_VRecord: {
    heff_drop(v_l_240);
    return NTAG(TAG_False);
  }
  case TAG_VSum: {
    heff_drop(v_l_240);
    return NTAG(TAG_False);
  }
  case TAG_VPrimInt: {
    heff_drop(v_l_240);
    return NTAG(TAG_False);
  }
  case TAG_VPrimFloat: {
    heff_drop(v_l_240);
    return NTAG(TAG_False);
  }
  case TAG_VPrimString: {
    heff_drop(v_l_240);
    return NTAG(TAG_False);
  }
  case TAG_VPrimRune: {
    heff_drop(v_l_240);
    return NTAG(TAG_False);
  }
  case TAG_VPrimArray: {
    heff_drop(v_l_240);
    return NTAG(TAG_False);
  }
  case TAG_VFixed: {
    heff_drop(v_l_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eelab_2erules_2eheldIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2eheldIn(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2ecoerced_str0, 20, "an instance argument");
HEFF_LIT(g_heff_2eelab_2erules_2ecoerced_str1, 3, "coe");
HEFF_LIT(g_heff_2eelab_2erules_2ecoerced_str2, 6, "coerce");
HEFF_LIT(g_heff_2eelab_2erules_2ecoerced_str3, 6, "  ~>  ");
HEFF_LIT(g_heff_2eelab_2erules_2ecoerced_str4, 3, "coe");
V g_heff_2eelab_2erules_2ecoerced_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2ecoerced_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecoerced_lam0, 1, 0};
V g_heff_2eelab_2erules_2ecoerced_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam8(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam11(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam10(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam9(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam7(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam6(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ecoerced_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ecoerced_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecoerced_entry, 9, 0};

V g_heff_2eelab_2erules_2ecoerced(V v_e_240, V v_sp_241, V v_a_242, V v_a_27_243, V v_m_244, V v_err_245, V v_x7_246, V v_z_247, V v_z_248) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Nothing: {
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2emismatch(v_e_240, v_sp_241, v_a_242, v_a_27_243, v_err_245, v_z_247, v_z_248));
  }
  case TAG_Just: {
    V v_goal_249 = heff_field(v_x7_246, 0);
    V v_ru_24x7_246_24Just = heff_take_reuse_n(v_x7_246, 1ULL, 1);
    V v_t_2411 = heff_tag_at_n(v_ru_24x7_246_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2ecoerced_lam0_clo)})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_247, 2)), 1, (V[]){v_t_2412}));
    return heff_tail(heff_dup(heff_rfield(v_z_247, 1)), 2, (V[]){v_t_2413, heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam1, 1, 9, (V[]){v_e_240, v_a_242, v_a_27_243, v_sp_241, v_goal_249, v_z_247, heff_dup(v_err_245), v_z_248, v_m_244})});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2eelab_2erules_2ecoerced_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2eelab_2erules_2ecoerced(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7], a[8]); heff_drop(a5); return r;
}
V g_heff_2eelab_2erules_2ecoerced_lam0(V self, V *args) {
  V v_c_2410 = args[0];
  return heff_get_n(v_c_2410, 3, 8);
}
V g_heff_2eelab_2erules_2ecoerced_lam3(V self, V *args) {
  V v_u_2424 = args[0];
  V v_c_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2424);
  return heff_get_n(v_c_2421, 0, 3);
}
V g_heff_2eelab_2erules_2ecoerced_lam2(V self, V *args) {
  V v_c_2421 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_get_n(heff_get_n(v_e_240, 0, 6), 0, 4);
  V v_stx_2423 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_t_2422, heff_dup(heff_rfield(v_c_2421, 2))));
  return heff_rec_n(6, shape_name__from__scheme__ty__stx__val, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam3, 1, 1, (V[]){heff_dup(v_c_2421)}), ((V)&g_heff_2eelab_2erules_2ecoerced_str0), NTAG(TAG_False), heff_dup(heff_rfield(v_c_2421, 1)), v_stx_2423, heff_get_n(v_c_2421, 2, 3)});
}
V g_heff_2eelab_2erules_2ecoerced_lam4(V self, V *args) {
  V v_i_2428 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2erules_2einstGlobal(v_e_240, v_i_2428));
}
V g_heff_2eelab_2erules_2ecoerced_lam8(V self, V *args) {
  V v_u_2476 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_a_27_243 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2476);
  V v_t_2477 = (g_heff_2eelab_2erules_2einstShown(heff_dup(v_e_240), v_x_2414, v_a_27_243));
  V v_t_2478 = ({ V a_0 = v_e_240; V a_1 = v_x_2414; V a_2 = v_a_242; V r_ = (g_heff_2eelab_2erules_2einstShown(a_0, a_1, a_2)); heff_drop(v_x_2414); r_; });
  return heff_strAppend(v_t_2477, heff_strAppend(((V)&g_heff_2eelab_2erules_2ecoerced_str3), v_t_2478));
}
V g_heff_2eelab_2erules_2ecoerced_lam11(V self, V *args) {
  V v_u_2486 = args[0];
  V v_x_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2486);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_x_2437, 1, 2)});
}
V g_heff_2eelab_2erules_2ecoerced_lam10(V self, V *args) {
  V v_x_2485 = args[0];
  V v_x_2437 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_z_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2485);
  V v_t_2487 = ({ V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam11, 1, 1, (V[]){heff_dup(v_x_2437)}); V rr_ = heff_rec_reuse_nf(v_x_2437, 1ULL, 2, shape_stx__val, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2488 = (g_heff_2eelab_2ememoed_2eproj(v_t_2487, ((V)&g_heff_2eelab_2erules_2ecoerced_str4)));
  V v_t_2489 = (g_heff_2eelab_2ememoed_2eapp(v_t_2488, v_m_244));
  V f_ = v_z_248;
  args[0] = v_t_2489;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecoerced_lam9(V self, V *args) {
  V v_x_2481 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_x_2437 = heff_env(self)[1];
  V v_m_244 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2481);
  V v_t_2482 = heff_tag_n(TAG_Wake, 2, (V[]){NTAG(TAG_False), NTAG(TAG_MkUnit)});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tr(heff_call(heff_take_field(v_z_247, 2), 1, (V[]){v_t_2483}));
  V f_ = heff_get_n(v_z_247, 1, 3);
  heff_room[0] = v_t_2484;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam10, 1, 3, (V[]){v_x_2437, v_m_244, v_z_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ecoerced_lam7(V self, V *args) {
  V v_x_2475 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_a_27_243 = heff_env(self)[3];
  V v_a_242 = heff_env(self)[4];
  V v_z_247 = heff_env(self)[5];
  V v_x_2437 = heff_env(self)[6];
  V v_m_244 = heff_env(self)[7];
  V v_z_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2475);
  V v_t_2479 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){v_sp_241, ((V)&g_heff_2eelab_2erules_2ecoerced_str2), heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam8, 1, 4, (V[]){v_e_240, v_x_2414, v_a_27_243, v_a_242})}), NTAG(TAG_MkUnit)});
  V v_t_2480 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_247, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})}));
  V f_ = heff_dup(heff_rfield(v_z_247, 1));
  heff_room[0] = v_t_2480;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam9, 1, 4, (V[]){v_z_247, v_x_2437, v_m_244, v_z_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ecoerced_lam6(V self, V *args) {
  V v_x_2437 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_goal_249 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_x_2414 = heff_env(self)[4];
  V v_a_27_243 = heff_env(self)[5];
  V v_a_242 = heff_env(self)[6];
  V v_m_244 = heff_env(self)[7];
  V v_z_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2438 = heff_dup(heff_rfield(v_x_2437, 0));
  V v_t_2474;
  switch (heff_tag_of(v_t_2438)) {
  case TAG_SLocal: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_2438, 0ULL, 2);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_2438, 0ULL, 2);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_2438, 0ULL, 2);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_2438, 0ULL, 2);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_2438, 0ULL, 2);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_2438, 0ULL, 3);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_2438, 0ULL, 2);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_2438, 0ULL, 2);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_2463 = heff_field(v_t_2438, 0);
    heff_take_n(v_t_2438, 1ULL, 3);
    v_t_2474 = v_k_2463;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_na(v_t_2438, 0ULL, 1);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_2438, 0ULL, 2);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_t_2438, 0ULL, 1);
    v_t_2474 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_2438);
  }
  return (g_heff_2eelab_2erules_2eresolveWanted(heff_dup(v_e_240), heff_dup(v_sp_241), heff_dup(g_heff_2eelab_2erules_2etopSearch_get()), v_t_2474, heff_dup(heff_rfield(v_x_2437, 1)), v_goal_249, NTAG(TAG_True), heff_dup(v_z_247), heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam7, 1, 9, (V[]){v_sp_241, v_e_240, v_x_2414, v_a_27_243, v_a_242, v_z_247, v_x_2437, v_m_244, v_z_248})));
}
V g_heff_2eelab_2erules_2ecoerced_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_243 = heff_env(self)[3];
  V v_err_245 = heff_env(self)[4];
  V v_z_247 = heff_env(self)[5];
  V v_z_248 = heff_env(self)[6];
  V v_goal_249 = heff_env(self)[7];
  V v_x_2414 = heff_env(self)[8];
  V v_m_244 = heff_env(self)[9];
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_x_2432)) {
  case TAG_Nil: {
    heff_drop(v_goal_249);
    heff_drop(v_x_2414);
    heff_drop(v_m_244);
    return ({ V a_0 = v_e_240; V a_1 = v_sp_241; V a_2 = v_a_242; V a_3 = v_a_27_243; V a_4 = v_err_245; V a_5 = v_z_247; V a_6 = v_z_248; V r_ = (g_heff_2eelab_2erules_2emismatch(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_err_245); r_; });
  }
  case TAG_Cons: {
    heff_take_n(v_x_2432, 0ULL, 2);
    heff_drop(v_err_245);
    V v_t_2435 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
    V v_t_2436 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 2, 4);
    return ({ V a_0 = v_t_2435; V a_1 = v_t_2436; V a_2 = heff_dup(v_goal_249); V a_3 = ((V)&g_heff_2eelab_2erules_2ecoerced_str1); V a_4 = heff_dup(v_sp_241); V a_5 = heff_dup(v_z_247); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam6, 1, 9, (V[]){v_e_240, v_sp_241, v_goal_249, v_z_247, v_x_2414, v_a_27_243, v_a_242, v_m_244, v_z_248}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2436); r_; });
  }
  default: return heff_nomatch(v_x_2432);
  }
}
V g_heff_2eelab_2erules_2ecoerced_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_a_242 = heff_env(self)[1];
  V v_a_27_243 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_goal_249 = heff_env(self)[4];
  V v_z_247 = heff_env(self)[5];
  V v_err_245 = heff_env(self)[6];
  V v_z_248 = heff_env(self)[7];
  V v_m_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2415 = (g_heff_2eelab_2eunify_2emetasK(v_x_2414));
  V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_x1_2417 = heff_tr(heff_call(heff_get_n(v_t_2415, 1, 3), 3, (V[]){MK_INT(20LL), v_t_2416, heff_dup(v_a_242)}));
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_Nil: {
    V v_t_2418 = (g_heff_2eelab_2eunify_2emetasK(v_x_2414));
    V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
    V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_t_2418, 1, 3), 3, (V[]){MK_INT(20LL), v_t_2419, heff_dup(v_a_27_243)}));
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_Nil: {
      V v_t_2425 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam2, 1, 1, (V[]){heff_dup(v_e_240)}), heff_dup(heff_rfield(v_e_240, 5))));
      V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_e_240, 1)), 7, 8);
      V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2426));
      V v_t_2429 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam4, 1, 1, (V[]){heff_dup(v_e_240)}), v_t_2427));
      V v_t_2430 = (g_heff_2eelab_2erules_2ecatMaybesR(v_t_2429));
      V v_t_2431 = (g_prelude_2e_2b_2b(v_t_2425, v_t_2430));
      return (g_heff_2eelab_2erules_2ewitnessMatches(heff_dup(v_e_240), heff_dup(v_sp_241), heff_dup(v_goal_249), v_t_2431, heff_dup(v_z_247), heff_clo_n(g_heff_2eelab_2erules_2ecoerced_lam5, 1, 10, (V[]){v_e_240, v_sp_241, v_a_242, v_a_27_243, v_err_245, v_z_247, v_z_248, v_goal_249, v_x_2414, v_m_244})));
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2420, 0ULL, 2);
      heff_drop(v_x_2414);
      heff_drop(v_goal_249);
      heff_drop(v_m_244);
      return ({ V a_0 = v_e_240; V a_1 = v_sp_241; V a_2 = v_a_242; V a_3 = v_a_27_243; V a_4 = v_err_245; V a_5 = v_z_247; V a_6 = v_z_248; V r_ = (g_heff_2eelab_2erules_2emismatch(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_err_245); r_; });
    }
    default: return heff_nomatch(v_x1_2420);
    }
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2417, 0ULL, 2);
    heff_drop(v_x_2414);
    heff_drop(v_goal_249);
    heff_drop(v_m_244);
    return ({ V a_0 = v_e_240; V a_1 = v_sp_241; V a_2 = v_a_242; V a_3 = v_a_27_243; V a_4 = v_err_245; V a_5 = v_z_247; V a_6 = v_z_248; V r_ = (g_heff_2eelab_2erules_2emismatch(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_err_245); r_; });
  }
  default: return heff_nomatch(v_x1_2417);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eabandonChk_str0, 50, "can only use abandon when checking at a small type");
HEFF_LIT(g_heff_2eelab_2erules_2eabandonChk_str1, 50, "can only use abandon when checking at a small type");
V g_heff_2eelab_2erules_2eabandonChk_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2eabandonChk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eabandonChk_lam1, 2, 0};
V g_heff_2eelab_2erules_2eabandonChk_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eabandonChk_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eabandonChk_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eabandonChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eabandonChk_entry, 1, 0};

V g_heff_2eelab_2erules_2eabandonChk(V v_sp_240) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eabandonChk_lam0, 2, 1, (V[]){v_sp_240})});
}
V g_heff_2eelab_2erules_2eabandonChk_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eabandonChk(a[0]);
}
V g_heff_2eelab_2erules_2eabandonChk_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eabandonM_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eabandonChk_lam2(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k2_247 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(321LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eabandonChk_str0), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2410}));
  V f_ = heff_get_n(v_hd_246, 1, 3);
  args[0] = v_t_2411;
  args[1] = v_k2_247;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eabandonChk_lam3(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(321LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eabandonChk_str1), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_2412, 2), 1, (V[]){v_t_2416}));
  V f_ = heff_get_n(v_hd_2412, 1, 3);
  args[0] = v_t_2417;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eabandonChk_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_242 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_241);
  V v_x1_243 = ({ V a_0 = v_a_242; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_a_242); r_; });
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Small: {
    heff_drop(v_sp_240);
    return ((V)&g_heff_2eelab_2erules_2eabandonChk_lam1_clo);
  }
  case TAG_Large: {
    return heff_clo_n(g_heff_2eelab_2erules_2eabandonChk_lam2, 2, 1, (V[]){v_sp_240});
  }
  case TAG_TopL: {
    return heff_clo_n(g_heff_2eelab_2erules_2eabandonChk_lam3, 2, 1, (V[]){v_sp_240});
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2eelab_2erules_2ewritten_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ewritten_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ewritten_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ewritten_entry, 8, 0};

V g_heff_2eelab_2erules_2ewritten(V v_e_240, V v_it_241, V v_x_242, V v_fty_243, V v_fs_244, V v_rest_245, V v_hd_246, V v_k_247) {
top: ;
  return ({ V a_0 = heff_dup(v_e_240); V b_1 = heff_get_n(v_it_241, 1, 5); V a_2 = heff_dup(heff_rfield(v_fs_244, 0)); V a_3 = heff_dup(heff_rfield(v_fs_244, 3)); V a_4 = heff_dup(v_fty_243); V a_5 = heff_dup(v_hd_246); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2ewritten_lam0, 1, 7, (V[]){v_fs_244, v_e_240, v_x_242, v_fty_243, v_hd_246, v_rest_245, v_k_247}); V r_ = (g_heff_2eelab_2erules_2erecordName(a_0, b_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(b_1); r_; });
}
V g_heff_2eelab_2erules_2ewritten_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ewritten(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2ewritten_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_fs_244 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_rec_n(4, shape_el__span__dflt__rest, (V[]){v_x_2417, heff_get_n(v_fs_244, 2, 4), NTAG(TAG_False), v_rest_245});
  V f_ = v_k_247;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ewritten_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_fs_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_fty_243 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_248);
  V v_t_249 = heff_dup(heff_rfield(v_fs_244, 1));
  V v_c_2416;
  switch (heff_tag_of(v_t_249)) {
  case TAG_MkChk: {
    V v_f_2410 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    V v_t_2411 = heff_take_field(v_e_240, 2);
    V v_t_2414;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_ForNominative: {
      heff_drop(v_x_242);
      v_t_2414 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_2412 = heff_field(v_t_2411, 0);
      V v_sp_2413 = heff_field(v_t_2411, 1);
      V v_ru_24t_2411_24ForDescriptive = heff_take_reuse_n(v_t_2411, 3ULL, 2);
      v_t_2414 = heff_tag_at_n(v_ru_24t_2411_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2412, heff_tag_n(TAG_SpProj, 2, (V[]){v_sp_2413, v_x_242})});
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    V v_t_2415 = ({ V rv_2 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_e_240, 59ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4047u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_c_2416 = heff_tr(heff_call(v_f_2410, 2, (V[]){v_t_2415, v_fty_243}));
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V f_ = v_c_2416;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ewritten_lam1, 1, 3, (V[]){v_fs_244, v_rest_245, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efieldTyAt_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2erules_2efieldTyAt_24cpr(V v_len_240, V v_capture_241, V v_fieldTypes_242, V v_i_243, V v_before_244, V v_j_245) {
top: ;
  if (heff_intLt_c_lent(v_j_245, v_i_243, 0)) {
    V v_xs_247 = heff_dup(heff_rfield(v_fieldTypes_242, 2));
    V v_t_2411;
    if (heff_intLe_c_lent(MK_INT(0LL), v_j_245, 1)) {
      if (heff_intLt_c(heff_dup(v_j_245), heff_arrayLength_lent(v_xs_247, 0))) {
        V v_v_2410 = heff_arrayIndex_lent(v_xs_247, v_j_245, 1);
        v_t_2411 = v_v_2410;
      } else {
        heff_drop(v_xs_247);
        v_t_2411 = heff_abandon();
      }
    } else {
      heff_drop(v_xs_247);
      v_t_2411 = heff_abandon();
    }
    V v_t_2412 = heff_tr(heff_call(v_t_2411, 1, (V[]){heff_tag_n(TAG_LChunkSnoc, 2, (V[]){heff_dup(v_capture_241), heff_dup(v_before_244)})}));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_MkField: {
      V v_fty_2413 = heff_field(v_t_2412, 0);
      V v_fvalue_2414 = heff_field(v_t_2412, 1);
      V v_ru_24t_2412_24MkField = heff_take_reuse_n(v_t_2412, 3ULL, 2);
      V v_t_2418;
      switch (heff_tag_of(v_fvalue_2414)) {
      case TAG_Nothing: {
        V v_t_2415 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_intAdd(heff_dup(v_len_240), heff_dup(v_j_245))});
        v_t_2418 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2415, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2efieldTyAt_24cpr_lam0, 1, 1, (V[]){v_fty_2413}), NTAG(TAG_Nothing)));
        break;
      }
      case TAG_Just: {
        V v_v_2417 = heff_field(v_fvalue_2414, 0);
        heff_take_n(v_fvalue_2414, 1ULL, 1);
        heff_drop(v_fty_2413);
        v_t_2418 = v_v_2417;
        break;
      }
      default: heff_nomatch(v_fvalue_2414);
      }
      V v_t_2419 = heff_tag_at_n(v_ru_24t_2412_24MkField, TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
      V v_t_2420 = (g_heff_2eelab_2erules_2eappendP(heff_arrayToList(v_before_244), v_t_2419));
      V t_0 = v_len_240;
      V t_1 = v_capture_241;
      V t_2 = v_fieldTypes_242;
      V t_3 = v_i_243;
      V t_4 = heff_arrayFromList(v_t_2420);
      V t_5 = heff_intAdd(v_j_245, MK_INT(1LL));
      v_len_240 = t_0;
      v_capture_241 = t_1;
      v_fieldTypes_242 = t_2;
      v_i_243 = t_3;
      v_before_244 = t_4;
      v_j_245 = t_5;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2412)}});
    }
  } else {
    heff_drop(v_j_245);
    V v_xs_2421 = heff_get_n(v_fieldTypes_242, 2, 3);
    V v_t_2425;
    if (heff_intLe_c_lent(MK_INT(0LL), v_i_243, 1)) {
      if (heff_intLt_c(heff_dup(v_i_243), heff_arrayLength_lent(v_xs_2421, 0))) {
        V v_v_2424 = heff_arrayIndex_lent(v_xs_2421, v_i_243, 1);
        v_t_2425 = v_v_2424;
      } else {
        heff_drop(v_xs_2421);
        v_t_2425 = heff_abandon();
      }
    } else {
      heff_drop(v_xs_2421);
      v_t_2425 = heff_abandon();
    }
    V v_t_2426 = heff_tr(heff_call(v_t_2425, 1, (V[]){heff_tag_n(TAG_LChunkSnoc, 2, (V[]){v_capture_241, v_before_244})}));
    switch (heff_tag_of(v_t_2426)) {
    case TAG_MkField: {
      V v_fty_2427 = heff_field(v_t_2426, 0);
      heff_take_n(v_t_2426, 1ULL, 2);
      V v_t_2429 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_len_240, v_i_243), heff_dup(v_fty_2427)));
      V v_t_2430 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(MK_INT(0LL), v_t_2429));
      if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
        heff_drop(v_fty_2427);
        heff_drop(v_t_2430);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        heff_drop(v_t_2430);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_fty_2427}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2426)}});
    }
  }
}
V g_heff_2eelab_2erules_2efieldTyAt_24cpr_lam0(V self, V *args) {
  V v_u_2416 = args[0];
  V v_fty_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2416);
  return v_fty_2413;
}