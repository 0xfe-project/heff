// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_Right 62770
#define LBL_hash 9690581
#define LBL_path 9928940
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_version 583465758
static uint32_t shape_path__version__hash[] = {LBL_path, LBL_version, LBL_hash};
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_2ek_24l0_clo;
V g_list_2ekeepIf_24s1943838498x1969994910(V, V);
V g_list_2ekeepIf_24s1943838498x1969994910_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1943838498x1969994910_clo;
V g_list_2ekeepIf_24s537296923x1092827761(V, V);
V g_list_2ekeepIf_24s537296923x1092827761_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s537296923x1092827761_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
Clo g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_2ek_24l0_entry, 5, 0};

V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_2ek_24l0(V v_x_240, V v_root_241, V v_x_242, V v_k_243, V v_x_244) {
top: ;
  V v_require_245 = heff_take_field(v_root_241, 2);
  V v_replace_246 = heff_get_n(v_root_241, 3, 4);
  V v_path_247 = heff_take_field(v_x_240, 0);
  V v_version_248 = heff_get_n(v_x_240, 1, 3);
  switch (heff_tag_of(v_x_244)) {
  case TAG_Left: {
    heff_drop(v_version_248);
    V v_t_2410 = ({ V a_0 = v_path_247; V a_1 = v_require_245; V r_ = (g_list_2ekeepIf_24s1943838498x1969994910(a_0, a_1)); heff_drop(v_path_247); r_; });
    V v_x_2416;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nil: {
      heff_drop(v_replace_246);
      v_x_2416 = v_x_242;
      break;
    }
    case TAG_Cons: {
      V v_r_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 2);
      V v_t_2413 = (g_list_2ekeepIf_24s537296923x1092827761(v_r_2411, v_replace_246));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nil: {
        v_x_2416 = v_x_242;
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2413, 0ULL, 2);
        v_x_2416 = v_x_242;
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    return heff_tail(v_k_243, 1, (V[]){v_x_2416});
  }
  case TAG_Right: {
    V v_y_2417 = heff_field(v_x_244, 0);
    V v_t_2418 = (g_list_2ekeepIf_24s1943838498x1969994910(v_path_247, v_require_245));
    V v_x_2432;
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nil: {
      heff_drop(v_replace_246);
      V v_t_2419 = (g_prelude_2eskipSpaces(v_y_2417, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2420 = (heff_unbox_word(heff_strLength_lent(v_y_2417, 0)) - ((int64_t)1ULL));
      V v_t_2421 = (g_prelude_2eskipSpaces(v_y_2417, heff_box_word(v_t_2420), MK_INT(-1LL)));
      V v_t_2422 = heff_strSlice(heff_dup(v_y_2417), v_t_2419, heff_intAdd(v_t_2421, MK_INT(1LL)));
      v_x_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_path__version__hash, (V[]){v_path_247, v_version_248, v_t_2422}), v_x_242});
      break;
    }
    case TAG_Cons: {
      V v_r_2423 = heff_field(v_t_2418, 0);
      V v_ru_24t_2418_24Cons = heff_take_reuse_n(v_t_2418, 1ULL, 2);
      V v_t_2425 = (g_list_2ekeepIf_24s537296923x1092827761(v_r_2423, v_replace_246));
      switch (heff_tag_of(v_t_2425)) {
      case TAG_Nil: {
        V v_t_2426 = (g_prelude_2eskipSpaces(v_y_2417, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2427 = (heff_unbox_word(heff_strLength_lent(v_y_2417, 0)) - ((int64_t)1ULL));
        V v_t_2428 = (g_prelude_2eskipSpaces(v_y_2417, heff_box_word(v_t_2427), MK_INT(-1LL)));
        V v_t_2429 = heff_strSlice(heff_dup(v_y_2417), v_t_2426, heff_intAdd(v_t_2428, MK_INT(1LL)));
        v_x_2432 = heff_tag_at_n(v_ru_24t_2418_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_path__version__hash, (V[]){v_path_247, v_version_248, v_t_2429}), v_x_242});
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2425, 0ULL, 2);
        heff_drop(v_path_247);
        heff_drop(v_version_248);
        heff_drop_cell(v_ru_24t_2418_24Cons, 2);
        v_x_2432 = v_x_242;
        break;
      }
      default: heff_nomatch(v_t_2425);
      }
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    return heff_tail(v_k_243, 1, (V[]){v_x_2432});
  }
  default: return heff_nomatch(v_x_244);
  }
}
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_2ek_24l0(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}