// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsPath 63561
#define TAG_Arrived 9729
#define TAG_Attempt 14217
#define TAG_Await 41810
#define TAG_Closed 4831
#define TAG_Expected 48537
#define TAG_Gone 5826
#define TAG_Log 24016
#define TAG_Message 12631
#define TAG_Now 25954
#define TAG_PathUri 23459
#define TAG_ProjectFiles 9175
#define TAG_Quit 47258
#define TAG_Send 26077
#define TAG_Timeout 14063
#define TAG_UriPath 39251
#define TAG_Value 50841
#define TAG_Waited 38255
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_co_2eop_24s897039307x1692197561(V, V, V, V, V, V);
V g_co_2eop_24s897039307x1692197561_entry(V self, V *a);
extern Clo g_co_2eop_24s897039307x1692197561_clo;
V g_heff_2elsp_2erpc_2eawait_24s474875037x969107480(V, V);
V g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_entry(V self, V *a);
extern Clo g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_clo;
HeffT2 g_heff_2elsp_2erpc_2eeventOf_24cpr(V);
V g_heff_2elsp_2erpc_2erpc_get(void);
HeffT2 g_json_2esteps_24cpr(V, V);
V g_heff_2elsp_2erpc_2erpc_lam1(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam2(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam3(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam4(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam5(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam6(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam9(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam8(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam7(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam0(V self, V *args); static Clo g_heff_2elsp_2erpc_2erpc_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erpc_2erpc_lam0, 3, 0};
V g_heff_2elsp_2erpc_2erpc_lam12(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam11(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam10(V self, V *args); static Clo g_heff_2elsp_2erpc_2erpc_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erpc_2erpc_lam10, 4, 0};

static V g_heff_2elsp_2erpc_2erpc_val;
static HEFF_ONCE g_heff_2elsp_2erpc_2erpc_st;
static V g_heff_2elsp_2erpc_2erpc_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_heff_2elsp_2erpc_2erpc_lam0_clo), ((V)&g_heff_2elsp_2erpc_2erpc_lam10_clo)});
}
V g_heff_2elsp_2erpc_2erpc_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2erpc_2erpc_st)) return g_heff_2elsp_2erpc_2erpc_val;
  return heff_global(&g_heff_2elsp_2erpc_2erpc_val, &g_heff_2elsp_2erpc_2erpc_st, g_heff_2elsp_2erpc_2erpc_init);
}
V g_heff_2elsp_2erpc_2erpc_lam1(V self, V *args) {
  V v_e_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_call(v_k_244, 1, (V[]){v_e_245}));
  V f_ = v_g_241;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam2(V self, V *args) {
  V v_n_2414 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_call(v_k_2413, 1, (V[]){v_n_2414}));
  V f_ = v_g_241;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam3(V self, V *args) {
  V v_fs_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tr(heff_call(v_k_2417, 1, (V[]){v_fs_2418}));
  V f_ = v_g_241;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam4(V self, V *args) {
  V v_p_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_tr(heff_call(v_k_2421, 1, (V[]){v_p_2422}));
  V f_ = v_g_241;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam5(V self, V *args) {
  V v_u_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_tr(heff_call(v_k_2425, 1, (V[]){v_u_2426}));
  V f_ = v_g_241;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam6(V self, V *args) {
  V v_a_2430 = args[0];
  V v_k_2429 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_tr(heff_call(v_k_2429, 1, (V[]){v_a_2430}));
  V f_ = v_g_241;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam9(V self, V *args) {
  V v_v_2436 = args[0];
  V v_k_2435 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = heff_tr(heff_call(v_k_2435, 1, (V[]){v_v_2436}));
  V f_ = v_g_241;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam8(V self, V *args) {
  V v_c_2434 = args[0];
  V v_k_2435 = args[1];
  V v_use_2433 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_use_2433;
  args[0] = v_c_2434;
  args[1] = heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam9, 1, 2, (V[]){v_k_2435, v_g_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erpc_2erpc_lam7(V self, V *args) {
  V v_use_2433 = args[0];
  V v_b_2432 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_b_2432;
  args[0] = heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam8, 2, 2, (V[]){v_use_2433, v_g_241});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Await: {
    V v_t_243 = heff_field(v_p_242, 0);
    V v_k_244 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Await = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Await, TAG_Await, 2, (V[]){v_t_243, heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam1, 1, 2, (V[]){v_k_244, v_g_241})});
  }
  case TAG_Send: {
    V v_s_247 = heff_field(v_p_242, 0);
    V v_x_248 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Send = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_249 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_248}));
    return heff_tag_at_n(v_ru_24p_242_24Send, TAG_Send, 2, (V[]){v_s_247, v_t_249});
  }
  case TAG_Log: {
    V v_s_2410 = heff_field(v_p_242, 0);
    V v_x_2411 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Log = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2412 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2411}));
    return heff_tag_at_n(v_ru_24p_242_24Log, TAG_Log, 2, (V[]){v_s_2410, v_t_2412});
  }
  case TAG_Now: {
    V v_k_2413 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Now = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Now, TAG_Now, 1, (V[]){heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam2, 1, 2, (V[]){v_k_2413, v_g_241})});
  }
  case TAG_ProjectFiles: {
    V v_r_2416 = heff_field(v_p_242, 0);
    V v_k_2417 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ProjectFiles = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24ProjectFiles, TAG_ProjectFiles, 2, (V[]){v_r_2416, heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam3, 1, 2, (V[]){v_k_2417, v_g_241})});
  }
  case TAG_UriPath: {
    V v_u_2420 = heff_field(v_p_242, 0);
    V v_k_2421 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24UriPath = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24UriPath, TAG_UriPath, 2, (V[]){v_u_2420, heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam4, 1, 2, (V[]){v_k_2421, v_g_241})});
  }
  case TAG_PathUri: {
    V v_p_2424 = heff_field(v_p_242, 0);
    V v_k_2425 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24PathUri = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24PathUri, TAG_PathUri, 2, (V[]){v_p_2424, heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam5, 1, 2, (V[]){v_k_2425, v_g_241})});
  }
  case TAG_AbsPath: {
    V v_p_2428 = heff_field(v_p_242, 0);
    V v_k_2429 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24AbsPath = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24AbsPath, TAG_AbsPath, 2, (V[]){v_p_2428, heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam6, 1, 2, (V[]){v_k_2429, v_g_241})});
  }
  case TAG_Attempt: {
    V v_b_2432 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Attempt = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Attempt, TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam7, 1, 2, (V[]){v_b_2432, v_g_241})});
  }
  case TAG_Quit: {
    V v_c_2438 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Quit = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_g_241);
    return heff_tag_at_n(v_ru_24p_242_24Quit, TAG_Quit, 1, (V[]){v_c_2438});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_heff_2elsp_2erpc_2erpc_lam12(V self, V *args) {
  V v_c_2460 = args[0];
  V v_k_2461 = args[1];
  V v_nt_2441 = heff_env(self)[0];
  V v_use_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2462 = heff_tr(heff_call(v_nt_2441, 1, (V[]){v_c_2460}));
  V f_ = v_use_2459;
  args[0] = v_t_2462;
  args[1] = v_k_2461;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erpc_2erpc_lam11(V self, V *args) {
  V v_use_2459 = args[0];
  V v_b_2458 = heff_env(self)[0];
  V v_nt_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_b_2458;
  args[0] = heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam12, 2, 2, (V[]){v_nt_2441, v_use_2459});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam10(V self, V *args) {
  V v_m_2439 = args[0];
  V v_n_2440 = args[1];
  V v_nt_2441 = args[2];
  V v_p_2442 = args[3];
  heff_drop(v_m_2439);
  heff_drop(v_n_2440);
  switch (heff_tag_of(v_p_2442)) {
  case TAG_Await: {
    V v_t_2443 = heff_field(v_p_2442, 0);
    V v_k_2444 = heff_field(v_p_2442, 1);
    V v_ru_24p_2442_24Await = heff_take_reuse_n(v_p_2442, 3ULL, 2);
    heff_drop(v_nt_2441);
    return heff_tag_at_n(v_ru_24p_2442_24Await, TAG_Await, 2, (V[]){v_t_2443, v_k_2444});
  }
  case TAG_Send: {
    V v_s_2445 = heff_field(v_p_2442, 0);
    V v_x_2446 = heff_field(v_p_2442, 1);
    V v_ru_24p_2442_24Send = heff_take_reuse_n(v_p_2442, 3ULL, 2);
    heff_drop(v_nt_2441);
    return heff_tag_at_n(v_ru_24p_2442_24Send, TAG_Send, 2, (V[]){v_s_2445, v_x_2446});
  }
  case TAG_Log: {
    V v_s_2447 = heff_field(v_p_2442, 0);
    V v_x_2448 = heff_field(v_p_2442, 1);
    V v_ru_24p_2442_24Log = heff_take_reuse_n(v_p_2442, 3ULL, 2);
    heff_drop(v_nt_2441);
    return heff_tag_at_n(v_ru_24p_2442_24Log, TAG_Log, 2, (V[]){v_s_2447, v_x_2448});
  }
  case TAG_Now: {
    V v_k_2449 = heff_field(v_p_2442, 0);
    V v_ru_24p_2442_24Now = heff_take_reuse_n(v_p_2442, 1ULL, 1);
    heff_drop(v_nt_2441);
    return heff_tag_at_n(v_ru_24p_2442_24Now, TAG_Now, 1, (V[]){v_k_2449});
  }
  case TAG_ProjectFiles: {
    V v_r_2450 = heff_field(v_p_2442, 0);
    V v_k_2451 = heff_field(v_p_2442, 1);
    V v_ru_24p_2442_24ProjectFiles = heff_take_reuse_n(v_p_2442, 3ULL, 2);
    heff_drop(v_nt_2441);
    return heff_tag_at_n(v_ru_24p_2442_24ProjectFiles, TAG_ProjectFiles, 2, (V[]){v_r_2450, v_k_2451});
  }
  case TAG_UriPath: {
    V v_u_2452 = heff_field(v_p_2442, 0);
    V v_k_2453 = heff_field(v_p_2442, 1);
    V v_ru_24p_2442_24UriPath = heff_take_reuse_n(v_p_2442, 3ULL, 2);
    heff_drop(v_nt_2441);
    return heff_tag_at_n(v_ru_24p_2442_24UriPath, TAG_UriPath, 2, (V[]){v_u_2452, v_k_2453});
  }
  case TAG_PathUri: {
    V v_p_2454 = heff_field(v_p_2442, 0);
    V v_k_2455 = heff_field(v_p_2442, 1);
    V v_ru_24p_2442_24PathUri = heff_take_reuse_n(v_p_2442, 3ULL, 2);
    heff_drop(v_nt_2441);
    return heff_tag_at_n(v_ru_24p_2442_24PathUri, TAG_PathUri, 2, (V[]){v_p_2454, v_k_2455});
  }
  case TAG_AbsPath: {
    V v_p_2456 = heff_field(v_p_2442, 0);
    V v_k_2457 = heff_field(v_p_2442, 1);
    V v_ru_24p_2442_24AbsPath = heff_take_reuse_n(v_p_2442, 3ULL, 2);
    heff_drop(v_nt_2441);
    return heff_tag_at_n(v_ru_24p_2442_24AbsPath, TAG_AbsPath, 2, (V[]){v_p_2456, v_k_2457});
  }
  case TAG_Attempt: {
    V v_b_2458 = heff_field(v_p_2442, 0);
    V v_ru_24p_2442_24Attempt = heff_take_reuse_n(v_p_2442, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_2442_24Attempt, TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam11, 1, 2, (V[]){v_b_2458, v_nt_2441})});
  }
  case TAG_Quit: {
    V v_c_2463 = heff_field(v_p_2442, 0);
    V v_ru_24p_2442_24Quit = heff_take_reuse_n(v_p_2442, 1ULL, 1);
    heff_drop(v_nt_2441);
    return heff_tag_at_n(v_ru_24p_2442_24Quit, TAG_Quit, 1, (V[]){v_c_2463});
  }
  default: return heff_nomatch(v_p_2442);
  }
}
HEFF_LIT(g_heff_2elsp_2erpc_2eeventOf_24cpr_str0, 11, ": expected ");
HEFF_LIT(g_heff_2elsp_2erpc_2eeventOf_24cpr_str1, 8, "at byte ");

HeffT2 g_heff_2elsp_2erpc_2eeventOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Arrived: {
    V v_body_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Arrived = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_242 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
    HeffT2 v_t_243 = ({ V a_0 = v_body_241; V a_1 = v_t_242; HeffT2 r_ = (g_json_2esteps_24cpr(a_0, a_1)); heff_drop(v_body_241); r_; });
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x1_240_24Arrived, 1);
        V v_x_247 = v_field_245;
        V v_f_2411;
        switch (heff_tag_of(v_x_247)) {
        case TAG_Expected: {
          V v_i_248 = heff_field(v_x_247, 0);
          V v_what_249 = heff_field(v_x_247, 1);
          heff_take_n(v_x_247, 3ULL, 2);
          V v_t_2410 = heff_strAppend(heff_intShow(v_i_248), heff_strAppend(((V)&g_heff_2elsp_2erpc_2eeventOf_24cpr_str0), v_what_249));
          v_f_2411 = heff_strAppend(((V)&g_heff_2elsp_2erpc_2eeventOf_24cpr_str1), v_t_2410);
          break;
        }
        default: heff_nomatch(v_x_247);
        }
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2411}});
      } else {
        V v_y_2412 = v_field_245;
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x1_240_24Arrived, TAG_Message, 1, (V[]){v_y_2412})}});
      }
    }
  }
  case TAG_Waited: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Timeout)}});
  }
  case TAG_Gone: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Closed)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_str0, 10, "not JSON, ");
V g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_lam0(V self, V *args); static Clo g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_lam0, 1, 0};
V g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_lam2(V self, V *args);
V g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_lam1(V self, V *args);
Clo g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_entry, 2, 0};

V g_heff_2elsp_2erpc_2eawait_24s474875037x969107480(V v_ev_240, V v_ms_241) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_ms_241)) {
  case TAG_Nothing: {
    v_t_243 = MK_INT(-1LL);
    break;
  }
  case TAG_Just: {
    V v_x_242 = heff_field(v_ms_241, 0);
    v_t_243 = heff_dup(v_x_242);
    break;
  }
  default: heff_nomatch(v_ms_241);
  }
  V v_t_245 = heff_tr(heff_call(heff_dup(v_ev_240), 1, (V[]){heff_tag_n(TAG_Await, 2, (V[]){v_t_243, ((V)&g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_lam0_clo)})}));
  return heff_clo_n(g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_lam1, 2, 3, (V[]){v_t_245, v_ev_240, heff_dup(v_ms_241)});
}
V g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2erpc_2eawait_24s474875037x969107480(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_lam0(V self, V *args) {
  V v_x_244 = args[0];
  return v_x_244;
}
V g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_ev_240 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_249 = (g_heff_2elsp_2erpc_2eeventOf_24cpr(v_x_248));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_x_2413 = v_field_2411;
      V v_t_2414 = heff_tag_n(TAG_Log, 2, (V[]){heff_strAppend(((V)&g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_str0), v_x_2413), NTAG(TAG_MkUnit)});
      V v_t_2415 = heff_tr(heff_call(heff_dup(v_ev_240), 1, (V[]){v_t_2414}));
      return ({ V a_0 = v_ev_240; V a_1 = v_ms_241; V a_2 = heff_dup(v_hd_246); V a_3 = v_k_247; V a_4 = v_t_2415; V a_5 = v_hd_246; V r_ = (g_co_2eop_24s897039307x1692197561(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_ms_241); r_; });
    } else {
      heff_drop(v_ev_240);
      heff_drop(v_ms_241);
      heff_drop(v_hd_246);
      V v_y_2416 = v_field_2411;
      V f_ = v_k_247;
      args[0] = v_y_2416;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_t_245 = heff_env(self)[0];
  V v_ev_240 = heff_env(self)[1];
  V v_ms_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s495635622x733177935(v_t_245, heff_dup(v_hd_246), heff_clo_n(g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_lam2, 1, 4, (V[]){v_ev_240, v_ms_241, v_hd_246, v_k_247})));
}