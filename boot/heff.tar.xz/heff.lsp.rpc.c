// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsPath 63561
#define TAG_Arrived 9729
#define TAG_Attempt 14217
#define TAG_Await 41810
#define TAG_Catch 6517
#define TAG_Closed 4831
#define TAG_Expected 48537
#define TAG_Gone 5826
#define TAG_Left 13886
#define TAG_Log 24016
#define TAG_Message 12631
#define TAG_Now 25954
#define TAG_PathUri 23459
#define TAG_ProjectFiles 9175
#define TAG_Quit 47258
#define TAG_Right 62770
#define TAG_Send 26077
#define TAG_Throw 56084
#define TAG_Timeout 14063
#define TAG_UriPath 39251
#define TAG_Value 50841
#define TAG_Waited 38255
#define LBL_bind 9519364
#define LBL_fmap 9641981
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_malg 9839318
#define LBL_ret 322331
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_co_2e_3c_2b_3e_24s373441151x488264545_get(void);
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877(V, V, V);
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_entry(V self, V *a);
extern Clo g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_clo;
V g_heff_2elsp_2erpc_2erpc_get(void);
HeffT2 g_json_2esteps_24cpr(V, V);
V g_heff_2elsp_2erpc_2erpc_lam1(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam2(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam3(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam4(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam5(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam6(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam9(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam8(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam7(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam0(V self, V *args); static Clo g_heff_2elsp_2erpc_2erpc_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erpc_2erpc_lam0, 3, 0};
V g_heff_2elsp_2erpc_2erpc_lam12(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam11(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam10(V self, V *args); static Clo g_heff_2elsp_2erpc_2erpc_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erpc_2erpc_lam10, 4, 0};

static V g_heff_2elsp_2erpc_2erpc_val;
static HEFF_ONCE g_heff_2elsp_2erpc_2erpc_st;
static V g_heff_2elsp_2erpc_2erpc_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_heff_2elsp_2erpc_2erpc_lam0_clo), ((V)&g_heff_2elsp_2erpc_2erpc_lam10_clo)});
}
V g_heff_2elsp_2erpc_2erpc_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2erpc_2erpc_st)) return g_heff_2elsp_2erpc_2erpc_val;
  return heff_global(&g_heff_2elsp_2erpc_2erpc_val, &g_heff_2elsp_2erpc_2erpc_st, g_heff_2elsp_2erpc_2erpc_init);
}
V g_heff_2elsp_2erpc_2erpc_lam1(V self, V *args) {
  V v_e_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_call(v_k_244, 1, (V[]){v_e_245}));
  V f_ = v_g_241;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam2(V self, V *args) {
  V v_n_2414 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_call(v_k_2413, 1, (V[]){v_n_2414}));
  V f_ = v_g_241;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam3(V self, V *args) {
  V v_fs_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tr(heff_call(v_k_2417, 1, (V[]){v_fs_2418}));
  V f_ = v_g_241;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam4(V self, V *args) {
  V v_p_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_tr(heff_call(v_k_2421, 1, (V[]){v_p_2422}));
  V f_ = v_g_241;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam5(V self, V *args) {
  V v_u_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_tr(heff_call(v_k_2425, 1, (V[]){v_u_2426}));
  V f_ = v_g_241;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam6(V self, V *args) {
  V v_a_2430 = args[0];
  V v_k_2429 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_tr(heff_call(v_k_2429, 1, (V[]){v_a_2430}));
  V f_ = v_g_241;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam9(V self, V *args) {
  V v_v_2436 = args[0];
  V v_k_2435 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = heff_tr(heff_call(v_k_2435, 1, (V[]){v_v_2436}));
  V f_ = v_g_241;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam8(V self, V *args) {
  V v_c_2434 = args[0];
  V v_k_2435 = args[1];
  V v_use_2433 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_use_2433;
  args[0] = v_c_2434;
  args[1] = heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam9, 1, 2, (V[]){v_k_2435, v_g_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erpc_2erpc_lam7(V self, V *args) {
  V v_use_2433 = args[0];
  V v_b_2432 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_b_2432;
  args[0] = heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam8, 2, 2, (V[]){v_use_2433, v_g_241});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Await: {
    V v_t_243 = heff_field(v_p_242, 0);
    V v_k_244 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Await = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Await, TAG_Await, 2, (V[]){v_t_243, heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam1, 1, 2, (V[]){v_k_244, v_g_241})});
  }
  case TAG_Send: {
    V v_s_247 = heff_field(v_p_242, 0);
    V v_x_248 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Send = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_249 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_248}));
    return heff_tag_at_n(v_ru_24p_242_24Send, TAG_Send, 2, (V[]){v_s_247, v_t_249});
  }
  case TAG_Log: {
    V v_s_2410 = heff_field(v_p_242, 0);
    V v_x_2411 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Log = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2412 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2411}));
    return heff_tag_at_n(v_ru_24p_242_24Log, TAG_Log, 2, (V[]){v_s_2410, v_t_2412});
  }
  case TAG_Now: {
    V v_k_2413 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Now = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Now, TAG_Now, 1, (V[]){heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam2, 1, 2, (V[]){v_k_2413, v_g_241})});
  }
  case TAG_ProjectFiles: {
    V v_r_2416 = heff_field(v_p_242, 0);
    V v_k_2417 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ProjectFiles = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24ProjectFiles, TAG_ProjectFiles, 2, (V[]){v_r_2416, heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam3, 1, 2, (V[]){v_k_2417, v_g_241})});
  }
  case TAG_UriPath: {
    V v_u_2420 = heff_field(v_p_242, 0);
    V v_k_2421 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24UriPath = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24UriPath, TAG_UriPath, 2, (V[]){v_u_2420, heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam4, 1, 2, (V[]){v_k_2421, v_g_241})});
  }
  case TAG_PathUri: {
    V v_p_2424 = heff_field(v_p_242, 0);
    V v_k_2425 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24PathUri = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24PathUri, TAG_PathUri, 2, (V[]){v_p_2424, heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam5, 1, 2, (V[]){v_k_2425, v_g_241})});
  }
  case TAG_AbsPath: {
    V v_p_2428 = heff_field(v_p_242, 0);
    V v_k_2429 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24AbsPath = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24AbsPath, TAG_AbsPath, 2, (V[]){v_p_2428, heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam6, 1, 2, (V[]){v_k_2429, v_g_241})});
  }
  case TAG_Attempt: {
    V v_b_2432 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Attempt = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Attempt, TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam7, 1, 2, (V[]){v_b_2432, v_g_241})});
  }
  case TAG_Quit: {
    V v_c_2438 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Quit = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_g_241);
    return heff_tag_at_n(v_ru_24p_242_24Quit, TAG_Quit, 1, (V[]){v_c_2438});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_heff_2elsp_2erpc_2erpc_lam12(V self, V *args) {
  V v_c_2460 = args[0];
  V v_k_2461 = args[1];
  V v_nt_2441 = heff_env(self)[0];
  V v_use_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2462 = heff_tr(heff_call(v_nt_2441, 1, (V[]){v_c_2460}));
  V f_ = v_use_2459;
  args[0] = v_t_2462;
  args[1] = v_k_2461;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erpc_2erpc_lam11(V self, V *args) {
  V v_use_2459 = args[0];
  V v_b_2458 = heff_env(self)[0];
  V v_nt_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_b_2458;
  args[0] = heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam12, 2, 2, (V[]){v_nt_2441, v_use_2459});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam10(V self, V *args) {
  V v_m_2439 = args[0];
  V v_n_2440 = args[1];
  V v_nt_2441 = args[2];
  V v_p_2442 = args[3];
  heff_drop(v_m_2439);
  heff_drop(v_n_2440);
  switch (heff_tag_of(v_p_2442)) {
  case TAG_Await: {
    V v_t_2443 = heff_field(v_p_2442, 0);
    V v_k_2444 = heff_field(v_p_2442, 1);
    V v_ru_24p_2442_24Await = heff_take_reuse_n(v_p_2442, 3ULL, 2);
    heff_drop(v_nt_2441);
    return heff_tag_at_n(v_ru_24p_2442_24Await, TAG_Await, 2, (V[]){v_t_2443, v_k_2444});
  }
  case TAG_Send: {
    V v_s_2445 = heff_field(v_p_2442, 0);
    V v_x_2446 = heff_field(v_p_2442, 1);
    V v_ru_24p_2442_24Send = heff_take_reuse_n(v_p_2442, 3ULL, 2);
    heff_drop(v_nt_2441);
    return heff_tag_at_n(v_ru_24p_2442_24Send, TAG_Send, 2, (V[]){v_s_2445, v_x_2446});
  }
  case TAG_Log: {
    V v_s_2447 = heff_field(v_p_2442, 0);
    V v_x_2448 = heff_field(v_p_2442, 1);
    V v_ru_24p_2442_24Log = heff_take_reuse_n(v_p_2442, 3ULL, 2);
    heff_drop(v_nt_2441);
    return heff_tag_at_n(v_ru_24p_2442_24Log, TAG_Log, 2, (V[]){v_s_2447, v_x_2448});
  }
  case TAG_Now: {
    V v_k_2449 = heff_field(v_p_2442, 0);
    V v_ru_24p_2442_24Now = heff_take_reuse_n(v_p_2442, 1ULL, 1);
    heff_drop(v_nt_2441);
    return heff_tag_at_n(v_ru_24p_2442_24Now, TAG_Now, 1, (V[]){v_k_2449});
  }
  case TAG_ProjectFiles: {
    V v_r_2450 = heff_field(v_p_2442, 0);
    V v_k_2451 = heff_field(v_p_2442, 1);
    V v_ru_24p_2442_24ProjectFiles = heff_take_reuse_n(v_p_2442, 3ULL, 2);
    heff_drop(v_nt_2441);
    return heff_tag_at_n(v_ru_24p_2442_24ProjectFiles, TAG_ProjectFiles, 2, (V[]){v_r_2450, v_k_2451});
  }
  case TAG_UriPath: {
    V v_u_2452 = heff_field(v_p_2442, 0);
    V v_k_2453 = heff_field(v_p_2442, 1);
    V v_ru_24p_2442_24UriPath = heff_take_reuse_n(v_p_2442, 3ULL, 2);
    heff_drop(v_nt_2441);
    return heff_tag_at_n(v_ru_24p_2442_24UriPath, TAG_UriPath, 2, (V[]){v_u_2452, v_k_2453});
  }
  case TAG_PathUri: {
    V v_p_2454 = heff_field(v_p_2442, 0);
    V v_k_2455 = heff_field(v_p_2442, 1);
    V v_ru_24p_2442_24PathUri = heff_take_reuse_n(v_p_2442, 3ULL, 2);
    heff_drop(v_nt_2441);
    return heff_tag_at_n(v_ru_24p_2442_24PathUri, TAG_PathUri, 2, (V[]){v_p_2454, v_k_2455});
  }
  case TAG_AbsPath: {
    V v_p_2456 = heff_field(v_p_2442, 0);
    V v_k_2457 = heff_field(v_p_2442, 1);
    V v_ru_24p_2442_24AbsPath = heff_take_reuse_n(v_p_2442, 3ULL, 2);
    heff_drop(v_nt_2441);
    return heff_tag_at_n(v_ru_24p_2442_24AbsPath, TAG_AbsPath, 2, (V[]){v_p_2456, v_k_2457});
  }
  case TAG_Attempt: {
    V v_b_2458 = heff_field(v_p_2442, 0);
    V v_ru_24p_2442_24Attempt = heff_take_reuse_n(v_p_2442, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_2442_24Attempt, TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam11, 1, 2, (V[]){v_b_2458, v_nt_2441})});
  }
  case TAG_Quit: {
    V v_c_2463 = heff_field(v_p_2442, 0);
    V v_ru_24p_2442_24Quit = heff_take_reuse_n(v_p_2442, 1ULL, 1);
    heff_drop(v_nt_2441);
    return heff_tag_at_n(v_ru_24p_2442_24Quit, TAG_Quit, 1, (V[]){v_c_2463});
  }
  default: return heff_nomatch(v_p_2442);
  }
}
HEFF_LIT(g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_str0, 8, "at byte ");
HEFF_LIT(g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_str1, 11, ": expected ");
HEFF_LIT(g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_str2, 10, "not JSON, ");
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam0(V self, V *args); static Clo g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam0, 1, 0};
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam2(V self, V *args);
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam4(V self, V *args);
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam3(V self, V *args); static Clo g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam3, 4, 0};
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam6(V self, V *args);
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam5(V self, V *args);
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam7(V self, V *args);
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam8(V self, V *args);
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam1(V self, V *args);
Clo g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_entry, 3, 0};

V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877(V v_ms_240, V v_p_241, V v_p_242) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_ms_240)) {
  case TAG_Nothing: {
    v_t_244 = MK_INT(-1LL);
    break;
  }
  case TAG_Just: {
    V v_x_243 = heff_dup(heff_field(v_ms_240, 0));
    v_t_244 = v_x_243;
    break;
  }
  default: heff_nomatch(v_ms_240);
  }
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Await, 2, (V[]){v_t_244, ((V)&g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam0_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})}));
  return heff_tail(heff_dup(heff_rfield(v_p_241, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam1, 1, 3, (V[]){v_ms_240, v_p_241, v_p_242})});
}
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erpc_2eawait_24s696017795x59635877(a[0], a[1], a[2]);
}
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam0(V self, V *args) {
  V v_x_245 = args[0];
  return v_x_245;
}
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam2(V self, V *args) {
  V v_s_2442 = args[0];
  V v_h_2440 = heff_env(self)[0];
  V v_hd_2436 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2443 = heff_tr(heff_call(v_h_2440, 1, (V[]){v_s_2442}));
  V f_ = v_c_2443;
  heff_room[0] = heff_dup(v_hd_2436);
  heff_room[1] = heff_get_n(v_hd_2436, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam4(V self, V *args) {
  V v_x_2450 = args[0];
  V v_g_2446 = heff_env(self)[0];
  V v_k_2449 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2451 = heff_tr(heff_call(v_g_2446, 1, (V[]){v_x_2450}));
  V f_ = v_k_2449;
  args[0] = v_x_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam3(V self, V *args) {
  V v_g_2446 = args[0];
  V v_c_2447 = args[1];
  V v_hd_2448 = args[2];
  V v_k_2449 = args[3];
  V f_ = v_c_2447;
  args[0] = v_hd_2448;
  args[1] = heff_clo_n(g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam4, 1, 2, (V[]){v_g_2446, v_k_2449});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam6(V self, V *args) {
  V v_x_2454 = args[0];
  V v_g_2452 = heff_env(self)[0];
  V v_hd_2436 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2455 = heff_tr(heff_call(v_g_2452, 1, (V[]){v_x_2454}));
  V f_ = heff_get_n(v_hd_2436, 0, 3);
  args[0] = v_t_2455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam5(V self, V *args) {
  V v_g_2452 = args[0];
  V v_m_2453 = args[1];
  V v_hd_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_2436, 1));
  args[0] = v_m_2453;
  args[1] = heff_clo_n(g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam6, 1, 2, (V[]){v_g_2452, v_hd_2436});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam7(V self, V *args) {
  V v_c_2456 = args[0];
  V v_hd_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2456;
  heff_room[0] = heff_dup(v_hd_2436);
  heff_room[1] = heff_get_n(v_hd_2436, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam8(V self, V *args) {
  V v_a_2460 = args[0];
  V v_lit_2427 = heff_env(self)[0];
  V v_lit_2428 = heff_env(self)[1];
  V v_lit_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_a_2460);
  return (g_heff_2elsp_2erpc_2eawait_24s696017795x59635877(v_lit_2427, v_lit_2428, v_lit_2429));
}
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_ms_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_2413 = v_x_2412;
  V v_x3_2425;
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_Arrived: {
    V v_body_2414 = heff_field(v_x1_2413, 0);
    V v_ru_24x1_2413_24Arrived = heff_take_reuse_n(v_x1_2413, 1ULL, 1);
    V v_t_2415 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
    HeffT2 v_t_2416 = (g_json_2esteps_24cpr(v_body_2414, v_t_2415));
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        V v_x_2419 = v_field_2418;
        V v_t_2423;
        switch (heff_tag_of(v_x_2419)) {
        case TAG_Expected: {
          V v_i_2420 = heff_field(v_x_2419, 0);
          V v_what_2421 = heff_field(v_x_2419, 1);
          heff_take_n(v_x_2419, 3ULL, 2);
          V v_t_2422 = heff_strAppend(((V)&g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_str0), heff_intShow(v_i_2420));
          v_t_2423 = heff_strAppend(heff_strAppend(v_t_2422, ((V)&g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_str1)), v_what_2421);
          break;
        }
        default: heff_nomatch(v_x_2419);
        }
        v_x3_2425 = heff_tag_at_n(v_ru_24x1_2413_24Arrived, TAG_Left, 1, (V[]){v_t_2423});
      } else {
        V v_y_2424 = v_field_2418;
        v_x3_2425 = heff_tag_at_n(v_ru_24x1_2413_24Arrived, TAG_Right, 1, (V[]){heff_tag_n(TAG_Message, 1, (V[]){v_y_2424})});
      }
    }
    break;
  }
  case TAG_Waited: {
    v_x3_2425 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Timeout)});
    break;
  }
  case TAG_Gone: {
    v_x3_2425 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Closed)});
    break;
  }
  default: heff_nomatch(v_x1_2413);
  }
  switch (heff_tag_of(v_x3_2425)) {
  case TAG_Left: {
    V v_x_2426 = heff_field(v_x3_2425, 0);
    V v_ru_24x3_2425_24Left = heff_take_reuse_n(v_x3_2425, 1ULL, 1);
    V v_lit_2427 = v_ms_240;
    V v_lit_2428 = heff_dup(v_p_241);
    V v_lit_2429 = v_p_242;
    V v_t_2430 = heff_tag_n(TAG_Log, 2, (V[]){heff_strAppend(((V)&g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_str2), v_x_2426), NTAG(TAG_MkUnit)});
    V v_t_2431 = heff_tag_at_n(v_ru_24x3_2425_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_p_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
    V v_hd_2436 = v_p_241;
    V v_t_2458;
    switch (heff_tag_of(v_p_2435)) {
    case TAG_InL: {
      V v_x_2437 = heff_field(v_p_2435, 0);
      V v_ru_24p_2435_24InL = heff_take_reuse_n(v_p_2435, 1ULL, 1);
      V v_t_2444;
      switch (heff_tag_of(v_x_2437)) {
      case TAG_Throw: {
        V v_s_2438 = heff_field(v_x_2437, 0);
        V v_ru_24x_2437_24Throw = heff_take_reuse_n(v_x_2437, 1ULL, 1);
        v_t_2444 = heff_tag_at_n(v_ru_24x_2437_24Throw, TAG_Throw, 1, (V[]){v_s_2438});
        break;
      }
      case TAG_Catch: {
        V v_c_2439 = heff_field(v_x_2437, 0);
        V v_h_2440 = heff_field(v_x_2437, 1);
        V v_ru_24x_2437_24Catch = heff_take_reuse_n(v_x_2437, 3ULL, 2);
        V v_t_2441 = heff_tr(heff_call(v_c_2439, 2, (V[]){heff_dup(v_hd_2436), heff_dup(heff_rfield(v_hd_2436, 0))}));
        v_t_2444 = heff_tag_at_n(v_ru_24x_2437_24Catch, TAG_Catch, 2, (V[]){v_t_2441, heff_clo_n(g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam2, 1, 2, (V[]){v_h_2440, heff_dup(v_hd_2436)})});
        break;
      }
      default: heff_nomatch(v_x_2437);
      }
      v_t_2458 = heff_tag_at_n(v_ru_24p_2435_24InL, TAG_InL, 1, (V[]){v_t_2444});
      break;
    }
    case TAG_InR: {
      V v_y_2445 = heff_field(v_p_2435, 0);
      V v_ru_24p_2435_24InR = heff_take_reuse_n(v_p_2435, 1ULL, 1);
      V v_t_2457 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam3_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam5, 2, 1, (V[]){heff_dup(v_hd_2436)})}), heff_clo_n(g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam7, 1, 1, (V[]){heff_dup(v_hd_2436)}), v_y_2445}));
      v_t_2458 = heff_tag_at_n(v_ru_24p_2435_24InR, TAG_InR, 1, (V[]){v_t_2457});
      break;
    }
    default: heff_nomatch(v_p_2435);
    }
    V v_t_2459 = heff_tr(heff_call(heff_take_field(v_hd_2436, 2), 1, (V[]){v_t_2458}));
    V f_ = heff_get_n(v_hd_2436, 1, 3);
    heff_room[0] = v_t_2459;
    heff_room[1] = heff_clo_n(g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_lam8, 1, 3, (V[]){v_lit_2427, v_lit_2428, v_lit_2429});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2461 = heff_field(v_x3_2425, 0);
    heff_take_n(v_x3_2425, 1ULL, 1);
    heff_drop(v_ms_240);
    heff_drop_rec(v_p_241, 3);
    V f_ = v_p_242;
    args[0] = v_y_2461;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x3_2425);
  }
}