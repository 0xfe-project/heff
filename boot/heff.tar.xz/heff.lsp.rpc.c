// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsPath 63561
#define TAG_Await 41810
#define TAG_Log 24016
#define TAG_Now 25954
#define TAG_PathUri 23459
#define TAG_ProjectFiles 9175
#define TAG_Quit 47258
#define TAG_Send 26077
#define TAG_UriPath 39251
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_heff_2elsp_2erpc_2erpc_get(void);
V g_heff_2elsp_2erpc_2erpc_lam1(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam2(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam3(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam4(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam5(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam6(V self, V *args);
V g_heff_2elsp_2erpc_2erpc_lam0(V self, V *args); static Clo g_heff_2elsp_2erpc_2erpc_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erpc_2erpc_lam0, 3, 0};
V g_heff_2elsp_2erpc_2erpc_lam7(V self, V *args); static Clo g_heff_2elsp_2erpc_2erpc_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erpc_2erpc_lam7, 4, 0};

static V g_heff_2elsp_2erpc_2erpc_val;
static int g_heff_2elsp_2erpc_2erpc_st;
static V g_heff_2elsp_2erpc_2erpc_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_heff_2elsp_2erpc_2erpc_lam0_clo), ((V)&g_heff_2elsp_2erpc_2erpc_lam7_clo)});
}
V g_heff_2elsp_2erpc_2erpc_get(void) {
  if (g_heff_2elsp_2erpc_2erpc_st == 2) return g_heff_2elsp_2erpc_2erpc_val;
  if (g_heff_2elsp_2erpc_2erpc_st == 1) heff_fail("defined by itself");
  g_heff_2elsp_2erpc_2erpc_st = 1;
  g_heff_2elsp_2erpc_2erpc_val = heff_tr(g_heff_2elsp_2erpc_2erpc_init());
  g_heff_2elsp_2erpc_2erpc_st = 2;
  return g_heff_2elsp_2erpc_2erpc_val;
}
V g_heff_2elsp_2erpc_2erpc_lam1(V self, V *args) {
  V v_e_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_apply(v_k_244, 1, (V[]){v_e_245}));
  V f_ = v_g_241;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam2(V self, V *args) {
  V v_n_2414 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_apply(v_k_2413, 1, (V[]){v_n_2414}));
  V f_ = v_g_241;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam3(V self, V *args) {
  V v_fs_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tr(heff_apply(v_k_2417, 1, (V[]){v_fs_2418}));
  V f_ = v_g_241;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam4(V self, V *args) {
  V v_p_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_tr(heff_apply(v_k_2421, 1, (V[]){v_p_2422}));
  V f_ = v_g_241;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam5(V self, V *args) {
  V v_u_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_tr(heff_apply(v_k_2425, 1, (V[]){v_u_2426}));
  V f_ = v_g_241;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam6(V self, V *args) {
  V v_a_2430 = args[0];
  V v_k_2429 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_tr(heff_apply(v_k_2429, 1, (V[]){v_a_2430}));
  V f_ = v_g_241;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erpc_2erpc_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Await: {
    V v_t_243 = heff_field(v_p_242, 0);
    V v_k_244 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Await = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Await, TAG_Await, 2, (V[]){v_t_243, heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam1, 1, 2, (V[]){v_k_244, v_g_241})});
  }
  case TAG_Send: {
    V v_s_247 = heff_field(v_p_242, 0);
    V v_x_248 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Send = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_249 = heff_tr(heff_apply(v_g_241, 1, (V[]){v_x_248}));
    return heff_tag_at_n(v_ru_24p_242_24Send, TAG_Send, 2, (V[]){v_s_247, v_t_249});
  }
  case TAG_Log: {
    V v_s_2410 = heff_field(v_p_242, 0);
    V v_x_2411 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Log = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2412 = heff_tr(heff_apply(v_g_241, 1, (V[]){v_x_2411}));
    return heff_tag_at_n(v_ru_24p_242_24Log, TAG_Log, 2, (V[]){v_s_2410, v_t_2412});
  }
  case TAG_Now: {
    V v_k_2413 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Now = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Now, TAG_Now, 1, (V[]){heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam2, 1, 2, (V[]){v_k_2413, v_g_241})});
  }
  case TAG_ProjectFiles: {
    V v_r_2416 = heff_field(v_p_242, 0);
    V v_k_2417 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ProjectFiles = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24ProjectFiles, TAG_ProjectFiles, 2, (V[]){v_r_2416, heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam3, 1, 2, (V[]){v_k_2417, v_g_241})});
  }
  case TAG_UriPath: {
    V v_u_2420 = heff_field(v_p_242, 0);
    V v_k_2421 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24UriPath = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24UriPath, TAG_UriPath, 2, (V[]){v_u_2420, heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam4, 1, 2, (V[]){v_k_2421, v_g_241})});
  }
  case TAG_PathUri: {
    V v_p_2424 = heff_field(v_p_242, 0);
    V v_k_2425 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24PathUri = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24PathUri, TAG_PathUri, 2, (V[]){v_p_2424, heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam5, 1, 2, (V[]){v_k_2425, v_g_241})});
  }
  case TAG_AbsPath: {
    V v_p_2428 = heff_field(v_p_242, 0);
    V v_k_2429 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24AbsPath = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24AbsPath, TAG_AbsPath, 2, (V[]){v_p_2428, heff_clo_n(g_heff_2elsp_2erpc_2erpc_lam6, 1, 2, (V[]){v_k_2429, v_g_241})});
  }
  case TAG_Quit: {
    V v_c_2432 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Quit = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_g_241);
    return heff_tag_at_n(v_ru_24p_242_24Quit, TAG_Quit, 1, (V[]){v_c_2432});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_heff_2elsp_2erpc_2erpc_lam7(V self, V *args) {
  V v_m_2433 = args[0];
  V v_n_2434 = args[1];
  V v_nt_2435 = args[2];
  V v_p_2436 = args[3];
  heff_drop(v_m_2433);
  heff_drop(v_n_2434);
  heff_drop(v_nt_2435);
  switch (heff_tag_of(v_p_2436)) {
  case TAG_Await: {
    V v_t_2437 = heff_field(v_p_2436, 0);
    V v_k_2438 = heff_field(v_p_2436, 1);
    V v_ru_24p_2436_24Await = heff_take_reuse_n(v_p_2436, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2436_24Await, TAG_Await, 2, (V[]){v_t_2437, v_k_2438});
  }
  case TAG_Send: {
    V v_s_2439 = heff_field(v_p_2436, 0);
    V v_x_2440 = heff_field(v_p_2436, 1);
    V v_ru_24p_2436_24Send = heff_take_reuse_n(v_p_2436, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2436_24Send, TAG_Send, 2, (V[]){v_s_2439, v_x_2440});
  }
  case TAG_Log: {
    V v_s_2441 = heff_field(v_p_2436, 0);
    V v_x_2442 = heff_field(v_p_2436, 1);
    V v_ru_24p_2436_24Log = heff_take_reuse_n(v_p_2436, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2436_24Log, TAG_Log, 2, (V[]){v_s_2441, v_x_2442});
  }
  case TAG_Now: {
    V v_k_2443 = heff_field(v_p_2436, 0);
    V v_ru_24p_2436_24Now = heff_take_reuse_n(v_p_2436, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_2436_24Now, TAG_Now, 1, (V[]){v_k_2443});
  }
  case TAG_ProjectFiles: {
    V v_r_2444 = heff_field(v_p_2436, 0);
    V v_k_2445 = heff_field(v_p_2436, 1);
    V v_ru_24p_2436_24ProjectFiles = heff_take_reuse_n(v_p_2436, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2436_24ProjectFiles, TAG_ProjectFiles, 2, (V[]){v_r_2444, v_k_2445});
  }
  case TAG_UriPath: {
    V v_u_2446 = heff_field(v_p_2436, 0);
    V v_k_2447 = heff_field(v_p_2436, 1);
    V v_ru_24p_2436_24UriPath = heff_take_reuse_n(v_p_2436, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2436_24UriPath, TAG_UriPath, 2, (V[]){v_u_2446, v_k_2447});
  }
  case TAG_PathUri: {
    V v_p_2448 = heff_field(v_p_2436, 0);
    V v_k_2449 = heff_field(v_p_2436, 1);
    V v_ru_24p_2436_24PathUri = heff_take_reuse_n(v_p_2436, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2436_24PathUri, TAG_PathUri, 2, (V[]){v_p_2448, v_k_2449});
  }
  case TAG_AbsPath: {
    V v_p_2450 = heff_field(v_p_2436, 0);
    V v_k_2451 = heff_field(v_p_2436, 1);
    V v_ru_24p_2436_24AbsPath = heff_take_reuse_n(v_p_2436, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2436_24AbsPath, TAG_AbsPath, 2, (V[]){v_p_2450, v_k_2451});
  }
  case TAG_Quit: {
    V v_c_2452 = heff_field(v_p_2436, 0);
    V v_ru_24p_2436_24Quit = heff_take_reuse_n(v_p_2436, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_2436_24Quit, TAG_Quit, 1, (V[]){v_c_2452});
  }
  default: return heff_nomatch(v_p_2436);
  }
}