// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayGenerate 2390
#define TAG_ArrayIndex 31774
#define TAG_ArrayIndexIn 58029
#define TAG_BocGiven 26228
#define TAG_BocNew 29139
#define TAG_BocTaken 53948
#define TAG_BocWhen 59622
#define TAG_CustodianDue 8759
#define TAG_CustodyIn 58670
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_FuelTick 47424
#define TAG_FuelTicks 28388
#define TAG_IntShl 35657
#define TAG_IntShr 35663
#define TAG_Keep 49586
#define TAG_MkArm 55352
#define TAG_Panic 15447
#define TAG_Perform 19235
#define TAG_PerformAt 64592
#define TAG_Tip 31527
#define LBL_arity 294440695
#define LBL_arms 9498206
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_bs 9912
#define LBL_c 317
#define LBL_consumers 1203455020
#define LBL_count 296209705
#define LBL_cp 9940
#define LBL_cvars 296399145
#define LBL_fixed 298804110
#define LBL_fresh 299054408
#define LBL_goes 9673821
#define LBL_key 315609
#define LBL_left 9813198
#define LBL_made 9839068
#define LBL_name 9869138
#define LBL_p 330
#define LBL_params 951713969
#define LBL_parity 951721880
#define LBL_producers 572620898
#define LBL_rest 9992347
#define LBL_safe 10017876
#define LBL_supply 1056026650
#define LBL_tags 10047712
#define LBL_total 311908190
#define LBL_underLam 296337946
#define LBL_x 338
static uint32_t shape_c__arity__at__arms__goes__p__parity__cp__cvars[] = {LBL_c, LBL_arity, LBL_at, LBL_arms, LBL_goes, LBL_p, LBL_parity, LBL_cp, LBL_cvars};
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_params__at__arms__goes__fixed[] = {LBL_params, LBL_at, LBL_arms, LBL_goes, LBL_fixed};
static uint32_t shape_supply__consumers__producers__made__fresh__left[] = {LBL_supply, LBL_consumers, LBL_producers, LBL_made, LBL_fresh, LBL_left};
static uint32_t shape_x__p__bs[] = {LBL_x, LBL_p, LBL_bs};
V g_heff_2ecompile_2efuse_2earmGiven(V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2earmGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2earmGiven_clo;
V g_heff_2ecompile_2efuse_2earmGiven_24tok3(V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2earmGiven_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2earmGiven_24tok3_clo;
V g_heff_2ecompile_2efuse_2ebindsOf(V, V, V);
V g_heff_2ecompile_2efuse_2ebindsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ebindsOf_clo;
HeffT2 g_heff_2ecompile_2efuse_2ecallOf_24cpr(V, V, V);
V g_heff_2ecompile_2efuse_2econdCalls(V, V);
V g_heff_2ecompile_2efuse_2econdCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2econdCalls_clo;
HeffT2 g_heff_2ecompile_2efuse_2econsumerOf_24cpr(V, V);
V g_heff_2ecompile_2efuse_2eendAt(V, V);
V g_heff_2ecompile_2efuse_2eendAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eendAt_clo;
V g_heff_2ecompile_2efuse_2efixedGo(V, V, V);
V g_heff_2ecompile_2efuse_2efixedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efixedGo_clo;
V g_heff_2ecompile_2efuse_2efixedGo_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2efixedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efixedGo_24dps_clo;
HeffT2 g_heff_2ecompile_2efuse_2efreshF_24cpr(V, V);
V g_heff_2ecompile_2efuse_2efuseKnown(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseKnown_clo;
V g_heff_2ecompile_2efuse_2efuseNew(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseNew_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseNew_clo;
V g_heff_2ecompile_2efuse_2efuseOn(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseOn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseOn_clo;
V g_heff_2ecompile_2efuse_2efuseOn_24tok2(V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseOn_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseOn_24tok2_clo;
V g_heff_2ecompile_2efuse_2efuseWith(V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseWith_clo;
V g_heff_2ecompile_2efuse_2efuseWith_24tok1(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseWith_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseWith_24tok1_clo;
HeffT2 g_heff_2ecompile_2efuse_2efusedOf_24cpr(V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2eglobalCall(V);
V g_heff_2ecompile_2efuse_2eglobalCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eglobalCall_clo;
HeffT3 g_heff_2ecompile_2efuse_2eglobalCall_24cpr(V);
V g_heff_2ecompile_2efuse_2egoesOf(V);
V g_heff_2ecompile_2efuse_2egoesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2egoesOf_clo;
V g_heff_2ecompile_2efuse_2egoesOf_24dps(V, V);
V g_heff_2ecompile_2efuse_2egoesOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2egoesOf_24dps_clo;
V g_heff_2ecompile_2efuse_2ehere(V, V, V);
V g_heff_2ecompile_2efuse_2ehere_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ehere_clo;
V g_heff_2ecompile_2efuse_2einitF(V);
V g_heff_2ecompile_2efuse_2einitF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einitF_clo;
V g_heff_2ecompile_2efuse_2einitF_24dps(V, V);
V g_heff_2ecompile_2efuse_2einitF_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einitF_24dps_clo;
V g_heff_2ecompile_2efuse_2einsertAt(V, V, V);
V g_heff_2ecompile_2efuse_2einsertAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einsertAt_clo;
V g_heff_2ecompile_2efuse_2einsertAt_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2einsertAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einsertAt_24dps_clo;
V g_heff_2ecompile_2efuse_2eisSelf(V, V, V);
V g_heff_2ecompile_2efuse_2eisSelf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eisSelf_clo;
V g_heff_2ecompile_2efuse_2eisVar(V, V);
V g_heff_2ecompile_2efuse_2eisVar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eisVar_clo;
V g_heff_2ecompile_2efuse_2eletHere(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2eletHere_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eletHere_clo;
V g_heff_2ecompile_2efuse_2emakeFused(V, V, V, V);
V g_heff_2ecompile_2efuse_2emakeFused_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2emakeFused_clo;
V g_heff_2ecompile_2efuse_2emayFuse(V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2emayFuse_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2emayFuse_clo;
V g_heff_2ecompile_2efuse_2enthF(V, V);
V g_heff_2ecompile_2efuse_2enthF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2enthF_clo;
HeffT2 g_heff_2ecompile_2efuse_2enthF_24cpr(V, V);
V g_heff_2ecompile_2efuse_2epathCalls(V, V);
V g_heff_2ecompile_2efuse_2epathCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2epathCalls_clo;
HeffT1 g_heff_2ecompile_2efuse_2eplugK_24cpr(V);
HeffT2 g_heff_2ecompile_2efuse_2eposF_24cpr(V, V, V);
V g_heff_2ecompile_2efuse_2erecall(V, V, V, V);
V g_heff_2ecompile_2efuse_2erecall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2erecall_clo;
V g_heff_2ecompile_2efuse_2erecallAt(V, V, V);
V g_heff_2ecompile_2efuse_2erecallAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2erecallAt_clo;
V g_heff_2ecompile_2efuse_2eremoveAt(V, V);
V g_heff_2ecompile_2efuse_2eremoveAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eremoveAt_clo;
V g_heff_2ecompile_2efuse_2eremoveAt_24dps(V, V, V);
V g_heff_2ecompile_2efuse_2eremoveAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eremoveAt_24dps_clo;
V g_heff_2ecompile_2efuse_2esameGo(V, V);
V g_heff_2ecompile_2efuse_2esameGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esameGo_clo;
V g_heff_2ecompile_2efuse_2eselfArgs(V, V, V);
V g_heff_2ecompile_2efuse_2eselfArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eselfArgs_clo;
V g_heff_2ecompile_2efuse_2esetAt(V, V, V);
V g_heff_2ecompile_2efuse_2esetAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esetAt_clo;
V g_heff_2ecompile_2efuse_2esetAt_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2esetAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esetAt_24dps_clo;
V g_heff_2ecompile_2efuse_2esites(V, V);
V g_heff_2ecompile_2efuse_2esites_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esites_clo;
V g_heff_2ecompile_2efuse_2eworkPure(V, V);
V g_heff_2ecompile_2efuse_2eworkPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eworkPure_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_clo;
V g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423(V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_clo;
V g_heff_2ecompile_2espec_2ehashGo(V, V, V, V);
V g_heff_2ecompile_2espec_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ehashGo_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s1373454977x2143028054(V);
V g_list_2eall_24s1373454977x2143028054_entry(V self, V *a);
extern Clo g_list_2eall_24s1373454977x2143028054_clo;
V g_list_2eall_24s1543979616x278497281(V, V, V, V, V);
V g_list_2eall_24s1543979616x278497281_entry(V self, V *a);
extern Clo g_list_2eall_24s1543979616x278497281_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1375915522x445000623(V);
V g_list_2eany_24s1375915522x445000623_entry(V self, V *a);
extern Clo g_list_2eany_24s1375915522x445000623_clo;
V g_list_2eany_24s667046479x351039015(V, V);
V g_list_2eany_24s667046479x351039015_entry(V self, V *a);
extern Clo g_list_2eany_24s667046479x351039015_clo;
HeffT2 g_list_2efind_24s2013978071x937269256_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2127176832x914341824(V, V);
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127176832x914341824_clo;
V g_list_2efoldl_24s455728131x407835966(V, V);
V g_list_2efoldl_24s455728131x407835966_entry(V self, V *a);
extern Clo g_list_2efoldl_24s455728131x407835966_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1457049037x722637222(V);
V g_list_2ekeepIf_24s1457049037x722637222_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1457049037x722637222_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f505181408x1813697659(V, V);
V g_list_2emap_24f505181408x1813697659_entry(V self, V *a);
extern Clo g_list_2emap_24f505181408x1813697659_clo;
V g_list_2emap_24s1690674600x556093466(V);
V g_list_2emap_24s1690674600x556093466_entry(V self, V *a);
extern Clo g_list_2emap_24s1690674600x556093466_clo;
V g_list_2emap_24s866308031x234213482(V, V, V, V, V);
V g_list_2emap_24s866308031x234213482_entry(V self, V *a);
extern Clo g_list_2emap_24s866308031x234213482_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f677743828x1026746250(V, V, V);
V g_prelude_2e_2b_2b_24f677743828x1026746250_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f677743828x1026746250_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2emaybe(V, V, V);
V g_prelude_2emaybe_entry(V self, V *a);
extern Clo g_prelude_2emaybe_clo;
V g_prelude_2etraverse_24s545943161x1483966866(V, V);
V g_prelude_2etraverse_24s545943161x1483966866_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s545943161x1483966866_clo;
HeffT2 g_prelude_2etraverse_24s801310267x475583082_24cpr(V, V);
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
Clo g_heff_2ecompile_2efuse_2enthF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2enthF_entry, 2, 0};

V g_heff_2ecompile_2efuse_2enthF(V v_i_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2efuse_2enthF_24cpr(v_i_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2efuse_2enthF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2efuse_2enthF(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2efuse_2eremoveAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eremoveAt_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eremoveAt(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return v_xs_243;
    } else {
      V v_cell_244 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2efuse_2eremoveAt_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_xs_243, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2eremoveAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eremoveAt(a[0], a[1]);
}
Clo g_heff_2ecompile_2efuse_2esetAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2esetAt_24dps_entry, 4, 0};

V g_heff_2ecompile_2efuse_2esetAt_24dps(V v_i_240, V v_y_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_y_241);
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_xs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return heff_setField(heff_dup(v_d_243), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_y_241, v_xs_245}));
    } else {
      V v_cell_246 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_244, heff_hole()});
      V v_u_247 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_246);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_y_241;
      V t_2 = v_xs_245;
      V t_3 = v_u_247;
      v_i_240 = t_0;
      v_y_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2esetAt_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2efuse_2esetAt_24dps(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2efuse_2einsertAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2einsertAt_24dps_entry, 4, 0};

V g_heff_2ecompile_2efuse_2einsertAt_24dps(V v_i_240, V v_y_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_241, NTAG(TAG_Nil)});
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), v_t_244);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_xs_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      V v_t_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_241, heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, v_xs_246})});
      return heff_setField(heff_dup(v_d_243), MK_INT(1LL), v_t_247);
    } else {
      V v_cell_248 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_245, heff_hole()});
      V v_u_249 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_248);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_y_241;
      V t_2 = v_xs_246;
      V t_3 = v_u_249;
      v_i_240 = t_0;
      v_y_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2einsertAt_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2efuse_2einsertAt_24dps(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2efuse_2einitF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2einitF_entry, 1, 0};

V g_heff_2ecompile_2efuse_2einitF(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, heff_hole()});
      V v_u_246 = (g_heff_2ecompile_2efuse_2einitF_24dps(v_x12_242, v_cell_245));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuse_2einitF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2einitF(a[0]);
}

HeffT2 g_heff_2ecompile_2efuse_2eposF_24cpr(V v_x_240, V v_x2_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_241, 0);
    V v_ys_244 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_243, 0)) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_242}});
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_244;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_x_240 = t_0;
      v_x2_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT3 g_heff_2ecompile_2efuse_2eglobalCall_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    V v_x11_245 = heff_field(v_x1_240, 0);
    V v_args_246 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_EVar: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EGlobal: {
      V v_g_248 = heff_field(v_x11_245, 0);
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_g_248), heff_dup(v_args_246)}});
    }
    case TAG_ELam: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    default: return ((HeffT3){{heff_nomatch(v_x11_245)}});
    }
  }
  case TAG_ELet: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    V v_g_2463 = heff_field(v_x1_240, 0);
    V v_args_2464 = heff_field(v_x1_240, 1);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_g_2463), heff_dup(v_args_2464)}});
  }
  case TAG_EInt: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  default: return ((HeffT3){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2efuse_2eworkPure_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2efuse_2eworkPure_str1, 5, "False");
V g_heff_2ecompile_2efuse_2eworkPure_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2eworkPure_lam1(V self, V *args);
Clo g_heff_2ecompile_2efuse_2eworkPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eworkPure_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eworkPure(V v_sg_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_sg_240, 0, 2); V a_1 = v_g_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_g_243); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_246;
        heff_drop(v_x_247);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_field_246);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_x21_2410 = heff_field(v_x2_241, 0);
    V v_args_2411 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2410)) {
    case TAG_EVar: {
      heff_take_n(v_x21_2410, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_2413 = heff_field(v_x21_2410, 0);
      heff_take_n(v_x21_2410, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      HeffT2 v_t_2414 = ({ V a_0 = heff_rfield(v_sg_240, 1); V a_1 = v_g_2413; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_g_2413); r_; });
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_ar_2417 = v_field_2416;
          V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2411));
          if (heff_intLe_c(v_t_2418, v_ar_2417)) {
            V v_t_2419 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){v_sg_240}));
            return ({ V a_0 = v_t_2419; V a_1 = v_args_2411; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_args_2411); r_; });
          } else {
            heff_drop_rec(v_sg_240, 2);
            heff_drop(v_args_2411);
            return NTAG(TAG_False);
          }
        } else {
          heff_drop_rec(v_sg_240, 2);
          heff_drop(v_args_2411);
          heff_drop(v_field_2416);
          return NTAG(TAG_False);
        }
      }
    }
    case TAG_ELam: {
      V v_xs_2420 = heff_field(v_x21_2410, 0);
      V v_b_2421 = heff_field(v_x21_2410, 1);
      heff_take_n(v_x21_2410, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      V v_t_2422 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2411));
      V v_t_2423 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2420));
      if (heff_intLe_c(v_t_2422, v_t_2423)) {
        V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){heff_dup(v_sg_240)}));
        V v_t_2425 = (g_list_2eall(v_t_2424, v_args_2411));
        if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
          heff_drop(v_t_2425);
          V v_t_2426 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_2411; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_2411); r_; });
          V v_t_2427 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2420; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
          if (heff_intLt_c(v_t_2426, v_t_2427)) {
            heff_drop_rec(v_sg_240, 2);
            heff_drop(v_b_2421);
            return NTAG(TAG_True);
          } else {
            V t_0 = v_sg_240;
            V t_1 = v_b_2421;
            v_sg_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
        } else {
          heff_drop_rec(v_sg_240, 2);
          heff_drop(v_args_2411);
          heff_drop(v_xs_2420);
          heff_drop(v_b_2421);
          heff_drop(v_t_2425);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop_rec(v_sg_240, 2);
        heff_drop(v_args_2411);
        heff_drop(v_xs_2420);
        heff_drop(v_b_2421);
        return NTAG(TAG_False);
      }
    }
    case TAG_EApp: {
      V v_f_2428 = heff_field(v_x21_2410, 0);
      V v_bs_2429 = heff_field(v_x21_2410, 1);
      V v_ru_24x21_2410_24EApp = heff_take_reuse_n(v_x21_2410, 3ULL, 2);
      V v_t_2430 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x21_2410_24EApp, v_bs_2429, v_args_2411));
      V t_0 = v_sg_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_f_2428, v_t_2430});
      v_sg_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      heff_take_n(v_x21_2410, 0ULL, 3);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_take_n(v_x21_2410, 0ULL, 2);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_take_n(v_x21_2410, 0ULL, 4);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_take_n(v_x21_2410, 0ULL, 3);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_take_n(v_x21_2410, 0ULL, 2);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_2410, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x21_2410, 0ULL, 2);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_take_n(v_x21_2410, 0ULL, 2);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_take_n(v_x21_2410, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_take_nf(v_x21_2410, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_take_n(v_x21_2410, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_2410, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_2410, 0ULL, 2);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_2410, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      heff_take_n(v_x21_2410, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      heff_take_n(v_x21_2410, 0ULL, 3);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      heff_take_n(v_x21_2410, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_take_n(v_x21_2410, 0ULL, 2);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_2410);
    }
  }
  case TAG_ELet: {
    V v_a_2465 = heff_field(v_x2_241, 1);
    V v_b_2466 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2467 = (g_heff_2ecompile_2efuse_2eworkPure(heff_dup(v_sg_240), v_a_2465));
    if ((heff_dup(v_t_2467) == NTAG(TAG_True))) {
      heff_drop(v_t_2467);
      V t_0 = v_sg_240;
      V t_1 = v_b_2466;
      v_sg_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_b_2466);
      heff_drop(v_t_2467);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    V v_fs_2468 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eworkPure_lam0, 1, 1, (V[]){v_sg_240}); V a_1 = v_fs_2468; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_fs_2468); r_; });
  }
  case TAG_EProj: {
    V v_e_2474 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 4);
    V t_0 = v_sg_240;
    V t_1 = v_e_2474;
    v_sg_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_args_2479 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    V v_t_2481 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){v_sg_240}));
    return ({ V a_0 = v_t_2481; V a_1 = v_args_2479; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_args_2479); r_; });
  }
  case TAG_EMatch: {
    V v_s_2482 = heff_field(v_x2_241, 0);
    V v_arms_2483 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2484 = (g_heff_2ecompile_2efuse_2eworkPure(heff_dup(v_sg_240), v_s_2482));
    if ((heff_dup(v_t_2484) == NTAG(TAG_True))) {
      heff_drop(v_t_2484);
      V v_t_2485 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2483));
      if (heff_intEq_c(v_t_2485, MK_INT(2LL))) {
        V v_t_2486 = ({ V b_0 = ((V)&g_heff_2ecompile_2efuse_2eworkPure_str0); V a_1 = v_arms_2483; V r_ = (g_list_2eany_24s667046479x351039015(b_0, a_1)); heff_drop(b_0); r_; });
        if ((heff_dup(v_t_2486) == NTAG(TAG_True))) {
          heff_drop(v_t_2486);
          V v_t_2487 = ({ V b_0 = ((V)&g_heff_2ecompile_2efuse_2eworkPure_str1); V a_1 = v_arms_2483; V r_ = (g_list_2eany_24s667046479x351039015(b_0, a_1)); heff_drop(b_0); r_; });
          if ((heff_dup(v_t_2487) == NTAG(TAG_True))) {
            heff_drop(v_t_2487);
            return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eworkPure_lam1, 1, 1, (V[]){v_sg_240}); V a_1 = v_arms_2483; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2483); r_; });
          } else {
            heff_drop_rec(v_sg_240, 2);
            heff_drop(v_arms_2483);
            heff_drop(v_t_2487);
            return NTAG(TAG_False);
          }
        } else {
          heff_drop_rec(v_sg_240, 2);
          heff_drop(v_arms_2483);
          heff_drop(v_t_2486);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop_rec(v_sg_240, 2);
        heff_drop(v_arms_2483);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_arms_2483);
      heff_drop(v_t_2484);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2494 = heff_field(v_x2_241, 0);
    V v_args_2495 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_p_2494)) {
    case TAG_IntShl: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2495);
      return NTAG(TAG_False);
    }
    case TAG_IntShr: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2495);
      return NTAG(TAG_False);
    }
    case TAG_ArrayIndex: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2495);
      return NTAG(TAG_False);
    }
    case TAG_ArrayGenerate: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2495);
      return NTAG(TAG_False);
    }
    case TAG_Keep: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2495);
      return NTAG(TAG_False);
    }
    case TAG_Panic: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2495);
      return NTAG(TAG_False);
    }
    case TAG_Perform: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2495);
      return NTAG(TAG_False);
    }
    case TAG_PerformAt: {
      heff_take_n(v_p_2494, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2495);
      return NTAG(TAG_False);
    }
    case TAG_BocWhen: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2495);
      return NTAG(TAG_False);
    }
    case TAG_BocNew: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2495);
      return NTAG(TAG_False);
    }
    case TAG_BocTaken: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2495);
      return NTAG(TAG_False);
    }
    case TAG_BocGiven: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2495);
      return NTAG(TAG_False);
    }
    case TAG_ArrayIndexIn: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2495);
      return NTAG(TAG_False);
    }
    case TAG_FuelTick: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2495);
      return NTAG(TAG_False);
    }
    case TAG_FuelTicks: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2495);
      return NTAG(TAG_False);
    }
    case TAG_CustodianDue: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2495);
      return NTAG(TAG_False);
    }
    case TAG_CustodyIn: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2495);
      return NTAG(TAG_False);
    }
    default: {
      heff_drop(v_p_2494);
      V v_t_2497 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){v_sg_240}));
      return ({ V a_0 = v_t_2497; V a_1 = v_args_2495; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_args_2495); r_; });
    }
    }
  }
  case TAG_ECall: {
    V v_g_2498 = heff_field(v_x2_241, 0);
    V v_args_2499 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_24100 = ({ V a_0 = heff_rfield(v_sg_240, 1); V a_1 = v_g_2498; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_g_2498); r_; });
    {
      V v_field_24102 = v_t_24100.f[1];
      int64_t v_tag_24101 = ((int64_t)v_t_24100.f[0]);
      if ((v_tag_24101 == ((int64_t)0ULL))) {
        V v_ar_24103 = v_field_24102;
        V v_t_24104 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2499));
        if (heff_intLe_c(v_t_24104, v_ar_24103)) {
          V v_t_24105 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){v_sg_240}));
          return ({ V a_0 = v_t_24105; V a_1 = v_args_2499; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_args_2499); r_; });
        } else {
          heff_drop_rec(v_sg_240, 2);
          heff_drop(v_args_2499);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop_rec(v_sg_240, 2);
        heff_drop(v_args_2499);
        heff_drop(v_field_24102);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_take_nf(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    V v_c_24113 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24114 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){v_sg_240}));
    V v_t_24115 = ({ V a_0 = v_c_24113; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_24113); r_; });
    return ({ V a_0 = v_t_24114; V a_1 = v_t_24115; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24115); r_; });
  }
  case TAG_ESet: {
    V v_a_24117 = heff_field(v_x2_241, 1);
    V v_b_24118 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_24119 = (g_heff_2ecompile_2efuse_2eworkPure(heff_dup(v_sg_240), v_a_24117));
    if ((heff_dup(v_t_24119) == NTAG(TAG_True))) {
      heff_drop(v_t_24119);
      V t_0 = v_sg_240;
      V t_1 = v_b_24118;
      v_sg_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_b_24118);
      heff_drop(v_t_24119);
      return NTAG(TAG_False);
    }
  }
  case TAG_EValues: {
    V v_es_24120 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24121 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){v_sg_240}));
    return ({ V a_0 = v_t_24121; V a_1 = v_es_24120; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_es_24120); r_; });
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2eworkPure_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eworkPure(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2eworkPure_lam0(V self, V *args) {
  V v_p_2470 = args[0];
  V v_sg_240 = heff_env(self)[0];
  V v_t_2473;
  switch (heff_tag_of(v_p_2470)) {
  case TAG_MkPair: {
    V v_y_2472 = heff_field(v_p_2470, 1);
    heff_take_n(v_p_2470, 2ULL, 2);
    v_t_2473 = v_y_2472;
    break;
  }
  default: heff_nomatch(v_p_2470);
  }
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2efuse_2eworkPure(v_sg_240, v_t_2473));
}
V g_heff_2ecompile_2efuse_2eworkPure_lam1(V self, V *args) {
  V v_a_2488 = args[0];
  V v_sg_240 = heff_env(self)[0];
  V v_t_2492;
  switch (heff_tag_of(v_a_2488)) {
  case TAG_MkArm: {
    V v_b_2491 = heff_field(v_a_2488, 2);
    heff_take_n(v_a_2488, 4ULL, 3);
    v_t_2492 = v_b_2491;
    break;
  }
  default: heff_nomatch(v_a_2488);
  }
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2efuse_2eworkPure(v_sg_240, v_t_2492));
}
Clo g_heff_2ecompile_2efuse_2eisSelf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eisSelf_entry, 3, 0};

V g_heff_2ecompile_2efuse_2eisSelf(V v_me_240, V v_g_241, V v_args_242) {
top: ;
  V v_key_243 = heff_take_field(v_me_240, 0);
  V v_arity_244 = heff_take_field(v_me_240, 1);
  V v_at_245 = heff_take_field(v_me_240, 2);
  V v_rest_246 = heff_get_n(v_me_240, 3, 4);
  if (heff_strEq_c_lent(v_g_241, v_key_243, 2)) {
    V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_242));
    if (heff_intEq_c(v_t_247, v_arity_244)) {
      V v_i_248 = v_at_245;
      V v_t_249 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eisVar_clo), 1, (V[]){v_rest_246}));
      V v_t_2410 = (g_heff_2ecompile_2efuse_2enthF(v_i_248, v_args_242));
      return ({ V a_0 = NTAG(TAG_False); V a_1 = v_t_249; V a_2 = v_t_2410; V r_ = (g_prelude_2emaybe(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
    } else {
      heff_drop(v_at_245);
      heff_drop(v_rest_246);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_arity_244);
    heff_drop(v_at_245);
    heff_drop(v_rest_246);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2efuse_2eisSelf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2efuse_2eisSelf(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2efuse_2epathCalls_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2epathCalls_lam1(V self, V *args);
V g_heff_2ecompile_2efuse_2epathCalls_lam2(V self, V *args);
Clo g_heff_2ecompile_2efuse_2epathCalls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2epathCalls_entry, 2, 0};

V g_heff_2ecompile_2efuse_2epathCalls(V v_me_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EGlobal: {
    V v_g_242 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24EGlobal = heff_take_reuse_n(v_e_241, 1ULL, 1);
    if (heff_strEq_c(v_g_242, heff_get_n(v_me_240, 0, 4))) {
      heff_drop_cell(v_ru_24e_241_24EGlobal, 1);
      return NTAG(TAG_Nothing);
    } else {
      return heff_tag_at_n(v_ru_24e_241_24EGlobal, TAG_Just, 1, (V[]){MK_INT(0LL)});
    }
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 2ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_244)));
    V v_xs_246 = (g_heff_2ecompile_2eir_2enubI(v_t_245));
    V v_t_247 = ({ V a_0 = heff_rfield(v_me_240, 0); V a_1 = v_xs_246; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_xs_246); r_; });
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop_rec(v_me_240, 4);
      heff_drop(v_b_244);
      heff_drop_cell(v_ru_24e_241_24ELam, 2);
      heff_drop(v_t_247);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_247);
      V v_x_248 = heff_get_n(v_me_240, 3, 4);
      V v_t_249 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_Cons, 2, (V[]){heff_dup(v_b_244), NTAG(TAG_Nil)});
      V v_t_2410 = (g_heff_2ecompile_2eir_2ecountW(v_x_248, MK_INT(0LL), v_t_249));
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_244, NTAG(TAG_Nil)});
      V v_t_2412 = ({ V a_0 = v_x_248; V a_1 = v_t_2411; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_248); r_; });
      V v_x_2413 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2410, v_t_2412}), 0, 2);
      if (heff_intLt_c(MK_INT(0LL), v_x_2413)) {
        return NTAG(TAG_Nothing);
      } else {
        return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)});
      }
    }
  }
  case TAG_EApp: {
    V v_e1_2414 = heff_dup(heff_field(v_e_241, 0));
    switch (heff_tag_of(v_e1_2414)) {
    case TAG_EGlobal: {
      V v_g_2416 = heff_field(v_e1_2414, 0);
      V v_ru_24e1_2414_24EGlobal = heff_take_reuse_n(v_e1_2414, 1ULL, 1);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EApp: {
        V v_args_2418 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 2ULL, 2);
        if (heff_strEq_c(heff_dup(v_g_2416), heff_dup(heff_rfield(v_me_240, 0)))) {
          heff_drop_cell(v_ru_24e_241_24EApp, 2);
          V v_t_2419 = ({ V a_0 = heff_dup(v_me_240); V a_1 = v_g_2416; V a_2 = v_args_2418; V r_ = heff_tr(g_heff_2ecompile_2efuse_2eisSelf(a_0, a_1, a_2)); heff_drop(v_g_2416); r_; });
          if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
            heff_drop(v_t_2419);
            V v_x1_2423 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2epathCalls_lam0, 1, 1, (V[]){v_me_240}); V a_1 = v_args_2418; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_args_2418); r_; });
            if (!(heff_dup(v_x1_2423) == NTAG(TAG_True))) {
              heff_drop(v_x1_2423);
              return heff_tag_at_n(v_ru_24e1_2414_24EGlobal, TAG_Just, 1, (V[]){MK_INT(1LL)});
            } else {
              heff_drop_cell(v_ru_24e1_2414_24EGlobal, 1);
              heff_drop(v_x1_2423);
              return NTAG(TAG_Nothing);
            }
          } else {
            heff_drop_rec(v_me_240, 4);
            heff_drop_cell(v_ru_24e1_2414_24EGlobal, 1);
            heff_drop(v_args_2418);
            heff_drop(v_t_2419);
            return NTAG(TAG_Nothing);
          }
        } else {
          heff_drop(v_g_2416);
          V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
          V v_ms_2425 = (g_list_2emap_24tok2(v_ru_24e_241_24EApp, v_t_2424, v_args_2418));
          return ({ V a_0 = heff_tag_at_n(v_ru_24e1_2414_24EGlobal, TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2425; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2425); r_; });
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    default: {
      heff_drop(v_e1_2414);
      V v_t_2426 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_t_2427 = (g_heff_2ecompile_2eir_2epartsOnto(v_e_241, NTAG(TAG_Nil)));
      V v_ms_2428 = (g_list_2emap(v_t_2426, v_t_2427));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2428; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2428); r_; });
    }
    }
  }
  case TAG_EMatch: {
    V v_s_2429 = heff_field(v_e_241, 0);
    V v_arms_2430 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_x1_2431 = heff_tr(g_heff_2ecompile_2efuse_2epathCalls(heff_dup(v_me_240), v_s_2429));
    V v_x1_2437 = (g_list_2emap_24tok2(v_ru_24e_241_24EMatch, heff_clo_n(g_heff_2ecompile_2efuse_2epathCalls_lam1, 1, 1, (V[]){v_me_240}), v_arms_2430));
    switch (heff_tag_of(v_x1_2437)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_x1_2431)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_a_2438 = heff_field(v_x1_2431, 0);
        V v_ru_24x1_2431_24Just = heff_take_reuse_n(v_x1_2431, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2431_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2438, MK_INT(0LL))});
      }
      default: return heff_nomatch(v_x1_2431);
      }
    }
    case TAG_Cons: {
      V v_m_2439 = heff_field(v_x1_2437, 0);
      V v_rest_2440 = heff_field(v_x1_2437, 1);
      heff_take_n(v_x1_2437, 3ULL, 2);
      V v_x2_2441 = ({ V a_0 = v_m_2439; V a_1 = v_rest_2440; V r_ = (g_heff_2ecompile_2efuse_2esameGo(a_0, a_1)); heff_drop(v_rest_2440); r_; });
      switch (heff_tag_of(v_x1_2431)) {
      case TAG_Nothing: {
        heff_drop(v_x2_2441);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_a_2442 = heff_field(v_x1_2431, 0);
        V v_ru_24x1_2431_24Just = heff_take_reuse_n(v_x1_2431, 1ULL, 1);
        switch (heff_tag_of(v_x2_2441)) {
        case TAG_Nothing: {
          heff_drop(v_a_2442);
          heff_drop_cell(v_ru_24x1_2431_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_b_2443 = heff_field(v_x2_2441, 0);
          heff_take_n(v_x2_2441, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x1_2431_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2442, v_b_2443)});
        }
        default: return heff_nomatch(v_x2_2441);
        }
      }
      default: return heff_nomatch(v_x1_2431);
      }
    }
    default: return heff_nomatch(v_x1_2437);
    }
  }
  case TAG_ECall: {
    V v_g_2444 = heff_field(v_e_241, 0);
    V v_args_2445 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ECall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_g_2444), heff_dup(heff_rfield(v_me_240, 0)))) {
      heff_drop_cell(v_ru_24e_241_24ECall, 2);
      V v_t_2446 = ({ V a_0 = heff_dup(v_me_240); V a_1 = v_g_2444; V a_2 = v_args_2445; V r_ = heff_tr(g_heff_2ecompile_2efuse_2eisSelf(a_0, a_1, a_2)); heff_drop(v_g_2444); r_; });
      if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
        heff_drop(v_t_2446);
        V v_x1_2450 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2epathCalls_lam2, 1, 1, (V[]){v_me_240}); V a_1 = v_args_2445; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_args_2445); r_; });
        if (!(heff_dup(v_x1_2450) == NTAG(TAG_True))) {
          heff_drop(v_x1_2450);
          return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(1LL)});
        } else {
          heff_drop(v_x1_2450);
          return NTAG(TAG_Nothing);
        }
      } else {
        heff_drop_rec(v_me_240, 4);
        heff_drop(v_args_2445);
        heff_drop(v_t_2446);
        return NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_g_2444);
      V v_t_2451 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2452 = (g_list_2emap_24tok2(v_ru_24e_241_24ECall, v_t_2451, v_args_2445));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2452; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2452); r_; });
    }
  }
  case TAG_EBool: {
    V v_c_2453 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_t_2454 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
    return ({ V a_0 = v_t_2454; V a_1 = v_c_2453; V r_ = (g_heff_2ecompile_2efuse_2econdCalls(a_0, a_1)); heff_drop(v_c_2453); r_; });
  }
  default: {
    V v_t_2455 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
    V v_t_2456 = (g_heff_2ecompile_2eir_2epartsOnto(v_e_241, NTAG(TAG_Nil)));
    V v_ms_2457 = (g_list_2emap(v_t_2455, v_t_2456));
    return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2457; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2457); r_; });
  }
  }
}
V g_heff_2ecompile_2efuse_2epathCalls_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2epathCalls(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2epathCalls_lam0(V self, V *args) {
  V v_e_2420 = args[0];
  V v_me_240 = heff_env(self)[0];
  V v_t_2421 = (g_heff_2ecompile_2eir_2eglobalsGo(v_e_2420));
  V v_xs_2422 = (g_heff_2ecompile_2eir_2enubI(v_t_2421));
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_me_240, 0, 4); V a_1 = v_xs_2422; V r_ = (g_list_2eany_24s1006624359x760861690(b_0, a_1)); heff_drop(b_0); heff_drop(v_xs_2422); r_; });
}
V g_heff_2ecompile_2efuse_2epathCalls_lam1(V self, V *args) {
  V v_a_2432 = args[0];
  V v_me_240 = heff_env(self)[0];
  V v_t_2436;
  switch (heff_tag_of(v_a_2432)) {
  case TAG_MkArm: {
    V v_b_2435 = heff_field(v_a_2432, 2);
    heff_take_n(v_a_2432, 4ULL, 3);
    v_t_2436 = v_b_2435;
    break;
  }
  default: heff_nomatch(v_a_2432);
  }
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2efuse_2epathCalls(v_me_240, v_t_2436));
}
V g_heff_2ecompile_2efuse_2epathCalls_lam2(V self, V *args) {
  V v_e_2447 = args[0];
  V v_me_240 = heff_env(self)[0];
  V v_t_2448 = (g_heff_2ecompile_2eir_2eglobalsGo(v_e_2447));
  V v_xs_2449 = (g_heff_2ecompile_2eir_2enubI(v_t_2448));
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_me_240, 0, 4); V a_1 = v_xs_2449; V r_ = (g_list_2eany_24s1006624359x760861690(b_0, a_1)); heff_drop(b_0); heff_drop(v_xs_2449); r_; });
}
V g_heff_2ecompile_2efuse_2efixedGo_lam0(V self, V *args);
Clo g_heff_2ecompile_2efuse_2efixedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efixedGo_entry, 3, 0};

V g_heff_2ecompile_2efuse_2efixedGo(V v_calls_240, V v_k_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_248 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2efuse_2efixedGo_lam0, 1, 2, (V[]){v_x_243, heff_dup(v_k_241)}), v_calls_240));
    V v_cell_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_heff_2ecompile_2efuse_2efixedGo_24dps(v_calls_240, heff_box_word((heff_unbox_word(v_k_241) + ((int64_t)1ULL))), v_xs_244, v_cell_249));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2efixedGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efuse_2efixedGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2efuse_2efixedGo_lam0(V self, V *args) {
  V v_es_245 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eisVar_clo), 1, (V[]){v_x_243}));
  V v_t_247 = ({ V a_0 = v_k_241; V a_1 = v_es_245; V r_ = (g_heff_2ecompile_2efuse_2enthF(a_0, a_1)); heff_drop(v_es_245); r_; });
  return ({ V a_0 = NTAG(TAG_False); V a_1 = v_t_246; V a_2 = v_t_247; V r_ = (g_prelude_2emaybe(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
}
V g_heff_2ecompile_2efuse_2efixedGo_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2efuse_2efixedGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efixedGo_24dps_entry, 4, 0};

V g_heff_2ecompile_2efuse_2efixedGo_24dps(V v_calls_240, V v_k_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_xs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_249 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2efuse_2efixedGo_24dps_lam0, 1, 2, (V[]){v_x_244, heff_dup(v_k_241)}), v_calls_240));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2410);
    V t_0 = v_calls_240;
    V t_1 = heff_intAdd(v_k_241, MK_INT(1LL));
    V t_2 = v_xs_245;
    V t_3 = v_u_2411;
    v_calls_240 = t_0;
    v_k_241 = t_1;
    v_x3_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2efixedGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2ecompile_2efuse_2efixedGo_24dps(a0, a[1], a[2], a3); heff_drop(a0); heff_drop(a3); return r;
}
V g_heff_2ecompile_2efuse_2efixedGo_24dps_lam0(V self, V *args) {
  V v_es_246 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eisVar_clo), 1, (V[]){v_x_244}));
  V v_t_248 = ({ V a_0 = v_k_241; V a_1 = v_es_246; V r_ = (g_heff_2ecompile_2efuse_2enthF(a_0, a_1)); heff_drop(v_es_246); r_; });
  return ({ V a_0 = NTAG(TAG_False); V a_1 = v_t_247; V a_2 = v_t_248; V r_ = (g_prelude_2emaybe(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
}
Clo g_heff_2ecompile_2efuse_2egoesOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2egoesOf_24dps_entry, 2, 0};

V g_heff_2ecompile_2efuse_2egoesOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x11_242, 0);
      V v_x112_245 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      switch (heff_tag_of(v_x112_245)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_244);
        V t_0 = v_rest_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_Just: {
        V v_x1121_246 = heff_field(v_x112_245, 0);
        heff_take_n(v_x112_245, 1ULL, 1);
        if ((heff_dup(v_x1121_246) == NTAG(TAG_True))) {
          heff_drop(v_x1121_246);
          V v_t_2410;
          switch (heff_tag_of(v_a_244)) {
          case TAG_MkArm: {
            V v_t_247 = heff_field(v_a_244, 0);
            heff_take_n(v_a_244, 1ULL, 3);
            v_t_2410 = v_t_247;
            break;
          }
          default: heff_nomatch(v_a_244);
          }
          V v_cell_2411 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
          V v_u_2412 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2411);
          V t_0 = v_rest_243;
          V t_1 = v_u_2412;
          v_x1_240 = t_0;
          v_d_241 = t_1;
          goto top;
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_a_244);
          heff_drop(v_x1121_246);
          V t_0 = v_rest_243;
          V t_1 = v_d_241;
          v_x1_240 = t_0;
          v_d_241 = t_1;
          goto top;
        }
      }
      default: return heff_nomatch(v_x112_245);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuse_2egoesOf_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2efuse_2egoesOf_24dps(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2efuse_2econsumerOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2efuse_2econsumerOf_24cpr(V v_key_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    V v_ps_244 = heff_field(v_x2_241, 0);
    V v_x22_245 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_245)) {
    case TAG_EVar: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EGlobal: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      V v_x221_2424 = heff_field(v_x22_245, 0);
      V v_arms_2425 = heff_field(v_x22_245, 1);
      switch (heff_tag_of(v_x221_2424)) {
      case TAG_EVar: {
        V v_l_2426 = heff_field(v_x221_2424, 0);
        HeffT2 v_t_2427 = (g_heff_2ecompile_2efuse_2eposF_24cpr(v_l_2426, v_ps_244, MK_INT(0LL)));
        {
          V v_field_2429 = v_t_2427.f[1];
          int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
          if ((v_tag_2428 == ((int64_t)0ULL))) {
            V v_at_2430 = v_field_2429;
            V v_key_2431 = heff_dup(v_key_240);
            V v_ps_2432 = heff_dup(v_ps_244);
            V v_at_2433 = heff_dup(v_at_2430);
            V v_arms_2434 = heff_dup(v_arms_2425);
            V v_t_2435 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ps_244));
            V v_ks_2436 = (g_list_2emap_24s866308031x234213482(v_key_240, v_t_2435, v_at_2430, heff_dup(v_l_2426), heff_dup(v_arms_2425)));
            V v_t_2437 = (g_list_2eall_24s1373454977x2143028054(v_ks_2436));
            if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
              heff_drop(v_t_2437);
              V v_t_2438 = (g_list_2eany_24s1375915522x445000623(v_ks_2436));
              if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
                heff_drop(v_t_2438);
                V v_t_2439 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_arms_2434), v_ks_2436));
                V v_t_2440 = (g_heff_2ecompile_2efuse_2egoesOf(v_t_2439));
                V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2434)));
                V v_t_2450 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2econsumerOf_24cpr_lam0, 2, 2, (V[]){heff_dup(v_ps_2432), v_key_2431}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2441; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2441); r_; });
                V v_t_2451 = ({ V a_0 = v_t_2450; V a_1 = MK_INT(0LL); V a_2 = heff_dup(v_ps_2432); V r_ = (g_heff_2ecompile_2efuse_2efixedGo(a_0, a_1, a_2)); heff_drop(v_t_2450); r_; });
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(5, shape_params__at__arms__goes__fixed, (V[]){v_ps_2432, v_at_2433, v_arms_2434, v_t_2440, v_t_2451})}});
              } else {
                heff_drop(v_key_2431);
                heff_drop(v_ps_2432);
                heff_drop(v_at_2433);
                heff_drop(v_arms_2434);
                heff_drop(v_ks_2436);
                heff_drop(v_t_2438);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            } else {
              heff_drop(v_key_2431);
              heff_drop(v_ps_2432);
              heff_drop(v_at_2433);
              heff_drop(v_arms_2434);
              heff_drop(v_ks_2436);
              heff_drop(v_t_2437);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          } else {
            heff_drop(v_key_240);
            heff_drop(v_field_2429);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      case TAG_EGlobal: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELam: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EApp: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELet: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ERecord: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EProj: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ETag: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EMatch: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EPrim: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EPrimCall: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ECall: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EInt: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFloat: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EStr: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EBytes: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFixed: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFloat32: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EAbandon: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EBool: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESet: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EValues: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFix: {
        heff_drop(v_key_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x221_2424)}});
      }
    }
    case TAG_EPrim: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_drop(v_key_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x22_245)}});
    }
  }
  case TAG_EApp: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2ecompile_2efuse_2econsumerOf_24cpr_lam0(V self, V *args) {
  V v_acc_2442 = args[0];
  V v_x_2443 = args[1];
  V v_ps_2432 = heff_env(self)[0];
  V v_key_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2444 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ps_2432; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ps_2432); r_; });
  V v_t_2448;
  switch (heff_tag_of(v_x_2443)) {
  case TAG_MkArm: {
    V v_b_2447 = heff_field(v_x_2443, 2);
    heff_take_n(v_x_2443, 4ULL, 3);
    v_t_2448 = v_b_2447;
    break;
  }
  default: heff_nomatch(v_x_2443);
  }
  V v_t_2449 = (g_heff_2ecompile_2efuse_2eselfArgs(v_key_2431, v_t_2444, v_t_2448));
  return (g_prelude_2e_2b_2b(v_t_2449, v_acc_2442));
}
V g_heff_2ecompile_2efuse_2erecallAt_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2erecallAt_lam1(V self, V *args);
Clo g_heff_2ecompile_2efuse_2erecallAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2erecallAt_entry, 3, 0};

V g_heff_2ecompile_2efuse_2erecallAt(V v_fu_240, V v_h_241, V v_args_242) {
top: ;
  V v_p_243 = heff_take_field(v_fu_240, 5);
  V v_parity_244 = heff_take_field(v_fu_240, 6);
  V v_at_245 = heff_take_field(v_fu_240, 2);
  V v_cp_246 = heff_take_field(v_fu_240, 7);
  V v_c_247 = heff_get_n(v_fu_240, 0, 9);
  HeffT2 v_t_248 = ({ V a_0 = v_p_243; V a_1 = v_parity_244; V a_2 = v_h_241; HeffT2 r_ = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(a_0, a_1, a_2)); heff_drop(v_p_243); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      heff_drop(v_h_241);
      heff_drop(v_c_247);
      V v_bs_2411 = v_field_2410;
      return heff_clo_n(g_heff_2ecompile_2efuse_2erecallAt_lam0, 1, 4, (V[]){v_bs_2411, v_at_245, v_args_242, v_cp_246});
    } else {
      heff_drop(v_cp_246);
      heff_drop(v_field_2410);
      return heff_clo_n(g_heff_2ecompile_2efuse_2erecallAt_lam1, 1, 4, (V[]){v_h_241, v_at_245, v_args_242, v_c_247});
    }
  }
}
V g_heff_2ecompile_2efuse_2erecallAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2erecallAt(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2efuse_2erecallAt_lam0(V self, V *args) {
  V v_s_2412 = args[0];
  V v_bs_2411 = heff_env(self)[0];
  V v_at_245 = heff_env(self)[1];
  V v_args_242 = heff_env(self)[2];
  V v_cp_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2413 = (g_prelude_2etraverse_24s801310267x475583082_24cpr(v_bs_2411, v_s_2412));
  {
    V v_field_2414 = v_t_2413.f[0];
    V v_field_2415 = v_t_2413.f[1];
    V v_x_2416 = v_field_2414;
    V v_s_2417 = v_field_2415;
    V v_t_2418 = (g_prelude_2e_2b_2b_24f677743828x1026746250(v_x_2416, v_at_245, v_args_242));
    V v_x_2419 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_cp_246}), v_t_2418});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_s_2417});
  }
}
V g_heff_2ecompile_2efuse_2erecallAt_lam1(V self, V *args) {
  V v_s_2420 = args[0];
  V v_h_241 = heff_env(self)[0];
  V v_at_245 = heff_env(self)[1];
  V v_args_242 = heff_env(self)[2];
  V v_c_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2421 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2eordmap_2eempty_get()), heff_take_field(v_s_2420, 0), v_h_241));
  {
    V v_field_2422 = v_t_2421.f[0];
    V v_field_2423 = v_t_2421.f[1];
    V v_e_2424 = v_field_2422;
    V v_n_2425 = v_field_2423;
    V v_t_2426 = (g_heff_2ecompile_2efuse_2esetAt(v_at_245, v_e_2424, v_args_242));
    V v_x_2427 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_c_247}), v_t_2426});
    V v_t_2428 = ({ V rv_0 = v_n_2425; V rr_ = heff_rec_reuse_nf(v_s_2420, 62ULL, 6, shape_supply__consumers__producers__made__fresh__left, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2427, v_t_2428});
  }
}
V g_heff_2ecompile_2efuse_2erecall_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2erecall_lam1(V self, V *args);
V g_heff_2ecompile_2efuse_2erecall_lam2(V self, V *args);
V g_heff_2ecompile_2efuse_2erecall_lam3(V self, V *args);
Clo g_heff_2ecompile_2efuse_2erecall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2erecall_entry, 4, 0};

V g_heff_2ecompile_2efuse_2erecall(V v_fu_240, V v_r_241, V v_h_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EApp: {
    V v_e1_244 = heff_dup(heff_field(v_e_243, 0));
    switch (heff_tag_of(v_e1_244)) {
    case TAG_EGlobal: {
      V v_g_246 = heff_field(v_e1_244, 0);
      heff_take_n(v_e1_244, 1ULL, 1);
      switch (heff_tag_of(v_e_243)) {
      case TAG_EApp: {
        V v_args_248 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 2ULL, 2);
        V v_t_2412;
        if (heff_strEq_c(heff_dup(v_g_246), heff_dup(heff_rfield(v_fu_240, 0)))) {
          V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_248));
          if (heff_intEq_c(v_t_249, heff_dup(heff_rfield(v_fu_240, 1)))) {
            V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eisVar_clo), 1, (V[]){heff_dup(v_r_241)}));
            V v_t_2411 = (g_heff_2ecompile_2efuse_2enthF(heff_dup(heff_rfield(v_fu_240, 2)), v_args_248));
            v_t_2412 = ({ V a_0 = NTAG(TAG_False); V a_1 = v_t_2410; V a_2 = v_t_2411; V r_ = heff_tr(g_prelude_2emaybe(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
          } else {
            v_t_2412 = NTAG(TAG_False);
          }
        } else {
          v_t_2412 = NTAG(TAG_False);
        }
        if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
          heff_drop(v_r_241);
          heff_drop(v_g_246);
          heff_drop(v_t_2412);
          return (g_heff_2ecompile_2efuse_2erecallAt(v_fu_240, v_h_242, v_args_248));
        } else {
          heff_drop(v_t_2412);
          V v_t_2413 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
          V v_m_2414 = (g_prelude_2etraverse_24s545943161x1483966866(v_t_2413, v_args_248));
          return heff_clo_n(g_heff_2ecompile_2efuse_2erecall_lam0, 1, 2, (V[]){v_m_2414, v_g_246});
        }
      }
      default: return heff_nomatch(v_e_243);
      }
    }
    default: {
      heff_drop(v_e1_244);
      V v_f_2420 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258(heff_clo_n(g_heff_2ecompile_2efuse_2erecall_lam1, 1, 1, (V[]){v_f_2420}), v_e_243));
    }
    }
  }
  case TAG_ECall: {
    V v_g_2422 = heff_field(v_e_243, 0);
    V v_args_2423 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    V v_t_2427;
    if (heff_strEq_c(heff_dup(v_g_2422), heff_dup(heff_rfield(v_fu_240, 0)))) {
      V v_t_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2423));
      if (heff_intEq_c(v_t_2424, heff_dup(heff_rfield(v_fu_240, 1)))) {
        V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eisVar_clo), 1, (V[]){heff_dup(v_r_241)}));
        V v_t_2426 = (g_heff_2ecompile_2efuse_2enthF(heff_dup(heff_rfield(v_fu_240, 2)), v_args_2423));
        v_t_2427 = ({ V a_0 = NTAG(TAG_False); V a_1 = v_t_2425; V a_2 = v_t_2426; V r_ = heff_tr(g_prelude_2emaybe(a_0, a_1, a_2)); heff_drop(v_t_2426); r_; });
      } else {
        v_t_2427 = NTAG(TAG_False);
      }
    } else {
      v_t_2427 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
      heff_drop(v_r_241);
      heff_drop(v_g_2422);
      heff_drop(v_t_2427);
      return (g_heff_2ecompile_2efuse_2erecallAt(v_fu_240, v_h_242, v_args_2423));
    } else {
      heff_drop(v_t_2427);
      V v_t_2428 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      V v_m_2429 = (g_prelude_2etraverse_24s545943161x1483966866(v_t_2428, v_args_2423));
      return heff_clo_n(g_heff_2ecompile_2efuse_2erecall_lam2, 1, 2, (V[]){v_m_2429, v_g_2422});
    }
  }
  default: {
    V v_f_2434 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258(heff_clo_n(g_heff_2ecompile_2efuse_2erecall_lam3, 1, 1, (V[]){v_f_2434}), v_e_243));
  }
  }
}
V g_heff_2ecompile_2efuse_2erecall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2erecall(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2efuse_2erecall_lam0(V self, V *args) {
  V v_s_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_g_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_s_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_s_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    V v_t_2419 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_246}), v_x_2417});
    return heff_tag_re_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2419, v_s_2418});
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ecompile_2efuse_2erecall_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_f_2420 = heff_env(self)[0];
  heff_drop(v_x_2421);
  heff_clo_take(self, 1);
  return v_f_2420;
}
V g_heff_2ecompile_2efuse_2erecall_lam2(V self, V *args) {
  V v_s_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  V v_g_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2431 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_s_2430}));
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_s_2433 = heff_field(v_x2_2431, 1);
    V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2431_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2422, v_x_2432}), v_s_2433});
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2ecompile_2efuse_2erecall_lam3(V self, V *args) {
  V v_x_2435 = args[0];
  V v_f_2434 = heff_env(self)[0];
  heff_drop(v_x_2435);
  heff_clo_take(self, 1);
  return v_f_2434;
}
HEFF_LIT(g_heff_2ecompile_2efuse_2earmGiven_str0, 0, "");
Clo g_heff_2ecompile_2efuse_2earmGiven_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2earmGiven_entry, 6, 0};

V g_heff_2ecompile_2efuse_2earmGiven(V v_fu_240, V v_t_241, V v_hs_242, V v_ts_243, V v_e_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_ELam: {
    V v_vs_246 = heff_field(v_e_244, 0);
    V v_b_247 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24ELam = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_x_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_246));
    V v_y_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_hs_242));
    if (!heff_intEq_c_lent(v_x_248, v_y_249, 0)) {
      heff_drop(v_vs_246);
      heff_drop(v_b_247);
      heff_drop(v_x_248);
      heff_drop(v_y_249);
      V v_t_2410 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_take_field(v_fu_240, 8)));
      V v_t_2411 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_get_n(v_fu_240, 0, 9)});
      V v_x_2412 = heff_tag_at_n(v_ru_24e_244_24ELam, TAG_EApp, 2, (V[]){v_t_2411, v_t_2410});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2412, v_z_245});
    } else {
      heff_drop(v_ts_243);
      heff_drop(v_x_248);
      heff_drop(v_y_249);
      V v_t_2413 = ({ V a_0 = v_t_241; V a_1 = heff_rfield(v_fu_240, 4); V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_t_241); r_; });
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        V v_x1_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_vs_246)));
        V v_t_2417;
        switch (heff_tag_of(v_x1_2414)) {
        case TAG_Nil: {
          v_t_2417 = ((V)&g_heff_2ecompile_2efuse_2earmGiven_str0);
          break;
        }
        case TAG_Cons: {
          V v_x_2415 = heff_field(v_x1_2414, 0);
          heff_take_n(v_x1_2414, 1ULL, 2);
          v_t_2417 = v_x_2415;
          break;
        }
        default: heff_nomatch(v_x1_2414);
        }
        V v_x1_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_hs_242)));
        V v_t_2421;
        switch (heff_tag_of(v_x1_2418)) {
        case TAG_Nil: {
          v_t_2421 = heff_tag_n(TAG_EInt, 1, (V[]){MK_INT(0LL)});
          break;
        }
        case TAG_Cons: {
          V v_x_2419 = heff_field(v_x1_2418, 0);
          heff_take_n(v_x1_2418, 1ULL, 2);
          v_t_2421 = v_x_2419;
          break;
        }
        default: heff_nomatch(v_x1_2418);
        }
        V v_m_2422 = (g_heff_2ecompile_2efuse_2erecall(v_fu_240, v_t_2417, v_t_2421, v_b_247));
        V v_x2_2423 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_z_245}));
        switch (heff_tag_of(v_x2_2423)) {
        case TAG_MkPair: {
          V v_x_2424 = heff_field(v_x2_2423, 0);
          V v_s_2425 = heff_field(v_x2_2423, 1);
          heff_take_n(v_x2_2423, 3ULL, 2);
          V v_t_2426 = (g_heff_2ecompile_2efuse_2einitF(v_vs_246));
          V v_t_2427 = (g_heff_2ecompile_2efuse_2einitF(v_hs_242));
          V v_x_2428 = ({ V a_0 = v_t_2426; V a_1 = v_t_2427; V a_2 = v_x_2424; V r_ = (g_heff_2ecompile_2efuse_2ebindsOf(a_0, a_1, a_2)); heff_drop(v_t_2426); heff_drop(v_t_2427); r_; });
          return heff_tag_at_n(v_ru_24e_244_24ELam, TAG_MkPair, 2, (V[]){v_x_2428, v_s_2425});
        }
        default: return heff_nomatch(v_x2_2423);
        }
      } else {
        heff_drop_rec(v_fu_240, 9);
        heff_drop(v_t_2413);
        V v_x_2429 = ({ V a_0 = v_vs_246; V a_1 = v_hs_242; V a_2 = v_b_247; V r_ = (g_heff_2ecompile_2efuse_2ebindsOf(a_0, a_1, a_2)); heff_drop(v_vs_246); heff_drop(v_hs_242); r_; });
        return heff_tag_at_n(v_ru_24e_244_24ELam, TAG_MkPair, 2, (V[]){v_x_2429, v_z_245});
      }
    }
  }
  default: {
    heff_drop(v_e_244);
    V v_t_2430 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_take_field(v_fu_240, 8)));
    V v_t_2431 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_get_n(v_fu_240, 0, 9)});
    V v_x_2432 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2431, v_t_2430});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2432, v_z_245});
  }
  }
}
V g_heff_2ecompile_2efuse_2earmGiven_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2earmGiven(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2efuse_2eendAt_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam1(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam2(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam3(V self, V *args);
Clo g_heff_2ecompile_2efuse_2eendAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eendAt_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eendAt(V v_fu_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_ETag: {
    V v_t_242 = heff_field(v_e_241, 0);
    V v_hs_243 = heff_field(v_e_241, 1);
    V v_ts_244 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ETag = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_fu_245 = v_fu_240;
    V v_t_246 = v_t_242;
    V v_hs_247 = v_hs_243;
    V v_ts_248 = v_ts_244;
    HeffT2 v_t_249 = (g_list_2efind_24s2013978071x937269256_24cpr(v_t_246, heff_rfield(v_fu_245, 3)));
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24e_241_24ETag, 3);
        V v_a_2412 = v_field_2411;
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam0, 1, 5, (V[]){v_a_2412, v_fu_245, v_t_246, v_hs_247, v_ts_248});
      } else {
        heff_drop(v_field_2411);
        V v_t_2422 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_245, 2), heff_tag_at_n(v_ru_24e_241_24ETag, TAG_ETag, 3, (V[]){v_t_246, v_hs_247, v_ts_248}), heff_take_field(v_fu_245, 8)));
        V v_t_2423 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_get_n(v_fu_245, 0, 9)});
        V v_x_2424 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2423, v_t_2422});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam1, 1, 1, (V[]){v_x_2424});
      }
    }
  }
  default: {
    HeffT2 v_t_2426 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    {
      V v_field_2428 = v_t_2426.f[1];
      int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
      if ((v_tag_2427 == ((int64_t)0ULL))) {
        heff_drop(v_e_241);
        V v_bs_2429 = v_field_2428;
        V v_t_2430 = (g_prelude_2e_2b_2b(heff_take_field(v_fu_240, 8), v_bs_2429));
        V v_t_2431 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_get_n(v_fu_240, 7, 9)});
        V v_x_2432 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2431, v_t_2430});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam2, 1, 1, (V[]){v_x_2432});
      } else {
        heff_drop(v_field_2428);
        V v_t_2434 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_take_field(v_fu_240, 8)));
        V v_t_2435 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_get_n(v_fu_240, 0, 9)});
        V v_x_2436 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2435, v_t_2434});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam3, 1, 1, (V[]){v_x_2436});
      }
    }
  }
  }
}
V g_heff_2ecompile_2efuse_2eendAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eendAt(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2eendAt_lam0(V self, V *args) {
  V v_p_2413 = args[0];
  V v_a_2412 = heff_env(self)[0];
  V v_fu_245 = heff_env(self)[1];
  V v_t_246 = heff_env(self)[2];
  V v_hs_247 = heff_env(self)[3];
  V v_ts_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_a_2412)) {
  case TAG_MkArm: {
    V v_vs_2415 = heff_field(v_a_2412, 1);
    V v_b_2416 = heff_field(v_a_2412, 2);
    V v_ru_24a_2412_24MkArm = heff_take_reuse_n(v_a_2412, 6ULL, 3);
    HeffT2 v_t_2417 = (g_heff_2ecompile_2efuse_2efreshF_24cpr(heff_tag_n(TAG_ELam, 2, (V[]){v_vs_2415, v_b_2416}), v_p_2413));
    {
      V v_field_2418 = v_t_2417.f[0];
      V v_field_2419 = v_t_2417.f[1];
      V v_x_2420 = v_field_2418;
      V v_s_2421 = v_field_2419;
      return (g_heff_2ecompile_2efuse_2earmGiven_24tok3(v_ru_24a_2412_24MkArm, v_fu_245, v_t_246, v_hs_247, v_ts_248, v_x_2420, v_s_2421));
    }
  }
  default: return heff_nomatch(v_a_2412);
  }
}
V g_heff_2ecompile_2efuse_2eendAt_lam1(V self, V *args) {
  V v_s_2425 = args[0];
  V v_x_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2424, v_s_2425});
}
V g_heff_2ecompile_2efuse_2eendAt_lam2(V self, V *args) {
  V v_s_2433 = args[0];
  V v_x_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2432, v_s_2433});
}
V g_heff_2ecompile_2efuse_2eendAt_lam3(V self, V *args) {
  V v_s_2437 = args[0];
  V v_x_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2436, v_s_2437});
}
HEFF_LIT(g_heff_2ecompile_2efuse_2efusedOf_24cpr_str0, 2, "$s");
HEFF_LIT(g_heff_2ecompile_2efuse_2efusedOf_24cpr_str1, 1, " ");
HEFF_LIT(g_heff_2ecompile_2efuse_2efusedOf_24cpr_str2, 2, "$f");
HEFF_LIT(g_heff_2ecompile_2efuse_2efusedOf_24cpr_str3, 2, "$s");
HEFF_LIT(g_heff_2ecompile_2efuse_2efusedOf_24cpr_str4, 1, " ");
HEFF_LIT(g_heff_2ecompile_2efuse_2efusedOf_24cpr_str5, 2, "$f");
HEFF_LIT(g_heff_2ecompile_2efuse_2efusedOf_24cpr_str6, 2, "$s");
HEFF_LIT(g_heff_2ecompile_2efuse_2efusedOf_24cpr_str7, 1, " ");
HEFF_LIT(g_heff_2ecompile_2efuse_2efusedOf_24cpr_str8, 2, "$f");

HeffT2 g_heff_2ecompile_2efuse_2efusedOf_24cpr(V v_c_240, V v_cs_241, V v_p_242, V v_ps_243, V v_cl_244, V v_pl_245, V v_z_246) {
top: ;
  V v_at_247 = heff_take_field(v_cs_241, 1);
  V v_goes_248 = heff_get_n(v_cs_241, 3, 5);
  switch (heff_tag_of(v_cl_244)) {
  case TAG_ELam: {
    V v_xs_249 = heff_field(v_cl_244, 0);
    V v_cl2_2410 = heff_field(v_cl_244, 1);
    V v_ru_24cl_244_24ELam = heff_take_reuse_n(v_cl_244, 3ULL, 2);
    switch (heff_tag_of(v_cl2_2410)) {
    case TAG_EMatch: {
      V v_arms_2412 = heff_field(v_cl2_2410, 1);
      heff_take_n(v_cl2_2410, 2ULL, 2);
      switch (heff_tag_of(v_pl_245)) {
      case TAG_ELam: {
        V v_ys_2413 = heff_field(v_pl_245, 0);
        V v_pb_2414 = heff_field(v_pl_245, 1);
        heff_take_n(v_pl_245, 3ULL, 2);
        V v_t_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_249));
        V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_2413));
        V v_j_2417 = heff_strFind_lent(((V)&g_heff_2ecompile_2efuse_2efusedOf_24cpr_str0), v_c_240, MK_INT(0LL), 5);
        V v_t_2418;
        if (heff_intLt_c_lent(v_j_2417, MK_INT(0LL), 2)) {
          heff_drop(v_j_2417);
          v_t_2418 = heff_dup(v_c_240);
        } else {
          v_t_2418 = heff_strSlice_lent(v_c_240, MK_INT(0LL), v_j_2417, 6);
        }
        V v_t_2419 = heff_strAppend(heff_strAppend(heff_dup(v_c_240), ((V)&g_heff_2ecompile_2efuse_2efusedOf_24cpr_str1)), heff_dup(v_p_242));
        V v_t_2420 = ({ V a_0 = v_t_2419; V a_1 = MK_INT(0LL); V a_2 = MK_INT(5381LL); V a_3 = MK_INT(7919LL); V r_ = (g_heff_2ecompile_2espec_2ehashGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2419); r_; });
        V v_t_2421 = (g_list_2emap_24f505181408x1813697659(heff_dup(v_at_247), heff_dup(v_xs_249)));
        V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2efuse_2efusedOf_24cpr_str2)), v_t_2420);
        V v_t_2423 = heff_rec_n(9, shape_c__arity__at__arms__goes__p__parity__cp__cvars, (V[]){heff_dup(v_c_240), v_t_2415, heff_dup(v_at_247), v_arms_2412, v_goes_248, heff_dup(v_p_242), v_t_2416, v_t_2422, v_t_2421});
        V v_m_2424 = (g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423(v_t_2423, v_pb_2414));
        V v_x2_2425 = heff_tr(heff_call(v_m_2424, 1, (V[]){v_z_246}));
        switch (heff_tag_of(v_x2_2425)) {
        case TAG_MkPair: {
          V v_x_2426 = heff_field(v_x2_2425, 0);
          V v_s_2427 = heff_field(v_x2_2425, 1);
          heff_take_n(v_x2_2425, 3ULL, 2);
          V v_j_2428 = heff_strFind_lent(((V)&g_heff_2ecompile_2efuse_2efusedOf_24cpr_str3), v_c_240, MK_INT(0LL), 5);
          V v_t_2429;
          if (heff_intLt_c_lent(v_j_2428, MK_INT(0LL), 2)) {
            heff_drop(v_j_2428);
            v_t_2429 = heff_dup(v_c_240);
          } else {
            v_t_2429 = heff_strSlice_lent(v_c_240, MK_INT(0LL), v_j_2428, 6);
          }
          V v_t_2430 = heff_strAppend(heff_strAppend(heff_dup(v_c_240), ((V)&g_heff_2ecompile_2efuse_2efusedOf_24cpr_str4)), heff_dup(v_p_242));
          V v_t_2431 = ({ V a_0 = v_t_2430; V a_1 = MK_INT(0LL); V a_2 = MK_INT(5381LL); V a_3 = MK_INT(7919LL); V r_ = (g_heff_2ecompile_2espec_2ehashGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2430); r_; });
          V v_key_2432 = heff_strAppend(heff_strAppend(v_t_2429, ((V)&g_heff_2ecompile_2efuse_2efusedOf_24cpr_str5)), v_t_2431);
          V v_j_2433 = heff_strFind_lent(((V)&g_heff_2ecompile_2efuse_2efusedOf_24cpr_str6), v_c_240, MK_INT(0LL), 5);
          V v_t_2434;
          if (heff_intLt_c_lent(v_j_2433, MK_INT(0LL), 2)) {
            heff_drop(v_j_2433);
            v_t_2434 = heff_dup(v_c_240);
          } else {
            v_t_2434 = heff_strSlice_lent(v_c_240, MK_INT(0LL), v_j_2433, 6);
          }
          V v_t_2435 = heff_strAppend(heff_strAppend(v_c_240, ((V)&g_heff_2ecompile_2efuse_2efusedOf_24cpr_str7)), v_p_242);
          V v_t_2436 = ({ V a_0 = v_t_2435; V a_1 = MK_INT(0LL); V a_2 = MK_INT(5381LL); V a_3 = MK_INT(7919LL); V r_ = (g_heff_2ecompile_2espec_2ehashGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2435); r_; });
          V v_name_2437 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_heff_2ecompile_2efuse_2efusedOf_24cpr_str8)), v_t_2436);
          V v_t_2438 = (g_prelude_2e_2b_2b_24f677743828x1026746250(v_ys_2413, v_at_247, v_xs_249));
          V v_body_2439 = heff_tag_at_n(v_ru_24cl_244_24ELam, TAG_ELam, 2, (V[]){v_t_2438, v_x_2426});
          V v_x_2440 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){v_key_2432, v_name_2437, v_body_2439})});
          return ((HeffT2){{v_x_2440, v_s_2427}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x2_2425)}});
        }
      }
      default: {
        heff_drop(v_c_240);
        heff_drop(v_p_242);
        heff_drop(v_pl_245);
        heff_drop(v_at_247);
        heff_drop(v_goes_248);
        heff_drop(v_xs_249);
        heff_drop_cell(v_ru_24cl_244_24ELam, 2);
        heff_drop(v_arms_2412);
        return ((HeffT2){{NTAG(TAG_Nothing), v_z_246}});
      }
      }
    }
    default: {
      heff_drop(v_c_240);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_at_247);
      heff_drop(v_goes_248);
      heff_drop(v_xs_249);
      heff_drop(v_cl2_2410);
      heff_drop_cell(v_ru_24cl_244_24ELam, 2);
      return ((HeffT2){{NTAG(TAG_Nothing), v_z_246}});
    }
    }
  }
  default: {
    heff_drop(v_c_240);
    heff_drop(v_p_242);
    heff_drop(v_cl_244);
    heff_drop(v_pl_245);
    heff_drop(v_at_247);
    heff_drop(v_goes_248);
    return ((HeffT2){{NTAG(TAG_Nothing), v_z_246}});
  }
  }
}
HEFF_LIT(g_heff_2ecompile_2efuse_2emakeFused_str0, 0, "");
V g_heff_2ecompile_2efuse_2emakeFused_lam0(V self, V *args);
Clo g_heff_2ecompile_2efuse_2emakeFused_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2emakeFused_entry, 4, 0};

V g_heff_2ecompile_2efuse_2emakeFused(V v_c_240, V v_cs_241, V v_p_242, V v_ps_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2efuse_2enthF_24cpr(heff_dup(heff_rfield(v_cs_241, 1)), heff_rfield(v_cs_241, 0)));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    V v_t_248;
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_246;
      v_t_248 = v_x_247;
    } else {
      heff_drop(v_field_246);
      v_t_248 = ((V)&g_heff_2ecompile_2efuse_2emakeFused_str0);
    }
    V v_t_249 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_248}), heff_dup(heff_rfield(v_cs_241, 2))});
    V v_e_2410 = heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(heff_rfield(v_cs_241, 0)), v_t_249});
    return heff_clo_n(g_heff_2ecompile_2efuse_2emakeFused_lam0, 1, 5, (V[]){v_e_2410, v_ps_243, v_c_240, v_cs_241, v_p_242});
  }
}
V g_heff_2ecompile_2efuse_2emakeFused_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2emakeFused(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2efuse_2emakeFused_lam0(V self, V *args) {
  V v_s_2411 = args[0];
  V v_e_2410 = heff_env(self)[0];
  V v_ps_243 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  HeffT2 v_t_2412 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2eordmap_2eempty_get()), heff_take_field(v_s_2411, 0), v_e_2410));
  {
    V v_field_2413 = v_t_2412.f[0];
    V v_field_2414 = v_t_2412.f[1];
    V v_e_2415 = v_field_2413;
    V v_n_2416 = v_field_2414;
    V v_t_2417 = heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(heff_rfield(v_ps_243, 0)), heff_dup(heff_rfield(v_ps_243, 1))});
    V v_t_2418 = ({ V rv_0 = v_n_2416; V rr_ = heff_rec_reuse_nf(v_s_2411, 62ULL, 6, shape_supply__consumers__producers__made__fresh__left, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    HeffT2 v_t_2419 = (g_heff_2ecompile_2efuse_2efreshF_24cpr(v_t_2417, v_t_2418));
    {
      V v_field_2420 = v_t_2419.f[0];
      V v_field_2421 = v_t_2419.f[1];
      V v_x_2422 = v_field_2420;
      V v_s_2423 = v_field_2421;
      HeffT2 v_t_2424 = ({ V a_0 = v_c_240; V a_1 = v_cs_241; V a_2 = v_p_242; V a_3 = v_ps_243; V a_4 = heff_dup(v_e_2415); V a_5 = heff_dup(v_x_2422); V a_6 = v_s_2423; HeffT2 r_ = (g_heff_2ecompile_2efuse_2efusedOf_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop_rec(v_ps_243, 3); r_; });
      {
        V v_field_2425 = v_t_2424.f[0];
        V v_field_2426 = v_t_2424.f[1];
        V v_x_2427 = v_field_2425;
        V v_s_2428 = v_field_2426;
        V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2415, NTAG(TAG_Nil)});
        V v_t_2430 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_2429));
        V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2422, NTAG(TAG_Nil)});
        V v_t_2432 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_2431));
        V v_lim_2433 = heff_intAdd(heff_intAdd(v_t_2430, v_t_2432), MK_INT(64LL));
        V v_x_2437;
        switch (heff_tag_of(v_x_2427)) {
        case TAG_Nothing: {
          heff_drop(v_lim_2433);
          v_x_2437 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_d_2434 = heff_field(v_x_2427, 0);
          V v_ru_24x_2427_24Just = heff_take_reuse_n(v_x_2427, 1ULL, 1);
          V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_d_2434, 2)), NTAG(TAG_Nil)});
          V v_x_2436 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2433), MK_INT(0LL), v_t_2435));
          if (heff_intLt_c(v_lim_2433, v_x_2436)) {
            heff_drop_rec(v_d_2434, 3);
            heff_drop_cell(v_ru_24x_2427_24Just, 1);
            v_x_2437 = NTAG(TAG_Nothing);
          } else {
            v_x_2437 = heff_tag_re_n(v_ru_24x_2427_24Just, TAG_Just, 1, 1ULL, (V[]){v_d_2434});
          }
          break;
        }
        default: heff_nomatch(v_x_2427);
        }
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2437, v_s_2428});
      }
    }
  }
}
V g_heff_2ecompile_2efuse_2emayFuse_lam0(V self, V *args);
Clo g_heff_2ecompile_2efuse_2emayFuse_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2emayFuse_entry, 6, 0};

V g_heff_2ecompile_2efuse_2emayFuse(V v_sg_240, V v_c_241, V v_cs_242, V v_ps_243, V v_args_244, V v_bs_245) {
top: ;
  V v_params_246 = heff_take_field(v_ps_243, 0);
  V v_tags_247 = heff_get_n(v_ps_243, 2, 3);
  V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_244));
  V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_cs_242, 0)));
  if (heff_intEq_c(v_t_248, v_t_249)) {
    V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_bs_245));
    V v_t_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_params_246; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_params_246); r_; });
    if (heff_intEq_c(v_t_2410, v_t_2411)) {
      V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){heff_dup(v_sg_240)}));
      V v_t_2413 = (g_heff_2ecompile_2efuse_2eremoveAt(heff_dup(heff_rfield(v_cs_242, 1)), heff_dup(v_args_244)));
      V v_t_2414 = ({ V a_0 = v_t_2412; V a_1 = v_t_2413; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2413); r_; });
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_t_2414);
        V v_t_2415 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(heff_rfield(v_cs_242, 0)), heff_dup(heff_rfield(v_cs_242, 4))));
        V v_t_2416 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2415, v_args_244));
        V v_t_2417 = (g_heff_2ecompile_2efuse_2eremoveAt(heff_dup(heff_rfield(v_cs_242, 1)), v_t_2416));
        V v_t_2418 = (g_list_2ekeepIf_24s1457049037x722637222(v_t_2417));
        V v_ps_2419 = (g_list_2emap_24s1690674600x556093466(v_t_2418));
        V v_t_2420 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2419; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_2419); r_; });
        V v_t_2421 = (g_list_2eall_24s1543979616x278497281(v_sg_240, v_c_241, heff_dup(v_cs_242), v_t_2420, heff_rfield(v_cs_242, 2)));
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_t_2421);
          return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2emayFuse_lam0, 1, 1, (V[]){v_cs_242}); V a_1 = v_tags_247; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_tags_247); r_; });
        } else {
          heff_drop_rec(v_cs_242, 5);
          heff_drop(v_tags_247);
          heff_drop(v_t_2421);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop(v_sg_240);
        heff_drop(v_c_241);
        heff_drop_rec(v_cs_242, 5);
        heff_drop(v_args_244);
        heff_drop(v_tags_247);
        heff_drop(v_t_2414);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_sg_240);
      heff_drop(v_c_241);
      heff_drop_rec(v_cs_242, 5);
      heff_drop(v_args_244);
      heff_drop(v_tags_247);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_sg_240);
    heff_drop(v_c_241);
    heff_drop_rec(v_cs_242, 5);
    heff_drop(v_args_244);
    heff_drop(v_params_246);
    heff_drop(v_tags_247);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2efuse_2emayFuse_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ecompile_2efuse_2emayFuse(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
V g_heff_2ecompile_2efuse_2emayFuse_lam0(V self, V *args) {
  V v_t_2422 = args[0];
  V v_cs_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2423 = ({ V a_0 = v_t_2422; V b_1 = heff_get_n(v_cs_242, 2, 5); HeffT2 r_ = (g_list_2efind_24s2013978071x937269256_24cpr(a_0, b_1)); heff_drop(v_t_2422); heff_drop(b_1); r_; });
  {
    V v_field_2425 = v_t_2423.f[1];
    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2424 == ((int64_t)0ULL)) && ({ V v_x11_2426 = heff_dup(v_field_2425); int c_ = 1; heff_drop(v_x11_2426); c_; })));
    heff_drop(v_field_2425);
    return v_ret_24bool;
  }
}
HEFF_LIT(g_heff_2ecompile_2efuse_2efuseWith_str0, 1, " ");
HEFF_LIT(g_heff_2ecompile_2efuse_2efuseWith_str1, 0, "");
Clo g_heff_2ecompile_2efuse_2efuseWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efuseWith_entry, 7, 0};

V g_heff_2ecompile_2efuse_2efuseWith(V v_c_240, V v_cs_241, V v_p_242, V v_ps_243, V v_args_244, V v_bs_245, V v_s_246) {
top: ;
  V v_t_247 = heff_strAppend(heff_strAppend(heff_dup(v_c_240), ((V)&g_heff_2ecompile_2efuse_2efuseWith_str0)), heff_dup(v_p_242));
  HeffT2 v_t_248 = ({ V a_0 = heff_rfield(v_s_246, 3); V a_1 = v_t_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_247); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      heff_drop(v_c_240);
      heff_drop(v_p_242);
      heff_drop(v_ps_243);
      V v_k_2411 = v_field_2410;
      V v_x_2414;
      if (heff_strEq_c_lent(v_k_2411, ((V)&g_heff_2ecompile_2efuse_2efuseWith_str1), 2)) {
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_args_244);
        heff_drop(v_bs_245);
        heff_drop(v_k_2411);
        v_x_2414 = NTAG(TAG_Nothing);
      } else {
        V v_t_2412 = (g_prelude_2e_2b_2b_24f677743828x1026746250(v_bs_245, heff_get_n(v_cs_241, 1, 5), v_args_244));
        V v_t_2413 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_k_2411}), v_t_2412});
        v_x_2414 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
      }
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2414, v_s_246});
    } else {
      heff_drop(v_field_2410);
      return (g_heff_2ecompile_2efuse_2efuseNew(v_c_240, v_cs_241, v_p_242, v_ps_243, v_args_244, v_bs_245, heff_dup(heff_rfield(v_s_246, 5)), v_s_246));
    }
  }
}
V g_heff_2ecompile_2efuse_2efuseWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2efuseWith(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_heff_2ecompile_2efuse_2efuseKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efuseKnown_entry, 8, 0};

V g_heff_2ecompile_2efuse_2efuseKnown(V v_sg_240, V v_c_241, V v_args_242, V v_p_243, V v_bs_244, V v_x6_245, V v_x7_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nothing: {
    heff_drop(v_sg_240);
    heff_drop(v_c_241);
    heff_drop(v_args_242);
    heff_drop(v_p_243);
    heff_drop(v_bs_244);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_247});
  }
  case TAG_Just: {
    V v_cs_248 = heff_field(v_x6_245, 0);
    switch (heff_tag_of(v_x7_246)) {
    case TAG_Nothing: {
      heff_drop(v_sg_240);
      heff_drop(v_c_241);
      heff_drop(v_args_242);
      heff_drop(v_p_243);
      heff_drop(v_bs_244);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_247});
    }
    case TAG_Just: {
      V v_ps_249 = heff_field(v_x7_246, 0);
      V v_t_2410 = (g_heff_2ecompile_2efuse_2emayFuse(v_sg_240, heff_dup(v_c_241), heff_dup(v_cs_248), heff_dup(v_ps_249), heff_dup(v_args_242), v_bs_244));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        return (g_heff_2ecompile_2efuse_2efuseWith(v_c_241, heff_dup(v_cs_248), v_p_243, heff_dup(v_ps_249), v_args_242, v_bs_244, v_z_247));
      } else {
        heff_drop(v_c_241);
        heff_drop(v_args_242);
        heff_drop(v_p_243);
        heff_drop(v_bs_244);
        heff_drop(v_t_2410);
        return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_247});
      }
    }
    default: return heff_nomatch(v_x7_246);
    }
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ecompile_2efuse_2efuseKnown_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V a6 = a[6]; V r = g_heff_2ecompile_2efuse_2efuseKnown(a[0], a[1], a[2], a[3], a[4], a5, a6, a[7]); heff_drop(a5); heff_drop(a6); return r;
}
Clo g_heff_2ecompile_2efuse_2efuseOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efuseOn_entry, 5, 0};

V g_heff_2ecompile_2efuse_2efuseOn(V v_sg_240, V v_c_241, V v_args_242, V v_x4_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_sg_240);
    heff_drop(v_c_241);
    heff_drop(v_args_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_244});
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_x4_243, 0);
    HeffT3 v_t_246 = (g_heff_2ecompile_2efuse_2eglobalCall_24cpr(v_e_245));
    {
      V v_field_248 = v_t_246.f[1];
      V v_field_249 = v_t_246.f[2];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_p_2410 = v_field_248;
        V v_bs_2411 = v_field_249;
        V v_t_2412 = (g_std_2eordmap_2elookup_24s305164685x44869932(heff_rfield(v_z_244, 1), v_c_241));
        V v_t_2413 = (g_std_2eordmap_2elookup_24s305164685x44869932(heff_rfield(v_z_244, 2), v_p_2410));
        return ({ V a_0 = v_sg_240; V a_1 = v_c_241; V a_2 = v_args_242; V a_3 = v_p_2410; V a_4 = v_bs_2411; V a_5 = v_t_2412; V a_6 = v_t_2413; V a_7 = v_z_244; V r_ = (g_heff_2ecompile_2efuse_2efuseKnown(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2412); heff_drop(v_t_2413); r_; });
      } else {
        heff_drop(v_sg_240);
        heff_drop(v_c_241);
        heff_drop(v_args_242);
        heff_drop(v_field_248);
        heff_drop(v_field_249);
        return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_244});
      }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2efuse_2efuseOn_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2efuse_2efuseOn(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2efuse_2eletHere_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eletHere_entry, 5, 0};

V g_heff_2ecompile_2efuse_2eletHere(V v_sg_240, V v_x_241, V v_b_242, V v_x4_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_sg_240);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_244});
  }
  case TAG_Just: {
    V v_x41_245 = heff_field(v_x4_243, 0);
    switch (heff_tag_of(v_x41_245)) {
    case TAG_MkPair: {
      V v_p_246 = heff_field(v_x41_245, 0);
      V v_bs_247 = heff_field(v_x41_245, 1);
      HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_p_244, 2), v_p_246));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_2410;
          heff_drop(v_x_2411);
          V v_x_2412 = heff_dup(v_x_241);
          V v_e_2413 = heff_dup(v_b_242);
          V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2413), NTAG(TAG_Nil)});
          V v_t_2415 = (g_heff_2ecompile_2eir_2ecountW(v_x_2412, MK_INT(0LL), v_t_2414));
          V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2413), NTAG(TAG_Nil)});
          V v_t_2417 = (g_heff_2ecompile_2eir_2elamW(v_x_2412, v_t_2416));
          V v_t_2418 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2415, v_t_2417}), 0, 2);
          V v_t_2424;
          if (heff_intEq_c(v_t_2418, MK_INT(1LL))) {
            V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2413), NTAG(TAG_Nil)});
            V v_t_2420 = (g_heff_2ecompile_2eir_2ecountW(v_x_2412, MK_INT(0LL), v_t_2419));
            V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2413, NTAG(TAG_Nil)});
            V v_t_2422 = ({ V a_0 = v_x_2412; V a_1 = v_t_2421; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_2412); r_; });
            V v_x1_2423 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2420, v_t_2422}), 1, 2);
            v_t_2424 = heff_bool(!(heff_dup(v_x1_2423) == NTAG(TAG_True)));
            heff_drop(v_x1_2423);
          } else {
            heff_drop(v_x_2412);
            heff_drop(v_e_2413);
            v_t_2424 = NTAG(TAG_False);
          }
          if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
            heff_drop(v_t_2424);
            HeffT1 v_t_2425 = (g_heff_2ecompile_2efuse_2eplugK_24cpr(v_sg_240));
            {
              V v_field_2426 = v_t_2425.f[0];
              return heff_tail(v_field_2426, 3, (V[]){heff_rec_n(3, shape_x__p__bs, (V[]){v_x_241, heff_dup(v_p_246), heff_dup(v_bs_247)}), v_b_242, v_p_244});
            }
          } else {
            heff_drop(v_sg_240);
            heff_drop(v_x_241);
            heff_drop(v_b_242);
            heff_drop(v_t_2424);
            return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_244});
          }
        } else {
          heff_drop(v_sg_240);
          heff_drop(v_x_241);
          heff_drop(v_b_242);
          heff_drop(v_field_2410);
          return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_244});
        }
      }
    }
    default: return heff_nomatch(v_x41_245);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2efuse_2eletHere_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2efuse_2eletHere(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2efuse_2ehere_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_entry, 3, 0};

V g_heff_2ecompile_2efuse_2ehere(V v_sg_240, V v_x2_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EApp: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_args_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_EGlobal: {
      V v_c_245 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      HeffT2 v_t_246 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_z_242, 1), v_c_245));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_cs_249 = v_field_248;
          V v_t_2410 = (g_heff_2ecompile_2efuse_2enthF(heff_get_n(v_cs_249, 1, 5), v_args_244));
          return ({ V a_0 = v_ru_24x2_241_24EApp; V a_1 = v_sg_240; V a_2 = v_c_245; V a_3 = v_args_244; V a_4 = v_t_2410; V a_5 = v_z_242; V r_ = (g_heff_2ecompile_2efuse_2efuseOn_24tok2(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2410); r_; });
        } else {
          heff_drop(v_sg_240);
          heff_drop(v_args_244);
          heff_drop(v_c_245);
          heff_drop(v_field_248);
          return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_242});
        }
      }
    }
    default: {
      heff_drop(v_sg_240);
      heff_drop(v_x21_243);
      heff_drop(v_args_244);
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_242});
    }
    }
  }
  case TAG_ELet: {
    V v_x_2411 = heff_field(v_x2_241, 0);
    V v_a_2412 = heff_field(v_x2_241, 1);
    V v_b_2413 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2414 = ({ V a_0 = v_a_2412; V r_ = (g_heff_2ecompile_2efuse_2eglobalCall(a_0)); heff_drop(v_a_2412); r_; });
    return ({ V a_0 = v_sg_240; V a_1 = v_x_2411; V a_2 = v_b_2413; V a_3 = v_t_2414; V a_4 = v_z_242; V r_ = (g_heff_2ecompile_2efuse_2eletHere(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2414); r_; });
  }
  case TAG_ECall: {
    V v_c_2415 = heff_field(v_x2_241, 0);
    V v_args_2416 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_2417 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_z_242, 1), v_c_2415));
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      if ((v_tag_2418 == ((int64_t)0ULL))) {
        V v_cs_2420 = v_field_2419;
        V v_t_2421 = (g_heff_2ecompile_2efuse_2enthF(heff_get_n(v_cs_2420, 1, 5), v_args_2416));
        return ({ V a_0 = v_ru_24x2_241_24ECall; V a_1 = v_sg_240; V a_2 = v_c_2415; V a_3 = v_args_2416; V a_4 = v_t_2421; V a_5 = v_z_242; V r_ = (g_heff_2ecompile_2efuse_2efuseOn_24tok2(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2421); r_; });
      } else {
        heff_drop(v_sg_240);
        heff_drop(v_c_2415);
        heff_drop(v_args_2416);
        heff_drop(v_field_2419);
        return heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_242});
      }
    }
  }
  default: {
    heff_drop(v_sg_240);
    heff_drop(v_x2_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_242});
  }
  }
}
V g_heff_2ecompile_2efuse_2ehere_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2ehere(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2efuse_2esites_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2esites_lam1(V self, V *args);
Clo g_heff_2ecompile_2efuse_2esites_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2esites_entry, 2, 0};

V g_heff_2ecompile_2efuse_2esites(V v_sg_240, V v_e_241) {
top: ;
  V v_f_242 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2esites_clo), 1, (V[]){heff_dup(v_sg_240)}));
  V v_m_244 = (g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258(heff_clo_n(g_heff_2ecompile_2efuse_2esites_lam0, 1, 1, (V[]){v_f_242}), v_e_241));
  return heff_clo_n(g_heff_2ecompile_2efuse_2esites_lam1, 1, 2, (V[]){v_m_244, v_sg_240});
}
V g_heff_2ecompile_2efuse_2esites_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2esites(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2esites_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_f_242 = heff_env(self)[0];
  heff_drop(v_x_243);
  heff_clo_take(self, 1);
  return v_f_242;
}
V g_heff_2ecompile_2efuse_2esites_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_sg_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_x2_249 = heff_tr(g_heff_2ecompile_2efuse_2ehere(heff_dup(v_sg_240), heff_dup(v_x_247), v_s_248));
    switch (heff_tag_of(v_x2_249)) {
    case TAG_MkPair: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      V v_s_2411 = heff_field(v_x2_249, 1);
      heff_take_n(v_x2_249, 3ULL, 2);
      V v_go_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2esites_clo), 1, (V[]){v_sg_240}));
      switch (heff_tag_of(v_x_2410)) {
      case TAG_Nothing: {
        heff_drop(v_go_2412);
        return heff_tag_re_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_x_247, v_s_2411});
      }
      case TAG_Just: {
        V v_e2_2413 = heff_field(v_x_2410, 0);
        heff_take_n(v_x_2410, 1ULL, 1);
        heff_drop(v_x_247);
        heff_drop_cell(v_ru_24x2_246_24MkPair, 2);
        V f_ = v_go_2412;
        heff_room[0] = v_e2_2413;
        heff_room[1] = v_s_2411;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
      default: return heff_nomatch(v_x_2410);
      }
    }
    default: return heff_nomatch(v_x2_249);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
HEFF_LIT(g_heff_2ecompile_2efuse_2efuseWith_24tok1_str0, 1, " ");
HEFF_LIT(g_heff_2ecompile_2efuse_2efuseWith_24tok1_str1, 0, "");
Clo g_heff_2ecompile_2efuse_2efuseWith_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efuseWith_24tok1_entry, 8, 0};

V g_heff_2ecompile_2efuse_2efuseWith_24tok1(V v_tok_240, V v_c_241, V v_cs_242, V v_p_243, V v_ps_244, V v_args_245, V v_bs_246, V v_s_247) {
top: ;
  V v_t_248 = heff_strAppend(heff_strAppend(heff_dup(v_c_241), ((V)&g_heff_2ecompile_2efuse_2efuseWith_24tok1_str0)), heff_dup(v_p_243));
  HeffT2 v_t_249 = ({ V a_0 = heff_rfield(v_s_247, 3); V a_1 = v_t_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_248); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      heff_drop(v_c_241);
      heff_drop(v_p_243);
      heff_drop(v_ps_244);
      V v_k_2412 = v_field_2411;
      V v_x_2415;
      if (heff_strEq_c_lent(v_k_2412, ((V)&g_heff_2ecompile_2efuse_2efuseWith_24tok1_str1), 2)) {
        heff_drop_cell(v_tok_240, 1);
        heff_drop_rec(v_cs_242, 5);
        heff_drop(v_args_245);
        heff_drop(v_bs_246);
        heff_drop(v_k_2412);
        v_x_2415 = NTAG(TAG_Nothing);
      } else {
        V v_t_2413 = (g_prelude_2e_2b_2b_24f677743828x1026746250(v_bs_246, heff_get_n(v_cs_242, 1, 5), v_args_245));
        V v_t_2414 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_EGlobal, 1, (V[]){v_k_2412}), v_t_2413});
        v_x_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
      }
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2415, v_s_247});
    } else {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_field_2411);
      HEFF_LAST return g_heff_2ecompile_2efuse_2efuseNew(v_c_241, v_cs_242, v_p_243, v_ps_244, v_args_245, v_bs_246, heff_dup(heff_rfield(v_s_247, 5)), v_s_247);
    }
  }
}
V g_heff_2ecompile_2efuse_2efuseWith_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2efuseWith_24tok1(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}