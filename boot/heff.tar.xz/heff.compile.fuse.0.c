// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define TAG_Tip 31527
#define LBL_arity 294440695
#define LBL_arms 9498206
#define LBL_at 9882
#define LBL_bs 9912
#define LBL_c 317
#define LBL_consumers 1203455020
#define LBL_count 296209705
#define LBL_cp 9940
#define LBL_cvars 296399145
#define LBL_fixed 298804110
#define LBL_fresh 299054408
#define LBL_go 10063
#define LBL_key 315609
#define LBL_left 9813198
#define LBL_made 9839068
#define LBL_p 330
#define LBL_params 951713969
#define LBL_parity 951721880
#define LBL_producers 572620898
#define LBL_rest 9992347
#define LBL_safe 10017876
#define LBL_supply 1056026650
#define LBL_tags 10047712
#define LBL_total 311908190
#define LBL_underLam 296337946
#define LBL_x 338
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_supply__consumers__producers__made__fresh__left[] = {LBL_supply, LBL_consumers, LBL_producers, LBL_made, LBL_fresh, LBL_left};
static uint32_t shape_x__p__bs[] = {LBL_x, LBL_p, LBL_bs};
V g_heff_2ecompile_2efuse_2earmCopy(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2earmCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2earmCopy_clo;
V g_heff_2ecompile_2efuse_2earmGiven(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2earmGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2earmGiven_clo;
V g_heff_2ecompile_2efuse_2earmWorks(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2earmWorks_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2earmWorks_clo;
V g_heff_2ecompile_2efuse_2ecallOf(V, V, V);
V g_heff_2ecompile_2efuse_2ecallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ecallOf_clo;
V g_heff_2ecompile_2efuse_2econsRec(V, V, V);
V g_heff_2ecompile_2efuse_2econsRec_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2econsRec_clo;
V g_heff_2ecompile_2efuse_2eelemF(V, V);
V g_heff_2ecompile_2efuse_2eelemF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eelemF_clo;
V g_heff_2ecompile_2efuse_2eendAt(V, V);
V g_heff_2ecompile_2efuse_2eendAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eendAt_clo;
V g_heff_2ecompile_2efuse_2efindArm(V, V);
V g_heff_2ecompile_2efuse_2efindArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efindArm_clo;
V g_heff_2ecompile_2efuse_2efixedGo(V, V, V);
V g_heff_2ecompile_2efuse_2efixedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efixedGo_clo;
V g_heff_2ecompile_2efuse_2efixedGo_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2efixedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efixedGo_24dps_clo;
V g_heff_2ecompile_2efuse_2efuseNew(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseNew_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseNew_clo;
V g_heff_2ecompile_2efuse_2efuseOn(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseOn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseOn_clo;
V g_heff_2ecompile_2efuse_2efuseWith(V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseWith_clo;
V g_heff_2ecompile_2efuse_2eglobalCall(V);
V g_heff_2ecompile_2efuse_2eglobalCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eglobalCall_clo;
V g_heff_2ecompile_2efuse_2egoesOf_24dps(V, V);
V g_heff_2ecompile_2efuse_2egoesOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2egoesOf_24dps_clo;
V g_heff_2ecompile_2efuse_2ehere(V, V);
V g_heff_2ecompile_2efuse_2ehere_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ehere_clo;
V g_heff_2ecompile_2efuse_2einitF(V);
V g_heff_2ecompile_2efuse_2einitF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einitF_clo;
V g_heff_2ecompile_2efuse_2einitF_24dps(V, V);
V g_heff_2ecompile_2efuse_2einitF_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einitF_24dps_clo;
V g_heff_2ecompile_2efuse_2einsertAt(V, V, V);
V g_heff_2ecompile_2efuse_2einsertAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einsertAt_clo;
V g_heff_2ecompile_2efuse_2einsertAt_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2einsertAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einsertAt_24dps_clo;
V g_heff_2ecompile_2efuse_2ekidsF(V, V);
V g_heff_2ecompile_2efuse_2ekidsF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ekidsF_clo;
V g_heff_2ecompile_2efuse_2elastF(V);
V g_heff_2ecompile_2efuse_2elastF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2elastF_clo;
V g_heff_2ecompile_2efuse_2eletHere(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2eletHere_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eletHere_clo;
V g_heff_2ecompile_2efuse_2emayFuse(V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2emayFuse_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2emayFuse_clo;
V g_heff_2ecompile_2efuse_2enthF(V, V);
V g_heff_2ecompile_2efuse_2enthF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2enthF_clo;
V g_heff_2ecompile_2efuse_2eonceIn(V, V);
V g_heff_2ecompile_2efuse_2eonceIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eonceIn_clo;
V g_heff_2ecompile_2efuse_2epathCalls(V, V);
V g_heff_2ecompile_2efuse_2epathCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2epathCalls_clo;
V g_heff_2ecompile_2efuse_2eplugK(V);
V g_heff_2ecompile_2efuse_2eplugK_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eplugK_clo;
V g_heff_2ecompile_2efuse_2erecall(V, V, V, V);
V g_heff_2ecompile_2efuse_2erecall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2erecall_clo;
V g_heff_2ecompile_2efuse_2erecallAt(V, V, V);
V g_heff_2ecompile_2efuse_2erecallAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2erecallAt_clo;
V g_heff_2ecompile_2efuse_2eremoveAt(V, V);
V g_heff_2ecompile_2efuse_2eremoveAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eremoveAt_clo;
V g_heff_2ecompile_2efuse_2eremoveAt_24dps(V, V, V);
V g_heff_2ecompile_2efuse_2eremoveAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eremoveAt_24dps_clo;
V g_heff_2ecompile_2efuse_2esameGo(V, V);
V g_heff_2ecompile_2efuse_2esameGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esameGo_clo;
V g_heff_2ecompile_2efuse_2eselfCalls(V, V, V);
V g_heff_2ecompile_2efuse_2eselfCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eselfCalls_clo;
V g_heff_2ecompile_2efuse_2esetAt(V, V, V);
V g_heff_2ecompile_2efuse_2esetAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esetAt_clo;
V g_heff_2ecompile_2efuse_2esetAt_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2esetAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esetAt_24dps_clo;
V g_heff_2ecompile_2efuse_2etagEnd(V, V, V);
V g_heff_2ecompile_2efuse_2etagEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2etagEnd_clo;
V g_heff_2ecompile_2efuse_2etraverseF(V, V);
V g_heff_2ecompile_2efuse_2etraverseF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2etraverseF_clo;
V g_heff_2ecompile_2efuse_2etraverseF_24s847914641x1886275130(V, V);
V g_heff_2ecompile_2efuse_2etraverseF_24s847914641x1886275130_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2etraverseF_24s847914641x1886275130_clo;
V g_heff_2ecompile_2efuse_2evarAt(V, V, V);
V g_heff_2ecompile_2efuse_2evarAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2evarAt_clo;
V g_heff_2ecompile_2efuse_2eworkPure(V, V);
V g_heff_2ecompile_2efuse_2eworkPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eworkPure_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2efailing_get(void);
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany_24s526192058x2139448609(V, V);
V g_list_2eany_24s526192058x2139448609_entry(V self, V *a);
extern Clo g_list_2eany_24s526192058x2139448609_clo;
V g_list_2efilter_24s2102446697x281519753(V);
V g_list_2efilter_24s2102446697x281519753_entry(V self, V *a);
extern Clo g_list_2efilter_24s2102446697x281519753_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s455728131x407835966(V, V);
V g_list_2efoldl_24s455728131x407835966_entry(V self, V *a);
extern Clo g_list_2efoldl_24s455728131x407835966_clo;
V g_list_2efoldl_24s753153351x493712762(V, V);
V g_list_2efoldl_24s753153351x493712762_entry(V self, V *a);
extern Clo g_list_2efoldl_24s753153351x493712762_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1842320150x747311840(V);
V g_list_2emap_24s1842320150x747311840_entry(V self, V *a);
extern Clo g_list_2emap_24s1842320150x747311840_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_map_2eempty_get(void);
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f677743828x1026746250(V, V, V);
V g_prelude_2e_2b_2b_24f677743828x1026746250_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f677743828x1026746250_clo;
Clo g_heff_2ecompile_2efuse_2enthF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2enthF_entry, 2, 0};

V g_heff_2ecompile_2efuse_2enthF(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2enthF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2efuse_2enthF(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2efuse_2eremoveAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eremoveAt_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eremoveAt(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return v_xs_243;
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_heff_2ecompile_2efuse_2eremoveAt_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2eremoveAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eremoveAt(a[0], a[1]);
}
Clo g_heff_2ecompile_2efuse_2esetAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2esetAt_24dps_entry, 4, 0};

V g_heff_2ecompile_2efuse_2esetAt_24dps(V v_i_240, V v_y_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_y_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_xs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_y_241, v_xs_245}));
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_y_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_247;
      v_i_240 = t_0;
      v_y_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2esetAt_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2esetAt_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2efuse_2einsertAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2einsertAt_24dps_entry, 4, 0};

V g_heff_2ecompile_2efuse_2einsertAt_24dps(V v_i_240, V v_y_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_241, NTAG(TAG_Nil)});
    return heff_setField(v_d_243, MK_INT(1LL), v_t_244);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_xs_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      V v_t_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_241, heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, v_xs_246})});
      return heff_setField(v_d_243, MK_INT(1LL), v_t_248);
    } else {
      V v_cell_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_y_241;
      V t_2 = v_xs_246;
      V t_3 = v_cell_249;
      v_i_240 = t_0;
      v_y_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2einsertAt_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2einsertAt_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2efuse_2einitF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2einitF_entry, 1, 0};

V g_heff_2ecompile_2efuse_2einitF(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_246 = (g_heff_2ecompile_2efuse_2einitF_24dps(v_x12_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuse_2einitF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2einitF(a[0]);
}
Clo g_heff_2ecompile_2efuse_2evarAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2evarAt_entry, 3, 0};

V g_heff_2ecompile_2efuse_2evarAt(V v_i_240, V v_x_241, V v_es_242) {
top: ;
  V v_x3_243 = (g_heff_2ecompile_2efuse_2enthF(v_i_240, v_es_242));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop(v_x_241);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x_244)) {
    case TAG_EVar: {
      V v_y_245 = heff_field(v_x_244, 0);
      heff_take_n(v_x_244, 1ULL, 1);
      return heff_strEq(v_x_241, v_y_245);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_244, 0ULL, 1);
      heff_drop(v_x_241);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      heff_take_n(v_x_244, 0ULL, 2);
      heff_drop(v_x_241);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_take_n(v_x_244, 0ULL, 2);
      heff_drop(v_x_241);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_take_n(v_x_244, 0ULL, 3);
      heff_drop(v_x_241);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_take_n(v_x_244, 0ULL, 2);
      heff_drop(v_x_241);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_take_n(v_x_244, 0ULL, 4);
      heff_drop(v_x_241);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_take_n(v_x_244, 0ULL, 2);
      heff_drop(v_x_241);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_take_n(v_x_244, 0ULL, 2);
      heff_drop(v_x_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_take_n(v_x_244, 0ULL, 1);
      heff_drop(v_x_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_244, 0ULL, 2);
      heff_drop(v_x_241);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_take_n(v_x_244, 0ULL, 2);
      heff_drop(v_x_241);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_take_n(v_x_244, 0ULL, 1);
      heff_drop(v_x_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_take_n(v_x_244, 0ULL, 1);
      heff_drop(v_x_241);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_take_n(v_x_244, 0ULL, 1);
      heff_drop(v_x_241);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_take_n(v_x_244, 0ULL, 1);
      heff_drop(v_x_241);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_take_n(v_x_244, 0ULL, 2);
      heff_drop(v_x_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_take_n(v_x_244, 0ULL, 1);
      heff_drop(v_x_241);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_x_241);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_take_n(v_x_244, 0ULL, 2);
      heff_drop(v_x_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2efuse_2evarAt_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2efuse_2evarAt(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2efuse_2eworkPure_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2efuse_2eworkPure_str1, 5, "False");
V g_heff_2ecompile_2efuse_2eworkPure_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2eworkPure_lam1(V self, V *args);
Clo g_heff_2ecompile_2efuse_2eworkPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eworkPure_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eworkPure(V v_sg_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_x3_244 = ({ V a_0 = v_g_243; V b_1 = heff_get_n(v_sg_240, 0, 2); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_x21_248 = heff_field(v_x2_241, 0);
    V v_as_249 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_EVar: {
      heff_take_n(v_x21_248, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_as_249);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_2411 = heff_field(v_x21_248, 0);
      heff_take_n(v_x21_248, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      V v_t_2412 = (g_map_2elookup_24s1546226666x2146984184(v_g_2411, heff_rfield(v_sg_240, 1)));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_Nothing: {
        heff_drop_rec(v_sg_240, 2);
        heff_drop(v_as_249);
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_ar_2413 = heff_field(v_t_2412, 0);
        heff_take_n(v_t_2412, 1ULL, 1);
        V v_t_2414 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_249));
        if (heff_intLe_c(v_t_2414, v_ar_2413)) {
          V v_t_2416 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){v_sg_240}));
          return ({ V a_0 = v_t_2416; V a_1 = v_as_249; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_249); r_; });
        } else {
          heff_drop_rec(v_sg_240, 2);
          heff_drop(v_as_249);
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    case TAG_ELam: {
      V v_xs_2417 = heff_field(v_x21_248, 0);
      V v_b_2418 = heff_field(v_x21_248, 1);
      heff_take_n(v_x21_248, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      V v_t_2419 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_249));
      V v_t_2420 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_2417));
      if (heff_intLe_c(v_t_2419, v_t_2420)) {
        V v_t_2422 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){heff_dup(v_sg_240)}));
        V v_t_2423 = (g_list_2eall(v_t_2422, v_as_249));
        if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
          heff_drop(v_t_2423);
          V v_t_2424 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_as_249; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_as_249); r_; });
          V v_t_2425 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2417; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
          if (heff_intLt_c(v_t_2424, v_t_2425)) {
            heff_drop_rec(v_sg_240, 2);
            heff_drop(v_b_2418);
            return NTAG(TAG_True);
          } else {
            V t_0 = v_sg_240;
            V t_1 = v_b_2418;
            v_sg_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
        } else {
          heff_drop_rec(v_sg_240, 2);
          heff_drop(v_as_249);
          heff_drop(v_xs_2417);
          heff_drop(v_b_2418);
          heff_drop(v_t_2423);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop_rec(v_sg_240, 2);
        heff_drop(v_as_249);
        heff_drop(v_xs_2417);
        heff_drop(v_b_2418);
        return NTAG(TAG_False);
      }
    }
    case TAG_EApp: {
      V v_f_2427 = heff_field(v_x21_248, 0);
      V v_bs_2428 = heff_field(v_x21_248, 1);
      heff_take_n(v_x21_248, 3ULL, 2);
      V v_t_2429 = (g_prelude_2e_2b_2b(v_bs_2428, v_as_249));
      V t_0 = v_sg_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_f_2427, v_t_2429});
      v_sg_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      heff_take_n(v_x21_248, 0ULL, 3);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_as_249);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_take_n(v_x21_248, 0ULL, 2);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_as_249);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_take_n(v_x21_248, 0ULL, 4);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_as_249);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_take_n(v_x21_248, 0ULL, 2);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_as_249);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_take_n(v_x21_248, 0ULL, 2);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_as_249);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_248, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_as_249);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x21_248, 0ULL, 2);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_as_249);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_take_n(v_x21_248, 0ULL, 2);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_as_249);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_take_n(v_x21_248, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_as_249);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_take_n(v_x21_248, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_as_249);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_take_n(v_x21_248, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_as_249);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_248, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_as_249);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_248, 0ULL, 2);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_as_249);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_take_n(v_x21_248, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_as_249);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_as_249);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_take_n(v_x21_248, 0ULL, 2);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_as_249);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  case TAG_ELet: {
    V v_a_2458 = heff_field(v_x2_241, 1);
    V v_b_2459 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2460 = (g_heff_2ecompile_2efuse_2eworkPure(heff_dup(v_sg_240), v_a_2458));
    if ((heff_dup(v_t_2460) == NTAG(TAG_True))) {
      heff_drop(v_t_2460);
      V t_0 = v_sg_240;
      V t_1 = v_b_2459;
      v_sg_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_b_2459);
      heff_drop(v_t_2460);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    V v_fs_2461 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eworkPure_lam0, 1, 1, (V[]){v_sg_240}); V a_1 = v_fs_2461; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_fs_2461); r_; });
  }
  case TAG_EProj: {
    V v_e_2467 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 4);
    V t_0 = v_sg_240;
    V t_1 = v_e_2467;
    v_sg_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2472 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2473 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){v_sg_240}));
    return ({ V a_0 = v_t_2473; V a_1 = v_as_2472; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2472); r_; });
  }
  case TAG_EMatch: {
    V v_s_2474 = heff_field(v_x2_241, 0);
    V v_arms_2475 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2476 = (g_heff_2ecompile_2efuse_2eworkPure(heff_dup(v_sg_240), v_s_2474));
    if ((heff_dup(v_t_2476) == NTAG(TAG_True))) {
      heff_drop(v_t_2476);
      V v_t_2477 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_arms_2475));
      if (heff_intEq_c(v_t_2477, MK_INT(2LL))) {
        V v_t_2479 = (g_list_2eany_24s526192058x2139448609(((V)&g_heff_2ecompile_2efuse_2eworkPure_str0), v_arms_2475));
        if ((heff_dup(v_t_2479) == NTAG(TAG_True))) {
          heff_drop(v_t_2479);
          V v_t_2480 = (g_list_2eany_24s526192058x2139448609(((V)&g_heff_2ecompile_2efuse_2eworkPure_str1), v_arms_2475));
          if ((heff_dup(v_t_2480) == NTAG(TAG_True))) {
            heff_drop(v_t_2480);
            return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eworkPure_lam1, 1, 1, (V[]){v_sg_240}); V a_1 = v_arms_2475; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2475); r_; });
          } else {
            heff_drop_rec(v_sg_240, 2);
            heff_drop(v_arms_2475);
            heff_drop(v_t_2480);
            return NTAG(TAG_False);
          }
        } else {
          heff_drop_rec(v_sg_240, 2);
          heff_drop(v_arms_2475);
          heff_drop(v_t_2479);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop_rec(v_sg_240, 2);
        heff_drop(v_arms_2475);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_arms_2475);
      heff_drop(v_t_2476);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2487 = heff_field(v_x2_241, 0);
    V v_as_2488 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_x1_2489 = ({ V a_0 = v_p_2487; V b_1 = heff_dup(g_heff_2ecompile_2esimplify_2efailing_get()); V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_x1_2489) == NTAG(TAG_True))) {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_as_2488);
      heff_drop(v_x1_2489);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_x1_2489);
      V v_t_2490 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){v_sg_240}));
      return ({ V a_0 = v_t_2490; V a_1 = v_as_2488; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2488); r_; });
    }
  }
  case TAG_ECall: {
    V v_g_2491 = heff_field(v_x2_241, 0);
    V v_as_2492 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2493 = (g_map_2elookup_24s1546226666x2146984184(v_g_2491, heff_rfield(v_sg_240, 1)));
    switch (heff_tag_of(v_t_2493)) {
    case TAG_Nothing: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_as_2492);
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_ar_2494 = heff_field(v_t_2493, 0);
      heff_take_n(v_t_2493, 1ULL, 1);
      V v_t_2495 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2492));
      if (heff_intLe_c(v_t_2495, v_ar_2494)) {
        V v_t_2497 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){v_sg_240}));
        return ({ V a_0 = v_t_2497; V a_1 = v_as_2492; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2492); r_; });
      } else {
        heff_drop_rec(v_sg_240, 2);
        heff_drop(v_as_2492);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_t_2493);
    }
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2eworkPure_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eworkPure(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2eworkPure_lam0(V self, V *args) {
  V v_p_2463 = args[0];
  V v_sg_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466;
  switch (heff_tag_of(v_p_2463)) {
  case TAG_MkPair: {
    V v_y_2465 = heff_field(v_p_2463, 1);
    heff_take_n(v_p_2463, 2ULL, 2);
    v_t_2466 = v_y_2465;
    break;
  }
  default: heff_nomatch(v_p_2463);
  }
  return (g_heff_2ecompile_2efuse_2eworkPure(v_sg_240, v_t_2466));
}
V g_heff_2ecompile_2efuse_2eworkPure_lam1(V self, V *args) {
  V v_a_2481 = args[0];
  V v_sg_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2485;
  switch (heff_tag_of(v_a_2481)) {
  case TAG_MkArm: {
    V v_b_2484 = heff_field(v_a_2481, 2);
    heff_take_n(v_a_2481, 4ULL, 3);
    v_t_2485 = v_b_2484;
    break;
  }
  default: heff_nomatch(v_a_2481);
  }
  return (g_heff_2ecompile_2efuse_2eworkPure(v_sg_240, v_t_2485));
}
V g_heff_2ecompile_2efuse_2epathCalls_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2epathCalls_lam1(V self, V *args);
Clo g_heff_2ecompile_2efuse_2epathCalls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2epathCalls_entry, 2, 0};

V g_heff_2ecompile_2efuse_2epathCalls(V v_me_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_ru_24x2_241_24EVar = heff_take_reuse_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_me_240, 4);
    return heff_tag_at_n(v_ru_24x2_241_24EVar, TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EGlobal = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    if (heff_strEq_c(v_g_243, heff_get_n(v_me_240, 0, 4))) {
      heff_drop_cell(v_ru_24x2_241_24EGlobal, 1);
      return NTAG(TAG_Nothing);
    } else {
      return heff_tag_at_n(v_ru_24x2_241_24EGlobal, TAG_Just, 1, (V[]){MK_INT(0LL)});
    }
  }
  case TAG_ELam: {
    V v_b_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_246)));
    V v_t_248 = (g_heff_2ecompile_2eir_2enubI(v_t_247));
    V v_t_249 = ({ V a_0 = heff_take_field(v_me_240, 0); V a_1 = v_t_248; V r_ = (g_heff_2ecompile_2efuse_2eelemF(a_0, a_1)); heff_drop(v_t_248); r_; });
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop_rec(v_me_240, 4);
      heff_drop(v_b_246);
      heff_drop_cell(v_ru_24x2_241_24ELam, 2);
      heff_drop(v_t_249);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_249);
      V v_x_2410 = heff_get_n(v_me_240, 3, 4);
      V v_t_2411 = heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_Cons, 2, (V[]){heff_dup(v_b_246), NTAG(TAG_Nil)});
      V v_t_2412 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_2410), MK_INT(0LL), v_t_2411));
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_246, NTAG(TAG_Nil)});
      V v_t_2414 = (g_heff_2ecompile_2eir_2elamW(v_x_2410, v_t_2413));
      V v_x_2415 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2412, v_t_2414}), 0, 2);
      if (heff_intLt_c(MK_INT(0LL), v_x_2415)) {
        return NTAG(TAG_Nothing);
      } else {
        return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)});
      }
    }
  }
  case TAG_EApp: {
    V v_x21_2417 = heff_field(v_x2_241, 0);
    V v_as_2418 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2417)) {
    case TAG_EVar: {
      V v_t_2420 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2421 = (g_list_2emap(v_t_2420, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2417, v_as_2418})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2421; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2421); r_; });
    }
    case TAG_EGlobal: {
      V v_g_2422 = heff_field(v_x21_2417, 0);
      V v_ru_24x21_2417_24EGlobal = heff_take_reuse_n(v_x21_2417, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      if (heff_strEq_c(heff_dup(v_g_2422), heff_dup(heff_rfield(v_me_240, 0)))) {
        heff_drop_cell(v_ru_24x21_2417_24EGlobal, 1);
        return ({ V a_0 = v_me_240; V a_1 = v_g_2422; V a_2 = v_as_2418; V r_ = (g_heff_2ecompile_2efuse_2eselfCalls(a_0, a_1, a_2)); heff_drop(v_as_2418); r_; });
      } else {
        heff_drop(v_g_2422);
        V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
        V v_ms_2425 = (g_list_2emap(v_t_2424, v_as_2418));
        return ({ V a_0 = heff_tag_at_n(v_ru_24x21_2417_24EGlobal, TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2425; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2425); r_; });
      }
    }
    case TAG_ELam: {
      V v_t_2428 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2429 = (g_list_2emap(v_t_2428, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2417, v_as_2418})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2429; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2429); r_; });
    }
    case TAG_EApp: {
      V v_t_2432 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2433 = (g_list_2emap(v_t_2432, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2417, v_as_2418})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2433; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2433); r_; });
    }
    case TAG_ELet: {
      V v_t_2437 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2438 = (g_list_2emap(v_t_2437, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2417, v_as_2418})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2438; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2438); r_; });
    }
    case TAG_ERecord: {
      V v_t_2441 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2442 = (g_list_2emap(v_t_2441, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2417, v_as_2418})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2442; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2442); r_; });
    }
    case TAG_EProj: {
      V v_t_2447 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2448 = (g_list_2emap(v_t_2447, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2417, v_as_2418})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2448; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2448); r_; });
    }
    case TAG_ETag: {
      V v_t_2451 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2452 = (g_list_2emap(v_t_2451, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2417, v_as_2418})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2452; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2452); r_; });
    }
    case TAG_EMatch: {
      V v_t_2455 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2456 = (g_list_2emap(v_t_2455, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2417, v_as_2418})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2456; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2456); r_; });
    }
    case TAG_EPrim: {
      V v_t_2458 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2459 = (g_list_2emap(v_t_2458, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2417, v_as_2418})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2459; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2459); r_; });
    }
    case TAG_EPrimCall: {
      V v_t_2462 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2463 = (g_list_2emap(v_t_2462, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2417, v_as_2418})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2463; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2463); r_; });
    }
    case TAG_ECall: {
      V v_t_2466 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2467 = (g_list_2emap(v_t_2466, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2417, v_as_2418})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2467; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2467); r_; });
    }
    case TAG_EInt: {
      V v_t_2469 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2470 = (g_list_2emap(v_t_2469, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2417, v_as_2418})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2470; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2470); r_; });
    }
    case TAG_EFloat: {
      V v_t_2472 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2473 = (g_list_2emap(v_t_2472, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2417, v_as_2418})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2473; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2473); r_; });
    }
    case TAG_EStr: {
      V v_t_2475 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2476 = (g_list_2emap(v_t_2475, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2417, v_as_2418})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2476; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2476); r_; });
    }
    case TAG_EBytes: {
      V v_t_2478 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2479 = (g_list_2emap(v_t_2478, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2417, v_as_2418})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2479; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2479); r_; });
    }
    case TAG_EFixed: {
      V v_t_2482 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2483 = (g_list_2emap(v_t_2482, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2417, v_as_2418})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2483; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2483); r_; });
    }
    case TAG_EFloat32: {
      V v_t_2485 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2486 = (g_list_2emap(v_t_2485, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2417, v_as_2418})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2486; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2486); r_; });
    }
    case TAG_EAbandon: {
      V v_t_2487 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2488 = (g_list_2emap(v_t_2487, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2417, v_as_2418})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2488; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2488); r_; });
    }
    case TAG_EFix: {
      V v_t_2491 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2492 = (g_list_2emap(v_t_2491, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2417, v_as_2418})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2492; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2492); r_; });
    }
    default: return heff_nomatch(v_x21_2417);
    }
  }
  case TAG_ELet: {
    V v_a_2494 = heff_field(v_x2_241, 1);
    V v_b_2495 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_x1_2496 = (g_heff_2ecompile_2efuse_2epathCalls(heff_dup(v_me_240), v_a_2494));
    V v_x2_2497 = (g_heff_2ecompile_2efuse_2epathCalls(v_me_240, v_b_2495));
    switch (heff_tag_of(v_x1_2496)) {
    case TAG_Nothing: {
      heff_drop(v_x2_2497);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_a_2498 = heff_field(v_x1_2496, 0);
      V v_ru_24x1_2496_24Just = heff_take_reuse_n(v_x1_2496, 1ULL, 1);
      switch (heff_tag_of(v_x2_2497)) {
      case TAG_Nothing: {
        heff_drop(v_a_2498);
        heff_drop_cell(v_ru_24x1_2496_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_b_2499 = heff_field(v_x2_2497, 0);
        heff_take_n(v_x2_2497, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2496_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2498, v_b_2499)});
      }
      default: return heff_nomatch(v_x2_2497);
      }
    }
    default: return heff_nomatch(v_x1_2496);
    }
  }
  case TAG_ERecord: {
    V v_fs_24100 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    V v_ms_24106 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2efuse_2epathCalls_lam0, 1, 1, (V[]){v_me_240}), v_fs_24100));
    return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_24106; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_24106); r_; });
  }
  case TAG_EProj: {
    V v_e_24107 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 4);
    V t_0 = v_me_240;
    V t_1 = v_e_24107;
    v_me_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_24112 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_24113 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
    V v_ms_24114 = (g_list_2emap(v_t_24113, v_as_24112));
    return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_24114; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_24114); r_; });
  }
  case TAG_EMatch: {
    V v_s_24115 = heff_field(v_x2_241, 0);
    V v_arms_24116 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_x1_24117 = (g_heff_2ecompile_2efuse_2epathCalls(heff_dup(v_me_240), v_s_24115));
    V v_x1_24123 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2efuse_2epathCalls_lam1, 1, 1, (V[]){v_me_240}), v_arms_24116));
    V v_x2_24126;
    switch (heff_tag_of(v_x1_24123)) {
    case TAG_Nil: {
      v_x2_24126 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)});
      break;
    }
    case TAG_Cons: {
      V v_m_24124 = heff_field(v_x1_24123, 0);
      V v_rest_24125 = heff_field(v_x1_24123, 1);
      heff_take_n(v_x1_24123, 3ULL, 2);
      v_x2_24126 = ({ V a_0 = v_m_24124; V a_1 = v_rest_24125; V r_ = (g_heff_2ecompile_2efuse_2esameGo(a_0, a_1)); heff_drop(v_rest_24125); r_; });
      break;
    }
    default: heff_nomatch(v_x1_24123);
    }
    switch (heff_tag_of(v_x1_24117)) {
    case TAG_Nothing: {
      heff_drop(v_x2_24126);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_a_24127 = heff_field(v_x1_24117, 0);
      V v_ru_24x1_24117_24Just = heff_take_reuse_n(v_x1_24117, 1ULL, 1);
      switch (heff_tag_of(v_x2_24126)) {
      case TAG_Nothing: {
        heff_drop(v_a_24127);
        heff_drop_cell(v_ru_24x1_24117_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_b_24128 = heff_field(v_x2_24126, 0);
        heff_take_n(v_x2_24126, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_24117_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_24127, v_b_24128)});
      }
      default: return heff_nomatch(v_x2_24126);
      }
    }
    default: return heff_nomatch(v_x1_24117);
    }
  }
  case TAG_EPrim: {
    V v_ru_24x2_241_24EPrim = heff_take_reuse_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_me_240, 4);
    return heff_tag_at_n(v_ru_24x2_241_24EPrim, TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_EPrimCall: {
    V v_as_24131 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_24132 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
    V v_ms_24133 = (g_list_2emap(v_t_24132, v_as_24131));
    return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_24133; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_24133); r_; });
  }
  case TAG_ECall: {
    V v_g_24134 = heff_field(v_x2_241, 0);
    V v_as_24135 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_g_24134), heff_dup(heff_rfield(v_me_240, 0)))) {
      return ({ V a_0 = v_me_240; V a_1 = v_g_24134; V a_2 = v_as_24135; V r_ = (g_heff_2ecompile_2efuse_2eselfCalls(a_0, a_1, a_2)); heff_drop(v_as_24135); r_; });
    } else {
      heff_drop(v_g_24134);
      V v_t_24137 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_24138 = (g_list_2emap(v_t_24137, v_as_24135));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_24138; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_24138); r_; });
    }
  }
  case TAG_EInt: {
    V v_ru_24x2_241_24EInt = heff_take_reuse_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_me_240, 4);
    return heff_tag_at_n(v_ru_24x2_241_24EInt, TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_EFloat: {
    V v_ru_24x2_241_24EFloat = heff_take_reuse_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_me_240, 4);
    return heff_tag_at_n(v_ru_24x2_241_24EFloat, TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_EStr: {
    V v_ru_24x2_241_24EStr = heff_take_reuse_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_me_240, 4);
    return heff_tag_at_n(v_ru_24x2_241_24EStr, TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_EBytes: {
    V v_ru_24x2_241_24EBytes = heff_take_reuse_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_me_240, 4);
    return heff_tag_at_n(v_ru_24x2_241_24EBytes, TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_me_240, 4);
    return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_EFloat32: {
    V v_ru_24x2_241_24EFloat32 = heff_take_reuse_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_me_240, 4);
    return heff_tag_at_n(v_ru_24x2_241_24EFloat32, TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_me_240, 4);
    return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_me_240, 4);
    return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2epathCalls_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2epathCalls(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2epathCalls_lam0(V self, V *args) {
  V v_p_24102 = args[0];
  V v_me_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24105;
  switch (heff_tag_of(v_p_24102)) {
  case TAG_MkPair: {
    V v_y_24104 = heff_field(v_p_24102, 1);
    heff_take_n(v_p_24102, 2ULL, 2);
    v_t_24105 = v_y_24104;
    break;
  }
  default: heff_nomatch(v_p_24102);
  }
  return (g_heff_2ecompile_2efuse_2epathCalls(v_me_240, v_t_24105));
}
V g_heff_2ecompile_2efuse_2epathCalls_lam1(V self, V *args) {
  V v_a_24118 = args[0];
  V v_me_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24122;
  switch (heff_tag_of(v_a_24118)) {
  case TAG_MkArm: {
    V v_b_24121 = heff_field(v_a_24118, 2);
    heff_take_n(v_a_24118, 4ULL, 3);
    v_t_24122 = v_b_24121;
    break;
  }
  default: heff_nomatch(v_a_24118);
  }
  return (g_heff_2ecompile_2efuse_2epathCalls(v_me_240, v_t_24122));
}
Clo g_heff_2ecompile_2efuse_2efixedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efixedGo_entry, 3, 0};

V g_heff_2ecompile_2efuse_2efixedGo(V v_calls_240, V v_k_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2evarAt_clo), 2, (V[]){heff_dup(v_k_241), v_x_243}));
    V v_t_246 = (g_list_2eall(v_t_245, v_calls_240));
    V v_cell_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_heff_2ecompile_2efuse_2efixedGo_24dps(v_calls_240, heff_intAdd(v_k_241, MK_INT(1LL)), v_xs_244, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2efixedGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efuse_2efixedGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2efuse_2efixedGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efixedGo_24dps_entry, 4, 0};

V g_heff_2ecompile_2efuse_2efixedGo_24dps(V v_calls_240, V v_k_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_xs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2evarAt_clo), 2, (V[]){heff_dup(v_k_241), v_x_244}));
    V v_t_247 = (g_list_2eall(v_t_246, v_calls_240));
    V v_cell_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_calls_240;
    V t_1 = heff_intAdd(v_k_241, MK_INT(1LL));
    V t_2 = v_xs_245;
    V t_3 = v_cell_248;
    v_calls_240 = t_0;
    v_k_241 = t_1;
    v_x3_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2efixedGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efuse_2efixedGo_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2efuse_2egoesOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2egoesOf_24dps_entry, 2, 0};

V g_heff_2ecompile_2efuse_2egoesOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x11_242, 0);
      V v_x112_245 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      switch (heff_tag_of(v_x112_245)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_244);
        V t_0 = v_rest_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_Just: {
        V v_x1121_246 = heff_field(v_x112_245, 0);
        heff_take_n(v_x112_245, 1ULL, 1);
        if ((heff_dup(v_x1121_246) == NTAG(TAG_True))) {
          heff_drop(v_x1121_246);
          V v_t_2410;
          switch (heff_tag_of(v_a_244)) {
          case TAG_MkArm: {
            V v_t_247 = heff_field(v_a_244, 0);
            heff_take_n(v_a_244, 1ULL, 3);
            v_t_2410 = v_t_247;
            break;
          }
          default: heff_nomatch(v_a_244);
          }
          V v_cell_2411 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
          V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
          heff_drop(v_u_2412);
          V t_0 = v_rest_243;
          V t_1 = v_cell_2411;
          v_x1_240 = t_0;
          v_d_241 = t_1;
          goto top;
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_a_244);
          heff_drop(v_x1121_246);
          V t_0 = v_rest_243;
          V t_1 = v_d_241;
          v_x1_240 = t_0;
          v_d_241 = t_1;
          goto top;
        }
      }
      default: return heff_nomatch(v_x112_245);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuse_2egoesOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2egoesOf_24dps(a[0], a[1]);
}
Clo g_heff_2ecompile_2efuse_2econsRec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2econsRec_entry, 3, 0};

V g_heff_2ecompile_2efuse_2econsRec(V v_key_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_as_2419 = heff_field(v_x3_242, 1);
    V v_t_2420 = (g_heff_2ecompile_2efuse_2elastF(v_as_2419));
    switch (heff_tag_of(v_t_2420)) {
    case TAG_Nothing: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_l_2421 = heff_field(v_t_2420, 0);
      heff_take_n(v_t_2420, 1ULL, 1);
      V v_x1_2422 = ({ V a_0 = v_key_240; V a_1 = v_n_241; V a_2 = v_l_2421; V r_ = (g_heff_2ecompile_2efuse_2ecallOf(a_0, a_1, a_2)); heff_drop(v_l_2421); r_; });
      switch (heff_tag_of(v_x1_2422)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        heff_take_n(v_x1_2422, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_x1_2422);
      }
    }
    default: return heff_nomatch(v_t_2420);
    }
  }
  case TAG_EMatch: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2econsRec_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2efuse_2econsRec(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2efuse_2erecallAt_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2erecallAt_lam1(V self, V *args);
Clo g_heff_2ecompile_2efuse_2erecallAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2erecallAt_entry, 3, 0};

V g_heff_2ecompile_2efuse_2erecallAt(V v_fu_240, V v_h_241, V v_as_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2efuse_2ecallOf(heff_dup(heff_rfield(v_fu_240, 5)), heff_dup(heff_rfield(v_fu_240, 6)), v_h_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    return heff_clo_n(g_heff_2ecompile_2efuse_2erecallAt_lam0, 1, 3, (V[]){v_h_241, v_fu_240, v_as_242});
  }
  case TAG_Just: {
    V v_bs_2415 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    heff_drop(v_h_241);
    return heff_clo_n(g_heff_2ecompile_2efuse_2erecallAt_lam1, 1, 3, (V[]){v_bs_2415, v_fu_240, v_as_242});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2efuse_2erecallAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2erecallAt(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2efuse_2erecallAt_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_h_241 = heff_env(self)[0];
  V v_fu_240 = heff_env(self)[1];
  V v_as_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_245 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(g_map_2eempty_get()), heff_take_field(v_s_244, 0), v_h_241));
  V v_x2_249;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_e_246 = heff_field(v_x2_245, 0);
    V v_n_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = ({ V rv_0 = v_n_247; V rr_ = heff_rec_reuse_nf(v_s_244, 62ULL, 6, shape_supply__consumers__producers__made__fresh__left, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    v_x2_249 = heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){v_e_246, v_t_248});
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_t_2412 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
    V v_t_2413 = (g_heff_2ecompile_2efuse_2esetAt(heff_get_n(v_fu_240, 2, 9), v_x_2410, v_as_242));
    V v_x_2414 = heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_EApp, 2, (V[]){v_t_2412, v_t_2413});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2414, v_s_2411});
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2efuse_2erecallAt_lam1(V self, V *args) {
  V v_s_2416 = args[0];
  V v_bs_2415 = heff_env(self)[0];
  V v_fu_240 = heff_env(self)[1];
  V v_as_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = (g_heff_2ecompile_2efuse_2etraverseF_24s847914641x1886275130(v_bs_2415, v_s_2416));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_s_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_t_2420 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
    V v_t_2421 = (g_prelude_2e_2b_2b_24f677743828x1026746250(v_x_2418, heff_get_n(v_fu_240, 2, 9), v_as_242));
    V v_x_2422 = heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_EApp, 2, (V[]){v_t_2420, v_t_2421});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2422, v_s_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2efuse_2erecall_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2erecall_lam1(V self, V *args);
V g_heff_2ecompile_2efuse_2erecall_lam2(V self, V *args);
V g_heff_2ecompile_2efuse_2erecall_lam3(V self, V *args);
V g_heff_2ecompile_2efuse_2erecall_lam4(V self, V *args);
V g_heff_2ecompile_2efuse_2erecall_lam5(V self, V *args);
Clo g_heff_2ecompile_2efuse_2erecall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2erecall_entry, 4, 0};

V g_heff_2ecompile_2efuse_2erecall(V v_fu_240, V v_r_241, V v_h_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    V v_t_245 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_245, v_e_243));
  }
  case TAG_EGlobal: {
    V v_t_247 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_247, v_e_243));
  }
  case TAG_ELam: {
    V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2410, v_e_243));
  }
  case TAG_EApp: {
    V v_e1_2411 = heff_dup(heff_field(v_e_243, 0));
    V v_as_2412 = heff_dup(heff_field(v_e_243, 1));
    switch (heff_tag_of(v_e1_2411)) {
    case TAG_EVar: {
      heff_take_n(v_e1_2411, 0ULL, 1);
      heff_drop(v_as_2412);
      V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2414, v_e_243));
    }
    case TAG_EGlobal: {
      V v_g_2415 = heff_field(v_e1_2411, 0);
      heff_take_n(v_e1_2411, 1ULL, 1);
      heff_drop_tag(v_e_243, 2);
      if (heff_strEq_c(heff_dup(v_g_2415), heff_dup(heff_rfield(v_fu_240, 0)))) {
        V v_t_2417 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2412));
        if (heff_intEq_c(v_t_2417, heff_dup(heff_rfield(v_fu_240, 1)))) {
          V v_t_2419 = (g_heff_2ecompile_2efuse_2evarAt(heff_dup(heff_rfield(v_fu_240, 2)), heff_dup(v_r_241), v_as_2412));
          if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
            heff_drop(v_r_241);
            heff_drop(v_g_2415);
            heff_drop(v_t_2419);
            return (g_heff_2ecompile_2efuse_2erecallAt(v_fu_240, v_h_242, v_as_2412));
          } else {
            heff_drop(v_t_2419);
            V v_t_2420 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
            V v_m_2421 = (g_heff_2ecompile_2efuse_2etraverseF(v_t_2420, v_as_2412));
            return heff_clo_n(g_heff_2ecompile_2efuse_2erecall_lam0, 1, 2, (V[]){v_m_2421, v_g_2415});
          }
        } else {
          V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
          V v_m_2428 = (g_heff_2ecompile_2efuse_2etraverseF(v_t_2427, v_as_2412));
          return heff_clo_n(g_heff_2ecompile_2efuse_2erecall_lam1, 1, 2, (V[]){v_m_2428, v_g_2415});
        }
      } else {
        V v_t_2434 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
        V v_m_2435 = (g_heff_2ecompile_2efuse_2etraverseF(v_t_2434, v_as_2412));
        return heff_clo_n(g_heff_2ecompile_2efuse_2erecall_lam2, 1, 2, (V[]){v_m_2435, v_g_2415});
      }
    }
    case TAG_ELam: {
      heff_take_n(v_e1_2411, 0ULL, 2);
      heff_drop(v_as_2412);
      V v_t_2443 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2443, v_e_243));
    }
    case TAG_EApp: {
      heff_take_n(v_e1_2411, 0ULL, 2);
      heff_drop(v_as_2412);
      V v_t_2446 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2446, v_e_243));
    }
    case TAG_ELet: {
      heff_take_n(v_e1_2411, 0ULL, 3);
      heff_drop(v_as_2412);
      V v_t_2450 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2450, v_e_243));
    }
    case TAG_ERecord: {
      heff_take_n(v_e1_2411, 0ULL, 2);
      heff_drop(v_as_2412);
      V v_t_2453 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2453, v_e_243));
    }
    case TAG_EProj: {
      heff_take_n(v_e1_2411, 0ULL, 4);
      heff_drop(v_as_2412);
      V v_t_2458 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2458, v_e_243));
    }
    case TAG_ETag: {
      heff_take_n(v_e1_2411, 0ULL, 2);
      heff_drop(v_as_2412);
      V v_t_2461 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2461, v_e_243));
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_2411, 0ULL, 2);
      heff_drop(v_as_2412);
      V v_t_2464 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2464, v_e_243));
    }
    case TAG_EPrim: {
      heff_take_n(v_e1_2411, 0ULL, 1);
      heff_drop(v_as_2412);
      V v_t_2466 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2466, v_e_243));
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e1_2411, 0ULL, 2);
      heff_drop(v_as_2412);
      V v_t_2469 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2469, v_e_243));
    }
    case TAG_ECall: {
      heff_take_n(v_e1_2411, 0ULL, 2);
      heff_drop(v_as_2412);
      V v_t_2472 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2472, v_e_243));
    }
    case TAG_EInt: {
      heff_take_n(v_e1_2411, 0ULL, 1);
      heff_drop(v_as_2412);
      V v_t_2474 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2474, v_e_243));
    }
    case TAG_EFloat: {
      heff_take_n(v_e1_2411, 0ULL, 1);
      heff_drop(v_as_2412);
      V v_t_2476 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2476, v_e_243));
    }
    case TAG_EStr: {
      heff_take_n(v_e1_2411, 0ULL, 1);
      heff_drop(v_as_2412);
      V v_t_2478 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2478, v_e_243));
    }
    case TAG_EBytes: {
      heff_take_n(v_e1_2411, 0ULL, 1);
      heff_drop(v_as_2412);
      V v_t_2480 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2480, v_e_243));
    }
    case TAG_EFixed: {
      heff_take_n(v_e1_2411, 0ULL, 2);
      heff_drop(v_as_2412);
      V v_t_2483 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2483, v_e_243));
    }
    case TAG_EFloat32: {
      heff_take_n(v_e1_2411, 0ULL, 1);
      heff_drop(v_as_2412);
      V v_t_2485 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2485, v_e_243));
    }
    case TAG_EAbandon: {
      heff_drop(v_as_2412);
      V v_t_2486 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2486, v_e_243));
    }
    case TAG_EFix: {
      heff_take_n(v_e1_2411, 0ULL, 2);
      heff_drop(v_as_2412);
      V v_t_2489 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2489, v_e_243));
    }
    default: return heff_nomatch(v_e1_2411);
    }
  }
  case TAG_ELet: {
    V v_t_2493 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2493, v_e_243));
  }
  case TAG_ERecord: {
    V v_t_2496 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2496, v_e_243));
  }
  case TAG_EProj: {
    V v_t_24101 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24101, v_e_243));
  }
  case TAG_ETag: {
    V v_t_24104 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24104, v_e_243));
  }
  case TAG_EMatch: {
    V v_t_24107 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24107, v_e_243));
  }
  case TAG_EPrim: {
    V v_t_24109 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24109, v_e_243));
  }
  case TAG_EPrimCall: {
    V v_t_24112 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24112, v_e_243));
  }
  case TAG_ECall: {
    V v_g_24113 = heff_field(v_e_243, 0);
    V v_as_24114 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_g_24113), heff_dup(heff_rfield(v_fu_240, 0)))) {
      V v_t_24116 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_24114));
      if (heff_intEq_c(v_t_24116, heff_dup(heff_rfield(v_fu_240, 1)))) {
        V v_t_24118 = (g_heff_2ecompile_2efuse_2evarAt(heff_dup(heff_rfield(v_fu_240, 2)), heff_dup(v_r_241), v_as_24114));
        if ((heff_dup(v_t_24118) == NTAG(TAG_True))) {
          heff_drop(v_r_241);
          heff_drop(v_g_24113);
          heff_drop(v_t_24118);
          return (g_heff_2ecompile_2efuse_2erecallAt(v_fu_240, v_h_242, v_as_24114));
        } else {
          heff_drop(v_t_24118);
          V v_t_24119 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
          V v_m_24120 = (g_heff_2ecompile_2efuse_2etraverseF(v_t_24119, v_as_24114));
          return heff_clo_n(g_heff_2ecompile_2efuse_2erecall_lam3, 1, 2, (V[]){v_m_24120, v_g_24113});
        }
      } else {
        V v_t_24125 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
        V v_m_24126 = (g_heff_2ecompile_2efuse_2etraverseF(v_t_24125, v_as_24114));
        return heff_clo_n(g_heff_2ecompile_2efuse_2erecall_lam4, 1, 2, (V[]){v_m_24126, v_g_24113});
      }
    } else {
      V v_t_24131 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      V v_m_24132 = (g_heff_2ecompile_2efuse_2etraverseF(v_t_24131, v_as_24114));
      return heff_clo_n(g_heff_2ecompile_2efuse_2erecall_lam5, 1, 2, (V[]){v_m_24132, v_g_24113});
    }
  }
  case TAG_EInt: {
    V v_t_24138 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24138, v_e_243));
  }
  case TAG_EFloat: {
    V v_t_24140 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24140, v_e_243));
  }
  case TAG_EStr: {
    V v_t_24142 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24142, v_e_243));
  }
  case TAG_EBytes: {
    V v_t_24144 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24144, v_e_243));
  }
  case TAG_EFixed: {
    V v_t_24147 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24147, v_e_243));
  }
  case TAG_EFloat32: {
    V v_t_24149 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24149, v_e_243));
  }
  case TAG_EAbandon: {
    V v_t_24150 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24150, v_e_243));
  }
  case TAG_EFix: {
    V v_t_24153 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24153, v_e_243));
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2efuse_2erecall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2erecall(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2efuse_2erecall_lam0(V self, V *args) {
  V v_s_2422 = args[0];
  V v_m_2421 = heff_env(self)[0];
  V v_g_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2423 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_s_2422}));
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_s_2425 = heff_field(v_x2_2423, 1);
    V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
    V v_t_2426 = heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2415}), v_x_2424});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2426, v_s_2425});
  }
  default: return heff_nomatch(v_x2_2423);
  }
}
V g_heff_2ecompile_2efuse_2erecall_lam1(V self, V *args) {
  V v_s_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_g_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2430 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_s_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_s_2432 = heff_field(v_x2_2430, 1);
    V v_ru_24x2_2430_24MkPair = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
    V v_t_2433 = heff_tag_at_n(v_ru_24x2_2430_24MkPair, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2415}), v_x_2431});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2433, v_s_2432});
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2ecompile_2efuse_2erecall_lam2(V self, V *args) {
  V v_s_2436 = args[0];
  V v_m_2435 = heff_env(self)[0];
  V v_g_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2437 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_s_2436}));
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_MkPair: {
    V v_x_2438 = heff_field(v_x2_2437, 0);
    V v_s_2439 = heff_field(v_x2_2437, 1);
    V v_ru_24x2_2437_24MkPair = heff_take_reuse_n(v_x2_2437, 3ULL, 2);
    V v_t_2440 = heff_tag_at_n(v_ru_24x2_2437_24MkPair, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2415}), v_x_2438});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2440, v_s_2439});
  }
  default: return heff_nomatch(v_x2_2437);
  }
}
V g_heff_2ecompile_2efuse_2erecall_lam3(V self, V *args) {
  V v_s_24121 = args[0];
  V v_m_24120 = heff_env(self)[0];
  V v_g_24113 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24122 = heff_tr(heff_call(v_m_24120, 1, (V[]){v_s_24121}));
  switch (heff_tag_of(v_x2_24122)) {
  case TAG_MkPair: {
    V v_x_24123 = heff_field(v_x2_24122, 0);
    V v_s_24124 = heff_field(v_x2_24122, 1);
    V v_ru_24x2_24122_24MkPair = heff_take_reuse_n(v_x2_24122, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24122_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24113, v_x_24123}), v_s_24124});
  }
  default: return heff_nomatch(v_x2_24122);
  }
}
V g_heff_2ecompile_2efuse_2erecall_lam4(V self, V *args) {
  V v_s_24127 = args[0];
  V v_m_24126 = heff_env(self)[0];
  V v_g_24113 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24128 = heff_tr(heff_call(v_m_24126, 1, (V[]){v_s_24127}));
  switch (heff_tag_of(v_x2_24128)) {
  case TAG_MkPair: {
    V v_x_24129 = heff_field(v_x2_24128, 0);
    V v_s_24130 = heff_field(v_x2_24128, 1);
    V v_ru_24x2_24128_24MkPair = heff_take_reuse_n(v_x2_24128, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24128_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24113, v_x_24129}), v_s_24130});
  }
  default: return heff_nomatch(v_x2_24128);
  }
}
V g_heff_2ecompile_2efuse_2erecall_lam5(V self, V *args) {
  V v_s_24133 = args[0];
  V v_m_24132 = heff_env(self)[0];
  V v_g_24113 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24134 = heff_tr(heff_call(v_m_24132, 1, (V[]){v_s_24133}));
  switch (heff_tag_of(v_x2_24134)) {
  case TAG_MkPair: {
    V v_x_24135 = heff_field(v_x2_24134, 0);
    V v_s_24136 = heff_field(v_x2_24134, 1);
    V v_ru_24x2_24134_24MkPair = heff_take_reuse_n(v_x2_24134, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24134_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24113, v_x_24135}), v_s_24136});
  }
  default: return heff_nomatch(v_x2_24134);
  }
}
Clo g_heff_2ecompile_2efuse_2earmCopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2earmCopy_entry, 5, 0};

V g_heff_2ecompile_2efuse_2earmCopy(V v_fu_240, V v_t_241, V v_hs_242, V v_x4_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkArm: {
    V v_vs_246 = heff_field(v_x4_243, 1);
    V v_b_247 = heff_field(v_x4_243, 2);
    V v_x2_248 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(g_map_2eempty_get()), heff_take_field(v_p_244, 0), heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(v_vs_246), heff_dup(v_b_247)})));
    V v_x2_2412;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_e_249 = heff_field(v_x2_248, 0);
      V v_n_2410 = heff_field(v_x2_248, 1);
      V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
      V v_t_2411 = ({ V rv_0 = v_n_2410; V rr_ = heff_rec_reuse_nf(v_p_244, 62ULL, 6, shape_supply__consumers__producers__made__fresh__left, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      v_x2_2412 = heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_e_249, v_t_2411});
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      HEFF_LAST return g_heff_2ecompile_2efuse_2earmGiven(v_fu_240, v_t_241, v_hs_242, v_x_2413, v_s_2414);
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2efuse_2earmCopy_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2efuse_2earmCopy(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2ecompile_2efuse_2etagEnd_lam0(V self, V *args);
Clo g_heff_2ecompile_2efuse_2etagEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2etagEnd_entry, 3, 0};

V g_heff_2ecompile_2efuse_2etagEnd(V v_fu_240, V v_t_241, V v_hs_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2efuse_2efindArm(heff_dup(v_t_241), heff_rfield(v_fu_240, 3)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
    V v_t_245 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 2, (V[]){v_t_241, v_hs_242}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_246 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_244, v_t_245});
    return heff_clo_n(g_heff_2ecompile_2efuse_2etagEnd_lam0, 1, 1, (V[]){v_x_246});
  }
  case TAG_Just: {
    V v_a_248 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    return heff_tail(((V)&g_heff_2ecompile_2efuse_2earmCopy_clo), 4, (V[]){v_fu_240, v_t_241, v_hs_242, v_a_248});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2efuse_2etagEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2etagEnd(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2efuse_2etagEnd_lam0(V self, V *args) {
  V v_s_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_s_247});
}
V g_heff_2ecompile_2efuse_2eendAt_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam1(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam2(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam3(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam4(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam5(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam6(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam7(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam8(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam9(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam10(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam11(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam12(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam13(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam14(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam15(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam16(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam17(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam18(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam19(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam20(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam21(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam22(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam23(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam24(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam25(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam26(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam27(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam28(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam29(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam30(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam31(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam32(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam33(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam34(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam35(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam36(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam37(V self, V *args);
Clo g_heff_2ecompile_2efuse_2eendAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eendAt_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eendAt(V v_fu_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_t_243 = (g_heff_2ecompile_2efuse_2ecallOf(heff_take_field(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      V v_t_244 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_245 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
      V v_x_246 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_244, v_t_245});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam0, 1, 1, (V[]){v_x_246});
    }
    case TAG_Just: {
      V v_bs_248 = heff_field(v_t_243, 0);
      V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
      heff_drop_tag(v_e_241, 1);
      V v_t_249 = heff_tag_at_n(v_ru_24t_243_24Just, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 7))});
      V v_t_2410 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_248));
      V v_x_2411 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_249, v_t_2410});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam1, 1, 1, (V[]){v_x_2411});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_EGlobal: {
    V v_t_2414 = (g_heff_2ecompile_2efuse_2ecallOf(heff_take_field(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nothing: {
      V v_t_2415 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_2416 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
      V v_x_2417 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2415, v_t_2416});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam2, 1, 1, (V[]){v_x_2417});
    }
    case TAG_Just: {
      V v_bs_2419 = heff_field(v_t_2414, 0);
      V v_ru_24t_2414_24Just = heff_take_reuse_n(v_t_2414, 1ULL, 1);
      heff_drop_tag(v_e_241, 1);
      V v_t_2420 = heff_tag_at_n(v_ru_24t_2414_24Just, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 7))});
      V v_t_2421 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_2419));
      V v_x_2422 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2420, v_t_2421});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam3, 1, 1, (V[]){v_x_2422});
    }
    default: return heff_nomatch(v_t_2414);
    }
  }
  case TAG_ELam: {
    V v_t_2426 = (g_heff_2ecompile_2efuse_2ecallOf(heff_take_field(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    switch (heff_tag_of(v_t_2426)) {
    case TAG_Nothing: {
      V v_t_2427 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_2428 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
      V v_x_2429 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2427, v_t_2428});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam4, 1, 1, (V[]){v_x_2429});
    }
    case TAG_Just: {
      V v_bs_2431 = heff_field(v_t_2426, 0);
      V v_ru_24t_2426_24Just = heff_take_reuse_n(v_t_2426, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      V v_t_2432 = heff_tag_at_n(v_ru_24t_2426_24Just, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 7))});
      V v_t_2433 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_2431));
      V v_x_2434 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2432, v_t_2433});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam5, 1, 1, (V[]){v_x_2434});
    }
    default: return heff_nomatch(v_t_2426);
    }
  }
  case TAG_EApp: {
    V v_t_2438 = (g_heff_2ecompile_2efuse_2ecallOf(heff_take_field(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    switch (heff_tag_of(v_t_2438)) {
    case TAG_Nothing: {
      V v_t_2439 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_2440 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
      V v_x_2441 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2439, v_t_2440});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam6, 1, 1, (V[]){v_x_2441});
    }
    case TAG_Just: {
      V v_bs_2443 = heff_field(v_t_2438, 0);
      V v_ru_24t_2438_24Just = heff_take_reuse_n(v_t_2438, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      V v_t_2444 = heff_tag_at_n(v_ru_24t_2438_24Just, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 7))});
      V v_t_2445 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_2443));
      V v_x_2446 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2444, v_t_2445});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam7, 1, 1, (V[]){v_x_2446});
    }
    default: return heff_nomatch(v_t_2438);
    }
  }
  case TAG_ELet: {
    V v_t_2451 = (g_heff_2ecompile_2efuse_2ecallOf(heff_take_field(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    switch (heff_tag_of(v_t_2451)) {
    case TAG_Nothing: {
      V v_t_2452 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_2453 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
      V v_x_2454 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2452, v_t_2453});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam8, 1, 1, (V[]){v_x_2454});
    }
    case TAG_Just: {
      V v_bs_2456 = heff_field(v_t_2451, 0);
      V v_ru_24t_2451_24Just = heff_take_reuse_n(v_t_2451, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      V v_t_2457 = heff_tag_at_n(v_ru_24t_2451_24Just, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 7))});
      V v_t_2458 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_2456));
      V v_x_2459 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2457, v_t_2458});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam9, 1, 1, (V[]){v_x_2459});
    }
    default: return heff_nomatch(v_t_2451);
    }
  }
  case TAG_ERecord: {
    V v_t_2463 = (g_heff_2ecompile_2efuse_2ecallOf(heff_take_field(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    switch (heff_tag_of(v_t_2463)) {
    case TAG_Nothing: {
      V v_t_2464 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_2465 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
      V v_x_2466 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2464, v_t_2465});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam10, 1, 1, (V[]){v_x_2466});
    }
    case TAG_Just: {
      V v_bs_2468 = heff_field(v_t_2463, 0);
      V v_ru_24t_2463_24Just = heff_take_reuse_n(v_t_2463, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      V v_t_2469 = heff_tag_at_n(v_ru_24t_2463_24Just, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 7))});
      V v_t_2470 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_2468));
      V v_x_2471 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2469, v_t_2470});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam11, 1, 1, (V[]){v_x_2471});
    }
    default: return heff_nomatch(v_t_2463);
    }
  }
  case TAG_EProj: {
    V v_t_2477 = (g_heff_2ecompile_2efuse_2ecallOf(heff_take_field(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    switch (heff_tag_of(v_t_2477)) {
    case TAG_Nothing: {
      V v_t_2478 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_2479 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
      V v_x_2480 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2478, v_t_2479});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam12, 1, 1, (V[]){v_x_2480});
    }
    case TAG_Just: {
      V v_bs_2482 = heff_field(v_t_2477, 0);
      V v_ru_24t_2477_24Just = heff_take_reuse_n(v_t_2477, 1ULL, 1);
      heff_drop_tag(v_e_241, 4);
      V v_t_2483 = heff_tag_at_n(v_ru_24t_2477_24Just, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 7))});
      V v_t_2484 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_2482));
      V v_x_2485 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2483, v_t_2484});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam13, 1, 1, (V[]){v_x_2485});
    }
    default: return heff_nomatch(v_t_2477);
    }
  }
  case TAG_ETag: {
    V v_t_2487 = heff_field(v_e_241, 0);
    V v_hs_2488 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    return (g_heff_2ecompile_2efuse_2etagEnd(v_fu_240, v_t_2487, v_hs_2488));
  }
  case TAG_EMatch: {
    V v_t_2491 = (g_heff_2ecompile_2efuse_2ecallOf(heff_take_field(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    switch (heff_tag_of(v_t_2491)) {
    case TAG_Nothing: {
      V v_t_2492 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_2493 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
      V v_x_2494 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2492, v_t_2493});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam14, 1, 1, (V[]){v_x_2494});
    }
    case TAG_Just: {
      V v_bs_2496 = heff_field(v_t_2491, 0);
      V v_ru_24t_2491_24Just = heff_take_reuse_n(v_t_2491, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      V v_t_2497 = heff_tag_at_n(v_ru_24t_2491_24Just, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 7))});
      V v_t_2498 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_2496));
      V v_x_2499 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2497, v_t_2498});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam15, 1, 1, (V[]){v_x_2499});
    }
    default: return heff_nomatch(v_t_2491);
    }
  }
  case TAG_EPrim: {
    V v_t_24102 = (g_heff_2ecompile_2efuse_2ecallOf(heff_take_field(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    switch (heff_tag_of(v_t_24102)) {
    case TAG_Nothing: {
      V v_t_24103 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_24104 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
      V v_x_24105 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24103, v_t_24104});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam16, 1, 1, (V[]){v_x_24105});
    }
    case TAG_Just: {
      V v_bs_24107 = heff_field(v_t_24102, 0);
      V v_ru_24t_24102_24Just = heff_take_reuse_n(v_t_24102, 1ULL, 1);
      heff_drop_tag(v_e_241, 1);
      V v_t_24108 = heff_tag_at_n(v_ru_24t_24102_24Just, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 7))});
      V v_t_24109 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24107));
      V v_x_24110 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24108, v_t_24109});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam17, 1, 1, (V[]){v_x_24110});
    }
    default: return heff_nomatch(v_t_24102);
    }
  }
  case TAG_EPrimCall: {
    V v_t_24114 = (g_heff_2ecompile_2efuse_2ecallOf(heff_take_field(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    switch (heff_tag_of(v_t_24114)) {
    case TAG_Nothing: {
      V v_t_24115 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_24116 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
      V v_x_24117 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24115, v_t_24116});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam18, 1, 1, (V[]){v_x_24117});
    }
    case TAG_Just: {
      V v_bs_24119 = heff_field(v_t_24114, 0);
      V v_ru_24t_24114_24Just = heff_take_reuse_n(v_t_24114, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      V v_t_24120 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 7))});
      V v_t_24121 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24119));
      V v_x_24122 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24120, v_t_24121});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam19, 1, 1, (V[]){v_x_24122});
    }
    default: return heff_nomatch(v_t_24114);
    }
  }
  case TAG_ECall: {
    V v_t_24126 = (g_heff_2ecompile_2efuse_2ecallOf(heff_take_field(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    switch (heff_tag_of(v_t_24126)) {
    case TAG_Nothing: {
      V v_t_24127 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_24128 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
      V v_x_24129 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24127, v_t_24128});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam20, 1, 1, (V[]){v_x_24129});
    }
    case TAG_Just: {
      V v_bs_24131 = heff_field(v_t_24126, 0);
      V v_ru_24t_24126_24Just = heff_take_reuse_n(v_t_24126, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      V v_t_24132 = heff_tag_at_n(v_ru_24t_24126_24Just, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 7))});
      V v_t_24133 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24131));
      V v_x_24134 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24132, v_t_24133});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam21, 1, 1, (V[]){v_x_24134});
    }
    default: return heff_nomatch(v_t_24126);
    }
  }
  case TAG_EInt: {
    V v_t_24137 = (g_heff_2ecompile_2efuse_2ecallOf(heff_take_field(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    switch (heff_tag_of(v_t_24137)) {
    case TAG_Nothing: {
      V v_t_24138 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_24139 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
      V v_x_24140 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24138, v_t_24139});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam22, 1, 1, (V[]){v_x_24140});
    }
    case TAG_Just: {
      V v_bs_24142 = heff_field(v_t_24137, 0);
      V v_ru_24t_24137_24Just = heff_take_reuse_n(v_t_24137, 1ULL, 1);
      heff_drop_tag(v_e_241, 1);
      V v_t_24143 = heff_tag_at_n(v_ru_24t_24137_24Just, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 7))});
      V v_t_24144 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24142));
      V v_x_24145 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24143, v_t_24144});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam23, 1, 1, (V[]){v_x_24145});
    }
    default: return heff_nomatch(v_t_24137);
    }
  }
  case TAG_EFloat: {
    V v_t_24148 = (g_heff_2ecompile_2efuse_2ecallOf(heff_take_field(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    switch (heff_tag_of(v_t_24148)) {
    case TAG_Nothing: {
      V v_t_24149 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_24150 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
      V v_x_24151 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24149, v_t_24150});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam24, 1, 1, (V[]){v_x_24151});
    }
    case TAG_Just: {
      V v_bs_24153 = heff_field(v_t_24148, 0);
      V v_ru_24t_24148_24Just = heff_take_reuse_n(v_t_24148, 1ULL, 1);
      heff_drop_tag(v_e_241, 1);
      V v_t_24154 = heff_tag_at_n(v_ru_24t_24148_24Just, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 7))});
      V v_t_24155 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24153));
      V v_x_24156 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24154, v_t_24155});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam25, 1, 1, (V[]){v_x_24156});
    }
    default: return heff_nomatch(v_t_24148);
    }
  }
  case TAG_EStr: {
    V v_t_24159 = (g_heff_2ecompile_2efuse_2ecallOf(heff_take_field(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    switch (heff_tag_of(v_t_24159)) {
    case TAG_Nothing: {
      V v_t_24160 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_24161 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
      V v_x_24162 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24160, v_t_24161});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam26, 1, 1, (V[]){v_x_24162});
    }
    case TAG_Just: {
      V v_bs_24164 = heff_field(v_t_24159, 0);
      V v_ru_24t_24159_24Just = heff_take_reuse_n(v_t_24159, 1ULL, 1);
      heff_drop_tag(v_e_241, 1);
      V v_t_24165 = heff_tag_at_n(v_ru_24t_24159_24Just, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 7))});
      V v_t_24166 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24164));
      V v_x_24167 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24165, v_t_24166});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam27, 1, 1, (V[]){v_x_24167});
    }
    default: return heff_nomatch(v_t_24159);
    }
  }
  case TAG_EBytes: {
    V v_t_24170 = (g_heff_2ecompile_2efuse_2ecallOf(heff_take_field(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    switch (heff_tag_of(v_t_24170)) {
    case TAG_Nothing: {
      V v_t_24171 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_24172 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
      V v_x_24173 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24171, v_t_24172});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam28, 1, 1, (V[]){v_x_24173});
    }
    case TAG_Just: {
      V v_bs_24175 = heff_field(v_t_24170, 0);
      V v_ru_24t_24170_24Just = heff_take_reuse_n(v_t_24170, 1ULL, 1);
      heff_drop_tag(v_e_241, 1);
      V v_t_24176 = heff_tag_at_n(v_ru_24t_24170_24Just, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 7))});
      V v_t_24177 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24175));
      V v_x_24178 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24176, v_t_24177});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam29, 1, 1, (V[]){v_x_24178});
    }
    default: return heff_nomatch(v_t_24170);
    }
  }
  case TAG_EFixed: {
    V v_t_24182 = (g_heff_2ecompile_2efuse_2ecallOf(heff_take_field(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    switch (heff_tag_of(v_t_24182)) {
    case TAG_Nothing: {
      V v_t_24183 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_24184 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
      V v_x_24185 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24183, v_t_24184});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam30, 1, 1, (V[]){v_x_24185});
    }
    case TAG_Just: {
      V v_bs_24187 = heff_field(v_t_24182, 0);
      V v_ru_24t_24182_24Just = heff_take_reuse_n(v_t_24182, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      V v_t_24188 = heff_tag_at_n(v_ru_24t_24182_24Just, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 7))});
      V v_t_24189 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24187));
      V v_x_24190 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24188, v_t_24189});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam31, 1, 1, (V[]){v_x_24190});
    }
    default: return heff_nomatch(v_t_24182);
    }
  }
  case TAG_EFloat32: {
    V v_t_24193 = (g_heff_2ecompile_2efuse_2ecallOf(heff_take_field(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    switch (heff_tag_of(v_t_24193)) {
    case TAG_Nothing: {
      V v_t_24194 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_24195 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
      V v_x_24196 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24194, v_t_24195});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam32, 1, 1, (V[]){v_x_24196});
    }
    case TAG_Just: {
      V v_bs_24198 = heff_field(v_t_24193, 0);
      V v_ru_24t_24193_24Just = heff_take_reuse_n(v_t_24193, 1ULL, 1);
      heff_drop_tag(v_e_241, 1);
      V v_t_24199 = heff_tag_at_n(v_ru_24t_24193_24Just, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 7))});
      V v_t_24200 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24198));
      V v_x_24201 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24199, v_t_24200});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam33, 1, 1, (V[]){v_x_24201});
    }
    default: return heff_nomatch(v_t_24193);
    }
  }
  case TAG_EAbandon: {
    V v_t_24203 = (g_heff_2ecompile_2efuse_2ecallOf(heff_take_field(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    switch (heff_tag_of(v_t_24203)) {
    case TAG_Nothing: {
      V v_t_24204 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_24205 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
      V v_x_24206 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24204, v_t_24205});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam34, 1, 1, (V[]){v_x_24206});
    }
    case TAG_Just: {
      V v_bs_24208 = heff_field(v_t_24203, 0);
      V v_ru_24t_24203_24Just = heff_take_reuse_n(v_t_24203, 1ULL, 1);
      V v_t_24209 = heff_tag_at_n(v_ru_24t_24203_24Just, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 7))});
      V v_t_24210 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24208));
      V v_x_24211 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24209, v_t_24210});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam35, 1, 1, (V[]){v_x_24211});
    }
    default: return heff_nomatch(v_t_24203);
    }
  }
  case TAG_EFix: {
    V v_t_24215 = (g_heff_2ecompile_2efuse_2ecallOf(heff_take_field(v_fu_240, 5), heff_take_field(v_fu_240, 6), v_e_241));
    switch (heff_tag_of(v_t_24215)) {
    case TAG_Nothing: {
      V v_t_24216 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_24217 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
      V v_x_24218 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24216, v_t_24217});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam36, 1, 1, (V[]){v_x_24218});
    }
    case TAG_Just: {
      V v_bs_24220 = heff_field(v_t_24215, 0);
      V v_ru_24t_24215_24Just = heff_take_reuse_n(v_t_24215, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      V v_t_24221 = heff_tag_at_n(v_ru_24t_24215_24Just, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 7))});
      V v_t_24222 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24220));
      V v_x_24223 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24221, v_t_24222});
      return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam37, 1, 1, (V[]){v_x_24223});
    }
    default: return heff_nomatch(v_t_24215);
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2efuse_2eendAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eendAt(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2eendAt_lam0(V self, V *args) {
  V v_s_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_s_247});
}
V g_heff_2ecompile_2efuse_2eendAt_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_s_2412});
}
V g_heff_2ecompile_2efuse_2eendAt_lam2(V self, V *args) {
  V v_s_2418 = args[0];
  V v_x_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_s_2418});
}
V g_heff_2ecompile_2efuse_2eendAt_lam3(V self, V *args) {
  V v_s_2423 = args[0];
  V v_x_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2422, v_s_2423});
}
V g_heff_2ecompile_2efuse_2eendAt_lam4(V self, V *args) {
  V v_s_2430 = args[0];
  V v_x_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2429, v_s_2430});
}
V g_heff_2ecompile_2efuse_2eendAt_lam5(V self, V *args) {
  V v_s_2435 = args[0];
  V v_x_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2434, v_s_2435});
}
V g_heff_2ecompile_2efuse_2eendAt_lam6(V self, V *args) {
  V v_s_2442 = args[0];
  V v_x_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2441, v_s_2442});
}
V g_heff_2ecompile_2efuse_2eendAt_lam7(V self, V *args) {
  V v_s_2447 = args[0];
  V v_x_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2446, v_s_2447});
}
V g_heff_2ecompile_2efuse_2eendAt_lam8(V self, V *args) {
  V v_s_2455 = args[0];
  V v_x_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2454, v_s_2455});
}
V g_heff_2ecompile_2efuse_2eendAt_lam9(V self, V *args) {
  V v_s_2460 = args[0];
  V v_x_2459 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2459, v_s_2460});
}
V g_heff_2ecompile_2efuse_2eendAt_lam10(V self, V *args) {
  V v_s_2467 = args[0];
  V v_x_2466 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2466, v_s_2467});
}
V g_heff_2ecompile_2efuse_2eendAt_lam11(V self, V *args) {
  V v_s_2472 = args[0];
  V v_x_2471 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2471, v_s_2472});
}
V g_heff_2ecompile_2efuse_2eendAt_lam12(V self, V *args) {
  V v_s_2481 = args[0];
  V v_x_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2480, v_s_2481});
}
V g_heff_2ecompile_2efuse_2eendAt_lam13(V self, V *args) {
  V v_s_2486 = args[0];
  V v_x_2485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2485, v_s_2486});
}
V g_heff_2ecompile_2efuse_2eendAt_lam14(V self, V *args) {
  V v_s_2495 = args[0];
  V v_x_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2494, v_s_2495});
}
V g_heff_2ecompile_2efuse_2eendAt_lam15(V self, V *args) {
  V v_s_24100 = args[0];
  V v_x_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2499, v_s_24100});
}
V g_heff_2ecompile_2efuse_2eendAt_lam16(V self, V *args) {
  V v_s_24106 = args[0];
  V v_x_24105 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24105, v_s_24106});
}
V g_heff_2ecompile_2efuse_2eendAt_lam17(V self, V *args) {
  V v_s_24111 = args[0];
  V v_x_24110 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24110, v_s_24111});
}
V g_heff_2ecompile_2efuse_2eendAt_lam18(V self, V *args) {
  V v_s_24118 = args[0];
  V v_x_24117 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24117, v_s_24118});
}
V g_heff_2ecompile_2efuse_2eendAt_lam19(V self, V *args) {
  V v_s_24123 = args[0];
  V v_x_24122 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24122, v_s_24123});
}
V g_heff_2ecompile_2efuse_2eendAt_lam20(V self, V *args) {
  V v_s_24130 = args[0];
  V v_x_24129 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24129, v_s_24130});
}
V g_heff_2ecompile_2efuse_2eendAt_lam21(V self, V *args) {
  V v_s_24135 = args[0];
  V v_x_24134 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24134, v_s_24135});
}
V g_heff_2ecompile_2efuse_2eendAt_lam22(V self, V *args) {
  V v_s_24141 = args[0];
  V v_x_24140 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24140, v_s_24141});
}
V g_heff_2ecompile_2efuse_2eendAt_lam23(V self, V *args) {
  V v_s_24146 = args[0];
  V v_x_24145 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24145, v_s_24146});
}
V g_heff_2ecompile_2efuse_2eendAt_lam24(V self, V *args) {
  V v_s_24152 = args[0];
  V v_x_24151 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24151, v_s_24152});
}
V g_heff_2ecompile_2efuse_2eendAt_lam25(V self, V *args) {
  V v_s_24157 = args[0];
  V v_x_24156 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24156, v_s_24157});
}
V g_heff_2ecompile_2efuse_2eendAt_lam26(V self, V *args) {
  V v_s_24163 = args[0];
  V v_x_24162 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24162, v_s_24163});
}
V g_heff_2ecompile_2efuse_2eendAt_lam27(V self, V *args) {
  V v_s_24168 = args[0];
  V v_x_24167 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24167, v_s_24168});
}
V g_heff_2ecompile_2efuse_2eendAt_lam28(V self, V *args) {
  V v_s_24174 = args[0];
  V v_x_24173 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24173, v_s_24174});
}
V g_heff_2ecompile_2efuse_2eendAt_lam29(V self, V *args) {
  V v_s_24179 = args[0];
  V v_x_24178 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24178, v_s_24179});
}
V g_heff_2ecompile_2efuse_2eendAt_lam30(V self, V *args) {
  V v_s_24186 = args[0];
  V v_x_24185 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24185, v_s_24186});
}
V g_heff_2ecompile_2efuse_2eendAt_lam31(V self, V *args) {
  V v_s_24191 = args[0];
  V v_x_24190 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24190, v_s_24191});
}
V g_heff_2ecompile_2efuse_2eendAt_lam32(V self, V *args) {
  V v_s_24197 = args[0];
  V v_x_24196 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24196, v_s_24197});
}
V g_heff_2ecompile_2efuse_2eendAt_lam33(V self, V *args) {
  V v_s_24202 = args[0];
  V v_x_24201 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24201, v_s_24202});
}
V g_heff_2ecompile_2efuse_2eendAt_lam34(V self, V *args) {
  V v_s_24207 = args[0];
  V v_x_24206 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24206, v_s_24207});
}
V g_heff_2ecompile_2efuse_2eendAt_lam35(V self, V *args) {
  V v_s_24212 = args[0];
  V v_x_24211 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24211, v_s_24212});
}
V g_heff_2ecompile_2efuse_2eendAt_lam36(V self, V *args) {
  V v_s_24219 = args[0];
  V v_x_24218 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24218, v_s_24219});
}
V g_heff_2ecompile_2efuse_2eendAt_lam37(V self, V *args) {
  V v_s_24224 = args[0];
  V v_x_24223 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24223, v_s_24224});
}
V g_heff_2ecompile_2efuse_2emayFuse_lam0(V self, V *args);
Clo g_heff_2ecompile_2efuse_2emayFuse_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2emayFuse_entry, 6, 0};

V g_heff_2ecompile_2efuse_2emayFuse(V v_sg_240, V v_c_241, V v_cs_242, V v_ps_243, V v_as_244, V v_bs_245) {
top: ;
  V v_t_246 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_244));
  V v_t_247 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_cs_242, 0)));
  if (heff_intEq_c(v_t_246, v_t_247)) {
    V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_bs_245));
    V v_t_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_ps_243, 0)));
    if (heff_intEq_c(v_t_249, v_t_2410)) {
      V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){heff_dup(v_sg_240)}));
      V v_t_2413 = (g_heff_2ecompile_2efuse_2eremoveAt(heff_dup(heff_rfield(v_cs_242, 1)), heff_dup(v_as_244)));
      V v_t_2414 = ({ V a_0 = v_t_2412; V a_1 = v_t_2413; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2413); r_; });
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_t_2414);
        V v_t_2415 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(heff_rfield(v_cs_242, 0)), heff_dup(heff_rfield(v_cs_242, 4))));
        V v_t_2416 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2415, v_as_244));
        V v_t_2417 = (g_heff_2ecompile_2efuse_2eremoveAt(heff_dup(heff_rfield(v_cs_242, 1)), v_t_2416));
        V v_t_2418 = (g_list_2efilter_24s2102446697x281519753(v_t_2417));
        V v_ps_2419 = (g_list_2emap_24s1842320150x747311840(v_t_2418));
        V v_t_2420 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2419; V r_ = (g_list_2efoldl_24s753153351x493712762(a_0, a_1)); heff_drop(v_ps_2419); r_; });
        V v_t_2421 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2earmWorks_clo), 4, (V[]){v_sg_240, v_c_241, heff_dup(v_cs_242), v_t_2420}));
        V v_t_2422 = (g_list_2eall(v_t_2421, heff_rfield(v_cs_242, 2)));
        if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
          heff_drop(v_t_2422);
          return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2emayFuse_lam0, 1, 1, (V[]){v_cs_242}); V b_1 = heff_get_n(v_ps_243, 2, 3); V r_ = (g_list_2eall(a_0, b_1)); heff_drop(b_1); r_; });
        } else {
          heff_drop_rec(v_cs_242, 5);
          heff_drop_rec(v_ps_243, 3);
          heff_drop(v_t_2422);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop(v_sg_240);
        heff_drop(v_c_241);
        heff_drop_rec(v_cs_242, 5);
        heff_drop_rec(v_ps_243, 3);
        heff_drop(v_as_244);
        heff_drop(v_t_2414);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_sg_240);
      heff_drop(v_c_241);
      heff_drop_rec(v_cs_242, 5);
      heff_drop_rec(v_ps_243, 3);
      heff_drop(v_as_244);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_sg_240);
    heff_drop(v_c_241);
    heff_drop_rec(v_cs_242, 5);
    heff_drop_rec(v_ps_243, 3);
    heff_drop(v_as_244);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2efuse_2emayFuse_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ecompile_2efuse_2emayFuse(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
V g_heff_2ecompile_2efuse_2emayFuse_lam0(V self, V *args) {
  V v_t_2423 = args[0];
  V v_cs_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2424 = ({ V a_0 = v_t_2423; V b_1 = heff_get_n(v_cs_242, 2, 5); V r_ = (g_heff_2ecompile_2efuse_2efindArm(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x1_2424)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x1_2424, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2424);
  }
}
HEFF_LIT(g_heff_2ecompile_2efuse_2efuseWith_str0, 1, " ");
HEFF_LIT(g_heff_2ecompile_2efuse_2efuseWith_str1, 0, "");
Clo g_heff_2ecompile_2efuse_2efuseWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efuseWith_entry, 7, 0};

V g_heff_2ecompile_2efuse_2efuseWith(V v_c_240, V v_cs_241, V v_p_242, V v_ps_243, V v_as_244, V v_bs_245, V v_s_246) {
top: ;
  V v_t_247 = heff_strAppend(heff_dup(v_c_240), heff_strAppend(((V)&g_heff_2ecompile_2efuse_2efuseWith_str0), heff_dup(v_p_242)));
  V v_t_248 = (g_map_2elookup_24s1546226666x2146984184(v_t_247, heff_rfield(v_s_246, 3)));
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    return (g_heff_2ecompile_2efuse_2efuseNew(v_c_240, v_cs_241, v_p_242, v_ps_243, v_as_244, v_bs_245, heff_dup(heff_rfield(v_s_246, 5)), v_s_246));
  }
  case TAG_Just: {
    V v_k_249 = heff_field(v_t_248, 0);
    V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_p_242);
    heff_drop(v_ps_243);
    V v_x_2413;
    if (heff_strEq_c(heff_dup(v_k_249), ((V)&g_heff_2ecompile_2efuse_2efuseWith_str1))) {
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_as_244);
      heff_drop(v_bs_245);
      heff_drop(v_k_249);
      heff_drop_cell(v_ru_24t_248_24Just, 1);
      v_x_2413 = NTAG(TAG_Nothing);
    } else {
      V v_t_2411 = (g_prelude_2e_2b_2b_24f677743828x1026746250(v_bs_245, heff_get_n(v_cs_241, 1, 5), v_as_244));
      V v_t_2412 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24t_248_24Just, TAG_EGlobal, 1, (V[]){v_k_249}), v_t_2411});
      v_x_2413 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2412});
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_s_246});
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ecompile_2efuse_2efuseWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2efuseWith(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_heff_2ecompile_2efuse_2eletHere_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eletHere_entry, 5, 0};

V g_heff_2ecompile_2efuse_2eletHere(V v_sg_240, V v_x_241, V v_b_242, V v_x4_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_sg_240);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_244});
  }
  case TAG_Just: {
    V v_x41_245 = heff_field(v_x4_243, 0);
    switch (heff_tag_of(v_x41_245)) {
    case TAG_MkPair: {
      V v_p_246 = heff_field(v_x41_245, 0);
      V v_bs_247 = heff_field(v_x41_245, 1);
      V v_x3_248 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_p_246), heff_rfield(v_p_244, 2)));
      switch (heff_tag_of(v_x3_248)) {
      case TAG_Nothing: {
        heff_drop(v_sg_240);
        heff_drop(v_x_241);
        heff_drop(v_b_242);
        return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_244});
      }
      case TAG_Just: {
        heff_take_n(v_x3_248, 0ULL, 1);
        V v_t_2410 = (g_heff_2ecompile_2efuse_2eonceIn(heff_dup(v_x_241), heff_dup(v_b_242)));
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_t_2410);
          V v_t_2411 = (g_heff_2ecompile_2efuse_2eplugK(v_sg_240));
          return heff_tail(heff_get_n(v_t_2411, 0, 1), 3, (V[]){heff_rec_n(3, shape_x__p__bs, (V[]){v_x_241, heff_dup(v_p_246), heff_dup(v_bs_247)}), v_b_242, v_p_244});
        } else {
          heff_drop(v_sg_240);
          heff_drop(v_x_241);
          heff_drop(v_b_242);
          heff_drop(v_t_2410);
          return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_244});
        }
      }
      default: return heff_nomatch(v_x3_248);
      }
    }
    default: return heff_nomatch(v_x41_245);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2efuse_2eletHere_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2efuse_2eletHere(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2ecompile_2efuse_2ehere_lam0(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam0, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam1(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam1, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam2(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam2, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam3(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam3, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam4(V self, V *args);
V g_heff_2ecompile_2efuse_2ehere_lam5(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam5, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam6(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam6, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam7(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam7, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam8(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam8, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam9(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam9, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam10(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam10, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam11(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam11, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam12(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam12, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam13(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam13, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam14(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam14, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam15(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam15, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam16(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam16, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam17(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam17, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam18(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam18, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam19(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam19, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam20(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam20, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam21(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam21, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam22(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam22, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam23(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam23, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam24(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam24, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam25(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam25, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam26(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam26, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam27(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam27, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam28(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam28, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam29(V self, V *args);
V g_heff_2ecompile_2efuse_2ehere_lam30(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam30, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam31(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam31, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam32(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam32_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam32, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam33(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam33_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam33, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam34(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam34_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam34, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam35(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam35, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam36(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam36, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam37(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam37_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam37, 1, 0};
Clo g_heff_2ecompile_2efuse_2ehere_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_entry, 2, 0};

V g_heff_2ecompile_2efuse_2ehere(V v_sg_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam0_clo);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam1_clo);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam2_clo);
  }
  case TAG_EApp: {
    V v_x21_249 = heff_field(v_x2_241, 0);
    V v_as_2410 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_249)) {
    case TAG_EVar: {
      heff_take_n(v_x21_249, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop(v_as_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam3_clo);
    }
    case TAG_EGlobal: {
      V v_c_2413 = heff_field(v_x21_249, 0);
      heff_take_n(v_x21_249, 1ULL, 1);
      return heff_clo_n(g_heff_2ecompile_2efuse_2ehere_lam4, 1, 3, (V[]){v_c_2413, v_as_2410, v_sg_240});
    }
    case TAG_ELam: {
      heff_take_n(v_x21_249, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop(v_as_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam5_clo);
    }
    case TAG_EApp: {
      heff_take_n(v_x21_249, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop(v_as_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam6_clo);
    }
    case TAG_ELet: {
      heff_take_n(v_x21_249, 0ULL, 3);
      heff_drop(v_sg_240);
      heff_drop(v_as_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam7_clo);
    }
    case TAG_ERecord: {
      heff_take_n(v_x21_249, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop(v_as_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam8_clo);
    }
    case TAG_EProj: {
      heff_take_n(v_x21_249, 0ULL, 4);
      heff_drop(v_sg_240);
      heff_drop(v_as_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam9_clo);
    }
    case TAG_ETag: {
      heff_take_n(v_x21_249, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop(v_as_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam10_clo);
    }
    case TAG_EMatch: {
      heff_take_n(v_x21_249, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop(v_as_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam11_clo);
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_249, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop(v_as_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam12_clo);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x21_249, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop(v_as_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam13_clo);
    }
    case TAG_ECall: {
      heff_take_n(v_x21_249, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop(v_as_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam14_clo);
    }
    case TAG_EInt: {
      heff_take_n(v_x21_249, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop(v_as_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam15_clo);
    }
    case TAG_EFloat: {
      heff_take_n(v_x21_249, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop(v_as_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam16_clo);
    }
    case TAG_EStr: {
      heff_take_n(v_x21_249, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop(v_as_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam17_clo);
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_249, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop(v_as_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam18_clo);
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_249, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop(v_as_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam19_clo);
    }
    case TAG_EFloat32: {
      heff_take_n(v_x21_249, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop(v_as_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam20_clo);
    }
    case TAG_EAbandon: {
      heff_drop(v_sg_240);
      heff_drop(v_as_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam21_clo);
    }
    case TAG_EFix: {
      heff_take_n(v_x21_249, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop(v_as_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam22_clo);
    }
    default: return heff_nomatch(v_x21_249);
    }
  }
  case TAG_ELet: {
    V v_x_2467 = heff_field(v_x2_241, 0);
    V v_a_2468 = heff_field(v_x2_241, 1);
    V v_b_2469 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2470 = (g_heff_2ecompile_2efuse_2eglobalCall(v_a_2468));
    return heff_tail(((V)&g_heff_2ecompile_2efuse_2eletHere_clo), 4, (V[]){v_sg_240, v_x_2467, v_b_2469, v_t_2470});
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam23_clo);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam24_clo);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam25_clo);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam26_clo);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam27_clo);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam28_clo);
  }
  case TAG_ECall: {
    V v_c_2490 = heff_field(v_x2_241, 0);
    V v_as_2491 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    return heff_clo_n(g_heff_2ecompile_2efuse_2ehere_lam29, 1, 3, (V[]){v_c_2490, v_as_2491, v_sg_240});
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam30_clo);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam31_clo);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam32_clo);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam33_clo);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam34_clo);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam35_clo);
  }
  case TAG_EAbandon: {
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam36_clo);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam37_clo);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2ehere_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2ehere(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2ehere_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_243});
}
V g_heff_2ecompile_2efuse_2ehere_lam1(V self, V *args) {
  V v_s_245 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_245});
}
V g_heff_2ecompile_2efuse_2ehere_lam2(V self, V *args) {
  V v_s_248 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_248});
}
V g_heff_2ecompile_2efuse_2ehere_lam3(V self, V *args) {
  V v_s_2412 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2412});
}
V g_heff_2ecompile_2efuse_2ehere_lam4(V self, V *args) {
  V v_s_2414 = args[0];
  V v_c_2413 = heff_env(self)[0];
  V v_as_2410 = heff_env(self)[1];
  V v_sg_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_c_2413), heff_rfield(v_s_2414, 1)));
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    heff_drop(v_c_2413);
    heff_drop(v_as_2410);
    heff_drop(v_sg_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2414});
  }
  case TAG_Just: {
    V v_cs_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    V v_t_2417 = (g_heff_2ecompile_2efuse_2enthF(heff_get_n(v_cs_2416, 1, 5), v_as_2410));
    return ({ V a_0 = v_sg_240; V a_1 = v_c_2413; V a_2 = v_as_2410; V a_3 = v_t_2417; V a_4 = v_s_2414; V r_ = (g_heff_2ecompile_2efuse_2efuseOn(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2417); r_; });
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2ecompile_2efuse_2ehere_lam5(V self, V *args) {
  V v_s_2420 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2420});
}
V g_heff_2ecompile_2efuse_2ehere_lam6(V self, V *args) {
  V v_s_2423 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2423});
}
V g_heff_2ecompile_2efuse_2ehere_lam7(V self, V *args) {
  V v_s_2427 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2427});
}
V g_heff_2ecompile_2efuse_2ehere_lam8(V self, V *args) {
  V v_s_2430 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2430});
}
V g_heff_2ecompile_2efuse_2ehere_lam9(V self, V *args) {
  V v_s_2435 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2435});
}
V g_heff_2ecompile_2efuse_2ehere_lam10(V self, V *args) {
  V v_s_2438 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2438});
}
V g_heff_2ecompile_2efuse_2ehere_lam11(V self, V *args) {
  V v_s_2441 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2441});
}
V g_heff_2ecompile_2efuse_2ehere_lam12(V self, V *args) {
  V v_s_2443 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2443});
}
V g_heff_2ecompile_2efuse_2ehere_lam13(V self, V *args) {
  V v_s_2446 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2446});
}
V g_heff_2ecompile_2efuse_2ehere_lam14(V self, V *args) {
  V v_s_2449 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2449});
}
V g_heff_2ecompile_2efuse_2ehere_lam15(V self, V *args) {
  V v_s_2451 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2451});
}
V g_heff_2ecompile_2efuse_2ehere_lam16(V self, V *args) {
  V v_s_2453 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2453});
}
V g_heff_2ecompile_2efuse_2ehere_lam17(V self, V *args) {
  V v_s_2455 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2455});
}
V g_heff_2ecompile_2efuse_2ehere_lam18(V self, V *args) {
  V v_s_2457 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2457});
}
V g_heff_2ecompile_2efuse_2ehere_lam19(V self, V *args) {
  V v_s_2460 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2460});
}
V g_heff_2ecompile_2efuse_2ehere_lam20(V self, V *args) {
  V v_s_2462 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2462});
}
V g_heff_2ecompile_2efuse_2ehere_lam21(V self, V *args) {
  V v_s_2463 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2463});
}
V g_heff_2ecompile_2efuse_2ehere_lam22(V self, V *args) {
  V v_s_2466 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2466});
}
V g_heff_2ecompile_2efuse_2ehere_lam23(V self, V *args) {
  V v_s_2473 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2473});
}
V g_heff_2ecompile_2efuse_2ehere_lam24(V self, V *args) {
  V v_s_2478 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2478});
}
V g_heff_2ecompile_2efuse_2ehere_lam25(V self, V *args) {
  V v_s_2481 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2481});
}
V g_heff_2ecompile_2efuse_2ehere_lam26(V self, V *args) {
  V v_s_2484 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2484});
}
V g_heff_2ecompile_2efuse_2ehere_lam27(V self, V *args) {
  V v_s_2486 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2486});
}
V g_heff_2ecompile_2efuse_2ehere_lam28(V self, V *args) {
  V v_s_2489 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2489});
}
V g_heff_2ecompile_2efuse_2ehere_lam29(V self, V *args) {
  V v_s_2492 = args[0];
  V v_c_2490 = heff_env(self)[0];
  V v_as_2491 = heff_env(self)[1];
  V v_sg_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2493 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_c_2490), heff_rfield(v_s_2492, 1)));
  switch (heff_tag_of(v_t_2493)) {
  case TAG_Nothing: {
    heff_drop(v_c_2490);
    heff_drop(v_as_2491);
    heff_drop(v_sg_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2492});
  }
  case TAG_Just: {
    V v_cs_2494 = heff_field(v_t_2493, 0);
    heff_take_n(v_t_2493, 1ULL, 1);
    V v_t_2495 = (g_heff_2ecompile_2efuse_2enthF(heff_get_n(v_cs_2494, 1, 5), v_as_2491));
    return ({ V a_0 = v_sg_240; V a_1 = v_c_2490; V a_2 = v_as_2491; V a_3 = v_t_2495; V a_4 = v_s_2492; V r_ = (g_heff_2ecompile_2efuse_2efuseOn(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2495); r_; });
  }
  default: return heff_nomatch(v_t_2493);
  }
}
V g_heff_2ecompile_2efuse_2ehere_lam30(V self, V *args) {
  V v_s_2497 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2497});
}
V g_heff_2ecompile_2efuse_2ehere_lam31(V self, V *args) {
  V v_s_2499 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2499});
}
V g_heff_2ecompile_2efuse_2ehere_lam32(V self, V *args) {
  V v_s_24101 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24101});
}
V g_heff_2ecompile_2efuse_2ehere_lam33(V self, V *args) {
  V v_s_24103 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24103});
}
V g_heff_2ecompile_2efuse_2ehere_lam34(V self, V *args) {
  V v_s_24106 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24106});
}
V g_heff_2ecompile_2efuse_2ehere_lam35(V self, V *args) {
  V v_s_24108 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24108});
}
V g_heff_2ecompile_2efuse_2ehere_lam36(V self, V *args) {
  V v_s_24109 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24109});
}
V g_heff_2ecompile_2efuse_2ehere_lam37(V self, V *args) {
  V v_s_24112 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24112});
}