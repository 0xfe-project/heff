// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define TAG_Tip 31527
#define LBL_arity 294440695
#define LBL_arms 9498206
#define LBL_at 9882
#define LBL_bs 9912
#define LBL_c 317
#define LBL_consumers 1203455020
#define LBL_count 296209705
#define LBL_cp 9940
#define LBL_cvars 296399145
#define LBL_fixed 298804110
#define LBL_fresh 299054408
#define LBL_go 10063
#define LBL_key 315609
#define LBL_left 9813198
#define LBL_made 9839068
#define LBL_p 330
#define LBL_params 951713969
#define LBL_parity 951721880
#define LBL_producers 572620898
#define LBL_rest 9992347
#define LBL_safe 10017876
#define LBL_supply 1056026650
#define LBL_tags 10047712
#define LBL_total 311908190
#define LBL_underLam 296337946
#define LBL_x 338
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_supply__consumers__producers__made__fresh__left[] = {LBL_supply, LBL_consumers, LBL_producers, LBL_made, LBL_fresh, LBL_left};
static uint32_t shape_x__p__bs[] = {LBL_x, LBL_p, LBL_bs};
V g_heff_2ecompile_2efuse_2earmGiven(V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2earmGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2earmGiven_clo;
HeffT2 g_heff_2ecompile_2efuse_2ecallOf_24cpr(V, V, V);
V g_heff_2ecompile_2efuse_2econdCalls(V, V);
V g_heff_2ecompile_2efuse_2econdCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2econdCalls_clo;
V g_heff_2ecompile_2efuse_2econsRec(V, V, V);
V g_heff_2ecompile_2efuse_2econsRec_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2econsRec_clo;
HeffT2 g_heff_2ecompile_2efuse_2econsumerOf_24cpr(V, V);
HeffT2 g_heff_2ecompile_2efuse_2econsumerWith_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2eelemF(V, V);
V g_heff_2ecompile_2efuse_2eelemF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eelemF_clo;
V g_heff_2ecompile_2efuse_2eendAt(V, V);
V g_heff_2ecompile_2efuse_2eendAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eendAt_clo;
HeffT2 g_heff_2ecompile_2efuse_2efindArm_24cpr(V, V);
V g_heff_2ecompile_2efuse_2efixedGo(V, V, V);
V g_heff_2ecompile_2efuse_2efixedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efixedGo_clo;
V g_heff_2ecompile_2efuse_2efixedGo_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2efixedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efixedGo_24dps_clo;
HeffT2 g_heff_2ecompile_2efuse_2efreshF_24cpr(V, V);
V g_heff_2ecompile_2efuse_2efuseKnown_24tok2(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseKnown_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseKnown_24tok2_clo;
V g_heff_2ecompile_2efuse_2efuseNew(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseNew_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseNew_clo;
V g_heff_2ecompile_2efuse_2efuseOn(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseOn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseOn_clo;
V g_heff_2ecompile_2efuse_2efuseWith(V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseWith_clo;
V g_heff_2ecompile_2efuse_2efuseWith_24tok1(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseWith_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseWith_24tok1_clo;
V g_heff_2ecompile_2efuse_2eglobalCall(V);
V g_heff_2ecompile_2efuse_2eglobalCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eglobalCall_clo;
HeffT2 g_heff_2ecompile_2efuse_2eglobalCall_24cpr(V);
V g_heff_2ecompile_2efuse_2egoesOf_24dps(V, V);
V g_heff_2ecompile_2efuse_2egoesOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2egoesOf_24dps_clo;
V g_heff_2ecompile_2efuse_2ehere(V, V);
V g_heff_2ecompile_2efuse_2ehere_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ehere_clo;
V g_heff_2ecompile_2efuse_2einitF(V);
V g_heff_2ecompile_2efuse_2einitF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einitF_clo;
V g_heff_2ecompile_2efuse_2einitF_24dps(V, V);
V g_heff_2ecompile_2efuse_2einitF_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einitF_24dps_clo;
V g_heff_2ecompile_2efuse_2einsertAt(V, V, V);
V g_heff_2ecompile_2efuse_2einsertAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einsertAt_clo;
V g_heff_2ecompile_2efuse_2einsertAt_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2einsertAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einsertAt_24dps_clo;
V g_heff_2ecompile_2efuse_2eisVar(V, V);
V g_heff_2ecompile_2efuse_2eisVar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eisVar_clo;
V g_heff_2ecompile_2efuse_2ekidsF(V, V);
V g_heff_2ecompile_2efuse_2ekidsF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ekidsF_clo;
HeffT2 g_heff_2ecompile_2efuse_2elastF_24cpr(V);
V g_heff_2ecompile_2efuse_2eletHere(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2eletHere_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eletHere_clo;
V g_heff_2ecompile_2efuse_2emayFuse(V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2emayFuse_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2emayFuse_clo;
V g_heff_2ecompile_2efuse_2enthF(V, V);
V g_heff_2ecompile_2efuse_2enthF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2enthF_clo;
HeffT2 g_heff_2ecompile_2efuse_2enthF_24cpr(V, V);
V g_heff_2ecompile_2efuse_2eonceIn(V, V);
V g_heff_2ecompile_2efuse_2eonceIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eonceIn_clo;
V g_heff_2ecompile_2efuse_2epathCalls(V, V);
V g_heff_2ecompile_2efuse_2epathCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2epathCalls_clo;
V g_heff_2ecompile_2efuse_2eplugK(V);
V g_heff_2ecompile_2efuse_2eplugK_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eplugK_clo;
HeffT2 g_heff_2ecompile_2efuse_2eposF_24cpr(V, V, V);
V g_heff_2ecompile_2efuse_2erecall(V, V, V, V);
V g_heff_2ecompile_2efuse_2erecall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2erecall_clo;
V g_heff_2ecompile_2efuse_2erecallAt(V, V, V);
V g_heff_2ecompile_2efuse_2erecallAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2erecallAt_clo;
V g_heff_2ecompile_2efuse_2eremoveAt(V, V);
V g_heff_2ecompile_2efuse_2eremoveAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eremoveAt_clo;
V g_heff_2ecompile_2efuse_2eremoveAt_24dps(V, V, V);
V g_heff_2ecompile_2efuse_2eremoveAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eremoveAt_24dps_clo;
V g_heff_2ecompile_2efuse_2esameGo(V, V);
V g_heff_2ecompile_2efuse_2esameGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esameGo_clo;
V g_heff_2ecompile_2efuse_2eselfCalls(V, V, V);
V g_heff_2ecompile_2efuse_2eselfCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eselfCalls_clo;
V g_heff_2ecompile_2efuse_2eselfCalls_24tok1(V, V, V, V);
V g_heff_2ecompile_2efuse_2eselfCalls_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eselfCalls_24tok1_clo;
V g_heff_2ecompile_2efuse_2esetAt(V, V, V);
V g_heff_2ecompile_2efuse_2esetAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esetAt_clo;
V g_heff_2ecompile_2efuse_2esetAt_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2esetAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esetAt_24dps_clo;
V g_heff_2ecompile_2efuse_2etagEnd(V, V, V, V);
V g_heff_2ecompile_2efuse_2etagEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2etagEnd_clo;
V g_heff_2ecompile_2efuse_2etagEnd_24tok3(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2etagEnd_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2etagEnd_24tok3_clo;
V g_heff_2ecompile_2efuse_2eworkPure(V, V);
V g_heff_2ecompile_2efuse_2eworkPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eworkPure_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2efailing_get(void);
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s1543979616x278497281(V, V, V, V, V);
V g_list_2eall_24s1543979616x278497281_entry(V self, V *a);
extern Clo g_list_2eall_24s1543979616x278497281_clo;
V g_list_2eany_24s667046479x351039015(V, V);
V g_list_2eany_24s667046479x351039015_entry(V self, V *a);
extern Clo g_list_2eany_24s667046479x351039015_clo;
V g_list_2efoldl_24s455728131x407835966(V, V);
V g_list_2efoldl_24s455728131x407835966_entry(V self, V *a);
extern Clo g_list_2efoldl_24s455728131x407835966_clo;
V g_list_2efoldl_24s571527232x333134686(V, V);
V g_list_2efoldl_24s571527232x333134686_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571527232x333134686_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1457049037x722637222(V);
V g_list_2ekeepIf_24s1457049037x722637222_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1457049037x722637222_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1690674600x556093466(V);
V g_list_2emap_24s1690674600x556093466_entry(V self, V *a);
extern Clo g_list_2emap_24s1690674600x556093466_clo;
V g_list_2emap_24s866308031x234213482(V, V, V, V, V);
V g_list_2emap_24s866308031x234213482_entry(V self, V *a);
extern Clo g_list_2emap_24s866308031x234213482_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f677743828x1026746250(V, V, V);
V g_prelude_2e_2b_2b_24f677743828x1026746250_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f677743828x1026746250_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2emaybe(V, V, V);
V g_prelude_2emaybe_entry(V self, V *a);
extern Clo g_prelude_2emaybe_clo;
V g_prelude_2etraverse_24s545943161x1483966866(V, V);
V g_prelude_2etraverse_24s545943161x1483966866_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s545943161x1483966866_clo;
HeffT2 g_prelude_2etraverse_24s801310267x475583082_24cpr(V, V);
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
Clo g_heff_2ecompile_2efuse_2enthF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2enthF_entry, 2, 0};

V g_heff_2ecompile_2efuse_2enthF(V v_i_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2efuse_2enthF_24cpr(v_i_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2efuse_2enthF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2enthF(a[0], a[1]);
}
Clo g_heff_2ecompile_2efuse_2eremoveAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eremoveAt_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eremoveAt(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return v_xs_243;
    } else {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2efuse_2eremoveAt_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2eremoveAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eremoveAt(a[0], a[1]);
}
Clo g_heff_2ecompile_2efuse_2esetAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2esetAt_24dps_entry, 4, 0};

V g_heff_2ecompile_2efuse_2esetAt_24dps(V v_i_240, V v_y_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_y_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_xs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_y_241, v_xs_245}));
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_247 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_y_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_246;
      v_i_240 = t_0;
      v_y_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2esetAt_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2esetAt_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2efuse_2einsertAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2einsertAt_24dps_entry, 4, 0};

V g_heff_2ecompile_2efuse_2einsertAt_24dps(V v_i_240, V v_y_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_241, NTAG(TAG_Nil)});
    return heff_setField(v_d_243, MK_INT(1LL), v_t_244);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_xs_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      V v_t_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_241, heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, v_xs_246})});
      return heff_setField(v_d_243, MK_INT(1LL), v_t_247);
    } else {
      V v_cell_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_y_241;
      V t_2 = v_xs_246;
      V t_3 = v_cell_248;
      v_i_240 = t_0;
      v_y_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2einsertAt_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2einsertAt_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2efuse_2einitF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2einitF_entry, 1, 0};

V g_heff_2ecompile_2efuse_2einitF(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_246 = (g_heff_2ecompile_2efuse_2einitF_24dps(v_x12_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuse_2einitF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2einitF(a[0]);
}

HeffT2 g_heff_2ecompile_2efuse_2eglobalCall_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    V v_x11_245 = heff_field(v_x1_240, 0);
    V v_args_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_EVar: {
      heff_take_n(v_x11_245, 0ULL, 1);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EGlobal: {
      V v_g_248 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_MkPair, 2, (V[]){v_g_248, v_args_246})}});
    }
    case TAG_ELam: {
      heff_take_n(v_x11_245, 0ULL, 2);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_take_n(v_x11_245, 0ULL, 2);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_take_n(v_x11_245, 0ULL, 3);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_take_n(v_x11_245, 0ULL, 2);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_take_n(v_x11_245, 0ULL, 4);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_take_n(v_x11_245, 0ULL, 3);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_245, 0ULL, 2);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      heff_take_n(v_x11_245, 0ULL, 1);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x11_245, 0ULL, 2);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_take_n(v_x11_245, 0ULL, 2);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      heff_take_n(v_x11_245, 0ULL, 1);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      heff_take_na(v_x11_245, 0ULL, 1);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      heff_take_n(v_x11_245, 0ULL, 1);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      heff_take_n(v_x11_245, 0ULL, 1);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_take_n(v_x11_245, 0ULL, 2);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_take_na(v_x11_245, 0ULL, 1);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      heff_take_n(v_x11_245, 0ULL, 1);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      heff_take_n(v_x11_245, 0ULL, 3);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      heff_take_n(v_x11_245, 0ULL, 1);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_take_n(v_x11_245, 0ULL, 2);
      heff_drop(v_args_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_245)}});
    }
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    V v_g_2463 = heff_field(v_x1_240, 0);
    V v_args_2464 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_MkPair, 2, (V[]){v_g_2463, v_args_2464})}});
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2efuse_2eworkPure_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2efuse_2eworkPure_str1, 5, "False");
V g_heff_2ecompile_2efuse_2eworkPure_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2eworkPure_lam1(V self, V *args);
Clo g_heff_2ecompile_2efuse_2eworkPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eworkPure_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eworkPure(V v_sg_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_sg_240, 0, 2); V a_1 = v_g_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_g_243); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_246;
        heff_drop(v_x_247);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_field_246);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_x21_2410 = heff_field(v_x2_241, 0);
    V v_args_2411 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2410)) {
    case TAG_EVar: {
      heff_take_n(v_x21_2410, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_2413 = heff_field(v_x21_2410, 0);
      heff_take_n(v_x21_2410, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      HeffT2 v_t_2414 = ({ V a_0 = heff_rfield(v_sg_240, 1); V a_1 = v_g_2413; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_g_2413); r_; });
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_ar_2417 = v_field_2416;
          V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2411));
          if (heff_intLe_c(v_t_2418, v_ar_2417)) {
            V v_t_2419 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){v_sg_240}));
            return ({ V a_0 = v_t_2419; V a_1 = v_args_2411; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_args_2411); r_; });
          } else {
            heff_drop_rec(v_sg_240, 2);
            heff_drop(v_args_2411);
            return NTAG(TAG_False);
          }
        } else {
          heff_drop_rec(v_sg_240, 2);
          heff_drop(v_args_2411);
          heff_drop(v_field_2416);
          return NTAG(TAG_False);
        }
      }
    }
    case TAG_ELam: {
      V v_xs_2420 = heff_field(v_x21_2410, 0);
      V v_b_2421 = heff_field(v_x21_2410, 1);
      heff_take_n(v_x21_2410, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      V v_t_2422 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2411));
      V v_t_2423 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2420));
      if (heff_intLe_c(v_t_2422, v_t_2423)) {
        V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){heff_dup(v_sg_240)}));
        V v_t_2425 = (g_list_2eall(v_t_2424, v_args_2411));
        if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
          heff_drop(v_t_2425);
          V v_t_2426 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_2411; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_2411); r_; });
          V v_t_2427 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2420; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
          if (heff_intLt_c(v_t_2426, v_t_2427)) {
            heff_drop_rec(v_sg_240, 2);
            heff_drop(v_b_2421);
            return NTAG(TAG_True);
          } else {
            V t_0 = v_sg_240;
            V t_1 = v_b_2421;
            v_sg_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
        } else {
          heff_drop_rec(v_sg_240, 2);
          heff_drop(v_args_2411);
          heff_drop(v_xs_2420);
          heff_drop(v_b_2421);
          heff_drop(v_t_2425);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop_rec(v_sg_240, 2);
        heff_drop(v_args_2411);
        heff_drop(v_xs_2420);
        heff_drop(v_b_2421);
        return NTAG(TAG_False);
      }
    }
    case TAG_EApp: {
      V v_f_2428 = heff_field(v_x21_2410, 0);
      V v_bs_2429 = heff_field(v_x21_2410, 1);
      V v_ru_24x21_2410_24EApp = heff_take_reuse_n(v_x21_2410, 3ULL, 2);
      V v_t_2430 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x21_2410_24EApp, v_bs_2429, v_args_2411));
      V t_0 = v_sg_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_f_2428, v_t_2430});
      v_sg_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      heff_take_n(v_x21_2410, 0ULL, 3);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_take_n(v_x21_2410, 0ULL, 2);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_take_n(v_x21_2410, 0ULL, 4);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_take_n(v_x21_2410, 0ULL, 3);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_take_n(v_x21_2410, 0ULL, 2);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_2410, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x21_2410, 0ULL, 2);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_take_n(v_x21_2410, 0ULL, 2);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_take_n(v_x21_2410, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_2410, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_take_n(v_x21_2410, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_2410, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_2410, 0ULL, 2);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_2410, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      heff_take_n(v_x21_2410, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      heff_take_n(v_x21_2410, 0ULL, 3);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      heff_take_n(v_x21_2410, 0ULL, 1);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_take_n(v_x21_2410, 0ULL, 2);
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2411);
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_2410);
    }
  }
  case TAG_ELet: {
    V v_a_2465 = heff_field(v_x2_241, 1);
    V v_b_2466 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2467 = (g_heff_2ecompile_2efuse_2eworkPure(heff_dup(v_sg_240), v_a_2465));
    if ((heff_dup(v_t_2467) == NTAG(TAG_True))) {
      heff_drop(v_t_2467);
      V t_0 = v_sg_240;
      V t_1 = v_b_2466;
      v_sg_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_b_2466);
      heff_drop(v_t_2467);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    V v_fs_2468 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eworkPure_lam0, 1, 1, (V[]){v_sg_240}); V a_1 = v_fs_2468; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_fs_2468); r_; });
  }
  case TAG_EProj: {
    V v_e_2474 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 4);
    V t_0 = v_sg_240;
    V t_1 = v_e_2474;
    v_sg_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_args_2479 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    V v_t_2481 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){v_sg_240}));
    return ({ V a_0 = v_t_2481; V a_1 = v_args_2479; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_args_2479); r_; });
  }
  case TAG_EMatch: {
    V v_s_2482 = heff_field(v_x2_241, 0);
    V v_arms_2483 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2484 = (g_heff_2ecompile_2efuse_2eworkPure(heff_dup(v_sg_240), v_s_2482));
    if ((heff_dup(v_t_2484) == NTAG(TAG_True))) {
      heff_drop(v_t_2484);
      V v_t_2485 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2483));
      if (heff_intEq_c(v_t_2485, MK_INT(2LL))) {
        V v_t_2486 = ({ V b_0 = ((V)&g_heff_2ecompile_2efuse_2eworkPure_str0); V a_1 = v_arms_2483; V r_ = (g_list_2eany_24s667046479x351039015(b_0, a_1)); heff_drop(b_0); r_; });
        if ((heff_dup(v_t_2486) == NTAG(TAG_True))) {
          heff_drop(v_t_2486);
          V v_t_2487 = ({ V b_0 = ((V)&g_heff_2ecompile_2efuse_2eworkPure_str1); V a_1 = v_arms_2483; V r_ = (g_list_2eany_24s667046479x351039015(b_0, a_1)); heff_drop(b_0); r_; });
          if ((heff_dup(v_t_2487) == NTAG(TAG_True))) {
            heff_drop(v_t_2487);
            return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eworkPure_lam1, 1, 1, (V[]){v_sg_240}); V a_1 = v_arms_2483; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2483); r_; });
          } else {
            heff_drop_rec(v_sg_240, 2);
            heff_drop(v_arms_2483);
            heff_drop(v_t_2487);
            return NTAG(TAG_False);
          }
        } else {
          heff_drop_rec(v_sg_240, 2);
          heff_drop(v_arms_2483);
          heff_drop(v_t_2486);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop_rec(v_sg_240, 2);
        heff_drop(v_arms_2483);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_arms_2483);
      heff_drop(v_t_2484);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2494 = heff_field(v_x2_241, 0);
    V v_args_2495 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_x1_2496 = ({ V a_0 = v_p_2494; V b_1 = heff_dup(g_heff_2ecompile_2esimplify_2efailing_get()); V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, b_1)); heff_drop(v_p_2494); heff_drop(b_1); r_; });
    if (!(heff_dup(v_x1_2496) == NTAG(TAG_True))) {
      heff_drop(v_x1_2496);
      V v_t_2497 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){v_sg_240}));
      return ({ V a_0 = v_t_2497; V a_1 = v_args_2495; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_args_2495); r_; });
    } else {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_args_2495);
      heff_drop(v_x1_2496);
      return NTAG(TAG_False);
    }
  }
  case TAG_ECall: {
    V v_g_2498 = heff_field(v_x2_241, 0);
    V v_args_2499 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_24100 = ({ V a_0 = heff_rfield(v_sg_240, 1); V a_1 = v_g_2498; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_g_2498); r_; });
    {
      V v_field_24102 = v_t_24100.f[1];
      int64_t v_tag_24101 = ((int64_t)v_t_24100.f[0]);
      if ((v_tag_24101 == ((int64_t)0ULL))) {
        V v_ar_24103 = v_field_24102;
        V v_t_24104 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2499));
        if (heff_intLe_c(v_t_24104, v_ar_24103)) {
          V v_t_24105 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){v_sg_240}));
          return ({ V a_0 = v_t_24105; V a_1 = v_args_2499; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_args_2499); r_; });
        } else {
          heff_drop_rec(v_sg_240, 2);
          heff_drop(v_args_2499);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop_rec(v_sg_240, 2);
        heff_drop(v_args_2499);
        heff_drop(v_field_24102);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    V v_c_24113 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24114 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){v_sg_240}));
    V v_t_24115 = ({ V a_0 = v_c_24113; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_24113); r_; });
    return ({ V a_0 = v_t_24114; V a_1 = v_t_24115; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24115); r_; });
  }
  case TAG_ESet: {
    V v_a_24117 = heff_field(v_x2_241, 1);
    V v_b_24118 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_24119 = (g_heff_2ecompile_2efuse_2eworkPure(heff_dup(v_sg_240), v_a_24117));
    if ((heff_dup(v_t_24119) == NTAG(TAG_True))) {
      heff_drop(v_t_24119);
      V t_0 = v_sg_240;
      V t_1 = v_b_24118;
      v_sg_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_sg_240, 2);
      heff_drop(v_b_24118);
      heff_drop(v_t_24119);
      return NTAG(TAG_False);
    }
  }
  case TAG_EValues: {
    V v_es_24120 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24121 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){v_sg_240}));
    return ({ V a_0 = v_t_24121; V a_1 = v_es_24120; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_es_24120); r_; });
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_sg_240, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2eworkPure_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eworkPure(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2eworkPure_lam0(V self, V *args) {
  V v_p_2470 = args[0];
  V v_sg_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2473;
  switch (heff_tag_of(v_p_2470)) {
  case TAG_MkPair: {
    V v_y_2472 = heff_field(v_p_2470, 1);
    heff_take_n(v_p_2470, 2ULL, 2);
    v_t_2473 = v_y_2472;
    break;
  }
  default: heff_nomatch(v_p_2470);
  }
  return (g_heff_2ecompile_2efuse_2eworkPure(v_sg_240, v_t_2473));
}
V g_heff_2ecompile_2efuse_2eworkPure_lam1(V self, V *args) {
  V v_a_2488 = args[0];
  V v_sg_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2492;
  switch (heff_tag_of(v_a_2488)) {
  case TAG_MkArm: {
    V v_b_2491 = heff_field(v_a_2488, 2);
    heff_take_n(v_a_2488, 4ULL, 3);
    v_t_2492 = v_b_2491;
    break;
  }
  default: heff_nomatch(v_a_2488);
  }
  return (g_heff_2ecompile_2efuse_2eworkPure(v_sg_240, v_t_2492));
}
V g_heff_2ecompile_2efuse_2epathCalls_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2epathCalls_lam1(V self, V *args);
Clo g_heff_2ecompile_2efuse_2epathCalls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2epathCalls_entry, 2, 0};

V g_heff_2ecompile_2efuse_2epathCalls(V v_me_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_ru_24x2_241_24EVar = heff_take_reuse_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_me_240, 4);
    return heff_tag_at_n(v_ru_24x2_241_24EVar, TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EGlobal = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    if (heff_strEq_c(v_g_243, heff_get_n(v_me_240, 0, 4))) {
      heff_drop_cell(v_ru_24x2_241_24EGlobal, 1);
      return NTAG(TAG_Nothing);
    } else {
      return heff_tag_at_n(v_ru_24x2_241_24EGlobal, TAG_Just, 1, (V[]){MK_INT(0LL)});
    }
  }
  case TAG_ELam: {
    V v_b_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_245)));
    V v_t_247 = (g_heff_2ecompile_2eir_2enubI(v_t_246));
    V v_t_248 = ({ V a_0 = heff_rfield(v_me_240, 0); V a_1 = v_t_247; V r_ = (g_heff_2ecompile_2efuse_2eelemF(a_0, a_1)); heff_drop(v_t_247); r_; });
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop_rec(v_me_240, 4);
      heff_drop(v_b_245);
      heff_drop_cell(v_ru_24x2_241_24ELam, 2);
      heff_drop(v_t_248);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_248);
      V v_x_249 = heff_get_n(v_me_240, 3, 4);
      V v_t_2410 = heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_Cons, 2, (V[]){heff_dup(v_b_245), NTAG(TAG_Nil)});
      V v_t_2411 = (g_heff_2ecompile_2eir_2ecountW(v_x_249, MK_INT(0LL), v_t_2410));
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_245, NTAG(TAG_Nil)});
      V v_t_2413 = ({ V a_0 = v_x_249; V a_1 = v_t_2412; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_249); r_; });
      V v_x_2414 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2411, v_t_2413}), 0, 2);
      if (heff_intLt_c(MK_INT(0LL), v_x_2414)) {
        return NTAG(TAG_Nothing);
      } else {
        return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)});
      }
    }
  }
  case TAG_EApp: {
    V v_x21_2415 = heff_field(v_x2_241, 0);
    V v_args_2416 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2415)) {
    case TAG_EVar: {
      V v_t_2418 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2419 = (g_list_2emap(v_t_2418, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2419; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2419); r_; });
    }
    case TAG_EGlobal: {
      V v_g_2420 = heff_field(v_x21_2415, 0);
      V v_ru_24x21_2415_24EGlobal = heff_take_reuse_n(v_x21_2415, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_g_2420), heff_dup(heff_rfield(v_me_240, 0)))) {
        heff_drop_cell(v_ru_24x2_241_24EApp, 2);
        return ({ V a_0 = v_ru_24x21_2415_24EGlobal; V a_1 = v_me_240; V a_2 = v_g_2420; V a_3 = v_args_2416; V r_ = (g_heff_2ecompile_2efuse_2eselfCalls_24tok1(a_0, a_1, a_2, a_3)); heff_drop(v_g_2420); r_; });
      } else {
        heff_drop(v_g_2420);
        V v_t_2421 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
        V v_ms_2422 = (g_list_2emap_24tok2(v_ru_24x2_241_24EApp, v_t_2421, v_args_2416));
        return ({ V a_0 = heff_tag_at_n(v_ru_24x21_2415_24EGlobal, TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2422; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2422); r_; });
      }
    }
    case TAG_ELam: {
      V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2426 = (g_list_2emap(v_t_2425, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2426; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2426); r_; });
    }
    case TAG_EApp: {
      V v_t_2429 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2430 = (g_list_2emap(v_t_2429, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2430; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2430); r_; });
    }
    case TAG_ELet: {
      V v_t_2434 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2435 = (g_list_2emap(v_t_2434, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2435; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2435); r_; });
    }
    case TAG_ERecord: {
      V v_t_2438 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2439 = (g_list_2emap(v_t_2438, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2439; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2439); r_; });
    }
    case TAG_EProj: {
      V v_t_2444 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2445 = (g_list_2emap(v_t_2444, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2445; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2445); r_; });
    }
    case TAG_ETag: {
      V v_t_2449 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2450 = (g_list_2emap(v_t_2449, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2450; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2450); r_; });
    }
    case TAG_EMatch: {
      V v_t_2453 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2454 = (g_list_2emap(v_t_2453, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2454; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2454); r_; });
    }
    case TAG_EPrim: {
      V v_t_2456 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2457 = (g_list_2emap(v_t_2456, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2457; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2457); r_; });
    }
    case TAG_EPrimCall: {
      V v_t_2460 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2461 = (g_list_2emap(v_t_2460, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2461; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2461); r_; });
    }
    case TAG_ECall: {
      V v_t_2464 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2465 = (g_list_2emap(v_t_2464, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2465; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2465); r_; });
    }
    case TAG_EInt: {
      V v_t_2467 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2468 = (g_list_2emap(v_t_2467, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2468; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2468); r_; });
    }
    case TAG_EFloat: {
      V v_t_2470 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2471 = (g_list_2emap(v_t_2470, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2471; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2471); r_; });
    }
    case TAG_EStr: {
      V v_t_2473 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2474 = (g_list_2emap(v_t_2473, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2474; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2474); r_; });
    }
    case TAG_EBytes: {
      V v_t_2476 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2477 = (g_list_2emap(v_t_2476, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2477; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2477); r_; });
    }
    case TAG_EFixed: {
      V v_t_2480 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2481 = (g_list_2emap(v_t_2480, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2481; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2481); r_; });
    }
    case TAG_EFloat32: {
      V v_t_2483 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2484 = (g_list_2emap(v_t_2483, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2484; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2484); r_; });
    }
    case TAG_EAbandon: {
      V v_t_2485 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2486 = (g_list_2emap(v_t_2485, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2486; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2486); r_; });
    }
    case TAG_EBool: {
      V v_t_2488 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2489 = (g_list_2emap(v_t_2488, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2489; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2489); r_; });
    }
    case TAG_ESet: {
      V v_t_2493 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2494 = (g_list_2emap(v_t_2493, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2494; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2494); r_; });
    }
    case TAG_EValues: {
      V v_t_2496 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_2497 = (g_list_2emap(v_t_2496, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_2497; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_2497); r_; });
    }
    case TAG_EFix: {
      V v_t_24100 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_24101 = (g_list_2emap(v_t_24100, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_x21_2415, v_args_2416})));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_24101; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_24101); r_; });
    }
    default: return heff_nomatch(v_x21_2415);
    }
  }
  case TAG_ELet: {
    V v_a_24103 = heff_field(v_x2_241, 1);
    V v_b_24104 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_x1_24105 = heff_tr(g_heff_2ecompile_2efuse_2epathCalls(heff_dup(v_me_240), v_a_24103));
    V v_x2_24106 = heff_tr(g_heff_2ecompile_2efuse_2epathCalls(v_me_240, v_b_24104));
    switch (heff_tag_of(v_x1_24105)) {
    case TAG_Nothing: {
      heff_drop(v_x2_24106);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_a_24107 = heff_field(v_x1_24105, 0);
      V v_ru_24x1_24105_24Just = heff_take_reuse_n(v_x1_24105, 1ULL, 1);
      switch (heff_tag_of(v_x2_24106)) {
      case TAG_Nothing: {
        heff_drop(v_a_24107);
        heff_drop_cell(v_ru_24x1_24105_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_b_24108 = heff_field(v_x2_24106, 0);
        heff_take_n(v_x2_24106, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_24105_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_24107, v_b_24108)});
      }
      default: return heff_nomatch(v_x2_24106);
      }
    }
    default: return heff_nomatch(v_x1_24105);
    }
  }
  case TAG_ERecord: {
    V v_fs_24109 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24ERecord = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    V v_ms_24115 = (g_list_2emap_24tok2(v_ru_24x2_241_24ERecord, heff_clo_n(g_heff_2ecompile_2efuse_2epathCalls_lam0, 1, 1, (V[]){v_me_240}), v_fs_24109));
    return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_24115; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_24115); r_; });
  }
  case TAG_EProj: {
    V v_e_24116 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 4);
    V t_0 = v_me_240;
    V t_1 = v_e_24116;
    v_me_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_args_24121 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    V v_t_24123 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
    V v_ms_24124 = (g_list_2emap(v_t_24123, v_args_24121));
    return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_24124; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_24124); r_; });
  }
  case TAG_EMatch: {
    V v_s_24125 = heff_field(v_x2_241, 0);
    V v_arms_24126 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EMatch = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x1_24127 = heff_tr(g_heff_2ecompile_2efuse_2epathCalls(heff_dup(v_me_240), v_s_24125));
    V v_x1_24133 = (g_list_2emap_24tok2(v_ru_24x2_241_24EMatch, heff_clo_n(g_heff_2ecompile_2efuse_2epathCalls_lam1, 1, 1, (V[]){v_me_240}), v_arms_24126));
    switch (heff_tag_of(v_x1_24133)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_x1_24127)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_a_24134 = heff_field(v_x1_24127, 0);
        V v_ru_24x1_24127_24Just = heff_take_reuse_n(v_x1_24127, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_24127_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_24134, MK_INT(0LL))});
      }
      default: return heff_nomatch(v_x1_24127);
      }
    }
    case TAG_Cons: {
      V v_m_24135 = heff_field(v_x1_24133, 0);
      V v_rest_24136 = heff_field(v_x1_24133, 1);
      heff_take_n(v_x1_24133, 3ULL, 2);
      V v_x2_24137 = ({ V a_0 = v_m_24135; V a_1 = v_rest_24136; V r_ = (g_heff_2ecompile_2efuse_2esameGo(a_0, a_1)); heff_drop(v_rest_24136); r_; });
      switch (heff_tag_of(v_x1_24127)) {
      case TAG_Nothing: {
        heff_drop(v_x2_24137);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_a_24138 = heff_field(v_x1_24127, 0);
        V v_ru_24x1_24127_24Just = heff_take_reuse_n(v_x1_24127, 1ULL, 1);
        switch (heff_tag_of(v_x2_24137)) {
        case TAG_Nothing: {
          heff_drop(v_a_24138);
          heff_drop_cell(v_ru_24x1_24127_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_b_24139 = heff_field(v_x2_24137, 0);
          heff_take_n(v_x2_24137, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x1_24127_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_24138, v_b_24139)});
        }
        default: return heff_nomatch(v_x2_24137);
        }
      }
      default: return heff_nomatch(v_x1_24127);
      }
    }
    default: return heff_nomatch(v_x1_24133);
    }
  }
  case TAG_EPrim: {
    V v_ru_24x2_241_24EPrim = heff_take_reuse_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_me_240, 4);
    return heff_tag_at_n(v_ru_24x2_241_24EPrim, TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_EPrimCall: {
    V v_args_24142 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EPrimCall = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_t_24143 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
    V v_ms_24144 = (g_list_2emap_24tok2(v_ru_24x2_241_24EPrimCall, v_t_24143, v_args_24142));
    return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_24144; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_24144); r_; });
  }
  case TAG_ECall: {
    V v_g_24145 = heff_field(v_x2_241, 0);
    V v_args_24146 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_g_24145), heff_dup(heff_rfield(v_me_240, 0)))) {
      heff_drop_cell(v_ru_24x2_241_24ECall, 2);
      return ({ V a_0 = v_me_240; V a_1 = v_g_24145; V a_2 = v_args_24146; V r_ = (g_heff_2ecompile_2efuse_2eselfCalls(a_0, a_1, a_2)); heff_drop(v_g_24145); r_; });
    } else {
      heff_drop(v_g_24145);
      V v_t_24147 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
      V v_ms_24148 = (g_list_2emap_24tok2(v_ru_24x2_241_24ECall, v_t_24147, v_args_24146));
      return ({ V a_0 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_24148; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_24148); r_; });
    }
  }
  case TAG_EInt: {
    V v_ru_24x2_241_24EInt = heff_take_reuse_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_me_240, 4);
    return heff_tag_at_n(v_ru_24x2_241_24EInt, TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_EFloat: {
    V v_ru_24x2_241_24EFloat = heff_take_reuse_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_me_240, 4);
    return heff_tag_at_n(v_ru_24x2_241_24EFloat, TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_EStr: {
    V v_ru_24x2_241_24EStr = heff_take_reuse_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_me_240, 4);
    return heff_tag_at_n(v_ru_24x2_241_24EStr, TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_EBytes: {
    V v_ru_24x2_241_24EBytes = heff_take_reuse_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_me_240, 4);
    return heff_tag_at_n(v_ru_24x2_241_24EBytes, TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_me_240, 4);
    return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_EFloat32: {
    V v_ru_24x2_241_24EFloat32 = heff_take_reuse_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_me_240, 4);
    return heff_tag_at_n(v_ru_24x2_241_24EFloat32, TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_me_240, 4);
    return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_EBool: {
    V v_c_24156 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24157 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
    return ({ V a_0 = v_t_24157; V a_1 = v_c_24156; V r_ = (g_heff_2ecompile_2efuse_2econdCalls(a_0, a_1)); heff_drop(v_c_24156); r_; });
  }
  case TAG_ESet: {
    V v_a_24159 = heff_field(v_x2_241, 1);
    V v_b_24160 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_x1_24161 = heff_tr(g_heff_2ecompile_2efuse_2epathCalls(heff_dup(v_me_240), v_a_24159));
    V v_x2_24162 = heff_tr(g_heff_2ecompile_2efuse_2epathCalls(v_me_240, v_b_24160));
    switch (heff_tag_of(v_x1_24161)) {
    case TAG_Nothing: {
      heff_drop(v_x2_24162);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_a_24163 = heff_field(v_x1_24161, 0);
      V v_ru_24x1_24161_24Just = heff_take_reuse_n(v_x1_24161, 1ULL, 1);
      switch (heff_tag_of(v_x2_24162)) {
      case TAG_Nothing: {
        heff_drop(v_a_24163);
        heff_drop_cell(v_ru_24x1_24161_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_b_24164 = heff_field(v_x2_24162, 0);
        heff_take_n(v_x2_24162, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_24161_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_24163, v_b_24164)});
      }
      default: return heff_nomatch(v_x2_24162);
      }
    }
    default: return heff_nomatch(v_x1_24161);
    }
  }
  case TAG_EValues: {
    V v_es_24165 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EValues = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_24166 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2epathCalls_clo), 1, (V[]){v_me_240}));
    V v_ms_24167 = (g_list_2emap(v_t_24166, v_es_24165));
    return ({ V a_0 = heff_tag_at_n(v_ru_24x2_241_24EValues, TAG_Just, 1, (V[]){MK_INT(0LL)}); V a_1 = v_ms_24167; V r_ = (g_list_2efoldl_24s455728131x407835966(a_0, a_1)); heff_drop(v_ms_24167); r_; });
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_me_240, 4);
    return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2epathCalls_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2epathCalls(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2epathCalls_lam0(V self, V *args) {
  V v_p_24111 = args[0];
  V v_me_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24114;
  switch (heff_tag_of(v_p_24111)) {
  case TAG_MkPair: {
    V v_y_24113 = heff_field(v_p_24111, 1);
    heff_take_n(v_p_24111, 2ULL, 2);
    v_t_24114 = v_y_24113;
    break;
  }
  default: heff_nomatch(v_p_24111);
  }
  return (g_heff_2ecompile_2efuse_2epathCalls(v_me_240, v_t_24114));
}
V g_heff_2ecompile_2efuse_2epathCalls_lam1(V self, V *args) {
  V v_a_24128 = args[0];
  V v_me_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24132;
  switch (heff_tag_of(v_a_24128)) {
  case TAG_MkArm: {
    V v_b_24131 = heff_field(v_a_24128, 2);
    heff_take_n(v_a_24128, 4ULL, 3);
    v_t_24132 = v_b_24131;
    break;
  }
  default: heff_nomatch(v_a_24128);
  }
  return (g_heff_2ecompile_2efuse_2epathCalls(v_me_240, v_t_24132));
}
V g_heff_2ecompile_2efuse_2efixedGo_lam0(V self, V *args);
Clo g_heff_2ecompile_2efuse_2efixedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efixedGo_entry, 3, 0};

V g_heff_2ecompile_2efuse_2efixedGo(V v_calls_240, V v_k_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_248 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2efuse_2efixedGo_lam0, 1, 2, (V[]){v_x_243, heff_dup(v_k_241)}), v_calls_240));
    V v_cell_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_heff_2ecompile_2efuse_2efixedGo_24dps(v_calls_240, heff_box_word((heff_unbox_word(v_k_241) + ((int64_t)1ULL))), v_xs_244, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2efixedGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efuse_2efixedGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2efuse_2efixedGo_lam0(V self, V *args) {
  V v_es_245 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eisVar_clo), 1, (V[]){v_x_243}));
  V v_t_247 = (g_heff_2ecompile_2efuse_2enthF(v_k_241, v_es_245));
  return ({ V a_0 = NTAG(TAG_False); V a_1 = v_t_246; V a_2 = v_t_247; V r_ = (g_prelude_2emaybe(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
}
V g_heff_2ecompile_2efuse_2efixedGo_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2efuse_2efixedGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efixedGo_24dps_entry, 4, 0};

V g_heff_2ecompile_2efuse_2efixedGo_24dps(V v_calls_240, V v_k_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_xs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_249 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2efuse_2efixedGo_24dps_lam0, 1, 2, (V[]){v_x_244, heff_dup(v_k_241)}), v_calls_240));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_calls_240;
    V t_1 = heff_intAdd(v_k_241, MK_INT(1LL));
    V t_2 = v_xs_245;
    V t_3 = v_cell_2410;
    v_calls_240 = t_0;
    v_k_241 = t_1;
    v_x3_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2efixedGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efuse_2efixedGo_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2efuse_2efixedGo_24dps_lam0(V self, V *args) {
  V v_es_246 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eisVar_clo), 1, (V[]){v_x_244}));
  V v_t_248 = (g_heff_2ecompile_2efuse_2enthF(v_k_241, v_es_246));
  return ({ V a_0 = NTAG(TAG_False); V a_1 = v_t_247; V a_2 = v_t_248; V r_ = (g_prelude_2emaybe(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
}
Clo g_heff_2ecompile_2efuse_2egoesOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2egoesOf_24dps_entry, 2, 0};

V g_heff_2ecompile_2efuse_2egoesOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x11_242, 0);
      V v_x112_245 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      switch (heff_tag_of(v_x112_245)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_244);
        V t_0 = v_rest_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_Just: {
        V v_x1121_246 = heff_field(v_x112_245, 0);
        heff_take_n(v_x112_245, 1ULL, 1);
        if ((heff_dup(v_x1121_246) == NTAG(TAG_True))) {
          heff_drop(v_x1121_246);
          V v_t_2410;
          switch (heff_tag_of(v_a_244)) {
          case TAG_MkArm: {
            V v_t_247 = heff_field(v_a_244, 0);
            heff_take_n(v_a_244, 1ULL, 3);
            v_t_2410 = v_t_247;
            break;
          }
          default: heff_nomatch(v_a_244);
          }
          V v_cell_2411 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
          V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
          heff_drop(v_u_2412);
          V t_0 = v_rest_243;
          V t_1 = v_cell_2411;
          v_x1_240 = t_0;
          v_d_241 = t_1;
          goto top;
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_a_244);
          heff_drop(v_x1121_246);
          V t_0 = v_rest_243;
          V t_1 = v_d_241;
          v_x1_240 = t_0;
          v_d_241 = t_1;
          goto top;
        }
      }
      default: return heff_nomatch(v_x112_245);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuse_2egoesOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2egoesOf_24dps(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2efuse_2econsumerOf_24cpr(V v_key_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    V v_ps_244 = heff_field(v_x2_241, 0);
    V v_x22_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_245)) {
    case TAG_EVar: {
      heff_take_n(v_x22_245, 0ULL, 1);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EGlobal: {
      heff_take_n(v_x22_245, 0ULL, 1);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      heff_take_n(v_x22_245, 0ULL, 2);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_take_n(v_x22_245, 0ULL, 2);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_take_n(v_x22_245, 0ULL, 3);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_take_n(v_x22_245, 0ULL, 2);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_take_n(v_x22_245, 0ULL, 4);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_take_n(v_x22_245, 0ULL, 3);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      V v_x221_2424 = heff_field(v_x22_245, 0);
      V v_arms_2425 = heff_field(v_x22_245, 1);
      heff_take_n(v_x22_245, 3ULL, 2);
      switch (heff_tag_of(v_x221_2424)) {
      case TAG_EVar: {
        V v_l_2426 = heff_field(v_x221_2424, 0);
        heff_take_n(v_x221_2424, 1ULL, 1);
        HeffT2 v_t_2427 = (g_heff_2ecompile_2efuse_2eposF_24cpr(v_l_2426, heff_dup(v_ps_244), MK_INT(0LL)));
        {
          V v_field_2429 = v_t_2427.f[1];
          int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
          if ((v_tag_2428 == ((int64_t)0ULL))) {
            V v_at_2430 = v_field_2429;
            V v_t_2431 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ps_244));
            V v_t_2432 = ({ V a_0 = heff_dup(v_key_240); V a_1 = v_t_2431; V a_2 = heff_dup(v_at_2430); V a_3 = v_l_2426; V a_4 = heff_dup(v_arms_2425); V r_ = (g_list_2emap_24s866308031x234213482(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_l_2426); r_; });
            return (g_heff_2ecompile_2efuse_2econsumerWith_24cpr(v_key_240, v_ps_244, v_at_2430, v_arms_2425, v_t_2432));
          } else {
            heff_drop(v_key_240);
            heff_drop(v_ps_244);
            heff_drop(v_arms_2425);
            heff_drop(v_l_2426);
            heff_drop(v_field_2429);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      case TAG_EGlobal: {
        heff_take_n(v_x221_2424, 0ULL, 1);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELam: {
        heff_take_n(v_x221_2424, 0ULL, 2);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EApp: {
        heff_take_n(v_x221_2424, 0ULL, 2);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELet: {
        heff_take_n(v_x221_2424, 0ULL, 3);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ERecord: {
        heff_take_n(v_x221_2424, 0ULL, 2);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EProj: {
        heff_take_n(v_x221_2424, 0ULL, 4);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ETag: {
        heff_take_n(v_x221_2424, 0ULL, 3);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EMatch: {
        heff_take_n(v_x221_2424, 0ULL, 2);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EPrim: {
        heff_take_n(v_x221_2424, 0ULL, 1);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x221_2424, 0ULL, 2);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ECall: {
        heff_take_n(v_x221_2424, 0ULL, 2);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EInt: {
        heff_take_n(v_x221_2424, 0ULL, 1);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFloat: {
        heff_take_na(v_x221_2424, 0ULL, 1);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EStr: {
        heff_take_n(v_x221_2424, 0ULL, 1);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EBytes: {
        heff_take_n(v_x221_2424, 0ULL, 1);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFixed: {
        heff_take_n(v_x221_2424, 0ULL, 2);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFloat32: {
        heff_take_na(v_x221_2424, 0ULL, 1);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EAbandon: {
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EBool: {
        heff_take_n(v_x221_2424, 0ULL, 1);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESet: {
        heff_take_n(v_x221_2424, 0ULL, 3);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EValues: {
        heff_take_n(v_x221_2424, 0ULL, 1);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFix: {
        heff_take_n(v_x221_2424, 0ULL, 2);
        heff_drop(v_key_240);
        heff_drop(v_ps_244);
        heff_drop(v_arms_2425);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x221_2424)}});
      }
    }
    case TAG_EPrim: {
      heff_take_n(v_x22_245, 0ULL, 1);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x22_245, 0ULL, 2);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_take_n(v_x22_245, 0ULL, 2);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      heff_take_n(v_x22_245, 0ULL, 1);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      heff_take_na(v_x22_245, 0ULL, 1);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      heff_take_n(v_x22_245, 0ULL, 1);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      heff_take_n(v_x22_245, 0ULL, 1);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_take_n(v_x22_245, 0ULL, 2);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_take_na(v_x22_245, 0ULL, 1);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      heff_take_n(v_x22_245, 0ULL, 1);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      heff_take_n(v_x22_245, 0ULL, 3);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      heff_take_n(v_x22_245, 0ULL, 1);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_take_n(v_x22_245, 0ULL, 2);
      heff_drop(v_key_240);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x22_245)}});
    }
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2efuse_2econsRec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2econsRec_entry, 3, 0};

V g_heff_2ecompile_2efuse_2econsRec(V v_key_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_args_2419 = heff_field(v_x3_242, 1);
    HeffT2 v_t_2421 = (g_heff_2ecompile_2efuse_2elastF_24cpr(heff_dup(v_args_2419)));
    {
      V v_field_2423 = v_t_2421.f[1];
      int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
      if ((v_tag_2422 == ((int64_t)0ULL))) {
        V v_l_2424 = v_field_2423;
        HeffT2 v_t_2425 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(v_key_240, v_n_241, v_l_2424));
        {
          V v_field_2427 = v_t_2425.f[1];
          int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
          V v_ret_24bool = heff_bool(((v_tag_2426 == ((int64_t)0ULL)) && ({ V v_x11_2428 = heff_dup(v_field_2427); int c_ = 1; heff_drop(v_x11_2428); c_; })));
          heff_drop(v_field_2427);
          return v_ret_24bool;
        }
      } else {
        heff_drop(v_n_241);
        heff_drop(v_field_2423);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EMatch: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2econsRec_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2efuse_2econsRec(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ecompile_2efuse_2erecallAt_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2erecallAt_lam1(V self, V *args);
Clo g_heff_2ecompile_2efuse_2erecallAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2erecallAt_entry, 3, 0};

V g_heff_2ecompile_2efuse_2erecallAt(V v_fu_240, V v_h_241, V v_args_242) {
top: ;
  V v_p_243 = heff_take_field(v_fu_240, 5);
  V v_parity_244 = heff_take_field(v_fu_240, 6);
  V v_cp_245 = heff_take_field(v_fu_240, 7);
  V v_at_246 = heff_take_field(v_fu_240, 2);
  V v_c_247 = heff_get_n(v_fu_240, 0, 9);
  HeffT2 v_t_248 = ({ V a_0 = v_p_243; V a_1 = v_parity_244; V a_2 = heff_dup(v_h_241); HeffT2 r_ = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(a_0, a_1, a_2)); heff_drop(v_p_243); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      heff_drop(v_h_241);
      heff_drop(v_c_247);
      V v_bs_2411 = v_field_2410;
      return heff_clo_n(g_heff_2ecompile_2efuse_2erecallAt_lam0, 1, 4, (V[]){v_bs_2411, v_at_246, v_args_242, v_cp_245});
    } else {
      heff_drop(v_cp_245);
      heff_drop(v_field_2410);
      return heff_clo_n(g_heff_2ecompile_2efuse_2erecallAt_lam1, 1, 4, (V[]){v_h_241, v_at_246, v_args_242, v_c_247});
    }
  }
}
V g_heff_2ecompile_2efuse_2erecallAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2erecallAt(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2efuse_2erecallAt_lam0(V self, V *args) {
  V v_s_2412 = args[0];
  V v_bs_2411 = heff_env(self)[0];
  V v_at_246 = heff_env(self)[1];
  V v_args_242 = heff_env(self)[2];
  V v_cp_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2413 = (g_prelude_2etraverse_24s801310267x475583082_24cpr(v_bs_2411, v_s_2412));
  {
    V v_field_2414 = v_t_2413.f[0];
    V v_field_2415 = v_t_2413.f[1];
    V v_x_2416 = v_field_2414;
    V v_s_2417 = v_field_2415;
    V v_t_2418 = (g_prelude_2e_2b_2b_24f677743828x1026746250(v_x_2416, v_at_246, v_args_242));
    V v_x_2419 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_cp_245}), v_t_2418});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_s_2417});
  }
}
V g_heff_2ecompile_2efuse_2erecallAt_lam1(V self, V *args) {
  V v_s_2420 = args[0];
  V v_h_241 = heff_env(self)[0];
  V v_at_246 = heff_env(self)[1];
  V v_args_242 = heff_env(self)[2];
  V v_c_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_supply_2421 = heff_take_field(v_s_2420, 0);
  V v_consumers_2422 = heff_take_field(v_s_2420, 1);
  V v_producers_2423 = heff_take_field(v_s_2420, 2);
  V v_made_2424 = heff_take_field(v_s_2420, 3);
  V v_fresh_2425 = heff_take_field(v_s_2420, 4);
  V v_left_2426 = heff_get_n(v_s_2420, 5, 6);
  HeffT2 v_t_2427 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2emap_2eempty_get()), v_supply_2421, v_h_241));
  {
    V v_field_2428 = v_t_2427.f[0];
    V v_field_2429 = v_t_2427.f[1];
    V v_e_2430 = v_field_2428;
    V v_n_2431 = v_field_2429;
    V v_t_2432 = (g_heff_2ecompile_2efuse_2esetAt(v_at_246, v_e_2430, v_args_242));
    V v_x_2433 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_c_247}), v_t_2432});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2433, heff_rec_n(6, shape_supply__consumers__producers__made__fresh__left, (V[]){v_n_2431, v_consumers_2422, v_producers_2423, v_made_2424, v_fresh_2425, v_left_2426})});
  }
}
V g_heff_2ecompile_2efuse_2erecall_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2erecall_lam1(V self, V *args);
Clo g_heff_2ecompile_2efuse_2erecall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2erecall_entry, 4, 0};

V g_heff_2ecompile_2efuse_2erecall(V v_fu_240, V v_r_241, V v_h_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    V v_t_245 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_245, v_e_243));
  }
  case TAG_EGlobal: {
    V v_t_247 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_247, v_e_243));
  }
  case TAG_ELam: {
    V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2410, v_e_243));
  }
  case TAG_EApp: {
    V v_e1_2411 = heff_dup(heff_field(v_e_243, 0));
    switch (heff_tag_of(v_e1_2411)) {
    case TAG_EVar: {
      heff_take_n(v_e1_2411, 0ULL, 1);
      V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2414, v_e_243));
    }
    case TAG_EGlobal: {
      V v_g_2415 = heff_field(v_e1_2411, 0);
      heff_take_n(v_e1_2411, 1ULL, 1);
      switch (heff_tag_of(v_e_243)) {
      case TAG_EApp: {
        V v_args_2417 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 2ULL, 2);
        V v_t_2421;
        if (heff_strEq_c(heff_dup(v_g_2415), heff_dup(heff_rfield(v_fu_240, 0)))) {
          V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2417));
          if (heff_intEq_c(v_t_2418, heff_dup(heff_rfield(v_fu_240, 1)))) {
            V v_t_2419 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eisVar_clo), 1, (V[]){heff_dup(v_r_241)}));
            V v_t_2420 = (g_heff_2ecompile_2efuse_2enthF(heff_dup(heff_rfield(v_fu_240, 2)), heff_dup(v_args_2417)));
            v_t_2421 = ({ V a_0 = NTAG(TAG_False); V a_1 = v_t_2419; V a_2 = v_t_2420; V r_ = heff_tr(g_prelude_2emaybe(a_0, a_1, a_2)); heff_drop(v_t_2420); r_; });
          } else {
            v_t_2421 = NTAG(TAG_False);
          }
        } else {
          v_t_2421 = NTAG(TAG_False);
        }
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_r_241);
          heff_drop(v_g_2415);
          heff_drop(v_t_2421);
          return (g_heff_2ecompile_2efuse_2erecallAt(v_fu_240, v_h_242, v_args_2417));
        } else {
          heff_drop(v_t_2421);
          V v_t_2422 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
          V v_m_2423 = (g_prelude_2etraverse_24s545943161x1483966866(v_t_2422, v_args_2417));
          return heff_clo_n(g_heff_2ecompile_2efuse_2erecall_lam0, 1, 2, (V[]){v_m_2423, v_g_2415});
        }
      }
      default: return heff_nomatch(v_e_243);
      }
    }
    case TAG_ELam: {
      heff_take_n(v_e1_2411, 0ULL, 2);
      V v_t_2431 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2431, v_e_243));
    }
    case TAG_EApp: {
      heff_take_n(v_e1_2411, 0ULL, 2);
      V v_t_2434 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2434, v_e_243));
    }
    case TAG_ELet: {
      heff_take_n(v_e1_2411, 0ULL, 3);
      V v_t_2438 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2438, v_e_243));
    }
    case TAG_ERecord: {
      heff_take_n(v_e1_2411, 0ULL, 2);
      V v_t_2441 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2441, v_e_243));
    }
    case TAG_EProj: {
      heff_take_n(v_e1_2411, 0ULL, 4);
      V v_t_2446 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2446, v_e_243));
    }
    case TAG_ETag: {
      heff_take_n(v_e1_2411, 0ULL, 3);
      V v_t_2450 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2450, v_e_243));
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_2411, 0ULL, 2);
      V v_t_2453 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2453, v_e_243));
    }
    case TAG_EPrim: {
      heff_take_n(v_e1_2411, 0ULL, 1);
      V v_t_2455 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2455, v_e_243));
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e1_2411, 0ULL, 2);
      V v_t_2458 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2458, v_e_243));
    }
    case TAG_ECall: {
      heff_take_n(v_e1_2411, 0ULL, 2);
      V v_t_2461 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2461, v_e_243));
    }
    case TAG_EInt: {
      heff_take_n(v_e1_2411, 0ULL, 1);
      V v_t_2463 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2463, v_e_243));
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_2411, 0ULL, 1);
      V v_t_2465 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2465, v_e_243));
    }
    case TAG_EStr: {
      heff_take_n(v_e1_2411, 0ULL, 1);
      V v_t_2467 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2467, v_e_243));
    }
    case TAG_EBytes: {
      heff_take_n(v_e1_2411, 0ULL, 1);
      V v_t_2469 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2469, v_e_243));
    }
    case TAG_EFixed: {
      heff_take_n(v_e1_2411, 0ULL, 2);
      V v_t_2472 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2472, v_e_243));
    }
    case TAG_EFloat32: {
      heff_take_na(v_e1_2411, 0ULL, 1);
      V v_t_2474 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2474, v_e_243));
    }
    case TAG_EAbandon: {
      V v_t_2475 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2475, v_e_243));
    }
    case TAG_EBool: {
      heff_take_n(v_e1_2411, 0ULL, 1);
      V v_t_2477 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2477, v_e_243));
    }
    case TAG_ESet: {
      heff_take_n(v_e1_2411, 0ULL, 3);
      V v_t_2481 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2481, v_e_243));
    }
    case TAG_EValues: {
      heff_take_n(v_e1_2411, 0ULL, 1);
      V v_t_2483 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2483, v_e_243));
    }
    case TAG_EFix: {
      heff_take_n(v_e1_2411, 0ULL, 2);
      V v_t_2486 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2486, v_e_243));
    }
    default: return heff_nomatch(v_e1_2411);
    }
  }
  case TAG_ELet: {
    V v_t_2490 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2490, v_e_243));
  }
  case TAG_ERecord: {
    V v_t_2493 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2493, v_e_243));
  }
  case TAG_EProj: {
    V v_t_2498 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_2498, v_e_243));
  }
  case TAG_ETag: {
    V v_t_24102 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24102, v_e_243));
  }
  case TAG_EMatch: {
    V v_t_24105 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24105, v_e_243));
  }
  case TAG_EPrim: {
    V v_t_24107 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24107, v_e_243));
  }
  case TAG_EPrimCall: {
    V v_t_24110 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24110, v_e_243));
  }
  case TAG_ECall: {
    V v_g_24111 = heff_field(v_e_243, 0);
    V v_args_24112 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    V v_t_24116;
    if (heff_strEq_c(heff_dup(v_g_24111), heff_dup(heff_rfield(v_fu_240, 0)))) {
      V v_t_24113 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_24112));
      if (heff_intEq_c(v_t_24113, heff_dup(heff_rfield(v_fu_240, 1)))) {
        V v_t_24114 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eisVar_clo), 1, (V[]){heff_dup(v_r_241)}));
        V v_t_24115 = (g_heff_2ecompile_2efuse_2enthF(heff_dup(heff_rfield(v_fu_240, 2)), heff_dup(v_args_24112)));
        v_t_24116 = ({ V a_0 = NTAG(TAG_False); V a_1 = v_t_24114; V a_2 = v_t_24115; V r_ = heff_tr(g_prelude_2emaybe(a_0, a_1, a_2)); heff_drop(v_t_24115); r_; });
      } else {
        v_t_24116 = NTAG(TAG_False);
      }
    } else {
      v_t_24116 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_24116) == NTAG(TAG_True))) {
      heff_drop(v_r_241);
      heff_drop(v_g_24111);
      heff_drop(v_t_24116);
      return (g_heff_2ecompile_2efuse_2erecallAt(v_fu_240, v_h_242, v_args_24112));
    } else {
      heff_drop(v_t_24116);
      V v_t_24117 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
      V v_m_24118 = (g_prelude_2etraverse_24s545943161x1483966866(v_t_24117, v_args_24112));
      return heff_clo_n(g_heff_2ecompile_2efuse_2erecall_lam1, 1, 2, (V[]){v_m_24118, v_g_24111});
    }
  }
  case TAG_EInt: {
    V v_t_24124 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24124, v_e_243));
  }
  case TAG_EFloat: {
    V v_t_24126 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24126, v_e_243));
  }
  case TAG_EStr: {
    V v_t_24128 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24128, v_e_243));
  }
  case TAG_EBytes: {
    V v_t_24130 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24130, v_e_243));
  }
  case TAG_EFixed: {
    V v_t_24133 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24133, v_e_243));
  }
  case TAG_EFloat32: {
    V v_t_24135 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24135, v_e_243));
  }
  case TAG_EAbandon: {
    V v_t_24136 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24136, v_e_243));
  }
  case TAG_EBool: {
    V v_t_24138 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24138, v_e_243));
  }
  case TAG_ESet: {
    V v_t_24142 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24142, v_e_243));
  }
  case TAG_EValues: {
    V v_t_24144 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24144, v_e_243));
  }
  case TAG_EFix: {
    V v_t_24147 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2erecall_clo), 3, (V[]){v_fu_240, v_r_241, v_h_242}));
    return (g_heff_2ecompile_2efuse_2ekidsF(v_t_24147, v_e_243));
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2efuse_2erecall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2erecall(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2efuse_2erecall_lam0(V self, V *args) {
  V v_s_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  V v_g_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_s_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    V v_t_2428 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2415}), v_x_2426});
    return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){v_t_2428, v_s_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2efuse_2erecall_lam1(V self, V *args) {
  V v_s_24119 = args[0];
  V v_m_24118 = heff_env(self)[0];
  V v_g_24111 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24120 = heff_tr(heff_call(v_m_24118, 1, (V[]){v_s_24119}));
  switch (heff_tag_of(v_x2_24120)) {
  case TAG_MkPair: {
    V v_x_24121 = heff_field(v_x2_24120, 0);
    V v_s_24122 = heff_field(v_x2_24120, 1);
    V v_ru_24x2_24120_24MkPair = heff_take_reuse_n(v_x2_24120, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24120_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24111, v_x_24121}), v_s_24122});
  }
  default: return heff_nomatch(v_x2_24120);
  }
}
V g_heff_2ecompile_2efuse_2etagEnd_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2etagEnd_lam1(V self, V *args);
Clo g_heff_2ecompile_2efuse_2etagEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2etagEnd_entry, 4, 0};

V g_heff_2ecompile_2efuse_2etagEnd(V v_fu_240, V v_t_241, V v_hs_242, V v_ts_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2efuse_2efindArm_24cpr(v_t_241, heff_dup(heff_rfield(v_fu_240, 3))));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_a_247 = v_field_246;
      return heff_clo_n(g_heff_2ecompile_2efuse_2etagEnd_lam0, 1, 5, (V[]){v_a_247, v_fu_240, v_t_241, v_hs_242, v_ts_243});
    } else {
      heff_drop(v_field_246);
      V v_t_2417 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_2418 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
      V v_x_2419 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2417, v_t_2418});
      return heff_clo_n(g_heff_2ecompile_2efuse_2etagEnd_lam1, 1, 1, (V[]){v_x_2419});
    }
  }
}
V g_heff_2ecompile_2efuse_2etagEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2etagEnd(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2efuse_2etagEnd_lam0(V self, V *args) {
  V v_p_248 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_fu_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_hs_242 = heff_env(self)[3];
  V v_ts_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_a_247)) {
  case TAG_MkArm: {
    V v_vs_2410 = heff_field(v_a_247, 1);
    V v_b_2411 = heff_field(v_a_247, 2);
    heff_take_n(v_a_247, 6ULL, 3);
    HeffT2 v_t_2412 = (g_heff_2ecompile_2efuse_2efreshF_24cpr(heff_tag_n(TAG_ELam, 2, (V[]){v_vs_2410, v_b_2411}), v_p_248));
    {
      V v_field_2413 = v_t_2412.f[0];
      V v_field_2414 = v_t_2412.f[1];
      V v_x_2415 = v_field_2413;
      V v_s_2416 = v_field_2414;
      return (g_heff_2ecompile_2efuse_2earmGiven(v_fu_240, v_t_241, v_hs_242, v_ts_243, v_x_2415, v_s_2416));
    }
  }
  default: return heff_nomatch(v_a_247);
  }
}
V g_heff_2ecompile_2efuse_2etagEnd_lam1(V self, V *args) {
  V v_s_2420 = args[0];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_s_2420});
}
V g_heff_2ecompile_2efuse_2eendAt_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam1(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam2(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam3(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam4(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam5(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam6(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam7(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam8(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam9(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam10(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam11(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam12(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam13(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam14(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam15(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam16(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam17(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam18(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam19(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam20(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam21(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam22(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam23(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam24(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam25(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam26(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam27(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam28(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam29(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam30(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam31(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam32(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam33(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam34(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam35(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam36(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam37(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam38(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam39(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam40(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam41(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam42(V self, V *args);
V g_heff_2ecompile_2efuse_2eendAt_lam43(V self, V *args);
Clo g_heff_2ecompile_2efuse_2eendAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eendAt_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eendAt(V v_fu_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    HeffT2 v_t_243 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 1);
        V v_bs_246 = v_field_245;
        V v_t_247 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_248 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_246));
        V v_x_249 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_247, v_t_248});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam0, 1, 1, (V[]){v_x_249});
      } else {
        heff_drop(v_field_245);
        V v_t_2411 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_2412 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_2413 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2411, v_t_2412});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam1, 1, 1, (V[]){v_x_2413});
      }
    }
  }
  case TAG_EGlobal: {
    HeffT2 v_t_2416 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 1);
        V v_bs_2419 = v_field_2418;
        V v_t_2420 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_2421 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_2419));
        V v_x_2422 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2420, v_t_2421});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam2, 1, 1, (V[]){v_x_2422});
      } else {
        heff_drop(v_field_2418);
        V v_t_2424 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_2425 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_2426 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2424, v_t_2425});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam3, 1, 1, (V[]){v_x_2426});
      }
    }
  }
  case TAG_ELam: {
    HeffT2 v_t_2430 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_2432 = v_t_2430.f[1];
      int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
      if ((v_tag_2431 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 2);
        V v_bs_2433 = v_field_2432;
        V v_t_2434 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_2435 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_2433));
        V v_x_2436 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2434, v_t_2435});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam4, 1, 1, (V[]){v_x_2436});
      } else {
        heff_drop(v_field_2432);
        V v_t_2438 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_2439 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_2440 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2438, v_t_2439});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam5, 1, 1, (V[]){v_x_2440});
      }
    }
  }
  case TAG_EApp: {
    HeffT2 v_t_2444 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_2446 = v_t_2444.f[1];
      int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
      if ((v_tag_2445 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 2);
        V v_bs_2447 = v_field_2446;
        V v_t_2448 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_2449 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_2447));
        V v_x_2450 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2448, v_t_2449});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam6, 1, 1, (V[]){v_x_2450});
      } else {
        heff_drop(v_field_2446);
        V v_t_2452 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_2453 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_2454 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2452, v_t_2453});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam7, 1, 1, (V[]){v_x_2454});
      }
    }
  }
  case TAG_ELet: {
    HeffT2 v_t_2459 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_2461 = v_t_2459.f[1];
      int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
      if ((v_tag_2460 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 3);
        V v_bs_2462 = v_field_2461;
        V v_t_2463 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_2464 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_2462));
        V v_x_2465 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2463, v_t_2464});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam8, 1, 1, (V[]){v_x_2465});
      } else {
        heff_drop(v_field_2461);
        V v_t_2467 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_2468 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_2469 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2467, v_t_2468});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam9, 1, 1, (V[]){v_x_2469});
      }
    }
  }
  case TAG_ERecord: {
    HeffT2 v_t_2473 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_2475 = v_t_2473.f[1];
      int64_t v_tag_2474 = ((int64_t)v_t_2473.f[0]);
      if ((v_tag_2474 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 2);
        V v_bs_2476 = v_field_2475;
        V v_t_2477 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_2478 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_2476));
        V v_x_2479 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2477, v_t_2478});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam10, 1, 1, (V[]){v_x_2479});
      } else {
        heff_drop(v_field_2475);
        V v_t_2481 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_2482 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_2483 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2481, v_t_2482});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam11, 1, 1, (V[]){v_x_2483});
      }
    }
  }
  case TAG_EProj: {
    HeffT2 v_t_2489 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_2491 = v_t_2489.f[1];
      int64_t v_tag_2490 = ((int64_t)v_t_2489.f[0]);
      if ((v_tag_2490 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 4);
        V v_bs_2492 = v_field_2491;
        V v_t_2493 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_2494 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_2492));
        V v_x_2495 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2493, v_t_2494});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam12, 1, 1, (V[]){v_x_2495});
      } else {
        heff_drop(v_field_2491);
        V v_t_2497 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_2498 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_2499 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2497, v_t_2498});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam13, 1, 1, (V[]){v_x_2499});
      }
    }
  }
  case TAG_ETag: {
    V v_t_24101 = heff_field(v_e_241, 0);
    V v_hs_24102 = heff_field(v_e_241, 1);
    V v_ts_24103 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ETag = heff_take_reuse_n(v_e_241, 7ULL, 3);
    return (g_heff_2ecompile_2efuse_2etagEnd_24tok3(v_ru_24e_241_24ETag, v_fu_240, v_t_24101, v_hs_24102, v_ts_24103));
  }
  case TAG_EMatch: {
    HeffT2 v_t_24106 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_24108 = v_t_24106.f[1];
      int64_t v_tag_24107 = ((int64_t)v_t_24106.f[0]);
      if ((v_tag_24107 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 2);
        V v_bs_24109 = v_field_24108;
        V v_t_24110 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_24111 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24109));
        V v_x_24112 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24110, v_t_24111});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam14, 1, 1, (V[]){v_x_24112});
      } else {
        heff_drop(v_field_24108);
        V v_t_24114 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_24115 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_24116 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24114, v_t_24115});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam15, 1, 1, (V[]){v_x_24116});
      }
    }
  }
  case TAG_EPrim: {
    HeffT2 v_t_24119 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_24121 = v_t_24119.f[1];
      int64_t v_tag_24120 = ((int64_t)v_t_24119.f[0]);
      if ((v_tag_24120 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 1);
        V v_bs_24122 = v_field_24121;
        V v_t_24123 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_24124 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24122));
        V v_x_24125 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24123, v_t_24124});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam16, 1, 1, (V[]){v_x_24125});
      } else {
        heff_drop(v_field_24121);
        V v_t_24127 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_24128 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_24129 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24127, v_t_24128});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam17, 1, 1, (V[]){v_x_24129});
      }
    }
  }
  case TAG_EPrimCall: {
    HeffT2 v_t_24133 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_24135 = v_t_24133.f[1];
      int64_t v_tag_24134 = ((int64_t)v_t_24133.f[0]);
      if ((v_tag_24134 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 2);
        V v_bs_24136 = v_field_24135;
        V v_t_24137 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_24138 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24136));
        V v_x_24139 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24137, v_t_24138});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam18, 1, 1, (V[]){v_x_24139});
      } else {
        heff_drop(v_field_24135);
        V v_t_24141 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_24142 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_24143 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24141, v_t_24142});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam19, 1, 1, (V[]){v_x_24143});
      }
    }
  }
  case TAG_ECall: {
    HeffT2 v_t_24147 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_24149 = v_t_24147.f[1];
      int64_t v_tag_24148 = ((int64_t)v_t_24147.f[0]);
      if ((v_tag_24148 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 2);
        V v_bs_24150 = v_field_24149;
        V v_t_24151 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_24152 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24150));
        V v_x_24153 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24151, v_t_24152});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam20, 1, 1, (V[]){v_x_24153});
      } else {
        heff_drop(v_field_24149);
        V v_t_24155 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_24156 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_24157 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24155, v_t_24156});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam21, 1, 1, (V[]){v_x_24157});
      }
    }
  }
  case TAG_EInt: {
    HeffT2 v_t_24160 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_24162 = v_t_24160.f[1];
      int64_t v_tag_24161 = ((int64_t)v_t_24160.f[0]);
      if ((v_tag_24161 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 1);
        V v_bs_24163 = v_field_24162;
        V v_t_24164 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_24165 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24163));
        V v_x_24166 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24164, v_t_24165});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam22, 1, 1, (V[]){v_x_24166});
      } else {
        heff_drop(v_field_24162);
        V v_t_24168 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_24169 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_24170 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24168, v_t_24169});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam23, 1, 1, (V[]){v_x_24170});
      }
    }
  }
  case TAG_EFloat: {
    HeffT2 v_t_24173 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_24175 = v_t_24173.f[1];
      int64_t v_tag_24174 = ((int64_t)v_t_24173.f[0]);
      if ((v_tag_24174 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 1);
        V v_bs_24176 = v_field_24175;
        V v_t_24177 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_24178 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24176));
        V v_x_24179 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24177, v_t_24178});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam24, 1, 1, (V[]){v_x_24179});
      } else {
        heff_drop(v_field_24175);
        V v_t_24181 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_24182 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_24183 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24181, v_t_24182});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam25, 1, 1, (V[]){v_x_24183});
      }
    }
  }
  case TAG_EStr: {
    HeffT2 v_t_24186 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_24188 = v_t_24186.f[1];
      int64_t v_tag_24187 = ((int64_t)v_t_24186.f[0]);
      if ((v_tag_24187 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 1);
        V v_bs_24189 = v_field_24188;
        V v_t_24190 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_24191 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24189));
        V v_x_24192 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24190, v_t_24191});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam26, 1, 1, (V[]){v_x_24192});
      } else {
        heff_drop(v_field_24188);
        V v_t_24194 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_24195 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_24196 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24194, v_t_24195});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam27, 1, 1, (V[]){v_x_24196});
      }
    }
  }
  case TAG_EBytes: {
    HeffT2 v_t_24199 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_24201 = v_t_24199.f[1];
      int64_t v_tag_24200 = ((int64_t)v_t_24199.f[0]);
      if ((v_tag_24200 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 1);
        V v_bs_24202 = v_field_24201;
        V v_t_24203 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_24204 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24202));
        V v_x_24205 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24203, v_t_24204});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam28, 1, 1, (V[]){v_x_24205});
      } else {
        heff_drop(v_field_24201);
        V v_t_24207 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_24208 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_24209 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24207, v_t_24208});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam29, 1, 1, (V[]){v_x_24209});
      }
    }
  }
  case TAG_EFixed: {
    HeffT2 v_t_24213 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_24215 = v_t_24213.f[1];
      int64_t v_tag_24214 = ((int64_t)v_t_24213.f[0]);
      if ((v_tag_24214 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 2);
        V v_bs_24216 = v_field_24215;
        V v_t_24217 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_24218 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24216));
        V v_x_24219 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24217, v_t_24218});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam30, 1, 1, (V[]){v_x_24219});
      } else {
        heff_drop(v_field_24215);
        V v_t_24221 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_24222 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_24223 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24221, v_t_24222});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam31, 1, 1, (V[]){v_x_24223});
      }
    }
  }
  case TAG_EFloat32: {
    HeffT2 v_t_24226 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_24228 = v_t_24226.f[1];
      int64_t v_tag_24227 = ((int64_t)v_t_24226.f[0]);
      if ((v_tag_24227 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 1);
        V v_bs_24229 = v_field_24228;
        V v_t_24230 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_24231 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24229));
        V v_x_24232 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24230, v_t_24231});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam32, 1, 1, (V[]){v_x_24232});
      } else {
        heff_drop(v_field_24228);
        V v_t_24234 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_24235 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_24236 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24234, v_t_24235});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam33, 1, 1, (V[]){v_x_24236});
      }
    }
  }
  case TAG_EAbandon: {
    HeffT2 v_t_24238 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_24240 = v_t_24238.f[1];
      int64_t v_tag_24239 = ((int64_t)v_t_24238.f[0]);
      if ((v_tag_24239 == ((int64_t)0ULL))) {
        V v_bs_24241 = v_field_24240;
        V v_t_24242 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_24243 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24241));
        V v_x_24244 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24242, v_t_24243});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam34, 1, 1, (V[]){v_x_24244});
      } else {
        heff_drop(v_field_24240);
        V v_t_24246 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_24247 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_24248 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24246, v_t_24247});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam35, 1, 1, (V[]){v_x_24248});
      }
    }
  }
  case TAG_EBool: {
    HeffT2 v_t_24251 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_24253 = v_t_24251.f[1];
      int64_t v_tag_24252 = ((int64_t)v_t_24251.f[0]);
      if ((v_tag_24252 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 1);
        V v_bs_24254 = v_field_24253;
        V v_t_24255 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_24256 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24254));
        V v_x_24257 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24255, v_t_24256});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam36, 1, 1, (V[]){v_x_24257});
      } else {
        heff_drop(v_field_24253);
        V v_t_24259 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_24260 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_24261 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24259, v_t_24260});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam37, 1, 1, (V[]){v_x_24261});
      }
    }
  }
  case TAG_ESet: {
    HeffT2 v_t_24266 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_24268 = v_t_24266.f[1];
      int64_t v_tag_24267 = ((int64_t)v_t_24266.f[0]);
      if ((v_tag_24267 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 3);
        V v_bs_24269 = v_field_24268;
        V v_t_24270 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_24271 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24269));
        V v_x_24272 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24270, v_t_24271});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam38, 1, 1, (V[]){v_x_24272});
      } else {
        heff_drop(v_field_24268);
        V v_t_24274 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_24275 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_24276 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24274, v_t_24275});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam39, 1, 1, (V[]){v_x_24276});
      }
    }
  }
  case TAG_EValues: {
    HeffT2 v_t_24279 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_24281 = v_t_24279.f[1];
      int64_t v_tag_24280 = ((int64_t)v_t_24279.f[0]);
      if ((v_tag_24280 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 1);
        V v_bs_24282 = v_field_24281;
        V v_t_24283 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_24284 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24282));
        V v_x_24285 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24283, v_t_24284});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam40, 1, 1, (V[]){v_x_24285});
      } else {
        heff_drop(v_field_24281);
        V v_t_24287 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_24288 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_24289 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24287, v_t_24288});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam41, 1, 1, (V[]){v_x_24289});
      }
    }
  }
  case TAG_EFix: {
    HeffT2 v_t_24293 = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(heff_rfield(v_fu_240, 5), heff_take_field(v_fu_240, 6), heff_dup(v_e_241)));
    {
      V v_field_24295 = v_t_24293.f[1];
      int64_t v_tag_24294 = ((int64_t)v_t_24293.f[0]);
      if ((v_tag_24294 == ((int64_t)0ULL))) {
        heff_drop_tag(v_e_241, 2);
        V v_bs_24296 = v_field_24295;
        V v_t_24297 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 7)});
        V v_t_24298 = (g_prelude_2e_2b_2b(heff_get_n(v_fu_240, 8, 9), v_bs_24296));
        V v_x_24299 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24297, v_t_24298});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam42, 1, 1, (V[]){v_x_24299});
      } else {
        heff_drop(v_field_24295);
        V v_t_24301 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
        V v_t_24302 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), v_e_241, heff_get_n(v_fu_240, 8, 9)));
        V v_x_24303 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24301, v_t_24302});
        return heff_clo_n(g_heff_2ecompile_2efuse_2eendAt_lam43, 1, 1, (V[]){v_x_24303});
      }
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2efuse_2eendAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eendAt(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2eendAt_lam0(V self, V *args) {
  V v_s_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_s_2410});
}
V g_heff_2ecompile_2efuse_2eendAt_lam1(V self, V *args) {
  V v_s_2414 = args[0];
  V v_x_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_s_2414});
}
V g_heff_2ecompile_2efuse_2eendAt_lam2(V self, V *args) {
  V v_s_2423 = args[0];
  V v_x_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2422, v_s_2423});
}
V g_heff_2ecompile_2efuse_2eendAt_lam3(V self, V *args) {
  V v_s_2427 = args[0];
  V v_x_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2426, v_s_2427});
}
V g_heff_2ecompile_2efuse_2eendAt_lam4(V self, V *args) {
  V v_s_2437 = args[0];
  V v_x_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2436, v_s_2437});
}
V g_heff_2ecompile_2efuse_2eendAt_lam5(V self, V *args) {
  V v_s_2441 = args[0];
  V v_x_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2440, v_s_2441});
}
V g_heff_2ecompile_2efuse_2eendAt_lam6(V self, V *args) {
  V v_s_2451 = args[0];
  V v_x_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2450, v_s_2451});
}
V g_heff_2ecompile_2efuse_2eendAt_lam7(V self, V *args) {
  V v_s_2455 = args[0];
  V v_x_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2454, v_s_2455});
}
V g_heff_2ecompile_2efuse_2eendAt_lam8(V self, V *args) {
  V v_s_2466 = args[0];
  V v_x_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2465, v_s_2466});
}
V g_heff_2ecompile_2efuse_2eendAt_lam9(V self, V *args) {
  V v_s_2470 = args[0];
  V v_x_2469 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2469, v_s_2470});
}
V g_heff_2ecompile_2efuse_2eendAt_lam10(V self, V *args) {
  V v_s_2480 = args[0];
  V v_x_2479 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2479, v_s_2480});
}
V g_heff_2ecompile_2efuse_2eendAt_lam11(V self, V *args) {
  V v_s_2484 = args[0];
  V v_x_2483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2483, v_s_2484});
}
V g_heff_2ecompile_2efuse_2eendAt_lam12(V self, V *args) {
  V v_s_2496 = args[0];
  V v_x_2495 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2495, v_s_2496});
}
V g_heff_2ecompile_2efuse_2eendAt_lam13(V self, V *args) {
  V v_s_24100 = args[0];
  V v_x_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2499, v_s_24100});
}
V g_heff_2ecompile_2efuse_2eendAt_lam14(V self, V *args) {
  V v_s_24113 = args[0];
  V v_x_24112 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24112, v_s_24113});
}
V g_heff_2ecompile_2efuse_2eendAt_lam15(V self, V *args) {
  V v_s_24117 = args[0];
  V v_x_24116 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24116, v_s_24117});
}
V g_heff_2ecompile_2efuse_2eendAt_lam16(V self, V *args) {
  V v_s_24126 = args[0];
  V v_x_24125 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24125, v_s_24126});
}
V g_heff_2ecompile_2efuse_2eendAt_lam17(V self, V *args) {
  V v_s_24130 = args[0];
  V v_x_24129 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24129, v_s_24130});
}
V g_heff_2ecompile_2efuse_2eendAt_lam18(V self, V *args) {
  V v_s_24140 = args[0];
  V v_x_24139 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24139, v_s_24140});
}
V g_heff_2ecompile_2efuse_2eendAt_lam19(V self, V *args) {
  V v_s_24144 = args[0];
  V v_x_24143 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24143, v_s_24144});
}
V g_heff_2ecompile_2efuse_2eendAt_lam20(V self, V *args) {
  V v_s_24154 = args[0];
  V v_x_24153 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24153, v_s_24154});
}
V g_heff_2ecompile_2efuse_2eendAt_lam21(V self, V *args) {
  V v_s_24158 = args[0];
  V v_x_24157 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24157, v_s_24158});
}
V g_heff_2ecompile_2efuse_2eendAt_lam22(V self, V *args) {
  V v_s_24167 = args[0];
  V v_x_24166 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24166, v_s_24167});
}
V g_heff_2ecompile_2efuse_2eendAt_lam23(V self, V *args) {
  V v_s_24171 = args[0];
  V v_x_24170 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24170, v_s_24171});
}
V g_heff_2ecompile_2efuse_2eendAt_lam24(V self, V *args) {
  V v_s_24180 = args[0];
  V v_x_24179 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24179, v_s_24180});
}
V g_heff_2ecompile_2efuse_2eendAt_lam25(V self, V *args) {
  V v_s_24184 = args[0];
  V v_x_24183 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24183, v_s_24184});
}
V g_heff_2ecompile_2efuse_2eendAt_lam26(V self, V *args) {
  V v_s_24193 = args[0];
  V v_x_24192 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24192, v_s_24193});
}
V g_heff_2ecompile_2efuse_2eendAt_lam27(V self, V *args) {
  V v_s_24197 = args[0];
  V v_x_24196 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24196, v_s_24197});
}
V g_heff_2ecompile_2efuse_2eendAt_lam28(V self, V *args) {
  V v_s_24206 = args[0];
  V v_x_24205 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24205, v_s_24206});
}
V g_heff_2ecompile_2efuse_2eendAt_lam29(V self, V *args) {
  V v_s_24210 = args[0];
  V v_x_24209 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24209, v_s_24210});
}
V g_heff_2ecompile_2efuse_2eendAt_lam30(V self, V *args) {
  V v_s_24220 = args[0];
  V v_x_24219 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24219, v_s_24220});
}
V g_heff_2ecompile_2efuse_2eendAt_lam31(V self, V *args) {
  V v_s_24224 = args[0];
  V v_x_24223 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24223, v_s_24224});
}
V g_heff_2ecompile_2efuse_2eendAt_lam32(V self, V *args) {
  V v_s_24233 = args[0];
  V v_x_24232 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24232, v_s_24233});
}
V g_heff_2ecompile_2efuse_2eendAt_lam33(V self, V *args) {
  V v_s_24237 = args[0];
  V v_x_24236 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24236, v_s_24237});
}
V g_heff_2ecompile_2efuse_2eendAt_lam34(V self, V *args) {
  V v_s_24245 = args[0];
  V v_x_24244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24244, v_s_24245});
}
V g_heff_2ecompile_2efuse_2eendAt_lam35(V self, V *args) {
  V v_s_24249 = args[0];
  V v_x_24248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24248, v_s_24249});
}
V g_heff_2ecompile_2efuse_2eendAt_lam36(V self, V *args) {
  V v_s_24258 = args[0];
  V v_x_24257 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24257, v_s_24258});
}
V g_heff_2ecompile_2efuse_2eendAt_lam37(V self, V *args) {
  V v_s_24262 = args[0];
  V v_x_24261 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24261, v_s_24262});
}
V g_heff_2ecompile_2efuse_2eendAt_lam38(V self, V *args) {
  V v_s_24273 = args[0];
  V v_x_24272 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24272, v_s_24273});
}
V g_heff_2ecompile_2efuse_2eendAt_lam39(V self, V *args) {
  V v_s_24277 = args[0];
  V v_x_24276 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24276, v_s_24277});
}
V g_heff_2ecompile_2efuse_2eendAt_lam40(V self, V *args) {
  V v_s_24286 = args[0];
  V v_x_24285 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24285, v_s_24286});
}
V g_heff_2ecompile_2efuse_2eendAt_lam41(V self, V *args) {
  V v_s_24290 = args[0];
  V v_x_24289 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24289, v_s_24290});
}
V g_heff_2ecompile_2efuse_2eendAt_lam42(V self, V *args) {
  V v_s_24300 = args[0];
  V v_x_24299 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24299, v_s_24300});
}
V g_heff_2ecompile_2efuse_2eendAt_lam43(V self, V *args) {
  V v_s_24304 = args[0];
  V v_x_24303 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24303, v_s_24304});
}
V g_heff_2ecompile_2efuse_2emayFuse_lam0(V self, V *args);
Clo g_heff_2ecompile_2efuse_2emayFuse_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2emayFuse_entry, 6, 0};

V g_heff_2ecompile_2efuse_2emayFuse(V v_sg_240, V v_c_241, V v_cs_242, V v_ps_243, V v_args_244, V v_bs_245) {
top: ;
  V v_params_246 = heff_take_field(v_ps_243, 0);
  V v_tags_247 = heff_get_n(v_ps_243, 2, 3);
  V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_244));
  V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_cs_242, 0)));
  if (heff_intEq_c(v_t_248, v_t_249)) {
    V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_bs_245));
    V v_t_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_params_246; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_params_246); r_; });
    if (heff_intEq_c(v_t_2410, v_t_2411)) {
      V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eworkPure_clo), 1, (V[]){heff_dup(v_sg_240)}));
      V v_t_2413 = (g_heff_2ecompile_2efuse_2eremoveAt(heff_dup(heff_rfield(v_cs_242, 1)), heff_dup(v_args_244)));
      V v_t_2414 = ({ V a_0 = v_t_2412; V a_1 = v_t_2413; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2413); r_; });
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_t_2414);
        V v_t_2415 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(heff_rfield(v_cs_242, 0)), heff_dup(heff_rfield(v_cs_242, 4))));
        V v_t_2416 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2415, v_args_244));
        V v_t_2417 = (g_heff_2ecompile_2efuse_2eremoveAt(heff_dup(heff_rfield(v_cs_242, 1)), v_t_2416));
        V v_t_2418 = (g_list_2ekeepIf_24s1457049037x722637222(v_t_2417));
        V v_ps_2419 = (g_list_2emap_24s1690674600x556093466(v_t_2418));
        V v_t_2420 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2419; V r_ = (g_list_2efoldl_24s571527232x333134686(a_0, a_1)); heff_drop(v_ps_2419); r_; });
        V v_t_2421 = ({ V a_0 = v_sg_240; V a_1 = v_c_241; V a_2 = heff_dup(v_cs_242); V a_3 = v_t_2420; V a_4 = heff_rfield(v_cs_242, 2); V r_ = (g_list_2eall_24s1543979616x278497281(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2420); r_; });
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_t_2421);
          return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2emayFuse_lam0, 1, 1, (V[]){v_cs_242}); V a_1 = v_tags_247; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_tags_247); r_; });
        } else {
          heff_drop_rec(v_cs_242, 5);
          heff_drop(v_tags_247);
          heff_drop(v_t_2421);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop(v_sg_240);
        heff_drop(v_c_241);
        heff_drop_rec(v_cs_242, 5);
        heff_drop(v_args_244);
        heff_drop(v_tags_247);
        heff_drop(v_t_2414);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_sg_240);
      heff_drop(v_c_241);
      heff_drop_rec(v_cs_242, 5);
      heff_drop(v_args_244);
      heff_drop(v_tags_247);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_sg_240);
    heff_drop(v_c_241);
    heff_drop_rec(v_cs_242, 5);
    heff_drop(v_args_244);
    heff_drop(v_params_246);
    heff_drop(v_tags_247);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2efuse_2emayFuse_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ecompile_2efuse_2emayFuse(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
V g_heff_2ecompile_2efuse_2emayFuse_lam0(V self, V *args) {
  V v_t_2422 = args[0];
  V v_cs_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2423 = ({ V a_0 = v_t_2422; V a_1 = heff_get_n(v_cs_242, 2, 5); HeffT2 r_ = (g_heff_2ecompile_2efuse_2efindArm_24cpr(a_0, a_1)); heff_drop(v_t_2422); r_; });
  {
    V v_field_2425 = v_t_2423.f[1];
    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2424 == ((int64_t)0ULL)) && ({ V v_x11_2426 = heff_dup(v_field_2425); int c_ = 1; heff_drop(v_x11_2426); c_; })));
    heff_drop(v_field_2425);
    return v_ret_24bool;
  }
}
HEFF_LIT(g_heff_2ecompile_2efuse_2efuseWith_str0, 1, " ");
HEFF_LIT(g_heff_2ecompile_2efuse_2efuseWith_str1, 0, "");
Clo g_heff_2ecompile_2efuse_2efuseWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efuseWith_entry, 7, 0};

V g_heff_2ecompile_2efuse_2efuseWith(V v_c_240, V v_cs_241, V v_p_242, V v_ps_243, V v_args_244, V v_bs_245, V v_s_246) {
top: ;
  V v_t_247 = heff_strAppend(heff_dup(v_c_240), heff_strAppend(((V)&g_heff_2ecompile_2efuse_2efuseWith_str0), heff_dup(v_p_242)));
  HeffT2 v_t_248 = ({ V a_0 = heff_rfield(v_s_246, 3); V a_1 = v_t_247; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_247); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      heff_drop(v_c_240);
      heff_drop(v_p_242);
      heff_drop(v_ps_243);
      V v_k_2411 = v_field_2410;
      V v_x_2414;
      if (heff_strEq_c_lent(v_k_2411, ((V)&g_heff_2ecompile_2efuse_2efuseWith_str1), 2)) {
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_args_244);
        heff_drop(v_bs_245);
        heff_drop(v_k_2411);
        v_x_2414 = NTAG(TAG_Nothing);
      } else {
        V v_t_2412 = (g_prelude_2e_2b_2b_24f677743828x1026746250(v_bs_245, heff_get_n(v_cs_241, 1, 5), v_args_244));
        V v_t_2413 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_k_2411}), v_t_2412});
        v_x_2414 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
      }
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2414, v_s_246});
    } else {
      heff_drop(v_field_2410);
      return (g_heff_2ecompile_2efuse_2efuseNew(v_c_240, v_cs_241, v_p_242, v_ps_243, v_args_244, v_bs_245, heff_dup(heff_rfield(v_s_246, 5)), v_s_246));
    }
  }
}
V g_heff_2ecompile_2efuse_2efuseWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2efuseWith(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_heff_2ecompile_2efuse_2eletHere_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eletHere_entry, 5, 0};

V g_heff_2ecompile_2efuse_2eletHere(V v_sg_240, V v_x_241, V v_b_242, V v_x4_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_sg_240);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_244});
  }
  case TAG_Just: {
    V v_x41_245 = heff_field(v_x4_243, 0);
    switch (heff_tag_of(v_x41_245)) {
    case TAG_MkPair: {
      V v_p_246 = heff_field(v_x41_245, 0);
      V v_bs_247 = heff_field(v_x41_245, 1);
      HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(heff_rfield(v_p_244, 2), v_p_246));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_2410;
          heff_drop(v_x_2411);
          V v_t_2412 = (g_heff_2ecompile_2efuse_2eonceIn(v_x_241, heff_dup(v_b_242)));
          if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
            heff_drop(v_t_2412);
            V v_t_2413 = (g_heff_2ecompile_2efuse_2eplugK(v_sg_240));
            return heff_tail(heff_get_n(v_t_2413, 0, 1), 3, (V[]){heff_rec_n(3, shape_x__p__bs, (V[]){v_x_241, heff_dup(v_p_246), heff_dup(v_bs_247)}), v_b_242, v_p_244});
          } else {
            heff_drop(v_sg_240);
            heff_drop(v_x_241);
            heff_drop(v_b_242);
            heff_drop(v_t_2412);
            return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_244});
          }
        } else {
          heff_drop(v_sg_240);
          heff_drop(v_x_241);
          heff_drop(v_b_242);
          heff_drop(v_field_2410);
          return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_244});
        }
      }
    }
    default: return heff_nomatch(v_x41_245);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2efuse_2eletHere_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2efuse_2eletHere(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2ecompile_2efuse_2ehere_lam0(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam0, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam1(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam1, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam2(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam2, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam3(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam3, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam4(V self, V *args);
V g_heff_2ecompile_2efuse_2ehere_lam5(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam5, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam6(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam6, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam7(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam7, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam8(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam8, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam9(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam9, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam10(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam10, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam11(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam11, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam12(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam12, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam13(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam13, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam14(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam14, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam15(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam15, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam16(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam16, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam17(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam17, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam18(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam18, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam19(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam19, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam20(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam20, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam21(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam21, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam22(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam22, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam23(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam23, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam24(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam24, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam25(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam25, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam26(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam26, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam27(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam27, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam28(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam28, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam29(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam29, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam30(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam30, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam31(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam31, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam32(V self, V *args);
V g_heff_2ecompile_2efuse_2ehere_lam33(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam33_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam33, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam34(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam34_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam34, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam35(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam35, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam36(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam36, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam37(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam37_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam37, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam38(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam38, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam39(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam39_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam39, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam40(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam40, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam41(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam41_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam41, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam42(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam42, 1, 0};
V g_heff_2ecompile_2efuse_2ehere_lam43(V self, V *args); static Clo g_heff_2ecompile_2efuse_2ehere_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_lam43, 1, 0};
Clo g_heff_2ecompile_2efuse_2ehere_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ehere_entry, 2, 0};

V g_heff_2ecompile_2efuse_2ehere(V v_sg_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam0_clo);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam1_clo);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam2_clo);
  }
  case TAG_EApp: {
    V v_x21_249 = heff_field(v_x2_241, 0);
    V v_args_2410 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_249)) {
    case TAG_EVar: {
      heff_take_n(v_x21_249, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam3_clo);
    }
    case TAG_EGlobal: {
      V v_c_2413 = heff_field(v_x21_249, 0);
      heff_take_n(v_x21_249, 1ULL, 1);
      return heff_clo_n(g_heff_2ecompile_2efuse_2ehere_lam4, 1, 3, (V[]){v_c_2413, v_args_2410, v_sg_240});
    }
    case TAG_ELam: {
      heff_take_n(v_x21_249, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam5_clo);
    }
    case TAG_EApp: {
      heff_take_n(v_x21_249, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam6_clo);
    }
    case TAG_ELet: {
      heff_take_n(v_x21_249, 0ULL, 3);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam7_clo);
    }
    case TAG_ERecord: {
      heff_take_n(v_x21_249, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam8_clo);
    }
    case TAG_EProj: {
      heff_take_n(v_x21_249, 0ULL, 4);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam9_clo);
    }
    case TAG_ETag: {
      heff_take_n(v_x21_249, 0ULL, 3);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam10_clo);
    }
    case TAG_EMatch: {
      heff_take_n(v_x21_249, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam11_clo);
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_249, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam12_clo);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x21_249, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam13_clo);
    }
    case TAG_ECall: {
      heff_take_n(v_x21_249, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam14_clo);
    }
    case TAG_EInt: {
      heff_take_n(v_x21_249, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam15_clo);
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_249, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam16_clo);
    }
    case TAG_EStr: {
      heff_take_n(v_x21_249, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam17_clo);
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_249, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam18_clo);
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_249, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam19_clo);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_249, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam20_clo);
    }
    case TAG_EAbandon: {
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam21_clo);
    }
    case TAG_EBool: {
      heff_take_n(v_x21_249, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam22_clo);
    }
    case TAG_ESet: {
      heff_take_n(v_x21_249, 0ULL, 3);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam23_clo);
    }
    case TAG_EValues: {
      heff_take_n(v_x21_249, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam24_clo);
    }
    case TAG_EFix: {
      heff_take_n(v_x21_249, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop(v_args_2410);
      return ((V)&g_heff_2ecompile_2efuse_2ehere_lam25_clo);
    }
    default: return heff_nomatch(v_x21_249);
    }
  }
  case TAG_ELet: {
    V v_x_2478 = heff_field(v_x2_241, 0);
    V v_a_2479 = heff_field(v_x2_241, 1);
    V v_b_2480 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2481 = (g_heff_2ecompile_2efuse_2eglobalCall(v_a_2479));
    return heff_tail(((V)&g_heff_2ecompile_2efuse_2eletHere_clo), 4, (V[]){v_sg_240, v_x_2478, v_b_2480, v_t_2481});
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam26_clo);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam27_clo);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam28_clo);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam29_clo);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam30_clo);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam31_clo);
  }
  case TAG_ECall: {
    V v_c_24102 = heff_field(v_x2_241, 0);
    V v_args_24103 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    return heff_clo_n(g_heff_2ecompile_2efuse_2ehere_lam32, 1, 3, (V[]){v_c_24102, v_args_24103, v_sg_240});
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam33_clo);
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam34_clo);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam35_clo);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam36_clo);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam37_clo);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam38_clo);
  }
  case TAG_EAbandon: {
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam39_clo);
  }
  case TAG_EBool: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam40_clo);
  }
  case TAG_ESet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam41_clo);
  }
  case TAG_EValues: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam42_clo);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_sg_240);
    return ((V)&g_heff_2ecompile_2efuse_2ehere_lam43_clo);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2ehere_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2ehere(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2ehere_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_243});
}
V g_heff_2ecompile_2efuse_2ehere_lam1(V self, V *args) {
  V v_s_245 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_245});
}
V g_heff_2ecompile_2efuse_2ehere_lam2(V self, V *args) {
  V v_s_248 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_248});
}
V g_heff_2ecompile_2efuse_2ehere_lam3(V self, V *args) {
  V v_s_2412 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2412});
}
V g_heff_2ecompile_2efuse_2ehere_lam4(V self, V *args) {
  V v_s_2414 = args[0];
  V v_c_2413 = heff_env(self)[0];
  V v_args_2410 = heff_env(self)[1];
  V v_sg_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2415 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_s_2414, 1), v_c_2413));
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_cs_2418 = v_field_2417;
      V v_t_2419 = (g_heff_2ecompile_2efuse_2enthF(heff_get_n(v_cs_2418, 1, 5), heff_dup(v_args_2410)));
      return ({ V a_0 = v_sg_240; V a_1 = v_c_2413; V a_2 = v_args_2410; V a_3 = v_t_2419; V a_4 = v_s_2414; V r_ = (g_heff_2ecompile_2efuse_2efuseOn(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2419); r_; });
    } else {
      heff_drop(v_c_2413);
      heff_drop(v_args_2410);
      heff_drop(v_sg_240);
      heff_drop(v_field_2417);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2414});
    }
  }
}
V g_heff_2ecompile_2efuse_2ehere_lam5(V self, V *args) {
  V v_s_2422 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2422});
}
V g_heff_2ecompile_2efuse_2ehere_lam6(V self, V *args) {
  V v_s_2425 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2425});
}
V g_heff_2ecompile_2efuse_2ehere_lam7(V self, V *args) {
  V v_s_2429 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2429});
}
V g_heff_2ecompile_2efuse_2ehere_lam8(V self, V *args) {
  V v_s_2432 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2432});
}
V g_heff_2ecompile_2efuse_2ehere_lam9(V self, V *args) {
  V v_s_2437 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2437});
}
V g_heff_2ecompile_2efuse_2ehere_lam10(V self, V *args) {
  V v_s_2441 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2441});
}
V g_heff_2ecompile_2efuse_2ehere_lam11(V self, V *args) {
  V v_s_2444 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2444});
}
V g_heff_2ecompile_2efuse_2ehere_lam12(V self, V *args) {
  V v_s_2446 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2446});
}
V g_heff_2ecompile_2efuse_2ehere_lam13(V self, V *args) {
  V v_s_2449 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2449});
}
V g_heff_2ecompile_2efuse_2ehere_lam14(V self, V *args) {
  V v_s_2452 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2452});
}
V g_heff_2ecompile_2efuse_2ehere_lam15(V self, V *args) {
  V v_s_2454 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2454});
}
V g_heff_2ecompile_2efuse_2ehere_lam16(V self, V *args) {
  V v_s_2456 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2456});
}
V g_heff_2ecompile_2efuse_2ehere_lam17(V self, V *args) {
  V v_s_2458 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2458});
}
V g_heff_2ecompile_2efuse_2ehere_lam18(V self, V *args) {
  V v_s_2460 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2460});
}
V g_heff_2ecompile_2efuse_2ehere_lam19(V self, V *args) {
  V v_s_2463 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2463});
}
V g_heff_2ecompile_2efuse_2ehere_lam20(V self, V *args) {
  V v_s_2465 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2465});
}
V g_heff_2ecompile_2efuse_2ehere_lam21(V self, V *args) {
  V v_s_2466 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2466});
}
V g_heff_2ecompile_2efuse_2ehere_lam22(V self, V *args) {
  V v_s_2468 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2468});
}
V g_heff_2ecompile_2efuse_2ehere_lam23(V self, V *args) {
  V v_s_2472 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2472});
}
V g_heff_2ecompile_2efuse_2ehere_lam24(V self, V *args) {
  V v_s_2474 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2474});
}
V g_heff_2ecompile_2efuse_2ehere_lam25(V self, V *args) {
  V v_s_2477 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2477});
}
V g_heff_2ecompile_2efuse_2ehere_lam26(V self, V *args) {
  V v_s_2484 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2484});
}
V g_heff_2ecompile_2efuse_2ehere_lam27(V self, V *args) {
  V v_s_2489 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2489});
}
V g_heff_2ecompile_2efuse_2ehere_lam28(V self, V *args) {
  V v_s_2493 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2493});
}
V g_heff_2ecompile_2efuse_2ehere_lam29(V self, V *args) {
  V v_s_2496 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2496});
}
V g_heff_2ecompile_2efuse_2ehere_lam30(V self, V *args) {
  V v_s_2498 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2498});
}
V g_heff_2ecompile_2efuse_2ehere_lam31(V self, V *args) {
  V v_s_24101 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24101});
}
V g_heff_2ecompile_2efuse_2ehere_lam32(V self, V *args) {
  V v_s_24104 = args[0];
  V v_c_24102 = heff_env(self)[0];
  V v_args_24103 = heff_env(self)[1];
  V v_sg_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_24105 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_s_24104, 1), v_c_24102));
  {
    V v_field_24107 = v_t_24105.f[1];
    int64_t v_tag_24106 = ((int64_t)v_t_24105.f[0]);
    if ((v_tag_24106 == ((int64_t)0ULL))) {
      V v_cs_24108 = v_field_24107;
      V v_t_24109 = (g_heff_2ecompile_2efuse_2enthF(heff_get_n(v_cs_24108, 1, 5), heff_dup(v_args_24103)));
      return ({ V a_0 = v_sg_240; V a_1 = v_c_24102; V a_2 = v_args_24103; V a_3 = v_t_24109; V a_4 = v_s_24104; V r_ = (g_heff_2ecompile_2efuse_2efuseOn(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_24109); r_; });
    } else {
      heff_drop(v_c_24102);
      heff_drop(v_args_24103);
      heff_drop(v_sg_240);
      heff_drop(v_field_24107);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24104});
    }
  }
}
V g_heff_2ecompile_2efuse_2ehere_lam33(V self, V *args) {
  V v_s_24111 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24111});
}
V g_heff_2ecompile_2efuse_2ehere_lam34(V self, V *args) {
  V v_s_24113 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24113});
}
V g_heff_2ecompile_2efuse_2ehere_lam35(V self, V *args) {
  V v_s_24115 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24115});
}
V g_heff_2ecompile_2efuse_2ehere_lam36(V self, V *args) {
  V v_s_24117 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24117});
}
V g_heff_2ecompile_2efuse_2ehere_lam37(V self, V *args) {
  V v_s_24120 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24120});
}
V g_heff_2ecompile_2efuse_2ehere_lam38(V self, V *args) {
  V v_s_24122 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24122});
}
V g_heff_2ecompile_2efuse_2ehere_lam39(V self, V *args) {
  V v_s_24123 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24123});
}
V g_heff_2ecompile_2efuse_2ehere_lam40(V self, V *args) {
  V v_s_24125 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24125});
}
V g_heff_2ecompile_2efuse_2ehere_lam41(V self, V *args) {
  V v_s_24129 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24129});
}
V g_heff_2ecompile_2efuse_2ehere_lam42(V self, V *args) {
  V v_s_24131 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24131});
}
V g_heff_2ecompile_2efuse_2ehere_lam43(V self, V *args) {
  V v_s_24134 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24134});
}
Clo g_heff_2ecompile_2efuse_2efuseKnown_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efuseKnown_24tok2_entry, 9, 0};

V g_heff_2ecompile_2efuse_2efuseKnown_24tok2(V v_tok_240, V v_sg_241, V v_c_242, V v_args_243, V v_p_244, V v_bs_245, V v_x6_246, V v_x7_247, V v_z_248) {
top: ;
  switch (heff_tag_of(v_x6_246)) {
  case TAG_Nothing: {
    heff_drop(v_sg_241);
    heff_drop(v_c_242);
    heff_drop(v_args_243);
    heff_drop(v_p_244);
    heff_drop(v_bs_245);
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_248});
  }
  case TAG_Just: {
    V v_cs_249 = heff_field(v_x6_246, 0);
    switch (heff_tag_of(v_x7_247)) {
    case TAG_Nothing: {
      heff_drop(v_sg_241);
      heff_drop(v_c_242);
      heff_drop(v_args_243);
      heff_drop(v_p_244);
      heff_drop(v_bs_245);
      return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_248});
    }
    case TAG_Just: {
      V v_ps_2410 = heff_field(v_x7_247, 0);
      V v_t_2411 = (g_heff_2ecompile_2efuse_2emayFuse(v_sg_241, heff_dup(v_c_242), heff_dup(v_cs_249), heff_dup(v_ps_2410), heff_dup(v_args_243), v_bs_245));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_t_2411);
        return (g_heff_2ecompile_2efuse_2efuseWith(v_c_242, heff_dup(v_cs_249), v_p_244, heff_dup(v_ps_2410), v_args_243, v_bs_245, v_z_248));
      } else {
        heff_drop(v_c_242);
        heff_drop(v_args_243);
        heff_drop(v_p_244);
        heff_drop(v_bs_245);
        heff_drop(v_t_2411);
        return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_248});
      }
    }
    default: return heff_nomatch(v_x7_247);
    }
  }
  default: return heff_nomatch(v_x6_246);
  }
}
V g_heff_2ecompile_2efuse_2efuseKnown_24tok2_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V a7 = a[7]; V r = g_heff_2ecompile_2efuse_2efuseKnown_24tok2(a[0], a[1], a[2], a[3], a[4], a[5], a6, a7, a[8]); heff_drop(a6); heff_drop(a7); return r;
}
V g_heff_2ecompile_2efuse_2etagEnd_24tok3_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2etagEnd_24tok3_lam1(V self, V *args);
Clo g_heff_2ecompile_2efuse_2etagEnd_24tok3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2etagEnd_24tok3_entry, 5, 0};

V g_heff_2ecompile_2efuse_2etagEnd_24tok3(V v_tok_240, V v_fu_241, V v_t_242, V v_hs_243, V v_ts_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2ecompile_2efuse_2efindArm_24cpr(v_t_242, heff_dup(heff_rfield(v_fu_241, 3))));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop_cell(v_tok_240, 3);
      V v_a_248 = v_field_247;
      return heff_clo_n(g_heff_2ecompile_2efuse_2etagEnd_24tok3_lam0, 1, 5, (V[]){v_a_248, v_fu_241, v_t_242, v_hs_243, v_ts_244});
    } else {
      heff_drop(v_field_247);
      V v_t_2418 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_241, 0)});
      V v_t_2419 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_241, 2), heff_tag_at_n(v_tok_240, TAG_ETag, 3, (V[]){v_t_242, v_hs_243, v_ts_244}), heff_get_n(v_fu_241, 8, 9)));
      V v_x_2420 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2418, v_t_2419});
      return heff_clo_n(g_heff_2ecompile_2efuse_2etagEnd_24tok3_lam1, 1, 1, (V[]){v_x_2420});
    }
  }
}
V g_heff_2ecompile_2efuse_2etagEnd_24tok3_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2etagEnd_24tok3(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2efuse_2etagEnd_24tok3_lam0(V self, V *args) {
  V v_p_249 = args[0];
  V v_a_248 = heff_env(self)[0];
  V v_fu_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_hs_243 = heff_env(self)[3];
  V v_ts_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_a_248)) {
  case TAG_MkArm: {
    V v_vs_2411 = heff_field(v_a_248, 1);
    V v_b_2412 = heff_field(v_a_248, 2);
    heff_take_n(v_a_248, 6ULL, 3);
    HeffT2 v_t_2413 = (g_heff_2ecompile_2efuse_2efreshF_24cpr(heff_tag_n(TAG_ELam, 2, (V[]){v_vs_2411, v_b_2412}), v_p_249));
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_field_2415 = v_t_2413.f[1];
      V v_x_2416 = v_field_2414;
      V v_s_2417 = v_field_2415;
      return (g_heff_2ecompile_2efuse_2earmGiven(v_fu_241, v_t_242, v_hs_243, v_ts_244, v_x_2416, v_s_2417));
    }
  }
  default: return heff_nomatch(v_a_248);
  }
}
V g_heff_2ecompile_2efuse_2etagEnd_24tok3_lam1(V self, V *args) {
  V v_s_2421 = args[0];
  V v_x_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2420, v_s_2421});
}