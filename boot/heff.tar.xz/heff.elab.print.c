// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
V g_heff_2eelab_2eprint_2eabsOf(V, V);
V g_heff_2eelab_2eprint_2eabsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eabsOf_clo;
V g_heff_2eelab_2eprint_2earmOf(V, V);
V g_heff_2eelab_2eprint_2earmOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2earmOf_clo;
V g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143(V);
V g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_clo;
V g_heff_2eelab_2eprint_2ecommaSep(V);
V g_heff_2eelab_2eprint_2ecommaSep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2ecommaSep_clo;
V g_heff_2eelab_2eprint_2edictOf(V, V);
V g_heff_2eelab_2eprint_2edictOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2edictOf_clo;
V g_heff_2eelab_2eprint_2eescChar(V);
V g_heff_2eelab_2eprint_2eescChar_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescChar_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2epr_get(void);
V g_heff_2eelab_2eprint_2eshowTermF(V, V);
V g_heff_2eelab_2eprint_2eshowTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTermF_clo;
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(V);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_clo;
V g_heff_2eelab_2eprint_2eshowTypeF(V, V);
V g_heff_2eelab_2eprint_2eshowTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTypeF_clo;
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(V);
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1181937096x2120532116(V);
V g_list_2emap_24s1181937096x2120532116_entry(V self, V *a);
extern Clo g_list_2emap_24s1181937096x2120532116_clo;
V g_list_2emap_24s1201815197x1377530874(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1201815197x1377530874_entry(V self, V *a);
extern Clo g_list_2emap_24s1201815197x1377530874_clo;
V g_list_2emap_24s1397747289x2145601499(V);
V g_list_2emap_24s1397747289x2145601499_entry(V self, V *a);
extern Clo g_list_2emap_24s1397747289x2145601499_clo;
V g_list_2emap_24s1646944445x1684083181(V, V, V, V, V, V, V);
V g_list_2emap_24s1646944445x1684083181_entry(V self, V *a);
extern Clo g_list_2emap_24s1646944445x1684083181_clo;
V g_list_2emap_24s500158289x1934493753(V, V, V, V, V, V, V);
V g_list_2emap_24s500158289x1934493753_entry(V self, V *a);
extern Clo g_list_2emap_24s500158289x1934493753_clo;
V g_list_2emap_24s846355817x1552148381(V, V, V, V, V, V, V);
V g_list_2emap_24s846355817x1552148381_entry(V self, V *a);
extern Clo g_list_2emap_24s846355817x1552148381_clo;
HEFF_LIT(g_heff_2eelab_2eprint_2eescChar_str0, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eescChar_str1, 2, "\\\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eescChar_str2, 1, "\\");
HEFF_LIT(g_heff_2eelab_2eprint_2eescChar_str3, 2, "\\\\");
HEFF_LIT(g_heff_2eelab_2eprint_2eescChar_str4, 1, "\012");
HEFF_LIT(g_heff_2eelab_2eprint_2eescChar_str5, 2, "\\n");
HEFF_LIT(g_heff_2eelab_2eprint_2eescChar_str6, 1, "\015");
HEFF_LIT(g_heff_2eelab_2eprint_2eescChar_str7, 2, "\\r");
HEFF_LIT(g_heff_2eelab_2eprint_2eescChar_str8, 1, "\011");
HEFF_LIT(g_heff_2eelab_2eprint_2eescChar_str9, 2, "\\t");
Clo g_heff_2eelab_2eprint_2eescChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2eescChar_entry, 1, 0};

V g_heff_2eelab_2eprint_2eescChar(V v_c_240) {
top: ;
  if (heff_strEq_c(heff_dup(v_c_240), ((V)&g_heff_2eelab_2eprint_2eescChar_str0))) {
    heff_drop(v_c_240);
    return ((V)&g_heff_2eelab_2eprint_2eescChar_str1);
  } else {
    if (heff_strEq_c(heff_dup(v_c_240), ((V)&g_heff_2eelab_2eprint_2eescChar_str2))) {
      heff_drop(v_c_240);
      return ((V)&g_heff_2eelab_2eprint_2eescChar_str3);
    } else {
      if (heff_strEq_c(heff_dup(v_c_240), ((V)&g_heff_2eelab_2eprint_2eescChar_str4))) {
        heff_drop(v_c_240);
        return ((V)&g_heff_2eelab_2eprint_2eescChar_str5);
      } else {
        if (heff_strEq_c(heff_dup(v_c_240), ((V)&g_heff_2eelab_2eprint_2eescChar_str6))) {
          heff_drop(v_c_240);
          return ((V)&g_heff_2eelab_2eprint_2eescChar_str7);
        } else {
          if (heff_strEq_c(heff_dup(v_c_240), ((V)&g_heff_2eelab_2eprint_2eescChar_str8))) {
            heff_drop(v_c_240);
            return ((V)&g_heff_2eelab_2eprint_2eescChar_str9);
          } else {
            return v_c_240;
          }
        }
      }
    }
  }
}
V g_heff_2eelab_2eprint_2eescChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eprint_2eescChar(a[0]);
}
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_str0, 0, "");
Clo g_heff_2eelab_2eprint_2eescFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2eescFrom_entry, 2, 0};

V g_heff_2eelab_2eprint_2eescFrom(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_241), heff_strLength(heff_dup(v_s_240)))) {
    V v_t_243 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
    V v_t_244 = (g_heff_2eelab_2eprint_2eescChar(v_t_243));
    return heff_strAppend(v_t_244, (g_heff_2eelab_2eprint_2eescFrom(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)))));
  } else {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return ((V)&g_heff_2eelab_2eprint_2eescFrom_str0);
  }
}
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eprint_2eescFrom(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2eprint_2ecommaSep_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2eprint_2ecommaSep_str1, 2, ", ");
Clo g_heff_2eelab_2eprint_2ecommaSep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2ecommaSep_entry, 1, 0};

V g_heff_2eelab_2eprint_2ecommaSep(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2eprint_2ecommaSep_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2eelab_2eprint_2ecommaSep_str1), (g_heff_2eelab_2eprint_2ecommaSep(v_x12_242))));
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eprint_2ecommaSep_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eprint_2ecommaSep(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eprint_2edictOf_str0, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2edictOf_str1, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2edictOf_str2, 8, "(MkPair ");
HEFF_LIT(g_heff_2eelab_2eprint_2edictOf_str3, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2edictOf_str4, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2edictOf_str5, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2edictOf_str6, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2edictOf_str7, 12, "(D.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2edictOf_str8, 1, ")");
V g_heff_2eelab_2eprint_2edictOf_lam0(V self, V *args);
Clo g_heff_2eelab_2eprint_2edictOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2edictOf_entry, 2, 0};

V g_heff_2eelab_2eprint_2edictOf(V v_f_240, V v_d_241) {
top: ;
  V v_t_242 = heff_arrayToList(heff_take_field(v_d_241, 0));
  V v_t_243 = heff_arrayToList(heff_get_n(v_d_241, 2, 3));
  V v_t_244 = (g_heff_2eutil_2edict_2ezipKV(v_t_242, v_t_243));
  V v_xs_2411 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eprint_2edictOf_lam0, 1, 1, (V[]){v_f_240}), v_t_244));
  V v_t_2412 = ({ V a_0 = v_xs_2411; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2411); r_; });
  V v_t_2413 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2edictOf_str5), heff_strAppend(v_t_2412, ((V)&g_heff_2eelab_2eprint_2edictOf_str6)));
  return heff_strAppend(((V)&g_heff_2eelab_2eprint_2edictOf_str7), heff_strAppend(v_t_2413, ((V)&g_heff_2eelab_2eprint_2edictOf_str8)));
}
V g_heff_2eelab_2eprint_2edictOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eprint_2edictOf(a[0], a[1]);
}
V g_heff_2eelab_2eprint_2edictOf_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_k_246 = heff_field(v_p_245, 0);
    V v_v_247 = heff_field(v_p_245, 1);
    heff_take_n(v_p_245, 3ULL, 2);
    V v_t_248 = (g_heff_2eelab_2eprint_2eescFrom(v_k_246, MK_INT(0LL)));
    V v_t_249 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2edictOf_str0), heff_strAppend(v_t_248, ((V)&g_heff_2eelab_2eprint_2edictOf_str1)));
    V v_t_2410 = heff_tr(heff_call(v_f_240, 1, (V[]){v_v_247}));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2edictOf_str2), heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2eelab_2eprint_2edictOf_str3), heff_strAppend(v_t_2410, ((V)&g_heff_2eelab_2eprint_2edictOf_str4)))));
  }
  default: return heff_nomatch(v_p_245);
  }
}
HEFF_LIT(g_heff_2eelab_2eprint_2eabsOf_str0, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eabsOf_str1, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eabsOf_str2, 7, "(MkAbs ");
HEFF_LIT(g_heff_2eelab_2eprint_2eabsOf_str3, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eabsOf_str4, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eabsOf_str5, 10, "(AbsConst ");
HEFF_LIT(g_heff_2eelab_2eprint_2eabsOf_str6, 1, ")");
Clo g_heff_2eelab_2eprint_2eabsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2eabsOf_entry, 2, 0};

V g_heff_2eelab_2eprint_2eabsOf(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkAbs: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_b_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2eelab_2eprint_2eescFrom(heff_dup(v_x_242), MK_INT(0LL)));
    V v_t_245 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eabsOf_str0), heff_strAppend(v_t_244, ((V)&g_heff_2eelab_2eprint_2eabsOf_str1)));
    V v_t_246 = heff_tr(heff_call(v_f_240, 1, (V[]){heff_dup(v_b_243)}));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eabsOf_str2), heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eabsOf_str3), heff_strAppend(v_t_246, ((V)&g_heff_2eelab_2eprint_2eabsOf_str4)))));
  }
  case TAG_AbsConst: {
    V v_b_247 = heff_field(v_x2_241, 0);
    V v_t_248 = heff_tr(heff_call(v_f_240, 1, (V[]){heff_dup(v_b_247)}));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eabsOf_str5), heff_strAppend(v_t_248, ((V)&g_heff_2eelab_2eprint_2eabsOf_str6)));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eprint_2eabsOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eprint_2eabsOf(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_str0, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_str1, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_str2, 12, "(A.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_str3, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_str4, 8, "(MkPair ");
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_str5, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_str6, 1, ")");
Clo g_heff_2eelab_2eprint_2earmOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2earmOf_entry, 2, 0};

V g_heff_2eelab_2eprint_2earmOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_xs_242 = heff_field(v_x2_241, 0);
    V v_b_243 = heff_field(v_x2_241, 1);
    V v_xs_244 = (g_list_2emap_24s1397747289x2145601499(heff_arrayToList(heff_dup(v_xs_242))));
    V v_t_245 = ({ V a_0 = v_xs_244; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_244); r_; });
    V v_t_246 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2earmOf_str0), heff_strAppend(v_t_245, ((V)&g_heff_2eelab_2eprint_2earmOf_str1)));
    V v_t_247 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2earmOf_str2), heff_strAppend(v_t_246, ((V)&g_heff_2eelab_2eprint_2earmOf_str3)));
    V v_t_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_b_243)}));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2earmOf_str4), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2eelab_2eprint_2earmOf_str5), heff_strAppend(v_t_248, ((V)&g_heff_2eelab_2eprint_2earmOf_str6)))));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eprint_2earmOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eprint_2earmOf(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str0, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str1, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str2, 8, "(SLocal ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str3, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str4, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str5, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str6, 9, "(SGlobal ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str7, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str8, 7, "(SCode ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str9, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str10, 6, "(SApp ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str11, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str12, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str13, 6, "(SLam ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str14, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str15, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str16, 7, "(SCons ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str17, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str18, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str19, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str20, 7, "(SProj ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str21, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str22, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str23, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str24, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str25, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str26, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str27, 12, "(A.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str28, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str29, 6, "(STag ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str30, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str31, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str32, 8, "(SMatch ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str33, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str34, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str35, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str36, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str37, 13, "(SSpecialize ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str38, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str39, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str40, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str41, 5, "(SIs ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str42, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str43, 7, "SOpaque");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str44, 8, "SAbandon");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str45, 6, "(SRec ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str46, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str47, 6, "(SFix ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str48, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str49, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str50, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str51, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str52, 11, "(SImplicit ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str53, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str54, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str55, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str56, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str57, 7, "(SPrim ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str58, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str59, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str60, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str61, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str62, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str63, 12, "(A.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str64, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str65, 10, "(SMetaApp ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str66, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str67, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str68, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str69, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str70, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str71, 9, "(SLitInt ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str72, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str73, 11, "(SLitFloat ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str74, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str75, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str76, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str77, 12, "(SLitString ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str78, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str79, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str80, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str81, 10, "(SLitRune ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str82, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str83, 2, "I8");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str84, 3, "I16");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str85, 3, "I32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str86, 3, "I64");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str87, 2, "U8");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str88, 3, "U16");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str89, 3, "U32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str90, 3, "U64");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str91, 3, "F32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str92, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str93, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str94, 11, "(SLitFixed ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str95, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str96, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str97, 13, "(SLitFloat32 ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str98, 1, ")");
Clo g_heff_2eelab_2eprint_2eshowTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2eshowTermF_entry, 2, 0};

V g_heff_2eelab_2eprint_2eshowTermF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SLocal: {
    V v_i_242 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    V v_t_245;
    if (heff_intLt_c(heff_dup(v_i_242), MK_INT(0LL))) {
      V v_t_244 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_i_242)));
      v_t_245 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str0), heff_strAppend(v_t_244, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str1)));
    } else {
      v_t_245 = heff_intShow(heff_dup(v_i_242));
    }
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str2), heff_strAppend(v_t_245, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str3)));
  }
  case TAG_SGlobal: {
    V v_x_246 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    V v_t_247 = (g_heff_2eelab_2eprint_2eescFrom(heff_dup(v_x_246), MK_INT(0LL)));
    V v_t_248 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str4), heff_strAppend(v_t_247, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str5)));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str6), heff_strAppend(v_t_248, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str7)));
  }
  case TAG_SCode: {
    V v_a_249 = heff_field(v_x2_241, 0);
    V v_t_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){heff_dup(v_a_249)}));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str8), heff_strAppend(v_t_2410, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str9)));
  }
  case TAG_SApp: {
    V v_f_2411 = heff_field(v_x2_241, 0);
    V v_a_2412 = heff_field(v_x2_241, 1);
    V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){heff_dup(v_f_2411)}));
    V v_t_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_a_2412)}));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str10), heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str11), heff_strAppend(v_t_2414, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str12)))));
  }
  case TAG_SLam: {
    V v_a_2415 = heff_field(v_x2_241, 0);
    V v_b_2416 = heff_field(v_x2_241, 1);
    V v_t_2417 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 1, (V[]){heff_dup(v_a_2415)}));
    V v_t_2418 = (g_heff_2eelab_2eprint_2eabsOf(heff_get_n(v_r_240, 0, 2), v_b_2416));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str13), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str14), heff_strAppend(v_t_2418, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str15)))));
  }
  case TAG_SCons: {
    V v_d_2419 = heff_field(v_x2_241, 0);
    V v_t_2420 = (g_heff_2eelab_2eprint_2edictOf(heff_get_n(v_r_240, 0, 2), heff_dup(v_d_2419)));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str16), heff_strAppend(v_t_2420, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str17)));
  }
  case TAG_SProj: {
    V v_t_2421 = heff_field(v_x2_241, 0);
    V v_x_2422 = heff_field(v_x2_241, 1);
    V v_t_2423 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2421)}));
    V v_t_2424 = (g_heff_2eelab_2eprint_2eescFrom(heff_dup(v_x_2422), MK_INT(0LL)));
    V v_t_2425 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str18), heff_strAppend(v_t_2424, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str19)));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str20), heff_strAppend(v_t_2423, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str21), heff_strAppend(v_t_2425, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str22)))));
  }
  case TAG_STag: {
    V v_x_2426 = heff_field(v_x2_241, 0);
    V v_ts_2427 = heff_field(v_x2_241, 1);
    V v_t_2428 = (g_heff_2eelab_2eprint_2eescFrom(heff_dup(v_x_2426), MK_INT(0LL)));
    V v_t_2429 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str23), heff_strAppend(v_t_2428, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str24)));
    V v_xs_2430 = (g_list_2emap(heff_get_n(v_r_240, 0, 2), heff_arrayToList(heff_dup(v_ts_2427))));
    V v_t_2431 = ({ V a_0 = v_xs_2430; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2430); r_; });
    V v_t_2432 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str25), heff_strAppend(v_t_2431, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str26)));
    V v_t_2433 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str27), heff_strAppend(v_t_2432, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str28)));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str29), heff_strAppend(v_t_2429, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str30), heff_strAppend(v_t_2433, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str31)))));
  }
  case TAG_SMatch: {
    V v_t_2434 = heff_field(v_x2_241, 0);
    V v_arms_2435 = heff_field(v_x2_241, 1);
    V v_t_2436 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){heff_dup(v_t_2434)}));
    V v_t_2437 = heff_tr(heff_call(((V)&g_heff_2eelab_2eprint_2earmOf_clo), 1, (V[]){v_r_240}));
    V v_t_2438 = (g_heff_2eelab_2eprint_2edictOf(v_t_2437, heff_dup(v_arms_2435)));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str32), heff_strAppend(v_t_2436, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str33), heff_strAppend(v_t_2438, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str34)))));
  }
  case TAG_SSpecialize: {
    V v_t_2439 = heff_field(v_x2_241, 0);
    V v_x_2440 = heff_field(v_x2_241, 1);
    V v_t_27_2441 = heff_field(v_x2_241, 2);
    V v_t_2442 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){heff_dup(v_t_2439)}));
    V v_t_2443 = (g_heff_2eelab_2eprint_2eescFrom(heff_dup(v_x_2440), MK_INT(0LL)));
    V v_t_2444 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str35), heff_strAppend(v_t_2443, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str36)));
    V v_t_2445 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_27_2441)}));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str37), heff_strAppend(v_t_2442, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str38), heff_strAppend(v_t_2444, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str39), heff_strAppend(v_t_2445, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str40)))))));
  }
  case TAG_SIs: {
    V v_t_2446 = heff_field(v_x2_241, 0);
    V v_t_2447 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2446)}));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str41), heff_strAppend(v_t_2447, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str42)));
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    return ((V)&g_heff_2eelab_2eprint_2eshowTermF_str43);
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    return ((V)&g_heff_2eelab_2eprint_2eshowTermF_str44);
  }
  case TAG_SRec: {
    V v_t_2448 = heff_field(v_x2_241, 0);
    V v_t_2449 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2448)}));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str45), heff_strAppend(v_t_2449, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str46)));
  }
  case TAG_SFix: {
    V v_a_2450 = heff_field(v_x2_241, 0);
    V v_b_2451 = heff_field(v_x2_241, 1);
    V v_t_2452 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 1, (V[]){heff_dup(v_a_2450)}));
    V v_t_2453 = (g_heff_2eelab_2eprint_2eabsOf(heff_get_n(v_r_240, 0, 2), v_b_2451));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str47), heff_strAppend(v_t_2452, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str48), heff_strAppend(v_t_2453, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str49)))));
  }
  case TAG_SImplicit: {
    V v_x_2454 = heff_field(v_x2_241, 0);
    V v_t_2455 = heff_field(v_x2_241, 1);
    V v_t_2456 = (g_heff_2eelab_2eprint_2eescFrom(heff_dup(v_x_2454), MK_INT(0LL)));
    V v_t_2457 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str50), heff_strAppend(v_t_2456, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str51)));
    V v_t_2458 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2455)}));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str52), heff_strAppend(v_t_2457, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str53), heff_strAppend(v_t_2458, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str54)))));
  }
  case TAG_SPrim: {
    V v_x_2459 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    V v_t_2460 = (g_heff_2eelab_2eprint_2eescFrom(heff_dup(v_x_2459), MK_INT(0LL)));
    V v_t_2461 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str55), heff_strAppend(v_t_2460, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str56)));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str57), heff_strAppend(v_t_2461, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str58)));
  }
  case TAG_SMetaApp: {
    V v_m_2462 = heff_field(v_x2_241, 0);
    V v_idxs_2463 = heff_field(v_x2_241, 1);
    V v_a_2464 = heff_field(v_x2_241, 2);
    V v_t_2467;
    if (heff_intLt_c(heff_dup(v_m_2462), MK_INT(0LL))) {
      V v_t_2466 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_m_2462)));
      v_t_2467 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str59), heff_strAppend(v_t_2466, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str60)));
    } else {
      v_t_2467 = heff_intShow(heff_dup(v_m_2462));
    }
    V v_xs_2468 = (g_list_2emap_24s1181937096x2120532116(heff_arrayToList(heff_dup(v_idxs_2463))));
    V v_t_2469 = ({ V a_0 = v_xs_2468; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2468); r_; });
    V v_t_2470 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str61), heff_strAppend(v_t_2469, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str62)));
    V v_t_2471 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str63), heff_strAppend(v_t_2470, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str64)));
    V v_t_2472 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){heff_dup(v_a_2464)}));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str65), heff_strAppend(v_t_2467, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str66), heff_strAppend(v_t_2471, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str67), heff_strAppend(v_t_2472, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str68)))))));
  }
  case TAG_SLitInt: {
    V v_n_2473 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    V v_t_2476;
    if (heff_intLt_c(heff_dup(v_n_2473), MK_INT(0LL))) {
      V v_t_2475 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_n_2473)));
      v_t_2476 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str69), heff_strAppend(v_t_2475, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str70)));
    } else {
      v_t_2476 = heff_intShow(heff_dup(v_n_2473));
    }
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str71), heff_strAppend(v_t_2476, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str72)));
  }
  case TAG_SLitFloat: {
    V v_x_2477 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str73), heff_strAppend(heff_floatShow(heff_dup(v_x_2477)), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str74)));
  }
  case TAG_SLitString: {
    V v_s_2478 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    V v_t_2479 = (g_heff_2eelab_2eprint_2eescFrom(heff_dup(v_s_2478), MK_INT(0LL)));
    V v_t_2480 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str75), heff_strAppend(v_t_2479, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str76)));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str77), heff_strAppend(v_t_2480, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str78)));
  }
  case TAG_SLitRune: {
    V v_c_2481 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    V v_t_2484;
    if (heff_intLt_c(heff_dup(v_c_2481), MK_INT(0LL))) {
      V v_t_2483 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_c_2481)));
      v_t_2484 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str79), heff_strAppend(v_t_2483, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str80)));
    } else {
      v_t_2484 = heff_intShow(heff_dup(v_c_2481));
    }
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str81), heff_strAppend(v_t_2484, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str82)));
  }
  case TAG_SLitFixed: {
    V v_w_2485 = heff_field(v_x2_241, 0);
    V v_n_2486 = heff_field(v_x2_241, 1);
    heff_drop_rec(v_r_240, 2);
    V v_t_2487;
    switch (heff_tag_of(v_w_2485)) {
    case TAG_I8: {
      v_t_2487 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_str83);
      break;
    }
    case TAG_I16: {
      v_t_2487 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_str84);
      break;
    }
    case TAG_I32: {
      v_t_2487 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_str85);
      break;
    }
    case TAG_I64: {
      v_t_2487 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_str86);
      break;
    }
    case TAG_U8: {
      v_t_2487 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_str87);
      break;
    }
    case TAG_U16: {
      v_t_2487 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_str88);
      break;
    }
    case TAG_U32: {
      v_t_2487 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_str89);
      break;
    }
    case TAG_U64: {
      v_t_2487 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_str90);
      break;
    }
    case TAG_F32: {
      v_t_2487 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_str91);
      break;
    }
    default: heff_nomatch(v_w_2485);
    }
    V v_t_2490;
    if (heff_intLt_c(heff_dup(v_n_2486), MK_INT(0LL))) {
      V v_t_2489 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_n_2486)));
      v_t_2490 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str92), heff_strAppend(v_t_2489, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str93)));
    } else {
      v_t_2490 = heff_intShow(heff_dup(v_n_2486));
    }
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str94), heff_strAppend(v_t_2487, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str95), heff_strAppend(v_t_2490, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str96)))));
  }
  case TAG_SLitFloat32: {
    V v_x_2491 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str97), heff_strAppend(heff_floatShow(heff_dup(v_x_2491)), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str98)));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eprint_2eshowTermF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eprint_2eshowTermF(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str0, 6, "SmallU");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str1, 6, "LargeU");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str2, 4, "(SU ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str3, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str4, 9, "(SDecode ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str5, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str6, 5, "Small");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str7, 5, "Large");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str8, 4, "TopL");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str9, 4, "Expl");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str10, 4, "Impl");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str11, 4, "Inst");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str12, 8, " Nothing");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str13, 7, " (Just ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str14, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str15, 11, "(SFunction ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str16, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str17, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str18, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str19, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str20, 5, "Small");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str21, 5, "Large");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str22, 4, "TopL");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str23, 9, "(SRecord ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str24, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str25, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str26, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str27, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str28, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str29, 12, "(A.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str30, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str31, 6, "(SSum ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str32, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str33, 7, "(SIsTy ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str34, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str35, 8, "SPrimInt");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str36, 10, "SPrimFloat");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str37, 11, "SPrimString");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str38, 9, "SPrimRune");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str39, 12, "(SPrimArray ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str40, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str41, 2, "I8");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str42, 3, "I16");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str43, 3, "I32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str44, 3, "I64");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str45, 2, "U8");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str46, 3, "U16");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str47, 3, "U32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str48, 3, "U64");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str49, 3, "F32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str50, 8, "(SFixed ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str51, 1, ")");
V g_heff_2eelab_2eprint_2eshowTypeF_lam0(V self, V *args);
Clo g_heff_2eelab_2eprint_2eshowTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2eshowTypeF_entry, 2, 0};

V g_heff_2eelab_2eprint_2eshowTypeF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SU: {
    V v_u_242 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    V v_t_243;
    switch (heff_tag_of(v_u_242)) {
    case TAG_SmallU: {
      v_t_243 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str0);
      break;
    }
    case TAG_LargeU: {
      v_t_243 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str1);
      break;
    }
    default: heff_nomatch(v_u_242);
    }
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str2), heff_strAppend(v_t_243, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str3)));
  }
  case TAG_SDecode: {
    V v_t_244 = heff_field(v_x2_241, 0);
    V v_t_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_244)}));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str4), heff_strAppend(v_t_245, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str5)));
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_x2_241, 0);
    V v_dom_247 = heff_field(v_x2_241, 1);
    V v_cod_248 = heff_field(v_x2_241, 2);
    V v_implicit_249 = heff_field(v_x2_241, 3);
    V v_dflt_2410 = heff_field(v_x2_241, 4);
    V v_t_2411;
    switch (heff_tag_of(v_level_246)) {
    case TAG_Small: {
      v_t_2411 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str6);
      break;
    }
    case TAG_Large: {
      v_t_2411 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str7);
      break;
    }
    case TAG_TopL: {
      v_t_2411 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str8);
      break;
    }
    default: heff_nomatch(v_level_246);
    }
    V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_dom_247)}));
    V v_t_2413 = (g_heff_2eelab_2eprint_2eabsOf(heff_take_field(v_r_240, 1), v_cod_248));
    V v_t_2414;
    switch (heff_tag_of(v_implicit_249)) {
    case TAG_Expl: {
      v_t_2414 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str9);
      break;
    }
    case TAG_Impl: {
      v_t_2414 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str10);
      break;
    }
    case TAG_Inst: {
      v_t_2414 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str11);
      break;
    }
    default: heff_nomatch(v_implicit_249);
    }
    V v_t_2417;
    switch (heff_tag_of(v_dflt_2410)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 2);
      v_t_2417 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str12);
      break;
    }
    case TAG_Just: {
      V v_d_2415 = heff_field(v_dflt_2410, 0);
      V v_t_2416 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_d_2415)}));
      v_t_2417 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str13), heff_strAppend(v_t_2416, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str14)));
      break;
    }
    default: heff_nomatch(v_dflt_2410);
    }
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str15), heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str16), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str17), heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str18), heff_strAppend(v_t_2414, heff_strAppend(v_t_2417, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str19))))))))));
  }
  case TAG_SRecord: {
    V v_level_2418 = heff_field(v_x2_241, 0);
    V v_fieldTypes_2419 = heff_field(v_x2_241, 1);
    V v_defaults_2420 = heff_field(v_x2_241, 2);
    V v_t_2421;
    switch (heff_tag_of(v_level_2418)) {
    case TAG_Small: {
      v_t_2421 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str20);
      break;
    }
    case TAG_Large: {
      v_t_2421 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str21);
      break;
    }
    case TAG_TopL: {
      v_t_2421 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str22);
      break;
    }
    default: heff_nomatch(v_level_2418);
    }
    V v_t_2422 = (g_heff_2eelab_2eprint_2edictOf(heff_take_field(v_r_240, 1), heff_dup(v_fieldTypes_2419)));
    V v_t_2423 = (g_heff_2eelab_2eprint_2edictOf(heff_get_n(v_r_240, 0, 2), heff_dup(v_defaults_2420)));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str23), heff_strAppend(v_t_2421, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str24), heff_strAppend(v_t_2422, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str25), heff_strAppend(v_t_2423, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str26)))))));
  }
  case TAG_SSum: {
    V v_st_2424 = heff_field(v_x2_241, 0);
    V v_t_2429 = (g_heff_2eelab_2eprint_2edictOf(heff_clo_n(g_heff_2eelab_2eprint_2eshowTypeF_lam0, 1, 1, (V[]){v_r_240}), heff_dup(v_st_2424)));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str31), heff_strAppend(v_t_2429, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str32)));
  }
  case TAG_SIsTy: {
    V v_t_2430 = heff_field(v_x2_241, 0);
    V v_t_2431 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){heff_dup(v_t_2430)}));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str33), heff_strAppend(v_t_2431, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str34)));
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    return ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str35);
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    return ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str36);
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    return ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str37);
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    return ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str38);
  }
  case TAG_SPrimArray: {
    V v_a_2432 = heff_field(v_x2_241, 0);
    V v_t_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){heff_dup(v_a_2432)}));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str39), heff_strAppend(v_t_2433, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str40)));
  }
  case TAG_SFixed: {
    V v_w_2434 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    V v_t_2435;
    switch (heff_tag_of(v_w_2434)) {
    case TAG_I8: {
      v_t_2435 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str41);
      break;
    }
    case TAG_I16: {
      v_t_2435 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str42);
      break;
    }
    case TAG_I32: {
      v_t_2435 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str43);
      break;
    }
    case TAG_I64: {
      v_t_2435 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str44);
      break;
    }
    case TAG_U8: {
      v_t_2435 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str45);
      break;
    }
    case TAG_U16: {
      v_t_2435 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str46);
      break;
    }
    case TAG_U32: {
      v_t_2435 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str47);
      break;
    }
    case TAG_U64: {
      v_t_2435 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str48);
      break;
    }
    case TAG_F32: {
      v_t_2435 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str49);
      break;
    }
    default: heff_nomatch(v_w_2434);
    }
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str50), heff_strAppend(v_t_2435, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str51)));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eprint_2eshowTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eprint_2eshowTypeF(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2eprint_2eshowTypeF_lam0(V self, V *args) {
  V v_xs_2425 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_2426 = (g_list_2emap(heff_get_n(v_r_240, 1, 2), heff_arrayToList(v_xs_2425)));
  V v_t_2427 = ({ V a_0 = v_xs_2426; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2426); r_; });
  V v_t_2428 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str27), heff_strAppend(v_t_2427, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str28)));
  return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str29), heff_strAppend(v_t_2428, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str30)));
}
V g_heff_2eelab_2eprint_2epr_lam0(V self, V *args); static Clo g_heff_2eelab_2eprint_2epr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2epr_lam0, 1, 0};
V g_heff_2eelab_2eprint_2epr_lam1(V self, V *args); static Clo g_heff_2eelab_2eprint_2epr_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2epr_lam1, 1, 0};

static V g_heff_2eelab_2eprint_2epr_val;
static HEFF_ONCE g_heff_2eelab_2eprint_2epr_st;
static V g_heff_2eelab_2eprint_2epr_init(void) {
  return heff_rec_n(2, shape_el__ty, (V[]){((V)&g_heff_2eelab_2eprint_2epr_lam0_clo), ((V)&g_heff_2eelab_2eprint_2epr_lam1_clo)});
}
V g_heff_2eelab_2eprint_2epr_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eprint_2epr_st)) return g_heff_2eelab_2eprint_2epr_val;
  return heff_global(&g_heff_2eelab_2eprint_2epr_val, &g_heff_2eelab_2eprint_2epr_st, g_heff_2eelab_2eprint_2epr_init);
}
V g_heff_2eelab_2eprint_2epr_lam0(V self, V *args) {
  V v_t_240 = args[0];
  return ({ V a_0 = heff_dup(g_heff_2eelab_2eprint_2epr_get()); V a_1 = v_t_240; V r_ = (g_heff_2eelab_2eprint_2eshowTermF(a_0, a_1)); heff_drop(v_t_240); r_; });
}
V g_heff_2eelab_2eprint_2epr_lam1(V self, V *args) {
  V v_t_241 = args[0];
  return ({ V a_0 = heff_dup(g_heff_2eelab_2eprint_2epr_get()); V a_1 = v_t_241; V r_ = (g_heff_2eelab_2eprint_2eshowTypeF(a_0, a_1)); heff_drop(v_t_241); r_; });
}
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str0, 6, "SmallU");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str1, 6, "LargeU");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str2, 4, "(SU ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str3, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str4, 9, "(SDecode ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str5, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str6, 5, "Small");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str7, 5, "Large");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str8, 4, "TopL");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str9, 4, "Expl");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str10, 4, "Impl");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str11, 4, "Inst");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str12, 8, " Nothing");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str13, 7, " (Just ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str14, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str15, 11, "(SFunction ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str16, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str17, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str18, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str19, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str20, 5, "Small");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str21, 5, "Large");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str22, 4, "TopL");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str23, 8, "(MkPair ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str24, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str25, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str26, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str27, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str28, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str29, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str30, 12, "(D.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str31, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str32, 8, "(MkPair ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str33, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str34, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str35, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str36, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str37, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str38, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str39, 12, "(D.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str40, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str41, 9, "(SRecord ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str42, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str43, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str44, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str45, 8, "(MkPair ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str46, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str47, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str48, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str49, 12, "(A.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str50, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str51, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str52, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str53, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str54, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str55, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str56, 12, "(D.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str57, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str58, 6, "(SSum ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str59, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str60, 7, "(SIsTy ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str61, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str62, 8, "SPrimInt");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str63, 10, "SPrimFloat");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str64, 11, "SPrimString");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str65, 9, "SPrimRune");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str66, 12, "(SPrimArray ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str67, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str68, 2, "I8");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str69, 3, "I16");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str70, 3, "I32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str71, 3, "I64");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str72, 2, "U8");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str73, 3, "U16");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str74, 3, "U32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str75, 3, "U64");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str76, 3, "F32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str77, 8, "(SFixed ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str78, 1, ")");
Clo g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry, 1, 0};

V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SU: {
    V v_u_241 = heff_field(v_x2_240, 0);
    V v_t_242;
    switch (heff_tag_of(v_u_241)) {
    case TAG_SmallU: {
      v_t_242 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str0);
      break;
    }
    case TAG_LargeU: {
      v_t_242 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str1);
      break;
    }
    default: heff_nomatch(v_u_241);
    }
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str2), heff_strAppend(v_t_242, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str3)));
  }
  case TAG_SDecode: {
    V v_t_243 = heff_field(v_x2_240, 0);
    V v_t_244 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_t_243));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str4), heff_strAppend(v_t_244, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str5)));
  }
  case TAG_SFunction: {
    V v_level_245 = heff_field(v_x2_240, 0);
    V v_dom_246 = heff_field(v_x2_240, 1);
    V v_cod_247 = heff_field(v_x2_240, 2);
    V v_implicit_248 = heff_field(v_x2_240, 3);
    V v_dflt_249 = heff_field(v_x2_240, 4);
    V v_t_2410;
    switch (heff_tag_of(v_level_245)) {
    case TAG_Small: {
      v_t_2410 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str6);
      break;
    }
    case TAG_Large: {
      v_t_2410 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str7);
      break;
    }
    case TAG_TopL: {
      v_t_2410 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str8);
      break;
    }
    default: heff_nomatch(v_level_245);
    }
    V v_t_2411 = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(v_dom_246));
    V v_t_2412 = (g_heff_2eelab_2eprint_2eabsOf(heff_dup(heff_rfield(g_heff_2eelab_2eprint_2epr_get(), 1)), v_cod_247));
    V v_t_2413;
    switch (heff_tag_of(v_implicit_248)) {
    case TAG_Expl: {
      v_t_2413 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str9);
      break;
    }
    case TAG_Impl: {
      v_t_2413 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str10);
      break;
    }
    case TAG_Inst: {
      v_t_2413 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str11);
      break;
    }
    default: heff_nomatch(v_implicit_248);
    }
    V v_t_2416;
    switch (heff_tag_of(v_dflt_249)) {
    case TAG_Nothing: {
      v_t_2416 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str12);
      break;
    }
    case TAG_Just: {
      V v_d_2414 = heff_field(v_dflt_249, 0);
      V v_t_2415 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_d_2414));
      v_t_2416 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str13), heff_strAppend(v_t_2415, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str14)));
      break;
    }
    default: heff_nomatch(v_dflt_249);
    }
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str15), heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str16), heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str17), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str18), heff_strAppend(v_t_2413, heff_strAppend(v_t_2416, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str19))))))))));
  }
  case TAG_SRecord: {
    V v_level_2417 = heff_field(v_x2_240, 0);
    V v_fieldTypes_2418 = heff_field(v_x2_240, 1);
    V v_defaults_2419 = heff_field(v_x2_240, 2);
    V v_t_2420;
    switch (heff_tag_of(v_level_2417)) {
    case TAG_Small: {
      v_t_2420 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str20);
      break;
    }
    case TAG_Large: {
      v_t_2420 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str21);
      break;
    }
    case TAG_TopL: {
      v_t_2420 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str22);
      break;
    }
    default: heff_nomatch(v_level_2417);
    }
    V v_t_2421 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2418, 0)));
    V v_t_2422 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2418, 2)));
    V v_t_2423 = (g_heff_2eutil_2edict_2ezipKV(v_t_2421, v_t_2422));
    V v_xs_2424 = (g_list_2emap_24s1646944445x1684083181(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str23), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str24), MK_INT(0LL), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str25), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str26), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str27), v_t_2423));
    V v_t_2425 = ({ V a_0 = v_xs_2424; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2424); r_; });
    V v_t_2426 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str28), heff_strAppend(v_t_2425, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str29)));
    V v_t_2427 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str30), heff_strAppend(v_t_2426, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str31)));
    V v_t_2428 = heff_arrayToList(heff_dup(heff_rfield(v_defaults_2419, 0)));
    V v_t_2429 = heff_arrayToList(heff_dup(heff_rfield(v_defaults_2419, 2)));
    V v_t_2430 = (g_heff_2eutil_2edict_2ezipKV(v_t_2428, v_t_2429));
    V v_xs_2431 = (g_list_2emap_24s846355817x1552148381(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str32), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str33), MK_INT(0LL), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str34), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str35), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str36), v_t_2430));
    V v_t_2432 = ({ V a_0 = v_xs_2431; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2431); r_; });
    V v_t_2433 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str37), heff_strAppend(v_t_2432, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str38)));
    V v_t_2434 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str39), heff_strAppend(v_t_2433, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str40)));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str41), heff_strAppend(v_t_2420, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str42), heff_strAppend(v_t_2427, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str43), heff_strAppend(v_t_2434, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str44)))))));
  }
  case TAG_SSum: {
    V v_st_2435 = heff_field(v_x2_240, 0);
    V v_t_2436 = heff_arrayToList(heff_dup(heff_rfield(v_st_2435, 0)));
    V v_t_2437 = heff_arrayToList(heff_dup(heff_rfield(v_st_2435, 2)));
    V v_t_2438 = (g_heff_2eutil_2edict_2ezipKV(v_t_2436, v_t_2437));
    V v_xs_2439 = (g_list_2emap_24s1201815197x1377530874(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str45), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str46), MK_INT(0LL), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str47), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str48), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str49), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str50), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str51), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str52), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str53), v_t_2438));
    V v_t_2440 = ({ V a_0 = v_xs_2439; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2439); r_; });
    V v_t_2441 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str54), heff_strAppend(v_t_2440, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str55)));
    V v_t_2442 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str56), heff_strAppend(v_t_2441, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str57)));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str58), heff_strAppend(v_t_2442, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str59)));
  }
  case TAG_SIsTy: {
    V v_t_2443 = heff_field(v_x2_240, 0);
    V v_t_2444 = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(v_t_2443));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str60), heff_strAppend(v_t_2444, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str61)));
  }
  case TAG_SPrimInt: {
    return ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str62);
  }
  case TAG_SPrimFloat: {
    return ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str63);
  }
  case TAG_SPrimString: {
    return ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str64);
  }
  case TAG_SPrimRune: {
    return ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str65);
  }
  case TAG_SPrimArray: {
    V v_a_2445 = heff_field(v_x2_240, 0);
    V v_t_2446 = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(v_a_2445));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str66), heff_strAppend(v_t_2446, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str67)));
  }
  case TAG_SFixed: {
    V v_w_2447 = heff_field(v_x2_240, 0);
    V v_t_2448;
    switch (heff_tag_of(v_w_2447)) {
    case TAG_I8: {
      v_t_2448 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str68);
      break;
    }
    case TAG_I16: {
      v_t_2448 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str69);
      break;
    }
    case TAG_I32: {
      v_t_2448 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str70);
      break;
    }
    case TAG_I64: {
      v_t_2448 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str71);
      break;
    }
    case TAG_U8: {
      v_t_2448 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str72);
      break;
    }
    case TAG_U16: {
      v_t_2448 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str73);
      break;
    }
    case TAG_U32: {
      v_t_2448 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str74);
      break;
    }
    case TAG_U64: {
      v_t_2448 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str75);
      break;
    }
    case TAG_F32: {
      v_t_2448 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str76);
      break;
    }
    default: heff_nomatch(v_w_2447);
    }
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str77), heff_strAppend(v_t_2448, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str78)));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_str0, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_str1, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_str2, 12, "(A.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_str3, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_str4, 8, "(MkPair ");
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_str5, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_str6, 1, ")");
Clo g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_entry, 1, 0};

V g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_MkPair: {
    V v_xs_241 = heff_field(v_x2_240, 0);
    V v_b_242 = heff_field(v_x2_240, 1);
    V v_xs_243 = (g_list_2emap_24s1397747289x2145601499(heff_arrayToList(heff_dup(v_xs_241))));
    V v_t_244 = ({ V a_0 = v_xs_243; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_243); r_; });
    V v_t_245 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_str0), heff_strAppend(v_t_244, ((V)&g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_str1)));
    V v_t_246 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_str2), heff_strAppend(v_t_245, ((V)&g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_str3)));
    V v_t_247 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_b_242));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_str4), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_str5), heff_strAppend(v_t_247, ((V)&g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_str6)))));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str0, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str1, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str2, 8, "(SLocal ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str3, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str4, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str5, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str6, 9, "(SGlobal ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str7, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str8, 7, "(SCode ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str9, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str10, 6, "(SApp ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str11, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str12, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str13, 6, "(SLam ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str14, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str15, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str16, 8, "(MkPair ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str17, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str18, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str19, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str20, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str21, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str22, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str23, 12, "(D.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str24, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str25, 7, "(SCons ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str26, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str27, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str28, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str29, 7, "(SProj ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str30, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str31, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str32, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str33, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str34, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str35, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str36, 12, "(A.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str37, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str38, 6, "(STag ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str39, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str40, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str41, 8, "(MkPair ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str42, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str43, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str44, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str45, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str46, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str47, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str48, 12, "(D.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str49, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str50, 8, "(SMatch ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str51, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str52, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str53, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str54, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str55, 13, "(SSpecialize ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str56, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str57, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str58, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str59, 5, "(SIs ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str60, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str61, 7, "SOpaque");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str62, 8, "SAbandon");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str63, 6, "(SRec ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str64, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str65, 6, "(SFix ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str66, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str67, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str68, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str69, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str70, 11, "(SImplicit ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str71, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str72, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str73, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str74, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str75, 7, "(SPrim ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str76, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str77, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str78, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str79, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str80, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str81, 12, "(A.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str82, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str83, 10, "(SMetaApp ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str84, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str85, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str86, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str87, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str88, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str89, 9, "(SLitInt ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str90, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str91, 11, "(SLitFloat ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str92, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str93, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str94, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str95, 12, "(SLitString ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str96, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str97, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str98, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str99, 10, "(SLitRune ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str100, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str101, 2, "I8");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str102, 3, "I16");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str103, 3, "I32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str104, 3, "I64");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str105, 2, "U8");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str106, 3, "U16");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str107, 3, "U32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str108, 3, "U64");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str109, 3, "F32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str110, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str111, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str112, 11, "(SLitFixed ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str113, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str114, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str115, 13, "(SLitFloat32 ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str116, 1, ")");
Clo g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry, 1, 0};

V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SLocal: {
    V v_i_241 = heff_field(v_x2_240, 0);
    V v_t_244;
    if (heff_intLt_c(heff_dup(v_i_241), MK_INT(0LL))) {
      V v_t_243 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_i_241)));
      v_t_244 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str0), heff_strAppend(v_t_243, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str1)));
    } else {
      v_t_244 = heff_intShow(heff_dup(v_i_241));
    }
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str2), heff_strAppend(v_t_244, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str3)));
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_t_246 = (g_heff_2eelab_2eprint_2eescFrom(heff_dup(v_x_245), MK_INT(0LL)));
    V v_t_247 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str4), heff_strAppend(v_t_246, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str5)));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str6), heff_strAppend(v_t_247, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str7)));
  }
  case TAG_SCode: {
    V v_a_248 = heff_field(v_x2_240, 0);
    V v_t_249 = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(v_a_248));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str8), heff_strAppend(v_t_249, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str9)));
  }
  case TAG_SApp: {
    V v_f_2410 = heff_field(v_x2_240, 0);
    V v_a_2411 = heff_field(v_x2_240, 1);
    V v_t_2412 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_f_2410));
    V v_t_2413 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_a_2411));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str10), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str11), heff_strAppend(v_t_2413, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str12)))));
  }
  case TAG_SLam: {
    V v_a_2414 = heff_field(v_x2_240, 0);
    V v_b_2415 = heff_field(v_x2_240, 1);
    V v_t_2416 = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(v_a_2414));
    V v_t_2417 = (g_heff_2eelab_2eprint_2eabsOf(heff_dup(heff_rfield(g_heff_2eelab_2eprint_2epr_get(), 0)), v_b_2415));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str13), heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str14), heff_strAppend(v_t_2417, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str15)))));
  }
  case TAG_SCons: {
    V v_d_2418 = heff_field(v_x2_240, 0);
    V v_t_2419 = heff_arrayToList(heff_dup(heff_rfield(v_d_2418, 0)));
    V v_t_2420 = heff_arrayToList(heff_dup(heff_rfield(v_d_2418, 2)));
    V v_t_2421 = (g_heff_2eutil_2edict_2ezipKV(v_t_2419, v_t_2420));
    V v_xs_2422 = (g_list_2emap_24s846355817x1552148381(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str16), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str17), MK_INT(0LL), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str18), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str19), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str20), v_t_2421));
    V v_t_2423 = ({ V a_0 = v_xs_2422; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2422); r_; });
    V v_t_2424 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str21), heff_strAppend(v_t_2423, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str22)));
    V v_t_2425 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str23), heff_strAppend(v_t_2424, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str24)));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str25), heff_strAppend(v_t_2425, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str26)));
  }
  case TAG_SProj: {
    V v_t_2426 = heff_field(v_x2_240, 0);
    V v_x_2427 = heff_field(v_x2_240, 1);
    V v_t_2428 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_t_2426));
    V v_t_2429 = (g_heff_2eelab_2eprint_2eescFrom(heff_dup(v_x_2427), MK_INT(0LL)));
    V v_t_2430 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str27), heff_strAppend(v_t_2429, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str28)));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str29), heff_strAppend(v_t_2428, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str30), heff_strAppend(v_t_2430, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str31)))));
  }
  case TAG_STag: {
    V v_x_2431 = heff_field(v_x2_240, 0);
    V v_ts_2432 = heff_field(v_x2_240, 1);
    V v_t_2433 = (g_heff_2eelab_2eprint_2eescFrom(heff_dup(v_x_2431), MK_INT(0LL)));
    V v_t_2434 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str32), heff_strAppend(v_t_2433, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str33)));
    V v_xs_2435 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2eelab_2eprint_2epr_get(), 0)), heff_arrayToList(heff_dup(v_ts_2432))));
    V v_t_2436 = ({ V a_0 = v_xs_2435; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2435); r_; });
    V v_t_2437 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str34), heff_strAppend(v_t_2436, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str35)));
    V v_t_2438 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str36), heff_strAppend(v_t_2437, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str37)));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str38), heff_strAppend(v_t_2434, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str39), heff_strAppend(v_t_2438, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str40)))));
  }
  case TAG_SMatch: {
    V v_t_2439 = heff_field(v_x2_240, 0);
    V v_arms_2440 = heff_field(v_x2_240, 1);
    V v_t_2441 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_t_2439));
    V v_t_2442 = heff_arrayToList(heff_dup(heff_rfield(v_arms_2440, 0)));
    V v_t_2443 = heff_arrayToList(heff_dup(heff_rfield(v_arms_2440, 2)));
    V v_t_2444 = (g_heff_2eutil_2edict_2ezipKV(v_t_2442, v_t_2443));
    V v_xs_2445 = (g_list_2emap_24s500158289x1934493753(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str41), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str42), MK_INT(0LL), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str43), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str44), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str45), v_t_2444));
    V v_t_2446 = ({ V a_0 = v_xs_2445; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2445); r_; });
    V v_t_2447 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str46), heff_strAppend(v_t_2446, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str47)));
    V v_t_2448 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str48), heff_strAppend(v_t_2447, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str49)));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str50), heff_strAppend(v_t_2441, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str51), heff_strAppend(v_t_2448, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str52)))));
  }
  case TAG_SSpecialize: {
    V v_t_2449 = heff_field(v_x2_240, 0);
    V v_x_2450 = heff_field(v_x2_240, 1);
    V v_t_27_2451 = heff_field(v_x2_240, 2);
    V v_t_2452 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_t_2449));
    V v_t_2453 = (g_heff_2eelab_2eprint_2eescFrom(heff_dup(v_x_2450), MK_INT(0LL)));
    V v_t_2454 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str53), heff_strAppend(v_t_2453, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str54)));
    V v_t_2455 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_t_27_2451));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str55), heff_strAppend(v_t_2452, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str56), heff_strAppend(v_t_2454, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str57), heff_strAppend(v_t_2455, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str58)))))));
  }
  case TAG_SIs: {
    V v_t_2456 = heff_field(v_x2_240, 0);
    V v_t_2457 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_t_2456));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str59), heff_strAppend(v_t_2457, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str60)));
  }
  case TAG_SOpaque: {
    return ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str61);
  }
  case TAG_SAbandon: {
    return ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str62);
  }
  case TAG_SRec: {
    V v_t_2458 = heff_field(v_x2_240, 0);
    V v_t_2459 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_t_2458));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str63), heff_strAppend(v_t_2459, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str64)));
  }
  case TAG_SFix: {
    V v_a_2460 = heff_field(v_x2_240, 0);
    V v_b_2461 = heff_field(v_x2_240, 1);
    V v_t_2462 = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(v_a_2460));
    V v_t_2463 = (g_heff_2eelab_2eprint_2eabsOf(heff_dup(heff_rfield(g_heff_2eelab_2eprint_2epr_get(), 0)), v_b_2461));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str65), heff_strAppend(v_t_2462, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str66), heff_strAppend(v_t_2463, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str67)))));
  }
  case TAG_SImplicit: {
    V v_x_2464 = heff_field(v_x2_240, 0);
    V v_t_2465 = heff_field(v_x2_240, 1);
    V v_t_2466 = (g_heff_2eelab_2eprint_2eescFrom(heff_dup(v_x_2464), MK_INT(0LL)));
    V v_t_2467 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str68), heff_strAppend(v_t_2466, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str69)));
    V v_t_2468 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_t_2465));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str70), heff_strAppend(v_t_2467, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str71), heff_strAppend(v_t_2468, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str72)))));
  }
  case TAG_SPrim: {
    V v_x_2469 = heff_field(v_x2_240, 0);
    V v_t_2470 = (g_heff_2eelab_2eprint_2eescFrom(heff_dup(v_x_2469), MK_INT(0LL)));
    V v_t_2471 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str73), heff_strAppend(v_t_2470, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str74)));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str75), heff_strAppend(v_t_2471, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str76)));
  }
  case TAG_SMetaApp: {
    V v_m_2472 = heff_field(v_x2_240, 0);
    V v_idxs_2473 = heff_field(v_x2_240, 1);
    V v_a_2474 = heff_field(v_x2_240, 2);
    V v_t_2477;
    if (heff_intLt_c(heff_dup(v_m_2472), MK_INT(0LL))) {
      V v_t_2476 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_m_2472)));
      v_t_2477 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str77), heff_strAppend(v_t_2476, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str78)));
    } else {
      v_t_2477 = heff_intShow(heff_dup(v_m_2472));
    }
    V v_xs_2478 = (g_list_2emap_24s1181937096x2120532116(heff_arrayToList(heff_dup(v_idxs_2473))));
    V v_t_2479 = ({ V a_0 = v_xs_2478; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2478); r_; });
    V v_t_2480 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str79), heff_strAppend(v_t_2479, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str80)));
    V v_t_2481 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str81), heff_strAppend(v_t_2480, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str82)));
    V v_t_2482 = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(v_a_2474));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str83), heff_strAppend(v_t_2477, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str84), heff_strAppend(v_t_2481, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str85), heff_strAppend(v_t_2482, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str86)))))));
  }
  case TAG_SLitInt: {
    V v_n_2483 = heff_field(v_x2_240, 0);
    V v_t_2486;
    if (heff_intLt_c(heff_dup(v_n_2483), MK_INT(0LL))) {
      V v_t_2485 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_n_2483)));
      v_t_2486 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str87), heff_strAppend(v_t_2485, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str88)));
    } else {
      v_t_2486 = heff_intShow(heff_dup(v_n_2483));
    }
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str89), heff_strAppend(v_t_2486, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str90)));
  }
  case TAG_SLitFloat: {
    V v_x_2487 = heff_field(v_x2_240, 0);
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str91), heff_strAppend(heff_floatShow(heff_dup(v_x_2487)), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str92)));
  }
  case TAG_SLitString: {
    V v_s_2488 = heff_field(v_x2_240, 0);
    V v_t_2489 = (g_heff_2eelab_2eprint_2eescFrom(heff_dup(v_s_2488), MK_INT(0LL)));
    V v_t_2490 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str93), heff_strAppend(v_t_2489, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str94)));
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str95), heff_strAppend(v_t_2490, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str96)));
  }
  case TAG_SLitRune: {
    V v_c_2491 = heff_field(v_x2_240, 0);
    V v_t_2494;
    if (heff_intLt_c(heff_dup(v_c_2491), MK_INT(0LL))) {
      V v_t_2493 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_c_2491)));
      v_t_2494 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str97), heff_strAppend(v_t_2493, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str98)));
    } else {
      v_t_2494 = heff_intShow(heff_dup(v_c_2491));
    }
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str99), heff_strAppend(v_t_2494, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str100)));
  }
  case TAG_SLitFixed: {
    V v_w_2495 = heff_field(v_x2_240, 0);
    V v_n_2496 = heff_field(v_x2_240, 1);
    V v_t_2497;
    switch (heff_tag_of(v_w_2495)) {
    case TAG_I8: {
      v_t_2497 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str101);
      break;
    }
    case TAG_I16: {
      v_t_2497 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str102);
      break;
    }
    case TAG_I32: {
      v_t_2497 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str103);
      break;
    }
    case TAG_I64: {
      v_t_2497 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str104);
      break;
    }
    case TAG_U8: {
      v_t_2497 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str105);
      break;
    }
    case TAG_U16: {
      v_t_2497 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str106);
      break;
    }
    case TAG_U32: {
      v_t_2497 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str107);
      break;
    }
    case TAG_U64: {
      v_t_2497 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str108);
      break;
    }
    case TAG_F32: {
      v_t_2497 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str109);
      break;
    }
    default: heff_nomatch(v_w_2495);
    }
    V v_t_24100;
    if (heff_intLt_c(heff_dup(v_n_2496), MK_INT(0LL))) {
      V v_t_2499 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_n_2496)));
      v_t_24100 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str110), heff_strAppend(v_t_2499, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str111)));
    } else {
      v_t_24100 = heff_intShow(heff_dup(v_n_2496));
    }
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str112), heff_strAppend(v_t_2497, heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str113), heff_strAppend(v_t_24100, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str114)))));
  }
  case TAG_SLitFloat32: {
    V v_x_24101 = heff_field(v_x2_240, 0);
    return heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str115), heff_strAppend(heff_floatShow(heff_dup(v_x_24101)), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str116)));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(a0); heff_drop(a0); return r;
}