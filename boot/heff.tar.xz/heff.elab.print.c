// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9006
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_heff_2eelab_2eprint_2eabsOf(V, V);
V g_heff_2eelab_2eprint_2eabsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eabsOf_clo;
V g_heff_2eelab_2eprint_2earmOf(V, V);
V g_heff_2eelab_2eprint_2earmOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2earmOf_clo;
V g_heff_2eelab_2eprint_2ecommaSep(V);
V g_heff_2eelab_2eprint_2ecommaSep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2ecommaSep_clo;
V g_heff_2eelab_2eprint_2ecommaSep_24acc(V, V);
V g_heff_2eelab_2eprint_2ecommaSep_24acc_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2ecommaSep_24acc_clo;
V g_heff_2eelab_2eprint_2edictOf(V, V);
V g_heff_2eelab_2eprint_2edictOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2edictOf_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2eescFrom_24acc(V, V, V);
V g_heff_2eelab_2eprint_2eescFrom_24acc_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_24acc_clo;
V g_heff_2eelab_2eprint_2epr_get(void);
V g_heff_2eelab_2eprint_2eshowTermF(V, V);
V g_heff_2eelab_2eprint_2eshowTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTermF_clo;
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(V);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_clo;
V g_heff_2eelab_2eprint_2eshowTypeF(V, V);
V g_heff_2eelab_2eprint_2eshowTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTypeF_clo;
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(V);
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1181937096x2120532116(V);
V g_list_2emap_24s1181937096x2120532116_entry(V self, V *a);
extern Clo g_list_2emap_24s1181937096x2120532116_clo;
V g_list_2emap_24s1397747289x2145601499(V);
V g_list_2emap_24s1397747289x2145601499_entry(V self, V *a);
extern Clo g_list_2emap_24s1397747289x2145601499_clo;
V g_list_2emap_24s1839428429x1874782624(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1839428429x1874782624_entry(V self, V *a);
extern Clo g_list_2emap_24s1839428429x1874782624_clo;
V g_list_2emap_24s191715292x1660526539(V, V, V, V, V, V, V);
V g_list_2emap_24s191715292x1660526539_entry(V self, V *a);
extern Clo g_list_2emap_24s191715292x1660526539_clo;
V g_list_2emap_24s323105787x487030640(V, V, V, V, V, V, V);
V g_list_2emap_24s323105787x487030640_entry(V self, V *a);
extern Clo g_list_2emap_24s323105787x487030640_clo;
V g_list_2emap_24s525732339x518706186(V, V, V, V, V, V, V);
V g_list_2emap_24s525732339x518706186_entry(V self, V *a);
extern Clo g_list_2emap_24s525732339x518706186_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_str0, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_str1, 2, "\\\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_str2, 1, "\\");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_str3, 2, "\\\\");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_str4, 1, "\012");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_str5, 2, "\\n");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_str6, 1, "\015");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_str7, 2, "\\r");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_str8, 1, "\011");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_str9, 2, "\\t");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_str10, 0, "");
Clo g_heff_2eelab_2eprint_2eescFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2eescFrom_entry, 2, 0};

V g_heff_2eelab_2eprint_2eescFrom(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((v_i_241 < heff_unbox_word(heff_strLength_lent(v_s_240, 0)))) {
    V v_c_242 = heff_strSlice_lent(v_s_240, heff_box_word(v_i_241), heff_box_word((v_i_241 + ((int64_t)1ULL))), 6);
    V v_t_243;
    if (heff_strEq_c_lent(v_c_242, ((V)&g_heff_2eelab_2eprint_2eescFrom_str0), 2)) {
      heff_drop(v_c_242);
      v_t_243 = ((V)&g_heff_2eelab_2eprint_2eescFrom_str1);
    } else {
      if (heff_strEq_c_lent(v_c_242, ((V)&g_heff_2eelab_2eprint_2eescFrom_str2), 2)) {
        heff_drop(v_c_242);
        v_t_243 = ((V)&g_heff_2eelab_2eprint_2eescFrom_str3);
      } else {
        if (heff_strEq_c_lent(v_c_242, ((V)&g_heff_2eelab_2eprint_2eescFrom_str4), 2)) {
          heff_drop(v_c_242);
          v_t_243 = ((V)&g_heff_2eelab_2eprint_2eescFrom_str5);
        } else {
          if (heff_strEq_c_lent(v_c_242, ((V)&g_heff_2eelab_2eprint_2eescFrom_str6), 2)) {
            heff_drop(v_c_242);
            v_t_243 = ((V)&g_heff_2eelab_2eprint_2eescFrom_str7);
          } else {
            if (heff_strEq_c_lent(v_c_242, ((V)&g_heff_2eelab_2eprint_2eescFrom_str8), 2)) {
              heff_drop(v_c_242);
              v_t_243 = ((V)&g_heff_2eelab_2eprint_2eescFrom_str9);
            } else {
              v_t_243 = v_c_242;
            }
          }
        }
      }
    }
    V v_s_244 = v_t_243;
    return (g_heff_2eelab_2eprint_2eescFrom_24acc(v_s_240, heff_box_word((v_i_241 + ((int64_t)1ULL))), v_s_244));
  } else {
    return ((V)&g_heff_2eelab_2eprint_2eescFrom_str10);
  }
}
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eprint_2eescFrom(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_24acc_str0, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_24acc_str1, 2, "\\\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_24acc_str2, 1, "\\");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_24acc_str3, 2, "\\\\");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_24acc_str4, 1, "\012");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_24acc_str5, 2, "\\n");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_24acc_str6, 1, "\015");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_24acc_str7, 2, "\\r");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_24acc_str8, 1, "\011");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_24acc_str9, 2, "\\t");
HEFF_LIT(g_heff_2eelab_2eprint_2eescFrom_24acc_str10, 0, "");
Clo g_heff_2eelab_2eprint_2eescFrom_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2eescFrom_24acc_entry, 3, 0};

V g_heff_2eelab_2eprint_2eescFrom_24acc(V v_s_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((v_i_241 < heff_unbox_word(heff_strLength_lent(v_s_240, 0)))) {
    V v_c_243 = heff_strSlice_lent(v_s_240, heff_box_word(v_i_241), heff_box_word((v_i_241 + ((int64_t)1ULL))), 6);
    V v_t_244;
    if (heff_strEq_c_lent(v_c_243, ((V)&g_heff_2eelab_2eprint_2eescFrom_24acc_str0), 2)) {
      heff_drop(v_c_243);
      v_t_244 = ((V)&g_heff_2eelab_2eprint_2eescFrom_24acc_str1);
    } else {
      if (heff_strEq_c_lent(v_c_243, ((V)&g_heff_2eelab_2eprint_2eescFrom_24acc_str2), 2)) {
        heff_drop(v_c_243);
        v_t_244 = ((V)&g_heff_2eelab_2eprint_2eescFrom_24acc_str3);
      } else {
        if (heff_strEq_c_lent(v_c_243, ((V)&g_heff_2eelab_2eprint_2eescFrom_24acc_str4), 2)) {
          heff_drop(v_c_243);
          v_t_244 = ((V)&g_heff_2eelab_2eprint_2eescFrom_24acc_str5);
        } else {
          if (heff_strEq_c_lent(v_c_243, ((V)&g_heff_2eelab_2eprint_2eescFrom_24acc_str6), 2)) {
            heff_drop(v_c_243);
            v_t_244 = ((V)&g_heff_2eelab_2eprint_2eescFrom_24acc_str7);
          } else {
            if (heff_strEq_c_lent(v_c_243, ((V)&g_heff_2eelab_2eprint_2eescFrom_24acc_str8), 2)) {
              heff_drop(v_c_243);
              v_t_244 = ((V)&g_heff_2eelab_2eprint_2eescFrom_24acc_str9);
            } else {
              v_t_244 = v_c_243;
            }
          }
        }
      }
    }
    V v_s_245 = heff_strAppend(v_acc_242, v_t_244);
    V t_0 = v_s_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = v_s_245;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  } else {
    return heff_strAppend(v_acc_242, ((V)&g_heff_2eelab_2eprint_2eescFrom_24acc_str10));
  }
}
V g_heff_2eelab_2eprint_2eescFrom_24acc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eprint_2eescFrom_24acc(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eprint_2ecommaSep_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2eprint_2ecommaSep_str1, 2, ", ");
Clo g_heff_2eelab_2eprint_2ecommaSep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2ecommaSep_entry, 1, 0};

V g_heff_2eelab_2eprint_2ecommaSep(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2eprint_2ecommaSep_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_s_245 = heff_strAppend(heff_dup(v_x_241), ((V)&g_heff_2eelab_2eprint_2ecommaSep_str1));
      return (g_heff_2eelab_2eprint_2ecommaSep_24acc(v_x12_242, v_s_245));
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eprint_2ecommaSep_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eprint_2ecommaSep(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eprint_2ecommaSep_24acc_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2eprint_2ecommaSep_24acc_str1, 2, ", ");
Clo g_heff_2eelab_2eprint_2ecommaSep_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2ecommaSep_24acc_entry, 2, 0};

V g_heff_2eelab_2eprint_2ecommaSep_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_heff_2eelab_2eprint_2ecommaSep_24acc_str0));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      return heff_strAppend(v_acc_241, heff_dup(v_x_242));
    }
    case TAG_Cons: {
      V v_s_246 = heff_strAppend(heff_strAppend(v_acc_241, heff_dup(v_x_242)), ((V)&g_heff_2eelab_2eprint_2ecommaSep_24acc_str1));
      V t_0 = v_x12_243;
      V t_1 = v_s_246;
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eprint_2ecommaSep_24acc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eprint_2ecommaSep_24acc(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eprint_2edictOf_str0, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2edictOf_str1, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2edictOf_str2, 8, "(MkPair ");
HEFF_LIT(g_heff_2eelab_2eprint_2edictOf_str3, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2edictOf_str4, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2edictOf_str5, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2edictOf_str6, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2edictOf_str7, 12, "(D.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2edictOf_str8, 1, ")");
V g_heff_2eelab_2eprint_2edictOf_lam0(V self, V *args);
Clo g_heff_2eelab_2eprint_2edictOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2edictOf_entry, 2, 0};

V g_heff_2eelab_2eprint_2edictOf(V v_f_240, V v_d_241) {
top: ;
  V v_keys_242 = heff_take_field(v_d_241, 0);
  V v_values_243 = heff_get_n(v_d_241, 2, 3);
  V v_t_244 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_242), heff_arrayToList(v_values_243)));
  V v_xs_2412 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eprint_2edictOf_lam0, 1, 1, (V[]){v_f_240}), v_t_244));
  V v_t_2413 = ({ V a_0 = v_xs_2412; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2412); r_; });
  V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2edictOf_str5), v_t_2413), ((V)&g_heff_2eelab_2eprint_2edictOf_str6));
  return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2edictOf_str7), v_t_2414), ((V)&g_heff_2eelab_2eprint_2edictOf_str8));
}
V g_heff_2eelab_2eprint_2edictOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eprint_2edictOf(a[0], a[1]);
}
V g_heff_2eelab_2eprint_2edictOf_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_f_240 = heff_env(self)[0];
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_k_246 = heff_field(v_p_245, 0);
    V v_v_247 = heff_field(v_p_245, 1);
    heff_take_n(v_p_245, 3ULL, 2);
    V v_t_248 = ({ V a_0 = v_k_246; V a_1 = MK_INT(0LL); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_k_246); r_; });
    heff_clo_take(self, 1);
    V v_t_249 = heff_tr(heff_call(v_f_240, 1, (V[]){v_v_247}));
    V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2edictOf_str0), v_t_248), ((V)&g_heff_2eelab_2eprint_2edictOf_str1));
    V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2edictOf_str2), v_t_2410), ((V)&g_heff_2eelab_2eprint_2edictOf_str3));
    return heff_strAppend(heff_strAppend(v_t_2411, v_t_249), ((V)&g_heff_2eelab_2eprint_2edictOf_str4));
  }
  default: return heff_nomatch(v_p_245);
  }
}
HEFF_LIT(g_heff_2eelab_2eprint_2eabsOf_str0, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eabsOf_str1, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eabsOf_str2, 7, "(MkAbs ");
HEFF_LIT(g_heff_2eelab_2eprint_2eabsOf_str3, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eabsOf_str4, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eabsOf_str5, 10, "(AbsConst ");
HEFF_LIT(g_heff_2eelab_2eprint_2eabsOf_str6, 1, ")");
Clo g_heff_2eelab_2eprint_2eabsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2eabsOf_entry, 2, 0};

V g_heff_2eelab_2eprint_2eabsOf(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkAbs: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_b_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2eelab_2eprint_2eescFrom(v_x_242, MK_INT(0LL)));
    V v_t_245 = heff_tr(heff_call(v_f_240, 1, (V[]){heff_dup(v_b_243)}));
    V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eabsOf_str0), v_t_244), ((V)&g_heff_2eelab_2eprint_2eabsOf_str1));
    V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eabsOf_str2), v_t_246), ((V)&g_heff_2eelab_2eprint_2eabsOf_str3));
    return heff_strAppend(heff_strAppend(v_t_247, v_t_245), ((V)&g_heff_2eelab_2eprint_2eabsOf_str4));
  }
  case TAG_AbsConst: {
    V v_b_248 = heff_field(v_x2_241, 0);
    V v_t_249 = heff_tr(heff_call(v_f_240, 1, (V[]){heff_dup(v_b_248)}));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eabsOf_str5), v_t_249), ((V)&g_heff_2eelab_2eprint_2eabsOf_str6));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eprint_2eabsOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eprint_2eabsOf(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_str0, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_str1, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_str2, 12, "(A.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_str3, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_str4, 8, "(MkPair ");
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_str5, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2earmOf_str6, 1, ")");
Clo g_heff_2eelab_2eprint_2earmOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2earmOf_entry, 2, 0};

V g_heff_2eelab_2eprint_2earmOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_xs_242 = heff_field(v_x2_241, 0);
    V v_b_243 = heff_field(v_x2_241, 1);
    V v_xs_244 = (g_list_2emap_24s1397747289x2145601499(heff_arrayToList(heff_dup(v_xs_242))));
    V v_t_245 = ({ V a_0 = v_xs_244; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_244); r_; });
    V v_t_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_b_243)}));
    V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2earmOf_str0), v_t_245), ((V)&g_heff_2eelab_2eprint_2earmOf_str1));
    V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2earmOf_str2), v_t_247), ((V)&g_heff_2eelab_2eprint_2earmOf_str3));
    V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2earmOf_str4), v_t_248), ((V)&g_heff_2eelab_2eprint_2earmOf_str5));
    return heff_strAppend(heff_strAppend(v_t_249, v_t_246), ((V)&g_heff_2eelab_2eprint_2earmOf_str6));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eprint_2earmOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eprint_2earmOf(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str0, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str1, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str2, 8, "(SLocal ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str3, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str4, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str5, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str6, 9, "(SGlobal ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str7, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str8, 7, "(SCode ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str9, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str10, 6, "(SApp ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str11, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str12, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str13, 6, "(SLam ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str14, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str15, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str16, 7, "(SCons ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str17, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str18, 7, "(SProj ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str19, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str20, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str21, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str22, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str23, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str24, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str25, 6, "(STag ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str26, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str27, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str28, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str29, 12, "(A.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str30, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str31, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str32, 8, "(SMatch ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str33, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str34, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str35, 13, "(SSpecialize ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str36, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str37, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str38, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str39, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str40, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str41, 5, "(SIs ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str42, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str43, 7, "SOpaque");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str44, 8, "SAbandon");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str45, 6, "(SRec ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str46, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str47, 6, "(SFix ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str48, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str49, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str50, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str51, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str52, 11, "(SImplicit ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str53, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str54, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str55, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str56, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str57, 7, "(SPrim ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str58, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str59, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str60, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str61, 10, "(SMetaApp ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str62, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str63, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str64, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str65, 12, "(A.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str66, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str67, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str68, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str69, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str70, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str71, 9, "(SLitInt ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str72, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str73, 11, "(SLitFloat ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str74, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str75, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str76, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str77, 12, "(SLitString ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str78, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str79, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str80, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str81, 11, "(SLitBytes ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str82, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str83, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str84, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str85, 10, "(SLitRune ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str86, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str87, 2, "I8");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str88, 3, "I16");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str89, 3, "I32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str90, 3, "I64");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str91, 2, "U8");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str92, 3, "U16");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str93, 3, "U32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str94, 3, "U64");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str95, 3, "F32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str96, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str97, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str98, 11, "(SLitFixed ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str99, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str100, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str101, 13, "(SLitFloat32 ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_str102, 1, ")");
Clo g_heff_2eelab_2eprint_2eshowTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2eshowTermF_entry, 2, 0};

V g_heff_2eelab_2eprint_2eshowTermF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SLocal: {
    V v_i_242 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    V v_t_244;
    if (heff_intLt_c_lent(v_i_242, MK_INT(0LL), 2)) {
      V v_t_243 = heff_intShow(heff_intSub_lent(MK_INT(0LL), v_i_242, 1));
      v_t_244 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str0), v_t_243), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str1));
    } else {
      v_t_244 = heff_intShow(heff_dup(v_i_242));
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str2), v_t_244), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str3));
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    V v_t_246 = (g_heff_2eelab_2eprint_2eescFrom(v_x_245, MK_INT(0LL)));
    V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str4), v_t_246), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str5));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str6), v_t_247), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str7));
  }
  case TAG_SCode: {
    V v_a_248 = heff_field(v_x2_241, 0);
    V v_t_249 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){heff_dup(v_a_248)}));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str8), v_t_249), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str9));
  }
  case TAG_SApp: {
    V v_f_2410 = heff_field(v_x2_241, 0);
    V v_a_2411 = heff_field(v_x2_241, 1);
    V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){heff_dup(v_f_2410)}));
    V v_t_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_a_2411)}));
    V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str10), v_t_2412), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str11));
    return heff_strAppend(heff_strAppend(v_t_2414, v_t_2413), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str12));
  }
  case TAG_SLam: {
    V v_a_2415 = heff_field(v_x2_241, 0);
    V v_b_2416 = heff_field(v_x2_241, 1);
    V v_t_2417 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 1, (V[]){heff_dup(v_a_2415)}));
    V v_t_2418 = (g_heff_2eelab_2eprint_2eabsOf(heff_get_n(v_r_240, 0, 2), v_b_2416));
    V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str13), v_t_2417), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str14));
    return heff_strAppend(heff_strAppend(v_t_2419, v_t_2418), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str15));
  }
  case TAG_SCons: {
    V v_d_2420 = heff_field(v_x2_241, 0);
    V v_t_2421 = (g_heff_2eelab_2eprint_2edictOf(heff_get_n(v_r_240, 0, 2), heff_dup(v_d_2420)));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str16), v_t_2421), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str17));
  }
  case TAG_SProj: {
    V v_t_2422 = heff_field(v_x2_241, 0);
    V v_x_2423 = heff_field(v_x2_241, 1);
    V v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2422)}));
    V v_t_2425 = (g_heff_2eelab_2eprint_2eescFrom(v_x_2423, MK_INT(0LL)));
    V v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str18), v_t_2424), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str19));
    V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str20), v_t_2425), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str21));
    return heff_strAppend(heff_strAppend(v_t_2426, v_t_2427), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str22));
  }
  case TAG_STag: {
    V v_x_2428 = heff_field(v_x2_241, 0);
    V v_ts_2429 = heff_field(v_x2_241, 1);
    V v_t_2430 = (g_heff_2eelab_2eprint_2eescFrom(v_x_2428, MK_INT(0LL)));
    V v_xs_2431 = (g_list_2emap(heff_get_n(v_r_240, 0, 2), heff_arrayToList(heff_dup(v_ts_2429))));
    V v_t_2432 = ({ V a_0 = v_xs_2431; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2431); r_; });
    V v_t_2433 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str23), v_t_2430), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str24));
    V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str25), v_t_2433), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str26));
    V v_t_2435 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str27), v_t_2432), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str28));
    V v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str29), v_t_2435), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str30));
    return heff_strAppend(heff_strAppend(v_t_2434, v_t_2436), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str31));
  }
  case TAG_SMatch: {
    V v_t_2437 = heff_field(v_x2_241, 0);
    V v_arms_2438 = heff_field(v_x2_241, 1);
    V v_t_2439 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){heff_dup(v_t_2437)}));
    V v_t_2440 = heff_tr(heff_call(((V)&g_heff_2eelab_2eprint_2earmOf_clo), 1, (V[]){v_r_240}));
    V v_t_2441 = (g_heff_2eelab_2eprint_2edictOf(v_t_2440, heff_dup(v_arms_2438)));
    V v_t_2442 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str32), v_t_2439), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str33));
    return heff_strAppend(heff_strAppend(v_t_2442, v_t_2441), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str34));
  }
  case TAG_SSpecialize: {
    V v_t_2443 = heff_field(v_x2_241, 0);
    V v_x_2444 = heff_field(v_x2_241, 1);
    V v_t_27_2445 = heff_field(v_x2_241, 2);
    V v_t_2446 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){heff_dup(v_t_2443)}));
    V v_t_2447 = (g_heff_2eelab_2eprint_2eescFrom(v_x_2444, MK_INT(0LL)));
    V v_t_2448 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_27_2445)}));
    V v_t_2449 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str35), v_t_2446), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str36));
    V v_t_2450 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str37), v_t_2447), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str38));
    V v_t_2451 = heff_strAppend(heff_strAppend(v_t_2449, v_t_2450), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str39));
    return heff_strAppend(heff_strAppend(v_t_2451, v_t_2448), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str40));
  }
  case TAG_SIs: {
    V v_t_2452 = heff_field(v_x2_241, 0);
    V v_t_2453 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2452)}));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str41), v_t_2453), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str42));
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    return ((V)&g_heff_2eelab_2eprint_2eshowTermF_str43);
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    return ((V)&g_heff_2eelab_2eprint_2eshowTermF_str44);
  }
  case TAG_SRec: {
    V v_t_2454 = heff_field(v_x2_241, 0);
    V v_t_2455 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2454)}));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str45), v_t_2455), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str46));
  }
  case TAG_SFix: {
    V v_a_2456 = heff_field(v_x2_241, 0);
    V v_b_2457 = heff_field(v_x2_241, 1);
    V v_t_2458 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 1, (V[]){heff_dup(v_a_2456)}));
    V v_t_2459 = (g_heff_2eelab_2eprint_2eabsOf(heff_get_n(v_r_240, 0, 2), v_b_2457));
    V v_t_2460 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str47), v_t_2458), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str48));
    return heff_strAppend(heff_strAppend(v_t_2460, v_t_2459), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str49));
  }
  case TAG_SImplicit: {
    V v_x_2461 = heff_field(v_x2_241, 0);
    V v_t_2462 = heff_field(v_x2_241, 1);
    V v_t_2463 = (g_heff_2eelab_2eprint_2eescFrom(v_x_2461, MK_INT(0LL)));
    V v_t_2464 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2462)}));
    V v_t_2465 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str50), v_t_2463), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str51));
    V v_t_2466 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str52), v_t_2465), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str53));
    return heff_strAppend(heff_strAppend(v_t_2466, v_t_2464), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str54));
  }
  case TAG_SPrim: {
    V v_x_2467 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    V v_s_2468 = (g_heff_2eelab_2eprimitive_2eprimName(v_x_2467));
    V v_t_2469 = ({ V a_0 = v_s_2468; V a_1 = MK_INT(0LL); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_s_2468); r_; });
    V v_t_2470 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str55), v_t_2469), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str56));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str57), v_t_2470), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str58));
  }
  case TAG_SMetaApp: {
    V v_m_2471 = heff_field(v_x2_241, 0);
    V v_idxs_2472 = heff_field(v_x2_241, 1);
    V v_a_2473 = heff_field(v_x2_241, 2);
    V v_t_2475;
    if (heff_intLt_c_lent(v_m_2471, MK_INT(0LL), 2)) {
      V v_t_2474 = heff_intShow(heff_intSub_lent(MK_INT(0LL), v_m_2471, 1));
      v_t_2475 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str59), v_t_2474), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str60));
    } else {
      v_t_2475 = heff_intShow(heff_dup(v_m_2471));
    }
    V v_xs_2476 = (g_list_2emap_24s1181937096x2120532116(heff_arrayToList(heff_dup(v_idxs_2472))));
    V v_t_2477 = ({ V a_0 = v_xs_2476; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2476); r_; });
    V v_t_2478 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){heff_dup(v_a_2473)}));
    V v_t_2479 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str61), v_t_2475), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str62));
    V v_t_2480 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str63), v_t_2477), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str64));
    V v_t_2481 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str65), v_t_2480), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str66));
    V v_t_2482 = heff_strAppend(heff_strAppend(v_t_2479, v_t_2481), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str67));
    return heff_strAppend(heff_strAppend(v_t_2482, v_t_2478), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str68));
  }
  case TAG_SLitInt: {
    V v_n_2483 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    V v_t_2485;
    if (heff_intLt_c_lent(v_n_2483, MK_INT(0LL), 2)) {
      V v_t_2484 = heff_intShow(heff_intSub_lent(MK_INT(0LL), v_n_2483, 1));
      v_t_2485 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str69), v_t_2484), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str70));
    } else {
      v_t_2485 = heff_intShow(heff_dup(v_n_2483));
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str71), v_t_2485), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str72));
  }
  case TAG_SLitFloat: {
    V v_x_2486 = heff_tget_v(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    V v_t_2487 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str73), heff_floatShow(v_x_2486));
    return heff_strAppend(v_t_2487, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str74));
  }
  case TAG_SLitString: {
    V v_s_2488 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    V v_t_2489 = (g_heff_2eelab_2eprint_2eescFrom(v_s_2488, MK_INT(0LL)));
    V v_t_2490 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str75), v_t_2489), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str76));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str77), v_t_2490), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str78));
  }
  case TAG_SLitBytes: {
    V v_s_2491 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    V v_t_2492 = (g_heff_2eelab_2eprint_2eescFrom(v_s_2491, MK_INT(0LL)));
    V v_t_2493 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str79), v_t_2492), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str80));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str81), v_t_2493), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str82));
  }
  case TAG_SLitRune: {
    V v_c_2494 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    V v_t_2496;
    if (heff_intLt_c_lent(v_c_2494, MK_INT(0LL), 2)) {
      V v_t_2495 = heff_intShow(heff_intSub_lent(MK_INT(0LL), v_c_2494, 1));
      v_t_2496 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str83), v_t_2495), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str84));
    } else {
      v_t_2496 = heff_intShow(heff_dup(v_c_2494));
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str85), v_t_2496), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str86));
  }
  case TAG_SLitFixed: {
    V v_w_2497 = heff_field(v_x2_241, 0);
    V v_n_2498 = heff_field(v_x2_241, 1);
    heff_drop_rec(v_r_240, 2);
    V v_t_2499;
    switch (heff_tag_of(v_w_2497)) {
    case TAG_I8: {
      v_t_2499 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_str87);
      break;
    }
    case TAG_I16: {
      v_t_2499 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_str88);
      break;
    }
    case TAG_I32: {
      v_t_2499 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_str89);
      break;
    }
    case TAG_I64: {
      v_t_2499 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_str90);
      break;
    }
    case TAG_U8: {
      v_t_2499 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_str91);
      break;
    }
    case TAG_U16: {
      v_t_2499 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_str92);
      break;
    }
    case TAG_U32: {
      v_t_2499 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_str93);
      break;
    }
    case TAG_U64: {
      v_t_2499 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_str94);
      break;
    }
    case TAG_F32: {
      v_t_2499 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_str95);
      break;
    }
    default: heff_nomatch(v_w_2497);
    }
    V v_t_24101;
    if (heff_intLt_c_lent(v_n_2498, MK_INT(0LL), 2)) {
      V v_t_24100 = heff_intShow(heff_intSub_lent(MK_INT(0LL), v_n_2498, 1));
      v_t_24101 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str96), v_t_24100), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str97));
    } else {
      v_t_24101 = heff_intShow(heff_dup(v_n_2498));
    }
    V v_t_24102 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str98), v_t_2499), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str99));
    return heff_strAppend(heff_strAppend(v_t_24102, v_t_24101), ((V)&g_heff_2eelab_2eprint_2eshowTermF_str100));
  }
  case TAG_SLitFloat32: {
    V v_x_24103 = heff_tget_v(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    V v_t_24104 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_str101), heff_floatShow(v_x_24103));
    return heff_strAppend(v_t_24104, ((V)&g_heff_2eelab_2eprint_2eshowTermF_str102));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eprint_2eshowTermF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eprint_2eshowTermF(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str0, 6, "SmallU");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str1, 6, "LargeU");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str2, 4, "(SU ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str3, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str4, 9, "(SDecode ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str5, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str6, 5, "Small");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str7, 5, "Large");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str8, 4, "TopL");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str9, 4, "Expl");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str10, 4, "Impl");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str11, 4, "Inst");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str12, 8, " Nothing");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str13, 7, " (Just ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str14, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str15, 11, "(SFunction ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str16, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str17, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str18, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str19, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str20, 5, "Small");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str21, 5, "Large");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str22, 4, "TopL");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str23, 9, "(SRecord ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str24, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str25, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str26, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str27, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str28, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str29, 12, "(A.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str30, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str31, 6, "(SSum ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str32, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str33, 7, "(SIsTy ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str34, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str35, 8, "SPrimInt");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str36, 10, "SPrimFloat");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str37, 11, "SPrimString");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str38, 9, "SPrimRune");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str39, 12, "(SPrimArray ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str40, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str41, 2, "I8");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str42, 3, "I16");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str43, 3, "I32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str44, 3, "I64");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str45, 2, "U8");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str46, 3, "U16");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str47, 3, "U32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str48, 3, "U64");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str49, 3, "F32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str50, 8, "(SFixed ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_str51, 1, ")");
V g_heff_2eelab_2eprint_2eshowTypeF_lam0(V self, V *args);
Clo g_heff_2eelab_2eprint_2eshowTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2eshowTypeF_entry, 2, 0};

V g_heff_2eelab_2eprint_2eshowTypeF(V v_r_240, V v_x2_241) {
top: ;
  V v_el_242 = heff_take_field(v_r_240, 0);
  V v_ty_243 = heff_get_n(v_r_240, 1, 2);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SU: {
    V v_u_244 = heff_field(v_x2_241, 0);
    heff_drop(v_el_242);
    heff_drop(v_ty_243);
    V v_t_245;
    switch (heff_tag_of(v_u_244)) {
    case TAG_SmallU: {
      v_t_245 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str0);
      break;
    }
    case TAG_LargeU: {
      v_t_245 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str1);
      break;
    }
    default: heff_nomatch(v_u_244);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str2), v_t_245), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str3));
  }
  case TAG_SDecode: {
    V v_t_246 = heff_field(v_x2_241, 0);
    heff_drop(v_ty_243);
    V v_t_247 = heff_tr(heff_call(v_el_242, 1, (V[]){heff_dup(v_t_246)}));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str4), v_t_247), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str5));
  }
  case TAG_SFunction: {
    V v_level_248 = heff_field(v_x2_241, 0);
    V v_dom_249 = heff_field(v_x2_241, 1);
    V v_cod_2410 = heff_field(v_x2_241, 2);
    V v_implicit_2411 = heff_field(v_x2_241, 3);
    V v_dflt_2412 = heff_field(v_x2_241, 4);
    V v_t_2413;
    switch (heff_tag_of(v_level_248)) {
    case TAG_Small: {
      v_t_2413 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str6);
      break;
    }
    case TAG_Large: {
      v_t_2413 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str7);
      break;
    }
    case TAG_TopL: {
      v_t_2413 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str8);
      break;
    }
    default: heff_nomatch(v_level_248);
    }
    V v_t_2414 = heff_tr(heff_call(heff_dup(v_ty_243), 1, (V[]){heff_dup(v_dom_249)}));
    V v_t_2415 = (g_heff_2eelab_2eprint_2eabsOf(v_ty_243, v_cod_2410));
    V v_t_2416;
    switch (heff_tag_of(v_implicit_2411)) {
    case TAG_Expl: {
      v_t_2416 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str9);
      break;
    }
    case TAG_Impl: {
      v_t_2416 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str10);
      break;
    }
    case TAG_Inst: {
      v_t_2416 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str11);
      break;
    }
    default: heff_nomatch(v_implicit_2411);
    }
    V v_t_2419;
    switch (heff_tag_of(v_dflt_2412)) {
    case TAG_Nothing: {
      heff_drop(v_el_242);
      v_t_2419 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str12);
      break;
    }
    case TAG_Just: {
      V v_d_2417 = heff_field(v_dflt_2412, 0);
      V v_t_2418 = heff_tr(heff_call(v_el_242, 1, (V[]){heff_dup(v_d_2417)}));
      v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str13), v_t_2418), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str14));
      break;
    }
    default: heff_nomatch(v_dflt_2412);
    }
    V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str15), v_t_2413), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str16));
    V v_t_2421 = heff_strAppend(heff_strAppend(v_t_2420, v_t_2414), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str17));
    V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2421, v_t_2415), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str18));
    V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2422, v_t_2416), v_t_2419);
    return heff_strAppend(v_t_2423, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str19));
  }
  case TAG_SRecord: {
    V v_level_2424 = heff_field(v_x2_241, 0);
    V v_fieldTypes_2425 = heff_field(v_x2_241, 1);
    V v_defaults_2426 = heff_field(v_x2_241, 2);
    V v_t_2427;
    switch (heff_tag_of(v_level_2424)) {
    case TAG_Small: {
      v_t_2427 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str20);
      break;
    }
    case TAG_Large: {
      v_t_2427 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str21);
      break;
    }
    case TAG_TopL: {
      v_t_2427 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str22);
      break;
    }
    default: heff_nomatch(v_level_2424);
    }
    V v_t_2428 = (g_heff_2eelab_2eprint_2edictOf(v_ty_243, heff_dup(v_fieldTypes_2425)));
    V v_t_2429 = (g_heff_2eelab_2eprint_2edictOf(v_el_242, heff_dup(v_defaults_2426)));
    V v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str23), v_t_2427), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str24));
    V v_t_2431 = heff_strAppend(heff_strAppend(v_t_2430, v_t_2428), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str25));
    return heff_strAppend(heff_strAppend(v_t_2431, v_t_2429), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str26));
  }
  case TAG_SSum: {
    V v_st_2432 = heff_field(v_x2_241, 0);
    heff_drop(v_el_242);
    V v_t_2437 = (g_heff_2eelab_2eprint_2edictOf(heff_clo_n(g_heff_2eelab_2eprint_2eshowTypeF_lam0, 1, 1, (V[]){v_ty_243}), heff_dup(v_st_2432)));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str31), v_t_2437), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str32));
  }
  case TAG_SIsTy: {
    V v_t_2438 = heff_field(v_x2_241, 0);
    heff_drop(v_el_242);
    V v_t_2439 = heff_tr(heff_call(v_ty_243, 1, (V[]){heff_dup(v_t_2438)}));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str33), v_t_2439), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str34));
  }
  case TAG_SPrimInt: {
    heff_drop(v_el_242);
    heff_drop(v_ty_243);
    return ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str35);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_el_242);
    heff_drop(v_ty_243);
    return ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str36);
  }
  case TAG_SPrimString: {
    heff_drop(v_el_242);
    heff_drop(v_ty_243);
    return ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str37);
  }
  case TAG_SPrimRune: {
    heff_drop(v_el_242);
    heff_drop(v_ty_243);
    return ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str38);
  }
  case TAG_SPrimArray: {
    V v_a_2440 = heff_field(v_x2_241, 0);
    heff_drop(v_el_242);
    V v_t_2441 = heff_tr(heff_call(v_ty_243, 1, (V[]){heff_dup(v_a_2440)}));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str39), v_t_2441), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str40));
  }
  case TAG_SFixed: {
    V v_w_2442 = heff_field(v_x2_241, 0);
    heff_drop(v_el_242);
    heff_drop(v_ty_243);
    V v_t_2443;
    switch (heff_tag_of(v_w_2442)) {
    case TAG_I8: {
      v_t_2443 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str41);
      break;
    }
    case TAG_I16: {
      v_t_2443 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str42);
      break;
    }
    case TAG_I32: {
      v_t_2443 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str43);
      break;
    }
    case TAG_I64: {
      v_t_2443 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str44);
      break;
    }
    case TAG_U8: {
      v_t_2443 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str45);
      break;
    }
    case TAG_U16: {
      v_t_2443 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str46);
      break;
    }
    case TAG_U32: {
      v_t_2443 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str47);
      break;
    }
    case TAG_U64: {
      v_t_2443 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str48);
      break;
    }
    case TAG_F32: {
      v_t_2443 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str49);
      break;
    }
    default: heff_nomatch(v_w_2442);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str50), v_t_2443), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str51));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eprint_2eshowTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eprint_2eshowTypeF(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2eprint_2eshowTypeF_lam0(V self, V *args) {
  V v_xs_2433 = args[0];
  V v_ty_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_2434 = (g_list_2emap(v_ty_243, heff_arrayToList(v_xs_2433)));
  V v_t_2435 = ({ V a_0 = v_xs_2434; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2434); r_; });
  V v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str27), v_t_2435), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str28));
  return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_str29), v_t_2436), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_str30));
}
V g_heff_2eelab_2eprint_2epr_lam0(V self, V *args); static Clo g_heff_2eelab_2eprint_2epr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2epr_lam0, 1, 0};
V g_heff_2eelab_2eprint_2epr_lam1(V self, V *args); static Clo g_heff_2eelab_2eprint_2epr_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2epr_lam1, 1, 0};

static V g_heff_2eelab_2eprint_2epr_val;
static HEFF_ONCE g_heff_2eelab_2eprint_2epr_st;
static V g_heff_2eelab_2eprint_2epr_init(void) {
  return heff_rec_n(2, shape_el__ty, (V[]){((V)&g_heff_2eelab_2eprint_2epr_lam0_clo), ((V)&g_heff_2eelab_2eprint_2epr_lam1_clo)});
}
V g_heff_2eelab_2eprint_2epr_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eprint_2epr_st)) return g_heff_2eelab_2eprint_2epr_val;
  return heff_global(&g_heff_2eelab_2eprint_2epr_val, &g_heff_2eelab_2eprint_2epr_st, g_heff_2eelab_2eprint_2epr_init);
}
V g_heff_2eelab_2eprint_2epr_lam0(V self, V *args) {
  V v_t_240 = args[0];
  return ({ V a_0 = heff_dup(g_heff_2eelab_2eprint_2epr_get()); V a_1 = v_t_240; V r_ = (g_heff_2eelab_2eprint_2eshowTermF(a_0, a_1)); heff_drop(v_t_240); r_; });
}
V g_heff_2eelab_2eprint_2epr_lam1(V self, V *args) {
  V v_t_241 = args[0];
  return ({ V a_0 = heff_dup(g_heff_2eelab_2eprint_2epr_get()); V a_1 = v_t_241; V r_ = (g_heff_2eelab_2eprint_2eshowTypeF(a_0, a_1)); heff_drop(v_t_241); r_; });
}
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str0, 6, "SmallU");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str1, 6, "LargeU");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str2, 4, "(SU ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str3, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str4, 9, "(SDecode ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str5, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str6, 5, "Small");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str7, 5, "Large");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str8, 4, "TopL");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str9, 4, "Expl");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str10, 4, "Impl");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str11, 4, "Inst");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str12, 8, " Nothing");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str13, 7, " (Just ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str14, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str15, 11, "(SFunction ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str16, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str17, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str18, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str19, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str20, 5, "Small");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str21, 5, "Large");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str22, 4, "TopL");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str23, 8, "(MkPair ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str24, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str25, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str26, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str27, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str28, 8, "(MkPair ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str29, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str30, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str31, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str32, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str33, 9, "(SRecord ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str34, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str35, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str36, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str37, 12, "(D.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str38, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str39, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str40, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str41, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str42, 12, "(D.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str43, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str44, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str45, 8, "(MkPair ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str46, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str47, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str48, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str49, 12, "(A.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str50, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str51, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str52, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str53, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str54, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str55, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str56, 12, "(D.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str57, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str58, 6, "(SSum ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str59, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str60, 7, "(SIsTy ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str61, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str62, 8, "SPrimInt");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str63, 10, "SPrimFloat");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str64, 11, "SPrimString");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str65, 9, "SPrimRune");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str66, 12, "(SPrimArray ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str67, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str68, 2, "I8");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str69, 3, "I16");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str70, 3, "I32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str71, 3, "I64");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str72, 2, "U8");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str73, 3, "U16");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str74, 3, "U32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str75, 3, "U64");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str76, 3, "F32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str77, 8, "(SFixed ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str78, 1, ")");
Clo g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry, 1, 0};

V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SU: {
    V v_u_241 = heff_field(v_x2_240, 0);
    V v_t_242;
    switch (heff_tag_of(v_u_241)) {
    case TAG_SmallU: {
      v_t_242 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str0);
      break;
    }
    case TAG_LargeU: {
      v_t_242 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str1);
      break;
    }
    default: heff_nomatch(v_u_241);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str2), v_t_242), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str3));
  }
  case TAG_SDecode: {
    V v_t_243 = heff_field(v_x2_240, 0);
    V v_t_244 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_t_243));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str4), v_t_244), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str5));
  }
  case TAG_SFunction: {
    V v_level_245 = heff_field(v_x2_240, 0);
    V v_dom_246 = heff_field(v_x2_240, 1);
    V v_cod_247 = heff_field(v_x2_240, 2);
    V v_implicit_248 = heff_field(v_x2_240, 3);
    V v_dflt_249 = heff_field(v_x2_240, 4);
    V v_t_2410;
    switch (heff_tag_of(v_level_245)) {
    case TAG_Small: {
      v_t_2410 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str6);
      break;
    }
    case TAG_Large: {
      v_t_2410 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str7);
      break;
    }
    case TAG_TopL: {
      v_t_2410 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str8);
      break;
    }
    default: heff_nomatch(v_level_245);
    }
    V v_t_2411 = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(v_dom_246));
    V v_t_2412 = (g_heff_2eelab_2eprint_2eabsOf(heff_dup(heff_rfield(g_heff_2eelab_2eprint_2epr_get(), 1)), v_cod_247));
    V v_t_2413;
    switch (heff_tag_of(v_implicit_248)) {
    case TAG_Expl: {
      v_t_2413 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str9);
      break;
    }
    case TAG_Impl: {
      v_t_2413 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str10);
      break;
    }
    case TAG_Inst: {
      v_t_2413 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str11);
      break;
    }
    default: heff_nomatch(v_implicit_248);
    }
    V v_t_2416;
    switch (heff_tag_of(v_dflt_249)) {
    case TAG_Nothing: {
      v_t_2416 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str12);
      break;
    }
    case TAG_Just: {
      V v_d_2414 = heff_field(v_dflt_249, 0);
      V v_t_2415 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_d_2414));
      v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str13), v_t_2415), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str14));
      break;
    }
    default: heff_nomatch(v_dflt_249);
    }
    V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str15), v_t_2410), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str16));
    V v_t_2418 = heff_strAppend(heff_strAppend(v_t_2417, v_t_2411), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str17));
    V v_t_2419 = heff_strAppend(heff_strAppend(v_t_2418, v_t_2412), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str18));
    V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2419, v_t_2413), v_t_2416);
    return heff_strAppend(v_t_2420, ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str19));
  }
  case TAG_SRecord: {
    V v_level_2421 = heff_field(v_x2_240, 0);
    V v_fieldTypes_2422 = heff_field(v_x2_240, 1);
    V v_defaults_2423 = heff_field(v_x2_240, 2);
    V v_keys_2424 = heff_dup(heff_rfield(v_defaults_2423, 0));
    V v_values_2425 = heff_dup(heff_rfield(v_defaults_2423, 2));
    V v_keys_2426 = heff_dup(heff_rfield(v_fieldTypes_2422, 0));
    V v_values_2427 = heff_dup(heff_rfield(v_fieldTypes_2422, 2));
    V v_t_2428;
    switch (heff_tag_of(v_level_2421)) {
    case TAG_Small: {
      v_t_2428 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str20);
      break;
    }
    case TAG_Large: {
      v_t_2428 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str21);
      break;
    }
    case TAG_TopL: {
      v_t_2428 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str22);
      break;
    }
    default: heff_nomatch(v_level_2421);
    }
    V v_t_2429 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2426), heff_arrayToList(v_values_2427)));
    V v_xs_2430 = (g_list_2emap_24s191715292x1660526539(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str23), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str24), MK_INT(0LL), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str25), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str26), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str27), v_t_2429));
    V v_t_2431 = ({ V a_0 = v_xs_2430; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2430); r_; });
    V v_t_2432 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2424), heff_arrayToList(v_values_2425)));
    V v_xs_2433 = (g_list_2emap_24s323105787x487030640(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str28), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str29), MK_INT(0LL), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str30), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str31), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str32), v_t_2432));
    V v_t_2434 = ({ V a_0 = v_xs_2433; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2433); r_; });
    V v_t_2435 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str33), v_t_2428), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str34));
    V v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str35), v_t_2431), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str36));
    V v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str37), v_t_2436), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str38));
    V v_t_2438 = heff_strAppend(heff_strAppend(v_t_2435, v_t_2437), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str39));
    V v_t_2439 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str40), v_t_2434), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str41));
    V v_t_2440 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str42), v_t_2439), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str43));
    return heff_strAppend(heff_strAppend(v_t_2438, v_t_2440), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str44));
  }
  case TAG_SSum: {
    V v_st_2441 = heff_field(v_x2_240, 0);
    V v_keys_2442 = heff_dup(heff_rfield(v_st_2441, 0));
    V v_values_2443 = heff_dup(heff_rfield(v_st_2441, 2));
    V v_t_2444 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2442), heff_arrayToList(v_values_2443)));
    V v_xs_2445 = (g_list_2emap_24s1839428429x1874782624(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str45), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str46), MK_INT(0LL), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str47), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str48), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str49), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str50), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str51), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str52), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str53), v_t_2444));
    V v_t_2446 = ({ V a_0 = v_xs_2445; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2445); r_; });
    V v_t_2447 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str54), v_t_2446), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str55));
    V v_t_2448 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str56), v_t_2447), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str57));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str58), v_t_2448), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str59));
  }
  case TAG_SIsTy: {
    V v_t_2449 = heff_field(v_x2_240, 0);
    V v_t_2450 = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(v_t_2449));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str60), v_t_2450), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str61));
  }
  case TAG_SPrimInt: {
    return ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str62);
  }
  case TAG_SPrimFloat: {
    return ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str63);
  }
  case TAG_SPrimString: {
    return ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str64);
  }
  case TAG_SPrimRune: {
    return ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str65);
  }
  case TAG_SPrimArray: {
    V v_a_2451 = heff_field(v_x2_240, 0);
    V v_t_2452 = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(v_a_2451));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str66), v_t_2452), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str67));
  }
  case TAG_SFixed: {
    V v_w_2453 = heff_field(v_x2_240, 0);
    V v_t_2454;
    switch (heff_tag_of(v_w_2453)) {
    case TAG_I8: {
      v_t_2454 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str68);
      break;
    }
    case TAG_I16: {
      v_t_2454 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str69);
      break;
    }
    case TAG_I32: {
      v_t_2454 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str70);
      break;
    }
    case TAG_I64: {
      v_t_2454 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str71);
      break;
    }
    case TAG_U8: {
      v_t_2454 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str72);
      break;
    }
    case TAG_U16: {
      v_t_2454 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str73);
      break;
    }
    case TAG_U32: {
      v_t_2454 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str74);
      break;
    }
    case TAG_U64: {
      v_t_2454 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str75);
      break;
    }
    case TAG_F32: {
      v_t_2454 = ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str76);
      break;
    }
    default: heff_nomatch(v_w_2453);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str77), v_t_2454), ((V)&g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_str78));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str0, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str1, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str2, 8, "(SLocal ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str3, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str4, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str5, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str6, 9, "(SGlobal ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str7, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str8, 7, "(SCode ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str9, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str10, 6, "(SApp ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str11, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str12, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str13, 6, "(SLam ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str14, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str15, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str16, 8, "(MkPair ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str17, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str18, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str19, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str20, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str21, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str22, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str23, 12, "(D.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str24, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str25, 7, "(SCons ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str26, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str27, 7, "(SProj ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str28, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str29, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str30, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str31, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str32, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str33, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str34, 6, "(STag ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str35, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str36, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str37, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str38, 12, "(A.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str39, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str40, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str41, 8, "(MkPair ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str42, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str43, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str44, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str45, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str46, 8, "(SMatch ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str47, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str48, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str49, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str50, 12, "(D.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str51, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str52, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str53, 13, "(SSpecialize ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str54, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str55, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str56, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str57, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str58, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str59, 5, "(SIs ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str60, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str61, 7, "SOpaque");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str62, 8, "SAbandon");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str63, 6, "(SRec ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str64, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str65, 6, "(SFix ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str66, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str67, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str68, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str69, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str70, 11, "(SImplicit ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str71, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str72, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str73, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str74, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str75, 7, "(SPrim ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str76, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str77, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str78, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str79, 10, "(SMetaApp ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str80, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str81, 1, "[");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str82, 1, "]");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str83, 12, "(A.fromList ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str84, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str85, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str86, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str87, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str88, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str89, 9, "(SLitInt ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str90, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str91, 11, "(SLitFloat ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str92, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str93, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str94, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str95, 12, "(SLitString ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str96, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str97, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str98, 1, "\"");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str99, 11, "(SLitBytes ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str100, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str101, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str102, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str103, 10, "(SLitRune ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str104, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str105, 2, "I8");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str106, 3, "I16");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str107, 3, "I32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str108, 3, "I64");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str109, 2, "U8");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str110, 3, "U16");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str111, 3, "U32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str112, 3, "U64");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str113, 3, "F32");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str114, 5, "(0 - ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str115, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str116, 11, "(SLitFixed ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str117, 1, " ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str118, 1, ")");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str119, 13, "(SLitFloat32 ");
HEFF_LIT(g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str120, 1, ")");
Clo g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry, 1, 0};

V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SLocal: {
    V v_i_241 = heff_field(v_x2_240, 0);
    V v_t_243;
    if (heff_intLt_c_lent(v_i_241, MK_INT(0LL), 2)) {
      V v_t_242 = heff_intShow(heff_intSub_lent(MK_INT(0LL), v_i_241, 1));
      v_t_243 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str0), v_t_242), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str1));
    } else {
      v_t_243 = heff_intShow(heff_dup(v_i_241));
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str2), v_t_243), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str3));
  }
  case TAG_SGlobal: {
    V v_x_244 = heff_field(v_x2_240, 0);
    V v_t_245 = (g_heff_2eelab_2eprint_2eescFrom(v_x_244, MK_INT(0LL)));
    V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str4), v_t_245), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str5));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str6), v_t_246), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str7));
  }
  case TAG_SCode: {
    V v_a_247 = heff_field(v_x2_240, 0);
    V v_t_248 = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(v_a_247));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str8), v_t_248), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str9));
  }
  case TAG_SApp: {
    V v_f_249 = heff_field(v_x2_240, 0);
    V v_a_2410 = heff_field(v_x2_240, 1);
    V v_t_2411 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_f_249));
    V v_t_2412 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_a_2410));
    V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str10), v_t_2411), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str11));
    return heff_strAppend(heff_strAppend(v_t_2413, v_t_2412), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str12));
  }
  case TAG_SLam: {
    V v_a_2414 = heff_field(v_x2_240, 0);
    V v_b_2415 = heff_field(v_x2_240, 1);
    V v_t_2416 = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(v_a_2414));
    V v_t_2417 = (g_heff_2eelab_2eprint_2eabsOf(heff_dup(heff_rfield(g_heff_2eelab_2eprint_2epr_get(), 0)), v_b_2415));
    V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str13), v_t_2416), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str14));
    return heff_strAppend(heff_strAppend(v_t_2418, v_t_2417), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str15));
  }
  case TAG_SCons: {
    V v_d_2419 = heff_field(v_x2_240, 0);
    V v_keys_2420 = heff_dup(heff_rfield(v_d_2419, 0));
    V v_values_2421 = heff_dup(heff_rfield(v_d_2419, 2));
    V v_t_2422 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2420), heff_arrayToList(v_values_2421)));
    V v_xs_2423 = (g_list_2emap_24s323105787x487030640(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str16), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str17), MK_INT(0LL), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str18), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str19), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str20), v_t_2422));
    V v_t_2424 = ({ V a_0 = v_xs_2423; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2423); r_; });
    V v_t_2425 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str21), v_t_2424), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str22));
    V v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str23), v_t_2425), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str24));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str25), v_t_2426), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str26));
  }
  case TAG_SProj: {
    V v_t_2427 = heff_field(v_x2_240, 0);
    V v_x_2428 = heff_field(v_x2_240, 1);
    V v_t_2429 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_t_2427));
    V v_t_2430 = (g_heff_2eelab_2eprint_2eescFrom(v_x_2428, MK_INT(0LL)));
    V v_t_2431 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str27), v_t_2429), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str28));
    V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str29), v_t_2430), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str30));
    return heff_strAppend(heff_strAppend(v_t_2431, v_t_2432), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str31));
  }
  case TAG_STag: {
    V v_x_2433 = heff_field(v_x2_240, 0);
    V v_ts_2434 = heff_field(v_x2_240, 1);
    V v_t_2435 = (g_heff_2eelab_2eprint_2eescFrom(v_x_2433, MK_INT(0LL)));
    V v_xs_2436 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2eelab_2eprint_2epr_get(), 0)), heff_arrayToList(heff_dup(v_ts_2434))));
    V v_t_2437 = ({ V a_0 = v_xs_2436; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2436); r_; });
    V v_t_2438 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str32), v_t_2435), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str33));
    V v_t_2439 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str34), v_t_2438), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str35));
    V v_t_2440 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str36), v_t_2437), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str37));
    V v_t_2441 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str38), v_t_2440), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str39));
    return heff_strAppend(heff_strAppend(v_t_2439, v_t_2441), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str40));
  }
  case TAG_SMatch: {
    V v_t_2442 = heff_field(v_x2_240, 0);
    V v_arms_2443 = heff_field(v_x2_240, 1);
    V v_keys_2444 = heff_dup(heff_rfield(v_arms_2443, 0));
    V v_values_2445 = heff_dup(heff_rfield(v_arms_2443, 2));
    V v_t_2446 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_t_2442));
    V v_t_2447 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2444), heff_arrayToList(v_values_2445)));
    V v_xs_2448 = (g_list_2emap_24s525732339x518706186(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str41), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str42), MK_INT(0LL), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str43), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str44), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str45), v_t_2447));
    V v_t_2449 = ({ V a_0 = v_xs_2448; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2448); r_; });
    V v_t_2450 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str46), v_t_2446), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str47));
    V v_t_2451 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str48), v_t_2449), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str49));
    V v_t_2452 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str50), v_t_2451), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str51));
    return heff_strAppend(heff_strAppend(v_t_2450, v_t_2452), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str52));
  }
  case TAG_SSpecialize: {
    V v_t_2453 = heff_field(v_x2_240, 0);
    V v_x_2454 = heff_field(v_x2_240, 1);
    V v_t_27_2455 = heff_field(v_x2_240, 2);
    V v_t_2456 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_t_2453));
    V v_t_2457 = (g_heff_2eelab_2eprint_2eescFrom(v_x_2454, MK_INT(0LL)));
    V v_t_2458 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_t_27_2455));
    V v_t_2459 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str53), v_t_2456), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str54));
    V v_t_2460 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str55), v_t_2457), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str56));
    V v_t_2461 = heff_strAppend(heff_strAppend(v_t_2459, v_t_2460), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str57));
    return heff_strAppend(heff_strAppend(v_t_2461, v_t_2458), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str58));
  }
  case TAG_SIs: {
    V v_t_2462 = heff_field(v_x2_240, 0);
    V v_t_2463 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_t_2462));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str59), v_t_2463), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str60));
  }
  case TAG_SOpaque: {
    return ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str61);
  }
  case TAG_SAbandon: {
    return ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str62);
  }
  case TAG_SRec: {
    V v_t_2464 = heff_field(v_x2_240, 0);
    V v_t_2465 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_t_2464));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str63), v_t_2465), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str64));
  }
  case TAG_SFix: {
    V v_a_2466 = heff_field(v_x2_240, 0);
    V v_b_2467 = heff_field(v_x2_240, 1);
    V v_t_2468 = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(v_a_2466));
    V v_t_2469 = (g_heff_2eelab_2eprint_2eabsOf(heff_dup(heff_rfield(g_heff_2eelab_2eprint_2epr_get(), 0)), v_b_2467));
    V v_t_2470 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str65), v_t_2468), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str66));
    return heff_strAppend(heff_strAppend(v_t_2470, v_t_2469), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str67));
  }
  case TAG_SImplicit: {
    V v_x_2471 = heff_field(v_x2_240, 0);
    V v_t_2472 = heff_field(v_x2_240, 1);
    V v_t_2473 = (g_heff_2eelab_2eprint_2eescFrom(v_x_2471, MK_INT(0LL)));
    V v_t_2474 = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(v_t_2472));
    V v_t_2475 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str68), v_t_2473), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str69));
    V v_t_2476 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str70), v_t_2475), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str71));
    return heff_strAppend(heff_strAppend(v_t_2476, v_t_2474), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str72));
  }
  case TAG_SPrim: {
    V v_x_2477 = heff_field(v_x2_240, 0);
    V v_s_2478 = (g_heff_2eelab_2eprimitive_2eprimName(v_x_2477));
    V v_t_2479 = ({ V a_0 = v_s_2478; V a_1 = MK_INT(0LL); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_s_2478); r_; });
    V v_t_2480 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str73), v_t_2479), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str74));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str75), v_t_2480), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str76));
  }
  case TAG_SMetaApp: {
    V v_m_2481 = heff_field(v_x2_240, 0);
    V v_idxs_2482 = heff_field(v_x2_240, 1);
    V v_a_2483 = heff_field(v_x2_240, 2);
    V v_t_2485;
    if (heff_intLt_c_lent(v_m_2481, MK_INT(0LL), 2)) {
      V v_t_2484 = heff_intShow(heff_intSub_lent(MK_INT(0LL), v_m_2481, 1));
      v_t_2485 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str77), v_t_2484), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str78));
    } else {
      v_t_2485 = heff_intShow(heff_dup(v_m_2481));
    }
    V v_xs_2486 = (g_list_2emap_24s1181937096x2120532116(heff_arrayToList(heff_dup(v_idxs_2482))));
    V v_t_2487 = ({ V a_0 = v_xs_2486; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2486); r_; });
    V v_t_2488 = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(v_a_2483));
    V v_t_2489 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str79), v_t_2485), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str80));
    V v_t_2490 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str81), v_t_2487), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str82));
    V v_t_2491 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str83), v_t_2490), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str84));
    V v_t_2492 = heff_strAppend(heff_strAppend(v_t_2489, v_t_2491), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str85));
    return heff_strAppend(heff_strAppend(v_t_2492, v_t_2488), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str86));
  }
  case TAG_SLitInt: {
    V v_n_2493 = heff_field(v_x2_240, 0);
    V v_t_2495;
    if (heff_intLt_c_lent(v_n_2493, MK_INT(0LL), 2)) {
      V v_t_2494 = heff_intShow(heff_intSub_lent(MK_INT(0LL), v_n_2493, 1));
      v_t_2495 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str87), v_t_2494), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str88));
    } else {
      v_t_2495 = heff_intShow(heff_dup(v_n_2493));
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str89), v_t_2495), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str90));
  }
  case TAG_SLitFloat: {
    V v_x_2496 = heff_tget_v(v_x2_240, 0);
    V v_t_2497 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str91), heff_floatShow(v_x_2496));
    return heff_strAppend(v_t_2497, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str92));
  }
  case TAG_SLitString: {
    V v_s_2498 = heff_field(v_x2_240, 0);
    V v_t_2499 = (g_heff_2eelab_2eprint_2eescFrom(v_s_2498, MK_INT(0LL)));
    V v_t_24100 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str93), v_t_2499), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str94));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str95), v_t_24100), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str96));
  }
  case TAG_SLitBytes: {
    V v_s_24101 = heff_field(v_x2_240, 0);
    V v_t_24102 = (g_heff_2eelab_2eprint_2eescFrom(v_s_24101, MK_INT(0LL)));
    V v_t_24103 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str97), v_t_24102), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str98));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str99), v_t_24103), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str100));
  }
  case TAG_SLitRune: {
    V v_c_24104 = heff_field(v_x2_240, 0);
    V v_t_24106;
    if (heff_intLt_c_lent(v_c_24104, MK_INT(0LL), 2)) {
      V v_t_24105 = heff_intShow(heff_intSub_lent(MK_INT(0LL), v_c_24104, 1));
      v_t_24106 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str101), v_t_24105), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str102));
    } else {
      v_t_24106 = heff_intShow(heff_dup(v_c_24104));
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str103), v_t_24106), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str104));
  }
  case TAG_SLitFixed: {
    V v_w_24107 = heff_field(v_x2_240, 0);
    V v_n_24108 = heff_field(v_x2_240, 1);
    V v_t_24109;
    switch (heff_tag_of(v_w_24107)) {
    case TAG_I8: {
      v_t_24109 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str105);
      break;
    }
    case TAG_I16: {
      v_t_24109 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str106);
      break;
    }
    case TAG_I32: {
      v_t_24109 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str107);
      break;
    }
    case TAG_I64: {
      v_t_24109 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str108);
      break;
    }
    case TAG_U8: {
      v_t_24109 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str109);
      break;
    }
    case TAG_U16: {
      v_t_24109 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str110);
      break;
    }
    case TAG_U32: {
      v_t_24109 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str111);
      break;
    }
    case TAG_U64: {
      v_t_24109 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str112);
      break;
    }
    case TAG_F32: {
      v_t_24109 = ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str113);
      break;
    }
    default: heff_nomatch(v_w_24107);
    }
    V v_t_24111;
    if (heff_intLt_c_lent(v_n_24108, MK_INT(0LL), 2)) {
      V v_t_24110 = heff_intShow(heff_intSub_lent(MK_INT(0LL), v_n_24108, 1));
      v_t_24111 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str114), v_t_24110), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str115));
    } else {
      v_t_24111 = heff_intShow(heff_dup(v_n_24108));
    }
    V v_t_24112 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str116), v_t_24109), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str117));
    return heff_strAppend(heff_strAppend(v_t_24112, v_t_24111), ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str118));
  }
  case TAG_SLitFloat32: {
    V v_x_24113 = heff_tget_v(v_x2_240, 0);
    V v_t_24114 = heff_strAppend(((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str119), heff_floatShow(v_x_24113));
    return heff_strAppend(v_t_24114, ((V)&g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_str120));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(a0); heff_drop(a0); return r;
}