// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
Clo g_heff_2erules_2eintoSilent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eintoSilent_entry, 7, 0};

V g_heff_2erules_2eintoSilent(V v_e_240, V v_implicit_241, V v_y_242, V v_dom_243, V v_sc_244, V v_v_245, V v_counted_246) {
top: ;
  V v_t_247 = heff_get(heff_dup(v_e_240), LBL_elabFor);
  V v_t_2410;
  switch (heff_tag_of(v_t_247)) {
  case TAG_ForNominative: {
    v_t_2410 = NTAG(TAG_ForNominative);
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_248 = heff_field(v_t_247, 0);
    V v_sp_249 = heff_field(v_t_247, 1);
    V v_ru_24t_247_24ForDescriptive = heff_take_reuse_n(v_t_247, 3ULL, 2);
    v_t_2410 = heff_tag_at(v_ru_24t_247_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_248, heff_tag(TAG_SpApp, 2, (V[]){v_sp_249, heff_dup(v_v_245)})});
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_t_2411;
  switch (heff_tag_of(v_counted_246)) {
  case TAG_True: {
    v_t_2411 = heff_intAdd(heff_get(heff_dup(v_e_240), LBL_lams), MK_INT(1LL));
    break;
  }
  case TAG_False: {
    v_t_2411 = heff_get(heff_dup(v_e_240), LBL_lams);
    break;
  }
  default: heff_nomatch(v_counted_246);
  }
  V v_t_2412;
  switch (heff_tag_of(v_implicit_241)) {
  case TAG_Expl: {
    heff_drop(v_y_242);
    heff_drop(v_dom_243);
    heff_drop(v_v_245);
    v_t_2412 = heff_get(heff_dup(v_e_240), LBL_insts);
    break;
  }
  case TAG_Impl: {
    heff_drop(v_y_242);
    heff_drop(v_dom_243);
    heff_drop(v_v_245);
    v_t_2412 = heff_get(heff_dup(v_e_240), LBL_insts);
    break;
  }
  case TAG_Inst: {
    v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(3, shape_198_351_365, (V[]){v_y_242, v_dom_243, v_v_245}), heff_get(heff_dup(v_e_240), LBL_insts)});
    break;
  }
  default: heff_nomatch(v_implicit_241);
  }
  return heff_rec(6, shape_289_115_81_161_295_145, (V[]){v_sc_244, heff_get(heff_dup(v_e_240), LBL_globals), v_t_2410, v_t_2411, heff_get(v_e_240, LBL_self), v_t_2412});
}
V g_heff_2erules_2eintoSilent_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2eintoSilent(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[1]); heff_drop(a[6]); return r;
}
V g_heff_2erules_2eerrorOf_lam1(V self, V *args);
V g_heff_2erules_2eerrorOf_lam0(V self, V *args);
V g_heff_2erules_2eerrorOf_lam2(V self, V *args);

static V g_heff_2erules_2eerrorOf_val;
static int g_heff_2erules_2eerrorOf_st;
static V g_heff_2erules_2eerrorOf_init(void) {
  V v_t_240 = (g_heff_2evalue_2emkNeu_24s10_24s425(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  V v_a_241 = ({ V a_0 = v_t_240; V r_ = (g_heff_2evalue_2edecodeN(a_0)); heff_drop(v_t_240); r_; });
  V v_t_244 = heff_rec(2, shape_326_366, (V[]){NTAG(TAG_SAbandon), heff_clo(g_heff_2erules_2eerrorOf_lam0, 1, 1, (V[]){v_a_241})});
  V v_t_245 = (g_heff_2evalue_2emkNeu_24s10_24s425(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  V v_x_246 = heff_tag(TAG_MkPair, 2, (V[]){v_t_244, ({ V a_0 = v_t_245; V r_ = (g_heff_2evalue_2edecodeN(a_0)); heff_drop(v_t_245); r_; })});
  return heff_clo(g_heff_2erules_2eerrorOf_lam2, 2, 1, (V[]){v_x_246});
}
V g_heff_2erules_2eerrorOf_get(void) {
  if (g_heff_2erules_2eerrorOf_st == 2) return g_heff_2erules_2eerrorOf_val;
  if (g_heff_2erules_2eerrorOf_st == 1) heff_fail("defined by itself");
  g_heff_2erules_2eerrorOf_st = 1;
  g_heff_2erules_2eerrorOf_val = heff_tr(g_heff_2erules_2eerrorOf_init());
  g_heff_2erules_2eerrorOf_st = 2;
  return g_heff_2erules_2eerrorOf_val;
}
V g_heff_2erules_2eerrorOf_lam1(V self, V *args) {
  V v_u_243 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_243);
  return v_a_241;
}
V g_heff_2erules_2eerrorOf_lam0(V self, V *args) {
  V v_u_242 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_242);
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2emkNeu_24s10(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2eerrorOf_lam1, 1, 1, (V[]){v_a_241}), NTAG(TAG_Nothing)))});
}
V g_heff_2erules_2eerrorOf_lam2(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_x_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2erules_2edownFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2edownFrom_entry, 1, 0};

V g_heff_2erules_2edownFrom(V v_n_240) {
top: ;
  V v_t_241 = heff_intLt(heff_dup(v_n_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_False: {
    return heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_n_240), (g_heff_2erules_2edownFrom(heff_intSub(v_n_240, MK_INT(1LL))))});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2erules_2edownFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2edownFrom(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2enamesFor_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
Clo g_heff_2erules_2enamesFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2enamesFor_entry, 1, 0};

V g_heff_2erules_2enamesFor(V v_n_240) {
top: ;
  V v_t_241 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_False: {
    V v_t_242 = heff_intShow(heff_intSub(heff_dup(v_n_240), MK_INT(1LL)));
    return heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2erules_2enamesFor_str0), v_t_242), (g_heff_2erules_2enamesFor(heff_intSub(v_n_240, MK_INT(1LL))))});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2erules_2enamesFor_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2enamesFor(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2erules_2efreshMeta_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {109, 101, 116, 97}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2efreshMeta_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2erules_2efreshMeta_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2erules_2efreshMeta_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {41, 32, 58, 32}};
V g_heff_2erules_2efreshMeta_lam0(V self, V *args); static Clo g_heff_2erules_2efreshMeta_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2efreshMeta_lam0, 1, 0};
V g_heff_2erules_2efreshMeta_lam2(V self, V *args);
V g_heff_2erules_2efreshMeta_lam5(V self, V *args); static Clo g_heff_2erules_2efreshMeta_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2efreshMeta_lam5, 1, 0};
V g_heff_2erules_2efreshMeta_lam7(V self, V *args);
V g_heff_2erules_2efreshMeta_lam9(V self, V *args);
V g_heff_2erules_2efreshMeta_lam10(V self, V *args);
V g_heff_2erules_2efreshMeta_lam8(V self, V *args);
V g_heff_2erules_2efreshMeta_lam6(V self, V *args);
V g_heff_2erules_2efreshMeta_lam4(V self, V *args);
V g_heff_2erules_2efreshMeta_lam3(V self, V *args);
V g_heff_2erules_2efreshMeta_lam1(V self, V *args);
Clo g_heff_2erules_2efreshMeta_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2efreshMeta_entry, 7, 0};

V g_heff_2erules_2efreshMeta(V v_len_240, V v_locals_241, V v_ty_242, V v_name_243, V v_sp_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2erules_2efreshMeta_lam0_clo)})});
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_249}));
  return heff_tail(heff_get(heff_dup(v_hd_245), LBL_bind), 2, (V[]){v_t_2410, heff_clo(g_heff_2erules_2efreshMeta_lam1, 1, 7, (V[]){v_ty_242, v_len_240, v_name_243, v_sp_244, v_hd_245, heff_dup(v_locals_241), v_k_246})});
}
V g_heff_2erules_2efreshMeta_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2efreshMeta(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[1]); return r;
}
V g_heff_2erules_2efreshMeta_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get(v_c_247, LBL_nextMeta);
}
V g_heff_2erules_2efreshMeta_lam2(V self, V *args) {
  V v_c_2412 = args[0];
  V v_ty_242 = heff_env(self)[0];
  V v_len_240 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_rec(6, shape_351_308_309_14_198_314, (V[]){v_ty_242, NTAG(TAG_Nothing), NTAG(TAG_Nothing), v_len_240, v_name_243, v_sp_244});
  V v_mc_2414 = (g_map_2einsert_24s194(heff_dup(v_x_2411), v_t_2413, heff_get(heff_dup(v_c_2412), LBL_metas)));
  return heff_rec(8, shape_139_266_247_190_202_250_346_296, (V[]){heff_get(heff_dup(v_c_2412), LBL_infos), heff_get(heff_dup(v_c_2412), LBL_recovered), heff_get(heff_dup(v_c_2412), LBL_poisoned), v_mc_2414, heff_intAdd(v_x_2411, MK_INT(1LL)), heff_get(heff_dup(v_c_2412), LBL_postponed), heff_get(heff_dup(v_c_2412), LBL_trace), heff_get(v_c_2412, LBL_selfKey)});
}
V g_heff_2erules_2efreshMeta_lam5(V self, V *args) {
  V v_c_2423 = args[0];
  return heff_get(v_c_2423, LBL_metas);
}
V g_heff_2erules_2efreshMeta_lam7(V self, V *args) {
  V v_u_2428 = args[0];
  V v_len_240 = heff_env(self)[0];
  V v_ty_242 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_name_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_2428);
  V v_xs_2429 = (g_heff_2erules_2enamesFor(heff_dup(v_len_240)));
  V v_t_2430 = (g_heff_2ereadback_2ereadbTypeF_24s182(v_len_240, v_ty_242));
  V v_t_2431 = ({ V a_0 = v_x_2427; V r_ = (g_heff_2eunify_2ezonker(a_0)); heff_drop(v_x_2427); r_; });
  V v_t_2432 = heff_tr(heff_apply(heff_get(v_t_2431, LBL_ty), 1, (V[]){v_t_2430}));
  V v_t_2433 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2429; V a_2 = v_t_2432; V r_ = (g_heff_2epsurface_2etyF_24s97_24s306(a_0, a_1, a_2)); heff_drop(v_t_2432); r_; });
  return heff_strAppend(((V)&g_heff_2erules_2efreshMeta_str1), heff_strAppend(heff_intShow(v_x_2411), heff_strAppend(((V)&g_heff_2erules_2efreshMeta_str2), heff_strAppend(v_name_243, heff_strAppend(((V)&g_heff_2erules_2efreshMeta_str3), v_t_2433)))));
}
V g_heff_2erules_2efreshMeta_lam9(V self, V *args) {
  V v_sp_27_2440 = args[0];
  V v_i_2441 = args[1];
  V v_locals_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_SpApp, 2, (V[]){v_sp_27_2440, ({ V a_0 = v_locals_241; V a_1 = v_i_2441; V r_ = heff_tr(g_heff_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_locals_241); r_; })});
}
V g_heff_2erules_2efreshMeta_lam10(V self, V *args) {
  V v_u_2443 = args[0];
  V v_ty_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2443);
  return v_ty_242;
}
V g_heff_2erules_2efreshMeta_lam8(V self, V *args) {
  V v_x_2436 = args[0];
  V v_len_240 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_locals_241 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2436);
  V v_t_2437 = (g_heff_2erules_2edownFrom(heff_intSub(heff_dup(v_len_240), MK_INT(1LL))));
  V v_t_2438 = heff_tag(TAG_SMetaApp, 3, (V[]){heff_dup(v_x_2411), heff_arrayFromList(v_t_2437), (g_heff_2ereadback_2ereadbTypeF_24s182(heff_dup(v_len_240), heff_dup(v_ty_242)))});
  V v_t_2439 = (g_heff_2erules_2edownFrom(heff_intSub(v_len_240, MK_INT(1LL))));
  V v_sp_2442 = ({ V a_0 = heff_clo(g_heff_2erules_2efreshMeta_lam9, 2, 1, (V[]){v_locals_241}); V a_1 = NTAG(TAG_SpId); V a_2 = v_t_2439; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2439); r_; });
  V v_t_2444 = (g_heff_2evalue_2emkNeu_24s10(heff_tag(TAG_HMeta, 1, (V[]){v_x_2411}), v_sp_2442, heff_clo(g_heff_2erules_2efreshMeta_lam10, 1, 1, (V[]){v_ty_242}), NTAG(TAG_Nothing)));
  V v_x_2445 = heff_rec(2, shape_326_366, (V[]){v_t_2438, v_t_2444});
  V f_ = v_k_246;
  args[0] = v_x_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2efreshMeta_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_sp_244 = heff_env(self)[0];
  V v_len_240 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_name_243 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_locals_241 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2434 = heff_tag(TAG_Trace, 2, (V[]){heff_rec(3, shape_314_154_337, (V[]){v_sp_244, ((V)&g_heff_2erules_2efreshMeta_str0), heff_clo(g_heff_2erules_2efreshMeta_lam7, 1, 5, (V[]){heff_dup(v_len_240), heff_dup(v_ty_242), v_x_2427, heff_dup(v_x_2411), v_name_243})}), NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2434})}));
  return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2435, heff_clo(g_heff_2erules_2efreshMeta_lam8, 1, 5, (V[]){v_len_240, v_x_2411, v_ty_242, v_locals_241, v_k_246})});
}
V g_heff_2erules_2efreshMeta_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_len_240 = heff_env(self)[2];
  V v_ty_242 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_name_243 = heff_env(self)[5];
  V v_locals_241 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2422);
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2erules_2efreshMeta_lam5_clo)})});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2425}));
  return heff_tail(heff_get(heff_dup(v_hd_245), LBL_bind), 2, (V[]){v_t_2426, heff_clo(g_heff_2erules_2efreshMeta_lam6, 1, 8, (V[]){v_sp_244, v_len_240, v_ty_242, v_x_2411, v_name_243, v_hd_245, v_locals_241, v_k_246})});
}
V g_heff_2erules_2efreshMeta_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_len_240 = heff_env(self)[2];
  V v_ty_242 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_name_243 = heff_env(self)[5];
  V v_locals_241 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2419 = heff_tag(TAG_Put, 2, (V[]){v_x_2418, NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2420})}));
  return heff_tail(heff_get(heff_dup(v_hd_245), LBL_bind), 2, (V[]){v_t_2421, heff_clo(g_heff_2erules_2efreshMeta_lam4, 1, 8, (V[]){v_hd_245, v_sp_244, v_len_240, v_ty_242, v_x_2411, v_name_243, v_locals_241, v_k_246})});
}
V g_heff_2erules_2efreshMeta_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_ty_242 = heff_env(self)[0];
  V v_len_240 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_locals_241 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2efreshMeta_lam2, 1, 5, (V[]){heff_dup(v_ty_242), heff_dup(v_len_240), heff_dup(v_name_243), heff_dup(v_sp_244), heff_dup(v_x_2411)})})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2416}));
  return heff_tail(heff_get(heff_dup(v_hd_245), LBL_bind), 2, (V[]){v_t_2417, heff_clo(g_heff_2erules_2efreshMeta_lam3, 1, 8, (V[]){v_hd_245, v_sp_244, v_len_240, v_ty_242, v_x_2411, v_name_243, v_locals_241, v_k_246})});
}
V g_heff_2erules_2efillHole_lam0(V self, V *args);
V g_heff_2erules_2efillHole_lam1(V self, V *args);
Clo g_heff_2erules_2efillHole_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2efillHole_entry, 6, 0};

V g_heff_2erules_2efillHole(V v_g_240, V v_m_241, V v_e_242, V v_argStx_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2efillHole_lam0, 1, 4, (V[]){v_e_242, v_argStx_243, v_g_240, v_m_241})})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_2418, heff_clo(g_heff_2erules_2efillHole_lam1, 1, 2, (V[]){v_hd_244, v_k_245})});
}
V g_heff_2erules_2efillHole_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2efillHole(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2erules_2efillHole_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_argStx_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = (g_heff_2eunify_2elamsU(heff_get(heff_dup(v_e_242), LBL_arity), heff_dup(v_argStx_243)));
  V v_x1_248 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(v_g_240, NTAG(TAG_N), v_t_247, NTAG(TAG_LNil)));
  V v_t_2412;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nom: {
    V v_x_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_t_2412 = v_x_249;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_248, 0ULL, 1);
    v_t_2412 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2411 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  V v_t_2413 = heff_tag(TAG_Just, 1, (V[]){(g_heff_2eunify_2elamsU(heff_get(heff_dup(v_e_242), LBL_arity), v_argStx_243))});
  V v_t_2414 = heff_rec(6, shape_351_308_309_14_198_314, (V[]){heff_get(heff_dup(v_e_242), LBL_ty), heff_tag(TAG_Just, 1, (V[]){v_t_2412}), v_t_2413, heff_get(heff_dup(v_e_242), LBL_arity), heff_get(heff_dup(v_e_242), LBL_name), heff_get(v_e_242, LBL_span)});
  V v_mc_2415 = (g_map_2einsert_24s194(v_m_241, v_t_2414, heff_get(heff_dup(v_c_246), LBL_metas)));
  return heff_rec(8, shape_139_266_247_190_202_250_346_296, (V[]){heff_get(heff_dup(v_c_246), LBL_infos), heff_get(heff_dup(v_c_246), LBL_recovered), heff_get(heff_dup(v_c_246), LBL_poisoned), v_mc_2415, heff_get(heff_dup(v_c_246), LBL_nextMeta), heff_get(heff_dup(v_c_246), LBL_postponed), heff_get(heff_dup(v_c_246), LBL_trace), heff_get(v_c_246, LBL_selfKey)});
}
V g_heff_2erules_2efillHole_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = heff_tag(TAG_Put, 2, (V[]){v_x_2419, NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2421})}));
  return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2422, v_k_245});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2esolveHole_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 111, 108, 118, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2esolveHole_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2erules_2esolveHole_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2esolveHole_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {41, 32, 58, 61, 32}};
V g_heff_2erules_2esolveHole_lam0(V self, V *args); static Clo g_heff_2erules_2esolveHole_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2esolveHole_lam0, 1, 0};
V g_heff_2erules_2esolveHole_lam3(V self, V *args); static Clo g_heff_2erules_2esolveHole_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2esolveHole_lam3, 1, 0};
V g_heff_2erules_2esolveHole_lam5(V self, V *args);
V g_heff_2erules_2esolveHole_lam6(V self, V *args);
V g_heff_2erules_2esolveHole_lam4(V self, V *args);
V g_heff_2erules_2esolveHole_lam2(V self, V *args);
V g_heff_2erules_2esolveHole_lam1(V self, V *args);
Clo g_heff_2erules_2esolveHole_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2esolveHole_entry, 8, 0};

V g_heff_2erules_2esolveHole(V v_g_240, V v_cs_241, V v_m_242, V v_holeVal_243, V v_argStx_244, V v_argVal_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2erules_2esolveHole_lam0_clo)})});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2410}));
  return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_2411, heff_clo(g_heff_2erules_2esolveHole_lam1, 1, 8, (V[]){v_m_242, v_g_240, v_cs_241, v_holeVal_243, v_argVal_245, v_hd_246, v_k_247, v_argStx_244})});
}
V g_heff_2erules_2esolveHole_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2esolveHole(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2erules_2esolveHole_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get(v_c_248, LBL_metas);
}
V g_heff_2erules_2esolveHole_lam3(V self, V *args) {
  V v_c_2418 = args[0];
  return heff_get(v_c_2418, LBL_metas);
}
V g_heff_2erules_2esolveHole_lam5(V self, V *args) {
  V v_u_2423 = args[0];
  V v_e_2415 = heff_env(self)[0];
  V v_argStx_244 = heff_env(self)[1];
  V v_x_2422 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2423);
  V v_t_2424 = (g_heff_2eunify_2elamsU(heff_get(heff_dup(v_e_2415), LBL_arity), v_argStx_244));
  V v_t_2425 = ({ V a_0 = v_x_2422; V r_ = (g_heff_2eunify_2ezonker(a_0)); heff_drop(v_x_2422); r_; });
  V v_e_2426 = heff_tr(heff_apply(heff_get(v_t_2425, LBL_el), 1, (V[]){v_t_2424}));
  V v_t_2427 = (g_heff_2epsurface_2eelF_24s91_24s305(MK_INT(0LL), NTAG(TAG_Nil), v_e_2426));
  return heff_strAppend(((V)&g_heff_2erules_2esolveHole_str1), heff_strAppend(heff_intShow(v_m_242), heff_strAppend(((V)&g_heff_2erules_2esolveHole_str2), heff_strAppend(heff_get(v_e_2415, LBL_name), heff_strAppend(((V)&g_heff_2erules_2esolveHole_str3), v_t_2427)))));
}
V g_heff_2erules_2esolveHole_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2431);
  V v_t_2432 = heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_247;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2esolveHole_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_e_2415 = heff_env(self)[0];
  V v_argStx_244 = heff_env(self)[1];
  V v_m_242 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2428 = heff_rec(3, shape_314_154_337, (V[]){heff_get(heff_dup(v_e_2415), LBL_span), ((V)&g_heff_2erules_2esolveHole_str0), heff_clo(g_heff_2erules_2esolveHole_lam5, 1, 4, (V[]){v_e_2415, v_argStx_244, v_x_2422, v_m_242})});
  V v_t_2429 = heff_tag(TAG_Trace, 2, (V[]){v_t_2428, NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2429})}));
  return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2430, heff_clo(g_heff_2erules_2esolveHole_lam6, 1, 1, (V[]){v_k_247})});
}
V g_heff_2erules_2esolveHole_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_e_2415 = heff_env(self)[1];
  V v_argStx_244 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2417);
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2erules_2esolveHole_lam3_clo)})});
  V v_t_2420 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2420}));
  return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_2421, heff_clo(g_heff_2erules_2esolveHole_lam4, 1, 5, (V[]){v_e_2415, v_argStx_244, v_m_242, v_hd_246, v_k_247})});
}
V g_heff_2erules_2esolveHole_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_holeVal_243 = heff_env(self)[3];
  V v_argVal_245 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_argStx_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2413 = ({ V a_0 = heff_dup(v_m_242); V a_1 = v_x_2412; V r_ = (g_map_2elookup_24s12(a_0, a_1)); heff_drop(v_x_2412); r_; });
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    heff_drop(v_m_242);
    heff_drop(v_argStx_244);
    V v_t_2414 = (g_heff_2eunify_2euTermF(heff_dup(g_co_2eplus_24s16_get()), ((V)&g_heff_2eunify_2emsEv_clo), ((V)&g_heff_2eunify_2eufEv_clo), heff_dup(g_heff_2eunify_2euk_24s391_get()), v_g_240, v_cs_241, v_holeVal_243, v_argVal_245));
    return (g_heff_2emeta_2eliftU(v_t_2414, v_hd_246, v_k_247));
  }
  case TAG_Just: {
    V v_e_2415 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    V v_t_2416 = heff_get(heff_dup(v_e_2415), LBL_sol);
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nothing: {
      heff_drop(v_cs_241);
      heff_drop(v_holeVal_243);
      heff_drop(v_argVal_245);
      return (g_heff_2erules_2efillHole(v_g_240, heff_dup(v_m_242), heff_dup(v_e_2415), heff_dup(v_argStx_244), heff_dup(v_hd_246), heff_clo(g_heff_2erules_2esolveHole_lam2, 1, 5, (V[]){v_hd_246, v_e_2415, v_argStx_244, v_m_242, v_k_247})));
    }
    case TAG_Just: {
      heff_take_n(v_t_2416, 0ULL, 1);
      heff_drop(v_m_242);
      heff_drop(v_argStx_244);
      heff_drop(v_e_2415);
      V v_t_2434 = (g_heff_2eunify_2euTermF(heff_dup(g_co_2eplus_24s16_get()), ((V)&g_heff_2eunify_2emsEv_clo), ((V)&g_heff_2eunify_2eufEv_clo), heff_dup(g_heff_2eunify_2euk_24s391_get()), v_g_240, v_cs_241, v_holeVal_243, v_argVal_245));
      return (g_heff_2emeta_2eliftU(v_t_2434, v_hd_246, v_k_247));
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2erules_2etyStr_lam0(V self, V *args);
Clo g_heff_2erules_2etyStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2etyStr_entry, 2, 0};

V g_heff_2erules_2etyStr(V v_e_240, V v_t_241) {
top: ;
  V v_t_242 = heff_get(heff_get(heff_dup(v_e_240), LBL_scope), LBL_len);
  V v_t_243 = (g_heff_2ereadback_2ereadbTypeF_24s182(v_t_242, v_t_241));
  V v_t_2410 = (g_heff_2erename_2erkOf(heff_clo(g_heff_2erules_2etyStr_lam0, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_2411 = heff_tr(heff_apply(heff_get(v_t_2410, LBL_ty), 1, (V[]){v_t_243}));
  V v_t_2412 = heff_get(heff_get(v_e_240, LBL_scope), LBL_names);
  return ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2412; V a_2 = v_t_2411; V r_ = (g_heff_2epsurface_2etyF_24s97_24s306(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
}
V g_heff_2erules_2etyStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2etyStr(a[0], a[1]);
}
V g_heff_2erules_2etyStr_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_245 = (g_heff_2erename_2edescribeKey(heff_dup(v_x_244)));
  V v_t_246 = heff_get(heff_get(v_e_240, LBL_globals), LBL_aliases);
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_x2_248 = ({ V a_0 = v_t_247; V a_1 = v_x_244; V r_ = (g_heff_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_247); r_; });
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nothing: {
    return v_d_245;
  }
  case TAG_Just: {
    V v_x_249 = heff_field(v_x2_248, 0);
    heff_take_n(v_x2_248, 1ULL, 1);
    heff_drop(v_d_245);
    return v_x_249;
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2erules_2etyStrM_lam0(V self, V *args);
Clo g_heff_2erules_2etyStrM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2etyStrM_entry, 2, 0};

V g_heff_2erules_2etyStrM(V v_e_240, V v_m_241) {
top: ;
  V v_t_248 = (g_heff_2erename_2erkOf(heff_clo(g_heff_2erules_2etyStrM_lam0, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_249 = heff_tr(heff_apply(heff_get(v_t_248, LBL_ty), 1, (V[]){heff_get(v_m_241, LBL_stx)}));
  V v_t_2410 = heff_get(heff_get(v_e_240, LBL_scope), LBL_names);
  return ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2410; V a_2 = v_t_249; V r_ = (g_heff_2epsurface_2etyF_24s97_24s306(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
}
V g_heff_2erules_2etyStrM_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2etyStrM(a[0], a[1]);
}
V g_heff_2erules_2etyStrM_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_243 = (g_heff_2erename_2edescribeKey(heff_dup(v_x_242)));
  V v_t_244 = heff_get(heff_get(v_e_240, LBL_globals), LBL_aliases);
  V v_t_245 = ({ V a_0 = v_t_244; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_x2_246 = ({ V a_0 = v_t_245; V a_1 = v_x_242; V r_ = (g_heff_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_245); r_; });
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nothing: {
    return v_d_243;
  }
  case TAG_Just: {
    V v_x_247 = heff_field(v_x2_246, 0);
    heff_take_n(v_x2_246, 1ULL, 1);
    heff_drop(v_d_243);
    return v_x_247;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2erules_2eeqTyStr_lam0(V self, V *args);
Clo g_heff_2erules_2eeqTyStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eeqTyStr_entry, 3, 0};

V g_heff_2erules_2eeqTyStr(V v_g_240, V v_cs_241, V v_t_242) {
top: ;
  V v_t_243 = (g_heff_2ereadback_2ereadbTypeF_24s182(heff_get(heff_dup(v_cs_241), LBL_len), v_t_242));
  V v_t_249 = (g_heff_2erename_2erkOf(heff_clo(g_heff_2erules_2eeqTyStr_lam0, 1, 1, (V[]){v_g_240})));
  V v_t_2410 = heff_tr(heff_apply(heff_get(v_t_249, LBL_ty), 1, (V[]){v_t_243}));
  return ({ V a_0 = MK_INT(0LL); V a_1 = heff_get(v_cs_241, LBL_names); V a_2 = v_t_2410; V r_ = (g_heff_2epsurface_2etyF_24s97_24s306(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
}
V g_heff_2erules_2eeqTyStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2eeqTyStr(a[0], a[1], a[2]);
}
V g_heff_2erules_2eeqTyStr_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_245 = (g_heff_2erename_2edescribeKey(heff_dup(v_x_244)));
  V v_t_246 = ({ V b_0 = heff_get(v_g_240, LBL_aliases); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_247 = ({ V a_0 = v_t_246; V a_1 = v_x_244; V r_ = (g_heff_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_246); r_; });
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    return v_d_245;
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x2_247, 0);
    heff_take_n(v_x2_247, 1ULL, 1);
    heff_drop(v_d_245);
    return v_x_248;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2erules_2eeqElStr_lam0(V self, V *args);
Clo g_heff_2erules_2eeqElStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eeqElStr_entry, 3, 0};

V g_heff_2erules_2eeqElStr(V v_g_240, V v_cs_241, V v_v_242) {
top: ;
  V v_e_243 = (g_heff_2ereadback_2ereadbTermF_24s178(heff_get(heff_dup(v_cs_241), LBL_len), v_v_242));
  V v_t_249 = (g_heff_2erename_2erkOf(heff_clo(g_heff_2erules_2eeqElStr_lam0, 1, 1, (V[]){v_g_240})));
  V v_e_2410 = heff_tr(heff_apply(heff_get(v_t_249, LBL_el), 1, (V[]){v_e_243}));
  HEFF_LAST return g_heff_2epsurface_2eelF_24s91_24s305(MK_INT(0LL), heff_get(v_cs_241, LBL_names), v_e_2410);
}
V g_heff_2erules_2eeqElStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2eeqElStr(a[0], a[1], a[2]);
}
V g_heff_2erules_2eeqElStr_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_245 = (g_heff_2erename_2edescribeKey(heff_dup(v_x_244)));
  V v_t_246 = ({ V b_0 = heff_get(v_g_240, LBL_aliases); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_247 = ({ V a_0 = v_t_246; V a_1 = v_x_244; V r_ = (g_heff_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_246); r_; });
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    return v_d_245;
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x2_247, 0);
    heff_take_n(v_x2_247, 1ULL, 1);
    heff_drop(v_d_245);
    return v_x_248;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2erules_2eeqBareStr_lam0(V self, V *args);
Clo g_heff_2erules_2eeqBareStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eeqBareStr_entry, 4, 0};

V g_heff_2erules_2eeqBareStr(V v_g_240, V v_cs_241, V v_h_242, V v_sp_243) {
top: ;
  V v_e_244 = (g_heff_2ereadback_2ereadbBare_24s185(heff_get(heff_dup(v_cs_241), LBL_len), v_h_242, v_sp_243));
  V v_t_2410 = (g_heff_2erename_2erkOf(heff_clo(g_heff_2erules_2eeqBareStr_lam0, 1, 1, (V[]){v_g_240})));
  V v_e_2411 = heff_tr(heff_apply(heff_get(v_t_2410, LBL_el), 1, (V[]){v_e_244}));
  return (g_heff_2epsurface_2eelF_24s91_24s305(MK_INT(0LL), heff_get(v_cs_241, LBL_names), v_e_2411));
}
V g_heff_2erules_2eeqBareStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2eeqBareStr(a[0], a[1], a[2], a[3]);
}
V g_heff_2erules_2eeqBareStr_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_246 = (g_heff_2erename_2edescribeKey(heff_dup(v_x_245)));
  V v_t_247 = ({ V b_0 = heff_get(v_g_240, LBL_aliases); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_248 = ({ V a_0 = v_t_247; V a_1 = v_x_245; V r_ = (g_heff_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_247); r_; });
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nothing: {
    return v_d_246;
  }
  case TAG_Just: {
    V v_x_249 = heff_field(v_x2_248, 0);
    heff_take_n(v_x2_248, 1ULL, 1);
    heff_drop(v_d_246);
    return v_x_249;
  }
  default: return heff_nomatch(v_x2_248);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2erules_2eprettyEqErr_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {116, 121, 112, 101, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2eprettyEqErr_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 97, 110, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2erules_2eprettyEqErr_str2 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 97, 114, 101, 32, 110, 111, 116, 32, 101, 113, 117, 97, 108, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2erules_2eprettyEqErr_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {101, 108, 101, 109, 101, 110, 116, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2eprettyEqErr_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 97, 110, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2erules_2eprettyEqErr_str5 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 97, 114, 101, 32, 110, 111, 116, 32, 101, 113, 117, 97, 108, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2erules_2eprettyEqErr_str6 = {{0x80000000u, K_STR, 0}, 9, 9, {110, 101, 117, 116, 114, 97, 108, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2eprettyEqErr_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 97, 110, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2erules_2eprettyEqErr_str8 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 97, 114, 101, 32, 110, 111, 116, 32, 101, 113, 117, 97, 108, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2erules_2eprettyEqErr_str9 = {{0x80000000u, K_STR, 0}, 47, 47, {97, 32, 115, 111, 108, 117, 116, 105, 111, 110, 32, 119, 111, 117, 108, 100, 32, 109, 101, 110, 116, 105, 111, 110, 32, 119, 104, 97, 116, 32, 100, 105, 100, 32, 110, 111, 116, 32, 101, 108, 97, 98, 111, 114, 97, 116, 101}};
Clo g_heff_2erules_2eprettyEqErr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eprettyEqErr_entry, 2, 0};

V g_heff_2erules_2eprettyEqErr(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_UnequalTys: {
    V v_cs_242 = heff_field(v_x2_241, 0);
    V v_a_243 = heff_field(v_x2_241, 1);
    V v_a2_244 = heff_field(v_x2_241, 2);
    V v_t_245 = (g_heff_2erules_2eeqTyStr(heff_dup(v_g_240), heff_dup(v_cs_242), heff_dup(v_a_243)));
    V v_t_246 = (g_heff_2erules_2eeqTyStr(v_g_240, heff_dup(v_cs_242), heff_dup(v_a2_244)));
    return heff_strAppend(((V)&g_heff_2erules_2eprettyEqErr_str0), heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2erules_2eprettyEqErr_str1), heff_strAppend(v_t_246, ((V)&g_heff_2erules_2eprettyEqErr_str2)))));
  }
  case TAG_UnequalEls: {
    V v_cs_247 = heff_field(v_x2_241, 0);
    V v_a_248 = heff_field(v_x2_241, 1);
    V v_a2_249 = heff_field(v_x2_241, 2);
    V v_t_2410 = (g_heff_2erules_2eeqElStr(heff_dup(v_g_240), heff_dup(v_cs_247), heff_dup(v_a_248)));
    V v_t_2411 = (g_heff_2erules_2eeqElStr(v_g_240, heff_dup(v_cs_247), heff_dup(v_a2_249)));
    return heff_strAppend(((V)&g_heff_2erules_2eprettyEqErr_str3), heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2erules_2eprettyEqErr_str4), heff_strAppend(v_t_2411, ((V)&g_heff_2erules_2eprettyEqErr_str5)))));
  }
  case TAG_UnequalNeus: {
    V v_cs_2412 = heff_field(v_x2_241, 0);
    V v_h_2413 = heff_field(v_x2_241, 1);
    V v_sp_2414 = heff_field(v_x2_241, 2);
    V v_h2_2415 = heff_field(v_x2_241, 3);
    V v_sp2_2416 = heff_field(v_x2_241, 4);
    V v_t_2417 = (g_heff_2erules_2eeqBareStr(heff_dup(v_g_240), heff_dup(v_cs_2412), heff_dup(v_h_2413), heff_dup(v_sp_2414)));
    V v_t_2418 = (g_heff_2erules_2eeqBareStr(v_g_240, heff_dup(v_cs_2412), heff_dup(v_h2_2415), heff_dup(v_sp2_2416)));
    return heff_strAppend(((V)&g_heff_2erules_2eprettyEqErr_str6), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2erules_2eprettyEqErr_str7), heff_strAppend(v_t_2418, ((V)&g_heff_2erules_2eprettyEqErr_str8)))));
  }
  case TAG_MentionsError: {
    heff_drop(v_g_240);
    return ((V)&g_heff_2erules_2eprettyEqErr_str9);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2erules_2eprettyEqErr_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2eprettyEqErr(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2erules_2etyStrZ_lam0(V self, V *args); static Clo g_heff_2erules_2etyStrZ_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2etyStrZ_lam0, 1, 0};
V g_heff_2erules_2etyStrZ_lam2(V self, V *args);
V g_heff_2erules_2etyStrZ_lam1(V self, V *args);
Clo g_heff_2erules_2etyStrZ_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2etyStrZ_entry, 4, 0};

V g_heff_2erules_2etyStrZ(V v_e_240, V v_t_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2erules_2etyStrZ_lam0_clo)})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_246}));
  return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2erules_2etyStrZ_lam1, 1, 3, (V[]){v_e_240, v_t_241, v_k_243})});
}
V g_heff_2erules_2etyStrZ_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2etyStrZ(a[0], a[1], a[2], a[3]);
}
V g_heff_2erules_2etyStrZ_lam0(V self, V *args) {
  V v_c_244 = args[0];
  return heff_get(v_c_244, LBL_metas);
}
V g_heff_2erules_2etyStrZ_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_2414 = (g_heff_2erename_2edescribeKey(heff_dup(v_x_2413)));
  V v_t_2415 = heff_get(heff_get(v_e_240, LBL_globals), LBL_aliases);
  V v_t_2416 = ({ V a_0 = v_t_2415; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_2415); r_; });
  V v_x2_2417 = ({ V a_0 = v_t_2416; V a_1 = v_x_2413; V r_ = (g_heff_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_2416); r_; });
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_Nothing: {
    return v_d_2414;
  }
  case TAG_Just: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    heff_take_n(v_x2_2417, 1ULL, 1);
    heff_drop(v_d_2414);
    return v_x_2418;
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2erules_2etyStrZ_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_get(heff_get(heff_dup(v_e_240), LBL_scope), LBL_len);
  V v_t_2410 = (g_heff_2ereadback_2ereadbTypeF_24s182(v_t_249, v_t_241));
  V v_t_2411 = ({ V a_0 = v_x_248; V r_ = (g_heff_2eunify_2ezonker(a_0)); heff_drop(v_x_248); r_; });
  V v_t_2412 = heff_tr(heff_apply(heff_get(v_t_2411, LBL_ty), 1, (V[]){v_t_2410}));
  V v_t_2419 = (g_heff_2erename_2erkOf(heff_clo(g_heff_2erules_2etyStrZ_lam2, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_2420 = heff_tr(heff_apply(heff_get(v_t_2419, LBL_ty), 1, (V[]){v_t_2412}));
  V v_t_2421 = heff_get(heff_get(v_e_240, LBL_scope), LBL_names);
  V v_x_2422 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2421; V a_2 = v_t_2420; V r_ = (g_heff_2epsurface_2etyF_24s97_24s306(a_0, a_1, a_2)); heff_drop(v_t_2420); r_; });
  V f_ = v_k_243;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2ekeepRecovered_lam0(V self, V *args);
V g_heff_2erules_2ekeepRecovered_lam3(V self, V *args);
V g_heff_2erules_2ekeepRecovered_lam5(V self, V *args);
V g_heff_2erules_2ekeepRecovered_lam4(V self, V *args);
V g_heff_2erules_2ekeepRecovered_lam2(V self, V *args);
V g_heff_2erules_2ekeepRecovered_lam1(V self, V *args);
Clo g_heff_2erules_2ekeepRecovered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2ekeepRecovered_entry, 5, 0};

V g_heff_2erules_2ekeepRecovered(V v_kept_240, V v_saved_241, V v_waiting_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2ekeepRecovered_lam0, 1, 1, (V[]){v_kept_240})})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_248}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2erules_2ekeepRecovered_lam1, 1, 4, (V[]){v_hd_243, v_saved_241, v_waiting_242, v_k_244})});
}
V g_heff_2erules_2ekeepRecovered_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2ekeepRecovered(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2erules_2ekeepRecovered_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_kept_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_kept_240, heff_get(heff_dup(v_c_245), LBL_recovered)});
  return heff_rec(8, shape_139_266_247_190_202_250_346_296, (V[]){heff_get(heff_dup(v_c_245), LBL_infos), v_t_246, heff_get(heff_dup(v_c_245), LBL_poisoned), heff_get(heff_dup(v_c_245), LBL_metas), heff_get(heff_dup(v_c_245), LBL_nextMeta), heff_get(heff_dup(v_c_245), LBL_postponed), heff_get(heff_dup(v_c_245), LBL_trace), heff_get(v_c_245, LBL_selfKey)});
}
V g_heff_2erules_2ekeepRecovered_lam3(V self, V *args) {
  V v_c_2415 = args[0];
  V v_saved_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_rec(8, shape_139_266_247_190_202_250_346_296, (V[]){heff_get(heff_dup(v_c_2415), LBL_infos), heff_get(heff_dup(v_c_2415), LBL_recovered), heff_get(heff_dup(v_c_2415), LBL_poisoned), heff_get(heff_dup(v_c_2415), LBL_metas), heff_get(heff_dup(v_c_2415), LBL_nextMeta), heff_get(v_saved_241, LBL_postponed), heff_get(heff_dup(v_c_2415), LBL_trace), heff_get(v_c_2415, LBL_selfKey)});
}
V g_heff_2erules_2ekeepRecovered_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_waiting_242 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2423);
  V v_t_2424 = heff_tag(TAG_RestoreDelayed, 2, (V[]){v_waiting_242, NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2425}));
  return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2426, v_k_244});
}
V g_heff_2erules_2ekeepRecovered_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_waiting_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2420 = heff_tag(TAG_Put, 2, (V[]){v_x_2419, NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2421})}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2422, heff_clo(g_heff_2erules_2ekeepRecovered_lam5, 1, 3, (V[]){v_waiting_242, v_hd_243, v_k_244})});
}
V g_heff_2erules_2ekeepRecovered_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_saved_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_waiting_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2414);
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2ekeepRecovered_lam3, 1, 1, (V[]){v_saved_241})})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2418, heff_clo(g_heff_2erules_2ekeepRecovered_lam4, 1, 3, (V[]){v_hd_243, v_waiting_242, v_k_244})});
}
V g_heff_2erules_2ekeepRecovered_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_saved_241 = heff_env(self)[1];
  V v_waiting_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag(TAG_Put, 2, (V[]){v_x_2410, NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2413, heff_clo(g_heff_2erules_2ekeepRecovered_lam2, 1, 4, (V[]){v_saved_241, v_hd_243, v_waiting_242, v_k_244})});
}
V g_heff_2erules_2erecoverWith_lam3(V self, V *args);
V g_heff_2erules_2erecoverWith_lam2(V self, V *args);
V g_heff_2erules_2erecoverWith_lam1(V self, V *args);
V g_heff_2erules_2erecoverWith_lam0(V self, V *args);
Clo g_heff_2erules_2erecoverWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erecoverWith_entry, 7, 0};

V g_heff_2erules_2erecoverWith(V v_e_240, V v_a_241, V v_d_242, V v_saved_243, V v_waiting_244, V v_hd_245, V v_k_246) {
top: ;
  return (g_heff_2emeta_2eblockedTy(heff_dup(v_a_241), heff_dup(v_hd_245), heff_clo(g_heff_2erules_2erecoverWith_lam0, 1, 6, (V[]){v_d_242, v_saved_243, v_waiting_244, v_hd_245, v_a_241, v_k_246})));
}
V g_heff_2erules_2erecoverWith_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2erecoverWith(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[0]); return r;
}
V g_heff_2erules_2erecoverWith_lam3(V self, V *args) {
  V v_u_2412 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2412);
  return v_a_241;
}
V g_heff_2erules_2erecoverWith_lam2(V self, V *args) {
  V v_u_2411 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2411);
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2emkNeu_24s10(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2erecoverWith_lam3, 1, 1, (V[]){v_a_241}), NTAG(TAG_Nothing)))});
}
V g_heff_2erules_2erecoverWith_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_a_241 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2410);
  V v_t_2413 = heff_rec(2, shape_326_366, (V[]){NTAG(TAG_SAbandon), heff_clo(g_heff_2erules_2erecoverWith_lam2, 1, 1, (V[]){v_a_241})});
  V f_ = v_k_246;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2erecoverWith_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_saved_243 = heff_env(self)[1];
  V v_waiting_244 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_a_241 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_248;
  switch (heff_tag_of(v_x_247)) {
  case TAG_True: {
    v_t_248 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(-1LL), heff_get(heff_dup(v_d_242), LBL_severity), heff_get(heff_dup(v_d_242), LBL_msg), heff_get(heff_dup(v_d_242), LBL_span), heff_get(v_d_242, LBL_note)});
    break;
  }
  case TAG_False: {
    v_t_248 = v_d_242;
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V v_c_249 = heff_tr(heff_apply(((V)&g_heff_2erules_2ekeepRecovered_clo), 3, (V[]){v_t_248, v_saved_243, v_waiting_244}));
  return heff_tail(v_c_249, 2, (V[]){v_hd_245, heff_clo(g_heff_2erules_2erecoverWith_lam1, 1, 2, (V[]){v_a_241, v_k_246})});
}
V g_heff_2erules_2erecovering_lam1(V self, V *args); static Clo g_heff_2erules_2erecovering_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erecovering_lam1, 1, 0};
V g_heff_2erules_2erecovering_lam3(V self, V *args); static Clo g_heff_2erules_2erecovering_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erecovering_lam3, 1, 0};
V g_heff_2erules_2erecovering_lam5(V self, V *args);
V g_heff_2erules_2erecovering_lam4(V self, V *args);
V g_heff_2erules_2erecovering_lam2(V self, V *args);
V g_heff_2erules_2erecovering_lam0(V self, V *args);
Clo g_heff_2erules_2erecovering_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erecovering_entry, 1, 0};

V g_heff_2erules_2erecovering(V v_c_240) {
top: ;
  return heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2erules_2erecovering_lam0, 4, 1, (V[]){heff_dup(v_c_240)})});
}
V g_heff_2erules_2erecovering_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2erecovering(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2erules_2erecovering_lam1(V self, V *args) {
  V v_c0_245 = args[0];
  return v_c0_245;
}
V g_heff_2erules_2erecovering_lam3(V self, V *args) {
  V v_sv_2410 = args[0];
  return v_sv_2410;
}
V g_heff_2erules_2erecovering_lam5(V self, V *args) {
  V v_s_2417 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_a_242 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_e_241; V a_1 = v_a_242; V a_2 = v_s_2417; V a_3 = v_x_249; V a_4 = v_x_2413; V a_5 = heff_dup(v_hd_243); V a_6 = heff_get(v_hd_243, LBL_ret); V r_ = (g_heff_2erules_2erecoverWith(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_e_241); r_; });
}
V g_heff_2erules_2erecovering_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_x_249 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_m_2415;
  switch (heff_tag_of(v_c_240)) {
  case TAG_MkChk: {
    V v_f_2414 = heff_field(v_c_240, 0);
    heff_take_n(v_c_240, 1ULL, 1);
    v_m_2415 = heff_tr(heff_apply(v_f_2414, 2, (V[]){heff_dup(v_e_241), heff_dup(v_a_242)}));
    break;
  }
  default: heff_nomatch(v_c_240);
  }
  V v_t_2416 = heff_tr(heff_apply(v_m_2415, 2, (V[]){heff_dup(v_hd_243), heff_get(heff_dup(v_hd_243), LBL_ret)}));
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Catch, 2, (V[]){v_t_2416, heff_clo(g_heff_2erules_2erecovering_lam5, 1, 5, (V[]){v_e_241, v_a_242, v_x_249, v_x_2413, heff_dup(v_hd_243)})})});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2419}));
  return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2420, v_k_244});
}
V g_heff_2erules_2erecovering_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_SaveDelayed, 1, (V[]){((V)&g_heff_2erules_2erecovering_lam3_clo)})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2erules_2erecovering_lam4, 1, 6, (V[]){v_c_240, v_e_241, v_a_242, v_hd_243, v_x_249, v_k_244})});
}
V g_heff_2erules_2erecovering_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_242 = args[1];
  V v_hd_243 = args[2];
  V v_k_244 = args[3];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2erules_2erecovering_lam1_clo)})});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_247}));
  V f_ = heff_get(heff_dup(v_hd_243), LBL_bind);
  args[0] = v_t_248;
  args[1] = heff_clo(g_heff_2erules_2erecovering_lam2, 1, 5, (V[]){v_hd_243, v_c_240, v_e_241, v_a_242, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2einstShown_lam0(V self, V *args);
Clo g_heff_2erules_2einstShown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2einstShown_entry, 3, 0};

V g_heff_2erules_2einstShown(V v_e_240, V v_mc_241, V v_goal_242) {
top: ;
  V v_t_243 = heff_get(heff_get(heff_dup(v_e_240), LBL_scope), LBL_len);
  V v_t_244 = (g_heff_2ereadback_2ereadbTypeF_24s182(v_t_243, v_goal_242));
  V v_t_245 = (g_heff_2eunify_2ezonker(v_mc_241));
  V v_t_246 = heff_tr(heff_apply(heff_get(v_t_245, LBL_ty), 1, (V[]){v_t_244}));
  V v_t_2413 = (g_heff_2erename_2erkOf(heff_clo(g_heff_2erules_2einstShown_lam0, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_2414 = heff_tr(heff_apply(heff_get(v_t_2413, LBL_ty), 1, (V[]){v_t_246}));
  V v_t_2415 = heff_get(heff_get(v_e_240, LBL_scope), LBL_names);
  return ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2415; V a_2 = v_t_2414; V r_ = (g_heff_2epsurface_2etyF_24s97_24s306(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
}
V g_heff_2erules_2einstShown_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2einstShown(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2erules_2einstShown_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_248 = (g_heff_2erename_2edescribeKey(heff_dup(v_x_247)));
  V v_t_249 = heff_get(heff_get(v_e_240, LBL_globals), LBL_aliases);
  V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_x2_2411 = ({ V a_0 = v_t_2410; V a_1 = v_x_247; V r_ = (g_heff_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_2410); r_; });
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nothing: {
    return v_d_248;
  }
  case TAG_Just: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    heff_take_n(v_x2_2411, 1ULL, 1);
    heff_drop(v_d_248);
    return v_x_2412;
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2erules_2ewitnessMatches_lam0(V self, V *args); static Clo g_heff_2erules_2ewitnessMatches_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2ewitnessMatches_lam0, 2, 0};
V g_heff_2erules_2ewitnessMatches_lam3(V self, V *args);
V g_heff_2erules_2ewitnessMatches_lam2(V self, V *args);
V g_heff_2erules_2ewitnessMatches_lam1(V self, V *args);
Clo g_heff_2erules_2ewitnessMatches_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2ewitnessMatches_entry, 3, 0};

V g_heff_2erules_2ewitnessMatches(V v_e_240, V v_goal_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_goal_241);
    return ((V)&g_heff_2erules_2ewitnessMatches_lam0_clo);
  }
  case TAG_Cons: {
    V v_w_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_c_247 = heff_get(heff_dup(v_e_240), LBL_scope);
    V v_cs_248 = heff_rec(2, shape_168_200, (V[]){heff_get(heff_dup(v_c_247), LBL_len), heff_get(v_c_247, LBL_names)});
    V v_t_249 = heff_tr(heff_apply(((V)&g_heff_2eunify_2euTypeF_24s392_clo), 4, (V[]){heff_get(heff_dup(v_e_240), LBL_globals), v_cs_248, heff_dup(v_goal_241), heff_get(heff_dup(v_w_245), LBL_ty)}));
    V v_t_2410 = heff_tr(heff_apply(((V)&g_heff_2emeta_2eliftU_clo), 1, (V[]){v_t_249}));
    V v_c_2411 = heff_tr(heff_apply(((V)&g_heff_2emeta_2eattempt_clo), 1, (V[]){v_t_2410}));
    return heff_clo(g_heff_2erules_2ewitnessMatches_lam1, 2, 5, (V[]){v_c_2411, v_e_240, v_goal_241, v_rest_246, v_w_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2erules_2ewitnessMatches_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2ewitnessMatches(a[0], a[1], a[2]);
}
V g_heff_2erules_2ewitnessMatches_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2ewitnessMatches_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  V v_w_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    heff_take_n(v_x_2414, 0ULL, 1);
    heff_drop(v_w_245);
    V f_ = v_k_2413;
    args[0] = v_x_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2414, 0ULL, 1);
    V f_ = v_k_2413;
    args[0] = heff_tag(TAG_Cons, 2, (V[]){v_w_245, v_x_2416});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2erules_2ewitnessMatches_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_goal_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2412 = heff_env(self)[3];
  V v_k_2413 = heff_env(self)[4];
  V v_w_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2415 = (g_heff_2erules_2ewitnessMatches(v_e_240, v_goal_241, v_rest_246));
  return heff_tail(v_c_2415, 2, (V[]){v_hd_2412, heff_clo(g_heff_2erules_2ewitnessMatches_lam3, 1, 3, (V[]){v_x_2414, v_k_2413, v_w_245})});
}
V g_heff_2erules_2ewitnessMatches_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_goal_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_w_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo(g_heff_2erules_2ewitnessMatches_lam2, 1, 6, (V[]){v_e_240, v_goal_241, v_rest_246, v_hd_2412, v_k_2413, v_w_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[52]; } g_heff_2erules_2eresolveWanted_str0 = {{0x80000000u, K_STR, 0}, 52, 52, {97, 110, 32, 105, 110, 115, 116, 97, 110, 99, 101, 32, 97, 114, 103, 117, 109, 101, 110, 116, 39, 115, 32, 116, 121, 112, 101, 32, 105, 115, 32, 110, 111, 116, 32, 100, 101, 116, 101, 114, 109, 105, 110, 101, 100, 32, 104, 101, 114, 101, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[79]; } g_heff_2erules_2eresolveWanted_str1 = {{0x80000000u, K_STR, 0}, 79, 79, {103, 105, 118, 101, 32, 116, 104, 101, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 101, 120, 112, 108, 105, 99, 105, 116, 108, 121, 44, 32, 111, 114, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 115, 111, 32, 116, 104, 101, 32, 105, 109, 112, 108, 105, 99, 105, 116, 115, 32, 97, 114, 111, 117, 110, 100, 32, 105, 116, 32, 97, 114, 101, 32, 115, 111, 108, 118, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2erules_2eresolveWanted_str2 = {{0x80000000u, K_STR, 0}, 16, 16, {110, 111, 32, 105, 110, 115, 116, 97, 110, 99, 101, 32, 102, 111, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2erules_2eresolveWanted_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {32, 105, 110, 32, 115, 99, 111, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[72]; } g_heff_2erules_2eresolveWanted_str4 = {{0x80000000u, K_STR, 0}, 72, 72, {98, 105, 110, 100, 32, 111, 110, 101, 44, 32, 96, 123, 123, 120, 32, 58, 32, 84, 125, 125, 32, 45, 62, 32, 46, 46, 46, 96, 44, 32, 119, 104, 101, 114, 101, 32, 116, 104, 105, 115, 32, 105, 115, 32, 117, 115, 101, 100, 44, 32, 111, 114, 32, 103, 105, 118, 101, 32, 105, 116, 58, 32, 96, 40, 120, 32, 58, 61, 32, 101, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2erules_2eresolveWanted_str5 = {{0x80000000u, K_STR, 0}, 20, 20, {116, 104, 101, 32, 105, 110, 115, 116, 97, 110, 99, 101, 32, 102, 111, 117, 110, 100, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2erules_2eresolveWanted_str6 = {{0x80000000u, K_STR, 0}, 19, 19, {44, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 102, 105, 116, 32, 104, 101, 114, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2erules_2eresolveWanted_str7 = {{0x80000000u, K_STR, 0}, 8, 8, {105, 110, 115, 116, 97, 110, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2erules_2eresolveWanted_str8 = {{0x80000000u, K_STR, 0}, 6, 6, {102, 111, 117, 110, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2erules_2eresolveWanted_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2eresolveWanted_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2erules_2eresolveWanted_str11 = {{0x80000000u, K_STR, 0}, 27, 27, {109, 111, 114, 101, 32, 116, 104, 97, 110, 32, 111, 110, 101, 32, 105, 110, 115, 116, 97, 110, 99, 101, 32, 102, 111, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2erules_2eresolveWanted_str12 = {{0x80000000u, K_STR, 0}, 11, 11, {32, 105, 110, 32, 115, 99, 111, 112, 101, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[100]; } g_heff_2erules_2eresolveWanted_str13 = {{0x80000000u, K_STR, 0}, 100, 100, {116, 104, 101, 121, 32, 99, 97, 110, 110, 111, 116, 32, 98, 101, 32, 116, 111, 108, 100, 32, 97, 112, 97, 114, 116, 32, 98, 121, 32, 116, 121, 112, 101, 32, 40, 115, 109, 97, 108, 108, 32, 118, 97, 108, 117, 101, 115, 32, 97, 114, 101, 32, 115, 116, 97, 116, 105, 99, 97, 108, 108, 121, 32, 111, 112, 97, 113, 117, 101, 41, 58, 32, 103, 105, 118, 101, 32, 116, 104, 101, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 101, 120, 112, 108, 105, 99, 105, 116, 108, 121}};
V g_heff_2erules_2eresolveWanted_lam0(V self, V *args); static Clo g_heff_2erules_2eresolveWanted_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eresolveWanted_lam0, 1, 0};
V g_heff_2erules_2eresolveWanted_lam2(V self, V *args);
V g_heff_2erules_2eresolveWanted_lam5(V self, V *args);
V g_heff_2erules_2eresolveWanted_lam6(V self, V *args);
V g_heff_2erules_2eresolveWanted_lam4(V self, V *args);
V g_heff_2erules_2eresolveWanted_lam3(V self, V *args);
V g_heff_2erules_2eresolveWanted_lam1(V self, V *args);
Clo g_heff_2erules_2eresolveWanted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eresolveWanted_entry, 8, 0};

V g_heff_2erules_2eresolveWanted(V v_e_240, V v_sp_241, V v_hm_242, V v_holeVal_243, V v_goal_244, V v_final_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2erules_2eresolveWanted_lam0_clo)})});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2410}));
  return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_2411, heff_clo(g_heff_2erules_2eresolveWanted_lam1, 1, 8, (V[]){v_e_240, v_goal_244, heff_dup(v_final_245), v_sp_241, v_hd_246, v_k_247, v_hm_242, v_holeVal_243})});
}
V g_heff_2erules_2eresolveWanted_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2eresolveWanted(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[5]); return r;
}
V g_heff_2erules_2eresolveWanted_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get(v_c_248, LBL_metas);
}
V g_heff_2erules_2eresolveWanted_lam2(V self, V *args) {
  V v_c_2425 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_get(heff_get(v_e_240, LBL_scope), LBL_len);
  V v_stx_2427 = (g_heff_2ereadback_2ereadbTermF_24s178(v_t_2426, heff_get(heff_dup(v_c_2425), LBL_v)));
  return heff_rec(4, shape_198_351_326_366, (V[]){heff_get(heff_dup(v_c_2425), LBL_name), heff_get(heff_dup(v_c_2425), LBL_ty), v_stx_2427, heff_get(v_c_2425, LBL_v)});
}
V g_heff_2erules_2eresolveWanted_lam5(V self, V *args) {
  V v_u_2451 = args[0];
  V v_one_2437 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_goal_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2451);
  return heff_strAppend(((V)&g_heff_2erules_2eresolveWanted_str8), heff_strAppend(heff_get(v_one_2437, LBL_name), heff_strAppend(((V)&g_heff_2erules_2eresolveWanted_str9), ({ V a_0 = v_e_240; V a_1 = v_x_2412; V a_2 = v_goal_244; V r_ = (g_heff_2erules_2einstShown(a_0, a_1, a_2)); heff_drop(v_x_2412); r_; }))));
}
V g_heff_2erules_2eresolveWanted_lam6(V self, V *args) {
  V v_x_2454 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2454);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2eresolveWanted_lam4(V self, V *args) {
  V v_x_2442 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_one_2437 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_x_2412 = heff_env(self)[5];
  V v_goal_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Left: {
    V v_err_2443 = heff_field(v_x_2442, 0);
    V v_ru_24x_2442_24Left = heff_take_reuse_n(v_x_2442, 1ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_goal_244);
    V v_note_2444 = ({ V a_0 = heff_get(v_e_240, LBL_globals); V a_1 = v_err_2443; V r_ = (g_heff_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2443); r_; });
    V v_t_2445 = heff_strAppend(((V)&g_heff_2erules_2eresolveWanted_str5), heff_strAppend(heff_get(v_one_2437, LBL_name), ((V)&g_heff_2erules_2eresolveWanted_str6)));
    V v_t_2446 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_2445, v_sp_241, heff_tag(TAG_Just, 1, (V[]){v_note_2444})});
    V v_t_2447 = heff_tag_at(v_ru_24x_2442_24Left, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2448}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2449, v_k_247});
  }
  case TAG_Right: {
    heff_take_n(v_x_2442, 0ULL, 1);
    V v_t_2452 = heff_tag(TAG_Trace, 2, (V[]){heff_rec(3, shape_314_154_337, (V[]){v_sp_241, ((V)&g_heff_2erules_2eresolveWanted_str7), heff_clo(g_heff_2erules_2eresolveWanted_lam5, 1, 4, (V[]){v_one_2437, v_e_240, v_x_2412, v_goal_244})}), NTAG(TAG_MkUnit)});
    V v_t_2453 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2452})}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2453, heff_clo(g_heff_2erules_2eresolveWanted_lam6, 1, 1, (V[]){v_k_247})});
  }
  default: return heff_nomatch(v_x_2442);
  }
}
V g_heff_2erules_2eresolveWanted_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_goal_244 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_hm_242 = heff_env(self)[6];
  V v_holeVal_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Nil: {
    heff_drop(v_hm_242);
    heff_drop(v_holeVal_243);
    V v_t_2431 = ({ V a_0 = v_e_240; V a_1 = v_x_2412; V a_2 = v_goal_244; V r_ = (g_heff_2erules_2einstShown(a_0, a_1, a_2)); heff_drop(v_x_2412); r_; });
    V v_msg_2432 = heff_strAppend(((V)&g_heff_2erules_2eresolveWanted_str2), heff_strAppend(v_t_2431, ((V)&g_heff_2erules_2eresolveWanted_str3)));
    V v_t_2433 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(341LL), NTAG(TAG_SError), v_msg_2432, v_sp_241, heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2erules_2eresolveWanted_str4)})});
    V v_t_2434 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2435}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2436, v_k_247});
  }
  case TAG_Cons: {
    V v_one_2437 = heff_dup(heff_field(v_x_2430, 0));
    V v_it2_2438 = heff_dup(heff_field(v_x_2430, 1));
    switch (heff_tag_of(v_it2_2438)) {
    case TAG_Nil: {
      heff_drop_tag(v_x_2430, 2);
      V v_c_2439 = heff_get(heff_dup(v_e_240), LBL_scope);
      V v_t_2440 = heff_rec(2, shape_168_200, (V[]){heff_get(heff_dup(v_c_2439), LBL_len), heff_get(v_c_2439, LBL_names)});
      V v_c_2441 = heff_tr(heff_apply(((V)&g_heff_2erules_2esolveHole_clo), 6, (V[]){heff_get(heff_dup(v_e_240), LBL_globals), v_t_2440, v_hm_242, v_holeVal_243, heff_get(heff_dup(v_one_2437), LBL_stx), heff_get(heff_dup(v_one_2437), LBL_val)}));
      return heff_tail(v_c_2441, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2erules_2eresolveWanted_lam4, 1, 7, (V[]){v_e_240, v_one_2437, v_sp_241, v_hd_246, v_k_247, v_x_2412, v_goal_244})});
    }
    case TAG_Cons: {
      heff_take_n(v_it2_2438, 0ULL, 2);
      heff_drop(v_hm_242);
      heff_drop(v_holeVal_243);
      heff_drop(v_one_2437);
      V v_t_2457 = ({ V a_0 = v_e_240; V a_1 = v_x_2412; V a_2 = v_goal_244; V r_ = (g_heff_2erules_2einstShown(a_0, a_1, a_2)); heff_drop(v_x_2412); r_; });
      V v_x2_2458 = (g_prelude_2emap_24s426(v_x_2430));
      V v_t_2461;
      switch (heff_tag_of(v_x2_2458)) {
      case TAG_Nil: {
        v_t_2461 = ((V)&g_heff_2erules_2eresolveWanted_str10);
        break;
      }
      case TAG_Cons: {
        V v_x_2459 = heff_field(v_x2_2458, 0);
        V v_xs_2460 = heff_field(v_x2_2458, 1);
        heff_take_n(v_x2_2458, 3ULL, 2);
        v_t_2461 = ({ V a_0 = v_x_2459; V a_1 = v_xs_2460; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2460); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2458);
      }
      V v_msg_2462 = heff_strAppend(((V)&g_heff_2erules_2eresolveWanted_str11), heff_strAppend(v_t_2457, heff_strAppend(((V)&g_heff_2erules_2eresolveWanted_str12), v_t_2461)));
      V v_t_2463 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(342LL), NTAG(TAG_SError), v_msg_2462, v_sp_241, heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2erules_2eresolveWanted_str13)})});
      V v_t_2464 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2463})});
      V v_t_2465 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2464})});
      V v_t_2466 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2465}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2466, v_k_247});
    }
    default: return heff_nomatch(v_it2_2438);
    }
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2erules_2eresolveWanted_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_goal_244 = heff_env(self)[1];
  V v_final_245 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_hm_242 = heff_env(self)[6];
  V v_holeVal_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2413 = (g_heff_2eunify_2emetasK(v_x_2412));
  V v_t_2414 = heff_get(heff_get(heff_dup(v_e_240), LBL_scope), LBL_len);
  V v_x1_2415 = heff_tr(heff_apply(heff_get(v_t_2413, LBL_mty), 3, (V[]){MK_INT(20LL), v_t_2414, heff_dup(v_goal_244)}));
  V v_x1_2418;
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_Nil: {
    v_x1_2418 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2415, 0ULL, 2);
    v_x1_2418 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_2415);
  }
  V v_t_2419;
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_True: {
    v_t_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_2419 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_2418);
  }
  switch (heff_tag_of(v_t_2419)) {
  case TAG_True: {
    heff_drop(v_hm_242);
    heff_drop(v_holeVal_243);
    switch (heff_tag_of(v_final_245)) {
    case TAG_True: {
      V v_msg_2420 = heff_strAppend(((V)&g_heff_2erules_2eresolveWanted_str0), ({ V a_0 = v_e_240; V a_1 = v_x_2412; V a_2 = v_goal_244; V r_ = (g_heff_2erules_2einstShown(a_0, a_1, a_2)); heff_drop(v_x_2412); r_; }));
      V v_t_2421 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(340LL), NTAG(TAG_SError), v_msg_2420, v_sp_241, heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2erules_2eresolveWanted_str1)})});
      V v_t_2422 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2423}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2424, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_x_2412);
      heff_drop(v_e_240);
      heff_drop(v_goal_244);
      heff_drop(v_sp_241);
      heff_drop(v_hd_246);
      V f_ = v_k_247;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_final_245);
    }
  }
  case TAG_False: {
    heff_drop(v_final_245);
    V v_t_2428 = (g_prelude_2emap(heff_clo(g_heff_2erules_2eresolveWanted_lam2, 1, 1, (V[]){heff_dup(v_e_240)}), heff_get(heff_dup(v_e_240), LBL_insts)));
    V v_c_2429 = (g_heff_2erules_2ewitnessMatches(heff_dup(v_e_240), heff_dup(v_goal_244), v_t_2428));
    return heff_tail(v_c_2429, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2erules_2eresolveWanted_lam3, 1, 8, (V[]){v_e_240, v_x_2412, v_goal_244, v_sp_241, v_hd_246, v_k_247, v_hm_242, v_holeVal_243})});
  }
  default: return heff_nomatch(v_t_2419);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2erules_2einsertInstance_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {105, 110, 115, 116, 97, 110, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2erules_2einsertInstance_str1 = {{0x80000000u, K_STR, 0}, 21, 21, {32, 32, 91, 114, 101, 97, 100, 121, 32, 97, 116, 32, 116, 104, 101, 32, 99, 97, 108, 108, 93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2erules_2einsertInstance_str2 = {{0x80000000u, K_STR, 0}, 23, 23, {32, 32, 91, 119, 97, 105, 116, 115, 32, 102, 111, 114, 32, 105, 109, 112, 108, 105, 99, 105, 116, 115, 93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2erules_2einsertInstance_str3 = {{0x80000000u, K_STR, 0}, 7, 7, {119, 97, 110, 116, 101, 100, 32}};
V g_heff_2erules_2einsertInstance_lam1(V self, V *args); static Clo g_heff_2erules_2einsertInstance_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2einsertInstance_lam1, 1, 0};
V g_heff_2erules_2einsertInstance_lam3(V self, V *args);
V g_heff_2erules_2einsertInstance_lam5(V self, V *args);
V g_heff_2erules_2einsertInstance_lam7(V self, V *args);
V g_heff_2erules_2einsertInstance_lam6(V self, V *args);
V g_heff_2erules_2einsertInstance_lam4(V self, V *args);
V g_heff_2erules_2einsertInstance_lam2(V self, V *args);
V g_heff_2erules_2einsertInstance_lam0(V self, V *args);
Clo g_heff_2erules_2einsertInstance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2einsertInstance_entry, 6, 0};

V g_heff_2erules_2einsertInstance(V v_e_240, V v_sp_241, V v_goal_242, V v_name_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_246 = heff_get(heff_get(heff_dup(v_e_240), LBL_scope), LBL_len);
  V v_t_247 = heff_get(heff_get(heff_dup(v_e_240), LBL_scope), LBL_locals);
  return ({ V a_0 = v_t_246; V a_1 = v_t_247; V a_2 = heff_dup(v_goal_242); V a_3 = v_name_243; V a_4 = heff_dup(v_sp_241); V a_5 = heff_dup(v_hd_244); V a_6 = heff_clo(g_heff_2erules_2einsertInstance_lam0, 1, 5, (V[]){v_hd_244, v_sp_241, v_e_240, v_goal_242, v_k_245}); V r_ = (g_heff_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_247); r_; });
}
V g_heff_2erules_2einsertInstance_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2einsertInstance(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2erules_2einsertInstance_lam1(V self, V *args) {
  V v_c_249 = args[0];
  return heff_get(v_c_249, LBL_metas);
}
V g_heff_2erules_2einsertInstance_lam3(V self, V *args) {
  V v_u_2414 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_goal_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2414);
  V v_t_2415 = (g_heff_2erules_2einstShown(heff_dup(v_e_240), v_x_2413, heff_dup(v_goal_242)));
  V v_t_2416 = ({ V a_0 = v_x_2413; V r_ = (g_heff_2eunify_2emetasK(a_0)); heff_drop(v_x_2413); r_; });
  V v_t_2417 = heff_get(heff_get(v_e_240, LBL_scope), LBL_len);
  V v_x1_2418 = heff_tr(heff_apply(heff_get(v_t_2416, LBL_mty), 3, (V[]){MK_INT(20LL), v_t_2417, v_goal_242}));
  V v_t_2421;
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_Nil: {
    v_t_2421 = ((V)&g_heff_2erules_2einsertInstance_str1);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2418, 0ULL, 2);
    v_t_2421 = ((V)&g_heff_2erules_2einsertInstance_str2);
    break;
  }
  default: heff_nomatch(v_x1_2418);
  }
  return heff_strAppend(((V)&g_heff_2erules_2einsertInstance_str3), heff_strAppend(v_t_2415, v_t_2421));
}
V g_heff_2erules_2einsertInstance_lam5(V self, V *args) {
  V v_b_2425 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_goal_242 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2426 = heff_get(heff_dup(v_x_248), LBL_stx);
  V v_t_2457;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_SLocal: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_2426, 0ULL, 3);
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_2451 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 3);
    v_t_2457 = v_k_2451;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2457 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  V v_c_2458 = heff_tr(heff_apply(((V)&g_heff_2erules_2eresolveWanted_clo), 6, (V[]){v_e_240, v_sp_241, v_t_2457, heff_get(v_x_248, LBL_val), v_goal_242, v_b_2425}));
  return heff_tail(v_c_2458, 2, (V[]){heff_dup(v_hd_244), heff_get(v_hd_244, LBL_ret)});
}
V g_heff_2erules_2einsertInstance_lam7(V self, V *args) {
  V v_u_2463 = args[0];
  V v_x_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2463);
  return heff_tag(TAG_Nom, 1, (V[]){heff_get(v_x_248, LBL_val)});
}
V g_heff_2erules_2einsertInstance_lam6(V self, V *args) {
  V v_x_2462 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2462);
  V v_t_2464 = heff_rec(2, shape_326_366, (V[]){heff_get(heff_dup(v_x_248), LBL_stx), heff_clo(g_heff_2erules_2einsertInstance_lam7, 1, 1, (V[]){v_x_248})});
  V f_ = v_k_245;
  args[0] = v_t_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2einsertInstance_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_goal_242 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2424);
  V v_t_2459 = heff_tag(TAG_Want, 3, (V[]){heff_dup(v_sp_241), heff_clo(g_heff_2erules_2einsertInstance_lam5, 1, 5, (V[]){heff_dup(v_x_248), v_e_240, v_sp_241, v_goal_242, heff_dup(v_hd_244)}), NTAG(TAG_MkUnit)});
  V v_t_2460 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2460}));
  return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2461, heff_clo(g_heff_2erules_2einsertInstance_lam6, 1, 2, (V[]){v_x_248, v_k_245})});
}
V g_heff_2erules_2einsertInstance_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_goal_242 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422 = heff_tag(TAG_Trace, 2, (V[]){heff_rec(3, shape_314_154_337, (V[]){heff_dup(v_sp_241), ((V)&g_heff_2erules_2einsertInstance_str0), heff_clo(g_heff_2erules_2einsertInstance_lam3, 1, 3, (V[]){heff_dup(v_e_240), v_x_2413, heff_dup(v_goal_242)})}), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2422})}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_2423, heff_clo(g_heff_2erules_2einsertInstance_lam4, 1, 6, (V[]){v_sp_241, v_x_248, v_e_240, v_goal_242, v_hd_244, v_k_245})});
}
V g_heff_2erules_2einsertInstance_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_goal_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2erules_2einsertInstance_lam1_clo)})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2411}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2erules_2einsertInstance_lam2, 1, 6, (V[]){v_sp_241, v_e_240, v_goal_242, v_hd_244, v_x_248, v_k_245})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2einsertImplicits_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2einsertImplicits_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2einsertImplicits_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
V g_heff_2erules_2einsertImplicits_lam0(V self, V *args);
V g_heff_2erules_2einsertImplicits_lam3(V self, V *args);
V g_heff_2erules_2einsertImplicits_lam4(V self, V *args);
V g_heff_2erules_2einsertImplicits_lam2(V self, V *args);
V g_heff_2erules_2einsertImplicits_lam6(V self, V *args);
V g_heff_2erules_2einsertImplicits_lam5(V self, V *args);
V g_heff_2erules_2einsertImplicits_lam1(V self, V *args);
Clo g_heff_2erules_2einsertImplicits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2einsertImplicits_entry, 6, 0};

V g_heff_2erules_2einsertImplicits(V v_e_240, V v_sp_241, V v_m_242, V v_ty0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2einsertImplicits_lam0, 1, 1, (V[]){v_ty0_243})})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_248}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2erules_2einsertImplicits_lam1, 1, 5, (V[]){v_k_245, v_m_242, v_e_240, v_sp_241, v_hd_244})});
}
V g_heff_2erules_2einsertImplicits_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2einsertImplicits(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2erules_2einsertImplicits_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_ty0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_246, LBL_metas); V a_1 = v_ty0_243; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2erules_2einsertImplicits_lam3(V self, V *args) {
  V v_u_2431 = args[0];
  V v_x_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2431);
  return heff_tag(TAG_Nom, 1, (V[]){heff_get(v_x_2425, LBL_val)});
}
V g_heff_2erules_2einsertImplicits_lam4(V self, V *args) {
  V v_u_2437 = args[0];
  V v_x_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2437);
  return heff_get(v_x_2425, LBL_val);
}
V g_heff_2erules_2einsertImplicits_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_cod_2415 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2430;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_n_2426 = heff_dup(heff_field(v_cod_2415, 0));
    v_t_2430 = v_n_2426;
    break;
  }
  case TAG_CloConst: {
    v_t_2430 = ((V)&g_heff_2erules_2einsertImplicits_str1);
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2432 = heff_rec(2, shape_326_366, (V[]){heff_get(heff_dup(v_x_2425), LBL_stx), heff_clo(g_heff_2erules_2einsertImplicits_lam3, 1, 1, (V[]){heff_dup(v_x_2425)})});
  V v_t_2433 = (g_heff_2ememoed_2eiapp(v_t_2430, v_m_242, v_t_2432));
  V v_x1_2439;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_vs_2435 = heff_field(v_cod_2415, 1);
    V v_body_2436 = heff_field(v_cod_2415, 2);
    heff_take_n(v_cod_2415, 6ULL, 3);
    v_x1_2439 = heff_tr(heff_apply(v_body_2436, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2435, heff_clo(g_heff_2erules_2einsertImplicits_lam4, 1, 1, (V[]){v_x_2425})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2438 = heff_field(v_cod_2415, 0);
    heff_take_n(v_cod_2415, 1ULL, 1);
    heff_drop(v_x_2425);
    v_x1_2439 = v_body_2438;
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2443;
  switch (heff_tag_of(v_x1_2439)) {
  case TAG_Nom: {
    V v_x_2440 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2440;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2439, 0ULL, 1);
    v_t_2443 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2442 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2442;
    break;
  }
  default: heff_nomatch(v_x1_2439);
  }
  return (g_heff_2erules_2einsertImplicits(v_e_240, v_sp_241, v_t_2433, v_t_2443, v_hd_244, v_k_245));
}
V g_heff_2erules_2einsertImplicits_lam6(V self, V *args) {
  V v_u_2455 = args[0];
  V v_x_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2455);
  V v_x1_2456 = heff_tr(heff_apply(heff_get(v_x_2450, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2456)) {
  case TAG_Nom: {
    V v_x_2457 = heff_field(v_x1_2456, 0);
    heff_take_n(v_x1_2456, 1ULL, 1);
    return v_x_2457;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2456, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2459 = heff_field(v_x1_2456, 0);
    heff_take_n(v_x1_2456, 1ULL, 1);
    return v_x_2459;
  }
  default: return heff_nomatch(v_x1_2456);
  }
}
V g_heff_2erules_2einsertImplicits_lam5(V self, V *args) {
  V v_x_2450 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_cod_2415 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2451 = (g_heff_2ememoed_2eapp(v_m_242, heff_dup(v_x_2450)));
  V v_x1_2461;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_vs_2453 = heff_field(v_cod_2415, 1);
    V v_body_2454 = heff_field(v_cod_2415, 2);
    heff_take_n(v_cod_2415, 6ULL, 3);
    v_x1_2461 = heff_tr(heff_apply(v_body_2454, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2453, heff_clo(g_heff_2erules_2einsertImplicits_lam6, 1, 1, (V[]){v_x_2450})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2460 = heff_field(v_cod_2415, 0);
    heff_take_n(v_cod_2415, 1ULL, 1);
    heff_drop(v_x_2450);
    v_x1_2461 = v_body_2460;
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2465;
  switch (heff_tag_of(v_x1_2461)) {
  case TAG_Nom: {
    V v_x_2462 = heff_field(v_x1_2461, 0);
    heff_take_n(v_x1_2461, 1ULL, 1);
    v_t_2465 = v_x_2462;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2461, 0ULL, 1);
    v_t_2465 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2464 = heff_field(v_x1_2461, 0);
    heff_take_n(v_x1_2461, 1ULL, 1);
    v_t_2465 = v_x_2464;
    break;
  }
  default: heff_nomatch(v_x1_2461);
  }
  return (g_heff_2erules_2einsertImplicits(v_e_240, v_sp_241, v_t_2451, v_t_2465, v_hd_244, v_k_245));
}
V g_heff_2erules_2einsertImplicits_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_it_2411 = (g_heff_2evalue_2ebehavior(heff_dup(v_x_2410)));
  switch (heff_tag_of(v_it_2411)) {
  case TAG_LikeU: {
    heff_take_n(v_it_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFunction: {
    V v_dom_2414 = heff_field(v_it_2411, 1);
    V v_cod_2415 = heff_field(v_it_2411, 2);
    V v_it4_2416 = heff_field(v_it_2411, 3);
    heff_take_n(v_it_2411, 14ULL, 4);
    switch (heff_tag_of(v_it4_2416)) {
    case TAG_Expl: {
      heff_drop(v_e_240);
      heff_drop(v_sp_241);
      heff_drop(v_hd_244);
      heff_drop(v_dom_2414);
      heff_drop(v_cod_2415);
      V f_ = v_k_245;
      args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Impl: {
      heff_drop(v_x_2410);
      V v_t_2417 = heff_get(heff_get(heff_dup(v_e_240), LBL_scope), LBL_len);
      V v_t_2418 = heff_get(heff_get(heff_dup(v_e_240), LBL_scope), LBL_locals);
      V v_t_2423;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_n_2419 = heff_dup(heff_field(v_cod_2415, 0));
        v_t_2423 = v_n_2419;
        break;
      }
      case TAG_CloConst: {
        v_t_2423 = ((V)&g_heff_2erules_2einsertImplicits_str0);
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      V v_c_2424 = heff_tr(heff_apply(((V)&g_heff_2erules_2efreshMeta_clo), 5, (V[]){v_t_2417, v_t_2418, v_dom_2414, v_t_2423, heff_dup(v_sp_241)}));
      return heff_tail(v_c_2424, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2erules_2einsertImplicits_lam2, 1, 6, (V[]){v_cod_2415, v_m_242, v_e_240, v_sp_241, v_hd_244, v_k_245})});
    }
    case TAG_Inst: {
      heff_drop(v_x_2410);
      V v_t_2448;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_n_2444 = heff_dup(heff_field(v_cod_2415, 0));
        v_t_2448 = v_n_2444;
        break;
      }
      case TAG_CloConst: {
        v_t_2448 = ((V)&g_heff_2erules_2einsertImplicits_str2);
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      V v_c_2449 = heff_tr(heff_apply(((V)&g_heff_2erules_2einsertInstance_clo), 4, (V[]){heff_dup(v_e_240), heff_dup(v_sp_241), v_dom_2414, v_t_2448}));
      return heff_tail(v_c_2449, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2erules_2einsertImplicits_lam5, 1, 6, (V[]){v_m_242, v_cod_2415, v_e_240, v_sp_241, v_hd_244, v_k_245})});
    }
    default: return heff_nomatch(v_it4_2416);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_it_2411, 0ULL, 3);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeSum: {
    heff_take_n(v_it_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeInt: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFloat: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeString: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeArray: {
    heff_take_n(v_it_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_NoRules: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_it_2411);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[119]; } g_heff_2erules_2efunctionFormation_str0 = {{0x80000000u, K_STR, 0}, 119, 119, {97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 109, 117, 115, 116, 32, 104, 97, 118, 101, 32, 97, 32, 108, 97, 114, 103, 101, 32, 116, 121, 112, 101, 32, 40, 97, 32, 115, 109, 97, 108, 108, 32, 111, 110, 101, 32, 99, 111, 117, 108, 100, 32, 110, 101, 118, 101, 114, 32, 98, 101, 32, 105, 110, 102, 101, 114, 114, 101, 100, 58, 32, 105, 116, 115, 32, 118, 97, 108, 117, 101, 115, 32, 97, 114, 101, 32, 115, 116, 97, 116, 105, 99, 97, 108, 108, 121, 32, 105, 114, 114, 101, 108, 101, 118, 97, 110, 116, 41}};
V g_heff_2erules_2efunctionFormation_lam3(V self, V *args);
V g_heff_2erules_2efunctionFormation_lam2(V self, V *args);
V g_heff_2erules_2efunctionFormation_lam1(V self, V *args);
V g_heff_2erules_2efunctionFormation_lam0(V self, V *args);
V g_heff_2erules_2efunctionFormation_lam7(V self, V *args);
V g_heff_2erules_2efunctionFormation_lam6(V self, V *args);
V g_heff_2erules_2efunctionFormation_lam5(V self, V *args);
V g_heff_2erules_2efunctionFormation_lam4(V self, V *args);
V g_heff_2erules_2efunctionFormation_lam11(V self, V *args);
V g_heff_2erules_2efunctionFormation_lam10(V self, V *args);
V g_heff_2erules_2efunctionFormation_lam9(V self, V *args);
V g_heff_2erules_2efunctionFormation_lam8(V self, V *args);
V g_heff_2erules_2efunctionFormation_lam15(V self, V *args);
V g_heff_2erules_2efunctionFormation_lam14(V self, V *args);
V g_heff_2erules_2efunctionFormation_lam13(V self, V *args);
V g_heff_2erules_2efunctionFormation_lam12(V self, V *args);
Clo g_heff_2erules_2efunctionFormation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2efunctionFormation_entry, 2, 0};

V g_heff_2erules_2efunctionFormation(V v_x1_240, V v_cod_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Anonymous: {
    V v_dom_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Anonymous = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at(v_ru_24x1_240_24Anonymous, TAG_MkTyp, 1, (V[]){heff_clo(g_heff_2erules_2efunctionFormation_lam0, 1, 2, (V[]){v_dom_242, heff_dup(v_cod_241)})});
  }
  case TAG_Named: {
    V v_x_2414 = heff_field(v_x1_240, 0);
    V v_dom_2415 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return heff_tag(TAG_MkTyp, 1, (V[]){heff_clo(g_heff_2erules_2efunctionFormation_lam4, 1, 3, (V[]){v_dom_2415, v_x_2414, heff_dup(v_cod_241)})});
  }
  case TAG_NamedImplicit: {
    V v_sp_2434 = heff_field(v_x1_240, 0);
    V v_x_2435 = heff_field(v_x1_240, 1);
    V v_dom_2436 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    return heff_tag(TAG_MkTyp, 1, (V[]){heff_clo(g_heff_2erules_2efunctionFormation_lam8, 1, 4, (V[]){v_dom_2436, v_sp_2434, v_x_2435, heff_dup(v_cod_241)})});
  }
  case TAG_NamedInstance: {
    V v_x_2466 = heff_field(v_x1_240, 1);
    V v_dom_2467 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    return heff_tag(TAG_MkTyp, 1, (V[]){heff_clo(g_heff_2erules_2efunctionFormation_lam12, 1, 3, (V[]){v_dom_2467, v_x_2466, heff_dup(v_cod_241)})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2erules_2efunctionFormation_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2efunctionFormation(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2erules_2efunctionFormation_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_locals);
  V v_x_2413 = (g_heff_2ememoed_2efunctionI(NTAG(TAG_Expl), heff_get(v_e_243, LBL_globals), v_t_2412, v_x_248, heff_tag(TAG_AbsConst, 1, (V[]){v_x_2411})));
  V f_ = v_k_247;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2efunctionFormation_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_cod_241 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410;
  switch (heff_tag_of(v_cod_241)) {
  case TAG_MkTyp: {
    V v_f_249 = heff_field(v_cod_241, 0);
    heff_take_n(v_cod_241, 1ULL, 1);
    v_c_2410 = heff_tr(heff_apply(v_f_249, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_cod_241);
  }
  return heff_tail(v_c_2410, 2, (V[]){v_hd_246, heff_clo(g_heff_2erules_2efunctionFormation_lam3, 1, 3, (V[]){v_e_243, v_x_248, v_k_247})});
}
V g_heff_2erules_2efunctionFormation_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_cod_241 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo(g_heff_2erules_2efunctionFormation_lam2, 1, 4, (V[]){v_cod_241, v_e_243, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2efunctionFormation_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_dom_242 = heff_env(self)[0];
  V v_cod_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245;
  switch (heff_tag_of(v_dom_242)) {
  case TAG_MkTyp: {
    V v_f_244 = heff_field(v_dom_242, 0);
    heff_take_n(v_dom_242, 1ULL, 1);
    v_c_245 = heff_tr(heff_apply(v_f_244, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_dom_242);
  }
  return heff_clo(g_heff_2erules_2efunctionFormation_lam1, 2, 3, (V[]){v_c_245, v_cod_241, v_e_243});
}
V g_heff_2erules_2efunctionFormation_lam7(V self, V *args) {
  V v_x_2431 = args[0];
  V v_e_2416 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_k_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2432 = heff_get(heff_get(heff_dup(v_e_2416), LBL_scope), LBL_locals);
  V v_x_2433 = (g_heff_2ememoed_2efunctionI(NTAG(TAG_Expl), heff_get(v_e_2416, LBL_globals), v_t_2432, v_x_2421, heff_tag(TAG_MkAbs, 2, (V[]){v_x_2414, v_x_2431})));
  V f_ = v_k_2420;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2efunctionFormation_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_e_2416 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  V v_hd_2419 = heff_env(self)[3];
  V v_k_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_x_2421), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2426;
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Nom: {
    V v_x_2423 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_t_2426 = v_x_2423;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2422, 0ULL, 1);
    v_t_2426 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2425 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_t_2426 = v_x_2425;
    break;
  }
  default: heff_nomatch(v_x1_2422);
  }
  V v_sc_2427 = (g_heff_2eenvironment_2ebindName(heff_dup(v_x_2414), v_t_2426, heff_get(heff_dup(v_e_2416), LBL_scope)));
  V v_e_2428 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){v_sc_2427, heff_get(heff_dup(v_e_2416), LBL_globals), heff_get(heff_dup(v_e_2416), LBL_elabFor), heff_get(heff_dup(v_e_2416), LBL_lams), heff_get(heff_dup(v_e_2416), LBL_self), heff_get(heff_dup(v_e_2416), LBL_insts)});
  V v_c_2430;
  switch (heff_tag_of(v_cod_241)) {
  case TAG_MkTyp: {
    V v_f_2429 = heff_field(v_cod_241, 0);
    heff_take_n(v_cod_241, 1ULL, 1);
    v_c_2430 = heff_tr(heff_apply(v_f_2429, 1, (V[]){v_e_2428}));
    break;
  }
  default: heff_nomatch(v_cod_241);
  }
  return heff_tail(v_c_2430, 2, (V[]){v_hd_2419, heff_clo(g_heff_2erules_2efunctionFormation_lam7, 1, 4, (V[]){v_e_2416, v_x_2421, v_x_2414, v_k_2420})});
}
V g_heff_2erules_2efunctionFormation_lam5(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_e_2416 = heff_env(self)[2];
  V v_cod_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo(g_heff_2erules_2efunctionFormation_lam6, 1, 5, (V[]){v_x_2414, v_e_2416, v_cod_241, v_hd_2419, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2efunctionFormation_lam4(V self, V *args) {
  V v_e_2416 = args[0];
  V v_dom_2415 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2418;
  switch (heff_tag_of(v_dom_2415)) {
  case TAG_MkTyp: {
    V v_f_2417 = heff_field(v_dom_2415, 0);
    heff_take_n(v_dom_2415, 1ULL, 1);
    v_c_2418 = heff_tr(heff_apply(v_f_2417, 1, (V[]){heff_dup(v_e_2416)}));
    break;
  }
  default: heff_nomatch(v_dom_2415);
  }
  return heff_clo(g_heff_2erules_2efunctionFormation_lam5, 2, 4, (V[]){v_c_2418, v_x_2414, v_e_2416, v_cod_241});
}
V g_heff_2erules_2efunctionFormation_lam11(V self, V *args) {
  V v_x_2462 = args[0];
  V v_e_2437 = heff_env(self)[0];
  V v_x_2442 = heff_env(self)[1];
  V v_x_2435 = heff_env(self)[2];
  V v_k_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2463 = heff_get(heff_get(heff_dup(v_e_2437), LBL_scope), LBL_locals);
  V v_x_2464 = (g_heff_2ememoed_2efunctionI(NTAG(TAG_Impl), heff_get(v_e_2437, LBL_globals), v_t_2463, v_x_2442, heff_tag(TAG_MkAbs, 2, (V[]){v_x_2435, v_x_2462})));
  V f_ = v_k_2441;
  args[0] = v_x_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2efunctionFormation_lam10(V self, V *args) {
  V v_x_2442 = args[0];
  V v_sp_2434 = heff_env(self)[0];
  V v_hd_2440 = heff_env(self)[1];
  V v_k_2441 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_e_2437 = heff_env(self)[4];
  V v_cod_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_2443 = heff_tr(heff_apply(heff_get(heff_dup(v_x_2442), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x1_2447;
  switch (heff_tag_of(v_x1_2443)) {
  case TAG_Nom: {
    V v_t_2444 = heff_field(v_x1_2443, 0);
    heff_take_n(v_x1_2443, 1ULL, 1);
    v_x1_2447 = ({ V a_0 = v_t_2444; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2444); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2445 = heff_field(v_x1_2443, 0);
    heff_take_n(v_x1_2443, 1ULL, 1);
    v_x1_2447 = ({ V a_0 = v_t_2445; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2445); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2446 = heff_field(v_x1_2443, 0);
    heff_take_n(v_x1_2443, 1ULL, 1);
    v_x1_2447 = ({ V a_0 = v_t_2446; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2446); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2443);
  }
  V v_t_2448;
  switch (heff_tag_of(v_x1_2447)) {
  case TAG_Small: {
    v_t_2448 = NTAG(TAG_True);
    break;
  }
  case TAG_Large: {
    v_t_2448 = NTAG(TAG_False);
    break;
  }
  case TAG_TopL: {
    v_t_2448 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_2447);
  }
  switch (heff_tag_of(v_t_2448)) {
  case TAG_True: {
    heff_drop(v_x_2442);
    heff_drop(v_x_2435);
    heff_drop(v_e_2437);
    heff_drop(v_cod_241);
    V v_t_2449 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(324LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionFormation_str0), v_sp_2434, NTAG(TAG_Nothing)});
    V v_t_2450 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2440), LBL_malg), 1, (V[]){v_t_2451}));
    return heff_tail(heff_get(v_hd_2440, LBL_bind), 2, (V[]){v_t_2452, v_k_2441});
  }
  case TAG_False: {
    heff_drop(v_sp_2434);
    V v_x1_2453 = heff_tr(heff_apply(heff_get(heff_dup(v_x_2442), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2457;
    switch (heff_tag_of(v_x1_2453)) {
    case TAG_Nom: {
      V v_x_2454 = heff_field(v_x1_2453, 0);
      heff_take_n(v_x1_2453, 1ULL, 1);
      v_t_2457 = v_x_2454;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2453, 0ULL, 1);
      v_t_2457 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2456 = heff_field(v_x1_2453, 0);
      heff_take_n(v_x1_2453, 1ULL, 1);
      v_t_2457 = v_x_2456;
      break;
    }
    default: heff_nomatch(v_x1_2453);
    }
    V v_sc_2458 = (g_heff_2eenvironment_2ebindName(heff_dup(v_x_2435), v_t_2457, heff_get(heff_dup(v_e_2437), LBL_scope)));
    V v_e_2459 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){v_sc_2458, heff_get(heff_dup(v_e_2437), LBL_globals), heff_get(heff_dup(v_e_2437), LBL_elabFor), heff_get(heff_dup(v_e_2437), LBL_lams), heff_get(heff_dup(v_e_2437), LBL_self), heff_get(heff_dup(v_e_2437), LBL_insts)});
    V v_c_2461;
    switch (heff_tag_of(v_cod_241)) {
    case TAG_MkTyp: {
      V v_f_2460 = heff_field(v_cod_241, 0);
      heff_take_n(v_cod_241, 1ULL, 1);
      v_c_2461 = heff_tr(heff_apply(v_f_2460, 1, (V[]){v_e_2459}));
      break;
    }
    default: heff_nomatch(v_cod_241);
    }
    return heff_tail(v_c_2461, 2, (V[]){v_hd_2440, heff_clo(g_heff_2erules_2efunctionFormation_lam11, 1, 4, (V[]){v_e_2437, v_x_2442, v_x_2435, v_k_2441})});
  }
  default: return heff_nomatch(v_t_2448);
  }
}
V g_heff_2erules_2efunctionFormation_lam9(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_c_2439 = heff_env(self)[0];
  V v_sp_2434 = heff_env(self)[1];
  V v_x_2435 = heff_env(self)[2];
  V v_e_2437 = heff_env(self)[3];
  V v_cod_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2439;
  args[0] = heff_dup(v_hd_2440);
  args[1] = heff_clo(g_heff_2erules_2efunctionFormation_lam10, 1, 6, (V[]){v_sp_2434, v_hd_2440, v_k_2441, v_x_2435, v_e_2437, v_cod_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2efunctionFormation_lam8(V self, V *args) {
  V v_e_2437 = args[0];
  V v_dom_2436 = heff_env(self)[0];
  V v_sp_2434 = heff_env(self)[1];
  V v_x_2435 = heff_env(self)[2];
  V v_cod_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2439;
  switch (heff_tag_of(v_dom_2436)) {
  case TAG_MkTyp: {
    V v_f_2438 = heff_field(v_dom_2436, 0);
    heff_take_n(v_dom_2436, 1ULL, 1);
    v_c_2439 = heff_tr(heff_apply(v_f_2438, 1, (V[]){heff_dup(v_e_2437)}));
    break;
  }
  default: heff_nomatch(v_dom_2436);
  }
  return heff_clo(g_heff_2erules_2efunctionFormation_lam9, 2, 5, (V[]){v_c_2439, v_sp_2434, v_x_2435, v_e_2437, v_cod_241});
}
V g_heff_2erules_2efunctionFormation_lam15(V self, V *args) {
  V v_x_2483 = args[0];
  V v_e_2468 = heff_env(self)[0];
  V v_x_2473 = heff_env(self)[1];
  V v_x_2466 = heff_env(self)[2];
  V v_k_2472 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2484 = heff_get(heff_get(heff_dup(v_e_2468), LBL_scope), LBL_locals);
  V v_x_2485 = (g_heff_2ememoed_2efunctionI(NTAG(TAG_Inst), heff_get(v_e_2468, LBL_globals), v_t_2484, v_x_2473, heff_tag(TAG_MkAbs, 2, (V[]){v_x_2466, v_x_2483})));
  V f_ = v_k_2472;
  args[0] = v_x_2485;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2efunctionFormation_lam14(V self, V *args) {
  V v_x_2473 = args[0];
  V v_x_2466 = heff_env(self)[0];
  V v_e_2468 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  V v_hd_2471 = heff_env(self)[3];
  V v_k_2472 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2474 = heff_tr(heff_apply(heff_get(heff_dup(v_x_2473), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2478;
  switch (heff_tag_of(v_x1_2474)) {
  case TAG_Nom: {
    V v_x_2475 = heff_field(v_x1_2474, 0);
    heff_take_n(v_x1_2474, 1ULL, 1);
    v_t_2478 = v_x_2475;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2474, 0ULL, 1);
    v_t_2478 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2477 = heff_field(v_x1_2474, 0);
    heff_take_n(v_x1_2474, 1ULL, 1);
    v_t_2478 = v_x_2477;
    break;
  }
  default: heff_nomatch(v_x1_2474);
  }
  V v_sc_2479 = (g_heff_2eenvironment_2ebindName(heff_dup(v_x_2466), v_t_2478, heff_get(heff_dup(v_e_2468), LBL_scope)));
  V v_e_2480 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){v_sc_2479, heff_get(heff_dup(v_e_2468), LBL_globals), heff_get(heff_dup(v_e_2468), LBL_elabFor), heff_get(heff_dup(v_e_2468), LBL_lams), heff_get(heff_dup(v_e_2468), LBL_self), heff_get(heff_dup(v_e_2468), LBL_insts)});
  V v_c_2482;
  switch (heff_tag_of(v_cod_241)) {
  case TAG_MkTyp: {
    V v_f_2481 = heff_field(v_cod_241, 0);
    heff_take_n(v_cod_241, 1ULL, 1);
    v_c_2482 = heff_tr(heff_apply(v_f_2481, 1, (V[]){v_e_2480}));
    break;
  }
  default: heff_nomatch(v_cod_241);
  }
  return heff_tail(v_c_2482, 2, (V[]){v_hd_2471, heff_clo(g_heff_2erules_2efunctionFormation_lam15, 1, 4, (V[]){v_e_2468, v_x_2473, v_x_2466, v_k_2472})});
}
V g_heff_2erules_2efunctionFormation_lam13(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k_2472 = args[1];
  V v_c_2470 = heff_env(self)[0];
  V v_x_2466 = heff_env(self)[1];
  V v_e_2468 = heff_env(self)[2];
  V v_cod_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2470;
  args[0] = heff_dup(v_hd_2471);
  args[1] = heff_clo(g_heff_2erules_2efunctionFormation_lam14, 1, 5, (V[]){v_x_2466, v_e_2468, v_cod_241, v_hd_2471, v_k_2472});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2efunctionFormation_lam12(V self, V *args) {
  V v_e_2468 = args[0];
  V v_dom_2467 = heff_env(self)[0];
  V v_x_2466 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2470;
  switch (heff_tag_of(v_dom_2467)) {
  case TAG_MkTyp: {
    V v_f_2469 = heff_field(v_dom_2467, 0);
    heff_take_n(v_dom_2467, 1ULL, 1);
    v_c_2470 = heff_tr(heff_apply(v_f_2469, 1, (V[]){heff_dup(v_e_2468)}));
    break;
  }
  default: heff_nomatch(v_dom_2467);
  }
  return heff_clo(g_heff_2erules_2efunctionFormation_lam13, 2, 4, (V[]){v_c_2470, v_x_2466, v_e_2468, v_cod_241});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2eimplicitLams_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2eimplicitLams_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2eimplicitLams_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
V g_heff_2erules_2eimplicitLams_lam1(V self, V *args);
V g_heff_2erules_2eimplicitLams_lam4(V self, V *args);
V g_heff_2erules_2eimplicitLams_lam7(V self, V *args);
V g_heff_2erules_2eimplicitLams_lam6(V self, V *args);
V g_heff_2erules_2eimplicitLams_lam5(V self, V *args);
V g_heff_2erules_2eimplicitLams_lam3(V self, V *args);
V g_heff_2erules_2eimplicitLams_lam2(V self, V *args);
V g_heff_2erules_2eimplicitLams_lam0(V self, V *args);
Clo g_heff_2erules_2eimplicitLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eimplicitLams_entry, 1, 0};

V g_heff_2erules_2eimplicitLams(V v_c_240) {
top: ;
  return heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2erules_2eimplicitLams_lam0, 4, 1, (V[]){heff_dup(v_c_240)})});
}
V g_heff_2erules_2eimplicitLams_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2eimplicitLams(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2erules_2eimplicitLams_lam1(V self, V *args) {
  V v_c_245 = args[0];
  V v_a0_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_245, LBL_metas); V a_1 = v_a0_242; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2erules_2eimplicitLams_lam4(V self, V *args) {
  V v_u_2441 = args[0];
  V v_v_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2441);
  return v_v_2424;
}
V g_heff_2erules_2eimplicitLams_lam7(V self, V *args) {
  V v_u_2465 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2465);
  return heff_tag(TAG_Nom, 1, (V[]){v_x_249});
}
V g_heff_2erules_2eimplicitLams_lam6(V self, V *args) {
  V v_x_2452 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_cod_2415 = heff_env(self)[2];
  V v_k_2451 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2453 = heff_get(heff_dup(v_e_241), LBL_elabFor);
  V v_t_2456;
  switch (heff_tag_of(v_t_2453)) {
  case TAG_ForNominative: {
    v_t_2456 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2453, 0ULL, 2);
    v_t_2456 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2453);
  }
  V v_t_2457 = heff_get(heff_get(heff_dup(v_e_241), LBL_scope), LBL_locals);
  V v_t_2458 = heff_get(heff_get(heff_dup(v_e_241), LBL_scope), LBL_len);
  V v_t_2459 = (g_heff_2ereadback_2ereadbTypeF_24s182(v_t_2458, heff_dup(v_x_249)));
  V v_t_2464;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_n_2460 = heff_field(v_cod_2415, 0);
    heff_take_n(v_cod_2415, 1ULL, 3);
    v_t_2464 = v_n_2460;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2415, 0ULL, 1);
    v_t_2464 = ((V)&g_heff_2erules_2eimplicitLams_str2);
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_x_2466 = (g_heff_2ememoed_2elam(v_t_2456, heff_get(v_e_241, LBL_globals), v_t_2457, heff_rec(2, shape_326_366, (V[]){v_t_2459, heff_clo(g_heff_2erules_2eimplicitLams_lam7, 1, 1, (V[]){v_x_249})}), heff_tag(TAG_MkAbs, 2, (V[]){v_t_2464, v_x_2452})));
  V f_ = v_k_2451;
  args[0] = v_x_2466;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2eimplicitLams_lam5(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_c_2449 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_cod_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2449;
  args[0] = v_hd_2450;
  args[1] = heff_clo(g_heff_2erules_2eimplicitLams_lam6, 1, 4, (V[]){v_e_241, v_x_249, v_cod_2415, v_k_2451});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2eimplicitLams_lam3(V self, V *args) {
  V v_v_2424 = args[0];
  V v_scope_27_2425 = args[1];
  V v_c_240 = heff_env(self)[0];
  V v_cod_2415 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_implicit_2416 = heff_env(self)[3];
  V v_dom_2414 = heff_env(self)[4];
  V v_x_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_2426 = ({ V a_0 = v_c_240; V r_ = (g_heff_2erules_2eimplicitLams(a_0)); heff_drop(v_c_240); r_; });
  V v_y_2431;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_n_2427 = heff_dup(heff_field(v_cod_2415, 0));
    v_y_2431 = v_n_2427;
    break;
  }
  case TAG_CloConst: {
    v_y_2431 = ((V)&g_heff_2erules_2eimplicitLams_str1);
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2432 = heff_get(heff_dup(v_e_241), LBL_elabFor);
  V v_t_2435;
  switch (heff_tag_of(v_t_2432)) {
  case TAG_ForNominative: {
    v_t_2435 = NTAG(TAG_ForNominative);
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2433 = heff_field(v_t_2432, 0);
    V v_sp_2434 = heff_field(v_t_2432, 1);
    V v_ru_24t_2432_24ForDescriptive = heff_take_reuse_n(v_t_2432, 3ULL, 2);
    v_t_2435 = heff_tag_at(v_ru_24t_2432_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2433, heff_tag(TAG_SpApp, 2, (V[]){v_sp_2434, heff_dup(v_v_2424)})});
    break;
  }
  default: heff_nomatch(v_t_2432);
  }
  V v_t_2436;
  switch (heff_tag_of(v_implicit_2416)) {
  case TAG_Expl: {
    heff_drop(v_dom_2414);
    heff_drop(v_y_2431);
    v_t_2436 = heff_get(heff_dup(v_e_241), LBL_insts);
    break;
  }
  case TAG_Impl: {
    heff_drop(v_dom_2414);
    heff_drop(v_y_2431);
    v_t_2436 = heff_get(heff_dup(v_e_241), LBL_insts);
    break;
  }
  case TAG_Inst: {
    v_t_2436 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(3, shape_198_351_365, (V[]){v_y_2431, v_dom_2414, heff_dup(v_v_2424)}), heff_get(heff_dup(v_e_241), LBL_insts)});
    break;
  }
  default: heff_nomatch(v_implicit_2416);
  }
  V v_e_2437 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){v_scope_27_2425, heff_get(heff_dup(v_e_241), LBL_globals), v_t_2435, heff_get(heff_dup(v_e_241), LBL_lams), heff_get(heff_dup(v_e_241), LBL_self), v_t_2436});
  V v_x1_2443;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_vs_2439 = heff_dup(heff_field(v_cod_2415, 1));
    V v_body_2440 = heff_dup(heff_field(v_cod_2415, 2));
    v_x1_2443 = heff_tr(heff_apply(v_body_2440, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2439, heff_clo(g_heff_2erules_2eimplicitLams_lam4, 1, 1, (V[]){v_v_2424})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2442 = heff_dup(heff_field(v_cod_2415, 0));
    heff_drop(v_v_2424);
    v_x1_2443 = v_body_2442;
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_a_2447;
  switch (heff_tag_of(v_x1_2443)) {
  case TAG_Nom: {
    V v_x_2444 = heff_field(v_x1_2443, 0);
    heff_take_n(v_x1_2443, 1ULL, 1);
    v_a_2447 = v_x_2444;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2443, 0ULL, 1);
    v_a_2447 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2446 = heff_field(v_x1_2443, 0);
    heff_take_n(v_x1_2443, 1ULL, 1);
    v_a_2447 = v_x_2446;
    break;
  }
  default: heff_nomatch(v_x1_2443);
  }
  V v_c_2449;
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_MkChk: {
    V v_f_2448 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_c_2449 = heff_tr(heff_apply(v_f_2448, 2, (V[]){v_e_2437, v_a_2447}));
    break;
  }
  default: heff_nomatch(v_x1_2426);
  }
  return heff_clo(g_heff_2erules_2eimplicitLams_lam5, 2, 4, (V[]){v_c_2449, v_e_241, v_x_249, v_cod_2415});
}
V g_heff_2erules_2eimplicitLams_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = (g_heff_2evalue_2ebehavior(heff_dup(v_x_249)));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2410, 0ULL, 1);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2412 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      return heff_tail(v_f_2412, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeFunction: {
    V v_dom_2414 = heff_field(v_t_2410, 1);
    V v_cod_2415 = heff_field(v_t_2410, 2);
    V v_implicit_2416 = heff_field(v_t_2410, 3);
    heff_take_n(v_t_2410, 14ULL, 4);
    V v_t_2417;
    switch (heff_tag_of(v_implicit_2416)) {
    case TAG_Expl: {
      v_t_2417 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2417 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2417 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2416);
    }
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      heff_drop(v_dom_2414);
      heff_drop(v_cod_2415);
      heff_drop(v_implicit_2416);
      switch (heff_tag_of(v_c_240)) {
      case TAG_MkChk: {
        V v_f_2418 = heff_field(v_c_240, 0);
        heff_take_n(v_c_240, 1ULL, 1);
        return heff_tail(v_f_2418, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
      }
      default: return heff_nomatch(v_c_240);
      }
    }
    case TAG_False: {
      V v_t_2423;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_n_2419 = heff_dup(heff_field(v_cod_2415, 0));
        v_t_2423 = v_n_2419;
        break;
      }
      case TAG_CloConst: {
        v_t_2423 = ((V)&g_heff_2erules_2eimplicitLams_str0);
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      V v_t_2467 = heff_tr(g_heff_2eenvironment_2ewithBound(v_t_2423, heff_dup(v_dom_2414), heff_get(heff_dup(v_e_241), LBL_scope), heff_clo(g_heff_2erules_2eimplicitLams_lam3, 2, 6, (V[]){v_c_240, v_cod_2415, v_e_241, v_implicit_2416, v_dom_2414, v_x_249})));
      return heff_tail(v_t_2467, 2, (V[]){v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2410, 0ULL, 3);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2471 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      return heff_tail(v_f_2471, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2410, 0ULL, 1);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2473 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      return heff_tail(v_f_2473, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeInt: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2474 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      return heff_tail(v_f_2474, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeFloat: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2475 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      return heff_tail(v_f_2475, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeString: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2476 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      return heff_tail(v_f_2476, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2410, 0ULL, 1);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2478 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      return heff_tail(v_f_2478, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_NoRules: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2479 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      return heff_tail(v_f_2479, 4, (V[]){v_e_241, v_x_249, v_hd_243, v_k_244});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2erules_2eimplicitLams_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a0_242 = args[1];
  V v_hd_243 = args[2];
  V v_k_244 = args[3];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2eimplicitLams_lam1, 1, 1, (V[]){v_a0_242})})});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_247}));
  V f_ = heff_get(heff_dup(v_hd_243), LBL_bind);
  args[0] = v_t_248;
  args[1] = heff_clo(g_heff_2erules_2eimplicitLams_lam2, 1, 4, (V[]){v_c_240, v_e_241, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2erules_2efunctionIntro_str0 = {{0x80000000u, K_STR, 0}, 57, 57, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2efunctionIntro_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2efunctionIntro_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2efunctionIntro_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2erules_2efunctionIntro_str4 = {{0x80000000u, K_STR, 0}, 57, 57, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2erules_2efunctionIntro_str5 = {{0x80000000u, K_STR, 0}, 57, 57, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2erules_2efunctionIntro_str6 = {{0x80000000u, K_STR, 0}, 57, 57, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2erules_2efunctionIntro_str7 = {{0x80000000u, K_STR, 0}, 57, 57, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2erules_2efunctionIntro_str8 = {{0x80000000u, K_STR, 0}, 57, 57, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2erules_2efunctionIntro_str9 = {{0x80000000u, K_STR, 0}, 57, 57, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2erules_2efunctionIntro_str10 = {{0x80000000u, K_STR, 0}, 57, 57, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
V g_heff_2erules_2efunctionIntro_lam1(V self, V *args);
V g_heff_2erules_2efunctionIntro_lam4(V self, V *args);
V g_heff_2erules_2efunctionIntro_lam7(V self, V *args);
V g_heff_2erules_2efunctionIntro_lam6(V self, V *args);
V g_heff_2erules_2efunctionIntro_lam5(V self, V *args);
V g_heff_2erules_2efunctionIntro_lam3(V self, V *args);
V g_heff_2erules_2efunctionIntro_lam9(V self, V *args);
V g_heff_2erules_2efunctionIntro_lam12(V self, V *args);
V g_heff_2erules_2efunctionIntro_lam11(V self, V *args);
V g_heff_2erules_2efunctionIntro_lam10(V self, V *args);
V g_heff_2erules_2efunctionIntro_lam8(V self, V *args);
V g_heff_2erules_2efunctionIntro_lam2(V self, V *args);
V g_heff_2erules_2efunctionIntro_lam0(V self, V *args);
Clo g_heff_2erules_2efunctionIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2efunctionIntro_entry, 3, 0};

V g_heff_2erules_2efunctionIntro(V v_sp_240, V v_x_241, V v_body_242) {
top: ;
  return heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2erules_2efunctionIntro_lam0, 4, 3, (V[]){v_sp_240, v_x_241, heff_dup(v_body_242)})});
}
V g_heff_2erules_2efunctionIntro_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2efunctionIntro(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2erules_2efunctionIntro_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_247, LBL_metas); V a_1 = v_a0_244; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2erules_2efunctionIntro_lam4(V self, V *args) {
  V v_u_2434 = args[0];
  V v_v_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2434);
  return v_v_2423;
}
V g_heff_2erules_2efunctionIntro_lam7(V self, V *args) {
  V v_u_2453 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2453);
  return heff_tag(TAG_Nom, 1, (V[]){v_x_2411});
}
V g_heff_2erules_2efunctionIntro_lam6(V self, V *args) {
  V v_x_2445 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_k_2444 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2446 = heff_get(heff_dup(v_e_243), LBL_elabFor);
  V v_t_2449;
  switch (heff_tag_of(v_t_2446)) {
  case TAG_ForNominative: {
    v_t_2449 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2446, 0ULL, 2);
    v_t_2449 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2446);
  }
  V v_t_2450 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_locals);
  V v_t_2451 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_len);
  V v_t_2452 = (g_heff_2ereadback_2ereadbTypeF_24s182(v_t_2451, heff_dup(v_x_2411)));
  V v_x_2454 = (g_heff_2ememoed_2elam(v_t_2449, heff_get(v_e_243, LBL_globals), v_t_2450, heff_rec(2, shape_326_366, (V[]){v_t_2452, heff_clo(g_heff_2erules_2efunctionIntro_lam7, 1, 1, (V[]){v_x_2411})}), heff_tag(TAG_MkAbs, 2, (V[]){v_x_241, v_x_2445})));
  V f_ = v_k_2444;
  args[0] = v_x_2454;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2efunctionIntro_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  V v_c_2442 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2442;
  args[0] = v_hd_2443;
  args[1] = heff_clo(g_heff_2erules_2efunctionIntro_lam6, 1, 4, (V[]){v_e_243, v_x_2411, v_x_241, v_k_2444});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2efunctionIntro_lam3(V self, V *args) {
  V v_v_2423 = args[0];
  V v_scope_27_2424 = args[1];
  V v_e_243 = heff_env(self)[0];
  V v_cod_2420 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_x_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2425 = heff_get(heff_dup(v_e_243), LBL_elabFor);
  V v_t_2428;
  switch (heff_tag_of(v_t_2425)) {
  case TAG_ForNominative: {
    v_t_2428 = NTAG(TAG_ForNominative);
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2426 = heff_field(v_t_2425, 0);
    V v_sp_2427 = heff_field(v_t_2425, 1);
    V v_ru_24t_2425_24ForDescriptive = heff_take_reuse_n(v_t_2425, 3ULL, 2);
    v_t_2428 = heff_tag_at(v_ru_24t_2425_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2426, heff_tag(TAG_SpApp, 2, (V[]){v_sp_2427, heff_dup(v_v_2423)})});
    break;
  }
  default: heff_nomatch(v_t_2425);
  }
  V v_t_2429 = heff_intAdd(heff_get(heff_dup(v_e_243), LBL_lams), MK_INT(1LL));
  V v_e_2430 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){v_scope_27_2424, heff_get(heff_dup(v_e_243), LBL_globals), v_t_2428, v_t_2429, heff_get(heff_dup(v_e_243), LBL_self), heff_get(heff_dup(v_e_243), LBL_insts)});
  V v_x1_2436;
  switch (heff_tag_of(v_cod_2420)) {
  case TAG_MkClo: {
    V v_vs_2432 = heff_field(v_cod_2420, 1);
    V v_body_2433 = heff_field(v_cod_2420, 2);
    heff_take_n(v_cod_2420, 6ULL, 3);
    v_x1_2436 = heff_tr(heff_apply(v_body_2433, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2432, heff_clo(g_heff_2erules_2efunctionIntro_lam4, 1, 1, (V[]){v_v_2423})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2435 = heff_field(v_cod_2420, 0);
    heff_take_n(v_cod_2420, 1ULL, 1);
    heff_drop(v_v_2423);
    v_x1_2436 = v_body_2435;
    break;
  }
  default: heff_nomatch(v_cod_2420);
  }
  V v_a_2440;
  switch (heff_tag_of(v_x1_2436)) {
  case TAG_Nom: {
    V v_x_2437 = heff_field(v_x1_2436, 0);
    heff_take_n(v_x1_2436, 1ULL, 1);
    v_a_2440 = v_x_2437;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2436, 0ULL, 1);
    v_a_2440 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2439 = heff_field(v_x1_2436, 0);
    heff_take_n(v_x1_2436, 1ULL, 1);
    v_a_2440 = v_x_2439;
    break;
  }
  default: heff_nomatch(v_x1_2436);
  }
  V v_c_2442;
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2441 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    v_c_2442 = heff_tr(heff_apply(v_f_2441, 2, (V[]){v_e_2430, v_a_2440}));
    break;
  }
  default: heff_nomatch(v_body_242);
  }
  return heff_clo(g_heff_2erules_2efunctionIntro_lam5, 2, 4, (V[]){v_c_2442, v_e_243, v_x_2411, v_x_241});
}
V g_heff_2erules_2efunctionIntro_lam9(V self, V *args) {
  V v_u_2473 = args[0];
  V v_v_2461 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2473);
  return v_v_2461;
}
V g_heff_2erules_2efunctionIntro_lam12(V self, V *args) {
  V v_u_2497 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2497);
  return heff_tag(TAG_Nom, 1, (V[]){v_x_2411});
}
V g_heff_2erules_2efunctionIntro_lam11(V self, V *args) {
  V v_x_2484 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_cod_2420 = heff_env(self)[2];
  V v_k_2483 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2485 = heff_get(heff_dup(v_e_243), LBL_elabFor);
  V v_t_2488;
  switch (heff_tag_of(v_t_2485)) {
  case TAG_ForNominative: {
    v_t_2488 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2485, 0ULL, 2);
    v_t_2488 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2485);
  }
  V v_t_2489 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_locals);
  V v_t_2490 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_len);
  V v_t_2491 = (g_heff_2ereadback_2ereadbTypeF_24s182(v_t_2490, heff_dup(v_x_2411)));
  V v_t_2496;
  switch (heff_tag_of(v_cod_2420)) {
  case TAG_MkClo: {
    V v_n_2492 = heff_field(v_cod_2420, 0);
    heff_take_n(v_cod_2420, 1ULL, 3);
    v_t_2496 = v_n_2492;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2420, 0ULL, 1);
    v_t_2496 = ((V)&g_heff_2erules_2efunctionIntro_str3);
    break;
  }
  default: heff_nomatch(v_cod_2420);
  }
  V v_x_2498 = (g_heff_2ememoed_2elam(v_t_2488, heff_get(v_e_243, LBL_globals), v_t_2489, heff_rec(2, shape_326_366, (V[]){v_t_2491, heff_clo(g_heff_2erules_2efunctionIntro_lam12, 1, 1, (V[]){v_x_2411})}), heff_tag(TAG_MkAbs, 2, (V[]){v_t_2496, v_x_2484})));
  V f_ = v_k_2483;
  args[0] = v_x_2498;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2efunctionIntro_lam10(V self, V *args) {
  V v_hd_2482 = args[0];
  V v_k_2483 = args[1];
  V v_c_2481 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_cod_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2481;
  args[0] = v_hd_2482;
  args[1] = heff_clo(g_heff_2erules_2efunctionIntro_lam11, 1, 4, (V[]){v_e_243, v_x_2411, v_cod_2420, v_k_2483});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2efunctionIntro_lam8(V self, V *args) {
  V v_v_2461 = args[0];
  V v_scope_27_2462 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_cod_2420 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  V v_implicit_2421 = heff_env(self)[5];
  V v_dom_2419 = heff_env(self)[6];
  V v_x_2411 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x1_2463 = ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_body_242; V r_ = (g_heff_2erules_2efunctionIntro(a_0, a_1, a_2)); heff_drop(v_body_242); r_; });
  V v_t_2468;
  switch (heff_tag_of(v_cod_2420)) {
  case TAG_MkClo: {
    V v_n_2464 = heff_dup(heff_field(v_cod_2420, 0));
    v_t_2468 = v_n_2464;
    break;
  }
  case TAG_CloConst: {
    v_t_2468 = ((V)&g_heff_2erules_2efunctionIntro_str2);
    break;
  }
  default: heff_nomatch(v_cod_2420);
  }
  V v_e_2469 = ({ V a_0 = heff_dup(v_e_243); V a_1 = v_implicit_2421; V a_2 = v_t_2468; V a_3 = v_dom_2419; V a_4 = v_scope_27_2462; V a_5 = heff_dup(v_v_2461); V b_6 = NTAG(TAG_True); V r_ = (g_heff_2erules_2eintoSilent(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(v_implicit_2421); heff_drop(b_6); r_; });
  V v_x1_2475;
  switch (heff_tag_of(v_cod_2420)) {
  case TAG_MkClo: {
    V v_vs_2471 = heff_dup(heff_field(v_cod_2420, 1));
    V v_body_2472 = heff_dup(heff_field(v_cod_2420, 2));
    v_x1_2475 = heff_tr(heff_apply(v_body_2472, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2471, heff_clo(g_heff_2erules_2efunctionIntro_lam9, 1, 1, (V[]){v_v_2461})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2474 = heff_dup(heff_field(v_cod_2420, 0));
    heff_drop(v_v_2461);
    v_x1_2475 = v_body_2474;
    break;
  }
  default: heff_nomatch(v_cod_2420);
  }
  V v_a_2479;
  switch (heff_tag_of(v_x1_2475)) {
  case TAG_Nom: {
    V v_x_2476 = heff_field(v_x1_2475, 0);
    heff_take_n(v_x1_2475, 1ULL, 1);
    v_a_2479 = v_x_2476;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2475, 0ULL, 1);
    v_a_2479 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2478 = heff_field(v_x1_2475, 0);
    heff_take_n(v_x1_2475, 1ULL, 1);
    v_a_2479 = v_x_2478;
    break;
  }
  default: heff_nomatch(v_x1_2475);
  }
  V v_c_2481;
  switch (heff_tag_of(v_x1_2463)) {
  case TAG_MkChk: {
    V v_f_2480 = heff_field(v_x1_2463, 0);
    heff_take_n(v_x1_2463, 1ULL, 1);
    v_c_2481 = heff_tr(heff_apply(v_f_2480, 2, (V[]){v_e_2469, v_a_2479}));
    break;
  }
  default: heff_nomatch(v_x1_2463);
  }
  return heff_clo(g_heff_2erules_2efunctionIntro_lam10, 2, 4, (V[]){v_c_2481, v_e_243, v_x_2411, v_cod_2420});
}
V g_heff_2erules_2efunctionIntro_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  V v_body_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2412 = (g_heff_2evalue_2ebehavior(heff_dup(v_x_2411)));
  switch (heff_tag_of(v_t_2412)) {
  case TAG_LikeU: {
    V v_ru_24t_2412_24LikeU = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop(v_e_243);
    heff_drop(v_body_242);
    V v_t_2414 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntro_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2415 = heff_tag_at(v_ru_24t_2412_24LikeU, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2416}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2417, v_k_246});
  }
  case TAG_LikeFunction: {
    V v_dom_2419 = heff_field(v_t_2412, 1);
    V v_cod_2420 = heff_field(v_t_2412, 2);
    V v_implicit_2421 = heff_field(v_t_2412, 3);
    heff_take_n(v_t_2412, 14ULL, 4);
    V v_t_2422;
    switch (heff_tag_of(v_implicit_2421)) {
    case TAG_Expl: {
      v_t_2422 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2422 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2422 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2421);
    }
    switch (heff_tag_of(v_t_2422)) {
    case TAG_True: {
      heff_drop(v_sp_240);
      heff_drop(v_implicit_2421);
      V v_t_2455 = heff_tr(g_heff_2eenvironment_2ewithBound(heff_dup(v_x_241), v_dom_2419, heff_get(heff_dup(v_e_243), LBL_scope), heff_clo(g_heff_2erules_2efunctionIntro_lam3, 2, 5, (V[]){v_e_243, v_cod_2420, v_body_242, v_x_2411, v_x_241})));
      return heff_tail(v_t_2455, 2, (V[]){v_hd_245, v_k_246});
    }
    case TAG_False: {
      V v_t_2460;
      switch (heff_tag_of(v_cod_2420)) {
      case TAG_MkClo: {
        V v_n_2456 = heff_dup(heff_field(v_cod_2420, 0));
        v_t_2460 = v_n_2456;
        break;
      }
      case TAG_CloConst: {
        v_t_2460 = ((V)&g_heff_2erules_2efunctionIntro_str1);
        break;
      }
      default: heff_nomatch(v_cod_2420);
      }
      V v_t_2499 = heff_tr(g_heff_2eenvironment_2ewithBound(v_t_2460, heff_dup(v_dom_2419), heff_get(heff_dup(v_e_243), LBL_scope), heff_clo(g_heff_2erules_2efunctionIntro_lam8, 2, 8, (V[]){v_sp_240, v_x_241, v_body_242, v_cod_2420, v_e_243, v_implicit_2421, v_dom_2419, v_x_2411})));
      return heff_tail(v_t_2499, 2, (V[]){v_hd_245, v_k_246});
    }
    default: return heff_nomatch(v_t_2422);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2412, 0ULL, 3);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop(v_e_243);
    heff_drop(v_body_242);
    V v_t_24103 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntro_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24104 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24103})});
    V v_t_24105 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24104})});
    V v_t_24106 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_24105}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_24106, v_k_246});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2412_24LikeSum = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop(v_e_243);
    heff_drop(v_body_242);
    V v_t_24108 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntro_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24109 = heff_tag_at(v_ru_24t_2412_24LikeSum, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24108})});
    V v_t_24110 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24109})});
    V v_t_24111 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_24110}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_24111, v_k_246});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop(v_e_243);
    heff_drop(v_body_242);
    V v_t_24112 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntro_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24113 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24112})});
    V v_t_24114 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24113})});
    V v_t_24115 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_24114}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_24115, v_k_246});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop(v_e_243);
    heff_drop(v_body_242);
    V v_t_24116 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntro_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24117 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24116})});
    V v_t_24118 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24117})});
    V v_t_24119 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_24118}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_24119, v_k_246});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop(v_e_243);
    heff_drop(v_body_242);
    V v_t_24120 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntro_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24121 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24120})});
    V v_t_24122 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24121})});
    V v_t_24123 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_24122}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_24123, v_k_246});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2412_24LikeArray = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop(v_e_243);
    heff_drop(v_body_242);
    V v_t_24125 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntro_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24126 = heff_tag_at(v_ru_24t_2412_24LikeArray, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24125})});
    V v_t_24127 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24126})});
    V v_t_24128 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_24127}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_24128, v_k_246});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop(v_e_243);
    heff_drop(v_body_242);
    V v_t_24129 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntro_str10), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24130 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24129})});
    V v_t_24131 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24130})});
    V v_t_24132 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_24131}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_24132, v_k_246});
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2erules_2efunctionIntro_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a0_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2efunctionIntro_lam1, 1, 1, (V[]){v_a0_244})})});
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_249}));
  V f_ = heff_get(heff_dup(v_hd_245), LBL_bind);
  args[0] = v_t_2410;
  args[1] = heff_clo(g_heff_2erules_2efunctionIntro_lam2, 1, 6, (V[]){v_sp_240, v_hd_245, v_k_246, v_x_241, v_e_243, v_body_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2efunctionIntroSyn_lam3(V self, V *args);
V g_heff_2erules_2efunctionIntroSyn_lam5(V self, V *args);
V g_heff_2erules_2efunctionIntroSyn_lam6(V self, V *args);
V g_heff_2erules_2efunctionIntroSyn_lam4(V self, V *args);
V g_heff_2erules_2efunctionIntroSyn_lam2(V self, V *args);
V g_heff_2erules_2efunctionIntroSyn_lam1(V self, V *args);
V g_heff_2erules_2efunctionIntroSyn_lam0(V self, V *args);
Clo g_heff_2erules_2efunctionIntroSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2efunctionIntroSyn_entry, 3, 0};

V g_heff_2erules_2efunctionIntroSyn(V v_x_240, V v_dom_241, V v_body_242) {
top: ;
  return heff_tag(TAG_MkSyn, 1, (V[]){heff_clo(g_heff_2erules_2efunctionIntroSyn_lam0, 1, 3, (V[]){heff_dup(v_dom_241), v_x_240, heff_dup(v_body_242)})});
}
V g_heff_2erules_2efunctionIntroSyn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2efunctionIntroSyn(a[0], a[1], a[2]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
V g_heff_2erules_2efunctionIntroSyn_lam3(V self, V *args) {
  V v_v_2414 = args[0];
  V v_scope_27_2415 = args[1];
  V v_e_243 = heff_env(self)[0];
  V v_body_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_get(heff_dup(v_e_243), LBL_elabFor);
  V v_t_2419;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_ForNominative: {
    heff_drop(v_v_2414);
    v_t_2419 = NTAG(TAG_ForNominative);
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2417 = heff_field(v_t_2416, 0);
    V v_sp_2418 = heff_field(v_t_2416, 1);
    V v_ru_24t_2416_24ForDescriptive = heff_take_reuse_n(v_t_2416, 3ULL, 2);
    v_t_2419 = heff_tag_at(v_ru_24t_2416_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2417, heff_tag(TAG_SpApp, 2, (V[]){v_sp_2418, v_v_2414})});
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V v_e_2420 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){v_scope_27_2415, heff_get(heff_dup(v_e_243), LBL_globals), v_t_2419, heff_get(heff_dup(v_e_243), LBL_lams), heff_get(heff_dup(v_e_243), LBL_self), heff_get(v_e_243, LBL_insts)});
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkSyn: {
    V v_f_2421 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    V f_ = v_f_2421;
    args[0] = v_e_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_body_242);
  }
}
V g_heff_2erules_2efunctionIntroSyn_lam5(V self, V *args) {
  V v_u_2433 = args[0];
  V v_bty_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2433);
  return heff_tag(TAG_Nom, 1, (V[]){v_bty_2425});
}
V g_heff_2erules_2efunctionIntroSyn_lam6(V self, V *args) {
  V v_u_2440 = args[0];
  V v_bty_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2440);
  return heff_tag(TAG_Nom, 1, (V[]){v_bty_2425});
}
V g_heff_2erules_2efunctionIntroSyn_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_MkPair: {
    V v_ebody_2424 = heff_field(v_x_2423, 0);
    V v_bty_2425 = heff_field(v_x_2423, 1);
    V v_ru_24x_2423_24MkPair = heff_take_reuse_n(v_x_2423, 3ULL, 2);
    V v_t_2426 = heff_get(heff_dup(v_e_243), LBL_elabFor);
    V v_t_2429;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_ForNominative: {
      v_t_2429 = NTAG(TAG_N);
      break;
    }
    case TAG_ForDescriptive: {
      heff_take_n(v_t_2426, 0ULL, 2);
      v_t_2429 = NTAG(TAG_De);
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    V v_t_2430 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_locals);
    V v_t_2431 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_len);
    V v_t_2432 = (g_heff_2ereadback_2ereadbTypeF_24s182(heff_intAdd(v_t_2431, MK_INT(1LL)), heff_dup(v_bty_2425)));
    V v_cod_2434 = heff_tag_at(v_ru_24x_2423_24MkPair, TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), heff_rec(2, shape_326_366, (V[]){v_t_2432, heff_clo(g_heff_2erules_2efunctionIntroSyn_lam5, 1, 1, (V[]){heff_dup(v_bty_2425)})})});
    V v_t_2435 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_locals);
    V v_t_2436 = (g_heff_2ememoed_2efunctionI(NTAG(TAG_Expl), heff_get(heff_dup(v_e_243), LBL_globals), v_t_2435, heff_dup(v_x_248), v_cod_2434));
    V v_t_2437 = (g_heff_2ememoed_2elam(v_t_2429, heff_get(heff_dup(v_e_243), LBL_globals), v_t_2430, v_t_2436, heff_tag(TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), v_ebody_2424})));
    V v_t_2438 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_len);
    V v_t_2439 = (g_heff_2ereadback_2ereadbTypeF_24s182(heff_intAdd(v_t_2438, MK_INT(1LL)), heff_dup(v_bty_2425)));
    V v_cod_2441 = heff_tag(TAG_MkAbs, 2, (V[]){v_x_240, heff_rec(2, shape_326_366, (V[]){v_t_2439, heff_clo(g_heff_2erules_2efunctionIntroSyn_lam6, 1, 1, (V[]){v_bty_2425})})});
    V v_t_2442 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_locals);
    V v_m_2443 = (g_heff_2ememoed_2efunctionI(NTAG(TAG_Expl), heff_get(v_e_243, LBL_globals), v_t_2442, v_x_248, v_cod_2441));
    V v_x1_2444 = heff_tr(heff_apply(heff_get(v_m_2443, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2448;
    switch (heff_tag_of(v_x1_2444)) {
    case TAG_Nom: {
      V v_x_2445 = heff_field(v_x1_2444, 0);
      heff_take_n(v_x1_2444, 1ULL, 1);
      v_t_2448 = v_x_2445;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2444, 0ULL, 1);
      v_t_2448 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2447 = heff_field(v_x1_2444, 0);
      heff_take_n(v_x1_2444, 1ULL, 1);
      v_t_2448 = v_x_2447;
      break;
    }
    default: heff_nomatch(v_x1_2444);
    }
    V v_x_2449 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2437, v_t_2448});
    V f_ = v_k_247;
    args[0] = v_x_2449;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2erules_2efunctionIntroSyn_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_249 = heff_tr(heff_apply(heff_get(heff_dup(v_x_248), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2413;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nom: {
    V v_x_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_t_2413 = v_x_2410;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_t_2413 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2412 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_t_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  V v_c_2422 = heff_tr(g_heff_2eenvironment_2ewithBound(heff_dup(v_x_240), v_t_2413, heff_get(heff_dup(v_e_243), LBL_scope), heff_clo(g_heff_2erules_2efunctionIntroSyn_lam3, 2, 2, (V[]){heff_dup(v_e_243), v_body_242})));
  return heff_tail(v_c_2422, 2, (V[]){v_hd_246, heff_clo(g_heff_2erules_2efunctionIntroSyn_lam4, 1, 4, (V[]){v_e_243, v_x_240, v_x_248, v_k_247})});
}
V g_heff_2erules_2efunctionIntroSyn_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo(g_heff_2erules_2efunctionIntroSyn_lam2, 1, 5, (V[]){v_x_240, v_e_243, v_body_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2efunctionIntroSyn_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_dom_241 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245;
  switch (heff_tag_of(v_dom_241)) {
  case TAG_MkTyp: {
    V v_f_244 = heff_field(v_dom_241, 0);
    heff_take_n(v_dom_241, 1ULL, 1);
    v_c_245 = heff_tr(heff_apply(v_f_244, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_dom_241);
  }
  return heff_clo(g_heff_2erules_2efunctionIntroSyn_lam1, 2, 4, (V[]){v_c_245, v_x_240, v_e_243, v_body_242});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[62]; } g_heff_2erules_2erequireAgree_str0 = {{0x80000000u, K_STR, 0}, 62, 62, {116, 104, 101, 32, 98, 105, 110, 100, 101, 114, 39, 115, 32, 97, 110, 110, 111, 116, 97, 116, 105, 111, 110, 32, 105, 115, 32, 110, 111, 116, 32, 116, 104, 101, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 116, 121, 112, 101, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 104, 101, 114, 101}};
V g_heff_2erules_2erequireAgree_lam0(V self, V *args);
V g_heff_2erules_2erequireAgree_lam1(V self, V *args); static Clo g_heff_2erules_2erequireAgree_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erequireAgree_lam1, 2, 0};
Clo g_heff_2erules_2erequireAgree_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erequireAgree_entry, 3, 0};

V g_heff_2erules_2erequireAgree(V v_e_240, V v_sp_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Left: {
    V v_err_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_note_244 = ({ V a_0 = heff_get(v_e_240, LBL_globals); V a_1 = v_err_243; V r_ = (g_heff_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_243); r_; });
    return heff_clo(g_heff_2erules_2erequireAgree_lam0, 2, 2, (V[]){v_sp_241, v_note_244});
  }
  case TAG_Right: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    return ((V)&g_heff_2erules_2erequireAgree_lam1_clo);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2erules_2erequireAgree_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2erequireAgree(a[0], a[1], a[2]);
}
V g_heff_2erules_2erequireAgree_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k2_246 = args[1];
  V v_sp_241 = heff_env(self)[0];
  V v_note_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(311LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erequireAgree_str0), v_sp_241, heff_tag(TAG_Just, 1, (V[]){v_note_244})});
  V v_t_248 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_249}));
  V f_ = heff_get(v_hd_245, LBL_bind);
  args[0] = v_t_2410;
  args[1] = v_k2_246;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2erequireAgree_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2erules_2efunctionIntroAnn_str0 = {{0x80000000u, K_STR, 0}, 57, 57, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2efunctionIntroAnn_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2efunctionIntroAnn_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2efunctionIntroAnn_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2erules_2efunctionIntroAnn_str4 = {{0x80000000u, K_STR, 0}, 57, 57, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2erules_2efunctionIntroAnn_str5 = {{0x80000000u, K_STR, 0}, 57, 57, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2erules_2efunctionIntroAnn_str6 = {{0x80000000u, K_STR, 0}, 57, 57, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2erules_2efunctionIntroAnn_str7 = {{0x80000000u, K_STR, 0}, 57, 57, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2erules_2efunctionIntroAnn_str8 = {{0x80000000u, K_STR, 0}, 57, 57, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2erules_2efunctionIntroAnn_str9 = {{0x80000000u, K_STR, 0}, 57, 57, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2erules_2efunctionIntroAnn_str10 = {{0x80000000u, K_STR, 0}, 57, 57, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 108, 97, 109, 98, 100, 97, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
V g_heff_2erules_2efunctionIntroAnn_lam1(V self, V *args);
V g_heff_2erules_2efunctionIntroAnn_lam7(V self, V *args);
V g_heff_2erules_2efunctionIntroAnn_lam10(V self, V *args);
V g_heff_2erules_2efunctionIntroAnn_lam9(V self, V *args);
V g_heff_2erules_2efunctionIntroAnn_lam8(V self, V *args);
V g_heff_2erules_2efunctionIntroAnn_lam6(V self, V *args);
V g_heff_2erules_2efunctionIntroAnn_lam5(V self, V *args);
V g_heff_2erules_2efunctionIntroAnn_lam4(V self, V *args);
V g_heff_2erules_2efunctionIntroAnn_lam3(V self, V *args);
V g_heff_2erules_2efunctionIntroAnn_lam12(V self, V *args);
V g_heff_2erules_2efunctionIntroAnn_lam15(V self, V *args);
V g_heff_2erules_2efunctionIntroAnn_lam14(V self, V *args);
V g_heff_2erules_2efunctionIntroAnn_lam13(V self, V *args);
V g_heff_2erules_2efunctionIntroAnn_lam11(V self, V *args);
V g_heff_2erules_2efunctionIntroAnn_lam2(V self, V *args);
V g_heff_2erules_2efunctionIntroAnn_lam0(V self, V *args);
Clo g_heff_2erules_2efunctionIntroAnn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2efunctionIntroAnn_entry, 4, 0};

V g_heff_2erules_2efunctionIntroAnn(V v_sp_240, V v_x_241, V v_dom_242, V v_body_243) {
top: ;
  return heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2erules_2efunctionIntroAnn_lam0, 4, 4, (V[]){v_sp_240, heff_dup(v_dom_242), v_x_241, heff_dup(v_body_243)})});
}
V g_heff_2erules_2efunctionIntroAnn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2efunctionIntroAnn(a[0], a[1], a[2], a[3]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
V g_heff_2erules_2efunctionIntroAnn_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_248, LBL_metas); V a_1 = v_a0_245; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2erules_2efunctionIntroAnn_lam7(V self, V *args) {
  V v_u_2455 = args[0];
  V v_v_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2455);
  return v_v_2444;
}
V g_heff_2erules_2efunctionIntroAnn_lam10(V self, V *args) {
  V v_u_2474 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2474);
  return heff_tag(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2erules_2efunctionIntroAnn_lam9(V self, V *args) {
  V v_x_2466 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_k_2465 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2467 = heff_get(heff_dup(v_e_244), LBL_elabFor);
  V v_t_2470;
  switch (heff_tag_of(v_t_2467)) {
  case TAG_ForNominative: {
    v_t_2470 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2467, 0ULL, 2);
    v_t_2470 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2467);
  }
  V v_t_2471 = heff_get(heff_get(heff_dup(v_e_244), LBL_scope), LBL_locals);
  V v_t_2472 = heff_get(heff_get(heff_dup(v_e_244), LBL_scope), LBL_len);
  V v_t_2473 = (g_heff_2ereadback_2ereadbTypeF_24s182(v_t_2472, heff_dup(v_x_2412)));
  V v_x_2475 = (g_heff_2ememoed_2elam(v_t_2470, heff_get(v_e_244, LBL_globals), v_t_2471, heff_rec(2, shape_326_366, (V[]){v_t_2473, heff_clo(g_heff_2erules_2efunctionIntroAnn_lam10, 1, 1, (V[]){v_x_2412})}), heff_tag(TAG_MkAbs, 2, (V[]){v_x_241, v_x_2466})));
  V f_ = v_k_2465;
  args[0] = v_x_2475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2efunctionIntroAnn_lam8(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k_2465 = args[1];
  V v_c_2463 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2463;
  args[0] = v_hd_2464;
  args[1] = heff_clo(g_heff_2erules_2efunctionIntroAnn_lam9, 1, 4, (V[]){v_e_244, v_x_2412, v_x_241, v_k_2465});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2efunctionIntroAnn_lam6(V self, V *args) {
  V v_v_2444 = args[0];
  V v_scope_27_2445 = args[1];
  V v_e_244 = heff_env(self)[0];
  V v_cod_2421 = heff_env(self)[1];
  V v_body_243 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_x_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2446 = heff_get(heff_dup(v_e_244), LBL_elabFor);
  V v_t_2449;
  switch (heff_tag_of(v_t_2446)) {
  case TAG_ForNominative: {
    v_t_2449 = NTAG(TAG_ForNominative);
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2447 = heff_field(v_t_2446, 0);
    V v_sp_2448 = heff_field(v_t_2446, 1);
    V v_ru_24t_2446_24ForDescriptive = heff_take_reuse_n(v_t_2446, 3ULL, 2);
    v_t_2449 = heff_tag_at(v_ru_24t_2446_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2447, heff_tag(TAG_SpApp, 2, (V[]){v_sp_2448, heff_dup(v_v_2444)})});
    break;
  }
  default: heff_nomatch(v_t_2446);
  }
  V v_t_2450 = heff_intAdd(heff_get(heff_dup(v_e_244), LBL_lams), MK_INT(1LL));
  V v_e_2451 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){v_scope_27_2445, heff_get(heff_dup(v_e_244), LBL_globals), v_t_2449, v_t_2450, heff_get(heff_dup(v_e_244), LBL_self), heff_get(heff_dup(v_e_244), LBL_insts)});
  V v_x1_2457;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_vs_2453 = heff_field(v_cod_2421, 1);
    V v_body_2454 = heff_field(v_cod_2421, 2);
    heff_take_n(v_cod_2421, 6ULL, 3);
    v_x1_2457 = heff_tr(heff_apply(v_body_2454, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2453, heff_clo(g_heff_2erules_2efunctionIntroAnn_lam7, 1, 1, (V[]){v_v_2444})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2456 = heff_field(v_cod_2421, 0);
    heff_take_n(v_cod_2421, 1ULL, 1);
    heff_drop(v_v_2444);
    v_x1_2457 = v_body_2456;
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_a_2461;
  switch (heff_tag_of(v_x1_2457)) {
  case TAG_Nom: {
    V v_x_2458 = heff_field(v_x1_2457, 0);
    heff_take_n(v_x1_2457, 1ULL, 1);
    v_a_2461 = v_x_2458;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2457, 0ULL, 1);
    v_a_2461 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2460 = heff_field(v_x1_2457, 0);
    heff_take_n(v_x1_2457, 1ULL, 1);
    v_a_2461 = v_x_2460;
    break;
  }
  default: heff_nomatch(v_x1_2457);
  }
  V v_c_2463;
  switch (heff_tag_of(v_body_243)) {
  case TAG_MkChk: {
    V v_f_2462 = heff_field(v_body_243, 0);
    heff_take_n(v_body_243, 1ULL, 1);
    v_c_2463 = heff_tr(heff_apply(v_f_2462, 2, (V[]){v_e_2451, v_a_2461}));
    break;
  }
  default: heff_nomatch(v_body_243);
  }
  return heff_clo(g_heff_2erules_2efunctionIntroAnn_lam8, 2, 4, (V[]){v_c_2463, v_e_244, v_x_2412, v_x_241});
}
V g_heff_2erules_2efunctionIntroAnn_lam5(V self, V *args) {
  V v_x_2438 = args[0];
  V v_x_2426 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_cod_2421 = heff_env(self)[3];
  V v_body_243 = heff_env(self)[4];
  V v_x_2412 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2438);
  V v_x1_2439 = heff_tr(heff_apply(heff_get(v_x_2426, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2443;
  switch (heff_tag_of(v_x1_2439)) {
  case TAG_Nom: {
    V v_x_2440 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2440;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2439, 0ULL, 1);
    v_t_2443 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2442 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2442;
    break;
  }
  default: heff_nomatch(v_x1_2439);
  }
  V v_t_2476 = heff_tr(g_heff_2eenvironment_2ewithBound(heff_dup(v_x_241), v_t_2443, heff_get(heff_dup(v_e_244), LBL_scope), heff_clo(g_heff_2erules_2efunctionIntroAnn_lam6, 2, 5, (V[]){v_e_244, v_cod_2421, v_body_243, v_x_2412, v_x_241})));
  return heff_tail(v_t_2476, 2, (V[]){v_hd_246, v_k_247});
}
V g_heff_2erules_2efunctionIntroAnn_lam4(V self, V *args) {
  V v_x_2436 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_x_2426 = heff_env(self)[3];
  V v_x_241 = heff_env(self)[4];
  V v_cod_2421 = heff_env(self)[5];
  V v_body_243 = heff_env(self)[6];
  V v_x_2412 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2437 = (g_heff_2erules_2erequireAgree(heff_dup(v_e_244), v_sp_240, v_x_2436));
  return heff_tail(v_c_2437, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2erules_2efunctionIntroAnn_lam5, 1, 8, (V[]){v_x_2426, v_x_241, v_e_244, v_cod_2421, v_body_243, v_x_2412, v_hd_246, v_k_247})});
}
V g_heff_2erules_2efunctionIntroAnn_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_fdom_2420 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_x_241 = heff_env(self)[4];
  V v_cod_2421 = heff_env(self)[5];
  V v_body_243 = heff_env(self)[6];
  V v_x_2412 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2427 = heff_get(heff_dup(v_e_244), LBL_scope);
  V v_cs_2428 = heff_rec(2, shape_168_200, (V[]){heff_get(heff_dup(v_c_2427), LBL_len), heff_get(v_c_2427, LBL_names)});
  V v_x1_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_x_2426), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_b_2433;
  switch (heff_tag_of(v_x1_2429)) {
  case TAG_Nom: {
    V v_x_2430 = heff_field(v_x1_2429, 0);
    heff_take_n(v_x1_2429, 1ULL, 1);
    v_b_2433 = v_x_2430;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2429, 0ULL, 1);
    v_b_2433 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2432 = heff_field(v_x1_2429, 0);
    heff_take_n(v_x1_2429, 1ULL, 1);
    v_b_2433 = v_x_2432;
    break;
  }
  default: heff_nomatch(v_x1_2429);
  }
  V v_t_2434 = heff_tr(heff_apply(((V)&g_heff_2eunify_2euTypeF_24s392_clo), 4, (V[]){heff_get(heff_dup(v_e_244), LBL_globals), v_cs_2428, v_fdom_2420, v_b_2433}));
  V v_c_2435 = heff_tr(heff_apply(((V)&g_heff_2emeta_2eliftU_clo), 1, (V[]){v_t_2434}));
  return heff_tail(v_c_2435, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2erules_2efunctionIntroAnn_lam4, 1, 9, (V[]){v_e_244, v_sp_240, v_hd_246, v_x_2426, v_x_241, v_cod_2421, v_body_243, v_x_2412, v_k_247})});
}
V g_heff_2erules_2efunctionIntroAnn_lam12(V self, V *args) {
  V v_u_2494 = args[0];
  V v_v_2482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2494);
  return v_v_2482;
}
V g_heff_2erules_2efunctionIntroAnn_lam15(V self, V *args) {
  V v_u_24118 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24118);
  return heff_tag(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2erules_2efunctionIntroAnn_lam14(V self, V *args) {
  V v_x_24105 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_cod_2421 = heff_env(self)[2];
  V v_k_24104 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24106 = heff_get(heff_dup(v_e_244), LBL_elabFor);
  V v_t_24109;
  switch (heff_tag_of(v_t_24106)) {
  case TAG_ForNominative: {
    v_t_24109 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_24106, 0ULL, 2);
    v_t_24109 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_24106);
  }
  V v_t_24110 = heff_get(heff_get(heff_dup(v_e_244), LBL_scope), LBL_locals);
  V v_t_24111 = heff_get(heff_get(heff_dup(v_e_244), LBL_scope), LBL_len);
  V v_t_24112 = (g_heff_2ereadback_2ereadbTypeF_24s182(v_t_24111, heff_dup(v_x_2412)));
  V v_t_24117;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_n_24113 = heff_field(v_cod_2421, 0);
    heff_take_n(v_cod_2421, 1ULL, 3);
    v_t_24117 = v_n_24113;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2421, 0ULL, 1);
    v_t_24117 = ((V)&g_heff_2erules_2efunctionIntroAnn_str3);
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_x_24119 = (g_heff_2ememoed_2elam(v_t_24109, heff_get(v_e_244, LBL_globals), v_t_24110, heff_rec(2, shape_326_366, (V[]){v_t_24112, heff_clo(g_heff_2erules_2efunctionIntroAnn_lam15, 1, 1, (V[]){v_x_2412})}), heff_tag(TAG_MkAbs, 2, (V[]){v_t_24117, v_x_24105})));
  V f_ = v_k_24104;
  args[0] = v_x_24119;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2efunctionIntroAnn_lam13(V self, V *args) {
  V v_hd_24103 = args[0];
  V v_k_24104 = args[1];
  V v_c_24102 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_cod_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24102;
  args[0] = v_hd_24103;
  args[1] = heff_clo(g_heff_2erules_2efunctionIntroAnn_lam14, 1, 4, (V[]){v_e_244, v_x_2412, v_cod_2421, v_k_24104});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2efunctionIntroAnn_lam11(V self, V *args) {
  V v_v_2482 = args[0];
  V v_scope_27_2483 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_dom_242 = heff_env(self)[2];
  V v_body_243 = heff_env(self)[3];
  V v_cod_2421 = heff_env(self)[4];
  V v_e_244 = heff_env(self)[5];
  V v_implicit_2422 = heff_env(self)[6];
  V v_fdom_2420 = heff_env(self)[7];
  V v_x_2412 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x1_2484 = ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_dom_242; V a_3 = v_body_243; V r_ = (g_heff_2erules_2efunctionIntroAnn(a_0, a_1, a_2, a_3)); heff_drop(v_dom_242); heff_drop(v_body_243); r_; });
  V v_t_2489;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_n_2485 = heff_dup(heff_field(v_cod_2421, 0));
    v_t_2489 = v_n_2485;
    break;
  }
  case TAG_CloConst: {
    v_t_2489 = ((V)&g_heff_2erules_2efunctionIntroAnn_str2);
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_e_2490 = ({ V a_0 = heff_dup(v_e_244); V a_1 = v_implicit_2422; V a_2 = v_t_2489; V a_3 = v_fdom_2420; V a_4 = v_scope_27_2483; V a_5 = heff_dup(v_v_2482); V b_6 = NTAG(TAG_True); V r_ = (g_heff_2erules_2eintoSilent(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(v_implicit_2422); heff_drop(b_6); r_; });
  V v_x1_2496;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_vs_2492 = heff_dup(heff_field(v_cod_2421, 1));
    V v_body_2493 = heff_dup(heff_field(v_cod_2421, 2));
    v_x1_2496 = heff_tr(heff_apply(v_body_2493, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2492, heff_clo(g_heff_2erules_2efunctionIntroAnn_lam12, 1, 1, (V[]){v_v_2482})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2495 = heff_dup(heff_field(v_cod_2421, 0));
    heff_drop(v_v_2482);
    v_x1_2496 = v_body_2495;
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_a_24100;
  switch (heff_tag_of(v_x1_2496)) {
  case TAG_Nom: {
    V v_x_2497 = heff_field(v_x1_2496, 0);
    heff_take_n(v_x1_2496, 1ULL, 1);
    v_a_24100 = v_x_2497;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2496, 0ULL, 1);
    v_a_24100 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2499 = heff_field(v_x1_2496, 0);
    heff_take_n(v_x1_2496, 1ULL, 1);
    v_a_24100 = v_x_2499;
    break;
  }
  default: heff_nomatch(v_x1_2496);
  }
  V v_c_24102;
  switch (heff_tag_of(v_x1_2484)) {
  case TAG_MkChk: {
    V v_f_24101 = heff_field(v_x1_2484, 0);
    heff_take_n(v_x1_2484, 1ULL, 1);
    v_c_24102 = heff_tr(heff_apply(v_f_24101, 2, (V[]){v_e_2490, v_a_24100}));
    break;
  }
  default: heff_nomatch(v_x1_2484);
  }
  return heff_clo(g_heff_2erules_2efunctionIntroAnn_lam13, 2, 4, (V[]){v_c_24102, v_e_244, v_x_2412, v_cod_2421});
}
V g_heff_2erules_2efunctionIntroAnn_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_dom_242 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_x_241 = heff_env(self)[5];
  V v_body_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    V v_ru_24t_2413_24LikeU = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop(v_e_244);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_2415 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntroAnn_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2416 = heff_tag_at(v_ru_24t_2413_24LikeU, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2417}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2418, v_k_247});
  }
  case TAG_LikeFunction: {
    V v_fdom_2420 = heff_field(v_t_2413, 1);
    V v_cod_2421 = heff_field(v_t_2413, 2);
    V v_implicit_2422 = heff_field(v_t_2413, 3);
    heff_take_n(v_t_2413, 14ULL, 4);
    V v_t_2423;
    switch (heff_tag_of(v_implicit_2422)) {
    case TAG_Expl: {
      v_t_2423 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2423 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2423 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2422);
    }
    switch (heff_tag_of(v_t_2423)) {
    case TAG_True: {
      heff_drop(v_implicit_2422);
      V v_c_2425;
      switch (heff_tag_of(v_dom_242)) {
      case TAG_MkTyp: {
        V v_f_2424 = heff_field(v_dom_242, 0);
        heff_take_n(v_dom_242, 1ULL, 1);
        v_c_2425 = heff_tr(heff_apply(v_f_2424, 1, (V[]){heff_dup(v_e_244)}));
        break;
      }
      default: heff_nomatch(v_dom_242);
      }
      return heff_tail(v_c_2425, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2erules_2efunctionIntroAnn_lam3, 1, 9, (V[]){v_e_244, v_fdom_2420, v_hd_246, v_sp_240, v_x_241, v_cod_2421, v_body_243, v_x_2412, v_k_247})});
    }
    case TAG_False: {
      V v_t_2481;
      switch (heff_tag_of(v_cod_2421)) {
      case TAG_MkClo: {
        V v_n_2477 = heff_dup(heff_field(v_cod_2421, 0));
        v_t_2481 = v_n_2477;
        break;
      }
      case TAG_CloConst: {
        v_t_2481 = ((V)&g_heff_2erules_2efunctionIntroAnn_str1);
        break;
      }
      default: heff_nomatch(v_cod_2421);
      }
      V v_t_24120 = heff_tr(g_heff_2eenvironment_2ewithBound(v_t_2481, heff_dup(v_fdom_2420), heff_get(heff_dup(v_e_244), LBL_scope), heff_clo(g_heff_2erules_2efunctionIntroAnn_lam11, 2, 9, (V[]){v_sp_240, v_x_241, v_dom_242, v_body_243, v_cod_2421, v_e_244, v_implicit_2422, v_fdom_2420, v_x_2412})));
      return heff_tail(v_t_24120, 2, (V[]){v_hd_246, v_k_247});
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2413, 0ULL, 3);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop(v_e_244);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24124 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntroAnn_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24125 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24124})});
    V v_t_24126 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24125})});
    V v_t_24127 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24126}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24127, v_k_247});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2413_24LikeSum = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop(v_e_244);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24129 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntroAnn_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24130 = heff_tag_at(v_ru_24t_2413_24LikeSum, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24129})});
    V v_t_24131 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24130})});
    V v_t_24132 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24131}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24132, v_k_247});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop(v_e_244);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24133 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntroAnn_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24134 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24133})});
    V v_t_24135 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24134})});
    V v_t_24136 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24135}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24136, v_k_247});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop(v_e_244);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24137 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntroAnn_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24138 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24137})});
    V v_t_24139 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24138})});
    V v_t_24140 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24139}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24140, v_k_247});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop(v_e_244);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24141 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntroAnn_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24142 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24141})});
    V v_t_24143 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24142})});
    V v_t_24144 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24143}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24144, v_k_247});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2413_24LikeArray = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop(v_e_244);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24146 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntroAnn_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24147 = heff_tag_at(v_ru_24t_2413_24LikeArray, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24146})});
    V v_t_24148 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24147})});
    V v_t_24149 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24148}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24149, v_k_247});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop(v_e_244);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24150 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntroAnn_str10), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24151 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24150})});
    V v_t_24152 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24151})});
    V v_t_24153 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24152}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24153, v_k_247});
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2erules_2efunctionIntroAnn_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_a0_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_dom_242 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_body_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2efunctionIntroAnn_lam1, 1, 1, (V[]){v_a0_245})})});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2410}));
  V f_ = heff_get(heff_dup(v_hd_246), LBL_bind);
  args[0] = v_t_2411;
  args[1] = heff_clo(g_heff_2erules_2efunctionIntroAnn_lam2, 1, 7, (V[]){v_sp_240, v_hd_246, v_k_247, v_dom_242, v_e_244, v_x_241, v_body_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[82]; } g_heff_2erules_2efunctionIntroImplicit_str0 = {{0x80000000u, K_STR, 0}, 82, 82, {97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[82]; } g_heff_2erules_2efunctionIntroImplicit_str1 = {{0x80000000u, K_STR, 0}, 82, 82, {97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[82]; } g_heff_2erules_2efunctionIntroImplicit_str2 = {{0x80000000u, K_STR, 0}, 82, 82, {97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[82]; } g_heff_2erules_2efunctionIntroImplicit_str3 = {{0x80000000u, K_STR, 0}, 82, 82, {97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[82]; } g_heff_2erules_2efunctionIntroImplicit_str4 = {{0x80000000u, K_STR, 0}, 82, 82, {97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[82]; } g_heff_2erules_2efunctionIntroImplicit_str5 = {{0x80000000u, K_STR, 0}, 82, 82, {97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[82]; } g_heff_2erules_2efunctionIntroImplicit_str6 = {{0x80000000u, K_STR, 0}, 82, 82, {97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[82]; } g_heff_2erules_2efunctionIntroImplicit_str7 = {{0x80000000u, K_STR, 0}, 82, 82, {97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[82]; } g_heff_2erules_2efunctionIntroImplicit_str8 = {{0x80000000u, K_STR, 0}, 82, 82, {97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 108, 97, 109, 98, 100, 97, 32, 96, 92, 123, 120, 125, 32, 45, 62, 32, 46, 46, 46, 96, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116}};
V g_heff_2erules_2efunctionIntroImplicit_lam1(V self, V *args);
V g_heff_2erules_2efunctionIntroImplicit_lam4(V self, V *args);
V g_heff_2erules_2efunctionIntroImplicit_lam7(V self, V *args);
V g_heff_2erules_2efunctionIntroImplicit_lam6(V self, V *args);
V g_heff_2erules_2efunctionIntroImplicit_lam5(V self, V *args);
V g_heff_2erules_2efunctionIntroImplicit_lam3(V self, V *args);
V g_heff_2erules_2efunctionIntroImplicit_lam2(V self, V *args);
V g_heff_2erules_2efunctionIntroImplicit_lam0(V self, V *args);
Clo g_heff_2erules_2efunctionIntroImplicit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2efunctionIntroImplicit_entry, 3, 0};

V g_heff_2erules_2efunctionIntroImplicit(V v_sp_240, V v_x_241, V v_body_242) {
top: ;
  return heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2erules_2efunctionIntroImplicit_lam0, 4, 3, (V[]){v_sp_240, v_x_241, heff_dup(v_body_242)})});
}
V g_heff_2erules_2efunctionIntroImplicit_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2efunctionIntroImplicit(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2erules_2efunctionIntroImplicit_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_247, LBL_metas); V a_1 = v_a0_244; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2erules_2efunctionIntroImplicit_lam4(V self, V *args) {
  V v_u_2439 = args[0];
  V v_v_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2439);
  return v_v_2427;
}
V g_heff_2erules_2efunctionIntroImplicit_lam7(V self, V *args) {
  V v_u_2458 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2458);
  return heff_tag(TAG_Nom, 1, (V[]){v_x_2411});
}
V g_heff_2erules_2efunctionIntroImplicit_lam6(V self, V *args) {
  V v_x_2450 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_k_2449 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2451 = heff_get(heff_dup(v_e_243), LBL_elabFor);
  V v_t_2454;
  switch (heff_tag_of(v_t_2451)) {
  case TAG_ForNominative: {
    v_t_2454 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2451, 0ULL, 2);
    v_t_2454 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2451);
  }
  V v_t_2455 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_locals);
  V v_t_2456 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_len);
  V v_t_2457 = (g_heff_2ereadback_2ereadbTypeF_24s182(v_t_2456, heff_dup(v_x_2411)));
  V v_x_2459 = (g_heff_2ememoed_2elam(v_t_2454, heff_get(v_e_243, LBL_globals), v_t_2455, heff_rec(2, shape_326_366, (V[]){v_t_2457, heff_clo(g_heff_2erules_2efunctionIntroImplicit_lam7, 1, 1, (V[]){v_x_2411})}), heff_tag(TAG_MkAbs, 2, (V[]){v_x_241, v_x_2450})));
  V f_ = v_k_2449;
  args[0] = v_x_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2efunctionIntroImplicit_lam5(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  V v_c_2447 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2447;
  args[0] = v_hd_2448;
  args[1] = heff_clo(g_heff_2erules_2efunctionIntroImplicit_lam6, 1, 4, (V[]){v_e_243, v_x_2411, v_x_241, v_k_2449});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2efunctionIntroImplicit_lam3(V self, V *args) {
  V v_v_2427 = args[0];
  V v_scope_27_2428 = args[1];
  V v_e_243 = heff_env(self)[0];
  V v_implicit_2421 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_dom_2419 = heff_env(self)[3];
  V v_cod_2420 = heff_env(self)[4];
  V v_body_242 = heff_env(self)[5];
  V v_x_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2429 = heff_get(heff_dup(v_e_243), LBL_elabFor);
  V v_t_2432;
  switch (heff_tag_of(v_t_2429)) {
  case TAG_ForNominative: {
    v_t_2432 = NTAG(TAG_ForNominative);
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2430 = heff_field(v_t_2429, 0);
    V v_sp_2431 = heff_field(v_t_2429, 1);
    V v_ru_24t_2429_24ForDescriptive = heff_take_reuse_n(v_t_2429, 3ULL, 2);
    v_t_2432 = heff_tag_at(v_ru_24t_2429_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2430, heff_tag(TAG_SpApp, 2, (V[]){v_sp_2431, heff_dup(v_v_2427)})});
    break;
  }
  default: heff_nomatch(v_t_2429);
  }
  V v_t_2433 = heff_intAdd(heff_get(heff_dup(v_e_243), LBL_lams), MK_INT(1LL));
  V v_t_2434;
  switch (heff_tag_of(v_implicit_2421)) {
  case TAG_Expl: {
    heff_drop(v_dom_2419);
    v_t_2434 = heff_get(heff_dup(v_e_243), LBL_insts);
    break;
  }
  case TAG_Impl: {
    heff_drop(v_dom_2419);
    v_t_2434 = heff_get(heff_dup(v_e_243), LBL_insts);
    break;
  }
  case TAG_Inst: {
    v_t_2434 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(3, shape_198_351_365, (V[]){heff_dup(v_x_241), v_dom_2419, heff_dup(v_v_2427)}), heff_get(heff_dup(v_e_243), LBL_insts)});
    break;
  }
  default: heff_nomatch(v_implicit_2421);
  }
  V v_e_2435 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){v_scope_27_2428, heff_get(heff_dup(v_e_243), LBL_globals), v_t_2432, v_t_2433, heff_get(heff_dup(v_e_243), LBL_self), v_t_2434});
  V v_x1_2441;
  switch (heff_tag_of(v_cod_2420)) {
  case TAG_MkClo: {
    V v_vs_2437 = heff_field(v_cod_2420, 1);
    V v_body_2438 = heff_field(v_cod_2420, 2);
    heff_take_n(v_cod_2420, 6ULL, 3);
    v_x1_2441 = heff_tr(heff_apply(v_body_2438, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2437, heff_clo(g_heff_2erules_2efunctionIntroImplicit_lam4, 1, 1, (V[]){v_v_2427})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2440 = heff_field(v_cod_2420, 0);
    heff_take_n(v_cod_2420, 1ULL, 1);
    heff_drop(v_v_2427);
    v_x1_2441 = v_body_2440;
    break;
  }
  default: heff_nomatch(v_cod_2420);
  }
  V v_a_2445;
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_Nom: {
    V v_x_2442 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_a_2445 = v_x_2442;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2441, 0ULL, 1);
    v_a_2445 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2444 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_a_2445 = v_x_2444;
    break;
  }
  default: heff_nomatch(v_x1_2441);
  }
  V v_c_2447;
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2446 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    v_c_2447 = heff_tr(heff_apply(v_f_2446, 2, (V[]){v_e_2435, v_a_2445}));
    break;
  }
  default: heff_nomatch(v_body_242);
  }
  return heff_clo(g_heff_2erules_2efunctionIntroImplicit_lam5, 2, 4, (V[]){v_c_2447, v_e_243, v_x_2411, v_x_241});
}
V g_heff_2erules_2efunctionIntroImplicit_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  V v_body_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2412 = (g_heff_2evalue_2ebehavior(heff_dup(v_x_2411)));
  switch (heff_tag_of(v_t_2412)) {
  case TAG_LikeU: {
    V v_ru_24t_2412_24LikeU = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop(v_e_243);
    heff_drop(v_body_242);
    V v_t_2414 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntroImplicit_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2415 = heff_tag_at(v_ru_24t_2412_24LikeU, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2416}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2417, v_k_246});
  }
  case TAG_LikeFunction: {
    V v_dom_2419 = heff_field(v_t_2412, 1);
    V v_cod_2420 = heff_field(v_t_2412, 2);
    V v_implicit_2421 = heff_field(v_t_2412, 3);
    heff_take_n(v_t_2412, 14ULL, 4);
    V v_t_2422;
    switch (heff_tag_of(v_implicit_2421)) {
    case TAG_Expl: {
      v_t_2422 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2422 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2422 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2421);
    }
    switch (heff_tag_of(v_t_2422)) {
    case TAG_True: {
      heff_drop(v_x_2411);
      heff_drop(v_x_241);
      heff_drop(v_e_243);
      heff_drop(v_body_242);
      heff_drop(v_dom_2419);
      heff_drop(v_cod_2420);
      heff_drop(v_implicit_2421);
      V v_t_2423 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntroImplicit_str1), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2424 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2425}));
      return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2426, v_k_246});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_2460 = heff_tr(g_heff_2eenvironment_2ewithBound(heff_dup(v_x_241), heff_dup(v_dom_2419), heff_get(heff_dup(v_e_243), LBL_scope), heff_clo(g_heff_2erules_2efunctionIntroImplicit_lam3, 2, 7, (V[]){v_e_243, v_implicit_2421, v_x_241, v_dom_2419, v_cod_2420, v_body_242, v_x_2411})));
      return heff_tail(v_t_2460, 2, (V[]){v_hd_245, v_k_246});
    }
    default: return heff_nomatch(v_t_2422);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2412, 0ULL, 3);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop(v_e_243);
    heff_drop(v_body_242);
    V v_t_2464 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntroImplicit_str2), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2465 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2466}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2467, v_k_246});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2412_24LikeSum = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop(v_e_243);
    heff_drop(v_body_242);
    V v_t_2469 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntroImplicit_str3), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2470 = heff_tag_at(v_ru_24t_2412_24LikeSum, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2471}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2472, v_k_246});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop(v_e_243);
    heff_drop(v_body_242);
    V v_t_2473 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntroImplicit_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2474 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2475}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2476, v_k_246});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop(v_e_243);
    heff_drop(v_body_242);
    V v_t_2477 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntroImplicit_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2478 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2479}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2480, v_k_246});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop(v_e_243);
    heff_drop(v_body_242);
    V v_t_2481 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntroImplicit_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2482 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2481})});
    V v_t_2483 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2482})});
    V v_t_2484 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2483}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2484, v_k_246});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2412_24LikeArray = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop(v_e_243);
    heff_drop(v_body_242);
    V v_t_2486 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntroImplicit_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2487 = heff_tag_at(v_ru_24t_2412_24LikeArray, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2486})});
    V v_t_2488 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2487})});
    V v_t_2489 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2488}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2489, v_k_246});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop(v_e_243);
    heff_drop(v_body_242);
    V v_t_2490 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2efunctionIntroImplicit_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2491 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2491})});
    V v_t_2493 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2492}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2493, v_k_246});
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2erules_2efunctionIntroImplicit_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a0_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2efunctionIntroImplicit_lam1, 1, 1, (V[]){v_a0_244})})});
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_249}));
  V f_ = heff_get(heff_dup(v_hd_245), LBL_bind);
  args[0] = v_t_2410;
  args[1] = heff_clo(g_heff_2erules_2efunctionIntroImplicit_lam2, 1, 6, (V[]){v_sp_240, v_hd_245, v_k_246, v_x_241, v_e_243, v_body_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2enamedGo_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2enamedGo_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2enamedGo_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
V g_heff_2erules_2enamedGo_lam0(V self, V *args);
V g_heff_2erules_2enamedGo_lam3(V self, V *args);
V g_heff_2erules_2enamedGo_lam2(V self, V *args);
V g_heff_2erules_2enamedGo_lam5(V self, V *args);
V g_heff_2erules_2enamedGo_lam6(V self, V *args);
V g_heff_2erules_2enamedGo_lam4(V self, V *args);
V g_heff_2erules_2enamedGo_lam8(V self, V *args);
V g_heff_2erules_2enamedGo_lam7(V self, V *args);
V g_heff_2erules_2enamedGo_lam1(V self, V *args);
Clo g_heff_2erules_2enamedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2enamedGo_entry, 8, 0};

V g_heff_2erules_2enamedGo(V v_sp_240, V v_x_241, V v_arg_242, V v_e_243, V v_m_244, V v_ty0_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2enamedGo_lam0, 1, 1, (V[]){v_ty0_245})})});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2410}));
  return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_2411, heff_clo(g_heff_2erules_2enamedGo_lam1, 1, 7, (V[]){v_sp_240, v_x_241, v_hd_246, v_k_247, heff_dup(v_arg_242), v_e_243, v_m_244})});
}
V g_heff_2erules_2enamedGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2enamedGo(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[2]); return r;
}
V g_heff_2erules_2enamedGo_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_ty0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_248, LBL_metas); V a_1 = v_ty0_245; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2erules_2enamedGo_lam3(V self, V *args) {
  V v_u_2433 = args[0];
  V v_x_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2433);
  V v_x1_2434 = heff_tr(heff_apply(heff_get(v_x_2428, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_Nom: {
    V v_x_2435 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    return v_x_2435;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2434, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2437 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    return v_x_2437;
  }
  default: return heff_nomatch(v_x1_2434);
  }
}
V g_heff_2erules_2enamedGo_lam2(V self, V *args) {
  V v_x_2428 = args[0];
  V v_implicit_2418 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_cod_2417 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2429;
  switch (heff_tag_of(v_implicit_2418)) {
  case TAG_Expl: {
    heff_drop(v_x_241);
    v_t_2429 = (g_heff_2ememoed_2eapp(v_m_244, heff_dup(v_x_2428)));
    break;
  }
  case TAG_Impl: {
    v_t_2429 = (g_heff_2ememoed_2eiapp(v_x_241, v_m_244, heff_dup(v_x_2428)));
    break;
  }
  case TAG_Inst: {
    heff_drop(v_x_241);
    v_t_2429 = (g_heff_2ememoed_2eapp(v_m_244, heff_dup(v_x_2428)));
    break;
  }
  default: heff_nomatch(v_implicit_2418);
  }
  V v_x1_2439;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2431 = heff_field(v_cod_2417, 1);
    V v_body_2432 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2439 = heff_tr(heff_apply(v_body_2432, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2431, heff_clo(g_heff_2erules_2enamedGo_lam3, 1, 1, (V[]){v_x_2428})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2438 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop(v_x_2428);
    v_x1_2439 = v_body_2438;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2443;
  switch (heff_tag_of(v_x1_2439)) {
  case TAG_Nom: {
    V v_x_2440 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2440;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2439, 0ULL, 1);
    v_t_2443 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2442 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2442;
    break;
  }
  default: heff_nomatch(v_x1_2439);
  }
  V v_x_2444 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2429, v_t_2443});
  V f_ = v_k_247;
  args[0] = v_x_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2enamedGo_lam5(V self, V *args) {
  V v_u_2460 = args[0];
  V v_x_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2460);
  return heff_tag(TAG_Nom, 1, (V[]){heff_get(v_x_2454, LBL_val)});
}
V g_heff_2erules_2enamedGo_lam6(V self, V *args) {
  V v_u_2466 = args[0];
  V v_x_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2466);
  return heff_get(v_x_2454, LBL_val);
}
V g_heff_2erules_2enamedGo_lam4(V self, V *args) {
  V v_x_2454 = args[0];
  V v_cod_2417 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_e_243 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2459;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_n_2455 = heff_dup(heff_field(v_cod_2417, 0));
    v_t_2459 = v_n_2455;
    break;
  }
  case TAG_CloConst: {
    v_t_2459 = ((V)&g_heff_2erules_2enamedGo_str1);
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2461 = heff_rec(2, shape_326_366, (V[]){heff_get(heff_dup(v_x_2454), LBL_stx), heff_clo(g_heff_2erules_2enamedGo_lam5, 1, 1, (V[]){heff_dup(v_x_2454)})});
  V v_t_2462 = (g_heff_2ememoed_2eiapp(v_t_2459, v_m_244, v_t_2461));
  V v_x1_2468;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2464 = heff_field(v_cod_2417, 1);
    V v_body_2465 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2468 = heff_tr(heff_apply(v_body_2465, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2464, heff_clo(g_heff_2erules_2enamedGo_lam6, 1, 1, (V[]){v_x_2454})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2467 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop(v_x_2454);
    v_x1_2468 = v_body_2467;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2472;
  switch (heff_tag_of(v_x1_2468)) {
  case TAG_Nom: {
    V v_x_2469 = heff_field(v_x1_2468, 0);
    heff_take_n(v_x1_2468, 1ULL, 1);
    v_t_2472 = v_x_2469;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2468, 0ULL, 1);
    v_t_2472 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2471 = heff_field(v_x1_2468, 0);
    heff_take_n(v_x1_2468, 1ULL, 1);
    v_t_2472 = v_x_2471;
    break;
  }
  default: heff_nomatch(v_x1_2468);
  }
  return ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_arg_242; V a_3 = v_e_243; V a_4 = v_t_2462; V a_5 = v_t_2472; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2erules_2enamedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_arg_242); r_; });
}
V g_heff_2erules_2enamedGo_lam8(V self, V *args) {
  V v_u_2485 = args[0];
  V v_x_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2485);
  V v_x1_2486 = heff_tr(heff_apply(heff_get(v_x_2480, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2486)) {
  case TAG_Nom: {
    V v_x_2487 = heff_field(v_x1_2486, 0);
    heff_take_n(v_x1_2486, 1ULL, 1);
    return v_x_2487;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2486, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2489 = heff_field(v_x1_2486, 0);
    heff_take_n(v_x1_2486, 1ULL, 1);
    return v_x_2489;
  }
  default: return heff_nomatch(v_x1_2486);
  }
}
V g_heff_2erules_2enamedGo_lam7(V self, V *args) {
  V v_x_2480 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_cod_2417 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_e_243 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2481 = (g_heff_2ememoed_2eapp(v_m_244, heff_dup(v_x_2480)));
  V v_x1_2491;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2483 = heff_field(v_cod_2417, 1);
    V v_body_2484 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2491 = heff_tr(heff_apply(v_body_2484, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2483, heff_clo(g_heff_2erules_2enamedGo_lam8, 1, 1, (V[]){v_x_2480})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2490 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop(v_x_2480);
    v_x1_2491 = v_body_2490;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2495;
  switch (heff_tag_of(v_x1_2491)) {
  case TAG_Nom: {
    V v_x_2492 = heff_field(v_x1_2491, 0);
    heff_take_n(v_x1_2491, 1ULL, 1);
    v_t_2495 = v_x_2492;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2491, 0ULL, 1);
    v_t_2495 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2494 = heff_field(v_x1_2491, 0);
    heff_take_n(v_x1_2491, 1ULL, 1);
    v_t_2495 = v_x_2494;
    break;
  }
  default: heff_nomatch(v_x1_2491);
  }
  return ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_arg_242; V a_3 = v_e_243; V a_4 = v_t_2481; V a_5 = v_t_2495; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2erules_2enamedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_arg_242); r_; });
}
V g_heff_2erules_2enamedGo_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_e_243 = heff_env(self)[5];
  V v_m_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2evalue_2ebehavior(v_x_2412));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeFunction: {
    V v_dom_2416 = heff_field(v_t_2413, 1);
    V v_cod_2417 = heff_field(v_t_2413, 2);
    V v_implicit_2418 = heff_field(v_t_2413, 3);
    heff_take_n(v_t_2413, 14ULL, 4);
    V v_x1_2423;
    switch (heff_tag_of(v_cod_2417)) {
    case TAG_MkClo: {
      V v_n_2419 = heff_dup(heff_field(v_cod_2417, 0));
      v_x1_2423 = heff_tag(TAG_Just, 1, (V[]){v_n_2419});
      break;
    }
    case TAG_CloConst: {
      v_x1_2423 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_cod_2417);
    }
    V v_t_2425;
    switch (heff_tag_of(v_x1_2423)) {
    case TAG_Nothing: {
      v_t_2425 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_y_2424 = heff_field(v_x1_2423, 0);
      heff_take_n(v_x1_2423, 1ULL, 1);
      v_t_2425 = heff_strEq(v_y_2424, heff_dup(v_x_241));
      break;
    }
    default: heff_nomatch(v_x1_2423);
    }
    switch (heff_tag_of(v_t_2425)) {
    case TAG_True: {
      heff_drop(v_sp_240);
      V v_c_2427;
      switch (heff_tag_of(v_arg_242)) {
      case TAG_MkChk: {
        V v_f_2426 = heff_field(v_arg_242, 0);
        heff_take_n(v_arg_242, 1ULL, 1);
        v_c_2427 = heff_tr(heff_apply(v_f_2426, 2, (V[]){v_e_243, v_dom_2416}));
        break;
      }
      default: heff_nomatch(v_arg_242);
      }
      return heff_tail(v_c_2427, 2, (V[]){v_hd_246, heff_clo(g_heff_2erules_2enamedGo_lam2, 1, 5, (V[]){v_implicit_2418, v_m_244, v_x_241, v_cod_2417, v_k_247})});
    }
    case TAG_False: {
      V v_t_2445;
      switch (heff_tag_of(v_implicit_2418)) {
      case TAG_Expl: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_Impl: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_Inst: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_implicit_2418);
      }
      switch (heff_tag_of(v_t_2445)) {
      case TAG_True: {
        heff_drop(v_implicit_2418);
        V v_t_2446 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_len);
        V v_t_2447 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_locals);
        V v_t_2452;
        switch (heff_tag_of(v_cod_2417)) {
        case TAG_MkClo: {
          V v_n_2448 = heff_dup(heff_field(v_cod_2417, 0));
          v_t_2452 = v_n_2448;
          break;
        }
        case TAG_CloConst: {
          v_t_2452 = ((V)&g_heff_2erules_2enamedGo_str0);
          break;
        }
        default: heff_nomatch(v_cod_2417);
        }
        V v_c_2453 = heff_tr(heff_apply(((V)&g_heff_2erules_2efreshMeta_clo), 5, (V[]){v_t_2446, v_t_2447, v_dom_2416, v_t_2452, heff_dup(v_sp_240)}));
        return heff_tail(v_c_2453, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2erules_2enamedGo_lam4, 1, 8, (V[]){v_cod_2417, v_m_244, v_sp_240, v_x_241, v_arg_242, v_e_243, v_hd_246, v_k_247})});
      }
      case TAG_False: {
        V v_t_2473;
        switch (heff_tag_of(v_implicit_2418)) {
        case TAG_Expl: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_Impl: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_Inst: {
          v_t_2473 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_implicit_2418);
        }
        switch (heff_tag_of(v_t_2473)) {
        case TAG_True: {
          V v_t_2478;
          switch (heff_tag_of(v_cod_2417)) {
          case TAG_MkClo: {
            V v_n_2474 = heff_dup(heff_field(v_cod_2417, 0));
            v_t_2478 = v_n_2474;
            break;
          }
          case TAG_CloConst: {
            v_t_2478 = ((V)&g_heff_2erules_2enamedGo_str2);
            break;
          }
          default: heff_nomatch(v_cod_2417);
          }
          V v_c_2479 = heff_tr(heff_apply(((V)&g_heff_2erules_2einsertInstance_clo), 4, (V[]){heff_dup(v_e_243), heff_dup(v_sp_240), v_dom_2416, v_t_2478}));
          return heff_tail(v_c_2479, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2erules_2enamedGo_lam7, 1, 8, (V[]){v_m_244, v_cod_2417, v_sp_240, v_x_241, v_arg_242, v_e_243, v_hd_246, v_k_247})});
        }
        case TAG_False: {
          heff_drop(v_arg_242);
          heff_drop(v_e_243);
          heff_drop(v_m_244);
          heff_drop(v_dom_2416);
          heff_drop(v_cod_2417);
          return (g_heff_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
        }
        default: return heff_nomatch(v_t_2473);
        }
      }
      default: return heff_nomatch(v_t_2445);
      }
    }
    default: return heff_nomatch(v_t_2425);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2413, 0ULL, 3);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeInt: {
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeFloat: {
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeString: {
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_NoRules: {
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  default: return heff_nomatch(v_t_2413);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2edelayedCheck_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 104, 105, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[28]; } g_heff_2erules_2edelayedCheck_str1 = {{0x80000000u, K_STR, 0}, 28, 28, {32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 102, 105, 116, 32, 104, 111, 119, 32, 105, 116, 32, 105, 115, 32, 117, 115, 101, 100}};
V g_heff_2erules_2edelayedCheck_lam2(V self, V *args);
V g_heff_2erules_2edelayedCheck_lam1(V self, V *args);
V g_heff_2erules_2edelayedCheck_lam0(V self, V *args);
Clo g_heff_2erules_2edelayedCheck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2edelayedCheck_entry, 7, 0};

V g_heff_2erules_2edelayedCheck(V v_e_240, V v_sp_241, V v_what_242, V v_c_243, V v_ty_244, V v_m_245, V v_hole_246) {
top: ;
  V v_c_248;
  switch (heff_tag_of(v_c_243)) {
  case TAG_MkChk: {
    V v_f_247 = heff_field(v_c_243, 0);
    v_c_248 = heff_tr(heff_apply(heff_dup(v_f_247), 2, (V[]){heff_dup(v_e_240), v_ty_244}));
    break;
  }
  default: heff_nomatch(v_c_243);
  }
  return heff_clo(g_heff_2erules_2edelayedCheck_lam0, 2, 6, (V[]){v_c_248, v_e_240, v_m_245, v_hole_246, v_what_242, v_sp_241});
}
V g_heff_2erules_2edelayedCheck_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2edelayedCheck(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[3]); return r;
}
V g_heff_2erules_2edelayedCheck_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_what_242 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    V v_err_2421 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Left = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    V v_note_2422 = ({ V a_0 = heff_get(v_e_240, LBL_globals); V a_1 = v_err_2421; V r_ = (g_heff_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2421); r_; });
    V v_t_2423 = heff_strAppend(((V)&g_heff_2erules_2edelayedCheck_str0), heff_strAppend(v_what_242, ((V)&g_heff_2erules_2edelayedCheck_str1)));
    V v_t_2424 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_2423, v_sp_241, heff_tag(TAG_Just, 1, (V[]){v_note_2422})});
    V v_t_2425 = heff_tag_at(v_ru_24x_2420_24Left, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){v_t_2426}));
    return heff_tail(heff_get(v_hd_249, LBL_bind), 2, (V[]){v_t_2427, v_k_2410});
  }
  case TAG_Right: {
    heff_take_n(v_x_2420, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_what_242);
    heff_drop(v_sp_241);
    heff_drop(v_hd_249);
    V f_ = v_k_2410;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2erules_2edelayedCheck_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_m_245 = heff_env(self)[1];
  V v_hole_246 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_what_242 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2412 = heff_get(heff_dup(v_e_240), LBL_scope);
  V v_t_2413 = heff_rec(2, shape_168_200, (V[]){heff_get(heff_dup(v_c_2412), LBL_len), heff_get(v_c_2412, LBL_names)});
  V v_x1_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_x_2411), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2418;
  switch (heff_tag_of(v_x1_2414)) {
  case TAG_Nom: {
    V v_x_2415 = heff_field(v_x1_2414, 0);
    heff_take_n(v_x1_2414, 1ULL, 1);
    v_t_2418 = v_x_2415;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2414, 0ULL, 1);
    v_t_2418 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2417 = heff_field(v_x1_2414, 0);
    heff_take_n(v_x1_2414, 1ULL, 1);
    v_t_2418 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_x1_2414);
  }
  V v_c_2419 = heff_tr(heff_apply(((V)&g_heff_2erules_2esolveHole_clo), 6, (V[]){heff_get(heff_dup(v_e_240), LBL_globals), v_t_2413, v_m_245, heff_get(v_hole_246, LBL_val), heff_get(v_x_2411, LBL_stx), v_t_2418}));
  return heff_tail(v_c_2419, 2, (V[]){heff_dup(v_hd_249), heff_clo(g_heff_2erules_2edelayedCheck_lam2, 1, 5, (V[]){v_e_240, v_what_242, v_sp_241, v_hd_249, v_k_2410})});
}
V g_heff_2erules_2edelayedCheck_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_m_245 = heff_env(self)[2];
  V v_hole_246 = heff_env(self)[3];
  V v_what_242 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo(g_heff_2erules_2edelayedCheck_lam1, 1, 7, (V[]){v_e_240, v_m_245, v_hole_246, v_hd_249, v_what_242, v_sp_241, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2edelayChkOn_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {100, 101, 108, 97, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2erules_2edelayChkOn_str1 = {{0x80000000u, K_STR, 0}, 21, 21, {32, 119, 97, 105, 116, 115, 32, 102, 111, 114, 32, 105, 116, 115, 32, 116, 121, 112, 101, 32, 63}};
V g_heff_2erules_2edelayChkOn_lam1(V self, V *args);
V g_heff_2erules_2edelayChkOn_lam3(V self, V *args);
V g_heff_2erules_2edelayChkOn_lam5(V self, V *args);
V g_heff_2erules_2edelayChkOn_lam4(V self, V *args);
V g_heff_2erules_2edelayChkOn_lam2(V self, V *args);
V g_heff_2erules_2edelayChkOn_lam0(V self, V *args);
Clo g_heff_2erules_2edelayChkOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2edelayChkOn_entry, 8, 0};

V g_heff_2erules_2edelayChkOn(V v_e_240, V v_sp_241, V v_what_242, V v_c_243, V v_keyTy_244, V v_ty_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_248 = heff_get(heff_get(heff_dup(v_e_240), LBL_scope), LBL_len);
  V v_t_249 = heff_get(heff_get(heff_dup(v_e_240), LBL_scope), LBL_locals);
  return ({ V a_0 = v_t_248; V a_1 = v_t_249; V a_2 = heff_dup(v_ty_245); V a_3 = heff_dup(v_what_242); V a_4 = heff_dup(v_sp_241); V a_5 = heff_dup(v_hd_246); V a_6 = heff_clo(g_heff_2erules_2edelayChkOn_lam0, 1, 8, (V[]){v_e_240, v_sp_241, v_what_242, heff_dup(v_c_243), v_ty_245, v_keyTy_244, v_hd_246, v_k_247}); V r_ = (g_heff_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_249); r_; });
}
V g_heff_2erules_2edelayChkOn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2edelayChkOn(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[3]); return r;
}
V g_heff_2erules_2edelayChkOn_lam1(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k2_2445 = args[1];
  V v_chk_2443 = heff_env(self)[0];
  V v_keyTy_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = heff_tr(heff_apply(v_chk_2443, 2, (V[]){heff_dup(v_hd_2444), heff_get(heff_dup(v_hd_2444), LBL_ret)}));
  V v_t_2447 = heff_tag(TAG_Delay, 3, (V[]){v_keyTy_244, v_t_2446, NTAG(TAG_MkUnit)});
  V v_t_2448 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2444), LBL_malg), 1, (V[]){v_t_2448}));
  V f_ = heff_get(v_hd_2444, LBL_bind);
  args[0] = v_t_2449;
  args[1] = v_k2_2445;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2edelayChkOn_lam3(V self, V *args) {
  V v_u_2452 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_what_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2452);
  V v_t_2453 = heff_get(v_x_2410, LBL_stx);
  V v_t_2484;
  switch (heff_tag_of(v_t_2453)) {
  case TAG_SLocal: {
    heff_take_n(v_t_2453, 0ULL, 1);
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_2453, 0ULL, 1);
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_2453, 0ULL, 1);
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_2453, 0ULL, 2);
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_2453, 0ULL, 2);
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_2453, 0ULL, 1);
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_2453, 0ULL, 2);
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_2453, 0ULL, 2);
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_2453, 0ULL, 2);
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_2453, 0ULL, 3);
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_2453, 0ULL, 1);
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_2453, 0ULL, 1);
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_2453, 0ULL, 2);
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_2453, 0ULL, 2);
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_2453, 0ULL, 1);
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_2478 = heff_field(v_t_2453, 0);
    heff_take_n(v_t_2453, 1ULL, 3);
    v_t_2484 = v_k_2478;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_2453, 0ULL, 1);
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_n(v_t_2453, 0ULL, 1);
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_2453, 0ULL, 1);
    v_t_2484 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_2453);
  }
  return heff_strAppend(v_what_242, heff_strAppend(((V)&g_heff_2erules_2edelayChkOn_str1), heff_intShow(v_t_2484)));
}
V g_heff_2erules_2edelayChkOn_lam5(V self, V *args) {
  V v_u_2488 = args[0];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2488);
  return heff_tag(TAG_Nom, 1, (V[]){heff_get(v_x_2410, LBL_val)});
}
V g_heff_2erules_2edelayChkOn_lam4(V self, V *args) {
  V v_x_2487 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2487);
  V v_t_2489 = heff_rec(2, shape_326_366, (V[]){heff_get(heff_dup(v_x_2410), LBL_stx), heff_clo(g_heff_2erules_2edelayChkOn_lam5, 1, 1, (V[]){v_x_2410})});
  V f_ = v_k_247;
  args[0] = v_t_2489;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2edelayChkOn_lam2(V self, V *args) {
  V v_x_2451 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_what_242 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2451);
  V v_t_2485 = heff_tag(TAG_Trace, 2, (V[]){heff_rec(3, shape_314_154_337, (V[]){v_sp_241, ((V)&g_heff_2erules_2edelayChkOn_str0), heff_clo(g_heff_2erules_2edelayChkOn_lam3, 1, 2, (V[]){heff_dup(v_x_2410), v_what_242})}), NTAG(TAG_MkUnit)});
  V v_t_2486 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2485})}));
  return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2486, heff_clo(g_heff_2erules_2edelayChkOn_lam4, 1, 2, (V[]){v_x_2410, v_k_247})});
}
V g_heff_2erules_2edelayChkOn_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_what_242 = heff_env(self)[2];
  V v_c_243 = heff_env(self)[3];
  V v_ty_245 = heff_env(self)[4];
  V v_keyTy_244 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2411 = heff_get(heff_dup(v_x_2410), LBL_stx);
  V v_t_2442;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_SLocal: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_2411, 0ULL, 3);
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_2436 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 3);
    v_t_2442 = v_k_2436;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2442 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  V v_chk_2443 = ({ V a_0 = v_e_240; V a_1 = heff_dup(v_sp_241); V a_2 = heff_dup(v_what_242); V a_3 = v_c_243; V a_4 = v_ty_245; V a_5 = v_t_2442; V a_6 = heff_dup(v_x_2410); V r_ = (g_heff_2erules_2edelayedCheck(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_c_243); r_; });
  V v_c_2450 = heff_clo(g_heff_2erules_2edelayChkOn_lam1, 2, 2, (V[]){v_chk_2443, v_keyTy_244});
  return heff_tail(v_c_2450, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2erules_2edelayChkOn_lam2, 1, 5, (V[]){v_sp_241, v_x_2410, v_what_242, v_hd_246, v_k_247})});
}
V g_heff_2erules_2eelimPlain_lam2(V self, V *args);
V g_heff_2erules_2eelimPlain_lam1(V self, V *args);
V g_heff_2erules_2eelimPlain_lam0(V self, V *args);
Clo g_heff_2erules_2eelimPlain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eelimPlain_entry, 5, 0};

V g_heff_2erules_2eelimPlain(V v_e_240, V v_ecallee_241, V v_dom_242, V v_cod_243, V v_arg_244) {
top: ;
  V v_c_246;
  switch (heff_tag_of(v_arg_244)) {
  case TAG_MkChk: {
    V v_f_245 = heff_field(v_arg_244, 0);
    v_c_246 = heff_tr(heff_apply(heff_dup(v_f_245), 2, (V[]){v_e_240, v_dom_242}));
    break;
  }
  default: heff_nomatch(v_arg_244);
  }
  return heff_clo(g_heff_2erules_2eelimPlain_lam0, 2, 3, (V[]){v_c_246, v_ecallee_241, heff_dup(v_cod_243)});
}
V g_heff_2erules_2eelimPlain_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2eelimPlain(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[3]); heff_drop(a[4]); return r;
}
V g_heff_2erules_2eelimPlain_lam2(V self, V *args) {
  V v_u_2414 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2414);
  V v_x1_2415 = heff_tr(heff_apply(heff_get(v_x_249, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_Nom: {
    V v_x_2416 = heff_field(v_x1_2415, 0);
    heff_take_n(v_x1_2415, 1ULL, 1);
    return v_x_2416;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2415, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2418 = heff_field(v_x1_2415, 0);
    heff_take_n(v_x1_2415, 1ULL, 1);
    return v_x_2418;
  }
  default: return heff_nomatch(v_x1_2415);
  }
}
V g_heff_2erules_2eelimPlain_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_ecallee_241 = heff_env(self)[0];
  V v_cod_243 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = (g_heff_2ememoed_2eapp(v_ecallee_241, heff_dup(v_x_249)));
  V v_x1_2420;
  switch (heff_tag_of(v_cod_243)) {
  case TAG_MkClo: {
    V v_vs_2412 = heff_field(v_cod_243, 1);
    V v_body_2413 = heff_field(v_cod_243, 2);
    heff_take_n(v_cod_243, 6ULL, 3);
    v_x1_2420 = heff_tr(heff_apply(v_body_2413, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2412, heff_clo(g_heff_2erules_2eelimPlain_lam2, 1, 1, (V[]){v_x_249})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2419 = heff_field(v_cod_243, 0);
    heff_take_n(v_cod_243, 1ULL, 1);
    heff_drop(v_x_249);
    v_x1_2420 = v_body_2419;
    break;
  }
  default: heff_nomatch(v_cod_243);
  }
  V v_t_2424;
  switch (heff_tag_of(v_x1_2420)) {
  case TAG_Nom: {
    V v_x_2421 = heff_field(v_x1_2420, 0);
    heff_take_n(v_x1_2420, 1ULL, 1);
    v_t_2424 = v_x_2421;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2420, 0ULL, 1);
    v_t_2424 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2423 = heff_field(v_x1_2420, 0);
    heff_take_n(v_x1_2420, 1ULL, 1);
    v_t_2424 = v_x_2423;
    break;
  }
  default: heff_nomatch(v_x1_2420);
  }
  V v_x_2425 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2410, v_t_2424});
  V f_ = v_k_248;
  args[0] = v_x_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2eelimPlain_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_ecallee_241 = heff_env(self)[1];
  V v_cod_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo(g_heff_2erules_2eelimPlain_lam1, 1, 3, (V[]){v_ecallee_241, v_cod_243, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2erules_2eelimGo_str0 = {{0x80000000u, K_STR, 0}, 54, 54, {116, 114, 105, 101, 100, 32, 116, 111, 32, 97, 112, 112, 108, 121, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2erules_2eelimGo_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {97, 114, 103, 117, 109, 101, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2erules_2eelimGo_str2 = {{0x80000000u, K_STR, 0}, 54, 54, {116, 114, 105, 101, 100, 32, 116, 111, 32, 97, 112, 112, 108, 121, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2erules_2eelimGo_str3 = {{0x80000000u, K_STR, 0}, 54, 54, {116, 114, 105, 101, 100, 32, 116, 111, 32, 97, 112, 112, 108, 121, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2erules_2eelimGo_str4 = {{0x80000000u, K_STR, 0}, 54, 54, {116, 114, 105, 101, 100, 32, 116, 111, 32, 97, 112, 112, 108, 121, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2erules_2eelimGo_str5 = {{0x80000000u, K_STR, 0}, 54, 54, {116, 114, 105, 101, 100, 32, 116, 111, 32, 97, 112, 112, 108, 121, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2erules_2eelimGo_str6 = {{0x80000000u, K_STR, 0}, 54, 54, {116, 114, 105, 101, 100, 32, 116, 111, 32, 97, 112, 112, 108, 121, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2erules_2eelimGo_str7 = {{0x80000000u, K_STR, 0}, 54, 54, {116, 114, 105, 101, 100, 32, 116, 111, 32, 97, 112, 112, 108, 121, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2erules_2eelimGo_str8 = {{0x80000000u, K_STR, 0}, 54, 54, {116, 114, 105, 101, 100, 32, 116, 111, 32, 97, 112, 112, 108, 121, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
V g_heff_2erules_2eelimGo_lam1(V self, V *args);
V g_heff_2erules_2eelimGo_lam0(V self, V *args);
V g_heff_2erules_2eelimGo_lam3(V self, V *args);
V g_heff_2erules_2eelimGo_lam6(V self, V *args);
V g_heff_2erules_2eelimGo_lam5(V self, V *args);
V g_heff_2erules_2eelimGo_lam4(V self, V *args);
V g_heff_2erules_2eelimGo_lam2(V self, V *args);
V g_heff_2erules_2eelimGo_lam8(V self, V *args);
V g_heff_2erules_2eelimGo_lam7(V self, V *args);
V g_heff_2erules_2eelimGo_lam10(V self, V *args);
V g_heff_2erules_2eelimGo_lam9(V self, V *args);
V g_heff_2erules_2eelimGo_lam12(V self, V *args);
V g_heff_2erules_2eelimGo_lam11(V self, V *args);
V g_heff_2erules_2eelimGo_lam14(V self, V *args);
V g_heff_2erules_2eelimGo_lam13(V self, V *args);
V g_heff_2erules_2eelimGo_lam16(V self, V *args);
V g_heff_2erules_2eelimGo_lam15(V self, V *args);
V g_heff_2erules_2eelimGo_lam18(V self, V *args);
V g_heff_2erules_2eelimGo_lam17(V self, V *args);
V g_heff_2erules_2eelimGo_lam20(V self, V *args);
V g_heff_2erules_2eelimGo_lam19(V self, V *args);
Clo g_heff_2erules_2eelimGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eelimGo_entry, 5, 0};

V g_heff_2erules_2eelimGo(V v_checksOnly_240, V v_sp_241, V v_arg_242, V v_e_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_ecallee_245 = heff_field(v_x5_244, 0);
    V v_a_246 = heff_field(v_x5_244, 1);
    heff_take_n(v_x5_244, 3ULL, 2);
    V v_t_247 = (g_heff_2evalue_2ebehavior(heff_dup(v_a_246)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_LikeU: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_e_243);
      heff_drop(v_ecallee_245);
      return heff_clo(g_heff_2erules_2eelimGo_lam0, 2, 2, (V[]){v_a_246, v_sp_241});
    }
    case TAG_LikeFunction: {
      V v_dom_2417 = heff_field(v_t_247, 1);
      V v_cod_2418 = heff_field(v_t_247, 2);
      heff_take_n(v_t_247, 6ULL, 4);
      heff_drop(v_a_246);
      switch (heff_tag_of(v_checksOnly_240)) {
      case TAG_True: {
        return heff_clo(g_heff_2erules_2eelimGo_lam2, 2, 6, (V[]){v_dom_2417, v_e_243, v_ecallee_245, v_cod_2418, heff_dup(v_arg_242), v_sp_241});
      }
      case TAG_False: {
        heff_drop(v_sp_241);
        return ({ V a_0 = v_e_243; V a_1 = v_ecallee_245; V a_2 = v_dom_2417; V a_3 = v_cod_2418; V a_4 = v_arg_242; V r_ = (g_heff_2erules_2eelimPlain(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_cod_2418); r_; });
      }
      default: return heff_nomatch(v_checksOnly_240);
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_247, 0ULL, 3);
      heff_drop(v_e_243);
      heff_drop(v_ecallee_245);
      return heff_clo(g_heff_2erules_2eelimGo_lam7, 2, 2, (V[]){v_a_246, v_sp_241});
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_e_243);
      heff_drop(v_ecallee_245);
      return heff_clo(g_heff_2erules_2eelimGo_lam9, 2, 2, (V[]){v_a_246, v_sp_241});
    }
    case TAG_LikeInt: {
      heff_drop(v_e_243);
      heff_drop(v_ecallee_245);
      return heff_clo(g_heff_2erules_2eelimGo_lam11, 2, 2, (V[]){v_a_246, v_sp_241});
    }
    case TAG_LikeFloat: {
      heff_drop(v_e_243);
      heff_drop(v_ecallee_245);
      return heff_clo(g_heff_2erules_2eelimGo_lam13, 2, 2, (V[]){v_a_246, v_sp_241});
    }
    case TAG_LikeString: {
      heff_drop(v_e_243);
      heff_drop(v_ecallee_245);
      return heff_clo(g_heff_2erules_2eelimGo_lam15, 2, 2, (V[]){v_a_246, v_sp_241});
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_e_243);
      heff_drop(v_ecallee_245);
      return heff_clo(g_heff_2erules_2eelimGo_lam17, 2, 2, (V[]){v_a_246, v_sp_241});
    }
    case TAG_NoRules: {
      heff_drop(v_e_243);
      heff_drop(v_ecallee_245);
      return heff_clo(g_heff_2erules_2eelimGo_lam19, 2, 2, (V[]){v_a_246, v_sp_241});
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2erules_2eelimGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2eelimGo(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); heff_drop(a[2]); return r;
}
V g_heff_2erules_2eelimGo_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_True: {
    heff_drop(v_sp_241);
    return heff_tail(heff_dup(g_heff_2erules_2eerrorOf_get()), 2, (V[]){v_hd_249, v_k_2410});
  }
  case TAG_False: {
    V v_t_2412 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2eelimGo_str0), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){v_t_2414}));
    return heff_tail(heff_get(v_hd_249, LBL_bind), 2, (V[]){v_t_2415, v_k_2410});
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2erules_2eelimGo_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2emeta_2eblockedTy(v_a_246, heff_dup(v_hd_249), heff_clo(g_heff_2erules_2eelimGo_lam1, 1, 3, (V[]){v_hd_249, v_k_2410, v_sp_241})));
}
V g_heff_2erules_2eelimGo_lam3(V self, V *args) {
  V v_c_2422 = args[0];
  V v_dom_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_2422, LBL_metas); V a_1 = v_dom_2417; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2erules_2eelimGo_lam6(V self, V *args) {
  V v_u_2454 = args[0];
  V v_x_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2454);
  V v_x1_2455 = heff_tr(heff_apply(heff_get(v_x_2449, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2455)) {
  case TAG_Nom: {
    V v_x_2456 = heff_field(v_x1_2455, 0);
    heff_take_n(v_x1_2455, 1ULL, 1);
    return v_x_2456;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2455, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2458 = heff_field(v_x1_2455, 0);
    heff_take_n(v_x1_2455, 1ULL, 1);
    return v_x_2458;
  }
  default: return heff_nomatch(v_x1_2455);
  }
}
V g_heff_2erules_2eelimGo_lam5(V self, V *args) {
  V v_x_2449 = args[0];
  V v_ecallee_245 = heff_env(self)[0];
  V v_cod_2418 = heff_env(self)[1];
  V v_k_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2450 = (g_heff_2ememoed_2eapp(v_ecallee_245, heff_dup(v_x_2449)));
  V v_x1_2460;
  switch (heff_tag_of(v_cod_2418)) {
  case TAG_MkClo: {
    V v_vs_2452 = heff_field(v_cod_2418, 1);
    V v_body_2453 = heff_field(v_cod_2418, 2);
    heff_take_n(v_cod_2418, 6ULL, 3);
    v_x1_2460 = heff_tr(heff_apply(v_body_2453, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2452, heff_clo(g_heff_2erules_2eelimGo_lam6, 1, 1, (V[]){v_x_2449})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2459 = heff_field(v_cod_2418, 0);
    heff_take_n(v_cod_2418, 1ULL, 1);
    heff_drop(v_x_2449);
    v_x1_2460 = v_body_2459;
    break;
  }
  default: heff_nomatch(v_cod_2418);
  }
  V v_t_2464;
  switch (heff_tag_of(v_x1_2460)) {
  case TAG_Nom: {
    V v_x_2461 = heff_field(v_x1_2460, 0);
    heff_take_n(v_x1_2460, 1ULL, 1);
    v_t_2464 = v_x_2461;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2460, 0ULL, 1);
    v_t_2464 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2463 = heff_field(v_x1_2460, 0);
    heff_take_n(v_x1_2460, 1ULL, 1);
    v_t_2464 = v_x_2463;
    break;
  }
  default: heff_nomatch(v_x1_2460);
  }
  V v_x_2465 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2450, v_t_2464});
  V f_ = v_k_2421;
  args[0] = v_x_2465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2eelimGo_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_ecallee_245 = heff_env(self)[1];
  V v_dom_2417 = heff_env(self)[2];
  V v_cod_2418 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_hd_2420 = heff_env(self)[5];
  V v_k_2421 = heff_env(self)[6];
  V v_sp_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x1_2446;
  switch (heff_tag_of(v_x_2426)) {
  case TAG_VU: {
    v_x1_2446 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_it1_2428 = heff_dup(heff_field(v_x_2426, 0));
    switch (heff_tag_of(v_it1_2428)) {
    case TAG_HLocal: {
      heff_take_n(v_it1_2428, 0ULL, 1);
      v_x1_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_it1_2428, 0ULL, 1);
      v_x1_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_it1_2428, 0ULL, 1);
      v_x1_2446 = NTAG(TAG_True);
      break;
    }
    case TAG_HError: {
      v_x1_2446 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_it1_2428);
    }
    break;
  }
  case TAG_VFunction: {
    v_x1_2446 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_x1_2446 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_x1_2446 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_x1_2446 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_x1_2446 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_x1_2446 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_x1_2446 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2426);
  }
  V v_t_2447;
  switch (heff_tag_of(v_x1_2446)) {
  case TAG_True: {
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_2447 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_2446);
  }
  switch (heff_tag_of(v_t_2447)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_241);
    V v_t_2448 = ({ V a_0 = v_e_243; V a_1 = v_ecallee_245; V a_2 = v_dom_2417; V a_3 = v_cod_2418; V a_4 = v_arg_242; V r_ = (g_heff_2erules_2eelimPlain(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_cod_2418); heff_drop(v_arg_242); r_; });
    return heff_tail(v_t_2448, 2, (V[]){v_hd_2420, v_k_2421});
  }
  case TAG_False: {
    heff_drop(v_dom_2417);
    return ({ V a_0 = v_e_243; V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2erules_2eelimGo_str1); V a_3 = v_arg_242; V a_4 = heff_dup(v_x_2426); V a_5 = v_x_2426; V a_6 = v_hd_2420; V a_7 = heff_clo(g_heff_2erules_2eelimGo_lam5, 1, 3, (V[]){v_ecallee_245, v_cod_2418, v_k_2421}); V r_ = (g_heff_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_arg_242); r_; });
  }
  default: return heff_nomatch(v_t_2447);
  }
}
V g_heff_2erules_2eelimGo_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_dom_2417 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_ecallee_245 = heff_env(self)[2];
  V v_cod_2418 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2eelimGo_lam3, 1, 1, (V[]){heff_dup(v_dom_2417)})})});
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2420), LBL_malg), 1, (V[]){v_t_2424}));
  V f_ = heff_get(heff_dup(v_hd_2420), LBL_bind);
  args[0] = v_t_2425;
  args[1] = heff_clo(g_heff_2erules_2eelimGo_lam4, 1, 8, (V[]){v_e_243, v_ecallee_245, v_dom_2417, v_cod_2418, v_arg_242, v_hd_2420, v_k_2421, v_sp_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2eelimGo_lam8(V self, V *args) {
  V v_x_2471 = args[0];
  V v_hd_2469 = heff_env(self)[0];
  V v_k_2470 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2471)) {
  case TAG_True: {
    heff_drop(v_sp_241);
    return heff_tail(heff_dup(g_heff_2erules_2eerrorOf_get()), 2, (V[]){v_hd_2469, v_k_2470});
  }
  case TAG_False: {
    V v_t_2472 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2eelimGo_str2), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2473 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2472})});
    V v_t_2474 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2469), LBL_malg), 1, (V[]){v_t_2474}));
    return heff_tail(heff_get(v_hd_2469, LBL_bind), 2, (V[]){v_t_2475, v_k_2470});
  }
  default: return heff_nomatch(v_x_2471);
  }
}
V g_heff_2erules_2eelimGo_lam7(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k_2470 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2emeta_2eblockedTy(v_a_246, heff_dup(v_hd_2469), heff_clo(g_heff_2erules_2eelimGo_lam8, 1, 3, (V[]){v_hd_2469, v_k_2470, v_sp_241})));
}
V g_heff_2erules_2eelimGo_lam10(V self, V *args) {
  V v_x_2479 = args[0];
  V v_hd_2477 = heff_env(self)[0];
  V v_k_2478 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2479)) {
  case TAG_True: {
    heff_drop(v_sp_241);
    return heff_tail(heff_dup(g_heff_2erules_2eerrorOf_get()), 2, (V[]){v_hd_2477, v_k_2478});
  }
  case TAG_False: {
    V v_t_2480 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2eelimGo_str3), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2481 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2481})});
    V v_t_2483 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2477), LBL_malg), 1, (V[]){v_t_2482}));
    return heff_tail(heff_get(v_hd_2477, LBL_bind), 2, (V[]){v_t_2483, v_k_2478});
  }
  default: return heff_nomatch(v_x_2479);
  }
}
V g_heff_2erules_2eelimGo_lam9(V self, V *args) {
  V v_hd_2477 = args[0];
  V v_k_2478 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2emeta_2eblockedTy(v_a_246, heff_dup(v_hd_2477), heff_clo(g_heff_2erules_2eelimGo_lam10, 1, 3, (V[]){v_hd_2477, v_k_2478, v_sp_241})));
}
V g_heff_2erules_2eelimGo_lam12(V self, V *args) {
  V v_x_2486 = args[0];
  V v_hd_2484 = heff_env(self)[0];
  V v_k_2485 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2486)) {
  case TAG_True: {
    heff_drop(v_sp_241);
    return heff_tail(heff_dup(g_heff_2erules_2eerrorOf_get()), 2, (V[]){v_hd_2484, v_k_2485});
  }
  case TAG_False: {
    V v_t_2487 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2eelimGo_str4), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2488 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2487})});
    V v_t_2489 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2488})});
    V v_t_2490 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2484), LBL_malg), 1, (V[]){v_t_2489}));
    return heff_tail(heff_get(v_hd_2484, LBL_bind), 2, (V[]){v_t_2490, v_k_2485});
  }
  default: return heff_nomatch(v_x_2486);
  }
}
V g_heff_2erules_2eelimGo_lam11(V self, V *args) {
  V v_hd_2484 = args[0];
  V v_k_2485 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2emeta_2eblockedTy(v_a_246, heff_dup(v_hd_2484), heff_clo(g_heff_2erules_2eelimGo_lam12, 1, 3, (V[]){v_hd_2484, v_k_2485, v_sp_241})));
}
V g_heff_2erules_2eelimGo_lam14(V self, V *args) {
  V v_x_2493 = args[0];
  V v_hd_2491 = heff_env(self)[0];
  V v_k_2492 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2493)) {
  case TAG_True: {
    heff_drop(v_sp_241);
    return heff_tail(heff_dup(g_heff_2erules_2eerrorOf_get()), 2, (V[]){v_hd_2491, v_k_2492});
  }
  case TAG_False: {
    V v_t_2494 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2eelimGo_str5), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2495 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2494})});
    V v_t_2496 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2495})});
    V v_t_2497 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2491), LBL_malg), 1, (V[]){v_t_2496}));
    return heff_tail(heff_get(v_hd_2491, LBL_bind), 2, (V[]){v_t_2497, v_k_2492});
  }
  default: return heff_nomatch(v_x_2493);
  }
}
V g_heff_2erules_2eelimGo_lam13(V self, V *args) {
  V v_hd_2491 = args[0];
  V v_k_2492 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2emeta_2eblockedTy(v_a_246, heff_dup(v_hd_2491), heff_clo(g_heff_2erules_2eelimGo_lam14, 1, 3, (V[]){v_hd_2491, v_k_2492, v_sp_241})));
}
V g_heff_2erules_2eelimGo_lam16(V self, V *args) {
  V v_x_24100 = args[0];
  V v_hd_2498 = heff_env(self)[0];
  V v_k_2499 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_24100)) {
  case TAG_True: {
    heff_drop(v_sp_241);
    return heff_tail(heff_dup(g_heff_2erules_2eerrorOf_get()), 2, (V[]){v_hd_2498, v_k_2499});
  }
  case TAG_False: {
    V v_t_24101 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2eelimGo_str6), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_24102 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24101})});
    V v_t_24103 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24102})});
    V v_t_24104 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2498), LBL_malg), 1, (V[]){v_t_24103}));
    return heff_tail(heff_get(v_hd_2498, LBL_bind), 2, (V[]){v_t_24104, v_k_2499});
  }
  default: return heff_nomatch(v_x_24100);
  }
}
V g_heff_2erules_2eelimGo_lam15(V self, V *args) {
  V v_hd_2498 = args[0];
  V v_k_2499 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2emeta_2eblockedTy(v_a_246, heff_dup(v_hd_2498), heff_clo(g_heff_2erules_2eelimGo_lam16, 1, 3, (V[]){v_hd_2498, v_k_2499, v_sp_241})));
}
V g_heff_2erules_2eelimGo_lam18(V self, V *args) {
  V v_x_24108 = args[0];
  V v_hd_24106 = heff_env(self)[0];
  V v_k_24107 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_24108)) {
  case TAG_True: {
    heff_drop(v_sp_241);
    return heff_tail(heff_dup(g_heff_2erules_2eerrorOf_get()), 2, (V[]){v_hd_24106, v_k_24107});
  }
  case TAG_False: {
    V v_t_24109 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2eelimGo_str7), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_24110 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24109})});
    V v_t_24111 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24110})});
    V v_t_24112 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24106), LBL_malg), 1, (V[]){v_t_24111}));
    return heff_tail(heff_get(v_hd_24106, LBL_bind), 2, (V[]){v_t_24112, v_k_24107});
  }
  default: return heff_nomatch(v_x_24108);
  }
}
V g_heff_2erules_2eelimGo_lam17(V self, V *args) {
  V v_hd_24106 = args[0];
  V v_k_24107 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2emeta_2eblockedTy(v_a_246, heff_dup(v_hd_24106), heff_clo(g_heff_2erules_2eelimGo_lam18, 1, 3, (V[]){v_hd_24106, v_k_24107, v_sp_241})));
}
V g_heff_2erules_2eelimGo_lam20(V self, V *args) {
  V v_x_24115 = args[0];
  V v_hd_24113 = heff_env(self)[0];
  V v_k_24114 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_24115)) {
  case TAG_True: {
    heff_drop(v_sp_241);
    return heff_tail(heff_dup(g_heff_2erules_2eerrorOf_get()), 2, (V[]){v_hd_24113, v_k_24114});
  }
  case TAG_False: {
    V v_t_24116 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2eelimGo_str8), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_24117 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24116})});
    V v_t_24118 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24117})});
    V v_t_24119 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24113), LBL_malg), 1, (V[]){v_t_24118}));
    return heff_tail(heff_get(v_hd_24113, LBL_bind), 2, (V[]){v_t_24119, v_k_24114});
  }
  default: return heff_nomatch(v_x_24115);
  }
}
V g_heff_2erules_2eelimGo_lam19(V self, V *args) {
  V v_hd_24113 = args[0];
  V v_k_24114 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2emeta_2eblockedTy(v_a_246, heff_dup(v_hd_24113), heff_clo(g_heff_2erules_2eelimGo_lam20, 1, 3, (V[]){v_hd_24113, v_k_24114, v_sp_241})));
}
V g_heff_2erules_2efunctionElimC_lam3(V self, V *args);
V g_heff_2erules_2efunctionElimC_lam2(V self, V *args);
V g_heff_2erules_2efunctionElimC_lam1(V self, V *args);
V g_heff_2erules_2efunctionElimC_lam0(V self, V *args);
Clo g_heff_2erules_2efunctionElimC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2efunctionElimC_entry, 4, 0};

V g_heff_2erules_2efunctionElimC(V v_checksOnly_240, V v_sp_241, V v_callee_242, V v_arg_243) {
top: ;
  return heff_tag(TAG_MkSyn, 1, (V[]){heff_clo(g_heff_2erules_2efunctionElimC_lam0, 1, 4, (V[]){heff_dup(v_callee_242), v_sp_241, heff_dup(v_checksOnly_240), heff_dup(v_arg_243)})});
}
V g_heff_2erules_2efunctionElimC_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2efunctionElimC(a[0], a[1], a[2], a[3]); heff_drop(a[0]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
V g_heff_2erules_2efunctionElimC_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_checksOnly_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_arg_243 = heff_env(self)[2];
  V v_e_244 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2413 = ({ V a_0 = v_checksOnly_240; V a_1 = v_sp_241; V a_2 = v_arg_243; V a_3 = v_e_244; V a_4 = v_x_2412; V r_ = (g_heff_2erules_2eelimGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_checksOnly_240); heff_drop(v_arg_243); r_; });
  return heff_tail(v_t_2413, 2, (V[]){v_hd_247, v_k_248});
}
V g_heff_2erules_2efunctionElimC_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_checksOnly_240 = heff_env(self)[3];
  V v_arg_243 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_ecallee0_2410 = heff_field(v_x_249, 0);
    V v_a0_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    return (g_heff_2erules_2einsertImplicits(heff_dup(v_e_244), heff_dup(v_sp_241), v_ecallee0_2410, v_a0_2411, heff_dup(v_hd_247), heff_clo(g_heff_2erules_2efunctionElimC_lam3, 1, 6, (V[]){v_checksOnly_240, v_sp_241, v_arg_243, v_e_244, v_hd_247, v_k_248})));
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2erules_2efunctionElimC_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_checksOnly_240 = heff_env(self)[3];
  V v_arg_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2erules_2efunctionElimC_lam2, 1, 6, (V[]){v_e_244, v_sp_241, v_hd_247, v_checksOnly_240, v_arg_243, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2efunctionElimC_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_callee_242 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_checksOnly_240 = heff_env(self)[2];
  V v_arg_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246;
  switch (heff_tag_of(v_callee_242)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_callee_242, 0);
    heff_take_n(v_callee_242, 1ULL, 1);
    v_c_246 = heff_tr(heff_apply(v_f_245, 1, (V[]){heff_dup(v_e_244)}));
    break;
  }
  default: heff_nomatch(v_callee_242);
  }
  return heff_clo(g_heff_2erules_2efunctionElimC_lam1, 2, 5, (V[]){v_c_246, v_e_244, v_sp_241, v_checksOnly_240, v_arg_243});
}
V g_heff_2erules_2echeckFields_lam0(V self, V *args); static Clo g_heff_2erules_2echeckFields_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2echeckFields_lam0, 2, 0};
V g_heff_2erules_2echeckFields_lam2(V self, V *args);
V g_heff_2erules_2echeckFields_lam1(V self, V *args);
Clo g_heff_2erules_2echeckFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2echeckFields_entry, 3, 0};

V g_heff_2erules_2echeckFields(V v_e_240, V v_v_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    return ((V)&g_heff_2erules_2echeckFields_lam0_clo);
  }
  case TAG_Cons: {
    V v_x31_246 = heff_field(v_x3_242, 0);
    V v_rest_247 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_y_248 = heff_field(v_x31_246, 0);
      V v_g_249 = heff_field(v_x31_246, 1);
      V v_c_2410 = heff_get(heff_dup(v_e_240), LBL_scope);
      V v_cs_2411 = heff_rec(2, shape_168_200, (V[]){heff_get(heff_dup(v_c_2410), LBL_len), heff_get(v_c_2410, LBL_names)});
      V v_x1_2412 = (g_heff_2evalue_2eproj(heff_dup(v_v_241), heff_dup(v_y_248)));
      V v_a_2416;
      switch (heff_tag_of(v_x1_2412)) {
      case TAG_Nom: {
        V v_x_2413 = heff_field(v_x1_2412, 0);
        heff_take_n(v_x1_2412, 1ULL, 1);
        v_a_2416 = v_x_2413;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2412, 0ULL, 1);
        v_a_2416 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2415 = heff_field(v_x1_2412, 0);
        heff_take_n(v_x1_2412, 1ULL, 1);
        v_a_2416 = v_x_2415;
        break;
      }
      default: heff_nomatch(v_x1_2412);
      }
      V v_t_2417 = (g_heff_2eunify_2euTermF(heff_dup(g_co_2eplus_24s16_get()), ((V)&g_heff_2eunify_2emsEv_clo), ((V)&g_heff_2eunify_2eufEv_clo), heff_dup(g_heff_2eunify_2euk_24s391_get()), heff_get(heff_dup(v_e_240), LBL_globals), v_cs_2411, v_a_2416, heff_dup(v_g_249)));
      V v_c_2418 = heff_tr(heff_apply(((V)&g_heff_2emeta_2eliftU_clo), 1, (V[]){v_t_2417}));
      return heff_clo(g_heff_2erules_2echeckFields_lam1, 2, 4, (V[]){v_c_2418, v_e_240, v_v_241, heff_dup(v_rest_247)});
    }
    default: return heff_nomatch(v_x31_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2erules_2echeckFields_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2echeckFields(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2erules_2echeckFields_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V v_t_245 = heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_244;
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2echeckFields_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_2420 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_v_241 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    V v_err_2422 = heff_field(v_x_2421, 0);
    heff_take_n(v_x_2421, 1ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_rest_247);
    heff_drop(v_hd_2419);
    V f_ = v_k_2420;
    args[0] = heff_tag(TAG_Left, 1, (V[]){v_err_2422});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2421, 0ULL, 1);
    V v_t_2424 = ({ V a_0 = v_e_240; V a_1 = v_v_241; V a_2 = v_rest_247; V r_ = (g_heff_2erules_2echeckFields(a_0, a_1, a_2)); heff_drop(v_rest_247); r_; });
    return heff_tail(v_t_2424, 2, (V[]){v_hd_2419, v_k_2420});
  }
  default: return heff_nomatch(v_x_2421);
  }
}
V g_heff_2erules_2echeckFields_lam1(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_v_241 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo(g_heff_2erules_2echeckFields_lam2, 1, 5, (V[]){v_k_2420, v_e_240, v_v_241, v_rest_247, v_hd_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2especializedGo_lam0(V self, V *args);
V g_heff_2erules_2especializedGo_lam1(V self, V *args);
V g_heff_2erules_2especializedGo_lam2(V self, V *args);
V g_heff_2erules_2especializedGo_lam4(V self, V *args);
V g_heff_2erules_2especializedGo_lam3(V self, V *args);
Clo g_heff_2erules_2especializedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2especializedGo_entry, 10, 0};

V g_heff_2erules_2especializedGo(V v_e_240, V v_v_241, V v_a_27_242, V v_h_243, V v_sp_244, V v_u_245, V v_described_246, V v_el_247, V v_fields_248, V v_err_249) {
top: ;
  switch (heff_tag_of(v_sp_244)) {
  case TAG_SpId: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_fields_248);
    return heff_clo(g_heff_2erules_2especializedGo_lam0, 2, 1, (V[]){v_err_249});
  }
  case TAG_SpApp: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_fields_248);
    return heff_clo(g_heff_2erules_2especializedGo_lam1, 2, 1, (V[]){v_err_249});
  }
  case TAG_SpProj: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_fields_248);
    return heff_clo(g_heff_2erules_2especializedGo_lam2, 2, 1, (V[]){v_err_249});
  }
  case TAG_SpSpec: {
    V v_sq_2420 = heff_field(v_sp_244, 0);
    V v_x_2421 = heff_field(v_sp_244, 1);
    V v_f_2422 = heff_field(v_sp_244, 2);
    V v_c_2423 = heff_get(heff_dup(v_e_240), LBL_scope);
    V v_cs_2424 = heff_rec(2, shape_168_200, (V[]){heff_get(heff_dup(v_c_2423), LBL_len), heff_get(v_c_2423, LBL_names)});
    V v_t_2425 = heff_tr(heff_apply(((V)&g_heff_2eunify_2euTypeF_24s392_clo), 4, (V[]){heff_get(heff_dup(v_e_240), LBL_globals), v_cs_2424, heff_tag(TAG_VDecode, 5, (V[]){heff_dup(v_h_243), heff_dup(v_sq_2420), heff_dup(v_u_245), heff_dup(v_described_246), heff_dup(v_el_247)}), heff_dup(v_a_27_242)}));
    V v_t_2426 = heff_tr(heff_apply(((V)&g_heff_2emeta_2eliftU_clo), 1, (V[]){v_t_2425}));
    V v_c_2427 = heff_tr(heff_apply(((V)&g_heff_2emeta_2eattempt_clo), 1, (V[]){v_t_2426}));
    return heff_clo(g_heff_2erules_2especializedGo_lam3, 2, 13, (V[]){v_c_2427, heff_dup(v_x_2421), heff_dup(v_f_2422), v_fields_248, v_e_240, v_v_241, v_a_27_242, v_h_243, heff_dup(v_sq_2420), v_u_245, v_described_246, v_el_247, v_err_249});
  }
  default: return heff_nomatch(v_sp_244);
  }
}
V g_heff_2erules_2especializedGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2especializedGo(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]); heff_drop(a[4]); return r;
}
V g_heff_2erules_2especializedGo_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_err_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = v_err_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2especializedGo_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_err_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = v_err_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2especializedGo_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_err_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = v_err_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2especializedGo_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_f_2422 = heff_env(self)[1];
  V v_fields_248 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_v_241 = heff_env(self)[4];
  V v_a_27_242 = heff_env(self)[5];
  V v_h_243 = heff_env(self)[6];
  V v_sq_2420 = heff_env(self)[7];
  V v_u_245 = heff_env(self)[8];
  V v_described_246 = heff_env(self)[9];
  V v_el_247 = heff_env(self)[10];
  V v_err_249 = heff_env(self)[11];
  V v_hd_2428 = heff_env(self)[12];
  V v_k_2429 = heff_env(self)[13];
  heff_clo_take(self, 14);
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Left: {
    heff_take_n(v_x_2430, 0ULL, 1);
    V v_t_2432 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2421, v_f_2422}), v_fields_248});
    V v_t_2433 = ({ V a_0 = v_e_240; V a_1 = v_v_241; V a_2 = v_a_27_242; V a_3 = v_h_243; V a_4 = v_sq_2420; V a_5 = v_u_245; V a_6 = v_described_246; V a_7 = v_el_247; V a_8 = v_t_2432; V a_9 = v_err_249; V r_ = (g_heff_2erules_2especializedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_sq_2420); r_; });
    return heff_tail(v_t_2433, 2, (V[]){v_hd_2428, v_k_2429});
  }
  case TAG_Right: {
    heff_take_n(v_x_2430, 0ULL, 1);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_sq_2420);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_err_249);
    V v_t_2435 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2421, v_f_2422}), v_fields_248});
    V v_t_2436 = ({ V a_0 = v_e_240; V a_1 = v_v_241; V a_2 = v_t_2435; V r_ = (g_heff_2erules_2echeckFields(a_0, a_1, a_2)); heff_drop_tag(v_t_2435, 2); r_; });
    return heff_tail(v_t_2436, 2, (V[]){v_hd_2428, v_k_2429});
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2erules_2especializedGo_lam3(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_c_2427 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_f_2422 = heff_env(self)[2];
  V v_fields_248 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_v_241 = heff_env(self)[5];
  V v_a_27_242 = heff_env(self)[6];
  V v_h_243 = heff_env(self)[7];
  V v_sq_2420 = heff_env(self)[8];
  V v_u_245 = heff_env(self)[9];
  V v_described_246 = heff_env(self)[10];
  V v_el_247 = heff_env(self)[11];
  V v_err_249 = heff_env(self)[12];
  heff_clo_take(self, 13);
  V f_ = v_c_2427;
  args[0] = heff_dup(v_hd_2428);
  args[1] = heff_clo(g_heff_2erules_2especializedGo_lam4, 1, 14, (V[]){v_x_2421, v_f_2422, v_fields_248, v_e_240, v_v_241, v_a_27_242, v_h_243, v_sq_2420, v_u_245, v_described_246, v_el_247, v_err_249, v_hd_2428, v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2especialized_lam0(V self, V *args);
V g_heff_2erules_2especialized_lam1(V self, V *args);
V g_heff_2erules_2especialized_lam2(V self, V *args);
V g_heff_2erules_2especialized_lam3(V self, V *args);
V g_heff_2erules_2especialized_lam4(V self, V *args);
V g_heff_2erules_2especialized_lam5(V self, V *args);
V g_heff_2erules_2especialized_lam6(V self, V *args);
V g_heff_2erules_2especialized_lam7(V self, V *args);
Clo g_heff_2erules_2especialized_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2especialized_entry, 5, 0};

V g_heff_2erules_2especialized(V v_e_240, V v_v_241, V v_a_242, V v_a_27_243, V v_err_244) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo(g_heff_2erules_2especialized_lam0, 2, 1, (V[]){v_err_244});
  }
  case TAG_VDecode: {
    V v_h_248 = heff_field(v_a_242, 0);
    V v_sp_249 = heff_field(v_a_242, 1);
    V v_u_2410 = heff_field(v_a_242, 2);
    V v_described_2411 = heff_field(v_a_242, 3);
    V v_el_2412 = heff_field(v_a_242, 4);
    return (g_heff_2erules_2especializedGo(v_e_240, v_v_241, v_a_27_243, heff_dup(v_h_248), v_sp_249, heff_dup(v_u_2410), heff_dup(v_described_2411), heff_dup(v_el_2412), NTAG(TAG_Nil), v_err_244));
  }
  case TAG_VFunction: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo(g_heff_2erules_2especialized_lam1, 2, 1, (V[]){v_err_244});
  }
  case TAG_VRecord: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo(g_heff_2erules_2especialized_lam2, 2, 1, (V[]){v_err_244});
  }
  case TAG_VSum: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo(g_heff_2erules_2especialized_lam3, 2, 1, (V[]){v_err_244});
  }
  case TAG_VPrimInt: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo(g_heff_2erules_2especialized_lam4, 2, 1, (V[]){v_err_244});
  }
  case TAG_VPrimFloat: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo(g_heff_2erules_2especialized_lam5, 2, 1, (V[]){v_err_244});
  }
  case TAG_VPrimString: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo(g_heff_2erules_2especialized_lam6, 2, 1, (V[]){v_err_244});
  }
  case TAG_VPrimArray: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo(g_heff_2erules_2especialized_lam7, 2, 1, (V[]){v_err_244});
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2erules_2especialized_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2especialized(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2erules_2especialized_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2especialized_lam1(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2especialized_lam2(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2423);
  V f_ = v_k_2424;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2especialized_lam3(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2especialized_lam4(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2especialized_lam5(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2especialized_lam6(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2432);
  V f_ = v_k_2433;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2especialized_lam7(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2435);
  V f_ = v_k_2436;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2eapplyGo_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {117, 110, 105, 102, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2erules_2eapplyGo_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 32, 32, 70, 65, 73, 76, 83}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2eapplyGo_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 32, 32, 111, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2erules_2eapplyGo_str3 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 32, 61, 63, 61, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2erules_2eapplyGo_str4 = {{0x80000000u, K_STR, 0}, 14, 14, {101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2erules_2eapplyGo_str5 = {{0x80000000u, K_STR, 0}, 15, 15, {44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 121, 112, 101, 32}};
V g_heff_2erules_2eapplyGo_lam2(V self, V *args);
V g_heff_2erules_2eapplyGo_lam4(V self, V *args); static Clo g_heff_2erules_2eapplyGo_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eapplyGo_lam4, 1, 0};
V g_heff_2erules_2eapplyGo_lam6(V self, V *args);
V g_heff_2erules_2eapplyGo_lam9(V self, V *args);
V g_heff_2erules_2eapplyGo_lam8(V self, V *args);
V g_heff_2erules_2eapplyGo_lam10(V self, V *args);
V g_heff_2erules_2eapplyGo_lam7(V self, V *args);
V g_heff_2erules_2eapplyGo_lam5(V self, V *args);
V g_heff_2erules_2eapplyGo_lam3(V self, V *args);
V g_heff_2erules_2eapplyGo_lam1(V self, V *args);
V g_heff_2erules_2eapplyGo_lam0(V self, V *args);
Clo g_heff_2erules_2eapplyGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eapplyGo_entry, 4, 0};

V g_heff_2erules_2eapplyGo(V v_sp_240, V v_e_241, V v_a_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_m_244 = heff_field(v_x4_243, 0);
    V v_a_27_245 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_c_246 = heff_get(heff_dup(v_e_241), LBL_scope);
    V v_cs_247 = heff_rec(2, shape_168_200, (V[]){heff_get(heff_dup(v_c_246), LBL_len), heff_get(v_c_246, LBL_names)});
    V v_t_248 = heff_tr(heff_apply(((V)&g_heff_2eunify_2euTypeF_24s392_clo), 4, (V[]){heff_get(heff_dup(v_e_241), LBL_globals), v_cs_247, heff_dup(v_a_242), heff_dup(v_a_27_245)}));
    V v_t_249 = heff_tr(heff_apply(((V)&g_heff_2emeta_2eliftU_clo), 1, (V[]){v_t_248}));
    V v_c_2410 = heff_tr(heff_apply(((V)&g_heff_2emeta_2eattempt_clo), 1, (V[]){v_t_249}));
    return heff_clo(g_heff_2erules_2eapplyGo_lam0, 2, 6, (V[]){v_c_2410, v_m_244, v_e_241, v_a_242, v_a_27_245, v_sp_240});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2erules_2eapplyGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2eapplyGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2erules_2eapplyGo_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_x_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = heff_tag(TAG_Right, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2eapplyGo_lam4(V self, V *args) {
  V v_c_2425 = args[0];
  return heff_get(v_c_2425, LBL_metas);
}
V g_heff_2erules_2eapplyGo_lam6(V self, V *args) {
  V v_u_2430 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_245 = heff_env(self)[3];
  V v_x_2424 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_2430);
  V v_t_2431 = (g_heff_2erules_2einstShown(heff_dup(v_e_241), v_x_2429, v_a_242));
  V v_t_2432 = ({ V a_0 = v_e_241; V a_1 = v_x_2429; V a_2 = v_a_27_245; V r_ = (g_heff_2erules_2einstShown(a_0, a_1, a_2)); heff_drop(v_x_2429); r_; });
  V v_t_2435;
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    heff_take_n(v_x_2424, 0ULL, 1);
    v_t_2435 = ((V)&g_heff_2erules_2eapplyGo_str1);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2424, 0ULL, 1);
    v_t_2435 = ((V)&g_heff_2erules_2eapplyGo_str2);
    break;
  }
  default: heff_nomatch(v_x_2424);
  }
  return heff_strAppend(v_t_2431, heff_strAppend(((V)&g_heff_2erules_2eapplyGo_str3), heff_strAppend(v_t_2432, v_t_2435)));
}
V g_heff_2erules_2eapplyGo_lam9(V self, V *args) {
  V v_x_2441 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_err_2439 = heff_env(self)[1];
  V v_x_2440 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_note_2442 = ({ V a_0 = heff_get(v_e_241, LBL_globals); V a_1 = v_err_2439; V r_ = (g_heff_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2439); r_; });
  V v_t_2443 = heff_strAppend(((V)&g_heff_2erules_2eapplyGo_str4), heff_strAppend(v_x_2440, heff_strAppend(((V)&g_heff_2erules_2eapplyGo_str5), v_x_2441)));
  V v_t_2444 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_2443, v_sp_240, heff_tag(TAG_Just, 1, (V[]){v_note_2442})});
  V v_t_2445 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2411), LBL_malg), 1, (V[]){v_t_2446}));
  return heff_tail(heff_get(v_hd_2411, LBL_bind), 2, (V[]){v_t_2447, v_k_2412});
}
V g_heff_2erules_2eapplyGo_lam8(V self, V *args) {
  V v_x_2440 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_a_27_245 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_err_2439 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2erules_2etyStrZ(heff_dup(v_e_241), v_a_27_245, heff_dup(v_hd_2411), heff_clo(g_heff_2erules_2eapplyGo_lam9, 1, 6, (V[]){v_e_241, v_err_2439, v_x_2440, v_sp_240, v_hd_2411, v_k_2412})));
}
V g_heff_2erules_2eapplyGo_lam10(V self, V *args) {
  V v_x_2452 = args[0];
  V v_k_2412 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2452);
  V f_ = v_k_2412;
  args[0] = v_m_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2eapplyGo_lam7(V self, V *args) {
  V v_x_2438 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_a_27_245 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  V v_m_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2438);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    V v_err_2439 = heff_field(v_x_2424, 0);
    heff_take_n(v_x_2424, 1ULL, 1);
    heff_drop(v_m_244);
    return (g_heff_2erules_2etyStrZ(heff_dup(v_e_241), v_a_242, heff_dup(v_hd_2411), heff_clo(g_heff_2erules_2eapplyGo_lam8, 1, 6, (V[]){v_e_241, v_a_27_245, v_hd_2411, v_err_2439, v_sp_240, v_k_2412})));
  }
  case TAG_Right: {
    V v_ru_24x_2424_24Right = heff_take_reuse_n(v_x_2424, 0ULL, 1);
    heff_drop(v_e_241);
    heff_drop(v_a_242);
    heff_drop(v_a_27_245);
    heff_drop(v_sp_240);
    V v_t_2449 = heff_tag(TAG_Wake, 2, (V[]){NTAG(TAG_False), NTAG(TAG_MkUnit)});
    V v_t_2450 = heff_tag_at(v_ru_24x_2424_24Right, TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2411), LBL_malg), 1, (V[]){v_t_2450}));
    return heff_tail(heff_get(v_hd_2411, LBL_bind), 2, (V[]){v_t_2451, heff_clo(g_heff_2erules_2eapplyGo_lam10, 1, 2, (V[]){v_k_2412, v_m_244})});
  }
  default: return heff_nomatch(v_x_2424);
  }
}
V g_heff_2erules_2eapplyGo_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_245 = heff_env(self)[3];
  V v_x_2424 = heff_env(self)[4];
  V v_hd_2411 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  V v_m_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2436 = heff_tag(TAG_Trace, 2, (V[]){heff_rec(3, shape_314_154_337, (V[]){heff_dup(v_sp_240), ((V)&g_heff_2erules_2eapplyGo_str0), heff_clo(g_heff_2erules_2eapplyGo_lam6, 1, 5, (V[]){heff_dup(v_e_241), v_x_2429, heff_dup(v_a_242), heff_dup(v_a_27_245), heff_dup(v_x_2424)})}), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2411), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2436})}));
  return heff_tail(heff_get(heff_dup(v_hd_2411), LBL_bind), 2, (V[]){v_t_2437, heff_clo(g_heff_2erules_2eapplyGo_lam7, 1, 8, (V[]){v_x_2424, v_e_241, v_a_242, v_hd_2411, v_a_27_245, v_sp_240, v_k_2412, v_m_244})});
}
V g_heff_2erules_2eapplyGo_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_2411 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  V v_a_27_245 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  V v_m_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2426 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2erules_2eapplyGo_lam4_clo)})});
  V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2411), LBL_malg), 1, (V[]){v_t_2427}));
  return heff_tail(heff_get(heff_dup(v_hd_2411), LBL_bind), 2, (V[]){v_t_2428, heff_clo(g_heff_2erules_2eapplyGo_lam5, 1, 8, (V[]){v_sp_240, v_e_241, v_a_242, v_a_27_245, v_x_2424, v_hd_2411, v_k_2412, v_m_244})});
}
V g_heff_2erules_2eapplyGo_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_245 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2423;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Left = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    V v_x1_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_m_244), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2419;
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_Nom: {
      V v_x_2416 = heff_field(v_x1_2415, 0);
      heff_take_n(v_x1_2415, 1ULL, 1);
      v_t_2419 = v_x_2416;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2415, 0ULL, 1);
      v_t_2419 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2418 = heff_field(v_x1_2415, 0);
      heff_take_n(v_x1_2415, 1ULL, 1);
      v_t_2419 = v_x_2418;
      break;
    }
    default: heff_nomatch(v_x1_2415);
    }
    v_c_2423 = (g_heff_2erules_2especialized(heff_dup(v_e_241), v_t_2419, v_a_242, heff_dup(v_a_27_245), heff_tag_at(v_ru_24x_2413_24Left, TAG_Left, 1, (V[]){v_err_2414})));
    break;
  }
  case TAG_Right: {
    V v_x_2420 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    v_c_2423 = heff_clo(g_heff_2erules_2eapplyGo_lam2, 2, 1, (V[]){v_x_2420});
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  return heff_tail(v_c_2423, 2, (V[]){heff_dup(v_hd_2411), heff_clo(g_heff_2erules_2eapplyGo_lam3, 1, 7, (V[]){v_hd_2411, v_sp_240, v_e_241, v_a_242, v_a_27_245, v_k_2412, v_m_244})});
}
V g_heff_2erules_2eapplyGo_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  V v_a_27_245 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo(g_heff_2erules_2eapplyGo_lam1, 1, 7, (V[]){v_m_244, v_e_241, v_a_242, v_a_27_245, v_hd_2411, v_sp_240, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2eapply_lam3(V self, V *args);
V g_heff_2erules_2eapply_lam5(V self, V *args);
V g_heff_2erules_2eapply_lam6(V self, V *args);
V g_heff_2erules_2eapply_lam4(V self, V *args);
V g_heff_2erules_2eapply_lam2(V self, V *args);
V g_heff_2erules_2eapply_lam1(V self, V *args);
V g_heff_2erules_2eapply_lam0(V self, V *args);
Clo g_heff_2erules_2eapply_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eapply_entry, 2, 0};

V g_heff_2erules_2eapply(V v_sp_240, V v_syn_241) {
top: ;
  return heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2erules_2eapply_lam0, 2, 2, (V[]){heff_dup(v_syn_241), v_sp_240})});
}
V g_heff_2erules_2eapply_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2eapply(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2erules_2eapply_lam3(V self, V *args) {
  V v_c_2411 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_2411, LBL_metas); V a_1 = v_a0_243; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2erules_2eapply_lam5(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_m0_249 = heff_env(self)[0];
  V v_a1_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_m0_249, v_a1_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2eapply_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_x_2415 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2433 = (g_heff_2erules_2eapplyGo(v_sp_240, v_e_242, v_x_2415, v_x_2432));
  return heff_tail(v_t_2433, 2, (V[]){v_hd_246, v_k_247});
}
V g_heff_2erules_2eapply_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_m0_249 = heff_env(self)[0];
  V v_a1_2410 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2416 = (g_heff_2evalue_2ebehavior(heff_dup(v_x_2415)));
  V v_t_2428;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeFunction: {
    V v_implicit_2421 = heff_field(v_t_2416, 3);
    heff_take_n(v_t_2416, 8ULL, 4);
    V v_x1_2422;
    switch (heff_tag_of(v_implicit_2421)) {
    case TAG_Expl: {
      v_x1_2422 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_x1_2422 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_x1_2422 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2421);
    }
    switch (heff_tag_of(v_x1_2422)) {
    case TAG_True: {
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2428 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_2422);
    }
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2416, 0ULL, 3);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeInt: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeFloat: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeString: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_NoRules: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V v_c_2431;
  switch (heff_tag_of(v_t_2428)) {
  case TAG_True: {
    v_c_2431 = heff_clo(g_heff_2erules_2eapply_lam5, 2, 2, (V[]){v_m0_249, v_a1_2410});
    break;
  }
  case TAG_False: {
    v_c_2431 = heff_tr(heff_apply(((V)&g_heff_2erules_2einsertImplicits_clo), 4, (V[]){heff_dup(v_e_242), heff_dup(v_sp_240), v_m0_249, v_a1_2410}));
    break;
  }
  default: heff_nomatch(v_t_2428);
  }
  return heff_tail(v_c_2431, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2erules_2eapply_lam6, 1, 5, (V[]){v_sp_240, v_e_242, v_x_2415, v_hd_246, v_k_247})});
}
V g_heff_2erules_2eapply_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_a0_243 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_248)) {
  case TAG_MkPair: {
    V v_m0_249 = heff_field(v_x_248, 0);
    V v_a1_2410 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 2);
    V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2eapply_lam3, 1, 1, (V[]){v_a0_243})})});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2413}));
    return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2erules_2eapply_lam4, 1, 6, (V[]){v_m0_249, v_a1_2410, v_e_242, v_sp_240, v_hd_246, v_k_247})});
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2erules_2eapply_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_a0_243 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo(g_heff_2erules_2eapply_lam2, 1, 5, (V[]){v_a0_243, v_hd_246, v_e_242, v_sp_240, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2eapply_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a0_243 = args[1];
  V v_syn_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245;
  switch (heff_tag_of(v_syn_241)) {
  case TAG_MkSyn: {
    V v_f_244 = heff_field(v_syn_241, 0);
    heff_take_n(v_syn_241, 1ULL, 1);
    v_c_245 = heff_tr(heff_apply(v_f_244, 1, (V[]){heff_dup(v_e_242)}));
    break;
  }
  default: heff_nomatch(v_syn_241);
  }
  return heff_clo(g_heff_2erules_2eapply_lam1, 2, 4, (V[]){v_c_245, v_a0_243, v_e_242, v_sp_240});
}
V g_heff_2erules_2eannot_lam3(V self, V *args);
V g_heff_2erules_2eannot_lam2(V self, V *args);
V g_heff_2erules_2eannot_lam1(V self, V *args);
V g_heff_2erules_2eannot_lam0(V self, V *args);
Clo g_heff_2erules_2eannot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eannot_entry, 2, 0};

V g_heff_2erules_2eannot(V v_typ_240, V v_chk_241) {
top: ;
  return heff_tag(TAG_MkSyn, 1, (V[]){heff_clo(g_heff_2erules_2eannot_lam0, 1, 2, (V[]){heff_dup(v_typ_240), heff_dup(v_chk_241)})});
}
V g_heff_2erules_2eannot_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2eannot(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2erules_2eannot_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2417 = heff_tr(heff_apply(heff_get(v_x_248, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2421;
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_Nom: {
    V v_x_2418 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    v_t_2421 = v_x_2418;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    v_t_2421 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2420 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    v_t_2421 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_x1_2417);
  }
  V v_x_2422 = heff_tag(TAG_MkPair, 2, (V[]){v_x_2416, v_t_2421});
  V f_ = v_k_247;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2eannot_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_chk_241 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_249 = heff_tr(heff_apply(heff_get(heff_dup(v_x_248), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_a_2413;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nom: {
    V v_x_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_a_2413 = v_x_2410;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_a_2413 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2412 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_a_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  V v_c_2415;
  switch (heff_tag_of(v_chk_241)) {
  case TAG_MkChk: {
    V v_f_2414 = heff_field(v_chk_241, 0);
    heff_take_n(v_chk_241, 1ULL, 1);
    v_c_2415 = heff_tr(heff_apply(v_f_2414, 2, (V[]){v_e_242, v_a_2413}));
    break;
  }
  default: heff_nomatch(v_chk_241);
  }
  return heff_tail(v_c_2415, 2, (V[]){v_hd_246, heff_clo(g_heff_2erules_2eannot_lam3, 1, 2, (V[]){v_x_248, v_k_247})});
}
V g_heff_2erules_2eannot_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_chk_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo(g_heff_2erules_2eannot_lam2, 1, 4, (V[]){v_chk_241, v_e_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2eannot_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_typ_240 = heff_env(self)[0];
  V v_chk_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245;
  switch (heff_tag_of(v_typ_240)) {
  case TAG_MkTyp: {
    V v_f_243 = heff_field(v_typ_240, 0);
    heff_take_n(v_typ_240, 1ULL, 1);
    V v_t_244 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){heff_get(heff_dup(v_e_242), LBL_scope), heff_get(heff_dup(v_e_242), LBL_globals), NTAG(TAG_ForNominative), heff_get(heff_dup(v_e_242), LBL_lams), heff_get(heff_dup(v_e_242), LBL_self), heff_get(heff_dup(v_e_242), LBL_insts)});
    v_c_245 = heff_tr(heff_apply(v_f_243, 1, (V[]){v_t_244}));
    break;
  }
  default: heff_nomatch(v_typ_240);
  }
  return heff_clo(g_heff_2erules_2eannot_lam1, 2, 3, (V[]){v_c_245, v_chk_241, v_e_242});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2erules_2erecChk_str0 = {{0x80000000u, K_STR, 0}, 46, 46, {99, 97, 110, 32, 111, 110, 108, 121, 32, 117, 115, 101, 32, 114, 101, 99, 32, 119, 104, 101, 110, 32, 99, 104, 101, 99, 107, 105, 110, 103, 32, 97, 116, 32, 97, 32, 115, 109, 97, 108, 108, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[97]; } g_heff_2erules_2erecChk_str1 = {{0x80000000u, K_STR, 0}, 97, 97, {116, 104, 101, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 119, 111, 117, 108, 100, 32, 110, 101, 101, 100, 32, 105, 116, 115, 101, 108, 102, 32, 119, 104, 105, 108, 101, 32, 105, 116, 32, 105, 115, 32, 98, 101, 105, 110, 103, 32, 99, 111, 109, 112, 117, 116, 101, 100, 58, 32, 112, 117, 116, 32, 116, 104, 101, 32, 114, 101, 99, 117, 114, 115, 105, 118, 101, 32, 117, 115, 101, 32, 117, 110, 100, 101, 114, 32, 97, 32, 108, 97, 109, 98, 100, 97}};
V g_heff_2erules_2erecChk_lam1(V self, V *args);
V g_heff_2erules_2erecChk_lam2(V self, V *args);
V g_heff_2erules_2erecChk_lam5(V self, V *args); static Clo g_heff_2erules_2erecChk_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erecChk_lam5, 1, 0};
V g_heff_2erules_2erecChk_lam4(V self, V *args);
V g_heff_2erules_2erecChk_lam3(V self, V *args);
V g_heff_2erules_2erecChk_lam0(V self, V *args);
Clo g_heff_2erules_2erecChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erecChk_entry, 2, 0};

V g_heff_2erules_2erecChk(V v_sp_240, V v_c_241) {
top: ;
  return heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2erules_2erecChk_lam0, 2, 2, (V[]){v_sp_240, heff_dup(v_c_241)})});
}
V g_heff_2erules_2erecChk_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2erecChk(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2erules_2erecChk_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(320LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecChk_str0), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2411}));
  V f_ = heff_get(v_hd_247, LBL_bind);
  args[0] = v_t_2412;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2erecChk_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k2_2415 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(331LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecChk_str1), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2417 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2418}));
  V f_ = heff_get(v_hd_2414, LBL_bind);
  args[0] = v_t_2419;
  args[1] = v_k2_2415;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2erecChk_lam5(V self, V *args) {
  V v_u_2430 = args[0];
  heff_drop(v_u_2430);
  return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2erules_2erecChk_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = heff_tag(TAG_SRec, 1, (V[]){heff_get(v_x_2428, LBL_stx)});
  V f_ = v_k_2427;
  args[0] = heff_rec(2, shape_326_366, (V[]){v_t_2429, ((V)&g_heff_2erules_2erecChk_lam5_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2erecChk_lam3(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_c_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2425;
  args[0] = v_hd_2426;
  args[1] = heff_clo(g_heff_2erules_2erecChk_lam4, 1, 1, (V[]){v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2erecChk_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a_243 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_244 = (g_heff_2evalue_2elevelOf(v_a_243));
  V v_x1_245;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Small: {
    v_x1_245 = NTAG(TAG_True);
    break;
  }
  case TAG_Large: {
    v_x1_245 = NTAG(TAG_False);
    break;
  }
  case TAG_TopL: {
    v_x1_245 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  V v_t_246;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_True: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_246 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_e_242);
    heff_drop(v_a_243);
    heff_drop(v_c_241);
    return heff_clo(g_heff_2erules_2erecChk_lam1, 2, 1, (V[]){v_sp_240});
  }
  case TAG_False: {
    V v_t_2413 = heff_intEq(heff_get(heff_dup(v_e_242), LBL_lams), MK_INT(0LL));
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      heff_drop(v_e_242);
      heff_drop(v_a_243);
      heff_drop(v_c_241);
      return heff_clo(g_heff_2erules_2erecChk_lam2, 2, 1, (V[]){v_sp_240});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_sd_2420 = heff_get(heff_dup(v_e_242), LBL_scope);
      V v_t_2421 = heff_tag(TAG_CUndelay, 1, (V[]){heff_get(heff_dup(v_sd_2420), LBL_ctx)});
      V v_sc_2422 = heff_rec(4, shape_168_200_179_53, (V[]){heff_get(heff_dup(v_sd_2420), LBL_len), heff_get(heff_dup(v_sd_2420), LBL_names), heff_get(v_sd_2420, LBL_locals), v_t_2421});
      V v_e_2423 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){v_sc_2422, heff_get(heff_dup(v_e_242), LBL_globals), heff_get(heff_dup(v_e_242), LBL_elabFor), heff_get(heff_dup(v_e_242), LBL_lams), heff_get(heff_dup(v_e_242), LBL_self), heff_get(v_e_242, LBL_insts)});
      V v_c_2425;
      switch (heff_tag_of(v_c_241)) {
      case TAG_MkChk: {
        V v_f_2424 = heff_field(v_c_241, 0);
        heff_take_n(v_c_241, 1ULL, 1);
        v_c_2425 = heff_tr(heff_apply(v_f_2424, 2, (V[]){v_e_2423, v_a_243}));
        break;
      }
      default: heff_nomatch(v_c_241);
      }
      return heff_clo(g_heff_2erules_2erecChk_lam3, 2, 1, (V[]){v_c_2425});
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2erules_2evarGo_lam0(V self, V *args);
Clo g_heff_2erules_2evarGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2evarGo_entry, 6, 0};

V g_heff_2erules_2evarGo(V v_x_240, V v_names_241, V v_ctx_242, V v_locals_243, V v_n_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_ctx_242)) {
  case TAG_CEmpty: {
    heff_drop(v_x_240);
    heff_drop(v_names_241);
    heff_drop(v_locals_243);
    heff_drop(v_n_244);
    heff_drop(v_i_245);
    return heff_tag(TAG_Left, 1, (V[]){NTAG(TAG_NotInScope)});
  }
  case TAG_CBind: {
    V v_c_27_246 = heff_field(v_ctx_242, 0);
    V v_it2_247 = heff_field(v_ctx_242, 1);
    V v_a_248 = heff_field(v_ctx_242, 2);
    switch (heff_tag_of(v_it2_247)) {
    case TAG_BDelayedBy: {
      V v_k_249 = heff_field(v_it2_247, 0);
      switch (heff_tag_of(v_names_241)) {
      case TAG_Nil: {
        heff_drop(v_x_240);
        heff_drop(v_locals_243);
        heff_drop(v_n_244);
        heff_drop(v_i_245);
        return heff_tag(TAG_Left, 1, (V[]){NTAG(TAG_NotInScope)});
      }
      case TAG_Cons: {
        V v_x_27_2410 = heff_field(v_names_241, 0);
        V v_xs_2411 = heff_field(v_names_241, 1);
        V v_ru_24names_241_24Cons = heff_take_reuse_n(v_names_241, 3ULL, 2);
        switch (heff_tag_of(v_locals_243)) {
        case TAG_LNil: {
          heff_drop(v_x_240);
          heff_drop(v_n_244);
          heff_drop(v_i_245);
          heff_drop(v_x_27_2410);
          heff_drop(v_xs_2411);
          heff_drop_cell(v_ru_24names_241_24Cons, 2);
          return heff_tag(TAG_Left, 1, (V[]){NTAG(TAG_NotInScope)});
        }
        case TAG_LSnoc: {
          V v_vs_2412 = heff_field(v_locals_243, 0);
          V v_v_2413 = heff_field(v_locals_243, 1);
          heff_take_n(v_locals_243, 3ULL, 2);
          V v_t_2414 = heff_strEq(heff_dup(v_x_240), v_x_27_2410);
          switch (heff_tag_of(v_t_2414)) {
          case TAG_True: {
            heff_drop(v_x_240);
            heff_drop(v_xs_2411);
            heff_drop(v_vs_2412);
            V v_t_2415 = heff_intLe(heff_dup(v_k_249), v_n_244);
            switch (heff_tag_of(v_t_2415)) {
            case TAG_True: {
              V v_t_2418 = heff_rec(2, shape_326_366, (V[]){heff_tag(TAG_SLocal, 1, (V[]){v_i_245}), heff_clo(g_heff_2erules_2evarGo_lam0, 1, 1, (V[]){v_v_2413})});
              return heff_tag(TAG_Right, 1, (V[]){heff_tag_at(v_ru_24names_241_24Cons, TAG_MkPair, 2, (V[]){v_t_2418, heff_dup(v_a_248)})});
            }
            case TAG_False: {
              heff_drop(v_i_245);
              heff_drop_cell(v_ru_24names_241_24Cons, 2);
              heff_drop(v_v_2413);
              return heff_tag(TAG_Left, 1, (V[]){NTAG(TAG_Delayed2)});
            }
            default: return heff_nomatch(v_t_2415);
            }
          }
          case TAG_False: {
            heff_drop_cell(v_ru_24names_241_24Cons, 2);
            heff_drop(v_v_2413);
            V t_0 = v_x_240;
            V t_1 = v_xs_2411;
            V t_2 = v_c_27_246;
            V t_3 = v_vs_2412;
            V t_4 = v_n_244;
            V t_5 = heff_intAdd(v_i_245, MK_INT(1LL));
            v_x_240 = t_0;
            v_names_241 = t_1;
            v_ctx_242 = t_2;
            v_locals_243 = t_3;
            v_n_244 = t_4;
            v_i_245 = t_5;
            goto top;
          }
          default: return heff_nomatch(v_t_2414);
          }
        }
        case TAG_LChunkSnoc: {
          heff_take_n(v_locals_243, 0ULL, 2);
          heff_drop(v_x_240);
          heff_drop(v_n_244);
          heff_drop(v_i_245);
          heff_drop(v_x_27_2410);
          heff_drop(v_xs_2411);
          heff_drop_cell(v_ru_24names_241_24Cons, 2);
          return heff_tag(TAG_Left, 1, (V[]){NTAG(TAG_NotInScope)});
        }
        default: return heff_nomatch(v_locals_243);
        }
      }
      default: return heff_nomatch(v_names_241);
      }
    }
    default: return heff_nomatch(v_it2_247);
    }
  }
  case TAG_CUndelay: {
    V v_c_27_2421 = heff_field(v_ctx_242, 0);
    V t_0 = v_x_240;
    V t_1 = v_names_241;
    V t_2 = v_c_27_2421;
    V t_3 = v_locals_243;
    V t_4 = heff_intAdd(v_n_244, MK_INT(1LL));
    V t_5 = v_i_245;
    v_x_240 = t_0;
    v_names_241 = t_1;
    v_ctx_242 = t_2;
    v_locals_243 = t_3;
    v_n_244 = t_4;
    v_i_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_ctx_242);
  }
}
V g_heff_2erules_2evarGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2evarGo(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[2]); return r;
}
V g_heff_2erules_2evarGo_lam0(V self, V *args) {
  V v_u_2416 = args[0];
  V v_v_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_tr(heff_apply(v_v_2413, 1, (V[]){v_u_2416}));
  return heff_tag(TAG_Nom, 1, (V[]){v_t_2417});
}
V g_heff_2erules_2eautoRec_lam0(V self, V *args);
Clo g_heff_2erules_2eautoRec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eautoRec_entry, 3, 0};

V g_heff_2erules_2eautoRec(V v_sp_240, V v_x_241, V v_c_242) {
top: ;
  return heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2erules_2eautoRec_lam0, 2, 3, (V[]){v_x_241, heff_dup(v_c_242), v_sp_240})});
}
V g_heff_2erules_2eautoRec_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2eautoRec(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2erules_2eautoRec_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a_244 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_245 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_names);
  V v_t_246 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_ctx);
  V v_t_247 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_locals);
  V v_it_248 = ({ V a_0 = v_x_241; V a_1 = v_t_245; V a_2 = v_t_246; V a_3 = v_t_247; V a_4 = MK_INT(0LL); V a_5 = MK_INT(0LL); V r_ = (g_heff_2erules_2evarGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_246); r_; });
  switch (heff_tag_of(v_it_248)) {
  case TAG_Left: {
    V v_it1_249 = heff_field(v_it_248, 0);
    heff_take_n(v_it_248, 1ULL, 1);
    switch (heff_tag_of(v_it1_249)) {
    case TAG_NotInScope: {
      heff_drop(v_sp_240);
      switch (heff_tag_of(v_c_242)) {
      case TAG_MkChk: {
        V v_f_2410 = heff_field(v_c_242, 0);
        heff_take_n(v_c_242, 1ULL, 1);
        V f_ = v_f_2410;
        args[0] = v_e_243;
        args[1] = v_a_244;
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
      default: return heff_nomatch(v_c_242);
      }
    }
    case TAG_Delayed2: {
      V v_x1_2411 = (g_heff_2evalue_2elevelOf(v_a_244));
      switch (heff_tag_of(v_x1_2411)) {
      case TAG_Small: {
        V v_t_2412 = ({ V a_0 = v_sp_240; V a_1 = v_c_242; V r_ = (g_heff_2erules_2erecChk(a_0, a_1)); heff_drop(v_c_242); r_; });
        switch (heff_tag_of(v_t_2412)) {
        case TAG_MkChk: {
          V v_f_2413 = heff_field(v_t_2412, 0);
          heff_take_n(v_t_2412, 1ULL, 1);
          V f_ = v_f_2413;
          args[0] = v_e_243;
          args[1] = v_a_244;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        default: return heff_nomatch(v_t_2412);
        }
      }
      case TAG_Large: {
        heff_drop(v_sp_240);
        switch (heff_tag_of(v_c_242)) {
        case TAG_MkChk: {
          V v_f_2414 = heff_field(v_c_242, 0);
          heff_take_n(v_c_242, 1ULL, 1);
          V f_ = v_f_2414;
          args[0] = v_e_243;
          args[1] = v_a_244;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        default: return heff_nomatch(v_c_242);
        }
      }
      case TAG_TopL: {
        heff_drop(v_sp_240);
        switch (heff_tag_of(v_c_242)) {
        case TAG_MkChk: {
          V v_f_2415 = heff_field(v_c_242, 0);
          heff_take_n(v_c_242, 1ULL, 1);
          V f_ = v_f_2415;
          args[0] = v_e_243;
          args[1] = v_a_244;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        default: return heff_nomatch(v_c_242);
        }
      }
      default: return heff_nomatch(v_x1_2411);
      }
    }
    default: return heff_nomatch(v_it1_249);
    }
  }
  case TAG_Right: {
    heff_take_n(v_it_248, 0ULL, 1);
    heff_drop(v_sp_240);
    switch (heff_tag_of(v_c_242)) {
    case TAG_MkChk: {
      V v_f_2417 = heff_field(v_c_242, 0);
      heff_take_n(v_c_242, 1ULL, 1);
      V f_ = v_f_2417;
      args[0] = v_e_243;
      args[1] = v_a_244;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_c_242);
    }
  }
  default: return heff_nomatch(v_it_248);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[50]; } g_heff_2erules_2eabandonChk_str0 = {{0x80000000u, K_STR, 0}, 50, 50, {99, 97, 110, 32, 111, 110, 108, 121, 32, 117, 115, 101, 32, 97, 98, 97, 110, 100, 111, 110, 32, 119, 104, 101, 110, 32, 99, 104, 101, 99, 107, 105, 110, 103, 32, 97, 116, 32, 97, 32, 115, 109, 97, 108, 108, 32, 116, 121, 112, 101}};
V g_heff_2erules_2eabandonChk_lam1(V self, V *args); static Clo g_heff_2erules_2eabandonChk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eabandonChk_lam1, 2, 0};
V g_heff_2erules_2eabandonChk_lam2(V self, V *args);
V g_heff_2erules_2eabandonChk_lam0(V self, V *args);
Clo g_heff_2erules_2eabandonChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eabandonChk_entry, 1, 0};

V g_heff_2erules_2eabandonChk(V v_sp_240) {
top: ;
  return heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2erules_2eabandonChk_lam0, 2, 1, (V[]){v_sp_240})});
}
V g_heff_2erules_2eabandonChk_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2eabandonChk(a[0]);
}
V g_heff_2erules_2eabandonChk_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_dup(g_heff_2ememoed_2eabandonM_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2eabandonChk_lam2(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(321LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2eabandonChk_str0), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2411}));
  V f_ = heff_get(v_hd_247, LBL_bind);
  args[0] = v_t_2412;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2eabandonChk_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_242 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_241);
  V v_x1_243 = ({ V a_0 = v_a_242; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_a_242); r_; });
  V v_t_244;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Small: {
    v_t_244 = NTAG(TAG_True);
    break;
  }
  case TAG_Large: {
    v_t_244 = NTAG(TAG_False);
    break;
  }
  case TAG_TopL: {
    v_t_244 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    return ((V)&g_heff_2erules_2eabandonChk_lam1_clo);
  }
  case TAG_False: {
    return heff_clo(g_heff_2erules_2eabandonChk_lam2, 2, 1, (V[]){v_sp_240});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2erules_2eprimInt_lam0(V self, V *args); static Clo g_heff_2erules_2eprimInt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eprimInt_lam0, 3, 0};

static V g_heff_2erules_2eprimInt_val;
static int g_heff_2erules_2eprimInt_st;
static V g_heff_2erules_2eprimInt_init(void) {
  return heff_tag(TAG_MkTyp, 1, (V[]){((V)&g_heff_2erules_2eprimInt_lam0_clo)});
}
V g_heff_2erules_2eprimInt_get(void) {
  if (g_heff_2erules_2eprimInt_st == 2) return g_heff_2erules_2eprimInt_val;
  if (g_heff_2erules_2eprimInt_st == 1) heff_fail("defined by itself");
  g_heff_2erules_2eprimInt_st = 1;
  g_heff_2erules_2eprimInt_val = heff_tr(g_heff_2erules_2eprimInt_init());
  g_heff_2erules_2eprimInt_st = 2;
  return g_heff_2erules_2eprimInt_val;
}
V g_heff_2erules_2eprimInt_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2ememoed_2eprimInt_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2eprimFloat_lam0(V self, V *args); static Clo g_heff_2erules_2eprimFloat_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eprimFloat_lam0, 3, 0};

static V g_heff_2erules_2eprimFloat_val;
static int g_heff_2erules_2eprimFloat_st;
static V g_heff_2erules_2eprimFloat_init(void) {
  return heff_tag(TAG_MkTyp, 1, (V[]){((V)&g_heff_2erules_2eprimFloat_lam0_clo)});
}
V g_heff_2erules_2eprimFloat_get(void) {
  if (g_heff_2erules_2eprimFloat_st == 2) return g_heff_2erules_2eprimFloat_val;
  if (g_heff_2erules_2eprimFloat_st == 1) heff_fail("defined by itself");
  g_heff_2erules_2eprimFloat_st = 1;
  g_heff_2erules_2eprimFloat_val = heff_tr(g_heff_2erules_2eprimFloat_init());
  g_heff_2erules_2eprimFloat_st = 2;
  return g_heff_2erules_2eprimFloat_val;
}
V g_heff_2erules_2eprimFloat_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2ememoed_2eprimFloat_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2eprimArray_lam3(V self, V *args);
V g_heff_2erules_2eprimArray_lam2(V self, V *args);
V g_heff_2erules_2eprimArray_lam1(V self, V *args);
V g_heff_2erules_2eprimArray_lam0(V self, V *args);
Clo g_heff_2erules_2eprimArray_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eprimArray_entry, 1, 0};

V g_heff_2erules_2eprimArray(V v_a_240) {
top: ;
  return heff_tag(TAG_MkTyp, 1, (V[]){heff_clo(g_heff_2erules_2eprimArray_lam0, 1, 1, (V[]){heff_dup(v_a_240)})});
}
V g_heff_2erules_2eprimArray_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2eprimArray(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2erules_2eprimArray_lam3(V self, V *args) {
  V v_u_248 = args[0];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  V v_x1_249 = heff_tr(heff_apply(heff_get(v_x_246, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2413;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nom: {
    V v_x_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_t_2413 = v_x_2410;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_t_2413 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2412 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_t_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  return heff_tag(TAG_Nom, 1, (V[]){heff_tag(TAG_VPrimArray, 1, (V[]){v_t_2413})});
}
V g_heff_2erules_2eprimArray_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag(TAG_SPrimArray, 1, (V[]){heff_get(heff_dup(v_x_246), LBL_stx)});
  V f_ = v_k_245;
  args[0] = heff_rec(2, shape_326_366, (V[]){v_t_247, heff_clo(g_heff_2erules_2eprimArray_lam3, 1, 1, (V[]){v_x_246})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2eprimArray_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_243;
  args[0] = v_hd_244;
  args[1] = heff_clo(g_heff_2erules_2eprimArray_lam2, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2eprimArray_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_243;
  switch (heff_tag_of(v_a_240)) {
  case TAG_MkTyp: {
    V v_f_242 = heff_field(v_a_240, 0);
    heff_take_n(v_a_240, 1ULL, 1);
    v_c_243 = heff_tr(heff_apply(v_f_242, 1, (V[]){v_e_241}));
    break;
  }
  default: heff_nomatch(v_a_240);
  }
  return heff_clo(g_heff_2erules_2eprimArray_lam1, 2, 1, (V[]){v_c_243});
}
V g_heff_2erules_2eprimString_lam0(V self, V *args); static Clo g_heff_2erules_2eprimString_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eprimString_lam0, 3, 0};

static V g_heff_2erules_2eprimString_val;
static int g_heff_2erules_2eprimString_st;
static V g_heff_2erules_2eprimString_init(void) {
  return heff_tag(TAG_MkTyp, 1, (V[]){((V)&g_heff_2erules_2eprimString_lam0_clo)});
}
V g_heff_2erules_2eprimString_get(void) {
  if (g_heff_2erules_2eprimString_st == 2) return g_heff_2erules_2eprimString_val;
  if (g_heff_2erules_2eprimString_st == 1) heff_fail("defined by itself");
  g_heff_2erules_2eprimString_st = 1;
  g_heff_2erules_2eprimString_val = heff_tr(g_heff_2erules_2eprimString_init());
  g_heff_2erules_2eprimString_st = 2;
  return g_heff_2erules_2eprimString_val;
}
V g_heff_2erules_2eprimString_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2ememoed_2eprimString_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2edefaultAt_lam0(V self, V *args); static Clo g_heff_2erules_2edefaultAt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2edefaultAt_lam0, 2, 0};
V g_heff_2erules_2edefaultAt_lam2(V self, V *args);
V g_heff_2erules_2edefaultAt_lam1(V self, V *args);
Clo g_heff_2erules_2edefaultAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2edefaultAt_entry, 3, 0};

V g_heff_2erules_2edefaultAt(V v_e_240, V v_ty_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    heff_drop(v_ty_241);
    return ((V)&g_heff_2erules_2edefaultAt_lam0_clo);
  }
  case TAG_Just: {
    V v_c_245 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_apply(heff_get(v_ty_241, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_a_2410;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nom: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      v_a_2410 = v_x_247;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_246, 0ULL, 1);
      v_a_2410 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_249 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      v_a_2410 = v_x_249;
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    V v_c_2412;
    switch (heff_tag_of(v_c_245)) {
    case TAG_MkChk: {
      V v_f_2411 = heff_field(v_c_245, 0);
      heff_take_n(v_c_245, 1ULL, 1);
      v_c_2412 = heff_tr(heff_apply(v_f_2411, 2, (V[]){v_e_240, v_a_2410}));
      break;
    }
    default: heff_nomatch(v_c_245);
    }
    return heff_clo(g_heff_2erules_2edefaultAt_lam1, 2, 1, (V[]){v_c_2412});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2erules_2edefaultAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2edefaultAt(a[0], a[1], a[2]);
}
V g_heff_2erules_2edefaultAt_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2edefaultAt_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_x_2415, LBL_stx)});
  V f_ = v_k_2414;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2edefaultAt_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2412;
  args[0] = v_hd_2413;
  args[1] = heff_clo(g_heff_2erules_2edefaultAt_lam2, 1, 1, (V[]){v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2eformGo_lam0(V self, V *args); static Clo g_heff_2erules_2eformGo_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eformGo_lam0, 2, 0};
V g_heff_2erules_2eformGo_lam4(V self, V *args);
V g_heff_2erules_2eformGo_lam3(V self, V *args);
V g_heff_2erules_2eformGo_lam2(V self, V *args);
V g_heff_2erules_2eformGo_lam1(V self, V *args);
Clo g_heff_2erules_2eformGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eformGo_entry, 2, 0};

V g_heff_2erules_2eformGo(V v_e_27_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_e_27_240);
    return ((V)&g_heff_2erules_2eformGo_lam0_clo);
  }
  case TAG_Cons: {
    V v_fd_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_247 = heff_get(heff_dup(v_fd_245), LBL_typ);
    V v_c_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_MkTyp: {
      V v_f_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_c_249 = heff_tr(heff_apply(v_f_248, 1, (V[]){heff_dup(v_e_27_240)}));
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    return heff_clo(g_heff_2erules_2eformGo_lam1, 2, 4, (V[]){v_c_249, v_e_27_240, v_fd_245, v_rest_246});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2erules_2eformGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2eformGo(a[0], a[1]);
}
V g_heff_2erules_2eformGo_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V v_t_244 = heff_rec(3, shape_173_99_57, (V[]){NTAG(TAG_Small), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V f_ = v_k_243;
  args[0] = v_t_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2eformGo_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_fd_245 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_k_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_l1_2424 = heff_get(heff_dup(v_x_2423), LBL_level);
  V v_x1_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_x_2412), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_l2_2429;
  switch (heff_tag_of(v_x1_2425)) {
  case TAG_Nom: {
    V v_t_2426 = heff_field(v_x1_2425, 0);
    heff_take_n(v_x1_2425, 1ULL, 1);
    v_l2_2429 = ({ V a_0 = v_t_2426; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2426); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2427 = heff_field(v_x1_2425, 0);
    heff_take_n(v_x1_2425, 1ULL, 1);
    v_l2_2429 = ({ V a_0 = v_t_2427; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2427); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2428 = heff_field(v_x1_2425, 0);
    heff_take_n(v_x1_2425, 1ULL, 1);
    v_l2_2429 = ({ V a_0 = v_t_2428; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2428); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2425);
  }
  V v_t_2430;
  switch (heff_tag_of(v_l1_2424)) {
  case TAG_Small: {
    v_t_2430 = v_l2_2429;
    break;
  }
  case TAG_Large: {
    switch (heff_tag_of(v_l2_2429)) {
    case TAG_Small: {
      v_t_2430 = v_l1_2424;
      break;
    }
    case TAG_Large: {
      v_t_2430 = v_l2_2429;
      break;
    }
    case TAG_TopL: {
      v_t_2430 = v_l2_2429;
      break;
    }
    default: heff_nomatch(v_l2_2429);
    }
    break;
  }
  case TAG_TopL: {
    switch (heff_tag_of(v_l2_2429)) {
    case TAG_Small: {
      v_t_2430 = v_l1_2424;
      break;
    }
    case TAG_Large: {
      v_t_2430 = v_l1_2424;
      break;
    }
    case TAG_TopL: {
      v_t_2430 = v_l2_2429;
      break;
    }
    default: heff_nomatch(v_l2_2429);
    }
    break;
  }
  default: heff_nomatch(v_l1_2424);
  }
  V v_t_2431 = heff_tag(TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_fd_245), LBL_name), heff_get(v_x_2412, LBL_stx)});
  V v_t_2432 = heff_tag(TAG_Cons, 2, (V[]){v_t_2431, heff_get(heff_dup(v_x_2423), LBL_fields)});
  V v_ds_2433 = heff_get(v_x_2423, LBL_defaults);
  V v_t_2436;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nothing: {
    heff_drop(v_fd_245);
    v_t_2436 = v_ds_2433;
    break;
  }
  case TAG_Just: {
    V v_d_2434 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2435 = heff_tag(TAG_MkPair, 2, (V[]){heff_get(v_fd_245, LBL_name), v_d_2434});
    v_t_2436 = heff_tag(TAG_Cons, 2, (V[]){v_t_2435, v_ds_2433});
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_x_2437 = heff_rec(3, shape_173_99_57, (V[]){v_t_2430, v_t_2432, v_t_2436});
  V f_ = v_k_2411;
  args[0] = v_x_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2eformGo_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_fd_245 = heff_env(self)[1];
  V v_e_27_240 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_hd_2410 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_x_2412), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2419;
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_Nom: {
    V v_x_2416 = heff_field(v_x1_2415, 0);
    heff_take_n(v_x1_2415, 1ULL, 1);
    v_t_2419 = v_x_2416;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2415, 0ULL, 1);
    v_t_2419 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2418 = heff_field(v_x1_2415, 0);
    heff_take_n(v_x1_2415, 1ULL, 1);
    v_t_2419 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_x1_2415);
  }
  V v_sc_2420 = (g_heff_2eenvironment_2ebindName(heff_get(heff_dup(v_fd_245), LBL_name), v_t_2419, heff_get(heff_dup(v_e_27_240), LBL_scope)));
  V v_t_2421 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){v_sc_2420, heff_get(heff_dup(v_e_27_240), LBL_globals), heff_get(heff_dup(v_e_27_240), LBL_elabFor), heff_get(heff_dup(v_e_27_240), LBL_lams), heff_get(heff_dup(v_e_27_240), LBL_self), heff_get(v_e_27_240, LBL_insts)});
  V v_c_2422 = (g_heff_2erules_2eformGo(v_t_2421, v_rest_246));
  return heff_tail(v_c_2422, 2, (V[]){v_hd_2410, heff_clo(g_heff_2erules_2eformGo_lam4, 1, 4, (V[]){v_x_2412, v_fd_245, v_x_2414, v_k_2411})});
}
V g_heff_2erules_2eformGo_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_27_240 = heff_env(self)[0];
  V v_fd_245 = heff_env(self)[1];
  V v_hd_2410 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_k_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2413 = (g_heff_2erules_2edefaultAt(heff_dup(v_e_27_240), heff_dup(v_x_2412), heff_get(heff_dup(v_fd_245), LBL_dflt)));
  return heff_tail(v_c_2413, 2, (V[]){heff_dup(v_hd_2410), heff_clo(g_heff_2erules_2eformGo_lam3, 1, 6, (V[]){v_x_2412, v_fd_245, v_e_27_240, v_rest_246, v_hd_2410, v_k_2411})});
}
V g_heff_2erules_2eformGo_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_e_27_240 = heff_env(self)[1];
  V v_fd_245 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo(g_heff_2erules_2eformGo_lam2, 1, 5, (V[]){v_e_27_240, v_fd_245, v_hd_2410, v_rest_246, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2erecordFormation_lam2(V self, V *args);
V g_heff_2erules_2erecordFormation_lam1(V self, V *args);
V g_heff_2erules_2erecordFormation_lam0(V self, V *args);
Clo g_heff_2erules_2erecordFormation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erecordFormation_entry, 1, 0};

V g_heff_2erules_2erecordFormation(V v_fieldTyps_240) {
top: ;
  return heff_tag(TAG_MkTyp, 1, (V[]){heff_clo(g_heff_2erules_2erecordFormation_lam0, 1, 1, (V[]){v_fieldTyps_240})});
}
V g_heff_2erules_2erecordFormation_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2erecordFormation(a[0]);
}
V g_heff_2erules_2erecordFormation_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_get(heff_get(heff_dup(v_e_241), LBL_scope), LBL_locals);
  V v_pairs_2412 = heff_get(heff_dup(v_x_2410), LBL_fields);
  V v_t_2413 = (g_prelude_2emap_24s5(heff_dup(v_pairs_2412)));
  V v_t_2414 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_pairs_2412));
  V v_t_2415 = (g_prelude_2emap_24s6(v_pairs_2412));
  V v_t_2416 = heff_rec(3, shape_153_35_368, (V[]){heff_arrayFromList(v_t_2413), v_t_2414, heff_arrayFromList(v_t_2415)});
  V v_pairs_2417 = heff_get(heff_dup(v_x_2410), LBL_defaults);
  V v_t_2418 = (g_prelude_2emap_24s5(heff_dup(v_pairs_2417)));
  V v_t_2419 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_pairs_2417));
  V v_t_2420 = (g_prelude_2emap_24s6(v_pairs_2417));
  V v_t_2421 = heff_rec(3, shape_153_35_368, (V[]){heff_arrayFromList(v_t_2418), v_t_2419, heff_arrayFromList(v_t_2420)});
  V v_x_2422 = (g_heff_2ememoed_2erecordM(heff_get(v_e_241, LBL_globals), v_t_2411, heff_get(v_x_2410, LBL_level), v_t_2416, v_t_2421));
  V f_ = v_k_249;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2erecordFormation_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_247;
  args[0] = v_hd_248;
  args[1] = heff_clo(g_heff_2erules_2erecordFormation_lam2, 1, 2, (V[]){v_e_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2erecordFormation_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_fieldTyps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_e_242 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){heff_get(heff_dup(v_e_241), LBL_scope), heff_get(heff_dup(v_e_241), LBL_globals), NTAG(TAG_ForNominative), heff_get(heff_dup(v_e_241), LBL_lams), heff_get(heff_dup(v_e_241), LBL_self), heff_get(heff_dup(v_e_241), LBL_insts)});
  V v_sd_243 = heff_get(heff_dup(v_e_241), LBL_scope);
  V v_t_244 = heff_tag(TAG_CUndelay, 1, (V[]){heff_get(heff_dup(v_sd_243), LBL_ctx)});
  V v_sc_245 = heff_rec(4, shape_168_200_179_53, (V[]){heff_get(heff_dup(v_sd_243), LBL_len), heff_get(heff_dup(v_sd_243), LBL_names), heff_get(v_sd_243, LBL_locals), v_t_244});
  V v_t_246 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){v_sc_245, heff_get(heff_dup(v_e_242), LBL_globals), heff_get(heff_dup(v_e_242), LBL_elabFor), heff_get(heff_dup(v_e_242), LBL_lams), heff_get(heff_dup(v_e_242), LBL_self), heff_get(v_e_242, LBL_insts)});
  V v_c_247 = (g_heff_2erules_2eformGo(v_t_246, v_fieldTyps_240));
  return heff_clo(g_heff_2erules_2erecordFormation_lam1, 2, 2, (V[]){v_c_247, v_e_241});
}
V g_heff_2erules_2erecordName_lam0(V self, V *args);
V g_heff_2erules_2erecordName_lam1(V self, V *args);
Clo g_heff_2erules_2erecordName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erecordName_entry, 7, 0};

V g_heff_2erules_2erecordName(V v_e_240, V v_a_241, V v_x_242, V v_sp_243, V v_ty_244, V v_p_245, V v_p_246) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_VU: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop(v_sp_243);
    heff_drop(v_ty_244);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VDecode: {
    V v_it1_248 = heff_field(v_a_241, 0);
    switch (heff_tag_of(v_it1_248)) {
    case TAG_HLocal: {
      heff_drop(v_e_240);
      heff_drop(v_x_242);
      heff_drop(v_sp_243);
      heff_drop(v_ty_244);
      heff_drop(v_p_245);
      return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_HGlobal: {
      V v_k_2414 = heff_field(v_it1_248, 0);
      V v_t_2415 = heff_intSub(heff_get(heff_dup(v_sp_243), LBL_end), heff_get(heff_dup(v_sp_243), LBL_start));
      V v_t_2416 = heff_intEq(v_t_2415, heff_strLength(heff_dup(v_x_242)));
      switch (heff_tag_of(v_t_2416)) {
      case TAG_True: {
        V v_t_2418 = heff_rec(5, shape_314_198_152_188_351, (V[]){v_sp_243, v_x_242, heff_tag(TAG_Just, 1, (V[]){heff_dup(v_k_2414)}), NTAG(TAG_True), heff_clo(g_heff_2erules_2erecordName_lam0, 1, 2, (V[]){v_e_240, v_ty_244})});
        V v_t_2419 = heff_tag(TAG_Record, 2, (V[]){v_t_2418, NTAG(TAG_MkUnit)});
        V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_p_245), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2419})}));
        return heff_tail(heff_get(v_p_245, LBL_bind), 2, (V[]){v_t_2420, v_p_246});
      }
      case TAG_False: {
        V v_t_2421 = heff_intSub(heff_get(heff_dup(v_sp_243), LBL_end), heff_get(heff_dup(v_sp_243), LBL_start));
        V v_t_2422 = heff_intAdd(heff_strLength(heff_dup(v_x_242)), MK_INT(1LL));
        V v_t_2423 = heff_intEq(v_t_2421, v_t_2422);
        switch (heff_tag_of(v_t_2423)) {
        case TAG_True: {
          V v_t_2425 = heff_rec(5, shape_314_198_152_188_351, (V[]){v_sp_243, v_x_242, heff_tag(TAG_Just, 1, (V[]){heff_dup(v_k_2414)}), NTAG(TAG_True), heff_clo(g_heff_2erules_2erecordName_lam1, 1, 2, (V[]){v_e_240, v_ty_244})});
          V v_t_2426 = heff_tag(TAG_Record, 2, (V[]){v_t_2425, NTAG(TAG_MkUnit)});
          V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_p_245), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2426})}));
          return heff_tail(heff_get(v_p_245, LBL_bind), 2, (V[]){v_t_2427, v_p_246});
        }
        case TAG_False: {
          heff_drop(v_e_240);
          heff_drop(v_x_242);
          heff_drop(v_sp_243);
          heff_drop(v_ty_244);
          heff_drop(v_p_245);
          return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
        }
        default: return heff_nomatch(v_t_2423);
        }
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
    case TAG_HMeta: {
      heff_drop(v_e_240);
      heff_drop(v_x_242);
      heff_drop(v_sp_243);
      heff_drop(v_ty_244);
      heff_drop(v_p_245);
      return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_HError: {
      heff_drop(v_e_240);
      heff_drop(v_x_242);
      heff_drop(v_sp_243);
      heff_drop(v_ty_244);
      heff_drop(v_p_245);
      return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: return heff_nomatch(v_it1_248);
    }
  }
  case TAG_VFunction: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop(v_sp_243);
    heff_drop(v_ty_244);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VRecord: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop(v_sp_243);
    heff_drop(v_ty_244);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VSum: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop(v_sp_243);
    heff_drop(v_ty_244);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimInt: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop(v_sp_243);
    heff_drop(v_ty_244);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimFloat: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop(v_sp_243);
    heff_drop(v_ty_244);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimString: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop(v_sp_243);
    heff_drop(v_ty_244);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimArray: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop(v_sp_243);
    heff_drop(v_ty_244);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2erules_2erecordName_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2erecordName(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[1]); return r;
}
V g_heff_2erules_2erecordName_lam0(V self, V *args) {
  V v_u_2417 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_ty_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2417);
  return (g_heff_2erules_2etyStr(v_e_240, v_ty_244));
}
V g_heff_2erules_2erecordName_lam1(V self, V *args) {
  V v_u_2424 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_ty_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2424);
  return (g_heff_2erules_2etyStr(v_e_240, v_ty_244));
}
Clo g_heff_2erules_2eappendP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eappendP_entry, 2, 0};

V g_heff_2erules_2eappendP(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2erules_2eappendP(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2erules_2eappendP_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2eappendP(a[0], a[1]);
}
Clo g_heff_2erules_2elookupP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2elookupP_entry, 2, 0};

V g_heff_2erules_2elookupP(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x11_242, 0);
      V v_v_245 = heff_field(v_x11_242, 1);
      V v_t_246 = heff_strEq(heff_dup(v_y_244), heff_dup(v_x_241));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_x_241);
        return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_v_245)});
      }
      case TAG_False: {
        V t_0 = v_rest_243;
        V t_1 = v_x_241;
        v_x1_240 = t_0;
        v_x_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2erules_2elookupP_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2elookupP(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2erules_2erebottom_lam0(V self, V *args);
V g_heff_2erules_2erebottom_lam1(V self, V *args);
Clo g_heff_2erules_2erebottom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erebottom_entry, 2, 0};

V g_heff_2erules_2erebottom(V v_v_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_LNil: {
    heff_drop(v_v_240);
    return NTAG(TAG_LNil);
  }
  case TAG_LSnoc: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_x_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24LSnoc = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_LNil: {
      heff_drop(v_x_243);
      return heff_tag_at(v_ru_24x2_241_24LSnoc, TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo(g_heff_2erules_2erebottom_lam0, 1, 1, (V[]){v_v_240})});
    }
    case TAG_LSnoc: {
      V v_t_247 = (g_heff_2erules_2erebottom(v_v_240, v_x21_242));
      return heff_tag_at(v_ru_24x2_241_24LSnoc, TAG_LSnoc, 2, (V[]){v_t_247, v_x_243});
    }
    case TAG_LChunkSnoc: {
      V v_t_2410 = (g_heff_2erules_2erebottom(v_v_240, v_x21_242));
      return heff_tag_at(v_ru_24x2_241_24LSnoc, TAG_LSnoc, 2, (V[]){v_t_2410, v_x_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  case TAG_LChunkSnoc: {
    V v_x21_2411 = heff_field(v_x2_241, 0);
    V v_xs_2412 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24LChunkSnoc = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_LNil: {
      V v_t_2413 = heff_intEq(heff_arrayLength(heff_dup(v_xs_2412)), MK_INT(1LL));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_True: {
        heff_drop(v_xs_2412);
        return heff_tag_at(v_ru_24x2_241_24LChunkSnoc, TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo(g_heff_2erules_2erebottom_lam1, 1, 1, (V[]){v_v_240})});
      }
      case TAG_False: {
        heff_drop(v_v_240);
        return heff_tag_at(v_ru_24x2_241_24LChunkSnoc, TAG_LChunkSnoc, 2, (V[]){NTAG(TAG_LNil), v_xs_2412});
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    case TAG_LSnoc: {
      V v_t_2417 = (g_heff_2erules_2erebottom(v_v_240, v_x21_2411));
      return heff_tag_at(v_ru_24x2_241_24LChunkSnoc, TAG_LChunkSnoc, 2, (V[]){v_t_2417, v_xs_2412});
    }
    case TAG_LChunkSnoc: {
      V v_t_2420 = (g_heff_2erules_2erebottom(v_v_240, v_x21_2411));
      return heff_tag_at(v_ru_24x2_241_24LChunkSnoc, TAG_LChunkSnoc, 2, (V[]){v_t_2420, v_xs_2412});
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2erules_2erebottom_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2erebottom(a[0], a[1]);
}
V g_heff_2erules_2erebottom_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_244);
  return v_v_240;
}
V g_heff_2erules_2erebottom_lam1(V self, V *args) {
  V v_u_2414 = args[0];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2414);
  return v_v_240;
}
V g_heff_2erules_2eadvanceSelf_lam1(V self, V *args);
V g_heff_2erules_2eadvanceSelf_lam0(V self, V *args);
V g_heff_2erules_2eadvanceSelf_lam2(V self, V *args);
V g_heff_2erules_2eadvanceSelf_lam3(V self, V *args);
Clo g_heff_2erules_2eadvanceSelf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eadvanceSelf_entry, 4, 0};

V g_heff_2erules_2eadvanceSelf(V v_gk_240, V v_a_241, V v_fieldTypes_242, V v_done_243) {
top: ;
  V v_xs_244 = heff_get(heff_dup(v_fieldTypes_242), LBL_keys);
  V v_t_2411 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_244)), heff_clo(g_heff_2erules_2eadvanceSelf_lam0, 1, 4, (V[]){v_xs_244, heff_dup(v_done_243), heff_dup(v_gk_240), heff_dup(v_a_241)}));
  V v_t_2412 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_fieldTypes_242), LBL_keys), heff_get(v_fieldTypes_242, LBL_byName), v_t_2411});
  V v_t_2413 = heff_tag(TAG_Describe, 1, (V[]){heff_tag(TAG_VCons, 1, (V[]){v_t_2412})});
  V v_edesc_2414 = heff_tag(TAG_Just, 1, (V[]){v_t_2413});
  switch (heff_tag_of(v_edesc_2414)) {
  case TAG_Nothing: {
    HEFF_LAST return g_heff_2evalue_2emkNeu_24s10(heff_tag(TAG_HGlobal, 1, (V[]){v_gk_240}), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2eadvanceSelf_lam2, 1, 1, (V[]){v_a_241}), NTAG(TAG_Nothing));
  }
  case TAG_Just: {
    V v_it1_2416 = heff_field(v_edesc_2414, 0);
    V v_ru_24edesc_2414_24Just = heff_take_reuse_n(v_edesc_2414, 1ULL, 1);
    switch (heff_tag_of(v_it1_2416)) {
    case TAG_Nom: {
      V v_v_2417 = heff_field(v_it1_2416, 0);
      heff_take_n(v_it1_2416, 1ULL, 1);
      heff_drop(v_gk_240);
      heff_drop(v_a_241);
      heff_drop_cell(v_ru_24edesc_2414_24Just, 1);
      return v_v_2417;
    }
    case TAG_Describe: {
      V v_desc_2418 = heff_field(v_it1_2416, 0);
      V v_ru_24it1_2416_24Describe = heff_take_reuse_n(v_it1_2416, 1ULL, 1);
      HEFF_LAST return g_heff_2evalue_2emkNeu_24s10(heff_tag_at(v_ru_24edesc_2414_24Just, TAG_HGlobal, 1, (V[]){v_gk_240}), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2eadvanceSelf_lam3, 1, 1, (V[]){v_a_241}), heff_tag_at(v_ru_24it1_2416_24Describe, TAG_Just, 1, (V[]){v_desc_2418}));
    }
    case TAG_Become: {
      V v_v_2420 = heff_field(v_it1_2416, 0);
      heff_take_n(v_it1_2416, 1ULL, 1);
      heff_drop(v_gk_240);
      heff_drop(v_a_241);
      heff_drop_cell(v_ru_24edesc_2414_24Just, 1);
      return v_v_2420;
    }
    default: return heff_nomatch(v_it1_2416);
    }
  }
  default: return heff_nomatch(v_edesc_2414);
  }
}
V g_heff_2erules_2eadvanceSelf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2eadvanceSelf(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
V g_heff_2erules_2eadvanceSelf_lam1(V self, V *args) {
  V v_u_248 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  return v_a_241;
}
V g_heff_2erules_2eadvanceSelf_lam0(V self, V *args) {
  V v_i_245 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_done_243 = heff_env(self)[1];
  V v_gk_240 = heff_env(self)[2];
  V v_a_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_f_246 = heff_arrayIndex(v_xs_244, v_i_245);
  V v_t_247 = ({ V a_0 = v_done_243; V a_1 = heff_dup(v_f_246); V r_ = (g_heff_2erules_2elookupP(a_0, a_1)); heff_drop(v_done_243); r_; });
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    V v_t_249 = (g_heff_2evalue_2emkNeu_24s10(heff_tag(TAG_HGlobal, 1, (V[]){v_gk_240}), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2eadvanceSelf_lam1, 1, 1, (V[]){v_a_241}), NTAG(TAG_Nothing)));
    return (g_heff_2evalue_2eproj(v_t_249, v_f_246));
  }
  case TAG_Just: {
    V v_v_2410 = heff_field(v_t_247, 0);
    V v_ru_24t_247_24Just = heff_take_reuse_n(v_t_247, 1ULL, 1);
    heff_drop(v_gk_240);
    heff_drop(v_a_241);
    heff_drop(v_f_246);
    return heff_tag_at(v_ru_24t_247_24Just, TAG_Nom, 1, (V[]){v_v_2410});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2erules_2eadvanceSelf_lam2(V self, V *args) {
  V v_u_2415 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_a_241;
}
V g_heff_2erules_2eadvanceSelf_lam3(V self, V *args) {
  V v_u_2419 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2419);
  return v_a_241;
}
V g_heff_2erules_2eselfAdvance_lam0(V self, V *args); static Clo g_heff_2erules_2eselfAdvance_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eselfAdvance_lam0, 1, 0};
V g_heff_2erules_2eselfAdvance_lam1(V self, V *args);
Clo g_heff_2erules_2eselfAdvance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eselfAdvance_entry, 5, 0};

V g_heff_2erules_2eselfAdvance(V v_e_240, V v_a_241, V v_done_242, V v_p_243, V v_p_244) {
top: ;
  V v_t_245 = heff_get(heff_dup(v_e_240), LBL_elabFor);
  switch (heff_tag_of(v_t_245)) {
  case TAG_ForNominative: {
    heff_drop(v_a_241);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_e_240});
  }
  case TAG_ForDescriptive: {
    V v_it1_246 = heff_field(v_t_245, 0);
    V v_it2_247 = heff_field(v_t_245, 1);
    heff_take_n(v_t_245, 3ULL, 2);
    switch (heff_tag_of(v_it1_246)) {
    case TAG_HLocal: {
      heff_take_n(v_it1_246, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_p_243);
      heff_drop(v_it2_247);
      return heff_tail(v_p_244, 1, (V[]){v_e_240});
    }
    case TAG_HGlobal: {
      V v_gk_249 = heff_field(v_it1_246, 0);
      V v_ru_24it1_246_24HGlobal = heff_take_reuse_n(v_it1_246, 1ULL, 1);
      switch (heff_tag_of(v_it2_247)) {
      case TAG_SpId: {
        V v_t_2411 = heff_tag_at(v_ru_24it1_246_24HGlobal, TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2erules_2eselfAdvance_lam0_clo)})});
        V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
        V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2412}));
        return heff_tail(heff_get(v_p_243, LBL_bind), 2, (V[]){v_t_2413, heff_clo(g_heff_2erules_2eselfAdvance_lam1, 1, 5, (V[]){v_a_241, v_p_244, v_e_240, v_gk_249, heff_dup(v_done_242)})});
      }
      case TAG_SpApp: {
        heff_take_n(v_it2_247, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop(v_p_243);
        heff_drop(v_gk_249);
        heff_drop_cell(v_ru_24it1_246_24HGlobal, 1);
        return heff_tail(v_p_244, 1, (V[]){v_e_240});
      }
      case TAG_SpProj: {
        heff_take_n(v_it2_247, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop(v_p_243);
        heff_drop(v_gk_249);
        heff_drop_cell(v_ru_24it1_246_24HGlobal, 1);
        return heff_tail(v_p_244, 1, (V[]){v_e_240});
      }
      case TAG_SpSpec: {
        heff_take_n(v_it2_247, 0ULL, 3);
        heff_drop(v_a_241);
        heff_drop(v_p_243);
        heff_drop(v_gk_249);
        heff_drop_cell(v_ru_24it1_246_24HGlobal, 1);
        return heff_tail(v_p_244, 1, (V[]){v_e_240});
      }
      default: return heff_nomatch(v_it2_247);
      }
    }
    case TAG_HMeta: {
      heff_take_n(v_it1_246, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_p_243);
      heff_drop(v_it2_247);
      return heff_tail(v_p_244, 1, (V[]){v_e_240});
    }
    case TAG_HError: {
      heff_drop(v_a_241);
      heff_drop(v_p_243);
      heff_drop(v_it2_247);
      return heff_tail(v_p_244, 1, (V[]){v_e_240});
    }
    default: return heff_nomatch(v_it1_246);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2erules_2eselfAdvance_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2eselfAdvance(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2erules_2eselfAdvance_lam0(V self, V *args) {
  V v_c_2410 = args[0];
  return heff_get(v_c_2410, LBL_selfKey);
}
V g_heff_2erules_2eselfAdvance_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_a_241 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_gk_249 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = (g_heff_2evalue_2ebehavior(heff_dup(v_a_241)));
  switch (heff_tag_of(v_t_2415)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2415, 0ULL, 1);
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2415, 0ULL, 4);
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeRecord: {
    V v_fieldTypes_2423 = heff_field(v_t_2415, 2);
    heff_take_n(v_t_2415, 4ULL, 3);
    V v_t_2425;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_Nothing: {
      v_t_2425 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_y_2424 = heff_field(v_x_2414, 0);
      heff_take_n(v_x_2414, 1ULL, 1);
      v_t_2425 = heff_strEq(v_y_2424, heff_dup(v_gk_249));
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    switch (heff_tag_of(v_t_2425)) {
    case TAG_True: {
      V v_sc_2426 = heff_get(heff_dup(v_e_240), LBL_scope);
      V v_v_2427 = ({ V a_0 = v_gk_249; V a_1 = v_a_241; V a_2 = v_fieldTypes_2423; V a_3 = v_done_242; V r_ = (g_heff_2erules_2eadvanceSelf(a_0, a_1, a_2, a_3)); heff_drop(v_done_242); r_; });
      V v_t_2428 = (g_heff_2erules_2erebottom(v_v_2427, heff_get(heff_dup(v_sc_2426), LBL_locals)));
      V v_sc_2429 = heff_rec(4, shape_168_200_179_53, (V[]){heff_get(heff_dup(v_sc_2426), LBL_len), heff_get(heff_dup(v_sc_2426), LBL_names), v_t_2428, heff_get(v_sc_2426, LBL_ctx)});
      V v_x_2430 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){v_sc_2429, heff_get(heff_dup(v_e_240), LBL_globals), heff_get(heff_dup(v_e_240), LBL_elabFor), heff_get(heff_dup(v_e_240), LBL_lams), heff_get(heff_dup(v_e_240), LBL_self), heff_get(v_e_240, LBL_insts)});
      V f_ = v_p_244;
      args[0] = v_x_2430;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_False: {
      heff_drop(v_a_241);
      heff_drop(v_gk_249);
      heff_drop(v_done_242);
      heff_drop(v_fieldTypes_2423);
      V f_ = v_p_244;
      args[0] = v_e_240;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_t_2425);
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2415, 0ULL, 1);
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeString: {
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2415, 0ULL, 1);
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_NoRules: {
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2415);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2erules_2echeckFixed_str0 = {{0x80000000u, K_STR, 0}, 15, 15, {101, 120, 112, 101, 99, 116, 101, 100, 32, 118, 97, 108, 117, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2erules_2echeckFixed_str1 = {{0x80000000u, K_STR, 0}, 16, 16, {44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 118, 97, 108, 117, 101, 32}};
V g_heff_2erules_2echeckFixed_lam0(V self, V *args); static Clo g_heff_2erules_2echeckFixed_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2echeckFixed_lam0, 2, 0};
V g_heff_2erules_2echeckFixed_lam2(V self, V *args);
V g_heff_2erules_2echeckFixed_lam1(V self, V *args);
Clo g_heff_2erules_2echeckFixed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2echeckFixed_entry, 4, 0};

V g_heff_2erules_2echeckFixed(V v_e_240, V v_sp_241, V v_v_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop(v_v_242);
    return ((V)&g_heff_2erules_2echeckFixed_lam0_clo);
  }
  case TAG_Just: {
    V v_expected_246 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_c_247 = heff_get(heff_dup(v_e_240), LBL_scope);
    V v_cs_248 = heff_rec(2, shape_168_200, (V[]){heff_get(heff_dup(v_c_247), LBL_len), heff_get(v_c_247, LBL_names)});
    V v_t_249 = (g_heff_2eunify_2euTermF(heff_dup(g_co_2eplus_24s16_get()), ((V)&g_heff_2eunify_2emsEv_clo), ((V)&g_heff_2eunify_2eufEv_clo), heff_dup(g_heff_2eunify_2euk_24s391_get()), heff_get(heff_dup(v_e_240), LBL_globals), v_cs_248, heff_dup(v_v_242), heff_dup(v_expected_246)));
    V v_c_2410 = heff_tr(heff_apply(((V)&g_heff_2emeta_2eliftU_clo), 1, (V[]){v_t_249}));
    return heff_clo(g_heff_2erules_2echeckFixed_lam1, 2, 5, (V[]){v_c_2410, v_e_240, v_expected_246, v_v_242, v_sp_241});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2erules_2echeckFixed_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2echeckFixed(a[0], a[1], a[2], a[3]);
}
V g_heff_2erules_2echeckFixed_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2echeckFixed_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_expected_246 = heff_env(self)[1];
  V v_v_242 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Left = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    V v_c_2415 = heff_get(heff_dup(v_e_240), LBL_scope);
    V v_t_2416 = heff_rec(2, shape_168_200, (V[]){heff_get(heff_dup(v_c_2415), LBL_len), heff_get(v_c_2415, LBL_names)});
    V v_t_2417 = (g_heff_2erules_2eeqElStr(heff_get(heff_dup(v_e_240), LBL_globals), v_t_2416, v_expected_246));
    V v_c_2418 = heff_get(heff_dup(v_e_240), LBL_scope);
    V v_t_2419 = heff_rec(2, shape_168_200, (V[]){heff_get(heff_dup(v_c_2418), LBL_len), heff_get(v_c_2418, LBL_names)});
    V v_msg_2420 = heff_strAppend(((V)&g_heff_2erules_2echeckFixed_str0), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2erules_2echeckFixed_str1), (g_heff_2erules_2eeqElStr(heff_get(heff_dup(v_e_240), LBL_globals), v_t_2419, v_v_242)))));
    V v_note_2421 = ({ V a_0 = heff_get(v_e_240, LBL_globals); V a_1 = v_err_2414; V r_ = (g_heff_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2414); r_; });
    V v_t_2422 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_msg_2420, v_sp_241, heff_tag(TAG_Just, 1, (V[]){v_note_2421})});
    V v_t_2423 = heff_tag_at(v_ru_24x_2413_24Left, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2411), LBL_malg), 1, (V[]){v_t_2424}));
    return heff_tail(heff_get(v_hd_2411, LBL_bind), 2, (V[]){v_t_2425, v_k_2412});
  }
  case TAG_Right: {
    heff_take_n(v_x_2413, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_expected_246);
    heff_drop(v_v_242);
    heff_drop(v_sp_241);
    heff_drop(v_hd_2411);
    V f_ = v_k_2412;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2erules_2echeckFixed_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_expected_246 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo(g_heff_2erules_2echeckFixed_lam2, 1, 6, (V[]){v_e_240, v_expected_246, v_v_242, v_sp_241, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2eandList_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2eandList_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 97, 110, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2erules_2eandList_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
Clo g_heff_2erules_2eandList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eandList_entry, 1, 0};

V g_heff_2erules_2eandList(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2erules_2eandList_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_y_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2erules_2eandList_str1), heff_dup(v_y_243)));
      }
      case TAG_Cons: {
        return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2erules_2eandList_str2), (g_heff_2erules_2eandList(v_x12_242))));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2erules_2eandList_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2eandList(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2efieldsNote_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2efieldsNote_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2erules_2efieldsNote_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2erules_2efieldsNote_str3 = {{0x80000000u, K_STR, 0}, 17, 17, {32, 109, 97, 121, 32, 98, 101, 32, 108, 101, 102, 116, 32, 111, 117, 116, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2erules_2efieldsNote_str4 = {{0x80000000u, K_STR, 0}, 15, 15, {116, 104, 101, 32, 102, 105, 101, 108, 100, 115, 32, 97, 114, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2erules_2efieldsNote_str5 = {{0x80000000u, K_STR, 0}, 15, 15, {44, 32, 105, 110, 32, 116, 104, 105, 115, 32, 111, 114, 100, 101, 114}};
Clo g_heff_2erules_2efieldsNote_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2efieldsNote_entry, 1, 0};

V g_heff_2erules_2efieldsNote(V v_it_240) {
top: ;
  V v_t_241 = heff_get(heff_dup(v_it_240), LBL_keys);
  V v_t_244;
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nil: {
    v_t_244 = ((V)&g_heff_2erules_2efieldsNote_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_t_241, 0);
    V v_xs_243 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    v_t_244 = ({ V a_0 = v_x_242; V a_1 = v_xs_243; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  V v_t_245 = heff_get(heff_get(heff_dup(v_it_240), LBL_defaults), LBL_values);
  V v_t_246 = heff_intEq(heff_arrayLength(v_t_245), MK_INT(0LL));
  V v_t_249;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_it_240);
    v_t_249 = ((V)&g_heff_2erules_2efieldsNote_str1);
    break;
  }
  case TAG_False: {
    V v_t_247 = heff_get(heff_get(v_it_240, LBL_defaults), LBL_keys);
    V v_t_248 = ({ V b_0 = heff_arrayToList(v_t_247); V r_ = (g_heff_2erules_2eandList(b_0)); heff_drop(b_0); r_; });
    v_t_249 = heff_strAppend(((V)&g_heff_2erules_2efieldsNote_str2), heff_strAppend(v_t_248, ((V)&g_heff_2erules_2efieldsNote_str3)));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return heff_strAppend(((V)&g_heff_2erules_2efieldsNote_str4), heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2erules_2efieldsNote_str5), v_t_249)));
}
V g_heff_2erules_2efieldsNote_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2efieldsNote(a[0]);
}
V g_heff_2erules_2edefaultFor_lam0(V self, V *args);
V g_heff_2erules_2edefaultFor_lam1(V self, V *args);
Clo g_heff_2erules_2edefaultFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2edefaultFor_entry, 3, 0};

V g_heff_2erules_2edefaultFor(V v_x1_240, V v_g_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_ForNominative: {
    return heff_rec(2, shape_326_366, (V[]){heff_dup(v_d_242), heff_clo(g_heff_2erules_2edefaultFor_lam0, 1, 2, (V[]){v_g_241, v_d_242})});
  }
  case TAG_ForDescriptive: {
    return heff_rec(2, shape_326_366, (V[]){heff_tag(TAG_SIs, 1, (V[]){heff_dup(v_d_242)}), heff_clo(g_heff_2erules_2edefaultFor_lam1, 1, 2, (V[]){v_g_241, v_d_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2erules_2edefaultFor_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2edefaultFor(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2erules_2edefaultFor_lam0(V self, V *args) {
  V v_u_243 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_243);
  return (g_heff_2eeval_2eevalTermF_24s14(v_g_241, NTAG(TAG_N), v_d_242, NTAG(TAG_LNil)));
}
V g_heff_2erules_2edefaultFor_lam1(V self, V *args) {
  V v_u_246 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_246);
  V v_x1_247 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(v_g_241, NTAG(TAG_N), v_d_242, NTAG(TAG_LNil)));
  V v_t_2411;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nom: {
    V v_x_248 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 1);
    v_t_2411 = v_x_248;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_247, 0ULL, 1);
    v_t_2411 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2410 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 1);
    v_t_2411 = v_x_2410;
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  return heff_tag(TAG_Become, 1, (V[]){v_t_2411});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2erules_2enotGiven_str0 = {{0x80000000u, K_STR, 0}, 21, 21, {109, 105, 115, 115, 105, 110, 103, 32, 114, 101, 99, 111, 114, 100, 32, 102, 105, 101, 108, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2erules_2enotGiven_str1 = {{0x80000000u, K_STR, 0}, 22, 22, {101, 120, 112, 101, 99, 116, 101, 100, 32, 114, 101, 99, 111, 114, 100, 32, 102, 105, 101, 108, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2erules_2enotGiven_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {32, 103, 111, 116, 58, 32}};
V g_heff_2erules_2enotGiven_lam0(V self, V *args);
V g_heff_2erules_2enotGiven_lam1(V self, V *args);
Clo g_heff_2erules_2enotGiven_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2enotGiven_entry, 3, 0};

V g_heff_2erules_2enotGiven(V v_it_240, V v_x_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    V v_note_243 = (g_heff_2erules_2efieldsNote(heff_dup(v_it_240)));
    return heff_clo(g_heff_2erules_2enotGiven_lam0, 2, 3, (V[]){v_x_241, v_it_240, v_note_243});
  }
  case TAG_Cons: {
    V v_fs_2410 = heff_field(v_x3_242, 0);
    V v_note_2412 = (g_heff_2erules_2efieldsNote(v_it_240));
    return heff_clo(g_heff_2erules_2enotGiven_lam1, 2, 3, (V[]){v_x_241, heff_dup(v_fs_2410), v_note_2412});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2erules_2enotGiven_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2enotGiven(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2erules_2enotGiven_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k2_245 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_it_240 = heff_env(self)[1];
  V v_note_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_246 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(304LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2erules_2enotGiven_str0), v_x_241), heff_get(v_it_240, LBL_span), heff_tag(TAG_Just, 1, (V[]){v_note_243})});
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_248}));
  V f_ = heff_get(v_hd_244, LBL_bind);
  args[0] = v_t_249;
  args[1] = v_k2_245;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2enotGiven_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_fs_2410 = heff_env(self)[1];
  V v_note_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_strAppend(((V)&g_heff_2erules_2enotGiven_str1), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2erules_2enotGiven_str2), heff_get(heff_dup(v_fs_2410), LBL_name))));
  V v_t_2416 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(303LL), NTAG(TAG_SError), v_t_2415, heff_get(v_fs_2410, LBL_span), heff_tag(TAG_Just, 1, (V[]){v_note_2412})});
  V v_t_2417 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2413), LBL_malg), 1, (V[]){v_t_2418}));
  V f_ = heff_get(v_hd_2413, LBL_bind);
  args[0] = v_t_2419;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2edefaulted_lam0(V self, V *args);
Clo g_heff_2erules_2edefaulted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2edefaulted_entry, 4, 0};

V g_heff_2erules_2edefaulted(V v_e_240, V v_it_241, V v_x_242, V v_settings_243) {
top: ;
  V v_d_244 = heff_get(heff_dup(v_it_241), LBL_defaults);
  V v_t_245 = ({ V a_0 = heff_dup(v_x_242); V b_1 = heff_get(heff_dup(v_d_244), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    heff_drop(v_d_244);
    return ({ V a_0 = v_it_241; V a_1 = v_x_242; V a_2 = v_settings_243; V r_ = (g_heff_2erules_2enotGiven(a_0, a_1, a_2)); heff_drop(v_settings_243); r_; });
  }
  case TAG_Just: {
    V v_i_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_xs_247 = heff_get(v_d_244, LBL_values);
    V v_t_248 = heff_intLe(MK_INT(0LL), heff_dup(v_i_246));
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      V v_t_249 = heff_intLt(heff_dup(v_i_246), heff_arrayLength(heff_dup(v_xs_247)));
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        V v_d_2410 = heff_arrayIndex(v_xs_247, v_i_246);
        V v_t_2411 = heff_get(heff_dup(v_e_240), LBL_elabFor);
        V v_t_2414;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_ForNominative: {
          heff_drop(v_x_242);
          v_t_2414 = NTAG(TAG_ForNominative);
          break;
        }
        case TAG_ForDescriptive: {
          V v_h_2412 = heff_field(v_t_2411, 0);
          V v_sp_2413 = heff_field(v_t_2411, 1);
          V v_ru_24t_2411_24ForDescriptive = heff_take_reuse_n(v_t_2411, 3ULL, 2);
          v_t_2414 = heff_tag_at(v_ru_24t_2411_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2412, heff_tag(TAG_SpProj, 2, (V[]){v_sp_2413, v_x_242})});
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        V v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = heff_get(v_e_240, LBL_globals); V a_2 = v_d_2410; V r_ = (g_heff_2erules_2edefaultFor(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
        V v_x_2416 = heff_rec(3, shape_80_314_277, (V[]){v_t_2415, heff_get(v_it_241, LBL_span), v_settings_243});
        return heff_clo(g_heff_2erules_2edefaulted_lam0, 2, 1, (V[]){v_x_2416});
      }
      case TAG_False: {
        heff_drop(v_e_240);
        heff_drop(v_i_246);
        heff_drop(v_xs_247);
        return ({ V a_0 = v_it_241; V a_1 = v_x_242; V a_2 = v_settings_243; V r_ = (g_heff_2erules_2enotGiven(a_0, a_1, a_2)); heff_drop(v_settings_243); r_; });
      }
      default: return heff_nomatch(v_t_249);
      }
    }
    case TAG_False: {
      heff_drop(v_e_240);
      heff_drop(v_i_246);
      heff_drop(v_xs_247);
      return ({ V a_0 = v_it_241; V a_1 = v_x_242; V a_2 = v_settings_243; V r_ = (g_heff_2erules_2enotGiven(a_0, a_1, a_2)); heff_drop(v_settings_243); r_; });
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2erules_2edefaulted_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2edefaulted(a[0], a[1], a[2], a[3]);
}
V g_heff_2erules_2edefaulted_lam0(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2ewritten_lam1(V self, V *args);
V g_heff_2erules_2ewritten_lam0(V self, V *args);
Clo g_heff_2erules_2ewritten_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2ewritten_entry, 8, 0};

V g_heff_2erules_2ewritten(V v_e_240, V v_it_241, V v_x_242, V v_fty_243, V v_fs_244, V v_rest_245, V v_hd_246, V v_k_247) {
top: ;
  return ({ V a_0 = heff_dup(v_e_240); V b_1 = heff_get(v_it_241, LBL_ty); V a_2 = heff_get(heff_dup(v_fs_244), LBL_name); V a_3 = heff_get(heff_dup(v_fs_244), LBL_nameSpan); V a_4 = heff_dup(v_fty_243); V a_5 = heff_dup(v_hd_246); V a_6 = heff_clo(g_heff_2erules_2ewritten_lam0, 1, 7, (V[]){v_e_240, v_x_242, v_fs_244, v_fty_243, v_hd_246, v_rest_245, v_k_247}); V r_ = (g_heff_2erules_2erecordName(a_0, b_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(b_1); r_; });
}
V g_heff_2erules_2ewritten_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2ewritten(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2erules_2ewritten_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_fs_244 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_rec(3, shape_80_314_277, (V[]){v_x_2417, heff_get(v_fs_244, LBL_span), v_rest_245});
  V f_ = v_k_247;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2ewritten_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_fs_244 = heff_env(self)[2];
  V v_fty_243 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_248);
  V v_t_249 = heff_get(heff_dup(v_e_240), LBL_elabFor);
  V v_ef_2412;
  switch (heff_tag_of(v_t_249)) {
  case TAG_ForNominative: {
    heff_drop(v_x_242);
    v_ef_2412 = NTAG(TAG_ForNominative);
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2410 = heff_field(v_t_249, 0);
    V v_sp_2411 = heff_field(v_t_249, 1);
    V v_ru_24t_249_24ForDescriptive = heff_take_reuse_n(v_t_249, 3ULL, 2);
    v_ef_2412 = heff_tag_at(v_ru_24t_249_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2410, heff_tag(TAG_SpProj, 2, (V[]){v_sp_2411, v_x_242})});
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_e_2413 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){heff_get(heff_dup(v_e_240), LBL_scope), heff_get(heff_dup(v_e_240), LBL_globals), v_ef_2412, heff_get(heff_dup(v_e_240), LBL_lams), heff_get(heff_dup(v_e_240), LBL_self), heff_get(v_e_240, LBL_insts)});
  V v_t_2414 = heff_get(heff_dup(v_fs_244), LBL_chk);
  V v_c_2416;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_MkChk: {
    V v_f_2415 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    v_c_2416 = heff_tr(heff_apply(v_f_2415, 2, (V[]){v_e_2413, v_fty_243}));
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  return heff_tail(v_c_2416, 2, (V[]){v_hd_246, heff_clo(g_heff_2erules_2ewritten_lam1, 1, 3, (V[]){v_fs_244, v_rest_245, v_k_247})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2erules_2eleftOver_str0 = {{0x80000000u, K_STR, 0}, 13, 13, {114, 101, 99, 111, 114, 100, 32, 102, 105, 101, 108, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2erules_2eleftOver_str1 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 105, 115, 32, 103, 105, 118, 101, 110, 32, 116, 119, 105, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2erules_2eleftOver_str2 = {{0x80000000u, K_STR, 0}, 13, 13, {114, 101, 99, 111, 114, 100, 32, 102, 105, 101, 108, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2erules_2eleftOver_str3 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 105, 115, 32, 111, 117, 116, 32, 111, 102, 32, 111, 114, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2erules_2eleftOver_str4 = {{0x80000000u, K_STR, 0}, 14, 14, {110, 111, 32, 115, 117, 99, 104, 32, 102, 105, 101, 108, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2erules_2eleftOver_str5 = {{0x80000000u, K_STR, 0}, 9, 9, {32, 105, 110, 32, 116, 121, 112, 101, 32}};
V g_heff_2erules_2eleftOver_lam0(V self, V *args); static Clo g_heff_2erules_2eleftOver_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eleftOver_lam0, 2, 0};
V g_heff_2erules_2eleftOver_lam1(V self, V *args);
V g_heff_2erules_2eleftOver_lam2(V self, V *args);
V g_heff_2erules_2eleftOver_lam3(V self, V *args);
V g_heff_2erules_2eleftOver_lam4(V self, V *args);
Clo g_heff_2erules_2eleftOver_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eleftOver_entry, 3, 0};

V g_heff_2erules_2eleftOver(V v_e_240, V v_it_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_it_241);
    return ((V)&g_heff_2erules_2eleftOver_lam0_clo);
  }
  case TAG_Cons: {
    V v_fs_245 = heff_field(v_x3_242, 0);
    V v_xs_248 = (g_prelude_2efilter(heff_clo(g_heff_2erules_2eleftOver_lam1, 1, 1, (V[]){heff_dup(v_fs_245)}), heff_get(heff_dup(v_it_241), LBL_written)));
    V v_a_249 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_248; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_248); r_; });
    V v_t_2410 = heff_intLt(MK_INT(1LL), v_a_249);
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      heff_drop(v_e_240);
      V v_note_2411 = (g_heff_2erules_2efieldsNote(v_it_241));
      return heff_clo(g_heff_2erules_2eleftOver_lam2, 2, 2, (V[]){heff_dup(v_fs_245), v_note_2411});
    }
    case TAG_False: {
      V v_t_2419 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_fs_245), LBL_name)}));
      V v_t_2420 = ({ V a_0 = v_t_2419; V b_1 = heff_get(heff_dup(v_it_241), LBL_keys); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2420)) {
      case TAG_True: {
        heff_drop(v_e_240);
        V v_note_2421 = (g_heff_2erules_2efieldsNote(v_it_241));
        return heff_clo(g_heff_2erules_2eleftOver_lam3, 2, 2, (V[]){heff_dup(v_fs_245), v_note_2421});
      }
      case TAG_False: {
        V v_msg_2429 = heff_strAppend(((V)&g_heff_2erules_2eleftOver_str4), heff_strAppend(heff_get(heff_dup(v_fs_245), LBL_name), heff_strAppend(((V)&g_heff_2erules_2eleftOver_str5), (g_heff_2erules_2etyStr(v_e_240, heff_get(heff_dup(v_it_241), LBL_ty))))));
        V v_note_2430 = (g_heff_2erules_2efieldsNote(v_it_241));
        return heff_clo(g_heff_2erules_2eleftOver_lam4, 2, 3, (V[]){v_msg_2429, heff_dup(v_fs_245), v_note_2430});
      }
      default: return heff_nomatch(v_t_2420);
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2erules_2eleftOver_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2eleftOver(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2erules_2eleftOver_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2eleftOver_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_fs_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(v_x_247, heff_get(v_fs_245, LBL_name));
}
V g_heff_2erules_2eleftOver_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_fs_245 = heff_env(self)[0];
  V v_note_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_strAppend(((V)&g_heff_2erules_2eleftOver_str0), heff_strAppend(heff_get(heff_dup(v_fs_245), LBL_name), ((V)&g_heff_2erules_2eleftOver_str1)));
  V v_t_2415 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(304LL), NTAG(TAG_SError), v_t_2414, heff_get(v_fs_245, LBL_span), heff_tag(TAG_Just, 1, (V[]){v_note_2411})});
  V v_t_2416 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2412), LBL_malg), 1, (V[]){v_t_2417}));
  V f_ = heff_get(v_hd_2412, LBL_bind);
  args[0] = v_t_2418;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2eleftOver_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k2_2423 = args[1];
  V v_fs_245 = heff_env(self)[0];
  V v_note_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_strAppend(((V)&g_heff_2erules_2eleftOver_str2), heff_strAppend(heff_get(heff_dup(v_fs_245), LBL_name), ((V)&g_heff_2erules_2eleftOver_str3)));
  V v_t_2425 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(304LL), NTAG(TAG_SError), v_t_2424, heff_get(v_fs_245, LBL_span), heff_tag(TAG_Just, 1, (V[]){v_note_2421})});
  V v_t_2426 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2422), LBL_malg), 1, (V[]){v_t_2427}));
  V f_ = heff_get(v_hd_2422, LBL_bind);
  args[0] = v_t_2428;
  args[1] = v_k2_2423;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2eleftOver_lam4(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k2_2432 = args[1];
  V v_msg_2429 = heff_env(self)[0];
  V v_fs_245 = heff_env(self)[1];
  V v_note_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2433 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(307LL), NTAG(TAG_SError), v_msg_2429, heff_get(v_fs_245, LBL_span), heff_tag(TAG_Just, 1, (V[]){v_note_2430})});
  V v_t_2434 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2431), LBL_malg), 1, (V[]){v_t_2435}));
  V f_ = heff_get(v_hd_2431, LBL_bind);
  args[0] = v_t_2436;
  args[1] = v_k2_2432;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2eintroGo_lam2(V self, V *args);
V g_heff_2erules_2eintroGo_lam5(V self, V *args);
V g_heff_2erules_2eintroGo_lam6(V self, V *args);
V g_heff_2erules_2eintroGo_lam4(V self, V *args);
V g_heff_2erules_2eintroGo_lam3(V self, V *args);
V g_heff_2erules_2eintroGo_lam1(V self, V *args);
V g_heff_2erules_2eintroGo_lam0(V self, V *args);
Clo g_heff_2erules_2eintroGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eintroGo_entry, 6, 0};

V g_heff_2erules_2eintroGo(V v_e_240, V v_it_241, V v_done_242, V v_vs_243, V v_settings_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_done_242);
    heff_drop(v_vs_243);
    return ({ V a_0 = v_e_240; V a_1 = v_it_241; V a_2 = v_settings_244; V r_ = (g_heff_2erules_2eleftOver(a_0, a_1, a_2)); heff_drop(v_settings_244); r_; });
  }
  case TAG_Cons: {
    V v_x61_246 = heff_field(v_x6_245, 0);
    V v_rest_247 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24Cons = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    switch (heff_tag_of(v_x61_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x61_246, 0);
      V v_fieldC_249 = heff_field(v_x61_246, 1);
      heff_take_n(v_x61_246, 3ULL, 2);
      V v_t_2410 = heff_tr(heff_apply(v_fieldC_249, 1, (V[]){heff_dup(v_vs_243)}));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_MkField: {
        V v_fty_2411 = heff_field(v_t_2410, 0);
        V v_fvalue_2412 = heff_field(v_t_2410, 1);
        heff_take_n(v_t_2410, 3ULL, 2);
        V v_c_2416;
        switch (heff_tag_of(v_settings_244)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x6_245_24Cons, 2);
          v_c_2416 = (g_heff_2erules_2edefaulted(heff_dup(v_e_240), heff_dup(v_it_241), heff_dup(v_x_248), NTAG(TAG_Nil)));
          break;
        }
        case TAG_Cons: {
          V v_fs_2413 = heff_field(v_settings_244, 0);
          V v_rest_2414 = heff_field(v_settings_244, 1);
          heff_take_n(v_settings_244, 3ULL, 2);
          V v_t_2415 = heff_strEq(heff_get(heff_dup(v_fs_2413), LBL_name), heff_dup(v_x_248));
          switch (heff_tag_of(v_t_2415)) {
          case TAG_True: {
            heff_drop_cell(v_ru_24x6_245_24Cons, 2);
            v_c_2416 = heff_tr(heff_apply(((V)&g_heff_2erules_2ewritten_clo), 6, (V[]){heff_dup(v_e_240), heff_dup(v_it_241), heff_dup(v_x_248), heff_dup(v_fty_2411), v_fs_2413, v_rest_2414}));
            break;
          }
          case TAG_False: {
            v_c_2416 = (g_heff_2erules_2edefaulted(heff_dup(v_e_240), heff_dup(v_it_241), heff_dup(v_x_248), heff_tag_at(v_ru_24x6_245_24Cons, TAG_Cons, 2, (V[]){v_fs_2413, v_rest_2414})));
            break;
          }
          default: heff_nomatch(v_t_2415);
          }
          break;
        }
        default: heff_nomatch(v_settings_244);
        }
        return heff_clo(g_heff_2erules_2eintroGo_lam0, 2, 9, (V[]){v_c_2416, v_e_240, v_x_248, v_fty_2411, v_fvalue_2412, v_done_242, v_it_241, v_vs_243, v_rest_247});
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_x61_246);
    }
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2erules_2eintroGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2eintroGo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2erules_2eintroGo_lam2(V self, V *args) {
  V v_u_2433 = args[0];
  V v_fty_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2433);
  return v_fty_2411;
}
V g_heff_2erules_2eintroGo_lam5(V self, V *args) {
  V v_u_2444 = args[0];
  V v_v_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2444);
  return v_v_2435;
}
V g_heff_2erules_2eintroGo_lam6(V self, V *args) {
  V v_x_2446 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  V v_k_2418 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2447 = heff_tag(TAG_MkPair, 2, (V[]){v_x_248, heff_get(v_x_2419, LBL_el)});
  V f_ = v_k_2418;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_t_2447, v_x_2446});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2eintroGo_lam4(V self, V *args) {
  V v_x_2441 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_v_2435 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  V v_it_241 = heff_env(self)[3];
  V v_vs_243 = heff_env(self)[4];
  V v_x_2419 = heff_env(self)[5];
  V v_rest_247 = heff_env(self)[6];
  V v_hd_2417 = heff_env(self)[7];
  V v_k_2418 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2442 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_x_248), heff_dup(v_v_2435)}), NTAG(TAG_Nil)});
  V v_t_2443 = (g_heff_2erules_2eappendP(v_done_242, v_t_2442));
  V v_c_2445 = (g_heff_2erules_2eintroGo(v_x_2441, v_it_241, v_t_2443, heff_tag(TAG_LSnoc, 2, (V[]){v_vs_243, heff_clo(g_heff_2erules_2eintroGo_lam5, 1, 1, (V[]){v_v_2435})}), heff_get(heff_dup(v_x_2419), LBL_rest), v_rest_247));
  return heff_tail(v_c_2445, 2, (V[]){v_hd_2417, heff_clo(g_heff_2erules_2eintroGo_lam6, 1, 3, (V[]){v_x_248, v_x_2419, v_k_2418})});
}
V g_heff_2erules_2eintroGo_lam3(V self, V *args) {
  V v_x_2437 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_v_2435 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_it_241 = heff_env(self)[4];
  V v_hd_2417 = heff_env(self)[5];
  V v_vs_243 = heff_env(self)[6];
  V v_x_2419 = heff_env(self)[7];
  V v_rest_247 = heff_env(self)[8];
  V v_k_2418 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_x_248), heff_dup(v_v_2435)}), NTAG(TAG_Nil)});
  V v_t_2439 = (g_heff_2erules_2eappendP(heff_dup(v_done_242), v_t_2438));
  V v_c_2440 = heff_tr(heff_apply(((V)&g_heff_2erules_2eselfAdvance_clo), 3, (V[]){v_e_240, heff_get(heff_dup(v_it_241), LBL_ty), v_t_2439}));
  return heff_tail(v_c_2440, 2, (V[]){heff_dup(v_hd_2417), heff_clo(g_heff_2erules_2eintroGo_lam4, 1, 9, (V[]){v_x_248, v_v_2435, v_done_242, v_it_241, v_vs_243, v_x_2419, v_rest_247, v_hd_2417, v_k_2418})});
}
V g_heff_2erules_2eintroGo_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_fty_2411 = heff_env(self)[2];
  V v_fvalue_2412 = heff_env(self)[3];
  V v_hd_2417 = heff_env(self)[4];
  V v_done_242 = heff_env(self)[5];
  V v_it_241 = heff_env(self)[6];
  V v_vs_243 = heff_env(self)[7];
  V v_rest_247 = heff_env(self)[8];
  V v_k_2418 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2420 = heff_get(heff_dup(v_e_240), LBL_elabFor);
  V v_x1_2423;
  switch (heff_tag_of(v_t_2420)) {
  case TAG_ForNominative: {
    v_x1_2423 = NTAG(TAG_ForNominative);
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2421 = heff_field(v_t_2420, 0);
    V v_sp_2422 = heff_field(v_t_2420, 1);
    V v_ru_24t_2420_24ForDescriptive = heff_take_reuse_n(v_t_2420, 3ULL, 2);
    v_x1_2423 = heff_tag_at(v_ru_24t_2420_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2421, heff_tag(TAG_SpProj, 2, (V[]){v_sp_2422, heff_dup(v_x_248)})});
    break;
  }
  default: heff_nomatch(v_t_2420);
  }
  V v_t_2424 = heff_get(heff_get(heff_dup(v_x_2419), LBL_el), LBL_val);
  V v_x2_2425 = heff_tr(heff_apply(v_t_2424, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_v_2435;
  switch (heff_tag_of(v_x1_2423)) {
  case TAG_ForNominative: {
    heff_drop(v_fty_2411);
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_Nom: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      heff_take_n(v_x2_2425, 1ULL, 1);
      v_v_2435 = v_x_2426;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x2_2425, 0ULL, 1);
      v_v_2435 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2428 = heff_field(v_x2_2425, 0);
      heff_take_n(v_x2_2425, 1ULL, 1);
      v_v_2435 = v_x_2428;
      break;
    }
    default: heff_nomatch(v_x2_2425);
    }
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2429 = heff_field(v_x1_2423, 0);
    V v_sp_2430 = heff_field(v_x1_2423, 1);
    heff_take_n(v_x1_2423, 3ULL, 2);
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_Nom: {
      V v_v_2431 = heff_field(v_x2_2425, 0);
      heff_take_n(v_x2_2425, 1ULL, 1);
      heff_drop(v_fty_2411);
      heff_drop(v_h_2429);
      heff_drop(v_sp_2430);
      v_v_2435 = v_v_2431;
      break;
    }
    case TAG_Describe: {
      V v_desc_2432 = heff_field(v_x2_2425, 0);
      V v_ru_24x2_2425_24Describe = heff_take_reuse_n(v_x2_2425, 1ULL, 1);
      v_v_2435 = (g_heff_2evalue_2emkNeu_24s10(v_h_2429, v_sp_2430, heff_clo(g_heff_2erules_2eintroGo_lam2, 1, 1, (V[]){v_fty_2411}), heff_tag_at(v_ru_24x2_2425_24Describe, TAG_Just, 1, (V[]){v_desc_2432})));
      break;
    }
    case TAG_Become: {
      V v_v_2434 = heff_field(v_x2_2425, 0);
      heff_take_n(v_x2_2425, 1ULL, 1);
      heff_drop(v_fty_2411);
      heff_drop(v_h_2429);
      heff_drop(v_sp_2430);
      v_v_2435 = v_v_2434;
      break;
    }
    default: heff_nomatch(v_x2_2425);
    }
    break;
  }
  default: heff_nomatch(v_x1_2423);
  }
  V v_c_2436 = (g_heff_2erules_2echeckFixed(heff_dup(v_e_240), heff_get(heff_dup(v_x_2419), LBL_span), heff_dup(v_v_2435), v_fvalue_2412));
  return heff_tail(v_c_2436, 2, (V[]){heff_dup(v_hd_2417), heff_clo(g_heff_2erules_2eintroGo_lam3, 1, 10, (V[]){v_x_248, v_v_2435, v_done_242, v_e_240, v_it_241, v_hd_2417, v_vs_243, v_x_2419, v_rest_247, v_k_2418})});
}
V g_heff_2erules_2eintroGo_lam0(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_fty_2411 = heff_env(self)[3];
  V v_fvalue_2412 = heff_env(self)[4];
  V v_done_242 = heff_env(self)[5];
  V v_it_241 = heff_env(self)[6];
  V v_vs_243 = heff_env(self)[7];
  V v_rest_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo(g_heff_2erules_2eintroGo_lam1, 1, 10, (V[]){v_e_240, v_x_248, v_fty_2411, v_fvalue_2412, v_hd_2417, v_done_242, v_it_241, v_vs_243, v_rest_247, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[55]; } g_heff_2erules_2erecordIntro_str0 = {{0x80000000u, K_STR, 0}, 55, 55, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[55]; } g_heff_2erules_2erecordIntro_str1 = {{0x80000000u, K_STR, 0}, 55, 55, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[55]; } g_heff_2erules_2erecordIntro_str2 = {{0x80000000u, K_STR, 0}, 55, 55, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[55]; } g_heff_2erules_2erecordIntro_str3 = {{0x80000000u, K_STR, 0}, 55, 55, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[55]; } g_heff_2erules_2erecordIntro_str4 = {{0x80000000u, K_STR, 0}, 55, 55, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[55]; } g_heff_2erules_2erecordIntro_str5 = {{0x80000000u, K_STR, 0}, 55, 55, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[55]; } g_heff_2erules_2erecordIntro_str6 = {{0x80000000u, K_STR, 0}, 55, 55, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[55]; } g_heff_2erules_2erecordIntro_str7 = {{0x80000000u, K_STR, 0}, 55, 55, {116, 114, 105, 101, 100, 32, 116, 111, 32, 99, 104, 101, 99, 107, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 97, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
V g_heff_2erules_2erecordIntro_lam1(V self, V *args);
V g_heff_2erules_2erecordIntro_lam3(V self, V *args);
V g_heff_2erules_2erecordIntro_lam2(V self, V *args);
V g_heff_2erules_2erecordIntro_lam0(V self, V *args);
Clo g_heff_2erules_2erecordIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erecordIntro_entry, 2, 0};

V g_heff_2erules_2erecordIntro(V v_sp_240, V v_fieldSettings_241) {
top: ;
  return heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2erules_2erecordIntro_lam0, 4, 2, (V[]){v_sp_240, v_fieldSettings_241})});
}
V g_heff_2erules_2erecordIntro_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2erecordIntro(a[0], a[1]);
}
V g_heff_2erules_2erecordIntro_lam1(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_246, LBL_metas); V a_1 = v_a0_243; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2erules_2erecordIntro_lam3(V self, V *args) {
  V v_x_2435 = args[0];
  V v_e0_242 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = heff_get(v_e0_242, LBL_elabFor);
  V v_t_2439;
  switch (heff_tag_of(v_t_2436)) {
  case TAG_ForNominative: {
    v_t_2439 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2436, 0ULL, 2);
    v_t_2439 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2436);
  }
  V v_t_2440 = (g_prelude_2emap_24s5(heff_dup(v_x_2435)));
  V v_t_2441 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_x_2435));
  V v_t_2442 = (g_prelude_2emap_24s6(v_x_2435));
  V v_t_2443 = heff_rec(3, shape_153_35_368, (V[]){heff_arrayFromList(v_t_2440), v_t_2441, heff_arrayFromList(v_t_2442)});
  V v_x_2444 = ({ V a_0 = v_t_2439; V a_1 = v_t_2443; V r_ = (g_heff_2ememoed_2econs(a_0, a_1)); heff_drop(v_t_2439); r_; });
  V f_ = v_k_245;
  args[0] = v_x_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2erecordIntro_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_fieldSettings_241 = heff_env(self)[3];
  V v_e0_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = (g_heff_2evalue_2ebehavior(heff_dup(v_x_2410)));
  switch (heff_tag_of(v_t_2411)) {
  case TAG_LikeU: {
    V v_ru_24t_2411_24LikeU = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2413 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordIntro_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2414 = heff_tag_at(v_ru_24t_2411_24LikeU, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2415}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2416, v_k_245});
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2411, 0ULL, 4);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2421 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordIntro_str1), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2422 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2423}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2424, v_k_245});
  }
  case TAG_LikeRecord: {
    V v_capture_2426 = heff_field(v_t_2411, 1);
    V v_fieldTypes_2427 = heff_field(v_t_2411, 2);
    heff_take_n(v_t_2411, 6ULL, 3);
    V v_t_2428 = heff_arrayToList(heff_get(heff_dup(v_fieldTypes_2427), LBL_keys));
    V v_t_2429 = (g_heff_2evalue_2edefaultsOf(heff_dup(v_x_2410)));
    V v_t_2430 = (g_prelude_2emap_24s426(heff_dup(v_fieldSettings_241)));
    V v_t_2431 = heff_arrayToList(heff_get(heff_dup(v_fieldTypes_2427), LBL_keys));
    V v_t_2432 = heff_arrayToList(heff_get(v_fieldTypes_2427, LBL_values));
    V v_t_2433 = (g_heff_2edict_2ezipKV(v_t_2431, v_t_2432));
    V v_c_2434 = (g_heff_2erules_2eintroGo(heff_dup(v_e0_242), heff_rec(5, shape_314_351_153_57_376, (V[]){v_sp_240, v_x_2410, v_t_2428, v_t_2429, v_t_2430}), NTAG(TAG_Nil), v_capture_2426, v_fieldSettings_241, v_t_2433));
    return heff_tail(v_c_2434, 2, (V[]){v_hd_244, heff_clo(g_heff_2erules_2erecordIntro_lam3, 1, 2, (V[]){v_e0_242, v_k_245})});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2411_24LikeSum = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2446 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordIntro_str2), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2447 = heff_tag_at(v_ru_24t_2411_24LikeSum, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2448}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2449, v_k_245});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2450 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordIntro_str3), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2451 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2452}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2453, v_k_245});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2454 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordIntro_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2455 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2456}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2457, v_k_245});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2458 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordIntro_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2459 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2460}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2461, v_k_245});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2411_24LikeArray = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2463 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordIntro_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2464 = heff_tag_at(v_ru_24t_2411_24LikeArray, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2465}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2466, v_k_245});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2467 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordIntro_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2468 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2469}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2470, v_k_245});
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2erules_2erecordIntro_lam0(V self, V *args) {
  V v_e0_242 = args[0];
  V v_a0_243 = args[1];
  V v_hd_244 = args[2];
  V v_k_245 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_fieldSettings_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2erecordIntro_lam1, 1, 1, (V[]){v_a0_243})})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_248}));
  V f_ = heff_get(heff_dup(v_hd_244), LBL_bind);
  args[0] = v_t_249;
  args[1] = heff_clo(g_heff_2erules_2erecordIntro_lam2, 1, 5, (V[]){v_sp_240, v_hd_244, v_k_245, v_fieldSettings_241, v_e0_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2erules_2eanyP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eanyP_entry, 2, 0};

V g_heff_2erules_2eanyP(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2erules_2eanyP_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2eanyP(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2erules_2eanyIdxGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eanyIdxGo_entry, 3, 0};

V g_heff_2erules_2eanyIdxGo(V v_i_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_tr(heff_apply(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), heff_dup(v_x_243)}));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_i_240);
      heff_drop(v_f_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_f_241;
      V t_2 = v_xs_244;
      v_i_240 = t_0;
      v_f_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2erules_2eanyIdxGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2eanyIdxGo(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2erules_2ementionsTermF_24s428_lam0(V self, V *args);
V g_heff_2erules_2ementionsTermF_24s428_lam1(V self, V *args);
V g_heff_2erules_2ementionsTermF_24s428_lam2(V self, V *args);
Clo g_heff_2erules_2ementionsTermF_24s428_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2ementionsTermF_24s428_entry, 2, 0};

V g_heff_2erules_2ementionsTermF_24s428(V v_d_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SLocal: {
    V v_i_242 = heff_field(v_t_241, 0);
    return heff_intLe(v_d_240, heff_dup(v_i_242));
  }
  case TAG_SGlobal: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    V v_a_244 = heff_field(v_t_241, 0);
    HEFF_LAST return g_heff_2erules_2ementionsTypeF_24s427(v_d_240, v_a_244);
  }
  case TAG_SApp: {
    V v_f_245 = heff_field(v_t_241, 0);
    V v_a_246 = heff_field(v_t_241, 1);
    V v_t_247 = (g_heff_2erules_2ementionsTermF_24s428(heff_dup(v_d_240), v_f_245));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_d_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_d_240;
      V t_1 = v_a_246;
      v_d_240 = t_0;
      v_t_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_SLam: {
    V v_dd_248 = heff_field(v_t_241, 0);
    V v_it2_249 = heff_field(v_t_241, 1);
    switch (heff_tag_of(v_it2_249)) {
    case TAG_MkAbs: {
      V v_b_2411 = heff_field(v_it2_249, 1);
      V v_t_2412 = (g_heff_2erules_2ementionsTypeF_24s427(heff_dup(v_d_240), v_dd_248));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        heff_drop(v_d_240);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
        V t_1 = v_b_2411;
        v_d_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    case TAG_AbsConst: {
      V v_b_2413 = heff_field(v_it2_249, 0);
      V v_t_2414 = (g_heff_2erules_2ementionsTypeF_24s427(heff_dup(v_d_240), v_dd_248));
      switch (heff_tag_of(v_t_2414)) {
      case TAG_True: {
        heff_drop(v_d_240);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V t_0 = v_d_240;
        V t_1 = v_b_2413;
        v_d_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    default: return heff_nomatch(v_it2_249);
    }
  }
  case TAG_SCons: {
    V v_dct_2415 = heff_field(v_t_241, 0);
    V v_t_2416 = heff_arrayToList(heff_get(heff_dup(v_dct_2415), LBL_keys));
    V v_t_2417 = heff_arrayToList(heff_get(heff_dup(v_dct_2415), LBL_values));
    V v_t_2418 = (g_heff_2edict_2ezipKV(v_t_2416, v_t_2417));
    return ({ V a_0 = heff_clo(g_heff_2erules_2ementionsTermF_24s428_lam0, 1, 1, (V[]){v_d_240}); V a_1 = v_t_2418; V r_ = (g_heff_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2418); r_; });
  }
  case TAG_SProj: {
    V v_e_2422 = heff_field(v_t_241, 0);
    V t_0 = v_d_240;
    V t_1 = v_e_2422;
    v_d_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_STag: {
    V v_as_2425 = heff_field(v_t_241, 1);
    return ({ V a_0 = heff_clo(g_heff_2erules_2ementionsTermF_24s428_lam1, 1, 1, (V[]){v_d_240}); V b_1 = heff_arrayToList(heff_dup(v_as_2425)); V r_ = (g_heff_2erules_2eanyP(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_SMatch: {
    V v_e_2427 = heff_field(v_t_241, 0);
    V v_cs_2428 = heff_field(v_t_241, 1);
    V v_t_2429 = (g_heff_2erules_2ementionsTermF_24s428(heff_dup(v_d_240), v_e_2427));
    switch (heff_tag_of(v_t_2429)) {
    case TAG_True: {
      heff_drop(v_d_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_2430 = heff_arrayToList(heff_get(heff_dup(v_cs_2428), LBL_keys));
      V v_t_2431 = heff_arrayToList(heff_get(heff_dup(v_cs_2428), LBL_values));
      V v_t_2432 = (g_heff_2edict_2ezipKV(v_t_2430, v_t_2431));
      return ({ V a_0 = heff_clo(g_heff_2erules_2ementionsTermF_24s428_lam2, 1, 1, (V[]){v_d_240}); V a_1 = v_t_2432; V r_ = (g_heff_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2432); r_; });
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  case TAG_SSpecialize: {
    V v_e_2439 = heff_field(v_t_241, 0);
    V v_v_2441 = heff_field(v_t_241, 2);
    V v_t_2442 = (g_heff_2erules_2ementionsTermF_24s428(heff_dup(v_d_240), v_e_2439));
    switch (heff_tag_of(v_t_2442)) {
    case TAG_True: {
      heff_drop(v_d_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_d_240;
      V t_1 = v_v_2441;
      v_d_240 = t_0;
      v_t_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_2442);
    }
  }
  case TAG_SIs: {
    V v_e_2443 = heff_field(v_t_241, 0);
    V t_0 = v_d_240;
    V t_1 = v_e_2443;
    v_d_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    V v_e_2444 = heff_field(v_t_241, 0);
    V t_0 = v_d_240;
    V t_1 = v_e_2444;
    v_d_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SFix: {
    V v_dd_2445 = heff_field(v_t_241, 0);
    V v_it2_2446 = heff_field(v_t_241, 1);
    switch (heff_tag_of(v_it2_2446)) {
    case TAG_MkAbs: {
      V v_b_2448 = heff_field(v_it2_2446, 1);
      V v_t_2449 = (g_heff_2erules_2ementionsTypeF_24s427(heff_dup(v_d_240), v_dd_2445));
      switch (heff_tag_of(v_t_2449)) {
      case TAG_True: {
        heff_drop(v_d_240);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
        V t_1 = v_b_2448;
        v_d_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2449);
      }
    }
    case TAG_AbsConst: {
      V v_b_2450 = heff_field(v_it2_2446, 0);
      V v_t_2451 = (g_heff_2erules_2ementionsTypeF_24s427(heff_dup(v_d_240), v_dd_2445));
      switch (heff_tag_of(v_t_2451)) {
      case TAG_True: {
        heff_drop(v_d_240);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V t_0 = v_d_240;
        V t_1 = v_b_2450;
        v_d_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2451);
      }
    }
    default: return heff_nomatch(v_it2_2446);
    }
  }
  case TAG_SImplicit: {
    V v_e_2453 = heff_field(v_t_241, 1);
    V t_0 = v_d_240;
    V t_1 = v_e_2453;
    v_d_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SPrim: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SMetaApp: {
    V v_ty_2457 = heff_field(v_t_241, 2);
    HEFF_LAST return g_heff_2erules_2ementionsTypeF_24s427(v_d_240, v_ty_2457);
  }
  case TAG_SLitInt: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2erules_2ementionsTermF_24s428_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2ementionsTermF_24s428(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2erules_2ementionsTermF_24s428_lam0(V self, V *args) {
  V v_x3_2419 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2419)) {
  case TAG_MkPair: {
    V v_v_2421 = heff_field(v_x3_2419, 1);
    heff_take_n(v_x3_2419, 2ULL, 2);
    return ({ V a_0 = v_d_240; V a_1 = v_v_2421; V r_ = (g_heff_2erules_2ementionsTermF_24s428(a_0, a_1)); heff_drop(v_v_2421); r_; });
  }
  default: return heff_nomatch(v_x3_2419);
  }
}
V g_heff_2erules_2ementionsTermF_24s428_lam1(V self, V *args) {
  V v_t_2426 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_d_240; V a_1 = v_t_2426; V r_ = (g_heff_2erules_2ementionsTermF_24s428(a_0, a_1)); heff_drop(v_t_2426); r_; });
}
V g_heff_2erules_2ementionsTermF_24s428_lam2(V self, V *args) {
  V v_x3_2433 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2433)) {
  case TAG_MkPair: {
    V v_x32_2435 = heff_field(v_x3_2433, 1);
    heff_take_n(v_x3_2433, 2ULL, 2);
    switch (heff_tag_of(v_x32_2435)) {
    case TAG_MkPair: {
      V v_xs_2436 = heff_field(v_x32_2435, 0);
      V v_b_2437 = heff_field(v_x32_2435, 1);
      heff_take_n(v_x32_2435, 3ULL, 2);
      V v_t_2438 = heff_intAdd(v_d_240, heff_arrayLength(v_xs_2436));
      return ({ V a_0 = v_t_2438; V a_1 = v_b_2437; V r_ = (g_heff_2erules_2ementionsTermF_24s428(a_0, a_1)); heff_drop(v_b_2437); r_; });
    }
    default: return heff_nomatch(v_x32_2435);
    }
  }
  default: return heff_nomatch(v_x3_2433);
  }
}
V g_heff_2erules_2ementionsTypeF_24s427_lam0(V self, V *args);
V g_heff_2erules_2ementionsTypeF_24s427_lam2(V self, V *args);
V g_heff_2erules_2ementionsTypeF_24s427_lam1(V self, V *args);
Clo g_heff_2erules_2ementionsTypeF_24s427_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2ementionsTypeF_24s427_entry, 2, 0};

V g_heff_2erules_2ementionsTypeF_24s427(V v_d_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SU: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SDecode: {
    V v_e_243 = heff_field(v_t_241, 0);
    HEFF_LAST return g_heff_2erules_2ementionsTermF_24s428(v_d_240, v_e_243);
  }
  case TAG_SFunction: {
    V v_dom_245 = heff_field(v_t_241, 1);
    V v_it3_246 = heff_field(v_t_241, 2);
    switch (heff_tag_of(v_it3_246)) {
    case TAG_MkAbs: {
      V v_b_249 = heff_field(v_it3_246, 1);
      V v_t_2410 = (g_heff_2erules_2ementionsTypeF_24s427(heff_dup(v_d_240), v_dom_245));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        heff_drop(v_d_240);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
        V t_1 = v_b_249;
        v_d_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    case TAG_AbsConst: {
      V v_b_2411 = heff_field(v_it3_246, 0);
      V v_t_2412 = (g_heff_2erules_2ementionsTypeF_24s427(heff_dup(v_d_240), v_dom_245));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        heff_drop(v_d_240);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V t_0 = v_d_240;
        V t_1 = v_b_2411;
        v_d_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    default: return heff_nomatch(v_it3_246);
    }
  }
  case TAG_SRecord: {
    V v_ft_2414 = heff_field(v_t_241, 1);
    V v_t_2416 = heff_arrayToList(heff_get(heff_dup(v_ft_2414), LBL_values));
    return ({ V a_0 = MK_INT(0LL); V a_1 = heff_clo(g_heff_2erules_2ementionsTypeF_24s427_lam0, 2, 1, (V[]){v_d_240}); V a_2 = v_t_2416; V r_ = (g_heff_2erules_2eanyIdxGo(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
  }
  case TAG_SSum: {
    V v_vs_2419 = heff_field(v_t_241, 0);
    V v_t_2420 = heff_arrayToList(heff_get(heff_dup(v_vs_2419), LBL_keys));
    V v_t_2421 = heff_arrayToList(heff_get(heff_dup(v_vs_2419), LBL_values));
    V v_t_2422 = (g_heff_2edict_2ezipKV(v_t_2420, v_t_2421));
    return ({ V a_0 = heff_clo(g_heff_2erules_2ementionsTypeF_24s427_lam1, 1, 1, (V[]){v_d_240}); V a_1 = v_t_2422; V r_ = (g_heff_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2422); r_; });
  }
  case TAG_SIsTy: {
    V v_a_2427 = heff_field(v_t_241, 0);
    V t_0 = v_d_240;
    V t_1 = v_a_2427;
    v_d_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SPrimInt: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SPrimString: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SPrimArray: {
    V v_a_2428 = heff_field(v_t_241, 0);
    V t_0 = v_d_240;
    V t_1 = v_a_2428;
    v_d_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2erules_2ementionsTypeF_24s427_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2ementionsTypeF_24s427(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2erules_2ementionsTypeF_24s427_lam0(V self, V *args) {
  V v_i_2417 = args[0];
  V v_ty_2418 = args[1];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = heff_intAdd(v_d_240, v_i_2417); V a_1 = v_ty_2418; V r_ = (g_heff_2erules_2ementionsTypeF_24s427(a_0, a_1)); heff_drop(v_ty_2418); r_; });
}
V g_heff_2erules_2ementionsTypeF_24s427_lam2(V self, V *args) {
  V v_t_2426 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_d_240; V a_1 = v_t_2426; V r_ = (g_heff_2erules_2ementionsTypeF_24s427(a_0, a_1)); heff_drop(v_t_2426); r_; });
}
V g_heff_2erules_2ementionsTypeF_24s427_lam1(V self, V *args) {
  V v_x3_2423 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2423)) {
  case TAG_MkPair: {
    V v_args_2425 = heff_field(v_x3_2423, 1);
    heff_take_n(v_x3_2423, 2ULL, 2);
    return ({ V a_0 = heff_clo(g_heff_2erules_2ementionsTypeF_24s427_lam2, 1, 1, (V[]){v_d_240}); V b_1 = heff_arrayToList(v_args_2425); V r_ = (g_heff_2erules_2eanyP(a_0, b_1)); heff_drop(b_1); r_; });
  }
  default: return heff_nomatch(v_x3_2423);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[85]; } g_heff_2erules_2eclosedDefault_str0 = {{0x80000000u, K_STR, 0}, 85, 85, {97, 32, 102, 105, 101, 108, 100, 39, 115, 32, 100, 101, 102, 97, 117, 108, 116, 32, 99, 97, 110, 32, 110, 97, 109, 101, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 115, 32, 111, 110, 108, 121, 44, 32, 110, 111, 116, 32, 116, 104, 101, 32, 116, 121, 112, 101, 39, 115, 32, 112, 97, 114, 97, 109, 101, 116, 101, 114, 115, 32, 110, 111, 114, 32, 105, 116, 115, 32, 102, 105, 101, 108, 100, 115}};
V g_heff_2erules_2eclosedDefault_lam3(V self, V *args); static Clo g_heff_2erules_2eclosedDefault_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eclosedDefault_lam3, 1, 0};
V g_heff_2erules_2eclosedDefault_lam4(V self, V *args);
V g_heff_2erules_2eclosedDefault_lam2(V self, V *args);
V g_heff_2erules_2eclosedDefault_lam1(V self, V *args);
V g_heff_2erules_2eclosedDefault_lam0(V self, V *args);
Clo g_heff_2erules_2eclosedDefault_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eclosedDefault_entry, 2, 0};

V g_heff_2erules_2eclosedDefault(V v_sp_240, V v_c_241) {
top: ;
  return heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2erules_2eclosedDefault_lam0, 2, 2, (V[]){heff_dup(v_c_241), v_sp_240})});
}
V g_heff_2erules_2eclosedDefault_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2eclosedDefault(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2erules_2eclosedDefault_lam3(V self, V *args) {
  V v_c0_249 = args[0];
  return heff_get(v_c0_249, LBL_metas);
}
V g_heff_2erules_2eclosedDefault_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = ({ V a_0 = v_x_2413; V r_ = (g_heff_2eunify_2ezonker(a_0)); heff_drop(v_x_2413); r_; });
  V v_stx_2415 = heff_tr(heff_apply(heff_get(v_t_2414, LBL_el), 1, (V[]){heff_get(heff_dup(v_x_248), LBL_stx)}));
  V v_t_2416 = (g_heff_2erules_2ementionsTermF_24s428(MK_INT(0LL), v_stx_2415));
  switch (heff_tag_of(v_t_2416)) {
  case TAG_True: {
    heff_drop(v_x_248);
    heff_drop(v_stx_2415);
    V v_t_2417 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(343LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2eclosedDefault_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2419}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2420, v_k_247});
  }
  case TAG_False: {
    heff_drop(v_sp_240);
    heff_drop(v_hd_246);
    V v_t_2421 = heff_rec(2, shape_326_366, (V[]){v_stx_2415, heff_get(v_x_248, LBL_val)});
    V f_ = v_k_247;
    args[0] = v_t_2421;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2416);
  }
}
V g_heff_2erules_2eclosedDefault_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2erules_2eclosedDefault_lam3_clo)})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2411}));
  return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2erules_2eclosedDefault_lam4, 1, 4, (V[]){v_x_248, v_sp_240, v_hd_246, v_k_247})});
}
V g_heff_2erules_2eclosedDefault_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo(g_heff_2erules_2eclosedDefault_lam2, 1, 3, (V[]){v_hd_246, v_sp_240, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2eclosedDefault_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245;
  switch (heff_tag_of(v_c_241)) {
  case TAG_MkChk: {
    V v_f_244 = heff_field(v_c_241, 0);
    heff_take_n(v_c_241, 1ULL, 1);
    v_c_245 = heff_tr(heff_apply(v_f_244, 2, (V[]){v_e_242, v_a_243}));
    break;
  }
  default: heff_nomatch(v_c_241);
  }
  return heff_clo(g_heff_2erules_2eclosedDefault_lam1, 2, 2, (V[]){v_c_245, v_sp_240});
}
V g_heff_2erules_2efieldTyAt_lam0(V self, V *args);
Clo g_heff_2erules_2efieldTyAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2efieldTyAt_entry, 6, 0};

V g_heff_2erules_2efieldTyAt(V v_len_240, V v_capture_241, V v_fieldTypes_242, V v_i_243, V v_before_244, V v_j_245) {
top: ;
  V v_t_246 = heff_intLt(heff_dup(v_j_245), heff_dup(v_i_243));
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    V v_t_247 = heff_arrayIndex(heff_get(heff_dup(v_fieldTypes_242), LBL_values), heff_dup(v_j_245));
    V v_t_248 = heff_tr(heff_apply(v_t_247, 1, (V[]){heff_tag(TAG_LChunkSnoc, 2, (V[]){heff_dup(v_capture_241), heff_dup(v_before_244)})}));
    switch (heff_tag_of(v_t_248)) {
    case TAG_MkField: {
      V v_fty_249 = heff_field(v_t_248, 0);
      V v_fvalue_2410 = heff_field(v_t_248, 1);
      V v_ru_24t_248_24MkField = heff_take_reuse_n(v_t_248, 3ULL, 2);
      V v_t_2414;
      switch (heff_tag_of(v_fvalue_2410)) {
      case TAG_Nothing: {
        V v_t_2411 = heff_tag(TAG_HLocal, 1, (V[]){heff_intAdd(heff_dup(v_len_240), heff_dup(v_j_245))});
        v_t_2414 = (g_heff_2evalue_2emkNeu_24s10(v_t_2411, NTAG(TAG_SpId), heff_clo(g_heff_2erules_2efieldTyAt_lam0, 1, 1, (V[]){v_fty_249}), NTAG(TAG_Nothing)));
        break;
      }
      case TAG_Just: {
        V v_v_2413 = heff_field(v_fvalue_2410, 0);
        heff_take_n(v_fvalue_2410, 1ULL, 1);
        heff_drop(v_fty_249);
        v_t_2414 = v_v_2413;
        break;
      }
      default: heff_nomatch(v_fvalue_2410);
      }
      V v_t_2415 = heff_tag_at(v_ru_24t_248_24MkField, TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
      V v_t_2416 = (g_heff_2erules_2eappendP(heff_arrayToList(v_before_244), v_t_2415));
      V t_0 = v_len_240;
      V t_1 = v_capture_241;
      V t_2 = v_fieldTypes_242;
      V t_3 = v_i_243;
      V t_4 = heff_arrayFromList(v_t_2416);
      V t_5 = heff_intAdd(v_j_245, MK_INT(1LL));
      v_len_240 = t_0;
      v_capture_241 = t_1;
      v_fieldTypes_242 = t_2;
      v_i_243 = t_3;
      v_before_244 = t_4;
      v_j_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  case TAG_False: {
    heff_drop(v_j_245);
    V v_t_2417 = heff_arrayIndex(heff_get(v_fieldTypes_242, LBL_values), heff_dup(v_i_243));
    V v_t_2418 = heff_tr(heff_apply(v_t_2417, 1, (V[]){heff_tag(TAG_LChunkSnoc, 2, (V[]){v_capture_241, v_before_244})}));
    switch (heff_tag_of(v_t_2418)) {
    case TAG_MkField: {
      V v_fty_2419 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 2);
      V v_t_2421 = (g_heff_2ereadback_2ereadbTypeF_24s182(heff_intAdd(v_len_240, v_i_243), heff_dup(v_fty_2419)));
      V v_t_2422 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2421; V r_ = (g_heff_2erules_2ementionsTypeF_24s427(a_0, a_1)); heff_drop(v_t_2421); r_; });
      switch (heff_tag_of(v_t_2422)) {
      case TAG_True: {
        heff_drop(v_fty_2419);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        return heff_tag(TAG_Just, 1, (V[]){v_fty_2419});
      }
      default: return heff_nomatch(v_t_2422);
      }
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2erules_2efieldTyAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2efieldTyAt(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2erules_2efieldTyAt_lam0(V self, V *args) {
  V v_u_2412 = args[0];
  V v_fty_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2412);
  return v_fty_249;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[59]; } g_heff_2erules_2erecordElim_str0 = {{0x80000000u, K_STR, 0}, 59, 59, {116, 114, 105, 101, 100, 32, 116, 111, 32, 112, 114, 111, 106, 101, 99, 116, 32, 102, 114, 111, 109, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[59]; } g_heff_2erules_2erecordElim_str1 = {{0x80000000u, K_STR, 0}, 59, 59, {116, 114, 105, 101, 100, 32, 116, 111, 32, 112, 114, 111, 106, 101, 99, 116, 32, 102, 114, 111, 109, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2erules_2erecordElim_str2 = {{0x80000000u, K_STR, 0}, 14, 14, {110, 111, 32, 115, 117, 99, 104, 32, 102, 105, 101, 108, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2erules_2erecordElim_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {32, 105, 110, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2erules_2erecordElim_str4 = {{0x80000000u, K_STR, 0}, 14, 14, {116, 104, 101, 32, 116, 121, 112, 101, 32, 111, 102, 32, 96, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[79]; } g_heff_2erules_2erecordElim_str5 = {{0x80000000u, K_STR, 0}, 79, 79, {96, 32, 100, 101, 112, 101, 110, 100, 115, 32, 111, 110, 32, 116, 104, 101, 32, 102, 105, 101, 108, 100, 115, 32, 98, 101, 102, 111, 114, 101, 32, 105, 116, 44, 32, 97, 110, 100, 32, 119, 104, 97, 116, 32, 116, 104, 105, 115, 32, 114, 101, 99, 111, 114, 100, 39, 115, 32, 97, 114, 101, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 32, 104, 101, 114, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[59]; } g_heff_2erules_2erecordElim_str6 = {{0x80000000u, K_STR, 0}, 59, 59, {116, 114, 105, 101, 100, 32, 116, 111, 32, 112, 114, 111, 106, 101, 99, 116, 32, 102, 114, 111, 109, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[59]; } g_heff_2erules_2erecordElim_str7 = {{0x80000000u, K_STR, 0}, 59, 59, {116, 114, 105, 101, 100, 32, 116, 111, 32, 112, 114, 111, 106, 101, 99, 116, 32, 102, 114, 111, 109, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[59]; } g_heff_2erules_2erecordElim_str8 = {{0x80000000u, K_STR, 0}, 59, 59, {116, 114, 105, 101, 100, 32, 116, 111, 32, 112, 114, 111, 106, 101, 99, 116, 32, 102, 114, 111, 109, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[59]; } g_heff_2erules_2erecordElim_str9 = {{0x80000000u, K_STR, 0}, 59, 59, {116, 114, 105, 101, 100, 32, 116, 111, 32, 112, 114, 111, 106, 101, 99, 116, 32, 102, 114, 111, 109, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[59]; } g_heff_2erules_2erecordElim_str10 = {{0x80000000u, K_STR, 0}, 59, 59, {116, 114, 105, 101, 100, 32, 116, 111, 32, 112, 114, 111, 106, 101, 99, 116, 32, 102, 114, 111, 109, 32, 97, 32, 118, 97, 108, 117, 101, 32, 116, 104, 97, 116, 32, 119, 97, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2erecordElim_str11 = {{0x80000000u, K_STR, 0}, 45, 45, {116, 104, 101, 32, 114, 101, 99, 111, 114, 100, 39, 115, 32, 115, 104, 97, 112, 101, 32, 105, 115, 32, 110, 111, 116, 32, 105, 110, 32, 104, 97, 110, 100, 32, 104, 101, 114, 101, 32, 102, 111, 114, 32, 96, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[84]; } g_heff_2erules_2erecordElim_str12 = {{0x80000000u, K_STR, 0}, 84, 84, {96, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 116, 104, 101, 32, 98, 105, 110, 100, 101, 114, 44, 32, 96, 92, 40, 120, 32, 58, 32, 84, 41, 32, 45, 62, 32, 46, 46, 46, 96, 44, 32, 111, 114, 32, 103, 105, 118, 101, 32, 116, 104, 101, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116, 44, 32, 96, 40, 97, 32, 58, 61, 32, 84, 41, 96}};
V g_heff_2erules_2erecordElim_lam3(V self, V *args);
V g_heff_2erules_2erecordElim_lam5(V self, V *args);
V g_heff_2erules_2erecordElim_lam6(V self, V *args);
V g_heff_2erules_2erecordElim_lam7(V self, V *args);
V g_heff_2erules_2erecordElim_lam8(V self, V *args);
V g_heff_2erules_2erecordElim_lam9(V self, V *args);
V g_heff_2erules_2erecordElim_lam10(V self, V *args);
V g_heff_2erules_2erecordElim_lam11(V self, V *args);
V g_heff_2erules_2erecordElim_lam12(V self, V *args);
V g_heff_2erules_2erecordElim_lam13(V self, V *args);
V g_heff_2erules_2erecordElim_lam14(V self, V *args);
V g_heff_2erules_2erecordElim_lam4(V self, V *args);
V g_heff_2erules_2erecordElim_lam2(V self, V *args);
V g_heff_2erules_2erecordElim_lam1(V self, V *args);
V g_heff_2erules_2erecordElim_lam0(V self, V *args);
Clo g_heff_2erules_2erecordElim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erecordElim_entry, 3, 0};

V g_heff_2erules_2erecordElim(V v_sp_240, V v_projectee_241, V v_x_242) {
top: ;
  return heff_tag(TAG_MkSyn, 1, (V[]){heff_clo(g_heff_2erules_2erecordElim_lam0, 1, 3, (V[]){heff_dup(v_projectee_241), v_sp_240, v_x_242})});
}
V g_heff_2erules_2erecordElim_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2erecordElim(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2erules_2erecordElim_lam3(V self, V *args) {
  V v_c_2411 = args[0];
  V v_a0_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_2411, LBL_metas); V a_1 = v_a0_2410; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2erules_2erecordElim_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    return heff_tail(heff_dup(g_heff_2erules_2eerrorOf_get()), 2, (V[]){v_hd_246, v_k_247});
  }
  case TAG_False: {
    V v_t_2419 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordElim_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2420 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2421}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2422, v_k_247});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2erules_2erecordElim_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2427)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    return heff_tail(heff_dup(g_heff_2erules_2eerrorOf_get()), 2, (V[]){v_hd_246, v_k_247});
  }
  case TAG_False: {
    V v_t_2428 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordElim_str1), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2429 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2430}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2431, v_k_247});
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2erules_2erecordElim_lam7(V self, V *args) {
  V v_x_2462 = args[0];
  V v_eprojectee_249 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_fieldTy_2461 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2462);
  V v_t_2463 = (g_heff_2ememoed_2eprojAt(v_eprojectee_249, v_x_242, heff_dup(v_fieldTy_2461)));
  V f_ = v_k_247;
  args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_t_2463, v_fieldTy_2461});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2erecordElim_lam8(V self, V *args) {
  V v_x_2465 = args[0];
  V v_eprojectee_249 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_fieldTy_2464 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2465);
  V v_t_2466 = (g_heff_2ememoed_2eproj(v_eprojectee_249, v_x_242));
  V f_ = v_k_247;
  args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_t_2466, v_fieldTy_2464});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2erecordElim_lam9(V self, V *args) {
  V v_x_2468 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2468)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    return heff_tail(heff_dup(g_heff_2erules_2eerrorOf_get()), 2, (V[]){v_hd_246, v_k_247});
  }
  case TAG_False: {
    V v_t_2469 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordElim_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2470 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2471}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2472, v_k_247});
  }
  default: return heff_nomatch(v_x_2468);
  }
}
V g_heff_2erules_2erecordElim_lam10(V self, V *args) {
  V v_x_2473 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2473)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    return heff_tail(heff_dup(g_heff_2erules_2eerrorOf_get()), 2, (V[]){v_hd_246, v_k_247});
  }
  case TAG_False: {
    V v_t_2474 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordElim_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2475 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2476}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2477, v_k_247});
  }
  default: return heff_nomatch(v_x_2473);
  }
}
V g_heff_2erules_2erecordElim_lam11(V self, V *args) {
  V v_x_2478 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2478)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    return heff_tail(heff_dup(g_heff_2erules_2eerrorOf_get()), 2, (V[]){v_hd_246, v_k_247});
  }
  case TAG_False: {
    V v_t_2479 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordElim_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2480 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2481}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2482, v_k_247});
  }
  default: return heff_nomatch(v_x_2478);
  }
}
V g_heff_2erules_2erecordElim_lam12(V self, V *args) {
  V v_x_2483 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2483)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    return heff_tail(heff_dup(g_heff_2erules_2eerrorOf_get()), 2, (V[]){v_hd_246, v_k_247});
  }
  case TAG_False: {
    V v_t_2484 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordElim_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2485 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2484})});
    V v_t_2486 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2485})});
    V v_t_2487 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2486}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2487, v_k_247});
  }
  default: return heff_nomatch(v_x_2483);
  }
}
V g_heff_2erules_2erecordElim_lam13(V self, V *args) {
  V v_x_2489 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2489)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    return heff_tail(heff_dup(g_heff_2erules_2eerrorOf_get()), 2, (V[]){v_hd_246, v_k_247});
  }
  case TAG_False: {
    V v_t_2490 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordElim_str10), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2491 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2491})});
    V v_t_2493 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2492}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2493, v_k_247});
  }
  default: return heff_nomatch(v_x_2489);
  }
}
V g_heff_2erules_2erecordElim_lam14(V self, V *args) {
  V v_x_2494 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2494)) {
  case TAG_True: {
    heff_drop(v_x_242);
    heff_drop(v_sp_240);
    return heff_tail(heff_dup(g_heff_2erules_2eerrorOf_get()), 2, (V[]){v_hd_246, v_k_247});
  }
  case TAG_False: {
    V v_t_2495 = heff_strAppend(((V)&g_heff_2erules_2erecordElim_str11), heff_strAppend(v_x_242, ((V)&g_heff_2erules_2erecordElim_str12)));
    V v_t_2496 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(332LL), NTAG(TAG_SError), v_t_2495, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2497 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2496})});
    V v_t_2498 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2497})});
    V v_t_2499 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2498}));
    return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2499, v_k_247});
  }
  default: return heff_nomatch(v_x_2494);
  }
}
V g_heff_2erules_2erecordElim_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  V v_eprojectee_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2416 = (g_heff_2evalue_2ebehavior(heff_dup(v_x_2415)));
  switch (heff_tag_of(v_t_2416)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2416, 0ULL, 1);
    heff_drop(v_x_242);
    heff_drop(v_e_243);
    heff_drop(v_eprojectee_249);
    return (g_heff_2emeta_2eblockedTy(v_x_2415, heff_dup(v_hd_246), heff_clo(g_heff_2erules_2erecordElim_lam5, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2416, 0ULL, 4);
    heff_drop(v_x_242);
    heff_drop(v_e_243);
    heff_drop(v_eprojectee_249);
    return (g_heff_2emeta_2eblockedTy(v_x_2415, heff_dup(v_hd_246), heff_clo(g_heff_2erules_2erecordElim_lam6, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeRecord: {
    V v_capture_2433 = heff_field(v_t_2416, 1);
    V v_fieldTypes_2434 = heff_field(v_t_2416, 2);
    heff_take_n(v_t_2416, 6ULL, 3);
    V v_x3_2435 = ({ V a_0 = heff_dup(v_x_242); V b_1 = heff_get(heff_dup(v_fieldTypes_2434), LBL_byName); V r_ = (g_map_2elookup_24s9(a_0, b_1)); heff_drop(b_1); r_; });
    V v_x1_2437;
    switch (heff_tag_of(v_x3_2435)) {
    case TAG_Nothing: {
      v_x1_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_2435, 0ULL, 1);
      v_x1_2437 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_2435);
    }
    V v_t_2438;
    switch (heff_tag_of(v_x1_2437)) {
    case TAG_True: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_2437);
    }
    switch (heff_tag_of(v_t_2438)) {
    case TAG_True: {
      heff_drop(v_eprojectee_249);
      heff_drop(v_capture_2433);
      heff_drop(v_fieldTypes_2434);
      V v_msg_2439 = heff_strAppend(((V)&g_heff_2erules_2erecordElim_str2), heff_strAppend(v_x_242, heff_strAppend(((V)&g_heff_2erules_2erecordElim_str3), (g_heff_2erules_2etyStr(v_e_243, v_x_2415)))));
      V v_t_2440 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(307LL), NTAG(TAG_SError), v_msg_2439, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2441 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2441})});
      V v_t_2443 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2442}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2443, v_k_247});
    }
    case TAG_False: {
      V v_x1_2444 = heff_tr(heff_apply(heff_get(heff_dup(v_eprojectee_249), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_v_2448;
      switch (heff_tag_of(v_x1_2444)) {
      case TAG_Nom: {
        V v_x_2445 = heff_field(v_x1_2444, 0);
        heff_take_n(v_x1_2444, 1ULL, 1);
        v_v_2448 = v_x_2445;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2444, 0ULL, 1);
        v_v_2448 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2447 = heff_field(v_x1_2444, 0);
        heff_take_n(v_x1_2444, 1ULL, 1);
        v_v_2448 = v_x_2447;
        break;
      }
      default: heff_nomatch(v_x1_2444);
      }
      V v_t_2449 = (g_heff_2evalue_2ecoerceToFieldsMaybe(v_v_2448));
      V v_t_2450 = (g_heff_2evalue_2eprojTyWith(heff_dup(v_x_2415), v_t_2449, heff_dup(v_x_242)));
      switch (heff_tag_of(v_t_2450)) {
      case TAG_Nothing: {
        V v_t_2451 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_len);
        V v_t_2452 = ({ V a_0 = heff_dup(v_x_242); V b_1 = heff_get(heff_dup(v_fieldTypes_2434), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
        V v_t_2454;
        switch (heff_tag_of(v_t_2452)) {
        case TAG_Nothing: {
          v_t_2454 = heff_abandon();
          break;
        }
        case TAG_Just: {
          V v_i_2453 = heff_field(v_t_2452, 0);
          heff_take_n(v_t_2452, 1ULL, 1);
          v_t_2454 = v_i_2453;
          break;
        }
        default: heff_nomatch(v_t_2452);
        }
        V v_t_2455 = (g_heff_2erules_2efieldTyAt(v_t_2451, v_capture_2433, v_fieldTypes_2434, v_t_2454, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
        switch (heff_tag_of(v_t_2455)) {
        case TAG_Nothing: {
          heff_drop(v_x_2415);
          heff_drop(v_e_243);
          heff_drop(v_eprojectee_249);
          V v_t_2456 = heff_strAppend(((V)&g_heff_2erules_2erecordElim_str4), heff_strAppend(v_x_242, ((V)&g_heff_2erules_2erecordElim_str5)));
          V v_t_2457 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(332LL), NTAG(TAG_SError), v_t_2456, v_sp_240, NTAG(TAG_Nothing)});
          V v_t_2458 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2457})});
          V v_t_2459 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2458})});
          V v_t_2460 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2459}));
          return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2460, v_k_247});
        }
        case TAG_Just: {
          V v_fieldTy_2461 = heff_field(v_t_2455, 0);
          heff_take_n(v_t_2455, 1ULL, 1);
          return ({ V a_0 = v_e_243; V a_1 = v_x_2415; V a_2 = heff_dup(v_x_242); V a_3 = v_sp_240; V a_4 = heff_dup(v_fieldTy_2461); V a_5 = v_hd_246; V a_6 = heff_clo(g_heff_2erules_2erecordElim_lam7, 1, 4, (V[]){v_eprojectee_249, v_x_242, v_fieldTy_2461, v_k_247}); V r_ = (g_heff_2erules_2erecordName(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2415); r_; });
        }
        default: return heff_nomatch(v_t_2455);
        }
      }
      case TAG_Just: {
        V v_fieldTy_2464 = heff_field(v_t_2450, 0);
        heff_take_n(v_t_2450, 1ULL, 1);
        heff_drop(v_capture_2433);
        heff_drop(v_fieldTypes_2434);
        return ({ V a_0 = v_e_243; V a_1 = v_x_2415; V a_2 = heff_dup(v_x_242); V a_3 = v_sp_240; V a_4 = heff_dup(v_fieldTy_2464); V a_5 = v_hd_246; V a_6 = heff_clo(g_heff_2erules_2erecordElim_lam8, 1, 4, (V[]){v_eprojectee_249, v_x_242, v_k_247, v_fieldTy_2464}); V r_ = (g_heff_2erules_2erecordName(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2415); r_; });
      }
      default: return heff_nomatch(v_t_2450);
      }
    }
    default: return heff_nomatch(v_t_2438);
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2416, 0ULL, 1);
    heff_drop(v_x_242);
    heff_drop(v_e_243);
    heff_drop(v_eprojectee_249);
    return (g_heff_2emeta_2eblockedTy(v_x_2415, heff_dup(v_hd_246), heff_clo(g_heff_2erules_2erecordElim_lam9, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeInt: {
    heff_drop(v_x_242);
    heff_drop(v_e_243);
    heff_drop(v_eprojectee_249);
    return (g_heff_2emeta_2eblockedTy(v_x_2415, heff_dup(v_hd_246), heff_clo(g_heff_2erules_2erecordElim_lam10, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_242);
    heff_drop(v_e_243);
    heff_drop(v_eprojectee_249);
    return (g_heff_2emeta_2eblockedTy(v_x_2415, heff_dup(v_hd_246), heff_clo(g_heff_2erules_2erecordElim_lam11, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeString: {
    heff_drop(v_x_242);
    heff_drop(v_e_243);
    heff_drop(v_eprojectee_249);
    return (g_heff_2emeta_2eblockedTy(v_x_2415, heff_dup(v_hd_246), heff_clo(g_heff_2erules_2erecordElim_lam12, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2416, 0ULL, 1);
    heff_drop(v_x_242);
    heff_drop(v_e_243);
    heff_drop(v_eprojectee_249);
    return (g_heff_2emeta_2eblockedTy(v_x_2415, heff_dup(v_hd_246), heff_clo(g_heff_2erules_2erecordElim_lam13, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_NoRules: {
    heff_drop(v_e_243);
    heff_drop(v_eprojectee_249);
    return (g_heff_2emeta_2eblockedTy(v_x_2415, heff_dup(v_hd_246), heff_clo(g_heff_2erules_2erecordElim_lam14, 1, 4, (V[]){v_hd_246, v_k_247, v_x_242, v_sp_240})));
  }
  default: return heff_nomatch(v_t_2416);
  }
}
V g_heff_2erules_2erecordElim_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_248)) {
  case TAG_MkPair: {
    V v_eprojectee_249 = heff_field(v_x_248, 0);
    V v_a0_2410 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 2);
    V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2erecordElim_lam3, 1, 1, (V[]){v_a0_2410})})});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2413}));
    return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2erules_2erecordElim_lam4, 1, 6, (V[]){v_hd_246, v_k_247, v_sp_240, v_x_242, v_e_243, v_eprojectee_249})});
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2erules_2erecordElim_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo(g_heff_2erules_2erecordElim_lam2, 1, 5, (V[]){v_hd_246, v_k_247, v_sp_240, v_x_242, v_e_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2erecordElim_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_projectee_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245;
  switch (heff_tag_of(v_projectee_241)) {
  case TAG_MkSyn: {
    V v_f_244 = heff_field(v_projectee_241, 0);
    heff_take_n(v_projectee_241, 1ULL, 1);
    v_c_245 = heff_tr(heff_apply(v_f_244, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_projectee_241);
  }
  return heff_clo(g_heff_2erules_2erecordElim_lam1, 2, 4, (V[]){v_c_245, v_sp_240, v_x_242, v_e_243});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2erecordSpec_str0 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2erecordSpec_str1 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2erecordSpec_str2 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2erecordSpec_str3 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2erecordSpec_str4 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2erules_2erecordSpec_str5 = {{0x80000000u, K_STR, 0}, 14, 14, {110, 111, 32, 115, 117, 99, 104, 32, 102, 105, 101, 108, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2erecordSpec_str6 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2erecordSpec_str7 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2erecordSpec_str8 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2erecordSpec_str9 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2erecordSpec_str10 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2erecordSpec_str11 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2erecordSpec_str12 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2erecordSpec_str13 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 116, 121, 112, 101, 32, 119, 105, 116, 104, 32, 114, 101, 99, 111, 114, 100, 32, 98, 101, 104, 97, 118, 105, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2erules_2erecordSpec_str14 = {{0x80000000u, K_STR, 0}, 27, 27, {99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 110, 101, 117, 116, 114, 97, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2erules_2erecordSpec_str15 = {{0x80000000u, K_STR, 0}, 27, 27, {99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 110, 101, 117, 116, 114, 97, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2erules_2erecordSpec_str16 = {{0x80000000u, K_STR, 0}, 27, 27, {99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 110, 101, 117, 116, 114, 97, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2erules_2erecordSpec_str17 = {{0x80000000u, K_STR, 0}, 27, 27, {99, 97, 110, 32, 111, 110, 108, 121, 32, 115, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32, 110, 101, 117, 116, 114, 97, 108}};
V g_heff_2erules_2erecordSpec_lam3(V self, V *args);
V g_heff_2erules_2erecordSpec_lam2(V self, V *args);
V g_heff_2erules_2erecordSpec_lam1(V self, V *args);
V g_heff_2erules_2erecordSpec_lam0(V self, V *args);
Clo g_heff_2erules_2erecordSpec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erecordSpec_entry, 4, 0};

V g_heff_2erules_2erecordSpec(V v_sp_240, V v_s_241, V v_x_242, V v_c_243) {
top: ;
  return heff_tag(TAG_MkSyn, 1, (V[]){heff_clo(g_heff_2erules_2erecordSpec_lam0, 1, 4, (V[]){heff_dup(v_s_241), v_sp_240, v_x_242, heff_dup(v_c_243)})});
}
V g_heff_2erules_2erecordSpec_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2erecordSpec(a[0], a[1], a[2], a[3]); heff_drop(a[1]); heff_drop(a[3]); return r;
}
V g_heff_2erules_2erecordSpec_lam3(V self, V *args) {
  V v_x_2479 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  V v_a_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2480 = (g_heff_2ememoed_2especializeM(v_g_2410, v_x_242, v_x_2479));
  V f_ = v_k_248;
  args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_t_2480, v_a_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2erecordSpec_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_c_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_g_2410 = heff_field(v_x_249, 0);
    V v_a_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    V v_x1_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_g_2410), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2416;
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_Nom: {
      V v_x_2413 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      v_t_2416 = v_x_2413;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2412, 0ULL, 1);
      v_t_2416 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2415 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      v_t_2416 = v_x_2415;
      break;
    }
    default: heff_nomatch(v_x1_2412);
    }
    switch (heff_tag_of(v_t_2416)) {
    case TAG_VNeu: {
      V v_desc_2421 = heff_field(v_t_2416, 4);
      heff_take_n(v_t_2416, 16ULL, 5);
      V v_it_2422 = heff_tr(heff_apply(v_desc_2421, 1, (V[]){NTAG(TAG_MkUnit)}));
      switch (heff_tag_of(v_it_2422)) {
      case TAG_Nothing: {
        heff_drop(v_x_242);
        heff_drop(v_e_244);
        heff_drop(v_c_243);
        heff_drop(v_g_2410);
        heff_drop(v_a_2411);
        V v_t_2423 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordSpec_str0), v_sp_240, NTAG(TAG_Nothing)});
        V v_t_2424 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2423})});
        V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
        V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2425}));
        return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2426, v_k_248});
      }
      case TAG_Just: {
        V v_it1_2427 = heff_field(v_it_2422, 0);
        V v_ru_24it_2422_24Just = heff_take_reuse_n(v_it_2422, 1ULL, 1);
        switch (heff_tag_of(v_it1_2427)) {
        case TAG_VNeu: {
          heff_take_n(v_it1_2427, 0ULL, 5);
          heff_drop(v_x_242);
          heff_drop(v_e_244);
          heff_drop(v_c_243);
          heff_drop(v_g_2410);
          heff_drop(v_a_2411);
          V v_t_2433 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordSpec_str1), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_2434 = heff_tag_at(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2433})});
          V v_t_2435 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2434})});
          V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2435}));
          return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2436, v_k_248});
        }
        case TAG_VCode: {
          V v_it11_2437 = heff_field(v_it1_2427, 0);
          V v_ru_24it1_2427_24VCode = heff_take_reuse_n(v_it1_2427, 1ULL, 1);
          switch (heff_tag_of(v_it11_2437)) {
          case TAG_VU: {
            heff_take_n(v_it11_2437, 0ULL, 1);
            heff_drop(v_x_242);
            heff_drop(v_e_244);
            heff_drop(v_c_243);
            heff_drop(v_g_2410);
            heff_drop(v_a_2411);
            V v_t_2439 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordSpec_str2), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2440 = heff_tag_at(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2439})});
            V v_t_2441 = heff_tag_at(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2440})});
            V v_t_2442 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2441}));
            return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2442, v_k_248});
          }
          case TAG_VDecode: {
            heff_take_n(v_it11_2437, 0ULL, 5);
            heff_drop(v_x_242);
            heff_drop(v_e_244);
            heff_drop(v_c_243);
            heff_drop(v_g_2410);
            heff_drop(v_a_2411);
            V v_t_2448 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordSpec_str3), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2449 = heff_tag_at(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2448})});
            V v_t_2450 = heff_tag_at(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2449})});
            V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2450}));
            return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2451, v_k_248});
          }
          case TAG_VFunction: {
            heff_take_n(v_it11_2437, 0ULL, 4);
            heff_drop(v_x_242);
            heff_drop(v_e_244);
            heff_drop(v_c_243);
            heff_drop(v_g_2410);
            heff_drop(v_a_2411);
            V v_t_2456 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordSpec_str4), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2457 = heff_tag_at(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2456})});
            V v_t_2458 = heff_tag_at(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2457})});
            V v_t_2459 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2458}));
            return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2459, v_k_248});
          }
          case TAG_VRecord: {
            V v_capture_2461 = heff_field(v_it11_2437, 1);
            V v_fieldTypes_2462 = heff_field(v_it11_2437, 2);
            heff_take_n(v_it11_2437, 6ULL, 4);
            V v_x3_2464 = ({ V a_0 = heff_dup(v_x_242); V b_1 = heff_get(heff_dup(v_fieldTypes_2462), LBL_byName); V r_ = (g_map_2elookup_24s9(a_0, b_1)); heff_drop(b_1); r_; });
            V v_t_2466;
            switch (heff_tag_of(v_x3_2464)) {
            case TAG_Nothing: {
              v_t_2466 = NTAG(TAG_False);
              break;
            }
            case TAG_Just: {
              heff_take_n(v_x3_2464, 0ULL, 1);
              v_t_2466 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_x3_2464);
            }
            switch (heff_tag_of(v_t_2466)) {
            case TAG_True: {
              heff_drop(v_sp_240);
              heff_drop_cell(v_ru_24it1_2427_24VCode, 1);
              V v_t_2467 = heff_get(heff_get(heff_dup(v_e_244), LBL_scope), LBL_len);
              V v_t_2468 = heff_arrayToList(heff_get(heff_dup(v_fieldTypes_2462), LBL_keys));
              V v_t_2469 = heff_arrayToList(heff_get(heff_dup(v_fieldTypes_2462), LBL_values));
              V v_t_2470 = (g_heff_2edict_2ezipKV(v_t_2468, v_t_2469));
              V v_xs_2471 = (g_heff_2evalue_2egoER_24s429(heff_dup(v_capture_2461), heff_tag_at(v_ru_24it_2422_24Just, TAG_HLocal, 1, (V[]){v_t_2467}), NTAG(TAG_SpId), NTAG(TAG_Nothing), v_t_2470, NTAG(TAG_Nil)));
              V v_t_2472 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2471));
              V v_t_2473 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_fieldTypes_2462), LBL_keys), heff_get(heff_dup(v_fieldTypes_2462), LBL_byName), heff_arrayFromList(v_t_2472)});
              V v_t_2474 = heff_tr(g_heff_2evalue_2etypeForProjection(v_capture_2461, v_fieldTypes_2462, heff_dup(v_x_242), v_t_2473));
              switch (heff_tag_of(v_t_2474)) {
              case TAG_MkField: {
                V v_fty_2475 = heff_field(v_t_2474, 0);
                heff_take_n(v_t_2474, 1ULL, 2);
                V v_c_2478;
                switch (heff_tag_of(v_c_243)) {
                case TAG_MkChk: {
                  V v_f_2477 = heff_field(v_c_243, 0);
                  heff_take_n(v_c_243, 1ULL, 1);
                  v_c_2478 = heff_tr(heff_apply(v_f_2477, 2, (V[]){v_e_244, v_fty_2475}));
                  break;
                }
                default: heff_nomatch(v_c_243);
                }
                return heff_tail(v_c_2478, 2, (V[]){v_hd_247, heff_clo(g_heff_2erules_2erecordSpec_lam3, 1, 4, (V[]){v_g_2410, v_x_242, v_k_248, v_a_2411})});
              }
              default: return heff_nomatch(v_t_2474);
              }
            }
            case TAG_False: {
              heff_drop(v_e_244);
              heff_drop(v_c_243);
              heff_drop(v_g_2410);
              heff_drop(v_a_2411);
              heff_drop(v_capture_2461);
              heff_drop(v_fieldTypes_2462);
              V v_t_2481 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(322LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2erules_2erecordSpec_str5), v_x_242), v_sp_240, NTAG(TAG_Nothing)});
              V v_t_2482 = heff_tag_at(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2481})});
              V v_t_2483 = heff_tag_at(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2482})});
              V v_t_2484 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2483}));
              return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2484, v_k_248});
            }
            default: return heff_nomatch(v_t_2466);
            }
          }
          case TAG_VSum: {
            heff_take_n(v_it11_2437, 0ULL, 1);
            heff_drop(v_x_242);
            heff_drop(v_e_244);
            heff_drop(v_c_243);
            heff_drop(v_g_2410);
            heff_drop(v_a_2411);
            V v_t_2486 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordSpec_str6), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2487 = heff_tag_at(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2486})});
            V v_t_2488 = heff_tag_at(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2487})});
            V v_t_2489 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2488}));
            return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2489, v_k_248});
          }
          case TAG_VPrimInt: {
            heff_drop(v_x_242);
            heff_drop(v_e_244);
            heff_drop(v_c_243);
            heff_drop(v_g_2410);
            heff_drop(v_a_2411);
            V v_t_2490 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordSpec_str7), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2491 = heff_tag_at(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2490})});
            V v_t_2492 = heff_tag_at(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2491})});
            V v_t_2493 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2492}));
            return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2493, v_k_248});
          }
          case TAG_VPrimFloat: {
            heff_drop(v_x_242);
            heff_drop(v_e_244);
            heff_drop(v_c_243);
            heff_drop(v_g_2410);
            heff_drop(v_a_2411);
            V v_t_2494 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordSpec_str8), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2495 = heff_tag_at(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2494})});
            V v_t_2496 = heff_tag_at(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2495})});
            V v_t_2497 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2496}));
            return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2497, v_k_248});
          }
          case TAG_VPrimString: {
            heff_drop(v_x_242);
            heff_drop(v_e_244);
            heff_drop(v_c_243);
            heff_drop(v_g_2410);
            heff_drop(v_a_2411);
            V v_t_2498 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordSpec_str9), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2499 = heff_tag_at(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2498})});
            V v_t_24100 = heff_tag_at(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2499})});
            V v_t_24101 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_24100}));
            return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_24101, v_k_248});
          }
          case TAG_VPrimArray: {
            heff_take_n(v_it11_2437, 0ULL, 1);
            heff_drop(v_x_242);
            heff_drop(v_e_244);
            heff_drop(v_c_243);
            heff_drop(v_g_2410);
            heff_drop(v_a_2411);
            V v_t_24103 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordSpec_str10), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24104 = heff_tag_at(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24103})});
            V v_t_24105 = heff_tag_at(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24104})});
            V v_t_24106 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_24105}));
            return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_24106, v_k_248});
          }
          default: return heff_nomatch(v_it11_2437);
          }
        }
        case TAG_VLam: {
          heff_take_n(v_it1_2427, 0ULL, 2);
          heff_drop(v_x_242);
          heff_drop(v_e_244);
          heff_drop(v_c_243);
          heff_drop(v_g_2410);
          heff_drop(v_a_2411);
          V v_t_24109 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordSpec_str11), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_24110 = heff_tag_at(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24109})});
          V v_t_24111 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24110})});
          V v_t_24112 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_24111}));
          return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_24112, v_k_248});
        }
        case TAG_VCons: {
          V v_ru_24it1_2427_24VCons = heff_take_reuse_n(v_it1_2427, 0ULL, 1);
          heff_drop(v_x_242);
          heff_drop(v_e_244);
          heff_drop(v_c_243);
          heff_drop(v_g_2410);
          heff_drop(v_a_2411);
          V v_t_24114 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordSpec_str12), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_24115 = heff_tag_at(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24114})});
          V v_t_24116 = heff_tag_at(v_ru_24it1_2427_24VCons, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24115})});
          V v_t_24117 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_24116}));
          return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_24117, v_k_248});
        }
        case TAG_VOpaque: {
          heff_drop(v_x_242);
          heff_drop(v_e_244);
          heff_drop(v_c_243);
          heff_drop(v_g_2410);
          heff_drop(v_a_2411);
          V v_t_24118 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordSpec_str13), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_24119 = heff_tag_at(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24118})});
          V v_t_24120 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24119})});
          V v_t_24121 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_24120}));
          return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_24121, v_k_248});
        }
        default: return heff_nomatch(v_it1_2427);
        }
      }
      default: return heff_nomatch(v_it_2422);
      }
    }
    case TAG_VCode: {
      V v_ru_24t_2416_24VCode = heff_take_reuse_n(v_t_2416, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop(v_e_244);
      heff_drop(v_c_243);
      heff_drop(v_g_2410);
      heff_drop(v_a_2411);
      V v_t_24123 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordSpec_str14), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24124 = heff_tag_at(v_ru_24t_2416_24VCode, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24123})});
      V v_t_24125 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24124})});
      V v_t_24126 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_24125}));
      return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_24126, v_k_248});
    }
    case TAG_VLam: {
      heff_take_n(v_t_2416, 0ULL, 2);
      heff_drop(v_x_242);
      heff_drop(v_e_244);
      heff_drop(v_c_243);
      heff_drop(v_g_2410);
      heff_drop(v_a_2411);
      V v_t_24129 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordSpec_str15), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24130 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24129})});
      V v_t_24131 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24130})});
      V v_t_24132 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_24131}));
      return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_24132, v_k_248});
    }
    case TAG_VCons: {
      V v_ru_24t_2416_24VCons = heff_take_reuse_n(v_t_2416, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop(v_e_244);
      heff_drop(v_c_243);
      heff_drop(v_g_2410);
      heff_drop(v_a_2411);
      V v_t_24134 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordSpec_str16), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24135 = heff_tag_at(v_ru_24t_2416_24VCons, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24134})});
      V v_t_24136 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24135})});
      V v_t_24137 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_24136}));
      return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_24137, v_k_248});
    }
    case TAG_VOpaque: {
      heff_drop(v_x_242);
      heff_drop(v_e_244);
      heff_drop(v_c_243);
      heff_drop(v_g_2410);
      heff_drop(v_a_2411);
      V v_t_24138 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2erecordSpec_str17), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24139 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24138})});
      V v_t_24140 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24139})});
      V v_t_24141 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_24140}));
      return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_24141, v_k_248});
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2erules_2erecordSpec_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_e_244 = heff_env(self)[3];
  V v_c_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2erules_2erecordSpec_lam2, 1, 6, (V[]){v_sp_240, v_hd_247, v_k_248, v_x_242, v_e_244, v_c_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2erecordSpec_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_c_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246;
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_246 = heff_tr(heff_apply(v_f_245, 1, (V[]){heff_dup(v_e_244)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo(g_heff_2erules_2erecordSpec_lam1, 2, 5, (V[]){v_c_246, v_sp_240, v_x_242, v_e_244, v_c_243});
}
V g_heff_2erules_2etraverseE_lam0(V self, V *args); static Clo g_heff_2erules_2etraverseE_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2etraverseE_lam0, 2, 0};
V g_heff_2erules_2etraverseE_lam3(V self, V *args);
V g_heff_2erules_2etraverseE_lam2(V self, V *args);
V g_heff_2erules_2etraverseE_lam1(V self, V *args);
Clo g_heff_2erules_2etraverseE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2etraverseE_entry, 2, 0};

V g_heff_2erules_2etraverseE(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2erules_2etraverseE_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo(g_heff_2erules_2etraverseE_lam1, 2, 3, (V[]){v_c_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2erules_2etraverseE_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2etraverseE(a[0], a[1]);
}
V g_heff_2erules_2etraverseE_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2etraverseE_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_x_249, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2etraverseE_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2erules_2etraverseE(v_f_240, v_xs_245));
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2erules_2etraverseE_lam3, 1, 2, (V[]){v_k_248, v_x_249})});
}
V g_heff_2erules_2etraverseE_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2erules_2etraverseE_lam2, 1, 4, (V[]){v_f_240, v_xs_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2esumFormation_lam2(V self, V *args);
V g_heff_2erules_2esumFormation_lam4(V self, V *args);
V g_heff_2erules_2esumFormation_lam3(V self, V *args);
V g_heff_2erules_2esumFormation_lam1(V self, V *args);
V g_heff_2erules_2esumFormation_lam6(V self, V *args);
V g_heff_2erules_2esumFormation_lam5(V self, V *args);
V g_heff_2erules_2esumFormation_lam0(V self, V *args);
Clo g_heff_2erules_2esumFormation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2esumFormation_entry, 1, 0};

V g_heff_2erules_2esumFormation(V v_vs_240) {
top: ;
  return heff_tag(TAG_MkTyp, 1, (V[]){heff_clo(g_heff_2erules_2esumFormation_lam0, 1, 1, (V[]){v_vs_240})});
}
V g_heff_2erules_2esumFormation_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2esumFormation(a[0]);
}
V g_heff_2erules_2esumFormation_lam2(V self, V *args) {
  V v_t_248 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_e_249 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){heff_get(heff_dup(v_e_241), LBL_scope), heff_get(heff_dup(v_e_241), LBL_globals), NTAG(TAG_ForNominative), heff_get(heff_dup(v_e_241), LBL_lams), heff_get(heff_dup(v_e_241), LBL_self), heff_get(heff_dup(v_e_241), LBL_insts)});
  V v_sd_2410 = heff_get(v_e_241, LBL_scope);
  V v_t_2411 = heff_tag(TAG_CUndelay, 1, (V[]){heff_get(heff_dup(v_sd_2410), LBL_ctx)});
  V v_sc_2412 = heff_rec(4, shape_168_200_179_53, (V[]){heff_get(heff_dup(v_sd_2410), LBL_len), heff_get(heff_dup(v_sd_2410), LBL_names), heff_get(v_sd_2410, LBL_locals), v_t_2411});
  V v_e_2413 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){v_sc_2412, heff_get(heff_dup(v_e_249), LBL_globals), heff_get(heff_dup(v_e_249), LBL_elabFor), heff_get(heff_dup(v_e_249), LBL_lams), heff_get(heff_dup(v_e_249), LBL_self), heff_get(v_e_249, LBL_insts)});
  switch (heff_tag_of(v_t_248)) {
  case TAG_MkSmallTyp: {
    V v_f_2414 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 1);
    V f_ = v_f_2414;
    args[0] = v_e_2413;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2erules_2esumFormation_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tag(TAG_MkPair, 2, (V[]){v_k_246, heff_arrayFromList(v_x_2418)});
  V f_ = v_k_2417;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2esumFormation_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo(g_heff_2erules_2esumFormation_lam4, 1, 2, (V[]){v_k_246, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2esumFormation_lam1(V self, V *args) {
  V v_p_245 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_k_246 = heff_field(v_p_245, 0);
    V v_ts_247 = heff_field(v_p_245, 1);
    heff_take_n(v_p_245, 3ULL, 2);
    V v_c_2415 = (g_heff_2erules_2etraverseE(heff_clo(g_heff_2erules_2esumFormation_lam2, 1, 1, (V[]){v_e_241}), heff_arrayToList(v_ts_247)));
    return heff_clo(g_heff_2erules_2esumFormation_lam3, 2, 2, (V[]){v_c_2415, v_k_246});
  }
  default: return heff_nomatch(v_p_245);
  }
}
V g_heff_2erules_2esumFormation_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424 = (g_prelude_2emap_24s5(heff_dup(v_x_2423)));
  V v_t_2425 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_x_2423));
  V v_t_2426 = (g_prelude_2emap_24s6(v_x_2423));
  V v_t_2427 = heff_rec(3, shape_153_35_368, (V[]){heff_arrayFromList(v_t_2424), v_t_2425, heff_arrayFromList(v_t_2426)});
  V v_x_2428 = (g_heff_2ememoed_2esumM(v_t_2427));
  V f_ = v_k_2422;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2esumFormation_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2420;
  args[0] = v_hd_2421;
  args[1] = heff_clo(g_heff_2erules_2esumFormation_lam6, 1, 1, (V[]){v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2esumFormation_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_vs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = heff_arrayToList(heff_get(heff_dup(v_vs_240), LBL_keys));
  V v_t_243 = heff_arrayToList(heff_get(v_vs_240, LBL_values));
  V v_t_244 = (g_heff_2edict_2ezipKV(v_t_242, v_t_243));
  V v_c_2420 = (g_heff_2erules_2etraverseE(heff_clo(g_heff_2erules_2esumFormation_lam1, 1, 1, (V[]){v_e_241}), v_t_244));
  return heff_clo(g_heff_2erules_2esumFormation_lam5, 2, 1, (V[]){v_c_2420});
}
V g_heff_2erules_2etagArgsGo_lam0(V self, V *args); static Clo g_heff_2erules_2etagArgsGo_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2etagArgsGo_lam0, 2, 0};
V g_heff_2erules_2etagArgsGo_lam1(V self, V *args); static Clo g_heff_2erules_2etagArgsGo_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2etagArgsGo_lam1, 2, 0};
V g_heff_2erules_2etagArgsGo_lam2(V self, V *args); static Clo g_heff_2erules_2etagArgsGo_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2etagArgsGo_lam2, 2, 0};
V g_heff_2erules_2etagArgsGo_lam5(V self, V *args);
V g_heff_2erules_2etagArgsGo_lam4(V self, V *args);
V g_heff_2erules_2etagArgsGo_lam3(V self, V *args);
Clo g_heff_2erules_2etagArgsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2etagArgsGo_entry, 3, 0};

V g_heff_2erules_2etagArgsGo(V v_e_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      return ((V)&g_heff_2erules_2etagArgsGo_lam0_clo);
    }
    case TAG_Cons: {
      heff_take_n(v_x3_242, 0ULL, 2);
      return ((V)&g_heff_2erules_2etagArgsGo_lam1_clo);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_Cons: {
    V v_c_249 = heff_field(v_x2_241, 0);
    V v_cs_2410 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_e_240);
      heff_drop(v_c_249);
      heff_drop(v_cs_2410);
      return ((V)&g_heff_2erules_2etagArgsGo_lam2_clo);
    }
    case TAG_Cons: {
      V v_t_2413 = heff_field(v_x3_242, 0);
      V v_ts_2414 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_a_2415 = heff_tr(heff_apply(v_t_2413, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_c_2417;
      switch (heff_tag_of(v_c_249)) {
      case TAG_MkChk: {
        V v_f_2416 = heff_field(v_c_249, 0);
        heff_take_n(v_c_249, 1ULL, 1);
        v_c_2417 = heff_tr(heff_apply(v_f_2416, 2, (V[]){heff_dup(v_e_240), v_a_2415}));
        break;
      }
      default: heff_nomatch(v_c_249);
      }
      return heff_clo(g_heff_2erules_2etagArgsGo_lam3, 2, 4, (V[]){v_c_2417, v_e_240, v_cs_2410, v_ts_2414});
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2erules_2etagArgsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2etagArgsGo(a[0], a[1], a[2]);
}
V g_heff_2erules_2etagArgsGo_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2etagArgsGo_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2etagArgsGo_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2etagArgsGo_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2419;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_x_2420, v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2etagArgsGo_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_cs_2410 = heff_env(self)[1];
  V v_ts_2414 = heff_env(self)[2];
  V v_hd_2418 = heff_env(self)[3];
  V v_k_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2421 = (g_heff_2erules_2etagArgsGo(v_e_240, v_cs_2410, v_ts_2414));
  return heff_tail(v_c_2421, 2, (V[]){v_hd_2418, heff_clo(g_heff_2erules_2etagArgsGo_lam5, 1, 2, (V[]){v_k_2419, v_x_2420})});
}
V g_heff_2erules_2etagArgsGo_lam3(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_cs_2410 = heff_env(self)[2];
  V v_ts_2414 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2417;
  args[0] = heff_dup(v_hd_2418);
  args[1] = heff_clo(g_heff_2erules_2etagArgsGo_lam4, 1, 5, (V[]){v_e_240, v_cs_2410, v_ts_2414, v_hd_2418, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[74]; } g_heff_2erules_2esumIntroNow_str0 = {{0x80000000u, K_STR, 0}, 74, 74, {99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 97, 103, 32, 115, 121, 110, 116, 97, 120, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 105, 116, 44, 32, 97, 115, 32, 105, 110, 32, 96, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2erules_2esumIntroNow_str1 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 46, 46, 46, 32, 58, 32, 84, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2erules_2esumIntroNow_str2 = {{0x80000000u, K_STR, 0}, 14, 14, {101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2erules_2esumIntroNow_str3 = {{0x80000000u, K_STR, 0}, 18, 18, {44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 104, 101, 32, 116, 97, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[63]; } g_heff_2erules_2esumIntroNow_str4 = {{0x80000000u, K_STR, 0}, 63, 63, {32, 110, 97, 109, 101, 115, 32, 110, 111, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 111, 114, 32, 98, 105, 110, 100, 101, 114, 32, 105, 110, 32, 115, 99, 111, 112, 101, 44, 32, 115, 111, 32, 105, 116, 32, 105, 115, 32, 114, 101, 97, 100, 32, 97, 115, 32, 97, 32, 116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[74]; } g_heff_2erules_2esumIntroNow_str5 = {{0x80000000u, K_STR, 0}, 74, 74, {99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 97, 103, 32, 115, 121, 110, 116, 97, 120, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 105, 116, 44, 32, 97, 115, 32, 105, 110, 32, 96, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2erules_2esumIntroNow_str6 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 46, 46, 46, 32, 58, 32, 84, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2erules_2esumIntroNow_str7 = {{0x80000000u, K_STR, 0}, 14, 14, {101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2erules_2esumIntroNow_str8 = {{0x80000000u, K_STR, 0}, 18, 18, {44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 104, 101, 32, 116, 97, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[63]; } g_heff_2erules_2esumIntroNow_str9 = {{0x80000000u, K_STR, 0}, 63, 63, {32, 110, 97, 109, 101, 115, 32, 110, 111, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 111, 114, 32, 98, 105, 110, 100, 101, 114, 32, 105, 110, 32, 115, 99, 111, 112, 101, 44, 32, 115, 111, 32, 105, 116, 32, 105, 115, 32, 114, 101, 97, 100, 32, 97, 115, 32, 97, 32, 116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[74]; } g_heff_2erules_2esumIntroNow_str10 = {{0x80000000u, K_STR, 0}, 74, 74, {99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 97, 103, 32, 115, 121, 110, 116, 97, 120, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 105, 116, 44, 32, 97, 115, 32, 105, 110, 32, 96, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2erules_2esumIntroNow_str11 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 46, 46, 46, 32, 58, 32, 84, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2erules_2esumIntroNow_str12 = {{0x80000000u, K_STR, 0}, 14, 14, {101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2erules_2esumIntroNow_str13 = {{0x80000000u, K_STR, 0}, 18, 18, {44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 104, 101, 32, 116, 97, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[63]; } g_heff_2erules_2esumIntroNow_str14 = {{0x80000000u, K_STR, 0}, 63, 63, {32, 110, 97, 109, 101, 115, 32, 110, 111, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 111, 114, 32, 98, 105, 110, 100, 101, 114, 32, 105, 110, 32, 115, 99, 111, 112, 101, 44, 32, 115, 111, 32, 105, 116, 32, 105, 115, 32, 114, 101, 97, 100, 32, 97, 115, 32, 97, 32, 116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2erules_2esumIntroNow_str15 = {{0x80000000u, K_STR, 0}, 12, 12, {110, 111, 32, 115, 117, 99, 104, 32, 116, 97, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2erules_2esumIntroNow_str16 = {{0x80000000u, K_STR, 0}, 9, 9, {32, 105, 110, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2erules_2esumIntroNow_str17 = {{0x80000000u, K_STR, 0}, 34, 34, {119, 114, 111, 110, 103, 32, 110, 117, 109, 98, 101, 114, 32, 111, 102, 32, 97, 114, 103, 117, 109, 101, 110, 116, 115, 32, 102, 111, 114, 32, 116, 97, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2erules_2esumIntroNow_str18 = {{0x80000000u, K_STR, 0}, 9, 9, {32, 105, 110, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[74]; } g_heff_2erules_2esumIntroNow_str19 = {{0x80000000u, K_STR, 0}, 74, 74, {99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 97, 103, 32, 115, 121, 110, 116, 97, 120, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 105, 116, 44, 32, 97, 115, 32, 105, 110, 32, 96, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2erules_2esumIntroNow_str20 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 46, 46, 46, 32, 58, 32, 84, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2erules_2esumIntroNow_str21 = {{0x80000000u, K_STR, 0}, 14, 14, {101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2erules_2esumIntroNow_str22 = {{0x80000000u, K_STR, 0}, 18, 18, {44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 104, 101, 32, 116, 97, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[63]; } g_heff_2erules_2esumIntroNow_str23 = {{0x80000000u, K_STR, 0}, 63, 63, {32, 110, 97, 109, 101, 115, 32, 110, 111, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 111, 114, 32, 98, 105, 110, 100, 101, 114, 32, 105, 110, 32, 115, 99, 111, 112, 101, 44, 32, 115, 111, 32, 105, 116, 32, 105, 115, 32, 114, 101, 97, 100, 32, 97, 115, 32, 97, 32, 116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[74]; } g_heff_2erules_2esumIntroNow_str24 = {{0x80000000u, K_STR, 0}, 74, 74, {99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 97, 103, 32, 115, 121, 110, 116, 97, 120, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 105, 116, 44, 32, 97, 115, 32, 105, 110, 32, 96, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2erules_2esumIntroNow_str25 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 46, 46, 46, 32, 58, 32, 84, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2erules_2esumIntroNow_str26 = {{0x80000000u, K_STR, 0}, 14, 14, {101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2erules_2esumIntroNow_str27 = {{0x80000000u, K_STR, 0}, 18, 18, {44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 104, 101, 32, 116, 97, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[63]; } g_heff_2erules_2esumIntroNow_str28 = {{0x80000000u, K_STR, 0}, 63, 63, {32, 110, 97, 109, 101, 115, 32, 110, 111, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 111, 114, 32, 98, 105, 110, 100, 101, 114, 32, 105, 110, 32, 115, 99, 111, 112, 101, 44, 32, 115, 111, 32, 105, 116, 32, 105, 115, 32, 114, 101, 97, 100, 32, 97, 115, 32, 97, 32, 116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[74]; } g_heff_2erules_2esumIntroNow_str29 = {{0x80000000u, K_STR, 0}, 74, 74, {99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 97, 103, 32, 115, 121, 110, 116, 97, 120, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 105, 116, 44, 32, 97, 115, 32, 105, 110, 32, 96, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2erules_2esumIntroNow_str30 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 46, 46, 46, 32, 58, 32, 84, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2erules_2esumIntroNow_str31 = {{0x80000000u, K_STR, 0}, 14, 14, {101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2erules_2esumIntroNow_str32 = {{0x80000000u, K_STR, 0}, 18, 18, {44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 104, 101, 32, 116, 97, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[63]; } g_heff_2erules_2esumIntroNow_str33 = {{0x80000000u, K_STR, 0}, 63, 63, {32, 110, 97, 109, 101, 115, 32, 110, 111, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 111, 114, 32, 98, 105, 110, 100, 101, 114, 32, 105, 110, 32, 115, 99, 111, 112, 101, 44, 32, 115, 111, 32, 105, 116, 32, 105, 115, 32, 114, 101, 97, 100, 32, 97, 115, 32, 97, 32, 116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[74]; } g_heff_2erules_2esumIntroNow_str34 = {{0x80000000u, K_STR, 0}, 74, 74, {99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 97, 103, 32, 115, 121, 110, 116, 97, 120, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 105, 116, 44, 32, 97, 115, 32, 105, 110, 32, 96, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2erules_2esumIntroNow_str35 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 46, 46, 46, 32, 58, 32, 84, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2erules_2esumIntroNow_str36 = {{0x80000000u, K_STR, 0}, 14, 14, {101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2erules_2esumIntroNow_str37 = {{0x80000000u, K_STR, 0}, 18, 18, {44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 104, 101, 32, 116, 97, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[63]; } g_heff_2erules_2esumIntroNow_str38 = {{0x80000000u, K_STR, 0}, 63, 63, {32, 110, 97, 109, 101, 115, 32, 110, 111, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 111, 114, 32, 98, 105, 110, 100, 101, 114, 32, 105, 110, 32, 115, 99, 111, 112, 101, 44, 32, 115, 111, 32, 105, 116, 32, 105, 115, 32, 114, 101, 97, 100, 32, 97, 115, 32, 97, 32, 116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[74]; } g_heff_2erules_2esumIntroNow_str39 = {{0x80000000u, K_STR, 0}, 74, 74, {99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 97, 103, 32, 115, 121, 110, 116, 97, 120, 32, 97, 116, 32, 97, 32, 116, 121, 112, 101, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 97, 110, 110, 111, 116, 97, 116, 101, 32, 105, 116, 44, 32, 97, 115, 32, 105, 110, 32, 96, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2erules_2esumIntroNow_str40 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 46, 46, 46, 32, 58, 32, 84, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2erules_2esumIntroNow_str41 = {{0x80000000u, K_STR, 0}, 14, 14, {101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2erules_2esumIntroNow_str42 = {{0x80000000u, K_STR, 0}, 18, 18, {44, 32, 98, 117, 116, 32, 103, 111, 116, 32, 116, 104, 101, 32, 116, 97, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[63]; } g_heff_2erules_2esumIntroNow_str43 = {{0x80000000u, K_STR, 0}, 63, 63, {32, 110, 97, 109, 101, 115, 32, 110, 111, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 111, 114, 32, 98, 105, 110, 100, 101, 114, 32, 105, 110, 32, 115, 99, 111, 112, 101, 44, 32, 115, 111, 32, 105, 116, 32, 105, 115, 32, 114, 101, 97, 100, 32, 97, 115, 32, 97, 32, 116, 97, 103}};
V g_heff_2erules_2esumIntroNow_lam1(V self, V *args);
V g_heff_2erules_2esumIntroNow_lam5(V self, V *args);
V g_heff_2erules_2esumIntroNow_lam6(V self, V *args); static Clo g_heff_2erules_2esumIntroNow_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2esumIntroNow_lam6, 1, 0};
V g_heff_2erules_2esumIntroNow_lam4(V self, V *args);
V g_heff_2erules_2esumIntroNow_lam3(V self, V *args);
V g_heff_2erules_2esumIntroNow_lam2(V self, V *args);
V g_heff_2erules_2esumIntroNow_lam0(V self, V *args);
Clo g_heff_2erules_2esumIntroNow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2esumIntroNow_entry, 4, 0};

V g_heff_2erules_2esumIntroNow(V v_sp_240, V v_tsp_241, V v_x_242, V v_cs_243) {
top: ;
  return heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2erules_2esumIntroNow_lam0, 4, 4, (V[]){v_x_242, v_sp_240, v_tsp_241, v_cs_243})});
}
V g_heff_2erules_2esumIntroNow_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2esumIntroNow(a[0], a[1], a[2], a[3]);
}
V g_heff_2erules_2esumIntroNow_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_248, LBL_metas); V a_1 = v_a0_245; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2erules_2esumIntroNow_lam5(V self, V *args) {
  V v_i_24138 = args[0];
  V v_gs_24137 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_24139 = heff_arrayIndex(v_gs_24137, v_i_24138);
  return heff_get(v_m_24139, LBL_stx);
}
V g_heff_2erules_2esumIntroNow_lam6(V self, V *args) {
  V v_u_24141 = args[0];
  heff_drop(v_u_24141);
  return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2erules_2esumIntroNow_lam4(V self, V *args) {
  V v_x_24136 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_gs_24137 = heff_arrayFromList(v_x_24136);
  V v_t_24140 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_gs_24137)), heff_clo(g_heff_2erules_2esumIntroNow_lam5, 1, 1, (V[]){v_gs_24137}));
  V v_x_24142 = heff_rec(2, shape_326_366, (V[]){heff_tag(TAG_STag, 2, (V[]){v_x_242, v_t_24140}), ((V)&g_heff_2erules_2esumIntroNow_lam6_clo)});
  V f_ = v_k_247;
  args[0] = v_x_24142;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2esumIntroNow_lam3(V self, V *args) {
  V v_x_24134 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_cs_243 = heff_env(self)[1];
  V v_ts_24131 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24134);
  V v_c_24135 = (g_heff_2erules_2etagArgsGo(v_e_244, v_cs_243, heff_arrayToList(v_ts_24131)));
  return heff_tail(v_c_24135, 2, (V[]){v_hd_246, heff_clo(g_heff_2erules_2esumIntroNow_lam4, 1, 2, (V[]){v_x_242, v_k_247})});
}
V g_heff_2erules_2esumIntroNow_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_tsp_241 = heff_env(self)[5];
  V v_cs_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    V v_ru_24t_2413_24LikeU = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_cs_243);
    V v_t_2434;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_2416 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_it1_2416)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_2416, 0ULL, 1);
        v_t_2434 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_2416, 0ULL, 1);
        v_t_2434 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_2416, 0ULL, 1);
        v_t_2434 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2434 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_2416);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    switch (heff_tag_of(v_t_2434)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      V v_t_2435 = heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str0), heff_strAppend(v_x_242, ((V)&g_heff_2erules_2esumIntroNow_str1)));
      V v_t_2436 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_2435, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2437 = heff_tag_at(v_ru_24t_2413_24LikeU, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2438}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2439, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_2440 = (g_heff_2erules_2etyStr(v_e_244, v_x_2412));
      V v_msg_2441 = heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str2), heff_strAppend(v_t_2440, heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str3), heff_dup(v_x_242))));
      V v_t_2442 = heff_tag_at(v_ru_24t_2413_24LikeU, TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2erules_2esumIntroNow_str4))});
      V v_t_2443 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_2441, v_tsp_241, v_t_2442});
      V v_t_2444 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2443})});
      V v_t_2445 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2444})});
      V v_t_2446 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2445}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2446, v_k_247});
    }
    default: return heff_nomatch(v_t_2434);
    }
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2413, 0ULL, 4);
    heff_drop(v_cs_243);
    V v_t_2470;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_2452 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_it1_2452)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_2452, 0ULL, 1);
        v_t_2470 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_2452, 0ULL, 1);
        v_t_2470 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_2452, 0ULL, 1);
        v_t_2470 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2470 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_2452);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    switch (heff_tag_of(v_t_2470)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      V v_t_2471 = heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str5), heff_strAppend(v_x_242, ((V)&g_heff_2erules_2esumIntroNow_str6)));
      V v_t_2472 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_2471, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2473 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2472})});
      V v_t_2474 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2473})});
      V v_t_2475 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2474}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2475, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_2476 = (g_heff_2erules_2etyStr(v_e_244, v_x_2412));
      V v_msg_2477 = heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str7), heff_strAppend(v_t_2476, heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str8), heff_dup(v_x_242))));
      V v_t_2478 = heff_tag(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2erules_2esumIntroNow_str9))});
      V v_t_2479 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_2477, v_tsp_241, v_t_2478});
      V v_t_2480 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2479})});
      V v_t_2481 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2480})});
      V v_t_2482 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2481}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_2482, v_k_247});
    }
    default: return heff_nomatch(v_t_2470);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2413, 0ULL, 3);
    heff_drop(v_cs_243);
    V v_t_24105;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24105 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_2487 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_it1_2487)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_2487, 0ULL, 1);
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_2487, 0ULL, 1);
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_2487, 0ULL, 1);
        v_t_24105 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_2487);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24105 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24105 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24105 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24105 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24105 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24105 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24105 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    switch (heff_tag_of(v_t_24105)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      V v_t_24106 = heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str10), heff_strAppend(v_x_242, ((V)&g_heff_2erules_2esumIntroNow_str11)));
      V v_t_24107 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24106, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24108 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24107})});
      V v_t_24109 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24108})});
      V v_t_24110 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24109}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24110, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_24111 = (g_heff_2erules_2etyStr(v_e_244, v_x_2412));
      V v_msg_24112 = heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str12), heff_strAppend(v_t_24111, heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str13), heff_dup(v_x_242))));
      V v_t_24113 = heff_tag(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2erules_2esumIntroNow_str14))});
      V v_t_24114 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24112, v_tsp_241, v_t_24113});
      V v_t_24115 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24114})});
      V v_t_24116 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24115})});
      V v_t_24117 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24116}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24117, v_k_247});
    }
    default: return heff_nomatch(v_t_24105);
    }
  }
  case TAG_LikeSum: {
    V v_vs_24118 = heff_field(v_t_2413, 0);
    V v_ru_24t_2413_24LikeSum = heff_take_reuse_n(v_t_2413, 1ULL, 1);
    V v_t_24119 = ({ V a_0 = heff_dup(v_x_242); V b_1 = heff_get(heff_dup(v_vs_24118), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_24125;
    switch (heff_tag_of(v_t_24119)) {
    case TAG_Nothing: {
      heff_drop(v_vs_24118);
      heff_drop_cell(v_ru_24t_2413_24LikeSum, 1);
      v_t_24125 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_i_24120 = heff_field(v_t_24119, 0);
      heff_take_n(v_t_24119, 1ULL, 1);
      V v_xs_24121 = heff_get(v_vs_24118, LBL_values);
      V v_t_24122 = heff_intLe(MK_INT(0LL), heff_dup(v_i_24120));
      switch (heff_tag_of(v_t_24122)) {
      case TAG_True: {
        V v_t_24123 = heff_intLt(heff_dup(v_i_24120), heff_arrayLength(heff_dup(v_xs_24121)));
        switch (heff_tag_of(v_t_24123)) {
        case TAG_True: {
          V v_t_24124 = heff_arrayIndex(v_xs_24121, v_i_24120);
          v_t_24125 = heff_tag_at(v_ru_24t_2413_24LikeSum, TAG_Just, 1, (V[]){v_t_24124});
          break;
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_2413_24LikeSum, 1);
          heff_drop(v_i_24120);
          heff_drop(v_xs_24121);
          v_t_24125 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_24123);
        }
        break;
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24t_2413_24LikeSum, 1);
        heff_drop(v_i_24120);
        heff_drop(v_xs_24121);
        v_t_24125 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t_24122);
      }
      break;
    }
    default: heff_nomatch(v_t_24119);
    }
    switch (heff_tag_of(v_t_24125)) {
    case TAG_Nothing: {
      heff_drop(v_tsp_241);
      heff_drop(v_cs_243);
      V v_msg_24126 = heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str15), heff_strAppend(v_x_242, heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str16), (g_heff_2erules_2etyStr(v_e_244, v_x_2412)))));
      V v_t_24127 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(315LL), NTAG(TAG_SError), v_msg_24126, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24128 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24127})});
      V v_t_24129 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24128})});
      V v_t_24130 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24129}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24130, v_k_247});
    }
    case TAG_Just: {
      V v_ts_24131 = heff_field(v_t_24125, 0);
      V v_ru_24t_24125_24Just = heff_take_reuse_n(v_t_24125, 1ULL, 1);
      V v_t_24132 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_cs_243));
      V v_t_24133 = heff_intEq(heff_arrayLength(heff_dup(v_ts_24131)), v_t_24132);
      switch (heff_tag_of(v_t_24133)) {
      case TAG_True: {
        heff_drop(v_sp_240);
        heff_drop_cell(v_ru_24t_24125_24Just, 1);
        return (g_heff_2erules_2erecordName(heff_dup(v_e_244), v_x_2412, heff_dup(v_x_242), v_tsp_241, v_x_2412, heff_dup(v_hd_246), heff_clo(g_heff_2erules_2esumIntroNow_lam3, 1, 6, (V[]){v_e_244, v_cs_243, v_ts_24131, v_hd_246, v_x_242, v_k_247})));
      }
      case TAG_False: {
        heff_drop(v_tsp_241);
        heff_drop(v_cs_243);
        heff_drop(v_ts_24131);
        V v_msg_24143 = heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str17), heff_strAppend(v_x_242, heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str18), (g_heff_2erules_2etyStr(v_e_244, v_x_2412)))));
        V v_t_24144 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(316LL), NTAG(TAG_SError), v_msg_24143, v_sp_240, NTAG(TAG_Nothing)});
        V v_t_24145 = heff_tag_at(v_ru_24t_24125_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24144})});
        V v_t_24146 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24145})});
        V v_t_24147 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24146}));
        return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24147, v_k_247});
      }
      default: return heff_nomatch(v_t_24133);
      }
    }
    default: return heff_nomatch(v_t_24125);
    }
  }
  case TAG_LikeInt: {
    heff_drop(v_cs_243);
    V v_t_24167;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24149 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_it1_24149)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24149, 0ULL, 1);
        v_t_24167 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24149, 0ULL, 1);
        v_t_24167 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24149, 0ULL, 1);
        v_t_24167 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24167 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24149);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    switch (heff_tag_of(v_t_24167)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      V v_t_24168 = heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str19), heff_strAppend(v_x_242, ((V)&g_heff_2erules_2esumIntroNow_str20)));
      V v_t_24169 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24168, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24170 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24169})});
      V v_t_24171 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24170})});
      V v_t_24172 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24171}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24172, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_24173 = (g_heff_2erules_2etyStr(v_e_244, v_x_2412));
      V v_msg_24174 = heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str21), heff_strAppend(v_t_24173, heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str22), heff_dup(v_x_242))));
      V v_t_24175 = heff_tag(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2erules_2esumIntroNow_str23))});
      V v_t_24176 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24174, v_tsp_241, v_t_24175});
      V v_t_24177 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24176})});
      V v_t_24178 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24177})});
      V v_t_24179 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24178}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24179, v_k_247});
    }
    default: return heff_nomatch(v_t_24167);
    }
  }
  case TAG_LikeFloat: {
    heff_drop(v_cs_243);
    V v_t_24199;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24199 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24181 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_it1_24181)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24181, 0ULL, 1);
        v_t_24199 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24181, 0ULL, 1);
        v_t_24199 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24181, 0ULL, 1);
        v_t_24199 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24199 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24181);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24199 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24199 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24199 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24199 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24199 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24199 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24199 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    switch (heff_tag_of(v_t_24199)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      V v_t_24200 = heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str24), heff_strAppend(v_x_242, ((V)&g_heff_2erules_2esumIntroNow_str25)));
      V v_t_24201 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24200, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24202 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24201})});
      V v_t_24203 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24202})});
      V v_t_24204 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24203}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24204, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_24205 = (g_heff_2erules_2etyStr(v_e_244, v_x_2412));
      V v_msg_24206 = heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str26), heff_strAppend(v_t_24205, heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str27), heff_dup(v_x_242))));
      V v_t_24207 = heff_tag(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2erules_2esumIntroNow_str28))});
      V v_t_24208 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24206, v_tsp_241, v_t_24207});
      V v_t_24209 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24208})});
      V v_t_24210 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24209})});
      V v_t_24211 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24210}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24211, v_k_247});
    }
    default: return heff_nomatch(v_t_24199);
    }
  }
  case TAG_LikeString: {
    heff_drop(v_cs_243);
    V v_t_24231;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24231 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24213 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_it1_24213)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24213, 0ULL, 1);
        v_t_24231 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24213, 0ULL, 1);
        v_t_24231 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24213, 0ULL, 1);
        v_t_24231 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24231 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24213);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24231 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24231 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24231 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24231 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24231 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24231 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24231 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    switch (heff_tag_of(v_t_24231)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      V v_t_24232 = heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str29), heff_strAppend(v_x_242, ((V)&g_heff_2erules_2esumIntroNow_str30)));
      V v_t_24233 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24232, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24234 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24233})});
      V v_t_24235 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24234})});
      V v_t_24236 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24235}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24236, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_24237 = (g_heff_2erules_2etyStr(v_e_244, v_x_2412));
      V v_msg_24238 = heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str31), heff_strAppend(v_t_24237, heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str32), heff_dup(v_x_242))));
      V v_t_24239 = heff_tag(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2erules_2esumIntroNow_str33))});
      V v_t_24240 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24238, v_tsp_241, v_t_24239});
      V v_t_24241 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24240})});
      V v_t_24242 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24241})});
      V v_t_24243 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24242}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24243, v_k_247});
    }
    default: return heff_nomatch(v_t_24231);
    }
  }
  case TAG_LikeArray: {
    V v_ru_24t_2413_24LikeArray = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_cs_243);
    V v_t_24264;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24264 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24246 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_it1_24246)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24246, 0ULL, 1);
        v_t_24264 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24246, 0ULL, 1);
        v_t_24264 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24246, 0ULL, 1);
        v_t_24264 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24264 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24246);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24264 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24264 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24264 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24264 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24264 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24264 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24264 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    switch (heff_tag_of(v_t_24264)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      V v_t_24265 = heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str34), heff_strAppend(v_x_242, ((V)&g_heff_2erules_2esumIntroNow_str35)));
      V v_t_24266 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24265, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24267 = heff_tag_at(v_ru_24t_2413_24LikeArray, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24266})});
      V v_t_24268 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24267})});
      V v_t_24269 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24268}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24269, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_24270 = (g_heff_2erules_2etyStr(v_e_244, v_x_2412));
      V v_msg_24271 = heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str36), heff_strAppend(v_t_24270, heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str37), heff_dup(v_x_242))));
      V v_t_24272 = heff_tag_at(v_ru_24t_2413_24LikeArray, TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2erules_2esumIntroNow_str38))});
      V v_t_24273 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24271, v_tsp_241, v_t_24272});
      V v_t_24274 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24273})});
      V v_t_24275 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24274})});
      V v_t_24276 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24275}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24276, v_k_247});
    }
    default: return heff_nomatch(v_t_24264);
    }
  }
  case TAG_NoRules: {
    heff_drop(v_cs_243);
    V v_t_24296;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24296 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24278 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_it1_24278)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24278, 0ULL, 1);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24278, 0ULL, 1);
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24278, 0ULL, 1);
        v_t_24296 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24296 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24278);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24296 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24296 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24296 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24296 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24296 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24296 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24296 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    switch (heff_tag_of(v_t_24296)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      V v_t_24297 = heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str39), heff_strAppend(v_x_242, ((V)&g_heff_2erules_2esumIntroNow_str40)));
      V v_t_24298 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24297, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24299 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24298})});
      V v_t_24300 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24299})});
      V v_t_24301 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24300}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24301, v_k_247});
    }
    case TAG_False: {
      heff_drop(v_sp_240);
      V v_t_24302 = (g_heff_2erules_2etyStr(v_e_244, v_x_2412));
      V v_msg_24303 = heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str41), heff_strAppend(v_t_24302, heff_strAppend(((V)&g_heff_2erules_2esumIntroNow_str42), heff_dup(v_x_242))));
      V v_t_24304 = heff_tag(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2erules_2esumIntroNow_str43))});
      V v_t_24305 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24303, v_tsp_241, v_t_24304});
      V v_t_24306 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24305})});
      V v_t_24307 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24306})});
      V v_t_24308 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24307}));
      return heff_tail(heff_get(v_hd_246, LBL_bind), 2, (V[]){v_t_24308, v_k_247});
    }
    default: return heff_nomatch(v_t_24296);
    }
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2erules_2esumIntroNow_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_a0_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V v_x_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_tsp_241 = heff_env(self)[2];
  V v_cs_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2esumIntroNow_lam1, 1, 1, (V[]){v_a0_245})})});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2410}));
  V f_ = heff_get(heff_dup(v_hd_246), LBL_bind);
  args[0] = v_t_2411;
  args[1] = heff_clo(g_heff_2erules_2esumIntroNow_lam2, 1, 7, (V[]){v_x_242, v_sp_240, v_hd_246, v_k_247, v_e_244, v_tsp_241, v_cs_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2erules_2esumIntro_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {116, 97, 103}};
V g_heff_2erules_2esumIntro_lam1(V self, V *args);
V g_heff_2erules_2esumIntro_lam2(V self, V *args);
V g_heff_2erules_2esumIntro_lam0(V self, V *args);
Clo g_heff_2erules_2esumIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2esumIntro_entry, 4, 0};

V g_heff_2erules_2esumIntro(V v_sp_240, V v_tsp_241, V v_x_242, V v_cs_243) {
top: ;
  return heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2erules_2esumIntro_lam0, 4, 4, (V[]){v_sp_240, v_tsp_241, v_x_242, v_cs_243})});
}
V g_heff_2erules_2esumIntro_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2esumIntro(a[0], a[1], a[2], a[3]);
}
V g_heff_2erules_2esumIntro_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_248, LBL_metas); V a_1 = v_a0_245; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2erules_2esumIntro_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_tsp_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_cs_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2432;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_VU: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_it1_2414 = heff_dup(heff_field(v_x_2412, 0));
    switch (heff_tag_of(v_it1_2414)) {
    case TAG_HLocal: {
      heff_take_n(v_it1_2414, 0ULL, 1);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_it1_2414, 0ULL, 1);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_it1_2414, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_HError: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_it1_2414);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  switch (heff_tag_of(v_t_2432)) {
  case TAG_True: {
    V v_t_2433 = (g_heff_2erules_2esumIntroNow(heff_dup(v_sp_240), v_tsp_241, v_x_242, v_cs_243));
    return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2erules_2esumIntro_str0); V a_3 = v_t_2433; V a_4 = heff_dup(v_x_2412); V a_5 = v_x_2412; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2433); r_; });
  }
  case TAG_False: {
    V v_t_2434 = (g_heff_2erules_2esumIntroNow(v_sp_240, v_tsp_241, v_x_242, v_cs_243));
    switch (heff_tag_of(v_t_2434)) {
    case TAG_MkChk: {
      V v_f_2435 = heff_field(v_t_2434, 0);
      heff_take_n(v_t_2434, 1ULL, 1);
      return heff_tail(v_f_2435, 4, (V[]){v_e_244, v_x_2412, v_hd_246, v_k_247});
    }
    default: return heff_nomatch(v_t_2434);
    }
  }
  default: return heff_nomatch(v_t_2432);
  }
}
V g_heff_2erules_2esumIntro_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_a0_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_tsp_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_cs_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2esumIntro_lam1, 1, 1, (V[]){v_a0_245})})});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2410}));
  V f_ = heff_get(heff_dup(v_hd_246), LBL_bind);
  args[0] = v_t_2411;
  args[1] = heff_clo(g_heff_2erules_2esumIntro_lam2, 1, 7, (V[]){v_sp_240, v_tsp_241, v_x_242, v_cs_243, v_e_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2erecordTagIn_lam0(V self, V *args); static Clo g_heff_2erules_2erecordTagIn_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erecordTagIn_lam0, 2, 0};
V g_heff_2erules_2erecordTagIn_lam1(V self, V *args); static Clo g_heff_2erules_2erecordTagIn_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erecordTagIn_lam1, 2, 0};
V g_heff_2erules_2erecordTagIn_lam2(V self, V *args); static Clo g_heff_2erules_2erecordTagIn_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erecordTagIn_lam2, 2, 0};
Clo g_heff_2erules_2erecordTagIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erecordTagIn_entry, 5, 0};

V g_heff_2erules_2erecordTagIn(V v_e_240, V v_a_241, V v_vs_242, V v_x_243, V v_tsp_244) {
top: ;
  V v_t_245 = ({ V a_0 = heff_dup(v_x_243); V b_1 = heff_get(heff_dup(v_vs_242), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    heff_drop(v_a_241);
    heff_drop(v_vs_242);
    heff_drop(v_x_243);
    heff_drop(v_tsp_244);
    return ((V)&g_heff_2erules_2erecordTagIn_lam0_clo);
  }
  case TAG_Just: {
    V v_i_248 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_xs_249 = heff_get(v_vs_242, LBL_values);
    V v_t_2410 = heff_intLe(MK_INT(0LL), heff_dup(v_i_248));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      V v_t_2411 = heff_intLt(heff_dup(v_i_248), heff_arrayLength(heff_dup(v_xs_249)));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        V v_x_2412 = heff_arrayIndex(v_xs_249, v_i_248);
        heff_drop(v_x_2412);
        return heff_tail(((V)&g_heff_2erules_2erecordName_clo), 5, (V[]){v_e_240, heff_dup(v_a_241), v_x_243, v_tsp_244, v_a_241});
      }
      case TAG_False: {
        heff_drop(v_e_240);
        heff_drop(v_a_241);
        heff_drop(v_x_243);
        heff_drop(v_tsp_244);
        heff_drop(v_i_248);
        heff_drop(v_xs_249);
        return ((V)&g_heff_2erules_2erecordTagIn_lam1_clo);
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    case TAG_False: {
      heff_drop(v_e_240);
      heff_drop(v_a_241);
      heff_drop(v_x_243);
      heff_drop(v_tsp_244);
      heff_drop(v_i_248);
      heff_drop(v_xs_249);
      return ((V)&g_heff_2erules_2erecordTagIn_lam2_clo);
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2erules_2erecordTagIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2erecordTagIn(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2erules_2erecordTagIn_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2erecordTagIn_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2erecordTagIn_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2erecordTags_lam0(V self, V *args); static Clo g_heff_2erules_2erecordTags_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erecordTags_lam0, 2, 0};
V g_heff_2erules_2erecordTags_lam2(V self, V *args);
V g_heff_2erules_2erecordTags_lam1(V self, V *args);
Clo g_heff_2erules_2erecordTags_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2erecordTags_entry, 4, 0};

V g_heff_2erules_2erecordTags(V v_e_240, V v_a_241, V v_vs_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_a_241);
    heff_drop(v_vs_242);
    return ((V)&g_heff_2erules_2erecordTags_lam0_clo);
  }
  case TAG_Cons: {
    V v_x41_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    switch (heff_tag_of(v_x41_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x41_246, 0);
      V v_tsp_249 = heff_field(v_x41_246, 1);
      V v_c_2410 = heff_tr(g_heff_2erules_2erecordTagIn(heff_dup(v_e_240), heff_dup(v_a_241), heff_dup(v_vs_242), heff_dup(v_x_248), heff_dup(v_tsp_249)));
      return heff_clo(g_heff_2erules_2erecordTags_lam1, 2, 5, (V[]){v_c_2410, v_e_240, v_a_241, v_vs_242, heff_dup(v_rest_247)});
    }
    default: return heff_nomatch(v_x41_246);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2erules_2erecordTags_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2erecordTags(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
V g_heff_2erules_2erecordTags_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2erecordTags_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2413);
  V v_t_2414 = ({ V a_0 = v_e_240; V a_1 = v_a_241; V a_2 = v_vs_242; V a_3 = v_rest_247; V r_ = (g_heff_2erules_2erecordTags(a_0, a_1, a_2, a_3)); heff_drop(v_rest_247); r_; });
  return heff_tail(v_t_2414, 2, (V[]){v_hd_2411, v_k_2412});
}
V g_heff_2erules_2erecordTags_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_vs_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo(g_heff_2erules_2erecordTags_lam2, 1, 6, (V[]){v_e_240, v_a_241, v_vs_242, v_rest_247, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erules_2ecaseArm_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2erules_2ecaseArm_str1 = {{0x80000000u, K_STR, 0}, 25, 25, {110, 111, 32, 99, 97, 115, 101, 32, 112, 114, 111, 118, 105, 100, 101, 100, 32, 102, 111, 114, 32, 116, 97, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[43]; } g_heff_2erules_2ecaseArm_str2 = {{0x80000000u, K_STR, 0}, 43, 43, {119, 114, 111, 110, 103, 32, 110, 117, 109, 98, 101, 114, 32, 111, 102, 32, 97, 114, 103, 117, 109, 101, 110, 116, 115, 32, 112, 114, 111, 118, 105, 100, 101, 100, 32, 102, 111, 114, 32, 116, 97, 103, 32}};
V g_heff_2erules_2ecaseArm_lam0(V self, V *args);
V g_heff_2erules_2ecaseArm_lam2(V self, V *args);
V g_heff_2erules_2ecaseArm_lam1(V self, V *args);
V g_heff_2erules_2ecaseArm_lam4(V self, V *args);
V g_heff_2erules_2ecaseArm_lam3(V self, V *args);
V g_heff_2erules_2ecaseArm_lam5(V self, V *args);
Clo g_heff_2erules_2ecaseArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2ecaseArm_entry, 7, 0};

V g_heff_2erules_2ecaseArm(V v_sp_240, V v_e_241, V v_b_242, V v_a_243, V v_x_244, V v_ts_245, V v_casesChk_246) {
top: ;
  V v_t_247 = ({ V a_0 = heff_dup(v_x_244); V b_1 = heff_get(heff_dup(v_casesChk_246), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  V v_it_2413;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    v_it_2413 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_i_248 = heff_field(v_t_247, 0);
    V v_ru_24t_247_24Just = heff_take_reuse_n(v_t_247, 1ULL, 1);
    V v_xs_249 = heff_get(heff_dup(v_casesChk_246), LBL_values);
    V v_t_2410 = heff_intLe(MK_INT(0LL), heff_dup(v_i_248));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      V v_t_2411 = heff_intLt(heff_dup(v_i_248), heff_arrayLength(heff_dup(v_xs_249)));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        V v_t_2412 = heff_arrayIndex(v_xs_249, v_i_248);
        v_it_2413 = heff_tag_at(v_ru_24t_247_24Just, TAG_Just, 1, (V[]){v_t_2412});
        break;
      }
      case TAG_False: {
        heff_drop(v_i_248);
        heff_drop_cell(v_ru_24t_247_24Just, 1);
        heff_drop(v_xs_249);
        v_it_2413 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
      break;
    }
    case TAG_False: {
      heff_drop(v_i_248);
      heff_drop_cell(v_ru_24t_247_24Just, 1);
      heff_drop(v_xs_249);
      v_it_2413 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  switch (heff_tag_of(v_it_2413)) {
  case TAG_Nothing: {
    V v_t_2414 = ({ V a_0 = ((V)&g_heff_2erules_2ecaseArm_str0); V b_1 = heff_get(heff_dup(v_casesChk_246), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    V v_it_2420;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nothing: {
      heff_drop(v_casesChk_246);
      v_it_2420 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_i_2415 = heff_field(v_t_2414, 0);
      V v_ru_24t_2414_24Just = heff_take_reuse_n(v_t_2414, 1ULL, 1);
      V v_xs_2416 = heff_get(v_casesChk_246, LBL_values);
      V v_t_2417 = heff_intLe(MK_INT(0LL), heff_dup(v_i_2415));
      switch (heff_tag_of(v_t_2417)) {
      case TAG_True: {
        V v_t_2418 = heff_intLt(heff_dup(v_i_2415), heff_arrayLength(heff_dup(v_xs_2416)));
        switch (heff_tag_of(v_t_2418)) {
        case TAG_True: {
          V v_t_2419 = heff_arrayIndex(v_xs_2416, v_i_2415);
          v_it_2420 = heff_tag_at(v_ru_24t_2414_24Just, TAG_Just, 1, (V[]){v_t_2419});
          break;
        }
        case TAG_False: {
          heff_drop(v_i_2415);
          heff_drop_cell(v_ru_24t_2414_24Just, 1);
          heff_drop(v_xs_2416);
          v_it_2420 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_i_2415);
        heff_drop_cell(v_ru_24t_2414_24Just, 1);
        heff_drop(v_xs_2416);
        v_it_2420 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t_2417);
      }
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    switch (heff_tag_of(v_it_2420)) {
    case TAG_Nothing: {
      heff_drop(v_e_241);
      heff_drop(v_b_242);
      heff_drop(v_ts_245);
      return heff_clo(g_heff_2erules_2ecaseArm_lam0, 2, 2, (V[]){v_x_244, v_sp_240});
    }
    case TAG_Just: {
      V v_it1_2427 = heff_field(v_it_2420, 0);
      heff_take_n(v_it_2420, 1ULL, 1);
      heff_drop(v_sp_240);
      switch (heff_tag_of(v_it1_2427)) {
      case TAG_MkPair: {
        V v_bodyChk_2429 = heff_field(v_it1_2427, 1);
        heff_take_n(v_it1_2427, 2ULL, 2);
        V v_t_2430 = (g_prelude_2emap_24s430(heff_dup(v_ts_245)));
        V v_t_2431 = (g_prelude_2emap_24s431(heff_dup(v_ts_245)));
        V v_sc_2432 = ({ V a_0 = v_t_2430; V a_1 = v_t_2431; V a_2 = heff_get(heff_dup(v_e_241), LBL_scope); V r_ = (g_heff_2eenvironment_2emultiBind(a_0, a_1, a_2)); heff_drop(v_t_2430); heff_drop(v_t_2431); r_; });
        V v_e_2433 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){v_sc_2432, heff_get(heff_dup(v_e_241), LBL_globals), heff_get(heff_dup(v_e_241), LBL_elabFor), heff_get(heff_dup(v_e_241), LBL_lams), heff_get(heff_dup(v_e_241), LBL_self), heff_get(v_e_241, LBL_insts)});
        V v_c_2435;
        switch (heff_tag_of(v_bodyChk_2429)) {
        case TAG_MkChk: {
          V v_f_2434 = heff_field(v_bodyChk_2429, 0);
          heff_take_n(v_bodyChk_2429, 1ULL, 1);
          v_c_2435 = heff_tr(heff_apply(v_f_2434, 2, (V[]){v_e_2433, v_b_242}));
          break;
        }
        default: heff_nomatch(v_bodyChk_2429);
        }
        return heff_clo(g_heff_2erules_2ecaseArm_lam1, 2, 3, (V[]){v_c_2435, v_ts_245, v_x_244});
      }
      default: return heff_nomatch(v_it1_2427);
      }
    }
    default: return heff_nomatch(v_it_2420);
    }
  }
  case TAG_Just: {
    V v_it1_2442 = heff_field(v_it_2413, 0);
    heff_take_n(v_it_2413, 1ULL, 1);
    heff_drop(v_casesChk_246);
    switch (heff_tag_of(v_it1_2442)) {
    case TAG_MkPair: {
      V v_xs_2443 = heff_field(v_it1_2442, 0);
      V v_bodyChk_2444 = heff_field(v_it1_2442, 1);
      heff_take_n(v_it1_2442, 3ULL, 2);
      V v_t_2445 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_ts_245));
      V v_t_2446 = heff_intEq(heff_arrayLength(heff_dup(v_xs_2443)), v_t_2445);
      switch (heff_tag_of(v_t_2446)) {
      case TAG_True: {
        heff_drop(v_sp_240);
        V v_t_2447 = (g_prelude_2emap_24s431(v_ts_245));
        V v_sc_2448 = ({ V b_0 = heff_arrayToList(heff_dup(v_xs_2443)); V a_1 = v_t_2447; V a_2 = heff_get(heff_dup(v_e_241), LBL_scope); V r_ = (g_heff_2eenvironment_2emultiBind(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2447); r_; });
        V v_e_2449 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){v_sc_2448, heff_get(heff_dup(v_e_241), LBL_globals), heff_get(heff_dup(v_e_241), LBL_elabFor), heff_get(heff_dup(v_e_241), LBL_lams), heff_get(heff_dup(v_e_241), LBL_self), heff_get(v_e_241, LBL_insts)});
        V v_c_2451;
        switch (heff_tag_of(v_bodyChk_2444)) {
        case TAG_MkChk: {
          V v_f_2450 = heff_field(v_bodyChk_2444, 0);
          heff_take_n(v_bodyChk_2444, 1ULL, 1);
          v_c_2451 = heff_tr(heff_apply(v_f_2450, 2, (V[]){v_e_2449, v_b_242}));
          break;
        }
        default: heff_nomatch(v_bodyChk_2444);
        }
        return heff_clo(g_heff_2erules_2ecaseArm_lam3, 2, 3, (V[]){v_c_2451, v_xs_2443, v_x_244});
      }
      case TAG_False: {
        heff_drop(v_e_241);
        heff_drop(v_b_242);
        heff_drop(v_ts_245);
        heff_drop(v_xs_2443);
        heff_drop(v_bodyChk_2444);
        return heff_clo(g_heff_2erules_2ecaseArm_lam5, 2, 2, (V[]){v_x_244, v_sp_240});
      }
      default: return heff_nomatch(v_t_2446);
      }
    }
    default: return heff_nomatch(v_it1_2442);
    }
  }
  default: return heff_nomatch(v_it_2413);
  }
}
V g_heff_2erules_2ecaseArm_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2ecaseArm(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[3]); return r;
}
V g_heff_2erules_2ecaseArm_lam0(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k2_2422 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(317LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2erules_2ecaseArm_str1), v_x_244), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2424 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2421), LBL_malg), 1, (V[]){v_t_2425}));
  V f_ = heff_get(v_hd_2421, LBL_bind);
  args[0] = v_t_2426;
  args[1] = v_k2_2422;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2ecaseArm_lam2(V self, V *args) {
  V v_x_2438 = args[0];
  V v_ts_245 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_2437 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2439 = (g_prelude_2emap_24s430(v_ts_245));
  V v_t_2440 = heff_tag(TAG_MkPair, 2, (V[]){heff_arrayFromList(v_t_2439), heff_get(v_x_2438, LBL_stx)});
  V v_x_2441 = heff_tag(TAG_MkPair, 2, (V[]){v_x_244, v_t_2440});
  V f_ = v_k_2437;
  args[0] = v_x_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2ecaseArm_lam1(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_c_2435 = heff_env(self)[0];
  V v_ts_245 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2435;
  args[0] = v_hd_2436;
  args[1] = heff_clo(g_heff_2erules_2ecaseArm_lam2, 1, 3, (V[]){v_ts_245, v_x_244, v_k_2437});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2ecaseArm_lam4(V self, V *args) {
  V v_x_2454 = args[0];
  V v_xs_2443 = heff_env(self)[0];
  V v_k_2453 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2455 = heff_tag(TAG_MkPair, 2, (V[]){v_xs_2443, heff_get(v_x_2454, LBL_stx)});
  V f_ = v_k_2453;
  args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_x_244, v_t_2455});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2ecaseArm_lam3(V self, V *args) {
  V v_hd_2452 = args[0];
  V v_k_2453 = args[1];
  V v_c_2451 = heff_env(self)[0];
  V v_xs_2443 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2451;
  args[0] = v_hd_2452;
  args[1] = heff_clo(g_heff_2erules_2ecaseArm_lam4, 1, 3, (V[]){v_xs_2443, v_k_2453, v_x_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2ecaseArm_lam5(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k2_2457 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2458 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(316LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2erules_2ecaseArm_str2), v_x_244), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2459 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2456), LBL_malg), 1, (V[]){v_t_2460}));
  V f_ = heff_get(v_hd_2456, LBL_bind);
  args[0] = v_t_2461;
  args[1] = v_k2_2457;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2ecasesAt_lam2(V self, V *args);
V g_heff_2erules_2ecasesAt_lam4(V self, V *args); static Clo g_heff_2erules_2ecasesAt_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2ecasesAt_lam4, 1, 0};
V g_heff_2erules_2ecasesAt_lam3(V self, V *args);
V g_heff_2erules_2ecasesAt_lam1(V self, V *args);
V g_heff_2erules_2ecasesAt_lam0(V self, V *args);
Clo g_heff_2erules_2ecasesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2ecasesAt_entry, 8, 0};

V g_heff_2erules_2ecasesAt(V v_sp_240, V v_e_241, V v_b_242, V v_scrut_243, V v_a_244, V v_vs_245, V v_tags_246, V v_casesChk_247) {
top: ;
  V v_c_248 = (g_heff_2erules_2erecordTags(heff_dup(v_e_241), heff_dup(v_a_244), heff_dup(v_vs_245), v_tags_246));
  return heff_clo(g_heff_2erules_2ecasesAt_lam0, 2, 8, (V[]){v_c_248, v_vs_245, v_sp_240, v_e_241, v_b_242, v_a_244, v_casesChk_247, v_scrut_243});
}
V g_heff_2erules_2ecasesAt_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2ecasesAt(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[6]); return r;
}
V g_heff_2erules_2ecasesAt_lam2(V self, V *args) {
  V v_p_2415 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_b_242 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_casesChk_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_p_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_p_2415, 0);
    V v_ts_2417 = heff_field(v_p_2415, 1);
    heff_take_n(v_p_2415, 3ULL, 2);
    return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_b_242; V a_3 = v_a_244; V a_4 = v_x_2416; V a_5 = heff_arrayToList(v_ts_2417); V a_6 = v_casesChk_247; V r_ = (g_heff_2erules_2ecaseArm(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_a_244); r_; });
  }
  default: return heff_nomatch(v_p_2415);
  }
}
V g_heff_2erules_2ecasesAt_lam4(V self, V *args) {
  V v_u_2425 = args[0];
  heff_drop(v_u_2425);
  return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2erules_2ecasesAt_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_scrut_243 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = (g_prelude_2emap_24s5(heff_dup(v_x_2419)));
  V v_t_2421 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_x_2419));
  V v_t_2422 = (g_prelude_2emap_24s6(v_x_2419));
  V v_cases_2423 = heff_rec(3, shape_153_35_368, (V[]){heff_arrayFromList(v_t_2420), v_t_2421, heff_arrayFromList(v_t_2422)});
  V v_t_2424 = heff_tag(TAG_SMatch, 2, (V[]){heff_get(v_scrut_243, LBL_stx), v_cases_2423});
  V v_x_2426 = heff_rec(2, shape_326_366, (V[]){v_t_2424, ((V)&g_heff_2erules_2ecasesAt_lam4_clo)});
  V f_ = v_k_2410;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2ecasesAt_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_vs_245 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_b_242 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_casesChk_247 = heff_env(self)[5];
  V v_hd_249 = heff_env(self)[6];
  V v_scrut_243 = heff_env(self)[7];
  V v_k_2410 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2411);
  V v_t_2412 = heff_arrayToList(heff_get(heff_dup(v_vs_245), LBL_keys));
  V v_t_2413 = heff_arrayToList(heff_get(v_vs_245, LBL_values));
  V v_t_2414 = (g_heff_2edict_2ezipKV(v_t_2412, v_t_2413));
  V v_c_2418 = (g_heff_2erules_2etraverseE(heff_clo(g_heff_2erules_2ecasesAt_lam2, 1, 5, (V[]){v_sp_240, v_e_241, v_b_242, v_a_244, v_casesChk_247}), v_t_2414));
  return heff_tail(v_c_2418, 2, (V[]){v_hd_249, heff_clo(g_heff_2erules_2ecasesAt_lam3, 1, 2, (V[]){v_scrut_243, v_k_2410})});
}
V g_heff_2erules_2ecasesAt_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_vs_245 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_e_241 = heff_env(self)[3];
  V v_b_242 = heff_env(self)[4];
  V v_a_244 = heff_env(self)[5];
  V v_casesChk_247 = heff_env(self)[6];
  V v_scrut_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo(g_heff_2erules_2ecasesAt_lam1, 1, 9, (V[]){v_vs_245, v_sp_240, v_e_241, v_b_242, v_a_244, v_casesChk_247, v_hd_249, v_scrut_243, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2erules_2ematchLater_str0 = {{0x80000000u, K_STR, 0}, 34, 34, {99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2erules_2ematchLater_str1 = {{0x80000000u, K_STR, 0}, 34, 34, {99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2erules_2ematchLater_str2 = {{0x80000000u, K_STR, 0}, 34, 34, {99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2erules_2ematchLater_str3 = {{0x80000000u, K_STR, 0}, 34, 34, {99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2erules_2ematchLater_str4 = {{0x80000000u, K_STR, 0}, 34, 34, {99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2erules_2ematchLater_str5 = {{0x80000000u, K_STR, 0}, 34, 34, {99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2erules_2ematchLater_str6 = {{0x80000000u, K_STR, 0}, 34, 34, {99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2erules_2ematchLater_str7 = {{0x80000000u, K_STR, 0}, 34, 34, {99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32}};
V g_heff_2erules_2ematchLater_lam1(V self, V *args);
V g_heff_2erules_2ematchLater_lam5(V self, V *args);
V g_heff_2erules_2ematchLater_lam4(V self, V *args);
V g_heff_2erules_2ematchLater_lam3(V self, V *args);
V g_heff_2erules_2ematchLater_lam8(V self, V *args);
V g_heff_2erules_2ematchLater_lam7(V self, V *args);
V g_heff_2erules_2ematchLater_lam6(V self, V *args);
V g_heff_2erules_2ematchLater_lam11(V self, V *args);
V g_heff_2erules_2ematchLater_lam10(V self, V *args);
V g_heff_2erules_2ematchLater_lam9(V self, V *args);
V g_heff_2erules_2ematchLater_lam14(V self, V *args);
V g_heff_2erules_2ematchLater_lam13(V self, V *args);
V g_heff_2erules_2ematchLater_lam12(V self, V *args);
V g_heff_2erules_2ematchLater_lam17(V self, V *args);
V g_heff_2erules_2ematchLater_lam16(V self, V *args);
V g_heff_2erules_2ematchLater_lam15(V self, V *args);
V g_heff_2erules_2ematchLater_lam20(V self, V *args);
V g_heff_2erules_2ematchLater_lam19(V self, V *args);
V g_heff_2erules_2ematchLater_lam18(V self, V *args);
V g_heff_2erules_2ematchLater_lam23(V self, V *args);
V g_heff_2erules_2ematchLater_lam22(V self, V *args);
V g_heff_2erules_2ematchLater_lam21(V self, V *args);
V g_heff_2erules_2ematchLater_lam26(V self, V *args);
V g_heff_2erules_2ematchLater_lam25(V self, V *args);
V g_heff_2erules_2ematchLater_lam24(V self, V *args);
V g_heff_2erules_2ematchLater_lam2(V self, V *args);
V g_heff_2erules_2ematchLater_lam0(V self, V *args);
Clo g_heff_2erules_2ematchLater_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2ematchLater_entry, 5, 0};

V g_heff_2erules_2ematchLater(V v_sp_240, V v_scrut_241, V v_a_242, V v_tags_243, V v_casesChk_244) {
top: ;
  return heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2erules_2ematchLater_lam0, 4, 5, (V[]){v_a_242, v_sp_240, v_scrut_241, heff_dup(v_tags_243), v_casesChk_244})});
}
V g_heff_2erules_2ematchLater_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2ematchLater(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[3]); return r;
}
V g_heff_2erules_2ematchLater_lam1(V self, V *args) {
  V v_c_249 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_249, LBL_metas); V a_1 = v_a_242; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2erules_2ematchLater_lam5(V self, V *args) {
  V v_u_2418 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2418);
  return v_b2_246;
}
V g_heff_2erules_2ematchLater_lam4(V self, V *args) {
  V v_u_2417 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2417);
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2emkNeu_24s10(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2ematchLater_lam5, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)))});
}
V g_heff_2erules_2ematchLater_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_True: {
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop(v_hd_247);
    V v_t_2419 = heff_rec(2, shape_326_366, (V[]){NTAG(TAG_SAbandon), heff_clo(g_heff_2erules_2ematchLater_lam4, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2419;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop(v_b2_246);
    V v_msg_2420 = heff_strAppend(((V)&g_heff_2erules_2ematchLater_str0), (g_heff_2erules_2etyStr(v_e2_245, v_x_2413)));
    V v_t_2421 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2420, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2422 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2423}));
    return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2424, v_k_248});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2erules_2ematchLater_lam8(V self, V *args) {
  V v_u_2431 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2431);
  return v_b2_246;
}
V g_heff_2erules_2ematchLater_lam7(V self, V *args) {
  V v_u_2430 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2430);
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2emkNeu_24s10(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2ematchLater_lam8, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)))});
}
V g_heff_2erules_2ematchLater_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2429)) {
  case TAG_True: {
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop(v_hd_247);
    V v_t_2432 = heff_rec(2, shape_326_366, (V[]){NTAG(TAG_SAbandon), heff_clo(g_heff_2erules_2ematchLater_lam7, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2432;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop(v_b2_246);
    V v_msg_2433 = heff_strAppend(((V)&g_heff_2erules_2ematchLater_str1), (g_heff_2erules_2etyStr(v_e2_245, v_x_2413)));
    V v_t_2434 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2433, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2435 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2436}));
    return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2437, v_k_248});
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2erules_2ematchLater_lam11(V self, V *args) {
  V v_u_2443 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2443);
  return v_b2_246;
}
V g_heff_2erules_2ematchLater_lam10(V self, V *args) {
  V v_u_2442 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2442);
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2emkNeu_24s10(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2ematchLater_lam11, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)))});
}
V g_heff_2erules_2ematchLater_lam9(V self, V *args) {
  V v_x_2441 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2441)) {
  case TAG_True: {
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop(v_hd_247);
    V v_t_2444 = heff_rec(2, shape_326_366, (V[]){NTAG(TAG_SAbandon), heff_clo(g_heff_2erules_2ematchLater_lam10, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2444;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop(v_b2_246);
    V v_msg_2445 = heff_strAppend(((V)&g_heff_2erules_2ematchLater_str2), (g_heff_2erules_2etyStr(v_e2_245, v_x_2413)));
    V v_t_2446 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2445, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2447 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2448}));
    return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2449, v_k_248});
  }
  default: return heff_nomatch(v_x_2441);
  }
}
V g_heff_2erules_2ematchLater_lam14(V self, V *args) {
  V v_u_2454 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2454);
  return v_b2_246;
}
V g_heff_2erules_2ematchLater_lam13(V self, V *args) {
  V v_u_2453 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2453);
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2emkNeu_24s10(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2ematchLater_lam14, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)))});
}
V g_heff_2erules_2ematchLater_lam12(V self, V *args) {
  V v_x_2452 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2452)) {
  case TAG_True: {
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop(v_hd_247);
    V v_t_2455 = heff_rec(2, shape_326_366, (V[]){NTAG(TAG_SAbandon), heff_clo(g_heff_2erules_2ematchLater_lam13, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2455;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop(v_b2_246);
    V v_msg_2456 = heff_strAppend(((V)&g_heff_2erules_2ematchLater_str3), (g_heff_2erules_2etyStr(v_e2_245, v_x_2413)));
    V v_t_2457 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2456, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2458 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2457})});
    V v_t_2459 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2459}));
    return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2460, v_k_248});
  }
  default: return heff_nomatch(v_x_2452);
  }
}
V g_heff_2erules_2ematchLater_lam17(V self, V *args) {
  V v_u_2463 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2463);
  return v_b2_246;
}
V g_heff_2erules_2ematchLater_lam16(V self, V *args) {
  V v_u_2462 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2462);
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2emkNeu_24s10(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2ematchLater_lam17, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)))});
}
V g_heff_2erules_2ematchLater_lam15(V self, V *args) {
  V v_x_2461 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2461)) {
  case TAG_True: {
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop(v_hd_247);
    V v_t_2464 = heff_rec(2, shape_326_366, (V[]){NTAG(TAG_SAbandon), heff_clo(g_heff_2erules_2ematchLater_lam16, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2464;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop(v_b2_246);
    V v_msg_2465 = heff_strAppend(((V)&g_heff_2erules_2ematchLater_str4), (g_heff_2erules_2etyStr(v_e2_245, v_x_2413)));
    V v_t_2466 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2465, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2467 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2468}));
    return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2469, v_k_248});
  }
  default: return heff_nomatch(v_x_2461);
  }
}
V g_heff_2erules_2ematchLater_lam20(V self, V *args) {
  V v_u_2472 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2472);
  return v_b2_246;
}
V g_heff_2erules_2ematchLater_lam19(V self, V *args) {
  V v_u_2471 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2471);
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2emkNeu_24s10(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2ematchLater_lam20, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)))});
}
V g_heff_2erules_2ematchLater_lam18(V self, V *args) {
  V v_x_2470 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2470)) {
  case TAG_True: {
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop(v_hd_247);
    V v_t_2473 = heff_rec(2, shape_326_366, (V[]){NTAG(TAG_SAbandon), heff_clo(g_heff_2erules_2ematchLater_lam19, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2473;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop(v_b2_246);
    V v_msg_2474 = heff_strAppend(((V)&g_heff_2erules_2ematchLater_str5), (g_heff_2erules_2etyStr(v_e2_245, v_x_2413)));
    V v_t_2475 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2474, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2476 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2476})});
    V v_t_2478 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2477}));
    return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2478, v_k_248});
  }
  default: return heff_nomatch(v_x_2470);
  }
}
V g_heff_2erules_2ematchLater_lam23(V self, V *args) {
  V v_u_2482 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2482);
  return v_b2_246;
}
V g_heff_2erules_2ematchLater_lam22(V self, V *args) {
  V v_u_2481 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2481);
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2emkNeu_24s10(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2ematchLater_lam23, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)))});
}
V g_heff_2erules_2ematchLater_lam21(V self, V *args) {
  V v_x_2480 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2480)) {
  case TAG_True: {
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop(v_hd_247);
    V v_t_2483 = heff_rec(2, shape_326_366, (V[]){NTAG(TAG_SAbandon), heff_clo(g_heff_2erules_2ematchLater_lam22, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2483;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop(v_b2_246);
    V v_msg_2484 = heff_strAppend(((V)&g_heff_2erules_2ematchLater_str6), (g_heff_2erules_2etyStr(v_e2_245, v_x_2413)));
    V v_t_2485 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2484, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2486 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2485})});
    V v_t_2487 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2486})});
    V v_t_2488 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2487}));
    return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2488, v_k_248});
  }
  default: return heff_nomatch(v_x_2480);
  }
}
V g_heff_2erules_2ematchLater_lam26(V self, V *args) {
  V v_u_2491 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2491);
  return v_b2_246;
}
V g_heff_2erules_2ematchLater_lam25(V self, V *args) {
  V v_u_2490 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2490);
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2emkNeu_24s10(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2ematchLater_lam26, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)))});
}
V g_heff_2erules_2ematchLater_lam24(V self, V *args) {
  V v_x_2489 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2489)) {
  case TAG_True: {
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop(v_hd_247);
    V v_t_2492 = heff_rec(2, shape_326_366, (V[]){NTAG(TAG_SAbandon), heff_clo(g_heff_2erules_2ematchLater_lam25, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2492;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop(v_b2_246);
    V v_msg_2493 = heff_strAppend(((V)&g_heff_2erules_2ematchLater_str7), (g_heff_2erules_2etyStr(v_e2_245, v_x_2413)));
    V v_t_2494 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2493, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2495 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2494})});
    V v_t_2496 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2495})});
    V v_t_2497 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2496}));
    return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2497, v_k_248});
  }
  default: return heff_nomatch(v_x_2489);
  }
}
V g_heff_2erules_2ematchLater_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_b2_246 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  V v_e2_245 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_scrut_241 = heff_env(self)[5];
  V v_tags_243 = heff_env(self)[6];
  V v_casesChk_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2414 = (g_heff_2evalue_2ebehavior(heff_dup(v_x_2413)));
  switch (heff_tag_of(v_t_2414)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2414, 0ULL, 1);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo(g_heff_2erules_2ematchLater_lam3, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2414, 0ULL, 4);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo(g_heff_2erules_2ematchLater_lam6, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2414, 0ULL, 3);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo(g_heff_2erules_2ematchLater_lam9, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeSum: {
    V v_vs_2450 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    V v_t_2451 = ({ V a_0 = v_sp_240; V a_1 = v_e2_245; V a_2 = v_b2_246; V a_3 = v_scrut_241; V a_4 = v_x_2413; V a_5 = v_vs_2450; V a_6 = v_tags_243; V a_7 = v_casesChk_244; V r_ = (g_heff_2erules_2ecasesAt(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_tags_243); r_; });
    return heff_tail(v_t_2451, 2, (V[]){v_hd_247, v_k_248});
  }
  case TAG_LikeInt: {
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo(g_heff_2erules_2ematchLater_lam12, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeFloat: {
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo(g_heff_2erules_2ematchLater_lam15, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeString: {
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo(g_heff_2erules_2ematchLater_lam18, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2414, 0ULL, 1);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo(g_heff_2erules_2ematchLater_lam21, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_NoRules: {
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo(g_heff_2erules_2ematchLater_lam24, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2erules_2ematchLater_lam0(V self, V *args) {
  V v_e2_245 = args[0];
  V v_b2_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V v_a_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_scrut_241 = heff_env(self)[2];
  V v_tags_243 = heff_env(self)[3];
  V v_casesChk_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2ematchLater_lam1, 1, 1, (V[]){v_a_242})})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2411}));
  V f_ = heff_get(heff_dup(v_hd_247), LBL_bind);
  args[0] = v_t_2412;
  args[1] = heff_clo(g_heff_2erules_2ematchLater_lam2, 1, 8, (V[]){v_hd_247, v_b2_246, v_k_248, v_e2_245, v_sp_240, v_scrut_241, v_tags_243, v_casesChk_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2erules_2esumElim_str0 = {{0x80000000u, K_STR, 0}, 46, 46, {99, 97, 110, 110, 111, 116, 32, 101, 108, 105, 109, 105, 110, 97, 116, 101, 32, 102, 114, 111, 109, 32, 115, 117, 109, 32, 116, 121, 112, 101, 32, 105, 110, 116, 111, 32, 108, 97, 114, 103, 101, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2esumElim_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {109, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2erules_2esumElim_str2 = {{0x80000000u, K_STR, 0}, 34, 34, {99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2esumElim_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {109, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2erules_2esumElim_str4 = {{0x80000000u, K_STR, 0}, 34, 34, {99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2esumElim_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {109, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2erules_2esumElim_str6 = {{0x80000000u, K_STR, 0}, 34, 34, {99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2esumElim_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {109, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2erules_2esumElim_str8 = {{0x80000000u, K_STR, 0}, 34, 34, {99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2esumElim_str9 = {{0x80000000u, K_STR, 0}, 5, 5, {109, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2erules_2esumElim_str10 = {{0x80000000u, K_STR, 0}, 34, 34, {99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2esumElim_str11 = {{0x80000000u, K_STR, 0}, 5, 5, {109, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2erules_2esumElim_str12 = {{0x80000000u, K_STR, 0}, 34, 34, {99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2esumElim_str13 = {{0x80000000u, K_STR, 0}, 5, 5, {109, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2erules_2esumElim_str14 = {{0x80000000u, K_STR, 0}, 34, 34, {99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2esumElim_str15 = {{0x80000000u, K_STR, 0}, 5, 5, {109, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2erules_2esumElim_str16 = {{0x80000000u, K_STR, 0}, 34, 34, {99, 97, 110, 110, 111, 116, 32, 109, 97, 116, 99, 104, 32, 97, 103, 97, 105, 110, 115, 116, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101, 32}};
V g_heff_2erules_2esumElim_lam1(V self, V *args);
V g_heff_2erules_2esumElim_lam4(V self, V *args);
V g_heff_2erules_2esumElim_lam8(V self, V *args);
V g_heff_2erules_2esumElim_lam7(V self, V *args);
V g_heff_2erules_2esumElim_lam6(V self, V *args);
V g_heff_2erules_2esumElim_lam11(V self, V *args);
V g_heff_2erules_2esumElim_lam10(V self, V *args);
V g_heff_2erules_2esumElim_lam9(V self, V *args);
V g_heff_2erules_2esumElim_lam14(V self, V *args);
V g_heff_2erules_2esumElim_lam13(V self, V *args);
V g_heff_2erules_2esumElim_lam12(V self, V *args);
V g_heff_2erules_2esumElim_lam17(V self, V *args);
V g_heff_2erules_2esumElim_lam16(V self, V *args);
V g_heff_2erules_2esumElim_lam15(V self, V *args);
V g_heff_2erules_2esumElim_lam20(V self, V *args);
V g_heff_2erules_2esumElim_lam19(V self, V *args);
V g_heff_2erules_2esumElim_lam18(V self, V *args);
V g_heff_2erules_2esumElim_lam23(V self, V *args);
V g_heff_2erules_2esumElim_lam22(V self, V *args);
V g_heff_2erules_2esumElim_lam21(V self, V *args);
V g_heff_2erules_2esumElim_lam26(V self, V *args);
V g_heff_2erules_2esumElim_lam25(V self, V *args);
V g_heff_2erules_2esumElim_lam24(V self, V *args);
V g_heff_2erules_2esumElim_lam29(V self, V *args);
V g_heff_2erules_2esumElim_lam28(V self, V *args);
V g_heff_2erules_2esumElim_lam27(V self, V *args);
V g_heff_2erules_2esumElim_lam5(V self, V *args);
V g_heff_2erules_2esumElim_lam3(V self, V *args);
V g_heff_2erules_2esumElim_lam2(V self, V *args);
V g_heff_2erules_2esumElim_lam0(V self, V *args);
Clo g_heff_2erules_2esumElim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2esumElim_entry, 4, 0};

V g_heff_2erules_2esumElim(V v_sp_240, V v_scrutSyn_241, V v_tags_242, V v_casesChk_243) {
top: ;
  return heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2erules_2esumElim_lam0, 2, 4, (V[]){v_sp_240, heff_dup(v_scrutSyn_241), heff_dup(v_tags_242), v_casesChk_243})});
}
V g_heff_2erules_2esumElim_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2esumElim(a[0], a[1], a[2], a[3]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
V g_heff_2erules_2esumElim_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k2_2410 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(323LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2esumElim_str0), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){v_t_2413}));
  V f_ = heff_get(v_hd_249, LBL_bind);
  args[0] = v_t_2414;
  args[1] = v_k2_2410;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2esumElim_lam4(V self, V *args) {
  V v_c_2422 = args[0];
  V v_a0_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_2422, LBL_metas); V a_1 = v_a0_2421; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2erules_2esumElim_lam8(V self, V *args) {
  V v_u_2431 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2431);
  return v_b_245;
}
V g_heff_2erules_2esumElim_lam7(V self, V *args) {
  V v_u_2430 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2430);
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2emkNeu_24s10(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2esumElim_lam8, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)))});
}
V g_heff_2erules_2esumElim_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_2429)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2420);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop(v_hd_2417);
    V v_t_2432 = heff_rec(2, shape_326_366, (V[]){NTAG(TAG_SAbandon), heff_clo(g_heff_2erules_2esumElim_lam7, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2418;
    args[0] = v_t_2432;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_2452;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_VU: {
      v_t_2452 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_2434 = heff_dup(heff_field(v_x_2426, 0));
      switch (heff_tag_of(v_it1_2434)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_2434, 0ULL, 1);
        v_t_2452 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_2434, 0ULL, 1);
        v_t_2452 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_2434, 0ULL, 1);
        v_t_2452 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2452 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_2434);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2452 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2452 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2452 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2452 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2452 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2452 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2452 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    switch (heff_tag_of(v_t_2452)) {
    case TAG_True: {
      V v_t_2453 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2420; V a_2 = heff_dup(v_x_2426); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2erules_2esumElim_str1); V a_3 = v_t_2453; V a_4 = v_x_2426; V a_5 = v_b_245; V a_6 = v_hd_2417; V a_7 = v_k_2418; V r_ = (g_heff_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2453); r_; });
    }
    case TAG_False: {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2420);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      V v_msg_2454 = heff_strAppend(((V)&g_heff_2erules_2esumElim_str2), (g_heff_2erules_2etyStr(v_e_244, v_x_2426)));
      V v_t_2455 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2454, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2456 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2455})});
      V v_t_2457 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2456})});
      V v_t_2458 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2417), LBL_malg), 1, (V[]){v_t_2457}));
      return heff_tail(heff_get(v_hd_2417, LBL_bind), 2, (V[]){v_t_2458, v_k_2418});
    }
    default: return heff_nomatch(v_t_2452);
    }
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2erules_2esumElim_lam11(V self, V *args) {
  V v_u_2465 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2465);
  return v_b_245;
}
V g_heff_2erules_2esumElim_lam10(V self, V *args) {
  V v_u_2464 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2464);
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2emkNeu_24s10(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2esumElim_lam11, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)))});
}
V g_heff_2erules_2esumElim_lam9(V self, V *args) {
  V v_x_2463 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_2463)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2420);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop(v_hd_2417);
    V v_t_2466 = heff_rec(2, shape_326_366, (V[]){NTAG(TAG_SAbandon), heff_clo(g_heff_2erules_2esumElim_lam10, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2418;
    args[0] = v_t_2466;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_2486;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_VU: {
      v_t_2486 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_2468 = heff_dup(heff_field(v_x_2426, 0));
      switch (heff_tag_of(v_it1_2468)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_2468, 0ULL, 1);
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_2468, 0ULL, 1);
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_2468, 0ULL, 1);
        v_t_2486 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_2468);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2486 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2486 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2486 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2486 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2486 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2486 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2486 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    switch (heff_tag_of(v_t_2486)) {
    case TAG_True: {
      V v_t_2487 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2420; V a_2 = heff_dup(v_x_2426); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2erules_2esumElim_str3); V a_3 = v_t_2487; V a_4 = v_x_2426; V a_5 = v_b_245; V a_6 = v_hd_2417; V a_7 = v_k_2418; V r_ = (g_heff_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2487); r_; });
    }
    case TAG_False: {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2420);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      V v_msg_2488 = heff_strAppend(((V)&g_heff_2erules_2esumElim_str4), (g_heff_2erules_2etyStr(v_e_244, v_x_2426)));
      V v_t_2489 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2488, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2490 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2489})});
      V v_t_2491 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2490})});
      V v_t_2492 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2417), LBL_malg), 1, (V[]){v_t_2491}));
      return heff_tail(heff_get(v_hd_2417, LBL_bind), 2, (V[]){v_t_2492, v_k_2418});
    }
    default: return heff_nomatch(v_t_2486);
    }
  }
  default: return heff_nomatch(v_x_2463);
  }
}
V g_heff_2erules_2esumElim_lam14(V self, V *args) {
  V v_u_2498 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2498);
  return v_b_245;
}
V g_heff_2erules_2esumElim_lam13(V self, V *args) {
  V v_u_2497 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2497);
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2emkNeu_24s10(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2esumElim_lam14, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)))});
}
V g_heff_2erules_2esumElim_lam12(V self, V *args) {
  V v_x_2496 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_2496)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2420);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop(v_hd_2417);
    V v_t_2499 = heff_rec(2, shape_326_366, (V[]){NTAG(TAG_SAbandon), heff_clo(g_heff_2erules_2esumElim_lam13, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2418;
    args[0] = v_t_2499;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_24119;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_VU: {
      v_t_24119 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24101 = heff_dup(heff_field(v_x_2426, 0));
      switch (heff_tag_of(v_it1_24101)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24101, 0ULL, 1);
        v_t_24119 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24101, 0ULL, 1);
        v_t_24119 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24101, 0ULL, 1);
        v_t_24119 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24119 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24101);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24119 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24119 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24119 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24119 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24119 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24119 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24119 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    switch (heff_tag_of(v_t_24119)) {
    case TAG_True: {
      V v_t_24120 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2420; V a_2 = heff_dup(v_x_2426); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2erules_2esumElim_str5); V a_3 = v_t_24120; V a_4 = v_x_2426; V a_5 = v_b_245; V a_6 = v_hd_2417; V a_7 = v_k_2418; V r_ = (g_heff_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24120); r_; });
    }
    case TAG_False: {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2420);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      V v_msg_24121 = heff_strAppend(((V)&g_heff_2erules_2esumElim_str6), (g_heff_2erules_2etyStr(v_e_244, v_x_2426)));
      V v_t_24122 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24121, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24123 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24122})});
      V v_t_24124 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24123})});
      V v_t_24125 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2417), LBL_malg), 1, (V[]){v_t_24124}));
      return heff_tail(heff_get(v_hd_2417, LBL_bind), 2, (V[]){v_t_24125, v_k_2418});
    }
    default: return heff_nomatch(v_t_24119);
    }
  }
  default: return heff_nomatch(v_x_2496);
  }
}
V g_heff_2erules_2esumElim_lam17(V self, V *args) {
  V v_u_24130 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24130);
  return v_b_245;
}
V g_heff_2erules_2esumElim_lam16(V self, V *args) {
  V v_u_24129 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24129);
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2emkNeu_24s10(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2esumElim_lam17, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)))});
}
V g_heff_2erules_2esumElim_lam15(V self, V *args) {
  V v_x_24128 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_24128)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2420);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop(v_hd_2417);
    V v_t_24131 = heff_rec(2, shape_326_366, (V[]){NTAG(TAG_SAbandon), heff_clo(g_heff_2erules_2esumElim_lam16, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2418;
    args[0] = v_t_24131;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_24151;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_VU: {
      v_t_24151 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24133 = heff_dup(heff_field(v_x_2426, 0));
      switch (heff_tag_of(v_it1_24133)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24133, 0ULL, 1);
        v_t_24151 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24133, 0ULL, 1);
        v_t_24151 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24133, 0ULL, 1);
        v_t_24151 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24151 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24133);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24151 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24151 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24151 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24151 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24151 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24151 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24151 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    switch (heff_tag_of(v_t_24151)) {
    case TAG_True: {
      V v_t_24152 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2420; V a_2 = heff_dup(v_x_2426); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2erules_2esumElim_str7); V a_3 = v_t_24152; V a_4 = v_x_2426; V a_5 = v_b_245; V a_6 = v_hd_2417; V a_7 = v_k_2418; V r_ = (g_heff_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24152); r_; });
    }
    case TAG_False: {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2420);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      V v_msg_24153 = heff_strAppend(((V)&g_heff_2erules_2esumElim_str8), (g_heff_2erules_2etyStr(v_e_244, v_x_2426)));
      V v_t_24154 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24153, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24155 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24154})});
      V v_t_24156 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24155})});
      V v_t_24157 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2417), LBL_malg), 1, (V[]){v_t_24156}));
      return heff_tail(heff_get(v_hd_2417, LBL_bind), 2, (V[]){v_t_24157, v_k_2418});
    }
    default: return heff_nomatch(v_t_24151);
    }
  }
  default: return heff_nomatch(v_x_24128);
  }
}
V g_heff_2erules_2esumElim_lam20(V self, V *args) {
  V v_u_24160 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24160);
  return v_b_245;
}
V g_heff_2erules_2esumElim_lam19(V self, V *args) {
  V v_u_24159 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24159);
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2emkNeu_24s10(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2esumElim_lam20, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)))});
}
V g_heff_2erules_2esumElim_lam18(V self, V *args) {
  V v_x_24158 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_24158)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2420);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop(v_hd_2417);
    V v_t_24161 = heff_rec(2, shape_326_366, (V[]){NTAG(TAG_SAbandon), heff_clo(g_heff_2erules_2esumElim_lam19, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2418;
    args[0] = v_t_24161;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_24181;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_VU: {
      v_t_24181 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24163 = heff_dup(heff_field(v_x_2426, 0));
      switch (heff_tag_of(v_it1_24163)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24163, 0ULL, 1);
        v_t_24181 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24163, 0ULL, 1);
        v_t_24181 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24163, 0ULL, 1);
        v_t_24181 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24181 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24163);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24181 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24181 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24181 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24181 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24181 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24181 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24181 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    switch (heff_tag_of(v_t_24181)) {
    case TAG_True: {
      V v_t_24182 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2420; V a_2 = heff_dup(v_x_2426); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2erules_2esumElim_str9); V a_3 = v_t_24182; V a_4 = v_x_2426; V a_5 = v_b_245; V a_6 = v_hd_2417; V a_7 = v_k_2418; V r_ = (g_heff_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24182); r_; });
    }
    case TAG_False: {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2420);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      V v_msg_24183 = heff_strAppend(((V)&g_heff_2erules_2esumElim_str10), (g_heff_2erules_2etyStr(v_e_244, v_x_2426)));
      V v_t_24184 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24183, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24185 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24184})});
      V v_t_24186 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24185})});
      V v_t_24187 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2417), LBL_malg), 1, (V[]){v_t_24186}));
      return heff_tail(heff_get(v_hd_2417, LBL_bind), 2, (V[]){v_t_24187, v_k_2418});
    }
    default: return heff_nomatch(v_t_24181);
    }
  }
  default: return heff_nomatch(v_x_24158);
  }
}
V g_heff_2erules_2esumElim_lam23(V self, V *args) {
  V v_u_24190 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24190);
  return v_b_245;
}
V g_heff_2erules_2esumElim_lam22(V self, V *args) {
  V v_u_24189 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24189);
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2emkNeu_24s10(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2esumElim_lam23, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)))});
}
V g_heff_2erules_2esumElim_lam21(V self, V *args) {
  V v_x_24188 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_24188)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2420);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop(v_hd_2417);
    V v_t_24191 = heff_rec(2, shape_326_366, (V[]){NTAG(TAG_SAbandon), heff_clo(g_heff_2erules_2esumElim_lam22, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2418;
    args[0] = v_t_24191;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_24211;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_VU: {
      v_t_24211 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24193 = heff_dup(heff_field(v_x_2426, 0));
      switch (heff_tag_of(v_it1_24193)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24193, 0ULL, 1);
        v_t_24211 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24193, 0ULL, 1);
        v_t_24211 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24193, 0ULL, 1);
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24211 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24193);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24211 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24211 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24211 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24211 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24211 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24211 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24211 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    switch (heff_tag_of(v_t_24211)) {
    case TAG_True: {
      V v_t_24212 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2420; V a_2 = heff_dup(v_x_2426); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2erules_2esumElim_str11); V a_3 = v_t_24212; V a_4 = v_x_2426; V a_5 = v_b_245; V a_6 = v_hd_2417; V a_7 = v_k_2418; V r_ = (g_heff_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24212); r_; });
    }
    case TAG_False: {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2420);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      V v_msg_24213 = heff_strAppend(((V)&g_heff_2erules_2esumElim_str12), (g_heff_2erules_2etyStr(v_e_244, v_x_2426)));
      V v_t_24214 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24213, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24215 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24214})});
      V v_t_24216 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24215})});
      V v_t_24217 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2417), LBL_malg), 1, (V[]){v_t_24216}));
      return heff_tail(heff_get(v_hd_2417, LBL_bind), 2, (V[]){v_t_24217, v_k_2418});
    }
    default: return heff_nomatch(v_t_24211);
    }
  }
  default: return heff_nomatch(v_x_24188);
  }
}
V g_heff_2erules_2esumElim_lam26(V self, V *args) {
  V v_u_24221 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24221);
  return v_b_245;
}
V g_heff_2erules_2esumElim_lam25(V self, V *args) {
  V v_u_24220 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24220);
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2emkNeu_24s10(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2esumElim_lam26, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)))});
}
V g_heff_2erules_2esumElim_lam24(V self, V *args) {
  V v_x_24219 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_24219)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2420);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop(v_hd_2417);
    V v_t_24222 = heff_rec(2, shape_326_366, (V[]){NTAG(TAG_SAbandon), heff_clo(g_heff_2erules_2esumElim_lam25, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2418;
    args[0] = v_t_24222;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_24242;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_VU: {
      v_t_24242 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24224 = heff_dup(heff_field(v_x_2426, 0));
      switch (heff_tag_of(v_it1_24224)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24224, 0ULL, 1);
        v_t_24242 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24224, 0ULL, 1);
        v_t_24242 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24224, 0ULL, 1);
        v_t_24242 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24242 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24224);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24242 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24242 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24242 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24242 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24242 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24242 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24242 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    switch (heff_tag_of(v_t_24242)) {
    case TAG_True: {
      V v_t_24243 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2420; V a_2 = heff_dup(v_x_2426); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2erules_2esumElim_str13); V a_3 = v_t_24243; V a_4 = v_x_2426; V a_5 = v_b_245; V a_6 = v_hd_2417; V a_7 = v_k_2418; V r_ = (g_heff_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24243); r_; });
    }
    case TAG_False: {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2420);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      V v_msg_24244 = heff_strAppend(((V)&g_heff_2erules_2esumElim_str14), (g_heff_2erules_2etyStr(v_e_244, v_x_2426)));
      V v_t_24245 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24244, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24245})});
      V v_t_24247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24246})});
      V v_t_24248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2417), LBL_malg), 1, (V[]){v_t_24247}));
      return heff_tail(heff_get(v_hd_2417, LBL_bind), 2, (V[]){v_t_24248, v_k_2418});
    }
    default: return heff_nomatch(v_t_24242);
    }
  }
  default: return heff_nomatch(v_x_24219);
  }
}
V g_heff_2erules_2esumElim_lam29(V self, V *args) {
  V v_u_24251 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24251);
  return v_b_245;
}
V g_heff_2erules_2esumElim_lam28(V self, V *args) {
  V v_u_24250 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24250);
  return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2emkNeu_24s10(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2esumElim_lam29, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)))});
}
V g_heff_2erules_2esumElim_lam27(V self, V *args) {
  V v_x_24249 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_24249)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2420);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop(v_hd_2417);
    V v_t_24252 = heff_rec(2, shape_326_366, (V[]){NTAG(TAG_SAbandon), heff_clo(g_heff_2erules_2esumElim_lam28, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2418;
    args[0] = v_t_24252;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_24272;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_VU: {
      v_t_24272 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_it1_24254 = heff_dup(heff_field(v_x_2426, 0));
      switch (heff_tag_of(v_it1_24254)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_24254, 0ULL, 1);
        v_t_24272 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_24254, 0ULL, 1);
        v_t_24272 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_24254, 0ULL, 1);
        v_t_24272 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24272 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_24254);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24272 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24272 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24272 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24272 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24272 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24272 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24272 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    switch (heff_tag_of(v_t_24272)) {
    case TAG_True: {
      V v_t_24273 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2420; V a_2 = heff_dup(v_x_2426); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2erules_2esumElim_str15); V a_3 = v_t_24273; V a_4 = v_x_2426; V a_5 = v_b_245; V a_6 = v_hd_2417; V a_7 = v_k_2418; V r_ = (g_heff_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24273); r_; });
    }
    case TAG_False: {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2420);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      V v_msg_24274 = heff_strAppend(((V)&g_heff_2erules_2esumElim_str16), (g_heff_2erules_2etyStr(v_e_244, v_x_2426)));
      V v_t_24275 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24274, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24276 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_24275})});
      V v_t_24277 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24276})});
      V v_t_24278 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2417), LBL_malg), 1, (V[]){v_t_24277}));
      return heff_tail(heff_get(v_hd_2417, LBL_bind), 2, (V[]){v_t_24278, v_k_2418});
    }
    default: return heff_nomatch(v_t_24272);
    }
  }
  default: return heff_nomatch(v_x_24249);
  }
}
V g_heff_2erules_2esumElim_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2417 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_k_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2420 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2427 = (g_heff_2evalue_2ebehavior(heff_dup(v_x_2426)));
  switch (heff_tag_of(v_t_2427)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2427, 0ULL, 1);
    return (g_heff_2emeta_2eblockedTy(heff_dup(v_x_2426), heff_dup(v_hd_2417), heff_clo(g_heff_2erules_2esumElim_lam6, 1, 9, (V[]){v_b_245, v_k_2418, v_x_2426, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244, v_hd_2417})));
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2427, 0ULL, 4);
    return (g_heff_2emeta_2eblockedTy(heff_dup(v_x_2426), heff_dup(v_hd_2417), heff_clo(g_heff_2erules_2esumElim_lam9, 1, 9, (V[]){v_b_245, v_k_2418, v_x_2426, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244, v_hd_2417})));
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2427, 0ULL, 3);
    return (g_heff_2emeta_2eblockedTy(heff_dup(v_x_2426), heff_dup(v_hd_2417), heff_clo(g_heff_2erules_2esumElim_lam12, 1, 9, (V[]){v_b_245, v_k_2418, v_x_2426, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244, v_hd_2417})));
  }
  case TAG_LikeSum: {
    V v_vs_24126 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    V v_t_24127 = ({ V a_0 = v_sp_240; V a_1 = v_e_244; V a_2 = v_b_245; V a_3 = v_scrut_2420; V a_4 = v_x_2426; V a_5 = v_vs_24126; V a_6 = v_tags_242; V a_7 = v_casesChk_243; V r_ = (g_heff_2erules_2ecasesAt(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_tags_242); r_; });
    return heff_tail(v_t_24127, 2, (V[]){v_hd_2417, v_k_2418});
  }
  case TAG_LikeInt: {
    return (g_heff_2emeta_2eblockedTy(heff_dup(v_x_2426), heff_dup(v_hd_2417), heff_clo(g_heff_2erules_2esumElim_lam15, 1, 9, (V[]){v_b_245, v_k_2418, v_x_2426, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244, v_hd_2417})));
  }
  case TAG_LikeFloat: {
    return (g_heff_2emeta_2eblockedTy(heff_dup(v_x_2426), heff_dup(v_hd_2417), heff_clo(g_heff_2erules_2esumElim_lam18, 1, 9, (V[]){v_b_245, v_k_2418, v_x_2426, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244, v_hd_2417})));
  }
  case TAG_LikeString: {
    return (g_heff_2emeta_2eblockedTy(heff_dup(v_x_2426), heff_dup(v_hd_2417), heff_clo(g_heff_2erules_2esumElim_lam21, 1, 9, (V[]){v_b_245, v_k_2418, v_x_2426, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244, v_hd_2417})));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2427, 0ULL, 1);
    return (g_heff_2emeta_2eblockedTy(heff_dup(v_x_2426), heff_dup(v_hd_2417), heff_clo(g_heff_2erules_2esumElim_lam24, 1, 9, (V[]){v_b_245, v_k_2418, v_x_2426, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244, v_hd_2417})));
  }
  case TAG_NoRules: {
    return (g_heff_2emeta_2eblockedTy(heff_dup(v_x_2426), heff_dup(v_hd_2417), heff_clo(g_heff_2erules_2esumElim_lam27, 1, 9, (V[]){v_b_245, v_k_2418, v_x_2426, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244, v_hd_2417})));
  }
  default: return heff_nomatch(v_t_2427);
  }
}
V g_heff_2erules_2esumElim_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_2417 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_k_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_tags_242 = heff_env(self)[4];
  V v_casesChk_243 = heff_env(self)[5];
  V v_e_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_MkPair: {
    V v_scrut_2420 = heff_field(v_x_2419, 0);
    V v_a0_2421 = heff_field(v_x_2419, 1);
    heff_take_n(v_x_2419, 3ULL, 2);
    V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2esumElim_lam4, 1, 1, (V[]){v_a0_2421})})});
    V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2417), LBL_malg), 1, (V[]){v_t_2424}));
    return heff_tail(heff_get(heff_dup(v_hd_2417), LBL_bind), 2, (V[]){v_t_2425, heff_clo(g_heff_2erules_2esumElim_lam5, 1, 8, (V[]){v_hd_2417, v_b_245, v_k_2418, v_sp_240, v_scrut_2420, v_tags_242, v_casesChk_243, v_e_244})});
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2erules_2esumElim_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_tags_242 = heff_env(self)[3];
  V v_casesChk_243 = heff_env(self)[4];
  V v_e_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo(g_heff_2erules_2esumElim_lam3, 1, 7, (V[]){v_hd_2417, v_b_245, v_k_2418, v_sp_240, v_tags_242, v_casesChk_243, v_e_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2esumElim_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_b_245 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_scrutSyn_241 = heff_env(self)[1];
  V v_tags_242 = heff_env(self)[2];
  V v_casesChk_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_246 = (g_heff_2evalue_2elevelOf(v_b_245));
  V v_x1_247;
  switch (heff_tag_of(v_x1_246)) {
  case TAG_Small: {
    v_x1_247 = NTAG(TAG_True);
    break;
  }
  case TAG_Large: {
    v_x1_247 = NTAG(TAG_False);
    break;
  }
  case TAG_TopL: {
    v_x1_247 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_246);
  }
  V v_t_248;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_True: {
    v_t_248 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_248 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    heff_drop(v_e_244);
    heff_drop(v_b_245);
    heff_drop(v_scrutSyn_241);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    return heff_clo(g_heff_2erules_2esumElim_lam1, 2, 1, (V[]){v_sp_240});
  }
  case TAG_False: {
    V v_c_2416;
    switch (heff_tag_of(v_scrutSyn_241)) {
    case TAG_MkSyn: {
      V v_f_2415 = heff_field(v_scrutSyn_241, 0);
      heff_take_n(v_scrutSyn_241, 1ULL, 1);
      v_c_2416 = heff_tr(heff_apply(v_f_2415, 1, (V[]){heff_dup(v_e_244)}));
      break;
    }
    default: heff_nomatch(v_scrutSyn_241);
    }
    return heff_clo(g_heff_2erules_2esumElim_lam2, 2, 6, (V[]){v_c_2416, v_b_245, v_sp_240, v_tags_242, v_casesChk_243, v_e_244});
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2erules_2ecaseLet_lam3(V self, V *args);
V g_heff_2erules_2ecaseLet_lam5(V self, V *args);
V g_heff_2erules_2ecaseLet_lam7(V self, V *args);
V g_heff_2erules_2ecaseLet_lam8(V self, V *args);
V g_heff_2erules_2ecaseLet_lam6(V self, V *args);
V g_heff_2erules_2ecaseLet_lam4(V self, V *args);
V g_heff_2erules_2ecaseLet_lam2(V self, V *args);
V g_heff_2erules_2ecaseLet_lam1(V self, V *args);
V g_heff_2erules_2ecaseLet_lam0(V self, V *args);
Clo g_heff_2erules_2ecaseLet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2ecaseLet_entry, 3, 0};

V g_heff_2erules_2ecaseLet(V v_x_240, V v_scrutSyn_241, V v_body_242) {
top: ;
  return heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2erules_2ecaseLet_lam0, 2, 3, (V[]){heff_dup(v_scrutSyn_241), v_x_240, heff_dup(v_body_242)})});
}
V g_heff_2erules_2ecaseLet_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2ecaseLet(a[0], a[1], a[2]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
V g_heff_2erules_2ecaseLet_lam3(V self, V *args) {
  V v_c_2412 = args[0];
  V v_a0_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_2412, LBL_metas); V a_1 = v_a0_2411; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2erules_2ecaseLet_lam5(V self, V *args) {
  V v_v_2417 = args[0];
  V v_scope_27_2418 = args[1];
  V v_body_242 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_b_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_v_2417);
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2419 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    V v_t_2420 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){v_scope_27_2418, heff_get(heff_dup(v_e_243), LBL_globals), heff_get(heff_dup(v_e_243), LBL_elabFor), heff_get(heff_dup(v_e_243), LBL_lams), heff_get(heff_dup(v_e_243), LBL_self), heff_get(v_e_243, LBL_insts)});
    V f_ = v_f_2419;
    args[0] = v_t_2420;
    args[1] = v_b_244;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_body_242);
  }
}
V g_heff_2erules_2ecaseLet_lam7(V self, V *args) {
  V v_u_2430 = args[0];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2430);
  return heff_tag(TAG_Nom, 1, (V[]){v_x_2416});
}
V g_heff_2erules_2ecaseLet_lam8(V self, V *args) {
  V v_u_2434 = args[0];
  V v_b_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2434);
  return heff_tag(TAG_Nom, 1, (V[]){v_b_244});
}
V g_heff_2erules_2ecaseLet_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_b_244 = heff_env(self)[2];
  V v_x_240 = heff_env(self)[3];
  V v_scrut_2410 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2423 = heff_get(heff_dup(v_e_243), LBL_elabFor);
  V v_t_2426;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_ForNominative: {
    v_t_2426 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2423, 0ULL, 2);
    v_t_2426 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  V v_t_2427 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_locals);
  V v_t_2428 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_len);
  V v_t_2429 = (g_heff_2ereadback_2ereadbTypeF_24s182(v_t_2428, heff_dup(v_x_2416)));
  V v_dom_2431 = heff_rec(2, shape_326_366, (V[]){v_t_2429, heff_clo(g_heff_2erules_2ecaseLet_lam7, 1, 1, (V[]){v_x_2416})});
  V v_t_2432 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_len);
  V v_t_2433 = (g_heff_2ereadback_2ereadbTypeF_24s182(heff_intAdd(v_t_2432, MK_INT(1LL)), heff_dup(v_b_244)));
  V v_cod_2435 = heff_tag(TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), heff_rec(2, shape_326_366, (V[]){v_t_2433, heff_clo(g_heff_2erules_2ecaseLet_lam8, 1, 1, (V[]){v_b_244})})});
  V v_t_2436 = heff_get(heff_get(heff_dup(v_e_243), LBL_scope), LBL_locals);
  V v_t_2437 = (g_heff_2ememoed_2efunctionI(NTAG(TAG_Expl), heff_get(heff_dup(v_e_243), LBL_globals), v_t_2436, v_dom_2431, v_cod_2435));
  V v_t_2438 = (g_heff_2ememoed_2elam(v_t_2426, heff_get(v_e_243, LBL_globals), v_t_2427, v_t_2437, heff_tag(TAG_MkAbs, 2, (V[]){v_x_240, v_x_2422})));
  V v_x_2439 = (g_heff_2ememoed_2eapp(v_t_2438, v_scrut_2410));
  V f_ = v_k_248;
  args[0] = v_x_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2ecaseLet_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_b_244 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_scrut_2410 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2421 = heff_tr(g_heff_2eenvironment_2ewithBound(heff_dup(v_x_240), heff_dup(v_x_2416), heff_get(heff_dup(v_e_243), LBL_scope), heff_clo(g_heff_2erules_2ecaseLet_lam5, 2, 3, (V[]){v_body_242, heff_dup(v_e_243), heff_dup(v_b_244)})));
  return heff_tail(v_c_2421, 2, (V[]){v_hd_247, heff_clo(g_heff_2erules_2ecaseLet_lam6, 1, 6, (V[]){v_e_243, v_x_2416, v_b_244, v_x_240, v_scrut_2410, v_k_248})});
}
V g_heff_2erules_2ecaseLet_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  V v_b_244 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_scrut_2410 = heff_field(v_x_249, 0);
    V v_a0_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2ecaseLet_lam3, 1, 1, (V[]){v_a0_2411})})});
    V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2414}));
    return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_2415, heff_clo(g_heff_2erules_2ecaseLet_lam4, 1, 7, (V[]){v_x_240, v_e_243, v_body_242, v_b_244, v_hd_247, v_scrut_2410, v_k_248})});
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2erules_2ecaseLet_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  V v_b_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2erules_2ecaseLet_lam2, 1, 6, (V[]){v_hd_247, v_x_240, v_e_243, v_body_242, v_b_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2ecaseLet_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_b_244 = args[1];
  V v_scrutSyn_241 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246;
  switch (heff_tag_of(v_scrutSyn_241)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_scrutSyn_241, 0);
    heff_take_n(v_scrutSyn_241, 1ULL, 1);
    v_c_246 = heff_tr(heff_apply(v_f_245, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_scrutSyn_241);
  }
  return heff_clo(g_heff_2erules_2ecaseLet_lam1, 2, 5, (V[]){v_c_246, v_x_240, v_e_243, v_body_242, v_b_244});
}
V g_heff_2erules_2efixEnv_lam0(V self, V *args);
V g_heff_2erules_2efixEnv_lam1(V self, V *args);
Clo g_heff_2erules_2efixEnv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2efixEnv_entry, 3, 0};

V g_heff_2erules_2efixEnv(V v_e_240, V v_x_241, V v_a_242) {
top: ;
  V v_t_243 = heff_get(heff_get(heff_dup(v_e_240), LBL_scope), LBL_len);
  V v_v_245 = (g_heff_2evalue_2emkNeu_24s10(heff_tag(TAG_HLocal, 1, (V[]){v_t_243}), NTAG(TAG_SpId), heff_clo(g_heff_2erules_2efixEnv_lam0, 1, 1, (V[]){heff_dup(v_a_242)}), NTAG(TAG_Nothing)));
  V v_c_246 = heff_get(heff_dup(v_e_240), LBL_scope);
  V v_t_247 = heff_intAdd(heff_get(heff_dup(v_c_246), LBL_len), MK_INT(1LL));
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){v_x_241, heff_get(heff_dup(v_c_246), LBL_names)});
  V v_t_2410 = heff_tag(TAG_LSnoc, 2, (V[]){heff_get(heff_dup(v_c_246), LBL_locals), heff_clo(g_heff_2erules_2efixEnv_lam1, 1, 1, (V[]){v_v_245})});
  V v_t_2411 = heff_tag(TAG_CBind, 3, (V[]){heff_get(v_c_246, LBL_ctx), heff_tag(TAG_BDelayedBy, 1, (V[]){MK_INT(1LL)}), v_a_242});
  return heff_rec(6, shape_289_115_81_161_295_145, (V[]){heff_rec(4, shape_168_200_179_53, (V[]){v_t_247, v_t_248, v_t_2410, v_t_2411}), heff_get(heff_dup(v_e_240), LBL_globals), NTAG(TAG_ForNominative), MK_INT(0LL), heff_get(heff_dup(v_e_240), LBL_self), heff_get(v_e_240, LBL_insts)});
}
V g_heff_2erules_2efixEnv_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2efixEnv(a[0], a[1], a[2]);
}
V g_heff_2erules_2efixEnv_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_244);
  return v_a_242;
}
V g_heff_2erules_2efixEnv_lam1(V self, V *args) {
  V v_u_249 = args[0];
  V v_v_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return v_v_245;
}
V g_heff_2erules_2elocalDef_lam4(V self, V *args);
V g_heff_2erules_2elocalDef_lam6(V self, V *args);
V g_heff_2erules_2elocalDef_lam7(V self, V *args); static Clo g_heff_2erules_2elocalDef_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2elocalDef_lam7, 1, 0};
V g_heff_2erules_2elocalDef_lam5(V self, V *args);
V g_heff_2erules_2elocalDef_lam3(V self, V *args);
V g_heff_2erules_2elocalDef_lam2(V self, V *args);
V g_heff_2erules_2elocalDef_lam1(V self, V *args);
V g_heff_2erules_2elocalDef_lam0(V self, V *args);
Clo g_heff_2erules_2elocalDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2elocalDef_entry, 4, 0};

V g_heff_2erules_2elocalDef(V v_x_240, V v_typ_241, V v_body_242, V v_rest_243) {
top: ;
  return heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2erules_2elocalDef_lam0, 2, 4, (V[]){heff_dup(v_typ_241), v_x_240, heff_dup(v_body_242), heff_dup(v_rest_243)})});
}
V g_heff_2erules_2elocalDef_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2elocalDef(a[0], a[1], a[2], a[3]); heff_drop(a[1]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
V g_heff_2erules_2elocalDef_lam4(V self, V *args) {
  V v_v_2431 = args[0];
  V v_scope_27_2432 = args[1];
  V v_rest_243 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_b_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_v_2431);
  switch (heff_tag_of(v_rest_243)) {
  case TAG_MkChk: {
    V v_f_2433 = heff_field(v_rest_243, 0);
    heff_take_n(v_rest_243, 1ULL, 1);
    V v_t_2434 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){v_scope_27_2432, heff_get(heff_dup(v_e_244), LBL_globals), heff_get(heff_dup(v_e_244), LBL_elabFor), heff_get(heff_dup(v_e_244), LBL_lams), heff_get(heff_dup(v_e_244), LBL_self), heff_get(v_e_244, LBL_insts)});
    V f_ = v_f_2433;
    args[0] = v_t_2434;
    args[1] = v_b_245;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_rest_243);
  }
}
V g_heff_2erules_2elocalDef_lam6(V self, V *args) {
  V v_u_2444 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2444);
  return heff_tag(TAG_Nom, 1, (V[]){v_b_245});
}
V g_heff_2erules_2elocalDef_lam7(V self, V *args) {
  V v_u_2451 = args[0];
  heff_drop(v_u_2451);
  return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2erules_2elocalDef_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_x_240 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_x_2425 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2437 = heff_get(heff_dup(v_e_244), LBL_elabFor);
  V v_t_2440;
  switch (heff_tag_of(v_t_2437)) {
  case TAG_ForNominative: {
    v_t_2440 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2437, 0ULL, 2);
    v_t_2440 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2437);
  }
  V v_t_2441 = heff_get(heff_get(heff_dup(v_e_244), LBL_scope), LBL_locals);
  V v_t_2442 = heff_get(heff_get(heff_dup(v_e_244), LBL_scope), LBL_len);
  V v_t_2443 = (g_heff_2ereadback_2ereadbTypeF_24s182(heff_intAdd(v_t_2442, MK_INT(1LL)), heff_dup(v_b_245)));
  V v_cod_2445 = heff_tag(TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), heff_rec(2, shape_326_366, (V[]){v_t_2443, heff_clo(g_heff_2erules_2elocalDef_lam6, 1, 1, (V[]){v_b_245})})});
  V v_t_2446 = heff_get(heff_get(heff_dup(v_e_244), LBL_scope), LBL_locals);
  V v_t_2447 = (g_heff_2ememoed_2efunctionI(NTAG(TAG_Expl), heff_get(heff_dup(v_e_244), LBL_globals), v_t_2446, heff_dup(v_x_2411), v_cod_2445));
  V v_t_2448 = (g_heff_2ememoed_2elam(v_t_2440, heff_get(v_e_244, LBL_globals), v_t_2441, v_t_2447, heff_tag(TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), v_x_2436})));
  V v_t_2449 = heff_tag(TAG_MkAbs, 2, (V[]){v_x_240, heff_get(v_x_2425, LBL_stx)});
  V v_t_2450 = heff_tag(TAG_SFix, 2, (V[]){heff_get(v_x_2411, LBL_stx), v_t_2449});
  V v_x_2452 = (g_heff_2ememoed_2eapp(v_t_2448, heff_rec(2, shape_326_366, (V[]){v_t_2450, ((V)&g_heff_2erules_2elocalDef_lam7_clo)})));
  V f_ = v_k_2410;
  args[0] = v_x_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2elocalDef_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_rest_243 = heff_env(self)[3];
  V v_b_245 = heff_env(self)[4];
  V v_hd_249 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_x_2411), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2430;
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_Nom: {
    V v_x_2427 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_t_2430 = v_x_2427;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2426, 0ULL, 1);
    v_t_2430 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2429 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_t_2430 = v_x_2429;
    break;
  }
  default: heff_nomatch(v_x1_2426);
  }
  V v_c_2435 = heff_tr(g_heff_2eenvironment_2ewithBound(heff_dup(v_x_240), v_t_2430, heff_get(heff_dup(v_e_244), LBL_scope), heff_clo(g_heff_2erules_2elocalDef_lam4, 2, 3, (V[]){v_rest_243, heff_dup(v_e_244), heff_dup(v_b_245)})));
  return heff_tail(v_c_2435, 2, (V[]){v_hd_249, heff_clo(g_heff_2erules_2elocalDef_lam5, 1, 6, (V[]){v_e_244, v_b_245, v_x_240, v_x_2411, v_x_2425, v_k_2410})});
}
V g_heff_2erules_2elocalDef_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_rest_243 = heff_env(self)[4];
  V v_b_245 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_x_2411), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2416;
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nom: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2413;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2412, 0ULL, 1);
    v_t_2416 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2415 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  V v_e_2417 = (g_heff_2erules_2efixEnv(heff_dup(v_e_244), heff_dup(v_x_240), v_t_2416));
  V v_x1_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_x_2411), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_a_2422;
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_Nom: {
    V v_x_2419 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    v_a_2422 = v_x_2419;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2418, 0ULL, 1);
    v_a_2422 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2421 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    v_a_2422 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_x1_2418);
  }
  V v_c_2424;
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2423 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    v_c_2424 = heff_tr(heff_apply(v_f_2423, 2, (V[]){v_e_2417, v_a_2422}));
    break;
  }
  default: heff_nomatch(v_body_242);
  }
  return heff_tail(v_c_2424, 2, (V[]){heff_dup(v_hd_249), heff_clo(g_heff_2erules_2elocalDef_lam3, 1, 7, (V[]){v_x_2411, v_x_240, v_e_244, v_rest_243, v_b_245, v_hd_249, v_k_2410})});
}
V g_heff_2erules_2elocalDef_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_x_240 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  V v_rest_243 = heff_env(self)[4];
  V v_b_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo(g_heff_2erules_2elocalDef_lam2, 1, 7, (V[]){v_e_244, v_x_240, v_body_242, v_hd_249, v_rest_243, v_b_245, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2elocalDef_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_b_245 = args[1];
  V v_typ_241 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_rest_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_248;
  switch (heff_tag_of(v_typ_241)) {
  case TAG_MkTyp: {
    V v_f_246 = heff_field(v_typ_241, 0);
    heff_take_n(v_typ_241, 1ULL, 1);
    V v_t_247 = heff_rec(6, shape_289_115_81_161_295_145, (V[]){heff_get(heff_dup(v_e_244), LBL_scope), heff_get(heff_dup(v_e_244), LBL_globals), NTAG(TAG_ForNominative), heff_get(heff_dup(v_e_244), LBL_lams), heff_get(heff_dup(v_e_244), LBL_self), heff_get(heff_dup(v_e_244), LBL_insts)});
    v_c_248 = heff_tr(heff_apply(v_f_246, 1, (V[]){v_t_247}));
    break;
  }
  default: heff_nomatch(v_typ_241);
  }
  return heff_clo(g_heff_2erules_2elocalDef_lam1, 2, 6, (V[]){v_c_248, v_e_244, v_x_240, v_body_242, v_rest_243, v_b_245});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2euniverseIntro_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2erules_2euniverseIntro_str1 = {{0x80000000u, K_STR, 0}, 27, 27, {32, 116, 111, 111, 32, 108, 97, 114, 103, 101, 32, 102, 111, 114, 32, 105, 116, 115, 32, 117, 110, 105, 118, 101, 114, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2erules_2euniverseIntro_str2 = {{0x80000000u, K_STR, 0}, 18, 18, {99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2erules_2euniverseIntro_str3 = {{0x80000000u, K_STR, 0}, 22, 22, {32, 97, 116, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2erules_2euniverseIntro_str4 = {{0x80000000u, K_STR, 0}, 18, 18, {99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2erules_2euniverseIntro_str5 = {{0x80000000u, K_STR, 0}, 22, 22, {32, 97, 116, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2erules_2euniverseIntro_str6 = {{0x80000000u, K_STR, 0}, 18, 18, {99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2erules_2euniverseIntro_str7 = {{0x80000000u, K_STR, 0}, 22, 22, {32, 97, 116, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2erules_2euniverseIntro_str8 = {{0x80000000u, K_STR, 0}, 18, 18, {99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2erules_2euniverseIntro_str9 = {{0x80000000u, K_STR, 0}, 22, 22, {32, 97, 116, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2erules_2euniverseIntro_str10 = {{0x80000000u, K_STR, 0}, 18, 18, {99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2erules_2euniverseIntro_str11 = {{0x80000000u, K_STR, 0}, 22, 22, {32, 97, 116, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2erules_2euniverseIntro_str12 = {{0x80000000u, K_STR, 0}, 18, 18, {99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2erules_2euniverseIntro_str13 = {{0x80000000u, K_STR, 0}, 22, 22, {32, 97, 116, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2erules_2euniverseIntro_str14 = {{0x80000000u, K_STR, 0}, 18, 18, {99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2erules_2euniverseIntro_str15 = {{0x80000000u, K_STR, 0}, 22, 22, {32, 97, 116, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2erules_2euniverseIntro_str16 = {{0x80000000u, K_STR, 0}, 18, 18, {99, 97, 110, 110, 111, 116, 32, 99, 104, 101, 99, 107, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2erules_2euniverseIntro_str17 = {{0x80000000u, K_STR, 0}, 22, 22, {32, 97, 116, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101, 32}};
V g_heff_2erules_2euniverseIntro_lam1(V self, V *args);
V g_heff_2erules_2euniverseIntro_lam3(V self, V *args);
V g_heff_2erules_2euniverseIntro_lam2(V self, V *args);
V g_heff_2erules_2euniverseIntro_lam0(V self, V *args);
Clo g_heff_2erules_2euniverseIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2euniverseIntro_entry, 2, 0};

V g_heff_2erules_2euniverseIntro(V v_sp_240, V v_typ_241) {
top: ;
  return heff_tag(TAG_MkChk, 1, (V[]){heff_clo(g_heff_2erules_2euniverseIntro_lam0, 4, 2, (V[]){heff_dup(v_typ_241), v_sp_240})});
}
V g_heff_2erules_2euniverseIntro_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2euniverseIntro(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2erules_2euniverseIntro_lam1(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_246, LBL_metas); V a_1 = v_a0_243; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2erules_2euniverseIntro_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414 = (g_heff_2evalue_2ebehavior(heff_dup(v_x_2410)));
  switch (heff_tag_of(v_t_2414)) {
  case TAG_LikeU: {
    V v_u_2415 = heff_field(v_t_2414, 0);
    V v_ru_24t_2414_24LikeU = heff_take_reuse_n(v_t_2414, 1ULL, 1);
    heff_drop(v_x_2410);
    V v_x1_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_x_2413), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_x1_2420;
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_Nom: {
      V v_t_2417 = heff_field(v_x1_2416, 0);
      heff_take_n(v_x1_2416, 1ULL, 1);
      v_x1_2420 = ({ V a_0 = v_t_2417; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2417); r_; });
      break;
    }
    case TAG_Describe: {
      V v_t_2418 = heff_field(v_x1_2416, 0);
      heff_take_n(v_x1_2416, 1ULL, 1);
      v_x1_2420 = ({ V a_0 = v_t_2418; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2418); r_; });
      break;
    }
    case TAG_Become: {
      V v_t_2419 = heff_field(v_x1_2416, 0);
      heff_take_n(v_x1_2416, 1ULL, 1);
      v_x1_2420 = ({ V a_0 = v_t_2419; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2419); r_; });
      break;
    }
    default: heff_nomatch(v_x1_2416);
    }
    V v_x2_2421;
    switch (heff_tag_of(v_u_2415)) {
    case TAG_SmallU: {
      v_x2_2421 = NTAG(TAG_Small);
      break;
    }
    case TAG_LargeU: {
      v_x2_2421 = NTAG(TAG_Large);
      break;
    }
    default: heff_nomatch(v_u_2415);
    }
    V v_t_2422;
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_Small: {
      heff_drop(v_x2_2421);
      v_t_2422 = NTAG(TAG_True);
      break;
    }
    case TAG_Large: {
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Small: {
        v_t_2422 = NTAG(TAG_False);
        break;
      }
      case TAG_Large: {
        v_t_2422 = NTAG(TAG_True);
        break;
      }
      case TAG_TopL: {
        v_t_2422 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      break;
    }
    case TAG_TopL: {
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Small: {
        v_t_2422 = NTAG(TAG_False);
        break;
      }
      case TAG_Large: {
        v_t_2422 = NTAG(TAG_False);
        break;
      }
      case TAG_TopL: {
        v_t_2422 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      break;
    }
    default: heff_nomatch(v_x1_2420);
    }
    switch (heff_tag_of(v_t_2422)) {
    case TAG_True: {
      heff_drop(v_e_242);
      heff_drop(v_sp_240);
      heff_drop(v_hd_244);
      heff_drop_cell(v_ru_24t_2414_24LikeU, 1);
      V v_t_2423 = (g_heff_2ememoed_2ecode(v_x_2413));
      V f_ = v_k_245;
      args[0] = v_t_2423;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_False: {
      V v_t_2424 = (g_heff_2erules_2etyStrM(v_e_242, v_x_2413));
      V v_msg_2425 = heff_strAppend(((V)&g_heff_2erules_2euniverseIntro_str0), heff_strAppend(v_t_2424, ((V)&g_heff_2erules_2euniverseIntro_str1)));
      V v_t_2426 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(309LL), NTAG(TAG_SError), v_msg_2425, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2427 = heff_tag_at(v_ru_24t_2414_24LikeU, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2428}));
      return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2429, v_k_245});
    }
    default: return heff_nomatch(v_t_2422);
    }
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2414, 0ULL, 4);
    V v_t_2434 = (g_heff_2erules_2etyStrM(heff_dup(v_e_242), v_x_2413));
    V v_msg_2435 = heff_strAppend(((V)&g_heff_2erules_2euniverseIntro_str2), heff_strAppend(v_t_2434, heff_strAppend(((V)&g_heff_2erules_2euniverseIntro_str3), (g_heff_2erules_2etyStr(v_e_242, v_x_2410)))));
    V v_t_2436 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2435, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2437 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2438}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2439, v_k_245});
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2414, 0ULL, 3);
    V v_t_2443 = (g_heff_2erules_2etyStrM(heff_dup(v_e_242), v_x_2413));
    V v_msg_2444 = heff_strAppend(((V)&g_heff_2erules_2euniverseIntro_str4), heff_strAppend(v_t_2443, heff_strAppend(((V)&g_heff_2erules_2euniverseIntro_str5), (g_heff_2erules_2etyStr(v_e_242, v_x_2410)))));
    V v_t_2445 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2444, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2446 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2447}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2448, v_k_245});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2414_24LikeSum = heff_take_reuse_n(v_t_2414, 0ULL, 1);
    V v_t_2450 = (g_heff_2erules_2etyStrM(heff_dup(v_e_242), v_x_2413));
    V v_msg_2451 = heff_strAppend(((V)&g_heff_2erules_2euniverseIntro_str6), heff_strAppend(v_t_2450, heff_strAppend(((V)&g_heff_2erules_2euniverseIntro_str7), (g_heff_2erules_2etyStr(v_e_242, v_x_2410)))));
    V v_t_2452 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2451, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2453 = heff_tag_at(v_ru_24t_2414_24LikeSum, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2454}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2455, v_k_245});
  }
  case TAG_LikeInt: {
    V v_t_2456 = (g_heff_2erules_2etyStrM(heff_dup(v_e_242), v_x_2413));
    V v_msg_2457 = heff_strAppend(((V)&g_heff_2erules_2euniverseIntro_str8), heff_strAppend(v_t_2456, heff_strAppend(((V)&g_heff_2erules_2euniverseIntro_str9), (g_heff_2erules_2etyStr(v_e_242, v_x_2410)))));
    V v_t_2458 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2457, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2459 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2460}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2461, v_k_245});
  }
  case TAG_LikeFloat: {
    V v_t_2462 = (g_heff_2erules_2etyStrM(heff_dup(v_e_242), v_x_2413));
    V v_msg_2463 = heff_strAppend(((V)&g_heff_2erules_2euniverseIntro_str10), heff_strAppend(v_t_2462, heff_strAppend(((V)&g_heff_2erules_2euniverseIntro_str11), (g_heff_2erules_2etyStr(v_e_242, v_x_2410)))));
    V v_t_2464 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2463, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2465 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2466}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2467, v_k_245});
  }
  case TAG_LikeString: {
    V v_t_2468 = (g_heff_2erules_2etyStrM(heff_dup(v_e_242), v_x_2413));
    V v_msg_2469 = heff_strAppend(((V)&g_heff_2erules_2euniverseIntro_str12), heff_strAppend(v_t_2468, heff_strAppend(((V)&g_heff_2erules_2euniverseIntro_str13), (g_heff_2erules_2etyStr(v_e_242, v_x_2410)))));
    V v_t_2470 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2469, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2471 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2472}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2473, v_k_245});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2414_24LikeArray = heff_take_reuse_n(v_t_2414, 0ULL, 1);
    V v_t_2475 = (g_heff_2erules_2etyStrM(heff_dup(v_e_242), v_x_2413));
    V v_msg_2476 = heff_strAppend(((V)&g_heff_2erules_2euniverseIntro_str14), heff_strAppend(v_t_2475, heff_strAppend(((V)&g_heff_2erules_2euniverseIntro_str15), (g_heff_2erules_2etyStr(v_e_242, v_x_2410)))));
    V v_t_2477 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2476, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2478 = heff_tag_at(v_ru_24t_2414_24LikeArray, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2479}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2480, v_k_245});
  }
  case TAG_NoRules: {
    V v_t_2481 = (g_heff_2erules_2etyStrM(heff_dup(v_e_242), v_x_2413));
    V v_msg_2482 = heff_strAppend(((V)&g_heff_2erules_2euniverseIntro_str16), heff_strAppend(v_t_2481, heff_strAppend(((V)&g_heff_2erules_2euniverseIntro_str17), (g_heff_2erules_2etyStr(v_e_242, v_x_2410)))));
    V v_t_2483 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2482, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2484 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2483})});
    V v_t_2485 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2484})});
    V v_t_2486 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2485}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2486, v_k_245});
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2erules_2euniverseIntro_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_typ_241 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2412;
  switch (heff_tag_of(v_typ_241)) {
  case TAG_MkTyp: {
    V v_f_2411 = heff_field(v_typ_241, 0);
    heff_take_n(v_typ_241, 1ULL, 1);
    v_c_2412 = heff_tr(heff_apply(v_f_2411, 1, (V[]){heff_dup(v_e_242)}));
    break;
  }
  default: heff_nomatch(v_typ_241);
  }
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2erules_2euniverseIntro_lam3, 1, 5, (V[]){v_x_2410, v_k_245, v_e_242, v_sp_240, v_hd_244})});
}
V g_heff_2erules_2euniverseIntro_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a0_243 = args[1];
  V v_hd_244 = args[2];
  V v_k_245 = args[3];
  V v_typ_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2erules_2euniverseIntro_lam1, 1, 1, (V[]){v_a0_243})})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_248}));
  V f_ = heff_get(heff_dup(v_hd_244), LBL_bind);
  args[0] = v_t_249;
  args[1] = heff_clo(g_heff_2erules_2euniverseIntro_lam2, 1, 5, (V[]){v_typ_241, v_e_242, v_hd_244, v_k_245, v_sp_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2euniverseElimSyn_str0 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 110, 111, 116, 32, 100, 101, 99, 111, 100, 101, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 111, 102, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2euniverseElimSyn_str1 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 110, 111, 116, 32, 100, 101, 99, 111, 100, 101, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 111, 102, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2euniverseElimSyn_str2 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 110, 111, 116, 32, 100, 101, 99, 111, 100, 101, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 111, 102, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2euniverseElimSyn_str3 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 110, 111, 116, 32, 100, 101, 99, 111, 100, 101, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 111, 102, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2euniverseElimSyn_str4 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 110, 111, 116, 32, 100, 101, 99, 111, 100, 101, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 111, 102, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2euniverseElimSyn_str5 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 110, 111, 116, 32, 100, 101, 99, 111, 100, 101, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 111, 102, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2euniverseElimSyn_str6 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 110, 111, 116, 32, 100, 101, 99, 111, 100, 101, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 111, 102, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2erules_2euniverseElimSyn_str7 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 97, 110, 110, 111, 116, 32, 100, 101, 99, 111, 100, 101, 32, 97, 110, 32, 101, 108, 101, 109, 101, 110, 116, 32, 111, 102, 32, 110, 111, 110, 45, 117, 110, 105, 118, 101, 114, 115, 101, 32, 116, 121, 112, 101}};
V g_heff_2erules_2euniverseElimSyn_lam2(V self, V *args);
V g_heff_2erules_2euniverseElimSyn_lam1(V self, V *args);
V g_heff_2erules_2euniverseElimSyn_lam0(V self, V *args);
Clo g_heff_2erules_2euniverseElimSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2euniverseElimSyn_entry, 2, 0};

V g_heff_2erules_2euniverseElimSyn(V v_sp_240, V v_syn_241) {
top: ;
  return heff_tag(TAG_MkTyp, 1, (V[]){heff_clo(g_heff_2erules_2euniverseElimSyn_lam0, 1, 2, (V[]){heff_dup(v_syn_241), v_sp_240})});
}
V g_heff_2erules_2euniverseElimSyn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2euniverseElimSyn(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2erules_2euniverseElimSyn_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkPair: {
    V v_m_248 = heff_field(v_x_247, 0);
    V v_a_249 = heff_field(v_x_247, 1);
    heff_take_n(v_x_247, 3ULL, 2);
    switch (heff_tag_of(v_a_249)) {
    case TAG_VU: {
      heff_take_n(v_a_249, 0ULL, 1);
      heff_drop(v_sp_240);
      heff_drop(v_hd_245);
      V v_t_2411 = (g_heff_2ememoed_2edecode(v_m_248));
      V f_ = v_k_246;
      args[0] = v_t_2411;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_VDecode: {
      heff_take_n(v_a_249, 0ULL, 5);
      heff_drop(v_m_248);
      V v_t_2417 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2euniverseElimSyn_str0), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2419}));
      return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2420, v_k_246});
    }
    case TAG_VFunction: {
      heff_take_n(v_a_249, 0ULL, 4);
      heff_drop(v_m_248);
      V v_t_2425 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2euniverseElimSyn_str1), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2426 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2427}));
      return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2428, v_k_246});
    }
    case TAG_VRecord: {
      heff_take_n(v_a_249, 0ULL, 4);
      heff_drop(v_m_248);
      V v_t_2433 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2euniverseElimSyn_str2), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2434 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2435}));
      return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2436, v_k_246});
    }
    case TAG_VSum: {
      V v_ru_24a_249_24VSum = heff_take_reuse_n(v_a_249, 0ULL, 1);
      heff_drop(v_m_248);
      V v_t_2438 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2euniverseElimSyn_str3), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2439 = heff_tag_at(v_ru_24a_249_24VSum, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2440}));
      return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2441, v_k_246});
    }
    case TAG_VPrimInt: {
      heff_drop(v_m_248);
      V v_t_2442 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2euniverseElimSyn_str4), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2443 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2442})});
      V v_t_2444 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2443})});
      V v_t_2445 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2444}));
      return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2445, v_k_246});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_m_248);
      V v_t_2446 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2euniverseElimSyn_str5), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2447 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2446})});
      V v_t_2448 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2447})});
      V v_t_2449 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2448}));
      return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2449, v_k_246});
    }
    case TAG_VPrimString: {
      heff_drop(v_m_248);
      V v_t_2450 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2euniverseElimSyn_str6), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2451 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2450})});
      V v_t_2452 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2451})});
      V v_t_2453 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2452}));
      return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2453, v_k_246});
    }
    case TAG_VPrimArray: {
      V v_ru_24a_249_24VPrimArray = heff_take_reuse_n(v_a_249, 0ULL, 1);
      heff_drop(v_m_248);
      V v_t_2455 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2euniverseElimSyn_str7), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2456 = heff_tag_at(v_ru_24a_249_24VPrimArray, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2455})});
      V v_t_2457 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2456})});
      V v_t_2458 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2457}));
      return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2458, v_k_246});
    }
    default: return heff_nomatch(v_a_249);
    }
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2erules_2euniverseElimSyn_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo(g_heff_2erules_2euniverseElimSyn_lam2, 1, 3, (V[]){v_k_246, v_sp_240, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2euniverseElimSyn_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_syn_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_244;
  switch (heff_tag_of(v_syn_241)) {
  case TAG_MkSyn: {
    V v_f_243 = heff_field(v_syn_241, 0);
    heff_take_n(v_syn_241, 1ULL, 1);
    v_c_244 = heff_tr(heff_apply(v_f_243, 1, (V[]){v_e_242}));
    break;
  }
  default: heff_nomatch(v_syn_241);
  }
  return heff_clo(g_heff_2erules_2euniverseElimSyn_lam1, 2, 2, (V[]){v_c_244, v_sp_240});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2erules_2easSmall_str0 = {{0x80000000u, K_STR, 0}, 19, 19, {101, 120, 112, 101, 99, 116, 101, 100, 32, 115, 109, 97, 108, 108, 32, 116, 121, 112, 101}};
V g_heff_2erules_2easSmall_lam2(V self, V *args);
V g_heff_2erules_2easSmall_lam1(V self, V *args);
V g_heff_2erules_2easSmall_lam0(V self, V *args);
Clo g_heff_2erules_2easSmall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2easSmall_entry, 2, 0};

V g_heff_2erules_2easSmall(V v_sp_240, V v_typ_241) {
top: ;
  return heff_tag(TAG_MkSmallTyp, 1, (V[]){heff_clo(g_heff_2erules_2easSmall_lam0, 1, 2, (V[]){heff_dup(v_typ_241), v_sp_240})});
}
V g_heff_2erules_2easSmall_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2easSmall(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2erules_2easSmall_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_248 = heff_tr(heff_apply(heff_get(heff_dup(v_x_247), LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x1_2412;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nom: {
    V v_t_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_x1_2412 = ({ V a_0 = v_t_249; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_249); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2410 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_x1_2412 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2410); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2411 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_x1_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2evalue_2elevelOf(a_0)); heff_drop(v_t_2411); r_; });
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  V v_t_2413;
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Small: {
    v_t_2413 = NTAG(TAG_True);
    break;
  }
  case TAG_Large: {
    v_t_2413 = NTAG(TAG_False);
    break;
  }
  case TAG_TopL: {
    v_t_2413 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  switch (heff_tag_of(v_t_2413)) {
  case TAG_True: {
    heff_drop(v_sp_240);
    heff_drop(v_hd_245);
    V f_ = v_k_246;
    args[0] = v_x_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    heff_drop(v_x_247);
    V v_t_2414 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(309LL), NTAG(TAG_SError), ((V)&g_heff_2erules_2easSmall_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2416}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2417, v_k_246});
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2erules_2easSmall_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo(g_heff_2erules_2easSmall_lam2, 1, 3, (V[]){v_k_246, v_sp_240, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2easSmall_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_typ_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_244;
  switch (heff_tag_of(v_typ_241)) {
  case TAG_MkTyp: {
    V v_f_243 = heff_field(v_typ_241, 0);
    heff_take_n(v_typ_241, 1ULL, 1);
    v_c_244 = heff_tr(heff_apply(v_f_243, 1, (V[]){v_e_242}));
    break;
  }
  default: heff_nomatch(v_typ_241);
  }
  return heff_clo(g_heff_2erules_2easSmall_lam1, 2, 2, (V[]){v_c_244, v_sp_240});
}
Clo g_heff_2erules_2eindexOfName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2eindexOfName_entry, 3, 0};

V g_heff_2erules_2eindexOfName(V v_x1_240, V v_x_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x1_240, 0);
    V v_ys_244 = heff_field(v_x1_240, 1);
    V v_t_245 = heff_strEq(heff_dup(v_y_243), heff_dup(v_x_241));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_x_241);
      return heff_tag(TAG_Just, 1, (V[]){v_i_242});
    }
    case TAG_False: {
      V t_0 = v_ys_244;
      V t_1 = v_x_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_x1_240 = t_0;
      v_x_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2erules_2eindexOfName_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erules_2eindexOfName(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2erules_2efind_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {117, 115, 101, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2erules_2efind_str1 = {{0x80000000u, K_STR, 0}, 26, 26, {44, 32, 119, 104, 105, 99, 104, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 101, 108, 97, 98, 111, 114, 97, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2erules_2efind_str2 = {{0x80000000u, K_STR, 0}, 17, 17, {110, 111, 32, 115, 117, 99, 104, 32, 118, 97, 114, 105, 97, 98, 108, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2erules_2efind_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {32, 105, 110, 32, 115, 99, 111, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2erules_2efind_str4 = {{0x80000000u, K_STR, 0}, 9, 9, {118, 97, 114, 105, 97, 98, 108, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[162]; } g_heff_2erules_2efind_str5 = {{0x80000000u, K_STR, 0}, 162, 162, {32, 105, 115, 32, 116, 104, 101, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 98, 101, 105, 110, 103, 32, 101, 108, 97, 98, 111, 114, 97, 116, 101, 100, 58, 32, 105, 116, 32, 105, 115, 32, 105, 110, 32, 104, 97, 110, 100, 32, 111, 110, 108, 121, 32, 117, 110, 100, 101, 114, 32, 97, 32, 108, 97, 109, 98, 100, 97, 44, 32, 119, 104, 101, 114, 101, 32, 97, 32, 116, 121, 112, 101, 32, 105, 115, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 111, 102, 32, 105, 116, 32, 40, 97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 44, 32, 97, 32, 98, 114, 97, 110, 99, 104, 44, 32, 116, 104, 101, 32, 114, 101, 115, 117, 108, 116, 32, 45, 45, 32, 110, 111, 116, 32, 97, 32, 99, 97, 115, 101, 32, 115, 99, 114, 117, 116, 105, 110, 101, 101, 41}};
V g_heff_2erules_2efind_lam1(V self, V *args);
V g_heff_2erules_2efind_lam2(V self, V *args);
V g_heff_2erules_2efind_lam4(V self, V *args);
V g_heff_2erules_2efind_lam6(V self, V *args);
V g_heff_2erules_2efind_lam5(V self, V *args);
V g_heff_2erules_2efind_lam3(V self, V *args);
V g_heff_2erules_2efind_lam7(V self, V *args);
V g_heff_2erules_2efind_lam8(V self, V *args);
V g_heff_2erules_2efind_lam9(V self, V *args);
V g_heff_2erules_2efind_lam11(V self, V *args);
V g_heff_2erules_2efind_lam10(V self, V *args);
V g_heff_2erules_2efind_lam0(V self, V *args);
Clo g_heff_2erules_2efind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erules_2efind_entry, 2, 0};

V g_heff_2erules_2efind(V v_sp_240, V v_x_241) {
top: ;
  return heff_tag(TAG_MkSyn, 1, (V[]){heff_clo(g_heff_2erules_2efind_lam0, 1, 2, (V[]){v_x_241, v_sp_240})});
}
V g_heff_2erules_2efind_entry(V self, V *a) {
  (void)self;
  return g_heff_2erules_2efind(a[0], a[1]);
}
V g_heff_2erules_2efind_lam1(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k2_2418 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_strAppend(((V)&g_heff_2erules_2efind_str0), heff_strAppend(v_x_241, ((V)&g_heff_2erules_2efind_str1)));
  V v_t_2420 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(-1LL), NTAG(TAG_SError), v_t_2419, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2417), LBL_malg), 1, (V[]){v_t_2422}));
  V f_ = heff_get(v_hd_2417, LBL_bind);
  args[0] = v_t_2423;
  args[1] = v_k2_2418;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2efind_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = heff_strAppend(((V)&g_heff_2erules_2efind_str2), heff_strAppend(v_x_241, ((V)&g_heff_2erules_2efind_str3)));
  V v_t_2427 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(308LL), NTAG(TAG_SError), v_t_2426, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2428 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2424), LBL_malg), 1, (V[]){v_t_2429}));
  V f_ = heff_get(v_hd_2424, LBL_bind);
  args[0] = v_t_2430;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2efind_lam4(V self, V *args) {
  V v_u_2436 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_ge_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2436);
  return (g_heff_2erules_2etyStr(v_e_242, heff_get(v_ge_2433, LBL_type_5f)));
}
V g_heff_2erules_2efind_lam6(V self, V *args) {
  V v_u_2441 = args[0];
  V v_ge_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2441);
  return heff_tag(TAG_Nom, 1, (V[]){heff_get(v_ge_2433, LBL_value)});
}
V g_heff_2erules_2efind_lam5(V self, V *args) {
  V v_x_2440 = args[0];
  V v_key_2432 = heff_env(self)[0];
  V v_ge_2433 = heff_env(self)[1];
  V v_k_2435 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2440);
  V v_t_2442 = heff_rec(2, shape_326_366, (V[]){heff_tag(TAG_SGlobal, 1, (V[]){v_key_2432}), heff_clo(g_heff_2erules_2efind_lam6, 1, 1, (V[]){heff_dup(v_ge_2433)})});
  V v_t_2443 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2442, heff_get(v_ge_2433, LBL_type_5f)});
  V f_ = v_k_2435;
  args[0] = v_t_2443;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2efind_lam3(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_key_2432 = heff_env(self)[2];
  V v_e_242 = heff_env(self)[3];
  V v_ge_2433 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2437 = heff_rec(5, shape_314_198_152_188_351, (V[]){v_sp_240, v_x_241, heff_tag(TAG_Just, 1, (V[]){heff_dup(v_key_2432)}), NTAG(TAG_False), heff_clo(g_heff_2erules_2efind_lam4, 1, 2, (V[]){v_e_242, heff_dup(v_ge_2433)})});
  V v_t_2438 = heff_tag(TAG_Record, 2, (V[]){v_t_2437, NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2434), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2438})}));
  V f_ = heff_get(v_hd_2434, LBL_bind);
  args[0] = v_t_2439;
  args[1] = heff_clo(g_heff_2erules_2efind_lam5, 1, 3, (V[]){v_key_2432, v_ge_2433, v_k_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2efind_lam7(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k2_2445 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = heff_strAppend(((V)&g_heff_2erules_2efind_str4), heff_strAppend(v_x_241, ((V)&g_heff_2erules_2efind_str5)));
  V v_t_2447 = heff_rec(5, shape_47_297_193_314_206, (V[]){MK_INT(319LL), NTAG(TAG_SError), v_t_2446, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2448 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2444), LBL_malg), 1, (V[]){v_t_2449}));
  V f_ = heff_get(v_hd_2444, LBL_bind);
  args[0] = v_t_2450;
  args[1] = v_k2_2445;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2efind_lam8(V self, V *args) {
  V v_u_2460 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_ty_2453 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2460);
  return (g_heff_2erules_2etyStr(v_e_242, v_ty_2453));
}
V g_heff_2erules_2efind_lam9(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k2_2463 = args[1];
  V v_i_2461 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2464 = heff_tag(TAG_Record, 2, (V[]){v_i_2461, NTAG(TAG_MkUnit)});
  V v_t_2465 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2462), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2464})}));
  V f_ = heff_get(v_hd_2462, LBL_bind);
  args[0] = v_t_2465;
  args[1] = v_k2_2463;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2efind_lam11(V self, V *args) {
  V v_x_2469 = args[0];
  V v_k_2468 = heff_env(self)[0];
  V v_m_2452 = heff_env(self)[1];
  V v_ty_2453 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2469);
  V f_ = v_k_2468;
  args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_m_2452, v_ty_2453});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erules_2efind_lam10(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k_2468 = args[1];
  V v_c_2466 = heff_env(self)[0];
  V v_m_2452 = heff_env(self)[1];
  V v_ty_2453 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2466;
  args[0] = v_hd_2467;
  args[1] = heff_clo(g_heff_2erules_2efind_lam11, 1, 3, (V[]){v_k_2468, v_m_2452, v_ty_2453});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2erules_2efind_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_get(heff_get(heff_dup(v_e_242), LBL_scope), LBL_names);
  V v_t_244 = heff_get(heff_get(heff_dup(v_e_242), LBL_scope), LBL_ctx);
  V v_t_245 = heff_get(heff_get(heff_dup(v_e_242), LBL_scope), LBL_locals);
  V v_it_246 = ({ V a_0 = heff_dup(v_x_241); V a_1 = v_t_243; V a_2 = v_t_244; V a_3 = v_t_245; V a_4 = MK_INT(0LL); V a_5 = MK_INT(0LL); V r_ = (g_heff_2erules_2evarGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_244); r_; });
  switch (heff_tag_of(v_it_246)) {
  case TAG_Left: {
    V v_it1_247 = heff_field(v_it_246, 0);
    heff_take_n(v_it_246, 1ULL, 1);
    switch (heff_tag_of(v_it1_247)) {
    case TAG_NotInScope: {
      V v_it_248 = (g_heff_2eglobals_2elookupKey(heff_get(heff_dup(v_e_242), LBL_globals), heff_dup(v_x_241)));
      switch (heff_tag_of(v_it_248)) {
      case TAG_Nothing: {
        V v_g_249 = heff_get(v_e_242, LBL_globals);
        V v_x3_2410 = ({ V a_0 = heff_dup(v_x_241); V b_1 = heff_get(heff_dup(v_g_249), LBL_broken); V r_ = (g_map_2elookup_24s9(a_0, b_1)); heff_drop(b_1); r_; });
        V v_t_2416;
        switch (heff_tag_of(v_x3_2410)) {
        case TAG_Nothing: {
          V v_t_2411 = ({ V a_0 = heff_dup(v_x_241); V b_1 = heff_get(heff_dup(v_g_249), LBL_aliases); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
          switch (heff_tag_of(v_t_2411)) {
          case TAG_Nothing: {
            heff_drop(v_g_249);
            v_t_2416 = NTAG(TAG_False);
            break;
          }
          case TAG_Just: {
            V v_k_2412 = heff_field(v_t_2411, 0);
            heff_take_n(v_t_2411, 1ULL, 1);
            V v_x3_2413 = ({ V a_0 = v_k_2412; V b_1 = heff_get(v_g_249, LBL_broken); V r_ = (g_map_2elookup_24s9(a_0, b_1)); heff_drop(b_1); r_; });
            switch (heff_tag_of(v_x3_2413)) {
            case TAG_Nothing: {
              v_t_2416 = NTAG(TAG_False);
              break;
            }
            case TAG_Just: {
              heff_take_n(v_x3_2413, 0ULL, 1);
              v_t_2416 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_x3_2413);
            }
            break;
          }
          default: heff_nomatch(v_t_2411);
          }
          break;
        }
        case TAG_Just: {
          heff_take_n(v_x3_2410, 0ULL, 1);
          heff_drop(v_g_249);
          v_t_2416 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x3_2410);
        }
        switch (heff_tag_of(v_t_2416)) {
        case TAG_True: {
          return heff_clo(g_heff_2erules_2efind_lam1, 2, 2, (V[]){v_x_241, v_sp_240});
        }
        case TAG_False: {
          return heff_clo(g_heff_2erules_2efind_lam2, 2, 2, (V[]){v_x_241, v_sp_240});
        }
        default: return heff_nomatch(v_t_2416);
        }
      }
      case TAG_Just: {
        V v_it1_2431 = heff_field(v_it_248, 0);
        heff_take_n(v_it_248, 1ULL, 1);
        switch (heff_tag_of(v_it1_2431)) {
        case TAG_MkPair: {
          V v_key_2432 = heff_field(v_it1_2431, 0);
          V v_ge_2433 = heff_field(v_it1_2431, 1);
          heff_take_n(v_it1_2431, 3ULL, 2);
          return heff_clo(g_heff_2erules_2efind_lam3, 2, 5, (V[]){v_sp_240, v_x_241, v_key_2432, v_e_242, v_ge_2433});
        }
        default: return heff_nomatch(v_it1_2431);
        }
      }
      default: return heff_nomatch(v_it_248);
      }
    }
    case TAG_Delayed2: {
      heff_drop(v_e_242);
      return heff_clo(g_heff_2erules_2efind_lam7, 2, 2, (V[]){v_x_241, v_sp_240});
    }
    default: return heff_nomatch(v_it1_247);
    }
  }
  case TAG_Right: {
    V v_it1_2451 = heff_field(v_it_246, 0);
    heff_take_n(v_it_246, 1ULL, 1);
    switch (heff_tag_of(v_it1_2451)) {
    case TAG_MkPair: {
      V v_m_2452 = heff_field(v_it1_2451, 0);
      V v_ty_2453 = heff_field(v_it1_2451, 1);
      heff_take_n(v_it1_2451, 3ULL, 2);
      V v_t_2454 = heff_get(heff_get(heff_dup(v_e_242), LBL_scope), LBL_names);
      V v_t_2455 = ({ V a_0 = v_t_2454; V a_1 = heff_dup(v_x_241); V a_2 = MK_INT(0LL); V r_ = (g_heff_2erules_2eindexOfName(a_0, a_1, a_2)); heff_drop(v_t_2454); r_; });
      V v_t_2459;
      switch (heff_tag_of(v_t_2455)) {
      case TAG_Nothing: {
        v_t_2459 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_i_2456 = heff_field(v_t_2455, 0);
        heff_take_n(v_t_2455, 1ULL, 1);
        V v_t_2457 = heff_get(heff_get(heff_dup(v_e_242), LBL_scope), LBL_len);
        V v_t_2458 = heff_intEq(v_i_2456, heff_intSub(v_t_2457, MK_INT(1LL)));
        switch (heff_tag_of(v_t_2458)) {
        case TAG_True: {
          v_t_2459 = heff_get(heff_dup(v_e_242), LBL_self);
          break;
        }
        case TAG_False: {
          v_t_2459 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2458);
        }
        break;
      }
      default: heff_nomatch(v_t_2455);
      }
      V v_i_2461 = heff_rec(5, shape_314_198_152_188_351, (V[]){v_sp_240, v_x_241, v_t_2459, NTAG(TAG_False), heff_clo(g_heff_2erules_2efind_lam8, 1, 2, (V[]){v_e_242, heff_dup(v_ty_2453)})});
      V v_c_2466 = heff_clo(g_heff_2erules_2efind_lam9, 2, 1, (V[]){v_i_2461});
      return heff_clo(g_heff_2erules_2efind_lam10, 2, 3, (V[]){v_c_2466, v_m_2452, v_ty_2453});
    }
    default: return heff_nomatch(v_it1_2451);
    }
  }
  default: return heff_nomatch(v_it_246);
  }
}