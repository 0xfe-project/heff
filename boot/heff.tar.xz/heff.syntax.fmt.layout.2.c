// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DMutual 35008
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Nest 8345
#define TAG_None 17785
#define TAG_Text 56194
#define LBL_blank 295177582
#define LBL_end 310101
#define LBL_fix 310927
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_lead 9813027
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_stmtDoc 493252245
#define LBL_text 10052084
#define LBL_trail 311979552
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efmt_2elayout_2easWritten(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2easWritten_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2easWritten_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2ecomment(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefLast(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLine(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLine_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLine_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps_clo;
V g_heff_2esyntax_2efmt_2elayout_2egapEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2egapEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2egapEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailOf(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailOf_clo;
V g_list_2efoldl_24f1160581125x508466714(V, V);
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1160581125x508466714_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2ehardline_get(void);
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_str0, 1, "\002");

static V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2enewlineMark_st;
static V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elayout_2enewlineMark_str0);
}
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_st)) return g_heff_2esyntax_2efmt_2elayout_2enewlineMark_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2enewlineMark_val, &g_heff_2esyntax_2efmt_2elayout_2enewlineMark_st, g_heff_2esyntax_2efmt_2elayout_2enewlineMark_init);
}
Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V v_s_240, V v_box_24e_241) {
  int64_t v_e_241 = heff_unbox_word(v_box_24e_241);
top: ;
  if ((((int64_t)0ULL) < v_e_241)) {
    V v_t_243 = heff_strByteAt_lent(v_s_240, heff_box_word((v_e_241 - ((int64_t)1ULL))), 2);
    if ((heff_unbox_word(v_t_243) == ((int64_t)32ULL))) {
      V t_0 = v_s_240;
      int64_t t_1 = (v_e_241 - ((int64_t)1ULL));
      v_s_240 = t_0;
      v_e_241 = t_1;
      goto top;
    } else {
      V v_t_245 = heff_strByteAt_lent(v_s_240, heff_box_word((v_e_241 - ((int64_t)1ULL))), 2);
      if ((heff_unbox_word(v_t_245) == ((int64_t)9ULL))) {
        V t_0 = v_s_240;
        int64_t t_1 = (v_e_241 - ((int64_t)1ULL));
        v_s_240 = t_0;
        v_e_241 = t_1;
        goto top;
      } else {
        V v_t_247 = heff_strByteAt_lent(v_s_240, heff_box_word((v_e_241 - ((int64_t)1ULL))), 2);
        if ((heff_unbox_word(v_t_247) == ((int64_t)13ULL))) {
          V t_0 = v_s_240;
          int64_t t_1 = (v_e_241 - ((int64_t)1ULL));
          v_s_240 = t_0;
          v_e_241 = t_1;
          goto top;
        } else {
          return heff_box_word(v_e_241);
        }
      }
    }
  } else {
    return heff_box_word(v_e_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblankLine_str0, 0, "");

static V g_heff_2esyntax_2efmt_2elayout_2eblankLine_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2eblankLine_st;
static V g_heff_2esyntax_2efmt_2elayout_2eblankLine_init(void) {
  V v_t_241;
  if (heff_strEq_c(heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankMark_get()), ((V)&g_heff_2esyntax_2efmt_2elayout_2eblankLine_str0))) {
    v_t_241 = NTAG(TAG_None);
  } else {
    v_t_241 = heff_tag_n(TAG_Text, 1, (V[]){heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankMark_get())});
  }
  return (g_std_2edoc_2e_3c_3e(v_t_241, heff_dup(g_std_2edoc_2ehardline_get())));
}
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2eblankLine_st)) return g_heff_2esyntax_2efmt_2elayout_2eblankLine_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2eblankLine_val, &g_heff_2esyntax_2efmt_2elayout_2eblankLine_st, g_heff_2esyntax_2efmt_2elayout_2eblankLine_init);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etrailOf_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etrailOf_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etrailOf_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etrailOf_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etrailOf_str4, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2etrailOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etrailOf(V v_env_240, V v_t_241) {
top: ;
  HeffT2 v_t_242 = ({ V b_0 = heff_get_n(v_env_240, 3, 7); V a_1 = heff_get_n(v_t_241, 7, 9); HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_c_246 = v_field_244;
      V v_x2_247 = ({ V b_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2etrailOf_str0); V a_1 = v_c_246; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2esyntax_2efmt_2elayout_2etrailOf_str1), v_c_246, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_c_246); r_; });
      V v_s_2410;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nil: {
        v_s_2410 = ((V)&g_heff_2esyntax_2efmt_2elayout_2etrailOf_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_xs_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        v_s_2410 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2412;
      if (heff_strEq_c_lent(v_s_2410, ((V)&g_heff_2esyntax_2efmt_2elayout_2etrailOf_str3), 2)) {
        heff_drop(v_s_2410);
        v_t_2412 = NTAG(TAG_None);
      } else {
        v_t_2412 = heff_tag_n(TAG_Text, 1, (V[]){v_s_2410});
      }
      V v_t_2413 = (g_std_2edoc_2e_3c_3e(v_t_2412, heff_dup(g_std_2edoc_2ehardline_get())));
      HEFF_LAST return g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2etrailOf_str4)}), v_t_2413);
    } else {
      heff_drop(v_field_244);
      return heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etrailOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitem_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitem(V v_env_240, V v_first_241, V v_last2_242, V v_body_243) {
top: ;
  HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_dup(heff_rfield(v_first_241, 7))));
  V v_t_249;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_246;
      v_t_249 = v_x_248;
    } else {
      heff_drop(v_field_246);
      v_t_249 = NTAG(TAG_Nil);
    }
  }
  V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a_0, a_1)); heff_drop(v_t_249); r_; });
  HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_dup(heff_rfield(v_first_241, 7))));
  V v_t_2419;
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x_2415 = v_field_2413;
      switch (heff_tag_of(v_x_2415)) {
      case TAG_Nil: {
        v_t_2419 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_x_2415, 0ULL, 2);
        V v_t_2418 = heff_dup(heff_rfield(v_first_241, 8));
        if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
          heff_drop(v_t_2418);
          v_t_2419 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        } else {
          heff_drop(v_t_2418);
          v_t_2419 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        }
        break;
      }
      default: heff_nomatch(v_x_2415);
      }
    } else {
      heff_drop(v_field_2413);
      v_t_2419 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
  }
  V v_t_2420 = heff_rec_n(7, shape_src__lead__inline__trail__noLead__noTrail__fix, (V[]){heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_env_240, 1)), heff_dup(heff_rfield(v_env_240, 2)), heff_dup(heff_rfield(v_env_240, 3)), heff_get_n(v_first_241, 7, 9), heff_dup(heff_rfield(v_last2_242, 7)), heff_dup(heff_rfield(v_env_240, 6))});
  V v_t_2421 = heff_tr(heff_call(v_body_243, 1, (V[]){v_t_2420}));
  V v_t_2423;
  if (heff_intEq_c(heff_dup(heff_rfield(v_last2_242, 7)), heff_dup(heff_rfield(v_env_240, 5)))) {
    heff_drop_rec(v_env_240, 7);
    heff_drop_rec(v_last2_242, 9);
    v_t_2423 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    v_t_2423 = (g_heff_2esyntax_2efmt_2elayout_2etrailOf(v_env_240, v_last2_242));
  }
  V v_d_2424 = (g_std_2edoc_2e_3c_3e(v_t_2421, v_t_2423));
  V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2419, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_2424})));
  return (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2425));
}
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2eitem(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2415;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_246 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
      HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_take_field(v_t_246, 7)));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        V v_t_2414;
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_249;
          switch (heff_tag_of(v_x_2411)) {
          case TAG_Nil: {
            v_t_2414 = heff_get_n(v_t_246, 8, 9);
            break;
          }
          case TAG_Cons: {
            V v_x_2412 = heff_field(v_x_2411, 0);
            heff_take_n(v_x_2411, 1ULL, 2);
            heff_drop_rec(v_t_246, 9);
            v_t_2414 = heff_get_n(v_x_2412, 1, 2);
            break;
          }
          default: heff_nomatch(v_x_2411);
          }
        } else {
          heff_drop(v_field_249);
          v_t_2414 = heff_get_n(v_t_246, 8, 9);
        }
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        } else {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        }
      }
    } else {
      v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2416 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
    V v_t_2417 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2416, v_t_2417, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2420 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2421 = (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2420));
    V v_t_2422 = (g_std_2edoc_2e_3c_3e(v_t_2415, v_t_2421));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2422));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_lam0(V self, V *args) {
  V v_e_2418 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 14));
  heff_room[0] = v_e_2418;
  heff_room[1] = v_x_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(V v_env_240, V v_i_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x4_242, 0);
    V v_ds_244 = heff_field(v_x4_242, 1);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_243));
    V v_t_246 = (g_heff_2esyntax_2ecst_2efirstD(v_d_243));
    V v_t_247 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_243)));
    V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_246, v_t_247, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_lam0, 1, 1, (V[]){heff_dup(v_d_243)})));
    V v_t_2410 = (g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_ds_244));
    V v_t_2411 = (g_std_2edoc_2e_3c_3e(v_t_249, v_t_2410));
    return (g_std_2edoc_2e_3c_3e(v_t_245, v_t_2411));
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_lam0(V self, V *args) {
  V v_e_248 = args[0];
  V v_d_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_248; V a_1 = v_d_243; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_243); r_; });
}
Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x2_241, 0);
    V v_cs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_dup(heff_rfield(v_c_242, 1));
    V v_t_245;
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      v_t_245 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
    } else {
      heff_drop(v_t_244);
      v_t_245 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2ecomment(heff_rfield(v_c_242, 0)));
    V v_t_247 = (g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(v_env_240, v_cs_243));
    V v_t_248 = (g_std_2edoc_2e_3c_3e(v_t_246, v_t_247));
    V v_t_249 = (g_std_2edoc_2e_3c_3e(v_t_245, v_t_248));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_249);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefLast_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefLast_str1, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edefLast_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edefLast(V v_x_240, V v_d_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_d_241;
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x3_242, 0);
    V v_es_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_e_243)) {
    case TAG_DImport: {
      return v_d_241;
    }
    case TAG_DFixity: {
      return v_d_241;
    }
    case TAG_DSig: {
      return v_d_241;
    }
    case TAG_DInstance: {
      return v_d_241;
    }
    case TAG_DEqn: {
      V v_n_2416 = heff_field(v_e_243, 0);
      V v_x2_2421 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2416)));
      V v_t_2424;
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Nil: {
        v_t_2424 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefLast_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_x2_2421, 0);
        V v_xs_2423 = heff_field(v_x2_2421, 1);
        heff_take_n(v_x2_2421, 3ULL, 2);
        v_t_2424 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefLast_str1); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      if (heff_strEq_c_lent(v_t_2424, v_x_240, 1)) {
        heff_drop(v_d_241);
        V t_0 = v_x_240;
        V t_1 = heff_dup(v_e_243);
        V t_2 = v_es_244;
        v_x_240 = t_0;
        v_d_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        return v_d_241;
      }
    }
    case TAG_DData: {
      return v_d_241;
    }
    case TAG_DType: {
      return v_d_241;
    }
    case TAG_DTheory: {
      return v_d_241;
    }
    case TAG_DMutual: {
      return v_d_241;
    }
    case TAG_DPrimitive: {
      return v_d_241;
    }
    case TAG_DTest: {
      return v_d_241;
    }
    case TAG_DWatch: {
      return v_d_241;
    }
    default: return heff_nomatch(v_e_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edefLast(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2egapEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2egapEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2egapEnd(V v_s_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)32ULL))) {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)9ULL))) {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      return v_i_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2egapEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2egapEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2easWritten_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2easWritten_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2easWritten(V v_env_240, V v_first_241, V v_last2_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_dup(heff_rfield(v_first_241, 7))));
  V v_t_248;
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_245;
      v_t_248 = v_x_247;
    } else {
      heff_drop(v_field_245);
      v_t_248 = NTAG(TAG_Nil);
    }
  }
  V v_t_249 = ({ V a_0 = v_t_248; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a_0, a_1)); heff_drop(v_t_248); r_; });
  HeffT2 v_t_2410 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 2), heff_take_field(v_first_241, 7)));
  V v_t_2415;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2414 = v_field_2412;
      v_t_2415 = v_x_2414;
    } else {
      heff_drop(v_field_2412);
      v_t_2415 = NTAG(TAG_Nil);
    }
  }
  V v_t_2416 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24f1160581125x508466714(a_0, a_1)); heff_drop(v_t_2415); r_; });
  V v_b_2417 = (g_heff_2esyntax_2efmt_2elayout_2etrailEnd(heff_rfield(v_env_240, 0), heff_get_n(v_last2_242, 4, 9)));
  V v_t_2418 = heff_strSlice(heff_get_n(v_env_240, 0, 7), heff_get_n(v_first_241, 3, 9), v_b_2417);
  V v_t_2419 = ({ V a_0 = v_t_2418; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ecomment(a_0)); heff_drop(v_t_2418); r_; });
  V v_t_2420 = (g_std_2edoc_2e_3c_3e(v_t_2416, v_t_2419));
  return (g_std_2edoc_2e_3c_3e(v_t_249, v_t_2420));
}
V g_heff_2esyntax_2efmt_2elayout_2easWritten_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2easWritten(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eexpectLines_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eexpectLines(V v_doc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x2_241, 0);
    V v_cs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2eexpectLine(v_doc_240, heff_dup(v_c_242)));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_c_242, heff_hole()});
      V v_u_246 = (g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps(v_doc_240, v_cs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop(v_c_242);
      heff_drop(v_cs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      return NTAG(TAG_Nil);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eexpectLines(a0, a[1]); heff_drop(a0); return r;
}