// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Nest 8345
#define TAG_None 17785
#define TAG_Text 56194
#define LBL_blank 295177582
#define LBL_end 310101
#define LBL_fix 310927
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_lead 9813027
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_stmtDoc 493252245
#define LBL_text 10052084
#define LBL_trail 311979552
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efmt_2elayout_2easWritten(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2easWritten_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2easWritten_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2ecomment(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefLast(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2egapEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2egapEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2egapEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailEnd_clo;
V g_list_2efoldl_24f1160581125x508466714(V, V);
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1160581125x508466714_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2ehardline_get(void);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_str0, 1, "\002");

static V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2enewlineMark_st;
static V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elayout_2enewlineMark_str0);
}
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_st)) return g_heff_2esyntax_2efmt_2elayout_2enewlineMark_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2enewlineMark_val, &g_heff_2esyntax_2efmt_2elayout_2enewlineMark_st, g_heff_2esyntax_2efmt_2elayout_2enewlineMark_init);
}
Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V v_s_240, V v_e_241) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(v_e_241))) {
    V v_t_243 = heff_strByteAt(heff_dup(v_s_240), heff_intSub(heff_dup(v_e_241), MK_INT(1LL)));
    if (heff_intEq_c(v_t_243, MK_INT(32LL))) {
      V t_0 = v_s_240;
      V t_1 = heff_intSub(v_e_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_e_241 = t_1;
      goto top;
    } else {
      V v_t_245 = heff_strByteAt(heff_dup(v_s_240), heff_intSub(heff_dup(v_e_241), MK_INT(1LL)));
      if (heff_intEq_c(v_t_245, MK_INT(9LL))) {
        V t_0 = v_s_240;
        V t_1 = heff_intSub(v_e_241, MK_INT(1LL));
        v_s_240 = t_0;
        v_e_241 = t_1;
        goto top;
      } else {
        V v_t_247 = heff_strByteAt(heff_dup(v_s_240), heff_intSub(heff_dup(v_e_241), MK_INT(1LL)));
        if (heff_intEq_c(v_t_247, MK_INT(13LL))) {
          V t_0 = v_s_240;
          V t_1 = heff_intSub(v_e_241, MK_INT(1LL));
          v_s_240 = t_0;
          v_e_241 = t_1;
          goto top;
        } else {
          heff_drop(v_s_240);
          return v_e_241;
        }
      }
    }
  } else {
    heff_drop(v_s_240);
    return v_e_241;
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblankLine_str0, 0, "");

static V g_heff_2esyntax_2efmt_2elayout_2eblankLine_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2eblankLine_st;
static V g_heff_2esyntax_2efmt_2elayout_2eblankLine_init(void) {
  V v_t_241;
  if (heff_strEq_c(heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankMark_get()), ((V)&g_heff_2esyntax_2efmt_2elayout_2eblankLine_str0))) {
    v_t_241 = NTAG(TAG_None);
  } else {
    v_t_241 = heff_tag_n(TAG_Text, 1, (V[]){heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankMark_get())});
  }
  return (g_std_2edoc_2e_3c_3e(v_t_241, heff_dup(g_std_2edoc_2ehardline_get())));
}
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2eblankLine_st)) return g_heff_2esyntax_2efmt_2elayout_2eblankLine_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2eblankLine_val, &g_heff_2esyntax_2efmt_2elayout_2eblankLine_st, g_heff_2esyntax_2efmt_2elayout_2eblankLine_init);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitem_str0, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitem_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitem(V v_env_240, V v_first_241, V v_last2_242, V v_body_243) {
top: ;
  V v_x2_244 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_first_241, 7)), heff_rfield(v_env_240, 1)));
  V v_t_246;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x2_244, 0);
    heff_take_n(v_x2_244, 1ULL, 1);
    v_t_246 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_x2_248 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_first_241, 7)), heff_rfield(v_env_240, 1)));
  V v_t_2413;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nothing: {
    v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Just: {
    V v_x_249 = heff_field(v_x2_248, 0);
    heff_take_n(v_x2_248, 1ULL, 1);
    switch (heff_tag_of(v_x_249)) {
    case TAG_Nil: {
      v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_x_249, 0ULL, 2);
      V v_t_2412 = heff_dup(heff_rfield(v_first_241, 8));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    break;
  }
  default: heff_nomatch(v_x2_248);
  }
  V v_t_2414 = heff_rec_n(7, shape_src__lead__inline__trail__noLead__noTrail__fix, (V[]){heff_take_field(v_env_240, 0), heff_take_field(v_env_240, 1), heff_take_field(v_env_240, 2), heff_dup(heff_rfield(v_env_240, 3)), heff_get_n(v_first_241, 7, 9), heff_dup(heff_rfield(v_last2_242, 7)), heff_take_field(v_env_240, 6)});
  V v_t_2415 = heff_tr(heff_call(v_body_243, 1, (V[]){v_t_2414}));
  V v_t_2421;
  if (heff_intEq_c(heff_dup(heff_rfield(v_last2_242, 7)), heff_dup(heff_rfield(v_env_240, 5)))) {
    heff_drop_rec(v_env_240, 7);
    heff_drop_rec(v_last2_242, 9);
    v_t_2421 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    V v_t_2417 = ({ V a_0 = heff_get_n(v_last2_242, 7, 9); V b_1 = heff_get_n(v_env_240, 3, 7); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Nothing: {
      v_t_2421 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_c_2418 = heff_field(v_t_2417, 0);
      V v_ru_24t_2417_24Just = heff_take_reuse_n(v_t_2417, 1ULL, 1);
      V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2ecomment(v_c_2418));
      V v_t_2420 = (g_std_2edoc_2e_3c_3e(v_t_2419, heff_dup(g_std_2edoc_2ehardline_get())));
      v_t_2421 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_2417_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2eitem_str0)}), v_t_2420));
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
  }
  V v_d_2422 = (g_std_2edoc_2e_3c_3e(v_t_2415, v_t_2421));
  V v_t_2423 = (g_std_2edoc_2e_3c_3e(v_t_2413, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_2422})));
  return (g_std_2edoc_2e_3c_3e(v_t_247, v_t_2423));
}
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2eitem(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2412;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_i_241))) {
      V v_t_246 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
      V v_x2_247 = (g_map_2elookup_24s567992785x1569911877(heff_take_field(v_t_246, 7), heff_rfield(v_env_240, 1)));
      V v_t_2411;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nothing: {
        v_t_2411 = heff_get_n(v_t_246, 8, 9);
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_x2_247, 0);
        heff_take_n(v_x2_247, 1ULL, 1);
        switch (heff_tag_of(v_x_248)) {
        case TAG_Nil: {
          v_t_2411 = heff_get_n(v_t_246, 8, 9);
          break;
        }
        case TAG_Cons: {
          V v_x_249 = heff_field(v_x_248, 0);
          heff_take_n(v_x_248, 1ULL, 2);
          heff_drop_rec(v_t_246, 9);
          v_t_2411 = heff_get_n(v_x_249, 1, 2);
          break;
        }
        default: heff_nomatch(v_x_248);
        }
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        v_t_2412 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_2411);
        v_t_2412 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    } else {
      v_t_2412 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2413 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
    V v_t_2414 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2416 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2413, v_t_2414, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2417 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2418 = (g_std_2edoc_2e_3c_3e(v_t_2416, v_t_2417));
    V v_t_2419 = (g_std_2edoc_2e_3c_3e(v_t_2412, v_t_2418));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2419));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_lam0(V self, V *args) {
  V v_e_2415 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 14));
  heff_room[0] = v_e_2415;
  heff_room[1] = v_x_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(V v_env_240, V v_i_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x4_242, 0);
    V v_ds_244 = heff_field(v_x4_242, 1);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_243));
    V v_t_246 = (g_heff_2esyntax_2ecst_2efirstD(v_d_243));
    V v_t_247 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_243)));
    V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_246, v_t_247, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_lam0, 1, 1, (V[]){heff_dup(v_d_243)})));
    V v_t_2410 = (g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_ds_244));
    V v_t_2411 = (g_std_2edoc_2e_3c_3e(v_t_249, v_t_2410));
    return (g_std_2edoc_2e_3c_3e(v_t_245, v_t_2411));
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_lam0(V self, V *args) {
  V v_e_248 = args[0];
  V v_d_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_248; V a_1 = v_d_243; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_243); r_; });
}
Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x2_241, 0);
    V v_cs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_dup(heff_rfield(v_c_242, 1));
    V v_t_245;
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      v_t_245 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
    } else {
      heff_drop(v_t_244);
      v_t_245 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2ecomment(heff_dup(heff_rfield(v_c_242, 0))));
    V v_t_247 = (g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(v_env_240, v_cs_243));
    V v_t_248 = (g_std_2edoc_2e_3c_3e(v_t_246, v_t_247));
    V v_t_249 = (g_std_2edoc_2e_3c_3e(v_t_245, v_t_248));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_249);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefLast_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefLast_str1, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edefLast_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edefLast(V v_x_240, V v_d_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return v_d_241;
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x3_242, 0);
    V v_es_244 = heff_field(v_x3_242, 1);
    V v_t_2447;
    switch (heff_tag_of(v_e_243)) {
    case TAG_DImport: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_DInstance: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      V v_n_2415 = heff_field(v_e_243, 0);
      V v_x2_2420 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2415)));
      V v_t_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefLast_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefLast_str1); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      v_t_2447 = heff_strEq_lent(v_t_2423, v_x_240, 1);
      break;
    }
    case TAG_DData: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_243);
    }
    if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
      heff_drop(v_d_241);
      heff_drop(v_t_2447);
      V t_0 = v_x_240;
      V t_1 = heff_dup(v_e_243);
      V t_2 = v_es_244;
      v_x_240 = t_0;
      v_d_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_240);
      heff_drop(v_t_2447);
      return v_d_241;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edefLast(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2egapEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2egapEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2egapEnd(V v_s_240, V v_i_241) {
top: ;
  if (heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(32LL))) {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    if (heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(9LL))) {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_s_240);
      return v_i_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2egapEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2egapEnd(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2easWritten_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2easWritten_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2easWritten(V v_env_240, V v_first_241, V v_last2_242) {
top: ;
  V v_x2_243 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_first_241, 7)), heff_rfield(v_env_240, 1)));
  V v_t_245;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nothing: {
    v_t_245 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x2_243, 0);
    heff_take_n(v_x2_243, 1ULL, 1);
    v_t_245 = v_x_244;
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_246 = ({ V a_0 = v_t_245; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_x2_247 = (g_map_2elookup_24s567992785x1569911877(heff_take_field(v_first_241, 7), heff_rfield(v_env_240, 2)));
  V v_t_249;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x2_247, 0);
    heff_take_n(v_x2_247, 1ULL, 1);
    v_t_249 = v_x_248;
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2410 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24f1160581125x508466714(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_b_2411 = (g_heff_2esyntax_2efmt_2elayout_2etrailEnd(heff_dup(heff_rfield(v_env_240, 0)), heff_get_n(v_last2_242, 4, 9)));
  V v_t_2412 = heff_strSlice(heff_get_n(v_env_240, 0, 7), heff_get_n(v_first_241, 3, 9), v_b_2411);
  V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2ecomment(v_t_2412));
  V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2413));
  return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2414));
}
V g_heff_2esyntax_2efmt_2elayout_2easWritten_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2easWritten(a[0], a[1], a[2]);
}