// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_None 17785
#define TAG_Text 56194
#define LBL_blank 295177582
#define LBL_end 310101
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_lead 9813027
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_stmtDoc 493252245
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efmt_2elayout_2easWritten(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2easWritten_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2easWritten_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2ecomment(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo;
V g_heff_2esyntax_2efmt_2elayout_2egapEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2egapEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2egapEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailEnd_clo;
V g_list_2efoldl_24f1160581125x508466714(V, V);
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1160581125x508466714_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2ehardline_get(void);
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblankLine_str0, 0, "");

static V g_heff_2esyntax_2efmt_2elayout_2eblankLine_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2eblankLine_st;
static V g_heff_2esyntax_2efmt_2elayout_2eblankLine_init(void) {
  V v_t_240;
  if (heff_strEq_c(heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankMark_get()), ((V)&g_heff_2esyntax_2efmt_2elayout_2eblankLine_str0))) {
    v_t_240 = NTAG(TAG_None);
  } else {
    v_t_240 = heff_tag_n(TAG_Text, 1, (V[]){heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankMark_get())});
  }
  return (g_std_2edoc_2e_3c_3e(v_t_240, heff_dup(g_std_2edoc_2ehardline_get())));
}
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2eblankLine_st)) return g_heff_2esyntax_2efmt_2elayout_2eblankLine_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2eblankLine_val, &g_heff_2esyntax_2efmt_2elayout_2eblankLine_st, g_heff_2esyntax_2efmt_2elayout_2eblankLine_init);
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2415;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_245 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
      V v_ix_246 = heff_take_field(v_t_245, 7);
      V v_blank_247 = heff_get_n(v_t_245, 8, 9);
      HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), v_ix_246));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        V v_t_2414;
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_2410;
          switch (heff_tag_of(v_x_2411)) {
          case TAG_Nil: {
            v_t_2414 = v_blank_247;
            break;
          }
          case TAG_Cons: {
            V v_x_2412 = heff_field(v_x_2411, 0);
            heff_take_n(v_x_2411, 1ULL, 2);
            heff_drop(v_blank_247);
            v_t_2414 = heff_get_n(v_x_2412, 1, 2);
            break;
          }
          default: heff_nomatch(v_x_2411);
          }
        } else {
          heff_drop(v_field_2410);
          v_t_2414 = v_blank_247;
        }
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        } else {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        }
      }
    } else {
      v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2416 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
    V v_t_2417 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2416, v_t_2417, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2420 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2421 = (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2420));
    V v_t_2422 = (g_std_2edoc_2e_3c_3e(v_t_2415, v_t_2421));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2422));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_lam0(V self, V *args) {
  V v_e_2418 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 14));
  heff_room[0] = v_e_2418;
  heff_room[1] = v_x_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2esyntax_2efmt_2elayout_2egapEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2egapEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2egapEnd(V v_s_240, V v_i_241) {
top: ;
  if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)32ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)9ULL)))) {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    return v_i_241;
  }
}
V g_heff_2esyntax_2efmt_2elayout_2egapEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2egapEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2easWritten_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2easWritten_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2easWritten(V v_env_240, V v_first_241, V v_last2_242) {
top: ;
  V v_ix_243 = heff_take_field(v_first_241, 7);
  V v_start_244 = heff_get_n(v_first_241, 3, 9);
  V v_lead_245 = heff_take_field(v_env_240, 1);
  V v_inline_246 = heff_take_field(v_env_240, 2);
  V v_src_247 = heff_get_n(v_env_240, 0, 7);
  HeffT2 v_t_248 = ({ V a_0 = v_lead_245; V a_1 = heff_dup(v_ix_243); HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(a_0, a_1)); heff_drop(v_lead_245); r_; });
  V v_t_2412;
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_x_2411 = v_field_2410;
      v_t_2412 = v_x_2411;
    } else {
      heff_drop(v_field_2410);
      v_t_2412 = NTAG(TAG_Nil);
    }
  }
  V v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a_0, a_1)); heff_drop(v_t_2412); r_; });
  HeffT2 v_t_2414 = ({ V a_0 = v_inline_246; V a_1 = v_ix_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(a_0, a_1)); heff_drop(v_inline_246); r_; });
  V v_t_2418;
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_x_2417 = v_field_2416;
      v_t_2418 = v_x_2417;
    } else {
      heff_drop(v_field_2416);
      v_t_2418 = NTAG(TAG_Nil);
    }
  }
  V v_t_2419 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24f1160581125x508466714(a_0, a_1)); heff_drop(v_t_2418); r_; });
  V v_b_2420 = (g_heff_2esyntax_2efmt_2elayout_2etrailEnd(v_src_247, heff_get_n(v_last2_242, 4, 9)));
  V v_t_2421 = ({ V b_0 = heff_strSlice(v_src_247, v_start_244, v_b_2420); V r_ = (g_heff_2esyntax_2efmt_2elayout_2ecomment(b_0)); heff_drop(b_0); r_; });
  V v_t_2422 = (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2421));
  return (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2422));
}
V g_heff_2esyntax_2efmt_2elayout_2easWritten_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2easWritten(a[0], a[1], a[2]);
}