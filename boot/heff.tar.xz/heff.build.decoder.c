// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Expl 20488
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define LBL_looser 850054335
#define LBL_owner 307523277
#define LBL_tighter 1059982480
#define LBL_ty 10476
#define LBL_units 312791945
#define LBL_ver 326173
static uint32_t shape_owner__ver__units[] = {LBL_owner, LBL_ver, LBL_units};
static uint32_t shape_tighter__looser[] = {LBL_tighter, LBL_looser};
V g_heff_2ebuild_2ebackcache_2ecopyD(V, V);
V g_heff_2ebuild_2ebackcache_2ecopyD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ecopyD_clo;
HeffT2 g_heff_2ebuild_2ebackcache_2eemitD_24cpr(V, V);
HeffT2 g_heff_2ebuild_2ebackcache_2ejsD_24cpr(V, V);
V g_heff_2ebuild_2ebackcache_2eunitD(V, V);
V g_heff_2ebuild_2ebackcache_2eunitD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eunitD_clo;
V g_heff_2ebuild_2ecache_2emeltDef(V, V);
V g_heff_2ebuild_2ecache_2emeltDef_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltDef_clo;
V g_heff_2ebuild_2ecache_2emeltFixGroup(V, V);
V g_heff_2ebuild_2ecache_2emeltFixGroup_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltFixGroup_clo;
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_clo;
V g_heff_2ebuild_2edecoder_2ecolonAt(V, V);
V g_heff_2ebuild_2edecoder_2ecolonAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ecolonAt_clo;
HeffT2 g_heff_2ebuild_2edecoder_2edecimalAt_24cpr(V, V, V);
V g_heff_2ebuild_2edecoder_2edigitsTo(V, V, V, V);
V g_heff_2ebuild_2edecoder_2edigitsTo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2edigitsTo_clo;
V g_heff_2ebuild_2edecoder_2efail(V, V);
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2efail_clo;
HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
V g_heff_2ebuild_2edecoder_2etimes(V, V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_clo;
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1391953550x1663492198_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1952093399x207461701_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1954476619x1073210498_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s2049614891x1595878686_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s481066606x2100141841_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ewhole_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
V g_heff_2ebuild_2edecoder_2ewordEnd(V, V);
V g_heff_2ebuild_2edecoder_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ewordEnd_clo;
V g_heff_2ebuild_2eserial_2edk_get(void);
HeffT2 g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(V, V, V);

HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V v_s_240, V v_i_241) {
top: ;
  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
}
Clo g_heff_2ebuild_2edecoder_2efail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2efail_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2efail(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2efail_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2edecoder_2efail(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ebuild_2edecoder_2ewhole_24cpr(V v_d_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = heff_tr(heff_call(v_d_240, 2, (V[]){heff_dup(v_s_241), v_i_242}));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop(v_s_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      if (heff_intLe_c(heff_strLength(v_s_241), heff_dup(v_j_246))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_MkPair, 2, (V[]){v_x_245, v_j_246})}});
      } else {
        heff_drop(v_x_245);
        heff_drop(v_j_246);
        heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_243)}});
  }
}
Clo g_heff_2ebuild_2edecoder_2ewordEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ewordEnd_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ewordEnd(V v_s_240, V v_i_241) {
top: ;
  if ((heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)32ULL)))) {
    return v_i_241;
  } else {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_i_241 = t_1;
    goto top;
  }
}
V g_heff_2ebuild_2edecoder_2ewordEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edecoder_2ewordEnd(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    V v_t_242 = (g_heff_2ebuild_2edecoder_2ewordEnd(v_s_240, heff_dup(v_i_241)));
    V v_i_243 = (g_heff_2ebuild_2edecoder_2ewordEnd(v_s_240, heff_dup(v_i_241)));
    V v_t_244;
    if ((heff_intLt_c(heff_dup(v_i_243), heff_strLength_lent(v_s_240, 0)) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_243, 0)) == ((int64_t)32ULL)))) {
      v_t_244 = heff_intAdd(v_i_243, MK_INT(1LL));
    } else {
      v_t_244 = v_i_243;
    }
    V v_f_245 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strSlice_lent(v_s_240, v_i_241, v_t_242, 6), v_t_244});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_245}});
  }
}
Clo g_heff_2ebuild_2edecoder_2ecolonAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ecolonAt_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ecolonAt(V v_s_240, V v_i_241) {
top: ;
  if ((heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)58ULL)))) {
    return v_i_241;
  } else {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_i_241 = t_1;
    goto top;
  }
}
V g_heff_2ebuild_2edecoder_2ecolonAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edecoder_2ecolonAt(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edecoder_2edigitsTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2edigitsTo_entry, 4, 0};

V g_heff_2ebuild_2edecoder_2edigitsTo(V v_s_240, V v_i_241, V v_j_242, V v_acc_243) {
top: ;
  if (heff_intLe_c_lent(v_j_242, v_i_241, 0)) {
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    return v_acc_243;
  } else {
    if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) < ((int64_t)48ULL)) || (((int64_t)57ULL) < heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0))))) {
      heff_drop(v_i_241);
      heff_drop(v_j_242);
      heff_drop(v_acc_243);
      return MK_INT(-1LL);
    } else {
      V v_t_244 = heff_intAdd(heff_intMul(v_acc_243, MK_INT(10LL)), heff_strByteAt_lent(v_s_240, v_i_241, 0));
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_j_242;
      V t_3 = heff_intSub(v_t_244, MK_INT(48LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2ebuild_2edecoder_2edigitsTo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edecoder_2edigitsTo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ebuild_2edecoder_2edecimalAt_24cpr(V v_s_240, V v_i_241, V v_j_242) {
top: ;
  if (heff_intLe_c_lent(v_j_242, v_i_241, 0)) {
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)45ULL))) {
      V v_n_243 = (g_heff_2ebuild_2edecoder_2edigitsTo(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_j_242, MK_INT(0LL)));
      if (heff_intLt_c_lent(v_n_243, MK_INT(0LL), 2)) {
        heff_drop(v_n_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V v_f_244 = heff_intSub(MK_INT(0LL), v_n_243);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_244}});
      }
    } else {
      V v_n_245 = (g_heff_2ebuild_2edecoder_2edigitsTo(v_s_240, v_i_241, v_j_242, MK_INT(0LL)));
      if (heff_intLt_c_lent(v_n_245, MK_INT(0LL), 2)) {
        heff_drop(v_n_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_n_245}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V v_s_240, V v_i_241) {
top: ;
  V v_x_242 = (g_heff_2ebuild_2edecoder_2ecolonAt(v_s_240, heff_dup(v_i_241)));
  V v_t_243 = heff_bool(heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_x_242)));
  heff_drop(v_x_242);
  if (((heff_dup(v_t_243) == NTAG(TAG_True)) || ({ V v_t_2418 = (g_heff_2ebuild_2edecoder_2ecolonAt(v_s_240, heff_dup(v_i_241))); int c_ = heff_intEq_c_lent(v_t_2418, v_i_241, 0); heff_drop(v_t_2418); c_; }))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    heff_drop(v_t_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    heff_drop(v_t_243);
    V v_t_244 = (g_heff_2ebuild_2edecoder_2ecolonAt(v_s_240, heff_dup(v_i_241)));
    V v_j_245 = heff_intAdd(v_t_244, MK_INT(1LL));
    V v_t_246 = (g_heff_2ebuild_2edecoder_2ecolonAt(v_s_240, heff_dup(v_i_241)));
    HeffT2 v_t_247 = (g_heff_2ebuild_2edecoder_2edecimalAt_24cpr(v_s_240, v_i_241, v_t_246));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_n_2410 = v_field_249;
        V v_s_2411 = v_s_240;
        V v_j_2412 = v_j_245;
        V v_n_2413 = v_n_2410;
        if ((heff_intLt_c_lent(v_n_2413, MK_INT(0LL), 2) || heff_intLt_c(heff_strLength_lent(v_s_2411, 0), heff_intAdd(heff_dup(v_j_2412), heff_dup(v_n_2413))))) {
          heff_drop(v_s_2411);
          heff_drop(v_j_2412);
          heff_drop(v_n_2413);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        } else {
          V v_t_2414 = heff_strSlice(heff_dup(v_s_2411), heff_dup(v_j_2412), heff_intAdd(heff_dup(v_j_2412), heff_dup(v_n_2413)));
          V v_i_2415 = heff_intAdd(v_j_2412, v_n_2413);
          V v_t_2416;
          if ((heff_intLt_c(heff_dup(v_i_2415), heff_strLength_lent(v_s_2411, 0)) && (heff_unbox_word(heff_strByteAt_lent(v_s_2411, v_i_2415, 0)) == ((int64_t)32ULL)))) {
            heff_drop(v_s_2411);
            v_t_2416 = heff_intAdd(v_i_2415, MK_INT(1LL));
          } else {
            heff_drop(v_s_2411);
            v_t_2416 = v_i_2415;
          }
          V v_f_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_t_2416});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2417}});
        }
      } else {
        heff_drop(v_s_240);
        heff_drop(v_j_245);
        heff_drop(v_field_249);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V v_s_240, V v_i_241) {
top: ;
  V v_j_242 = (g_heff_2ebuild_2edecoder_2ewordEnd(v_s_240, heff_dup(v_i_241)));
  V v_t_243 = (g_heff_2ebuild_2edecoder_2ewordEnd(v_s_240, heff_dup(v_i_241)));
  HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2edecimalAt_24cpr(v_s_240, v_i_241, v_t_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_n_247 = v_field_246;
      V v_t_248;
      if ((heff_intLt_c(heff_dup(v_j_242), heff_strLength_lent(v_s_240, 0)) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_242, 0)) == ((int64_t)32ULL)))) {
        v_t_248 = heff_intAdd(v_j_242, MK_INT(1LL));
      } else {
        v_t_248 = v_j_242;
      }
      V v_f_249 = heff_tag_n(TAG_MkPair, 2, (V[]){v_n_247, v_t_248});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_249}});
    } else {
      heff_drop(v_j_242);
      heff_drop(v_field_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24cpr(V v_d_240, V v_n_241, V v_p_242, V v_p_243) {
top: ;
  if (heff_intLe_c_lent(v_n_241, MK_INT(0LL), 2)) {
    heff_drop(v_d_240);
    heff_drop(v_n_241);
    heff_drop(v_p_242);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_243});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_244}});
  } else {
    V v_x3_245 = heff_tr(heff_call(heff_dup(v_d_240), 2, (V[]){heff_dup(v_p_242), v_p_243}));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      heff_drop(v_d_240);
      heff_drop(v_n_241);
      heff_drop(v_p_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_246 = heff_field(v_x3_245, 0);
      heff_take_n(v_x3_245, 1ULL, 1);
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        V v_m_249 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edecoder_2etimes_clo), 2, (V[]){v_d_240, heff_intSub(v_n_241, MK_INT(1LL))}));
        V v_x3_2410 = heff_tr(heff_call(v_m_249, 2, (V[]){v_p_242, v_j_248}));
        switch (heff_tag_of(v_x3_2410)) {
        case TAG_Nothing: {
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_x31_2411 = heff_field(v_x3_2410, 0);
          heff_take_n(v_x3_2410, 1ULL, 1);
          switch (heff_tag_of(v_x31_2411)) {
          case TAG_MkPair: {
            V v_x_2412 = heff_field(v_x31_2411, 0);
            V v_j_2413 = heff_field(v_x31_2411, 1);
            V v_ru_24x31_2411_24MkPair = heff_take_reuse_n(v_x31_2411, 3ULL, 2);
            V v_t_2414 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2411_24MkPair, TAG_Cons, 2, (V[]){v_x_247, v_x_2412}), v_j_2413});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2414}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2411)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x3_2410)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_245)}});
    }
  }
}
Clo g_heff_2ebuild_2edecoder_2etimes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_entry, 4, 0};

V g_heff_2ebuild_2edecoder_2etimes(V v_d_240, V v_n_241, V v_p_242, V v_p_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2etimes_24cpr(v_d_240, v_n_241, v_p_242, v_p_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_246});
    } else {
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2etimes(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_p_241), v_p_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_247 = v_field_246;
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          HeffT2 v_t_2410 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_249));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              V v_x31_2413 = v_field_2412;
              switch (heff_tag_of(v_x31_2413)) {
              case TAG_MkPair: {
                V v_x_2414 = heff_field(v_x31_2413, 0);
                V v_j_2415 = heff_field(v_x31_2413, 1);
                V v_ru_24x31_2413_24MkPair = heff_take_reuse_n(v_x31_2413, 3ULL, 2);
                V v_t_2416 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2413_24MkPair, TAG_Cons, 2, (V[]){v_x_248, v_x_2414}), v_j_2415});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2416}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
              }
            } else {
              heff_drop(v_x_248);
              heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
              heff_drop(v_field_2412);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str0, 1, "t");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str1, 1, "f");
Clo g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(V v_f_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_245;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        heff_take_n(v_x31_246, 3ULL, 2);
        if (heff_strEq_c_lent(v_x_247, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str0), 2)) {
          heff_drop(v_x_247);
          return heff_tail(v_f_240, 3, (V[]){NTAG(TAG_True), v_s_241, v_j_248});
        } else {
          if (heff_strEq_c(v_x_247, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str1))) {
            return heff_tail(v_f_240, 3, (V[]){NTAG(TAG_False), v_s_241, v_j_248});
          } else {
            heff_drop(v_f_240);
            heff_drop(v_s_241);
            heff_drop(v_j_248);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop(v_f_240);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_p_241), v_p_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_247 = v_field_246;
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          HeffT2 v_t_2410 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_p_241), v_j_249));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              V v_x31_2413 = v_field_2412;
              switch (heff_tag_of(v_x31_2413)) {
              case TAG_MkPair: {
                V v_x_2414 = heff_field(v_x31_2413, 0);
                V v_j_2415 = heff_field(v_x31_2413, 1);
                V v_ru_24x31_2413_24MkPair = heff_take_reuse_n(v_x31_2413, 3ULL, 2);
                HeffT2 v_t_2416 = (g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2415));
                {
                  V v_field_2418 = v_t_2416.f[1];
                  int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
                  if ((v_tag_2417 == ((int64_t)0ULL))) {
                    V v_x31_2419 = v_field_2418;
                    switch (heff_tag_of(v_x31_2419)) {
                    case TAG_MkPair: {
                      V v_x_2420 = heff_field(v_x31_2419, 0);
                      V v_j_2421 = heff_field(v_x31_2419, 1);
                      V v_ru_24x31_2419_24MkPair = heff_take_reuse_n(v_x31_2419, 3ULL, 2);
                      V v_t_2422 = heff_tag_at_n(v_ru_24x31_2419_24MkPair, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){v_x_248, v_x_2414}), v_x_2420});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2422, v_j_2421})}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2419)}});
                    }
                  } else {
                    heff_drop(v_x_248);
                    heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                    heff_drop(v_x_2414);
                    heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                    heff_drop(v_field_2418);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
              }
            } else {
              heff_drop(v_n_240);
              heff_drop(v_p_241);
              heff_drop(v_x_248);
              heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
              heff_drop(v_field_2412);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1952093399x207461701_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    V v_s_244 = heff_dup(v_p_241);
    V v_i_245 = v_p_242;
    V v_x3_246 = heff_tr(g_heff_2ebuild_2ebackcache_2eunitD(heff_dup(v_s_244), heff_dup(v_i_245)));
    V v_x3_2412;
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      heff_drop(v_s_244);
      heff_drop(v_i_245);
      v_x3_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x31_247 = heff_field(v_x3_246, 0);
      V v_ru_24x3_246_24Just = heff_take_reuse_n(v_x3_246, 1ULL, 1);
      switch (heff_tag_of(v_x31_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x31_247, 0);
        V v_j_249 = heff_field(v_x31_247, 1);
        V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
        V v_t_2410;
        if ((heff_intLt_c_lent(v_i_245, v_j_249, 0) && (heff_unbox_word(heff_strByteAt(heff_dup(v_s_244), heff_intSub(heff_dup(v_j_249), MK_INT(1LL)))) == ((int64_t)32ULL)))) {
          v_t_2410 = heff_intSub(heff_dup(v_j_249), MK_INT(1LL));
        } else {
          v_t_2410 = heff_dup(v_j_249);
        }
        V v_t_2411 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){v_x_248, heff_strSlice(v_s_244, v_i_245, v_t_2410)});
        v_x3_2412 = heff_tag_at_n(v_ru_24x3_246_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_j_249})});
        break;
      }
      default: heff_nomatch(v_x31_247);
      }
      break;
    }
    default: heff_nomatch(v_x3_246);
    }
    switch (heff_tag_of(v_x3_2412)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_2413 = heff_field(v_x3_2412, 0);
      heff_take_n(v_x3_2412, 1ULL, 1);
      switch (heff_tag_of(v_x31_2413)) {
      case TAG_MkPair: {
        V v_x_2414 = heff_field(v_x31_2413, 0);
        V v_j_2415 = heff_field(v_x31_2413, 1);
        V v_ru_24x31_2413_24MkPair = heff_take_reuse_n(v_x31_2413, 3ULL, 2);
        HeffT2 v_t_2416 = (g_heff_2ebuild_2edecoder_2etimes_24s1952093399x207461701_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2415));
        {
          V v_field_2418 = v_t_2416.f[1];
          int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
          if ((v_tag_2417 == ((int64_t)0ULL))) {
            V v_x31_2419 = v_field_2418;
            switch (heff_tag_of(v_x31_2419)) {
            case TAG_MkPair: {
              V v_x_2420 = heff_field(v_x31_2419, 0);
              V v_j_2421 = heff_field(v_x31_2419, 1);
              V v_ru_24x31_2419_24MkPair = heff_take_reuse_n(v_x31_2419, 3ULL, 2);
              V v_t_2422 = heff_tag_at_n(v_ru_24x31_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2419_24MkPair, TAG_Cons, 2, (V[]){v_x_2414, v_x_2420}), v_j_2421});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2422}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2419)}});
            }
          } else {
            heff_drop(v_x_2414);
            heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
            heff_drop(v_field_2418);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_2412)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s2049614891x1595878686_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    V v_s_244 = heff_dup(v_p_241);
    V v_i_245 = v_p_242;
    V v_s_246 = heff_dup(v_s_244);
    V v_i_247 = heff_dup(v_i_245);
    HeffT2 v_t_248 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_246), v_i_247));
    V v_x3_2433;
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_x31_2411 = v_field_2410;
        switch (heff_tag_of(v_x31_2411)) {
        case TAG_MkPair: {
          V v_x_2412 = heff_field(v_x31_2411, 0);
          V v_j_2413 = heff_field(v_x31_2411, 1);
          V v_ru_24x31_2411_24MkPair = heff_take_reuse_n(v_x31_2411, 3ULL, 2);
          HeffT2 v_t_2414 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_246), v_j_2413));
          {
            V v_field_2416 = v_t_2414.f[1];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              V v_x31_2417 = v_field_2416;
              switch (heff_tag_of(v_x31_2417)) {
              case TAG_MkPair: {
                V v_x_2418 = heff_field(v_x31_2417, 0);
                V v_j_2419 = heff_field(v_x31_2417, 1);
                heff_take_n(v_x31_2417, 3ULL, 2);
                HeffT2 v_t_2420 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_246, v_j_2419));
                {
                  V v_field_2422 = v_t_2420.f[1];
                  int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                  if ((v_tag_2421 == ((int64_t)0ULL))) {
                    V v_x31_2423 = v_field_2422;
                    switch (heff_tag_of(v_x31_2423)) {
                    case TAG_MkPair: {
                      V v_x_2424 = heff_field(v_x31_2423, 0);
                      V v_j_2425 = heff_field(v_x31_2423, 1);
                      heff_take_n(v_x31_2423, 3ULL, 2);
                      HeffT2 v_t_2426 = (g_heff_2ebuild_2edecoder_2etimes_24s1952093399x207461701_24cpr(v_x_2424, v_s_246, v_j_2425));
                      {
                        V v_field_2428 = v_t_2426.f[1];
                        int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
                        if ((v_tag_2427 == ((int64_t)0ULL))) {
                          V v_x31_2429 = v_field_2428;
                          switch (heff_tag_of(v_x31_2429)) {
                          case TAG_MkPair: {
                            V v_x_2430 = heff_field(v_x31_2429, 0);
                            V v_j_2431 = heff_field(v_x31_2429, 1);
                            heff_take_n(v_x31_2429, 3ULL, 2);
                            V v_t_2432 = heff_tag_at_n(v_ru_24x31_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(3, shape_owner__ver__units, (V[]){v_x_2412, v_x_2418, v_x_2430}), v_j_2431});
                            v_x3_2433 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2432});
                            break;
                          }
                          default: heff_nomatch(v_x31_2429);
                          }
                        } else {
                          heff_drop(v_x_2412);
                          heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                          heff_drop(v_x_2418);
                          heff_drop(v_field_2428);
                          v_x3_2433 = NTAG(TAG_Nothing);
                        }
                      }
                      break;
                    }
                    default: heff_nomatch(v_x31_2423);
                    }
                  } else {
                    heff_drop(v_s_246);
                    heff_drop(v_x_2412);
                    heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                    heff_drop(v_x_2418);
                    heff_drop(v_field_2422);
                    v_x3_2433 = NTAG(TAG_Nothing);
                  }
                }
                break;
              }
              default: heff_nomatch(v_x31_2417);
              }
            } else {
              heff_drop(v_s_246);
              heff_drop(v_x_2412);
              heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
              heff_drop(v_field_2416);
              v_x3_2433 = NTAG(TAG_Nothing);
            }
          }
          break;
        }
        default: heff_nomatch(v_x31_2411);
        }
      } else {
        heff_drop(v_s_246);
        heff_drop(v_field_2410);
        v_x3_2433 = NTAG(TAG_Nothing);
      }
    }
    V v_x3_2439;
    switch (heff_tag_of(v_x3_2433)) {
    case TAG_Nothing: {
      heff_drop(v_s_244);
      heff_drop(v_i_245);
      v_x3_2439 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x31_2434 = heff_field(v_x3_2433, 0);
      V v_ru_24x3_2433_24Just = heff_take_reuse_n(v_x3_2433, 1ULL, 1);
      switch (heff_tag_of(v_x31_2434)) {
      case TAG_MkPair: {
        V v_x_2435 = heff_field(v_x31_2434, 0);
        V v_j_2436 = heff_field(v_x31_2434, 1);
        V v_ru_24x31_2434_24MkPair = heff_take_reuse_n(v_x31_2434, 3ULL, 2);
        V v_t_2437;
        if ((heff_intLt_c_lent(v_i_245, v_j_2436, 0) && (heff_unbox_word(heff_strByteAt(heff_dup(v_s_244), heff_intSub(heff_dup(v_j_2436), MK_INT(1LL)))) == ((int64_t)32ULL)))) {
          v_t_2437 = heff_intSub(heff_dup(v_j_2436), MK_INT(1LL));
        } else {
          v_t_2437 = heff_dup(v_j_2436);
        }
        V v_t_2438 = heff_tag_at_n(v_ru_24x31_2434_24MkPair, TAG_MkPair, 2, (V[]){v_x_2435, heff_strSlice(v_s_244, v_i_245, v_t_2437)});
        v_x3_2439 = heff_tag_at_n(v_ru_24x3_2433_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2438, v_j_2436})});
        break;
      }
      default: heff_nomatch(v_x31_2434);
      }
      break;
    }
    default: heff_nomatch(v_x3_2433);
    }
    switch (heff_tag_of(v_x3_2439)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_2440 = heff_field(v_x3_2439, 0);
      heff_take_n(v_x3_2439, 1ULL, 1);
      switch (heff_tag_of(v_x31_2440)) {
      case TAG_MkPair: {
        V v_x_2441 = heff_field(v_x31_2440, 0);
        V v_j_2442 = heff_field(v_x31_2440, 1);
        V v_ru_24x31_2440_24MkPair = heff_take_reuse_n(v_x31_2440, 3ULL, 2);
        HeffT2 v_t_2443 = (g_heff_2ebuild_2edecoder_2etimes_24s2049614891x1595878686_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2442));
        {
          V v_field_2445 = v_t_2443.f[1];
          int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
          if ((v_tag_2444 == ((int64_t)0ULL))) {
            V v_x31_2446 = v_field_2445;
            switch (heff_tag_of(v_x31_2446)) {
            case TAG_MkPair: {
              V v_x_2447 = heff_field(v_x31_2446, 0);
              V v_j_2448 = heff_field(v_x31_2446, 1);
              V v_ru_24x31_2446_24MkPair = heff_take_reuse_n(v_x31_2446, 3ULL, 2);
              V v_t_2449 = heff_tag_at_n(v_ru_24x31_2440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2446_24MkPair, TAG_Cons, 2, (V[]){v_x_2441, v_x_2447}), v_j_2448});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2449}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2446)}});
            }
          } else {
            heff_drop(v_x_2441);
            heff_drop_cell(v_ru_24x31_2440_24MkPair, 2);
            heff_drop(v_field_2445);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_2440)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_2439)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s481066606x2100141841_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    V v_s_244 = heff_dup(v_p_241);
    V v_i_245 = v_p_242;
    V v_x3_246 = heff_tr(g_heff_2ebuild_2ebackcache_2ecopyD(heff_dup(v_s_244), heff_dup(v_i_245)));
    V v_x3_2412;
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      heff_drop(v_s_244);
      heff_drop(v_i_245);
      v_x3_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x31_247 = heff_field(v_x3_246, 0);
      V v_ru_24x3_246_24Just = heff_take_reuse_n(v_x3_246, 1ULL, 1);
      switch (heff_tag_of(v_x31_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x31_247, 0);
        V v_j_249 = heff_field(v_x31_247, 1);
        V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
        V v_t_2410;
        if ((heff_intLt_c_lent(v_i_245, v_j_249, 0) && (heff_unbox_word(heff_strByteAt(heff_dup(v_s_244), heff_intSub(heff_dup(v_j_249), MK_INT(1LL)))) == ((int64_t)32ULL)))) {
          v_t_2410 = heff_intSub(heff_dup(v_j_249), MK_INT(1LL));
        } else {
          v_t_2410 = heff_dup(v_j_249);
        }
        V v_t_2411 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){v_x_248, heff_strSlice(v_s_244, v_i_245, v_t_2410)});
        v_x3_2412 = heff_tag_at_n(v_ru_24x3_246_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_j_249})});
        break;
      }
      default: heff_nomatch(v_x31_247);
      }
      break;
    }
    default: heff_nomatch(v_x3_246);
    }
    switch (heff_tag_of(v_x3_2412)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_2413 = heff_field(v_x3_2412, 0);
      heff_take_n(v_x3_2412, 1ULL, 1);
      switch (heff_tag_of(v_x31_2413)) {
      case TAG_MkPair: {
        V v_x_2414 = heff_field(v_x31_2413, 0);
        V v_j_2415 = heff_field(v_x31_2413, 1);
        V v_ru_24x31_2413_24MkPair = heff_take_reuse_n(v_x31_2413, 3ULL, 2);
        HeffT2 v_t_2416 = (g_heff_2ebuild_2edecoder_2etimes_24s481066606x2100141841_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2415));
        {
          V v_field_2418 = v_t_2416.f[1];
          int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
          if ((v_tag_2417 == ((int64_t)0ULL))) {
            V v_x31_2419 = v_field_2418;
            switch (heff_tag_of(v_x31_2419)) {
            case TAG_MkPair: {
              V v_x_2420 = heff_field(v_x31_2419, 0);
              V v_j_2421 = heff_field(v_x31_2419, 1);
              V v_ru_24x31_2419_24MkPair = heff_take_reuse_n(v_x31_2419, 3ULL, 2);
              V v_t_2422 = heff_tag_at_n(v_ru_24x31_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2419_24MkPair, TAG_Cons, 2, (V[]){v_x_2414, v_x_2420}), v_j_2421});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2422}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2419)}});
            }
          } else {
            heff_drop(v_x_2414);
            heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
            heff_drop(v_field_2418);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_2412)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1954476619x1073210498_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    V v_s_244 = heff_dup(v_p_241);
    V v_i_245 = v_p_242;
    HeffT2 v_t_246 = (g_heff_2ebuild_2ebackcache_2eemitD_24cpr(heff_dup(v_s_244), heff_dup(v_i_245)));
    V v_x3_2414;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_x31_249 = v_field_248;
        switch (heff_tag_of(v_x31_249)) {
        case TAG_MkPair: {
          V v_x_2410 = heff_field(v_x31_249, 0);
          V v_j_2411 = heff_field(v_x31_249, 1);
          V v_ru_24x31_249_24MkPair = heff_take_reuse_n(v_x31_249, 3ULL, 2);
          V v_t_2412;
          if ((heff_intLt_c_lent(v_i_245, v_j_2411, 0) && (heff_unbox_word(heff_strByteAt(heff_dup(v_s_244), heff_intSub(heff_dup(v_j_2411), MK_INT(1LL)))) == ((int64_t)32ULL)))) {
            v_t_2412 = heff_intSub(heff_dup(v_j_2411), MK_INT(1LL));
          } else {
            v_t_2412 = heff_dup(v_j_2411);
          }
          V v_t_2413 = heff_tag_at_n(v_ru_24x31_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2410, heff_strSlice(v_s_244, v_i_245, v_t_2412)});
          v_x3_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_j_2411})});
          break;
        }
        default: heff_nomatch(v_x31_249);
        }
      } else {
        heff_drop(v_s_244);
        heff_drop(v_i_245);
        heff_drop(v_field_248);
        v_x3_2414 = NTAG(TAG_Nothing);
      }
    }
    switch (heff_tag_of(v_x3_2414)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_2415 = heff_field(v_x3_2414, 0);
      heff_take_n(v_x3_2414, 1ULL, 1);
      switch (heff_tag_of(v_x31_2415)) {
      case TAG_MkPair: {
        V v_x_2416 = heff_field(v_x31_2415, 0);
        V v_j_2417 = heff_field(v_x31_2415, 1);
        V v_ru_24x31_2415_24MkPair = heff_take_reuse_n(v_x31_2415, 3ULL, 2);
        HeffT2 v_t_2418 = (g_heff_2ebuild_2edecoder_2etimes_24s1954476619x1073210498_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2417));
        {
          V v_field_2420 = v_t_2418.f[1];
          int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
          if ((v_tag_2419 == ((int64_t)0ULL))) {
            V v_x31_2421 = v_field_2420;
            switch (heff_tag_of(v_x31_2421)) {
            case TAG_MkPair: {
              V v_x_2422 = heff_field(v_x31_2421, 0);
              V v_j_2423 = heff_field(v_x31_2421, 1);
              V v_ru_24x31_2421_24MkPair = heff_take_reuse_n(v_x31_2421, 3ULL, 2);
              V v_t_2424 = heff_tag_at_n(v_ru_24x31_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2421_24MkPair, TAG_Cons, 2, (V[]){v_x_2416, v_x_2422}), v_j_2423});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2424}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2421)}});
            }
          } else {
            heff_drop(v_x_2416);
            heff_drop_cell(v_ru_24x31_2415_24MkPair, 2);
            heff_drop(v_field_2420);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_2415)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_2414)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1391953550x1663492198_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    V v_s_244 = heff_dup(v_p_241);
    V v_i_245 = v_p_242;
    HeffT2 v_t_246 = (g_heff_2ebuild_2ebackcache_2ejsD_24cpr(heff_dup(v_s_244), heff_dup(v_i_245)));
    V v_x3_2414;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_x31_249 = v_field_248;
        switch (heff_tag_of(v_x31_249)) {
        case TAG_MkPair: {
          V v_x_2410 = heff_field(v_x31_249, 0);
          V v_j_2411 = heff_field(v_x31_249, 1);
          V v_ru_24x31_249_24MkPair = heff_take_reuse_n(v_x31_249, 3ULL, 2);
          V v_t_2412;
          if ((heff_intLt_c_lent(v_i_245, v_j_2411, 0) && (heff_unbox_word(heff_strByteAt(heff_dup(v_s_244), heff_intSub(heff_dup(v_j_2411), MK_INT(1LL)))) == ((int64_t)32ULL)))) {
            v_t_2412 = heff_intSub(heff_dup(v_j_2411), MK_INT(1LL));
          } else {
            v_t_2412 = heff_dup(v_j_2411);
          }
          V v_t_2413 = heff_tag_at_n(v_ru_24x31_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2410, heff_strSlice(v_s_244, v_i_245, v_t_2412)});
          v_x3_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_j_2411})});
          break;
        }
        default: heff_nomatch(v_x31_249);
        }
      } else {
        heff_drop(v_s_244);
        heff_drop(v_i_245);
        heff_drop(v_field_248);
        v_x3_2414 = NTAG(TAG_Nothing);
      }
    }
    switch (heff_tag_of(v_x3_2414)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_2415 = heff_field(v_x3_2414, 0);
      heff_take_n(v_x3_2414, 1ULL, 1);
      switch (heff_tag_of(v_x31_2415)) {
      case TAG_MkPair: {
        V v_x_2416 = heff_field(v_x31_2415, 0);
        V v_j_2417 = heff_field(v_x31_2415, 1);
        V v_ru_24x31_2415_24MkPair = heff_take_reuse_n(v_x31_2415, 3ULL, 2);
        HeffT2 v_t_2418 = (g_heff_2ebuild_2edecoder_2etimes_24s1391953550x1663492198_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2417));
        {
          V v_field_2420 = v_t_2418.f[1];
          int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
          if ((v_tag_2419 == ((int64_t)0ULL))) {
            V v_x31_2421 = v_field_2420;
            switch (heff_tag_of(v_x31_2421)) {
            case TAG_MkPair: {
              V v_x_2422 = heff_field(v_x31_2421, 0);
              V v_j_2423 = heff_field(v_x31_2421, 1);
              V v_ru_24x31_2421_24MkPair = heff_take_reuse_n(v_x31_2421, 3ULL, 2);
              V v_t_2424 = heff_tag_at_n(v_ru_24x31_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2421_24MkPair, TAG_Cons, 2, (V[]){v_x_2416, v_x_2422}), v_j_2423});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2424}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2421)}});
            }
          } else {
            heff_drop(v_x_2416);
            heff_drop_cell(v_ru_24x31_2415_24MkPair, 2);
            heff_drop(v_field_2420);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_2415)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_2414)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str1, 1, "1");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str2, 1, "2");

HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str0), 2)) {
          heff_drop(v_x_246);
          V v_t_248 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Expl), v_j_247});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_248}});
        } else {
          if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str1), 2)) {
            heff_drop(v_x_246);
            V v_t_249 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Impl), v_j_247});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_249}});
          } else {
            if (heff_strEq_c(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str2))) {
              V v_t_2410 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Inst), v_j_247});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2410}});
            } else {
              heff_drop(v_j_247);
              heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str1, 1, "1");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str2, 1, "2");

HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str0), 2)) {
          heff_drop(v_x_246);
          V v_t_248 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Small), v_j_247});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_248}});
        } else {
          if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str1), 2)) {
            heff_drop(v_x_246);
            V v_t_249 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Large), v_j_247});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_249}});
          } else {
            if (heff_strEq_c(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str2))) {
              V v_t_2410 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_TopL), v_j_247});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2410}});
            } else {
              heff_drop(v_j_247);
              heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr_str1, 1, "1");

HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr_str0), 2)) {
          heff_drop(v_x_246);
          V v_t_248 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_248, v_j_247})}});
        } else {
          if (heff_strEq_c(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr_str1))) {
            V v_t_249 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_LargeU)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_249, v_j_247})}});
          } else {
            heff_drop(v_j_247);
            heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    V v_x3_244 = heff_tr(g_heff_2ebuild_2ecache_2emeltFixGroup(heff_dup(v_p_241), v_p_242));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_245 = heff_field(v_x3_244, 0);
      heff_take_n(v_x3_244, 1ULL, 1);
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        HeffT2 v_t_248 = (g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x31_2411 = v_field_2410;
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              V v_ru_24x31_2411_24MkPair = heff_take_reuse_n(v_x31_2411, 3ULL, 2);
              V v_t_2414 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2411_24MkPair, TAG_Cons, 2, (V[]){v_x_246, v_x_2412}), v_j_2413});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2414}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2411)}});
            }
          } else {
            heff_drop(v_x_246);
            heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
            heff_drop(v_field_2410);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_244)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_p_241), v_p_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_247 = v_field_246;
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          HeffT2 v_t_2410 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_p_241), v_j_249));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              V v_x31_2413 = v_field_2412;
              switch (heff_tag_of(v_x31_2413)) {
              case TAG_MkPair: {
                V v_x_2414 = heff_field(v_x31_2413, 0);
                V v_j_2415 = heff_field(v_x31_2413, 1);
                V v_ru_24x31_2413_24MkPair = heff_take_reuse_n(v_x31_2413, 3ULL, 2);
                HeffT2 v_t_2416 = (g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2415));
                {
                  V v_field_2418 = v_t_2416.f[1];
                  int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
                  if ((v_tag_2417 == ((int64_t)0ULL))) {
                    V v_x31_2419 = v_field_2418;
                    switch (heff_tag_of(v_x31_2419)) {
                    case TAG_MkPair: {
                      V v_x_2420 = heff_field(v_x31_2419, 0);
                      V v_j_2421 = heff_field(v_x31_2419, 1);
                      heff_take_n(v_x31_2419, 3ULL, 2);
                      V v_t_2422 = heff_tag_at_n(v_ru_24x31_2413_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_tighter__looser, (V[]){v_x_248, v_x_2414}), v_x_2420});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){v_t_2422, v_j_2421})}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2419)}});
                    }
                  } else {
                    heff_drop(v_x_248);
                    heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                    heff_drop(v_x_2414);
                    heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                    heff_drop(v_field_2418);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
              }
            } else {
              heff_drop(v_n_240);
              heff_drop(v_p_241);
              heff_drop(v_x_248);
              heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
              heff_drop(v_field_2412);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_p_241), v_p_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_a_247 = v_field_246;
        switch (heff_tag_of(v_a_247)) {
        case TAG_MkPair: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          V v_ru_24a_247_24MkPair = heff_take_reuse_n(v_a_247, 3ULL, 2);
          V v_s_2410 = heff_dup(v_p_241);
          V v_i_2411 = v_a_249;
          HeffT2 v_t_2412 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_2410, v_i_2411));
          V v_a_2437;
          {
            V v_field_2414 = v_t_2412.f[1];
            int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
            if ((v_tag_2413 == ((int64_t)0ULL))) {
              V v_x31_2415 = v_field_2414;
              switch (heff_tag_of(v_x31_2415)) {
              case TAG_MkPair: {
                V v_x_2416 = heff_field(v_x31_2415, 0);
                V v_j_2417 = heff_field(v_x31_2415, 1);
                V v_ru_24x31_2415_24MkPair = heff_take_reuse_n(v_x31_2415, 3ULL, 2);
                HeffT2 v_t_2418 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2416, heff_dup(v_s_2410), v_j_2417));
                {
                  V v_field_2420 = v_t_2418.f[1];
                  int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
                  if ((v_tag_2419 == ((int64_t)0ULL))) {
                    V v_x31_2421 = v_field_2420;
                    switch (heff_tag_of(v_x31_2421)) {
                    case TAG_MkPair: {
                      V v_x_2422 = heff_field(v_x31_2421, 0);
                      V v_j_2423 = heff_field(v_x31_2421, 1);
                      heff_take_n(v_x31_2421, 3ULL, 2);
                      HeffT2 v_t_2424 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_2410, v_j_2423));
                      {
                        V v_field_2426 = v_t_2424.f[1];
                        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
                        if ((v_tag_2425 == ((int64_t)0ULL))) {
                          V v_x31_2427 = v_field_2426;
                          switch (heff_tag_of(v_x31_2427)) {
                          case TAG_MkPair: {
                            V v_x_2428 = heff_field(v_x31_2427, 0);
                            V v_j_2429 = heff_field(v_x31_2427, 1);
                            heff_take_n(v_x31_2427, 3ULL, 2);
                            HeffT2 v_t_2430 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_2428, v_s_2410, v_j_2429));
                            {
                              V v_field_2432 = v_t_2430.f[1];
                              int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
                              if ((v_tag_2431 == ((int64_t)0ULL))) {
                                V v_x31_2433 = v_field_2432;
                                switch (heff_tag_of(v_x31_2433)) {
                                case TAG_MkPair: {
                                  V v_x_2434 = heff_field(v_x31_2433, 0);
                                  V v_j_2435 = heff_field(v_x31_2433, 1);
                                  heff_take_n(v_x31_2433, 3ULL, 2);
                                  V v_t_2436 = heff_tag_at_n(v_ru_24a_247_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2422), v_x_2434});
                                  v_a_2437 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_2415_24MkPair, TAG_MkPair, 2, (V[]){v_t_2436, v_j_2435})});
                                  break;
                                }
                                default: heff_nomatch(v_x31_2433);
                                }
                              } else {
                                heff_drop_cell(v_ru_24a_247_24MkPair, 2);
                                heff_drop_cell(v_ru_24x31_2415_24MkPair, 2);
                                heff_drop(v_x_2422);
                                heff_drop(v_field_2432);
                                v_a_2437 = NTAG(TAG_Nothing);
                              }
                            }
                            break;
                          }
                          default: heff_nomatch(v_x31_2427);
                          }
                        } else {
                          heff_drop_cell(v_ru_24a_247_24MkPair, 2);
                          heff_drop(v_s_2410);
                          heff_drop_cell(v_ru_24x31_2415_24MkPair, 2);
                          heff_drop(v_x_2422);
                          heff_drop(v_field_2426);
                          v_a_2437 = NTAG(TAG_Nothing);
                        }
                      }
                      break;
                    }
                    default: heff_nomatch(v_x31_2421);
                    }
                  } else {
                    heff_drop_cell(v_ru_24a_247_24MkPair, 2);
                    heff_drop(v_s_2410);
                    heff_drop_cell(v_ru_24x31_2415_24MkPair, 2);
                    heff_drop(v_field_2420);
                    v_a_2437 = NTAG(TAG_Nothing);
                  }
                }
                break;
              }
              default: heff_nomatch(v_x31_2415);
              }
            } else {
              heff_drop_cell(v_ru_24a_247_24MkPair, 2);
              heff_drop(v_s_2410);
              heff_drop(v_field_2414);
              v_a_2437 = NTAG(TAG_Nothing);
            }
          }
          switch (heff_tag_of(v_a_2437)) {
          case TAG_Nothing: {
            heff_drop(v_n_240);
            heff_drop(v_p_241);
            heff_drop(v_a_248);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_a_2438 = heff_field(v_a_2437, 0);
            heff_take_n(v_a_2437, 1ULL, 1);
            switch (heff_tag_of(v_a_2438)) {
            case TAG_MkPair: {
              V v_a_2439 = heff_field(v_a_2438, 0);
              V v_a_2440 = heff_field(v_a_2438, 1);
              V v_ru_24a_2438_24MkPair = heff_take_reuse_n(v_a_2438, 3ULL, 2);
              HeffT2 v_t_2441 = (g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_a_2440));
              {
                V v_field_2443 = v_t_2441.f[1];
                int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
                if ((v_tag_2442 == ((int64_t)0ULL))) {
                  V v_x31_2444 = v_field_2443;
                  switch (heff_tag_of(v_x31_2444)) {
                  case TAG_MkPair: {
                    V v_x_2445 = heff_field(v_x31_2444, 0);
                    V v_j_2446 = heff_field(v_x31_2444, 1);
                    V v_ru_24x31_2444_24MkPair = heff_take_reuse_n(v_x31_2444, 3ULL, 2);
                    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24a_2438_24MkPair, TAG_MkPair, 2, (V[]){v_a_248, v_a_2439}), v_x_2445});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2444_24MkPair, TAG_MkPair, 2, (V[]){v_t_2447, v_j_2446})}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2444)}});
                  }
                } else {
                  heff_drop(v_a_248);
                  heff_drop(v_a_2439);
                  heff_drop_cell(v_ru_24a_2438_24MkPair, 2);
                  heff_drop(v_field_2443);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_a_2438)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_2437)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_a_247)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_p_241), v_p_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_a_247 = v_field_246;
        switch (heff_tag_of(v_a_247)) {
        case TAG_MkPair: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          V v_ru_24a_247_24MkPair = heff_take_reuse_n(v_a_247, 3ULL, 2);
          V v_s_2410 = heff_dup(v_p_241);
          V v_i_2411 = v_a_249;
          HeffT2 v_t_2412 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_2410, v_i_2411));
          V v_a_2425;
          {
            V v_field_2414 = v_t_2412.f[1];
            int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
            if ((v_tag_2413 == ((int64_t)0ULL))) {
              V v_x31_2415 = v_field_2414;
              switch (heff_tag_of(v_x31_2415)) {
              case TAG_MkPair: {
                V v_x_2416 = heff_field(v_x31_2415, 0);
                V v_j_2417 = heff_field(v_x31_2415, 1);
                heff_take_n(v_x31_2415, 3ULL, 2);
                HeffT2 v_t_2418 = (g_heff_2ebuild_2edecoder_2etimes_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1)), v_x_2416, v_s_2410, v_j_2417));
                {
                  V v_field_2420 = v_t_2418.f[1];
                  int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
                  if ((v_tag_2419 == ((int64_t)0ULL))) {
                    V v_x31_2421 = v_field_2420;
                    switch (heff_tag_of(v_x31_2421)) {
                    case TAG_MkPair: {
                      V v_x_2422 = heff_field(v_x31_2421, 0);
                      V v_j_2423 = heff_field(v_x31_2421, 1);
                      heff_take_n(v_x31_2421, 3ULL, 2);
                      V v_t_2424 = heff_tag_at_n(v_ru_24a_247_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2422), v_j_2423});
                      v_a_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2424});
                      break;
                    }
                    default: heff_nomatch(v_x31_2421);
                    }
                  } else {
                    heff_drop_cell(v_ru_24a_247_24MkPair, 2);
                    heff_drop(v_field_2420);
                    v_a_2425 = NTAG(TAG_Nothing);
                  }
                }
                break;
              }
              default: heff_nomatch(v_x31_2415);
              }
            } else {
              heff_drop_cell(v_ru_24a_247_24MkPair, 2);
              heff_drop(v_s_2410);
              heff_drop(v_field_2414);
              v_a_2425 = NTAG(TAG_Nothing);
            }
          }
          switch (heff_tag_of(v_a_2425)) {
          case TAG_Nothing: {
            heff_drop(v_n_240);
            heff_drop(v_p_241);
            heff_drop(v_a_248);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_a_2426 = heff_field(v_a_2425, 0);
            heff_take_n(v_a_2425, 1ULL, 1);
            switch (heff_tag_of(v_a_2426)) {
            case TAG_MkPair: {
              V v_a_2427 = heff_field(v_a_2426, 0);
              V v_a_2428 = heff_field(v_a_2426, 1);
              V v_ru_24a_2426_24MkPair = heff_take_reuse_n(v_a_2426, 3ULL, 2);
              HeffT2 v_t_2429 = (g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_a_2428));
              {
                V v_field_2431 = v_t_2429.f[1];
                int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
                if ((v_tag_2430 == ((int64_t)0ULL))) {
                  V v_x31_2432 = v_field_2431;
                  switch (heff_tag_of(v_x31_2432)) {
                  case TAG_MkPair: {
                    V v_x_2433 = heff_field(v_x31_2432, 0);
                    V v_j_2434 = heff_field(v_x31_2432, 1);
                    V v_ru_24x31_2432_24MkPair = heff_take_reuse_n(v_x31_2432, 3ULL, 2);
                    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24a_2426_24MkPair, TAG_MkPair, 2, (V[]){v_a_248, v_a_2427}), v_x_2433});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2432_24MkPair, TAG_MkPair, 2, (V[]){v_t_2435, v_j_2434})}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2432)}});
                  }
                } else {
                  heff_drop(v_a_248);
                  heff_drop(v_a_2427);
                  heff_drop_cell(v_ru_24a_2426_24MkPair, 2);
                  heff_drop(v_field_2431);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_a_2426)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_2425)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_a_247)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_p_241), v_p_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_247 = v_field_246;
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          HeffT2 v_t_2410 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_p_241), v_j_249));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              V v_x31_2413 = v_field_2412;
              switch (heff_tag_of(v_x31_2413)) {
              case TAG_MkPair: {
                V v_x_2414 = heff_field(v_x31_2413, 0);
                V v_j_2415 = heff_field(v_x31_2413, 1);
                V v_ru_24x31_2413_24MkPair = heff_take_reuse_n(v_x31_2413, 3ULL, 2);
                HeffT2 v_t_2416 = (g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2415));
                {
                  V v_field_2418 = v_t_2416.f[1];
                  int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
                  if ((v_tag_2417 == ((int64_t)0ULL))) {
                    V v_x31_2419 = v_field_2418;
                    switch (heff_tag_of(v_x31_2419)) {
                    case TAG_MkPair: {
                      V v_x_2420 = heff_field(v_x31_2419, 0);
                      V v_j_2421 = heff_field(v_x31_2419, 1);
                      V v_ru_24x31_2419_24MkPair = heff_take_reuse_n(v_x31_2419, 3ULL, 2);
                      V v_t_2422 = heff_tag_at_n(v_ru_24x31_2419_24MkPair, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){v_x_248, v_x_2414}), v_x_2420});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2422, v_j_2421})}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2419)}});
                    }
                  } else {
                    heff_drop(v_x_248);
                    heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                    heff_drop(v_x_2414);
                    heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                    heff_drop(v_field_2418);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
              }
            } else {
              heff_drop(v_n_240);
              heff_drop(v_p_241);
              heff_drop(v_x_248);
              heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
              heff_drop(v_field_2412);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    V v_x3_244 = heff_tr(g_heff_2ebuild_2ecache_2emeltDef(heff_dup(v_p_241), v_p_242));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_245 = heff_field(v_x3_244, 0);
      heff_take_n(v_x3_244, 1ULL, 1);
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        HeffT2 v_t_248 = (g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x31_2411 = v_field_2410;
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              V v_ru_24x31_2411_24MkPair = heff_take_reuse_n(v_x31_2411, 3ULL, 2);
              V v_t_2414 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2411_24MkPair, TAG_Cons, 2, (V[]){v_x_246, v_x_2412}), v_j_2413});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2414}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2411)}});
            }
          } else {
            heff_drop(v_x_246);
            heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
            heff_drop(v_field_2410);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_244)}});
    }
  }
}