// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Expl 20488
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define LBL_looser 850054335
#define LBL_owner 307523277
#define LBL_tighter 1059982480
#define LBL_ty 10476
#define LBL_units 312791945
#define LBL_ver 326173
static uint32_t shape_owner__ver__units[] = {LBL_owner, LBL_ver, LBL_units};
static uint32_t shape_tighter__looser[] = {LBL_tighter, LBL_looser};
V g_heff_2ebuild_2ebackcache_2ecopyD(V, V);
V g_heff_2ebuild_2ebackcache_2ecopyD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ecopyD_clo;
HeffT4 g_heff_2ebuild_2ebackcache_2eemitD_24cpr(V, V);
HeffT4 g_heff_2ebuild_2ebackcache_2ejsD_24cpr(V, V);
V g_heff_2ebuild_2ebackcache_2eunitD(V, V);
V g_heff_2ebuild_2ebackcache_2eunitD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eunitD_clo;
V g_heff_2ebuild_2ecache_2emeltDef(V, V);
V g_heff_2ebuild_2ecache_2emeltDef_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltDef_clo;
V g_heff_2ebuild_2ecache_2emeltFixGroup(V, V);
V g_heff_2ebuild_2ecache_2emeltFixGroup_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltFixGroup_clo;
HeffT3 g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_clo;
V g_heff_2ebuild_2edecoder_2ecolonAt(V, V);
V g_heff_2ebuild_2edecoder_2ecolonAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ecolonAt_clo;
HeffT2 g_heff_2ebuild_2edecoder_2edecimalAt_24cpr(V, V, V);
V g_heff_2ebuild_2edecoder_2edigitsTo(V, V, V, V);
V g_heff_2ebuild_2edecoder_2edigitsTo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2edigitsTo_clo;
V g_heff_2ebuild_2edecoder_2efail(V, V);
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2efail_clo;
HeffT3 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24cpr(V, V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1391953550x1663492198_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1952093399x207461701_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1954476619x1073210498_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s2049614891x1595878686_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s481066606x2100141841_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2ewhole_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
V g_heff_2ebuild_2edecoder_2ewordEnd(V, V);
V g_heff_2ebuild_2edecoder_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ewordEnd_clo;
V g_heff_2ebuild_2eserial_2edk_get(void);
HeffT3 g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(V, V, V);

HeffT3 g_heff_2ebuild_2edecoder_2efail_24cpr(V v_s_240, V v_i_241) {
top: ;
  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
}
Clo g_heff_2ebuild_2edecoder_2efail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2efail_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2efail(V v_s_240, V v_i_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2ebuild_2edecoder_2efail_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245})});
    } else {
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2edecoder_2efail(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT3 g_heff_2ebuild_2edecoder_2ewhole_24cpr(V v_d_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = heff_tr(heff_call(v_d_240, 2, (V[]){heff_dup(v_s_241), v_i_242}));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop(v_s_241);
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      if (heff_intLe_c(heff_strLength(v_s_241), heff_dup(v_j_246))) {
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_245, v_j_246}});
      } else {
        heff_drop(v_x_245);
        heff_drop(v_j_246);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x31_244)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x3_243)}});
  }
}
Clo g_heff_2ebuild_2edecoder_2ewordEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ewordEnd_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ewordEnd(V v_s_240, V v_i_241) {
top: ;
  if ((heff_intLe_c_lent(heff_strLength_lent(v_s_240, 0), v_i_241, 1) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)32ULL)))) {
    return v_i_241;
  } else {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_i_241 = t_1;
    goto top;
  }
}
V g_heff_2ebuild_2edecoder_2ewordEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edecoder_2ewordEnd(a0, a[1]); heff_drop(a0); return r;
}

HeffT3 g_heff_2ebuild_2edecoder_2eword_24cpr(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c_lent(heff_strLength_lent(v_s_240, 0), v_i_241, 1)) {
    heff_drop(v_i_241);
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  } else {
    V v_t_242 = (g_heff_2ebuild_2edecoder_2ewordEnd(v_s_240, heff_dup(v_i_241)));
    V v_i_243 = (g_heff_2ebuild_2edecoder_2ewordEnd(v_s_240, heff_dup(v_i_241)));
    V v_t_244;
    if ((heff_intLt_c_lent(v_i_243, heff_strLength_lent(v_s_240, 0), 2) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_243, 0)) == ((int64_t)32ULL)))) {
      v_t_244 = heff_intAdd(v_i_243, MK_INT(1LL));
    } else {
      v_t_244 = v_i_243;
    }
    V v_f_245 = heff_strSlice_lent(v_s_240, v_i_241, v_t_242, 6);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_245, v_t_244}});
  }
}
Clo g_heff_2ebuild_2edecoder_2ecolonAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ecolonAt_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ecolonAt(V v_s_240, V v_i_241) {
top: ;
  if ((heff_intLe_c_lent(heff_strLength_lent(v_s_240, 0), v_i_241, 1) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)58ULL)))) {
    return v_i_241;
  } else {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_i_241 = t_1;
    goto top;
  }
}
V g_heff_2ebuild_2edecoder_2ecolonAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edecoder_2ecolonAt(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edecoder_2edigitsTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2edigitsTo_entry, 4, 0};

V g_heff_2ebuild_2edecoder_2edigitsTo(V v_s_240, V v_i_241, V v_j_242, V v_acc_243) {
top: ;
  if (heff_intLe_c_lent(v_j_242, v_i_241, 0)) {
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    return v_acc_243;
  } else {
    if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) < ((int64_t)48ULL)) || (((int64_t)57ULL) < heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0))))) {
      heff_drop(v_i_241);
      heff_drop(v_j_242);
      heff_drop(v_acc_243);
      return MK_INT(-1LL);
    } else {
      V v_t_244 = heff_intAdd(heff_intMul(v_acc_243, MK_INT(10LL)), heff_strByteAt_lent(v_s_240, v_i_241, 0));
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_j_242;
      V t_3 = heff_intSub(v_t_244, MK_INT(48LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2ebuild_2edecoder_2edigitsTo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edecoder_2edigitsTo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ebuild_2edecoder_2edecimalAt_24cpr(V v_s_240, V v_i_241, V v_j_242) {
top: ;
  if (heff_intLe_c_lent(v_j_242, v_i_241, 0)) {
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)45ULL))) {
      V v_n_243 = (g_heff_2ebuild_2edecoder_2edigitsTo(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_j_242, MK_INT(0LL)));
      if (heff_intLt_c_lent(v_n_243, MK_INT(0LL), 2)) {
        heff_drop(v_n_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V v_f_244 = heff_intSub(MK_INT(0LL), v_n_243);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_244}});
      }
    } else {
      V v_n_245 = (g_heff_2ebuild_2edecoder_2edigitsTo(v_s_240, v_i_241, v_j_242, MK_INT(0LL)));
      if (heff_intLt_c_lent(v_n_245, MK_INT(0LL), 2)) {
        heff_drop(v_n_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_n_245}});
      }
    }
  }
}

HeffT3 g_heff_2ebuild_2edecoder_2estr_24cpr(V v_s_240, V v_i_241) {
top: ;
  V v_x_242 = (g_heff_2ebuild_2edecoder_2ecolonAt(v_s_240, heff_dup(v_i_241)));
  V v_t_243 = heff_bool(heff_intLe_c_lent(heff_strLength_lent(v_s_240, 0), v_x_242, 1));
  heff_drop(v_x_242);
  if (((heff_dup(v_t_243) == NTAG(TAG_True)) || ({ V v_t_2417 = (g_heff_2ebuild_2edecoder_2ecolonAt(v_s_240, heff_dup(v_i_241))); int c_ = heff_intEq_c_lent(v_t_2417, v_i_241, 0); heff_drop(v_t_2417); c_; }))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    heff_drop(v_t_243);
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  } else {
    heff_drop(v_t_243);
    V v_t_244 = (g_heff_2ebuild_2edecoder_2ecolonAt(v_s_240, heff_dup(v_i_241)));
    V v_j_245 = heff_intAdd(v_t_244, MK_INT(1LL));
    V v_t_246 = (g_heff_2ebuild_2edecoder_2ecolonAt(v_s_240, heff_dup(v_i_241)));
    HeffT2 v_t_247 = (g_heff_2ebuild_2edecoder_2edecimalAt_24cpr(v_s_240, v_i_241, v_t_246));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_n_2410 = v_field_249;
        V v_s_2411 = v_s_240;
        V v_j_2412 = v_j_245;
        V v_n_2413 = v_n_2410;
        if ((heff_intLt_c_lent(v_n_2413, MK_INT(0LL), 2) || heff_intLt_c(heff_strLength_lent(v_s_2411, 0), heff_intAdd_lent(v_j_2412, v_n_2413, 0)))) {
          heff_drop(v_s_2411);
          heff_drop(v_j_2412);
          heff_drop(v_n_2413);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        } else {
          V v_i_2414 = heff_intAdd_lent(v_j_2412, v_n_2413, 0);
          V v_t_2415;
          if ((heff_intLt_c_lent(v_i_2414, heff_strLength_lent(v_s_2411, 0), 2) && (heff_unbox_word(heff_strByteAt_lent(v_s_2411, v_i_2414, 0)) == ((int64_t)32ULL)))) {
            v_t_2415 = heff_intAdd(v_i_2414, MK_INT(1LL));
          } else {
            v_t_2415 = v_i_2414;
          }
          V v_f_2416 = heff_strSlice(v_s_2411, heff_dup(v_j_2412), heff_intAdd(v_j_2412, v_n_2413));
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_2416, v_t_2415}});
        }
      } else {
        heff_drop(v_s_240);
        heff_drop(v_j_245);
        heff_drop(v_field_249);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    }
  }
}

HeffT3 g_heff_2ebuild_2edecoder_2eint_24cpr(V v_s_240, V v_i_241) {
top: ;
  V v_j_242 = (g_heff_2ebuild_2edecoder_2ewordEnd(v_s_240, heff_dup(v_i_241)));
  V v_t_243 = (g_heff_2ebuild_2edecoder_2ewordEnd(v_s_240, heff_dup(v_i_241)));
  HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2edecimalAt_24cpr(v_s_240, v_i_241, v_t_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_n_247 = v_field_246;
      V v_t_248;
      if ((heff_intLt_c_lent(v_j_242, heff_strLength_lent(v_s_240, 0), 2) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_242, 0)) == ((int64_t)32ULL)))) {
        v_t_248 = heff_intAdd(v_j_242, MK_INT(1LL));
      } else {
        v_t_248 = v_j_242;
      }
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_n_247, v_t_248}});
    } else {
      heff_drop(v_j_242);
      heff_drop(v_field_246);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
  }
}

HeffT3 g_heff_2ebuild_2edecoder_2etimes_24cpr(V v_d_240, V v_n_241, V v_p_242, V v_p_243) {
top: ;
  if (heff_intLe_c_lent(v_n_241, MK_INT(0LL), 2)) {
    heff_drop(v_d_240);
    heff_drop(v_n_241);
    heff_drop(v_p_242);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil), v_p_243}});
  } else {
    V v_x3_244 = heff_tr(heff_call(heff_dup(v_d_240), 2, (V[]){heff_dup(v_p_242), v_p_243}));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      heff_drop(v_d_240);
      heff_drop(v_n_241);
      heff_drop(v_p_242);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_245 = heff_field(v_x3_244, 0);
      heff_take_n(v_x3_244, 1ULL, 1);
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        HeffT3 v_t_248 = (g_heff_2ebuild_2edecoder_2etimes_24cpr(v_d_240, heff_intSub(v_n_241, MK_INT(1LL)), v_p_242, v_j_247));
        {
          V v_field_2410 = v_t_248.f[1];
          V v_field_2411 = v_t_248.f[2];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x_2412 = v_field_2410;
            V v_j_2413 = v_field_2411;
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_Cons, 2, (V[]){v_x_246, v_x_2412}), v_j_2413}});
          } else {
            heff_drop(v_x_246);
            heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
            heff_drop(v_field_2410);
            heff_drop(v_field_2411);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_x31_245)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x3_244)}});
    }
  }
}

HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil), v_p_242}});
  } else {
    HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_p_241), v_p_242));
    {
      V v_field_245 = v_t_243.f[1];
      V v_field_246 = v_t_243.f[2];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_245;
        V v_j_248 = v_field_246;
        HeffT3 v_t_249 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          V v_field_2412 = v_t_249.f[2];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x_2413 = v_field_2411;
            V v_j_2414 = v_field_2412;
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_x_2413}), v_j_2414}});
          } else {
            heff_drop(v_x_247);
            heff_drop(v_field_2411);
            heff_drop(v_field_2412);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_245);
        heff_drop(v_field_246);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str0, 1, "t");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str1, 1, "f");
Clo g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(V v_f_240, V v_s_241, V v_i_242) {
top: ;
  HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_245;
      V v_j_248 = v_field_246;
      if (heff_strEq_c_lent(v_x_247, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str0), 2)) {
        heff_drop(v_x_247);
        return heff_tail(v_f_240, 3, (V[]){NTAG(TAG_True), v_s_241, v_j_248});
      } else {
        if (heff_strEq_c(v_x_247, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str1))) {
          return heff_tail(v_f_240, 3, (V[]){NTAG(TAG_False), v_s_241, v_j_248});
        } else {
          heff_drop(v_f_240);
          heff_drop(v_s_241);
          heff_drop(v_j_248);
          return NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop(v_f_240);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(a[0], a[1], a[2]);
}

HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil), v_p_242}});
  } else {
    HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_p_241), v_p_242));
    {
      V v_field_245 = v_t_243.f[1];
      V v_field_246 = v_t_243.f[2];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_245;
        V v_j_248 = v_field_246;
        HeffT3 v_t_249 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_p_241), v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          V v_field_2412 = v_t_249.f[2];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x_2413 = v_field_2411;
            V v_j_2414 = v_field_2412;
            HeffT3 v_t_2415 = (g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2414));
            {
              V v_field_2417 = v_t_2415.f[1];
              V v_field_2418 = v_t_2415.f[2];
              int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
              if ((v_tag_2416 == ((int64_t)0ULL))) {
                V v_x_2419 = v_field_2417;
                V v_j_2420 = v_field_2418;
                V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_x_2413}), v_x_2419});
                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_t_2421, v_j_2420}});
              } else {
                heff_drop(v_x_247);
                heff_drop(v_x_2413);
                heff_drop(v_field_2417);
                heff_drop(v_field_2418);
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
            }
          } else {
            heff_drop(v_n_240);
            heff_drop(v_p_241);
            heff_drop(v_x_247);
            heff_drop(v_field_2411);
            heff_drop(v_field_2412);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_245);
        heff_drop(v_field_246);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    }
  }
}

HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1952093399x207461701_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil), v_p_242}});
  } else {
    V v_s_243 = heff_dup(v_p_241);
    V v_i_244 = v_p_242;
    V v_x3_245 = heff_tr(g_heff_2ebuild_2ebackcache_2eunitD(heff_dup(v_s_243), heff_dup(v_i_244)));
    V v_x3_2411;
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      heff_drop(v_s_243);
      heff_drop(v_i_244);
      v_x3_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x31_246 = heff_field(v_x3_245, 0);
      V v_ru_24x3_245_24Just = heff_take_reuse_n(v_x3_245, 1ULL, 1);
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        V v_t_249;
        if ((heff_intLt_c_lent(v_i_244, v_j_248, 0) && (heff_unbox_word(heff_strByteAt_lent(v_s_243, heff_intSub_lent(v_j_248, MK_INT(1LL), 2), 2)) == ((int64_t)32ULL)))) {
          v_t_249 = heff_intSub_lent(v_j_248, MK_INT(1LL), 2);
        } else {
          v_t_249 = heff_dup(v_j_248);
        }
        V v_t_2410 = heff_tag_re_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_x_247, heff_strSlice(v_s_243, v_i_244, v_t_249)});
        v_x3_2411 = heff_tag_at_n(v_ru_24x3_245_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_j_248})});
        break;
      }
      default: heff_nomatch(v_x31_246);
      }
      break;
    }
    default: heff_nomatch(v_x3_245);
    }
    switch (heff_tag_of(v_x3_2411)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_2412 = heff_field(v_x3_2411, 0);
      heff_take_n(v_x3_2411, 1ULL, 1);
      switch (heff_tag_of(v_x31_2412)) {
      case TAG_MkPair: {
        V v_x_2413 = heff_field(v_x31_2412, 0);
        V v_j_2414 = heff_field(v_x31_2412, 1);
        V v_ru_24x31_2412_24MkPair = heff_take_reuse_n(v_x31_2412, 3ULL, 2);
        HeffT3 v_t_2415 = (g_heff_2ebuild_2edecoder_2etimes_24s1952093399x207461701_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2414));
        {
          V v_field_2417 = v_t_2415.f[1];
          V v_field_2418 = v_t_2415.f[2];
          int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            V v_x_2419 = v_field_2417;
            V v_j_2420 = v_field_2418;
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2412_24MkPair, TAG_Cons, 2, (V[]){v_x_2413, v_x_2419}), v_j_2420}});
          } else {
            heff_drop(v_x_2413);
            heff_drop_cell(v_ru_24x31_2412_24MkPair, 2);
            heff_drop(v_field_2417);
            heff_drop(v_field_2418);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_x31_2412)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x3_2411)}});
    }
  }
}

HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s2049614891x1595878686_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil), v_p_242}});
  } else {
    V v_s_243 = heff_dup(v_p_241);
    V v_i_244 = v_p_242;
    V v_s_245 = heff_dup(v_s_243);
    V v_i_246 = heff_dup(v_i_244);
    HeffT3 v_t_247 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_245), v_i_246));
    {
      V v_field_249 = v_t_247.f[1];
      V v_field_2410 = v_t_247.f[2];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      V v_x3_2432;
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_x_2411 = v_field_249;
        V v_j_2412 = v_field_2410;
        HeffT3 v_t_2413 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_245), v_j_2412));
        {
          V v_field_2415 = v_t_2413.f[1];
          V v_field_2416 = v_t_2413.f[2];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_x_2417 = v_field_2415;
            V v_j_2418 = v_field_2416;
            HeffT3 v_t_2419 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_245, v_j_2418));
            {
              V v_field_2421 = v_t_2419.f[1];
              V v_field_2422 = v_t_2419.f[2];
              int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
              if ((v_tag_2420 == ((int64_t)0ULL))) {
                V v_x_2423 = v_field_2421;
                V v_j_2424 = v_field_2422;
                HeffT3 v_t_2425 = (g_heff_2ebuild_2edecoder_2etimes_24s1952093399x207461701_24cpr(v_x_2423, v_s_245, v_j_2424));
                {
                  V v_field_2427 = v_t_2425.f[1];
                  V v_field_2428 = v_t_2425.f[2];
                  int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
                  if ((v_tag_2426 == ((int64_t)0ULL))) {
                    V v_x_2429 = v_field_2427;
                    V v_j_2430 = v_field_2428;
                    V v_t_2431 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_rec_n(3, shape_owner__ver__units, (V[]){v_x_2411, v_x_2417, v_x_2429}), v_j_2430});
                    v_x3_2432 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2431});
                  } else {
                    heff_drop(v_x_2411);
                    heff_drop(v_x_2417);
                    heff_drop(v_field_2427);
                    heff_drop(v_field_2428);
                    v_x3_2432 = NTAG(TAG_Nothing);
                  }
                }
              } else {
                heff_drop(v_s_245);
                heff_drop(v_x_2411);
                heff_drop(v_x_2417);
                heff_drop(v_field_2421);
                heff_drop(v_field_2422);
                v_x3_2432 = NTAG(TAG_Nothing);
              }
            }
          } else {
            heff_drop(v_s_245);
            heff_drop(v_x_2411);
            heff_drop(v_field_2415);
            heff_drop(v_field_2416);
            v_x3_2432 = NTAG(TAG_Nothing);
          }
        }
      } else {
        heff_drop(v_s_245);
        heff_drop(v_field_249);
        heff_drop(v_field_2410);
        v_x3_2432 = NTAG(TAG_Nothing);
      }
      V v_x3_2438;
      switch (heff_tag_of(v_x3_2432)) {
      case TAG_Nothing: {
        heff_drop(v_s_243);
        heff_drop(v_i_244);
        v_x3_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_2433 = heff_field(v_x3_2432, 0);
        V v_ru_24x3_2432_24Just = heff_take_reuse_n(v_x3_2432, 1ULL, 1);
        switch (heff_tag_of(v_x31_2433)) {
        case TAG_MkPair: {
          V v_x_2434 = heff_field(v_x31_2433, 0);
          V v_j_2435 = heff_field(v_x31_2433, 1);
          V v_ru_24x31_2433_24MkPair = heff_take_reuse_n(v_x31_2433, 3ULL, 2);
          V v_t_2436;
          if ((heff_intLt_c_lent(v_i_244, v_j_2435, 0) && (heff_unbox_word(heff_strByteAt_lent(v_s_243, heff_intSub_lent(v_j_2435, MK_INT(1LL), 2), 2)) == ((int64_t)32ULL)))) {
            v_t_2436 = heff_intSub_lent(v_j_2435, MK_INT(1LL), 2);
          } else {
            v_t_2436 = heff_dup(v_j_2435);
          }
          V v_t_2437 = heff_tag_re_n(v_ru_24x31_2433_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_x_2434, heff_strSlice(v_s_243, v_i_244, v_t_2436)});
          v_x3_2438 = heff_tag_at_n(v_ru_24x3_2432_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2437, v_j_2435})});
          break;
        }
        default: heff_nomatch(v_x31_2433);
        }
        break;
      }
      default: heff_nomatch(v_x3_2432);
      }
      switch (heff_tag_of(v_x3_2438)) {
      case TAG_Nothing: {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_x31_2439 = heff_field(v_x3_2438, 0);
        heff_take_n(v_x3_2438, 1ULL, 1);
        switch (heff_tag_of(v_x31_2439)) {
        case TAG_MkPair: {
          V v_x_2440 = heff_field(v_x31_2439, 0);
          V v_j_2441 = heff_field(v_x31_2439, 1);
          V v_ru_24x31_2439_24MkPair = heff_take_reuse_n(v_x31_2439, 3ULL, 2);
          HeffT3 v_t_2442 = (g_heff_2ebuild_2edecoder_2etimes_24s2049614891x1595878686_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2441));
          {
            V v_field_2444 = v_t_2442.f[1];
            V v_field_2445 = v_t_2442.f[2];
            int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
            if ((v_tag_2443 == ((int64_t)0ULL))) {
              V v_x_2446 = v_field_2444;
              V v_j_2447 = v_field_2445;
              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2439_24MkPair, TAG_Cons, 2, (V[]){v_x_2440, v_x_2446}), v_j_2447}});
            } else {
              heff_drop(v_x_2440);
              heff_drop_cell(v_ru_24x31_2439_24MkPair, 2);
              heff_drop(v_field_2444);
              heff_drop(v_field_2445);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT3){{heff_nomatch(v_x31_2439)}});
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_x3_2438)}});
      }
    }
  }
}

HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s481066606x2100141841_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil), v_p_242}});
  } else {
    V v_s_243 = heff_dup(v_p_241);
    V v_i_244 = v_p_242;
    V v_x3_245 = heff_tr(g_heff_2ebuild_2ebackcache_2ecopyD(heff_dup(v_s_243), heff_dup(v_i_244)));
    V v_x3_2411;
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      heff_drop(v_s_243);
      heff_drop(v_i_244);
      v_x3_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x31_246 = heff_field(v_x3_245, 0);
      V v_ru_24x3_245_24Just = heff_take_reuse_n(v_x3_245, 1ULL, 1);
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        V v_t_249;
        if ((heff_intLt_c_lent(v_i_244, v_j_248, 0) && (heff_unbox_word(heff_strByteAt_lent(v_s_243, heff_intSub_lent(v_j_248, MK_INT(1LL), 2), 2)) == ((int64_t)32ULL)))) {
          v_t_249 = heff_intSub_lent(v_j_248, MK_INT(1LL), 2);
        } else {
          v_t_249 = heff_dup(v_j_248);
        }
        V v_t_2410 = heff_tag_re_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_x_247, heff_strSlice(v_s_243, v_i_244, v_t_249)});
        v_x3_2411 = heff_tag_at_n(v_ru_24x3_245_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_j_248})});
        break;
      }
      default: heff_nomatch(v_x31_246);
      }
      break;
    }
    default: heff_nomatch(v_x3_245);
    }
    switch (heff_tag_of(v_x3_2411)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_2412 = heff_field(v_x3_2411, 0);
      heff_take_n(v_x3_2411, 1ULL, 1);
      switch (heff_tag_of(v_x31_2412)) {
      case TAG_MkPair: {
        V v_x_2413 = heff_field(v_x31_2412, 0);
        V v_j_2414 = heff_field(v_x31_2412, 1);
        V v_ru_24x31_2412_24MkPair = heff_take_reuse_n(v_x31_2412, 3ULL, 2);
        HeffT3 v_t_2415 = (g_heff_2ebuild_2edecoder_2etimes_24s481066606x2100141841_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2414));
        {
          V v_field_2417 = v_t_2415.f[1];
          V v_field_2418 = v_t_2415.f[2];
          int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            V v_x_2419 = v_field_2417;
            V v_j_2420 = v_field_2418;
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2412_24MkPair, TAG_Cons, 2, (V[]){v_x_2413, v_x_2419}), v_j_2420}});
          } else {
            heff_drop(v_x_2413);
            heff_drop_cell(v_ru_24x31_2412_24MkPair, 2);
            heff_drop(v_field_2417);
            heff_drop(v_field_2418);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_x31_2412)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x3_2411)}});
    }
  }
}

HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1954476619x1073210498_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil), v_p_242}});
  } else {
    V v_s_243 = heff_dup(v_p_241);
    V v_i_244 = v_p_242;
    HeffT4 v_t_245 = (g_heff_2ebuild_2ebackcache_2eemitD_24cpr(heff_dup(v_s_243), heff_dup(v_i_244)));
    {
      V v_field_247 = v_t_245.f[1];
      V v_field_248 = v_t_245.f[2];
      V v_field_249 = v_t_245.f[3];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_x3_2414;
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){v_field_247, v_field_248});
        V v_j_2411 = v_field_249;
        V v_t_2412;
        if ((heff_intLt_c_lent(v_i_244, v_j_2411, 0) && (heff_unbox_word(heff_strByteAt_lent(v_s_243, heff_intSub_lent(v_j_2411, MK_INT(1LL), 2), 2)) == ((int64_t)32ULL)))) {
          v_t_2412 = heff_intSub_lent(v_j_2411, MK_INT(1LL), 2);
        } else {
          v_t_2412 = heff_dup(v_j_2411);
        }
        V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2410, heff_strSlice(v_s_243, v_i_244, v_t_2412)});
        v_x3_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_j_2411})});
      } else {
        heff_drop(v_s_243);
        heff_drop(v_i_244);
        heff_drop(v_field_247);
        heff_drop(v_field_248);
        heff_drop(v_field_249);
        v_x3_2414 = NTAG(TAG_Nothing);
      }
      switch (heff_tag_of(v_x3_2414)) {
      case TAG_Nothing: {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_x31_2415 = heff_field(v_x3_2414, 0);
        heff_take_n(v_x3_2414, 1ULL, 1);
        switch (heff_tag_of(v_x31_2415)) {
        case TAG_MkPair: {
          V v_x_2416 = heff_field(v_x31_2415, 0);
          V v_j_2417 = heff_field(v_x31_2415, 1);
          V v_ru_24x31_2415_24MkPair = heff_take_reuse_n(v_x31_2415, 3ULL, 2);
          HeffT3 v_t_2418 = (g_heff_2ebuild_2edecoder_2etimes_24s1954476619x1073210498_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2417));
          {
            V v_field_2420 = v_t_2418.f[1];
            V v_field_2421 = v_t_2418.f[2];
            int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
            if ((v_tag_2419 == ((int64_t)0ULL))) {
              V v_x_2422 = v_field_2420;
              V v_j_2423 = v_field_2421;
              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2415_24MkPair, TAG_Cons, 2, (V[]){v_x_2416, v_x_2422}), v_j_2423}});
            } else {
              heff_drop(v_x_2416);
              heff_drop_cell(v_ru_24x31_2415_24MkPair, 2);
              heff_drop(v_field_2420);
              heff_drop(v_field_2421);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT3){{heff_nomatch(v_x31_2415)}});
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_x3_2414)}});
      }
    }
  }
}

HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1391953550x1663492198_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil), v_p_242}});
  } else {
    V v_s_243 = heff_dup(v_p_241);
    V v_i_244 = v_p_242;
    HeffT4 v_t_245 = (g_heff_2ebuild_2ebackcache_2ejsD_24cpr(heff_dup(v_s_243), heff_dup(v_i_244)));
    {
      V v_field_247 = v_t_245.f[1];
      V v_field_248 = v_t_245.f[2];
      V v_field_249 = v_t_245.f[3];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_x3_2414;
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){v_field_247, v_field_248});
        V v_j_2411 = v_field_249;
        V v_t_2412;
        if ((heff_intLt_c_lent(v_i_244, v_j_2411, 0) && (heff_unbox_word(heff_strByteAt_lent(v_s_243, heff_intSub_lent(v_j_2411, MK_INT(1LL), 2), 2)) == ((int64_t)32ULL)))) {
          v_t_2412 = heff_intSub_lent(v_j_2411, MK_INT(1LL), 2);
        } else {
          v_t_2412 = heff_dup(v_j_2411);
        }
        V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2410, heff_strSlice(v_s_243, v_i_244, v_t_2412)});
        v_x3_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_j_2411})});
      } else {
        heff_drop(v_s_243);
        heff_drop(v_i_244);
        heff_drop(v_field_247);
        heff_drop(v_field_248);
        heff_drop(v_field_249);
        v_x3_2414 = NTAG(TAG_Nothing);
      }
      switch (heff_tag_of(v_x3_2414)) {
      case TAG_Nothing: {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_x31_2415 = heff_field(v_x3_2414, 0);
        heff_take_n(v_x3_2414, 1ULL, 1);
        switch (heff_tag_of(v_x31_2415)) {
        case TAG_MkPair: {
          V v_x_2416 = heff_field(v_x31_2415, 0);
          V v_j_2417 = heff_field(v_x31_2415, 1);
          V v_ru_24x31_2415_24MkPair = heff_take_reuse_n(v_x31_2415, 3ULL, 2);
          HeffT3 v_t_2418 = (g_heff_2ebuild_2edecoder_2etimes_24s1391953550x1663492198_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2417));
          {
            V v_field_2420 = v_t_2418.f[1];
            V v_field_2421 = v_t_2418.f[2];
            int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
            if ((v_tag_2419 == ((int64_t)0ULL))) {
              V v_x_2422 = v_field_2420;
              V v_j_2423 = v_field_2421;
              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2415_24MkPair, TAG_Cons, 2, (V[]){v_x_2416, v_x_2422}), v_j_2423}});
            } else {
              heff_drop(v_x_2416);
              heff_drop_cell(v_ru_24x31_2415_24MkPair, 2);
              heff_drop(v_field_2420);
              heff_drop(v_field_2421);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT3){{heff_nomatch(v_x31_2415)}});
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_x3_2414)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str1, 1, "1");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str2, 1, "2");

HeffT3 g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      V v_j_247 = v_field_245;
      if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str0), 2)) {
        heff_drop(v_x_246);
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Expl), v_j_247}});
      } else {
        if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str1), 2)) {
          heff_drop(v_x_246);
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Impl), v_j_247}});
        } else {
          if (heff_strEq_c(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str2))) {
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Inst), v_j_247}});
          } else {
            heff_drop(v_j_247);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      }
    } else {
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str1, 1, "1");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str2, 1, "2");

HeffT3 g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      V v_j_247 = v_field_245;
      if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str0), 2)) {
        heff_drop(v_x_246);
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Small), v_j_247}});
      } else {
        if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str1), 2)) {
          heff_drop(v_x_246);
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Large), v_j_247}});
        } else {
          if (heff_strEq_c(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str2))) {
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_TopL), v_j_247}});
          } else {
            heff_drop(v_j_247);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      }
    } else {
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr_str1, 1, "1");

HeffT3 g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      V v_j_247 = v_field_245;
      if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr_str0), 2)) {
        heff_drop(v_x_246);
        V v_t_248 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_t_248, v_j_247}});
      } else {
        if (heff_strEq_c(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr_str1))) {
          V v_t_249 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_LargeU)});
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_t_249, v_j_247}});
        } else {
          heff_drop(v_j_247);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
      }
    } else {
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
  }
}

HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil), v_p_242}});
  } else {
    V v_x3_243 = heff_tr(g_heff_2ebuild_2ecache_2emeltFixGroup(heff_dup(v_p_241), v_p_242));
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_244 = heff_field(v_x3_243, 0);
      heff_take_n(v_x3_243, 1ULL, 1);
      switch (heff_tag_of(v_x31_244)) {
      case TAG_MkPair: {
        V v_x_245 = heff_field(v_x31_244, 0);
        V v_j_246 = heff_field(v_x31_244, 1);
        V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
        HeffT3 v_t_247 = (g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_246));
        {
          V v_field_249 = v_t_247.f[1];
          V v_field_2410 = v_t_247.f[2];
          int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
          if ((v_tag_248 == ((int64_t)0ULL))) {
            V v_x_2411 = v_field_249;
            V v_j_2412 = v_field_2410;
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_Cons, 2, (V[]){v_x_245, v_x_2411}), v_j_2412}});
          } else {
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
            heff_drop(v_field_249);
            heff_drop(v_field_2410);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_x31_244)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x3_243)}});
    }
  }
}

HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil), v_p_242}});
  } else {
    HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_p_241), v_p_242));
    {
      V v_field_245 = v_t_243.f[1];
      V v_field_246 = v_t_243.f[2];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_245;
        V v_j_248 = v_field_246;
        HeffT3 v_t_249 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_p_241), v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          V v_field_2412 = v_t_249.f[2];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x_2413 = v_field_2411;
            V v_j_2414 = v_field_2412;
            HeffT3 v_t_2415 = (g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2414));
            {
              V v_field_2417 = v_t_2415.f[1];
              V v_field_2418 = v_t_2415.f[2];
              int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
              if ((v_tag_2416 == ((int64_t)0ULL))) {
                V v_x_2419 = v_field_2417;
                V v_j_2420 = v_field_2418;
                V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_tighter__looser, (V[]){v_x_247, v_x_2413}), v_x_2419});
                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_t_2421, v_j_2420}});
              } else {
                heff_drop(v_x_247);
                heff_drop(v_x_2413);
                heff_drop(v_field_2417);
                heff_drop(v_field_2418);
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
            }
          } else {
            heff_drop(v_n_240);
            heff_drop(v_p_241);
            heff_drop(v_x_247);
            heff_drop(v_field_2411);
            heff_drop(v_field_2412);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_245);
        heff_drop(v_field_246);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    }
  }
}

HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil), v_p_242}});
  } else {
    HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_p_241), v_p_242));
    {
      V v_field_245 = v_t_243.f[1];
      V v_field_246 = v_t_243.f[2];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_a_247 = v_field_245;
        V v_a_248 = v_field_246;
        V v_s_249 = heff_dup(v_p_241);
        V v_i_2410 = v_a_248;
        HeffT3 v_t_2411 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_249, v_i_2410));
        {
          V v_field_2413 = v_t_2411.f[1];
          V v_field_2414 = v_t_2411.f[2];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          V v_a_2436;
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_x_2415 = v_field_2413;
            V v_j_2416 = v_field_2414;
            HeffT3 v_t_2417 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2415, heff_dup(v_s_249), v_j_2416));
            {
              V v_field_2419 = v_t_2417.f[1];
              V v_field_2420 = v_t_2417.f[2];
              int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
              if ((v_tag_2418 == ((int64_t)0ULL))) {
                V v_x_2421 = v_field_2419;
                V v_j_2422 = v_field_2420;
                HeffT3 v_t_2423 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_249, v_j_2422));
                {
                  V v_field_2425 = v_t_2423.f[1];
                  V v_field_2426 = v_t_2423.f[2];
                  int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                  if ((v_tag_2424 == ((int64_t)0ULL))) {
                    V v_x_2427 = v_field_2425;
                    V v_j_2428 = v_field_2426;
                    HeffT3 v_t_2429 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_2427, v_s_249, v_j_2428));
                    {
                      V v_field_2431 = v_t_2429.f[1];
                      V v_field_2432 = v_t_2429.f[2];
                      int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
                      if ((v_tag_2430 == ((int64_t)0ULL))) {
                        V v_x_2433 = v_field_2431;
                        V v_j_2434 = v_field_2432;
                        V v_t_2435 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2421), v_x_2433});
                        v_a_2436 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2435, v_j_2434})});
                      } else {
                        heff_drop(v_x_2421);
                        heff_drop(v_field_2431);
                        heff_drop(v_field_2432);
                        v_a_2436 = NTAG(TAG_Nothing);
                      }
                    }
                  } else {
                    heff_drop(v_s_249);
                    heff_drop(v_x_2421);
                    heff_drop(v_field_2425);
                    heff_drop(v_field_2426);
                    v_a_2436 = NTAG(TAG_Nothing);
                  }
                }
              } else {
                heff_drop(v_s_249);
                heff_drop(v_field_2419);
                heff_drop(v_field_2420);
                v_a_2436 = NTAG(TAG_Nothing);
              }
            }
          } else {
            heff_drop(v_s_249);
            heff_drop(v_field_2413);
            heff_drop(v_field_2414);
            v_a_2436 = NTAG(TAG_Nothing);
          }
          switch (heff_tag_of(v_a_2436)) {
          case TAG_Nothing: {
            heff_drop(v_n_240);
            heff_drop(v_p_241);
            heff_drop(v_a_247);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_a_2437 = heff_field(v_a_2436, 0);
            heff_take_n(v_a_2436, 1ULL, 1);
            switch (heff_tag_of(v_a_2437)) {
            case TAG_MkPair: {
              V v_a_2438 = heff_field(v_a_2437, 0);
              V v_a_2439 = heff_field(v_a_2437, 1);
              V v_ru_24a_2437_24MkPair = heff_take_reuse_n(v_a_2437, 3ULL, 2);
              HeffT3 v_t_2440 = (g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_a_2439));
              {
                V v_field_2442 = v_t_2440.f[1];
                V v_field_2443 = v_t_2440.f[2];
                int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
                if ((v_tag_2441 == ((int64_t)0ULL))) {
                  V v_x_2444 = v_field_2442;
                  V v_j_2445 = v_field_2443;
                  V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24a_2437_24MkPair, TAG_MkPair, 2, (V[]){v_a_247, v_a_2438}), v_x_2444});
                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_t_2446, v_j_2445}});
                } else {
                  heff_drop(v_a_247);
                  heff_drop(v_a_2438);
                  heff_drop_cell(v_ru_24a_2437_24MkPair, 2);
                  heff_drop(v_field_2442);
                  heff_drop(v_field_2443);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT3){{heff_nomatch(v_a_2437)}});
            }
          }
          default: return ((HeffT3){{heff_nomatch(v_a_2436)}});
          }
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_245);
        heff_drop(v_field_246);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    }
  }
}

HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil), v_p_242}});
  } else {
    HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_p_241), v_p_242));
    {
      V v_field_245 = v_t_243.f[1];
      V v_field_246 = v_t_243.f[2];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_a_247 = v_field_245;
        V v_a_248 = v_field_246;
        V v_s_249 = heff_dup(v_p_241);
        V v_i_2410 = v_a_248;
        HeffT3 v_t_2411 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_249, v_i_2410));
        {
          V v_field_2413 = v_t_2411.f[1];
          V v_field_2414 = v_t_2411.f[2];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          V v_a_2424;
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_x_2415 = v_field_2413;
            V v_j_2416 = v_field_2414;
            HeffT3 v_t_2417 = (g_heff_2ebuild_2edecoder_2etimes_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1)), v_x_2415, v_s_249, v_j_2416));
            {
              V v_field_2419 = v_t_2417.f[1];
              V v_field_2420 = v_t_2417.f[2];
              int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
              if ((v_tag_2418 == ((int64_t)0ULL))) {
                V v_x_2421 = v_field_2419;
                V v_j_2422 = v_field_2420;
                V v_t_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2421), v_j_2422});
                v_a_2424 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2423});
              } else {
                heff_drop(v_field_2419);
                heff_drop(v_field_2420);
                v_a_2424 = NTAG(TAG_Nothing);
              }
            }
          } else {
            heff_drop(v_s_249);
            heff_drop(v_field_2413);
            heff_drop(v_field_2414);
            v_a_2424 = NTAG(TAG_Nothing);
          }
          switch (heff_tag_of(v_a_2424)) {
          case TAG_Nothing: {
            heff_drop(v_n_240);
            heff_drop(v_p_241);
            heff_drop(v_a_247);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_a_2425 = heff_field(v_a_2424, 0);
            heff_take_n(v_a_2424, 1ULL, 1);
            switch (heff_tag_of(v_a_2425)) {
            case TAG_MkPair: {
              V v_a_2426 = heff_field(v_a_2425, 0);
              V v_a_2427 = heff_field(v_a_2425, 1);
              V v_ru_24a_2425_24MkPair = heff_take_reuse_n(v_a_2425, 3ULL, 2);
              HeffT3 v_t_2428 = (g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_a_2427));
              {
                V v_field_2430 = v_t_2428.f[1];
                V v_field_2431 = v_t_2428.f[2];
                int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
                if ((v_tag_2429 == ((int64_t)0ULL))) {
                  V v_x_2432 = v_field_2430;
                  V v_j_2433 = v_field_2431;
                  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24a_2425_24MkPair, TAG_MkPair, 2, (V[]){v_a_247, v_a_2426}), v_x_2432});
                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_t_2434, v_j_2433}});
                } else {
                  heff_drop(v_a_247);
                  heff_drop(v_a_2426);
                  heff_drop_cell(v_ru_24a_2425_24MkPair, 2);
                  heff_drop(v_field_2430);
                  heff_drop(v_field_2431);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT3){{heff_nomatch(v_a_2425)}});
            }
          }
          default: return ((HeffT3){{heff_nomatch(v_a_2424)}});
          }
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_245);
        heff_drop(v_field_246);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    }
  }
}

HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil), v_p_242}});
  } else {
    HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_p_241), v_p_242));
    {
      V v_field_245 = v_t_243.f[1];
      V v_field_246 = v_t_243.f[2];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_245;
        V v_j_248 = v_field_246;
        HeffT3 v_t_249 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_p_241), v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          V v_field_2412 = v_t_249.f[2];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x_2413 = v_field_2411;
            V v_j_2414 = v_field_2412;
            HeffT3 v_t_2415 = (g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2414));
            {
              V v_field_2417 = v_t_2415.f[1];
              V v_field_2418 = v_t_2415.f[2];
              int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
              if ((v_tag_2416 == ((int64_t)0ULL))) {
                V v_x_2419 = v_field_2417;
                V v_j_2420 = v_field_2418;
                V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_x_2413}), v_x_2419});
                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_t_2421, v_j_2420}});
              } else {
                heff_drop(v_x_247);
                heff_drop(v_x_2413);
                heff_drop(v_field_2417);
                heff_drop(v_field_2418);
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
            }
          } else {
            heff_drop(v_n_240);
            heff_drop(v_p_241);
            heff_drop(v_x_247);
            heff_drop(v_field_2411);
            heff_drop(v_field_2412);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_245);
        heff_drop(v_field_246);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    }
  }
}

HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil), v_p_242}});
  } else {
    V v_x3_243 = heff_tr(g_heff_2ebuild_2ecache_2emeltDef(heff_dup(v_p_241), v_p_242));
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_244 = heff_field(v_x3_243, 0);
      heff_take_n(v_x3_243, 1ULL, 1);
      switch (heff_tag_of(v_x31_244)) {
      case TAG_MkPair: {
        V v_x_245 = heff_field(v_x31_244, 0);
        V v_j_246 = heff_field(v_x31_244, 1);
        V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
        HeffT3 v_t_247 = (g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_246));
        {
          V v_field_249 = v_t_247.f[1];
          V v_field_2410 = v_t_247.f[2];
          int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
          if ((v_tag_248 == ((int64_t)0ULL))) {
            V v_x_2411 = v_field_249;
            V v_j_2412 = v_field_2410;
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_Cons, 2, (V[]){v_x_245, v_x_2411}), v_j_2412}});
          } else {
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
            heff_drop(v_field_249);
            heff_drop(v_field_2410);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_x31_244)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x3_243)}});
    }
  }
}