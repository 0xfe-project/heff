// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Expl 20488
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define LBL_looser 850054335
#define LBL_tighter 1059982480
static uint32_t shape_tighter__looser[] = {LBL_tighter, LBL_looser};
V g_heff_2ebuild_2ebackcache_2ecopyD(V, V);
V g_heff_2ebuild_2ebackcache_2ecopyD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ecopyD_clo;
V g_heff_2ebuild_2ebackcache_2eemitD(V, V);
V g_heff_2ebuild_2ebackcache_2eemitD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eemitD_clo;
V g_heff_2ebuild_2ebackcache_2egroupD(V, V);
V g_heff_2ebuild_2ebackcache_2egroupD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2egroupD_clo;
V g_heff_2ebuild_2ebackcache_2ejsD(V, V);
V g_heff_2ebuild_2ebackcache_2ejsD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ejsD_clo;
HeffT2 g_heff_2ebuild_2ebackcache_2erawGot_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2eunitD(V, V);
V g_heff_2ebuild_2ebackcache_2eunitD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eunitD_clo;
V g_heff_2ebuild_2ecache_2emeltDef(V, V);
V g_heff_2ebuild_2ecache_2emeltDef_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltDef_clo;
V g_heff_2ebuild_2ecache_2emeltFixGroup(V, V);
V g_heff_2ebuild_2ecache_2emeltFixGroup_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltFixGroup_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_clo;
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s2082925062x256752403_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_clo;
V g_heff_2ebuild_2edecoder_2ecolonAt(V, V);
V g_heff_2ebuild_2edecoder_2ecolonAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ecolonAt_clo;
HeffT2 g_heff_2ebuild_2edecoder_2edecimalAt_24cpr(V, V, V);
V g_heff_2ebuild_2edecoder_2edigitsTo(V, V, V, V);
V g_heff_2ebuild_2edecoder_2edigitsTo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2edigitsTo_clo;
V g_heff_2ebuild_2edecoder_2efail(V, V);
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2efail_clo;
HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estrAt_24cpr(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes(V, V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_clo;
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1444395529x927023430(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1444395529x927023430_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1444395529x927023430_clo;
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1444395529x927023430_24cpr(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_clo;
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_clo;
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_24cpr(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_clo;
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_24cpr(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1861622792x1526156306(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1861622792x1526156306_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1861622792x1526156306_clo;
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1861622792x1526156306_24cpr(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_clo;
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_24cpr(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_clo;
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_24cpr(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_clo;
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_24cpr(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s364931774x210987922(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s364931774x210987922_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s364931774x210987922_clo;
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s364931774x210987922_24cpr(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s372484702x1286645721(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s372484702x1286645721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s372484702x1286645721_clo;
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s372484702x1286645721_24cpr(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s700921301x1216293995(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s700921301x1216293995_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s700921301x1216293995_clo;
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s700921301x1216293995_24cpr(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_clo;
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ewhole_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
V g_heff_2ebuild_2edecoder_2ewordEnd(V, V);
V g_heff_2ebuild_2edecoder_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ewordEnd_clo;
HeffT2 g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeFields_24s1394680213x1941859555_24cpr(V, V);

HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V v_s_240, V v_i_241) {
top: ;
  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
}
Clo g_heff_2ebuild_2edecoder_2efail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2efail_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2efail(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2efail_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2edecoder_2efail(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ebuild_2edecoder_2ewhole_24cpr(V v_d_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = heff_tr(heff_call(v_d_240, 2, (V[]){heff_dup(v_s_241), v_i_242}));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop(v_s_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      if (heff_intLe_c(heff_strLength(v_s_241), heff_dup(v_j_246))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_MkPair, 2, (V[]){v_x_245, v_j_246})}});
      } else {
        heff_drop(v_x_245);
        heff_drop(v_j_246);
        heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_243)}});
  }
}
Clo g_heff_2ebuild_2edecoder_2ewordEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ewordEnd_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ewordEnd(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    return v_i_241;
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)32ULL))) {
      return v_i_241;
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2ebuild_2edecoder_2ewordEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edecoder_2ewordEnd(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    V v_t_243 = (g_heff_2ebuild_2edecoder_2ewordEnd(v_s_240, heff_dup(v_i_241)));
    V v_i_244 = (g_heff_2ebuild_2edecoder_2ewordEnd(v_s_240, heff_dup(v_i_241)));
    V v_t_247;
    if (heff_intLt_c(heff_dup(v_i_244), heff_strLength_lent(v_s_240, 0))) {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_244, 0)) == ((int64_t)32ULL))) {
        v_t_247 = heff_intAdd(v_i_244, MK_INT(1LL));
      } else {
        v_t_247 = v_i_244;
      }
    } else {
      v_t_247 = v_i_244;
    }
    V v_f_248 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strSlice_lent(v_s_240, v_i_241, v_t_243, 6), v_t_247});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
  }
}
Clo g_heff_2ebuild_2edecoder_2ecolonAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ecolonAt_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ecolonAt(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    return v_i_241;
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)58ULL))) {
      return v_i_241;
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2ebuild_2edecoder_2ecolonAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edecoder_2ecolonAt(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edecoder_2edigitsTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2edigitsTo_entry, 4, 0};

V g_heff_2ebuild_2edecoder_2edigitsTo(V v_s_240, V v_i_241, V v_j_242, V v_acc_243) {
top: ;
  if (heff_intLe_c_lent(v_j_242, v_i_241, 0)) {
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    return v_acc_243;
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) < ((int64_t)48ULL))) {
      heff_drop(v_i_241);
      heff_drop(v_j_242);
      heff_drop(v_acc_243);
      return MK_INT(-1LL);
    } else {
      if ((((int64_t)57ULL) < heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)))) {
        heff_drop(v_i_241);
        heff_drop(v_j_242);
        heff_drop(v_acc_243);
        return MK_INT(-1LL);
      } else {
        V v_t_247 = heff_intAdd(heff_intMul(v_acc_243, MK_INT(10LL)), heff_strByteAt_lent(v_s_240, v_i_241, 0));
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_j_242;
        V t_3 = heff_intSub(v_t_247, MK_INT(48LL));
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_j_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      }
    }
  }
}
V g_heff_2ebuild_2edecoder_2edigitsTo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edecoder_2edigitsTo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ebuild_2edecoder_2edecimalAt_24cpr(V v_s_240, V v_i_241, V v_j_242) {
top: ;
  if (heff_intLe_c_lent(v_j_242, v_i_241, 0)) {
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)45ULL))) {
      V v_n_245 = (g_heff_2ebuild_2edecoder_2edigitsTo(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_j_242, MK_INT(0LL)));
      if (heff_intLt_c_lent(v_n_245, MK_INT(0LL), 2)) {
        heff_drop(v_n_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V v_f_247 = heff_intSub(MK_INT(0LL), v_n_245);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_247}});
      }
    } else {
      V v_n_248 = (g_heff_2ebuild_2edecoder_2edigitsTo(v_s_240, v_i_241, v_j_242, MK_INT(0LL)));
      if (heff_intLt_c_lent(v_n_248, MK_INT(0LL), 2)) {
        heff_drop(v_n_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_n_248}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2estrAt_24cpr(V v_s_240, V v_j_241, V v_n_242) {
top: ;
  if (heff_intLt_c_lent(v_n_242, MK_INT(0LL), 2)) {
    heff_drop(v_j_241);
    heff_drop(v_n_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    if (heff_intLt_c(heff_strLength_lent(v_s_240, 0), heff_intAdd(heff_dup(v_j_241), heff_dup(v_n_242)))) {
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      V v_t_245 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_j_241), heff_intAdd(heff_dup(v_j_241), heff_dup(v_n_242)));
      V v_i_246 = heff_intAdd(v_j_241, v_n_242);
      V v_t_249;
      if (heff_intLt_c(heff_dup(v_i_246), heff_strLength_lent(v_s_240, 0))) {
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_246, 0)) == ((int64_t)32ULL))) {
          v_t_249 = heff_intAdd(v_i_246, MK_INT(1LL));
        } else {
          v_t_249 = v_i_246;
        }
      } else {
        v_t_249 = v_i_246;
      }
      V v_f_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_t_249});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2410}});
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V v_s_240, V v_i_241) {
top: ;
  V v_x_242 = (g_heff_2ebuild_2edecoder_2ecolonAt(v_s_240, heff_dup(v_i_241)));
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), v_x_242)) {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    V v_t_244 = (g_heff_2ebuild_2edecoder_2ecolonAt(v_s_240, heff_dup(v_i_241)));
    if (heff_intEq_c_lent(v_t_244, v_i_241, 1)) {
      heff_drop(v_i_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      V v_t_246 = (g_heff_2ebuild_2edecoder_2ecolonAt(v_s_240, heff_dup(v_i_241)));
      V v_j_247 = heff_intAdd(v_t_246, MK_INT(1LL));
      V v_t_248 = (g_heff_2ebuild_2edecoder_2ecolonAt(v_s_240, heff_dup(v_i_241)));
      HeffT2 v_t_249 = (g_heff_2ebuild_2edecoder_2edecimalAt_24cpr(v_s_240, v_i_241, v_t_248));
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_n_2413 = v_field_2411;
          return (g_heff_2ebuild_2edecoder_2estrAt_24cpr(v_s_240, v_j_247, v_n_2413));
        } else {
          heff_drop(v_j_247);
          heff_drop(v_field_2411);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V v_s_240, V v_i_241) {
top: ;
  V v_j_242 = (g_heff_2ebuild_2edecoder_2ewordEnd(v_s_240, heff_dup(v_i_241)));
  V v_t_243 = (g_heff_2ebuild_2edecoder_2ewordEnd(v_s_240, heff_dup(v_i_241)));
  HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2edecimalAt_24cpr(v_s_240, v_i_241, v_t_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_n_248 = v_field_246;
      V v_t_2411;
      if (heff_intLt_c(heff_dup(v_j_242), heff_strLength_lent(v_s_240, 0))) {
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_242, 0)) == ((int64_t)32ULL))) {
          v_t_2411 = heff_intAdd(v_j_242, MK_INT(1LL));
        } else {
          v_t_2411 = v_j_242;
        }
      } else {
        v_t_2411 = v_j_242;
      }
      V v_f_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){v_n_248, v_t_2411});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
    } else {
      heff_drop(v_j_242);
      heff_drop(v_field_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
Clo g_heff_2ebuild_2edecoder_2etimes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_entry, 4, 0};

V g_heff_2ebuild_2edecoder_2etimes(V v_d_240, V v_n_241, V v_p_242, V v_p_243) {
top: ;
  if (heff_intLe_c_lent(v_n_241, MK_INT(0LL), 2)) {
    heff_drop(v_d_240);
    heff_drop(v_n_241);
    heff_drop(v_p_242);
    V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_243});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
  } else {
    V v_x3_246 = heff_tr(heff_call(heff_dup(v_d_240), 2, (V[]){heff_dup(v_p_242), v_p_243}));
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      heff_drop(v_d_240);
      heff_drop(v_n_241);
      heff_drop(v_p_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x31_247 = heff_field(v_x3_246, 0);
      V v_ru_24x3_246_24Just = heff_take_reuse_n(v_x3_246, 1ULL, 1);
      switch (heff_tag_of(v_x31_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x31_247, 0);
        V v_j_249 = heff_field(v_x31_247, 1);
        V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
        V v_m_2410 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edecoder_2etimes_clo), 2, (V[]){v_d_240, heff_intSub(v_n_241, MK_INT(1LL))}));
        V v_x3_2411 = heff_tr(heff_call(v_m_2410, 2, (V[]){v_p_242, v_j_249}));
        switch (heff_tag_of(v_x3_2411)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x3_246_24Just, 1);
          heff_drop(v_x_248);
          heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2412 = heff_field(v_x3_2411, 0);
          heff_take_n(v_x3_2411, 1ULL, 1);
          switch (heff_tag_of(v_x31_2412)) {
          case TAG_MkPair: {
            V v_x_2413 = heff_field(v_x31_2412, 0);
            V v_j_2414 = heff_field(v_x31_2412, 1);
            heff_take_n(v_x31_2412, 3ULL, 2);
            V v_t_2415 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2413}), v_j_2414});
            return heff_tag_at_n(v_ru_24x3_246_24Just, TAG_Just, 1, (V[]){v_t_2415});
          }
          default: return heff_nomatch(v_x31_2412);
          }
        }
        default: return heff_nomatch(v_x3_2411);
        }
      }
      default: return heff_nomatch(v_x31_247);
      }
    }
    default: return heff_nomatch(v_x3_246);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2etimes(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_244}});
  } else {
    HeffT2 v_t_245 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_p_241, v_p_242));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x31_249 = v_field_247;
        switch (heff_tag_of(v_x31_249)) {
        case TAG_MkPair: {
          V v_x_2410 = heff_field(v_x31_249, 0);
          V v_j_2411 = heff_field(v_x31_249, 1);
          V v_ru_24x31_249_24MkPair = heff_take_reuse_n(v_x31_249, 3ULL, 2);
          HeffT2 v_t_2412 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2411));
          {
            V v_field_2414 = v_t_2412.f[1];
            int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
            if ((v_tag_2413 == ((int64_t)0ULL))) {
              V v_x31_2416 = v_field_2414;
              switch (heff_tag_of(v_x31_2416)) {
              case TAG_MkPair: {
                V v_x_2417 = heff_field(v_x31_2416, 0);
                V v_j_2418 = heff_field(v_x31_2416, 1);
                heff_take_n(v_x31_2416, 3ULL, 2);
                V v_t_2419 = heff_tag_at_n(v_ru_24x31_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_x_2417}), v_j_2418});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2419}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2416)}});
              }
            } else {
              heff_drop(v_x_2410);
              heff_drop_cell(v_ru_24x31_249_24MkPair, 2);
              heff_drop(v_field_2414);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_249)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_field_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
Clo g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_n_240, v_p_241, v_p_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str0, 1, "t");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str1, 1, "f");
Clo g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(V v_f_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_247 = v_field_245;
      switch (heff_tag_of(v_x31_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x31_247, 0);
        V v_j_249 = heff_field(v_x31_247, 1);
        heff_take_n(v_x31_247, 3ULL, 2);
        if (heff_strEq_c_lent(v_x_248, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str0), 2)) {
          heff_drop(v_x_248);
          return heff_tail(v_f_240, 3, (V[]){NTAG(TAG_True), v_s_241, v_j_249});
        } else {
          if (heff_strEq_c(v_x_248, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str1))) {
            return heff_tail(v_f_240, 3, (V[]){NTAG(TAG_False), v_s_241, v_j_249});
          } else {
            heff_drop(v_f_240);
            heff_drop(v_s_241);
            heff_drop(v_j_249);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_247);
      }
    } else {
      heff_drop(v_f_240);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_244}});
  } else {
    HeffT2 v_t_245 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_p_241, v_p_242));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x31_249 = v_field_247;
        switch (heff_tag_of(v_x31_249)) {
        case TAG_MkPair: {
          V v_x_2410 = heff_field(v_x31_249, 0);
          V v_j_2411 = heff_field(v_x31_249, 1);
          V v_ru_24x31_249_24MkPair = heff_take_reuse_n(v_x31_249, 3ULL, 2);
          HeffT2 v_t_2412 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_p_241, v_j_2411));
          {
            V v_field_2414 = v_t_2412.f[1];
            int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
            if ((v_tag_2413 == ((int64_t)0ULL))) {
              V v_x31_2416 = v_field_2414;
              switch (heff_tag_of(v_x31_2416)) {
              case TAG_MkPair: {
                V v_x_2417 = heff_field(v_x31_2416, 0);
                V v_j_2418 = heff_field(v_x31_2416, 1);
                V v_ru_24x31_2416_24MkPair = heff_take_reuse_n(v_x31_2416, 3ULL, 2);
                HeffT2 v_t_2419 = (g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2418));
                {
                  V v_field_2421 = v_t_2419.f[1];
                  int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
                  if ((v_tag_2420 == ((int64_t)0ULL))) {
                    V v_x31_2423 = v_field_2421;
                    switch (heff_tag_of(v_x31_2423)) {
                    case TAG_MkPair: {
                      V v_x_2424 = heff_field(v_x31_2423, 0);
                      V v_j_2425 = heff_field(v_x31_2423, 1);
                      V v_ru_24x31_2423_24MkPair = heff_take_reuse_n(v_x31_2423, 3ULL, 2);
                      V v_t_2426 = heff_tag_at_n(v_ru_24x31_2423_24MkPair, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2410, v_x_2417}), v_x_2424});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2416_24MkPair, TAG_MkPair, 2, (V[]){v_t_2426, v_j_2425})}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2423)}});
                    }
                  } else {
                    heff_drop(v_x_2410);
                    heff_drop_cell(v_ru_24x31_249_24MkPair, 2);
                    heff_drop(v_x_2417);
                    heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                    heff_drop(v_field_2421);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2416)}});
              }
            } else {
              heff_drop(v_n_240);
              heff_drop(v_x_2410);
              heff_drop_cell(v_ru_24x31_249_24MkPair, 2);
              heff_drop(v_field_2414);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_249)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_field_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
Clo g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(v_n_240, v_p_241, v_p_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820(a[0], a1, a[2]); heff_drop(a1); return r;
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1444395529x927023430_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_244}});
  } else {
    V v_t_245 = heff_tr(g_heff_2ebuild_2ebackcache_2eunitD(heff_dup(v_p_241), heff_dup(v_p_242)));
    HeffT2 v_t_246 = ({ V a_0 = v_p_241; V a_1 = v_p_242; V a_2 = v_t_245; HeffT2 r_ = (g_heff_2ebuild_2ebackcache_2erawGot_24cpr(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_x31_2410 = v_field_248;
        switch (heff_tag_of(v_x31_2410)) {
        case TAG_MkPair: {
          V v_x_2411 = heff_field(v_x31_2410, 0);
          V v_j_2412 = heff_field(v_x31_2410, 1);
          V v_ru_24x31_2410_24MkPair = heff_take_reuse_n(v_x31_2410, 3ULL, 2);
          HeffT2 v_t_2413 = (g_heff_2ebuild_2edecoder_2etimes_24s1444395529x927023430_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2412));
          {
            V v_field_2415 = v_t_2413.f[1];
            int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
            if ((v_tag_2414 == ((int64_t)0ULL))) {
              V v_x31_2417 = v_field_2415;
              switch (heff_tag_of(v_x31_2417)) {
              case TAG_MkPair: {
                V v_x_2418 = heff_field(v_x31_2417, 0);
                V v_j_2419 = heff_field(v_x31_2417, 1);
                heff_take_n(v_x31_2417, 3ULL, 2);
                V v_t_2420 = heff_tag_at_n(v_ru_24x31_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_x_2418}), v_j_2419});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2420}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2417)}});
              }
            } else {
              heff_drop(v_x_2411);
              heff_drop_cell(v_ru_24x31_2410_24MkPair, 2);
              heff_drop(v_field_2415);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_2410)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
Clo g_heff_2ebuild_2edecoder_2etimes_24s1444395529x927023430_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_24s1444395529x927023430_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2etimes_24s1444395529x927023430(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2etimes_24s1444395529x927023430_24cpr(v_n_240, v_p_241, v_p_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_24s1444395529x927023430_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2etimes_24s1444395529x927023430(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s364931774x210987922_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_244}});
  } else {
    V v_t_245 = (g_heff_2ebuild_2ebackcache_2egroupD(heff_dup(v_p_241), heff_dup(v_p_242)));
    HeffT2 v_t_246 = ({ V a_0 = v_p_241; V a_1 = v_p_242; V a_2 = v_t_245; HeffT2 r_ = (g_heff_2ebuild_2ebackcache_2erawGot_24cpr(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_x31_2410 = v_field_248;
        switch (heff_tag_of(v_x31_2410)) {
        case TAG_MkPair: {
          V v_x_2411 = heff_field(v_x31_2410, 0);
          V v_j_2412 = heff_field(v_x31_2410, 1);
          V v_ru_24x31_2410_24MkPair = heff_take_reuse_n(v_x31_2410, 3ULL, 2);
          HeffT2 v_t_2413 = (g_heff_2ebuild_2edecoder_2etimes_24s364931774x210987922_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2412));
          {
            V v_field_2415 = v_t_2413.f[1];
            int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
            if ((v_tag_2414 == ((int64_t)0ULL))) {
              V v_x31_2417 = v_field_2415;
              switch (heff_tag_of(v_x31_2417)) {
              case TAG_MkPair: {
                V v_x_2418 = heff_field(v_x31_2417, 0);
                V v_j_2419 = heff_field(v_x31_2417, 1);
                heff_take_n(v_x31_2417, 3ULL, 2);
                V v_t_2420 = heff_tag_at_n(v_ru_24x31_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_x_2418}), v_j_2419});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2420}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2417)}});
              }
            } else {
              heff_drop(v_x_2411);
              heff_drop_cell(v_ru_24x31_2410_24MkPair, 2);
              heff_drop(v_field_2415);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_2410)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
Clo g_heff_2ebuild_2edecoder_2etimes_24s364931774x210987922_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_24s364931774x210987922_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2etimes_24s364931774x210987922(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2etimes_24s364931774x210987922_24cpr(v_n_240, v_p_241, v_p_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_24s364931774x210987922_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2etimes_24s364931774x210987922(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1861622792x1526156306_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_244}});
  } else {
    V v_t_245 = heff_tr(g_heff_2ebuild_2ebackcache_2ecopyD(heff_dup(v_p_241), heff_dup(v_p_242)));
    HeffT2 v_t_246 = ({ V a_0 = v_p_241; V a_1 = v_p_242; V a_2 = v_t_245; HeffT2 r_ = (g_heff_2ebuild_2ebackcache_2erawGot_24cpr(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_x31_2410 = v_field_248;
        switch (heff_tag_of(v_x31_2410)) {
        case TAG_MkPair: {
          V v_x_2411 = heff_field(v_x31_2410, 0);
          V v_j_2412 = heff_field(v_x31_2410, 1);
          V v_ru_24x31_2410_24MkPair = heff_take_reuse_n(v_x31_2410, 3ULL, 2);
          HeffT2 v_t_2413 = (g_heff_2ebuild_2edecoder_2etimes_24s1861622792x1526156306_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2412));
          {
            V v_field_2415 = v_t_2413.f[1];
            int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
            if ((v_tag_2414 == ((int64_t)0ULL))) {
              V v_x31_2417 = v_field_2415;
              switch (heff_tag_of(v_x31_2417)) {
              case TAG_MkPair: {
                V v_x_2418 = heff_field(v_x31_2417, 0);
                V v_j_2419 = heff_field(v_x31_2417, 1);
                heff_take_n(v_x31_2417, 3ULL, 2);
                V v_t_2420 = heff_tag_at_n(v_ru_24x31_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_x_2418}), v_j_2419});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2420}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2417)}});
              }
            } else {
              heff_drop(v_x_2411);
              heff_drop_cell(v_ru_24x31_2410_24MkPair, 2);
              heff_drop(v_field_2415);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_2410)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
Clo g_heff_2ebuild_2edecoder_2etimes_24s1861622792x1526156306_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_24s1861622792x1526156306_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2etimes_24s1861622792x1526156306(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2etimes_24s1861622792x1526156306_24cpr(v_n_240, v_p_241, v_p_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_24s1861622792x1526156306_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2etimes_24s1861622792x1526156306(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s372484702x1286645721_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_244}});
  } else {
    V v_t_245 = (g_heff_2ebuild_2ebackcache_2eemitD(v_p_241, heff_dup(v_p_242)));
    HeffT2 v_t_246 = ({ V a_0 = v_p_241; V a_1 = v_p_242; V a_2 = v_t_245; HeffT2 r_ = (g_heff_2ebuild_2ebackcache_2erawGot_24cpr(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_x31_2410 = v_field_248;
        switch (heff_tag_of(v_x31_2410)) {
        case TAG_MkPair: {
          V v_x_2411 = heff_field(v_x31_2410, 0);
          V v_j_2412 = heff_field(v_x31_2410, 1);
          V v_ru_24x31_2410_24MkPair = heff_take_reuse_n(v_x31_2410, 3ULL, 2);
          HeffT2 v_t_2413 = (g_heff_2ebuild_2edecoder_2etimes_24s372484702x1286645721_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2412));
          {
            V v_field_2415 = v_t_2413.f[1];
            int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
            if ((v_tag_2414 == ((int64_t)0ULL))) {
              V v_x31_2417 = v_field_2415;
              switch (heff_tag_of(v_x31_2417)) {
              case TAG_MkPair: {
                V v_x_2418 = heff_field(v_x31_2417, 0);
                V v_j_2419 = heff_field(v_x31_2417, 1);
                heff_take_n(v_x31_2417, 3ULL, 2);
                V v_t_2420 = heff_tag_at_n(v_ru_24x31_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_x_2418}), v_j_2419});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2420}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2417)}});
              }
            } else {
              heff_drop(v_x_2411);
              heff_drop_cell(v_ru_24x31_2410_24MkPair, 2);
              heff_drop(v_field_2415);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_2410)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_field_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
Clo g_heff_2ebuild_2edecoder_2etimes_24s372484702x1286645721_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_24s372484702x1286645721_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2etimes_24s372484702x1286645721(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2etimes_24s372484702x1286645721_24cpr(v_n_240, v_p_241, v_p_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_24s372484702x1286645721_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edecoder_2etimes_24s372484702x1286645721(a[0], a1, a[2]); heff_drop(a1); return r;
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s700921301x1216293995_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_244}});
  } else {
    V v_t_245 = (g_heff_2ebuild_2ebackcache_2ejsD(v_p_241, heff_dup(v_p_242)));
    HeffT2 v_t_246 = ({ V a_0 = v_p_241; V a_1 = v_p_242; V a_2 = v_t_245; HeffT2 r_ = (g_heff_2ebuild_2ebackcache_2erawGot_24cpr(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_x31_2410 = v_field_248;
        switch (heff_tag_of(v_x31_2410)) {
        case TAG_MkPair: {
          V v_x_2411 = heff_field(v_x31_2410, 0);
          V v_j_2412 = heff_field(v_x31_2410, 1);
          V v_ru_24x31_2410_24MkPair = heff_take_reuse_n(v_x31_2410, 3ULL, 2);
          HeffT2 v_t_2413 = (g_heff_2ebuild_2edecoder_2etimes_24s700921301x1216293995_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2412));
          {
            V v_field_2415 = v_t_2413.f[1];
            int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
            if ((v_tag_2414 == ((int64_t)0ULL))) {
              V v_x31_2417 = v_field_2415;
              switch (heff_tag_of(v_x31_2417)) {
              case TAG_MkPair: {
                V v_x_2418 = heff_field(v_x31_2417, 0);
                V v_j_2419 = heff_field(v_x31_2417, 1);
                heff_take_n(v_x31_2417, 3ULL, 2);
                V v_t_2420 = heff_tag_at_n(v_ru_24x31_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_x_2418}), v_j_2419});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2420}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2417)}});
              }
            } else {
              heff_drop(v_x_2411);
              heff_drop_cell(v_ru_24x31_2410_24MkPair, 2);
              heff_drop(v_field_2415);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_2410)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_field_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
Clo g_heff_2ebuild_2edecoder_2etimes_24s700921301x1216293995_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_24s700921301x1216293995_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2etimes_24s700921301x1216293995(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2etimes_24s700921301x1216293995_24cpr(v_n_240, v_p_241, v_p_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_24s700921301x1216293995_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edecoder_2etimes_24s700921301x1216293995(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str1, 1, "1");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str2, 1, "2");

HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_244;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        if (heff_strEq_c_lent(v_x_247, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str0), 2)) {
          heff_drop(v_x_247);
          V v_t_2410 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Expl), v_j_248});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2410}});
        } else {
          if (heff_strEq_c_lent(v_x_247, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str1), 2)) {
            heff_drop(v_x_247);
            V v_t_2412 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Impl), v_j_248});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2412}});
          } else {
            if (heff_strEq_c(v_x_247, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str2))) {
              V v_t_2414 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Inst), v_j_248});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2414}});
            } else {
              heff_drop(v_j_248);
              heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str1, 1, "1");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str2, 1, "2");

HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_244;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        if (heff_strEq_c_lent(v_x_247, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str0), 2)) {
          heff_drop(v_x_247);
          V v_t_2410 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Small), v_j_248});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2410}});
        } else {
          if (heff_strEq_c_lent(v_x_247, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str1), 2)) {
            heff_drop(v_x_247);
            V v_t_2412 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Large), v_j_248});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2412}});
          } else {
            if (heff_strEq_c(v_x_247, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str2))) {
              V v_t_2414 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_TopL), v_j_248});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2414}});
            } else {
              heff_drop(v_j_248);
              heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
Clo g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698(V v_f_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_247 = v_field_245;
      switch (heff_tag_of(v_x31_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x31_247, 0);
        V v_j_249 = heff_field(v_x31_247, 1);
        heff_take_n(v_x31_247, 3ULL, 2);
        return heff_tail(v_f_240, 3, (V[]){v_x_248, v_s_241, v_j_249});
      }
      default: return heff_nomatch(v_x31_247);
      }
    } else {
      heff_drop(v_f_240);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr_str1, 1, "1");

HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_244;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        if (heff_strEq_c_lent(v_x_247, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr_str0), 2)) {
          heff_drop(v_x_247);
          V v_t_2410 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){v_t_2410, v_j_248})}});
        } else {
          if (heff_strEq_c(v_x_247, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr_str1))) {
            V v_t_2412 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_LargeU)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){v_t_2412, v_j_248})}});
          } else {
            heff_drop(v_j_248);
            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_244}});
  } else {
    V v_x3_245 = heff_tr(g_heff_2ebuild_2ecache_2emeltFixGroup(heff_dup(v_p_241), v_p_242));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_246 = heff_field(v_x3_245, 0);
      heff_take_n(v_x3_245, 1ULL, 1);
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        HeffT2 v_t_249 = (g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x31_2413 = v_field_2411;
            switch (heff_tag_of(v_x31_2413)) {
            case TAG_MkPair: {
              V v_x_2414 = heff_field(v_x31_2413, 0);
              V v_j_2415 = heff_field(v_x31_2413, 1);
              heff_take_n(v_x31_2413, 3ULL, 2);
              V v_t_2416 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_x_2414}), v_j_2415});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2416}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
            }
          } else {
            heff_drop(v_x_247);
            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
            heff_drop(v_field_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_245)}});
    }
  }
}
Clo g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_24cpr(v_n_240, v_p_241, v_p_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_244}});
  } else {
    HeffT2 v_t_245 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_p_241, v_p_242));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x31_249 = v_field_247;
        switch (heff_tag_of(v_x31_249)) {
        case TAG_MkPair: {
          V v_x_2410 = heff_field(v_x31_249, 0);
          V v_j_2411 = heff_field(v_x31_249, 1);
          V v_ru_24x31_249_24MkPair = heff_take_reuse_n(v_x31_249, 3ULL, 2);
          HeffT2 v_t_2412 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_p_241, v_j_2411));
          {
            V v_field_2414 = v_t_2412.f[1];
            int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
            if ((v_tag_2413 == ((int64_t)0ULL))) {
              V v_x31_2416 = v_field_2414;
              switch (heff_tag_of(v_x31_2416)) {
              case TAG_MkPair: {
                V v_x_2417 = heff_field(v_x31_2416, 0);
                V v_j_2418 = heff_field(v_x31_2416, 1);
                V v_ru_24x31_2416_24MkPair = heff_take_reuse_n(v_x31_2416, 3ULL, 2);
                HeffT2 v_t_2419 = (g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2418));
                {
                  V v_field_2421 = v_t_2419.f[1];
                  int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
                  if ((v_tag_2420 == ((int64_t)0ULL))) {
                    V v_x31_2423 = v_field_2421;
                    switch (heff_tag_of(v_x31_2423)) {
                    case TAG_MkPair: {
                      V v_x_2424 = heff_field(v_x31_2423, 0);
                      V v_j_2425 = heff_field(v_x31_2423, 1);
                      heff_take_n(v_x31_2423, 3ULL, 2);
                      V v_t_2426 = heff_tag_at_n(v_ru_24x31_2416_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_tighter__looser, (V[]){v_x_2410, v_x_2417}), v_x_2424});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_249_24MkPair, TAG_MkPair, 2, (V[]){v_t_2426, v_j_2425})}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2423)}});
                    }
                  } else {
                    heff_drop(v_x_2410);
                    heff_drop_cell(v_ru_24x31_249_24MkPair, 2);
                    heff_drop(v_x_2417);
                    heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                    heff_drop(v_field_2421);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2416)}});
              }
            } else {
              heff_drop(v_n_240);
              heff_drop(v_x_2410);
              heff_drop_cell(v_ru_24x31_249_24MkPair, 2);
              heff_drop(v_field_2414);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_249)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_field_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
Clo g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_24cpr(v_n_240, v_p_241, v_p_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499(a[0], a1, a[2]); heff_drop(a1); return r;
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_244}});
  } else {
    HeffT2 v_t_245 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_p_241, v_p_242));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_a_249 = v_field_247;
        switch (heff_tag_of(v_a_249)) {
        case TAG_MkPair: {
          V v_a_2410 = heff_field(v_a_249, 0);
          V v_a_2411 = heff_field(v_a_249, 1);
          V v_ru_24a_249_24MkPair = heff_take_reuse_n(v_a_249, 3ULL, 2);
          HeffT2 v_t_2412 = (g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_24cpr(heff_dup(v_p_241), v_a_2411));
          {
            V v_field_2414 = v_t_2412.f[1];
            int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
            if ((v_tag_2413 == ((int64_t)0ULL))) {
              V v_a_2416 = v_field_2414;
              switch (heff_tag_of(v_a_2416)) {
              case TAG_MkPair: {
                V v_a_2417 = heff_field(v_a_2416, 0);
                V v_a_2418 = heff_field(v_a_2416, 1);
                V v_ru_24a_2416_24MkPair = heff_take_reuse_n(v_a_2416, 3ULL, 2);
                HeffT2 v_t_2419 = (g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_a_2418));
                {
                  V v_field_2421 = v_t_2419.f[1];
                  int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
                  if ((v_tag_2420 == ((int64_t)0ULL))) {
                    V v_x31_2423 = v_field_2421;
                    switch (heff_tag_of(v_x31_2423)) {
                    case TAG_MkPair: {
                      V v_x_2424 = heff_field(v_x31_2423, 0);
                      V v_j_2425 = heff_field(v_x31_2423, 1);
                      V v_ru_24x31_2423_24MkPair = heff_take_reuse_n(v_x31_2423, 3ULL, 2);
                      V v_t_2426 = heff_tag_at_n(v_ru_24x31_2423_24MkPair, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24a_249_24MkPair, TAG_MkPair, 2, (V[]){v_a_2410, v_a_2417}), v_x_2424});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24a_2416_24MkPair, TAG_MkPair, 2, (V[]){v_t_2426, v_j_2425})}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2423)}});
                    }
                  } else {
                    heff_drop(v_a_2410);
                    heff_drop_cell(v_ru_24a_249_24MkPair, 2);
                    heff_drop(v_a_2417);
                    heff_drop_cell(v_ru_24a_2416_24MkPair, 2);
                    heff_drop(v_field_2421);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_a_2416)}});
              }
            } else {
              heff_drop(v_n_240);
              heff_drop(v_p_241);
              heff_drop(v_a_2410);
              heff_drop_cell(v_ru_24a_249_24MkPair, 2);
              heff_drop(v_field_2414);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_a_249)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
Clo g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(v_n_240, v_p_241, v_p_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s2082925062x256752403_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_244;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        heff_take_n(v_x31_246, 3ULL, 2);
        return ({ V a_0 = v_x_247; V a_1 = v_s_240; V a_2 = v_j_248; HeffT2 r_ = (g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr(a_0, a_1, a_2)); heff_drop(v_x_247); r_; });
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_244}});
  } else {
    HeffT2 v_t_245 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_p_241, v_p_242));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_a_249 = v_field_247;
        switch (heff_tag_of(v_a_249)) {
        case TAG_MkPair: {
          V v_a_2410 = heff_field(v_a_249, 0);
          V v_a_2411 = heff_field(v_a_249, 1);
          V v_ru_24a_249_24MkPair = heff_take_reuse_n(v_a_249, 3ULL, 2);
          HeffT2 v_t_2412 = (g_heff_2ebuild_2eserial_2etakeFields_24s1394680213x1941859555_24cpr(heff_dup(v_p_241), v_a_2411));
          {
            V v_field_2414 = v_t_2412.f[1];
            int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
            if ((v_tag_2413 == ((int64_t)0ULL))) {
              V v_a_2416 = v_field_2414;
              switch (heff_tag_of(v_a_2416)) {
              case TAG_MkPair: {
                V v_a_2417 = heff_field(v_a_2416, 0);
                V v_a_2418 = heff_field(v_a_2416, 1);
                V v_ru_24a_2416_24MkPair = heff_take_reuse_n(v_a_2416, 3ULL, 2);
                HeffT2 v_t_2419 = (g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_a_2418));
                {
                  V v_field_2421 = v_t_2419.f[1];
                  int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
                  if ((v_tag_2420 == ((int64_t)0ULL))) {
                    V v_x31_2423 = v_field_2421;
                    switch (heff_tag_of(v_x31_2423)) {
                    case TAG_MkPair: {
                      V v_x_2424 = heff_field(v_x31_2423, 0);
                      V v_j_2425 = heff_field(v_x31_2423, 1);
                      V v_ru_24x31_2423_24MkPair = heff_take_reuse_n(v_x31_2423, 3ULL, 2);
                      V v_t_2426 = heff_tag_at_n(v_ru_24x31_2423_24MkPair, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24a_249_24MkPair, TAG_MkPair, 2, (V[]){v_a_2410, v_a_2417}), v_x_2424});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24a_2416_24MkPair, TAG_MkPair, 2, (V[]){v_t_2426, v_j_2425})}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2423)}});
                    }
                  } else {
                    heff_drop(v_a_2410);
                    heff_drop_cell(v_ru_24a_249_24MkPair, 2);
                    heff_drop(v_a_2417);
                    heff_drop_cell(v_ru_24a_2416_24MkPair, 2);
                    heff_drop(v_field_2421);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_a_2416)}});
              }
            } else {
              heff_drop(v_n_240);
              heff_drop(v_p_241);
              heff_drop(v_a_2410);
              heff_drop_cell(v_ru_24a_249_24MkPair, 2);
              heff_drop(v_field_2414);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_a_249)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
Clo g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_24cpr(v_n_240, v_p_241, v_p_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_244}});
  } else {
    HeffT2 v_t_245 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_p_241, v_p_242));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x31_249 = v_field_247;
        switch (heff_tag_of(v_x31_249)) {
        case TAG_MkPair: {
          V v_x_2410 = heff_field(v_x31_249, 0);
          V v_j_2411 = heff_field(v_x31_249, 1);
          V v_ru_24x31_249_24MkPair = heff_take_reuse_n(v_x31_249, 3ULL, 2);
          HeffT2 v_t_2412 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_p_241, v_j_2411));
          {
            V v_field_2414 = v_t_2412.f[1];
            int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
            if ((v_tag_2413 == ((int64_t)0ULL))) {
              V v_x31_2416 = v_field_2414;
              switch (heff_tag_of(v_x31_2416)) {
              case TAG_MkPair: {
                V v_x_2417 = heff_field(v_x31_2416, 0);
                V v_j_2418 = heff_field(v_x31_2416, 1);
                V v_ru_24x31_2416_24MkPair = heff_take_reuse_n(v_x31_2416, 3ULL, 2);
                HeffT2 v_t_2419 = (g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2418));
                {
                  V v_field_2421 = v_t_2419.f[1];
                  int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
                  if ((v_tag_2420 == ((int64_t)0ULL))) {
                    V v_x31_2423 = v_field_2421;
                    switch (heff_tag_of(v_x31_2423)) {
                    case TAG_MkPair: {
                      V v_x_2424 = heff_field(v_x31_2423, 0);
                      V v_j_2425 = heff_field(v_x31_2423, 1);
                      V v_ru_24x31_2423_24MkPair = heff_take_reuse_n(v_x31_2423, 3ULL, 2);
                      V v_t_2426 = heff_tag_at_n(v_ru_24x31_2423_24MkPair, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2410, v_x_2417}), v_x_2424});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2416_24MkPair, TAG_MkPair, 2, (V[]){v_t_2426, v_j_2425})}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2423)}});
                    }
                  } else {
                    heff_drop(v_x_2410);
                    heff_drop_cell(v_ru_24x31_249_24MkPair, 2);
                    heff_drop(v_x_2417);
                    heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                    heff_drop(v_field_2421);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2416)}});
              }
            } else {
              heff_drop(v_n_240);
              heff_drop(v_x_2410);
              heff_drop_cell(v_ru_24x31_249_24MkPair, 2);
              heff_drop(v_field_2414);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_249)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_field_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
Clo g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_24cpr(v_n_240, v_p_241, v_p_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652(a[0], a1, a[2]); heff_drop(a1); return r;
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_244}});
  } else {
    V v_x3_245 = heff_tr(g_heff_2ebuild_2ecache_2emeltDef(heff_dup(v_p_241), v_p_242));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_246 = heff_field(v_x3_245, 0);
      heff_take_n(v_x3_245, 1ULL, 1);
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        HeffT2 v_t_249 = (g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x31_2413 = v_field_2411;
            switch (heff_tag_of(v_x31_2413)) {
            case TAG_MkPair: {
              V v_x_2414 = heff_field(v_x31_2413, 0);
              V v_j_2415 = heff_field(v_x31_2413, 1);
              heff_take_n(v_x31_2413, 3ULL, 2);
              V v_t_2416 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_x_2414}), v_j_2415});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2416}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
            }
          } else {
            heff_drop(v_x_247);
            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
            heff_drop(v_field_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_245)}});
    }
  }
}
Clo g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_24cpr(v_n_240, v_p_241, v_p_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349(a[0], a[1], a[2]);
}