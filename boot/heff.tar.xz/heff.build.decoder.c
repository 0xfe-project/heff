// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Expl 20488
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define LBL_looser 850054335
#define LBL_tighter 1059982480
static uint32_t shape_tighter__looser[] = {LBL_tighter, LBL_looser};
HeffT2 g_heff_2ebuild_2ebackcache_2ewithRaw_24s1280263334x1684915868_24cpr(V, V);
HeffT2 g_heff_2ebuild_2ebackcache_2ewithRaw_24s1304941386x8760443_24cpr(V, V);
HeffT2 g_heff_2ebuild_2ebackcache_2ewithRaw_24s1413851850x1114201945_24cpr(V, V);
HeffT2 g_heff_2ebuild_2ebackcache_2ewithRaw_24s1993828292x1749017443_24cpr(V, V);
HeffT2 g_heff_2ebuild_2ebackcache_2ewithRaw_24s497340727x548230450_24cpr(V, V);
V g_heff_2ebuild_2ecache_2emeltDef(V, V);
V g_heff_2ebuild_2ecache_2emeltDef_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltDef_clo;
V g_heff_2ebuild_2ecache_2emeltFixGroup(V, V);
V g_heff_2ebuild_2ecache_2emeltFixGroup_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltFixGroup_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_clo;
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s2082925062x256752403_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_clo;
V g_heff_2ebuild_2edecoder_2ecolonAt(V, V);
V g_heff_2ebuild_2edecoder_2ecolonAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ecolonAt_clo;
HeffT2 g_heff_2ebuild_2edecoder_2edecimalAt_24cpr(V, V, V);
V g_heff_2ebuild_2edecoder_2edigitsTo(V, V, V, V);
V g_heff_2ebuild_2edecoder_2edigitsTo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2edigitsTo_clo;
V g_heff_2ebuild_2edecoder_2efail(V, V);
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2efail_clo;
HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estrAt_24cpr(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes(V, V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_clo;
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1391953550x1663492198_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1952093399x207461701_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1954476619x1073210498_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s2049614891x1595878686_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s481066606x2100141841_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ewhole_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
V g_heff_2ebuild_2edecoder_2ewordEnd(V, V);
V g_heff_2ebuild_2edecoder_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ewordEnd_clo;
HeffT2 g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeFields_24s1394680213x1941859555_24cpr(V, V);

HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V v_s_240, V v_i_241) {
top: ;
  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
}
Clo g_heff_2ebuild_2edecoder_2efail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2efail_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2efail(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2efail_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2edecoder_2efail(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ebuild_2edecoder_2ewhole_24cpr(V v_d_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = heff_tr(heff_call(v_d_240, 2, (V[]){heff_dup(v_s_241), v_i_242}));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop(v_s_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      if (heff_intLe_c(heff_strLength(v_s_241), heff_dup(v_j_246))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_MkPair, 2, (V[]){v_x_245, v_j_246})}});
      } else {
        heff_drop(v_x_245);
        heff_drop(v_j_246);
        heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_243)}});
  }
}
Clo g_heff_2ebuild_2edecoder_2ewordEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ewordEnd_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ewordEnd(V v_s_240, V v_i_241) {
top: ;
  if ((heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)32ULL)))) {
    return v_i_241;
  } else {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_i_241 = t_1;
    goto top;
  }
}
V g_heff_2ebuild_2edecoder_2ewordEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edecoder_2ewordEnd(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    V v_t_242 = (g_heff_2ebuild_2edecoder_2ewordEnd(v_s_240, heff_dup(v_i_241)));
    V v_i_243 = (g_heff_2ebuild_2edecoder_2ewordEnd(v_s_240, heff_dup(v_i_241)));
    V v_t_244;
    if ((heff_intLt_c(heff_dup(v_i_243), heff_strLength_lent(v_s_240, 0)) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_243, 0)) == ((int64_t)32ULL)))) {
      v_t_244 = heff_intAdd(v_i_243, MK_INT(1LL));
    } else {
      v_t_244 = v_i_243;
    }
    V v_f_245 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strSlice_lent(v_s_240, v_i_241, v_t_242, 6), v_t_244});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_245}});
  }
}
Clo g_heff_2ebuild_2edecoder_2ecolonAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ecolonAt_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ecolonAt(V v_s_240, V v_i_241) {
top: ;
  if ((heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)58ULL)))) {
    return v_i_241;
  } else {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_i_241 = t_1;
    goto top;
  }
}
V g_heff_2ebuild_2edecoder_2ecolonAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edecoder_2ecolonAt(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edecoder_2edigitsTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2edigitsTo_entry, 4, 0};

V g_heff_2ebuild_2edecoder_2edigitsTo(V v_s_240, V v_i_241, V v_j_242, V v_acc_243) {
top: ;
  if (heff_intLe_c_lent(v_j_242, v_i_241, 0)) {
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    return v_acc_243;
  } else {
    if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) < ((int64_t)48ULL)) || (((int64_t)57ULL) < heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0))))) {
      heff_drop(v_i_241);
      heff_drop(v_j_242);
      heff_drop(v_acc_243);
      return MK_INT(-1LL);
    } else {
      V v_t_244 = heff_intAdd(heff_intMul(v_acc_243, MK_INT(10LL)), heff_strByteAt_lent(v_s_240, v_i_241, 0));
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_j_242;
      V t_3 = heff_intSub(v_t_244, MK_INT(48LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2ebuild_2edecoder_2edigitsTo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edecoder_2edigitsTo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ebuild_2edecoder_2edecimalAt_24cpr(V v_s_240, V v_i_241, V v_j_242) {
top: ;
  if (heff_intLe_c_lent(v_j_242, v_i_241, 0)) {
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)45ULL))) {
      V v_n_243 = (g_heff_2ebuild_2edecoder_2edigitsTo(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_j_242, MK_INT(0LL)));
      if (heff_intLt_c_lent(v_n_243, MK_INT(0LL), 2)) {
        heff_drop(v_n_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V v_f_244 = heff_intSub(MK_INT(0LL), v_n_243);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_244}});
      }
    } else {
      V v_n_245 = (g_heff_2ebuild_2edecoder_2edigitsTo(v_s_240, v_i_241, v_j_242, MK_INT(0LL)));
      if (heff_intLt_c_lent(v_n_245, MK_INT(0LL), 2)) {
        heff_drop(v_n_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_n_245}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2estrAt_24cpr(V v_s_240, V v_j_241, V v_n_242) {
top: ;
  if ((heff_intLt_c_lent(v_n_242, MK_INT(0LL), 2) || heff_intLt_c(heff_strLength_lent(v_s_240, 0), heff_intAdd(heff_dup(v_j_241), heff_dup(v_n_242))))) {
    heff_drop(v_j_241);
    heff_drop(v_n_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    V v_t_243 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_j_241), heff_intAdd(heff_dup(v_j_241), heff_dup(v_n_242)));
    V v_i_244 = heff_intAdd(v_j_241, v_n_242);
    V v_t_245;
    if ((heff_intLt_c(heff_dup(v_i_244), heff_strLength_lent(v_s_240, 0)) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_244, 0)) == ((int64_t)32ULL)))) {
      v_t_245 = heff_intAdd(v_i_244, MK_INT(1LL));
    } else {
      v_t_245 = v_i_244;
    }
    V v_f_246 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_t_245});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V v_s_240, V v_i_241) {
top: ;
  V v_x_242 = (g_heff_2ebuild_2edecoder_2ecolonAt(v_s_240, heff_dup(v_i_241)));
  V v_t_243 = heff_bool(heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_x_242)));
  heff_drop(v_x_242);
  if (((heff_dup(v_t_243) == NTAG(TAG_True)) || ({ V v_t_2411 = (g_heff_2ebuild_2edecoder_2ecolonAt(v_s_240, heff_dup(v_i_241))); int c_ = heff_intEq_c_lent(v_t_2411, v_i_241, 0); heff_drop(v_t_2411); c_; }))) {
    heff_drop(v_i_241);
    heff_drop(v_t_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    heff_drop(v_t_243);
    V v_t_244 = (g_heff_2ebuild_2edecoder_2ecolonAt(v_s_240, heff_dup(v_i_241)));
    V v_j_245 = heff_intAdd(v_t_244, MK_INT(1LL));
    V v_t_246 = (g_heff_2ebuild_2edecoder_2ecolonAt(v_s_240, heff_dup(v_i_241)));
    HeffT2 v_t_247 = (g_heff_2ebuild_2edecoder_2edecimalAt_24cpr(v_s_240, v_i_241, v_t_246));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_n_2410 = v_field_249;
        return (g_heff_2ebuild_2edecoder_2estrAt_24cpr(v_s_240, v_j_245, v_n_2410));
      } else {
        heff_drop(v_j_245);
        heff_drop(v_field_249);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V v_s_240, V v_i_241) {
top: ;
  V v_j_242 = (g_heff_2ebuild_2edecoder_2ewordEnd(v_s_240, heff_dup(v_i_241)));
  V v_t_243 = (g_heff_2ebuild_2edecoder_2ewordEnd(v_s_240, heff_dup(v_i_241)));
  HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2edecimalAt_24cpr(v_s_240, v_i_241, v_t_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_n_247 = v_field_246;
      V v_t_248;
      if ((heff_intLt_c(heff_dup(v_j_242), heff_strLength_lent(v_s_240, 0)) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_242, 0)) == ((int64_t)32ULL)))) {
        v_t_248 = heff_intAdd(v_j_242, MK_INT(1LL));
      } else {
        v_t_248 = v_j_242;
      }
      V v_f_249 = heff_tag_n(TAG_MkPair, 2, (V[]){v_n_247, v_t_248});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_249}});
    } else {
      heff_drop(v_j_242);
      heff_drop(v_field_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24cpr(V v_d_240, V v_n_241, V v_p_242, V v_p_243) {
top: ;
  if (heff_intLe_c_lent(v_n_241, MK_INT(0LL), 2)) {
    heff_drop(v_d_240);
    heff_drop(v_n_241);
    heff_drop(v_p_242);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_243});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_244}});
  } else {
    V v_x3_245 = heff_tr(heff_call(heff_dup(v_d_240), 2, (V[]){heff_dup(v_p_242), v_p_243}));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      heff_drop(v_d_240);
      heff_drop(v_n_241);
      heff_drop(v_p_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_246 = heff_field(v_x3_245, 0);
      heff_take_n(v_x3_245, 1ULL, 1);
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        V v_m_249 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edecoder_2etimes_clo), 2, (V[]){v_d_240, heff_intSub(v_n_241, MK_INT(1LL))}));
        V v_x3_2410 = heff_tr(heff_call(v_m_249, 2, (V[]){v_p_242, v_j_248}));
        switch (heff_tag_of(v_x3_2410)) {
        case TAG_Nothing: {
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_x31_2411 = heff_field(v_x3_2410, 0);
          heff_take_n(v_x3_2410, 1ULL, 1);
          switch (heff_tag_of(v_x31_2411)) {
          case TAG_MkPair: {
            V v_x_2412 = heff_field(v_x31_2411, 0);
            V v_j_2413 = heff_field(v_x31_2411, 1);
            heff_take_n(v_x31_2411, 3ULL, 2);
            V v_t_2414 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_x_2412}), v_j_2413});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2414}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2411)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x3_2410)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_245)}});
    }
  }
}
Clo g_heff_2ebuild_2edecoder_2etimes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_entry, 4, 0};

V g_heff_2ebuild_2edecoder_2etimes(V v_d_240, V v_n_241, V v_p_242, V v_p_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2etimes_24cpr(v_d_240, v_n_241, v_p_242, v_p_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_246});
    } else {
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2etimes(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_p_241, v_p_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_247 = v_field_246;
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          HeffT2 v_t_2410 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_249));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              V v_x31_2413 = v_field_2412;
              switch (heff_tag_of(v_x31_2413)) {
              case TAG_MkPair: {
                V v_x_2414 = heff_field(v_x31_2413, 0);
                V v_j_2415 = heff_field(v_x31_2413, 1);
                heff_take_n(v_x31_2413, 3ULL, 2);
                V v_t_2416 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2414}), v_j_2415});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2416}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
              }
            } else {
              heff_drop(v_x_248);
              heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
              heff_drop(v_field_2412);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str0, 1, "t");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str1, 1, "f");
Clo g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(V v_f_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_245;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        heff_take_n(v_x31_246, 3ULL, 2);
        if (heff_strEq_c_lent(v_x_247, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str0), 2)) {
          heff_drop(v_x_247);
          return heff_tail(v_f_240, 3, (V[]){NTAG(TAG_True), v_s_241, v_j_248});
        } else {
          if (heff_strEq_c(v_x_247, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str1))) {
            return heff_tail(v_f_240, 3, (V[]){NTAG(TAG_False), v_s_241, v_j_248});
          } else {
            heff_drop(v_f_240);
            heff_drop(v_s_241);
            heff_drop(v_j_248);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop(v_f_240);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_p_241, v_p_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_247 = v_field_246;
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          HeffT2 v_t_2410 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_p_241, v_j_249));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              V v_x31_2413 = v_field_2412;
              switch (heff_tag_of(v_x31_2413)) {
              case TAG_MkPair: {
                V v_x_2414 = heff_field(v_x31_2413, 0);
                V v_j_2415 = heff_field(v_x31_2413, 1);
                V v_ru_24x31_2413_24MkPair = heff_take_reuse_n(v_x31_2413, 3ULL, 2);
                HeffT2 v_t_2416 = (g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2415));
                {
                  V v_field_2418 = v_t_2416.f[1];
                  int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
                  if ((v_tag_2417 == ((int64_t)0ULL))) {
                    V v_x31_2419 = v_field_2418;
                    switch (heff_tag_of(v_x31_2419)) {
                    case TAG_MkPair: {
                      V v_x_2420 = heff_field(v_x31_2419, 0);
                      V v_j_2421 = heff_field(v_x31_2419, 1);
                      V v_ru_24x31_2419_24MkPair = heff_take_reuse_n(v_x31_2419, 3ULL, 2);
                      V v_t_2422 = heff_tag_at_n(v_ru_24x31_2419_24MkPair, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){v_x_248, v_x_2414}), v_x_2420});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2422, v_j_2421})}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2419)}});
                    }
                  } else {
                    heff_drop(v_x_248);
                    heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                    heff_drop(v_x_2414);
                    heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                    heff_drop(v_field_2418);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
              }
            } else {
              heff_drop(v_n_240);
              heff_drop(v_x_248);
              heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
              heff_drop(v_field_2412);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1952093399x207461701_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    HeffT2 v_t_244 = (g_heff_2ebuild_2ebackcache_2ewithRaw_24s1993828292x1749017443_24cpr(heff_dup(v_p_241), v_p_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_247 = v_field_246;
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          HeffT2 v_t_2410 = (g_heff_2ebuild_2edecoder_2etimes_24s1952093399x207461701_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_249));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              V v_x31_2413 = v_field_2412;
              switch (heff_tag_of(v_x31_2413)) {
              case TAG_MkPair: {
                V v_x_2414 = heff_field(v_x31_2413, 0);
                V v_j_2415 = heff_field(v_x31_2413, 1);
                heff_take_n(v_x31_2413, 3ULL, 2);
                V v_t_2416 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2414}), v_j_2415});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2416}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
              }
            } else {
              heff_drop(v_x_248);
              heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
              heff_drop(v_field_2412);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s2049614891x1595878686_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    HeffT2 v_t_244 = (g_heff_2ebuild_2ebackcache_2ewithRaw_24s1280263334x1684915868_24cpr(heff_dup(v_p_241), v_p_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_247 = v_field_246;
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          HeffT2 v_t_2410 = (g_heff_2ebuild_2edecoder_2etimes_24s2049614891x1595878686_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_249));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              V v_x31_2413 = v_field_2412;
              switch (heff_tag_of(v_x31_2413)) {
              case TAG_MkPair: {
                V v_x_2414 = heff_field(v_x31_2413, 0);
                V v_j_2415 = heff_field(v_x31_2413, 1);
                heff_take_n(v_x31_2413, 3ULL, 2);
                V v_t_2416 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2414}), v_j_2415});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2416}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
              }
            } else {
              heff_drop(v_x_248);
              heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
              heff_drop(v_field_2412);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s481066606x2100141841_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    HeffT2 v_t_244 = (g_heff_2ebuild_2ebackcache_2ewithRaw_24s497340727x548230450_24cpr(heff_dup(v_p_241), v_p_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_247 = v_field_246;
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          HeffT2 v_t_2410 = (g_heff_2ebuild_2edecoder_2etimes_24s481066606x2100141841_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_249));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              V v_x31_2413 = v_field_2412;
              switch (heff_tag_of(v_x31_2413)) {
              case TAG_MkPair: {
                V v_x_2414 = heff_field(v_x31_2413, 0);
                V v_j_2415 = heff_field(v_x31_2413, 1);
                heff_take_n(v_x31_2413, 3ULL, 2);
                V v_t_2416 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2414}), v_j_2415});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2416}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
              }
            } else {
              heff_drop(v_x_248);
              heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
              heff_drop(v_field_2412);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1954476619x1073210498_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    HeffT2 v_t_244 = (g_heff_2ebuild_2ebackcache_2ewithRaw_24s1413851850x1114201945_24cpr(v_p_241, v_p_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_247 = v_field_246;
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          HeffT2 v_t_2410 = (g_heff_2ebuild_2edecoder_2etimes_24s1954476619x1073210498_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_249));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              V v_x31_2413 = v_field_2412;
              switch (heff_tag_of(v_x31_2413)) {
              case TAG_MkPair: {
                V v_x_2414 = heff_field(v_x31_2413, 0);
                V v_j_2415 = heff_field(v_x31_2413, 1);
                heff_take_n(v_x31_2413, 3ULL, 2);
                V v_t_2416 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2414}), v_j_2415});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2416}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
              }
            } else {
              heff_drop(v_x_248);
              heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
              heff_drop(v_field_2412);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1391953550x1663492198_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    HeffT2 v_t_244 = (g_heff_2ebuild_2ebackcache_2ewithRaw_24s1304941386x8760443_24cpr(v_p_241, v_p_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_247 = v_field_246;
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          HeffT2 v_t_2410 = (g_heff_2ebuild_2edecoder_2etimes_24s1391953550x1663492198_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_249));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              V v_x31_2413 = v_field_2412;
              switch (heff_tag_of(v_x31_2413)) {
              case TAG_MkPair: {
                V v_x_2414 = heff_field(v_x31_2413, 0);
                V v_j_2415 = heff_field(v_x31_2413, 1);
                heff_take_n(v_x31_2413, 3ULL, 2);
                V v_t_2416 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2414}), v_j_2415});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2416}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
              }
            } else {
              heff_drop(v_x_248);
              heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
              heff_drop(v_field_2412);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str1, 1, "1");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str2, 1, "2");

HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str0), 2)) {
          heff_drop(v_x_246);
          V v_t_248 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Expl), v_j_247});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_248}});
        } else {
          if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str1), 2)) {
            heff_drop(v_x_246);
            V v_t_249 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Impl), v_j_247});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_249}});
          } else {
            if (heff_strEq_c(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr_str2))) {
              V v_t_2410 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Inst), v_j_247});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2410}});
            } else {
              heff_drop(v_j_247);
              heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str1, 1, "1");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str2, 1, "2");

HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str0), 2)) {
          heff_drop(v_x_246);
          V v_t_248 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Small), v_j_247});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_248}});
        } else {
          if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str1), 2)) {
            heff_drop(v_x_246);
            V v_t_249 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Large), v_j_247});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_249}});
          } else {
            if (heff_strEq_c(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr_str2))) {
              V v_t_2410 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_TopL), v_j_247});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2410}});
            } else {
              heff_drop(v_j_247);
              heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
Clo g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698(V v_f_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_245;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        heff_take_n(v_x31_246, 3ULL, 2);
        return heff_tail(v_f_240, 3, (V[]){v_x_247, v_s_241, v_j_248});
      }
      default: return heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop(v_f_240);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr_str1, 1, "1");

HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr_str0), 2)) {
          heff_drop(v_x_246);
          V v_t_248 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_248, v_j_247})}});
        } else {
          if (heff_strEq_c(v_x_246, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr_str1))) {
            V v_t_249 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_LargeU)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_249, v_j_247})}});
          } else {
            heff_drop(v_j_247);
            heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    V v_x3_244 = heff_tr(g_heff_2ebuild_2ecache_2emeltFixGroup(heff_dup(v_p_241), v_p_242));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_245 = heff_field(v_x3_244, 0);
      heff_take_n(v_x3_244, 1ULL, 1);
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        HeffT2 v_t_248 = (g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x31_2411 = v_field_2410;
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              heff_take_n(v_x31_2411, 3ULL, 2);
              V v_t_2414 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_x_2412}), v_j_2413});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2414}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2411)}});
            }
          } else {
            heff_drop(v_x_246);
            heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
            heff_drop(v_field_2410);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_244)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_p_241, v_p_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_247 = v_field_246;
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          HeffT2 v_t_2410 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_p_241, v_j_249));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              V v_x31_2413 = v_field_2412;
              switch (heff_tag_of(v_x31_2413)) {
              case TAG_MkPair: {
                V v_x_2414 = heff_field(v_x31_2413, 0);
                V v_j_2415 = heff_field(v_x31_2413, 1);
                V v_ru_24x31_2413_24MkPair = heff_take_reuse_n(v_x31_2413, 3ULL, 2);
                HeffT2 v_t_2416 = (g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2415));
                {
                  V v_field_2418 = v_t_2416.f[1];
                  int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
                  if ((v_tag_2417 == ((int64_t)0ULL))) {
                    V v_x31_2419 = v_field_2418;
                    switch (heff_tag_of(v_x31_2419)) {
                    case TAG_MkPair: {
                      V v_x_2420 = heff_field(v_x31_2419, 0);
                      V v_j_2421 = heff_field(v_x31_2419, 1);
                      heff_take_n(v_x31_2419, 3ULL, 2);
                      V v_t_2422 = heff_tag_at_n(v_ru_24x31_2413_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_tighter__looser, (V[]){v_x_248, v_x_2414}), v_x_2420});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){v_t_2422, v_j_2421})}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2419)}});
                    }
                  } else {
                    heff_drop(v_x_248);
                    heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                    heff_drop(v_x_2414);
                    heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                    heff_drop(v_field_2418);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
              }
            } else {
              heff_drop(v_n_240);
              heff_drop(v_x_248);
              heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
              heff_drop(v_field_2412);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_p_241, v_p_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_a_247 = v_field_246;
        switch (heff_tag_of(v_a_247)) {
        case TAG_MkPair: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          V v_ru_24a_247_24MkPair = heff_take_reuse_n(v_a_247, 3ULL, 2);
          HeffT2 v_t_2410 = (g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_24cpr(heff_dup(v_p_241), v_a_249));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              V v_a_2413 = v_field_2412;
              switch (heff_tag_of(v_a_2413)) {
              case TAG_MkPair: {
                V v_a_2414 = heff_field(v_a_2413, 0);
                V v_a_2415 = heff_field(v_a_2413, 1);
                V v_ru_24a_2413_24MkPair = heff_take_reuse_n(v_a_2413, 3ULL, 2);
                HeffT2 v_t_2416 = (g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_a_2415));
                {
                  V v_field_2418 = v_t_2416.f[1];
                  int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
                  if ((v_tag_2417 == ((int64_t)0ULL))) {
                    V v_x31_2419 = v_field_2418;
                    switch (heff_tag_of(v_x31_2419)) {
                    case TAG_MkPair: {
                      V v_x_2420 = heff_field(v_x31_2419, 0);
                      V v_j_2421 = heff_field(v_x31_2419, 1);
                      V v_ru_24x31_2419_24MkPair = heff_take_reuse_n(v_x31_2419, 3ULL, 2);
                      V v_t_2422 = heff_tag_at_n(v_ru_24x31_2419_24MkPair, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24a_247_24MkPair, TAG_MkPair, 2, (V[]){v_a_248, v_a_2414}), v_x_2420});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24a_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2422, v_j_2421})}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2419)}});
                    }
                  } else {
                    heff_drop(v_a_248);
                    heff_drop_cell(v_ru_24a_247_24MkPair, 2);
                    heff_drop(v_a_2414);
                    heff_drop_cell(v_ru_24a_2413_24MkPair, 2);
                    heff_drop(v_field_2418);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_a_2413)}});
              }
            } else {
              heff_drop(v_n_240);
              heff_drop(v_p_241);
              heff_drop(v_a_248);
              heff_drop_cell(v_ru_24a_247_24MkPair, 2);
              heff_drop(v_field_2412);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_a_247)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s2082925062x256752403_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        heff_take_n(v_x31_245, 3ULL, 2);
        return ({ V a_0 = v_x_246; V a_1 = v_s_240; V a_2 = v_j_247; HeffT2 r_ = (g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr(a_0, a_1, a_2)); heff_drop(v_x_246); r_; });
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_p_241, v_p_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_a_247 = v_field_246;
        switch (heff_tag_of(v_a_247)) {
        case TAG_MkPair: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          V v_ru_24a_247_24MkPair = heff_take_reuse_n(v_a_247, 3ULL, 2);
          HeffT2 v_t_2410 = (g_heff_2ebuild_2eserial_2etakeFields_24s1394680213x1941859555_24cpr(heff_dup(v_p_241), v_a_249));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              V v_a_2413 = v_field_2412;
              switch (heff_tag_of(v_a_2413)) {
              case TAG_MkPair: {
                V v_a_2414 = heff_field(v_a_2413, 0);
                V v_a_2415 = heff_field(v_a_2413, 1);
                V v_ru_24a_2413_24MkPair = heff_take_reuse_n(v_a_2413, 3ULL, 2);
                HeffT2 v_t_2416 = (g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_a_2415));
                {
                  V v_field_2418 = v_t_2416.f[1];
                  int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
                  if ((v_tag_2417 == ((int64_t)0ULL))) {
                    V v_x31_2419 = v_field_2418;
                    switch (heff_tag_of(v_x31_2419)) {
                    case TAG_MkPair: {
                      V v_x_2420 = heff_field(v_x31_2419, 0);
                      V v_j_2421 = heff_field(v_x31_2419, 1);
                      V v_ru_24x31_2419_24MkPair = heff_take_reuse_n(v_x31_2419, 3ULL, 2);
                      V v_t_2422 = heff_tag_at_n(v_ru_24x31_2419_24MkPair, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24a_247_24MkPair, TAG_MkPair, 2, (V[]){v_a_248, v_a_2414}), v_x_2420});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24a_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2422, v_j_2421})}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2419)}});
                    }
                  } else {
                    heff_drop(v_a_248);
                    heff_drop_cell(v_ru_24a_247_24MkPair, 2);
                    heff_drop(v_a_2414);
                    heff_drop_cell(v_ru_24a_2413_24MkPair, 2);
                    heff_drop(v_field_2418);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_a_2413)}});
              }
            } else {
              heff_drop(v_n_240);
              heff_drop(v_p_241);
              heff_drop(v_a_248);
              heff_drop_cell(v_ru_24a_247_24MkPair, 2);
              heff_drop(v_field_2412);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_a_247)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_p_241);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_p_241, v_p_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_247 = v_field_246;
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          HeffT2 v_t_2410 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_p_241, v_j_249));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              V v_x31_2413 = v_field_2412;
              switch (heff_tag_of(v_x31_2413)) {
              case TAG_MkPair: {
                V v_x_2414 = heff_field(v_x31_2413, 0);
                V v_j_2415 = heff_field(v_x31_2413, 1);
                V v_ru_24x31_2413_24MkPair = heff_take_reuse_n(v_x31_2413, 3ULL, 2);
                HeffT2 v_t_2416 = (g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2415));
                {
                  V v_field_2418 = v_t_2416.f[1];
                  int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
                  if ((v_tag_2417 == ((int64_t)0ULL))) {
                    V v_x31_2419 = v_field_2418;
                    switch (heff_tag_of(v_x31_2419)) {
                    case TAG_MkPair: {
                      V v_x_2420 = heff_field(v_x31_2419, 0);
                      V v_j_2421 = heff_field(v_x31_2419, 1);
                      V v_ru_24x31_2419_24MkPair = heff_take_reuse_n(v_x31_2419, 3ULL, 2);
                      V v_t_2422 = heff_tag_at_n(v_ru_24x31_2419_24MkPair, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){v_x_248, v_x_2414}), v_x_2420});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2422, v_j_2421})}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2419)}});
                    }
                  } else {
                    heff_drop(v_x_248);
                    heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                    heff_drop(v_x_2414);
                    heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                    heff_drop(v_field_2418);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
              }
            } else {
              heff_drop(v_n_240);
              heff_drop(v_x_248);
              heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
              heff_drop(v_field_2412);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      } else {
        heff_drop(v_n_240);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_24cpr(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  } else {
    V v_x3_244 = heff_tr(g_heff_2ebuild_2ecache_2emeltDef(heff_dup(v_p_241), v_p_242));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_245 = heff_field(v_x3_244, 0);
      heff_take_n(v_x3_244, 1ULL, 1);
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        HeffT2 v_t_248 = (g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_24cpr(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x31_2411 = v_field_2410;
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              heff_take_n(v_x31_2411, 3ULL, 2);
              V v_t_2414 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_x_2412}), v_j_2413});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2414}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2411)}});
            }
          } else {
            heff_drop(v_x_246);
            heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
            heff_drop(v_field_2410);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_244)}});
    }
  }
}