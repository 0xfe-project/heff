// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Expl 20488
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define LBL_above 293969847
#define LBL_groups 709681407
#define LBL_looser 850054335
#define LBL_tighter 1059982480
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_tighter__looser[] = {LBL_tighter, LBL_looser};
V g_heff_2ebuild_2ecache_2emeltDef(V, V);
V g_heff_2ebuild_2ecache_2emeltDef_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltDef_clo;
V g_heff_2ebuild_2ecache_2emeltFixGroup(V, V);
V g_heff_2ebuild_2ecache_2emeltFixGroup_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltFixGroup_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s1098195066x1958728779(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s1098195066x1958728779_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s1098195066x1958728779_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s1423786112x2002309168(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s1423786112x2002309168_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s1423786112x2002309168_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s175128368x196003177(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s175128368x196003177_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s175128368x196003177_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s175898238x1158484984(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s175898238x1158484984_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s175898238x1158484984_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s176077469x354005298(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s176077469x354005298_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s176077469x354005298_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s1913503246x426966566(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s1913503246x426966566_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s1913503246x426966566_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s1960447580x1521569455(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s1960447580x1521569455_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s1960447580x1521569455_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s218177533x1117745540(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s218177533x1117745540_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s218177533x1117745540_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s4558495x638074279(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s4558495x638074279_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s4558495x638074279_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_clo;
V g_heff_2ebuild_2edecoder_2ecolonAt(V, V);
V g_heff_2ebuild_2edecoder_2ecolonAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ecolonAt_clo;
V g_heff_2ebuild_2edecoder_2efail(V, V);
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2efail_clo;
V g_heff_2ebuild_2edecoder_2estr(V, V);
V g_heff_2ebuild_2edecoder_2estr_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2estr_clo;
V g_heff_2ebuild_2edecoder_2estrAt(V, V, V);
V g_heff_2ebuild_2edecoder_2estrAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2estrAt_clo;
V g_heff_2ebuild_2edecoder_2etimes(V, V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s1051287095x659193963(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1051287095x659193963_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1051287095x659193963_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s1478943154x230515376(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1478943154x230515376_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1478943154x230515376_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s1655053420x924810089(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1655053420x924810089_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1655053420x924810089_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s1761861291x2079271738(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1761861291x2079271738_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1761861291x2079271738_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s636384560x1104891369(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s636384560x1104891369_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s636384560x1104891369_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s809748896x1244656705(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s809748896x1244656705_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s809748896x1244656705_clo;
V g_heff_2ebuild_2edecoder_2eword(V, V);
V g_heff_2ebuild_2edecoder_2eword_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2eword_clo;
V g_heff_2ebuild_2edecoder_2ewordEnd(V, V);
V g_heff_2ebuild_2edecoder_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ewordEnd_clo;
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558(V);
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_clo;
V g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853(V, V);
V g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
Clo g_heff_2ebuild_2edecoder_2efail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2efail_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2efail(V v_s_240, V v_i_241) {
top: ;
  return NTAG(TAG_Nothing);
}
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2edecoder_2efail(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2ebuild_2edecoder_2ewordEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ewordEnd_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ewordEnd(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    return v_i_241;
  } else {
    if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(32LL))) {
      heff_drop(v_s_240);
      return v_i_241;
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2ebuild_2edecoder_2ewordEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ewordEnd(a[0], a[1]);
}
Clo g_heff_2ebuild_2edecoder_2eword_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2eword_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2eword(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  } else {
    V v_t_243 = (g_heff_2ebuild_2edecoder_2ewordEnd(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_i_244 = (g_heff_2ebuild_2edecoder_2ewordEnd(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_247;
    if (heff_intLt_c(heff_dup(v_i_244), heff_strLength(heff_dup(v_s_240)))) {
      if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_244)), MK_INT(32LL))) {
        v_t_247 = heff_intAdd(v_i_244, MK_INT(1LL));
      } else {
        v_t_247 = v_i_244;
      }
    } else {
      v_t_247 = v_i_244;
    }
    V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strSlice(v_s_240, v_i_241, v_t_243), v_t_247});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
  }
}
V g_heff_2ebuild_2edecoder_2eword_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2eword(a[0], a[1]);
}
Clo g_heff_2ebuild_2edecoder_2ecolonAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ecolonAt_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ecolonAt(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    return v_i_241;
  } else {
    if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(58LL))) {
      heff_drop(v_s_240);
      return v_i_241;
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2ebuild_2edecoder_2ecolonAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ecolonAt(a[0], a[1]);
}
Clo g_heff_2ebuild_2edecoder_2estrAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2estrAt_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2estrAt(V v_s_240, V v_j_241, V v_n_242) {
top: ;
  if (heff_intLt_c(heff_strLength(heff_dup(v_s_240)), heff_intAdd(heff_dup(v_j_241), heff_dup(v_n_242)))) {
    heff_drop(v_s_240);
    heff_drop(v_j_241);
    heff_drop(v_n_242);
    return NTAG(TAG_Nothing);
  } else {
    V v_t_244 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_j_241), heff_intAdd(heff_dup(v_j_241), heff_dup(v_n_242)));
    V v_i_245 = heff_intAdd(v_j_241, v_n_242);
    V v_t_248;
    if (heff_intLt_c(heff_dup(v_i_245), heff_strLength(heff_dup(v_s_240)))) {
      if (heff_intEq_c(heff_strByteAt(v_s_240, heff_dup(v_i_245)), MK_INT(32LL))) {
        v_t_248 = heff_intAdd(v_i_245, MK_INT(1LL));
      } else {
        v_t_248 = v_i_245;
      }
    } else {
      heff_drop(v_s_240);
      v_t_248 = v_i_245;
    }
    return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_244, v_t_248})});
  }
}
V g_heff_2ebuild_2edecoder_2estrAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2estrAt(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edecoder_2estr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2estr_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2estr(V v_s_240, V v_i_241) {
top: ;
  V v_a_242 = (g_heff_2ebuild_2edecoder_2ecolonAt(heff_dup(v_s_240), heff_dup(v_i_241)));
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), v_a_242)) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  } else {
    V v_t_244 = (g_heff_2ebuild_2edecoder_2ecolonAt(heff_dup(v_s_240), heff_dup(v_i_241)));
    if (heff_intEq_c(v_t_244, heff_dup(v_i_241))) {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      return NTAG(TAG_Nothing);
    } else {
      V v_t_246 = (g_heff_2ebuild_2edecoder_2ecolonAt(heff_dup(v_s_240), heff_dup(v_i_241)));
      V v_t_247 = (g_heff_2ebuild_2edecoder_2ecolonAt(heff_dup(v_s_240), heff_dup(v_i_241)));
      V v_t_248 = (g_heff_2esyntax_2esurface_2eintOfText(heff_strSlice(heff_dup(v_s_240), v_i_241, v_t_247)));
      return (g_heff_2ebuild_2edecoder_2estrAt(v_s_240, heff_intAdd(v_t_246, MK_INT(1LL)), v_t_248));
    }
  }
}
V g_heff_2ebuild_2edecoder_2estr_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2estr(a[0], a[1]);
}
Clo g_heff_2ebuild_2edecoder_2etimes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_entry, 4, 0};

V g_heff_2ebuild_2edecoder_2etimes(V v_d_240, V v_n_241, V v_p_242, V v_p_243) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_241), MK_INT(0LL))) {
    heff_drop(v_d_240);
    heff_drop(v_n_241);
    heff_drop(v_p_242);
    V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_243});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
  } else {
    V v_x3_246 = heff_tr(heff_apply(heff_dup(v_d_240), 2, (V[]){heff_dup(v_p_242), v_p_243}));
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      heff_drop(v_d_240);
      heff_drop(v_n_241);
      heff_drop(v_p_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x31_247 = heff_field(v_x3_246, 0);
      V v_ru_24x3_246_24Just = heff_take_reuse_n(v_x3_246, 1ULL, 1);
      switch (heff_tag_of(v_x31_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x31_247, 0);
        V v_j_249 = heff_field(v_x31_247, 1);
        V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
        V v_m_2410 = heff_tr(heff_apply(((V)&g_heff_2ebuild_2edecoder_2etimes_clo), 2, (V[]){v_d_240, heff_intSub(v_n_241, MK_INT(1LL))}));
        V v_x3_2411 = heff_tr(heff_apply(v_m_2410, 2, (V[]){v_p_242, v_j_249}));
        switch (heff_tag_of(v_x3_2411)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x3_246_24Just, 1);
          heff_drop(v_x_248);
          heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2412 = heff_field(v_x3_2411, 0);
          heff_take_n(v_x3_2411, 1ULL, 1);
          switch (heff_tag_of(v_x31_2412)) {
          case TAG_MkPair: {
            V v_x_2413 = heff_field(v_x31_2412, 0);
            V v_j_2414 = heff_field(v_x31_2412, 1);
            heff_take_n(v_x31_2412, 3ULL, 2);
            V v_t_2415 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2413}), v_j_2414});
            return heff_tag_at_n(v_ru_24x3_246_24Just, TAG_Just, 1, (V[]){v_t_2415});
          }
          default: return heff_nomatch(v_x31_2412);
          }
        }
        default: return heff_nomatch(v_x3_2411);
        }
      }
      default: return heff_nomatch(v_x31_247);
      }
    }
    default: return heff_nomatch(v_x3_246);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2etimes(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ebuild_2edecoder_2ebind_24s1913503246x426966566_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s1913503246x426966566_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s1913503246x426966566(V v_f_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_241), v_i_242));
  V v_x3_248;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    v_x3_248 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    V v_ru_24x3_243_24Just = heff_take_reuse_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      V v_x_247 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_245));
      v_x3_248 = heff_tag_at_n(v_ru_24x3_243_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_j_246})});
      break;
    }
    default: heff_nomatch(v_x31_244);
    }
    break;
  }
  default: heff_nomatch(v_x3_243);
  }
  switch (heff_tag_of(v_x3_248)) {
  case TAG_Nothing: {
    heff_drop(v_f_240);
    heff_drop(v_s_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_249 = heff_field(v_x3_248, 0);
    heff_take_n(v_x3_248, 1ULL, 1);
    switch (heff_tag_of(v_x31_249)) {
    case TAG_MkPair: {
      V v_x_2410 = heff_field(v_x31_249, 0);
      V v_j_2411 = heff_field(v_x31_249, 1);
      heff_take_n(v_x31_249, 3ULL, 2);
      return heff_tail(v_f_240, 3, (V[]){v_x_2410, v_s_241, v_j_2411});
    }
    default: return heff_nomatch(v_x31_249);
    }
  }
  default: return heff_nomatch(v_x3_248);
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s1913503246x426966566_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s1913503246x426966566(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_str1, 1, "1");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_str2, 1, "2");
Clo g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2eword(v_s_240, v_i_241));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24MkPair = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      if (heff_strEq_c(heff_dup(v_x_244), ((V)&g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_str0))) {
        heff_drop(v_x_244);
        V v_t_247 = heff_tag_at_n(v_ru_24x31_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Expl), v_j_245});
        return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_t_247});
      } else {
        if (heff_strEq_c(heff_dup(v_x_244), ((V)&g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_str1))) {
          heff_drop(v_x_244);
          V v_t_249 = heff_tag_at_n(v_ru_24x31_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Impl), v_j_245});
          return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_t_249});
        } else {
          if (heff_strEq_c(v_x_244, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_str2))) {
            V v_t_2411 = heff_tag_at_n(v_ru_24x31_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Inst), v_j_245});
            return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_t_2411});
          } else {
            heff_drop_cell(v_ru_24x3_242_24Just, 1);
            heff_drop(v_j_245);
            heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
            return NTAG(TAG_Nothing);
          }
        }
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_str1, 1, "1");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_str2, 1, "2");
Clo g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2eword(v_s_240, v_i_241));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24MkPair = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      if (heff_strEq_c(heff_dup(v_x_244), ((V)&g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_str0))) {
        heff_drop(v_x_244);
        V v_t_247 = heff_tag_at_n(v_ru_24x31_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Small), v_j_245});
        return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_t_247});
      } else {
        if (heff_strEq_c(heff_dup(v_x_244), ((V)&g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_str1))) {
          heff_drop(v_x_244);
          V v_t_249 = heff_tag_at_n(v_ru_24x31_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Large), v_j_245});
          return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_t_249});
        } else {
          if (heff_strEq_c(v_x_244, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_str2))) {
            V v_t_2411 = heff_tag_at_n(v_ru_24x31_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_TopL), v_j_245});
            return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_t_2411});
          } else {
            heff_drop_cell(v_ru_24x3_242_24Just, 1);
            heff_drop(v_j_245);
            heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
            return NTAG(TAG_Nothing);
          }
        }
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174(a[0], a[1]);
}
Clo g_heff_2ebuild_2edecoder_2etimes_24s1051287095x659193963_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_24s1051287095x659193963_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2etimes_24s1051287095x659193963(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
  } else {
    V v_x3_245 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_p_241), v_p_242));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x31_246 = heff_field(v_x3_245, 0);
      V v_ru_24x3_245_24Just = heff_take_reuse_n(v_x3_245, 1ULL, 1);
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        V v_x3_249 = (g_heff_2ebuild_2edecoder_2etimes_24s1051287095x659193963(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_248));
        switch (heff_tag_of(v_x3_249)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x3_245_24Just, 1);
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2410 = heff_field(v_x3_249, 0);
          heff_take_n(v_x3_249, 1ULL, 1);
          switch (heff_tag_of(v_x31_2410)) {
          case TAG_MkPair: {
            V v_x_2411 = heff_field(v_x31_2410, 0);
            V v_j_2412 = heff_field(v_x31_2410, 1);
            heff_take_n(v_x31_2410, 3ULL, 2);
            V v_t_2413 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_j_2412});
            return heff_tag_at_n(v_ru_24x3_245_24Just, TAG_Just, 1, (V[]){v_t_2413});
          }
          default: return heff_nomatch(v_x31_2410);
          }
        }
        default: return heff_nomatch(v_x3_249);
        }
      }
      default: return heff_nomatch(v_x31_246);
      }
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_24s1051287095x659193963_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2etimes_24s1051287095x659193963(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edecoder_2ebind_24s4558495x638074279_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s4558495x638074279_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s4558495x638074279(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_240), v_i_241));
  V v_x3_247;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    v_x3_247 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_x_246 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_244));
      v_x3_247 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_j_245})});
      break;
    }
    default: heff_nomatch(v_x31_243);
    }
    break;
  }
  default: heff_nomatch(v_x3_242);
  }
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_248 = heff_field(v_x3_247, 0);
    heff_take_n(v_x3_247, 1ULL, 1);
    switch (heff_tag_of(v_x31_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x31_248, 0);
      V v_j_2410 = heff_field(v_x31_248, 1);
      heff_take_n(v_x31_248, 3ULL, 2);
      return (g_heff_2ebuild_2edecoder_2etimes_24s1051287095x659193963(v_x_249, v_s_240, v_j_2410));
    }
    default: return heff_nomatch(v_x31_248);
    }
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s4558495x638074279_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s4558495x638074279(a[0], a[1]);
}
Clo g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698(V v_f_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_241), v_i_242));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop(v_f_240);
    heff_drop(v_s_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      return heff_tail(v_f_240, 3, (V[]){v_x_245, v_s_241, v_j_246});
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_str1, 1, "1");
Clo g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2eword(v_s_240, v_i_241));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24MkPair = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      if (heff_strEq_c(heff_dup(v_x_244), ((V)&g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_str0))) {
        heff_drop(v_x_244);
        V v_t_247 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
        return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_243_24MkPair, TAG_MkPair, 2, (V[]){v_t_247, v_j_245})});
      } else {
        if (heff_strEq_c(v_x_244, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_str1))) {
          V v_t_249 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_SU, 1, (V[]){NTAG(TAG_LargeU)});
          return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_243_24MkPair, TAG_MkPair, 2, (V[]){v_t_249, v_j_245})});
        } else {
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          heff_drop(v_j_245);
          heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str0, 1, "t");
HEFF_LIT(g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str1, 1, "f");
Clo g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(V v_f_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_241), v_i_242));
  V v_x3_2411;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    v_x3_2411 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    V v_ru_24x3_243_24Just = heff_take_reuse_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      if (heff_strEq_c(heff_dup(v_x_245), ((V)&g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str0))) {
        heff_drop(v_x_245);
        V v_t_248 = heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_j_246});
        v_x3_2411 = heff_tag_at_n(v_ru_24x3_243_24Just, TAG_Just, 1, (V[]){v_t_248});
      } else {
        if (heff_strEq_c(v_x_245, ((V)&g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_str1))) {
          V v_t_2410 = heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_j_246});
          v_x3_2411 = heff_tag_at_n(v_ru_24x3_243_24Just, TAG_Just, 1, (V[]){v_t_2410});
        } else {
          heff_drop_cell(v_ru_24x3_243_24Just, 1);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
          v_x3_2411 = NTAG(TAG_Nothing);
        }
      }
      break;
    }
    default: heff_nomatch(v_x31_244);
    }
    break;
  }
  default: heff_nomatch(v_x3_243);
  }
  switch (heff_tag_of(v_x3_2411)) {
  case TAG_Nothing: {
    heff_drop(v_f_240);
    heff_drop(v_s_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2412 = heff_field(v_x3_2411, 0);
    heff_take_n(v_x3_2411, 1ULL, 1);
    switch (heff_tag_of(v_x31_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x31_2412, 0);
      V v_j_2414 = heff_field(v_x31_2412, 1);
      heff_take_n(v_x31_2412, 3ULL, 2);
      return heff_tail(v_f_240, 3, (V[]){v_x_2413, v_s_241, v_j_2414});
    }
    default: return heff_nomatch(v_x31_2412);
    }
  }
  default: return heff_nomatch(v_x3_2411);
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edecoder_2etimes_24s636384560x1104891369_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_24s636384560x1104891369_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2etimes_24s636384560x1104891369(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
  } else {
    V v_x3_245 = heff_tr(g_heff_2ebuild_2ecache_2emeltFixGroup(heff_dup(v_p_241), v_p_242));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x31_246 = heff_field(v_x3_245, 0);
      V v_ru_24x3_245_24Just = heff_take_reuse_n(v_x3_245, 1ULL, 1);
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        V v_x3_249 = (g_heff_2ebuild_2edecoder_2etimes_24s636384560x1104891369(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_248));
        switch (heff_tag_of(v_x3_249)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x3_245_24Just, 1);
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2410 = heff_field(v_x3_249, 0);
          heff_take_n(v_x3_249, 1ULL, 1);
          switch (heff_tag_of(v_x31_2410)) {
          case TAG_MkPair: {
            V v_x_2411 = heff_field(v_x31_2410, 0);
            V v_j_2412 = heff_field(v_x31_2410, 1);
            heff_take_n(v_x31_2410, 3ULL, 2);
            V v_t_2413 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_j_2412});
            return heff_tag_at_n(v_ru_24x3_245_24Just, TAG_Just, 1, (V[]){v_t_2413});
          }
          default: return heff_nomatch(v_x31_2410);
          }
        }
        default: return heff_nomatch(v_x3_249);
        }
      }
      default: return heff_nomatch(v_x31_246);
      }
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_24s636384560x1104891369_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2etimes_24s636384560x1104891369(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edecoder_2ebind_24s175128368x196003177_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s175128368x196003177_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s175128368x196003177(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_240), v_i_241));
  V v_x3_247;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    v_x3_247 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_x_246 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_244));
      v_x3_247 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_j_245})});
      break;
    }
    default: heff_nomatch(v_x31_243);
    }
    break;
  }
  default: heff_nomatch(v_x3_242);
  }
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_248 = heff_field(v_x3_247, 0);
    heff_take_n(v_x3_247, 1ULL, 1);
    switch (heff_tag_of(v_x31_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x31_248, 0);
      V v_j_2410 = heff_field(v_x31_248, 1);
      heff_take_n(v_x31_248, 3ULL, 2);
      return (g_heff_2ebuild_2edecoder_2etimes_24s636384560x1104891369(v_x_249, v_s_240, v_j_2410));
    }
    default: return heff_nomatch(v_x31_248);
    }
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s175128368x196003177_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s175128368x196003177(a[0], a[1]);
}
Clo g_heff_2ebuild_2edecoder_2etimes_24s1478943154x230515376_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_24s1478943154x230515376_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2etimes_24s1478943154x230515376(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
  } else {
    V v_x3_245 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_p_241), v_p_242));
    V v_x3_2414;
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      v_x3_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x31_246 = heff_field(v_x3_245, 0);
      V v_ru_24x3_245_24Just = heff_take_reuse_n(v_x3_245, 1ULL, 1);
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        V v_x3_249 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_p_241), v_j_248));
        switch (heff_tag_of(v_x3_249)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x3_245_24Just, 1);
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
          v_x3_2414 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_x31_2410 = heff_field(v_x3_249, 0);
          heff_take_n(v_x3_249, 1ULL, 1);
          switch (heff_tag_of(v_x31_2410)) {
          case TAG_MkPair: {
            V v_x_2411 = heff_field(v_x31_2410, 0);
            V v_j_2412 = heff_field(v_x31_2410, 1);
            heff_take_n(v_x31_2410, 3ULL, 2);
            V v_t_2413 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(2, shape_tighter__looser, (V[]){v_x_247, v_x_2411}), v_j_2412});
            v_x3_2414 = heff_tag_at_n(v_ru_24x3_245_24Just, TAG_Just, 1, (V[]){v_t_2413});
            break;
          }
          default: heff_nomatch(v_x31_2410);
          }
          break;
        }
        default: heff_nomatch(v_x3_249);
        }
        break;
      }
      default: heff_nomatch(v_x31_246);
      }
      break;
    }
    default: heff_nomatch(v_x3_245);
    }
    switch (heff_tag_of(v_x3_2414)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x31_2415 = heff_field(v_x3_2414, 0);
      V v_ru_24x3_2414_24Just = heff_take_reuse_n(v_x3_2414, 1ULL, 1);
      switch (heff_tag_of(v_x31_2415)) {
      case TAG_MkPair: {
        V v_x_2416 = heff_field(v_x31_2415, 0);
        V v_j_2417 = heff_field(v_x31_2415, 1);
        V v_ru_24x31_2415_24MkPair = heff_take_reuse_n(v_x31_2415, 3ULL, 2);
        V v_x3_2418 = (g_heff_2ebuild_2edecoder_2etimes_24s1478943154x230515376(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2417));
        switch (heff_tag_of(v_x3_2418)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x3_2414_24Just, 1);
          heff_drop(v_x_2416);
          heff_drop_cell(v_ru_24x31_2415_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2419 = heff_field(v_x3_2418, 0);
          heff_take_n(v_x3_2418, 1ULL, 1);
          switch (heff_tag_of(v_x31_2419)) {
          case TAG_MkPair: {
            V v_x_2420 = heff_field(v_x31_2419, 0);
            V v_j_2421 = heff_field(v_x31_2419, 1);
            heff_take_n(v_x31_2419, 3ULL, 2);
            V v_t_2422 = heff_tag_at_n(v_ru_24x31_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2416, v_x_2420}), v_j_2421});
            return heff_tag_at_n(v_ru_24x3_2414_24Just, TAG_Just, 1, (V[]){v_t_2422});
          }
          default: return heff_nomatch(v_x31_2419);
          }
        }
        default: return heff_nomatch(v_x3_2418);
        }
      }
      default: return heff_nomatch(v_x31_2415);
      }
    }
    default: return heff_nomatch(v_x3_2414);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_24s1478943154x230515376_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2etimes_24s1478943154x230515376(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edecoder_2ebind_24s218177533x1117745540_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s218177533x1117745540_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s218177533x1117745540(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_240), v_i_241));
  V v_x3_247;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    v_x3_247 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_x_246 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_244));
      v_x3_247 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_j_245})});
      break;
    }
    default: heff_nomatch(v_x31_243);
    }
    break;
  }
  default: heff_nomatch(v_x3_242);
  }
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_248 = heff_field(v_x3_247, 0);
    heff_take_n(v_x3_247, 1ULL, 1);
    switch (heff_tag_of(v_x31_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x31_248, 0);
      V v_j_2410 = heff_field(v_x31_248, 1);
      heff_take_n(v_x31_248, 3ULL, 2);
      return (g_heff_2ebuild_2edecoder_2etimes_24s1478943154x230515376(v_x_249, v_s_240, v_j_2410));
    }
    default: return heff_nomatch(v_x31_248);
    }
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s218177533x1117745540_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s218177533x1117745540(a[0], a[1]);
}
Clo g_heff_2ebuild_2edecoder_2etimes_24s1761861291x2079271738_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_24s1761861291x2079271738_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2etimes_24s1761861291x2079271738(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
  } else {
    V v_a_245 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_p_241), v_p_242));
    V v_x3_2414;
    switch (heff_tag_of(v_a_245)) {
    case TAG_Nothing: {
      v_x3_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_a_246 = heff_field(v_a_245, 0);
      V v_ru_24a_245_24Just = heff_take_reuse_n(v_a_245, 1ULL, 1);
      switch (heff_tag_of(v_a_246)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_a_246, 0);
        V v_a_248 = heff_field(v_a_246, 1);
        V v_ru_24a_246_24MkPair = heff_take_reuse_n(v_a_246, 3ULL, 2);
        V v_a_249 = (g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853(heff_dup(v_p_241), v_a_248));
        switch (heff_tag_of(v_a_249)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24a_245_24Just, 1);
          heff_drop(v_a_247);
          heff_drop_cell(v_ru_24a_246_24MkPair, 2);
          v_x3_2414 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_a_2410 = heff_field(v_a_249, 0);
          heff_take_n(v_a_249, 1ULL, 1);
          switch (heff_tag_of(v_a_2410)) {
          case TAG_MkPair: {
            V v_a_2411 = heff_field(v_a_2410, 0);
            V v_a_2412 = heff_field(v_a_2410, 1);
            heff_take_n(v_a_2410, 3ULL, 2);
            V v_t_2413 = heff_tag_at_n(v_ru_24a_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_247, v_a_2411}), v_a_2412});
            v_x3_2414 = heff_tag_at_n(v_ru_24a_245_24Just, TAG_Just, 1, (V[]){v_t_2413});
            break;
          }
          default: heff_nomatch(v_a_2410);
          }
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    default: heff_nomatch(v_a_245);
    }
    switch (heff_tag_of(v_x3_2414)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x31_2415 = heff_field(v_x3_2414, 0);
      V v_ru_24x3_2414_24Just = heff_take_reuse_n(v_x3_2414, 1ULL, 1);
      switch (heff_tag_of(v_x31_2415)) {
      case TAG_MkPair: {
        V v_x_2416 = heff_field(v_x31_2415, 0);
        V v_j_2417 = heff_field(v_x31_2415, 1);
        V v_ru_24x31_2415_24MkPair = heff_take_reuse_n(v_x31_2415, 3ULL, 2);
        V v_x3_2418 = (g_heff_2ebuild_2edecoder_2etimes_24s1761861291x2079271738(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2417));
        switch (heff_tag_of(v_x3_2418)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x3_2414_24Just, 1);
          heff_drop(v_x_2416);
          heff_drop_cell(v_ru_24x31_2415_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2419 = heff_field(v_x3_2418, 0);
          heff_take_n(v_x3_2418, 1ULL, 1);
          switch (heff_tag_of(v_x31_2419)) {
          case TAG_MkPair: {
            V v_x_2420 = heff_field(v_x31_2419, 0);
            V v_j_2421 = heff_field(v_x31_2419, 1);
            heff_take_n(v_x31_2419, 3ULL, 2);
            V v_t_2422 = heff_tag_at_n(v_ru_24x31_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2416, v_x_2420}), v_j_2421});
            return heff_tag_at_n(v_ru_24x3_2414_24Just, TAG_Just, 1, (V[]){v_t_2422});
          }
          default: return heff_nomatch(v_x31_2419);
          }
        }
        default: return heff_nomatch(v_x3_2418);
        }
      }
      default: return heff_nomatch(v_x31_2415);
      }
    }
    default: return heff_nomatch(v_x3_2414);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_24s1761861291x2079271738_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2etimes_24s1761861291x2079271738(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edecoder_2ebind_24s176077469x354005298_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s176077469x354005298_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s176077469x354005298(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_240), v_i_241));
  V v_x3_247;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    v_x3_247 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_x_246 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_244));
      v_x3_247 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_j_245})});
      break;
    }
    default: heff_nomatch(v_x31_243);
    }
    break;
  }
  default: heff_nomatch(v_x3_242);
  }
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_248 = heff_field(v_x3_247, 0);
    heff_take_n(v_x3_247, 1ULL, 1);
    switch (heff_tag_of(v_x31_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x31_248, 0);
      V v_j_2410 = heff_field(v_x31_248, 1);
      heff_take_n(v_x31_248, 3ULL, 2);
      return (g_heff_2ebuild_2edecoder_2etimes_24s1761861291x2079271738(v_x_249, v_s_240, v_j_2410));
    }
    default: return heff_nomatch(v_x31_248);
    }
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s176077469x354005298_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s176077469x354005298(a[0], a[1]);
}
Clo g_heff_2ebuild_2edecoder_2ebind_24s1098195066x1958728779_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s1098195066x1958728779_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s1098195066x1958728779(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_240), v_i_241));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_246 = (g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558(v_x_244));
      return heff_tail(v_t_246, 2, (V[]){v_s_240, v_j_245});
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s1098195066x1958728779_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s1098195066x1958728779(a[0], a[1]);
}
Clo g_heff_2ebuild_2edecoder_2ebind_24s175898238x1158484984_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s175898238x1158484984_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s175898238x1158484984(V v_f_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2ebind_24s175128368x196003177(heff_dup(v_s_241), v_i_242));
  V v_x3_2412;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    v_x3_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    V v_ru_24x3_243_24Just = heff_take_reuse_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_x3_247 = (g_heff_2ebuild_2edecoder_2ebind_24s218177533x1117745540(heff_dup(v_s_241), v_j_246));
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_243_24Just, 1);
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
        v_x3_2412 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_248 = heff_field(v_x3_247, 0);
        heff_take_n(v_x3_247, 1ULL, 1);
        switch (heff_tag_of(v_x31_248)) {
        case TAG_MkPair: {
          V v_x_249 = heff_field(v_x31_248, 0);
          V v_j_2410 = heff_field(v_x31_248, 1);
          heff_take_n(v_x31_248, 3ULL, 2);
          V v_t_2411 = heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(2, shape_groups__above, (V[]){v_x_245, v_x_249}), v_j_2410});
          v_x3_2412 = heff_tag_at_n(v_ru_24x3_243_24Just, TAG_Just, 1, (V[]){v_t_2411});
          break;
        }
        default: heff_nomatch(v_x31_248);
        }
        break;
      }
      default: heff_nomatch(v_x3_247);
      }
      break;
    }
    default: heff_nomatch(v_x31_244);
    }
    break;
  }
  default: heff_nomatch(v_x3_243);
  }
  switch (heff_tag_of(v_x3_2412)) {
  case TAG_Nothing: {
    heff_drop(v_f_240);
    heff_drop(v_s_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2413 = heff_field(v_x3_2412, 0);
    heff_take_n(v_x3_2412, 1ULL, 1);
    switch (heff_tag_of(v_x31_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x31_2413, 0);
      V v_j_2415 = heff_field(v_x31_2413, 1);
      heff_take_n(v_x31_2413, 3ULL, 2);
      return heff_tail(v_f_240, 3, (V[]){v_x_2414, v_s_241, v_j_2415});
    }
    default: return heff_nomatch(v_x31_2413);
    }
  }
  default: return heff_nomatch(v_x3_2412);
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s175898238x1158484984_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s175898238x1158484984(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edecoder_2etimes_24s1655053420x924810089_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_24s1655053420x924810089_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2etimes_24s1655053420x924810089(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
  } else {
    V v_x3_245 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_p_241), v_p_242));
    V v_x3_2414;
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      v_x3_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x31_246 = heff_field(v_x3_245, 0);
      V v_ru_24x3_245_24Just = heff_take_reuse_n(v_x3_245, 1ULL, 1);
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        V v_x3_249 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_p_241), v_j_248));
        switch (heff_tag_of(v_x3_249)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x3_245_24Just, 1);
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
          v_x3_2414 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_x31_2410 = heff_field(v_x3_249, 0);
          heff_take_n(v_x3_249, 1ULL, 1);
          switch (heff_tag_of(v_x31_2410)) {
          case TAG_MkPair: {
            V v_x_2411 = heff_field(v_x31_2410, 0);
            V v_j_2412 = heff_field(v_x31_2410, 1);
            heff_take_n(v_x31_2410, 3ULL, 2);
            V v_t_2413 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_x_2411}), v_j_2412});
            v_x3_2414 = heff_tag_at_n(v_ru_24x3_245_24Just, TAG_Just, 1, (V[]){v_t_2413});
            break;
          }
          default: heff_nomatch(v_x31_2410);
          }
          break;
        }
        default: heff_nomatch(v_x3_249);
        }
        break;
      }
      default: heff_nomatch(v_x31_246);
      }
      break;
    }
    default: heff_nomatch(v_x3_245);
    }
    switch (heff_tag_of(v_x3_2414)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x31_2415 = heff_field(v_x3_2414, 0);
      V v_ru_24x3_2414_24Just = heff_take_reuse_n(v_x3_2414, 1ULL, 1);
      switch (heff_tag_of(v_x31_2415)) {
      case TAG_MkPair: {
        V v_x_2416 = heff_field(v_x31_2415, 0);
        V v_j_2417 = heff_field(v_x31_2415, 1);
        V v_ru_24x31_2415_24MkPair = heff_take_reuse_n(v_x31_2415, 3ULL, 2);
        V v_x3_2418 = (g_heff_2ebuild_2edecoder_2etimes_24s1655053420x924810089(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_2417));
        switch (heff_tag_of(v_x3_2418)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x3_2414_24Just, 1);
          heff_drop(v_x_2416);
          heff_drop_cell(v_ru_24x31_2415_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2419 = heff_field(v_x3_2418, 0);
          heff_take_n(v_x3_2418, 1ULL, 1);
          switch (heff_tag_of(v_x31_2419)) {
          case TAG_MkPair: {
            V v_x_2420 = heff_field(v_x31_2419, 0);
            V v_j_2421 = heff_field(v_x31_2419, 1);
            heff_take_n(v_x31_2419, 3ULL, 2);
            V v_t_2422 = heff_tag_at_n(v_ru_24x31_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2416, v_x_2420}), v_j_2421});
            return heff_tag_at_n(v_ru_24x3_2414_24Just, TAG_Just, 1, (V[]){v_t_2422});
          }
          default: return heff_nomatch(v_x31_2419);
          }
        }
        default: return heff_nomatch(v_x3_2418);
        }
      }
      default: return heff_nomatch(v_x31_2415);
      }
    }
    default: return heff_nomatch(v_x3_2414);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_24s1655053420x924810089_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2etimes_24s1655053420x924810089(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edecoder_2ebind_24s1423786112x2002309168_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s1423786112x2002309168_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s1423786112x2002309168(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_240), v_i_241));
  V v_x3_247;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    v_x3_247 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_x_246 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_244));
      v_x3_247 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_j_245})});
      break;
    }
    default: heff_nomatch(v_x31_243);
    }
    break;
  }
  default: heff_nomatch(v_x3_242);
  }
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_248 = heff_field(v_x3_247, 0);
    heff_take_n(v_x3_247, 1ULL, 1);
    switch (heff_tag_of(v_x31_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x31_248, 0);
      V v_j_2410 = heff_field(v_x31_248, 1);
      heff_take_n(v_x31_248, 3ULL, 2);
      return (g_heff_2ebuild_2edecoder_2etimes_24s1655053420x924810089(v_x_249, v_s_240, v_j_2410));
    }
    default: return heff_nomatch(v_x31_248);
    }
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s1423786112x2002309168_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s1423786112x2002309168(a[0], a[1]);
}
Clo g_heff_2ebuild_2edecoder_2etimes_24s809748896x1244656705_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2etimes_24s809748896x1244656705_entry, 3, 0};

V g_heff_2ebuild_2edecoder_2etimes_24s809748896x1244656705(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_242});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
  } else {
    V v_x3_245 = (g_heff_2ebuild_2ecache_2emeltDef(heff_dup(v_p_241), v_p_242));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop(v_p_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x31_246 = heff_field(v_x3_245, 0);
      V v_ru_24x3_245_24Just = heff_take_reuse_n(v_x3_245, 1ULL, 1);
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        V v_x3_249 = (g_heff_2ebuild_2edecoder_2etimes_24s809748896x1244656705(heff_intSub(v_n_240, MK_INT(1LL)), v_p_241, v_j_248));
        switch (heff_tag_of(v_x3_249)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x3_245_24Just, 1);
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2410 = heff_field(v_x3_249, 0);
          heff_take_n(v_x3_249, 1ULL, 1);
          switch (heff_tag_of(v_x31_2410)) {
          case TAG_MkPair: {
            V v_x_2411 = heff_field(v_x31_2410, 0);
            V v_j_2412 = heff_field(v_x31_2410, 1);
            heff_take_n(v_x31_2410, 3ULL, 2);
            V v_t_2413 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_j_2412});
            return heff_tag_at_n(v_ru_24x3_245_24Just, TAG_Just, 1, (V[]){v_t_2413});
          }
          default: return heff_nomatch(v_x31_2410);
          }
        }
        default: return heff_nomatch(v_x3_249);
        }
      }
      default: return heff_nomatch(v_x31_246);
      }
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
}
V g_heff_2ebuild_2edecoder_2etimes_24s809748896x1244656705_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2etimes_24s809748896x1244656705(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edecoder_2ebind_24s1960447580x1521569455_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edecoder_2ebind_24s1960447580x1521569455_entry, 2, 0};

V g_heff_2ebuild_2edecoder_2ebind_24s1960447580x1521569455(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_240), v_i_241));
  V v_x3_247;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    v_x3_247 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_x_246 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_244));
      v_x3_247 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_j_245})});
      break;
    }
    default: heff_nomatch(v_x31_243);
    }
    break;
  }
  default: heff_nomatch(v_x3_242);
  }
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_248 = heff_field(v_x3_247, 0);
    heff_take_n(v_x3_247, 1ULL, 1);
    switch (heff_tag_of(v_x31_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x31_248, 0);
      V v_j_2410 = heff_field(v_x31_248, 1);
      heff_take_n(v_x31_248, 3ULL, 2);
      return (g_heff_2ebuild_2edecoder_2etimes_24s809748896x1244656705(v_x_249, v_s_240, v_j_2410));
    }
    default: return heff_nomatch(v_x31_248);
    }
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_heff_2ebuild_2edecoder_2ebind_24s1960447580x1521569455_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edecoder_2ebind_24s1960447580x1521569455(a[0], a[1]);
}