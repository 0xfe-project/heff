// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_BadShape 33347
#define TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997 9522
#define TAG_Extra 49222
#define TAG_Many 40086
#define TAG_Missing 63220
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_Rest 61983
#define TAG_Some 35658
#define LBL_ap 9878
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_count 296209705
#define LBL_flag 9641011
#define LBL_flags 298871457
#define LBL_fs 10036
#define LBL_give 9668568
#define LBL_given 299725719
#define LBL_long 9823043
#define LBL_meta 9843404
#define LBL_name 9869138
#define LBL_on 10310
#define LBL_pos 320718
#define LBL_ps 10346
#define LBL_ra 10390
#define LBL_sh 10428
#define LBL_shape 310758331
#define LBL_take 10047822
#define LBL_waiting 1348170899
static uint32_t shape_flags__pos[] = {LBL_flags, LBL_pos};
static uint32_t shape_give__ap__flag__pos[] = {LBL_give, LBL_ap, LBL_flag, LBL_pos};
static uint32_t shape_on__waiting__count__given[] = {LBL_on, LBL_waiting, LBL_count, LBL_given};
static uint32_t shape_sh__ra__on__ps__fs[] = {LBL_sh, LBL_ra, LBL_on, LBL_ps, LBL_fs};
static uint32_t shape_shape__take[] = {LBL_shape, LBL_take};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s1867824208x1412174996_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1220809684x843195562(V, V);
V g_list_2ekeepIf_24s1220809684x843195562_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1220809684x843195562_clo;
V g_list_2ekeepIf_24s44384897x1267641110(V);
V g_list_2ekeepIf_24s44384897x1267641110_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s44384897x1267641110_clo;
V g_list_2ekeepIf_24s920421308x594300259(V, V, V);
V g_list_2ekeepIf_24s920421308x594300259_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s920421308x594300259_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1340051005x157438530(V, V, V, V);
V g_list_2emap_24f1340051005x157438530_entry(V self, V *a);
extern Clo g_list_2emap_24f1340051005x157438530_clo;
V g_list_2emap_24f1340051005x157438530_24f1161082868x102492123(V, V, V, V);
V g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_entry(V self, V *a);
extern Clo g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_clo;
V g_list_2emap_24f755592795x444686035(V, V, V, V, V, V);
V g_list_2emap_24f755592795x444686035_entry(V self, V *a);
extern Clo g_list_2emap_24f755592795x444686035_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1281445768x1036802655(V);
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_clo;
V g_list_2emap_24s2029999044x514618413(V);
V g_list_2emap_24s2029999044x514618413_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_clo;
V g_list_2emap_24s296585291x885335139(V);
V g_list_2emap_24s296585291x885335139_entry(V self, V *a);
extern Clo g_list_2emap_24s296585291x885335139_clo;
V g_list_2emap_24s501902900x1631592417(V, V, V, V);
V g_list_2emap_24s501902900x1631592417_entry(V self, V *a);
extern Clo g_list_2emap_24s501902900x1631592417_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2ecli_2ecandidatesText(V, V);
V g_std_2ecli_2ecandidatesText_entry(V self, V *a);
extern Clo g_std_2ecli_2ecandidatesText_clo;
V g_std_2ecli_2ecellOf(V, V, V, V, V, V);
V g_std_2ecli_2ecellOf_entry(V self, V *a);
extern Clo g_std_2ecli_2ecellOf_clo;
V g_std_2ecli_2ecompleteAt(V, V, V);
V g_std_2ecli_2ecompleteAt_entry(V self, V *a);
extern Clo g_std_2ecli_2ecompleteAt_clo;
V g_std_2ecli_2ecompleteWords(V, V, V);
V g_std_2ecli_2ecompleteWords_entry(V self, V *a);
extern Clo g_std_2ecli_2ecompleteWords_clo;
V g_std_2ecli_2edistance(V, V);
V g_std_2ecli_2edistance_entry(V self, V *a);
extern Clo g_std_2ecli_2edistance_clo;
HeffT2 g_std_2ecli_2edupOf_24cpr(V);
HeffT2 g_std_2ecli_2efirstJust_24s180945488x1856732267_24cpr(V, V);
HeffT2 g_std_2ecli_2eflagProblem_24cpr(V, V);
HeffT2 g_std_2ecli_2egroupsGo_24cpr(V, V);
V g_std_2ecli_2eheadOf(V);
V g_std_2ecli_2eheadOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eheadOf_clo;
V g_std_2ecli_2ehelpOf(V, V);
V g_std_2ecli_2ehelpOf_entry(V self, V *a);
extern Clo g_std_2ecli_2ehelpOf_clo;
V g_std_2ecli_2einitOf(V);
V g_std_2ecli_2einitOf_entry(V self, V *a);
extern Clo g_std_2ecli_2einitOf_clo;
V g_std_2ecli_2einitOf_24dps(V, V);
V g_std_2ecli_2einitOf_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2einitOf_24dps_clo;
V g_std_2ecli_2elastOf(V);
V g_std_2ecli_2elastOf_entry(V self, V *a);
extern Clo g_std_2ecli_2elastOf_clo;
V g_std_2ecli_2elastOr(V, V);
V g_std_2ecli_2elastOr_entry(V self, V *a);
extern Clo g_std_2ecli_2elastOr_clo;
V g_std_2ecli_2elastS(V);
V g_std_2ecli_2elastS_entry(V self, V *a);
extern Clo g_std_2ecli_2elastS_clo;
HeffT2 g_std_2ecli_2elastS_24cpr(V);
V g_std_2ecli_2eline2(V, V);
V g_std_2ecli_2eline2_entry(V self, V *a);
extern Clo g_std_2ecli_2eline2_clo;
HeffT2 g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr(V, V, V, V, V, V, V, V, V);
V g_std_2ecli_2elookupL(V, V);
V g_std_2ecli_2elookupL_entry(V self, V *a);
extern Clo g_std_2ecli_2elookupL_clo;
V g_std_2ecli_2enearest(V, V);
V g_std_2ecli_2enearest_entry(V self, V *a);
extern Clo g_std_2ecli_2enearest_clo;
V g_std_2ecli_2enextGo(V, V, V, V, V, V);
V g_std_2ecli_2enextGo_entry(V self, V *a);
extern Clo g_std_2ecli_2enextGo_clo;
V g_std_2ecli_2enextGo_24dps(V, V, V, V, V, V, V);
V g_std_2ecli_2enextGo_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2enextGo_24dps_clo;
V g_std_2ecli_2eorList(V);
V g_std_2ecli_2eorList_entry(V self, V *a);
extern Clo g_std_2ecli_2eorList_clo;
V g_std_2ecli_2eorList_24acc(V, V);
V g_std_2ecli_2eorList_24acc_entry(V self, V *a);
extern Clo g_std_2ecli_2eorList_24acc_clo;
HeffT2 g_std_2ecli_2eoutcomeOf_24cpr(V, V, V);
HeffT2 g_std_2ecli_2eparse_24cpr(V, V);
HeffT2 g_std_2ecli_2eproblemOf_24cpr(V, V);
HeffT2 g_std_2ecli_2ereadLine_24cpr(V, V, V);
V g_std_2ecli_2ereading_get(void);
V g_std_2ecli_2erestIndex(V, V);
V g_std_2ecli_2erestIndex_entry(V self, V *a);
extern Clo g_std_2ecli_2erestIndex_clo;
HeffT2 g_std_2ecli_2eshapeProblem_24cpr(V);
V g_std_2ecli_2eshells_get(void);
V g_std_2ecli_2eusage(V, V);
V g_std_2ecli_2eusage_entry(V self, V *a);
extern Clo g_std_2ecli_2eusage_clo;
V g_std_2ecli_2ewhereGo(V, V, V, V);
V g_std_2ecli_2ewhereGo_entry(V self, V *a);
extern Clo g_std_2ecli_2ewhereGo_clo;
HeffT2 g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr(V, V);
V g_std_2ecli_2ezshScript(V);
V g_std_2ecli_2ezshScript_entry(V self, V *a);
extern Clo g_std_2ecli_2ezshScript_clo;
Clo g_std_2ecli_2elastS_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elastS_entry, 1, 0};

V g_std_2ecli_2elastS(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_std_2ecli_2elastS_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_std_2ecli_2elastS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2elastS(a0); heff_drop(a0); return r;
}
V g_std_2ecli_2ereading_lam1(V self, V *args);
V g_std_2ecli_2ereading_lam0(V self, V *args); static Clo g_std_2ecli_2ereading_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam0, 1, 0};
V g_std_2ecli_2ereading_lam3(V self, V *args);
V g_std_2ecli_2ereading_lam2(V self, V *args); static Clo g_std_2ecli_2ereading_lam2_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam2, 2, 0};
V g_std_2ecli_2ereading_lam5(V self, V *args);
V g_std_2ecli_2ereading_lam4(V self, V *args); static Clo g_std_2ecli_2ereading_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam4, 1, 0};
V g_std_2ecli_2ereading_lam7(V self, V *args); static Clo g_std_2ecli_2ereading_lam7_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam7, 2, 0};
V g_std_2ecli_2ereading_lam6(V self, V *args); static Clo g_std_2ecli_2ereading_lam6_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam6, 1, 0};

static V g_std_2ecli_2ereading_val;
static HEFF_ONCE g_std_2ecli_2ereading_st;
static V g_std_2ecli_2ereading_init(void) {
  return heff_rec_n(4, shape_give__ap__flag__pos, (V[]){((V)&g_std_2ecli_2ereading_lam0_clo), ((V)&g_std_2ecli_2ereading_lam2_clo), ((V)&g_std_2ecli_2ereading_lam4_clo), ((V)&g_std_2ecli_2ereading_lam6_clo)});
}
V g_std_2ecli_2ereading_get(void) {
  if (HEFF_DONE(g_std_2ecli_2ereading_st)) return g_std_2ecli_2ereading_val;
  return heff_global(&g_std_2ecli_2ereading_val, &g_std_2ecli_2ereading_st, g_std_2ecli_2ereading_init);
}
V g_std_2ecli_2ereading_lam1(V self, V *args) {
  V v_x_242 = args[0];
  V v_x_243 = args[1];
  V v_x_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_242);
  heff_drop(v_x_243);
  return v_x_240;
}
V g_std_2ecli_2ereading_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_t_241 = heff_rec_n(2, shape_flags__pos, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  return heff_rec_n(2, shape_shape__take, (V[]){v_t_241, heff_clo_n(g_std_2ecli_2ereading_lam1, 2, 1, (V[]){v_x_240})});
}
V g_std_2ecli_2ereading_lam3(V self, V *args) {
  V v_groups_2412 = args[0];
  V v_fl_2413 = args[1];
  V v_shape_248 = heff_env(self)[0];
  V v_take_247 = heff_env(self)[1];
  V v_take_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_shape_248, 1, 2); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2415 = (g_list_2edrop(v_t_2414, v_groups_2412));
  V v_t_2416 = heff_tr(heff_call(v_take_247, 2, (V[]){v_t_2415, heff_dup(v_fl_2413)}));
  V f_ = v_take_249;
  heff_room[0] = v_groups_2412;
  heff_room[1] = v_fl_2413;
  heff_room[2] = v_t_2416;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_std_2ecli_2ereading_lam2(V self, V *args) {
  V v_f_244 = args[0];
  V v_x_245 = args[1];
  V v_shape_246 = heff_take_field(v_x_245, 0);
  V v_take_247 = heff_get_n(v_x_245, 1, 2);
  V v_shape_248 = heff_take_field(v_f_244, 0);
  V v_take_249 = heff_get_n(v_f_244, 1, 2);
  V v_t_2410 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_shape_248, 0)), heff_take_field(v_shape_246, 0)));
  V v_t_2411 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_shape_248, 1)), heff_get_n(v_shape_246, 1, 2)));
  return heff_rec_n(2, shape_shape__take, (V[]){heff_rec_n(2, shape_flags__pos, (V[]){v_t_2410, v_t_2411}), heff_clo_n(g_std_2ecli_2ereading_lam3, 2, 3, (V[]){v_shape_248, v_take_247, v_take_249})});
}
V g_std_2ecli_2ereading_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_given_2421 = args[1];
  V v_fl_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2420);
  return ({ V b_0 = heff_get_n(v_fl_2417, 0, 8); V a_1 = v_given_2421; V r_ = (g_std_2ecli_2elookupL(b_0, a_1)); heff_drop(b_0); heff_drop(v_given_2421); r_; });
}
V g_std_2ecli_2ereading_lam4(V self, V *args) {
  V v_fl_2417 = args[0];
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_fl_2417), NTAG(TAG_Nil)});
  V v_t_2419 = heff_rec_n(2, shape_flags__pos, (V[]){v_t_2418, NTAG(TAG_Nil)});
  return heff_rec_n(2, shape_shape__take, (V[]){v_t_2419, heff_clo_n(g_std_2ecli_2ereading_lam5, 2, 1, (V[]){v_fl_2417})});
}
V g_std_2ecli_2ereading_lam7(V self, V *args) {
  V v_groups_2425 = args[0];
  V v_x_2426 = args[1];
  heff_drop(v_x_2426);
  switch (heff_tag_of(v_groups_2425)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2427 = heff_field(v_groups_2425, 0);
    heff_take_n(v_groups_2425, 1ULL, 2);
    return v_x_2427;
  }
  default: return heff_nomatch(v_groups_2425);
  }
}
V g_std_2ecli_2ereading_lam6(V self, V *args) {
  V v_p_2422 = args[0];
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_p_2422, NTAG(TAG_Nil)});
  V v_t_2424 = heff_rec_n(2, shape_flags__pos, (V[]){NTAG(TAG_Nil), v_t_2423});
  return heff_rec_n(2, shape_shape__take, (V[]){v_t_2424, ((V)&g_std_2ecli_2ereading_lam7_clo)});
}

HeffT2 g_std_2ecli_2edupOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_241)}));
    V v_t_244 = (g_list_2eany(v_t_243, v_rest_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_241)}});
    } else {
      heff_drop(v_t_244);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_std_2ecli_2ecellOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecellOf_entry, 6, 0};

V g_std_2ecli_2ecellOf(V v_a_240, V v_box_24c_241, V v_up_242, V v_diag_243, V v_left_244, V v_i_245) {
  int64_t v_c_241 = heff_unbox_word(v_box_24c_241);
top: ;
  V v_x_246 = heff_intAdd(v_up_242, MK_INT(1LL));
  V v_y_247 = heff_intAdd(v_left_244, MK_INT(1LL));
  V v_x_248;
  if (heff_intLe_c_lent(v_x_246, v_y_247, 0)) {
    heff_drop(v_y_247);
    v_x_248 = v_x_246;
  } else {
    heff_drop(v_x_246);
    v_x_248 = v_y_247;
  }
  V v_t_249 = heff_strByteAt(heff_dup(v_a_240), heff_intSub(v_i_245, MK_INT(1LL)));
  V v_t_2410;
  if ((heff_unbox_word(v_t_249) == v_c_241)) {
    v_t_2410 = MK_INT(0LL);
  } else {
    v_t_2410 = MK_INT(1LL);
  }
  V v_y_2411 = heff_intAdd(v_diag_243, v_t_2410);
  if (heff_intLe_c_lent(v_x_248, v_y_2411, 0)) {
    heff_drop(v_y_2411);
    return v_x_248;
  } else {
    heff_drop(v_x_248);
    return v_y_2411;
  }
}
V g_std_2ecli_2ecellOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2ecellOf(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
Clo g_std_2ecli_2enextGo_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2enextGo_entry, 6, 0};

V g_std_2ecli_2enextGo(V v_a_240, V v_c_241, V v_x3_242, V v_diag_243, V v_left_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_241);
    heff_drop(v_diag_243);
    heff_drop(v_left_244);
    heff_drop(v_i_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_up_246 = heff_field(v_x3_242, 0);
    V v_ups_247 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_248 = (g_std_2ecli_2ecellOf(v_a_240, heff_dup(v_c_241), heff_dup(v_up_246), heff_dup(v_diag_243), heff_dup(v_left_244), heff_dup(v_i_245)));
    V v_cell_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_t_2410 = (g_std_2ecli_2ecellOf(v_a_240, heff_dup(v_c_241), heff_dup(v_up_246), v_diag_243, v_left_244, heff_dup(v_i_245)));
    V v_u_2411 = (g_std_2ecli_2enextGo_24dps(v_a_240, v_c_241, v_ups_247, v_up_246, v_t_2410, heff_box_word((heff_unbox_word(v_i_245) + ((int64_t)1ULL))), heff_dup(v_cell_249)));
    heff_drop(v_u_2411);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2ecli_2enextGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2enextGo(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
Clo g_std_2ecli_2elastOr_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elastOr_entry, 2, 0};

V g_std_2ecli_2elastOr(V v_d_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_d_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop(v_d_240);
      return heff_dup(v_x_242);
    }
    case TAG_Cons: {
      V t_0 = v_d_240;
      V t_1 = v_x22_243;
      v_d_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2elastOr_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2elastOr(a[0], a1); heff_drop(a1); return r;
}
V g_std_2ecli_2enearest_lam0(V self, V *args);
Clo g_std_2ecli_2enearest_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2enearest_entry, 2, 0};

V g_std_2ecli_2enearest(V v_sh_240, V v_x_241) {
top: ;
  return ({ V a_0 = heff_clo_n(g_std_2ecli_2enearest_lam0, 2, 1, (V[]){heff_dup(v_x_241)}); V a_1 = NTAG(TAG_Nothing); V b_2 = heff_get_n(v_sh_240, 0, 2); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_std_2ecli_2enearest_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2enearest(a[0], a1); heff_drop(a1); return r;
}
V g_std_2ecli_2enearest_lam0(V self, V *args) {
  V v_best_242 = args[0];
  V v_f_243 = args[1];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_std_2ecli_2edistance(heff_rfield(v_f_243, 0), v_x_241));
  if ((heff_intLe_c_lent(v_t_244, MK_INT(2LL), 2) && (heff_unbox_word(heff_strLength_lent(v_x_241, 0)) <= ((int64_t)16ULL)))) {
    heff_drop(v_t_244);
    switch (heff_tag_of(v_best_242)) {
    case TAG_Nothing: {
      heff_drop(v_x_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_f_243, 0, 8)});
    }
    case TAG_Just: {
      V v_b_245 = heff_dup(heff_field(v_best_242, 0));
      V v_t_246 = (g_std_2ecli_2edistance(heff_rfield(v_f_243, 0), v_x_241));
      V v_t_247 = ({ V a_0 = v_b_245; V a_1 = v_x_241; V r_ = (g_std_2ecli_2edistance(a_0, a_1)); heff_drop(v_b_245); heff_drop(v_x_241); r_; });
      if (heff_intLt_c(v_t_246, v_t_247)) {
        heff_drop_tag(v_best_242, 1);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_f_243, 0, 8)});
      } else {
        heff_drop_rec(v_f_243, 8);
        return v_best_242;
      }
    }
    default: return heff_nomatch(v_best_242);
    }
  } else {
    heff_drop_rec(v_f_243, 8);
    heff_drop(v_x_241);
    heff_drop(v_t_244);
    return v_best_242;
  }
}
HEFF_LIT(g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str0, 0, "");
HEFF_LIT(g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str1, 0, "");
HEFF_LIT(g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str2, 0, "");
HEFF_LIT(g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str3, 0, "");
HEFF_LIT(g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str4, 0, "");
HEFF_LIT(g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str5, 0, "");

HeffT2 g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr(V v_at_240, V v_x3_241) {
top: ;
  return (g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr(NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997), ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str0), ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str1), ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str2), ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str3), ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str4), ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str5), v_at_240, v_x3_241));
}
HEFF_LIT(g_std_2ecli_2egroupsGo_24cpr_str0, 3, "...");

HeffT2 g_std_2ecli_2egroupsGo_24cpr(V v_x1_240, V v_ws_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_ws_241)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
    }
    case TAG_Cons: {
      V v_w_242 = heff_field(v_ws_241, 0);
      heff_take_n(v_ws_241, 1ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_Extra, 1, (V[]){v_w_242})}});
    }
    default: return ((HeffT2){{heff_nomatch(v_ws_241)}});
    }
  }
  case TAG_Cons: {
    V v_x11_244 = heff_field(v_x1_240, 0);
    V v_ps_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_arity_246 = heff_take_field(v_x11_244, 1);
    V v_meta_247 = heff_get_n(v_x11_244, 0, 3);
    V v_arity_248 = v_arity_246;
    V v_m_249 = v_meta_247;
    switch (heff_tag_of(v_arity_248)) {
    case TAG_One: {
      switch (heff_tag_of(v_ws_241)) {
      case TAG_Nil: {
        heff_drop(v_ps_245);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_Missing, 1, (V[]){v_m_249})}});
      }
      case TAG_Cons: {
        V v_w_2410 = heff_field(v_ws_241, 0);
        V v_ws2_2411 = heff_field(v_ws_241, 1);
        V v_ru_24ws_241_24Cons = heff_take_reuse_n(v_ws_241, 3ULL, 2);
        heff_drop(v_m_249);
        HeffT2 v_t_2412 = (g_std_2ecli_2egroupsGo_24cpr(v_ps_245, v_ws2_2411));
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_w_2410);
            heff_drop_cell(v_ru_24ws_241_24Cons, 2);
            V v_p_2415 = v_field_2414;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2415}});
          } else {
            V v_gs_2416 = v_field_2414;
            V v_t_2417 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_w_2410, NTAG(TAG_Nil)});
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24ws_241_24Cons, TAG_Cons, 2, (V[]){v_t_2417, v_gs_2416})}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_ws_241)}});
      }
    }
    case TAG_Optional: {
      heff_drop(v_m_249);
      switch (heff_tag_of(v_ws_241)) {
      case TAG_Nil: {
        HeffT2 v_t_2418 = (g_std_2ecli_2egroupsGo_24cpr(v_ps_245, NTAG(TAG_Nil)));
        {
          V v_field_2420 = v_t_2418.f[1];
          int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
          if ((v_tag_2419 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            V v_p_2421 = v_field_2420;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2421}});
          } else {
            V v_gs_2422 = v_field_2420;
            V v_t_2423 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_gs_2422});
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2423}});
          }
        }
      }
      case TAG_Cons: {
        V v_w_2424 = heff_field(v_ws_241, 0);
        V v_ws2_2425 = heff_field(v_ws_241, 1);
        V v_ru_24ws_241_24Cons = heff_take_reuse_n(v_ws_241, 3ULL, 2);
        HeffT2 v_t_2426 = (g_std_2ecli_2egroupsGo_24cpr(v_ps_245, v_ws2_2425));
        {
          V v_field_2428 = v_t_2426.f[1];
          int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
          if ((v_tag_2427 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_w_2424);
            heff_drop_cell(v_ru_24ws_241_24Cons, 2);
            V v_p_2429 = v_field_2428;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2429}});
          } else {
            V v_gs_2430 = v_field_2428;
            V v_t_2431 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_w_2424, NTAG(TAG_Nil)});
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24ws_241_24Cons, TAG_Cons, 2, (V[]){v_t_2431, v_gs_2430})}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_ws_241)}});
      }
    }
    case TAG_Many: {
      heff_drop(v_m_249);
      HeffT2 v_t_2432 = (g_std_2ecli_2egroupsGo_24cpr(v_ps_245, NTAG(TAG_Nil)));
      {
        V v_field_2434 = v_t_2432.f[1];
        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
        if ((v_tag_2433 == ((int64_t)0ULL))) {
          heff_drop(v_ws_241);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          V v_p_2435 = v_field_2434;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2435}});
        } else {
          V v_gs_2436 = v_field_2434;
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_ws_241, v_gs_2436})}});
        }
      }
    }
    case TAG_Some: {
      switch (heff_tag_of(v_ws_241)) {
      case TAG_Nil: {
        heff_drop(v_ps_245);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V v_f_2437 = heff_tag_n(TAG_Missing, 1, (V[]){heff_strAppend(v_m_249, ((V)&g_std_2ecli_2egroupsGo_24cpr_str0))});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2437}});
      }
      case TAG_Cons: {
        heff_drop(v_m_249);
        HeffT2 v_t_2440 = (g_std_2ecli_2egroupsGo_24cpr(v_ps_245, NTAG(TAG_Nil)));
        {
          V v_field_2442 = v_t_2440.f[1];
          int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
          if ((v_tag_2441 == ((int64_t)0ULL))) {
            heff_drop_tag(v_ws_241, 2);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            V v_p_2443 = v_field_2442;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2443}});
          } else {
            V v_gs_2444 = v_field_2442;
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_ws_241, v_gs_2444})}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_ws_241)}});
      }
    }
    case TAG_Rest: {
      heff_drop(v_m_249);
      HeffT2 v_t_2445 = (g_std_2ecli_2egroupsGo_24cpr(v_ps_245, NTAG(TAG_Nil)));
      {
        V v_field_2447 = v_t_2445.f[1];
        int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
        if ((v_tag_2446 == ((int64_t)0ULL))) {
          heff_drop(v_ws_241);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          V v_p_2448 = v_field_2447;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2448}});
        } else {
          V v_gs_2449 = v_field_2447;
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_ws_241, v_gs_2449})}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_arity_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_std_2ecli_2efirstJust_24s180945488x1856732267_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    HeffT2 v_t_244 = (g_std_2ecli_2eflagProblem_24cpr(heff_dup(v_lit_240), heff_dup(v_x_242)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_lit_240);
        V v_y_247 = v_field_246;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_y_247}});
      } else {
        heff_drop(v_field_246);
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_std_2ecli_2eparse_24cpr_lam0(V self, V *args);

HeffT2 g_std_2ecli_2eparse_24cpr(V v_t_240, V v_ws_241) {
top: ;
  V v_t_242 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
  HeffT2 v_t_243 = (g_std_2ecli_2eshapeProblem_24cpr(heff_get_n(v_t_242, 0, 2)));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop(v_t_240);
      heff_drop(v_ws_241);
      V v_why_246 = v_field_245;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_BadShape, 1, (V[]){v_why_246})}});
    } else {
      heff_drop(v_field_245);
      V v_t_247 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
      V v_sh_248 = heff_get_n(v_t_247, 0, 2);
      V v_t_249 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_248, 1), MK_INT(0LL)));
      V v_at_2410 = heff_rec_n(5, shape_sh__ra__on__ps__fs, (V[]){v_sh_248, v_t_249, NTAG(TAG_True), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      HeffT2 v_t_2411 = (g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr(v_at_2410, v_ws_241));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          heff_drop(v_t_240);
          V v_p_2414 = v_field_2413;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2414}});
        } else {
          V v_sp_2415 = v_field_2413;
          V v_flags_2416 = heff_take_field(v_sp_2415, 1);
          V v_pos_2417 = heff_get_n(v_sp_2415, 0, 2);
          V v_t_2418 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_t_2419 = heff_get_n(heff_get_n(v_t_2418, 0, 2), 0, 2);
          HeffT2 v_t_2420 = ({ V a_0 = heff_dup(v_flags_2416); V a_1 = v_t_2419; HeffT2 r_ = (g_std_2ecli_2efirstJust_24s180945488x1856732267_24cpr(a_0, a_1)); heff_drop(v_t_2419); r_; });
          {
            V v_field_2422 = v_t_2420.f[1];
            int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
            if ((v_tag_2421 == ((int64_t)0ULL))) {
              heff_drop(v_t_240);
              heff_drop(v_flags_2416);
              heff_drop(v_pos_2417);
              V v_p_2423 = v_field_2422;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2423}});
            } else {
              heff_drop(v_field_2422);
              V v_t_2424 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
              V v_t_2425 = heff_get_n(heff_get_n(v_t_2424, 0, 2), 1, 2);
              HeffT2 v_t_2426 = (g_std_2ecli_2egroupsGo_24cpr(v_t_2425, v_pos_2417));
              {
                V v_field_2428 = v_t_2426.f[1];
                int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
                if ((v_tag_2427 == ((int64_t)0ULL))) {
                  heff_drop(v_t_240);
                  heff_drop(v_flags_2416);
                  V v_p_2429 = v_field_2428;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2429}});
                } else {
                  V v_gs_2430 = v_field_2428;
                  V v_t_2431 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
                  V v_t_2432 = heff_tr(heff_call(v_t_240, 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
                  V v_t_2433 = heff_get_n(heff_get_n(v_t_2432, 0, 2), 0, 2);
                  V v_t_2437 = (g_list_2emap(heff_clo_n(g_std_2ecli_2eparse_24cpr_lam0, 1, 1, (V[]){v_flags_2416}), v_t_2433));
                  V v_f_2438 = heff_tr(heff_call(heff_get_n(v_t_2431, 1, 2), 2, (V[]){v_gs_2430, v_t_2437}));
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2438}});
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_std_2ecli_2eparse_24cpr_lam0(V self, V *args) {
  V v_f_2434 = args[0];
  V v_flags_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = (g_list_2ekeepIf_24s1220809684x843195562(heff_rfield(v_f_2434, 0), v_flags_2416));
  V v_t_2436 = (g_list_2emap_24s1173914895x100384474(v_t_2435));
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2434, 0, 8), v_t_2436});
}

HeffT2 g_std_2ecli_2eproblemOf_24cpr(V v_sh_240, V v_ws_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2ecli_2eshapeProblem_24cpr(heff_dup(v_sh_240)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop_rec(v_sh_240, 2);
      heff_drop(v_ws_241);
      V v_why_245 = v_field_244;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_BadShape, 1, (V[]){v_why_245})}});
    } else {
      heff_drop(v_field_244);
      V v_t_246 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_240, 1), MK_INT(0LL)));
      V v_at_247 = heff_rec_n(5, shape_sh__ra__on__ps__fs, (V[]){heff_dup(v_sh_240), v_t_246, NTAG(TAG_True), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      HeffT2 v_t_248 = (g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr(v_at_247, v_ws_241));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          heff_drop_rec(v_sh_240, 2);
          V v_p_2411 = v_field_2410;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2411}});
        } else {
          V v_sp_2412 = v_field_2410;
          V v_flags_2413 = heff_take_field(v_sp_2412, 1);
          V v_pos_2414 = heff_get_n(v_sp_2412, 0, 2);
          HeffT2 v_t_2415 = (g_std_2ecli_2efirstJust_24s180945488x1856732267_24cpr(v_flags_2413, heff_rfield(v_sh_240, 0)));
          {
            V v_field_2417 = v_t_2415.f[1];
            int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
            if ((v_tag_2416 == ((int64_t)0ULL))) {
              heff_drop_rec(v_sh_240, 2);
              heff_drop(v_pos_2414);
              V v_p_2418 = v_field_2417;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2418}});
            } else {
              heff_drop(v_field_2417);
              HeffT2 v_t_2419 = (g_std_2ecli_2egroupsGo_24cpr(heff_get_n(v_sh_240, 1, 2), v_pos_2414));
              {
                V v_field_2421 = v_t_2419.f[1];
                int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
                if ((v_tag_2420 == ((int64_t)0ULL))) {
                  V v_p_2422 = v_field_2421;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2422}});
                } else {
                  V v_gs_2423 = v_field_2421;
                  heff_drop(v_gs_2423);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
          }
        }
      }
    }
  }
}
HEFF_LIT(g_std_2ecli_2eheadOf_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eheadOf_str1, 1, " ");
HEFF_LIT(g_std_2ecli_2eheadOf_str2, 0, "");
HEFF_LIT(g_std_2ecli_2eheadOf_str3, 0, "");
HEFF_LIT(g_std_2ecli_2eheadOf_str4, 1, " ");
HEFF_LIT(g_std_2ecli_2eheadOf_str5, 1, " ");
Clo g_std_2ecli_2eheadOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eheadOf_entry, 1, 0};

V g_std_2ecli_2eheadOf(V v_k_240) {
top: ;
  V v_args_241 = heff_take_field(v_k_240, 3);
  V v_name_242 = heff_get_n(v_k_240, 0, 4);
  V v_t_243 = heff_tr(heff_call(heff_dup(v_args_241), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
  V v_sh_244 = heff_get_n(v_t_243, 0, 2);
  V v_pos_245 = heff_take_field(v_sh_244, 1);
  V v_flags_246 = heff_get_n(v_sh_244, 0, 2);
  V v_t_247 = (g_list_2emap_24s2029999044x514618413(v_pos_245));
  V v_t_248 = (g_list_2emap_24s1281445768x1036802655(v_flags_246));
  V v_xs_249 = (g_prelude_2e_2b_2b(v_t_247, v_t_248));
  V v_t_2412;
  switch (heff_tag_of(v_xs_249)) {
  case TAG_Nil: {
    v_t_2412 = ((V)&g_std_2ecli_2eheadOf_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_xs_249, 0);
    V v_xs_2411 = heff_field(v_xs_249, 1);
    heff_take_n(v_xs_249, 3ULL, 2);
    v_t_2412 = ({ V a_0 = ((V)&g_std_2ecli_2eheadOf_str1); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
    break;
  }
  default: heff_nomatch(v_xs_249);
  }
  if (heff_strEq_c(v_t_2412, ((V)&g_std_2ecli_2eheadOf_str2))) {
    heff_drop(v_args_241);
    return v_name_242;
  } else {
    V v_t_2413 = heff_tr(heff_call(v_args_241, 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
    V v_sh_2414 = heff_get_n(v_t_2413, 0, 2);
    V v_pos_2415 = heff_take_field(v_sh_2414, 1);
    V v_flags_2416 = heff_get_n(v_sh_2414, 0, 2);
    V v_t_2417 = (g_list_2emap_24s2029999044x514618413(v_pos_2415));
    V v_t_2418 = (g_list_2emap_24s1281445768x1036802655(v_flags_2416));
    V v_xs_2419 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2418));
    V v_t_2422;
    switch (heff_tag_of(v_xs_2419)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_std_2ecli_2eheadOf_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_xs_2419, 0);
      V v_xs_2421 = heff_field(v_xs_2419, 1);
      heff_take_n(v_xs_2419, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_std_2ecli_2eheadOf_str4); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_xs_2419);
    }
    return heff_strAppend(heff_strAppend(v_name_242, ((V)&g_std_2ecli_2eheadOf_str5)), v_t_2422);
  }
}
V g_std_2ecli_2eheadOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eheadOf(a[0]);
}
HEFF_LIT(g_std_2ecli_2eusage_str0, 14, "help [COMMAND]");
HEFF_LIT(g_std_2ecli_2eusage_str1, 26, "this, or a command's flags");
HEFF_LIT(g_std_2ecli_2eusage_str2, 17, "completions SHELL");
HEFF_LIT(g_std_2ecli_2eusage_str3, 48, "a completion script for SHELL: fish, bash or zsh");
HEFF_LIT(g_std_2ecli_2eusage_str4, 7, "usage: ");
HEFF_LIT(g_std_2ecli_2eusage_str5, 12, " COMMAND ...");
HEFF_LIT(g_std_2ecli_2eusage_str6, 1, "\012");
HEFF_LIT(g_std_2ecli_2eusage_str7, 0, "");
HEFF_LIT(g_std_2ecli_2eusage_str8, 1, "\012");
Clo g_std_2ecli_2eusage_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eusage_entry, 2, 0};

V g_std_2ecli_2eusage(V v_prog_240, V v_cs_241) {
top: ;
  V v_t_242 = (g_list_2ekeepIf_24s44384897x1267641110(v_cs_241));
  V v_t_243 = (g_list_2emap_24s296585291x885335139(v_t_242));
  V v_t_244 = (g_std_2ecli_2eline2(((V)&g_std_2ecli_2eusage_str0), ((V)&g_std_2ecli_2eusage_str1)));
  V v_t_245 = (g_std_2ecli_2eline2(((V)&g_std_2ecli_2eusage_str2), ((V)&g_std_2ecli_2eusage_str3)));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_ys_247 = (g_prelude_2e_2b_2b(v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246})));
  V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2eusage_str4), v_prog_240), ((V)&g_std_2ecli_2eusage_str5));
  V v_t_249 = ({ V a_0 = ((V)&g_std_2ecli_2eusage_str6); V a_1 = v_t_248; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2eusage_str7), v_ys_247}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  return heff_strAppend(v_t_249, ((V)&g_std_2ecli_2eusage_str8));
}
V g_std_2ecli_2eusage_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eusage(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2eorList_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eorList_str1, 4, " or ");
HEFF_LIT(g_std_2ecli_2eorList_str2, 2, ", ");
Clo g_std_2ecli_2eorList_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eorList_entry, 1, 0};

V g_std_2ecli_2eorList(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_std_2ecli_2eorList_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_Cons: {
          V v_y_245 = heff_field(v_x12_242, 0);
          return heff_strAppend(heff_strAppend(heff_dup(v_x_241), ((V)&g_std_2ecli_2eorList_str1)), heff_dup(v_y_245));
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_Cons: {
        V v_s_249 = heff_strAppend(heff_dup(v_x_241), ((V)&g_std_2ecli_2eorList_str2));
        return (g_std_2ecli_2eorList_24acc(v_x12_242, v_s_249));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2eorList_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2eorList(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2eshells_str0, 3, "zsh");
HEFF_LIT(g_std_2ecli_2eshells_str1, 4, "fish");
HEFF_LIT(g_std_2ecli_2eshells_str2, 4, "bash");

static V g_std_2ecli_2eshells_val;
static HEFF_ONCE g_std_2ecli_2eshells_st;
static V g_std_2ecli_2eshells_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2eshells_str0), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2eshells_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2eshells_str2), v_t_240})});
}
V g_std_2ecli_2eshells_get(void) {
  if (HEFF_DONE(g_std_2ecli_2eshells_st)) return g_std_2ecli_2eshells_val;
  return heff_global(&g_std_2ecli_2eshells_val, &g_std_2ecli_2eshells_st, g_std_2ecli_2eshells_init);
}
HEFF_LIT(g_std_2ecli_2ecompleteWords_str0, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str1, 1, "\011");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str2, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str3, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str4, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str5, 4, "help");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str6, 11, "completions");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str7, 29, "a completion script for SHELL");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str8, 4, "help");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str9, 26, "this, or a command's flags");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str10, 11, "completions");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str11, 29, "a completion script for SHELL");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str12, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str13, 1, "\011");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str14, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str15, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str16, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str17, 4, "help");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str18, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str19, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str20, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str21, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str22, 11, "completions");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str23, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str24, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str25, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str26, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str27, 0, "");
Clo g_std_2ecli_2ecompleteWords_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecompleteWords_entry, 3, 0};

V g_std_2ecli_2ecompleteWords(V v_cs_240, V v_x2_241, V v_cur_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_cs_243 = v_cs_240;
    V v_cur_244 = v_cur_242;
    V v_x2_245 = ({ V b_0 = ((V)&g_std_2ecli_2ecompleteWords_str0); V a_1 = ((V)&g_std_2ecli_2ecompleteWords_str1); V a_2 = ((V)&g_std_2ecli_2ecompleteWords_str2); V b_3 = MK_INT(0LL); V a_4 = v_cur_244; V a_5 = v_cs_243; V r_ = (g_list_2emap_24f755592795x444686035(b_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_0); heff_drop(b_3); r_; });
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_std_2ecli_2ecompleteWords_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_std_2ecli_2ecompleteWords_str4); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_249 = heff_strSlice(((V)&g_std_2ecli_2ecompleteWords_str5), MK_INT(0LL), heff_strLength_lent(v_cur_244, 0));
    V v_xs_2413;
    if (heff_strEq_c_lent(v_t_249, v_cur_244, 1)) {
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_std_2ecli_2ecompleteWords_str6), ((V)&g_std_2ecli_2ecompleteWords_str7)}), NTAG(TAG_Nil)});
      V v_t_2411 = ({ V b_0 = MK_INT(0LL); V a_1 = v_cur_244; V a_2 = v_t_2410; V r_ = (g_list_2ekeepIf_24s920421308x594300259(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_cur_244); r_; });
      v_xs_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_std_2ecli_2ecompleteWords_str8), ((V)&g_std_2ecli_2ecompleteWords_str9)}), v_t_2411});
    } else {
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_std_2ecli_2ecompleteWords_str10), ((V)&g_std_2ecli_2ecompleteWords_str11)}), NTAG(TAG_Nil)});
      v_xs_2413 = ({ V b_0 = MK_INT(0LL); V a_1 = v_cur_244; V a_2 = v_t_2412; V r_ = (g_list_2ekeepIf_24s920421308x594300259(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_cur_244); r_; });
    }
    V v_x2_2414 = ({ V b_0 = ((V)&g_std_2ecli_2ecompleteWords_str12); V a_1 = ((V)&g_std_2ecli_2ecompleteWords_str13); V a_2 = ((V)&g_std_2ecli_2ecompleteWords_str14); V a_3 = v_xs_2413; V r_ = (g_list_2emap_24s501902900x1631592417(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
    V v_t_2417;
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_std_2ecli_2ecompleteWords_str15);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      v_t_2417 = ({ V a_0 = ((V)&g_std_2ecli_2ecompleteWords_str16); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2414);
    }
    return heff_strAppend(v_t_248, v_t_2417);
  }
  case TAG_Cons: {
    V v_x21_2418 = heff_field(v_x2_241, 0);
    V v_x22_2419 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x21_2418, ((V)&g_std_2ecli_2ecompleteWords_str17), 2)) {
      switch (heff_tag_of(v_x22_2419)) {
      case TAG_Nil: {
        V v_x2_2420 = ({ V a_0 = ((V)&g_std_2ecli_2ecompleteWords_str18); V b_1 = MK_INT(0LL); V a_2 = v_cur_242; V a_3 = v_cs_240; V r_ = (g_list_2emap_24f1340051005x157438530_24f1161082868x102492123(a_0, b_1, a_2, a_3)); heff_drop(b_1); heff_drop(v_cur_242); r_; });
        switch (heff_tag_of(v_x2_2420)) {
        case TAG_Nil: {
          return ((V)&g_std_2ecli_2ecompleteWords_str19);
        }
        case TAG_Cons: {
          V v_x_2421 = heff_field(v_x2_2420, 0);
          V v_xs_2422 = heff_field(v_x2_2420, 1);
          heff_take_n(v_x2_2420, 3ULL, 2);
          return ({ V a_0 = ((V)&g_std_2ecli_2ecompleteWords_str20); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        }
        default: return heff_nomatch(v_x2_2420);
        }
      }
      case TAG_Cons: {
        HeffT2 v_t_2425 = ({ V a_0 = v_x21_2418; V a_1 = v_cs_240; HeffT2 r_ = (g_list_2efind_24s1867824208x1412174996_24cpr(a_0, a_1)); heff_drop(v_cs_240); r_; });
        {
          V v_field_2427 = v_t_2425.f[1];
          int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
          if ((v_tag_2426 == ((int64_t)0ULL))) {
            V v_k_2428 = v_field_2427;
            V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_2428, 3)), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
            V v_t_2430 = heff_tr(heff_call(heff_get_n(v_k_2428, 3, 4), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
            V v_sh_2431 = heff_get_n(v_t_2430, 0, 2);
            V v_t_2432 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_2431, 1), MK_INT(0LL)));
            V v_t_2433 = heff_rec_n(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_True), NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil)});
            V v_t_2434 = (g_std_2ecli_2ewhereGo(heff_dup(v_sh_2431), v_t_2432, v_t_2433, heff_dup(v_x22_2419)));
            V v_t_2435 = ({ V a_0 = v_sh_2431; V a_1 = v_t_2434; V a_2 = v_cur_242; V r_ = (g_std_2ecli_2ecompleteAt(a_0, a_1, a_2)); heff_drop(v_cur_242); r_; });
            return ({ V a_0 = heff_get_n(v_t_2429, 0, 2); V a_1 = v_t_2435; V r_ = (g_std_2ecli_2ecandidatesText(a_0, a_1)); heff_drop(v_t_2435); r_; });
          } else {
            heff_drop(v_cur_242);
            heff_drop(v_field_2427);
            return ((V)&g_std_2ecli_2ecompleteWords_str21);
          }
        }
      }
      default: return heff_nomatch(v_x22_2419);
      }
    } else {
      if (heff_strEq_c_lent(v_x21_2418, ((V)&g_std_2ecli_2ecompleteWords_str22), 2)) {
        switch (heff_tag_of(v_x22_2419)) {
        case TAG_Nil: {
          heff_drop(v_cs_240);
          V v_x2_2436 = ({ V a_0 = ((V)&g_std_2ecli_2ecompleteWords_str23); V b_1 = MK_INT(0LL); V a_2 = v_cur_242; V a_3 = heff_dup(g_std_2ecli_2eshells_get()); V r_ = (g_list_2emap_24f1340051005x157438530(a_0, b_1, a_2, a_3)); heff_drop(b_1); heff_drop(v_cur_242); r_; });
          switch (heff_tag_of(v_x2_2436)) {
          case TAG_Nil: {
            return ((V)&g_std_2ecli_2ecompleteWords_str24);
          }
          case TAG_Cons: {
            V v_x_2437 = heff_field(v_x2_2436, 0);
            V v_xs_2438 = heff_field(v_x2_2436, 1);
            heff_take_n(v_x2_2436, 3ULL, 2);
            return ({ V a_0 = ((V)&g_std_2ecli_2ecompleteWords_str25); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
          }
          default: return heff_nomatch(v_x2_2436);
          }
        }
        case TAG_Cons: {
          HeffT2 v_t_2441 = ({ V a_0 = v_x21_2418; V a_1 = v_cs_240; HeffT2 r_ = (g_list_2efind_24s1867824208x1412174996_24cpr(a_0, a_1)); heff_drop(v_cs_240); r_; });
          {
            V v_field_2443 = v_t_2441.f[1];
            int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
            if ((v_tag_2442 == ((int64_t)0ULL))) {
              V v_k_2444 = v_field_2443;
              V v_t_2445 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_2444, 3)), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
              V v_t_2446 = heff_tr(heff_call(heff_get_n(v_k_2444, 3, 4), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
              V v_sh_2447 = heff_get_n(v_t_2446, 0, 2);
              V v_t_2448 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_2447, 1), MK_INT(0LL)));
              V v_t_2449 = heff_rec_n(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_True), NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil)});
              V v_t_2450 = (g_std_2ecli_2ewhereGo(heff_dup(v_sh_2447), v_t_2448, v_t_2449, heff_dup(v_x22_2419)));
              V v_t_2451 = ({ V a_0 = v_sh_2447; V a_1 = v_t_2450; V a_2 = v_cur_242; V r_ = (g_std_2ecli_2ecompleteAt(a_0, a_1, a_2)); heff_drop(v_cur_242); r_; });
              return ({ V a_0 = heff_get_n(v_t_2445, 0, 2); V a_1 = v_t_2451; V r_ = (g_std_2ecli_2ecandidatesText(a_0, a_1)); heff_drop(v_t_2451); r_; });
            } else {
              heff_drop(v_cur_242);
              heff_drop(v_field_2443);
              return ((V)&g_std_2ecli_2ecompleteWords_str26);
            }
          }
        }
        default: return heff_nomatch(v_x22_2419);
        }
      } else {
        HeffT2 v_t_2452 = ({ V a_0 = v_x21_2418; V a_1 = v_cs_240; HeffT2 r_ = (g_list_2efind_24s1867824208x1412174996_24cpr(a_0, a_1)); heff_drop(v_cs_240); r_; });
        {
          V v_field_2454 = v_t_2452.f[1];
          int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
          if ((v_tag_2453 == ((int64_t)0ULL))) {
            V v_k_2455 = v_field_2454;
            V v_t_2456 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_2455, 3)), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
            V v_t_2457 = heff_tr(heff_call(heff_get_n(v_k_2455, 3, 4), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
            V v_sh_2458 = heff_get_n(v_t_2457, 0, 2);
            V v_t_2459 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_2458, 1), MK_INT(0LL)));
            V v_t_2460 = heff_rec_n(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_True), NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil)});
            V v_t_2461 = (g_std_2ecli_2ewhereGo(heff_dup(v_sh_2458), v_t_2459, v_t_2460, heff_dup(v_x22_2419)));
            V v_t_2462 = ({ V a_0 = v_sh_2458; V a_1 = v_t_2461; V a_2 = v_cur_242; V r_ = (g_std_2ecli_2ecompleteAt(a_0, a_1, a_2)); heff_drop(v_cur_242); r_; });
            return ({ V a_0 = heff_get_n(v_t_2456, 0, 2); V a_1 = v_t_2462; V r_ = (g_std_2ecli_2ecandidatesText(a_0, a_1)); heff_drop(v_t_2462); r_; });
          } else {
            heff_drop(v_cur_242);
            heff_drop(v_field_2454);
            return ((V)&g_std_2ecli_2ecompleteWords_str27);
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2ecompleteWords_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2ecompleteWords(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_std_2ecli_2einitOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einitOf_entry, 1, 0};

V g_std_2ecli_2einitOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_246 = (g_std_2ecli_2einitOf_24dps(v_x12_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einitOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einitOf(a[0]);
}
HEFF_LIT(g_std_2ecli_2elastOf_str0, 0, "");
Clo g_std_2ecli_2elastOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elastOf_entry, 1, 0};

V g_std_2ecli_2elastOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_std_2ecli_2elastOf_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2elastOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2elastOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2ezshScript_str0, 9, "#compdef ");
HEFF_LIT(g_std_2ecli_2ezshScript_str1, 2, "# ");
HEFF_LIT(g_std_2ecli_2ezshScript_str2, 14, ": written by `");
HEFF_LIT(g_std_2ecli_2ezshScript_str3, 17, " completions zsh`");
HEFF_LIT(g_std_2ecli_2ezshScript_str4, 1, "_");
HEFF_LIT(g_std_2ecli_2ezshScript_str5, 4, "() {");
HEFF_LIT(g_std_2ecli_2ezshScript_str6, 16, "  out=(\"${(@f)$(");
HEFF_LIT(g_std_2ecli_2ezshScript_str7, 38, " complete \"${(@)words[2,CURRENT]}\")}\")");
HEFF_LIT(g_std_2ecli_2ezshScript_str8, 16, "      _describe ");
HEFF_LIT(g_std_2ecli_2ezshScript_str9, 9, " cands ;;");
HEFF_LIT(g_std_2ecli_2ezshScript_str10, 24, "if [ \"$funcstack[1]\" = _");
HEFF_LIT(g_std_2ecli_2ezshScript_str11, 10, " ]; then _");
HEFF_LIT(g_std_2ecli_2ezshScript_str12, 21, " \"$@\"; else compdef _");
HEFF_LIT(g_std_2ecli_2ezshScript_str13, 1, " ");
HEFF_LIT(g_std_2ecli_2ezshScript_str14, 4, "; fi");
HEFF_LIT(g_std_2ecli_2ezshScript_str15, 6, "  esac");
HEFF_LIT(g_std_2ecli_2ezshScript_str16, 1, "}");
HEFF_LIT(g_std_2ecli_2ezshScript_str17, 10, "      done");
HEFF_LIT(g_std_2ecli_2ezshScript_str18, 32, "          cands+=(\"${l//:/\\\\:}\")");
HEFF_LIT(g_std_2ecli_2ezshScript_str19, 10, "        fi");
HEFF_LIT(g_std_2ecli_2ezshScript_str20, 55, "          cands+=(\"${${l%%$'\\t'*}//:/\\\\:}:${l#*$'\\t'}\")");
HEFF_LIT(g_std_2ecli_2ezshScript_str21, 12, "        else");
HEFF_LIT(g_std_2ecli_2ezshScript_str22, 31, "        [[ -z $l ]] && continue");
HEFF_LIT(g_std_2ecli_2ezshScript_str23, 36, "        if [[ $l == *$'\\t'* ]]; then");
HEFF_LIT(g_std_2ecli_2ezshScript_str24, 6, "    *)");
HEFF_LIT(g_std_2ecli_2ezshScript_str25, 23, "      for l in $out; do");
HEFF_LIT(g_std_2ecli_2ezshScript_str26, 49, "    ':files '*) _files -g \"*${out[1]#:files }\" ;;");
HEFF_LIT(g_std_2ecli_2ezshScript_str27, 25, "    ':dirs') _files -/ ;;");
HEFF_LIT(g_std_2ecli_2ezshScript_str28, 17, "  case $out[1] in");
HEFF_LIT(g_std_2ecli_2ezshScript_str29, 20, "  local -a out cands");
HEFF_LIT(g_std_2ecli_2ezshScript_str30, 9, "  local l");
HEFF_LIT(g_std_2ecli_2ezshScript_str31, 1, "\012");
Clo g_std_2ecli_2ezshScript_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ezshScript_entry, 1, 0};

V g_std_2ecli_2ezshScript(V v_prog_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str0), heff_dup(v_prog_240));
  V v_t_242 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ezshScript_str1), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str2));
  V v_t_243 = heff_strAppend(heff_strAppend(v_t_242, heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str3));
  V v_t_244 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ezshScript_str4), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str5));
  V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ezshScript_str6), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str7));
  V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ezshScript_str8), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str9));
  V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ezshScript_str10), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str11));
  V v_t_248 = heff_strAppend(heff_strAppend(v_t_247, heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str12));
  V v_t_249 = heff_strAppend(heff_strAppend(v_t_248, heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str13));
  V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, v_prog_240), ((V)&g_std_2ecli_2ezshScript_str14));
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str16), v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str17), heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str18), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str19), v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str20), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str21), v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str22), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str23), v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str24), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str25), v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str26), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str27), v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str28), v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str29), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str30), v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2420})});
  return ({ V a_0 = ((V)&g_std_2ecli_2ezshScript_str31); V a_1 = v_t_241; V a_2 = v_t_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2421, 2); r_; });
}
V g_std_2ecli_2ezshScript_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ezshScript(a[0]);
}
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str0, 4, "help");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str1, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str2, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str3, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str4, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str5, 6, "--help");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str6, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str7, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str8, 2, "-h");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str9, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str10, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str11, 11, "completions");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str12, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str13, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str14, 4, "fish");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str15, 2, "# ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str16, 14, ": written by `");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str17, 18, " completions fish`");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str18, 11, "function __");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str19, 9, "_complete");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str20, 16, "    set -l out (");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str21, 17, " complete $words)");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str22, 12, "complete -c ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str23, 3, " -e");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str24, 12, "complete -c ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str25, 11, " -f -a '(__");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str26, 11, "_complete)'");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str27, 3, "end");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str28, 30, "            printf '%s\\n' $out");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str29, 7, "    end");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str30, 57, "            __fish_complete_directories (commandline -ct)");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str31, 16, "        case '*'");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str32, 75, "            __fish_complete_suffix (string replace ':files ' '' -- $out[1])");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str33, 20, "        case ':dirs'");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str34, 20, "    switch \"$out[1]\"");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str35, 23, "        case ':files *'");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str36, 19, "    set -e words[1]");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str37, 53, "    set -l words (commandline -opc) (commandline -ct)");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str38, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str39, 4, "bash");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str40, 2, "# ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str41, 14, ": written by `");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str42, 18, " completions bash`");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str43, 1, "_");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str44, 4, "() {");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str45, 49, "  while IFS= read -r w; do out+=(\"$w\"); done < <(");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str46, 26, " complete \"${words[@]:1}\")");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str47, 26, "complete -o filenames -F _");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str48, 1, " ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str49, 6, "  esac");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str50, 1, "}");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str51, 25, "        COMPREPLY+=(\"$w\")");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str52, 13, "      done ;;");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str53, 22, "        w=${w%%$'\\t'*}");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str54, 77, "        if [[ $last == *=* ]]; then w=${w#*=}; [[ $cur == = ]] && w=\"=$w\"; fi");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str55, 6, "    *)");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str56, 30, "      for w in \"${out[@]}\"; do");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str57, 103, "    ':files '*) COMPREPLY=($(compgen -d -- \"$cur\") $(compgen -f -X \"!*${out[0]#:files }\" -- \"$cur\")) ;;");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str58, 51, "    ':dirs') COMPREPLY=($(compgen -d -- \"$cur\")) ;;");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str59, 14, "  COMPREPLY=()");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str60, 21, "  case \"${out[0]}\" in");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str61, 31, "  last=${words[${#words[@]}-1]}");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str62, 28, "  read -ra words <<< \"$line\"");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str63, 58, "  [[ $line == *' ' || ${#words[@]} -eq 1 ]] && words+=('')");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str64, 75, "  local line=${COMP_LINE:0:COMP_POINT} cur=${COMP_WORDS[COMP_CWORD]} w last");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str65, 20, "  local -a words out");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str66, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str67, 3, "zsh");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str68, 25, " completions: a shell is ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str69, 6, ", not ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str70, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str71, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str72, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str73, 8, "complete");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str74, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str75, 1, "\012");

HeffT2 g_std_2ecli_2ereadLine_24cpr(V v_prog_240, V v_cs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    V v_f_243 = (g_std_2ecli_2eusage(v_prog_240, v_cs_241));
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_243}});
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_x32_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_strEq_c_lent(v_x31_244, ((V)&g_std_2ecli_2ereadLine_24cpr_str0), 2)) {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      switch (heff_tag_of(v_x32_245)) {
      case TAG_Nil: {
        heff_drop(v_x31_244);
        V v_f_246 = (g_std_2ecli_2eusage(v_prog_240, v_cs_241));
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_246}});
      }
      case TAG_Cons: {
        V v_x322_248 = heff_dup(heff_field(v_x32_245, 1));
        switch (heff_tag_of(v_x322_248)) {
        case TAG_Nil: {
          heff_drop(v_x31_244);
          switch (heff_tag_of(v_x32_245)) {
          case TAG_Cons: {
            V v_w_249 = heff_field(v_x32_245, 0);
            heff_take_n(v_x32_245, 1ULL, 2);
            HeffT2 v_t_2411 = (g_list_2efind_24s1867824208x1412174996_24cpr(v_w_249, v_cs_241));
            {
              V v_field_2413 = v_t_2411.f[1];
              int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
              if ((v_tag_2412 == ((int64_t)0ULL))) {
                heff_drop(v_cs_241);
                heff_drop(v_w_249);
                V v_k_2414 = v_field_2413;
                V v_f_2415 = (g_std_2ecli_2ehelpOf(v_prog_240, v_k_2414));
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2415}});
              } else {
                heff_drop(v_field_2413);
                V v_t_2416 = heff_strAppend(heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ereadLine_24cpr_str1)), v_w_249);
                V v_t_2417 = (g_std_2ecli_2eusage(v_prog_240, v_cs_241));
                V v_f_2418 = heff_strAppend(heff_strAppend(v_t_2416, ((V)&g_std_2ecli_2ereadLine_24cpr_str2)), v_t_2417);
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2418}});
              }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x32_245)}});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_x322_248, 0ULL, 2);
          HeffT2 v_t_2421 = (g_list_2efind_24s1867824208x1412174996_24cpr(v_x31_244, v_cs_241));
          {
            V v_field_2423 = v_t_2421.f[1];
            int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
            if ((v_tag_2422 == ((int64_t)0ULL))) {
              heff_drop(v_cs_241);
              heff_drop(v_x31_244);
              V v_k_2424 = v_field_2423;
              HEFF_LAST return g_std_2ecli_2eoutcomeOf_24cpr(v_prog_240, v_k_2424, v_x32_245);
            } else {
              heff_drop_tag(v_x32_245, 2);
              heff_drop(v_field_2423);
              V v_t_2425 = heff_strAppend(heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ereadLine_24cpr_str3)), v_x31_244);
              V v_t_2426 = (g_std_2ecli_2eusage(v_prog_240, v_cs_241));
              V v_f_2427 = heff_strAppend(heff_strAppend(v_t_2425, ((V)&g_std_2ecli_2ereadLine_24cpr_str4)), v_t_2426);
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2427}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x322_248)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x32_245)}});
      }
    } else {
      if (heff_strEq_c_lent(v_x31_244, ((V)&g_std_2ecli_2ereadLine_24cpr_str5), 2)) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        switch (heff_tag_of(v_x32_245)) {
        case TAG_Nil: {
          heff_drop(v_x31_244);
          V v_f_2428 = (g_std_2ecli_2eusage(v_prog_240, v_cs_241));
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2428}});
        }
        case TAG_Cons: {
          HeffT2 v_t_2431 = (g_list_2efind_24s1867824208x1412174996_24cpr(v_x31_244, v_cs_241));
          {
            V v_field_2433 = v_t_2431.f[1];
            int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
            if ((v_tag_2432 == ((int64_t)0ULL))) {
              heff_drop(v_cs_241);
              heff_drop(v_x31_244);
              V v_k_2434 = v_field_2433;
              HEFF_LAST return g_std_2ecli_2eoutcomeOf_24cpr(v_prog_240, v_k_2434, v_x32_245);
            } else {
              heff_drop_tag(v_x32_245, 2);
              heff_drop(v_field_2433);
              V v_t_2435 = heff_strAppend(heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ereadLine_24cpr_str6)), v_x31_244);
              V v_t_2436 = (g_std_2ecli_2eusage(v_prog_240, v_cs_241));
              V v_f_2437 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_std_2ecli_2ereadLine_24cpr_str7)), v_t_2436);
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2437}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x32_245)}});
        }
      } else {
        if (heff_strEq_c_lent(v_x31_244, ((V)&g_std_2ecli_2ereadLine_24cpr_str8), 2)) {
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          switch (heff_tag_of(v_x32_245)) {
          case TAG_Nil: {
            heff_drop(v_x31_244);
            V v_f_2438 = (g_std_2ecli_2eusage(v_prog_240, v_cs_241));
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2438}});
          }
          case TAG_Cons: {
            HeffT2 v_t_2441 = (g_list_2efind_24s1867824208x1412174996_24cpr(v_x31_244, v_cs_241));
            {
              V v_field_2443 = v_t_2441.f[1];
              int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
              if ((v_tag_2442 == ((int64_t)0ULL))) {
                heff_drop(v_cs_241);
                heff_drop(v_x31_244);
                V v_k_2444 = v_field_2443;
                HEFF_LAST return g_std_2ecli_2eoutcomeOf_24cpr(v_prog_240, v_k_2444, v_x32_245);
              } else {
                heff_drop_tag(v_x32_245, 2);
                heff_drop(v_field_2443);
                V v_t_2445 = heff_strAppend(heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ereadLine_24cpr_str9)), v_x31_244);
                V v_t_2446 = (g_std_2ecli_2eusage(v_prog_240, v_cs_241));
                V v_f_2447 = heff_strAppend(heff_strAppend(v_t_2445, ((V)&g_std_2ecli_2ereadLine_24cpr_str10)), v_t_2446);
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2447}});
              }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x32_245)}});
          }
        } else {
          if (heff_strEq_c_lent(v_x31_244, ((V)&g_std_2ecli_2ereadLine_24cpr_str11), 2)) {
            switch (heff_tag_of(v_x32_245)) {
            case TAG_Nil: {
              heff_drop_cell(v_ru_24x3_242_24Cons, 2);
              HeffT2 v_t_2448 = (g_list_2efind_24s1867824208x1412174996_24cpr(v_x31_244, v_cs_241));
              {
                V v_field_2450 = v_t_2448.f[1];
                int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
                if ((v_tag_2449 == ((int64_t)0ULL))) {
                  heff_drop(v_cs_241);
                  heff_drop(v_x31_244);
                  V v_k_2451 = v_field_2450;
                  HEFF_LAST return g_std_2ecli_2eoutcomeOf_24cpr(v_prog_240, v_k_2451, v_x32_245);
                } else {
                  heff_drop(v_field_2450);
                  V v_t_2452 = heff_strAppend(heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ereadLine_24cpr_str12)), v_x31_244);
                  V v_t_2453 = (g_std_2ecli_2eusage(v_prog_240, v_cs_241));
                  V v_f_2454 = heff_strAppend(heff_strAppend(v_t_2452, ((V)&g_std_2ecli_2ereadLine_24cpr_str13)), v_t_2453);
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2454}});
                }
              }
            }
            case TAG_Cons: {
              V v_x322_2456 = heff_dup(heff_field(v_x32_245, 1));
              switch (heff_tag_of(v_x322_2456)) {
              case TAG_Nil: {
                heff_drop(v_cs_241);
                heff_drop(v_x31_244);
                switch (heff_tag_of(v_x32_245)) {
                case TAG_Cons: {
                  V v_sh_2457 = heff_field(v_x32_245, 0);
                  V v_ru_24x32_245_24Cons = heff_take_reuse_n(v_x32_245, 1ULL, 2);
                  if (heff_strEq_c_lent(v_sh_2457, ((V)&g_std_2ecli_2ereadLine_24cpr_str14), 2)) {
                    heff_drop(v_sh_2457);
                    V v_prog_2459 = v_prog_240;
                    V v_t_2460 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ereadLine_24cpr_str15), heff_dup(v_prog_2459)), ((V)&g_std_2ecli_2ereadLine_24cpr_str16));
                    V v_t_2461 = heff_strAppend(heff_strAppend(v_t_2460, heff_dup(v_prog_2459)), ((V)&g_std_2ecli_2ereadLine_24cpr_str17));
                    V v_t_2462 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ereadLine_24cpr_str18), heff_dup(v_prog_2459)), ((V)&g_std_2ecli_2ereadLine_24cpr_str19));
                    V v_t_2463 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ereadLine_24cpr_str20), heff_dup(v_prog_2459)), ((V)&g_std_2ecli_2ereadLine_24cpr_str21));
                    V v_t_2464 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ereadLine_24cpr_str22), heff_dup(v_prog_2459)), ((V)&g_std_2ecli_2ereadLine_24cpr_str23));
                    V v_t_2465 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ereadLine_24cpr_str24), heff_dup(v_prog_2459)), ((V)&g_std_2ecli_2ereadLine_24cpr_str25));
                    V v_t_2466 = heff_strAppend(heff_strAppend(v_t_2465, v_prog_2459), ((V)&g_std_2ecli_2ereadLine_24cpr_str26));
                    V v_t_2467 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2466, NTAG(TAG_Nil)});
                    V v_t_2468 = heff_tag_at_n(v_ru_24x32_245_24Cons, TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str27), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2464, v_t_2467})});
                    V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str28), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str29), v_t_2468})});
                    V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str30), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str31), v_t_2469})});
                    V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str32), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str33), v_t_2470})});
                    V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str34), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str35), v_t_2471})});
                    V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2463, v_t_2472})});
                    V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2462, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str37), v_t_2473})});
                    V v_f_2475 = ({ V a_0 = ((V)&g_std_2ecli_2ereadLine_24cpr_str38); V a_1 = v_t_2461; V a_2 = v_t_2474; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2474, 2); r_; });
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2475}});
                  } else {
                    if (heff_strEq_c_lent(v_sh_2457, ((V)&g_std_2ecli_2ereadLine_24cpr_str39), 2)) {
                      heff_drop(v_sh_2457);
                      V v_prog_2476 = v_prog_240;
                      V v_t_2477 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ereadLine_24cpr_str40), heff_dup(v_prog_2476)), ((V)&g_std_2ecli_2ereadLine_24cpr_str41));
                      V v_t_2478 = heff_strAppend(heff_strAppend(v_t_2477, heff_dup(v_prog_2476)), ((V)&g_std_2ecli_2ereadLine_24cpr_str42));
                      V v_t_2479 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ereadLine_24cpr_str43), heff_dup(v_prog_2476)), ((V)&g_std_2ecli_2ereadLine_24cpr_str44));
                      V v_t_2480 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ereadLine_24cpr_str45), heff_dup(v_prog_2476)), ((V)&g_std_2ecli_2ereadLine_24cpr_str46));
                      V v_t_2481 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ereadLine_24cpr_str47), heff_dup(v_prog_2476)), ((V)&g_std_2ecli_2ereadLine_24cpr_str48));
                      V v_t_2482 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2481, v_prog_2476), NTAG(TAG_Nil)});
                      V v_t_2483 = heff_tag_at_n(v_ru_24x32_245_24Cons, TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str49), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str50), v_t_2482})});
                      V v_t_2484 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str51), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str52), v_t_2483})});
                      V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str53), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str54), v_t_2484})});
                      V v_t_2486 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str55), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str56), v_t_2485})});
                      V v_t_2487 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str57), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str58), v_t_2486})});
                      V v_t_2488 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str59), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str60), v_t_2487})});
                      V v_t_2489 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str61), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2480, v_t_2488})});
                      V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str62), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str63), v_t_2489})});
                      V v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str64), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ereadLine_24cpr_str65), v_t_2490})});
                      V v_f_2492 = ({ V a_0 = ((V)&g_std_2ecli_2ereadLine_24cpr_str66); V a_1 = v_t_2478; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2479, v_t_2491}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2492}});
                    } else {
                      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
                      heff_drop_cell(v_ru_24x32_245_24Cons, 2);
                      if (heff_strEq_c_lent(v_sh_2457, ((V)&g_std_2ecli_2ereadLine_24cpr_str67), 2)) {
                        heff_drop(v_sh_2457);
                        V v_f_2493 = (g_std_2ecli_2ezshScript(v_prog_240));
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2493}});
                      } else {
                        V v_t_2494 = ({ V b_0 = heff_dup(g_std_2ecli_2eshells_get()); V r_ = (g_std_2ecli_2eorList(b_0)); heff_drop(b_0); r_; });
                        V v_t_2495 = heff_strAppend(heff_strAppend(v_prog_240, ((V)&g_std_2ecli_2ereadLine_24cpr_str68)), v_t_2494);
                        V v_t_2496 = heff_strAppend(heff_strAppend(v_t_2495, ((V)&g_std_2ecli_2ereadLine_24cpr_str69)), v_sh_2457);
                        V v_f_2497 = heff_strAppend(v_t_2496, ((V)&g_std_2ecli_2ereadLine_24cpr_str70));
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2497}});
                      }
                    }
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x32_245)}});
                }
              }
              case TAG_Cons: {
                heff_take_n(v_x322_2456, 0ULL, 2);
                heff_drop_cell(v_ru_24x3_242_24Cons, 2);
                HeffT2 v_t_24100 = (g_list_2efind_24s1867824208x1412174996_24cpr(v_x31_244, v_cs_241));
                {
                  V v_field_24102 = v_t_24100.f[1];
                  int64_t v_tag_24101 = ((int64_t)v_t_24100.f[0]);
                  if ((v_tag_24101 == ((int64_t)0ULL))) {
                    heff_drop(v_cs_241);
                    heff_drop(v_x31_244);
                    V v_k_24103 = v_field_24102;
                    HEFF_LAST return g_std_2ecli_2eoutcomeOf_24cpr(v_prog_240, v_k_24103, v_x32_245);
                  } else {
                    heff_drop_tag(v_x32_245, 2);
                    heff_drop(v_field_24102);
                    V v_t_24104 = heff_strAppend(heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ereadLine_24cpr_str71)), v_x31_244);
                    V v_t_24105 = (g_std_2ecli_2eusage(v_prog_240, v_cs_241));
                    V v_f_24106 = heff_strAppend(heff_strAppend(v_t_24104, ((V)&g_std_2ecli_2ereadLine_24cpr_str72)), v_t_24105);
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24106}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x322_2456)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x32_245)}});
            }
          } else {
            heff_drop_cell(v_ru_24x3_242_24Cons, 2);
            if (heff_strEq_c_lent(v_x31_244, ((V)&g_std_2ecli_2ereadLine_24cpr_str73), 2)) {
              heff_drop(v_prog_240);
              heff_drop(v_x31_244);
              V v_t_24107 = (g_std_2ecli_2einitOf(heff_dup(v_x32_245)));
              V v_t_24108 = ({ V a_0 = v_x32_245; V r_ = (g_std_2ecli_2elastOf(a_0)); heff_drop(v_x32_245); r_; });
              V v_f_24109 = ({ V a_0 = v_cs_241; V a_1 = v_t_24107; V a_2 = v_t_24108; V r_ = (g_std_2ecli_2ecompleteWords(a_0, a_1, a_2)); heff_drop(v_t_24107); r_; });
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24109}});
            } else {
              HeffT2 v_t_24110 = (g_list_2efind_24s1867824208x1412174996_24cpr(v_x31_244, v_cs_241));
              {
                V v_field_24112 = v_t_24110.f[1];
                int64_t v_tag_24111 = ((int64_t)v_t_24110.f[0]);
                if ((v_tag_24111 == ((int64_t)0ULL))) {
                  heff_drop(v_cs_241);
                  heff_drop(v_x31_244);
                  V v_k_24113 = v_field_24112;
                  HEFF_LAST return g_std_2ecli_2eoutcomeOf_24cpr(v_prog_240, v_k_24113, v_x32_245);
                } else {
                  heff_drop(v_x32_245);
                  heff_drop(v_field_24112);
                  V v_t_24114 = heff_strAppend(heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ereadLine_24cpr_str74)), v_x31_244);
                  V v_t_24115 = (g_std_2ecli_2eusage(v_prog_240, v_cs_241));
                  V v_f_24116 = heff_strAppend(heff_strAppend(v_t_24114, ((V)&g_std_2ecli_2ereadLine_24cpr_str75)), v_t_24115);
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24116}});
                }
              }
            }
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}