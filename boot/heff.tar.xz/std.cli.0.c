// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ambiguous 41766
#define TAG_BadShape 33347
#define TAG_Extra 49222
#define TAG_Fail 27959
#define TAG_Help 25956
#define TAG_Left 13886
#define TAG_Many 40086
#define TAG_Missing 63220
#define TAG_MissingFlag 20234
#define TAG_NoValue 57584
#define TAG_NotIn 31836
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_Out 27098
#define TAG_Rest 61983
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Some 35657
#define TAG_SwitchValue 32207
#define TAG_Unknown 64328
#define LBL_ap 9878
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_count 296209705
#define LBL_flag 9641011
#define LBL_flags 298871457
#define LBL_fs 10036
#define LBL_give 9668568
#define LBL_given 299725719
#define LBL_long 9823043
#define LBL_meta 9843404
#define LBL_name 9869138
#define LBL_on 10310
#define LBL_pos 320718
#define LBL_ps 10346
#define LBL_ra 10390
#define LBL_required 351999471
#define LBL_sh 10428
#define LBL_shape 310758331
#define LBL_short 310771862
#define LBL_take 10047822
#define LBL_values 1123329101
#define LBL_waiting 1348170899
static uint32_t shape_flags__pos[] = {LBL_flags, LBL_pos};
static uint32_t shape_give__ap__flag__pos[] = {LBL_give, LBL_ap, LBL_flag, LBL_pos};
static uint32_t shape_on__waiting__count__given[] = {LBL_on, LBL_waiting, LBL_count, LBL_given};
static uint32_t shape_sh__ra__on__ps__fs[] = {LBL_sh, LBL_ra, LBL_on, LBL_ps, LBL_fs};
static uint32_t shape_shape__take[] = {LBL_shape, LBL_take};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1623010005x1805617852(V);
V g_list_2efilter_24s1623010005x1805617852_entry(V self, V *a);
extern Clo g_list_2efilter_24s1623010005x1805617852_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f935318736x1254281698(V, V, V);
V g_list_2emap_24f935318736x1254281698_entry(V self, V *a);
extern Clo g_list_2emap_24f935318736x1254281698_clo;
V g_list_2emap_24f935318736x1254281698_24f812639102x862288937(V, V, V);
V g_list_2emap_24f935318736x1254281698_24f812639102x862288937_entry(V self, V *a);
extern Clo g_list_2emap_24f935318736x1254281698_24f812639102x862288937_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1281445768x1036802655(V);
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_clo;
V g_list_2emap_24s2029999044x514618413(V);
V g_list_2emap_24s2029999044x514618413_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_clo;
V g_list_2emap_24s296585291x885335139(V);
V g_list_2emap_24s296585291x885335139_entry(V self, V *a);
extern Clo g_list_2emap_24s296585291x885335139_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2ecli_2ecandidatesText(V, V);
V g_std_2ecli_2ecandidatesText_entry(V self, V *a);
extern Clo g_std_2ecli_2ecandidatesText_clo;
V g_std_2ecli_2ecellOf(V, V, V, V, V, V);
V g_std_2ecli_2ecellOf_entry(V self, V *a);
extern Clo g_std_2ecli_2ecellOf_clo;
V g_std_2ecli_2ecommandsText(V, V);
V g_std_2ecli_2ecommandsText_entry(V self, V *a);
extern Clo g_std_2ecli_2ecommandsText_clo;
V g_std_2ecli_2ecompleteAt(V, V, V);
V g_std_2ecli_2ecompleteAt_entry(V self, V *a);
extern Clo g_std_2ecli_2ecompleteAt_clo;
V g_std_2ecli_2ecompleteWords(V, V, V);
V g_std_2ecli_2ecompleteWords_entry(V self, V *a);
extern Clo g_std_2ecli_2ecompleteWords_clo;
V g_std_2ecli_2edistance(V, V);
V g_std_2ecli_2edistance_entry(V self, V *a);
extern Clo g_std_2ecli_2edistance_clo;
V g_std_2ecli_2efirstJust(V, V);
V g_std_2ecli_2efirstJust_entry(V self, V *a);
extern Clo g_std_2ecli_2efirstJust_clo;
V g_std_2ecli_2eflagProblem(V, V);
V g_std_2ecli_2eflagProblem_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagProblem_clo;
V g_std_2ecli_2egroupsGo(V, V);
V g_std_2ecli_2egroupsGo_entry(V self, V *a);
extern Clo g_std_2ecli_2egroupsGo_clo;
V g_std_2ecli_2eheadOf(V);
V g_std_2ecli_2eheadOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eheadOf_clo;
V g_std_2ecli_2ehelpOf(V, V);
V g_std_2ecli_2ehelpOf_entry(V self, V *a);
extern Clo g_std_2ecli_2ehelpOf_clo;
V g_std_2ecli_2einitOf(V);
V g_std_2ecli_2einitOf_entry(V self, V *a);
extern Clo g_std_2ecli_2einitOf_clo;
V g_std_2ecli_2einitOf_24dps(V, V);
V g_std_2ecli_2einitOf_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2einitOf_24dps_clo;
V g_std_2ecli_2elastOf(V);
V g_std_2ecli_2elastOf_entry(V self, V *a);
extern Clo g_std_2ecli_2elastOf_clo;
V g_std_2ecli_2elastOr(V, V);
V g_std_2ecli_2elastOr_entry(V self, V *a);
extern Clo g_std_2ecli_2elastOr_clo;
V g_std_2ecli_2elastS(V);
V g_std_2ecli_2elastS_entry(V self, V *a);
extern Clo g_std_2ecli_2elastS_clo;
V g_std_2ecli_2eline2(V, V);
V g_std_2ecli_2eline2_entry(V self, V *a);
extern Clo g_std_2ecli_2eline2_clo;
V g_std_2ecli_2elongF_24s1119688962x564470218(V, V, V);
V g_std_2ecli_2elongF_24s1119688962x564470218_entry(V self, V *a);
extern Clo g_std_2ecli_2elongF_24s1119688962x564470218_clo;
V g_std_2ecli_2elongNamed(V, V);
V g_std_2ecli_2elongNamed_entry(V self, V *a);
extern Clo g_std_2ecli_2elongNamed_clo;
V g_std_2ecli_2elookupL(V, V);
V g_std_2ecli_2elookupL_entry(V self, V *a);
extern Clo g_std_2ecli_2elookupL_clo;
V g_std_2ecli_2enearest(V, V);
V g_std_2ecli_2enearest_entry(V self, V *a);
extern Clo g_std_2ecli_2enearest_clo;
V g_std_2ecli_2enextGo(V, V, V, V, V, V);
V g_std_2ecli_2enextGo_entry(V self, V *a);
extern Clo g_std_2ecli_2enextGo_clo;
V g_std_2ecli_2enextGo_24dps(V, V, V, V, V, V, V);
V g_std_2ecli_2enextGo_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2enextGo_24dps_clo;
V g_std_2ecli_2eorList(V);
V g_std_2ecli_2eorList_entry(V self, V *a);
extern Clo g_std_2ecli_2eorList_clo;
V g_std_2ecli_2eorList_24acc(V, V);
V g_std_2ecli_2eorList_24acc_entry(V self, V *a);
extern Clo g_std_2ecli_2eorList_24acc_clo;
V g_std_2ecli_2eoutcomeOf(V, V, V);
V g_std_2ecli_2eoutcomeOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eoutcomeOf_clo;
V g_std_2ecli_2eparse(V, V);
V g_std_2ecli_2eparse_entry(V self, V *a);
extern Clo g_std_2ecli_2eparse_clo;
V g_std_2ecli_2eposAt(V, V);
V g_std_2ecli_2eposAt_entry(V self, V *a);
extern Clo g_std_2ecli_2eposAt_clo;
V g_std_2ecli_2eproblemSaid(V);
V g_std_2ecli_2eproblemSaid_entry(V self, V *a);
extern Clo g_std_2ecli_2eproblemSaid_clo;
V g_std_2ecli_2ereading_get(void);
V g_std_2ecli_2erestIndex(V, V);
V g_std_2ecli_2erestIndex_entry(V self, V *a);
extern Clo g_std_2ecli_2erestIndex_clo;
V g_std_2ecli_2eshapeProblem(V);
V g_std_2ecli_2eshapeProblem_entry(V self, V *a);
extern Clo g_std_2ecli_2eshapeProblem_clo;
V g_std_2ecli_2eshells_get(void);
V g_std_2ecli_2eshortF_24s1014269042x1715098139(V, V, V);
V g_std_2ecli_2eshortF_24s1014269042x1715098139_entry(V self, V *a);
extern Clo g_std_2ecli_2eshortF_24s1014269042x1715098139_clo;
V g_std_2ecli_2eusage(V, V);
V g_std_2ecli_2eusage_entry(V self, V *a);
extern Clo g_std_2ecli_2eusage_clo;
V g_std_2ecli_2ewhereGo(V, V, V, V);
V g_std_2ecli_2ewhereGo_entry(V self, V *a);
extern Clo g_std_2ecli_2ewhereGo_clo;
V g_std_2ecli_2ewordsF_24s1352288509x2021617997(V, V);
V g_std_2ecli_2ewordsF_24s1352288509x2021617997_entry(V self, V *a);
extern Clo g_std_2ecli_2ewordsF_24s1352288509x2021617997_clo;
V g_std_2ecli_2ezshScript(V);
V g_std_2ecli_2ezshScript_entry(V self, V *a);
extern Clo g_std_2ecli_2ezshScript_clo;
Clo g_std_2ecli_2elastS_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elastS_entry, 1, 0};

V g_std_2ecli_2elastS(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_241)});
    }
    case TAG_Cons: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2elastS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2elastS(a0); heff_drop(a0); return r;
}
V g_std_2ecli_2ereading_lam1(V self, V *args);
V g_std_2ecli_2ereading_lam0(V self, V *args); static Clo g_std_2ecli_2ereading_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam0, 1, 0};
V g_std_2ecli_2ereading_lam3(V self, V *args);
V g_std_2ecli_2ereading_lam2(V self, V *args); static Clo g_std_2ecli_2ereading_lam2_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam2, 2, 0};
V g_std_2ecli_2ereading_lam5(V self, V *args);
V g_std_2ecli_2ereading_lam4(V self, V *args); static Clo g_std_2ecli_2ereading_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam4, 1, 0};
V g_std_2ecli_2ereading_lam7(V self, V *args); static Clo g_std_2ecli_2ereading_lam7_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam7, 2, 0};
V g_std_2ecli_2ereading_lam6(V self, V *args); static Clo g_std_2ecli_2ereading_lam6_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam6, 1, 0};

static V g_std_2ecli_2ereading_val;
static HEFF_ONCE g_std_2ecli_2ereading_st;
static V g_std_2ecli_2ereading_init(void) {
  return heff_rec_n(4, shape_give__ap__flag__pos, (V[]){((V)&g_std_2ecli_2ereading_lam0_clo), ((V)&g_std_2ecli_2ereading_lam2_clo), ((V)&g_std_2ecli_2ereading_lam4_clo), ((V)&g_std_2ecli_2ereading_lam6_clo)});
}
V g_std_2ecli_2ereading_get(void) {
  if (HEFF_DONE(g_std_2ecli_2ereading_st)) return g_std_2ecli_2ereading_val;
  return heff_global(&g_std_2ecli_2ereading_val, &g_std_2ecli_2ereading_st, g_std_2ecli_2ereading_init);
}
V g_std_2ecli_2ereading_lam1(V self, V *args) {
  V v_x_242 = args[0];
  V v_x_243 = args[1];
  V v_x_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_242);
  heff_drop(v_x_243);
  return v_x_240;
}
V g_std_2ecli_2ereading_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_t_241 = heff_rec_n(2, shape_flags__pos, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  return heff_rec_n(2, shape_shape__take, (V[]){v_t_241, heff_clo_n(g_std_2ecli_2ereading_lam1, 2, 1, (V[]){v_x_240})});
}
V g_std_2ecli_2ereading_lam3(V self, V *args) {
  V v_groups_2412 = args[0];
  V v_fl_2413 = args[1];
  V v_f_244 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_f_244, 0)), 1, 2);
  V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2414; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
  V v_t_2416 = (g_list_2edrop(v_t_2415, heff_dup(v_groups_2412)));
  V v_t_2417 = heff_tr(heff_call(heff_get_n(v_x_245, 1, 2), 2, (V[]){v_t_2416, heff_dup(v_fl_2413)}));
  V f_ = heff_get_n(v_f_244, 1, 2);
  heff_room[0] = v_groups_2412;
  heff_room[1] = v_fl_2413;
  heff_room[2] = v_t_2417;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_std_2ecli_2ereading_lam2(V self, V *args) {
  V v_f_244 = args[0];
  V v_x_245 = args[1];
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_f_244, 0)), 0, 2);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_x_245, 0)), 0, 2);
  V v_t_248 = (g_prelude_2e_2b_2b(v_t_246, v_t_247));
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_f_244, 0)), 1, 2);
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_x_245, 0)), 1, 2);
  V v_t_2411 = (g_prelude_2e_2b_2b(v_t_249, v_t_2410));
  return heff_rec_n(2, shape_shape__take, (V[]){heff_rec_n(2, shape_flags__pos, (V[]){v_t_248, v_t_2411}), heff_clo_n(g_std_2ecli_2ereading_lam3, 2, 2, (V[]){v_f_244, v_x_245})});
}
V g_std_2ecli_2ereading_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_given_2422 = args[1];
  V v_fl_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2421);
  return ({ V a_0 = heff_get_n(v_fl_2418, 0, 8); V a_1 = v_given_2422; V r_ = (g_std_2ecli_2elookupL(a_0, a_1)); heff_drop(v_given_2422); r_; });
}
V g_std_2ecli_2ereading_lam4(V self, V *args) {
  V v_fl_2418 = args[0];
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_fl_2418), NTAG(TAG_Nil)});
  V v_t_2420 = heff_rec_n(2, shape_flags__pos, (V[]){v_t_2419, NTAG(TAG_Nil)});
  return heff_rec_n(2, shape_shape__take, (V[]){v_t_2420, heff_clo_n(g_std_2ecli_2ereading_lam5, 2, 1, (V[]){v_fl_2418})});
}
V g_std_2ecli_2ereading_lam7(V self, V *args) {
  V v_groups_2426 = args[0];
  V v_x_2427 = args[1];
  heff_drop(v_x_2427);
  switch (heff_tag_of(v_groups_2426)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2428 = heff_field(v_groups_2426, 0);
    heff_take_n(v_groups_2426, 1ULL, 2);
    return v_x_2428;
  }
  default: return heff_nomatch(v_groups_2426);
  }
}
V g_std_2ecli_2ereading_lam6(V self, V *args) {
  V v_p_2423 = args[0];
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_p_2423, NTAG(TAG_Nil)});
  V v_t_2425 = heff_rec_n(2, shape_flags__pos, (V[]){NTAG(TAG_Nil), v_t_2424});
  return heff_rec_n(2, shape_shape__take, (V[]){v_t_2425, ((V)&g_std_2ecli_2ereading_lam7_clo)});
}
Clo g_std_2ecli_2ecellOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecellOf_entry, 6, 0};

V g_std_2ecli_2ecellOf(V v_a_240, V v_c_241, V v_up_242, V v_diag_243, V v_left_244, V v_i_245) {
top: ;
  V v_x_246 = heff_intAdd(v_up_242, MK_INT(1LL));
  V v_y_247 = heff_intAdd(v_left_244, MK_INT(1LL));
  V v_x_249;
  if (heff_intLe_c(heff_dup(v_x_246), heff_dup(v_y_247))) {
    heff_drop(v_y_247);
    v_x_249 = v_x_246;
  } else {
    heff_drop(v_x_246);
    v_x_249 = v_y_247;
  }
  V v_t_2410 = heff_strByteAt(v_a_240, heff_intSub(v_i_245, MK_INT(1LL)));
  V v_t_2412;
  if (heff_intEq_c(v_t_2410, v_c_241)) {
    v_t_2412 = MK_INT(0LL);
  } else {
    v_t_2412 = MK_INT(1LL);
  }
  V v_y_2413 = heff_intAdd(v_diag_243, v_t_2412);
  if (heff_intLe_c(heff_dup(v_x_249), heff_dup(v_y_2413))) {
    heff_drop(v_y_2413);
    return v_x_249;
  } else {
    heff_drop(v_x_249);
    return v_y_2413;
  }
}
V g_std_2ecli_2ecellOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ecellOf(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_std_2ecli_2enextGo_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2enextGo_entry, 6, 0};

V g_std_2ecli_2enextGo(V v_a_240, V v_c_241, V v_x3_242, V v_diag_243, V v_left_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_a_240);
    heff_drop(v_c_241);
    heff_drop(v_diag_243);
    heff_drop(v_left_244);
    heff_drop(v_i_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_up_246 = heff_field(v_x3_242, 0);
    V v_ups_247 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_248 = (g_std_2ecli_2ecellOf(heff_dup(v_a_240), heff_dup(v_c_241), heff_dup(v_up_246), heff_dup(v_diag_243), heff_dup(v_left_244), heff_dup(v_i_245)));
    V v_cell_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_t_2410 = (g_std_2ecli_2ecellOf(heff_dup(v_a_240), heff_dup(v_c_241), heff_dup(v_up_246), v_diag_243, v_left_244, heff_dup(v_i_245)));
    V v_u_2411 = (g_std_2ecli_2enextGo_24dps(v_a_240, v_c_241, v_ups_247, v_up_246, v_t_2410, heff_intAdd(v_i_245, MK_INT(1LL)), heff_dup(v_cell_249)));
    heff_drop(v_u_2411);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2ecli_2enextGo_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2enextGo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_std_2ecli_2elastOr_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elastOr_entry, 2, 0};

V g_std_2ecli_2elastOr(V v_d_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_d_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop(v_d_240);
      return heff_dup(v_x_242);
    }
    case TAG_Cons: {
      V t_0 = v_d_240;
      V t_1 = v_x22_243;
      v_d_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2elastOr_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2elastOr(a[0], a1); heff_drop(a1); return r;
}
V g_std_2ecli_2enearest_lam0(V self, V *args);
Clo g_std_2ecli_2enearest_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2enearest_entry, 2, 0};

V g_std_2ecli_2enearest(V v_sh_240, V v_x_241) {
top: ;
  return ({ V a_0 = heff_clo_n(g_std_2ecli_2enearest_lam0, 2, 1, (V[]){v_x_241}); V a_1 = NTAG(TAG_Nothing); V b_2 = heff_get_n(v_sh_240, 0, 2); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_std_2ecli_2enearest_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2enearest(a[0], a[1]);
}
V g_std_2ecli_2enearest_lam0(V self, V *args) {
  V v_best_242 = args[0];
  V v_f_243 = args[1];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_std_2ecli_2edistance(heff_dup(heff_rfield(v_f_243, 0)), heff_dup(v_x_241)));
  if (heff_intLe_c(v_t_244, MK_INT(2LL))) {
    if (heff_intLe_c(heff_strLength(heff_dup(v_x_241)), MK_INT(16LL))) {
      switch (heff_tag_of(v_best_242)) {
      case TAG_Nothing: {
        heff_drop(v_x_241);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_f_243, 0, 8)});
      }
      case TAG_Just: {
        V v_b_247 = heff_dup(heff_field(v_best_242, 0));
        V v_t_248 = (g_std_2ecli_2edistance(heff_dup(heff_rfield(v_f_243, 0)), heff_dup(v_x_241)));
        V v_t_249 = (g_std_2ecli_2edistance(v_b_247, v_x_241));
        if (heff_intLt_c(v_t_248, v_t_249)) {
          heff_drop_tag(v_best_242, 1);
          return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_f_243, 0, 8)});
        } else {
          heff_drop_rec(v_f_243, 8);
          return v_best_242;
        }
      }
      default: return heff_nomatch(v_best_242);
      }
    } else {
      heff_drop_rec(v_f_243, 8);
      heff_drop(v_x_241);
      return v_best_242;
    }
  } else {
    heff_drop_rec(v_f_243, 8);
    heff_drop(v_x_241);
    return v_best_242;
  }
}
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str0, 1, "=");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str1, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str2, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str3, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str4, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str5, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str6, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str7, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str8, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str9, 2, "--");
Clo g_std_2ecli_2elongF_24s1119688962x564470218_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elongF_24s1119688962x564470218_entry, 3, 0};

V g_std_2ecli_2elongF_24s1119688962x564470218(V v_at_240, V v_ws_241, V v_body_242) {
top: ;
  V v_t_243 = (g_prelude_2eindexFrom(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str0), heff_dup(v_body_242), MK_INT(0LL)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_std_2ecli_2elongNamed(heff_dup(heff_rfield(v_at_240, 0)), heff_dup(v_body_242)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Left: {
      V v_cands_245 = heff_field(v_t_244, 0);
      V v_ru_24t_244_24Left = heff_take_reuse_n(v_t_244, 1ULL, 1);
      heff_drop(v_ws_241);
      V v_t_249;
      switch (heff_tag_of(v_cands_245)) {
      case TAG_Nil: {
        V v_t_246 = (g_std_2ecli_2enearest(heff_get_n(v_at_240, 0, 5), heff_dup(v_body_242)));
        v_t_249 = heff_tag_n(TAG_Unknown, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str1), v_body_242), v_t_246});
        break;
      }
      case TAG_Cons: {
        heff_drop_rec(v_at_240, 5);
        v_t_249 = heff_tag_n(TAG_Ambiguous, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str2), v_body_242), v_cands_245});
        break;
      }
      default: heff_nomatch(v_cands_245);
      }
      return heff_tag_at_n(v_ru_24t_244_24Left, TAG_Left, 1, (V[]){v_t_249});
    }
    case TAG_Right: {
      V v_f_2410 = heff_field(v_t_244, 0);
      V v_ru_24t_244_24Right = heff_take_reuse_n(v_t_244, 1ULL, 1);
      heff_drop(v_body_242);
      if (heff_strEq_c(heff_dup(heff_rfield(v_f_2410, 2)), ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str3))) {
        heff_drop_cell(v_ru_24t_244_24Right, 1);
        V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2410, 0, 8), ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str4)});
        V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, heff_take_field(v_at_240, 4)});
        V v_t_2414 = ({ V rv_4 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_at_240, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
        return (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_t_2414, v_ws_241));
      } else {
        switch (heff_tag_of(v_ws_241)) {
        case TAG_Nil: {
          heff_drop_rec(v_at_240, 5);
          V v_t_2415 = heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str5), heff_get_n(v_f_2410, 0, 8));
          return heff_tag_at_n(v_ru_24t_244_24Right, TAG_Left, 1, (V[]){heff_tag_n(TAG_NoValue, 1, (V[]){v_t_2415})});
        }
        case TAG_Cons: {
          V v_v_2416 = heff_field(v_ws_241, 0);
          V v_ws2_2417 = heff_field(v_ws_241, 1);
          V v_ru_24ws_241_24Cons = heff_take_reuse_n(v_ws_241, 3ULL, 2);
          heff_drop_cell(v_ru_24t_244_24Right, 1);
          V v_t_2418 = heff_tag_at_n(v_ru_24ws_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_f_2410, 0, 8), v_v_2416});
          V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, heff_take_field(v_at_240, 4)});
          V v_t_2420 = ({ V rv_4 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_at_240, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
          return (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_t_2420, v_ws2_2417));
        }
        default: return heff_nomatch(v_ws_241);
        }
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_Just: {
    V v_i_2421 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2422 = (g_std_2ecli_2elongNamed(heff_dup(heff_rfield(v_at_240, 0)), heff_strSlice(heff_dup(v_body_242), MK_INT(0LL), heff_dup(v_i_2421))));
    switch (heff_tag_of(v_t_2422)) {
    case TAG_Left: {
      V v_cands_2423 = heff_field(v_t_2422, 0);
      heff_take_n(v_t_2422, 1ULL, 1);
      heff_drop(v_ws_241);
      V v_x_2424 = heff_strSlice(v_body_242, MK_INT(0LL), v_i_2421);
      V v_t_2428;
      switch (heff_tag_of(v_cands_2423)) {
      case TAG_Nil: {
        V v_t_2425 = (g_std_2ecli_2enearest(heff_get_n(v_at_240, 0, 5), heff_dup(v_x_2424)));
        v_t_2428 = heff_tag_n(TAG_Unknown, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str6), v_x_2424), v_t_2425});
        break;
      }
      case TAG_Cons: {
        heff_drop_rec(v_at_240, 5);
        v_t_2428 = heff_tag_n(TAG_Ambiguous, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str7), v_x_2424), v_cands_2423});
        break;
      }
      default: heff_nomatch(v_cands_2423);
      }
      return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Left, 1, (V[]){v_t_2428});
    }
    case TAG_Right: {
      V v_f_2429 = heff_field(v_t_2422, 0);
      heff_take_n(v_t_2422, 1ULL, 1);
      if (heff_strEq_c(heff_dup(heff_rfield(v_f_2429, 2)), ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str8))) {
        heff_drop_rec(v_at_240, 5);
        heff_drop(v_ws_241);
        heff_drop(v_body_242);
        heff_drop(v_i_2421);
        V v_t_2431 = heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str9), heff_get_n(v_f_2429, 0, 8));
        return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Left, 1, (V[]){heff_tag_n(TAG_SwitchValue, 1, (V[]){v_t_2431})});
      } else {
        heff_drop_cell(v_ru_24t_243_24Just, 1);
        V v_t_2432 = heff_strSlice(heff_dup(v_body_242), heff_intAdd(v_i_2421, MK_INT(1LL)), heff_strLength(v_body_242));
        V v_t_2433 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2429, 0, 8), v_t_2432});
        V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, heff_take_field(v_at_240, 4)});
        V v_t_2435 = ({ V rv_4 = v_t_2434; V rr_ = heff_rec_reuse_nf(v_at_240, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
        return (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_t_2435, v_ws_241));
      }
    }
    default: return heff_nomatch(v_t_2422);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_std_2ecli_2elongF_24s1119688962x564470218_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2elongF_24s1119688962x564470218(a[0], a[1], a[2]);
}
HEFF_LIT(g_std_2ecli_2eshortF_24s1014269042x1715098139_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eshortF_24s1014269042x1715098139_str1, 0, "");
HEFF_LIT(g_std_2ecli_2eshortF_24s1014269042x1715098139_str2, 1, "-");
HEFF_LIT(g_std_2ecli_2eshortF_24s1014269042x1715098139_str3, 0, "");
HEFF_LIT(g_std_2ecli_2eshortF_24s1014269042x1715098139_str4, 0, "");
HEFF_LIT(g_std_2ecli_2eshortF_24s1014269042x1715098139_str5, 1, "-");
V g_std_2ecli_2eshortF_24s1014269042x1715098139_lam0(V self, V *args);
Clo g_std_2ecli_2eshortF_24s1014269042x1715098139_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eshortF_24s1014269042x1715098139_entry, 3, 0};

V g_std_2ecli_2eshortF_24s1014269042x1715098139(V v_at_240, V v_ws_241, V v_cl_242) {
top: ;
  if (heff_strEq_c(heff_dup(v_cl_242), ((V)&g_std_2ecli_2eshortF_24s1014269042x1715098139_str0))) {
    heff_drop(v_cl_242);
    return (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_at_240, v_ws_241));
  } else {
    V v_x_244 = heff_strSlice(heff_dup(v_cl_242), MK_INT(0LL), MK_INT(1LL));
    V v_t_248;
    if (heff_strEq_c(heff_dup(v_x_244), ((V)&g_std_2ecli_2eshortF_24s1014269042x1715098139_str1))) {
      heff_drop(v_x_244);
      v_t_248 = NTAG(TAG_Nothing);
    } else {
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_at_240, 0)), 0, 2);
      v_t_248 = ({ V a_0 = heff_clo_n(g_std_2ecli_2eshortF_24s1014269042x1715098139_lam0, 1, 1, (V[]){v_x_244}); V a_1 = v_t_246; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_t_246); r_; });
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop_rec(v_at_240, 5);
      heff_drop(v_ws_241);
      V v_t_249 = heff_strAppend(((V)&g_std_2ecli_2eshortF_24s1014269042x1715098139_str2), heff_strSlice(v_cl_242, MK_INT(0LL), MK_INT(1LL)));
      V v_t_2410 = heff_tag_n(TAG_Unknown, 2, (V[]){v_t_249, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_Left, 1, (V[]){v_t_2410});
    }
    case TAG_Just: {
      V v_f_2411 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
      if (heff_strEq_c(heff_dup(heff_rfield(v_f_2411, 2)), ((V)&g_std_2ecli_2eshortF_24s1014269042x1715098139_str3))) {
        heff_drop_cell(v_ru_24t_248_24Just, 1);
        V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2411, 0, 8), ((V)&g_std_2ecli_2eshortF_24s1014269042x1715098139_str4)});
        V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, heff_take_field(v_at_240, 4)});
        V v_t_2415 = ({ V rv_4 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_at_240, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
        V v_t_2416 = heff_strSlice(heff_dup(v_cl_242), MK_INT(1LL), heff_strLength(v_cl_242));
        V t_0 = v_t_2415;
        V t_1 = v_ws_241;
        V t_2 = v_t_2416;
        v_at_240 = t_0;
        v_ws_241 = t_1;
        v_cl_242 = t_2;
        goto top;
      } else {
        if (heff_intLt_c(MK_INT(1LL), heff_strLength(heff_dup(v_cl_242)))) {
          heff_drop_cell(v_ru_24t_248_24Just, 1);
          V v_t_2418 = heff_strSlice(heff_dup(v_cl_242), MK_INT(1LL), heff_strLength(v_cl_242));
          V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2411, 0, 8), v_t_2418});
          V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, heff_take_field(v_at_240, 4)});
          V v_t_2421 = ({ V rv_4 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_at_240, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
          return (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_t_2421, v_ws_241));
        } else {
          heff_drop(v_cl_242);
          switch (heff_tag_of(v_ws_241)) {
          case TAG_Nil: {
            heff_drop_rec(v_at_240, 5);
            V v_t_2422 = heff_strAppend(((V)&g_std_2ecli_2eshortF_24s1014269042x1715098139_str5), heff_get_n(v_f_2411, 1, 8));
            return heff_tag_at_n(v_ru_24t_248_24Just, TAG_Left, 1, (V[]){heff_tag_n(TAG_NoValue, 1, (V[]){v_t_2422})});
          }
          case TAG_Cons: {
            V v_v_2423 = heff_field(v_ws_241, 0);
            V v_ws2_2424 = heff_field(v_ws_241, 1);
            V v_ru_24ws_241_24Cons = heff_take_reuse_n(v_ws_241, 3ULL, 2);
            heff_drop_cell(v_ru_24t_248_24Just, 1);
            V v_t_2425 = heff_tag_at_n(v_ru_24ws_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_f_2411, 0, 8), v_v_2423});
            V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, heff_take_field(v_at_240, 4)});
            V v_t_2427 = ({ V rv_4 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_at_240, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
            return (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_t_2427, v_ws2_2424));
          }
          default: return heff_nomatch(v_ws_241);
          }
        }
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
}
V g_std_2ecli_2eshortF_24s1014269042x1715098139_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eshortF_24s1014269042x1715098139(a[0], a[1], a[2]);
}
V g_std_2ecli_2eshortF_24s1014269042x1715098139_lam0(V self, V *args) {
  V v_f_247 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_f_247, 1, 8), v_x_244);
}
HEFF_LIT(g_std_2ecli_2eflagProblem_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eflagProblem_str1, 0, "");
HEFF_LIT(g_std_2ecli_2eflagProblem_str2, 1, "=");
HEFF_LIT(g_std_2ecli_2eflagProblem_str3, 2, "--");
HEFF_LIT(g_std_2ecli_2eflagProblem_str4, 2, "--");
V g_std_2ecli_2eflagProblem_lam0(V self, V *args);
V g_std_2ecli_2eflagProblem_lam1(V self, V *args);
V g_std_2ecli_2eflagProblem_lam2(V self, V *args);
Clo g_std_2ecli_2eflagProblem_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eflagProblem_entry, 2, 0};

V g_std_2ecli_2eflagProblem(V v_fs_240, V v_f_241) {
top: ;
  V v_t_246 = (g_list_2efilter(heff_clo_n(g_std_2ecli_2eflagProblem_lam0, 1, 1, (V[]){heff_dup(v_f_241)}), heff_dup(v_fs_240)));
  V v_x1_247 = (g_list_2emap_24s1173914895x100384474(v_t_246));
  V v_t_2410;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nil: {
    v_t_2410 = heff_dup(heff_rfield(v_f_241, 6));
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_247, 0ULL, 2);
    v_t_2410 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_fs_240);
    heff_drop(v_t_2410);
    V v_t_2412;
    if (heff_strEq_c(heff_dup(heff_rfield(v_f_241, 2)), ((V)&g_std_2ecli_2eflagProblem_str0))) {
      v_t_2412 = ((V)&g_std_2ecli_2eflagProblem_str1);
    } else {
      v_t_2412 = heff_strAppend(((V)&g_std_2ecli_2eflagProblem_str2), heff_dup(heff_rfield(v_f_241, 2)));
    }
    V v_t_2413 = heff_strAppend(heff_get_n(v_f_241, 0, 8), v_t_2412);
    V v_t_2414 = heff_tag_n(TAG_MissingFlag, 1, (V[]){heff_strAppend(((V)&g_std_2ecli_2eflagProblem_str3), v_t_2413)});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
  } else {
    heff_drop(v_t_2410);
    V v_t_2419 = (g_list_2efilter(heff_clo_n(g_std_2ecli_2eflagProblem_lam1, 1, 1, (V[]){heff_dup(v_f_241)}), v_fs_240));
    V v_t_2420 = (g_list_2emap_24s1173914895x100384474(v_t_2419));
    V v_t_2428 = ({ V a_0 = heff_clo_n(g_std_2ecli_2eflagProblem_lam2, 1, 1, (V[]){heff_dup(v_f_241)}); V a_1 = v_t_2420; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_t_2420); r_; });
    switch (heff_tag_of(v_t_2428)) {
    case TAG_Nothing: {
      heff_drop_rec(v_f_241, 8);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_v_2429 = heff_field(v_t_2428, 0);
      V v_ru_24t_2428_24Just = heff_take_reuse_n(v_t_2428, 1ULL, 1);
      V v_t_2430 = heff_strAppend(((V)&g_std_2ecli_2eflagProblem_str4), heff_take_field(v_f_241, 0));
      V v_t_2431 = heff_tag_n(TAG_NotIn, 3, (V[]){v_t_2430, v_v_2429, heff_get_n(v_f_241, 4, 8)});
      return heff_tag_at_n(v_ru_24t_2428_24Just, TAG_Just, 1, (V[]){v_t_2431});
    }
    default: return heff_nomatch(v_t_2428);
    }
  }
}
V g_std_2ecli_2eflagProblem_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eflagProblem(a[0], a[1]);
}
V g_std_2ecli_2eflagProblem_lam0(V self, V *args) {
  V v_p_242 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245;
  switch (heff_tag_of(v_p_242)) {
  case TAG_MkPair: {
    V v_x_243 = heff_field(v_p_242, 0);
    heff_take_n(v_p_242, 1ULL, 2);
    v_t_245 = v_x_243;
    break;
  }
  default: heff_nomatch(v_p_242);
  }
  return heff_strEq(v_t_245, heff_get_n(v_f_241, 0, 8));
}
V g_std_2ecli_2eflagProblem_lam1(V self, V *args) {
  V v_p_2415 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418;
  switch (heff_tag_of(v_p_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_p_2415, 0);
    heff_take_n(v_p_2415, 1ULL, 2);
    v_t_2418 = v_x_2416;
    break;
  }
  default: heff_nomatch(v_p_2415);
  }
  return heff_strEq(v_t_2418, heff_get_n(v_f_241, 0, 8));
}
V g_std_2ecli_2eflagProblem_lam2(V self, V *args) {
  V v_v_2421 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_dup(heff_rfield(v_f_241, 4));
  V v_x1_2425;
  switch (heff_tag_of(v_t_2422)) {
  case TAG_Nil: {
    v_x1_2425 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_2422, 0ULL, 2);
    v_x1_2425 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2422);
  }
  V v_ret_24bool = heff_bool(((heff_dup(v_x1_2425) == NTAG(TAG_True)) ? 0 : ({ V v_t_2426 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_v_2421)})); int c_ = ({ V v_x1_2427 = (g_list_2eany(heff_dup(v_t_2426), heff_rfield(v_f_241, 4))); int c_ = !(heff_dup(v_x1_2427) == NTAG(TAG_True)); heff_drop(v_x1_2427); c_; }); heff_drop(v_t_2426); c_; })));
  heff_drop(v_v_2421);
  heff_drop_rec(v_f_241, 8);
  heff_drop(v_x1_2425);
  return v_ret_24bool;
}
V g_std_2ecli_2eparse_lam1(V self, V *args);
V g_std_2ecli_2eparse_lam0(V self, V *args);
Clo g_std_2ecli_2eparse_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eparse_entry, 2, 0};

V g_std_2ecli_2eparse(V v_t_240, V v_ws_241) {
top: ;
  V v_t_242 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
  V v_t_243 = (g_std_2ecli_2eshapeProblem(heff_get_n(v_t_242, 0, 2)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
    V v_sh_245 = heff_get_n(v_t_244, 0, 2);
    V v_t_246 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_245, 1), MK_INT(0LL)));
    V v_at_247 = heff_rec_n(5, shape_sh__ra__on__ps__fs, (V[]){v_sh_245, v_t_246, NTAG(TAG_True), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_248 = (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_at_247, v_ws_241));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Left: {
      V v_p_249 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Left = heff_take_reuse_n(v_t_248, 1ULL, 1);
      heff_drop(v_t_240);
      return heff_tag_at_n(v_ru_24t_248_24Left, TAG_Left, 1, (V[]){v_p_249});
    }
    case TAG_Right: {
      V v_sp_2410 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Right = heff_take_reuse_n(v_t_248, 1ULL, 1);
      V v_t_2411 = heff_tr(heff_call(((V)&g_std_2ecli_2eflagProblem_clo), 1, (V[]){heff_dup(heff_rfield(v_sp_2410, 1))}));
      V v_t_2412 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
      V v_t_2413 = heff_get_n(heff_get_n(v_t_2412, 0, 2), 0, 2);
      V v_t_2414 = ({ V a_0 = v_t_2411; V a_1 = v_t_2413; V r_ = (g_std_2ecli_2efirstJust(a_0, a_1)); heff_drop(v_t_2413); r_; });
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nothing: {
        V v_t_2415 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
        V v_t_2416 = heff_get_n(heff_get_n(v_t_2415, 0, 2), 1, 2);
        V v_t_2417 = (g_std_2ecli_2egroupsGo(v_t_2416, heff_dup(heff_rfield(v_sp_2410, 0))));
        switch (heff_tag_of(v_t_2417)) {
        case TAG_Left: {
          V v_p_2418 = heff_field(v_t_2417, 0);
          heff_take_n(v_t_2417, 1ULL, 1);
          heff_drop(v_t_240);
          heff_drop_rec(v_sp_2410, 2);
          return heff_tag_at_n(v_ru_24t_248_24Right, TAG_Left, 1, (V[]){v_p_2418});
        }
        case TAG_Right: {
          V v_gs_2419 = heff_field(v_t_2417, 0);
          heff_take_n(v_t_2417, 1ULL, 1);
          V v_t_2420 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_t_2421 = heff_tr(heff_call(v_t_240, 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_t_2422 = heff_get_n(heff_get_n(v_t_2421, 0, 2), 0, 2);
          V v_t_2430 = (g_list_2emap(heff_clo_n(g_std_2ecli_2eparse_lam0, 1, 1, (V[]){v_sp_2410}), v_t_2422));
          V v_t_2431 = heff_tr(heff_call(heff_get_n(v_t_2420, 1, 2), 2, (V[]){v_gs_2419, v_t_2430}));
          return heff_tag_at_n(v_ru_24t_248_24Right, TAG_Right, 1, (V[]){v_t_2431});
        }
        default: return heff_nomatch(v_t_2417);
        }
      }
      case TAG_Just: {
        V v_p_2432 = heff_field(v_t_2414, 0);
        heff_take_n(v_t_2414, 1ULL, 1);
        heff_drop(v_t_240);
        heff_drop_rec(v_sp_2410, 2);
        return heff_tag_at_n(v_ru_24t_248_24Right, TAG_Left, 1, (V[]){v_p_2432});
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  case TAG_Just: {
    V v_why_2433 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_t_240);
    heff_drop(v_ws_241);
    return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Left, 1, (V[]){heff_tag_n(TAG_BadShape, 1, (V[]){v_why_2433})});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_std_2ecli_2eparse_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eparse(a[0], a[1]);
}
V g_std_2ecli_2eparse_lam1(V self, V *args) {
  V v_p_2424 = args[0];
  V v_f_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427;
  switch (heff_tag_of(v_p_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_p_2424, 0);
    heff_take_n(v_p_2424, 1ULL, 2);
    v_t_2427 = v_x_2425;
    break;
  }
  default: heff_nomatch(v_p_2424);
  }
  return heff_strEq(v_t_2427, heff_get_n(v_f_2423, 0, 8));
}
V g_std_2ecli_2eparse_lam0(V self, V *args) {
  V v_f_2423 = args[0];
  V v_sp_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = (g_list_2efilter(heff_clo_n(g_std_2ecli_2eparse_lam1, 1, 1, (V[]){heff_dup(v_f_2423)}), heff_get_n(v_sp_2410, 1, 2)));
  V v_t_2429 = (g_list_2emap_24s1173914895x100384474(v_t_2428));
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2423, 0, 8), v_t_2429});
}
Clo g_std_2ecli_2eposAt_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eposAt_entry, 2, 0};

V g_std_2ecli_2eposAt(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_ps_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_dup(heff_rfield(v_p_242, 1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_One: {
      if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
        heff_drop(v_i_241);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_p_242)});
      } else {
        V t_0 = v_ps_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
    case TAG_Optional: {
      if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
        heff_drop(v_i_241);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_p_242)});
      } else {
        V t_0 = v_ps_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
    case TAG_Many: {
      heff_drop(v_i_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_p_242)});
    }
    case TAG_Some: {
      heff_drop(v_i_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_p_242)});
    }
    case TAG_Rest: {
      heff_drop(v_i_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_p_242)});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2eposAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2eposAt(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2eheadOf_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eheadOf_str1, 1, " ");
HEFF_LIT(g_std_2ecli_2eheadOf_str2, 0, "");
HEFF_LIT(g_std_2ecli_2eheadOf_str3, 0, "");
HEFF_LIT(g_std_2ecli_2eheadOf_str4, 1, " ");
HEFF_LIT(g_std_2ecli_2eheadOf_str5, 1, " ");
Clo g_std_2ecli_2eheadOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eheadOf_entry, 1, 0};

V g_std_2ecli_2eheadOf(V v_k_240) {
top: ;
  V v_t_241 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 3)), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
  V v_sh_242 = heff_get_n(v_t_241, 0, 2);
  V v_t_243 = (g_list_2emap_24s2029999044x514618413(heff_take_field(v_sh_242, 1)));
  V v_t_244 = (g_list_2emap_24s1281445768x1036802655(heff_get_n(v_sh_242, 0, 2)));
  V v_xs_245 = (g_prelude_2e_2b_2b(v_t_243, v_t_244));
  V v_t_248;
  switch (heff_tag_of(v_xs_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_std_2ecli_2eheadOf_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_xs_245, 0);
    V v_xs_247 = heff_field(v_xs_245, 1);
    heff_take_n(v_xs_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_std_2ecli_2eheadOf_str1); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_xs_245);
  }
  if (heff_strEq_c(v_t_248, ((V)&g_std_2ecli_2eheadOf_str2))) {
    return heff_get_n(v_k_240, 0, 4);
  } else {
    V v_t_2410 = heff_tr(heff_call(heff_take_field(v_k_240, 3), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
    V v_sh_2411 = heff_get_n(v_t_2410, 0, 2);
    V v_t_2412 = (g_list_2emap_24s2029999044x514618413(heff_take_field(v_sh_2411, 1)));
    V v_t_2413 = (g_list_2emap_24s1281445768x1036802655(heff_get_n(v_sh_2411, 0, 2)));
    V v_xs_2414 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2413));
    V v_t_2417;
    switch (heff_tag_of(v_xs_2414)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_std_2ecli_2eheadOf_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_xs_2414, 0);
      V v_xs_2416 = heff_field(v_xs_2414, 1);
      heff_take_n(v_xs_2414, 3ULL, 2);
      v_t_2417 = ({ V a_0 = ((V)&g_std_2ecli_2eheadOf_str4); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_xs_2414);
    }
    return heff_strAppend(heff_get_n(v_k_240, 0, 4), heff_strAppend(((V)&g_std_2ecli_2eheadOf_str5), v_t_2417));
  }
}
V g_std_2ecli_2eheadOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eheadOf(a[0]);
}
HEFF_LIT(g_std_2ecli_2eusage_str0, 7, "usage: ");
HEFF_LIT(g_std_2ecli_2eusage_str1, 12, " COMMAND ...");
HEFF_LIT(g_std_2ecli_2eusage_str2, 0, "");
HEFF_LIT(g_std_2ecli_2eusage_str3, 14, "help [COMMAND]");
HEFF_LIT(g_std_2ecli_2eusage_str4, 26, "this, or a command's flags");
HEFF_LIT(g_std_2ecli_2eusage_str5, 17, "completions SHELL");
HEFF_LIT(g_std_2ecli_2eusage_str6, 48, "a completion script for SHELL: fish, bash or zsh");
HEFF_LIT(g_std_2ecli_2eusage_str7, 0, "");
HEFF_LIT(g_std_2ecli_2eusage_str8, 1, "\012");
HEFF_LIT(g_std_2ecli_2eusage_str9, 1, "\012");
Clo g_std_2ecli_2eusage_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eusage_entry, 2, 0};

V g_std_2ecli_2eusage(V v_prog_240, V v_cs_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_std_2ecli_2eusage_str0), heff_strAppend(v_prog_240, ((V)&g_std_2ecli_2eusage_str1)));
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2eusage_str2), NTAG(TAG_Nil)});
  V v_t_244 = (g_list_2efilter_24s1623010005x1805617852(v_cs_241));
  V v_t_245 = (g_list_2emap_24s296585291x885335139(v_t_244));
  V v_t_246 = (g_std_2ecli_2eline2(((V)&g_std_2ecli_2eusage_str3), ((V)&g_std_2ecli_2eusage_str4)));
  V v_t_247 = (g_std_2ecli_2eline2(((V)&g_std_2ecli_2eusage_str5), ((V)&g_std_2ecli_2eusage_str6)));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = (g_prelude_2e_2b_2b(v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_248})));
  V v_x2_2410 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_243}), v_t_249));
  V v_t_2413;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    v_t_2413 = ((V)&g_std_2ecli_2eusage_str7);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    heff_take_n(v_x2_2410, 3ULL, 2);
    v_t_2413 = ({ V a_0 = ((V)&g_std_2ecli_2eusage_str8); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  return heff_strAppend(v_t_2413, ((V)&g_std_2ecli_2eusage_str9));
}
V g_std_2ecli_2eusage_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eusage(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2eorList_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eorList_str1, 4, " or ");
HEFF_LIT(g_std_2ecli_2eorList_str2, 2, ", ");
Clo g_std_2ecli_2eorList_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eorList_entry, 1, 0};

V g_std_2ecli_2eorList(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_std_2ecli_2eorList_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_y_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_std_2ecli_2eorList_str1), heff_dup(v_y_243)));
      }
      case TAG_Cons: {
        V v_s_247 = heff_dup(v_x_241);
        V v_s_248 = heff_strAppend(v_s_247, ((V)&g_std_2ecli_2eorList_str2));
        return (g_std_2ecli_2eorList_24acc(v_x12_242, v_s_248));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2eorList_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2eorList(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2eshells_str0, 3, "zsh");
HEFF_LIT(g_std_2ecli_2eshells_str1, 4, "fish");
HEFF_LIT(g_std_2ecli_2eshells_str2, 4, "bash");

static V g_std_2ecli_2eshells_val;
static HEFF_ONCE g_std_2ecli_2eshells_st;
static V g_std_2ecli_2eshells_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2eshells_str0), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2eshells_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2eshells_str2), v_t_240})});
}
V g_std_2ecli_2eshells_get(void) {
  if (HEFF_DONE(g_std_2ecli_2eshells_st)) return g_std_2ecli_2eshells_val;
  return heff_global(&g_std_2ecli_2eshells_val, &g_std_2ecli_2eshells_st, g_std_2ecli_2eshells_init);
}
HEFF_LIT(g_std_2ecli_2ecompleteWords_str0, 4, "help");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str1, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str2, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str3, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str4, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str5, 11, "completions");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str6, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str7, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str8, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str9, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str10, 0, "");
V g_std_2ecli_2ecompleteWords_lam0(V self, V *args);
V g_std_2ecli_2ecompleteWords_lam1(V self, V *args);
V g_std_2ecli_2ecompleteWords_lam2(V self, V *args);
V g_std_2ecli_2ecompleteWords_lam3(V self, V *args);
V g_std_2ecli_2ecompleteWords_lam4(V self, V *args);
Clo g_std_2ecli_2ecompleteWords_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecompleteWords_entry, 3, 0};

V g_std_2ecli_2ecompleteWords(V v_cs_240, V v_x2_241, V v_cur_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return (g_std_2ecli_2ecommandsText(v_cs_240, v_cur_242));
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_x22_244 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x21_243), ((V)&g_std_2ecli_2ecompleteWords_str0))) {
      switch (heff_tag_of(v_x22_244)) {
      case TAG_Nil: {
        V v_x2_248 = (g_list_2emap_24f935318736x1254281698_24f812639102x862288937(((V)&g_std_2ecli_2ecompleteWords_str1), heff_clo_n(g_std_2ecli_2ecompleteWords_lam0, 1, 1, (V[]){v_cur_242}), v_cs_240));
        switch (heff_tag_of(v_x2_248)) {
        case TAG_Nil: {
          return ((V)&g_std_2ecli_2ecompleteWords_str2);
        }
        case TAG_Cons: {
          V v_x_249 = heff_field(v_x2_248, 0);
          V v_xs_2410 = heff_field(v_x2_248, 1);
          heff_take_n(v_x2_248, 3ULL, 2);
          return ({ V a_0 = ((V)&g_std_2ecli_2ecompleteWords_str3); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
        }
        default: return heff_nomatch(v_x2_248);
        }
      }
      case TAG_Cons: {
        V v_t_2414 = ({ V a_0 = heff_clo_n(g_std_2ecli_2ecompleteWords_lam1, 1, 1, (V[]){heff_dup(v_x21_243)}); V a_1 = v_cs_240; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_cs_240); r_; });
        switch (heff_tag_of(v_t_2414)) {
        case TAG_Nothing: {
          heff_drop(v_cur_242);
          return ((V)&g_std_2ecli_2ecompleteWords_str4);
        }
        case TAG_Just: {
          V v_k_2415 = heff_field(v_t_2414, 0);
          heff_take_n(v_t_2414, 1ULL, 1);
          V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_2415, 3)), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_t_2417 = heff_tr(heff_call(heff_get_n(v_k_2415, 3, 4), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_sh_2418 = heff_get_n(v_t_2417, 0, 2);
          V v_t_2419 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_2418, 1), MK_INT(0LL)));
          V v_t_2420 = heff_rec_n(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_True), NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil)});
          V v_t_2421 = (g_std_2ecli_2ewhereGo(heff_dup(v_sh_2418), v_t_2419, v_t_2420, heff_dup(v_x22_244)));
          V v_t_2422 = (g_std_2ecli_2ecompleteAt(v_sh_2418, v_t_2421, v_cur_242));
          return ({ V a_0 = heff_get_n(v_t_2416, 0, 2); V a_1 = v_t_2422; V r_ = (g_std_2ecli_2ecandidatesText(a_0, a_1)); heff_drop(v_t_2422); r_; });
        }
        default: return heff_nomatch(v_t_2414);
        }
      }
      default: return heff_nomatch(v_x22_244);
      }
    } else {
      if (heff_strEq_c(heff_dup(v_x21_243), ((V)&g_std_2ecli_2ecompleteWords_str5))) {
        switch (heff_tag_of(v_x22_244)) {
        case TAG_Nil: {
          heff_drop(v_cs_240);
          V v_x2_2426 = (g_list_2emap_24f935318736x1254281698(((V)&g_std_2ecli_2ecompleteWords_str6), heff_clo_n(g_std_2ecli_2ecompleteWords_lam2, 1, 1, (V[]){v_cur_242}), heff_dup(g_std_2ecli_2eshells_get())));
          switch (heff_tag_of(v_x2_2426)) {
          case TAG_Nil: {
            return ((V)&g_std_2ecli_2ecompleteWords_str7);
          }
          case TAG_Cons: {
            V v_x_2427 = heff_field(v_x2_2426, 0);
            V v_xs_2428 = heff_field(v_x2_2426, 1);
            heff_take_n(v_x2_2426, 3ULL, 2);
            return ({ V a_0 = ((V)&g_std_2ecli_2ecompleteWords_str8); V a_1 = v_x_2427; V a_2 = v_xs_2428; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2428); r_; });
          }
          default: return heff_nomatch(v_x2_2426);
          }
        }
        case TAG_Cons: {
          V v_t_2432 = ({ V a_0 = heff_clo_n(g_std_2ecli_2ecompleteWords_lam3, 1, 1, (V[]){heff_dup(v_x21_243)}); V a_1 = v_cs_240; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_cs_240); r_; });
          switch (heff_tag_of(v_t_2432)) {
          case TAG_Nothing: {
            heff_drop(v_cur_242);
            return ((V)&g_std_2ecli_2ecompleteWords_str9);
          }
          case TAG_Just: {
            V v_k_2433 = heff_field(v_t_2432, 0);
            heff_take_n(v_t_2432, 1ULL, 1);
            V v_t_2434 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_2433, 3)), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
            V v_t_2435 = heff_tr(heff_call(heff_get_n(v_k_2433, 3, 4), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
            V v_sh_2436 = heff_get_n(v_t_2435, 0, 2);
            V v_t_2437 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_2436, 1), MK_INT(0LL)));
            V v_t_2438 = heff_rec_n(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_True), NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil)});
            V v_t_2439 = (g_std_2ecli_2ewhereGo(heff_dup(v_sh_2436), v_t_2437, v_t_2438, heff_dup(v_x22_244)));
            V v_t_2440 = (g_std_2ecli_2ecompleteAt(v_sh_2436, v_t_2439, v_cur_242));
            return ({ V a_0 = heff_get_n(v_t_2434, 0, 2); V a_1 = v_t_2440; V r_ = (g_std_2ecli_2ecandidatesText(a_0, a_1)); heff_drop(v_t_2440); r_; });
          }
          default: return heff_nomatch(v_t_2432);
          }
        }
        default: return heff_nomatch(v_x22_244);
        }
      } else {
        V v_t_2442 = ({ V a_0 = heff_clo_n(g_std_2ecli_2ecompleteWords_lam4, 1, 1, (V[]){heff_dup(v_x21_243)}); V a_1 = v_cs_240; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_cs_240); r_; });
        switch (heff_tag_of(v_t_2442)) {
        case TAG_Nothing: {
          heff_drop(v_cur_242);
          return ((V)&g_std_2ecli_2ecompleteWords_str10);
        }
        case TAG_Just: {
          V v_k_2443 = heff_field(v_t_2442, 0);
          heff_take_n(v_t_2442, 1ULL, 1);
          V v_t_2444 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_2443, 3)), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_t_2445 = heff_tr(heff_call(heff_get_n(v_k_2443, 3, 4), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_sh_2446 = heff_get_n(v_t_2445, 0, 2);
          V v_t_2447 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_2446, 1), MK_INT(0LL)));
          V v_t_2448 = heff_rec_n(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_True), NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil)});
          V v_t_2449 = (g_std_2ecli_2ewhereGo(heff_dup(v_sh_2446), v_t_2447, v_t_2448, heff_dup(v_x22_244)));
          V v_t_2450 = (g_std_2ecli_2ecompleteAt(v_sh_2446, v_t_2449, v_cur_242));
          return ({ V a_0 = heff_get_n(v_t_2444, 0, 2); V a_1 = v_t_2450; V r_ = (g_std_2ecli_2ecandidatesText(a_0, a_1)); heff_drop(v_t_2450); r_; });
        }
        default: return heff_nomatch(v_t_2442);
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2ecompleteWords_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2ecompleteWords(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_std_2ecli_2ecompleteWords_lam0(V self, V *args) {
  V v_w_246 = args[0];
  V v_cur_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_strSlice(v_w_246, MK_INT(0LL), heff_strLength(heff_dup(v_cur_242)));
  return heff_strEq(v_t_247, v_cur_242);
}
V g_std_2ecli_2ecompleteWords_lam1(V self, V *args) {
  V v_k_2413 = args[0];
  V v_x21_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_k_2413, 0, 4), v_x21_243);
}
V g_std_2ecli_2ecompleteWords_lam2(V self, V *args) {
  V v_w_2424 = args[0];
  V v_cur_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_strSlice(v_w_2424, MK_INT(0LL), heff_strLength(heff_dup(v_cur_242)));
  return heff_strEq(v_t_2425, v_cur_242);
}
V g_std_2ecli_2ecompleteWords_lam3(V self, V *args) {
  V v_k_2431 = args[0];
  V v_x21_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_k_2431, 0, 4), v_x21_243);
}
V g_std_2ecli_2ecompleteWords_lam4(V self, V *args) {
  V v_k_2441 = args[0];
  V v_x21_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_k_2441, 0, 4), v_x21_243);
}
Clo g_std_2ecli_2einitOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einitOf_entry, 1, 0};

V g_std_2ecli_2einitOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_246 = (g_std_2ecli_2einitOf_24dps(v_x12_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einitOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einitOf(a[0]);
}
HEFF_LIT(g_std_2ecli_2elastOf_str0, 0, "");
Clo g_std_2ecli_2elastOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elastOf_entry, 1, 0};

V g_std_2ecli_2elastOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_std_2ecli_2elastOf_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2elastOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2elastOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2ezshScript_str0, 14, ": written by `");
HEFF_LIT(g_std_2ecli_2ezshScript_str1, 17, " completions zsh`");
HEFF_LIT(g_std_2ecli_2ezshScript_str2, 2, "# ");
HEFF_LIT(g_std_2ecli_2ezshScript_str3, 1, "_");
HEFF_LIT(g_std_2ecli_2ezshScript_str4, 4, "() {");
HEFF_LIT(g_std_2ecli_2ezshScript_str5, 16, "  out=(\"${(@f)$(");
HEFF_LIT(g_std_2ecli_2ezshScript_str6, 38, " complete \"${(@)words[2,CURRENT]}\")}\")");
HEFF_LIT(g_std_2ecli_2ezshScript_str7, 16, "      _describe ");
HEFF_LIT(g_std_2ecli_2ezshScript_str8, 9, " cands ;;");
HEFF_LIT(g_std_2ecli_2ezshScript_str9, 1, " ");
HEFF_LIT(g_std_2ecli_2ezshScript_str10, 4, "; fi");
HEFF_LIT(g_std_2ecli_2ezshScript_str11, 21, " \"$@\"; else compdef _");
HEFF_LIT(g_std_2ecli_2ezshScript_str12, 10, " ]; then _");
HEFF_LIT(g_std_2ecli_2ezshScript_str13, 24, "if [ \"$funcstack[1]\" = _");
HEFF_LIT(g_std_2ecli_2ezshScript_str14, 6, "  esac");
HEFF_LIT(g_std_2ecli_2ezshScript_str15, 1, "}");
HEFF_LIT(g_std_2ecli_2ezshScript_str16, 10, "      done");
HEFF_LIT(g_std_2ecli_2ezshScript_str17, 32, "          cands+=(\"${l//:/\\\\:}\")");
HEFF_LIT(g_std_2ecli_2ezshScript_str18, 10, "        fi");
HEFF_LIT(g_std_2ecli_2ezshScript_str19, 55, "          cands+=(\"${${l%%$'\\t'*}//:/\\\\:}:${l#*$'\\t'}\")");
HEFF_LIT(g_std_2ecli_2ezshScript_str20, 12, "        else");
HEFF_LIT(g_std_2ecli_2ezshScript_str21, 31, "        [[ -z $l ]] && continue");
HEFF_LIT(g_std_2ecli_2ezshScript_str22, 36, "        if [[ $l == *$'\\t'* ]]; then");
HEFF_LIT(g_std_2ecli_2ezshScript_str23, 6, "    *)");
HEFF_LIT(g_std_2ecli_2ezshScript_str24, 23, "      for l in $out; do");
HEFF_LIT(g_std_2ecli_2ezshScript_str25, 49, "    ':files '*) _files -g \"*${out[1]#:files }\" ;;");
HEFF_LIT(g_std_2ecli_2ezshScript_str26, 25, "    ':dirs') _files -/ ;;");
HEFF_LIT(g_std_2ecli_2ezshScript_str27, 17, "  case $out[1] in");
HEFF_LIT(g_std_2ecli_2ezshScript_str28, 20, "  local -a out cands");
HEFF_LIT(g_std_2ecli_2ezshScript_str29, 9, "  local l");
HEFF_LIT(g_std_2ecli_2ezshScript_str30, 1, "\012");
HEFF_LIT(g_std_2ecli_2ezshScript_str31, 9, "#compdef ");
Clo g_std_2ecli_2ezshScript_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ezshScript_entry, 1, 0};

V g_std_2ecli_2ezshScript(V v_prog_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str0), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ezshScript_str1)));
  V v_t_242 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str2), heff_strAppend(heff_dup(v_prog_240), v_t_241));
  V v_t_243 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str3), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ezshScript_str4)));
  V v_t_244 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str5), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ezshScript_str6)));
  V v_t_245 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str7), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ezshScript_str8)));
  V v_t_246 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str9), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ezshScript_str10)));
  V v_t_247 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str11), heff_strAppend(heff_dup(v_prog_240), v_t_246));
  V v_t_248 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str12), heff_strAppend(heff_dup(v_prog_240), v_t_247));
  V v_t_249 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str13), heff_strAppend(heff_dup(v_prog_240), v_t_248));
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str14), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str15), v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str16), heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str17), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str18), v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str19), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str20), v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str21), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str22), v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str23), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str24), v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str25), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str26), v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str27), v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str28), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str29), v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_2419})});
  return ({ V a_0 = ((V)&g_std_2ecli_2ezshScript_str30); V a_1 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str31), v_prog_240); V a_2 = v_t_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2420, 2); r_; });
}
V g_std_2ecli_2ezshScript_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ezshScript(a[0]);
}
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str0, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str1, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str2, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str3, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str4, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str5, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str6, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str7, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str8, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str9, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str10, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str11, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str12, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str13, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str14, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str15, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str16, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str17, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str18, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str19, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str20, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str21, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str22, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str23, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str24, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str25, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str26, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str27, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str28, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str29, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str30, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str31, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str32, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str33, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str34, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str35, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str36, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str37, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str38, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str39, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str40, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str41, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str42, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str43, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str44, 1, " ");
Clo g_std_2ecli_2eoutcomeOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eoutcomeOf_entry, 3, 0};

V g_std_2ecli_2eoutcomeOf(V v_prog_240, V v_k_241, V v_ws_242) {
top: ;
  V v_it_243 = (g_std_2ecli_2eparse(heff_dup(heff_rfield(v_k_241, 3)), v_ws_242));
  switch (heff_tag_of(v_it_243)) {
  case TAG_Left: {
    V v_it1_244 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Left = heff_take_reuse_n(v_it_243, 1ULL, 1);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_Unknown: {
      V v_t_247 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 2); r_; });
      V v_t_248 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_249 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str0), heff_strAppend(v_t_248, ((V)&g_std_2ecli_2eoutcomeOf_str1)));
      V v_t_2410 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str2), heff_strAppend(heff_dup(v_prog_240), v_t_249));
      V v_t_2411 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str3), heff_strAppend(v_t_247, v_t_2410));
      V v_t_2412 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2411);
      V v_t_2413 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str4), v_t_2412));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2413});
    }
    case TAG_NoValue: {
      V v_t_2415 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 1); r_; });
      V v_t_2416 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2417 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str5), heff_strAppend(v_t_2416, ((V)&g_std_2ecli_2eoutcomeOf_str6)));
      V v_t_2418 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str7), heff_strAppend(heff_dup(v_prog_240), v_t_2417));
      V v_t_2419 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str8), heff_strAppend(v_t_2415, v_t_2418));
      V v_t_2420 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2419);
      V v_t_2421 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str9), v_t_2420));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2421});
    }
    case TAG_SwitchValue: {
      V v_t_2423 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 1); r_; });
      V v_t_2424 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2425 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str10), heff_strAppend(v_t_2424, ((V)&g_std_2ecli_2eoutcomeOf_str11)));
      V v_t_2426 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str12), heff_strAppend(heff_dup(v_prog_240), v_t_2425));
      V v_t_2427 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str13), heff_strAppend(v_t_2423, v_t_2426));
      V v_t_2428 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2427);
      V v_t_2429 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str14), v_t_2428));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2429});
    }
    case TAG_Ambiguous: {
      V v_t_2432 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 2); r_; });
      V v_t_2433 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2434 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str15), heff_strAppend(v_t_2433, ((V)&g_std_2ecli_2eoutcomeOf_str16)));
      V v_t_2435 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str17), heff_strAppend(heff_dup(v_prog_240), v_t_2434));
      V v_t_2436 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str18), heff_strAppend(v_t_2432, v_t_2435));
      V v_t_2437 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2436);
      V v_t_2438 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str19), v_t_2437));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2438});
    }
    case TAG_MissingFlag: {
      V v_t_2440 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 1); r_; });
      V v_t_2441 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2442 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str20), heff_strAppend(v_t_2441, ((V)&g_std_2ecli_2eoutcomeOf_str21)));
      V v_t_2443 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str22), heff_strAppend(heff_dup(v_prog_240), v_t_2442));
      V v_t_2444 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str23), heff_strAppend(v_t_2440, v_t_2443));
      V v_t_2445 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2444);
      V v_t_2446 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str24), v_t_2445));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2446});
    }
    case TAG_NotIn: {
      V v_t_2450 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 3); r_; });
      V v_t_2451 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2452 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str25), heff_strAppend(v_t_2451, ((V)&g_std_2ecli_2eoutcomeOf_str26)));
      V v_t_2453 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str27), heff_strAppend(heff_dup(v_prog_240), v_t_2452));
      V v_t_2454 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str28), heff_strAppend(v_t_2450, v_t_2453));
      V v_t_2455 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2454);
      V v_t_2456 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str29), v_t_2455));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2456});
    }
    case TAG_Missing: {
      V v_t_2458 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 1); r_; });
      V v_t_2459 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2460 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str30), heff_strAppend(v_t_2459, ((V)&g_std_2ecli_2eoutcomeOf_str31)));
      V v_t_2461 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str32), heff_strAppend(heff_dup(v_prog_240), v_t_2460));
      V v_t_2462 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str33), heff_strAppend(v_t_2458, v_t_2461));
      V v_t_2463 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2462);
      V v_t_2464 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str34), v_t_2463));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2464});
    }
    case TAG_Extra: {
      V v_t_2466 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 1); r_; });
      V v_t_2467 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2468 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str35), heff_strAppend(v_t_2467, ((V)&g_std_2ecli_2eoutcomeOf_str36)));
      V v_t_2469 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str37), heff_strAppend(heff_dup(v_prog_240), v_t_2468));
      V v_t_2470 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str38), heff_strAppend(v_t_2466, v_t_2469));
      V v_t_2471 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2470);
      V v_t_2472 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str39), v_t_2471));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2472});
    }
    case TAG_Help: {
      V v_t_2473 = (g_std_2ecli_2ehelpOf(v_prog_240, v_k_241));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Out, 1, (V[]){v_t_2473});
    }
    case TAG_BadShape: {
      V v_t_2475 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 1); r_; });
      V v_t_2476 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2477 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str40), heff_strAppend(v_t_2476, ((V)&g_std_2ecli_2eoutcomeOf_str41)));
      V v_t_2478 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str42), heff_strAppend(heff_dup(v_prog_240), v_t_2477));
      V v_t_2479 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str43), heff_strAppend(v_t_2475, v_t_2478));
      V v_t_2480 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2479);
      V v_t_2481 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str44), v_t_2480));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2481});
    }
    default: return heff_nomatch(v_it1_244);
    }
  }
  case TAG_Right: {
    V v_x_2482 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Right = heff_take_reuse_n(v_it_243, 1ULL, 1);
    heff_drop(v_prog_240);
    heff_drop_rec(v_k_241, 4);
    return heff_tag_at_n(v_ru_24it_243_24Right, TAG_Run, 1, (V[]){v_x_2482});
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_std_2ecli_2eoutcomeOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eoutcomeOf(a[0], a[1], a[2]);
}