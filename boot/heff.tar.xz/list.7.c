// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArmCovered 35323
#define TAG_ArmRuledOut 21752
#define TAG_ArmTaken 39536
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_CondRelU 46269
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_EquationCovered 28162
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_MkCArm 24694
#define TAG_Ok 9325
#define TAG_PAs 26446
#define TAG_PBin 33976
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_RFixU 5362
#define TAG_RLocal 34280
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SetPath 11095
#define TAG_TagVariant 25174
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_WordLe 48792
#define LBL_atom 9500184
#define LBL_blank 295177582
#define LBL_byMember 2056687451
#define LBL_e 319
#define LBL_end 310101
#define LBL_facts 298546081
#define LBL_field 298786068
#define LBL_from 9647217
#define LBL_global 704121550
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_lengths 294322319
#define LBL_local 304503685
#define LBL_members 1180739419
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_path 9928940
#define LBL_places 961367927
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_supply 1056026650
#define LBL_tag 324116
#define LBL_text 10052084
static uint32_t shape_byMember__supply[] = {LBL_byMember, LBL_supply};
static uint32_t shape_facts__lengths[] = {LBL_facts, LBL_lengths};
static uint32_t shape_key__tag__members[] = {LBL_key, LBL_tag, LBL_members};
static uint32_t shape_kinds__places[] = {LBL_kinds, LBL_places};
static uint32_t shape_local__global[] = {LBL_local, LBL_global};
static uint32_t shape_members__supply[] = {LBL_members, LBL_supply};
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ecompile_2ebounds_2efixSt(V, V, V, V, V, V);
V g_heff_2ecompile_2ebounds_2efixSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2efixSt_clo;
HeffT2 g_heff_2ecompile_2ecpr_2efreeAt_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
HeffT2 g_heff_2ecompile_2efuse_2ecallOf_24cpr(V, V, V);
V g_heff_2ecompile_2eranges_2ewithRange(V, V, V);
V g_heff_2ecompile_2eranges_2ewithRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewithRange_clo;
V g_heff_2ecompile_2erefcount_2ekeptFrom(V, V);
V g_heff_2ecompile_2erefcount_2ekeptFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ekeptFrom_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eletsOut_24cpr(V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_list_2eall_24s494596359x1928238377(V);
V g_list_2eall_24s494596359x1928238377_entry(V self, V *a);
extern Clo g_list_2eall_24s494596359x1928238377_clo;
V g_list_2eany_24s1399422749x931279364(V, V);
V g_list_2eany_24s1399422749x931279364_entry(V self, V *a);
extern Clo g_list_2eany_24s1399422749x931279364_clo;
V g_list_2eany_24s2118781542x1794344985(V);
V g_list_2eany_24s2118781542x1794344985_entry(V self, V *a);
extern Clo g_list_2eany_24s2118781542x1794344985_clo;
V g_list_2eany_24s651804017x1543238976(V, V);
V g_list_2eany_24s651804017x1543238976_entry(V self, V *a);
extern Clo g_list_2eany_24s651804017x1543238976_clo;
V g_list_2eany_24s667046479x351039015(V, V);
V g_list_2eany_24s667046479x351039015_entry(V self, V *a);
extern Clo g_list_2eany_24s667046479x351039015_clo;
V g_list_2eany_24s78130935x581779089(V, V, V);
V g_list_2eany_24s78130935x581779089_entry(V self, V *a);
extern Clo g_list_2eany_24s78130935x581779089_clo;
V g_list_2ecollapse_24s1236926497x1606764496(V, V);
V g_list_2ecollapse_24s1236926497x1606764496_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s1236926497x1606764496_clo;
HeffT2 g_list_2efind_24s1140544609x424148735_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1016340684x604821087(V, V);
V g_list_2efoldl_24s1016340684x604821087_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1016340684x604821087_clo;
V g_list_2efoldl_24s1325692678x1256705229(V, V);
V g_list_2efoldl_24s1325692678x1256705229_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325692678x1256705229_clo;
V g_list_2efoldl_24s1344708576x2031305372(V, V);
V g_list_2efoldl_24s1344708576x2031305372_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1344708576x2031305372_clo;
V g_list_2efoldl_24s1344708576x2031305372_24scalars(V, V, V);
V g_list_2efoldl_24s1344708576x2031305372_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1344708576x2031305372_24scalars_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1663776184x1429962564_24scalars(V, V, V);
V g_list_2efoldl_24s1663776184x1429962564_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1663776184x1429962564_24scalars_clo;
V g_list_2efoldl_24s1977498258x1405492921(V, V, V, V);
V g_list_2efoldl_24s1977498258x1405492921_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1977498258x1405492921_clo;
V g_list_2efoldl_24s453100881x1701840665(V, V, V);
V g_list_2efoldl_24s453100881x1701840665_entry(V self, V *a);
extern Clo g_list_2efoldl_24s453100881x1701840665_clo;
V g_list_2efoldl_24s465028312x319285028(V, V);
V g_list_2efoldl_24s465028312x319285028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s465028312x319285028_clo;
V g_list_2efoldl_24s518632429x1911716206(V, V);
V g_list_2efoldl_24s518632429x1911716206_entry(V self, V *a);
extern Clo g_list_2efoldl_24s518632429x1911716206_clo;
V g_list_2efoldl_24s598828199x820230131(V, V);
V g_list_2efoldl_24s598828199x820230131_entry(V self, V *a);
extern Clo g_list_2efoldl_24s598828199x820230131_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s92926977x826280221(V, V, V);
V g_list_2efoldl_24s92926977x826280221_entry(V self, V *a);
extern Clo g_list_2efoldl_24s92926977x826280221_clo;
V g_list_2efoldl_24s959743277x860837294(V, V);
V g_list_2efoldl_24s959743277x860837294_entry(V self, V *a);
extern Clo g_list_2efoldl_24s959743277x860837294_clo;
V g_list_2ekeepIf_24s1066353734x1075193228(V, V);
V g_list_2ekeepIf_24s1066353734x1075193228_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1066353734x1075193228_clo;
V g_list_2ekeepIf_24s1228038992x175493858_24dps(V, V, V, V, V, V, V);
V g_list_2ekeepIf_24s1228038992x175493858_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1228038992x175493858_24dps_clo;
V g_list_2ekeepIf_24s1419960935x1367201220(V, V, V);
V g_list_2ekeepIf_24s1419960935x1367201220_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1419960935x1367201220_clo;
V g_list_2ekeepIf_24s1419960935x1367201220_24dps(V, V, V, V);
V g_list_2ekeepIf_24s1419960935x1367201220_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1419960935x1367201220_24dps_clo;
V g_list_2ekeepIf_24s1491357071x1050483543(V, V);
V g_list_2ekeepIf_24s1491357071x1050483543_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1491357071x1050483543_clo;
V g_list_2ekeepIf_24s2015972532x1874881274_24dps(V, V, V);
V g_list_2ekeepIf_24s2015972532x1874881274_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2015972532x1874881274_24dps_clo;
V g_list_2ekeepIf_24s958254147x1083401940(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2ekeepIf_24s958254147x1083401940_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s958254147x1083401940_clo;
V g_list_2ekeepIf_24s958254147x1083401940_24dps(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2ekeepIf_24s958254147x1083401940_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s958254147x1083401940_24dps_clo;
V g_list_2emap_24f1952774010x636070089_24dps(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1952774010x636070089_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1952774010x636070089_24dps_clo;
V g_list_2emap_24f2081800072x871100793(V);
V g_list_2emap_24f2081800072x871100793_entry(V self, V *a);
extern Clo g_list_2emap_24f2081800072x871100793_clo;
V g_list_2emap_24f2081800072x871100793_24dps(V, V);
V g_list_2emap_24f2081800072x871100793_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f2081800072x871100793_24dps_clo;
V g_list_2emap_24s1353477632x1698603588(V);
V g_list_2emap_24s1353477632x1698603588_entry(V self, V *a);
extern Clo g_list_2emap_24s1353477632x1698603588_clo;
V g_list_2emap_24s1353477632x1698603588_24dps(V, V);
V g_list_2emap_24s1353477632x1698603588_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1353477632x1698603588_24dps_clo;
V g_list_2emap_24s1354328764x1362350361(V);
V g_list_2emap_24s1354328764x1362350361_entry(V self, V *a);
extern Clo g_list_2emap_24s1354328764x1362350361_clo;
V g_list_2emap_24s1354328764x1362350361_24dps(V, V);
V g_list_2emap_24s1354328764x1362350361_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1354328764x1362350361_24dps_clo;
V g_list_2emap_24s1368853467x919806006_24dps(V, V);
V g_list_2emap_24s1368853467x919806006_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1368853467x919806006_24dps_clo;
V g_list_2emap_24s1417440002x1148747973_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24s1417440002x1148747973_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1417440002x1148747973_24dps_clo;
V g_list_2emap_24s158244903x55062455(V);
V g_list_2emap_24s158244903x55062455_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_clo;
V g_list_2emap_24s1809017761x1063871171_24dps(V, V);
V g_list_2emap_24s1809017761x1063871171_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24dps_clo;
V g_list_2emap_24s1816200867x1876638332(V);
V g_list_2emap_24s1816200867x1876638332_entry(V self, V *a);
extern Clo g_list_2emap_24s1816200867x1876638332_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s231073986x752637537_24dps(V, V, V);
V g_list_2emap_24s231073986x752637537_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_24dps_clo;
V g_list_2emap_24s3575633x347355318_24dps(V, V);
V g_list_2emap_24s3575633x347355318_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s3575633x347355318_24dps_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s420582357x1720502382(V);
V g_list_2emap_24s420582357x1720502382_entry(V self, V *a);
extern Clo g_list_2emap_24s420582357x1720502382_clo;
V g_list_2emap_24s420582357x1720502382_24dps(V, V);
V g_list_2emap_24s420582357x1720502382_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s420582357x1720502382_24dps_clo;
V g_list_2emap_24s510830240x893896831_24dps(V, V, V);
V g_list_2emap_24s510830240x893896831_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s510830240x893896831_24dps_clo;
V g_list_2emap_24s513391942x823299088_24dps(V, V);
V g_list_2emap_24s513391942x823299088_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_24dps_clo;
V g_list_2emap_24s531657185x2070920831_24dps(V, V, V);
V g_list_2emap_24s531657185x2070920831_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s531657185x2070920831_24dps_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_list_2emap_24s720989758x1967438448_24dps(V, V);
V g_list_2emap_24s720989758x1967438448_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_24dps_clo;
V g_list_2emap_24s813634804x1844296865_24dps(V, V);
V g_list_2emap_24s813634804x1844296865_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s813634804x1844296865_24dps_clo;
V g_list_2emergeFrom_24s13745007x135496587(V, V, V);
V g_list_2emergeFrom_24s13745007x135496587_entry(V self, V *a);
extern Clo g_list_2emergeFrom_24s13745007x135496587_clo;
V g_list_2emergeFrom_24s13745007x135496587_24dps(V, V, V, V);
V g_list_2emergeFrom_24s13745007x135496587_24dps_entry(V self, V *a);
extern Clo g_list_2emergeFrom_24s13745007x135496587_24dps_clo;
V g_list_2emergeFrom_24s1581178950x1617773292(V, V, V);
V g_list_2emergeFrom_24s1581178950x1617773292_entry(V self, V *a);
extern Clo g_list_2emergeFrom_24s1581178950x1617773292_clo;
V g_list_2ezipWith_24s1448987994x473765958(V, V);
V g_list_2ezipWith_24s1448987994x473765958_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1448987994x473765958_clo;
V g_list_2ezipWith_24s1448987994x473765958_24dps(V, V, V);
V g_list_2ezipWith_24s1448987994x473765958_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1448987994x473765958_24dps_clo;
V g_list_2ezipWith_24s1680834068x1673006787(V, V);
V g_list_2ezipWith_24s1680834068x1673006787_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1680834068x1673006787_clo;
V g_list_2ezipWith_24s1680834068x1673006787_24dps(V, V, V);
V g_list_2ezipWith_24s1680834068x1673006787_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1680834068x1673006787_24dps_clo;
V g_list_2ezipWith_24s490727218x2138671(V, V, V, V, V);
V g_list_2ezipWith_24s490727218x2138671_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s490727218x2138671_clo;
V g_list_2ezipWith_24s490727218x2138671_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s490727218x2138671_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s490727218x2138671_24dps_clo;
V g_list_2ezipWith_24s528321443x971020870(V, V);
V g_list_2ezipWith_24s528321443x971020870_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s528321443x971020870_clo;
V g_list_2ezipWith_24s528321443x971020870_24dps(V, V, V);
V g_list_2ezipWith_24s528321443x971020870_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s528321443x971020870_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s1703101629x493626677(V, V, V);
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoListOnto(V, V);
V g_std_2eordmap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoListOnto_clo;
V g_std_2eterminal_2ewidget_2ecolumns(V);
V g_std_2eterminal_2ewidget_2ecolumns_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ecolumns_clo;
Clo g_list_2emap_24s1809017761x1063871171_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1809017761x1063871171_24dps_entry, 2, 0};

V g_list_2emap_24s1809017761x1063871171_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1809017761x1063871171_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1809017761x1063871171_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s518632429x1911716206_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s518632429x1911716206_entry, 2, 0};

V g_list_2efoldl_24s518632429x1911716206(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_heff_2ecompile_2eranges_2ewithRange(v_z_240, v_t_246, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s518632429x1911716206_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s518632429x1911716206(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s92926977x826280221_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s92926977x826280221_entry, 3, 0};

V g_list_2efoldl_24s92926977x826280221(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      v_t_247 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2413;
    if (heff_intLe_c_lent(v_lit_240, v_t_247, 2)) {
      V v_a_2410;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_248 = heff_field(v_x_243, 0);
        v_a_2410 = heff_dup(v_a_248);
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      switch (heff_tag_of(v_z_241)) {
      case TAG_Nothing: {
        v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){v_a_2410});
        break;
      }
      case TAG_Just: {
        V v_a_2411 = heff_field(v_z_241, 0);
        V v_ru_24z_241_24Just = heff_take_reuse_n(v_z_241, 1ULL, 1);
        V v_t_2412;
        if (heff_intLt_c_lent(v_a_2411, v_a_2410, 0)) {
          heff_drop(v_a_2410);
          v_t_2412 = v_a_2411;
        } else {
          heff_drop(v_a_2411);
          v_t_2412 = v_a_2410;
        }
        v_t_2413 = heff_tag_at_n(v_ru_24z_241_24Just, TAG_Just, 1, (V[]){v_t_2412});
        break;
      }
      default: heff_nomatch(v_z_241);
      }
    } else {
      v_t_2413 = v_z_241;
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2413;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s92926977x826280221_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s92926977x826280221(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s513391942x823299088_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s513391942x823299088_24dps_entry, 2, 0};

V g_list_2emap_24s513391942x823299088_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2414;
      switch (heff_tag_of(v_a_244)) {
      case TAG_TagVariant: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24TagVariant = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_249 = (g_list_2emap_24s158244903x55062455(v_a_248));
        v_t_2414 = heff_tag_at_n(v_ru_24a_244_24TagVariant, TAG_TagVariant, 3, (V[]){v_a_246, v_a_247, v_t_249});
        break;
      }
      case TAG_BadVariant: {
        V v_a_2410 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24BadVariant = heff_take_reuse_n(v_a_244, 1ULL, 1);
        V v_t_2413;
        switch (heff_tag_of(v_a_2410)) {
        case TAG_At: {
          V v_a_2411 = heff_field(v_a_2410, 0);
          V v_a_2412 = heff_field(v_a_2410, 1);
          V v_ru_24a_2410_24At = heff_take_reuse_n(v_a_2410, 3ULL, 2);
          v_t_2413 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24a_2410_24At, v_a_2412, v_a_2411));
          break;
        }
        default: heff_nomatch(v_a_2410);
        }
        v_t_2414 = heff_tag_at_n(v_ru_24a_244_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2413});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2415 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2414, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2416));
    heff_drop(v_u_2417);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2416;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s513391942x823299088_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s513391942x823299088_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s528321443x971020870_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s528321443x971020870_entry, 2, 0};

V g_list_2ezipWith_24s528321443x971020870(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_a_246 = v_x_242;
      V v_e_247 = v_y_244;
      V v_t_2491;
      switch (heff_tag_of(v_e_247)) {
      case TAG_EVar: {
        heff_take_n(v_e_247, 0ULL, 1);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_e_247, 0ULL, 1);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_e_247, 0ULL, 2);
        HeffT2 v_t_2412 = (g_heff_2ecompile_2esimplify_2eletsOut_24cpr(v_a_246));
        {
          V v_field_2413 = v_t_2412.f[0];
          V v_field_2414 = v_t_2412.f[1];
          V v_x_2415 = v_field_2413;
          heff_drop(v_x_2415);
          V v_y_2416 = v_field_2414;
          switch (heff_tag_of(v_y_2416)) {
          case TAG_EVar: {
            heff_take_n(v_y_2416, 0ULL, 1);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_EGlobal: {
            heff_take_n(v_y_2416, 0ULL, 1);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_ELam: {
            heff_take_n(v_y_2416, 0ULL, 2);
            v_t_2491 = NTAG(TAG_False);
            break;
          }
          case TAG_EApp: {
            heff_take_n(v_y_2416, 0ULL, 2);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_ELet: {
            heff_take_n(v_y_2416, 0ULL, 3);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_ERecord: {
            heff_take_n(v_y_2416, 0ULL, 2);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_EProj: {
            heff_take_n(v_y_2416, 0ULL, 4);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_ETag: {
            heff_take_n(v_y_2416, 0ULL, 3);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_EMatch: {
            heff_take_n(v_y_2416, 0ULL, 2);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_EPrim: {
            heff_take_n(v_y_2416, 0ULL, 1);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_EPrimCall: {
            heff_take_n(v_y_2416, 0ULL, 2);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_ECall: {
            heff_take_n(v_y_2416, 0ULL, 2);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_EInt: {
            heff_take_n(v_y_2416, 0ULL, 1);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_EFloat: {
            heff_take_nf(v_y_2416, 0ULL, 1);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_EStr: {
            heff_take_n(v_y_2416, 0ULL, 1);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_EBytes: {
            heff_take_n(v_y_2416, 0ULL, 1);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_EFixed: {
            heff_take_n(v_y_2416, 0ULL, 2);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_EFloat32: {
            heff_take_na(v_y_2416, 0ULL, 1);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_EAbandon: {
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_EBool: {
            heff_take_n(v_y_2416, 0ULL, 1);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_ESet: {
            heff_take_n(v_y_2416, 0ULL, 3);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_EValues: {
            heff_take_n(v_y_2416, 0ULL, 1);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          case TAG_EFix: {
            heff_take_n(v_y_2416, 0ULL, 2);
            v_t_2491 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_y_2416);
          }
        }
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_e_247, 0ULL, 2);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_e_247, 0ULL, 3);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_e_247, 0ULL, 2);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_e_247, 0ULL, 4);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_e_247, 0ULL, 3);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_e_247, 0ULL, 2);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_e_247, 0ULL, 1);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_e_247, 0ULL, 2);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_e_247, 0ULL, 2);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_e_247, 0ULL, 1);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_e_247, 0ULL, 1);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_e_247, 0ULL, 1);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_e_247, 0ULL, 1);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_e_247, 0ULL, 2);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_e_247, 0ULL, 1);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_e_247, 0ULL, 1);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_e_247, 0ULL, 3);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_e_247, 0ULL, 1);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_e_247, 0ULL, 2);
        heff_drop(v_a_246);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_247);
      }
      V v_cell_2492 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2491, heff_hole()});
      V v_u_2493 = (g_list_2ezipWith_24s528321443x971020870_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_2492)));
      heff_drop(v_u_2493);
      return v_cell_2492;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s528321443x971020870_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s528321443x971020870(a[0], a[1]);
}
Clo g_list_2emap_24s531657185x2070920831_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s531657185x2070920831_24dps_entry, 3, 0};

V g_list_2emap_24s531657185x2070920831_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = ({ V a_0 = v_lit_240; V a_1 = v_x_243; V r_ = (g_heff_2ecompile_2erefcount_2ekeptFrom(a_0, a_1)); heff_drop(v_x_243); r_; });
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s531657185x2070920831_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s531657185x2070920831_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s959743277x860837294_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s959743277x860837294_entry, 2, 0};

V g_list_2efoldl_24s959743277x860837294(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkCArm: {
      V v_a_2410 = heff_field(v_x_242, 6);
      v_t_2412 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = ({ V a_0 = v_z_240; V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s598828199x820230131(a_0, a_1)); heff_drop(v_t_2412); r_; });
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s959743277x860837294_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s959743277x860837294(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1417440002x1148747973_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1417440002x1148747973_24dps_entry, 7, 0};

V g_list_2emap_24s1417440002x1148747973_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_244);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_245, 0);
    V v_xs_248 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_249 = (g_heff_2ecompile_2ebounds_2efixSt(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_lit_243, heff_dup(v_lit_244), v_x_247));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_xs_248;
    V t_6 = v_cell_2410;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_x2_245 = t_5;
    v_d_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s1417440002x1148747973_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2emap_24s1417440002x1148747973_24dps(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
Clo g_list_2emap_24s1353477632x1698603588_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1353477632x1698603588_entry, 1, 0};

V g_list_2emap_24s1353477632x1698603588(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_RFixU, 2, (V[]){NTAG(TAG_I64), MK_INT(0LL)});
    V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_x_241}), NTAG(TAG_Nil)});
    V v_t_245 = heff_tag_n(TAG_CondRelU, 2, (V[]){NTAG(TAG_WordLe), heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_244})});
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1353477632x1698603588_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1353477632x1698603588_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1353477632x1698603588(a[0]);
}
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str0, 7, "Float64");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str1, 4, "Int8");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str2, 5, "Int16");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str3, 5, "Int32");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str4, 5, "Int64");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str5, 5, "UInt8");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str6, 6, "UInt16");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str7, 6, "UInt32");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str8, 6, "UInt64");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str9, 7, "Float32");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str10, 1, "_");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str11, 1, "\?");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str12, 7, "Float64");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str13, 4, "Int8");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str14, 5, "Int16");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str15, 5, "Int32");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str16, 5, "Int64");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str17, 5, "UInt8");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str18, 6, "UInt16");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str19, 6, "UInt32");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str20, 6, "UInt64");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str21, 7, "Float32");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str22, 1, "_");
HEFF_LIT(g_list_2ezipWith_24s1680834068x1673006787_str23, 1, "\?");
Clo g_list_2ezipWith_24s1680834068x1673006787_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1680834068x1673006787_entry, 2, 0};

V g_list_2ezipWith_24s1680834068x1673006787(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_a_246 = v_x_242;
      V v_b_247 = v_y_244;
      V v_t_249;
      switch (heff_tag_of(v_a_246)) {
      case TAG_FtFloat: {
        v_t_249 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str0);
        break;
      }
      case TAG_FtFixed: {
        V v_w_248 = heff_dup(heff_field(v_a_246, 0));
        switch (heff_tag_of(v_w_248)) {
        case TAG_I8: {
          v_t_249 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str1);
          break;
        }
        case TAG_I16: {
          v_t_249 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str2);
          break;
        }
        case TAG_I32: {
          v_t_249 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str3);
          break;
        }
        case TAG_I64: {
          v_t_249 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str4);
          break;
        }
        case TAG_U8: {
          v_t_249 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str5);
          break;
        }
        case TAG_U16: {
          v_t_249 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str6);
          break;
        }
        case TAG_U32: {
          v_t_249 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str7);
          break;
        }
        case TAG_U64: {
          v_t_249 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str8);
          break;
        }
        case TAG_F32: {
          v_t_249 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str9);
          break;
        }
        default: heff_nomatch(v_w_248);
        }
        break;
      }
      case TAG_FtOther: {
        v_t_249 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str10);
        break;
      }
      case TAG_FtAny: {
        v_t_249 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str11);
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      V v_t_2411;
      switch (heff_tag_of(v_b_247)) {
      case TAG_FtFloat: {
        v_t_2411 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str12);
        break;
      }
      case TAG_FtFixed: {
        V v_w_2410 = heff_field(v_b_247, 0);
        heff_take_n(v_b_247, 1ULL, 1);
        switch (heff_tag_of(v_w_2410)) {
        case TAG_I8: {
          v_t_2411 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str13);
          break;
        }
        case TAG_I16: {
          v_t_2411 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str14);
          break;
        }
        case TAG_I32: {
          v_t_2411 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str15);
          break;
        }
        case TAG_I64: {
          v_t_2411 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str16);
          break;
        }
        case TAG_U8: {
          v_t_2411 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str17);
          break;
        }
        case TAG_U16: {
          v_t_2411 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str18);
          break;
        }
        case TAG_U32: {
          v_t_2411 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str19);
          break;
        }
        case TAG_U64: {
          v_t_2411 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str20);
          break;
        }
        case TAG_F32: {
          v_t_2411 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str21);
          break;
        }
        default: heff_nomatch(v_w_2410);
        }
        break;
      }
      case TAG_FtOther: {
        v_t_2411 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str22);
        break;
      }
      case TAG_FtAny: {
        v_t_2411 = ((V)&g_list_2ezipWith_24s1680834068x1673006787_str23);
        break;
      }
      default: heff_nomatch(v_b_247);
      }
      V v_t_2412;
      if (heff_strEq_c(v_t_249, v_t_2411)) {
        v_t_2412 = v_a_246;
      } else {
        heff_drop(v_a_246);
        v_t_2412 = NTAG(TAG_FtOther);
      }
      V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
      V v_u_2414 = (g_list_2ezipWith_24s1680834068x1673006787_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_2413)));
      heff_drop(v_u_2414);
      return v_cell_2413;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1680834068x1673006787_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1680834068x1673006787(a[0], a[1]);
}
Clo g_list_2efoldl_24s465028312x319285028_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s465028312x319285028_entry, 2, 0};

V g_list_2efoldl_24s465028312x319285028(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_p_244 = v_z_240;
    V v_t_245 = v_x_242;
    V v_p_246 = heff_dup(v_p_244);
    V v_k_249;
    switch (heff_tag_of(v_t_245)) {
    case TAG_FtFloat: {
      v_k_249 = NTAG(TAG_RepF64);
      break;
    }
    case TAG_FtFixed: {
      V v_w_247 = heff_dup(heff_field(v_t_245, 0));
      int64_t v_t_248;
      switch (heff_tag_of(v_w_247)) {
      case TAG_I8: {
        v_t_248 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_248 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_248 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_248 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_248 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_248 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_248 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_248 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_248 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_247);
      }
      if ((v_t_248 == ((int64_t)64ULL))) {
        v_k_249 = heff_tag_n(TAG_RepFix, 1, (V[]){v_w_247});
      } else {
        heff_drop(v_w_247);
        v_k_249 = NTAG(TAG_RepV);
      }
      break;
    }
    case TAG_FtOther: {
      v_k_249 = NTAG(TAG_RepV);
      break;
    }
    case TAG_FtAny: {
      v_k_249 = NTAG(TAG_RepV);
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_2412;
    switch (heff_tag_of(v_t_245)) {
    case TAG_FtFloat: {
      v_t_2412 = NTAG(TAG_RepF64);
      break;
    }
    case TAG_FtFixed: {
      V v_w_2410 = heff_field(v_t_245, 0);
      V v_ru_24t_245_24FtFixed = heff_take_reuse_n(v_t_245, 1ULL, 1);
      int64_t v_t_2411;
      switch (heff_tag_of(v_w_2410)) {
      case TAG_I8: {
        v_t_2411 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_2411 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_2411 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_2411 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_2411 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_2411 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_2411 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_2411 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_2411 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_2410);
      }
      if ((v_t_2411 == ((int64_t)64ULL))) {
        v_t_2412 = heff_tag_at_n(v_ru_24t_245_24FtFixed, TAG_RepFix, 1, (V[]){v_w_2410});
      } else {
        heff_drop(v_w_2410);
        heff_drop_cell(v_ru_24t_245_24FtFixed, 1);
        v_t_2412 = NTAG(TAG_RepV);
      }
      break;
    }
    case TAG_FtOther: {
      v_t_2412 = NTAG(TAG_RepV);
      break;
    }
    case TAG_FtAny: {
      v_t_2412 = NTAG(TAG_RepV);
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    HeffT2 v_t_2413 = ({ V a_0 = v_t_2412; V b_1 = heff_take_field(v_p_244, 1); V a_2 = MK_INT(0LL); V b_3 = heff_get_n(v_p_244, 0, 2); HeffT2 r_ = (g_heff_2ecompile_2ecpr_2efreeAt_24cpr(a_0, b_1, a_2, b_3)); heff_drop(v_t_2412); heff_drop(b_1); heff_drop(b_3); r_; });
    V v_t_2424;
    {
      V v_field_2415 = v_t_2413.f[1];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        heff_drop(v_k_249);
        V v_i_2416 = v_field_2415;
        V v_t_2417 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_i_2416, NTAG(TAG_Nil)});
        V v_t_2418 = (g_prelude_2e_2b_2b(heff_take_field(v_p_246, 1), v_t_2417));
        v_t_2424 = ({ V rv_1 = v_t_2418; V rr_ = heff_rec_reuse_nf(v_p_246, 1ULL, 2, shape_kinds__places, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      } else {
        heff_drop(v_field_2415);
        V v_t_2419 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_k_249, NTAG(TAG_Nil)});
        V v_t_2420 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_246, 0)), v_t_2419));
        V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_p_246, 0)));
        V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
        V v_t_2423 = (g_prelude_2e_2b_2b(heff_get_n(v_p_246, 1, 2), v_t_2422));
        v_t_2424 = heff_rec_n(2, shape_kinds__places, (V[]){v_t_2420, v_t_2423});
      }
    }
    V t_0 = v_t_2424;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s465028312x319285028_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s465028312x319285028(a[0], a[1]);
}
Clo g_list_2efoldl_24s1016340684x604821087_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1016340684x604821087_entry, 2, 0};

V g_list_2efoldl_24s1016340684x604821087(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = heff_tag_n(TAG_ELet, 3, (V[]){v_t_246, v_t_249, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1016340684x604821087_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1016340684x604821087(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2efoldl_24s1977498258x1405492921_str0, 4, "tag$");
HEFF_LIT(g_list_2efoldl_24s1977498258x1405492921_str1, 0, "");
HEFF_LIT(g_list_2efoldl_24s1977498258x1405492921_str2, 6, "$cycle");
V g_list_2efoldl_24s1977498258x1405492921_lam0(V self, V *args);
V g_list_2efoldl_24s1977498258x1405492921_lam1(V self, V *args);
Clo g_list_2efoldl_24s1977498258x1405492921_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1977498258x1405492921_entry, 4, 0};

V g_list_2efoldl_24s1977498258x1405492921(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_bodies_246 = heff_dup(v_lit_240);
    V v_places_247 = heff_dup(v_lit_241);
    V v_cs_248 = v_z_242;
    V v_supply_249 = heff_take_field(v_cs_248, 1);
    V v_byMember_2410 = heff_get_n(v_cs_248, 0, 2);
    V v_ks_2411 = heff_dup(v_x_244);
    V v_m_2419 = ({ V a_0 = heff_clo_n(g_list_2efoldl_24s1977498258x1405492921_lam0, 2, 1, (V[]){v_places_247}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ks_2411; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_ks_2411); r_; });
    V v_t_2420 = ({ V a_0 = v_m_2419; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2419); r_; });
    V v_ordered_2421 = (g_list_2emap_24s366344330x1145113647(v_t_2420));
    V v_n_2422 = v_supply_249;
    V v_t_2423 = heff_strAppend(((V)&g_list_2efoldl_24s1977498258x1405492921_str0), heff_intShow(heff_dup(v_n_2422)));
    V v_t_2424 = heff_rec_n(2, shape_members__supply, (V[]){NTAG(TAG_Nil), heff_intAdd(v_n_2422, MK_INT(1LL))});
    V v_ms_2425 = (g_list_2efoldl_24s453100881x1701840665(v_bodies_246, v_t_2424, heff_dup(v_ordered_2421)));
    V v_members_2426 = heff_take_field(v_ms_2425, 0);
    V v_supply_2427 = heff_get_n(v_ms_2425, 1, 2);
    V v_t_2430;
    switch (heff_tag_of(v_ordered_2421)) {
    case TAG_Nil: {
      v_t_2430 = ((V)&g_list_2efoldl_24s1977498258x1405492921_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2428 = heff_field(v_ordered_2421, 0);
      heff_take_n(v_ordered_2421, 1ULL, 2);
      v_t_2430 = v_x_2428;
      break;
    }
    default: heff_nomatch(v_ordered_2421);
    }
    V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_members_2426));
    V v_c_2432 = heff_rec_n(3, shape_key__tag__members, (V[]){heff_strAppend(v_t_2430, ((V)&g_list_2efoldl_24s1977498258x1405492921_str2)), v_t_2423, v_t_2431});
    V v_t_2435 = ({ V a_0 = heff_clo_n(g_list_2efoldl_24s1977498258x1405492921_lam1, 2, 1, (V[]){heff_dup(v_c_2432)}); V a_1 = v_byMember_2410; V b_2 = heff_get_n(v_c_2432, 2, 3); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = heff_rec_n(2, shape_byMember__supply, (V[]){v_t_2435, v_supply_2427});
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s1977498258x1405492921_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24s1977498258x1405492921(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_list_2efoldl_24s1977498258x1405492921_lam0(V self, V *args) {
  V v_m_2412 = args[0];
  V v_k_2413 = args[1];
  V v_places_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2414 = ({ V a_0 = v_places_247; V a_1 = v_k_2413; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_places_247); r_; });
  V v_t_2418;
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_x_2417 = v_field_2416;
      v_t_2418 = v_x_2417;
    } else {
      heff_drop(v_field_2416);
      v_t_2418 = MK_INT(0LL);
    }
  }
  return (g_std_2eordmap_2einsert_24s1703101629x493626677(v_m_2412, v_t_2418, v_k_2413));
}
V g_list_2efoldl_24s1977498258x1405492921_lam1(V self, V *args) {
  V v_m_2433 = args[0];
  V v_k_2434 = args[1];
  V v_c_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_2433, heff_get_n(v_k_2434, 0, 4), v_c_2432));
}
Clo g_list_2emap_24s231073986x752637537_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s231073986x752637537_entry, 2, 0};

V g_list_2emap_24s231073986x752637537(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_242), heff_hole()});
    V v_u_245 = (g_list_2emap_24s231073986x752637537_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s231073986x752637537_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s231073986x752637537(a[0], a[1]);
}
Clo g_list_2eany_24s667046479x351039015_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s667046479x351039015_entry, 2, 0};

V g_list_2eany_24s667046479x351039015(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_247 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_t_247, v_lit_240, 1)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s667046479x351039015_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s667046479x351039015(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2eany_24s78130935x581779089_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s78130935x581779089_entry, 3, 0};

V g_list_2eany_24s78130935x581779089(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_key_245 = heff_dup(v_lit_240);
    V v_n_246 = heff_dup(v_lit_241);
    V v_x3_247 = heff_dup(v_x_243);
    V v_t_2454;
    switch (heff_tag_of(v_x3_247)) {
    case TAG_EVar: {
      heff_take_n(v_x3_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x3_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x3_247, 0ULL, 2);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x3_247, 0ULL, 2);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x3_247, 0ULL, 3);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_247, 0ULL, 2);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x3_247, 0ULL, 4);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      V v_args_2424 = heff_field(v_x3_247, 1);
      heff_take_n(v_x3_247, 2ULL, 3);
      V v_x1_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2424));
      switch (heff_tag_of(v_x1_2426)) {
      case TAG_Nil: {
        heff_drop(v_key_245);
        heff_drop(v_n_246);
        v_t_2454 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        V v_x_2427 = heff_field(v_x1_2426, 0);
        heff_take_n(v_x1_2426, 1ULL, 2);
        HeffT2 v_t_2429 = ({ V a_0 = v_key_245; V a_1 = v_n_246; V a_2 = v_x_2427; HeffT2 r_ = (g_heff_2ecompile_2efuse_2ecallOf_24cpr(a_0, a_1, a_2)); heff_drop(v_key_245); heff_drop(v_x_2427); r_; });
        {
          V v_field_2431 = v_t_2429.f[1];
          int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
          v_t_2454 = heff_bool(((v_tag_2430 == ((int64_t)0ULL)) && ({ V v_x11_2432 = heff_dup(v_field_2431); int c_ = 1; heff_drop(v_x11_2432); c_; })));
          heff_drop(v_field_2431);
        }
        break;
      }
      default: heff_nomatch(v_x1_2426);
      }
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_247, 0ULL, 2);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_247, 0ULL, 2);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x3_247, 0ULL, 2);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x3_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_x3_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x3_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x3_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x3_247, 0ULL, 2);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x3_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_x3_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_x3_247, 0ULL, 3);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_x3_247, 0ULL, 1);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x3_247, 0ULL, 2);
      heff_drop(v_key_245);
      heff_drop(v_n_246);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x3_247);
    }
    if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_t_2454);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2454);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eany_24s78130935x581779089_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2eany_24s78130935x581779089(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s813634804x1844296865_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s813634804x1844296865_24dps_entry, 2, 0};

V g_list_2emap_24s813634804x1844296865_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s813634804x1844296865_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s813634804x1844296865_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1663776184x1429962564_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1663776184x1429962564_24scalars_entry, 3, 0};

V g_list_2efoldl_24s1663776184x1429962564_24scalars(V v_facts_240, V v_lengths_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_rec_n(2, shape_facts__lengths, (V[]){v_facts_240, v_lengths_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_list_2ekeepIf_24s1066353734x1075193228(v_x_243, v_facts_240));
    V v_t_246 = (g_list_2ekeepIf_24s1491357071x1050483543(v_x_243, v_lengths_241));
    V t_0 = v_t_245;
    V t_1 = v_t_246;
    V t_2 = v_xs_244;
    v_facts_240 = t_0;
    v_lengths_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1663776184x1429962564_24scalars_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1663776184x1429962564_24scalars(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2ezipWith_24s1448987994x473765958_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1448987994x473765958_entry, 2, 0};

V g_list_2ezipWith_24s1448987994x473765958(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_247;
      switch (heff_tag_of(v_x_242)) {
      case TAG_RepV: {
        v_t_247 = v_y_244;
        break;
      }
      case TAG_RepFix: {
        heff_drop(v_y_244);
        v_t_247 = v_x_242;
        break;
      }
      case TAG_RepF64: {
        heff_drop(v_y_244);
        v_t_247 = v_x_242;
        break;
      }
      case TAG_RepInt: {
        heff_drop(v_y_244);
        v_t_247 = v_x_242;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24s1448987994x473765958_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1448987994x473765958_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1448987994x473765958(a[0], a[1]);
}
Clo g_list_2emap_24s720989758x1967438448_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s720989758x1967438448_24dps_entry, 2, 0};

V g_list_2emap_24s720989758x1967438448_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s720989758x1967438448_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s720989758x1967438448_24dps(a[0], a[1]);
}
V g_list_2efoldl_24s1344708576x2031305372_24scalars_lam0(V self, V *args);
Clo g_list_2efoldl_24s1344708576x2031305372_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1344708576x2031305372_24scalars_entry, 3, 0};

V g_list_2efoldl_24s1344708576x2031305372_24scalars(V v_local_240, V v_global_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_rec_n(2, shape_local__global, (V[]){v_local_240, v_global_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V t_0 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_clo_n(g_list_2efoldl_24s1344708576x2031305372_24scalars_lam0, 1, 1, (V[]){v_x_243}), v_local_240});
    V t_1 = v_global_241;
    V t_2 = v_xs_244;
    v_local_240 = t_0;
    v_global_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1344708576x2031305372_24scalars_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1344708576x2031305372_24scalars(a[0], a[1], a[2]);
}
V g_list_2efoldl_24s1344708576x2031305372_24scalars_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_245);
  return heff_tag_n(TAG_Ok, 1, (V[]){v_x_243});
}
Clo g_list_2efoldl_24s1344708576x2031305372_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1344708576x2031305372_entry, 2, 0};

V g_list_2efoldl_24s1344708576x2031305372(V v_z_240, V v_x3_241) {
top: ;
  V v_local_242 = heff_take_field(v_z_240, 0);
  V v_global_243 = heff_get_n(v_z_240, 1, 2);
  return (g_list_2efoldl_24s1344708576x2031305372_24scalars(v_local_242, v_global_243, v_x3_241));
}
V g_list_2efoldl_24s1344708576x2031305372_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1344708576x2031305372(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s420582357x1720502382_str0, 0, "");
Clo g_list_2emap_24s420582357x1720502382_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s420582357x1720502382_entry, 1, 0};

V g_list_2emap_24s420582357x1720502382(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_list_2emap_24s420582357x1720502382_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s420582357x1720502382_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s420582357x1720502382_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s420582357x1720502382(a[0]);
}
Clo g_list_2ezipWith_24s490727218x2138671_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s490727218x2138671_entry, 5, 0};

V g_list_2ezipWith_24s490727218x2138671(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_x3_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_245);
      heff_drop(v_xs_246);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_247 = heff_field(v_x3_244, 0);
      V v_ys_248 = heff_field(v_x3_244, 1);
      heff_take_n(v_x3_244, 3ULL, 2);
      V v_t_2411;
      switch (heff_tag_of(v_x_245)) {
      case TAG_MkPair: {
        V v_a_249 = heff_dup(heff_field(v_x_245, 0));
        v_t_2411 = v_a_249;
        break;
      }
      default: heff_nomatch(v_x_245);
      }
      V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, heff_dup(v_lit_240)), heff_intShow(v_y_247));
      V v_t_2415;
      switch (heff_tag_of(v_x_245)) {
      case TAG_MkPair: {
        V v_a_2414 = heff_field(v_x_245, 1);
        heff_take_n(v_x_245, 2ULL, 2);
        v_t_2415 = v_a_2414;
        break;
      }
      default: heff_nomatch(v_x_245);
      }
      V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2412, heff_dup(v_lit_241)), v_t_2415);
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2416, heff_dup(v_lit_242)), heff_hole()});
      V v_u_2418 = (g_list_2ezipWith_24s490727218x2138671_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_246, v_ys_248, heff_dup(v_cell_2417)));
      heff_drop(v_u_2418);
      return v_cell_2417;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ezipWith_24s490727218x2138671_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s490727218x2138671(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efoldl_24s1325692678x1256705229_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1325692678x1256705229_entry, 2, 0};

V g_list_2efoldl_24s1325692678x1256705229(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_dup(heff_field(v_x_242, 1));
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    HeffT2 v_t_2413 = ({ V a_0 = v_z_240; V a_1 = v_t_2412; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2412); r_; });
    V v_t_2417;
    {
      V v_field_2415 = v_t_2413.f[1];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        V v_a_2416 = v_field_2415;
        v_t_2417 = v_a_2416;
      } else {
        heff_drop(v_field_2415);
        v_t_2417 = NTAG(TAG_Nil);
      }
    }
    V v_t_2418 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, v_t_246, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2417})));
    V t_0 = v_t_2418;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1325692678x1256705229_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1325692678x1256705229(a[0], a[1]);
}
Clo g_list_2emap_24s1368853467x919806006_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1368853467x919806006_24dps_entry, 2, 0};

V g_list_2emap_24s1368853467x919806006_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2417;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Nil: {
      v_t_2417 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_PVar: {
        V v_ru_24a_244_24PVar = heff_take_reuse_n(v_a_244, 0ULL, 1);
        v_t_2417 = heff_tag_at_n(v_ru_24a_244_24PVar, TAG_Just, 1, (V[]){v_a_245});
        break;
      }
      case TAG_PTag: {
        heff_take_n(v_a_244, 0ULL, 3);
        heff_drop(v_a_245);
        v_t_2417 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PLit: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop(v_a_245);
        v_t_2417 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PRec: {
        heff_take_n(v_a_244, 0ULL, 2);
        heff_drop(v_a_245);
        v_t_2417 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PAs: {
        heff_take_n(v_a_244, 0ULL, 2);
        heff_drop(v_a_245);
        v_t_2417 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PBin: {
        heff_take_n(v_a_244, 0ULL, 2);
        heff_drop(v_a_245);
        v_t_2417 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2418));
    heff_drop(v_u_2419);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2418;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1368853467x919806006_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1368853467x919806006_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s651804017x1543238976_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s651804017x1543238976_entry, 2, 0};

V g_list_2eany_24s651804017x1543238976(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_ArmTaken: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_a_2411 = heff_dup(v_a_244);
      break;
    }
    case TAG_ArmRuledOut: {
      V v_a_245 = heff_field(v_x_242, 0);
      v_a_2411 = heff_dup(v_a_245);
      break;
    }
    case TAG_ArmCovered: {
      V v_a_248 = heff_field(v_x_242, 0);
      v_a_2411 = heff_dup(v_a_248);
      break;
    }
    case TAG_EquationCovered: {
      V v_a_2410 = heff_field(v_x_242, 0);
      v_a_2411 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_start_2412 = heff_take_field(v_a_2411, 0);
    V v_end_2413 = heff_get_n(v_a_2411, 1, 2);
    if ((heff_intEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_start_2412)) && heff_intEq_c(heff_dup(heff_rfield(v_lit_240, 1)), heff_dup(v_end_2413)))) {
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_start_2412);
      heff_drop(v_end_2413);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_start_2412);
      heff_drop(v_end_2413);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s651804017x1543238976_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s651804017x1543238976(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s958254147x1083401940_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s958254147x1083401940_entry, 12, 0};

V g_list_2ekeepIf_24s958254147x1083401940(V v_lit_240, V v_lit_241, V v_lit_242, V v_box_24lit_243, V v_lit_244, V v_lit_245, V v_box_24lit_246, V v_box_24lit_247, V v_lit_248, V v_lit_249, V v_box_24lit_2410, V v_x2_2411) {
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
  int64_t v_lit_246 = heff_unbox_word(v_box_24lit_246);
  int64_t v_lit_247 = heff_unbox_word(v_box_24lit_247);
  int64_t v_lit_2410 = heff_unbox_word(v_box_24lit_2410);
top: ;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24Cons = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_a_2414 = heff_dup(heff_rfield(v_x_2412, 0));
    if ((heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_lit_241, v_a_2414, v_lit_242, 0)) ? (((v_lit_243 <= heff_unbox_word(heff_strByteAt_lent(v_a_2414, v_lit_244, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_a_2414, v_lit_245, 0)) <= v_lit_246)) ? 0 : ((v_lit_247 <= heff_unbox_word(heff_strByteAt_lent(v_a_2414, v_lit_248, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_a_2414, v_lit_249, 0)) <= v_lit_2410) : 1)) : 1)) {
      heff_drop(v_a_2414);
      V v_cell_2415 = heff_tag_at_n(v_ru_24x2_2411_24Cons, TAG_Cons, 2, (V[]){v_x_2412, heff_hole()});
      V v_u_2416 = (g_list_2ekeepIf_24s958254147x1083401940_24dps(v_lit_240, v_lit_241, v_lit_242, heff_box_word(v_lit_243), v_lit_244, v_lit_245, heff_box_word(v_lit_246), heff_box_word(v_lit_247), v_lit_248, v_lit_249, heff_box_word(v_lit_2410), v_xs_2413, heff_dup(v_cell_2415)));
      heff_drop(v_u_2416);
      return v_cell_2415;
    } else {
      heff_drop_rec(v_x_2412, 2);
      heff_drop_cell(v_ru_24x2_2411_24Cons, 2);
      heff_drop(v_a_2414);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2413;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_list_2ekeepIf_24s958254147x1083401940_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V a5 = a[5]; V a8 = a[8]; V a9 = a[9]; V r = g_list_2ekeepIf_24s958254147x1083401940(a[0], a1, a2, a[3], a4, a5, a[6], a[7], a8, a9, a[10], a[11]); heff_drop(a1); heff_drop(a2); heff_drop(a4); heff_drop(a5); heff_drop(a8); heff_drop(a9); return r;
}
Clo g_list_2emap_24s1354328764x1362350361_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1354328764x1362350361_entry, 1, 0};

V g_list_2emap_24s1354328764x1362350361(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_t_245, 0, 2), heff_hole()});
    V v_u_247 = (g_list_2emap_24s1354328764x1362350361_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1354328764x1362350361_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1354328764x1362350361(a[0]);
}
Clo g_list_2emergeFrom_24s13745007x135496587_clo = {{0x80000000u, K_CLO, 0}, g_list_2emergeFrom_24s13745007x135496587_entry, 3, 0};

V g_list_2emergeFrom_24s13745007x135496587(V v_left_240, V v_x3_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_left_240);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_241, 0);
    V v_rest_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_left_240);
      return heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_rest_244});
    }
    case TAG_Cons: {
      switch (heff_tag_of(v_rest_244)) {
      case TAG_Nil: {
        V v_cell_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_248 = (g_list_2emergeFrom_24s13745007x135496587_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      }
      case TAG_Cons: {
        V v_a_249 = heff_dup(heff_field(v_rest_244, 0));
        switch (heff_tag_of(v_ys_242)) {
        case TAG_Nil: {
          heff_drop_rec(v_a_249, 10);
          V v_cell_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
          V v_u_2412 = (g_list_2emergeFrom_24s13745007x135496587_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_2411)));
          heff_drop(v_u_2412);
          return v_cell_2411;
        }
        case TAG_Cons: {
          V v_b_2413 = heff_dup(heff_field(v_ys_242, 0));
          if (((heff_dup(v_left_240) == NTAG(TAG_True)) ? heff_intLe_c(heff_dup(heff_rfield(v_b_2413, 0)), heff_dup(heff_rfield(v_a_249, 0))) : !heff_intLe_c(heff_dup(heff_rfield(v_a_249, 0)), heff_dup(heff_rfield(v_b_2413, 0))))) {
            heff_drop_rec(v_a_249, 10);
            heff_drop_rec(v_b_2413, 10);
            V v_cell_2415 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
            V v_u_2416 = (g_list_2emergeFrom_24s13745007x135496587_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_2415)));
            heff_drop(v_u_2416);
            return v_cell_2415;
          } else {
            heff_drop_rec(v_a_249, 10);
            heff_drop_rec(v_b_2413, 10);
            V v_cell_2417 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
            V v_t_2418 = heff_bool(!(heff_dup(v_left_240) == NTAG(TAG_True)));
            heff_drop(v_left_240);
            V v_u_2419 = (g_list_2emergeFrom_24s13745007x135496587_24dps(v_t_2418, v_ys_242, v_rest_244, heff_dup(v_cell_2417)));
            heff_drop(v_u_2419);
            return v_cell_2417;
          }
        }
        default: return heff_nomatch(v_ys_242);
        }
      }
      default: return heff_nomatch(v_rest_244);
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2emergeFrom_24s13745007x135496587_entry(V self, V *a) {
  (void)self;
  return g_list_2emergeFrom_24s13745007x135496587(a[0], a[1], a[2]);
}
Clo g_list_2eall_24s494596359x1928238377_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s494596359x1928238377_entry, 1, 0};

V g_list_2eall_24s494596359x1928238377(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    if (((heff_intLe_c_lent(MK_INT(97LL), v_x_241, 1) && heff_intLe_c_lent(v_x_241, MK_INT(122LL), 2)) || ((heff_intLe_c_lent(MK_INT(48LL), v_x_241, 1) && heff_intLe_c_lent(v_x_241, MK_INT(57LL), 2)) || heff_intEq_c_lent(v_x_241, MK_INT(95LL), 2)))) {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s494596359x1928238377_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s494596359x1928238377(a0); heff_drop(a0); return r;
}
Clo g_list_2ekeepIf_24s2015972532x1874881274_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s2015972532x1874881274_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s2015972532x1874881274_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_intEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s2015972532x1874881274_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s2015972532x1874881274_24dps(a[0], a[1], a[2]);
}

HeffT2 g_list_2efind_24s1140544609x424148735_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 2));
    V v_start_245 = heff_take_field(v_a_244, 0);
    V v_end_246 = heff_get_n(v_a_244, 1, 2);
    V v_a_247 = heff_dup(heff_rfield(v_lit_240, 1));
    V v_start_248 = heff_take_field(v_a_247, 0);
    V v_end_249 = heff_get_n(v_a_247, 1, 2);
    if ((heff_intEq_c_lent(v_start_245, v_start_248, 0) && heff_intEq_c_lent(v_end_246, v_end_249, 0))) {
      heff_drop_rec(v_lit_240, 3);
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2ecollapse_24s1236926497x1606764496_clo = {{0x80000000u, K_CLO, 0}, g_list_2ecollapse_24s1236926497x1606764496_entry, 2, 0};

V g_list_2ecollapse_24s1236926497x1606764496(V v_run_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_run_240;
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_MkPair: {
      V v_below_245 = heff_field(v_x31_242, 1);
      V v_t_2412;
      switch (heff_tag_of(v_below_245)) {
      case TAG_Nil: {
        v_t_2412 = (g_list_2emergeFrom_24s1581178950x1617773292(NTAG(TAG_True), heff_dup(v_below_245), v_run_240));
        break;
      }
      case TAG_Cons: {
        V v_a_246 = heff_field(v_below_245, 0);
        switch (heff_tag_of(v_run_240)) {
        case TAG_Nil: {
          v_t_2412 = (g_list_2emergeFrom_24s1581178950x1617773292(NTAG(TAG_True), heff_dup(v_below_245), v_run_240));
          break;
        }
        case TAG_Cons: {
          V v_b_248 = heff_dup(heff_field(v_run_240, 0));
          V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_a_246, 2)), 0, 2);
          V v_t_2411 = heff_get_n(heff_get_n(v_b_248, 2, 5), 0, 2);
          if (heff_intLe_c(v_t_2410, v_t_2411)) {
            v_t_2412 = (g_list_2emergeFrom_24s1581178950x1617773292(NTAG(TAG_True), heff_dup(v_below_245), v_run_240));
          } else {
            v_t_2412 = (g_list_2emergeFrom_24s1581178950x1617773292(NTAG(TAG_False), v_run_240, heff_dup(v_below_245)));
          }
          break;
        }
        default: heff_nomatch(v_run_240);
        }
        break;
      }
      default: heff_nomatch(v_below_245);
      }
      V t_0 = v_t_2412;
      V t_1 = v_rest_243;
      v_run_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2ecollapse_24s1236926497x1606764496_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2ecollapse_24s1236926497x1606764496(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s2118781542x1794344985_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2118781542x1794344985_entry, 1, 0};

V g_list_2eany_24s2118781542x1794344985(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 1));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s2118781542x1794344985_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s2118781542x1794344985(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_list_2emap_24s510830240x893896831_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s510830240x893896831_24dps_str1, 2, ", ");
HEFF_LIT(g_list_2emap_24s510830240x893896831_24dps_str2, 1, "[");
HEFF_LIT(g_list_2emap_24s510830240x893896831_24dps_str3, 1, "]");
HEFF_LIT(g_list_2emap_24s510830240x893896831_24dps_str4, 1, " ");
HEFF_LIT(g_list_2emap_24s510830240x893896831_24dps_str5, 0, "");
HEFF_LIT(g_list_2emap_24s510830240x893896831_24dps_str6, 0, "");
HEFF_LIT(g_list_2emap_24s510830240x893896831_24dps_str7, 5, "(path");
HEFF_LIT(g_list_2emap_24s510830240x893896831_24dps_str8, 1, ")");
Clo g_list_2emap_24s510830240x893896831_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s510830240x893896831_24dps_entry, 3, 0};

V g_list_2emap_24s510830240x893896831_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_245 = heff_dup(v_lit_240);
    V v_x2_246 = v_x_243;
    V v_t_2423;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_At: {
      V v_x21_247 = heff_field(v_x2_246, 0);
      V v_ru_24x2_246_24At = heff_take_reuse_n(v_x2_246, 1ULL, 2);
      switch (heff_tag_of(v_x21_247)) {
      case TAG_SetPath: {
        V v_path_249 = heff_field(v_x21_247, 0);
        V v_e_2410 = heff_field(v_x21_247, 1);
        heff_take_n(v_x21_247, 3ULL, 2);
        V v_x2_2411 = (g_list_2emap_24s1816200867x1876638332(v_path_249));
        V v_t_2414;
        switch (heff_tag_of(v_x2_2411)) {
        case TAG_Nil: {
          v_t_2414 = ((V)&g_list_2emap_24s510830240x893896831_24dps_str0);
          break;
        }
        case TAG_Cons: {
          V v_x_2412 = heff_field(v_x2_2411, 0);
          V v_xs_2413 = heff_field(v_x2_2411, 1);
          heff_take_n(v_x2_2411, 3ULL, 2);
          v_t_2414 = ({ V a_0 = ((V)&g_list_2emap_24s510830240x893896831_24dps_str1); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2411);
        }
        V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s510830240x893896831_24dps_str2), v_t_2414), ((V)&g_list_2emap_24s510830240x893896831_24dps_str3));
        V v_t_2416 = heff_tr(heff_call(heff_get_n(v_r_245, 0, 2), 1, (V[]){v_e_2410}));
        V v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
        V v_parts_2418 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_Cons, 2, (V[]){v_t_2415, v_t_2417});
        V v_x2_2419 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s510830240x893896831_24dps_str4), v_parts_2418));
        V v_t_2422;
        switch (heff_tag_of(v_x2_2419)) {
        case TAG_Nil: {
          v_t_2422 = ((V)&g_list_2emap_24s510830240x893896831_24dps_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2420 = heff_field(v_x2_2419, 0);
          V v_xs_2421 = heff_field(v_x2_2419, 1);
          heff_take_n(v_x2_2419, 3ULL, 2);
          v_t_2422 = ({ V a_0 = ((V)&g_list_2emap_24s510830240x893896831_24dps_str6); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2419);
        }
        v_t_2423 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s510830240x893896831_24dps_str7), v_t_2422), ((V)&g_list_2emap_24s510830240x893896831_24dps_str8));
        break;
      }
      default: heff_nomatch(v_x21_247);
      }
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_cell_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
    V v_u_2425 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2424));
    heff_drop(v_u_2425);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_2424;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s510830240x893896831_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s510830240x893896831_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ekeepIf_24s1228038992x175493858_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1228038992x175493858_24dps_entry, 7, 0};

V g_list_2ekeepIf_24s1228038992x175493858_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_245, 0);
    V v_xs_248 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_a_249 = heff_dup(heff_rfield(v_x_247, 1));
    V v_t_2410 = ({ V a_0 = v_lit_240; V a_1 = v_a_249; V a_2 = heff_dup(v_lit_241); V a_3 = heff_strFind_lent(v_lit_242, v_a_249, v_lit_243, 0); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_a_249); r_; });
    V v_t_2411 = (g_list_2emap_24s649333309x1802289391(v_t_2410));
    V v_a_2412 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2411));
    switch (heff_tag_of(v_a_2412)) {
    case TAG_Nil: {
      V v_cell_2413 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
      V v_u_2414 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2413));
      heff_drop(v_u_2414);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_248;
      V t_6 = v_cell_2413;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      v_d_246 = t_6;
      goto top;
    }
    case TAG_Cons: {
      V v_a_2415 = heff_field(v_a_2412, 0);
      heff_take_n(v_a_2412, 1ULL, 2);
      if (heff_strEq_c_lent(v_a_2415, v_lit_244, 1)) {
        V v_cell_2417 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
        V v_u_2418 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2417));
        heff_drop(v_u_2418);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_xs_248;
        V t_6 = v_cell_2417;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_x2_245 = t_5;
        v_d_246 = t_6;
        goto top;
      } else {
        heff_drop_rec(v_x_247, 2);
        heff_drop_cell(v_ru_24x2_245_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_xs_248;
        V t_6 = v_d_246;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_x2_245 = t_5;
        v_d_246 = t_6;
        goto top;
      }
    }
    default: return heff_nomatch(v_a_2412);
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2ekeepIf_24s1228038992x175493858_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V r = g_list_2ekeepIf_24s1228038992x175493858_24dps(a0, a[1], a2, a3, a4, a[5], a[6]); heff_drop(a0); heff_drop(a2); heff_drop(a3); heff_drop(a4); return r;
}
Clo g_list_2eany_24s1399422749x931279364_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1399422749x931279364_entry, 2, 0};

V g_list_2eany_24s1399422749x931279364(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 14);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1399422749x931279364_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1399422749x931279364(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1419960935x1367201220_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1419960935x1367201220_entry, 3, 0};

V g_list_2ekeepIf_24s1419960935x1367201220(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strSlice(heff_dup(v_x_243), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_245, v_lit_241, 1)) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = (g_list_2ekeepIf_24s1419960935x1367201220_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ekeepIf_24s1419960935x1367201220_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2ekeepIf_24s1419960935x1367201220(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s3575633x347355318_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s3575633x347355318_24dps_entry, 2, 0};

V g_list_2emap_24s3575633x347355318_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_std_2eterminal_2ewidget_2ecolumns(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s3575633x347355318_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s3575633x347355318_24dps(a[0], a[1]);
}
Clo g_list_2emap_24f1952774010x636070089_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1952774010x636070089_24dps_entry, 10, 0};

V g_list_2emap_24f1952774010x636070089_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_x2_248, V v_d_249) {
top: ;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    heff_drop(v_lit_243);
    return heff_setField(v_d_249, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_248, 0);
    V v_xs_2411 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24Cons = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    if (!heff_strEq_c(heff_strSlice_lent(v_x_2410, v_lit_245, v_lit_246, 0), heff_dup(v_lit_247))) {
      V v_t_2413;
      if (heff_strEq_c(heff_strSlice_lent(v_x_2410, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
        V v_t_2412 = heff_strSlice(heff_dup(v_x_2410), heff_dup(v_lit_244), heff_strLength(v_x_2410));
        v_t_2413 = heff_strAppend(heff_dup(v_lit_243), v_t_2412);
      } else {
        v_t_2413 = v_x_2410;
      }
      V v_cell_2414 = heff_tag_at_n(v_ru_24x2_248_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
      V v_u_2415 = heff_setField(v_d_249, MK_INT(1LL), heff_dup(v_cell_2414));
      heff_drop(v_u_2415);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_xs_2411;
      V t_9 = v_cell_2414;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_x2_248 = t_8;
      v_d_249 = t_9;
      goto top;
    } else {
      heff_drop(v_x_2410);
      heff_drop_cell(v_ru_24x2_248_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_xs_2411;
      V t_9 = v_d_249;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_x2_248 = t_8;
      v_d_249 = t_9;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_list_2emap_24f1952774010x636070089_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V r = g_list_2emap_24f1952774010x636070089_24dps(a0, a1, a2, a[3], a4, a5, a6, a7, a[8], a[9]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); return r;
}
Clo g_list_2emap_24f2081800072x871100793_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f2081800072x871100793_entry, 1, 0};

V g_list_2emap_24f2081800072x871100793(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_path_243 = heff_take_field(v_x_241, 1);
    V v_name_244 = heff_get_n(v_x_241, 0, 3);
    if (heff_strEq_c(v_path_243, heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_name_244, heff_hole()});
      V v_u_246 = (g_list_2emap_24f2081800072x871100793_24dps(v_xs_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_name_244);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f2081800072x871100793_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f2081800072x871100793(a[0]);
}