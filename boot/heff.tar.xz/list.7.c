// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_Binds 36386
#define TAG_Boxed 28180
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkArm 55352
#define TAG_MkFieldPat 14710
#define TAG_Ok 9325
#define TAG_RLocal 34280
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_TagVariant 25174
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VArr 15466
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42634
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_above 293969847
#define LBL_assoc 294479919
#define LBL_at 9882
#define LBL_binder 558177493
#define LBL_blank 295177582
#define LBL_body 9524841
#define LBL_el 9998
#define LBL_end 310101
#define LBL_field 298786068
#define LBL_fixities 357800079
#define LBL_from 9647217
#define LBL_global 704121550
#define LBL_groups 709681407
#define LBL_hash 9690581
#define LBL_id 10114
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_local 304503685
#define LBL_long 9823043
#define LBL_looser 850054335
#define LBL_loosest 581880769
#define LBL_member 869372357
#define LBL_name 9869138
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_path 9928940
#define LBL_shown 310772011
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_use 325633
#define LBL_version 583465758
#define LBL_witness 1587180415
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_local__global[] = {LBL_local, LBL_global};
static uint32_t shape_name__field__use[] = {LBL_name, LBL_field, LBL_use};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
V g_heff_2ebuild_2edriver_2eenvOne(V, V);
V g_heff_2ebuild_2edriver_2eenvOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eenvOne_clo;
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ecompile_2eemit_2eexportNameOf(V);
V g_heff_2ecompile_2eemit_2eexportNameOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eexportNameOf_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2eprimCloDef(V);
V g_heff_2ecompile_2eemitc_2eprimCloDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimCloDef_clo;
V g_heff_2ecompile_2efacts_2etailGlobals(V);
V g_heff_2ecompile_2efacts_2etailGlobals_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2etailGlobals_clo;
V g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174(V, V);
V g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2elift_2eliftGo_24s1828885796x1813809576(V, V, V);
V g_heff_2ecompile_2elift_2eliftGo_24s1828885796x1813809576_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eliftGo_24s1828885796x1813809576_clo;
V g_heff_2ecompile_2eprims_2efixedImpl(V);
V g_heff_2ecompile_2eprims_2efixedImpl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2efixedImpl_clo;
V g_heff_2ecompile_2erepr_2eflatFields_get(void);
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2efmt_2eimports_2espacesOf(V);
V g_heff_2esyntax_2efmt_2eimports_2espacesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2espacesOf_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381(V);
V g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381_clo;
V g_heff_2esyntax_2esurface_2eidentOf(V);
V g_heff_2esyntax_2esurface_2eidentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eidentOf_clo;
V g_list_2eall_24s1359914687x262073401(V);
V g_list_2eall_24s1359914687x262073401_entry(V self, V *a);
extern Clo g_list_2eall_24s1359914687x262073401_clo;
V g_list_2eall_24s455618083x1946283732(V, V);
V g_list_2eall_24s455618083x1946283732_entry(V self, V *a);
extern Clo g_list_2eall_24s455618083x1946283732_clo;
V g_list_2eany_24s2118781542x1794344985(V);
V g_list_2eany_24s2118781542x1794344985_entry(V self, V *a);
extern Clo g_list_2eany_24s2118781542x1794344985_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1018181017x1541469354(V);
V g_list_2efilter_24s1018181017x1541469354_entry(V self, V *a);
extern Clo g_list_2efilter_24s1018181017x1541469354_clo;
V g_list_2efilter_24s1018181017x1541469354_24dps(V, V);
V g_list_2efilter_24s1018181017x1541469354_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1018181017x1541469354_24dps_clo;
V g_list_2efilter_24s1443337551x1015803594(V, V, V, V);
V g_list_2efilter_24s1443337551x1015803594_entry(V self, V *a);
extern Clo g_list_2efilter_24s1443337551x1015803594_clo;
V g_list_2efilter_24s1443337551x1015803594_24dps(V, V, V, V, V);
V g_list_2efilter_24s1443337551x1015803594_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1443337551x1015803594_24dps_clo;
V g_list_2efilter_24s1725367856x1498536808_24dps(V, V);
V g_list_2efilter_24s1725367856x1498536808_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1725367856x1498536808_24dps_clo;
V g_list_2efilter_24s2018073091x1385246979_24dps(V, V);
V g_list_2efilter_24s2018073091x1385246979_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s2018073091x1385246979_24dps_clo;
V g_list_2efoldl_24f106956753x832547985(V, V, V);
V g_list_2efoldl_24f106956753x832547985_entry(V self, V *a);
extern Clo g_list_2efoldl_24f106956753x832547985_clo;
V g_list_2efoldl_24f1481425034x1400185912(V, V, V, V, V);
V g_list_2efoldl_24f1481425034x1400185912_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1481425034x1400185912_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f446493955x1704994919(V, V, V);
V g_list_2efoldl_24f446493955x1704994919_entry(V self, V *a);
extern Clo g_list_2efoldl_24f446493955x1704994919_clo;
V g_list_2efoldl_24f451102424x74342153(V, V, V);
V g_list_2efoldl_24f451102424x74342153_entry(V self, V *a);
extern Clo g_list_2efoldl_24f451102424x74342153_clo;
V g_list_2efoldl_24f96178826x1085061806(V, V, V);
V g_list_2efoldl_24f96178826x1085061806_entry(V self, V *a);
extern Clo g_list_2efoldl_24f96178826x1085061806_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s125569247x179592613(V, V);
V g_list_2efoldl_24s125569247x179592613_entry(V self, V *a);
extern Clo g_list_2efoldl_24s125569247x179592613_clo;
V g_list_2efoldl_24s1261443129x1682844402(V, V);
V g_list_2efoldl_24s1261443129x1682844402_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1261443129x1682844402_clo;
V g_list_2efoldl_24s132236332x1381264820(V, V);
V g_list_2efoldl_24s132236332x1381264820_entry(V self, V *a);
extern Clo g_list_2efoldl_24s132236332x1381264820_clo;
V g_list_2efoldl_24s1344708576x2031305372(V, V);
V g_list_2efoldl_24s1344708576x2031305372_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1344708576x2031305372_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s141827321x1562243673(V, V);
V g_list_2efoldl_24s141827321x1562243673_entry(V self, V *a);
extern Clo g_list_2efoldl_24s141827321x1562243673_clo;
V g_list_2efoldl_24s1634882103x1209760496(V, V);
V g_list_2efoldl_24s1634882103x1209760496_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1634882103x1209760496_clo;
V g_list_2efoldl_24s1759289969x319536741(V, V);
V g_list_2efoldl_24s1759289969x319536741_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1759289969x319536741_clo;
V g_list_2efoldl_24s2096135476x728523350(V, V);
V g_list_2efoldl_24s2096135476x728523350_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2096135476x728523350_clo;
V g_list_2efoldl_24s2126981320x1580482478(V, V);
V g_list_2efoldl_24s2126981320x1580482478_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2126981320x1580482478_clo;
V g_list_2efoldl_24s249275339x7045056(V, V);
V g_list_2efoldl_24s249275339x7045056_entry(V self, V *a);
extern Clo g_list_2efoldl_24s249275339x7045056_clo;
V g_list_2efoldl_24s28329515x1288460863(V, V, V);
V g_list_2efoldl_24s28329515x1288460863_entry(V self, V *a);
extern Clo g_list_2efoldl_24s28329515x1288460863_clo;
V g_list_2efoldl_24s753153351x493712762(V, V);
V g_list_2efoldl_24s753153351x493712762_entry(V self, V *a);
extern Clo g_list_2efoldl_24s753153351x493712762_clo;
V g_list_2efoldl_24s775969440x1318400394(V, V, V);
V g_list_2efoldl_24s775969440x1318400394_entry(V self, V *a);
extern Clo g_list_2efoldl_24s775969440x1318400394_clo;
V g_list_2efoldl_24s807479917x1996344110(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s807479917x1996344110_entry(V self, V *a);
extern Clo g_list_2efoldl_24s807479917x1996344110_clo;
V g_list_2efoldl_24s895450532x1092988905(V, V);
V g_list_2efoldl_24s895450532x1092988905_entry(V self, V *a);
extern Clo g_list_2efoldl_24s895450532x1092988905_clo;
V g_list_2efoldl_24s936309876x1530772408(V, V, V);
V g_list_2efoldl_24s936309876x1530772408_entry(V self, V *a);
extern Clo g_list_2efoldl_24s936309876x1530772408_clo;
V g_list_2elookupBy(V, V, V);
V g_list_2elookupBy_entry(V self, V *a);
extern Clo g_list_2elookupBy_clo;
V g_list_2emap_24f1133029339x682401273(V);
V g_list_2emap_24f1133029339x682401273_entry(V self, V *a);
extern Clo g_list_2emap_24f1133029339x682401273_clo;
V g_list_2emap_24f1133029339x682401273_24dps(V, V);
V g_list_2emap_24f1133029339x682401273_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1133029339x682401273_24dps_clo;
V g_list_2emap_24f2063070488x1806431062_24dps(V, V, V);
V g_list_2emap_24f2063070488x1806431062_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f2063070488x1806431062_24dps_clo;
V g_list_2emap_24f505181408x1813697659_24dps(V, V, V);
V g_list_2emap_24f505181408x1813697659_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f505181408x1813697659_24dps_clo;
V g_list_2emap_24f599584836x1400862534_24dps(V, V, V);
V g_list_2emap_24f599584836x1400862534_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f599584836x1400862534_24dps_clo;
V g_list_2emap_24f88106788x1680212182_24dps(V, V);
V g_list_2emap_24f88106788x1680212182_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f88106788x1680212182_24dps_clo;
V g_list_2emap_24f916207306x844827868(V, V);
V g_list_2emap_24f916207306x844827868_entry(V self, V *a);
extern Clo g_list_2emap_24f916207306x844827868_clo;
V g_list_2emap_24f916207306x844827868_24dps(V, V, V);
V g_list_2emap_24f916207306x844827868_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f916207306x844827868_24dps_clo;
V g_list_2emap_24f935318736x1254281698(V, V, V);
V g_list_2emap_24f935318736x1254281698_entry(V self, V *a);
extern Clo g_list_2emap_24f935318736x1254281698_clo;
V g_list_2emap_24f935318736x1254281698_24dps(V, V, V, V);
V g_list_2emap_24f935318736x1254281698_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f935318736x1254281698_24dps_clo;
V g_list_2emap_24f935318736x1254281698_24f812639102x862288937(V, V, V);
V g_list_2emap_24f935318736x1254281698_24f812639102x862288937_entry(V self, V *a);
extern Clo g_list_2emap_24f935318736x1254281698_24f812639102x862288937_clo;
V g_list_2emap_24f935318736x1254281698_24f812639102x862288937_24dps(V, V, V, V);
V g_list_2emap_24f935318736x1254281698_24f812639102x862288937_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f935318736x1254281698_24f812639102x862288937_24dps_clo;
V g_list_2emap_24s1006818869x590968200(V);
V g_list_2emap_24s1006818869x590968200_entry(V self, V *a);
extern Clo g_list_2emap_24s1006818869x590968200_clo;
V g_list_2emap_24s1006818869x590968200_24dps(V, V);
V g_list_2emap_24s1006818869x590968200_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1006818869x590968200_24dps_clo;
V g_list_2emap_24s1049333826x1545174117_24dps(V, V, V, V);
V g_list_2emap_24s1049333826x1545174117_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1049333826x1545174117_24dps_clo;
V g_list_2emap_24s1165563338x395196550_24dps(V, V, V, V, V);
V g_list_2emap_24s1165563338x395196550_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1165563338x395196550_24dps_clo;
V g_list_2emap_24s1195846327x230486685(V, V, V, V, V, V, V);
V g_list_2emap_24s1195846327x230486685_entry(V self, V *a);
extern Clo g_list_2emap_24s1195846327x230486685_clo;
V g_list_2emap_24s1195846327x230486685_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s1195846327x230486685_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1195846327x230486685_24dps_clo;
V g_list_2emap_24s1253308387x88241051(V);
V g_list_2emap_24s1253308387x88241051_entry(V self, V *a);
extern Clo g_list_2emap_24s1253308387x88241051_clo;
V g_list_2emap_24s1253308387x88241051_24dps(V, V);
V g_list_2emap_24s1253308387x88241051_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1253308387x88241051_24dps_clo;
V g_list_2emap_24s1354328764x1362350361(V);
V g_list_2emap_24s1354328764x1362350361_entry(V self, V *a);
extern Clo g_list_2emap_24s1354328764x1362350361_clo;
V g_list_2emap_24s1354328764x1362350361_24dps(V, V);
V g_list_2emap_24s1354328764x1362350361_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1354328764x1362350361_24dps_clo;
V g_list_2emap_24s1367796012x2117543847(V, V);
V g_list_2emap_24s1367796012x2117543847_entry(V self, V *a);
extern Clo g_list_2emap_24s1367796012x2117543847_clo;
V g_list_2emap_24s1381986540x1952410492(V);
V g_list_2emap_24s1381986540x1952410492_entry(V self, V *a);
extern Clo g_list_2emap_24s1381986540x1952410492_clo;
V g_list_2emap_24s1381986540x1952410492_24dps(V, V);
V g_list_2emap_24s1381986540x1952410492_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1381986540x1952410492_24dps_clo;
V g_list_2emap_24s1386329375x1773300759_24dps(V, V);
V g_list_2emap_24s1386329375x1773300759_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1386329375x1773300759_24dps_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s1420651609x666245096_24dps(V, V);
V g_list_2emap_24s1420651609x666245096_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_24dps_clo;
V g_list_2emap_24s1462590149x1582455373(V);
V g_list_2emap_24s1462590149x1582455373_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_clo;
V g_list_2emap_24s1462590149x1582455373_24dps(V, V);
V g_list_2emap_24s1462590149x1582455373_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_24dps_clo;
V g_list_2emap_24s1543151117x629172256_24dps(V, V);
V g_list_2emap_24s1543151117x629172256_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1543151117x629172256_24dps_clo;
V g_list_2emap_24s1561756891x1126436879_24dps(V, V);
V g_list_2emap_24s1561756891x1126436879_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1561756891x1126436879_24dps_clo;
V g_list_2emap_24s158244903x55062455(V);
V g_list_2emap_24s158244903x55062455_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_clo;
V g_list_2emap_24s1661823642x1450093706_24dps(V, V);
V g_list_2emap_24s1661823642x1450093706_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1661823642x1450093706_24dps_clo;
V g_list_2emap_24s1729297000x968708966_24dps(V, V);
V g_list_2emap_24s1729297000x968708966_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1729297000x968708966_24dps_clo;
V g_list_2emap_24s1791433880x1360378684(V);
V g_list_2emap_24s1791433880x1360378684_entry(V self, V *a);
extern Clo g_list_2emap_24s1791433880x1360378684_clo;
V g_list_2emap_24s1791433880x1360378684_24dps(V, V);
V g_list_2emap_24s1791433880x1360378684_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1791433880x1360378684_24dps_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24dps(V, V);
V g_list_2emap_24s1809017761x1063871171_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24dps_clo;
V g_list_2emap_24s1819241345x1511673126(V);
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_clo;
V g_list_2emap_24s1819241345x1511673126_24dps(V, V);
V g_list_2emap_24s1819241345x1511673126_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_24dps_clo;
V g_list_2emap_24s1854779998x1713580578(V);
V g_list_2emap_24s1854779998x1713580578_entry(V self, V *a);
extern Clo g_list_2emap_24s1854779998x1713580578_clo;
V g_list_2emap_24s1854779998x1713580578_24dps(V, V);
V g_list_2emap_24s1854779998x1713580578_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1854779998x1713580578_24dps_clo;
V g_list_2emap_24s1917875516x88484758(V);
V g_list_2emap_24s1917875516x88484758_entry(V self, V *a);
extern Clo g_list_2emap_24s1917875516x88484758_clo;
V g_list_2emap_24s1917875516x88484758_24dps(V, V);
V g_list_2emap_24s1917875516x88484758_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1917875516x88484758_24dps_clo;
V g_list_2emap_24s1978122382x394628613_24dps(V, V);
V g_list_2emap_24s1978122382x394628613_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1978122382x394628613_24dps_clo;
V g_list_2emap_24s2067043448x720245267(V);
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_clo;
V g_list_2emap_24s2067043448x720245267_24dps(V, V);
V g_list_2emap_24s2067043448x720245267_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_24dps_clo;
V g_list_2emap_24s2090270526x1588636862_24dps(V, V);
V g_list_2emap_24s2090270526x1588636862_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2090270526x1588636862_24dps_clo;
V g_list_2emap_24s214260857x938990544_24dps(V, V);
V g_list_2emap_24s214260857x938990544_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s214260857x938990544_24dps_clo;
V g_list_2emap_24s218655275x981659442(V);
V g_list_2emap_24s218655275x981659442_entry(V self, V *a);
extern Clo g_list_2emap_24s218655275x981659442_clo;
V g_list_2emap_24s218655275x981659442_24dps(V, V);
V g_list_2emap_24s218655275x981659442_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s218655275x981659442_24dps_clo;
V g_list_2emap_24s420582357x1720502382(V);
V g_list_2emap_24s420582357x1720502382_entry(V self, V *a);
extern Clo g_list_2emap_24s420582357x1720502382_clo;
V g_list_2emap_24s420582357x1720502382_24dps(V, V);
V g_list_2emap_24s420582357x1720502382_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s420582357x1720502382_24dps_clo;
V g_list_2emap_24s503326960x1200444853(V);
V g_list_2emap_24s503326960x1200444853_entry(V self, V *a);
extern Clo g_list_2emap_24s503326960x1200444853_clo;
V g_list_2emap_24s503326960x1200444853_24dps(V, V);
V g_list_2emap_24s503326960x1200444853_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s503326960x1200444853_24dps_clo;
V g_list_2emap_24s513391942x823299088_24dps(V, V);
V g_list_2emap_24s513391942x823299088_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_24dps_clo;
V g_list_2emap_24s720989758x1967438448_24dps(V, V);
V g_list_2emap_24s720989758x1967438448_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_24dps_clo;
V g_list_2emap_24s732475005x1616712052_24dps(V, V);
V g_list_2emap_24s732475005x1616712052_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_24dps_clo;
V g_list_2emap_24s73473062x206541869(V);
V g_list_2emap_24s73473062x206541869_entry(V self, V *a);
extern Clo g_list_2emap_24s73473062x206541869_clo;
V g_list_2emap_24s73473062x206541869_24dps(V, V);
V g_list_2emap_24s73473062x206541869_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s73473062x206541869_24dps_clo;
V g_list_2emap_24s79542405x478516404_24dps(V, V);
V g_list_2emap_24s79542405x478516404_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_24dps_clo;
V g_list_2emap_24s878634257x1677201747_24dps(V, V);
V g_list_2emap_24s878634257x1677201747_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_24dps_clo;
V g_list_2emap_24s917234327x1197288555_24dps(V, V);
V g_list_2emap_24s917234327x1197288555_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s917234327x1197288555_24dps_clo;
V g_list_2emerge_24s1716485482x1012130009(V, V);
V g_list_2emerge_24s1716485482x1012130009_entry(V self, V *a);
extern Clo g_list_2emerge_24s1716485482x1012130009_clo;
V g_list_2emerge_24s179604802x978393081(V, V);
V g_list_2emerge_24s179604802x978393081_entry(V self, V *a);
extern Clo g_list_2emerge_24s179604802x978393081_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2erange_24dps(V, V, V);
V g_list_2erange_24dps_entry(V self, V *a);
extern Clo g_list_2erange_24dps_clo;
V g_list_2esortBy_24s1223185427x423554351(V);
V g_list_2esortBy_24s1223185427x423554351_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1223185427x423554351_clo;
V g_list_2esortBy_24s746560702x1620060712(V);
V g_list_2esortBy_24s746560702x1620060712_entry(V self, V *a);
extern Clo g_list_2esortBy_24s746560702x1620060712_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2etake_24dps(V, V, V);
V g_list_2etake_24dps_entry(V self, V *a);
extern Clo g_list_2etake_24dps_clo;
V g_list_2ezipWith_24s1029292936x211450510_24dps(V, V, V);
V g_list_2ezipWith_24s1029292936x211450510_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_24dps_clo;
V g_list_2ezipWith_24s1448987994x473765958(V, V);
V g_list_2ezipWith_24s1448987994x473765958_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1448987994x473765958_clo;
V g_list_2ezipWith_24s1448987994x473765958_24dps(V, V, V);
V g_list_2ezipWith_24s1448987994x473765958_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1448987994x473765958_24dps_clo;
V g_list_2ezipWith_24s1713677103x1107896282(V, V);
V g_list_2ezipWith_24s1713677103x1107896282_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1713677103x1107896282_clo;
V g_list_2ezipWith_24s1713677103x1107896282_24dps(V, V, V);
V g_list_2ezipWith_24s1713677103x1107896282_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1713677103x1107896282_24dps_clo;
V g_list_2ezipWith_24s1907923014x815971565(V, V, V, V, V);
V g_list_2ezipWith_24s1907923014x815971565_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1907923014x815971565_clo;
V g_list_2ezipWith_24s1907923014x815971565_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s1907923014x815971565_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1907923014x815971565_24dps_clo;
V g_list_2ezipWith_24s203264781x503274820(V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s203264781x503274820_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s203264781x503274820_clo;
V g_list_2ezipWith_24s203264781x503274820_24dps(V, V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s203264781x503274820_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s203264781x503274820_24dps_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2einsert_24s1687968944x933869791(V, V, V);
V g_map_2einsert_24s1687968944x933869791_entry(V self, V *a);
extern Clo g_map_2einsert_24s1687968944x933869791_clo;
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
Clo g_list_2etake_clo = {{0x80000000u, K_CLO, 0}, g_list_2etake_entry, 2, 0};

V g_list_2etake(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2etake_24dps(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2etake_entry(V self, V *a) {
  (void)self;
  return g_list_2etake(a[0], a[1]);
}
Clo g_list_2etake_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2etake_24dps_entry, 3, 0};

V g_list_2etake_24dps(V v_n_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2etake_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2etake_24dps(a[0], a[1], a[2]);
}
Clo g_list_2edrop_clo = {{0x80000000u, K_CLO, 0}, g_list_2edrop_entry, 2, 0};

V g_list_2edrop(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2edrop_entry(V self, V *a) {
  (void)self;
  return g_list_2edrop(a[0], a[1]);
}
Clo g_list_2elookupBy_clo = {{0x80000000u, K_CLO, 0}, g_list_2elookupBy_entry, 3, 0};

V g_list_2elookupBy(V v_eq_240, V v_k_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_eq_240);
    heff_drop(v_k_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_k_27_245 = heff_field(v_x31_243, 0);
      V v_v_246 = heff_field(v_x31_243, 1);
      V v_t_247 = heff_tr(heff_call(heff_dup(v_eq_240), 2, (V[]){heff_dup(v_k_241), heff_dup(v_k_27_245)}));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_eq_240);
        heff_drop(v_k_241);
        heff_drop(v_t_247);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_246)});
      } else {
        heff_drop(v_t_247);
        V t_0 = v_eq_240;
        V t_1 = v_k_241;
        V t_2 = v_rest_244;
        v_eq_240 = t_0;
        v_k_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2elookupBy_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2elookupBy(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2erange_clo = {{0x80000000u, K_CLO, 0}, g_list_2erange_entry, 2, 0};

V g_list_2erange(V v_a_240, V v_b_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_b_241), heff_dup(v_a_240))) {
    heff_drop(v_a_240);
    heff_drop(v_b_241);
    return NTAG(TAG_Nil);
  } else {
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_240), heff_hole()});
    V v_u_244 = (g_list_2erange_24dps(heff_intAdd(v_a_240, MK_INT(1LL)), v_b_241, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
}
V g_list_2erange_entry(V self, V *a) {
  (void)self;
  return g_list_2erange(a[0], a[1]);
}
Clo g_list_2efoldl_24s1759289969x319536741_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1759289969x319536741_entry, 2, 0};

V g_list_2efoldl_24s1759289969x319536741(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 1, 2);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    V v_t_247 = (g_heff_2esyntax_2efmt_2eimports_2espacesOf(heff_intSub(v_t_245, v_t_246)));
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 1, 2);
    V v_t_249 = heff_strSlice(heff_dup(v_z_240), v_t_248, heff_strLength(heff_dup(v_z_240)));
    V v_t_2410 = heff_strAppend(heff_strSlice(v_z_240, MK_INT(0LL), v_t_244), heff_strAppend(v_t_247, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1759289969x319536741_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1759289969x319536741(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2esortBy_24s746560702x1620060712_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s746560702x1620060712_entry, 1, 0};

V g_list_2esortBy_24s746560702x1620060712(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = (g_list_2etake(heff_intDiv(v_t_245, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_247 = (g_list_2esortBy_24s746560702x1620060712(v_t_246));
      V v_t_248 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_249 = (g_list_2edrop(heff_intDiv(v_t_248, MK_INT(2LL)), v_xs_240));
      V v_t_2410 = (g_list_2esortBy_24s746560702x1620060712(v_t_249));
      return (g_list_2emerge_24s179604802x978393081(v_t_247, v_t_2410));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s746560702x1620060712_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s746560702x1620060712(a[0]);
}
Clo g_list_2emap_24s1253308387x88241051_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1253308387x88241051_entry, 1, 0};

V g_list_2emap_24s1253308387x88241051(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1253308387x88241051_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1253308387x88241051_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1253308387x88241051(a[0]);
}
Clo g_list_2emap_24s503326960x1200444853_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s503326960x1200444853_entry, 1, 0};

V g_list_2emap_24s503326960x1200444853(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s503326960x1200444853_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s503326960x1200444853_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s503326960x1200444853(a[0]);
}
Clo g_list_2emap_24s513391942x823299088_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s513391942x823299088_24dps_entry, 2, 0};

V g_list_2emap_24s513391942x823299088_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_t_2414;
      switch (heff_tag_of(v_a_244)) {
      case TAG_TagVariant: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24TagVariant = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_249 = (g_list_2emap_24s158244903x55062455(v_a_248));
        v_t_2414 = heff_tag_at_n(v_ru_24a_244_24TagVariant, TAG_TagVariant, 3, (V[]){v_a_246, v_a_247, v_t_249});
        break;
      }
      case TAG_BadVariant: {
        V v_a_2410 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24BadVariant = heff_take_reuse_n(v_a_244, 1ULL, 1);
        V v_t_2413;
        switch (heff_tag_of(v_a_2410)) {
        case TAG_At: {
          V v_a_2411 = heff_field(v_a_2410, 0);
          V v_a_2412 = heff_field(v_a_2410, 1);
          heff_take_n(v_a_2410, 3ULL, 2);
          v_t_2413 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_2412, v_a_2411));
          break;
        }
        default: heff_nomatch(v_a_2410);
        }
        v_t_2414 = heff_tag_at_n(v_ru_24a_244_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2413});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2415 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2414, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2416));
    heff_drop(v_u_2417);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2416;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s513391942x823299088_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s513391942x823299088_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s79542405x478516404_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s79542405x478516404_24dps_entry, 2, 0};

V g_list_2emap_24s79542405x478516404_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_t_246 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_244));
      v_t_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_246, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s79542405x478516404_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s79542405x478516404_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s878634257x1677201747_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s878634257x1677201747_24dps_entry, 2, 0};

V g_list_2emap_24s878634257x1677201747_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2esyntax_2esurface_2eidentOf(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s878634257x1677201747_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s878634257x1677201747_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1006818869x590968200_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1006818869x590968200_entry, 1, 0};

V g_list_2emap_24s1006818869x590968200(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 7), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1006818869x590968200_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1006818869x590968200_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1006818869x590968200(a[0]);
}
Clo g_list_2efilter_24s1443337551x1015803594_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1443337551x1015803594_entry, 4, 0};

V g_list_2efilter_24s1443337551x1015803594(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = (g_list_2efoldl_24s1116451536x2100070357(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_rfield(v_x_244, 1)));
    if (heff_intEq_c(v_t_246, heff_dup(v_lit_242))) {
      heff_drop_rec(v_x_244, 8);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_249 = (g_list_2efilter_24s1443337551x1015803594_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s1443337551x1015803594_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1443337551x1015803594(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1543151117x629172256_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1543151117x629172256_24dps_entry, 2, 0};

V g_list_2emap_24s1543151117x629172256_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eprims_2efixedImpl(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1543151117x629172256_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1543151117x629172256_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1978122382x394628613_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1978122382x394628613_24dps_entry, 2, 0};

V g_list_2emap_24s1978122382x394628613_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2437;
    switch (heff_tag_of(v_x_242)) {
    case TAG_EVar: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_242, 0ULL, 3);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_242, 0ULL, 4);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2438 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2437, heff_hole()});
    V v_u_2439 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2438));
    heff_drop(v_u_2439);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2438;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1978122382x394628613_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1978122382x394628613_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1809017761x1063871171_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1809017761x1063871171_24dps_entry, 2, 0};

V g_list_2emap_24s1809017761x1063871171_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1809017761x1063871171_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1809017761x1063871171_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s73473062x206541869_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s73473062x206541869_entry, 1, 0};

V g_list_2emap_24s73473062x206541869(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_True), heff_hole()});
    V v_u_244 = (g_list_2emap_24s73473062x206541869_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s73473062x206541869_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s73473062x206541869(a[0]);
}
Clo g_list_2efoldl_24s28329515x1288460863_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s28329515x1288460863_entry, 3, 0};

V g_list_2efoldl_24s28329515x1288460863(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2438;
    switch (heff_tag_of(v_x_243)) {
    case TAG_EVar: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2441;
    if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_t_2438);
      v_t_2441 = v_z_241;
    } else {
      heff_drop(v_t_2438);
      V v_t_2439 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      V v_t_2440 = (g_heff_2ecompile_2eir_2esizeW(heff_dup(v_lit_240), v_t_2439));
      v_t_2441 = heff_intAdd(v_z_241, v_t_2440);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2441;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s28329515x1288460863_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s28329515x1288460863(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s2067043448x720245267_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2067043448x720245267_entry, 1, 0};

V g_list_2emap_24s2067043448x720245267(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2epushable(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s2067043448x720245267_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2067043448x720245267(a[0]);
}
Clo g_list_2eall_24s455618083x1946283732_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s455618083x1946283732_entry, 2, 0};

V g_list_2eall_24s455618083x1946283732(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c(v_t_246, heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return NTAG(TAG_False);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_24s455618083x1946283732_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eall_24s455618083x1946283732(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s1029292936x211450510_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1029292936x211450510_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1029292936x211450510_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_240, 0);
    V v_xs2_244 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_249;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_x_243, 0);
        heff_take_n(v_x_243, 1ULL, 2);
        v_t_249 = v_a_247;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_cell_2410 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_y_245}), heff_hole()});
      V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_xs2_244;
      V t_1 = v_ys2_246;
      V t_2 = v_cell_2410;
      v_xs_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s1029292936x211450510_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1029292936x211450510_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s141827321x1562243673_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s141827321x1562243673_entry, 2, 0};

V g_list_2efoldl_24s141827321x1562243673(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_tr(g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174(v_a_246, v_z_240));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s141827321x1562243673_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s141827321x1562243673(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str0, 1, "_");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str1, 4, "Int8");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str2, 5, "Int16");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str3, 5, "Int32");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str4, 5, "Int64");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str5, 5, "UInt8");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str6, 6, "UInt16");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str7, 6, "UInt32");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str8, 6, "UInt64");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str9, 7, "Float32");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str10, 7, "Float64");
Clo g_list_2emap_24s2090270526x1588636862_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2090270526x1588636862_24dps_entry, 2, 0};

V g_list_2emap_24s2090270526x1588636862_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_242)) {
    case TAG_RepV: {
      v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str0);
      break;
    }
    case TAG_RepFix: {
      V v_w_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      switch (heff_tag_of(v_w_244)) {
      case TAG_I8: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str1);
        break;
      }
      case TAG_I16: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str2);
        break;
      }
      case TAG_I32: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str3);
        break;
      }
      case TAG_I64: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str4);
        break;
      }
      case TAG_U8: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str5);
        break;
      }
      case TAG_U16: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str6);
        break;
      }
      case TAG_U32: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str7);
        break;
      }
      case TAG_U64: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str8);
        break;
      }
      case TAG_F32: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str9);
        break;
      }
      default: heff_nomatch(v_w_244);
      }
      break;
    }
    case TAG_RepF64: {
      v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str10);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2090270526x1588636862_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2090270526x1588636862_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1713677103x1107896282_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1713677103x1107896282_entry, 2, 0};

V g_list_2ezipWith_24s1713677103x1107896282(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_2410;
      if (heff_intLt_c(v_x_242, heff_dup(g_heff_2ecompile_2erepr_2eflatFields_get()))) {
        switch (heff_tag_of(v_y_244)) {
        case TAG_FtFloat: {
          v_t_2410 = NTAG(TAG_RepF64);
          break;
        }
        case TAG_FtFixed: {
          V v_w_247 = heff_field(v_y_244, 0);
          V v_ru_24y_244_24FtFixed = heff_take_reuse_n(v_y_244, 1ULL, 1);
          V v_t_248;
          switch (heff_tag_of(v_w_247)) {
          case TAG_I8: {
            v_t_248 = MK_INT(8LL);
            break;
          }
          case TAG_I16: {
            v_t_248 = MK_INT(16LL);
            break;
          }
          case TAG_I32: {
            v_t_248 = MK_INT(32LL);
            break;
          }
          case TAG_I64: {
            v_t_248 = MK_INT(64LL);
            break;
          }
          case TAG_U8: {
            v_t_248 = MK_INT(8LL);
            break;
          }
          case TAG_U16: {
            v_t_248 = MK_INT(16LL);
            break;
          }
          case TAG_U32: {
            v_t_248 = MK_INT(32LL);
            break;
          }
          case TAG_U64: {
            v_t_248 = MK_INT(64LL);
            break;
          }
          case TAG_F32: {
            v_t_248 = MK_INT(32LL);
            break;
          }
          default: heff_nomatch(v_w_247);
          }
          if (heff_intEq_c(v_t_248, MK_INT(64LL))) {
            v_t_2410 = heff_tag_at_n(v_ru_24y_244_24FtFixed, TAG_RepFix, 1, (V[]){v_w_247});
          } else {
            heff_drop(v_w_247);
            heff_drop_cell(v_ru_24y_244_24FtFixed, 1);
            v_t_2410 = NTAG(TAG_RepV);
          }
          break;
        }
        case TAG_FtOther: {
          v_t_2410 = NTAG(TAG_RepV);
          break;
        }
        case TAG_FtAny: {
          v_t_2410 = NTAG(TAG_RepV);
          break;
        }
        default: heff_nomatch(v_y_244);
        }
      } else {
        heff_drop(v_y_244);
        v_t_2410 = NTAG(TAG_RepV);
      }
      V v_cell_2411 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = (g_list_2ezipWith_24s1713677103x1107896282_24dps(v_xs2_243, v_ys2_245, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s1713677103x1107896282_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1713677103x1107896282(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1713677103x1107896282_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1713677103x1107896282_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1713677103x1107896282_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_240, 0);
    V v_xs2_244 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_2411;
      if (heff_intLt_c(v_x_243, heff_dup(g_heff_2ecompile_2erepr_2eflatFields_get()))) {
        switch (heff_tag_of(v_y_245)) {
        case TAG_FtFloat: {
          v_t_2411 = NTAG(TAG_RepF64);
          break;
        }
        case TAG_FtFixed: {
          V v_w_248 = heff_field(v_y_245, 0);
          V v_ru_24y_245_24FtFixed = heff_take_reuse_n(v_y_245, 1ULL, 1);
          V v_t_249;
          switch (heff_tag_of(v_w_248)) {
          case TAG_I8: {
            v_t_249 = MK_INT(8LL);
            break;
          }
          case TAG_I16: {
            v_t_249 = MK_INT(16LL);
            break;
          }
          case TAG_I32: {
            v_t_249 = MK_INT(32LL);
            break;
          }
          case TAG_I64: {
            v_t_249 = MK_INT(64LL);
            break;
          }
          case TAG_U8: {
            v_t_249 = MK_INT(8LL);
            break;
          }
          case TAG_U16: {
            v_t_249 = MK_INT(16LL);
            break;
          }
          case TAG_U32: {
            v_t_249 = MK_INT(32LL);
            break;
          }
          case TAG_U64: {
            v_t_249 = MK_INT(64LL);
            break;
          }
          case TAG_F32: {
            v_t_249 = MK_INT(32LL);
            break;
          }
          default: heff_nomatch(v_w_248);
          }
          if (heff_intEq_c(v_t_249, MK_INT(64LL))) {
            v_t_2411 = heff_tag_at_n(v_ru_24y_245_24FtFixed, TAG_RepFix, 1, (V[]){v_w_248});
          } else {
            heff_drop(v_w_248);
            heff_drop_cell(v_ru_24y_245_24FtFixed, 1);
            v_t_2411 = NTAG(TAG_RepV);
          }
          break;
        }
        case TAG_FtOther: {
          v_t_2411 = NTAG(TAG_RepV);
          break;
        }
        case TAG_FtAny: {
          v_t_2411 = NTAG(TAG_RepV);
          break;
        }
        default: heff_nomatch(v_y_245);
        }
      } else {
        heff_drop(v_y_245);
        v_t_2411 = NTAG(TAG_RepV);
      }
      V v_cell_2412 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
      V v_u_2413 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_xs2_244;
      V t_1 = v_ys2_246;
      V t_2 = v_cell_2412;
      v_xs_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s1713677103x1107896282_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1713677103x1107896282_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s2096135476x728523350_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2096135476x728523350_entry, 2, 0};

V g_list_2efoldl_24s2096135476x728523350(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_242)}), v_z_240});
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_242}), v_t_244});
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2096135476x728523350_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2096135476x728523350(a[0], a[1]);
}
Clo g_list_2emap_24s1917875516x88484758_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1917875516x88484758_entry, 1, 0};

V g_list_2emap_24s1917875516x88484758(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){v_x_241, NTAG(TAG_RepV)});
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1917875516x88484758_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1917875516x88484758_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1917875516x88484758(a[0]);
}
Clo g_list_2efoldl_24s249275339x7045056_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s249275339x7045056_entry, 2, 0};

V g_list_2efoldl_24s249275339x7045056(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_heff_2ecompile_2efacts_2etailGlobals(v_t_247));
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s249275339x7045056_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s249275339x7045056(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s895450532x1092988905_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s895450532x1092988905_entry, 2, 0};

V g_list_2efoldl_24s895450532x1092988905(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(v_x_242), NTAG(TAG_MkUnit), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s895450532x1092988905_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s895450532x1092988905(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1049333826x1545174117_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1049333826x1545174117_24dps_entry, 4, 0};

V g_list_2emap_24s1049333826x1545174117_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_244, 0)), 0, 6);
    V v_t_247 = heff_tr(heff_call(v_t_246, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_248 = heff_get_n(heff_get_n(v_x_244, 0, 3), 1, 6);
    V v_t_249 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_248, heff_dup(v_lit_241)));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_247, v_t_249), heff_hole()});
    V v_u_2411 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_2410;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1049333826x1545174117_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1049333826x1545174117_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1729297000x968708966_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1729297000x968708966_24dps_entry, 2, 0};

V g_list_2emap_24s1729297000x968708966_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_x_242, 0)), heff_get_n(v_x_242, 2, 5)});
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1729297000x968708966_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1729297000x968708966_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s753153351x493712762_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s753153351x493712762_entry, 2, 0};

V g_list_2efoldl_24s753153351x493712762(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_map_2einsert_24s1687968944x933869791(v_t_246, v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s753153351x493712762_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s753153351x493712762(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s936309876x1530772408_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s936309876x1530772408_entry, 3, 0};

V g_list_2efoldl_24s936309876x1530772408(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2elift_2eliftGo_24s1828885796x1813809576(heff_dup(v_lit_240), heff_dup(v_x_243), heff_dup(heff_rfield(v_x_243, 2))));
    V v_t_2410;
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_t_245, 0);
      V v_a_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 3ULL, 2);
      V v_t_248 = ({ V rv_2 = v_a_246; V rr_ = heff_rec_reuse_nf(v_x_243, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_a_247, 0, 2)));
      v_t_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, v_t_249});
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_2411;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s936309876x1530772408_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s936309876x1530772408(a[0], a[1], a[2]);
}
Clo g_list_2eall_24s1359914687x262073401_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1359914687x262073401_entry, 1, 0};

V g_list_2eall_24s1359914687x262073401(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_Given: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_GivenU: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_LentVar: {
      V v_x12_247 = heff_field(v_x_241, 1);
      switch (heff_tag_of(v_x12_247)) {
      case TAG_Nil: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_Cons: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x12_247);
      }
    }
    case TAG_LentValue: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1359914687x262073401_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1359914687x262073401(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1661823642x1450093706_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1661823642x1450093706_24dps_entry, 2, 0};

V g_list_2emap_24s1661823642x1450093706_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Given: {
      V v_e_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2410 = v_e_244;
      break;
    }
    case TAG_GivenU: {
      V v_e_246 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_2410 = v_e_246;
      break;
    }
    case TAG_LentVar: {
      V v_x_247 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2410 = heff_tag_n(TAG_RLocal, 1, (V[]){v_x_247});
      break;
    }
    case TAG_LentValue: {
      V v_e_249 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2410 = v_e_249;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1661823642x1450093706_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1661823642x1450093706_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1448987994x473765958_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1448987994x473765958_entry, 2, 0};

V g_list_2ezipWith_24s1448987994x473765958(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_247;
      switch (heff_tag_of(v_x_242)) {
      case TAG_RepV: {
        v_t_247 = v_y_244;
        break;
      }
      case TAG_RepFix: {
        heff_drop(v_y_244);
        v_t_247 = v_x_242;
        break;
      }
      case TAG_RepF64: {
        heff_drop(v_y_244);
        v_t_247 = v_x_242;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_cell_248 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24s1448987994x473765958_24dps(v_xs2_243, v_ys2_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s1448987994x473765958_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1448987994x473765958(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1448987994x473765958_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1448987994x473765958_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1448987994x473765958_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_240, 0);
    V v_xs2_244 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_248;
      switch (heff_tag_of(v_x_243)) {
      case TAG_RepV: {
        v_t_248 = v_y_245;
        break;
      }
      case TAG_RepFix: {
        heff_drop(v_y_245);
        v_t_248 = v_x_243;
        break;
      }
      case TAG_RepF64: {
        heff_drop(v_y_245);
        v_t_248 = v_x_243;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_xs2_244;
      V t_1 = v_ys2_246;
      V t_2 = v_cell_249;
      v_xs_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s1448987994x473765958_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1448987994x473765958_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s732475005x1616712052_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s732475005x1616712052_24dps_entry, 2, 0};

V g_list_2emap_24s732475005x1616712052_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemit_2eexportNameOf(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s732475005x1616712052_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s732475005x1616712052_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s720989758x1967438448_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s720989758x1967438448_24dps_entry, 2, 0};

V g_list_2emap_24s720989758x1967438448_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s720989758x1967438448_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s720989758x1967438448_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s420582357x1720502382_str0, 0, "");
Clo g_list_2emap_24s420582357x1720502382_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s420582357x1720502382_entry, 1, 0};

V g_list_2emap_24s420582357x1720502382(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_list_2emap_24s420582357x1720502382_str0)));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s420582357x1720502382_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s420582357x1720502382_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s420582357x1720502382(a[0]);
}
Clo g_list_2ezipWith_24s203264781x503274820_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s203264781x503274820_entry, 9, 0};

V g_list_2ezipWith_24s203264781x503274820(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_xs_247, V v_ys_248) {
top: ;
  switch (heff_tag_of(v_xs_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_ys_248);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_xs_247, 0);
    V v_xs2_2410 = heff_field(v_xs_247, 1);
    V v_ru_24xs_247_24Cons = heff_take_reuse_n(v_xs_247, 3ULL, 2);
    switch (heff_tag_of(v_ys_248)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_x_249);
      heff_drop(v_xs2_2410);
      heff_drop_cell(v_ru_24xs_247_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_2411 = heff_field(v_ys_248, 0);
      V v_ys2_2412 = heff_field(v_ys_248, 1);
      heff_take_n(v_ys_248, 3ULL, 2);
      V v_t_2413 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_249, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244)));
      V v_t_2414 = heff_strAppend(heff_intShow(v_y_2411), heff_dup(v_lit_246));
      V v_t_2415 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2413), heff_strAppend(heff_dup(v_lit_245), v_t_2414));
      V v_cell_2416 = heff_tag_at_n(v_ru_24xs_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2415), heff_hole()});
      V v_u_2417 = (g_list_2ezipWith_24s203264781x503274820_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs2_2410, v_ys2_2412, heff_dup(v_cell_2416)));
      heff_drop(v_u_2417);
      return v_cell_2416;
    }
    default: return heff_nomatch(v_ys_248);
    }
  }
  default: return heff_nomatch(v_xs_247);
  }
}
V g_list_2ezipWith_24s203264781x503274820_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s203264781x503274820(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_list_2ezipWith_24s203264781x503274820_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s203264781x503274820_24dps_entry, 10, 0};

V g_list_2ezipWith_24s203264781x503274820_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_xs_247, V v_ys_248, V v_d_249) {
top: ;
  switch (heff_tag_of(v_xs_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_ys_248);
    return heff_setField(v_d_249, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_xs_247, 0);
    V v_xs2_2411 = heff_field(v_xs_247, 1);
    V v_ru_24xs_247_24Cons = heff_take_reuse_n(v_xs_247, 3ULL, 2);
    switch (heff_tag_of(v_ys_248)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_x_2410);
      heff_drop(v_xs2_2411);
      heff_drop_cell(v_ru_24xs_247_24Cons, 2);
      return heff_setField(v_d_249, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_2412 = heff_field(v_ys_248, 0);
      V v_ys2_2413 = heff_field(v_ys_248, 1);
      heff_take_n(v_ys_248, 3ULL, 2);
      V v_t_2414 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_2410, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244)));
      V v_t_2415 = heff_strAppend(heff_intShow(v_y_2412), heff_dup(v_lit_246));
      V v_t_2416 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2414), heff_strAppend(heff_dup(v_lit_245), v_t_2415));
      V v_cell_2417 = heff_tag_at_n(v_ru_24xs_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2416), heff_hole()});
      V v_u_2418 = heff_setField(v_d_249, MK_INT(1LL), heff_dup(v_cell_2417));
      heff_drop(v_u_2418);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_xs2_2411;
      V t_8 = v_ys2_2413;
      V t_9 = v_cell_2417;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_xs_247 = t_7;
      v_ys_248 = t_8;
      v_d_249 = t_9;
      goto top;
    }
    default: return heff_nomatch(v_ys_248);
    }
  }
  default: return heff_nomatch(v_xs_247);
  }
}
V g_list_2ezipWith_24s203264781x503274820_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s203264781x503274820_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_list_2ezipWith_24s1907923014x815971565_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1907923014x815971565_entry, 5, 0};

V g_list_2ezipWith_24s1907923014x815971565(V v_lit_240, V v_lit_241, V v_lit_242, V v_xs_243, V v_ys_244) {
top: ;
  switch (heff_tag_of(v_xs_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_ys_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_xs_243, 0);
    V v_xs2_246 = heff_field(v_xs_243, 1);
    V v_ru_24xs_243_24Cons = heff_take_reuse_n(v_xs_243, 3ULL, 2);
    switch (heff_tag_of(v_ys_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_245);
      heff_drop(v_xs2_246);
      heff_drop_cell(v_ru_24xs_243_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_247 = heff_field(v_ys_244, 0);
      V v_ys2_248 = heff_field(v_ys_244, 1);
      heff_take_n(v_ys_244, 3ULL, 2);
      V v_t_2411;
      switch (heff_tag_of(v_x_245)) {
      case TAG_MkPair: {
        V v_a_249 = heff_dup(heff_field(v_x_245, 0));
        v_t_2411 = v_a_249;
        break;
      }
      default: heff_nomatch(v_x_245);
      }
      V v_t_2414;
      switch (heff_tag_of(v_x_245)) {
      case TAG_MkPair: {
        V v_a_2413 = heff_field(v_x_245, 1);
        heff_take_n(v_x_245, 2ULL, 2);
        v_t_2414 = v_a_2413;
        break;
      }
      default: heff_nomatch(v_x_245);
      }
      V v_t_2415 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2414, heff_dup(v_lit_242)));
      V v_t_2416 = heff_strAppend(heff_intShow(v_y_247), v_t_2415);
      V v_t_2417 = heff_strAppend(v_t_2411, heff_strAppend(heff_dup(v_lit_240), v_t_2416));
      V v_cell_2418 = heff_tag_at_n(v_ru_24xs_243_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
      V v_u_2419 = (g_list_2ezipWith_24s1907923014x815971565_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs2_246, v_ys2_248, heff_dup(v_cell_2418)));
      heff_drop(v_u_2419);
      return v_cell_2418;
    }
    default: return heff_nomatch(v_ys_244);
    }
  }
  default: return heff_nomatch(v_xs_243);
  }
}
V g_list_2ezipWith_24s1907923014x815971565_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1907923014x815971565(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2ezipWith_24s1907923014x815971565_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1907923014x815971565_24dps_entry, 6, 0};

V g_list_2ezipWith_24s1907923014x815971565_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_xs_243, V v_ys_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_xs_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_ys_244);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_xs_243, 0);
    V v_xs2_247 = heff_field(v_xs_243, 1);
    V v_ru_24xs_243_24Cons = heff_take_reuse_n(v_xs_243, 3ULL, 2);
    switch (heff_tag_of(v_ys_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_246);
      heff_drop(v_xs2_247);
      heff_drop_cell(v_ru_24xs_243_24Cons, 2);
      return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_248 = heff_field(v_ys_244, 0);
      V v_ys2_249 = heff_field(v_ys_244, 1);
      heff_take_n(v_ys_244, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_x_246)) {
      case TAG_MkPair: {
        V v_a_2410 = heff_dup(heff_field(v_x_246, 0));
        v_t_2412 = v_a_2410;
        break;
      }
      default: heff_nomatch(v_x_246);
      }
      V v_t_2415;
      switch (heff_tag_of(v_x_246)) {
      case TAG_MkPair: {
        V v_a_2414 = heff_field(v_x_246, 1);
        heff_take_n(v_x_246, 2ULL, 2);
        v_t_2415 = v_a_2414;
        break;
      }
      default: heff_nomatch(v_x_246);
      }
      V v_t_2416 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2415, heff_dup(v_lit_242)));
      V v_t_2417 = heff_strAppend(heff_intShow(v_y_248), v_t_2416);
      V v_t_2418 = heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_240), v_t_2417));
      V v_cell_2419 = heff_tag_at_n(v_ru_24xs_243_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
      V v_u_2420 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2419));
      heff_drop(v_u_2420);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs2_247;
      V t_4 = v_ys2_249;
      V t_5 = v_cell_2419;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_xs_243 = t_3;
      v_ys_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_ys_244);
    }
  }
  default: return heff_nomatch(v_xs_243);
  }
}
V g_list_2ezipWith_24s1907923014x815971565_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1907923014x815971565_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2efilter_24s1018181017x1541469354_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1018181017x1541469354_entry, 1, 0};

V g_list_2efilter_24s1018181017x1541469354(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_a_246 = ({ V a_0 = v_t_245; V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_a_246) == NTAG(TAG_True))) {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_a_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_a_246);
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_248 = (g_list_2efilter_24s1018181017x1541469354_24dps(v_xs_242, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1018181017x1541469354_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1018181017x1541469354(a[0]);
}
Clo g_list_2efoldl_24s125569247x179592613_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s125569247x179592613_entry, 2, 0};

V g_list_2efoldl_24s125569247x179592613(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eemitc_2eprimCloDef(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s125569247x179592613_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s125569247x179592613(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1386329375x1773300759_24dps_str0, 1, "V");
HEFF_LIT(g_list_2emap_24s1386329375x1773300759_24dps_str1, 6, "double");
Clo g_list_2emap_24s1386329375x1773300759_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1386329375x1773300759_24dps_entry, 2, 0};

V g_list_2emap_24s1386329375x1773300759_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_242)) {
    case TAG_RepV: {
      v_t_245 = ((V)&g_list_2emap_24s1386329375x1773300759_24dps_str0);
      break;
    }
    case TAG_RepFix: {
      V v_w_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_245 = ({ V a_0 = v_w_244; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_244); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_245 = ((V)&g_list_2emap_24s1386329375x1773300759_24dps_str1);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1386329375x1773300759_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1386329375x1773300759_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s132236332x1381264820_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s132236332x1381264820_entry, 2, 0};

V g_list_2efoldl_24s132236332x1381264820(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_dup(heff_field(v_x_242, 1));
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_a_2413 = (g_map_2elookup_24s1546226666x2146984184(v_t_2412, v_z_240));
    V v_t_2415;
    switch (heff_tag_of(v_a_2413)) {
    case TAG_Nothing: {
      v_t_2415 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_a_2414 = heff_field(v_a_2413, 0);
      heff_take_n(v_a_2413, 1ULL, 1);
      v_t_2415 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_a_2413);
    }
    V v_t_2416 = (g_map_2einsert_24s1341440536x470972936(v_t_246, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2415}), v_z_240));
    V t_0 = v_t_2416;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s132236332x1381264820_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s132236332x1381264820(a[0], a[1]);
}
Clo g_list_2efoldl_24s2126981320x1580482478_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2126981320x1580482478_entry, 2, 0};

V g_list_2efoldl_24s2126981320x1580482478(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_a_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_a_246)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_a_246, 0);
      heff_take_n(v_a_246, 1ULL, 2);
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_a_246);
    }
    V v_a_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      v_a_2412 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2415;
    switch (heff_tag_of(v_a_2412)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_a_2412, 1);
      heff_take_n(v_a_2412, 2ULL, 2);
      v_t_2415 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_a_2412);
    }
    V v_t_2416 = (g_map_2einsert_24s1341440536x470972936(v_t_249, v_t_2415, v_z_240));
    V t_0 = v_t_2416;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2126981320x1580482478_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2126981320x1580482478(a[0], a1); heff_drop(a1); return r;
}
V g_list_2efoldl_24s1344708576x2031305372_lam0(V self, V *args);
Clo g_list_2efoldl_24s1344708576x2031305372_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1344708576x2031305372_entry, 2, 0};

V g_list_2efoldl_24s1344708576x2031305372(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_clo_n(g_list_2efoldl_24s1344708576x2031305372_lam0, 1, 1, (V[]){v_x_242}), heff_dup(heff_rfield(v_z_240, 0))});
    V v_t_246 = ({ V rv_0 = v_t_245; V rr_ = heff_rec_reuse_nf(v_z_240, 2ULL, 2, shape_local__global, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1344708576x2031305372_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1344708576x2031305372(a[0], a[1]);
}
V g_list_2efoldl_24s1344708576x2031305372_lam0(V self, V *args) {
  V v_a_244 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_244);
  return heff_tag_n(TAG_Ok, 1, (V[]){v_x_242});
}
Clo g_list_2efoldl_24s1261443129x1682844402_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1261443129x1682844402_entry, 2, 0};

V g_list_2efoldl_24s1261443129x1682844402(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ebuild_2edriver_2eenvOne(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1261443129x1682844402_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1261443129x1682844402(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1634882103x1209760496_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1634882103x1209760496_entry, 2, 0};

V g_list_2efoldl_24s1634882103x1209760496(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 11));
    V v_t_245 = (g_heff_2esyntax_2efixity_2eappendF(heff_take_field(v_z_240, 0), heff_take_field(v_a_244, 0)));
    V v_t_246 = (g_heff_2esyntax_2efixity_2enubByG(v_t_245));
    V v_t_247 = (g_heff_2esyntax_2efixity_2eappendF(heff_get_n(v_z_240, 1, 2), heff_get_n(v_a_244, 1, 2)));
    V v_t_248 = (g_heff_2esyntax_2efixity_2enubByE(v_t_247));
    V t_0 = heff_rec_n(2, shape_groups__above, (V[]){v_t_246, v_t_248});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1634882103x1209760496_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1634882103x1209760496(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1725367856x1498536808_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1725367856x1498536808_24dps_entry, 2, 0};

V g_list_2efilter_24s1725367856x1498536808_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2426;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_dup(heff_field(v_x_242, 0));
      V v_sp_245 = heff_dup(heff_field(v_x_242, 1));
      switch (heff_tag_of(v_x11_244)) {
      case TAG_DeclEquations: {
        heff_take_n(v_x11_244, 0ULL, 5);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_245);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_244, 0ULL, 5);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_245);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_244, 0ULL, 4);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_245);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclPrimitive: {
        V v_x_2420 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 3);
        v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){v_x_2420, v_sp_245})});
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_245);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_245);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    switch (heff_tag_of(v_t_2426)) {
    case TAG_Nothing: {
      V v_cell_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2428 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2427));
      heff_drop(v_u_2428);
      V t_0 = v_xs_243;
      V t_1 = v_cell_2427;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_2426, 0ULL, 1);
      heff_drop(v_x_242);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_2426);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1725367856x1498536808_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1725367856x1498536808_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s214260857x938990544_24dps_str0, 0, "");
V g_list_2emap_24s214260857x938990544_24dps_lam0(V self, V *args); static Clo g_list_2emap_24s214260857x938990544_24dps_lam0_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s214260857x938990544_24dps_lam0, 1, 0};
Clo g_list_2emap_24s214260857x938990544_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s214260857x938990544_24dps_entry, 2, 0};

V g_list_2emap_24s214260857x938990544_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245 = ({ V rv_4 = ((V)&g_list_2emap_24s214260857x938990544_24dps_lam0_clo); V rr_ = heff_rec_reuse_nf(v_x_242, 15ULL, 5, shape_span__name__key__member__ty, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s214260857x938990544_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s214260857x938990544_24dps(a[0], a[1]);
}
V g_list_2emap_24s214260857x938990544_24dps_lam0(V self, V *args) {
  V v_u_244 = args[0];
  heff_drop(v_u_244);
  return ((V)&g_list_2emap_24s214260857x938990544_24dps_str0);
}
Clo g_list_2emap_24s1354328764x1362350361_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1354328764x1362350361_entry, 1, 0};

V g_list_2emap_24s1354328764x1362350361(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_t_245, 0, 2), heff_hole()});
    V v_u_247 = (g_list_2emap_24s1354328764x1362350361_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1354328764x1362350361_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1354328764x1362350361(a[0]);
}
HEFF_LIT(g_list_2emap_24s218655275x981659442_str0, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str1, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str2, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str3, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str4, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str5, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str6, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str7, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str8, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str9, 0, "");
Clo g_list_2emap_24s218655275x981659442_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s218655275x981659442_entry, 1, 0};

V g_list_2emap_24s218655275x981659442(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_241)) {
    case TAG_VFun: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2414 = ((V)&g_list_2emap_24s218655275x981659442_str0);
      break;
    }
    case TAG_VCons: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2414 = ((V)&g_list_2emap_24s218655275x981659442_str1);
      break;
    }
    case TAG_VTag: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2414 = ((V)&g_list_2emap_24s218655275x981659442_str2);
      break;
    }
    case TAG_VInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2414 = ((V)&g_list_2emap_24s218655275x981659442_str3);
      break;
    }
    case TAG_VFloat: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2414 = ((V)&g_list_2emap_24s218655275x981659442_str4);
      break;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2414 = ((V)&g_list_2emap_24s218655275x981659442_str5);
      break;
    }
    case TAG_VStr: {
      V v_s_2410 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_2414 = v_s_2410;
      break;
    }
    case TAG_VRune: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2414 = ((V)&g_list_2emap_24s218655275x981659442_str6);
      break;
    }
    case TAG_VArr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2414 = ((V)&g_list_2emap_24s218655275x981659442_str7);
      break;
    }
    case TAG_VBytes: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2414 = ((V)&g_list_2emap_24s218655275x981659442_str8);
      break;
    }
    case TAG_VErased: {
      v_t_2414 = ((V)&g_list_2emap_24s218655275x981659442_str9);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = (g_list_2emap_24s218655275x981659442_24dps(v_xs_242, heff_dup(v_cell_2415)));
    heff_drop(v_u_2416);
    return v_cell_2415;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s218655275x981659442_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s218655275x981659442(a[0]);
}
Clo g_list_2efoldl_24s807479917x1996344110_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s807479917x1996344110_entry, 12, 0};

V g_list_2efoldl_24s807479917x1996344110(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_z_2410, V v_x3_2411) {
top: ;
  switch (heff_tag_of(v_x3_2411)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    return v_z_2410;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x3_2411, 0);
    V v_xs_2413 = heff_field(v_x3_2411, 1);
    V v_ru_24x3_2411_24Cons = heff_take_reuse_n(v_x3_2411, 3ULL, 2);
    V v_a_2414 = heff_take_field(v_x_2412, 0);
    V v_t_2415 = heff_intShow(heff_strLength(heff_dup(v_a_2414)));
    V v_t_2416 = heff_strAppend(v_t_2415, heff_strAppend(heff_dup(v_lit_240), v_a_2414));
    V v_t_2417 = heff_take_field(v_x_2412, 1);
    V v_t_2418;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_AssocLeft: {
      v_t_2418 = heff_dup(v_lit_241);
      break;
    }
    case TAG_AssocRight: {
      v_t_2418 = heff_dup(v_lit_242);
      break;
    }
    case TAG_AssocNone: {
      v_t_2418 = heff_dup(v_lit_243);
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    V v_t_2419 = heff_take_field(v_x_2412, 3);
    V v_t_2420;
    if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
      heff_drop(v_t_2419);
      v_t_2420 = heff_dup(v_lit_244);
    } else {
      heff_drop(v_t_2419);
      v_t_2420 = heff_dup(v_lit_245);
    }
    V v_a_2421 = heff_take_field(v_x_2412, 4);
    V v_t_2422 = heff_intShow(heff_strLength(heff_dup(v_a_2421)));
    V v_t_2423 = heff_strAppend(v_t_2422, heff_strAppend(heff_dup(v_lit_246), v_a_2421));
    V v_a_2424 = heff_get_n(v_x_2412, 2, 5);
    V v_t_2425 = (g_list_2efoldl_24s1116451536x2100070357(heff_dup(v_lit_247), heff_dup(v_lit_248), v_a_2424));
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_a_2424));
    V v_t_2427 = (g_list_2efoldl_24s775969440x1318400394(heff_dup(v_lit_249), NTAG(TAG_Nil), v_t_2426));
    V v_t_2428 = heff_tag_at_n(v_ru_24x3_2411_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_t_2425), v_t_2427});
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2418), v_t_2429});
    V v_t_2431 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2430}), v_z_2410));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_lit_248;
    V t_9 = v_lit_249;
    V t_10 = v_t_2431;
    V t_11 = v_xs_2413;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_lit_248 = t_8;
    v_lit_249 = t_9;
    v_z_2410 = t_10;
    v_x3_2411 = t_11;
    goto top;
  }
  default: return heff_nomatch(v_x3_2411);
  }
}
V g_list_2efoldl_24s807479917x1996344110_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s807479917x1996344110(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]);
}
Clo g_list_2eany_24s2118781542x1794344985_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2118781542x1794344985_entry, 1, 0};

V g_list_2eany_24s2118781542x1794344985(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 1));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s2118781542x1794344985_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s2118781542x1794344985(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1195846327x230486685_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1195846327x230486685_entry, 7, 0};

V g_list_2emap_24s1195846327x230486685(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2419;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkFieldPat: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      V v_ru_24x_247_24MkFieldPat = heff_take_reuse_n(v_x_247, 3ULL, 2);
      V v_t_2411 = (g_heff_2esyntax_2eformat_2epatKey(v_a_2410));
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      V v_a_2413 = heff_tag_at_n(v_ru_24x_247_24MkFieldPat, TAG_Cons, 2, (V[]){v_a_249, v_t_2412});
      V v_a_2414 = (g_list_2emap_24s1367796012x2117543847(heff_dup(v_lit_242), v_a_2413));
      V v_t_2417;
      switch (heff_tag_of(v_a_2414)) {
      case TAG_Nil: {
        v_t_2417 = heff_dup(v_lit_243);
        break;
      }
      case TAG_Cons: {
        V v_a_2415 = heff_field(v_a_2414, 0);
        V v_a_2416 = heff_field(v_a_2414, 1);
        heff_take_n(v_a_2414, 3ULL, 2);
        v_t_2417 = ({ V a_0 = heff_dup(v_lit_244); V a_1 = v_a_2415; V a_2 = v_a_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2416); r_; });
        break;
      }
      default: heff_nomatch(v_a_2414);
      }
      V v_t_2418 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2417, heff_dup(v_lit_245)));
      v_t_2419 = heff_strAppend(heff_dup(v_lit_240), v_t_2418);
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_cell_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
    V v_u_2421 = (g_list_2emap_24s1195846327x230486685_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2420)));
    heff_drop(v_u_2421);
    return v_cell_2420;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s1195846327x230486685_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1195846327x230486685(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s1561756891x1126436879_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1561756891x1126436879_24dps_entry, 2, 0};

V g_list_2emap_24s1561756891x1126436879_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eformat_2epatKey(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1561756891x1126436879_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1561756891x1126436879_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1791433880x1360378684_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1791433880x1360378684_entry, 1, 0};

V g_list_2emap_24s1791433880x1360378684(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1791433880x1360378684_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1791433880x1360378684_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1791433880x1360378684(a[0]);
}
Clo g_list_2emap_24s1165563338x395196550_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1165563338x395196550_24dps_entry, 5, 0};

V g_list_2emap_24s1165563338x395196550_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = heff_strAppend(heff_take_field(v_x_245, 2), heff_dup(v_lit_242));
    V v_t_248 = heff_strAppend(heff_take_field(v_x_245, 1), heff_strAppend(heff_dup(v_lit_241), v_t_247));
    V v_t_249 = heff_strAppend(heff_get_n(v_x_245, 0, 3), heff_strAppend(heff_dup(v_lit_240), v_t_248));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_2410;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1165563338x395196550_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1165563338x395196550_24dps(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_str0, 12, ", version = ");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_str1, 2, " }");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_str2, 9, ", path = ");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_str3, 9, "{ name = ");
Clo g_list_2emap_24s1381986540x1952410492_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1381986540x1952410492_entry, 1, 0};

V g_list_2emap_24s1381986540x1952410492(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ebuild_2eproject_2equoted(heff_take_field(v_x_241, 0)));
    V v_t_244 = (g_heff_2ebuild_2eproject_2equoted(heff_take_field(v_x_241, 1)));
    V v_t_245 = (g_heff_2ebuild_2eproject_2equoted(heff_get_n(v_x_241, 2, 3)));
    V v_t_246 = heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_str0), heff_strAppend(v_t_245, ((V)&g_list_2emap_24s1381986540x1952410492_str1)));
    V v_t_247 = heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_str2), heff_strAppend(v_t_244, v_t_246));
    V v_t_248 = heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_str3), heff_strAppend(v_t_243, v_t_247));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s1381986540x1952410492_24dps(v_xs_242, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1381986540x1952410492_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1381986540x1952410492(a[0]);
}
HEFF_LIT(g_list_2emap_24s1462590149x1582455373_str0, 3, ".hf");
Clo g_list_2emap_24s1462590149x1582455373_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1462590149x1582455373_entry, 1, 0};

V g_list_2emap_24s1462590149x1582455373(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_intSub(heff_strLength(heff_dup(v_x_241)), MK_INT(3LL));
    V v_t_244 = heff_strSlice(heff_dup(v_x_241), v_t_243, heff_strLength(heff_dup(v_x_241)));
    V v_t_247;
    if (heff_strEq_c(v_t_244, ((V)&g_list_2emap_24s1462590149x1582455373_str0))) {
      V v_t_246 = heff_intSub(heff_strLength(heff_dup(v_x_241)), MK_INT(3LL));
      v_t_247 = heff_strSlice(v_x_241, MK_INT(0LL), v_t_246);
    } else {
      v_t_247 = v_x_241;
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_list_2emap_24s1462590149x1582455373_24dps(v_xs_242, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1462590149x1582455373_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1462590149x1582455373(a[0]);
}
Clo g_list_2emap_24s917234327x1197288555_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s917234327x1197288555_24dps_entry, 2, 0};

V g_list_2emap_24s917234327x1197288555_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 4), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s917234327x1197288555_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s917234327x1197288555_24dps(a[0], a[1]);
}
Clo g_list_2efilter_24s2018073091x1385246979_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2018073091x1385246979_24dps_entry, 2, 0};

V g_list_2efilter_24s2018073091x1385246979_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 2));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s2018073091x1385246979_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2018073091x1385246979_24dps(a[0], a[1]);
}
Clo g_list_2esortBy_24s1223185427x423554351_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s1223185427x423554351_entry, 1, 0};

V g_list_2esortBy_24s1223185427x423554351(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = (g_list_2etake(heff_intDiv(v_t_245, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_247 = (g_list_2esortBy_24s1223185427x423554351(v_t_246));
      V v_t_248 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_249 = (g_list_2edrop(heff_intDiv(v_t_248, MK_INT(2LL)), v_xs_240));
      V v_t_2410 = (g_list_2esortBy_24s1223185427x423554351(v_t_249));
      return (g_list_2emerge_24s1716485482x1012130009(v_t_247, v_t_2410));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s1223185427x423554351_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s1223185427x423554351(a[0]);
}
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_str0, 5, "-- | ");
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_str1, 4, "-- |");
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_str2, 0, "");
Clo g_list_2emap_24s1819241345x1511673126_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1819241345x1511673126_entry, 1, 0};

V g_list_2emap_24s1819241345x1511673126(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    if (heff_strEq_c(heff_strSlice(heff_dup(v_x_241), MK_INT(0LL), MK_INT(5LL)), ((V)&g_list_2emap_24s1819241345x1511673126_str0))) {
      V v_t_244 = heff_strSlice(heff_dup(v_x_241), MK_INT(5LL), heff_strLength(v_x_241));
      v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
    } else {
      if (heff_strEq_c(v_x_241, ((V)&g_list_2emap_24s1819241345x1511673126_str1))) {
        v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_list_2emap_24s1819241345x1511673126_str2)});
      } else {
        v_t_246 = NTAG(TAG_Nothing);
      }
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1819241345x1511673126_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1819241345x1511673126(a[0]);
}
Clo g_list_2emap_24s1420651609x666245096_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1420651609x666245096_entry, 1, 0};

V g_list_2emap_24s1420651609x666245096(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_x_241});
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1420651609x666245096_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1420651609x666245096(a[0]);
}
Clo g_list_2emap_24s1854779998x1713580578_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1854779998x1713580578_entry, 1, 0};

V g_list_2emap_24s1854779998x1713580578(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 8), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1854779998x1713580578_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1854779998x1713580578_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1854779998x1713580578(a[0]);
}
Clo g_list_2emap_24f916207306x844827868_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f916207306x844827868_entry, 2, 0};

V g_list_2emap_24f916207306x844827868(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 2), heff_hole()});
      V v_u_246 = (g_list_2emap_24f916207306x844827868_24dps(v_p_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f916207306x844827868_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f916207306x844827868(a[0], a[1]);
}
Clo g_list_2emap_24f916207306x844827868_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f916207306x844827868_24dps_entry, 3, 0};

V g_list_2emap_24f916207306x844827868_24dps(V v_p_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_243, 1, 2), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f916207306x844827868_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f916207306x844827868_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f88106788x1680212182_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f88106788x1680212182_24dps_entry, 2, 0};

V g_list_2emap_24f88106788x1680212182_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_take_field(v_x_242, 3);
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 5), heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_x_242, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f88106788x1680212182_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f88106788x1680212182_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2efoldl_24f451102424x74342153_str0, 3, "sym");
Clo g_list_2efoldl_24f451102424x74342153_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f451102424x74342153_entry, 3, 0};

V g_list_2efoldl_24f451102424x74342153(V v_lit_240, V v_z_241, V v_x1_242) {
top: ;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_u_243 = heff_field(v_x1_242, 0);
    V v_rest_244 = heff_field(v_x1_242, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_u_243, 0)), ((V)&g_list_2efoldl_24f451102424x74342153_str0))) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_rest_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x1_242 = t_2;
      goto top;
    } else {
      heff_drop(v_lit_240);
      return v_z_241;
    }
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_list_2efoldl_24f451102424x74342153_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f451102424x74342153(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24f1645967390x252727070_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1645967390x252727070_entry, 2, 0};

V g_list_2efoldl_24f1645967390x252727070(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_y_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_x_246 = v_y_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1645967390x252727070(a[0], a[1]);
}
Clo g_list_2efoldl_24f1481425034x1400185912_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1481425034x1400185912_entry, 5, 0};

V g_list_2efoldl_24f1481425034x1400185912(V v_lit_240, V v_z_241, V v_p_242, V v_n_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_p_242);
    heff_drop(v_n_243);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    if (heff_intLe_c(heff_dup(v_n_243), MK_INT(0LL))) {
      heff_drop(v_lit_240);
      heff_drop(v_p_242);
      heff_drop(v_n_243);
      return v_z_241;
    } else {
      V v_t_248 = heff_tr(heff_call(heff_dup(v_p_242), 1, (V[]){heff_dup(v_x_245)}));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V t_0 = heff_dup(v_lit_240);
        V t_1 = heff_intAdd(v_z_241, v_lit_240);
        V t_2 = v_p_242;
        V t_3 = heff_intSub(v_n_243, MK_INT(1LL));
        V t_4 = v_xs_246;
        v_lit_240 = t_0;
        v_z_241 = t_1;
        v_p_242 = t_2;
        v_n_243 = t_3;
        v_x2_244 = t_4;
        goto top;
      } else {
        heff_drop(v_t_248);
        V t_0 = v_lit_240;
        V t_1 = v_z_241;
        V t_2 = v_p_242;
        V t_3 = heff_intSub(v_n_243, MK_INT(1LL));
        V t_4 = v_xs_246;
        v_lit_240 = t_0;
        v_z_241 = t_1;
        v_p_242 = t_2;
        v_n_243 = t_3;
        v_x2_244 = t_4;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2efoldl_24f1481425034x1400185912_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_list_2efoldl_24f1481425034x1400185912(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
Clo g_list_2emap_24f505181408x1813697659_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f505181408x1813697659_24dps_entry, 3, 0};

V g_list_2emap_24f505181408x1813697659_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_246 = (g_list_2emap_24s1809017761x1063871171(v_xs_244));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_246);
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_243}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_cell_247;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f505181408x1813697659_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f505181408x1813697659_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f96178826x1085061806_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f96178826x1085061806_entry, 3, 0};

V g_list_2efoldl_24f96178826x1085061806(V v_z_240, V v_seen_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_seen_241);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x3_245 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_243), v_seen_241));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      V v_t_246 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_243), NTAG(TAG_MkUnit), v_seen_241));
      V t_0 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_z_240});
      V t_1 = v_t_246;
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_seen_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_z_240;
      V t_1 = v_seen_241;
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_seen_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f96178826x1085061806_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f96178826x1085061806(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f106956753x832547985_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f106956753x832547985_entry, 3, 0};

V g_list_2efoldl_24f106956753x832547985(V v_z_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return (g_list_2efoldl_24s1370882877x364361272(v_z_240, v_ys_242));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V t_0 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_z_240});
    V t_1 = v_xs_244;
    V t_2 = v_ys_242;
    v_z_240 = t_0;
    v_x1_241 = t_1;
    v_ys_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f106956753x832547985_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f106956753x832547985(a[0], a[1], a[2]);
}
V g_list_2efoldl_24f446493955x1704994919_lam0(V self, V *args);
Clo g_list_2efoldl_24f446493955x1704994919_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f446493955x1704994919_entry, 3, 0};

V g_list_2efoldl_24f446493955x1704994919(V v_lit_240, V v_z_241, V v_x1_242) {
top: ;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    V v_xs_244 = heff_field(v_x1_242, 1);
    heff_take_n(v_x1_242, 3ULL, 2);
    V v_t_247 = (g_list_2efilter(heff_clo_n(g_list_2efoldl_24f446493955x1704994919_lam0, 1, 1, (V[]){v_x_243}), v_xs_244));
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_z_241, v_lit_240);
    V t_2 = v_t_247;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x1_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_list_2efoldl_24f446493955x1704994919_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f446493955x1704994919(a[0], a[1], a[2]);
}
V g_list_2efoldl_24f446493955x1704994919_lam0(V self, V *args) {
  V v_y_245 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ret_24bool = heff_bool(!heff_strEq_c(heff_dup(v_y_245), heff_dup(v_x_243)));
  heff_drop(v_y_245);
  heff_drop(v_x_243);
  return v_ret_24bool;
}
Clo g_list_2emap_24f1133029339x682401273_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1133029339x682401273_entry, 1, 0};

V g_list_2emap_24f1133029339x682401273(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_x_241, 0)), 2, 3);
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_241, 0)), 0, 3);
      V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_241, 0)), 1, 3);
      V v_t_246 = heff_rec_n(3, shape_name__field__use, (V[]){v_t_244, v_t_245, heff_get_n(v_x_241, 1, 2)});
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2emap_24f1133029339x682401273_24dps(v_xs_242, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop_rec(v_x_241, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f1133029339x682401273_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1133029339x682401273(a[0]);
}
Clo g_list_2emap_24f2063070488x1806431062_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f2063070488x1806431062_24dps_entry, 3, 0};

V g_list_2emap_24f2063070488x1806431062_24dps(V v_p_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_243, 2, 3), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f2063070488x1806431062_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f2063070488x1806431062_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f599584836x1400862534_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f599584836x1400862534_24dps_entry, 3, 0};

V g_list_2emap_24f599584836x1400862534_24dps(V v_f_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 0)), 1, 3);
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nothing: {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_f_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_245, 0ULL, 1);
      V v_t_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_f_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_248;
      v_f_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f599584836x1400862534_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f599584836x1400862534_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f935318736x1254281698_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f935318736x1254281698_entry, 3, 0};

V g_list_2emap_24f935318736x1254281698(V v_lit_240, V v_p_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_241), 1, (V[]){heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_243, heff_dup(v_lit_240)), heff_hole()});
      V v_u_247 = (g_list_2emap_24f935318736x1254281698_24dps(v_lit_240, v_p_241, v_xs_244, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f935318736x1254281698_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f935318736x1254281698(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f935318736x1254281698_24f812639102x862288937_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f935318736x1254281698_24f812639102x862288937_entry, 3, 0};

V g_list_2emap_24f935318736x1254281698_24f812639102x862288937(V v_lit_240, V v_p_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_take_field(v_x_243, 2);
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_x_246 = heff_get_n(v_x_243, 0, 4);
      V v_t_247 = heff_tr(heff_call(heff_dup(v_p_241), 1, (V[]){heff_dup(v_x_246)}));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_246, heff_dup(v_lit_240)), heff_hole()});
        V v_u_249 = (g_list_2emap_24f935318736x1254281698_24f812639102x862288937_24dps(v_lit_240, v_p_241, v_xs_244, heff_dup(v_cell_248)));
        heff_drop(v_u_249);
        return v_cell_248;
      } else {
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        heff_drop(v_x_246);
        heff_drop(v_t_247);
        V t_0 = v_lit_240;
        V t_1 = v_p_241;
        V t_2 = v_xs_244;
        v_lit_240 = t_0;
        v_p_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_243, 4);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f935318736x1254281698_24f812639102x862288937_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f935318736x1254281698_24f812639102x862288937(a[0], a[1], a[2]);
}