// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_Binds 36386
#define TAG_Boxed 28180
#define TAG_CBool 61457
#define TAG_CDouble 41794
#define TAG_CInteger 35664
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_CondRelU 46269
#define TAG_ELet 43397
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_GivenOther 31238
#define TAG_GivenSame 9069
#define TAG_GivenTag 49870
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_MkCArm 24694
#define TAG_Ok 9325
#define TAG_RFixU 5362
#define TAG_RLocal 34280
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SError 24172
#define TAG_TagVariant 25174
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_alias 294261354
#define LBL_blank 295177582
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_def 308863
#define LBL_done 9584713
#define LBL_end 310101
#define LBL_field 298786068
#define LBL_global 704121550
#define LBL_hash 9690581
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_local 304503685
#define LBL_looser 850054335
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_parent 951717845
#define LBL_path 9928940
#define LBL_severity 75955546
#define LBL_slots 310891087
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_task 10048076
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_total 311908190
#define LBL_ty 10476
#define LBL_version 583465758
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_def__slots[] = {LBL_def, LBL_slots};
static uint32_t shape_local__global[] = {LBL_local, LBL_global};
static uint32_t shape_name__kind__span[] = {LBL_name, LBL_kind, LBL_span};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_task__parent__name__done__total[] = {LBL_task, LBL_parent, LBL_name, LBL_done, LBL_total};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2ecommands_2egoldenPart(V);
V g_heff_2ebuild_2ecommands_2egoldenPart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenPart_clo;
V g_heff_2ebuild_2edocpages_2epage(V);
V g_heff_2ebuild_2edocpages_2epage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2epage_clo;
V g_heff_2ebuild_2edriver_2edefUnder(V, V, V);
V g_heff_2ebuild_2edriver_2edefUnder_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2edefUnder_clo;
V g_heff_2ebuild_2edriver_2eenvOne(V, V);
V g_heff_2ebuild_2edriver_2eenvOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eenvOne_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ecompile_2ecpr_2eaddOut(V, V);
V g_heff_2ecompile_2ecpr_2eaddOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eaddOut_clo;
V g_heff_2ecompile_2ecpr_2emergeTy(V, V);
V g_heff_2ecompile_2ecpr_2emergeTy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2emergeTy_clo;
V g_heff_2ecompile_2ecpr_2eplaceOne(V, V);
V g_heff_2ecompile_2ecpr_2eplaceOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eplaceOne_clo;
V g_heff_2ecompile_2ecycles_2ecycleOf(V, V, V, V);
V g_heff_2ecompile_2ecycles_2ecycleOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2ecycleOf_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2efieldLine(V, V, V);
V g_heff_2ecompile_2eemitc_2efieldLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efieldLine_clo;
V g_heff_2ecompile_2eemitc_2eflatLine(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eflatLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eflatLine_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2efacts_2esureRecW(V, V);
V g_heff_2ecompile_2efacts_2esureRecW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2esureRecW_clo;
V g_heff_2ecompile_2efacts_2etailGlobals(V);
V g_heff_2ecompile_2efacts_2etailGlobals_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2etailGlobals_clo;
V g_heff_2ecompile_2efuse_2econsRec(V, V, V);
V g_heff_2ecompile_2efuse_2econsRec_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2econsRec_clo;
V g_heff_2ecompile_2elower_2egroupOut(V, V, V, V);
V g_heff_2ecompile_2elower_2egroupOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2egroupOut_clo;
V g_heff_2ecompile_2eprims_2efixedImpl(V);
V g_heff_2ecompile_2eprims_2efixedImpl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2efixedImpl_clo;
V g_heff_2ecompile_2eranges_2ewithRange(V, V, V);
V g_heff_2ecompile_2eranges_2ewithRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewithRange_clo;
V g_heff_2ecompile_2erefcount_2ekeptFrom(V, V);
V g_heff_2ecompile_2erefcount_2ekeptFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ekeptFrom_clo;
V g_heff_2ecompile_2esimplify_2eetaMade(V, V);
V g_heff_2ecompile_2esimplify_2eetaMade_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaMade_clo;
V g_heff_2ecompile_2eunbox_2eslotsOf(V);
V g_heff_2ecompile_2eunbox_2eslotsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eslotsOf_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(V);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2eformat_2eupdateSetKey(V, V);
V g_heff_2esyntax_2eformat_2eupdateSetKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eupdateSetKey_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2esurface_2eidentOf(V);
V g_heff_2esyntax_2esurface_2eidentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eidentOf_clo;
V g_list_2eall_24s494596359x1928238377(V);
V g_list_2eall_24s494596359x1928238377_entry(V self, V *a);
extern Clo g_list_2eall_24s494596359x1928238377_clo;
V g_list_2eall_24s523006110x1088755562(V);
V g_list_2eall_24s523006110x1088755562_entry(V self, V *a);
extern Clo g_list_2eall_24s523006110x1088755562_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1399422749x931279364(V, V);
V g_list_2eany_24s1399422749x931279364_entry(V self, V *a);
extern Clo g_list_2eany_24s1399422749x931279364_clo;
V g_list_2eany_24s1606644238x788321190(V, V);
V g_list_2eany_24s1606644238x788321190_entry(V self, V *a);
extern Clo g_list_2eany_24s1606644238x788321190_clo;
V g_list_2eany_24s2118781542x1794344985(V);
V g_list_2eany_24s2118781542x1794344985_entry(V self, V *a);
extern Clo g_list_2eany_24s2118781542x1794344985_clo;
V g_list_2eany_24s667046479x351039015(V, V);
V g_list_2eany_24s667046479x351039015_entry(V self, V *a);
extern Clo g_list_2eany_24s667046479x351039015_clo;
V g_list_2eany_24s78130935x581779089(V, V, V);
V g_list_2eany_24s78130935x581779089_entry(V self, V *a);
extern Clo g_list_2eany_24s78130935x581779089_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s1140544609x424148735_24cpr(V, V);
V g_list_2efind_24s1734629631x1085593985(V, V);
V g_list_2efind_24s1734629631x1085593985_entry(V self, V *a);
extern Clo g_list_2efind_24s1734629631x1085593985_clo;
HeffT2 g_list_2efind_24s1734629631x1085593985_24cpr(V, V);
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f237374790x641547121(V, V, V);
V g_list_2efoldl_24f237374790x641547121_entry(V self, V *a);
extern Clo g_list_2efoldl_24f237374790x641547121_clo;
V g_list_2efoldl_24s1016340684x604821087(V, V);
V g_list_2efoldl_24s1016340684x604821087_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1016340684x604821087_clo;
V g_list_2efoldl_24s1045503831x402406784(V, V, V);
V g_list_2efoldl_24s1045503831x402406784_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1045503831x402406784_clo;
V g_list_2efoldl_24s1261443129x1682844402(V, V);
V g_list_2efoldl_24s1261443129x1682844402_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1261443129x1682844402_clo;
V g_list_2efoldl_24s1344708576x2031305372(V, V);
V g_list_2efoldl_24s1344708576x2031305372_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1344708576x2031305372_clo;
V g_list_2efoldl_24s1344708576x2031305372_24scalars(V, V, V);
V g_list_2efoldl_24s1344708576x2031305372_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1344708576x2031305372_24scalars_clo;
V g_list_2efoldl_24s1738438673x24732785(V, V);
V g_list_2efoldl_24s1738438673x24732785_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1738438673x24732785_clo;
V g_list_2efoldl_24s1766906699x9526323(V, V);
V g_list_2efoldl_24s1766906699x9526323_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1766906699x9526323_clo;
V g_list_2efoldl_24s1977498258x1405492921(V, V, V, V);
V g_list_2efoldl_24s1977498258x1405492921_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1977498258x1405492921_clo;
V g_list_2efoldl_24s2096135476x728523350(V, V);
V g_list_2efoldl_24s2096135476x728523350_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2096135476x728523350_clo;
V g_list_2efoldl_24s249275339x7045056(V, V);
V g_list_2efoldl_24s249275339x7045056_entry(V self, V *a);
extern Clo g_list_2efoldl_24s249275339x7045056_clo;
V g_list_2efoldl_24s465028312x319285028(V, V);
V g_list_2efoldl_24s465028312x319285028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s465028312x319285028_clo;
V g_list_2efoldl_24s518632429x1911716206(V, V);
V g_list_2efoldl_24s518632429x1911716206_entry(V self, V *a);
extern Clo g_list_2efoldl_24s518632429x1911716206_clo;
V g_list_2efoldl_24s598828199x820230131(V, V);
V g_list_2efoldl_24s598828199x820230131_entry(V self, V *a);
extern Clo g_list_2efoldl_24s598828199x820230131_clo;
V g_list_2efoldl_24s655081849x360568693(V, V, V, V);
V g_list_2efoldl_24s655081849x360568693_entry(V self, V *a);
extern Clo g_list_2efoldl_24s655081849x360568693_clo;
V g_list_2efoldl_24s75764538x1218461500(V, V, V);
V g_list_2efoldl_24s75764538x1218461500_entry(V self, V *a);
extern Clo g_list_2efoldl_24s75764538x1218461500_clo;
V g_list_2efoldl_24s92926977x826280221(V, V, V);
V g_list_2efoldl_24s92926977x826280221_entry(V self, V *a);
extern Clo g_list_2efoldl_24s92926977x826280221_clo;
V g_list_2efoldl_24s959743277x860837294(V, V);
V g_list_2efoldl_24s959743277x860837294_entry(V self, V *a);
extern Clo g_list_2efoldl_24s959743277x860837294_clo;
V g_list_2ekeepIf_24s1220809684x843195562_24dps(V, V, V);
V g_list_2ekeepIf_24s1220809684x843195562_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1220809684x843195562_24dps_clo;
V g_list_2ekeepIf_24s1228038992x175493858_24dps(V, V, V, V, V, V, V);
V g_list_2ekeepIf_24s1228038992x175493858_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1228038992x175493858_24dps_clo;
V g_list_2ekeepIf_24s1419960935x1367201220(V, V, V);
V g_list_2ekeepIf_24s1419960935x1367201220_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1419960935x1367201220_clo;
V g_list_2ekeepIf_24s1419960935x1367201220_24dps(V, V, V, V);
V g_list_2ekeepIf_24s1419960935x1367201220_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1419960935x1367201220_24dps_clo;
V g_list_2ekeepIf_24s1814523351x214817707(V);
V g_list_2ekeepIf_24s1814523351x214817707_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1814523351x214817707_clo;
V g_list_2ekeepIf_24s1814523351x214817707_24dps(V, V);
V g_list_2ekeepIf_24s1814523351x214817707_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1814523351x214817707_24dps_clo;
V g_list_2ekeepIf_24s2015972532x1874881274_24dps(V, V, V);
V g_list_2ekeepIf_24s2015972532x1874881274_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2015972532x1874881274_24dps_clo;
V g_list_2ekeepIf_24s304198972x561714839(V, V);
V g_list_2ekeepIf_24s304198972x561714839_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s304198972x561714839_clo;
V g_list_2ekeepIf_24s304198972x561714839_24dps(V, V, V);
V g_list_2ekeepIf_24s304198972x561714839_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s304198972x561714839_24dps_clo;
V g_list_2ekeepIf_24s958254147x1083401940(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2ekeepIf_24s958254147x1083401940_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s958254147x1083401940_clo;
V g_list_2ekeepIf_24s958254147x1083401940_24dps(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2ekeepIf_24s958254147x1083401940_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s958254147x1083401940_24dps_clo;
V g_list_2emap_24f1534051505x274343589(V, V, V, V);
V g_list_2emap_24f1534051505x274343589_entry(V self, V *a);
extern Clo g_list_2emap_24f1534051505x274343589_clo;
V g_list_2emap_24f1534051505x274343589_24dps(V, V, V, V, V);
V g_list_2emap_24f1534051505x274343589_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1534051505x274343589_24dps_clo;
V g_list_2emap_24f1832335087x1608171547_24dps(V, V, V, V, V);
V g_list_2emap_24f1832335087x1608171547_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1832335087x1608171547_24dps_clo;
V g_list_2emap_24f1952774010x636070089_24dps(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1952774010x636070089_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1952774010x636070089_24dps_clo;
V g_list_2emap_24f2081800072x871100793(V);
V g_list_2emap_24f2081800072x871100793_entry(V self, V *a);
extern Clo g_list_2emap_24f2081800072x871100793_clo;
V g_list_2emap_24f2081800072x871100793_24dps(V, V);
V g_list_2emap_24f2081800072x871100793_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f2081800072x871100793_24dps_clo;
V g_list_2emap_24f212342957x901221134_24dps(V, V, V, V, V, V);
V g_list_2emap_24f212342957x901221134_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f212342957x901221134_24dps_clo;
V g_list_2emap_24f530523215x314966509(V, V, V, V, V, V, V);
V g_list_2emap_24f530523215x314966509_entry(V self, V *a);
extern Clo g_list_2emap_24f530523215x314966509_clo;
V g_list_2emap_24f530523215x314966509_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24f530523215x314966509_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f530523215x314966509_24dps_clo;
V g_list_2emap_24s1146729723x1441207893_24dps(V, V, V, V);
V g_list_2emap_24s1146729723x1441207893_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1146729723x1441207893_24dps_clo;
V g_list_2emap_24s1215346472x331828322(V);
V g_list_2emap_24s1215346472x331828322_entry(V self, V *a);
extern Clo g_list_2emap_24s1215346472x331828322_clo;
V g_list_2emap_24s1215346472x331828322_24dps(V, V);
V g_list_2emap_24s1215346472x331828322_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1215346472x331828322_24dps_clo;
V g_list_2emap_24s1353477632x1698603588(V);
V g_list_2emap_24s1353477632x1698603588_entry(V self, V *a);
extern Clo g_list_2emap_24s1353477632x1698603588_clo;
V g_list_2emap_24s1353477632x1698603588_24dps(V, V);
V g_list_2emap_24s1353477632x1698603588_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1353477632x1698603588_24dps_clo;
V g_list_2emap_24s1354328764x1362350361(V);
V g_list_2emap_24s1354328764x1362350361_entry(V self, V *a);
extern Clo g_list_2emap_24s1354328764x1362350361_clo;
V g_list_2emap_24s1354328764x1362350361_24dps(V, V);
V g_list_2emap_24s1354328764x1362350361_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1354328764x1362350361_24dps_clo;
V g_list_2emap_24s1462590149x1582455373(V);
V g_list_2emap_24s1462590149x1582455373_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_clo;
V g_list_2emap_24s1462590149x1582455373_24dps(V, V);
V g_list_2emap_24s1462590149x1582455373_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_24dps_clo;
V g_list_2emap_24s1518131677x2038133191_24dps(V, V, V, V);
V g_list_2emap_24s1518131677x2038133191_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1518131677x2038133191_24dps_clo;
V g_list_2emap_24s1543151117x629172256_24dps(V, V);
V g_list_2emap_24s1543151117x629172256_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1543151117x629172256_24dps_clo;
V g_list_2emap_24s1561756891x1126436879_24dps(V, V);
V g_list_2emap_24s1561756891x1126436879_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1561756891x1126436879_24dps_clo;
V g_list_2emap_24s158244903x55062455(V);
V g_list_2emap_24s158244903x55062455_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_clo;
V g_list_2emap_24s159747708x343809768_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s159747708x343809768_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s159747708x343809768_24dps_clo;
V g_list_2emap_24s1809017761x1063871171_24dps(V, V);
V g_list_2emap_24s1809017761x1063871171_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24dps_clo;
V g_list_2emap_24s1936967306x1304226505(V, V, V, V);
V g_list_2emap_24s1936967306x1304226505_entry(V self, V *a);
extern Clo g_list_2emap_24s1936967306x1304226505_clo;
V g_list_2emap_24s1936967306x1304226505_24dps(V, V, V, V, V);
V g_list_2emap_24s1936967306x1304226505_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1936967306x1304226505_24dps_clo;
V g_list_2emap_24s1960706388x853997965_24dps(V, V);
V g_list_2emap_24s1960706388x853997965_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1960706388x853997965_24dps_clo;
V g_list_2emap_24s1985010810x1780722131(V, V, V, V);
V g_list_2emap_24s1985010810x1780722131_entry(V self, V *a);
extern Clo g_list_2emap_24s1985010810x1780722131_clo;
V g_list_2emap_24s1985010810x1780722131_24dps(V, V, V, V, V);
V g_list_2emap_24s1985010810x1780722131_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1985010810x1780722131_24dps_clo;
V g_list_2emap_24s2029274225x672412636_24dps(V, V, V, V, V);
V g_list_2emap_24s2029274225x672412636_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2029274225x672412636_24dps_clo;
V g_list_2emap_24s2090270526x1588636862_24dps(V, V);
V g_list_2emap_24s2090270526x1588636862_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2090270526x1588636862_24dps_clo;
V g_list_2emap_24s214260857x938990544_24dps(V, V);
V g_list_2emap_24s214260857x938990544_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s214260857x938990544_24dps_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s231073986x752637537_24dps(V, V, V);
V g_list_2emap_24s231073986x752637537_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_24dps_clo;
V g_list_2emap_24s3575633x347355318_24dps(V, V);
V g_list_2emap_24s3575633x347355318_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s3575633x347355318_24dps_clo;
V g_list_2emap_24s420582357x1720502382(V);
V g_list_2emap_24s420582357x1720502382_entry(V self, V *a);
extern Clo g_list_2emap_24s420582357x1720502382_clo;
V g_list_2emap_24s420582357x1720502382_24dps(V, V);
V g_list_2emap_24s420582357x1720502382_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s420582357x1720502382_24dps_clo;
V g_list_2emap_24s500386242x1746840051_24dps(V, V);
V g_list_2emap_24s500386242x1746840051_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s500386242x1746840051_24dps_clo;
V g_list_2emap_24s510830240x893896831_24dps(V, V, V);
V g_list_2emap_24s510830240x893896831_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s510830240x893896831_24dps_clo;
V g_list_2emap_24s513391942x823299088_24dps(V, V);
V g_list_2emap_24s513391942x823299088_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_24dps_clo;
V g_list_2emap_24s531657185x2070920831_24dps(V, V, V);
V g_list_2emap_24s531657185x2070920831_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s531657185x2070920831_24dps_clo;
V g_list_2emap_24s564507054x318389057(V, V);
V g_list_2emap_24s564507054x318389057_entry(V self, V *a);
extern Clo g_list_2emap_24s564507054x318389057_clo;
V g_list_2emap_24s564507054x318389057_24dps(V, V, V);
V g_list_2emap_24s564507054x318389057_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s564507054x318389057_24dps_clo;
V g_list_2emap_24s588563787x236154271_24dps(V, V, V, V, V);
V g_list_2emap_24s588563787x236154271_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s588563787x236154271_24dps_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_list_2emap_24s720989758x1967438448_24dps(V, V);
V g_list_2emap_24s720989758x1967438448_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_24dps_clo;
V g_list_2emap_24s763976875x1978337183(V);
V g_list_2emap_24s763976875x1978337183_entry(V self, V *a);
extern Clo g_list_2emap_24s763976875x1978337183_clo;
V g_list_2emap_24s763976875x1978337183_24dps(V, V);
V g_list_2emap_24s763976875x1978337183_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s763976875x1978337183_24dps_clo;
V g_list_2emap_24s878634257x1677201747_24dps(V, V);
V g_list_2emap_24s878634257x1677201747_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_24dps_clo;
V g_list_2emap_24s966611702x135720910(V, V, V, V, V, V, V);
V g_list_2emap_24s966611702x135720910_entry(V self, V *a);
extern Clo g_list_2emap_24s966611702x135720910_clo;
V g_list_2emap_24s966611702x135720910_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s966611702x135720910_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s966611702x135720910_24dps_clo;
V g_list_2emap_24s984607094x1283457643(V, V, V, V);
V g_list_2emap_24s984607094x1283457643_entry(V self, V *a);
extern Clo g_list_2emap_24s984607094x1283457643_clo;
V g_list_2emap_24s984607094x1283457643_24dps(V, V, V, V, V);
V g_list_2emap_24s984607094x1283457643_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s984607094x1283457643_24dps_clo;
V g_list_2emerge_24s1347843181x1368204458_24dps(V, V, V);
V g_list_2emerge_24s1347843181x1368204458_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1347843181x1368204458_24dps_clo;
V g_list_2emerge_24s1347843181x1368204458_24tok2(V, V, V);
V g_list_2emerge_24s1347843181x1368204458_24tok2_entry(V self, V *a);
extern Clo g_list_2emerge_24s1347843181x1368204458_24tok2_clo;
V g_list_2ezipWith_24s1448987994x473765958(V, V);
V g_list_2ezipWith_24s1448987994x473765958_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1448987994x473765958_clo;
V g_list_2ezipWith_24s1448987994x473765958_24dps(V, V, V);
V g_list_2ezipWith_24s1448987994x473765958_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1448987994x473765958_24dps_clo;
V g_list_2ezipWith_24s1680834068x1673006787(V, V);
V g_list_2ezipWith_24s1680834068x1673006787_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1680834068x1673006787_clo;
V g_list_2ezipWith_24s1680834068x1673006787_24dps(V, V, V);
V g_list_2ezipWith_24s1680834068x1673006787_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1680834068x1673006787_24dps_clo;
V g_list_2ezipWith_24s1713677103x1107896282(V, V);
V g_list_2ezipWith_24s1713677103x1107896282_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1713677103x1107896282_clo;
V g_list_2ezipWith_24s1713677103x1107896282_24dps(V, V, V);
V g_list_2ezipWith_24s1713677103x1107896282_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1713677103x1107896282_24dps_clo;
V g_list_2ezipWith_24s528321443x971020870(V, V);
V g_list_2ezipWith_24s528321443x971020870_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s528321443x971020870_clo;
V g_list_2ezipWith_24s528321443x971020870_24dps(V, V, V);
V g_list_2ezipWith_24s528321443x971020870_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s528321443x971020870_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
V g_std_2eterminal_2ewidget_2ecolumns(V);
V g_std_2eterminal_2ewidget_2ecolumns_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ecolumns_clo;
Clo g_list_2edrop_clo = {{0x80000000u, K_CLO, 0}, g_list_2edrop_entry, 2, 0};

V g_list_2edrop(V v_n_240, V v_x2_241) {
top: ;
  HeffT3 v_t_242 = (g_list_2edrop_24cpr(v_n_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_field_244, v_field_245});
    } else {
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      return NTAG(TAG_Nil);
    }
  }
}
V g_list_2edrop_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2edrop(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s518632429x1911716206_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s518632429x1911716206_entry, 2, 0};

V g_list_2efoldl_24s518632429x1911716206(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_heff_2ecompile_2eranges_2ewithRange(v_z_240, v_t_246, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s518632429x1911716206_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s518632429x1911716206(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s92926977x826280221_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s92926977x826280221_entry, 3, 0};

V g_list_2efoldl_24s92926977x826280221(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      v_t_247 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2413;
    if (heff_intLe_c_lent(v_lit_240, v_t_247, 2)) {
      V v_a_2410;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_248 = heff_field(v_x_243, 0);
        v_a_2410 = heff_dup(v_a_248);
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      switch (heff_tag_of(v_z_241)) {
      case TAG_Nothing: {
        v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){v_a_2410});
        break;
      }
      case TAG_Just: {
        V v_a_2411 = heff_field(v_z_241, 0);
        V v_ru_24z_241_24Just = heff_take_reuse_n(v_z_241, 1ULL, 1);
        V v_t_2412;
        if (heff_intLt_c_lent(v_a_2411, v_a_2410, 0)) {
          heff_drop(v_a_2410);
          v_t_2412 = v_a_2411;
        } else {
          heff_drop(v_a_2411);
          v_t_2412 = v_a_2410;
        }
        v_t_2413 = heff_tag_at_n(v_ru_24z_241_24Just, TAG_Just, 1, (V[]){v_t_2412});
        break;
      }
      default: heff_nomatch(v_z_241);
      }
    } else {
      v_t_2413 = v_z_241;
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2413;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s92926977x826280221_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s92926977x826280221(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s513391942x823299088_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s513391942x823299088_24dps_entry, 2, 0};

V g_list_2emap_24s513391942x823299088_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2414;
      switch (heff_tag_of(v_a_244)) {
      case TAG_TagVariant: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24TagVariant = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_249 = (g_list_2emap_24s158244903x55062455(v_a_248));
        v_t_2414 = heff_tag_at_n(v_ru_24a_244_24TagVariant, TAG_TagVariant, 3, (V[]){v_a_246, v_a_247, v_t_249});
        break;
      }
      case TAG_BadVariant: {
        V v_a_2410 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24BadVariant = heff_take_reuse_n(v_a_244, 1ULL, 1);
        V v_t_2413;
        switch (heff_tag_of(v_a_2410)) {
        case TAG_At: {
          V v_a_2411 = heff_field(v_a_2410, 0);
          V v_a_2412 = heff_field(v_a_2410, 1);
          V v_ru_24a_2410_24At = heff_take_reuse_n(v_a_2410, 3ULL, 2);
          v_t_2413 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24a_2410_24At, v_a_2412, v_a_2411));
          break;
        }
        default: heff_nomatch(v_a_2410);
        }
        v_t_2414 = heff_tag_at_n(v_ru_24a_244_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2413});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2415 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2414, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2416));
    heff_drop(v_u_2417);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2416;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s513391942x823299088_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s513391942x823299088_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s878634257x1677201747_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s878634257x1677201747_24dps_entry, 2, 0};

V g_list_2emap_24s878634257x1677201747_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2esyntax_2esurface_2eidentOf(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s878634257x1677201747_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s878634257x1677201747_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1543151117x629172256_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1543151117x629172256_24dps_entry, 2, 0};

V g_list_2emap_24s1543151117x629172256_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eprims_2efixedImpl(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1543151117x629172256_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1543151117x629172256_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1809017761x1063871171_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1809017761x1063871171_24dps_entry, 2, 0};

V g_list_2emap_24s1809017761x1063871171_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1809017761x1063871171_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1809017761x1063871171_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s528321443x971020870_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s528321443x971020870_entry, 2, 0};

V g_list_2ezipWith_24s528321443x971020870(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_y_244; V r_ = (g_heff_2ecompile_2esimplify_2eetaMade(a_0, a_1)); heff_drop(v_y_244); r_; });
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s528321443x971020870_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s528321443x971020870_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s528321443x971020870(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str0, 1, "_");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str1, 4, "Int8");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str2, 5, "Int16");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str3, 5, "Int32");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str4, 5, "Int64");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str5, 5, "UInt8");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str6, 6, "UInt16");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str7, 6, "UInt32");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str8, 6, "UInt64");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str9, 7, "Float32");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str10, 7, "Float64");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str11, 3, "Int");
Clo g_list_2emap_24s2090270526x1588636862_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2090270526x1588636862_24dps_entry, 2, 0};

V g_list_2emap_24s2090270526x1588636862_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_242)) {
    case TAG_RepV: {
      v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str0);
      break;
    }
    case TAG_RepFix: {
      V v_w_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      switch (heff_tag_of(v_w_244)) {
      case TAG_I8: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str1);
        break;
      }
      case TAG_I16: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str2);
        break;
      }
      case TAG_I32: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str3);
        break;
      }
      case TAG_I64: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str4);
        break;
      }
      case TAG_U8: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str5);
        break;
      }
      case TAG_U16: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str6);
        break;
      }
      case TAG_U32: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str7);
        break;
      }
      case TAG_U64: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str8);
        break;
      }
      case TAG_F32: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str9);
        break;
      }
      default: heff_nomatch(v_w_244);
      }
      break;
    }
    case TAG_RepF64: {
      v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str10);
      break;
    }
    case TAG_RepInt: {
      v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str11);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2090270526x1588636862_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2090270526x1588636862_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1713677103x1107896282_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1713677103x1107896282_entry, 2, 0};

V g_list_2ezipWith_24s1713677103x1107896282(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_248;
      if (heff_intLt_c(v_x_242, MK_INT(16LL))) {
        switch (heff_tag_of(v_y_244)) {
        case TAG_FtFloat: {
          v_t_248 = NTAG(TAG_RepF64);
          break;
        }
        case TAG_FtFixed: {
          V v_w_246 = heff_field(v_y_244, 0);
          V v_ru_24y_244_24FtFixed = heff_take_reuse_n(v_y_244, 1ULL, 1);
          int64_t v_t_247;
          switch (heff_tag_of(v_w_246)) {
          case TAG_I8: {
            v_t_247 = ((int64_t)8ULL);
            break;
          }
          case TAG_I16: {
            v_t_247 = ((int64_t)16ULL);
            break;
          }
          case TAG_I32: {
            v_t_247 = ((int64_t)32ULL);
            break;
          }
          case TAG_I64: {
            v_t_247 = ((int64_t)64ULL);
            break;
          }
          case TAG_U8: {
            v_t_247 = ((int64_t)8ULL);
            break;
          }
          case TAG_U16: {
            v_t_247 = ((int64_t)16ULL);
            break;
          }
          case TAG_U32: {
            v_t_247 = ((int64_t)32ULL);
            break;
          }
          case TAG_U64: {
            v_t_247 = ((int64_t)64ULL);
            break;
          }
          case TAG_F32: {
            v_t_247 = ((int64_t)32ULL);
            break;
          }
          default: heff_nomatch(v_w_246);
          }
          if ((v_t_247 == ((int64_t)64ULL))) {
            v_t_248 = heff_tag_at_n(v_ru_24y_244_24FtFixed, TAG_RepFix, 1, (V[]){v_w_246});
          } else {
            heff_drop(v_w_246);
            heff_drop_cell(v_ru_24y_244_24FtFixed, 1);
            v_t_248 = NTAG(TAG_RepV);
          }
          break;
        }
        case TAG_FtOther: {
          v_t_248 = NTAG(TAG_RepV);
          break;
        }
        case TAG_FtAny: {
          v_t_248 = NTAG(TAG_RepV);
          break;
        }
        default: heff_nomatch(v_y_244);
        }
      } else {
        heff_drop(v_y_244);
        v_t_248 = NTAG(TAG_RepV);
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = (g_list_2ezipWith_24s1713677103x1107896282_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1713677103x1107896282_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1713677103x1107896282(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1713677103x1107896282_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1713677103x1107896282_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1713677103x1107896282_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_249;
      if (heff_intLt_c(v_x_243, MK_INT(16LL))) {
        switch (heff_tag_of(v_y_245)) {
        case TAG_FtFloat: {
          v_t_249 = NTAG(TAG_RepF64);
          break;
        }
        case TAG_FtFixed: {
          V v_w_247 = heff_field(v_y_245, 0);
          V v_ru_24y_245_24FtFixed = heff_take_reuse_n(v_y_245, 1ULL, 1);
          int64_t v_t_248;
          switch (heff_tag_of(v_w_247)) {
          case TAG_I8: {
            v_t_248 = ((int64_t)8ULL);
            break;
          }
          case TAG_I16: {
            v_t_248 = ((int64_t)16ULL);
            break;
          }
          case TAG_I32: {
            v_t_248 = ((int64_t)32ULL);
            break;
          }
          case TAG_I64: {
            v_t_248 = ((int64_t)64ULL);
            break;
          }
          case TAG_U8: {
            v_t_248 = ((int64_t)8ULL);
            break;
          }
          case TAG_U16: {
            v_t_248 = ((int64_t)16ULL);
            break;
          }
          case TAG_U32: {
            v_t_248 = ((int64_t)32ULL);
            break;
          }
          case TAG_U64: {
            v_t_248 = ((int64_t)64ULL);
            break;
          }
          case TAG_F32: {
            v_t_248 = ((int64_t)32ULL);
            break;
          }
          default: heff_nomatch(v_w_247);
          }
          if ((v_t_248 == ((int64_t)64ULL))) {
            v_t_249 = heff_tag_at_n(v_ru_24y_245_24FtFixed, TAG_RepFix, 1, (V[]){v_w_247});
          } else {
            heff_drop(v_w_247);
            heff_drop_cell(v_ru_24y_245_24FtFixed, 1);
            v_t_249 = NTAG(TAG_RepV);
          }
          break;
        }
        case TAG_FtOther: {
          v_t_249 = NTAG(TAG_RepV);
          break;
        }
        case TAG_FtAny: {
          v_t_249 = NTAG(TAG_RepV);
          break;
        }
        default: heff_nomatch(v_y_245);
        }
      } else {
        heff_drop(v_y_245);
        v_t_249 = NTAG(TAG_RepV);
      }
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
      V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_2410;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1713677103x1107896282_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1713677103x1107896282_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s2096135476x728523350_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2096135476x728523350_entry, 2, 0};

V g_list_2efoldl_24s2096135476x728523350(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_242)}), v_z_240});
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_242}), v_t_244});
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2096135476x728523350_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2096135476x728523350(a[0], a[1]);
}
Clo g_list_2efoldl_24s249275339x7045056_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s249275339x7045056_entry, 2, 0};

V g_list_2efoldl_24s249275339x7045056(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_heff_2ecompile_2efacts_2etailGlobals(v_t_247));
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s249275339x7045056_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s249275339x7045056(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1738438673x24732785_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1738438673x24732785_entry, 2, 0};

V g_list_2efoldl_24s1738438673x24732785(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 3), NTAG(TAG_Nil)});
    V v_t_245 = (g_heff_2ecompile_2efacts_2esureRecW(v_z_240, v_t_244));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1738438673x24732785_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1738438673x24732785(a[0], a[1]);
}
Clo g_list_2emap_24s531657185x2070920831_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s531657185x2070920831_24dps_entry, 3, 0};

V g_list_2emap_24s531657185x2070920831_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2erefcount_2ekeptFrom(v_lit_240, v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s531657185x2070920831_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s531657185x2070920831_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s959743277x860837294_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s959743277x860837294_entry, 2, 0};

V g_list_2efoldl_24s959743277x860837294(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkCArm: {
      V v_a_2410 = heff_field(v_x_242, 6);
      v_t_2412 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = ({ V a_0 = v_z_240; V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s598828199x820230131(a_0, a_1)); heff_drop(v_t_2412); r_; });
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s959743277x860837294_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s959743277x860837294(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1353477632x1698603588_str0, 6, "wordLe");
Clo g_list_2emap_24s1353477632x1698603588_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1353477632x1698603588_entry, 1, 0};

V g_list_2emap_24s1353477632x1698603588(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_RFixU, 2, (V[]){NTAG(TAG_I64), MK_INT(0LL)});
    V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_x_241}), NTAG(TAG_Nil)});
    V v_t_245 = heff_tag_n(TAG_CondRelU, 2, (V[]){((V)&g_list_2emap_24s1353477632x1698603588_str0), heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_244})});
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1353477632x1698603588_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1353477632x1698603588_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1353477632x1698603588(a[0]);
}
Clo g_list_2ezipWith_24s1680834068x1673006787_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1680834068x1673006787_entry, 2, 0};

V g_list_2ezipWith_24s1680834068x1673006787(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_y_244; V r_ = (g_heff_2ecompile_2ecpr_2emergeTy(a_0, a_1)); heff_drop(v_y_244); r_; });
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s1680834068x1673006787_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1680834068x1673006787_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1680834068x1673006787(a[0], a[1]);
}
Clo g_list_2efoldl_24s1766906699x9526323_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1766906699x9526323_entry, 2, 0};

V g_list_2efoldl_24s1766906699x9526323(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2ecpr_2eaddOut(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1766906699x9526323_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1766906699x9526323(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s465028312x319285028_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s465028312x319285028_entry, 2, 0};

V g_list_2efoldl_24s465028312x319285028(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2ecpr_2eplaceOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s465028312x319285028_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s465028312x319285028(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1016340684x604821087_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1016340684x604821087_entry, 2, 0};

V g_list_2efoldl_24s1016340684x604821087(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = heff_tag_n(TAG_ELet, 3, (V[]){v_t_246, v_t_249, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1016340684x604821087_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1016340684x604821087(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1977498258x1405492921_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1977498258x1405492921_entry, 4, 0};

V g_list_2efoldl_24s1977498258x1405492921(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_246 = (g_heff_2ecompile_2ecycles_2ecycleOf(v_lit_240, v_lit_241, v_z_242, v_x_244));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_246;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s1977498258x1405492921_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_list_2efoldl_24s1977498258x1405492921(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_list_2emap_24s231073986x752637537_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s231073986x752637537_entry, 2, 0};

V g_list_2emap_24s231073986x752637537(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_242), heff_hole()});
    V v_u_245 = (g_list_2emap_24s231073986x752637537_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s231073986x752637537_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s231073986x752637537(a[0], a[1]);
}
Clo g_list_2emap_24s966611702x135720910_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s966611702x135720910_entry, 7, 0};

V g_list_2emap_24s966611702x135720910(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 3ULL, 2);
      V v_t_2411 = ({ V a_0 = v_a_249; V a_1 = heff_dup(v_lit_242); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_a_249); r_; });
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_243)));
      V v_t_2413 = ({ V a_0 = v_a_2410; V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(a_0)); heff_drop(v_a_2410); r_; });
      V v_t_2414 = heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2413, heff_dup(v_lit_245)));
      v_t_2415 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, v_t_2414));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = (g_list_2emap_24s966611702x135720910_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s966611702x135720910_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s966611702x135720910(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2eany_24s667046479x351039015_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s667046479x351039015_entry, 2, 0};

V g_list_2eany_24s667046479x351039015(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_247 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_t_247, v_lit_240, 1)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s667046479x351039015_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s667046479x351039015(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2eany_24s78130935x581779089_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s78130935x581779089_entry, 3, 0};

V g_list_2eany_24s78130935x581779089(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = (g_heff_2ecompile_2efuse_2econsRec(v_lit_240, heff_dup(v_lit_241), v_x_243));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_lit_241);
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eany_24s78130935x581779089_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2eany_24s78130935x581779089(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s1045503831x402406784_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1045503831x402406784_entry, 3, 0};

V g_list_2efoldl_24s1045503831x402406784(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      v_t_247 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_243, 1);
      v_t_2410 = heff_dup(v_a_249);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2411 = heff_strAppend(heff_dup(v_lit_240), heff_intShow(v_t_2410));
    V v_t_2412 = heff_strAppend(heff_get_n(v_t_247, 0, 3), v_t_2411);
    V v_t_2415;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_x_243, 1);
      v_t_2415 = heff_dup(v_a_2414);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2416 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_241, v_t_2412, v_t_2415));
    V t_0 = v_lit_240;
    V t_1 = v_t_2416;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1045503831x402406784_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1045503831x402406784(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efind_24s1734629631x1085593985_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1734629631x1085593985_entry, 2, 0};

V g_list_2efind_24s1734629631x1085593985(V v_lit_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_list_2efind_24s1734629631x1085593985_24cpr(v_lit_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_list_2efind_24s1734629631x1085593985_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2efind_24s1734629631x1085593985(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s500386242x1746840051_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s500386242x1746840051_24dps_entry, 2, 0};

V g_list_2emap_24s500386242x1746840051_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eunbox_2eslotsOf(heff_dup(v_x_242)));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_def__slots, (V[]){v_x_242, v_t_244}), heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s500386242x1746840051_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s500386242x1746840051_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1448987994x473765958_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1448987994x473765958_entry, 2, 0};

V g_list_2ezipWith_24s1448987994x473765958(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_247;
      switch (heff_tag_of(v_x_242)) {
      case TAG_RepV: {
        v_t_247 = v_y_244;
        break;
      }
      case TAG_RepFix: {
        heff_drop(v_y_244);
        v_t_247 = v_x_242;
        break;
      }
      case TAG_RepF64: {
        heff_drop(v_y_244);
        v_t_247 = v_x_242;
        break;
      }
      case TAG_RepInt: {
        heff_drop(v_y_244);
        v_t_247 = v_x_242;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24s1448987994x473765958_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1448987994x473765958_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1448987994x473765958(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1448987994x473765958_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1448987994x473765958_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1448987994x473765958_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_248;
      switch (heff_tag_of(v_x_243)) {
      case TAG_RepV: {
        v_t_248 = v_y_245;
        break;
      }
      case TAG_RepFix: {
        heff_drop(v_y_245);
        v_t_248 = v_x_243;
        break;
      }
      case TAG_RepF64: {
        heff_drop(v_y_245);
        v_t_248 = v_x_243;
        break;
      }
      case TAG_RepInt: {
        heff_drop(v_y_245);
        v_t_248 = v_x_243;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_249;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1448987994x473765958_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1448987994x473765958_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1985010810x1780722131_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1985010810x1780722131_entry, 4, 0};

V g_list_2emap_24s1985010810x1780722131(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2elower_2egroupOut(v_lit_240, heff_dup(v_lit_241), v_lit_242, v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1985010810x1780722131_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1985010810x1780722131_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24s1985010810x1780722131(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1146729723x1441207893_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1146729723x1441207893_24dps_entry, 4, 0};

V g_list_2emap_24s1146729723x1441207893_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_x_244, heff_dup(v_lit_241)));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1146729723x1441207893_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1146729723x1441207893_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s720989758x1967438448_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s720989758x1967438448_24dps_entry, 2, 0};

V g_list_2emap_24s720989758x1967438448_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s720989758x1967438448_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s720989758x1967438448_24dps(a[0], a[1]);
}
V g_list_2efoldl_24s1344708576x2031305372_24scalars_lam0(V self, V *args);
Clo g_list_2efoldl_24s1344708576x2031305372_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1344708576x2031305372_24scalars_entry, 3, 0};

V g_list_2efoldl_24s1344708576x2031305372_24scalars(V v_local_240, V v_global_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_rec_n(2, shape_local__global, (V[]){v_local_240, v_global_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V t_0 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_clo_n(g_list_2efoldl_24s1344708576x2031305372_24scalars_lam0, 1, 1, (V[]){v_x_243}), v_local_240});
    V t_1 = v_global_241;
    V t_2 = v_xs_244;
    v_local_240 = t_0;
    v_global_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1344708576x2031305372_24scalars_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1344708576x2031305372_24scalars(a[0], a[1], a[2]);
}
V g_list_2efoldl_24s1344708576x2031305372_24scalars_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_245);
  return heff_tag_n(TAG_Ok, 1, (V[]){v_x_243});
}
Clo g_list_2efoldl_24s1344708576x2031305372_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1344708576x2031305372_entry, 2, 0};

V g_list_2efoldl_24s1344708576x2031305372(V v_z_240, V v_x3_241) {
top: ;
  V v_local_242 = heff_take_field(v_z_240, 0);
  V v_global_243 = heff_get_n(v_z_240, 1, 2);
  return (g_list_2efoldl_24s1344708576x2031305372_24scalars(v_local_242, v_global_243, v_x3_241));
}
V g_list_2efoldl_24s1344708576x2031305372_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1344708576x2031305372(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s420582357x1720502382_str0, 0, "");
Clo g_list_2emap_24s420582357x1720502382_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s420582357x1720502382_entry, 1, 0};

V g_list_2emap_24s420582357x1720502382(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_list_2emap_24s420582357x1720502382_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s420582357x1720502382_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s420582357x1720502382_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s420582357x1720502382(a[0]);
}
Clo g_list_2emap_24s1518131677x2038133191_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1518131677x2038133191_24dps_entry, 4, 0};

V g_list_2emap_24s1518131677x2038133191_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = v_lit_241; V a_2 = v_x_244; V r_ = (g_heff_2ecompile_2eemitc_2efieldLine(a_0, a_1, a_2)); heff_drop(v_x_244); r_; });
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1518131677x2038133191_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1518131677x2038133191_24dps(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1936967306x1304226505_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1936967306x1304226505_entry, 4, 0};

V g_list_2emap_24s1936967306x1304226505(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = v_lit_242; V a_3 = v_x_244; V r_ = (g_heff_2ecompile_2eemitc_2eflatLine(a_0, a_1, a_2, a_3)); heff_drop(v_x_244); r_; });
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1936967306x1304226505_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1936967306x1304226505_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s1936967306x1304226505(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_list_2emap_24s1215346472x331828322_str0, 6, "double");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_str1, 4, "bool");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_str2, 12, "const char *");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_str3, 12, "const char *");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_str4, 6, "char *");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_str5, 2, " *");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_str6, 4, "void");
Clo g_list_2emap_24s1215346472x331828322_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1215346472x331828322_entry, 1, 0};

V g_list_2emap_24s1215346472x331828322(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_CInteger: {
      V v_t_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_246 = v_t_243;
      break;
    }
    case TAG_CDouble: {
      v_t_246 = ((V)&g_list_2emap_24s1215346472x331828322_str0);
      break;
    }
    case TAG_CBool: {
      v_t_246 = ((V)&g_list_2emap_24s1215346472x331828322_str1);
      break;
    }
    case TAG_CString: {
      v_t_246 = ((V)&g_list_2emap_24s1215346472x331828322_str2);
      break;
    }
    case TAG_CText: {
      v_t_246 = ((V)&g_list_2emap_24s1215346472x331828322_str3);
      break;
    }
    case TAG_COwnedString: {
      v_t_246 = ((V)&g_list_2emap_24s1215346472x331828322_str4);
      break;
    }
    case TAG_CPointer: {
      V v_t_244 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_246 = heff_strAppend(v_t_244, ((V)&g_list_2emap_24s1215346472x331828322_str5));
      break;
    }
    case TAG_CVoid: {
      v_t_246 = ((V)&g_list_2emap_24s1215346472x331828322_str6);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1215346472x331828322_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1215346472x331828322_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1215346472x331828322(a[0]);
}
Clo g_list_2emap_24s588563787x236154271_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s588563787x236154271_24dps_entry, 5, 0};

V g_list_2emap_24s588563787x236154271_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_248 = heff_dup(heff_field(v_x_245, 1));
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_245, 0);
      heff_take_n(v_x_245, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_t_2413 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2412, heff_dup(v_lit_242)));
    V v_t_2414 = heff_strAppend(heff_intShow(v_t_249), v_t_2413);
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2414), heff_hole()});
    V v_u_2416 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2415));
    heff_drop(v_u_2416);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_2415;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s588563787x236154271_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s588563787x236154271_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2eany_24s1606644238x788321190_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1606644238x788321190_entry, 2, 0};

V g_list_2eany_24s1606644238x788321190(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1606644238x788321190_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1606644238x788321190(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1814523351x214817707_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1814523351x214817707_entry, 1, 0};

V g_list_2ekeepIf_24s1814523351x214817707(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_a_246 = ({ V a_0 = v_t_245; V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(v_t_245); heff_drop(b_1); r_; });
    if (!(heff_dup(v_a_246) == NTAG(TAG_True))) {
      heff_drop(v_a_246);
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_248 = (g_list_2ekeepIf_24s1814523351x214817707_24dps(v_xs_242, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_a_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1814523351x214817707_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1814523351x214817707(a[0]);
}
Clo g_list_2emap_24s1960706388x853997965_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1960706388x853997965_24dps_entry, 2, 0};

V g_list_2emap_24s1960706388x853997965_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1960706388x853997965_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1960706388x853997965_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1261443129x1682844402_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1261443129x1682844402_entry, 2, 0};

V g_list_2efoldl_24s1261443129x1682844402(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ebuild_2edriver_2eenvOne(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1261443129x1682844402_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1261443129x1682844402(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s958254147x1083401940_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s958254147x1083401940_entry, 12, 0};

V g_list_2ekeepIf_24s958254147x1083401940(V v_lit_240, V v_lit_241, V v_lit_242, V v_box_24lit_243, V v_lit_244, V v_lit_245, V v_box_24lit_246, V v_box_24lit_247, V v_lit_248, V v_lit_249, V v_box_24lit_2410, V v_x2_2411) {
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
  int64_t v_lit_246 = heff_unbox_word(v_box_24lit_246);
  int64_t v_lit_247 = heff_unbox_word(v_box_24lit_247);
  int64_t v_lit_2410 = heff_unbox_word(v_box_24lit_2410);
top: ;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24Cons = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_a_2414 = heff_dup(heff_rfield(v_x_2412, 0));
    if ((heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_lit_241, v_a_2414, v_lit_242, 0)) ? (((v_lit_243 <= heff_unbox_word(heff_strByteAt_lent(v_a_2414, v_lit_244, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_a_2414, v_lit_245, 0)) <= v_lit_246)) ? 0 : ((v_lit_247 <= heff_unbox_word(heff_strByteAt_lent(v_a_2414, v_lit_248, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_a_2414, v_lit_249, 0)) <= v_lit_2410) : 1)) : 1)) {
      heff_drop(v_a_2414);
      V v_cell_2415 = heff_tag_at_n(v_ru_24x2_2411_24Cons, TAG_Cons, 2, (V[]){v_x_2412, heff_hole()});
      V v_u_2416 = (g_list_2ekeepIf_24s958254147x1083401940_24dps(v_lit_240, v_lit_241, v_lit_242, heff_box_word(v_lit_243), v_lit_244, v_lit_245, heff_box_word(v_lit_246), heff_box_word(v_lit_247), v_lit_248, v_lit_249, heff_box_word(v_lit_2410), v_xs_2413, heff_dup(v_cell_2415)));
      heff_drop(v_u_2416);
      return v_cell_2415;
    } else {
      heff_drop_rec(v_x_2412, 2);
      heff_drop_cell(v_ru_24x2_2411_24Cons, 2);
      heff_drop(v_a_2414);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2413;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_list_2ekeepIf_24s958254147x1083401940_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V a5 = a[5]; V a8 = a[8]; V a9 = a[9]; V r = g_list_2ekeepIf_24s958254147x1083401940(a[0], a1, a2, a[3], a4, a5, a[6], a[7], a8, a9, a[10], a[11]); heff_drop(a1); heff_drop(a2); heff_drop(a4); heff_drop(a5); heff_drop(a8); heff_drop(a9); return r;
}
HEFF_LIT(g_list_2emap_24s214260857x938990544_24dps_str0, 0, "");
V g_list_2emap_24s214260857x938990544_24dps_lam0(V self, V *args); static Clo g_list_2emap_24s214260857x938990544_24dps_lam0_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s214260857x938990544_24dps_lam0, 1, 0};
Clo g_list_2emap_24s214260857x938990544_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s214260857x938990544_24dps_entry, 2, 0};

V g_list_2emap_24s214260857x938990544_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_span_244 = heff_take_field(v_x_242, 0);
    V v_name_245 = heff_take_field(v_x_242, 1);
    V v_key_246 = heff_take_field(v_x_242, 2);
    V v_member_247 = heff_get_n(v_x_242, 3, 5);
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_span_244, v_name_245, v_key_246, v_member_247, ((V)&g_list_2emap_24s214260857x938990544_24dps_lam0_clo)}), heff_hole()});
    V v_u_2410 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_xs_243;
    V t_1 = v_cell_249;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s214260857x938990544_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s214260857x938990544_24dps(a[0], a[1]);
}
V g_list_2emap_24s214260857x938990544_24dps_lam0(V self, V *args) {
  V v_u_248 = args[0];
  heff_drop(v_u_248);
  return ((V)&g_list_2emap_24s214260857x938990544_24dps_str0);
}
Clo g_list_2emap_24s1354328764x1362350361_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1354328764x1362350361_entry, 1, 0};

V g_list_2emap_24s1354328764x1362350361(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_t_245, 0, 2), heff_hole()});
    V v_u_247 = (g_list_2emap_24s1354328764x1362350361_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1354328764x1362350361_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1354328764x1362350361(a[0]);
}
Clo g_list_2efoldl_24s75764538x1218461500_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s75764538x1218461500_entry, 3, 0};

V g_list_2efoldl_24s75764538x1218461500(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ebuild_2edriver_2edefUnder(heff_dup(v_lit_240), v_z_241, heff_dup(v_x_243)));
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s75764538x1218461500_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s75764538x1218461500(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s984607094x1283457643_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s984607094x1283457643_entry, 4, 0};

V g_list_2emap_24s984607094x1283457643(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_module_246 = heff_take_field(v_x_244, 0);
    V v_alias_247 = heff_get_n(v_x_244, 1, 2);
    V v_t_248 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_alias_247, heff_dup(v_lit_242)));
    V v_t_249 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_module_246, v_t_248));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s984607094x1283457643_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s984607094x1283457643_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s984607094x1283457643(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s984607094x1283457643_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s984607094x1283457643_24dps_entry, 5, 0};

V g_list_2emap_24s984607094x1283457643_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_module_247 = heff_take_field(v_x_245, 0);
    V v_alias_248 = heff_get_n(v_x_245, 1, 2);
    V v_t_249 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_alias_248, heff_dup(v_lit_242)));
    V v_t_2410 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_module_247, v_t_249));
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_2411;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s984607094x1283457643_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s984607094x1283457643_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s564507054x318389057_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s564507054x318389057_entry, 2, 0};

V g_list_2emap_24s564507054x318389057(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_tighter_244 = heff_take_field(v_x_242, 0);
    V v_looser_245 = heff_get_n(v_x_242, 1, 2);
    V v_t_246 = heff_strAppend(v_tighter_244, heff_strAppend(heff_dup(v_lit_240), v_looser_245));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s564507054x318389057_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s564507054x318389057_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s564507054x318389057(a[0], a[1]);
}
Clo g_list_2efoldl_24s655081849x360568693_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s655081849x360568693_entry, 4, 0};

V g_list_2efoldl_24s655081849x360568693(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_tighter_246 = heff_take_field(v_x_244, 0);
    V v_looser_247 = heff_get_n(v_x_244, 1, 2);
    V v_a_248 = v_tighter_246;
    V v_t_249 = heff_intShow(heff_strLength_lent(v_a_248, 0));
    V v_t_2410 = heff_strAppend(v_t_249, heff_strAppend(heff_dup(v_lit_240), v_a_248));
    V v_a_2411 = v_looser_247;
    V v_t_2412 = heff_intShow(heff_strLength_lent(v_a_2411, 0));
    V v_t_2413 = heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_241), v_a_2411));
    V v_t_2414 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
    V v_t_2415 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2414}), v_z_242));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_2415;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s655081849x360568693_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s655081849x360568693(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s159747708x343809768_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s159747708x343809768_24dps_entry, 8, 0};

V g_list_2emap_24s159747708x343809768_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_a_2412;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 2ULL, 2);
      v_a_2412 = v_a_2411;
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_a_2413 = (g_prelude_2esplitFrom(v_lit_240, v_a_2412, heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_a_2412, v_lit_243, 0), NTAG(TAG_Nil)));
    V v_t_2418;
    switch (heff_tag_of(v_a_2413)) {
    case TAG_Nil: {
      v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){v_a_2412, heff_dup(v_lit_244)});
      break;
    }
    case TAG_Cons: {
      V v_a_2414 = heff_field(v_a_2413, 0);
      V v_a_2415 = heff_field(v_a_2413, 1);
      V v_ru_24a_2413_24Cons = heff_take_reuse_n(v_a_2413, 3ULL, 2);
      switch (heff_tag_of(v_a_2415)) {
      case TAG_Nil: {
        heff_drop(v_a_2414);
        v_t_2418 = heff_tag_at_n(v_ru_24a_2413_24Cons, TAG_MkPair, 2, (V[]){v_a_2412, heff_dup(v_lit_245)});
        break;
      }
      case TAG_Cons: {
        V v_a_2416 = heff_field(v_a_2415, 0);
        heff_take_n(v_a_2415, 1ULL, 2);
        heff_drop(v_a_2412);
        v_t_2418 = heff_tag_at_n(v_ru_24a_2413_24Cons, TAG_MkPair, 2, (V[]){v_a_2414, v_a_2416});
        break;
      }
      default: heff_nomatch(v_a_2415);
      }
      break;
    }
    default: heff_nomatch(v_a_2413);
    }
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2419));
    heff_drop(v_u_2420);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_cell_2419;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s159747708x343809768_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2emap_24s159747708x343809768_24dps(a0, a[1], a2, a3, a[4], a[5], a[6], a[7]); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2ekeepIf_24s2015972532x1874881274_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s2015972532x1874881274_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s2015972532x1874881274_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_intEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s2015972532x1874881274_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s2015972532x1874881274_24dps(a[0], a[1], a[2]);
}

HeffT2 g_list_2efind_24s1140544609x424148735_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 2));
    V v_start_245 = heff_take_field(v_a_244, 0);
    V v_end_246 = heff_get_n(v_a_244, 1, 2);
    V v_a_247 = heff_dup(heff_rfield(v_lit_240, 1));
    V v_start_248 = heff_take_field(v_a_247, 0);
    V v_end_249 = heff_get_n(v_a_247, 1, 2);
    if ((heff_intEq_c_lent(v_start_245, v_start_248, 0) && heff_intEq_c_lent(v_end_246, v_end_249, 0))) {
      heff_drop_rec(v_lit_240, 3);
      heff_drop(v_xs_243);
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2eany_24s2118781542x1794344985_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2118781542x1794344985_entry, 1, 0};

V g_list_2eany_24s2118781542x1794344985(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 1));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s2118781542x1794344985_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s2118781542x1794344985(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1561756891x1126436879_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1561756891x1126436879_24dps_entry, 2, 0};

V g_list_2emap_24s1561756891x1126436879_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eformat_2epatKey(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1561756891x1126436879_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1561756891x1126436879_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s510830240x893896831_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s510830240x893896831_24dps_entry, 3, 0};

V g_list_2emap_24s510830240x893896831_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2eformat_2eupdateSetKey(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s510830240x893896831_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s510830240x893896831_24dps(a[0], a[1], a[2]);
}
Clo g_list_2eall_24s494596359x1928238377_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s494596359x1928238377_entry, 1, 0};

V g_list_2eall_24s494596359x1928238377(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    if (((heff_intLe_c_lent(MK_INT(97LL), v_x_241, 1) && heff_intLe_c_lent(v_x_241, MK_INT(122LL), 2)) || ((heff_intLe_c_lent(MK_INT(48LL), v_x_241, 1) && heff_intLe_c_lent(v_x_241, MK_INT(57LL), 2)) || heff_intEq_c_lent(v_x_241, MK_INT(95LL), 2)))) {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s494596359x1928238377_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s494596359x1928238377(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s2029274225x672412636_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029274225x672412636_24dps_entry, 5, 0};

V g_list_2emap_24s2029274225x672412636_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_path_247 = heff_take_field(v_x_245, 0);
    V v_version_248 = heff_take_field(v_x_245, 1);
    V v_hash_249 = heff_get_n(v_x_245, 2, 3);
    V v_t_2410 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_hash_249, heff_dup(v_lit_242)));
    V v_t_2411 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_version_248, v_t_2410));
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_path_247, v_t_2411), heff_hole()});
    V v_u_2413 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_2412;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s2029274225x672412636_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029274225x672412636_24dps(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_list_2emap_24s1462590149x1582455373_str0, 3, ".hf");
Clo g_list_2emap_24s1462590149x1582455373_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1462590149x1582455373_entry, 1, 0};

V g_list_2emap_24s1462590149x1582455373(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_x_241, 0)) - ((int64_t)3ULL));
    V v_t_244 = heff_strSlice(heff_dup(v_x_241), heff_box_word(v_t_243), heff_strLength_lent(v_x_241, 0));
    V v_t_246;
    if (heff_strEq_c(v_t_244, ((V)&g_list_2emap_24s1462590149x1582455373_str0))) {
      int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_x_241, 0)) - ((int64_t)3ULL));
      v_t_246 = heff_strSlice(v_x_241, MK_INT(0LL), heff_box_word(v_t_245));
    } else {
      v_t_246 = v_x_241;
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1462590149x1582455373_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1462590149x1582455373_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1462590149x1582455373(a[0]);
}
Clo g_list_2ekeepIf_24s1220809684x843195562_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1220809684x843195562_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1220809684x843195562_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    if (heff_strEq_c_lent(v_t_247, v_lit_240, 1)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_248;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1220809684x843195562_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s1220809684x843195562_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2ekeepIf_24s1228038992x175493858_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1228038992x175493858_24dps_entry, 7, 0};

V g_list_2ekeepIf_24s1228038992x175493858_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_245, 0);
    V v_xs_248 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_a_249 = heff_dup(heff_rfield(v_x_247, 1));
    V v_t_2410 = ({ V a_0 = v_lit_240; V a_1 = v_a_249; V a_2 = heff_dup(v_lit_241); V a_3 = heff_strFind_lent(v_lit_242, v_a_249, v_lit_243, 0); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_a_249); r_; });
    V v_t_2411 = (g_list_2emap_24s649333309x1802289391(v_t_2410));
    V v_a_2412 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2411));
    switch (heff_tag_of(v_a_2412)) {
    case TAG_Nil: {
      V v_cell_2413 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
      V v_u_2414 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2413));
      heff_drop(v_u_2414);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_248;
      V t_6 = v_cell_2413;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      v_d_246 = t_6;
      goto top;
    }
    case TAG_Cons: {
      V v_a_2415 = heff_field(v_a_2412, 0);
      heff_take_n(v_a_2412, 1ULL, 2);
      if (heff_strEq_c_lent(v_a_2415, v_lit_244, 1)) {
        V v_cell_2417 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
        V v_u_2418 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2417));
        heff_drop(v_u_2418);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_xs_248;
        V t_6 = v_cell_2417;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_x2_245 = t_5;
        v_d_246 = t_6;
        goto top;
      } else {
        heff_drop_rec(v_x_247, 2);
        heff_drop_cell(v_ru_24x2_245_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_xs_248;
        V t_6 = v_d_246;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_x2_245 = t_5;
        v_d_246 = t_6;
        goto top;
      }
    }
    default: return heff_nomatch(v_a_2412);
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2ekeepIf_24s1228038992x175493858_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V r = g_list_2ekeepIf_24s1228038992x175493858_24dps(a0, a[1], a2, a3, a4, a[5], a[6]); heff_drop(a0); heff_drop(a2); heff_drop(a3); heff_drop(a4); return r;
}
Clo g_list_2eall_24s523006110x1088755562_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s523006110x1088755562_entry, 1, 0};

V g_list_2eall_24s523006110x1088755562(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ebuild_2ecommands_2egoldenPart(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s523006110x1088755562_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s523006110x1088755562(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s763976875x1978337183_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s763976875x1978337183_entry, 1, 0};

V g_list_2emap_24s763976875x1978337183(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ebuild_2edocpages_2epage(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s763976875x1978337183_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s763976875x1978337183_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s763976875x1978337183(a[0]);
}
Clo g_list_2eany_24s1399422749x931279364_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1399422749x931279364_entry, 2, 0};

V g_list_2eany_24s1399422749x931279364(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 14);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1399422749x931279364_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1399422749x931279364(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s304198972x561714839_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s304198972x561714839_entry, 2, 0};

V g_list_2ekeepIf_24s304198972x561714839(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s304198972x561714839_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 4);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s304198972x561714839_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s304198972x561714839(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2ekeepIf_24s1419960935x1367201220_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1419960935x1367201220_entry, 3, 0};

V g_list_2ekeepIf_24s1419960935x1367201220(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strSlice(heff_dup(v_x_243), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_245, v_lit_241, 1)) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = (g_list_2ekeepIf_24s1419960935x1367201220_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ekeepIf_24s1419960935x1367201220_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2ekeepIf_24s1419960935x1367201220(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s3575633x347355318_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s3575633x347355318_24dps_entry, 2, 0};

V g_list_2emap_24s3575633x347355318_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_std_2eterminal_2ewidget_2ecolumns(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s3575633x347355318_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s3575633x347355318_24dps(a[0], a[1]);
}
Clo g_list_2emap_24f212342957x901221134_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f212342957x901221134_24dps_entry, 6, 0};

V g_list_2emap_24f212342957x901221134_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_x2_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_p_243);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_248 = heff_tr(heff_call(heff_dup(v_p_243), 1, (V[]){heff_dup(v_x_246)}));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_t_249 = heff_strAppend(heff_take_field(v_x_246, 1), heff_dup(v_lit_242));
      V v_t_2410 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_246, 2), heff_get_n(v_x_246, 3, 7)});
      V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_240), NTAG(TAG_SError), heff_strAppend(heff_dup(v_lit_241), v_t_249), v_t_2410, NTAG(TAG_Nothing)});
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
      V v_u_2413 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_p_243;
      V t_4 = v_xs_247;
      V t_5 = v_cell_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_p_243 = t_3;
      v_x2_244 = t_4;
      v_d_245 = t_5;
      goto top;
    } else {
      heff_drop_rec(v_x_246, 7);
      heff_drop_cell(v_ru_24x2_244_24Cons, 2);
      heff_drop(v_t_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_p_243;
      V t_4 = v_xs_247;
      V t_5 = v_d_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_p_243 = t_3;
      v_x2_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24f212342957x901221134_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f212342957x901221134_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24f1534051505x274343589_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1534051505x274343589_entry, 4, 0};

V g_list_2emap_24f1534051505x274343589(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_text_246 = heff_take_field(v_x_244, 1);
    V v_start_247 = heff_take_field(v_x_244, 2);
    V v_end_248 = heff_get_n(v_x_244, 3, 7);
    V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_text_246)}));
    V v_t_2410 = ({ V a_0 = v_t_249; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      V v_t_2411 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_text_246, heff_dup(v_lit_242)));
      V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_240), NTAG(TAG_SError), v_t_2411, heff_rec_n(2, shape_start__end, (V[]){v_start_247, v_end_248}), NTAG(TAG_Nothing)});
      V v_cell_2413 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
      V v_u_2414 = (g_list_2emap_24f1534051505x274343589_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2413)));
      heff_drop(v_u_2414);
      return v_cell_2413;
    } else {
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_text_246);
      heff_drop(v_start_247);
      heff_drop(v_end_248);
      heff_drop(v_t_2410);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1534051505x274343589_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1534051505x274343589(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24f1645967390x252727070_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1645967390x252727070_entry, 2, 0};

V g_list_2efoldl_24f1645967390x252727070(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_y_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_x_246 = v_y_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1645967390x252727070(a[0], a[1]);
}
Clo g_list_2efoldl_24f237374790x641547121_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f237374790x641547121_entry, 3, 0};

V g_list_2efoldl_24f237374790x641547121(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    switch (heff_tag_of(v_x_243)) {
    case TAG_GivenTag: {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    case TAG_GivenSame: {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    case TAG_GivenOther: {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f237374790x641547121_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f237374790x641547121(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24f1952774010x636070089_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1952774010x636070089_24dps_entry, 10, 0};

V g_list_2emap_24f1952774010x636070089_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_x2_248, V v_d_249) {
top: ;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    heff_drop(v_lit_243);
    return heff_setField(v_d_249, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_248, 0);
    V v_xs_2411 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24Cons = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    if (!heff_strEq_c(heff_strSlice_lent(v_x_2410, v_lit_245, v_lit_246, 0), heff_dup(v_lit_247))) {
      V v_t_2413;
      if (heff_strEq_c(heff_strSlice_lent(v_x_2410, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
        V v_t_2412 = heff_strSlice(heff_dup(v_x_2410), heff_dup(v_lit_244), heff_strLength(v_x_2410));
        v_t_2413 = heff_strAppend(heff_dup(v_lit_243), v_t_2412);
      } else {
        v_t_2413 = v_x_2410;
      }
      V v_cell_2414 = heff_tag_at_n(v_ru_24x2_248_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
      V v_u_2415 = heff_setField(v_d_249, MK_INT(1LL), heff_dup(v_cell_2414));
      heff_drop(v_u_2415);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_xs_2411;
      V t_9 = v_cell_2414;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_x2_248 = t_8;
      v_d_249 = t_9;
      goto top;
    } else {
      heff_drop(v_x_2410);
      heff_drop_cell(v_ru_24x2_248_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_xs_2411;
      V t_9 = v_d_249;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_x2_248 = t_8;
      v_d_249 = t_9;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_list_2emap_24f1952774010x636070089_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V r = g_list_2emap_24f1952774010x636070089_24dps(a0, a1, a2, a[3], a4, a5, a6, a7, a[8], a[9]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); return r;
}
Clo g_list_2emap_24f530523215x314966509_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f530523215x314966509_entry, 7, 0};

V g_list_2emap_24f530523215x314966509(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    heff_drop_rec(v_lit_241, 2);
    heff_drop(v_lit_242);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_target_249 = heff_take_field(v_x_247, 0);
    V v_name_2410 = heff_take_field(v_x_247, 1);
    V v_span_2411 = heff_get_n(v_x_247, 2, 3);
    V v_t_2412 = heff_get_n(v_target_249, 1, 3);
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x2_246_24Cons, 2);
      heff_drop(v_name_2410);
      heff_drop(v_span_2411);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_248;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_2412, 0ULL, 1);
      V v_t_2414 = heff_intAdd(heff_dup(heff_rfield(v_lit_241, 0)), heff_dup(v_lit_242));
      V v_t_2415 = heff_strSlice(heff_dup(heff_rfield(v_lit_240, 3)), heff_dup(heff_rfield(v_lit_241, 0)), v_t_2414);
      V v_t_2416;
      if (heff_strEq_c_lent(v_t_2415, v_lit_243, 1)) {
        v_t_2416 = heff_dup(v_lit_244);
      } else {
        v_t_2416 = heff_dup(v_lit_245);
      }
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__kind__span, (V[]){v_name_2410, v_t_2416, v_span_2411}), heff_hole()});
      V v_u_2418 = (g_list_2emap_24f530523215x314966509_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2417)));
      heff_drop(v_u_2418);
      return v_cell_2417;
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24f530523215x314966509_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2emap_24f530523215x314966509(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
Clo g_list_2emap_24f2081800072x871100793_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f2081800072x871100793_entry, 1, 0};

V g_list_2emap_24f2081800072x871100793(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_path_243 = heff_take_field(v_x_241, 1);
    V v_name_244 = heff_get_n(v_x_241, 0, 3);
    if (heff_strEq_c(v_path_243, heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_name_244, heff_hole()});
      V v_u_246 = (g_list_2emap_24f2081800072x871100793_24dps(v_xs_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_name_244);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f2081800072x871100793_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f2081800072x871100793(a[0]);
}
Clo g_list_2emap_24f1832335087x1608171547_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1832335087x1608171547_24dps_entry, 5, 0};

V g_list_2emap_24f1832335087x1608171547_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (!heff_intEq_c(heff_dup(heff_rfield(v_x_245, 0)), heff_dup(v_lit_242))) {
      V v_t_248;
      if (heff_intEq_c(heff_dup(heff_rfield(v_x_245, 0)), heff_dup(v_lit_240))) {
        V v_t_247 = heff_intAdd(heff_take_field(v_x_245, 3), heff_dup(v_lit_241));
        v_t_248 = ({ V rv_3 = v_t_247; V rr_ = heff_rec_reuse_nf(v_x_245, 23ULL, 5, shape_task__parent__name__done__total, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      } else {
        v_t_248 = v_x_245;
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_249;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop_rec(v_x_245, 5);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1832335087x1608171547_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1832335087x1608171547_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emerge_24s1347843181x1368204458_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1347843181x1368204458_24tok2_entry, 3, 0};

V g_list_2emerge_24s1347843181x1368204458_24tok2(V v_tok_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_x3_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_x2_241, 0));
    V v_xs_244 = heff_dup(heff_field(v_x2_241, 1));
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop_rec(v_x_243, 7);
      heff_drop(v_xs_244);
      return v_x2_241;
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      heff_drop_tag(v_x2_241, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_243, 2)), heff_dup(heff_rfield(v_y_245, 2)))) {
        V v_cell_247 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_248 = (g_list_2emerge_24s1347843181x1368204458_24dps(v_xs_244, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_245, v_ys_246}), heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      } else {
        V v_cell_249 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2410 = (g_list_2emerge_24s1347843181x1368204458_24dps(heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_xs_244}), v_ys_246, heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emerge_24s1347843181x1368204458_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1347843181x1368204458_24tok2(a[0], a[1], a[2]);
}