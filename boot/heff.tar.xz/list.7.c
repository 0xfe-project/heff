// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_Binds 36386
#define TAG_Boxed 28180
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_Ok 9325
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_TagVariant 25174
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_above 293969847
#define LBL_alias 294261354
#define LBL_binder 558177493
#define LBL_blank 295177582
#define LBL_body 9524841
#define LBL_end 310101
#define LBL_field 298786068
#define LBL_fixities 357800079
#define LBL_global 704121550
#define LBL_groups 709681407
#define LBL_hash 9690581
#define LBL_jss 315076
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_local 304503685
#define LBL_looser 850054335
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_path 9928940
#define LBL_severity 75955546
#define LBL_short 310771862
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_ty 10476
#define LBL_use 325633
#define LBL_v 336
#define LBL_version 583465758
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_local__global[] = {LBL_local, LBL_global};
static uint32_t shape_name__field__use[] = {LBL_name, LBL_field, LBL_use};
static uint32_t shape_name__kind__span[] = {LBL_name, LBL_kind, LBL_span};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_target__name__span[] = {LBL_target, LBL_name, LBL_span};
V g_heff_2ebuild_2edriver_2edefUnder(V, V, V);
V g_heff_2ebuild_2edriver_2edefUnder_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2edefUnder_clo;
V g_heff_2ebuild_2edriver_2eenvOne(V, V);
V g_heff_2ebuild_2edriver_2eenvOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eenvOne_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2efieldLine(V, V, V);
V g_heff_2ecompile_2eemitc_2efieldLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efieldLine_clo;
V g_heff_2ecompile_2eemitc_2eflatLine(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eflatLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eflatLine_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2efacts_2esureRecW(V, V);
V g_heff_2ecompile_2efacts_2esureRecW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2esureRecW_clo;
V g_heff_2ecompile_2efacts_2etailGlobals(V);
V g_heff_2ecompile_2efacts_2etailGlobals_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2etailGlobals_clo;
V g_heff_2ecompile_2efuse_2econsRec(V, V, V);
V g_heff_2ecompile_2efuse_2econsRec_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2econsRec_clo;
V g_heff_2ecompile_2elower_2egroupOut(V, V, V, V);
V g_heff_2ecompile_2elower_2egroupOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2egroupOut_clo;
V g_heff_2ecompile_2eprims_2efixedImpl(V);
V g_heff_2ecompile_2eprims_2efixedImpl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2efixedImpl_clo;
V g_heff_2ecompile_2erefcount_2ekeptFrom(V, V);
V g_heff_2ecompile_2erefcount_2ekeptFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ekeptFrom_clo;
V g_heff_2ecompile_2erepr_2ehopedIn(V, V, V);
V g_heff_2ecompile_2erepr_2ehopedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ehopedIn_clo;
V g_heff_2ecompile_2esimplify_2eetaMade(V, V);
V g_heff_2ecompile_2esimplify_2eetaMade_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaMade_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(V);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2eformat_2eupdateSetKey(V, V);
V g_heff_2esyntax_2eformat_2eupdateSetKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eupdateSetKey_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2esurface_2eidentOf(V);
V g_heff_2esyntax_2esurface_2eidentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eidentOf_clo;
V g_list_2eall_24s272166631x2044789868(V, V);
V g_list_2eall_24s272166631x2044789868_entry(V self, V *a);
extern Clo g_list_2eall_24s272166631x2044789868_clo;
V g_list_2eany_24s1073020508x1907354150(V, V, V, V);
V g_list_2eany_24s1073020508x1907354150_entry(V self, V *a);
extern Clo g_list_2eany_24s1073020508x1907354150_clo;
V g_list_2eany_24s1579866964x445286031(V, V);
V g_list_2eany_24s1579866964x445286031_entry(V self, V *a);
extern Clo g_list_2eany_24s1579866964x445286031_clo;
V g_list_2eany_24s1868716698x184030185(V, V);
V g_list_2eany_24s1868716698x184030185_entry(V self, V *a);
extern Clo g_list_2eany_24s1868716698x184030185_clo;
V g_list_2eany_24s2118781542x1794344985(V);
V g_list_2eany_24s2118781542x1794344985_entry(V self, V *a);
extern Clo g_list_2eany_24s2118781542x1794344985_clo;
V g_list_2eany_24s332527547x6651279(V, V);
V g_list_2eany_24s332527547x6651279_entry(V self, V *a);
extern Clo g_list_2eany_24s332527547x6651279_clo;
V g_list_2eany_24s78130935x581779089(V, V, V);
V g_list_2eany_24s78130935x581779089_entry(V self, V *a);
extern Clo g_list_2eany_24s78130935x581779089_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24f419751885x381357165(V, V);
V g_list_2efilter_24f419751885x381357165_entry(V self, V *a);
extern Clo g_list_2efilter_24f419751885x381357165_clo;
V g_list_2efilter_24f419751885x381357165_24dps(V, V, V);
V g_list_2efilter_24f419751885x381357165_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24f419751885x381357165_24dps_clo;
V g_list_2efilter_24s1018181017x1541469354(V);
V g_list_2efilter_24s1018181017x1541469354_entry(V self, V *a);
extern Clo g_list_2efilter_24s1018181017x1541469354_clo;
V g_list_2efilter_24s1018181017x1541469354_24dps(V, V);
V g_list_2efilter_24s1018181017x1541469354_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1018181017x1541469354_24dps_clo;
V g_list_2efilter_24s1564977489x772952072_24dps(V, V, V);
V g_list_2efilter_24s1564977489x772952072_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1564977489x772952072_24dps_clo;
V g_list_2efilter_24s1725367856x1498536808_24dps(V, V);
V g_list_2efilter_24s1725367856x1498536808_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1725367856x1498536808_24dps_clo;
V g_list_2efilter_24s243175984x2038711596(V, V);
V g_list_2efilter_24s243175984x2038711596_entry(V self, V *a);
extern Clo g_list_2efilter_24s243175984x2038711596_clo;
V g_list_2efilter_24s243175984x2038711596_24dps(V, V, V);
V g_list_2efilter_24s243175984x2038711596_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s243175984x2038711596_24dps_clo;
V g_list_2efilter_24s343483820x881052984_24dps(V, V, V);
V g_list_2efilter_24s343483820x881052984_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s343483820x881052984_24dps_clo;
V g_list_2efind_24s1320851393x93733228(V, V);
V g_list_2efind_24s1320851393x93733228_entry(V self, V *a);
extern Clo g_list_2efind_24s1320851393x93733228_clo;
V g_list_2efind_24s465947678x1101118081(V, V);
V g_list_2efind_24s465947678x1101118081_entry(V self, V *a);
extern Clo g_list_2efind_24s465947678x1101118081_clo;
V g_list_2efoldl_24f1046331721x1909432377(V, V, V);
V g_list_2efoldl_24f1046331721x1909432377_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1046331721x1909432377_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f2107672210x353362204(V, V, V, V);
V g_list_2efoldl_24f2107672210x353362204_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2107672210x353362204_clo;
V g_list_2efoldl_24s1261443129x1682844402(V, V);
V g_list_2efoldl_24s1261443129x1682844402_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1261443129x1682844402_clo;
V g_list_2efoldl_24s132236332x1381264820(V, V);
V g_list_2efoldl_24s132236332x1381264820_entry(V self, V *a);
extern Clo g_list_2efoldl_24s132236332x1381264820_clo;
V g_list_2efoldl_24s1344708576x2031305372(V, V);
V g_list_2efoldl_24s1344708576x2031305372_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1344708576x2031305372_clo;
V g_list_2efoldl_24s1634882103x1209760496(V, V);
V g_list_2efoldl_24s1634882103x1209760496_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1634882103x1209760496_clo;
V g_list_2efoldl_24s1738438673x24732785(V, V);
V g_list_2efoldl_24s1738438673x24732785_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1738438673x24732785_clo;
V g_list_2efoldl_24s2096135476x728523350(V, V);
V g_list_2efoldl_24s2096135476x728523350_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2096135476x728523350_clo;
V g_list_2efoldl_24s249275339x7045056(V, V);
V g_list_2efoldl_24s249275339x7045056_entry(V self, V *a);
extern Clo g_list_2efoldl_24s249275339x7045056_clo;
V g_list_2efoldl_24s378225814x484524589(V, V);
V g_list_2efoldl_24s378225814x484524589_entry(V self, V *a);
extern Clo g_list_2efoldl_24s378225814x484524589_clo;
V g_list_2efoldl_24s655081849x360568693(V, V, V, V);
V g_list_2efoldl_24s655081849x360568693_entry(V self, V *a);
extern Clo g_list_2efoldl_24s655081849x360568693_clo;
V g_list_2efoldl_24s671692426x586469947(V, V);
V g_list_2efoldl_24s671692426x586469947_entry(V self, V *a);
extern Clo g_list_2efoldl_24s671692426x586469947_clo;
V g_list_2efoldl_24s753153351x493712762(V, V);
V g_list_2efoldl_24s753153351x493712762_entry(V self, V *a);
extern Clo g_list_2efoldl_24s753153351x493712762_clo;
V g_list_2efoldl_24s75764538x1218461500(V, V, V);
V g_list_2efoldl_24s75764538x1218461500_entry(V self, V *a);
extern Clo g_list_2efoldl_24s75764538x1218461500_clo;
V g_list_2emap_24f1133029339x682401273(V);
V g_list_2emap_24f1133029339x682401273_entry(V self, V *a);
extern Clo g_list_2emap_24f1133029339x682401273_clo;
V g_list_2emap_24f1133029339x682401273_24dps(V, V);
V g_list_2emap_24f1133029339x682401273_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1133029339x682401273_24dps_clo;
V g_list_2emap_24f1451184245x2111935062_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24f1451184245x2111935062_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1451184245x2111935062_24dps_clo;
V g_list_2emap_24s1146729723x1441207893_24dps(V, V, V, V);
V g_list_2emap_24s1146729723x1441207893_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1146729723x1441207893_24dps_clo;
V g_list_2emap_24s1266088736x105832553(V, V);
V g_list_2emap_24s1266088736x105832553_entry(V self, V *a);
extern Clo g_list_2emap_24s1266088736x105832553_clo;
V g_list_2emap_24s1266088736x105832553_24dps(V, V, V);
V g_list_2emap_24s1266088736x105832553_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1266088736x105832553_24dps_clo;
V g_list_2emap_24s1354328764x1362350361(V);
V g_list_2emap_24s1354328764x1362350361_entry(V self, V *a);
extern Clo g_list_2emap_24s1354328764x1362350361_clo;
V g_list_2emap_24s1354328764x1362350361_24dps(V, V);
V g_list_2emap_24s1354328764x1362350361_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1354328764x1362350361_24dps_clo;
V g_list_2emap_24s1462590149x1582455373(V);
V g_list_2emap_24s1462590149x1582455373_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_clo;
V g_list_2emap_24s1462590149x1582455373_24dps(V, V);
V g_list_2emap_24s1462590149x1582455373_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_24dps_clo;
V g_list_2emap_24s147874482x1367635103(V, V, V);
V g_list_2emap_24s147874482x1367635103_entry(V self, V *a);
extern Clo g_list_2emap_24s147874482x1367635103_clo;
V g_list_2emap_24s147874482x1367635103_24dps(V, V, V, V);
V g_list_2emap_24s147874482x1367635103_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s147874482x1367635103_24dps_clo;
V g_list_2emap_24s1518131677x2038133191_24dps(V, V, V, V);
V g_list_2emap_24s1518131677x2038133191_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1518131677x2038133191_24dps_clo;
V g_list_2emap_24s1543151117x629172256_24dps(V, V);
V g_list_2emap_24s1543151117x629172256_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1543151117x629172256_24dps_clo;
V g_list_2emap_24s1561756891x1126436879_24dps(V, V);
V g_list_2emap_24s1561756891x1126436879_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1561756891x1126436879_24dps_clo;
V g_list_2emap_24s158244903x55062455(V);
V g_list_2emap_24s158244903x55062455_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_clo;
V g_list_2emap_24s159747708x343809768_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s159747708x343809768_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s159747708x343809768_24dps_clo;
V g_list_2emap_24s1809017761x1063871171_24dps(V, V);
V g_list_2emap_24s1809017761x1063871171_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24dps_clo;
V g_list_2emap_24s1936967306x1304226505(V, V, V, V);
V g_list_2emap_24s1936967306x1304226505_entry(V self, V *a);
extern Clo g_list_2emap_24s1936967306x1304226505_clo;
V g_list_2emap_24s1936967306x1304226505_24dps(V, V, V, V, V);
V g_list_2emap_24s1936967306x1304226505_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1936967306x1304226505_24dps_clo;
V g_list_2emap_24s1985010810x1780722131(V, V, V, V);
V g_list_2emap_24s1985010810x1780722131_entry(V self, V *a);
extern Clo g_list_2emap_24s1985010810x1780722131_clo;
V g_list_2emap_24s1985010810x1780722131_24dps(V, V, V, V, V);
V g_list_2emap_24s1985010810x1780722131_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1985010810x1780722131_24dps_clo;
V g_list_2emap_24s2029274225x672412636_24dps(V, V, V, V, V);
V g_list_2emap_24s2029274225x672412636_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2029274225x672412636_24dps_clo;
V g_list_2emap_24s2090270526x1588636862_24dps(V, V);
V g_list_2emap_24s2090270526x1588636862_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2090270526x1588636862_24dps_clo;
V g_list_2emap_24s214260857x938990544_24dps(V, V);
V g_list_2emap_24s214260857x938990544_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s214260857x938990544_24dps_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s231073986x752637537_24dps(V, V, V);
V g_list_2emap_24s231073986x752637537_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_24dps_clo;
V g_list_2emap_24s420582357x1720502382(V);
V g_list_2emap_24s420582357x1720502382_entry(V self, V *a);
extern Clo g_list_2emap_24s420582357x1720502382_clo;
V g_list_2emap_24s420582357x1720502382_24dps(V, V);
V g_list_2emap_24s420582357x1720502382_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s420582357x1720502382_24dps_clo;
V g_list_2emap_24s510830240x893896831_24dps(V, V, V);
V g_list_2emap_24s510830240x893896831_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s510830240x893896831_24dps_clo;
V g_list_2emap_24s513391942x823299088_24dps(V, V);
V g_list_2emap_24s513391942x823299088_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_24dps_clo;
V g_list_2emap_24s531657185x2070920831_24dps(V, V, V);
V g_list_2emap_24s531657185x2070920831_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s531657185x2070920831_24dps_clo;
V g_list_2emap_24s564507054x318389057(V, V);
V g_list_2emap_24s564507054x318389057_entry(V self, V *a);
extern Clo g_list_2emap_24s564507054x318389057_clo;
V g_list_2emap_24s564507054x318389057_24dps(V, V, V);
V g_list_2emap_24s564507054x318389057_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s564507054x318389057_24dps_clo;
V g_list_2emap_24s588563787x236154271_24dps(V, V, V, V, V);
V g_list_2emap_24s588563787x236154271_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s588563787x236154271_24dps_clo;
V g_list_2emap_24s720989758x1967438448_24dps(V, V);
V g_list_2emap_24s720989758x1967438448_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_24dps_clo;
V g_list_2emap_24s878634257x1677201747_24dps(V, V);
V g_list_2emap_24s878634257x1677201747_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_24dps_clo;
V g_list_2emap_24s966611702x135720910(V, V, V, V, V, V, V);
V g_list_2emap_24s966611702x135720910_entry(V self, V *a);
extern Clo g_list_2emap_24s966611702x135720910_clo;
V g_list_2emap_24s966611702x135720910_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s966611702x135720910_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s966611702x135720910_24dps_clo;
V g_list_2emap_24s984607094x1283457643(V, V, V, V);
V g_list_2emap_24s984607094x1283457643_entry(V self, V *a);
extern Clo g_list_2emap_24s984607094x1283457643_clo;
V g_list_2emap_24s984607094x1283457643_24dps(V, V, V, V, V);
V g_list_2emap_24s984607094x1283457643_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s984607094x1283457643_24dps_clo;
V g_list_2ezipWith_24s1448987994x473765958(V, V);
V g_list_2ezipWith_24s1448987994x473765958_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1448987994x473765958_clo;
V g_list_2ezipWith_24s1448987994x473765958_24dps(V, V, V);
V g_list_2ezipWith_24s1448987994x473765958_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1448987994x473765958_24dps_clo;
V g_list_2ezipWith_24s1713677103x1107896282(V, V);
V g_list_2ezipWith_24s1713677103x1107896282_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1713677103x1107896282_clo;
V g_list_2ezipWith_24s1713677103x1107896282_24dps(V, V, V);
V g_list_2ezipWith_24s1713677103x1107896282_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1713677103x1107896282_24dps_clo;
V g_list_2ezipWith_24s528321443x971020870(V, V);
V g_list_2ezipWith_24s528321443x971020870_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s528321443x971020870_clo;
V g_list_2ezipWith_24s528321443x971020870_24dps(V, V, V);
V g_list_2ezipWith_24s528321443x971020870_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s528321443x971020870_24dps_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2einsert_24s1687968944x933869791(V, V, V);
V g_map_2einsert_24s1687968944x933869791_entry(V self, V *a);
extern Clo g_map_2einsert_24s1687968944x933869791_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
Clo g_list_2edrop_clo = {{0x80000000u, K_CLO, 0}, g_list_2edrop_entry, 2, 0};

V g_list_2edrop(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2edrop_entry(V self, V *a) {
  (void)self;
  return g_list_2edrop(a[0], a[1]);
}
Clo g_list_2eany_24s1868716698x184030185_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1868716698x184030185_entry, 2, 0};

V g_list_2eany_24s1868716698x184030185(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1868716698x184030185_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1868716698x184030185(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1564977489x772952072_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1564977489x772952072_24dps_entry, 3, 0};

V g_list_2efilter_24s1564977489x772952072_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLt_c(heff_dup(v_lit_240), heff_strLength_lent(v_x_243, 0))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1564977489x772952072_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1564977489x772952072_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s513391942x823299088_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s513391942x823299088_24dps_entry, 2, 0};

V g_list_2emap_24s513391942x823299088_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2414;
      switch (heff_tag_of(v_a_244)) {
      case TAG_TagVariant: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24TagVariant = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_249 = (g_list_2emap_24s158244903x55062455(v_a_248));
        v_t_2414 = heff_tag_at_n(v_ru_24a_244_24TagVariant, TAG_TagVariant, 3, (V[]){v_a_246, v_a_247, v_t_249});
        break;
      }
      case TAG_BadVariant: {
        V v_a_2410 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24BadVariant = heff_take_reuse_n(v_a_244, 1ULL, 1);
        V v_t_2413;
        switch (heff_tag_of(v_a_2410)) {
        case TAG_At: {
          V v_a_2411 = heff_field(v_a_2410, 0);
          V v_a_2412 = heff_field(v_a_2410, 1);
          heff_take_n(v_a_2410, 3ULL, 2);
          v_t_2413 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_2412, v_a_2411));
          break;
        }
        default: heff_nomatch(v_a_2410);
        }
        v_t_2414 = heff_tag_at_n(v_ru_24a_244_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2413});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2415 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2414, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2416));
    heff_drop(v_u_2417);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2416;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s513391942x823299088_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s513391942x823299088_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s878634257x1677201747_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s878634257x1677201747_24dps_entry, 2, 0};

V g_list_2emap_24s878634257x1677201747_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2esyntax_2esurface_2eidentOf(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s878634257x1677201747_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s878634257x1677201747_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1543151117x629172256_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1543151117x629172256_24dps_entry, 2, 0};

V g_list_2emap_24s1543151117x629172256_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eprims_2efixedImpl(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1543151117x629172256_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1543151117x629172256_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1809017761x1063871171_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1809017761x1063871171_24dps_entry, 2, 0};

V g_list_2emap_24s1809017761x1063871171_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1809017761x1063871171_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1809017761x1063871171_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s528321443x971020870_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s528321443x971020870_entry, 2, 0};

V g_list_2ezipWith_24s528321443x971020870(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_y_244; V r_ = (g_heff_2ecompile_2esimplify_2eetaMade(a_0, a_1)); heff_drop(v_y_244); r_; });
      V v_cell_247 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s528321443x971020870_24dps(v_xs2_243, v_ys2_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s528321443x971020870_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s528321443x971020870(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str0, 1, "_");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str1, 4, "Int8");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str2, 5, "Int16");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str3, 5, "Int32");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str4, 5, "Int64");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str5, 5, "UInt8");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str6, 6, "UInt16");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str7, 6, "UInt32");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str8, 6, "UInt64");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str9, 7, "Float32");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str10, 7, "Float64");
Clo g_list_2emap_24s2090270526x1588636862_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2090270526x1588636862_24dps_entry, 2, 0};

V g_list_2emap_24s2090270526x1588636862_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_242)) {
    case TAG_RepV: {
      v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str0);
      break;
    }
    case TAG_RepFix: {
      V v_w_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      switch (heff_tag_of(v_w_244)) {
      case TAG_I8: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str1);
        break;
      }
      case TAG_I16: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str2);
        break;
      }
      case TAG_I32: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str3);
        break;
      }
      case TAG_I64: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str4);
        break;
      }
      case TAG_U8: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str5);
        break;
      }
      case TAG_U16: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str6);
        break;
      }
      case TAG_U32: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str7);
        break;
      }
      case TAG_U64: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str8);
        break;
      }
      case TAG_F32: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str9);
        break;
      }
      default: heff_nomatch(v_w_244);
      }
      break;
    }
    case TAG_RepF64: {
      v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str10);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2090270526x1588636862_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2090270526x1588636862_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1713677103x1107896282_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1713677103x1107896282_entry, 2, 0};

V g_list_2ezipWith_24s1713677103x1107896282(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_2410;
      if (heff_intLt_c(v_x_242, MK_INT(16LL))) {
        switch (heff_tag_of(v_y_244)) {
        case TAG_FtFloat: {
          v_t_2410 = NTAG(TAG_RepF64);
          break;
        }
        case TAG_FtFixed: {
          V v_w_247 = heff_field(v_y_244, 0);
          V v_ru_24y_244_24FtFixed = heff_take_reuse_n(v_y_244, 1ULL, 1);
          V v_t_248;
          switch (heff_tag_of(v_w_247)) {
          case TAG_I8: {
            v_t_248 = MK_INT(8LL);
            break;
          }
          case TAG_I16: {
            v_t_248 = MK_INT(16LL);
            break;
          }
          case TAG_I32: {
            v_t_248 = MK_INT(32LL);
            break;
          }
          case TAG_I64: {
            v_t_248 = MK_INT(64LL);
            break;
          }
          case TAG_U8: {
            v_t_248 = MK_INT(8LL);
            break;
          }
          case TAG_U16: {
            v_t_248 = MK_INT(16LL);
            break;
          }
          case TAG_U32: {
            v_t_248 = MK_INT(32LL);
            break;
          }
          case TAG_U64: {
            v_t_248 = MK_INT(64LL);
            break;
          }
          case TAG_F32: {
            v_t_248 = MK_INT(32LL);
            break;
          }
          default: heff_nomatch(v_w_247);
          }
          if (heff_intEq_c(v_t_248, MK_INT(64LL))) {
            v_t_2410 = heff_tag_at_n(v_ru_24y_244_24FtFixed, TAG_RepFix, 1, (V[]){v_w_247});
          } else {
            heff_drop(v_w_247);
            heff_drop_cell(v_ru_24y_244_24FtFixed, 1);
            v_t_2410 = NTAG(TAG_RepV);
          }
          break;
        }
        case TAG_FtOther: {
          v_t_2410 = NTAG(TAG_RepV);
          break;
        }
        case TAG_FtAny: {
          v_t_2410 = NTAG(TAG_RepV);
          break;
        }
        default: heff_nomatch(v_y_244);
        }
      } else {
        heff_drop(v_y_244);
        v_t_2410 = NTAG(TAG_RepV);
      }
      V v_cell_2411 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = (g_list_2ezipWith_24s1713677103x1107896282_24dps(v_xs2_243, v_ys2_245, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s1713677103x1107896282_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1713677103x1107896282(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1713677103x1107896282_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1713677103x1107896282_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1713677103x1107896282_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_240, 0);
    V v_xs2_244 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_2411;
      if (heff_intLt_c(v_x_243, MK_INT(16LL))) {
        switch (heff_tag_of(v_y_245)) {
        case TAG_FtFloat: {
          v_t_2411 = NTAG(TAG_RepF64);
          break;
        }
        case TAG_FtFixed: {
          V v_w_248 = heff_field(v_y_245, 0);
          V v_ru_24y_245_24FtFixed = heff_take_reuse_n(v_y_245, 1ULL, 1);
          V v_t_249;
          switch (heff_tag_of(v_w_248)) {
          case TAG_I8: {
            v_t_249 = MK_INT(8LL);
            break;
          }
          case TAG_I16: {
            v_t_249 = MK_INT(16LL);
            break;
          }
          case TAG_I32: {
            v_t_249 = MK_INT(32LL);
            break;
          }
          case TAG_I64: {
            v_t_249 = MK_INT(64LL);
            break;
          }
          case TAG_U8: {
            v_t_249 = MK_INT(8LL);
            break;
          }
          case TAG_U16: {
            v_t_249 = MK_INT(16LL);
            break;
          }
          case TAG_U32: {
            v_t_249 = MK_INT(32LL);
            break;
          }
          case TAG_U64: {
            v_t_249 = MK_INT(64LL);
            break;
          }
          case TAG_F32: {
            v_t_249 = MK_INT(32LL);
            break;
          }
          default: heff_nomatch(v_w_248);
          }
          if (heff_intEq_c(v_t_249, MK_INT(64LL))) {
            v_t_2411 = heff_tag_at_n(v_ru_24y_245_24FtFixed, TAG_RepFix, 1, (V[]){v_w_248});
          } else {
            heff_drop(v_w_248);
            heff_drop_cell(v_ru_24y_245_24FtFixed, 1);
            v_t_2411 = NTAG(TAG_RepV);
          }
          break;
        }
        case TAG_FtOther: {
          v_t_2411 = NTAG(TAG_RepV);
          break;
        }
        case TAG_FtAny: {
          v_t_2411 = NTAG(TAG_RepV);
          break;
        }
        default: heff_nomatch(v_y_245);
        }
      } else {
        heff_drop(v_y_245);
        v_t_2411 = NTAG(TAG_RepV);
      }
      V v_cell_2412 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
      V v_u_2413 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_xs2_244;
      V t_1 = v_ys2_246;
      V t_2 = v_cell_2412;
      v_xs_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s1713677103x1107896282_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1713677103x1107896282_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s2096135476x728523350_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2096135476x728523350_entry, 2, 0};

V g_list_2efoldl_24s2096135476x728523350(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_242)}), v_z_240});
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_242}), v_t_244});
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2096135476x728523350_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2096135476x728523350(a[0], a[1]);
}
Clo g_list_2emap_24s147874482x1367635103_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s147874482x1367635103_entry, 3, 0};

V g_list_2emap_24s147874482x1367635103(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2erepr_2ehopedIn(v_lit_240, v_lit_241, v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s147874482x1367635103_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s147874482x1367635103_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2emap_24s147874482x1367635103(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s249275339x7045056_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s249275339x7045056_entry, 2, 0};

V g_list_2efoldl_24s249275339x7045056(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_heff_2ecompile_2efacts_2etailGlobals(v_t_247));
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s249275339x7045056_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s249275339x7045056(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s753153351x493712762_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s753153351x493712762_entry, 2, 0};

V g_list_2efoldl_24s753153351x493712762(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_map_2einsert_24s1687968944x933869791(v_t_246, v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s753153351x493712762_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s753153351x493712762(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1738438673x24732785_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1738438673x24732785_entry, 2, 0};

V g_list_2efoldl_24s1738438673x24732785(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 3), NTAG(TAG_Nil)});
    V v_t_245 = (g_heff_2ecompile_2efacts_2esureRecW(v_z_240, v_t_244));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1738438673x24732785_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1738438673x24732785(a[0], a[1]);
}
Clo g_list_2eany_24s1579866964x445286031_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1579866964x445286031_entry, 2, 0};

V g_list_2eany_24s1579866964x445286031(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_lit_240, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    V v_t_2441;
    switch (heff_tag_of(v_t_246)) {
    case TAG_EVar: {
      V v_a_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      v_t_2441 = heff_strEq_lent(v_x_242, v_a_247, 2);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_t_246, 0ULL, 3);
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_t_246, 0ULL, 4);
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_t_246, 0ULL, 3);
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_na(v_t_246, 0ULL, 1);
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_t_246, 0ULL, 1);
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
      heff_drop(v_t_2441);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2441);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1579866964x445286031_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1579866964x445286031(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s231073986x752637537_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s231073986x752637537_entry, 2, 0};

V g_list_2emap_24s231073986x752637537(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_242), heff_hole()});
    V v_u_245 = (g_list_2emap_24s231073986x752637537_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s231073986x752637537_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s231073986x752637537(a[0], a[1]);
}
Clo g_list_2emap_24s966611702x135720910_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s966611702x135720910_entry, 7, 0};

V g_list_2emap_24s966611702x135720910(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 3ULL, 2);
      V v_t_2411 = (g_heff_2eelab_2eprint_2eescFrom(v_a_249, heff_dup(v_lit_242)));
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_243)));
      V v_t_2413 = ({ V a_0 = v_a_2410; V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(a_0)); heff_drop(v_a_2410); r_; });
      V v_t_2414 = heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2413, heff_dup(v_lit_245)));
      v_t_2415 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, v_t_2414));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = (g_list_2emap_24s966611702x135720910_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s966611702x135720910_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s966611702x135720910(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2eany_24s78130935x581779089_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s78130935x581779089_entry, 3, 0};

V g_list_2eany_24s78130935x581779089(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = (g_heff_2ecompile_2efuse_2econsRec(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_243));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eany_24s78130935x581779089_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2eany_24s78130935x581779089(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s531657185x2070920831_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s531657185x2070920831_24dps_entry, 3, 0};

V g_list_2emap_24s531657185x2070920831_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = ({ V a_0 = v_lit_240; V a_1 = v_x_243; V r_ = (g_heff_2ecompile_2erefcount_2ekeptFrom(a_0, a_1)); heff_drop(v_x_243); r_; });
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s531657185x2070920831_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s531657185x2070920831_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2eall_24s272166631x2044789868_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s272166631x2044789868_entry, 2, 0};

V g_list_2eall_24s272166631x2044789868(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(v_x_242), heff_dup(v_lit_240))) {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_lit_240);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_24s272166631x2044789868_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eall_24s272166631x2044789868(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s1448987994x473765958_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1448987994x473765958_entry, 2, 0};

V g_list_2ezipWith_24s1448987994x473765958(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_247;
      switch (heff_tag_of(v_x_242)) {
      case TAG_RepV: {
        v_t_247 = v_y_244;
        break;
      }
      case TAG_RepFix: {
        heff_drop(v_y_244);
        v_t_247 = v_x_242;
        break;
      }
      case TAG_RepF64: {
        heff_drop(v_y_244);
        v_t_247 = v_x_242;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_cell_248 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24s1448987994x473765958_24dps(v_xs2_243, v_ys2_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s1448987994x473765958_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1448987994x473765958(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1448987994x473765958_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1448987994x473765958_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1448987994x473765958_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_240, 0);
    V v_xs2_244 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_248;
      switch (heff_tag_of(v_x_243)) {
      case TAG_RepV: {
        v_t_248 = v_y_245;
        break;
      }
      case TAG_RepFix: {
        heff_drop(v_y_245);
        v_t_248 = v_x_243;
        break;
      }
      case TAG_RepF64: {
        heff_drop(v_y_245);
        v_t_248 = v_x_243;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_xs2_244;
      V t_1 = v_ys2_246;
      V t_2 = v_cell_249;
      v_xs_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s1448987994x473765958_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1448987994x473765958_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1985010810x1780722131_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1985010810x1780722131_entry, 4, 0};

V g_list_2emap_24s1985010810x1780722131(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2elower_2egroupOut(v_lit_240, heff_dup(v_lit_241), v_lit_242, v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1985010810x1780722131_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1985010810x1780722131_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24s1985010810x1780722131(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1146729723x1441207893_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1146729723x1441207893_24dps_entry, 4, 0};

V g_list_2emap_24s1146729723x1441207893_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_x_244, heff_dup(v_lit_241)));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1146729723x1441207893_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1146729723x1441207893_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2eany_24s1073020508x1907354150_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1073020508x1907354150_entry, 4, 0};

V g_list_2eany_24s1073020508x1907354150(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    if (heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_x_244, v_lit_241, v_lit_242, 0))) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eany_24s1073020508x1907354150_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2eany_24s1073020508x1907354150(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2emap_24s720989758x1967438448_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s720989758x1967438448_24dps_entry, 2, 0};

V g_list_2emap_24s720989758x1967438448_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s720989758x1967438448_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s720989758x1967438448_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s420582357x1720502382_str0, 0, "");
Clo g_list_2emap_24s420582357x1720502382_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s420582357x1720502382_entry, 1, 0};

V g_list_2emap_24s420582357x1720502382(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_list_2emap_24s420582357x1720502382_str0)));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s420582357x1720502382_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s420582357x1720502382_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s420582357x1720502382(a[0]);
}
Clo g_list_2emap_24s1518131677x2038133191_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1518131677x2038133191_24dps_entry, 4, 0};

V g_list_2emap_24s1518131677x2038133191_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = v_lit_241; V a_2 = v_x_244; V r_ = (g_heff_2ecompile_2eemitc_2efieldLine(a_0, a_1, a_2)); heff_drop(v_x_244); r_; });
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1518131677x2038133191_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1518131677x2038133191_24dps(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1936967306x1304226505_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1936967306x1304226505_entry, 4, 0};

V g_list_2emap_24s1936967306x1304226505(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = v_lit_242; V a_3 = v_x_244; V r_ = (g_heff_2ecompile_2eemitc_2eflatLine(a_0, a_1, a_2, a_3)); heff_drop(v_x_244); r_; });
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1936967306x1304226505_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1936967306x1304226505_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s1936967306x1304226505(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_list_2emap_24s588563787x236154271_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s588563787x236154271_24dps_entry, 5, 0};

V g_list_2emap_24s588563787x236154271_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_248 = heff_dup(heff_field(v_x_245, 1));
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_245, 0);
      heff_take_n(v_x_245, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_t_2413 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2412, heff_dup(v_lit_242)));
    V v_t_2414 = heff_strAppend(heff_intShow(v_t_249), v_t_2413);
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2414), heff_hole()});
    V v_u_2416 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2415));
    heff_drop(v_u_2416);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_2415;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s588563787x236154271_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s588563787x236154271_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efilter_24s1018181017x1541469354_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1018181017x1541469354_entry, 1, 0};

V g_list_2efilter_24s1018181017x1541469354(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_a_246 = ({ V a_0 = v_t_245; V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_a_246) == NTAG(TAG_True))) {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_a_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_a_246);
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_248 = (g_list_2efilter_24s1018181017x1541469354_24dps(v_xs_242, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1018181017x1541469354_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1018181017x1541469354(a[0]);
}
Clo g_list_2efoldl_24s132236332x1381264820_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s132236332x1381264820_entry, 2, 0};

V g_list_2efoldl_24s132236332x1381264820(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_dup(heff_field(v_x_242, 1));
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_a_2413 = (g_map_2elookup_24s1546226666x2146984184(v_t_2412, v_z_240));
    V v_t_2415;
    switch (heff_tag_of(v_a_2413)) {
    case TAG_Nothing: {
      v_t_2415 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_a_2414 = heff_field(v_a_2413, 0);
      heff_take_n(v_a_2413, 1ULL, 1);
      v_t_2415 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_a_2413);
    }
    V v_t_2416 = (g_map_2einsert_24s1341440536x470972936(v_t_246, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2415}), v_z_240));
    V t_0 = v_t_2416;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s132236332x1381264820_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s132236332x1381264820(a[0], a[1]);
}
Clo g_list_2efoldl_24s671692426x586469947_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s671692426x586469947_entry, 2, 0};

V g_list_2efoldl_24s671692426x586469947(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_list_2efoldl_24s378225814x484524589(v_z_240, heff_rfield(v_x_242, 3)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s671692426x586469947_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s671692426x586469947(a[0], a1); heff_drop(a1); return r;
}
V g_list_2efoldl_24s1344708576x2031305372_lam0(V self, V *args);
Clo g_list_2efoldl_24s1344708576x2031305372_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1344708576x2031305372_entry, 2, 0};

V g_list_2efoldl_24s1344708576x2031305372(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_clo_n(g_list_2efoldl_24s1344708576x2031305372_lam0, 1, 1, (V[]){v_x_242}), heff_dup(heff_rfield(v_z_240, 0))});
    V v_t_246 = ({ V rv_0 = v_t_245; V rr_ = heff_rec_reuse_nf(v_z_240, 2ULL, 2, shape_local__global, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1344708576x2031305372_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1344708576x2031305372(a[0], a[1]);
}
V g_list_2efoldl_24s1344708576x2031305372_lam0(V self, V *args) {
  V v_a_244 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_244);
  return heff_tag_n(TAG_Ok, 1, (V[]){v_x_242});
}
Clo g_list_2efilter_24s243175984x2038711596_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s243175984x2038711596_entry, 2, 0};

V g_list_2efilter_24s243175984x2038711596(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(v_x_242), heff_dup(v_lit_240))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s243175984x2038711596_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s243175984x2038711596_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s243175984x2038711596(a[0], a[1]);
}
Clo g_list_2efoldl_24s1261443129x1682844402_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1261443129x1682844402_entry, 2, 0};

V g_list_2efoldl_24s1261443129x1682844402(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ebuild_2edriver_2eenvOne(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1261443129x1682844402_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1261443129x1682844402(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1634882103x1209760496_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1634882103x1209760496_entry, 2, 0};

V g_list_2efoldl_24s1634882103x1209760496(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 11));
    V v_t_245 = (g_heff_2esyntax_2efixity_2eappendF(heff_take_field(v_z_240, 0), heff_take_field(v_a_244, 0)));
    V v_t_246 = (g_heff_2esyntax_2efixity_2enubByG(v_t_245));
    V v_t_247 = (g_heff_2esyntax_2efixity_2eappendF(heff_get_n(v_z_240, 1, 2), heff_get_n(v_a_244, 1, 2)));
    V v_t_248 = (g_heff_2esyntax_2efixity_2enubByE(v_t_247));
    V t_0 = heff_rec_n(2, shape_groups__above, (V[]){v_t_246, v_t_248});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1634882103x1209760496_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1634882103x1209760496(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1725367856x1498536808_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1725367856x1498536808_24dps_entry, 2, 0};

V g_list_2efilter_24s1725367856x1498536808_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2426;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_dup(heff_field(v_x_242, 0));
      V v_sp_245 = heff_dup(heff_field(v_x_242, 1));
      switch (heff_tag_of(v_x11_244)) {
      case TAG_DeclEquations: {
        heff_take_n(v_x11_244, 0ULL, 5);
        heff_drop(v_sp_245);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_244, 0ULL, 5);
        heff_drop(v_sp_245);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_244, 0ULL, 4);
        heff_drop(v_sp_245);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclPrimitive: {
        V v_x_2420 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 3);
        v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2420, v_sp_245})});
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_244, 0ULL, 2);
        heff_drop(v_sp_245);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_244, 0ULL, 1);
        heff_drop(v_sp_245);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    switch (heff_tag_of(v_t_2426)) {
    case TAG_Nothing: {
      V v_cell_2427 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2428 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2427));
      heff_drop(v_u_2428);
      V t_0 = v_xs_243;
      V t_1 = v_cell_2427;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_2426, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_2426);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1725367856x1498536808_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1725367856x1498536808_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s214260857x938990544_24dps_str0, 0, "");
V g_list_2emap_24s214260857x938990544_24dps_lam0(V self, V *args); static Clo g_list_2emap_24s214260857x938990544_24dps_lam0_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s214260857x938990544_24dps_lam0, 1, 0};
Clo g_list_2emap_24s214260857x938990544_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s214260857x938990544_24dps_entry, 2, 0};

V g_list_2emap_24s214260857x938990544_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245 = ({ V rv_4 = ((V)&g_list_2emap_24s214260857x938990544_24dps_lam0_clo); V rr_ = heff_rec_reuse_nf(v_x_242, 15ULL, 5, shape_span__name__key__member__ty, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s214260857x938990544_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s214260857x938990544_24dps(a[0], a[1]);
}
V g_list_2emap_24s214260857x938990544_24dps_lam0(V self, V *args) {
  V v_u_244 = args[0];
  heff_drop(v_u_244);
  return ((V)&g_list_2emap_24s214260857x938990544_24dps_str0);
}
Clo g_list_2emap_24s1354328764x1362350361_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1354328764x1362350361_entry, 1, 0};

V g_list_2emap_24s1354328764x1362350361(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_t_245, 0, 2), heff_hole()});
    V v_u_247 = (g_list_2emap_24s1354328764x1362350361_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1354328764x1362350361_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1354328764x1362350361(a[0]);
}
Clo g_list_2efoldl_24s75764538x1218461500_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s75764538x1218461500_entry, 3, 0};

V g_list_2efoldl_24s75764538x1218461500(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ebuild_2edriver_2edefUnder(heff_dup(v_lit_240), v_z_241, heff_dup(v_x_243)));
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s75764538x1218461500_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s75764538x1218461500(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s984607094x1283457643_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s984607094x1283457643_entry, 4, 0};

V g_list_2emap_24s984607094x1283457643(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_take_field(v_x_244, 1), heff_dup(v_lit_242));
    V v_t_247 = heff_strAppend(heff_get_n(v_x_244, 0, 2), heff_strAppend(heff_dup(v_lit_241), v_t_246));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_247), heff_hole()});
    V v_u_249 = (g_list_2emap_24s984607094x1283457643_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s984607094x1283457643_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s984607094x1283457643(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s984607094x1283457643_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s984607094x1283457643_24dps_entry, 5, 0};

V g_list_2emap_24s984607094x1283457643_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = heff_strAppend(heff_take_field(v_x_245, 1), heff_dup(v_lit_242));
    V v_t_248 = heff_strAppend(heff_get_n(v_x_245, 0, 2), heff_strAppend(heff_dup(v_lit_241), v_t_247));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_248), heff_hole()});
    V v_u_2410 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_249;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s984607094x1283457643_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s984607094x1283457643_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s564507054x318389057_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s564507054x318389057_entry, 2, 0};

V g_list_2emap_24s564507054x318389057(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strAppend(heff_dup(v_lit_240), heff_take_field(v_x_242, 1));
    V v_t_245 = heff_strAppend(heff_get_n(v_x_242, 0, 2), v_t_244);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s564507054x318389057_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s564507054x318389057_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s564507054x318389057(a[0], a[1]);
}
Clo g_list_2efoldl_24s655081849x360568693_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s655081849x360568693_entry, 4, 0};

V g_list_2efoldl_24s655081849x360568693(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_a_246 = heff_take_field(v_x_244, 0);
    V v_t_247 = heff_intShow(heff_strLength_lent(v_a_246, 0));
    V v_t_248 = heff_strAppend(v_t_247, heff_strAppend(heff_dup(v_lit_240), v_a_246));
    V v_a_249 = heff_get_n(v_x_244, 1, 2);
    V v_t_2410 = heff_intShow(heff_strLength_lent(v_a_249, 0));
    V v_t_2411 = heff_strAppend(v_t_2410, heff_strAppend(heff_dup(v_lit_241), v_a_249));
    V v_t_2412 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
    V v_t_2413 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2412}), v_z_242));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_2413;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s655081849x360568693_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s655081849x360568693(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s159747708x343809768_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s159747708x343809768_24dps_entry, 8, 0};

V g_list_2emap_24s159747708x343809768_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_a_2412;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 2ULL, 2);
      v_a_2412 = v_a_2411;
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_a_2413 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), heff_dup(v_a_2412), heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_a_2412, v_lit_243, 0), NTAG(TAG_Nil)));
    V v_t_2418;
    switch (heff_tag_of(v_a_2413)) {
    case TAG_Nil: {
      v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){v_a_2412, heff_dup(v_lit_244)});
      break;
    }
    case TAG_Cons: {
      V v_a_2414 = heff_field(v_a_2413, 0);
      V v_a_2415 = heff_field(v_a_2413, 1);
      V v_ru_24a_2413_24Cons = heff_take_reuse_n(v_a_2413, 3ULL, 2);
      switch (heff_tag_of(v_a_2415)) {
      case TAG_Nil: {
        heff_drop(v_a_2414);
        v_t_2418 = heff_tag_at_n(v_ru_24a_2413_24Cons, TAG_MkPair, 2, (V[]){v_a_2412, heff_dup(v_lit_245)});
        break;
      }
      case TAG_Cons: {
        V v_a_2416 = heff_field(v_a_2415, 0);
        heff_take_n(v_a_2415, 1ULL, 2);
        heff_drop(v_a_2412);
        v_t_2418 = heff_tag_at_n(v_ru_24a_2413_24Cons, TAG_MkPair, 2, (V[]){v_a_2414, v_a_2416});
        break;
      }
      default: heff_nomatch(v_a_2415);
      }
      break;
    }
    default: heff_nomatch(v_a_2413);
    }
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2419));
    heff_drop(v_u_2420);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_cell_2419;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s159747708x343809768_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s159747708x343809768_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2eany_24s2118781542x1794344985_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2118781542x1794344985_entry, 1, 0};

V g_list_2eany_24s2118781542x1794344985(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 1));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s2118781542x1794344985_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s2118781542x1794344985(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1561756891x1126436879_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1561756891x1126436879_24dps_entry, 2, 0};

V g_list_2emap_24s1561756891x1126436879_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eformat_2epatKey(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1561756891x1126436879_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1561756891x1126436879_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s510830240x893896831_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s510830240x893896831_24dps_entry, 3, 0};

V g_list_2emap_24s510830240x893896831_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2eformat_2eupdateSetKey(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s510830240x893896831_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s510830240x893896831_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s2029274225x672412636_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029274225x672412636_24dps_entry, 5, 0};

V g_list_2emap_24s2029274225x672412636_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = heff_strAppend(heff_take_field(v_x_245, 2), heff_dup(v_lit_242));
    V v_t_248 = heff_strAppend(heff_take_field(v_x_245, 1), heff_strAppend(heff_dup(v_lit_241), v_t_247));
    V v_t_249 = heff_strAppend(heff_get_n(v_x_245, 0, 3), heff_strAppend(heff_dup(v_lit_240), v_t_248));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_2410;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s2029274225x672412636_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029274225x672412636_24dps(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_list_2emap_24s1462590149x1582455373_str0, 3, ".hf");
Clo g_list_2emap_24s1462590149x1582455373_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1462590149x1582455373_entry, 1, 0};

V g_list_2emap_24s1462590149x1582455373(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_intSub(heff_strLength_lent(v_x_241, 0), MK_INT(3LL));
    V v_t_244 = heff_strSlice(heff_dup(v_x_241), v_t_243, heff_strLength_lent(v_x_241, 0));
    V v_t_247;
    if (heff_strEq_c(v_t_244, ((V)&g_list_2emap_24s1462590149x1582455373_str0))) {
      V v_t_246 = heff_intSub(heff_strLength_lent(v_x_241, 0), MK_INT(3LL));
      v_t_247 = heff_strSlice(v_x_241, MK_INT(0LL), v_t_246);
    } else {
      v_t_247 = v_x_241;
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_list_2emap_24s1462590149x1582455373_24dps(v_xs_242, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1462590149x1582455373_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1462590149x1582455373(a[0]);
}
Clo g_list_2emap_24s1266088736x105832553_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1266088736x105832553_entry, 2, 0};

V g_list_2emap_24s1266088736x105832553(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_a_245 = heff_take_field(v_x_242, 1);
    V v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_242, 0, 2)});
    V v_t_247 = heff_rec_n(3, shape_key__member__local, (V[]){heff_dup(v_lit_240), v_t_246, NTAG(TAG_Nothing)});
    V v_a_248 = heff_take_field(v_a_245, 0);
    V v_a_249 = heff_intSub(heff_dup(heff_rfield(v_a_245, 1)), heff_strLength_lent(v_a_244, 0));
    V v_t_2411;
    if (heff_intLe_c(heff_dup(v_a_248), heff_dup(v_a_249))) {
      heff_drop(v_a_248);
      v_t_2411 = v_a_249;
    } else {
      heff_drop(v_a_249);
      v_t_2411 = v_a_248;
    }
    V v_t_2412 = ({ V rv_0 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_a_245, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_target__name__span, (V[]){v_t_247, v_a_244, v_t_2412}), heff_hole()});
    V v_u_2414 = (g_list_2emap_24s1266088736x105832553_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2413)));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1266088736x105832553_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1266088736x105832553(a[0], a[1]);
}
Clo g_list_2efilter_24s343483820x881052984_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s343483820x881052984_24dps_entry, 3, 0};

V g_list_2efilter_24s343483820x881052984_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 0, 2);
    if (heff_intLe_c(heff_dup(heff_rfield(v_lit_240, 0)), v_t_245)) {
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 1, 2);
      if (heff_intLe_c(v_t_247, heff_dup(heff_rfield(v_lit_240, 1)))) {
        V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V t_0 = v_lit_240;
        V t_1 = v_xs_244;
        V t_2 = v_cell_249;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop_rec(v_x_243, 3);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_xs_244;
        V t_2 = v_d_242;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s343483820x881052984_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s343483820x881052984_24dps(a[0], a[1], a[2]);
}
Clo g_list_2eany_24s332527547x6651279_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s332527547x6651279_entry, 2, 0};

V g_list_2eany_24s332527547x6651279(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s332527547x6651279_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s332527547x6651279(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efind_24s465947678x1101118081_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s465947678x1101118081_entry, 2, 0};

V g_list_2efind_24s465947678x1101118081(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_t_246, v_lit_240, 1)) {
      heff_drop(v_lit_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s465947678x1101118081_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s465947678x1101118081(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efind_24s1320851393x93733228_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1320851393x93733228_entry, 2, 0};

V g_list_2efind_24s1320851393x93733228(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s1320851393x93733228_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s1320851393x93733228(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24f1645967390x252727070_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1645967390x252727070_entry, 2, 0};

V g_list_2efoldl_24f1645967390x252727070(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_y_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_x_246 = v_y_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1645967390x252727070(a[0], a[1]);
}
Clo g_list_2efoldl_24f2107672210x353362204_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f2107672210x353362204_entry, 4, 0};

V g_list_2efoldl_24f2107672210x353362204(V v_lit_240, V v_z_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_242);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_242))) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f2107672210x353362204_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24f2107672210x353362204(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2emap_24f1133029339x682401273_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1133029339x682401273_entry, 1, 0};

V g_list_2emap_24f1133029339x682401273(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_x_241, 0)), 2, 3);
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_241, 0)), 0, 3);
      V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_241, 0)), 1, 3);
      V v_t_246 = heff_rec_n(3, shape_name__field__use, (V[]){v_t_244, v_t_245, heff_get_n(v_x_241, 1, 2)});
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2emap_24f1133029339x682401273_24dps(v_xs_242, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop_rec(v_x_241, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f1133029339x682401273_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1133029339x682401273(a[0]);
}
Clo g_list_2emap_24f1451184245x2111935062_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1451184245x2111935062_24dps_entry, 8, 0};

V g_list_2emap_24f1451184245x2111935062_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 13);
    heff_drop_rec(v_lit_241, 2);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_x_248, 0)), 1, 3);
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nothing: {
      heff_drop_rec(v_x_248, 3);
      heff_drop_cell(v_ru_24x2_246_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_249;
      V t_7 = v_d_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      v_d_247 = t_7;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_2410, 0ULL, 1);
      V v_t_2412 = heff_intAdd(heff_dup(heff_rfield(v_lit_241, 0)), heff_dup(v_lit_242));
      V v_t_2413 = heff_strSlice(heff_dup(heff_rfield(v_lit_240, 3)), heff_dup(heff_rfield(v_lit_241, 0)), v_t_2412);
      V v_t_2415;
      if (heff_strEq_c_lent(v_t_2413, v_lit_243, 1)) {
        v_t_2415 = heff_dup(v_lit_244);
      } else {
        v_t_2415 = heff_dup(v_lit_245);
      }
      V v_t_2416 = heff_rec_n(3, shape_name__kind__span, (V[]){heff_take_field(v_x_248, 1), v_t_2415, heff_get_n(v_x_248, 2, 3)});
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
      V v_u_2418 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2417));
      heff_drop(v_u_2418);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_249;
      V t_7 = v_cell_2417;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      v_d_247 = t_7;
      goto top;
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24f1451184245x2111935062_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1451184245x2111935062_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2efoldl_24f1046331721x1909432377_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1046331721x1909432377_entry, 3, 0};

V g_list_2efoldl_24f1046331721x1909432377(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = heff_dup(heff_rfield(v_x_243, 1));
    switch (heff_tag_of(v_t_245)) {
    case TAG_SError: {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    case TAG_SWarning: {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    case TAG_SDebug: {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1046331721x1909432377_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f1046331721x1909432377(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efilter_24f419751885x381357165_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24f419751885x381357165_entry, 2, 0};

V g_list_2efilter_24f419751885x381357165(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = heff_get_n(v_x_242, 1, 8);
    if (heff_strEq_c_lent(v_x_244, v_lit_240, 0)) {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_x_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_247 = (g_list_2efilter_24f419751885x381357165_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24f419751885x381357165_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24f419751885x381357165(a[0], a[1]);
}