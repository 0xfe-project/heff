// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CRel 55099
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_depth 296830685
#define LBL_depths 611816763
#define LBL_fresh 299054408
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_name 9869138
#define LBL_off 319465
#define LBL_recipe 1012227257
#define LBL_safe 10017876
#define LBL_sp 10436
#define LBL_touched 1244526179
#define LBL_vars 10107635
#define LBL_ver 326173
#define LBL_vers 10111479
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_name__ver__recipe__depth__safe__made[] = {LBL_name, LBL_ver, LBL_recipe, LBL_depth, LBL_safe, LBL_made};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisRel(V);
V g_heff_2ecompile_2eir_2eisRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisRel_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eallAsked_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eallJust_24cpr(V);
V g_heff_2ecompile_2esimplify_2ebinOp(V, V, V);
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebinOp_clo;
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS(V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(V, V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_clo;
V g_heff_2ecompile_2esimplify_2ecopyWith(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyWith_clo;
V g_heff_2ecompile_2esimplify_2edepthOf(V, V, V);
V g_heff_2ecompile_2esimplify_2edepthOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edepthOf_clo;
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2eetaFor(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaFor_clo;
V g_heff_2ecompile_2esimplify_2efoldPrim(V, V);
V g_heff_2ecompile_2esimplify_2efoldPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efoldPrim_clo;
V g_heff_2ecompile_2esimplify_2efoldPrim_24tok1(V, V, V);
V g_heff_2ecompile_2esimplify_2efoldPrim_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efoldPrim_24tok1_clo;
V g_heff_2ecompile_2esimplify_2ehandlerArg(V, V);
V g_heff_2ecompile_2esimplify_2ehandlerArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerArg_clo;
V g_heff_2ecompile_2esimplify_2ehandlerLike(V);
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams(V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ekeptAsk_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2emadeOf(V, V, V);
V g_heff_2ecompile_2esimplify_2emadeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeOf_clo;
V g_heff_2ecompile_2esimplify_2emarkedOf(V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkedOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ematchChosen_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2enoKeep_get(void);
V g_heff_2ecompile_2esimplify_2eprimAppN(V, V, V);
V g_heff_2ecompile_2esimplify_2eprimAppN_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprimAppN_clo;
V g_heff_2ecompile_2esimplify_2eprunedArm(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprunedArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedArm_clo;
V g_heff_2ecompile_2esimplify_2eprunedB(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprunedB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedB_clo;
HeffT2 g_heff_2ecompile_2esimplify_2erefsRetied_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2escrutW(V, V, V);
V g_heff_2ecompile_2esimplify_2escrutW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2escrutW_clo;
V g_heff_2ecompile_2esimplify_2esettleDef(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esettleDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esettleDef_clo;
HeffT2 g_heff_2ecompile_2esimplify_2esettleDef_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eshapesOf(V, V, V);
V g_heff_2ecompile_2esimplify_2eshapesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eshapesOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2especKey(V, V, V, V);
V g_heff_2ecompile_2esimplify_2especKey_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especKey_clo;
V g_heff_2ecompile_2esimplify_2especKnown(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especKnown_clo;
V g_heff_2ecompile_2esimplify_2especLam(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especLam_clo;
V g_heff_2ecompile_2esimplify_2especNamed(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especNamed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especNamed_clo;
V g_heff_2ecompile_2esimplify_2especShaped_24tok2(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especShaped_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especShaped_24tok2_clo;
V g_heff_2ecompile_2esimplify_2etagsGiven(V, V, V);
V g_heff_2ecompile_2esimplify_2etagsGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagsGiven_clo;
V g_heff_2ecompile_2esimplify_2etakeL(V, V);
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_clo;
V g_heff_2ecompile_2esimplify_2etestsOf(V, V);
V g_heff_2ecompile_2esimplify_2etestsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etestsOf_clo;
V g_heff_2ecompile_2esimplify_2etieDeps(V, V, V);
V g_heff_2ecompile_2esimplify_2etieDeps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etieDeps_clo;
V g_heff_2ecompile_2esimplify_2etieGo(V, V, V);
V g_heff_2ecompile_2esimplify_2etieGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etieGo_clo;
V g_heff_2ecompile_2esimplify_2etieOne(V, V, V, V);
V g_heff_2ecompile_2esimplify_2etieOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etieOne_clo;
V g_heff_2ecompile_2esimplify_2eunOp(V, V);
V g_heff_2ecompile_2esimplify_2eunOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunOp_clo;
V g_heff_2ecompile_2esimplify_2evaluesCalled(V, V, V);
V g_heff_2ecompile_2esimplify_2evaluesCalled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evaluesCalled_clo;
HeffT2 g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(V, V, V);
V g_heff_2ecompile_2espec_2ehashGo(V, V, V, V);
V g_heff_2ecompile_2espec_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ehashGo_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s549405518x243689326(V);
V g_list_2emap_24s549405518x243689326_entry(V self, V *a);
extern Clo g_list_2emap_24s549405518x243689326_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith_24s528321443x971020870(V, V);
V g_list_2ezipWith_24s528321443x971020870_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s528321443x971020870_clo;
V g_list_2ezipWith_24s738847920x410598254(V, V);
V g_list_2ezipWith_24s738847920x410598254_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_clo;
V g_prelude_2etraverse_24s1258110132x2117245331(V, V, V, V);
V g_prelude_2etraverse_24s1258110132x2117245331_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1258110132x2117245331_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);

static V g_heff_2ecompile_2esimplify_2enoKeep_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2enoKeep_st;
static V g_heff_2ecompile_2esimplify_2enoKeep_init(void) {
  return heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nil), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get())});
}
V g_heff_2ecompile_2esimplify_2enoKeep_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2enoKeep_st)) return g_heff_2ecompile_2esimplify_2enoKeep_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2enoKeep_val, &g_heff_2ecompile_2esimplify_2enoKeep_st, g_heff_2ecompile_2esimplify_2enoKeep_init);
}
Clo g_heff_2ecompile_2esimplify_2eelemStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eelemStr_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eelemStr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eelemStr(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eprimAppN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprimAppN_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eprimAppN(V v_p_240, V v_argv_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EPrim, 1, (V[]){v_p_240}), v_argv_241});
  }
  case TAG_Just: {
    V v_n_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_241));
    if (heff_intEq_c_lent(v_t_244, v_n_243, 1)) {
      heff_drop(v_n_243);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2efoldPrim_24tok1(v_ru_24x3_242_24Just, v_p_240, v_argv_241);
    } else {
      V v_x_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_241));
      if (heff_intLt_c_lent(v_n_243, v_x_245, 2)) {
        V v_t_246 = (g_heff_2ecompile_2esimplify_2etakeL(heff_dup(v_n_243), heff_dup(v_argv_241)));
        V v_t_247 = (g_heff_2ecompile_2esimplify_2efoldPrim_24tok1(v_ru_24x3_242_24Just, v_p_240, v_t_246));
        V v_t_248 = (g_heff_2ecompile_2esimplify_2edropL(v_n_243, v_argv_241));
        return heff_tag_n(TAG_EApp, 2, (V[]){v_t_247, v_t_248});
      } else {
        heff_drop(v_n_243);
        return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24Just, TAG_EPrim, 1, (V[]){v_p_240}), v_argv_241});
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eprimAppN_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprimAppN(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ehandlerLike_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ehandlerLike(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2410 = heff_field(v_x1_240, 0);
    V v_ts_2411 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_fs_2410)) {
    case TAG_Nil: {
      heff_drop(v_ts_2411);
      heff_drop_cell(v_ru_24x1_240_24ERecord, 2);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_t_2414 = (g_list_2emap_24s549405518x243689326(heff_dup(v_fs_2410)));
      V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2414); r_; });
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_ERecord, 2, (V[]){v_fs_2410, v_ts_2411}), NTAG(TAG_Nil)});
        V v_x_2417 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_2416));
        V v_ret_24bool = heff_bool(!heff_intLt_c_lent(MK_INT(60LL), v_x_2417, 1));
        heff_drop(v_x_2417);
        return v_ret_24bool;
      } else {
        heff_drop_tag(v_fs_2410, 2);
        heff_drop(v_ts_2411);
        heff_drop_cell(v_ru_24x1_240_24ERecord, 2);
        heff_drop(v_t_2415);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_fs_2410);
    }
  }
  case TAG_EProj: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ehandlerLike(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2ehandlerArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ehandlerArg_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ehandlerArg(V v_kinds_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    HeffT2 v_t_244 = ({ V a_0 = v_kinds_240; V a_1 = v_g_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_g_243); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_245 == ((int64_t)0ULL)) && ({ V v_x_247 = heff_dup(v_field_246); int c_ = 1; heff_drop(v_x_247); c_; })));
      heff_drop(v_field_246);
      return v_ret_24bool;
    }
  }
  case TAG_ELam: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EApp: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_ELet: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_ERecord: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EProj: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_ETag: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EMatch: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EPrim: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EPrimCall: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_ECall: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EInt: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EFloat: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EStr: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EBytes: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EFixed: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EFloat32: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EAbandon: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EBool: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_ESet: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EValues: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  case TAG_EFix: {
    return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2ehandlerArg_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ehandlerArg(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2escrutW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2escrutW_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2escrutW(V v_x_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_n_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_b_248 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_248, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_f_249 = heff_field(v_x31_243, 0);
      V v_argv_2410 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EApp = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_t_2411 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x31_243_24EApp, v_argv_2410, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_249, v_t_2411});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2413 = heff_field(v_x31_243, 1);
      V v_b_2414 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2414, v_rest_244})});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2415;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2416 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 2);
      V v_t_2418 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x3_242_24Cons, v_fs_2416, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2418;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2419 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 4);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2419, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_argv_2424 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 3);
      V v_t_2426 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_argv_2424, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2426;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_sc_2427 = heff_field(v_x31_243, 0);
      V v_arms_2428 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2468;
      switch (heff_tag_of(v_sc_2427)) {
      case TAG_EVar: {
        V v_y_2429 = heff_dup(heff_field(v_sc_2427, 0));
        if (heff_strEq_c_lent(v_x_240, v_y_2429, 2)) {
          v_t_2468 = heff_intAdd(v_n_241, MK_INT(1LL));
        } else {
          v_t_2468 = v_n_241;
        }
        break;
      }
      case TAG_EGlobal: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_ELam: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_EApp: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_ELet: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_ERecord: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_EProj: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_ETag: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_EMatch: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_EPrim: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_EPrimCall: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_ECall: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_EInt: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_EFloat: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_EStr: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_EBytes: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_EFixed: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_EFloat32: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_EAbandon: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_EBool: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_ESet: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_EValues: {
        v_t_2468 = v_n_241;
        break;
      }
      case TAG_EFix: {
        v_t_2468 = v_n_241;
        break;
      }
      default: heff_nomatch(v_sc_2427);
      }
      V v_t_2469 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2428, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_t_2468;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_sc_2427, v_t_2469});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_argv_2472 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V v_t_2473 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_argv_2472, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2473;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_argv_2475 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V v_t_2476 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_argv_2475, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2476;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2484 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2485 = (g_heff_2ecompile_2esimplify_2etestsOf(v_x_240, v_c_2484));
      V v_t_2486 = ({ V a_0 = v_c_2484; V a_1 = v_rest_244; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2484); r_; });
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(v_n_241, v_t_2485);
      V t_2 = v_t_2486;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2488 = heff_field(v_x31_243, 1);
      V v_b_2489 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2490 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2488, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2489, v_rest_244})});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2490;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2491 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_2492 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_es_2491, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2492;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2escrutW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2escrutW(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2eprunedB_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprunedB_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eprunedB(V v_lim_240, V v_known_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_lim_240);
    heff_drop(v_known_241);
    return v_n_242;
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    if (heff_intLt_c_lent(v_lim_240, v_n_242, 0)) {
      heff_drop(v_lim_240);
      heff_drop(v_known_241);
      heff_drop(v_e_244);
      heff_drop(v_rest_245);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      return v_n_242;
    } else {
      HeffT2 v_t_246 = (g_heff_2ecompile_2esimplify_2ematchChosen_24cpr(heff_dup(v_known_241), heff_dup(v_e_244)));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          heff_drop(v_known_241);
          heff_drop(v_e_244);
          V v_it1_249 = v_field_248;
          switch (heff_tag_of(v_it1_249)) {
          case TAG_MkPair: {
            V v_b_2410 = heff_field(v_it1_249, 0);
            V v_known2_2411 = heff_field(v_it1_249, 1);
            heff_take_n(v_it1_249, 3ULL, 2);
            V t_0 = v_lim_240;
            V t_1 = v_known2_2411;
            V t_2 = heff_intAdd(v_n_242, MK_INT(1LL));
            V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_b_2410, v_rest_245});
            v_lim_240 = t_0;
            v_known_241 = t_1;
            v_n_242 = t_2;
            v_x4_243 = t_3;
            goto top;
          }
          default: return heff_nomatch(v_it1_249);
          }
        } else {
          heff_drop_cell(v_ru_24x4_243_24Cons, 2);
          heff_drop(v_field_248);
          V v_t_2412 = (g_heff_2ecompile_2eir_2epartsOnto(v_e_244, v_rest_245));
          V t_0 = v_lim_240;
          V t_1 = v_known_241;
          V t_2 = heff_intAdd(v_n_242, MK_INT(1LL));
          V t_3 = v_t_2412;
          v_lim_240 = t_0;
          v_known_241 = t_1;
          v_n_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
      }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2esimplify_2eprunedB_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprunedB(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2eprunedArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprunedArm_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eprunedArm(V v_go_240, V v_known_241, V v_x3_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_x4_243)) {
    case TAG_MkArm: {
      V v_t2_244 = heff_field(v_x4_243, 0);
      V v_vs_245 = heff_field(v_x4_243, 1);
      V v_b_246 = heff_field(v_x4_243, 2);
      V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
      V v_t_247 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_246}));
      return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_244, v_vs_245, v_t_247});
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  case TAG_Just: {
    V v_x31_248 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_248)) {
    case TAG_EVar: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_2410 = heff_field(v_x4_243, 0);
        V v_vs_2411 = heff_field(v_x4_243, 1);
        V v_b_2412 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_2413 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_2412}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2410, v_vs_2411, v_t_2413});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_EGlobal: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_2415 = heff_field(v_x4_243, 0);
        V v_vs_2416 = heff_field(v_x4_243, 1);
        V v_b_2417 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_2418 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_2417}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2415, v_vs_2416, v_t_2418});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_ELam: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_2421 = heff_field(v_x4_243, 0);
        V v_vs_2422 = heff_field(v_x4_243, 1);
        V v_b_2423 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_2424 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_2423}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2421, v_vs_2422, v_t_2424});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_EApp: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_2427 = heff_field(v_x4_243, 0);
        V v_vs_2428 = heff_field(v_x4_243, 1);
        V v_b_2429 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_2430 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_2429}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2427, v_vs_2428, v_t_2430});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_ELet: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_2434 = heff_field(v_x4_243, 0);
        V v_vs_2435 = heff_field(v_x4_243, 1);
        V v_b_2436 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_2437 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_2436}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2434, v_vs_2435, v_t_2437});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_ERecord: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_2440 = heff_field(v_x4_243, 0);
        V v_vs_2441 = heff_field(v_x4_243, 1);
        V v_b_2442 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_2443 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_2442}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2440, v_vs_2441, v_t_2443});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_EProj: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_2448 = heff_field(v_x4_243, 0);
        V v_vs_2449 = heff_field(v_x4_243, 1);
        V v_b_2450 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_2451 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_2450}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2448, v_vs_2449, v_t_2451});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_ETag: {
      V v_t_2452 = heff_field(v_x31_248, 0);
      V v_argv_2453 = heff_field(v_x31_248, 1);
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_2455 = heff_field(v_x4_243, 0);
        V v_vs_2456 = heff_field(v_x4_243, 1);
        V v_b_2457 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        if (heff_strEq_c_lent(v_t_2452, v_t2_2455, 0)) {
          V v_t_2458 = (g_heff_2ecompile_2esimplify_2etagsGiven(v_vs_2456, v_argv_2453, v_known_241));
          V v_t_2459 = heff_tr(heff_call(v_go_240, 2, (V[]){v_t_2458, v_b_2457}));
          return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2455, v_vs_2456, v_t_2459});
        } else {
          heff_drop(v_go_240);
          heff_drop(v_known_241);
          heff_drop(v_b_2457);
          return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2455, v_vs_2456, NTAG(TAG_EAbandon)});
        }
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_EMatch: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_2462 = heff_field(v_x4_243, 0);
        V v_vs_2463 = heff_field(v_x4_243, 1);
        V v_b_2464 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_2465 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_2464}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2462, v_vs_2463, v_t_2465});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_EPrim: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_2467 = heff_field(v_x4_243, 0);
        V v_vs_2468 = heff_field(v_x4_243, 1);
        V v_b_2469 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_2470 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_2469}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2467, v_vs_2468, v_t_2470});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_EPrimCall: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_2473 = heff_field(v_x4_243, 0);
        V v_vs_2474 = heff_field(v_x4_243, 1);
        V v_b_2475 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_2476 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_2475}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2473, v_vs_2474, v_t_2476});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_ECall: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_2479 = heff_field(v_x4_243, 0);
        V v_vs_2480 = heff_field(v_x4_243, 1);
        V v_b_2481 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_2482 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_2481}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2479, v_vs_2480, v_t_2482});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_EInt: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_2484 = heff_field(v_x4_243, 0);
        V v_vs_2485 = heff_field(v_x4_243, 1);
        V v_b_2486 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_2487 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_2486}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2484, v_vs_2485, v_t_2487});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_EFloat: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_2489 = heff_field(v_x4_243, 0);
        V v_vs_2490 = heff_field(v_x4_243, 1);
        V v_b_2491 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_2492 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_2491}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2489, v_vs_2490, v_t_2492});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_EStr: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_2494 = heff_field(v_x4_243, 0);
        V v_vs_2495 = heff_field(v_x4_243, 1);
        V v_b_2496 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_2497 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_2496}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2494, v_vs_2495, v_t_2497});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_EBytes: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_2499 = heff_field(v_x4_243, 0);
        V v_vs_24100 = heff_field(v_x4_243, 1);
        V v_b_24101 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_24102 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_24101}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2499, v_vs_24100, v_t_24102});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_EFixed: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_24105 = heff_field(v_x4_243, 0);
        V v_vs_24106 = heff_field(v_x4_243, 1);
        V v_b_24107 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_24108 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_24107}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_24105, v_vs_24106, v_t_24108});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_EFloat32: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_24110 = heff_field(v_x4_243, 0);
        V v_vs_24111 = heff_field(v_x4_243, 1);
        V v_b_24112 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_24113 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_24112}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_24110, v_vs_24111, v_t_24113});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_EAbandon: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_24114 = heff_field(v_x4_243, 0);
        V v_vs_24115 = heff_field(v_x4_243, 1);
        V v_b_24116 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_24117 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_24116}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_24114, v_vs_24115, v_t_24117});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_EBool: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_24119 = heff_field(v_x4_243, 0);
        V v_vs_24120 = heff_field(v_x4_243, 1);
        V v_b_24121 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_24122 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_24121}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_24119, v_vs_24120, v_t_24122});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_ESet: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_24126 = heff_field(v_x4_243, 0);
        V v_vs_24127 = heff_field(v_x4_243, 1);
        V v_b_24128 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_24129 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_24128}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_24126, v_vs_24127, v_t_24129});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_EValues: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_24131 = heff_field(v_x4_243, 0);
        V v_vs_24132 = heff_field(v_x4_243, 1);
        V v_b_24133 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_24134 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_24133}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_24131, v_vs_24132, v_t_24134});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    case TAG_EFix: {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_MkArm: {
        V v_t2_24137 = heff_field(v_x4_243, 0);
        V v_vs_24138 = heff_field(v_x4_243, 1);
        V v_b_24139 = heff_field(v_x4_243, 2);
        V v_ru_24x4_243_24MkArm = heff_take_reuse_n(v_x4_243, 7ULL, 3);
        V v_t_24140 = heff_tr(heff_call(v_go_240, 2, (V[]){v_known_241, v_b_24139}));
        return heff_tag_at_n(v_ru_24x4_243_24MkArm, TAG_MkArm, 3, (V[]){v_t2_24137, v_vs_24138, v_t_24140});
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
    default: return heff_nomatch(v_x31_248);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eprunedArm_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2eprunedArm(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2eshapesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eshapesOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eshapesOf(V v_x1_240, V v_x2_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(v_x1_240, v_x2_241, v_p_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2esimplify_2eshapesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eshapesOf(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2esimplify_2eallAsked_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_True), v_p_241}});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_h_244 = heff_field(v_x11_242, 0);
      V v_v_245 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      HeffT2 v_t_246 = (g_heff_2ecompile_2esimplify_2ekeptAsk_24cpr(v_h_244, v_v_245, v_p_241));
      {
        V v_field_247 = v_t_246.f[0];
        V v_field_248 = v_t_246.f[1];
        V v_x_249 = v_field_247;
        V v_s_2410 = v_field_248;
        if ((heff_dup(v_x_249) == NTAG(TAG_True))) {
          heff_drop(v_x_249);
          V t_0 = v_rest_243;
          V t_1 = v_s_2410;
          v_x1_240 = t_0;
          v_p_241 = t_1;
          goto top;
        } else {
          heff_drop(v_rest_243);
          heff_drop(v_x_249);
          return ((HeffT2){{NTAG(TAG_False), v_s_2410}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ecompile_2esimplify_2especLam_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2especLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especLam_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2especLam(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_argv_244, V v_s_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 6, 7);
  if (((heff_dup(v_t_246) == NTAG(TAG_True)) || heff_intLe_c(MK_INT(50000LL), heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 5, 7)))) {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_t_246);
    V v_x_247 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_s_245});
  } else {
    heff_drop(v_t_246);
    V v_t_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2eetaFor_clo), 5, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), heff_dup(v_xs_242), heff_dup(v_b_243), heff_dup(v_argv_244)}));
    return (g_heff_2ecompile_2esimplify_2ebind(v_t_248, heff_clo_n(g_heff_2ecompile_2esimplify_2especLam_lam0, 2, 5, (V[]){v_argv_244, v_r_240, v_g_241, v_xs_242, v_b_243}), v_s_245));
  }
}
V g_heff_2ecompile_2esimplify_2especLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especLam(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2esimplify_2especLam_lam0(V self, V *args) {
  V v_bound_249 = args[0];
  V v_z_2410 = args[1];
  V v_argv_244 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_xs_242 = heff_env(self)[3];
  V v_b_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_bound_249)) {
  case TAG_MkPair: {
    V v_bds_2411 = heff_field(v_bound_249, 0);
    V v_argv_2412 = heff_field(v_bound_249, 1);
    V v_ru_24bound_249_24MkPair = heff_take_reuse_n(v_bound_249, 3ULL, 2);
    V v_t_2413 = (g_list_2ezipWith_24s528321443x971020870(v_argv_244, heff_dup(v_argv_2412)));
    V v_x2_2414 = heff_tr(g_heff_2ecompile_2esimplify_2especKnown(v_r_240, v_g_241, v_xs_242, v_b_243, v_argv_2412, v_t_2413, v_z_2410));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_MkPair: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_s_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      V v_x_2417 = ({ V a_0 = v_bds_2411; V a_1 = v_x_2415; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_bds_2411); r_; });
      return heff_tag_at_n(v_ru_24bound_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2417, v_s_2416});
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  default: return heff_nomatch(v_bound_249);
  }
}
V g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(V v_k_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    V v_e1_247 = heff_field(v_e_242, 0);
    V v_argv_248 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    switch (heff_tag_of(v_e1_247)) {
    case TAG_EVar: {
      V v_k2_249 = heff_field(v_e1_247, 0);
      V v_ru_24e1_247_24EVar = heff_take_reuse_n(v_e1_247, 1ULL, 1);
      if ((heff_strEq_c_lent(v_k_240, v_k2_249, 0) && ({ V v_t_24101 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_248)); int c_ = heff_intEq_c_lent(v_t_24101, v_n_241, 0); heff_drop(v_t_24101); c_; }))) {
        heff_drop(v_n_241);
        heff_drop(v_k2_249);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24e1_247_24EVar, TAG_EValues, 1, (V[]){v_argv_248})}});
      } else {
        heff_drop(v_n_241);
        heff_drop(v_argv_248);
        heff_drop(v_k2_249);
        heff_drop_cell(v_ru_24e1_247_24EVar, 1);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_EGlobal: {
      heff_take_n(v_e1_247, 0ULL, 1);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      heff_take_n(v_e1_247, 0ULL, 2);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_take_n(v_e1_247, 0ULL, 2);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_take_n(v_e1_247, 0ULL, 3);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_take_n(v_e1_247, 0ULL, 2);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_take_n(v_e1_247, 0ULL, 4);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_take_n(v_e1_247, 0ULL, 3);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_247, 0ULL, 2);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      heff_take_n(v_e1_247, 0ULL, 1);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e1_247, 0ULL, 2);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_take_n(v_e1_247, 0ULL, 2);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      heff_take_n(v_e1_247, 0ULL, 1);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_247, 0ULL, 1);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      heff_take_n(v_e1_247, 0ULL, 1);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      heff_take_n(v_e1_247, 0ULL, 1);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_take_n(v_e1_247, 0ULL, 2);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_take_na(v_e1_247, 0ULL, 1);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      heff_take_n(v_e1_247, 0ULL, 1);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      heff_take_n(v_e1_247, 0ULL, 3);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      heff_take_n(v_e1_247, 0ULL, 1);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_take_n(v_e1_247, 0ULL, 2);
      heff_drop(v_n_241);
      heff_drop(v_argv_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_e1_247)}});
    }
  }
  case TAG_ELet: {
    V v_y_2448 = heff_field(v_e_242, 0);
    V v_v_2449 = heff_field(v_e_242, 1);
    V v_b_2450 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2451 = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(v_k_240, v_n_241, v_b_2450));
    {
      V v_field_2453 = v_t_2451.f[1];
      int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
      if ((v_tag_2452 == ((int64_t)0ULL))) {
        V v_x_2454 = v_field_2453;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_y_2448, v_v_2449, v_x_2454})}});
      } else {
        heff_drop(v_y_2448);
        heff_drop(v_v_2449);
        heff_drop_cell(v_ru_24e_242_24ELet, 3);
        heff_drop(v_field_2453);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_take_n(v_e_242, 0ULL, 4);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_e_242, 0ULL, 3);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    V v_s_2464 = heff_field(v_e_242, 0);
    V v_arms_2465 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2471 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr_lam0, 1, 2, (V[]){heff_dup(v_k_240), v_n_241}), heff_dup(v_arms_2465)));
    HeffT2 v_t_2472 = (g_heff_2ecompile_2esimplify_2eallJust_24cpr(v_t_2471));
    {
      V v_field_2474 = v_t_2472.f[1];
      int64_t v_tag_2473 = ((int64_t)v_t_2472.f[0]);
      if ((v_tag_2473 == ((int64_t)0ULL))) {
        V v_x_2475 = v_field_2474;
        V v_t_2476 = (g_list_2ezipWith_24s738847920x410598254(v_arms_2465, v_x_2475));
        V v_f_2477 = heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_2464, v_t_2476});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2477}});
      } else {
        heff_drop(v_s_2464);
        heff_drop(v_arms_2465);
        heff_drop_cell(v_ru_24e_242_24EMatch, 2);
        heff_drop(v_field_2474);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_take_na(v_e_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_EAbandon)}});
  }
  case TAG_EBool: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    V v_ys_2491 = heff_field(v_e_242, 0);
    V v_v_2492 = heff_field(v_e_242, 1);
    V v_b_2493 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ESet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2494 = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(v_k_240, v_n_241, v_b_2493));
    {
      V v_field_2496 = v_t_2494.f[1];
      int64_t v_tag_2495 = ((int64_t)v_t_2494.f[0]);
      if ((v_tag_2495 == ((int64_t)0ULL))) {
        V v_x_2497 = v_field_2496;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24e_242_24ESet, TAG_ESet, 3, (V[]){v_ys_2491, v_v_2492, v_x_2497})}});
      } else {
        heff_drop(v_ys_2491);
        heff_drop(v_v_2492);
        heff_drop_cell(v_ru_24e_242_24ESet, 3);
        heff_drop(v_field_2496);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EValues: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}
V g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr_lam0(V self, V *args) {
  V v_a_2466 = args[0];
  V v_k_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2470;
  switch (heff_tag_of(v_a_2466)) {
  case TAG_MkArm: {
    V v_b_2469 = heff_field(v_a_2466, 2);
    heff_take_n(v_a_2466, 4ULL, 3);
    v_t_2470 = v_b_2469;
    break;
  }
  default: heff_nomatch(v_a_2466);
  }
  return ({ V a_0 = v_k_240; V a_1 = v_n_241; V a_2 = v_t_2470; V r_ = (g_heff_2ecompile_2esimplify_2evaluesCalled(a_0, a_1, a_2)); heff_drop(v_k_240); r_; });
}
V g_heff_2ecompile_2esimplify_2etieOne_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieOne_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieOne_lam2(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etieOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etieOne_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2etieOne(V v_h_240, V v_calls_241, V v_hb_242, V v_d_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2esimplify_2eelemStr(heff_rfield(v_d_243, 0), v_calls_241));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_t_245 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_243, 2))));
    V v_t_246 = (g_heff_2ecompile_2eir_2enubI(v_t_245));
    V v_t_247 = ({ V a_0 = v_h_240; V a_1 = v_t_246; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_246); r_; });
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_m_248 = (g_heff_2ecompile_2esimplify_2etieGo(v_h_240, v_hb_242, heff_dup(heff_rfield(v_d_243, 2))));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieOne_lam0, 1, 2, (V[]){v_m_248, v_d_243});
    } else {
      heff_drop(v_h_240);
      heff_drop(v_hb_242);
      heff_drop(v_t_247);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieOne_lam1, 1, 1, (V[]){v_d_243});
    }
  } else {
    heff_drop(v_h_240);
    heff_drop(v_hb_242);
    heff_drop(v_t_244);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieOne_lam2, 1, 1, (V[]){v_d_243});
  }
}
V g_heff_2ecompile_2esimplify_2etieOne_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2etieOne(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2etieOne_lam0(V self, V *args) {
  V v_s_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_s_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_s_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    HeffT2 v_t_2413 = (g_heff_2ecompile_2esimplify_2erefsRetied_24cpr(heff_dup(heff_rfield(v_d_243, 0)), heff_dup(v_x_2411), v_s_2412));
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_field_2415 = v_t_2413.f[1];
      V v_x_2416 = v_field_2414;
      heff_drop(v_x_2416);
      V v_s_2417 = v_field_2415;
      V v_t_2418 = ({ V rv_2 = v_x_2411; V rr_ = heff_rec_reuse_nf(v_d_243, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2418, v_s_2417});
    }
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2esimplify_2etieOne_lam1(V self, V *args) {
  V v_s_2419 = args[0];
  V v_d_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_243, v_s_2419});
}
V g_heff_2ecompile_2esimplify_2etieOne_lam2(V self, V *args) {
  V v_s_2420 = args[0];
  V v_d_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_243, v_s_2420});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieDeps_lam24(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etieDeps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etieDeps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etieDeps(V v_h_240, V v_hb_241, V v_deps_242) {
top: ;
  switch (heff_tag_of(v_hb_241)) {
  case TAG_EVar: {
    heff_take_n(v_hb_241, 0ULL, 1);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam0, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EGlobal: {
    heff_take_n(v_hb_241, 0ULL, 1);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam1, 1, 1, (V[]){v_deps_242});
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_hb_241, 0);
    V v_b_248 = heff_field(v_hb_241, 1);
    V v_ru_24hb_241_24ELam = heff_take_reuse_n(v_hb_241, 3ULL, 2);
    switch (heff_tag_of(v_deps_242)) {
    case TAG_Nil: {
      heff_drop(v_h_240);
      heff_drop(v_xs_247);
      heff_drop(v_b_248);
      heff_drop_cell(v_ru_24hb_241_24ELam, 2);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam2, 1, 1, (V[]){v_deps_242});
    }
    case TAG_Cons: {
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24hb_241_24ELam, TAG_ELam, 2, (V[]){heff_dup(v_xs_247), heff_dup(v_b_248)}), NTAG(TAG_Nil)});
      V v_x_2413 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(50LL), MK_INT(0LL), v_t_2412));
      if (!heff_intLt_c_lent(MK_INT(50LL), v_x_2413, 1)) {
        heff_drop(v_x_2413);
        V v_t_2414 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_248)));
        V v_t_2415 = (g_heff_2ecompile_2eir_2enubI(v_t_2414));
        V v_x1_2416 = ({ V a_0 = v_h_240; V a_1 = v_t_2415; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2415); r_; });
        if (!(heff_dup(v_x1_2416) == NTAG(TAG_True))) {
          heff_drop(v_x1_2416);
          V v_t_2417 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_248)));
          V v_t_2418 = (g_heff_2ecompile_2eir_2enubI(v_t_2417));
          return ({ V a_0 = v_h_240; V a_1 = v_t_2418; V a_2 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_247, v_b_248}); V a_3 = v_deps_242; V r_ = (g_prelude_2etraverse_24s1258110132x2117245331(a_0, a_1, a_2, a_3)); heff_drop(v_t_2418); r_; });
        } else {
          heff_drop(v_h_240);
          heff_drop(v_xs_247);
          heff_drop(v_b_248);
          heff_drop(v_x1_2416);
          return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam3, 1, 1, (V[]){v_deps_242});
        }
      } else {
        heff_drop(v_h_240);
        heff_drop(v_xs_247);
        heff_drop(v_b_248);
        heff_drop(v_x_2413);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam4, 1, 1, (V[]){v_deps_242});
      }
    }
    default: return heff_nomatch(v_deps_242);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_hb_241, 0ULL, 2);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam5, 1, 1, (V[]){v_deps_242});
  }
  case TAG_ELet: {
    heff_take_n(v_hb_241, 0ULL, 3);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam6, 1, 1, (V[]){v_deps_242});
  }
  case TAG_ERecord: {
    heff_take_n(v_hb_241, 0ULL, 2);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam7, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EProj: {
    heff_take_n(v_hb_241, 0ULL, 4);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam8, 1, 1, (V[]){v_deps_242});
  }
  case TAG_ETag: {
    heff_take_n(v_hb_241, 0ULL, 3);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam9, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EMatch: {
    heff_take_n(v_hb_241, 0ULL, 2);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam10, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EPrim: {
    heff_take_n(v_hb_241, 0ULL, 1);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam11, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_hb_241, 0ULL, 2);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam12, 1, 1, (V[]){v_deps_242});
  }
  case TAG_ECall: {
    heff_take_n(v_hb_241, 0ULL, 2);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam13, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EInt: {
    heff_take_n(v_hb_241, 0ULL, 1);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam14, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EFloat: {
    heff_take_na(v_hb_241, 0ULL, 1);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam15, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EStr: {
    heff_take_n(v_hb_241, 0ULL, 1);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam16, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EBytes: {
    heff_take_n(v_hb_241, 0ULL, 1);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam17, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EFixed: {
    heff_take_n(v_hb_241, 0ULL, 2);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam18, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EFloat32: {
    heff_take_na(v_hb_241, 0ULL, 1);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam19, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EAbandon: {
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam20, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EBool: {
    heff_take_n(v_hb_241, 0ULL, 1);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam21, 1, 1, (V[]){v_deps_242});
  }
  case TAG_ESet: {
    heff_take_n(v_hb_241, 0ULL, 3);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam22, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EValues: {
    heff_take_n(v_hb_241, 0ULL, 1);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam23, 1, 1, (V[]){v_deps_242});
  }
  case TAG_EFix: {
    heff_take_n(v_hb_241, 0ULL, 2);
    heff_drop(v_h_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieDeps_lam24, 1, 1, (V[]){v_deps_242});
  }
  default: return heff_nomatch(v_hb_241);
  }
}
V g_heff_2ecompile_2esimplify_2etieDeps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etieDeps(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_244});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_246});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_249});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam3(V self, V *args) {
  V v_s_2419 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2419});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam4(V self, V *args) {
  V v_s_2420 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2420});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam5(V self, V *args) {
  V v_s_2423 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2423});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam6(V self, V *args) {
  V v_s_2427 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2427});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam7(V self, V *args) {
  V v_s_2430 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2430});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam8(V self, V *args) {
  V v_s_2435 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2435});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam9(V self, V *args) {
  V v_s_2439 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2439});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam10(V self, V *args) {
  V v_s_2442 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2442});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam11(V self, V *args) {
  V v_s_2444 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2444});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam12(V self, V *args) {
  V v_s_2447 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2447});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam13(V self, V *args) {
  V v_s_2450 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2450});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam14(V self, V *args) {
  V v_s_2452 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2452});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam15(V self, V *args) {
  V v_s_2454 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2454});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam16(V self, V *args) {
  V v_s_2456 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2456});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam17(V self, V *args) {
  V v_s_2458 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2458});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam18(V self, V *args) {
  V v_s_2461 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2461});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam19(V self, V *args) {
  V v_s_2463 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2463});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam20(V self, V *args) {
  V v_s_2464 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2464});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam21(V self, V *args) {
  V v_s_2466 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2466});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam22(V self, V *args) {
  V v_s_2470 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2470});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam23(V self, V *args) {
  V v_s_2472 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2472});
}
V g_heff_2ecompile_2esimplify_2etieDeps_lam24(V self, V *args) {
  V v_s_2475 = args[0];
  V v_deps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_deps_242, v_s_2475});
}
Clo g_heff_2ecompile_2esimplify_2esettleDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esettleDef_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2esettleDef(V v_n_240, V v_key_241, V v_b_242, V v_s_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2esettleDef_24cpr(v_n_240, v_key_241, v_b_242, v_s_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_245, v_field_246});
  }
}
V g_heff_2ecompile_2esimplify_2esettleDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esettleDef(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopyWith_str0, 0, "");
Clo g_heff_2ecompile_2esimplify_2ecopyWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopyWith_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2ecopyWith(V v_st_240, V v_bodies_241, V v_h_242, V v_v_243, V v_r_244) {
top: ;
  if (heff_strEq_c_lent(v_v_243, ((V)&g_heff_2ecompile_2esimplify_2ecopyWith_str0), 2)) {
    heff_drop_rec(v_st_240, 9);
    heff_drop(v_h_242);
    heff_drop(v_v_243);
    heff_drop(v_r_244);
    return NTAG(TAG_Nothing);
  } else {
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_st_240, 7)), 3, 7);
    HeffT2 v_t_246 = ({ V a_0 = v_t_245; V a_1 = v_h_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_245); r_; });
    V v_t_2410;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_248;
        v_t_2410 = v_x_249;
      } else {
        heff_drop(v_field_248);
        v_t_2410 = MK_INT(0LL);
      }
    }
    HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(heff_rfield(v_st_240, 4), v_h_242));
    V v_t_2415;
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      v_t_2415 = heff_bool(((v_tag_2412 == ((int64_t)0ULL)) && ({ V v_x_2414 = heff_dup(v_field_2413); int c_ = 1; heff_drop(v_x_2414); c_; })));
      heff_drop(v_field_2413);
    }
    V v_t_2416 = (g_heff_2ecompile_2esimplify_2emadeOf(v_st_240, v_bodies_241, v_h_242));
    return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(6, shape_name__ver__recipe__depth__safe__made, (V[]){v_h_242, v_v_243, v_r_244, v_t_2410, v_t_2415, v_t_2416})});
  }
}
V g_heff_2ecompile_2esimplify_2ecopyWith_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ecopyWith(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecatMaybesS_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ecatMaybesS(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecatMaybesS(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2efoldPrim_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efoldPrim_24tok1_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2efoldPrim_24tok1(V v_tok_240, V v_p_241, V v_argv_242) {
top: ;
  V v_t_249;
  switch (heff_tag_of(v_argv_242)) {
  case TAG_Nil: {
    v_t_249 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_a_243 = heff_dup(heff_field(v_argv_242, 0));
    V v_x22_244 = heff_dup(heff_field(v_argv_242, 1));
    switch (heff_tag_of(v_x22_244)) {
    case TAG_Nil: {
      v_t_249 = (g_heff_2ecompile_2esimplify_2eunOp(v_p_241, v_a_243));
      break;
    }
    case TAG_Cons: {
      V v_b_245 = heff_field(v_x22_244, 0);
      V v_x222_246 = heff_field(v_x22_244, 1);
      heff_take_n(v_x22_244, 3ULL, 2);
      switch (heff_tag_of(v_x222_246)) {
      case TAG_Nil: {
        v_t_249 = (g_heff_2ecompile_2esimplify_2ebinOp(v_p_241, v_a_243, v_b_245));
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_x222_246, 0ULL, 2);
        heff_drop(v_a_243);
        heff_drop(v_b_245);
        v_t_249 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x222_246);
      }
      break;
    }
    default: heff_nomatch(v_x22_244);
    }
    break;
  }
  default: heff_nomatch(v_argv_242);
  }
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_argv_242)) {
    case TAG_Nil: {
      heff_drop_cell(v_tok_240, 1);
      return heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_241, v_argv_242});
    }
    case TAG_Cons: {
      V v_a_2410 = heff_dup(heff_field(v_argv_242, 0));
      V v_it2_2411 = heff_dup(heff_field(v_argv_242, 1));
      switch (heff_tag_of(v_it2_2411)) {
      case TAG_Nil: {
        heff_drop_cell(v_tok_240, 1);
        heff_drop(v_a_2410);
        return heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_241, v_argv_242});
      }
      case TAG_Cons: {
        V v_b_2412 = heff_field(v_it2_2411, 0);
        V v_it22_2413 = heff_field(v_it2_2411, 1);
        V v_ru_24it2_2411_24Cons = heff_take_reuse_n(v_it2_2411, 3ULL, 2);
        switch (heff_tag_of(v_it22_2413)) {
        case TAG_Nil: {
          V v_t_2414 = (g_heff_2ecompile_2eir_2eisRel(v_p_241));
          if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
            heff_drop_tag(v_argv_242, 2);
            heff_drop_cell(v_ru_24it2_2411_24Cons, 2);
            heff_drop(v_t_2414);
            return heff_tag_at_n(v_tok_240, TAG_EBool, 1, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_241, v_a_2410, v_b_2412})});
          } else {
            heff_drop_cell(v_tok_240, 1);
            heff_drop(v_a_2410);
            heff_drop(v_b_2412);
            heff_drop(v_t_2414);
            return heff_tag_at_n(v_ru_24it2_2411_24Cons, TAG_EPrimCall, 2, (V[]){v_p_241, v_argv_242});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it22_2413, 0ULL, 2);
          heff_drop_cell(v_tok_240, 1);
          heff_drop(v_a_2410);
          heff_drop(v_b_2412);
          return heff_tag_at_n(v_ru_24it2_2411_24Cons, TAG_EPrimCall, 2, (V[]){v_p_241, v_argv_242});
        }
        default: return heff_nomatch(v_it22_2413);
        }
      }
      default: return heff_nomatch(v_it2_2411);
      }
    }
    default: return heff_nomatch(v_argv_242);
    }
  }
  case TAG_Just: {
    V v_v_2417 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_p_241);
    heff_drop(v_argv_242);
    return v_v_2417;
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2ecompile_2esimplify_2efoldPrim_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efoldPrim_24tok1(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_24tok2_str0, 2, "$s");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_24tok2_str1, 2, "$s");
Clo g_heff_2ecompile_2esimplify_2especShaped_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especShaped_24tok2_entry, 9, 0};

V g_heff_2ecompile_2esimplify_2especShaped_24tok2(V v_tok_240, V v_r_241, V v_g_242, V v_xs_243, V v_b_244, V v_argv_245, V v_marks_246, V v_sh_247, V v_s_248) {
top: ;
  V v_x1_249 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_246), heff_dup(v_xs_243)));
  V v_t_2415;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nil: {
    V v_t_2410 = heff_dup(heff_rfield(v_sh_247, 1));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nil: {
      v_t_2415 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2410, 0ULL, 2);
      v_t_2415 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_249, 0ULL, 2);
    v_t_2415 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_r_241);
    heff_drop(v_xs_243);
    heff_drop(v_b_244);
    heff_drop(v_marks_246);
    heff_drop_rec(v_sh_247, 3);
    heff_drop(v_t_2415);
    V v_t_2416 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_242}), v_argv_245));
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_t_2416, v_s_248});
  } else {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_t_2415);
    V v_k_2417 = (g_heff_2ecompile_2esimplify_2especKey(heff_dup(v_g_242), heff_dup(v_marks_246), heff_dup(heff_rfield(v_sh_247, 1)), heff_dup(heff_rfield(v_sh_247, 0))));
    V v_j_2418 = heff_strFind_lent(((V)&g_heff_2ecompile_2esimplify_2especShaped_24tok2_str0), v_g_242, MK_INT(0LL), 5);
    V v_t_2419;
    if (heff_intLt_c_lent(v_j_2418, MK_INT(0LL), 2)) {
      heff_drop(v_j_2418);
      v_t_2419 = heff_dup(v_g_242);
    } else {
      v_t_2419 = heff_strSlice_lent(v_g_242, MK_INT(0LL), v_j_2418, 6);
    }
    V v_t_2420 = ({ V a_0 = v_k_2417; V a_1 = MK_INT(0LL); V a_2 = MK_INT(5381LL); V a_3 = MK_INT(7919LL); V r_ = (g_heff_2ecompile_2espec_2ehashGo(a_0, a_1, a_2, a_3)); heff_drop(v_k_2417); r_; });
    V v_t_2421 = heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2especShaped_24tok2_str1), v_t_2420));
    V v_t_2422 = heff_get_n(heff_dup(heff_rfield(v_s_248, 7)), 3, 7);
    V v_t_2423 = (g_heff_2ecompile_2esimplify_2emarkedOf(heff_dup(v_marks_246), heff_dup(heff_rfield(v_sh_247, 0))));
    V v_t_2424 = ({ V a_0 = v_t_2422; V a_1 = heff_dup(v_g_242); V a_2 = v_t_2423; V r_ = (g_heff_2ecompile_2esimplify_2edepthOf(a_0, a_1, a_2)); heff_drop(v_t_2422); r_; });
    return (g_heff_2ecompile_2esimplify_2especNamed(v_r_241, v_g_242, v_xs_243, v_b_244, v_argv_245, v_marks_246, v_sh_247, v_t_2421, v_t_2424, v_s_248));
  }
}
V g_heff_2ecompile_2esimplify_2especShaped_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especShaped_24tok2(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}