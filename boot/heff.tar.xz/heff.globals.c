// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"

static V g_heff_2eglobals_2eemptyGlobals_val;
static int g_heff_2eglobals_2eemptyGlobals_st;
static V g_heff_2eglobals_2eemptyGlobals_init(void) {
  return heff_rec(4, shape_222_85_4_32, (V[]){NTAG(TAG_Nil), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get())});
}
V g_heff_2eglobals_2eemptyGlobals_get(void) {
  if (g_heff_2eglobals_2eemptyGlobals_st == 2) return g_heff_2eglobals_2eemptyGlobals_val;
  if (g_heff_2eglobals_2eemptyGlobals_st == 1) heff_fail("defined by itself");
  g_heff_2eglobals_2eemptyGlobals_st = 1;
  g_heff_2eglobals_2eemptyGlobals_val = heff_tr(g_heff_2eglobals_2eemptyGlobals_init());
  g_heff_2eglobals_2eemptyGlobals_st = 2;
  return g_heff_2eglobals_2eemptyGlobals_val;
}
V g_heff_2eglobals_2eaddEntry_lam0(V self, V *args);
Clo g_heff_2eglobals_2eaddEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eglobals_2eaddEntry_entry, 3, 0};

V g_heff_2eglobals_2eaddEntry(V v_x_240, V v_e_241, V v_g_242) {
top: ;
  V v_x3_243 = ({ V a_0 = heff_dup(v_x_240); V b_1 = heff_get(heff_dup(v_g_242), LBL_entries); V r_ = (g_map_2elookup_24s9(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_247;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    v_t_247 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_240), heff_get(heff_dup(v_g_242), LBL_order)});
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_243, 0ULL, 1);
    v_t_247 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_240), (g_prelude_2efilter(heff_clo(g_heff_2eglobals_2eaddEntry_lam0, 1, 1, (V[]){heff_dup(v_x_240)}), heff_get(heff_dup(v_g_242), LBL_order)))});
    break;
  }
  default: heff_nomatch(v_x3_243);
  }
  V v_t_248 = (g_map_2einsert_24s7(v_x_240, v_e_241, heff_get(heff_dup(v_g_242), LBL_entries)));
  return heff_rec(4, shape_222_85_4_32, (V[]){v_t_247, v_t_248, heff_get(heff_dup(v_g_242), LBL_aliases), heff_get(v_g_242, LBL_broken)});
}
V g_heff_2eglobals_2eaddEntry_entry(V self, V *a) {
  (void)self;
  return g_heff_2eglobals_2eaddEntry(a[0], a[1], a[2]);
}
V g_heff_2eglobals_2eaddEntry_lam0(V self, V *args) {
  V v_y_245 = args[0];
  V v_x_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_strEq(v_y_245, v_x_240);
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_246);
  }
}
Clo g_heff_2eglobals_2elookupKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eglobals_2elookupKey_entry, 2, 0};

V g_heff_2eglobals_2elookupKey(V v_g_240, V v_x_241) {
top: ;
  V v_t_242 = ({ V a_0 = heff_dup(v_x_241); V b_1 = heff_get(heff_dup(v_g_240), LBL_entries); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_t_243 = ({ V a_0 = v_x_241; V b_1 = heff_get(heff_dup(v_g_240), LBL_aliases); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_k_244 = heff_field(v_t_243, 0);
      V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
      V v_t_245 = ({ V a_0 = heff_dup(v_k_244); V b_1 = heff_get(v_g_240, LBL_entries); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_245)) {
      case TAG_Nothing: {
        heff_drop(v_k_244);
        heff_drop_cell(v_ru_24t_243_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_e_246 = heff_field(v_t_245, 0);
        heff_take_n(v_t_245, 1ULL, 1);
        return heff_tag_at(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_k_244, v_e_246})});
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_Just: {
    V v_e_247 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Just = heff_take_reuse_n(v_t_242, 1ULL, 1);
    heff_drop(v_g_240);
    return heff_tag_at(v_ru_24t_242_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_241, v_e_247})});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eglobals_2elookupKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2eglobals_2elookupKey(a[0], a[1]);
}
Clo g_heff_2eglobals_2elookupEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eglobals_2elookupEntry_entry, 2, 0};

V g_heff_2eglobals_2elookupEntry(V v_g_240, V v_x_241) {
top: ;
  V v_t_242 = ({ V a_0 = heff_dup(v_x_241); V b_1 = heff_get(heff_dup(v_g_240), LBL_entries); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  V v_it_248;
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_t_243 = ({ V a_0 = v_x_241; V b_1 = heff_get(heff_dup(v_g_240), LBL_aliases); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop(v_g_240);
      v_it_248 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_k_244 = heff_field(v_t_243, 0);
      V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
      V v_t_245 = ({ V a_0 = heff_dup(v_k_244); V b_1 = heff_get(v_g_240, LBL_entries); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_245)) {
      case TAG_Nothing: {
        heff_drop(v_k_244);
        heff_drop_cell(v_ru_24t_243_24Just, 1);
        v_it_248 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_e_246 = heff_field(v_t_245, 0);
        heff_take_n(v_t_245, 1ULL, 1);
        v_it_248 = heff_tag_at(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_k_244, v_e_246})});
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    break;
  }
  case TAG_Just: {
    V v_e_247 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Just = heff_take_reuse_n(v_t_242, 1ULL, 1);
    heff_drop(v_g_240);
    v_it_248 = heff_tag_at(v_ru_24t_242_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_241, v_e_247})});
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  switch (heff_tag_of(v_it_248)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_it1_249 = heff_field(v_it_248, 0);
    V v_ru_24it_248_24Just = heff_take_reuse_n(v_it_248, 1ULL, 1);
    switch (heff_tag_of(v_it1_249)) {
    case TAG_MkPair: {
      V v_e_2411 = heff_field(v_it1_249, 1);
      heff_take_n(v_it1_249, 2ULL, 2);
      return heff_tag_at(v_ru_24it_248_24Just, TAG_Just, 1, (V[]){v_e_2411});
    }
    default: return heff_nomatch(v_it1_249);
    }
  }
  default: return heff_nomatch(v_it_248);
  }
}
V g_heff_2eglobals_2elookupEntry_entry(V self, V *a) {
  (void)self;
  return g_heff_2eglobals_2elookupEntry(a[0], a[1]);
}