// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_LNil 57394
#define TAG_N 306
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SGlobal 8650
#define TAG_Small 51389
#define TAG_TopL 65516
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_above 293969847
#define LBL_again 294104954
#define LBL_alias 294261354
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_assoc 294479919
#define LBL_broken 566525696
#define LBL_bug 307438
#define LBL_by 9918
#define LBL_byName 571997869
#define LBL_cmt 308164
#define LBL_code 9554612
#define LBL_deps 9575179
#define LBL_effect 641056956
#define LBL_el 9998
#define LBL_entries 787768015
#define LBL_err 310239
#define LBL_expected 956903529
#define LBL_exposes 1070285678
#define LBL_first 298798794
#define LBL_fixities 357800079
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_groups 709681407
#define LBL_hidden 729654485
#define LBL_i 323
#define LBL_id 10114
#define LBL_imports 10411951
#define LBL_instances 1653559473
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_looser 850054335
#define LBL_loosest 581880769
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_order 307364712
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_places 961367927
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_syntax 1059664654
#define LBL_tighter 1059982480
#define LBL_to 10466
#define LBL_tok 324554
#define LBL_top 324559
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_type_5f 312202367
#define LBL_value 313331083
#define LBL_values 1123329101
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_expected__from__to[] = {LBL_expected, LBL_from, LBL_to};
static uint32_t shape_first__again[] = {LBL_first, LBL_again};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_known__fixities__lenient__place__path[] = {LBL_known, LBL_fixities, LBL_lenient, LBL_place, LBL_path};
static uint32_t shape_module__alias[] = {LBL_module, LBL_alias};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_name__value__bug[] = {LBL_name, LBL_value, LBL_bug};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_instances};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
static uint32_t shape_ty__el[] = {LBL_ty, LBL_el};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2edriver_2ealiasOpen(V, V, V, V);
V g_heff_2ebuild_2edriver_2ealiasOpen_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasOpen_clo;
V g_heff_2ebuild_2edriver_2ealiasPairs(V);
V g_heff_2ebuild_2edriver_2ealiasPairs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasPairs_clo;
V g_heff_2ebuild_2edriver_2ealiasPairs_24dps(V, V);
V g_heff_2ebuild_2edriver_2ealiasPairs_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasPairs_24dps_clo;
V g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224(V, V);
V g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224_clo;
V g_heff_2ebuild_2edriver_2eanyD_24s657537213x1004423173(V, V);
V g_heff_2ebuild_2edriver_2eanyD_24s657537213x1004423173_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eanyD_24s657537213x1004423173_clo;
V g_heff_2ebuild_2edriver_2eappendD(V, V);
V g_heff_2ebuild_2edriver_2eappendD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_clo;
V g_heff_2ebuild_2edriver_2eappendD_24tok2(V, V, V);
V g_heff_2ebuild_2edriver_2eappendD_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_24tok2_clo;
V g_heff_2ebuild_2edriver_2eappendLv(V, V);
V g_heff_2ebuild_2edriver_2eappendLv_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendLv_clo;
V g_heff_2ebuild_2edriver_2eappendLv_24dps(V, V, V);
V g_heff_2ebuild_2edriver_2eappendLv_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendLv_24dps_clo;
V g_heff_2ebuild_2edriver_2eappendLv_24tok2(V, V, V);
V g_heff_2ebuild_2edriver_2eappendLv_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendLv_24tok2_clo;
V g_heff_2ebuild_2edriver_2ebenchesOf(V);
V g_heff_2ebuild_2edriver_2ebenchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ebenchesOf_clo;
V g_heff_2ebuild_2edriver_2ebrokenIn(V);
V g_heff_2ebuild_2edriver_2ebrokenIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ebrokenIn_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD_24dps(V, V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_24dps_clo;
V g_heff_2ebuild_2edriver_2eckOf(V);
V g_heff_2ebuild_2edriver_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eckOf_clo;
V g_heff_2ebuild_2edriver_2eclaimNameDiags(V, V);
V g_heff_2ebuild_2edriver_2eclaimNameDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eclaimNameDiags_clo;
V g_heff_2ebuild_2edriver_2ecloseTermF(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTermF_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTermF_clo;
V g_heff_2ebuild_2edriver_2ecloseTypeF(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTypeF_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTypeF_clo;
V g_heff_2ebuild_2edriver_2eclosureGo(V, V, V);
V g_heff_2ebuild_2edriver_2eclosureGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eclosureGo_clo;
V g_heff_2ebuild_2edriver_2edefUnder(V, V, V);
V g_heff_2ebuild_2edriver_2edefUnder_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2edefUnder_clo;
HeffT2 g_heff_2ebuild_2edriver_2edocExpect_24cpr(V);
V g_heff_2ebuild_2edriver_2eearlierGo(V, V, V, V);
V g_heff_2ebuild_2edriver_2eearlierGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eearlierGo_clo;
HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V, V);
V g_heff_2ebuild_2edriver_2eevalPick(V, V, V);
V g_heff_2ebuild_2edriver_2eevalPick_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eevalPick_clo;
V g_heff_2ebuild_2edriver_2eevalPick_24dps(V, V, V, V);
V g_heff_2ebuild_2edriver_2eevalPick_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eevalPick_24dps_clo;
V g_heff_2ebuild_2edriver_2eevaluate(V);
V g_heff_2ebuild_2edriver_2eevaluate_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eevaluate_clo;
V g_heff_2ebuild_2edriver_2eexpectAfter(V, V, V);
V g_heff_2ebuild_2edriver_2eexpectAfter_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexpectAfter_clo;
HeffT2 g_heff_2ebuild_2edriver_2eexpectGo_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2edriver_2eexpectLine_24cpr(V, V, V);
V g_heff_2ebuild_2edriver_2eexposedDiag(V, V, V, V);
V g_heff_2ebuild_2edriver_2eexposedDiag_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexposedDiag_clo;
V g_heff_2ebuild_2edriver_2eexposedDiagsGo(V, V, V, V);
V g_heff_2ebuild_2edriver_2eexposedDiagsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexposedDiagsGo_clo;
V g_heff_2ebuild_2edriver_2eexposedOwn(V);
V g_heff_2ebuild_2edriver_2eexposedOwn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexposedOwn_clo;
HeffT2 g_heff_2ebuild_2edriver_2efindChecked_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edriver_2efindFirst_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edriver_2efindRunnable_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edriver_2efits_24cpr(V, V);
V g_heff_2ebuild_2edriver_2efixOf(V, V);
V g_heff_2ebuild_2edriver_2efixOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixOf_clo;
V g_heff_2ebuild_2edriver_2efixityLine(V, V, V);
V g_heff_2ebuild_2edriver_2efixityLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixityLine_clo;
V g_heff_2ebuild_2edriver_2ehint(V);
V g_heff_2ebuild_2edriver_2ehint_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ehint_clo;
V g_heff_2ebuild_2edriver_2eholdsOf(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eholdsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eholdsOf_clo;
V g_heff_2ebuild_2edriver_2eimportOfGo(V, V, V);
V g_heff_2ebuild_2edriver_2eimportOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eimportOfGo_clo;
V g_heff_2ebuild_2edriver_2eimportedFix(V, V);
V g_heff_2ebuild_2edriver_2eimportedFix_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eimportedFix_clo;
V g_heff_2ebuild_2edriver_2eisBenchOwn(V, V);
V g_heff_2ebuild_2edriver_2eisBenchOwn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eisBenchOwn_clo;
V g_heff_2ebuild_2edriver_2eisDataKey(V, V);
V g_heff_2ebuild_2edriver_2eisDataKey_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eisDataKey_clo;
V g_heff_2ebuild_2edriver_2elabelOfV(V);
V g_heff_2ebuild_2edriver_2elabelOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elabelOfV_clo;
V g_heff_2ebuild_2edriver_2elistOfV(V);
V g_heff_2ebuild_2edriver_2elistOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elistOfV_clo;
V g_heff_2ebuild_2edriver_2elistedName(V);
V g_heff_2ebuild_2edriver_2elistedName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elistedName_clo;
V g_heff_2ebuild_2edriver_2emetIn(V, V, V, V);
V g_heff_2ebuild_2edriver_2emetIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2emetIn_clo;
V g_heff_2ebuild_2edriver_2emoduleStruct(V, V, V);
V g_heff_2ebuild_2edriver_2emoduleStruct_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2emoduleStruct_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2enubStrD_24dps(V, V);
V g_heff_2ebuild_2edriver_2enubStrD_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_24dps_clo;
V g_heff_2ebuild_2edriver_2eownUses(V, V);
V g_heff_2ebuild_2edriver_2eownUses_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eownUses_clo;
V g_heff_2ebuild_2edriver_2epickIntegrations(V, V, V);
V g_heff_2ebuild_2edriver_2epickIntegrations_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2epickIntegrations_clo;
V g_heff_2ebuild_2edriver_2eplaceAt(V, V);
V g_heff_2ebuild_2edriver_2eplaceAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eplaceAt_clo;
V g_heff_2ebuild_2edriver_2ereachOwn(V, V, V);
V g_heff_2ebuild_2edriver_2ereachOwn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ereachOwn_clo;
HeffT2 g_heff_2ebuild_2edriver_2ereadExpRead_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edriver_2ereadExpectation_24cpr(V, V, V, V);
V g_heff_2ebuild_2edriver_2eshowTySx(V, V);
V g_heff_2ebuild_2edriver_2eshowTySx_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eshowTySx_clo;
V g_heff_2ebuild_2edriver_2eshownGlobal(V, V, V);
V g_heff_2ebuild_2edriver_2eshownGlobal_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eshownGlobal_clo;
V g_heff_2ebuild_2edriver_2esigEntry(V, V, V);
V g_heff_2ebuild_2edriver_2esigEntry_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2esigEntry_clo;
V g_heff_2ebuild_2edriver_2esignatureOf(V, V);
V g_heff_2ebuild_2edriver_2esignatureOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2esignatureOf_clo;
V g_heff_2ebuild_2edriver_2eskippedOfV(V);
V g_heff_2ebuild_2edriver_2eskippedOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eskippedOfV_clo;
V g_heff_2ebuild_2edriver_2estructAdd(V, V, V, V);
V g_heff_2ebuild_2edriver_2estructAdd_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2estructAdd_clo;
V g_heff_2ebuild_2edriver_2estructBody(V, V, V);
V g_heff_2ebuild_2edriver_2estructBody_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2estructBody_clo;
V g_heff_2ebuild_2edriver_2estructEntryOf(V, V);
V g_heff_2ebuild_2edriver_2estructEntryOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2estructEntryOf_clo;
V g_heff_2ebuild_2edriver_2estructIdxGo(V, V, V);
V g_heff_2ebuild_2edriver_2estructIdxGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2estructIdxGo_clo;
V g_heff_2ebuild_2edriver_2etwiceDiag(V, V, V, V);
V g_heff_2ebuild_2edriver_2etwiceDiag_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etwiceDiag_clo;
V g_heff_2ebuild_2edriver_2etwicesGo(V, V);
V g_heff_2ebuild_2edriver_2etwicesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etwicesGo_clo;
V g_heff_2ebuild_2edriver_2etwicesGo_24dps(V, V, V);
V g_heff_2ebuild_2edriver_2etwicesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etwicesGo_24dps_clo;
HeffT2 g_heff_2ebuild_2edriver_2ewatchExpect_24cpr(V);
V g_heff_2ebuild_2edriver_2ewithPlace(V, V, V);
V g_heff_2ebuild_2edriver_2ewithPlace_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithPlace_clo;
V g_heff_2ecompile_2einterp_2eevalGlobalsGo(V, V, V, V);
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalGlobalsGo_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2eelab_2eeffect_2eleaves(V);
V g_heff_2eelab_2eeffect_2eleaves_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2eleaves_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eglobals_2eaddAmbiguous(V, V, V);
V g_heff_2eelab_2eglobals_2eaddAmbiguous_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddAmbiguous_clo;
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
HeffT2 g_heff_2eelab_2eglobals_2elookupKey_24cpr(V, V);
V g_heff_2eelab_2eparams_2eeqLevel(V, V);
V g_heff_2eelab_2eparams_2eeqLevel_entry(V self, V *a);
extern Clo g_heff_2eelab_2eparams_2eeqLevel_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2etop_2evalueOf(V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etop_2evalueOf_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
V g_heff_2esyntax_2efixity_2eemptyFixities_get(void);
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
V g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(V, V);
V g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_clo;
V g_heff_2esyntax_2esurface_2ereadLexed(V, V, V);
V g_heff_2esyntax_2esurface_2ereadLexed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadLexed_clo;
V g_heff_2esyntax_2esurfaceprint_2eisData(V, V);
V g_heff_2esyntax_2esurfaceprint_2eisData_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eisData_clo;
V g_heff_2esyntax_2esurfaceprint_2eisData_24tok2(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eisData_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eisData_24tok2_clo;
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s108509638x1972721376(V, V);
V g_list_2eany_24s108509638x1972721376_entry(V self, V *a);
extern Clo g_list_2eany_24s108509638x1972721376_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s279352081x1530195138_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1315672171x449285703(V, V);
V g_list_2efoldl_24s1315672171x449285703_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1315672171x449285703_clo;
V g_list_2efoldl_24s1608132097x1207501887(V, V);
V g_list_2efoldl_24s1608132097x1207501887_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1608132097x1207501887_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1823913665x1128491553(V, V);
V g_list_2ekeepIf_24s1823913665x1128491553_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1823913665x1128491553_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2ekeepIf_24s958254147x1083401940(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2ekeepIf_24s958254147x1083401940_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s958254147x1083401940_clo;
HeffT2 g_list_2elookupBy_24cpr(V, V, V);
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f669780424x1745768631(V, V, V, V, V);
V g_list_2emap_24f669780424x1745768631_entry(V self, V *a);
extern Clo g_list_2emap_24f669780424x1745768631_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s152505078x225062837(V);
V g_list_2emap_24s152505078x225062837_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s265594371x763318798(V);
V g_list_2emap_24s265594371x763318798_entry(V self, V *a);
extern Clo g_list_2emap_24s265594371x763318798_clo;
V g_list_2emap_24s588468714x1874323009(V);
V g_list_2emap_24s588468714x1874323009_entry(V self, V *a);
extern Clo g_list_2emap_24s588468714x1874323009_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
V g_strEq_get(void);
Clo g_heff_2ebuild_2edriver_2enubStrD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2enubStrD_entry, 1, 0};

V g_heff_2ebuild_2edriver_2enubStrD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = ({ V a_0 = v_x_241; V a_1 = v_xs_242; V r_ = (g_list_2ekeepIf_24s930188071x496633547(a_0, a_1)); heff_drop(v_x_241); r_; });
    V v_u_245 = (g_heff_2ebuild_2edriver_2enubStrD_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2enubStrD(a[0]);
}
Clo g_heff_2ebuild_2edriver_2eclosureGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eclosureGo_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eclosureGo(V v_done_240, V v_seen_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_done_240);
    return v_seen_241;
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x3_242, 0);
    V v_ms_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_m_243)}));
    V v_t_246 = (g_list_2eany(v_t_245, v_seen_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_m_243);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_done_240;
      V t_1 = v_seen_241;
      V t_2 = v_ms_244;
      v_done_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_246);
      HeffT2 v_t_247 = (g_heff_2ebuild_2edriver_2efindChecked_24cpr(heff_dup(v_done_240), v_m_243));
      V v_t_2411;
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_c_2410 = v_field_249;
          v_t_2411 = heff_get_n(v_c_2410, 8, 14);
        } else {
          heff_drop(v_field_249);
          v_t_2411 = NTAG(TAG_Nil);
        }
      }
      V v_t_2412 = (g_heff_2ebuild_2edriver_2eappendD(v_ms_244, v_t_2411));
      V t_0 = v_done_240;
      V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_m_243, v_seen_241});
      V t_2 = v_t_2412;
      v_done_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2eclosureGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eclosureGo(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecatMaybesD_entry, 1, 0};

V g_heff_2ebuild_2edriver_2ecatMaybesD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ebuild_2edriver_2ecatMaybesD_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ecatMaybesD(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedOwn_str0, 1, "#");
V g_heff_2ebuild_2edriver_2eexposedOwn_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eexposedOwn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eexposedOwn_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eexposedOwn(V v_c_240) {
top: ;
  V v_own_241 = heff_take_field(v_c_240, 7);
  V v_exposes_242 = heff_get_n(v_c_240, 13, 14);
  V v_own_243 = v_own_241;
  switch (heff_tag_of(v_exposes_242)) {
  case TAG_Nothing: {
    return ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2edriver_2eexposedOwn_str0); V b_2 = MK_INT(0LL); V a_3 = MK_INT(97LL); V b_4 = MK_INT(0LL); V b_5 = MK_INT(0LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(65LL); V b_8 = MK_INT(0LL); V b_9 = MK_INT(0LL); V a_10 = MK_INT(90LL); V a_11 = v_own_243; V r_ = (g_list_2ekeepIf_24s958254147x1083401940(a_0, b_1, b_2, a_3, b_4, b_5, a_6, a_7, b_8, b_9, a_10, a_11)); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_8); heff_drop(b_9); r_; });
  }
  case TAG_Just: {
    V v_es_244 = heff_field(v_exposes_242, 0);
    heff_take_n(v_exposes_242, 1ULL, 1);
    return (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edriver_2eexposedOwn_lam0, 1, 1, (V[]){v_es_244}), v_own_243));
  }
  default: return heff_nomatch(v_exposes_242);
  }
}
V g_heff_2ebuild_2edriver_2eexposedOwn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eexposedOwn(a[0]);
}
V g_heff_2ebuild_2edriver_2eexposedOwn_lam0(V self, V *args) {
  V v_o_245 = args[0];
  V v_es_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_o_245, 0, 2); V a_1 = v_es_244; V r_ = (g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224(b_0, a_1)); heff_drop(b_0); heff_drop(v_es_244); r_; });
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ebrokenIn_str0, 1, ".");
V g_heff_2ebuild_2edriver_2ebrokenIn_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ebrokenIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ebrokenIn_entry, 1, 0};

V g_heff_2ebuild_2edriver_2ebrokenIn(V v_c_240) {
top: ;
  V v_t_241 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_242 = ({ V b_0 = heff_get_n(v_t_241, 3, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_243 = ({ V a_0 = heff_dup(v_c_240); V a_1 = ((V)&g_heff_2ebuild_2edriver_2ebrokenIn_str0); V b_2 = MK_INT(0LL); V a_3 = MK_INT(1LL); V a_4 = v_t_242; V r_ = (g_list_2emap_24f669780424x1745768631(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
  V v_t_244 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_243));
  return (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edriver_2ebrokenIn_lam0, 1, 1, (V[]){v_c_240}), v_t_244));
}
V g_heff_2ebuild_2edriver_2ebrokenIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ebrokenIn(a[0]);
}
V g_heff_2ebuild_2edriver_2ebrokenIn_lam0(V self, V *args) {
  V v_o_245 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_get_n(v_c_240, 13, 14);
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop_rec(v_o_245, 3);
    return NTAG(TAG_True);
  }
  case TAG_Just: {
    V v_es_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    return ({ V b_0 = heff_get_n(v_o_245, 0, 3); V a_1 = v_es_247; V r_ = (g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224(b_0, a_1)); heff_drop(b_0); heff_drop(v_es_247); r_; });
  }
  default: return heff_nomatch(v_t_246);
  }
}
Clo g_heff_2ebuild_2edriver_2ealiasOpen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ealiasOpen_entry, 4, 0};

V g_heff_2ebuild_2edriver_2ealiasOpen(V v_done_240, V v_clashes_241, V v_g_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_done_240);
    return v_g_242;
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ebuild_2edriver_2eanyD_24s657537213x1004423173(heff_dup(v_o_244), v_clashes_241));
    V v_t_2410;
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_o_244, 1)), NTAG(TAG_Nil)});
      V v_t_248 = (g_heff_2eelab_2eglobals_2eaddAmbiguous(heff_dup(heff_rfield(v_o_244, 0)), v_t_247, v_g_242));
      v_t_2410 = (g_heff_2ebuild_2edriver_2ewithPlace(heff_dup(v_done_240), v_o_244, v_t_248));
    } else {
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_t_246);
      if (heff_strEq_c(heff_dup(heff_rfield(v_o_244, 1)), heff_dup(heff_rfield(v_o_244, 0)))) {
        heff_drop_rec(v_o_244, 3);
        v_t_2410 = v_g_242;
      } else {
        V v_t_249 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_g_242, 2), heff_take_field(v_o_244, 0), heff_get_n(v_o_244, 1, 3)));
        v_t_2410 = ({ V rv_2 = v_t_249; V rr_ = heff_rec_reuse_nf(v_g_242, 251ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 65487u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      }
    }
    V t_0 = v_done_240;
    V t_1 = v_clashes_241;
    V t_2 = v_t_2410;
    V t_3 = v_rest_245;
    v_done_240 = t_0;
    v_clashes_241 = t_1;
    v_g_242 = t_2;
    v_x4_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2edriver_2ealiasOpen_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2ealiasOpen(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2edriver_2ealiasPairs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ealiasPairs_entry, 1, 0};

V g_heff_2ebuild_2edriver_2ealiasPairs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_i_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_alias_243 = heff_take_field(v_i_241, 1);
    V v_name_244 = heff_get_n(v_i_241, 0, 3);
    switch (heff_tag_of(v_alias_243)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_name_244);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_a_245 = heff_field(v_alias_243, 0);
      heff_take_n(v_alias_243, 1ULL, 1);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_module__alias, (V[]){v_name_244, v_a_245}), heff_hole()});
      V v_u_247 = (g_heff_2ebuild_2edriver_2ealiasPairs_24dps(v_rest_242, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_alias_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2ealiasPairs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ealiasPairs(a[0]);
}
V g_heff_2ebuild_2edriver_2eckOf_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2eckOf_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eckOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eckOf_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eckOf(V v_idx_240) {
top: ;
  return heff_rec_n(2, shape_ty__el, (V[]){heff_clo_n(g_heff_2ebuild_2edriver_2eckOf_lam0, 3, 1, (V[]){heff_dup(v_idx_240)}), heff_clo_n(g_heff_2ebuild_2edriver_2eckOf_lam1, 3, 1, (V[]){heff_dup(v_idx_240)})});
}
V g_heff_2ebuild_2edriver_2eckOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eckOf(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2eckOf_lam0(V self, V *args) {
  V v_i_241 = args[0];
  V v_depth_242 = args[1];
  V v_t_243 = args[2];
  V v_idx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2ebuild_2edriver_2eckOf(v_idx_240));
  return ({ V a_0 = v_t_244; V a_1 = v_idx_240; V a_2 = v_i_241; V a_3 = v_depth_242; V a_4 = v_t_243; V r_ = (g_heff_2ebuild_2edriver_2ecloseTypeF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_idx_240); r_; });
}
V g_heff_2ebuild_2edriver_2eckOf_lam1(V self, V *args) {
  V v_i_245 = args[0];
  V v_depth_246 = args[1];
  V v_e_247 = args[2];
  V v_idx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2ebuild_2edriver_2eckOf(v_idx_240));
  return ({ V a_0 = v_t_248; V a_1 = v_idx_240; V a_2 = v_i_245; V a_3 = v_depth_246; V a_4 = v_e_247; V r_ = (g_heff_2ebuild_2edriver_2ecloseTermF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_idx_240); r_; });
}
HEFF_LIT(g_heff_2ebuild_2edriver_2estructBody_str0, 1, "#");
HEFF_LIT(g_heff_2ebuild_2edriver_2estructBody_str1, 2, "#T");
Clo g_heff_2ebuild_2edriver_2estructBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2estructBody_entry, 3, 0};

V g_heff_2ebuild_2edriver_2estructBody(V v_mkey_240, V v_es_241, V v_g_27_242) {
top: ;
  V v_k_243 = heff_strAppend(heff_dup(v_mkey_240), ((V)&g_heff_2ebuild_2edriver_2estructBody_str0));
  V v_t_244 = heff_tag_n(TAG_SGlobal, 1, (V[]){heff_strAppend(v_mkey_240, ((V)&g_heff_2ebuild_2edriver_2estructBody_str1))});
  V v_tyStx_245 = heff_tag_n(TAG_SDecode, 1, (V[]){v_t_244});
  V v_pairs_246 = (g_list_2emap_24s265594371x763318798(v_es_241));
  V v_t_247 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_246)));
  V v_t_248 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_246));
  V v_t_249 = (g_list_2emap_24s1173914895x100384474(v_pairs_246));
  V v_t_2410 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_247), v_t_248, heff_arrayFromList(v_t_249)});
  V v_bodyStx_2411 = heff_tag_n(TAG_SCons, 1, (V[]){v_t_2410});
  V v_t_2412 = (g_heff_2eelab_2etop_2evalueOf(heff_dup(v_g_27_242), heff_dup(v_k_243), heff_dup(v_tyStx_245), heff_dup(v_bodyStx_2411)));
  HeffT2 v_t_2413 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(v_g_27_242), NTAG(TAG_N), heff_dup(v_tyStx_245), NTAG(TAG_LNil)));
  V v_t_2419;
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_x_2416 = v_field_2415;
      v_t_2419 = v_x_2416;
    } else {
      if ((v_tag_2414 == ((int64_t)1ULL))) {
        V v_x11_2417 = v_field_2415;
        heff_drop(v_x11_2417);
        v_t_2419 = heff_abandon();
      } else {
        V v_x_2418 = v_field_2415;
        v_t_2419 = v_x_2418;
      }
    }
  }
  HEFF_LAST return g_heff_2eelab_2eglobals_2eaddEntry(v_k_243, heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){v_bodyStx_2411, v_tyStx_245, v_t_2412, v_t_2419}), v_g_27_242);
}
V g_heff_2ebuild_2edriver_2estructBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2estructBody(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edriver_2emoduleStruct_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2emoduleStruct_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2emoduleStruct_entry, 3, 0};

V g_heff_2ebuild_2edriver_2emoduleStruct(V v_mkey_240, V v_own_241, V v_g_242) {
top: ;
  V v_t_244 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2emoduleStruct_lam0, 1, 1, (V[]){heff_dup(v_g_242)}), v_own_241));
  V v_es_245 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_244));
  switch (heff_tag_of(v_es_245)) {
  case TAG_Nil: {
    heff_drop(v_mkey_240);
    return v_g_242;
  }
  case TAG_Cons: {
    V v_t_248 = (g_list_2efoldl_24s1608132097x1207501887(NTAG(TAG_Small), v_es_245));
    V v_t_249 = ({ V a_0 = v_t_248; V b_1 = NTAG(TAG_TopL); V r_ = (g_heff_2eelab_2eparams_2eeqLevel(a_0, b_1)); heff_drop(v_t_248); heff_drop(b_1); r_; });
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_mkey_240);
      heff_drop_tag(v_es_245, 2);
      heff_drop(v_t_249);
      return v_g_242;
    } else {
      heff_drop(v_t_249);
      V v_t_2410 = (g_heff_2ebuild_2edriver_2estructIdxGo(MK_INT(0LL), v_es_245, heff_dup(g_std_2emap_2eempty_get())));
      return ({ V a_0 = v_mkey_240; V a_1 = v_g_242; V a_2 = v_es_245; V a_3 = v_t_2410; V r_ = (g_heff_2ebuild_2edriver_2estructAdd(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); r_; });
    }
  }
  default: return heff_nomatch(v_es_245);
  }
}
V g_heff_2ebuild_2edriver_2emoduleStruct_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2emoduleStruct(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edriver_2emoduleStruct_lam0(V self, V *args) {
  V v_o_243 = args[0];
  V v_g_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2estructEntryOf(v_g_242, v_o_243));
}
V g_heff_2ebuild_2edriver_2eimportedFix_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eimportedFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eimportedFix_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eimportedFix(V v_done_240, V v_imps_241) {
top: ;
  return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2eimportedFix_lam0, 2, 1, (V[]){heff_dup(v_done_240)}); V a_1 = heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get()); V b_2 = heff_get_n(v_imps_241, 0, 4); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2edriver_2eimportedFix_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eimportedFix(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2eimportedFix_lam0(V self, V *args) {
  V v_f_242 = args[0];
  V v_i_243 = args[1];
  V v_done_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_groups_244 = heff_take_field(v_f_242, 0);
  V v_above_245 = heff_get_n(v_f_242, 1, 2);
  V v_b_246 = ({ V a_0 = v_done_240; V b_1 = heff_get_n(v_i_243, 0, 3); V r_ = (g_heff_2ebuild_2edriver_2efixOf(a_0, b_1)); heff_drop(v_done_240); heff_drop(b_1); r_; });
  V v_groups_247 = heff_take_field(v_b_246, 0);
  V v_above_248 = heff_get_n(v_b_246, 1, 2);
  V v_t_249 = (g_heff_2esyntax_2efixity_2eappendF(v_groups_244, v_groups_247));
  V v_t_2410 = (g_heff_2esyntax_2efixity_2enubByG(v_t_249));
  V v_t_2411 = (g_heff_2esyntax_2efixity_2eappendF(v_above_245, v_above_248));
  V v_t_2412 = (g_heff_2esyntax_2efixity_2enubByE(v_t_2411));
  return heff_rec_n(2, shape_groups__above, (V[]){v_t_2410, v_t_2412});
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ehint_str0, 93, "a recursive call is checked against a type: give it one, `(f ... : T)` or `let x : T = f ...`");
HEFF_LIT(g_heff_2ebuild_2edriver_2ehint_str1, 115, "name the type: `type T = ...` at top level, or a type field of the struct it is in (`t = { ... }`, then `m.t` here)");
Clo g_heff_2ebuild_2edriver_2ehint_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ehint_entry, 1, 0};

V g_heff_2ebuild_2edriver_2ehint(V v_d_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_d_240, 4));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nothing: {
    if (heff_intEq_c(heff_dup(heff_rfield(v_d_240, 0)), MK_INT(319LL))) {
      return ({ V rv_4 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2edriver_2ehint_str0)}); V rr_ = heff_rec_reuse_nf(v_d_240, 15ULL, 5, shape_code__severity__msg__span__note, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    } else {
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_240, 0)), MK_INT(204LL))) {
        return ({ V rv_4 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2edriver_2ehint_str1)}); V rr_ = heff_rec_reuse_nf(v_d_240, 15ULL, 5, shape_code__severity__msg__span__note, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
      } else {
        return v_d_240;
      }
    }
  }
  case TAG_Just: {
    heff_take_n(v_t_241, 0ULL, 1);
    return v_d_240;
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ebuild_2edriver_2ehint_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ehint(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2elistedName_str0, 1, "(");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistedName_str1, 1, ")");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistedName_str2, 1, "(");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistedName_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistedName_str4, 1, "(");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistedName_str5, 1, ")");
Clo g_heff_2ebuild_2edriver_2elistedName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2elistedName_entry, 1, 0};

V g_heff_2ebuild_2edriver_2elistedName(V v_x_240) {
top: ;
  if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_240, 0)))) {
    if (((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) ? !(heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)57ULL)) : 1)) {
      V v_t_241 = (g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(v_x_240, MK_INT(0LL)));
      if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
        heff_drop(v_t_241);
        return v_x_240;
      } else {
        heff_drop(v_t_241);
        return heff_strAppend(((V)&g_heff_2ebuild_2edriver_2elistedName_str0), heff_strAppend(v_x_240, ((V)&g_heff_2ebuild_2edriver_2elistedName_str1)));
      }
    } else {
      return heff_strAppend(((V)&g_heff_2ebuild_2edriver_2elistedName_str2), heff_strAppend(v_x_240, ((V)&g_heff_2ebuild_2edriver_2elistedName_str3)));
    }
  } else {
    return heff_strAppend(((V)&g_heff_2ebuild_2edriver_2elistedName_str4), heff_strAppend(v_x_240, ((V)&g_heff_2ebuild_2edriver_2elistedName_str5)));
  }
}
V g_heff_2ebuild_2edriver_2elistedName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2elistedName(a[0]);
}
Clo g_heff_2ebuild_2edriver_2eisDataKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eisDataKey_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eisDataKey(V v_g_240, V v_k_241) {
top: ;
  V v_entries_242 = heff_take_field(v_g_240, 1);
  V v_aliases_243 = heff_get_n(v_g_240, 2, 8);
  HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_entries_242, v_k_241));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      V v_e_247 = v_field_246;
      V v_tySyntax_248 = heff_take_field(v_e_247, 1);
      V v_syntax_249 = heff_get_n(v_e_247, 0, 4);
      return ({ V a_0 = v_tySyntax_248; V a_1 = v_syntax_249; V r_ = (g_heff_2esyntax_2esurfaceprint_2eisData(a_0, a_1)); heff_drop(v_tySyntax_248); r_; });
    } else {
      heff_drop(v_field_246);
      HeffT2 v_t_2410 = ({ V a_0 = v_aliases_243; V a_1 = v_k_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_aliases_243); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_k2_2413 = v_field_2412;
          HeffT2 v_t_2414 = ({ V a_0 = v_entries_242; V a_1 = v_k2_2413; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_entries_242); heff_drop(v_k2_2413); r_; });
          {
            V v_field_2416 = v_t_2414.f[1];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              V v_e_2417 = v_field_2416;
              V v_tySyntax_2418 = heff_take_field(v_e_2417, 1);
              V v_syntax_2419 = heff_get_n(v_e_2417, 0, 4);
              return ({ V a_0 = v_tySyntax_2418; V a_1 = v_syntax_2419; V r_ = (g_heff_2esyntax_2esurfaceprint_2eisData(a_0, a_1)); heff_drop(v_tySyntax_2418); r_; });
            } else {
              heff_drop(v_field_2416);
              return NTAG(TAG_False);
            }
          }
        } else {
          heff_drop(v_entries_242);
          heff_drop(v_field_2412);
          return NTAG(TAG_False);
        }
      }
    }
  }
}
V g_heff_2ebuild_2edriver_2eisDataKey_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2eisDataKey(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2edriver_2eexposedDiagsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eexposedDiagsGo_entry, 4, 0};

V g_heff_2ebuild_2edriver_2eexposedDiagsGo(V v_g_240, V v_own_241, V v_before_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_own_241);
    heff_drop(v_before_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ebuild_2edriver_2eexposedDiag(heff_dup(v_g_240), heff_dup(v_own_241), v_before_242, heff_dup(v_x_244)));
    V v_t_247 = (g_heff_2ebuild_2edriver_2eexposedDiagsGo(v_g_240, v_own_241, heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, v_before_242}), v_rest_245));
    return (g_heff_2ebuild_2edriver_2eappendD(v_t_246, v_t_247));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2edriver_2eexposedDiagsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eexposedDiagsGo(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eclaimNameDiags_str0, 33, "module claim is missing: `module ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eclaimNameDiags_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2edriver_2eclaimNameDiags_str2, 11, "`: `module ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eclaimNameDiags_str3, 1, "`");
HEFF_LIT(g_heff_2ebuild_2edriver_2eclaimNameDiags_str4, 26, "`, but by its path it is `");
HEFF_LIT(g_heff_2ebuild_2edriver_2eclaimNameDiags_str5, 24, "the module claim names `");
Clo g_heff_2ebuild_2edriver_2eclaimNameDiags_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eclaimNameDiags_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eclaimNameDiags(V v_modName_240, V v_h_241) {
top: ;
  V v_name_242 = heff_take_field(v_h_241, 0);
  V v_span_243 = heff_get_n(v_h_241, 3, 5);
  switch (heff_tag_of(v_name_242)) {
  case TAG_Nothing: {
    V v_t_244 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eclaimNameDiags_str0), heff_strAppend(v_modName_240, ((V)&g_heff_2ebuild_2edriver_2eclaimNameDiags_str1)));
    V v_t_245 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(156LL), NTAG(TAG_SError), v_t_244, v_span_243, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  }
  case TAG_Just: {
    V v_n_246 = heff_field(v_name_242, 0);
    heff_take_n(v_name_242, 1ULL, 1);
    if (heff_strEq_c_lent(v_n_246, v_modName_240, 0)) {
      heff_drop(v_modName_240);
      heff_drop(v_span_243);
      heff_drop(v_n_246);
      return NTAG(TAG_Nil);
    } else {
      V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eclaimNameDiags_str2), heff_strAppend(heff_dup(v_modName_240), ((V)&g_heff_2ebuild_2edriver_2eclaimNameDiags_str3)));
      V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eclaimNameDiags_str4), heff_strAppend(v_modName_240, v_t_247));
      V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eclaimNameDiags_str5), heff_strAppend(v_n_246, v_t_248));
      V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(157LL), NTAG(TAG_SError), v_t_249, v_span_243, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    }
  }
  default: return heff_nomatch(v_name_242);
  }
}
V g_heff_2ebuild_2edriver_2eclaimNameDiags_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eclaimNameDiags(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2etwicesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2etwicesGo_entry, 2, 0};

V g_heff_2ebuild_2edriver_2etwicesGo(V v_firsts_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_firsts_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_firsts_240, heff_rfield(v_d_242, 0)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_f_247 = v_field_246;
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_first__again, (V[]){v_f_247, v_d_242}), heff_hole()});
        V v_u_249 = (g_heff_2ebuild_2edriver_2etwicesGo_24dps(v_firsts_240, v_rest_243, heff_dup(v_cell_248)));
        heff_drop(v_u_249);
        return v_cell_248;
      } else {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_field_246);
        V v_t_2410 = (g_std_2emap_2einsert_24s93785294x875597928(v_firsts_240, heff_dup(heff_rfield(v_d_242, 0)), v_d_242));
        V t_0 = v_t_2410;
        V t_1 = v_rest_243;
        v_firsts_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2etwicesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2etwicesGo(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2emetIn_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2emetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2emetIn_entry, 4, 0};

V g_heff_2ebuild_2edriver_2emetIn(V v_done_240, V v_imps_241, V v_c_242, V v_t_243) {
top: ;
  V v_again_244 = heff_take_field(v_t_243, 1);
  V v_first_245 = heff_get_n(v_t_243, 0, 2);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_again_244, 1)), 0, 14);
  if (heff_strEq_c(v_t_246, heff_get_n(v_c_242, 0, 14))) {
    heff_drop(v_done_240);
    heff_drop_rec(v_imps_241, 4);
    heff_drop_rec(v_again_244, 3);
    heff_drop_rec(v_first_245, 3);
    return NTAG(TAG_True);
  } else {
    V v_x1_2417 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2emetIn_lam0, 1, 3, (V[]){v_done_240, v_first_245, v_again_244}); V b_1 = heff_get_n(v_imps_241, 0, 4); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2417) == NTAG(TAG_True)));
    heff_drop(v_x1_2417);
    return v_ret_24bool;
  }
}
V g_heff_2ebuild_2edriver_2emetIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2emetIn(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edriver_2emetIn_lam0(V self, V *args) {
  V v_i_247 = args[0];
  V v_done_240 = heff_env(self)[0];
  V v_first_245 = heff_env(self)[1];
  V v_again_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_i_247, 0)), NTAG(TAG_Nil)});
  V v_xs_249 = (g_heff_2ebuild_2edriver_2eclosureGo(heff_dup(v_done_240), NTAG(TAG_Nil), v_t_248));
  V v_t_2410 = heff_get_n(heff_get_n(v_first_245, 1, 3), 0, 14);
  V v_t_2411 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_t_2410}));
  V v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = v_xs_249; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_249); r_; });
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_t_2412);
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_i_247, 0, 3), NTAG(TAG_Nil)});
    V v_xs_2414 = (g_heff_2ebuild_2edriver_2eclosureGo(v_done_240, NTAG(TAG_Nil), v_t_2413));
    V v_t_2415 = heff_get_n(heff_get_n(v_again_244, 1, 3), 0, 14);
    V v_t_2416 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_t_2415}));
    return ({ V a_0 = v_t_2416; V a_1 = v_xs_2414; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_2414); r_; });
  } else {
    heff_drop_rec(v_i_247, 3);
    heff_drop(v_done_240);
    heff_drop_rec(v_again_244, 3);
    heff_drop(v_t_2412);
    return NTAG(TAG_False);
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2etwiceDiag_str0, 6, ", and ");
HEFF_LIT(g_heff_2ebuild_2edriver_2etwiceDiag_str1, 14, "` is declared ");
HEFF_LIT(g_heff_2ebuild_2edriver_2etwiceDiag_str2, 15, "the primitive `");
Clo g_heff_2ebuild_2edriver_2etwiceDiag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2etwiceDiag_entry, 4, 0};

V g_heff_2ebuild_2edriver_2etwiceDiag(V v_done_240, V v_imps_241, V v_c_242, V v_t_243) {
top: ;
  V v_again_244 = heff_take_field(v_t_243, 1);
  V v_first_245 = heff_get_n(v_t_243, 0, 2);
  V v_t_246 = (g_heff_2ebuild_2edriver_2eplaceAt(heff_take_field(v_first_245, 1), heff_get_n(v_first_245, 2, 3)));
  V v_t_247 = (g_heff_2ebuild_2edriver_2eplaceAt(heff_dup(heff_rfield(v_again_244, 1)), heff_dup(heff_rfield(v_again_244, 2))));
  V v_t_248 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ebuild_2edriver_2etwiceDiag_str0), v_t_247));
  V v_t_249 = heff_strAppend(heff_take_field(v_again_244, 0), heff_strAppend(((V)&g_heff_2ebuild_2edriver_2etwiceDiag_str1), v_t_248));
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_again_244, 1)), 0, 14);
  V v_t_2412;
  if (heff_strEq_c(v_t_2410, heff_get_n(v_c_242, 0, 14))) {
    heff_drop(v_done_240);
    heff_drop_rec(v_imps_241, 4);
    v_t_2412 = heff_get_n(v_again_244, 2, 3);
  } else {
    V v_t_2411 = heff_get_n(heff_get_n(v_again_244, 1, 3), 0, 14);
    v_t_2412 = (g_heff_2ebuild_2edriver_2eimportOfGo(v_done_240, v_t_2411, heff_get_n(v_imps_241, 0, 4)));
  }
  return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(336LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2ebuild_2edriver_2etwiceDiag_str2), v_t_249), v_t_2412, NTAG(TAG_Nothing)});
}
V g_heff_2ebuild_2edriver_2etwiceDiag_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2etwiceDiag(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edriver_2eshowTySx_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eshowTySx_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eshowTySx_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eshowTySx(V v_g_240, V v_t_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_get_n(v_g_240, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_m_243 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_242; V r_ = (g_list_2efoldl_24s1315672171x449285703(a_0, a_1)); heff_drop(v_t_242); r_; });
  V v_t_2410 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2ebuild_2edriver_2eshowTySx_lam0, 1, 1, (V[]){v_m_243})));
  V v_t_2411 = heff_tr(heff_call(heff_get_n(v_t_2410, 1, 2), 1, (V[]){v_t_241}));
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2411; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(a_0, a_1, a_2, a_3)); heff_drop(v_t_2411); r_; });
}
V g_heff_2ebuild_2edriver_2eshowTySx_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eshowTySx(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2eshowTySx_lam0(V self, V *args) {
  V v_k_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_245 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_k_244)));
  HeffT2 v_t_246 = ({ V a_0 = v_m_243; V a_1 = v_k_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_m_243); heff_drop(v_k_244); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_d_245);
      V v_x_249 = v_field_248;
      return v_x_249;
    } else {
      heff_drop(v_field_248);
      return v_d_245;
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ewatchExpect_24cpr_str0, 2, "--");
HEFF_LIT(g_heff_2ebuild_2edriver_2ewatchExpect_24cpr_str1, 6, "-- >>>");
HEFF_LIT(g_heff_2ebuild_2edriver_2ewatchExpect_24cpr_str2, 4, "-- |");
HEFF_LIT(g_heff_2ebuild_2edriver_2ewatchExpect_24cpr_str3, 0, "");

HeffT2 g_heff_2ebuild_2edriver_2ewatchExpect_24cpr(V v_line_240) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_line_240, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2ebuild_2edriver_2ewatchExpect_24cpr_str0))) {
    if (!heff_strEq_c(heff_strSlice_lent(v_line_240, MK_INT(0LL), MK_INT(6LL), 6), ((V)&g_heff_2ebuild_2edriver_2ewatchExpect_24cpr_str1))) {
      if (!heff_strEq_c(heff_strSlice_lent(v_line_240, MK_INT(0LL), MK_INT(4LL), 6), ((V)&g_heff_2ebuild_2edriver_2ewatchExpect_24cpr_str2))) {
        V v_s_241 = heff_strSlice(heff_dup(v_line_240), MK_INT(2LL), heff_strLength_lent(v_line_240, 0));
        V v_t_242 = (g_prelude_2eskipSpaces(v_s_241, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_s_241, 0)) - ((int64_t)1ULL));
        V v_t_244 = (g_prelude_2eskipSpaces(v_s_241, heff_box_word(v_t_243), MK_INT(-1LL)));
        V v_t_245 = heff_strSlice(v_s_241, v_t_242, heff_intAdd(v_t_244, MK_INT(1LL)));
        V v_x1_246 = heff_bool(heff_strEq_c_lent(v_t_245, ((V)&g_heff_2ebuild_2edriver_2ewatchExpect_24cpr_str3), 2));
        heff_drop(v_t_245);
        if (!(heff_dup(v_x1_246) == NTAG(TAG_True))) {
          heff_drop(v_x1_246);
          V v_s_247 = heff_strSlice(heff_dup(v_line_240), MK_INT(2LL), heff_strLength_lent(v_line_240, 0));
          V v_t_248 = (g_prelude_2eskipSpaces(v_s_247, MK_INT(0LL), MK_INT(1LL)));
          int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_s_247, 0)) - ((int64_t)1ULL));
          V v_t_2410 = (g_prelude_2eskipSpaces(v_s_247, heff_box_word(v_t_249), MK_INT(-1LL)));
          V v_f_2411 = heff_strSlice(v_s_247, v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2411}});
        } else {
          heff_drop(v_x1_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    } else {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  } else {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectLine_24cpr_str0, 1, "\012");

HeffT2 g_heff_2ebuild_2edriver_2eexpectLine_24cpr(V v_doc_240, V v_src_241, V v_i_242) {
top: ;
  V v_j_243 = heff_strFind_lent(((V)&g_heff_2ebuild_2edriver_2eexpectLine_24cpr_str0), v_src_241, v_i_242, 1);
  V v_t_244;
  if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
    heff_drop(v_j_243);
    v_t_244 = heff_strLength_lent(v_src_241, 0);
  } else {
    v_t_244 = v_j_243;
  }
  V v_s_245 = heff_strSlice_lent(v_src_241, v_i_242, v_t_244, 4);
  V v_t_246 = (g_prelude_2eskipSpaces(v_s_245, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_s_245, 0)) - ((int64_t)1ULL));
  V v_t_248 = (g_prelude_2eskipSpaces(v_s_245, heff_box_word(v_t_247), MK_INT(-1LL)));
  V v_line_249 = heff_strSlice(v_s_245, v_t_246, heff_intAdd(v_t_248, MK_INT(1LL)));
  if ((heff_unbox_word(heff_strLength_lent(v_src_241, 0)) <= heff_unbox_word(v_i_242))) {
    heff_drop(v_line_249);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    if ((heff_dup(v_doc_240) == NTAG(TAG_True))) {
      return ({ V a_0 = v_line_249; HeffT2 r_ = (g_heff_2ebuild_2edriver_2edocExpect_24cpr(a_0)); heff_drop(v_line_249); r_; });
    } else {
      return ({ V a_0 = v_line_249; HeffT2 r_ = (g_heff_2ebuild_2edriver_2ewatchExpect_24cpr(a_0)); heff_drop(v_line_249); r_; });
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectGo_24cpr_str0, 1, "\012");

HeffT2 g_heff_2ebuild_2edriver_2eexpectGo_24cpr(V v_doc_240, V v_src_241, V v_i_242, V v_acc_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ebuild_2edriver_2eexpectLine_24cpr(v_doc_240, v_src_241, heff_dup(v_i_242)));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_l_247 = v_field_246;
      V v_x_248 = heff_strLength_lent(v_src_241, 0);
      V v_j_249 = heff_strFind_lent(((V)&g_heff_2ebuild_2edriver_2eexpectGo_24cpr_str0), v_src_241, v_i_242, 5);
      V v_t_2410;
      if (heff_intLt_c_lent(v_j_249, MK_INT(0LL), 2)) {
        heff_drop(v_j_249);
        v_t_2410 = heff_strLength_lent(v_src_241, 0);
      } else {
        v_t_2410 = v_j_249;
      }
      V v_y_2411 = heff_intAdd(v_t_2410, MK_INT(1LL));
      V v_t_2412;
      if (heff_intLe_c_lent(v_x_248, v_y_2411, 0)) {
        heff_drop(v_y_2411);
        v_t_2412 = v_x_248;
      } else {
        heff_drop(v_x_248);
        v_t_2412 = v_y_2411;
      }
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_l_247, NTAG(TAG_Nil)});
      V v_t_2414 = (g_prelude_2e_2b_2b(v_acc_243, v_t_2413));
      V t_0 = v_doc_240;
      V t_1 = v_src_241;
      V t_2 = v_t_2412;
      V t_3 = v_t_2414;
      v_doc_240 = t_0;
      v_src_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      heff_drop(v_field_246);
      return ((HeffT2){{v_acc_243, v_i_242}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectAfter_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectAfter_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectAfter_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectAfter_str3, 1, "\012");
Clo g_heff_2ebuild_2edriver_2eexpectAfter_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eexpectAfter_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eexpectAfter(V v_doc_240, V v_src_241, V v_end_242) {
top: ;
  V v_x_243 = heff_strLength_lent(v_src_241, 0);
  V v_j_244 = heff_strFind_lent(((V)&g_heff_2ebuild_2edriver_2eexpectAfter_str0), v_src_241, v_end_242, 1);
  V v_t_245;
  if (heff_intLt_c_lent(v_j_244, MK_INT(0LL), 2)) {
    heff_drop(v_j_244);
    v_t_245 = heff_strLength_lent(v_src_241, 0);
  } else {
    v_t_245 = v_j_244;
  }
  V v_y_246 = heff_intAdd(v_t_245, MK_INT(1LL));
  V v_x_247 = heff_strLength_lent(v_src_241, 0);
  V v_j_248 = heff_strFind_lent(((V)&g_heff_2ebuild_2edriver_2eexpectAfter_str1), v_src_241, v_end_242, 1);
  V v_t_249;
  if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
    heff_drop(v_j_248);
    v_t_249 = heff_strLength_lent(v_src_241, 0);
  } else {
    v_t_249 = v_j_248;
  }
  V v_y_2410 = heff_intAdd(v_t_249, MK_INT(1LL));
  V v_t_2411;
  if (heff_intLe_c_lent(v_x_247, v_y_2410, 0)) {
    heff_drop(v_y_2410);
    v_t_2411 = v_x_247;
  } else {
    heff_drop(v_x_247);
    v_t_2411 = v_y_2410;
  }
  HeffT2 v_t_2412 = (g_heff_2ebuild_2edriver_2eexpectGo_24cpr(v_doc_240, v_src_241, v_t_2411, NTAG(TAG_Nil)));
  {
    V v_field_2413 = v_t_2412.f[0];
    V v_field_2414 = v_t_2412.f[1];
    V v_t_2420;
    switch (heff_tag_of(v_field_2413)) {
    case TAG_Nil: {
      v_t_2420 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_t_2419;
      switch (heff_tag_of(v_field_2413)) {
      case TAG_Nil: {
        v_t_2419 = ((V)&g_heff_2ebuild_2edriver_2eexpectAfter_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2417 = heff_field(v_field_2413, 0);
        V v_xs_2418 = heff_field(v_field_2413, 1);
        heff_take_n(v_field_2413, 3ULL, 2);
        v_t_2419 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2eexpectAfter_str3); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
        break;
      }
      default: heff_nomatch(v_field_2413);
      }
      v_t_2420 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_field_2413);
    }
    V v_t_2421;
    if (heff_intLe_c_lent(v_x_243, v_y_246, 0)) {
      heff_drop(v_y_246);
      v_t_2421 = v_x_243;
    } else {
      heff_drop(v_x_243);
      v_t_2421 = v_y_246;
    }
    return heff_rec_n(3, shape_expected__from__to, (V[]){v_t_2420, v_t_2421, v_field_2414});
  }
}
V g_heff_2ebuild_2edriver_2eexpectAfter_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2eexpectAfter(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str3, 3, "\012  ");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str4, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str5, 2, ")\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str6, 8, "-- >>> (");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str8, 0, "");
V g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2edriver_2ereadExpectation_24cpr(V v_ge_240, V v_g_241, V v_ty_242, V v_e_243) {
top: ;
  V v_x2_244 = ({ V b_0 = ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str0); V a_1 = v_e_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str1), v_e_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str3); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str4), heff_strAppend(v_ty_242, ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str5)));
  V v_src_249 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str6), heff_strAppend(v_t_247, v_t_248));
  V v_t_2417 = heff_rec_n(5, shape_known__fixities__lenient__place__path, (V[]){heff_clo_n(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_lam0, 1, 1, (V[]){heff_dup(v_g_241)}), heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get()), NTAG(TAG_False), ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str7), ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str8)});
  V v_t_2418 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_2419 = (g_heff_2esyntax_2efmt_2elex_2elexGo(v_src_249, v_t_2418, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_2420 = ({ V a_0 = v_src_249; V a_1 = v_t_2417; V a_2 = v_t_2419; V r_ = (g_heff_2esyntax_2esurface_2ereadLexed(a_0, a_1, a_2)); heff_drop(v_src_249); r_; });
  return (g_heff_2ebuild_2edriver_2ereadExpRead_24cpr(v_ge_240, v_g_241, v_t_2420));
}
V g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2411 = (g_heff_2eelab_2eglobals_2elookupKey_24cpr(v_g_241, v_x_2410));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_it1_2414 = v_field_2413;
      switch (heff_tag_of(v_it1_2414)) {
      case TAG_MkPair: {
        heff_take_n(v_it1_2414, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_it1_2414);
      }
    } else {
      heff_drop(v_field_2413);
      return NTAG(TAG_False);
    }
  }
}
Clo g_heff_2ebuild_2edriver_2eholdsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eholdsOf_entry, 6, 0};

V g_heff_2ebuild_2edriver_2eholdsOf(V v_ge_240, V v_g_241, V v_ty_242, V v_r_243, V v_value_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_r_243)) {
  case TAG_RSucceeded: {
    switch (heff_tag_of(v_x6_245)) {
    case TAG_Nothing: {
      heff_drop(v_ge_240);
      heff_drop(v_g_241);
      heff_drop(v_ty_242);
      return NTAG(TAG_True);
    }
    case TAG_Just: {
      V v_e_247 = heff_field(v_x6_245, 0);
      if (heff_strEq_c_lent(v_e_247, v_value_244, 0)) {
        heff_drop(v_ge_240);
        heff_drop(v_g_241);
        heff_drop(v_ty_242);
        return NTAG(TAG_True);
      } else {
        HeffT2 v_t_248 = (g_heff_2ebuild_2edriver_2ereadExpectation_24cpr(v_ge_240, v_g_241, v_ty_242, v_e_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_v_2411 = v_field_2410;
            V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_v_2411, v_value_244, 0));
            heff_drop(v_v_2411);
            return v_ret_24bool;
          } else {
            heff_drop(v_field_2410);
            return NTAG(TAG_False);
          }
        }
      }
    }
    default: return heff_nomatch(v_x6_245);
    }
  }
  case TAG_RAbandoned: {
    switch (heff_tag_of(v_x6_245)) {
    case TAG_Nothing: {
      heff_drop(v_ge_240);
      heff_drop(v_g_241);
      heff_drop(v_ty_242);
      return NTAG(TAG_True);
    }
    case TAG_Just: {
      V v_e_2412 = heff_field(v_x6_245, 0);
      if (heff_strEq_c_lent(v_e_2412, v_value_244, 0)) {
        heff_drop(v_ge_240);
        heff_drop(v_g_241);
        heff_drop(v_ty_242);
        return NTAG(TAG_True);
      } else {
        HeffT2 v_t_2413 = (g_heff_2ebuild_2edriver_2ereadExpectation_24cpr(v_ge_240, v_g_241, v_ty_242, v_e_2412));
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_v_2416 = v_field_2415;
            V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_v_2416, v_value_244, 0));
            heff_drop(v_v_2416);
            return v_ret_24bool;
          } else {
            heff_drop(v_field_2415);
            return NTAG(TAG_False);
          }
        }
      }
    }
    default: return heff_nomatch(v_x6_245);
    }
  }
  case TAG_RDiverged: {
    switch (heff_tag_of(v_x6_245)) {
    case TAG_Nothing: {
      heff_drop(v_ge_240);
      heff_drop(v_g_241);
      heff_drop(v_ty_242);
      return NTAG(TAG_True);
    }
    case TAG_Just: {
      V v_e_2417 = heff_field(v_x6_245, 0);
      if (heff_strEq_c_lent(v_e_2417, v_value_244, 0)) {
        heff_drop(v_ge_240);
        heff_drop(v_g_241);
        heff_drop(v_ty_242);
        return NTAG(TAG_True);
      } else {
        HeffT2 v_t_2418 = (g_heff_2ebuild_2edriver_2ereadExpectation_24cpr(v_ge_240, v_g_241, v_ty_242, v_e_2417));
        {
          V v_field_2420 = v_t_2418.f[1];
          int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
          if ((v_tag_2419 == ((int64_t)0ULL))) {
            V v_v_2421 = v_field_2420;
            V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_v_2421, v_value_244, 0));
            heff_drop(v_v_2421);
            return v_ret_24bool;
          } else {
            heff_drop(v_field_2420);
            return NTAG(TAG_False);
          }
        }
      }
    }
    default: return heff_nomatch(v_x6_245);
    }
  }
  case TAG_RBug: {
    heff_drop(v_ge_240);
    heff_drop(v_g_241);
    heff_drop(v_ty_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_r_243);
  }
}
V g_heff_2ebuild_2edriver_2eholdsOf_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V r = g_heff_2ebuild_2edriver_2eholdsOf(a[0], a[1], a[2], a3, a4, a5); heff_drop(a3); heff_drop(a4); heff_drop(a5); return r;
}
Clo g_heff_2ebuild_2edriver_2edefUnder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2edefUnder_entry, 3, 0};

V g_heff_2ebuild_2edriver_2edefUnder(V v_to_240, V v_x2_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_t_245;
    switch (heff_tag_of(v_b_242)) {
    case TAG_MkPair: {
      V v_y_244 = heff_dup(heff_field(v_b_242, 1));
      v_t_245 = v_y_244;
      break;
    }
    default: heff_nomatch(v_b_242);
    }
    if (heff_intLe_c(v_to_240, heff_get_n(v_t_245, 0, 2))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_b_242});
    } else {
      heff_drop(v_b_242);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_Just: {
    V v_a_246 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_249;
    switch (heff_tag_of(v_b_242)) {
    case TAG_MkPair: {
      V v_y_248 = heff_dup(heff_field(v_b_242, 1));
      v_t_249 = v_y_248;
      break;
    }
    default: heff_nomatch(v_b_242);
    }
    V v_t_2418;
    if (heff_intLe_c(v_to_240, heff_get_n(v_t_249, 0, 2))) {
      V v_t_2412;
      switch (heff_tag_of(v_b_242)) {
      case TAG_MkPair: {
        V v_y_2411 = heff_dup(heff_field(v_b_242, 1));
        v_t_2412 = v_y_2411;
        break;
      }
      default: heff_nomatch(v_b_242);
      }
      V v_t_2423 = heff_get_n(v_t_2412, 0, 2);
      V v_t_2415;
      switch (heff_tag_of(v_a_246)) {
      case TAG_MkPair: {
        V v_y_2414 = heff_dup(heff_field(v_a_246, 1));
        v_t_2415 = v_y_2414;
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      V v_t_2424 = heff_get_n(v_t_2415, 0, 2);
      v_t_2418 = heff_intLt(v_t_2423, v_t_2424);
    } else {
      v_t_2418 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_2418)) {
    case TAG_True: {
      heff_drop(v_a_246);
      return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_b_242});
    }
    case TAG_False: {
      heff_drop(v_b_242);
      return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_a_246});
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2edefUnder_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2edefUnder(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalPick_str0, 11, "<abandoned>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalPick_str1, 10, "<diverged>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalPick_str2, 15, "<compiler bug: ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalPick_str3, 1, ">");
Clo g_heff_2ebuild_2edriver_2eevalPick_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eevalPick_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eevalPick(V v_g_240, V v_results_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_results_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_key_245 = heff_take_field(v_o_243, 1);
    V v_name_246 = heff_get_n(v_o_243, 0, 2);
    HeffT2 v_t_247 = (g_list_2elookupBy_24cpr(heff_dup(g_strEq_get()), heff_dup(v_key_245), heff_dup(v_results_241)));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_r_2410 = v_field_249;
        V v_it_2411 = ({ V a_0 = heff_dup(v_g_240); V a_1 = v_key_245; V a_2 = v_r_2410; V r_ = (g_heff_2ebuild_2edriver_2eshownGlobal(a_0, a_1, a_2)); heff_drop(v_key_245); r_; });
        V v_t_2412 = (g_heff_2esyntax_2esurfaceprint_2enamed(v_name_246));
        V v_t_2415;
        switch (heff_tag_of(v_it_2411)) {
        case TAG_RSucceeded: {
          V v_v_2413 = heff_dup(heff_field(v_it_2411, 0));
          v_t_2415 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_v_2413; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
          break;
        }
        case TAG_RAbandoned: {
          v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eevalPick_str0);
          break;
        }
        case TAG_RDiverged: {
          v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eevalPick_str1);
          break;
        }
        case TAG_RBug: {
          V v_what_2414 = heff_dup(heff_field(v_it_2411, 0));
          v_t_2415 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eevalPick_str2), heff_strAppend(v_what_2414, ((V)&g_heff_2ebuild_2edriver_2eevalPick_str3)));
          break;
        }
        default: heff_nomatch(v_it_2411);
        }
        V v_t_2418;
        switch (heff_tag_of(v_it_2411)) {
        case TAG_RSucceeded: {
          heff_take_n(v_it_2411, 0ULL, 1);
          v_t_2418 = NTAG(TAG_False);
          break;
        }
        case TAG_RAbandoned: {
          v_t_2418 = NTAG(TAG_False);
          break;
        }
        case TAG_RDiverged: {
          v_t_2418 = NTAG(TAG_False);
          break;
        }
        case TAG_RBug: {
          heff_take_n(v_it_2411, 0ULL, 1);
          v_t_2418 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_it_2411);
        }
        V v_cell_2419 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__value__bug, (V[]){v_t_2412, v_t_2415, v_t_2418}), heff_hole()});
        V v_u_2420 = (g_heff_2ebuild_2edriver_2eevalPick_24dps(v_g_240, v_results_241, v_rest_244, heff_dup(v_cell_2419)));
        heff_drop(v_u_2420);
        return v_cell_2419;
      } else {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_key_245);
        heff_drop(v_name_246);
        heff_drop(v_field_249);
        V t_0 = v_g_240;
        V t_1 = v_results_241;
        V t_2 = v_rest_244;
        v_g_240 = t_0;
        v_results_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2eevalPick_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eevalPick(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eevaluate_str0, 1, "#");
V g_heff_2ebuild_2edriver_2eevaluate_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2eevaluate_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eevaluate_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eevaluate_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eevaluate(V v_c_240) {
top: ;
  V v_top_241 = heff_take_field(v_c_240, 5);
  V v_own_242 = heff_get_n(v_c_240, 7, 14);
  V v_gs_243 = heff_dup(heff_rfield(v_top_241, 0));
  V v_entries_244 = heff_take_field(v_gs_243, 1);
  V v_order_245 = heff_get_n(v_gs_243, 0, 8);
  V v_t_2412 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2eevaluate_lam0, 2, 1, (V[]){v_entries_244}); V a_1 = NTAG(TAG_Nil); V a_2 = v_order_245; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_order_245); r_; });
  V v_t_2416 = (g_heff_2ecompile_2einterp_2eevalGlobalsGo(heff_clo_n(g_heff_2ebuild_2edriver_2eevaluate_lam1, 1, 1, (V[]){heff_dup(v_own_242)}), heff_dup(g_std_2emap_2eempty_get()), v_t_2412, NTAG(TAG_Nil)));
  V v_t_2417 = ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2edriver_2eevaluate_str0); V b_2 = MK_INT(0LL); V a_3 = MK_INT(97LL); V b_4 = MK_INT(0LL); V b_5 = MK_INT(0LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(65LL); V b_8 = MK_INT(0LL); V b_9 = MK_INT(0LL); V a_10 = MK_INT(90LL); V a_11 = v_own_242; V r_ = (g_list_2ekeepIf_24s958254147x1083401940(a_0, b_1, b_2, a_3, b_4, b_5, a_6, a_7, b_8, b_9, a_10, a_11)); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_8); heff_drop(b_9); r_; });
  return (g_heff_2ebuild_2edriver_2eevalPick(heff_get_n(v_top_241, 0, 9), v_t_2416, v_t_2417));
}
V g_heff_2ebuild_2edriver_2eevaluate_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eevaluate(a[0]);
}
V g_heff_2ebuild_2edriver_2eevaluate_lam0(V self, V *args) {
  V v_acc_246 = args[0];
  V v_k_247 = args[1];
  V v_entries_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_248 = ({ V a_0 = v_entries_244; V a_1 = v_k_247; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_entries_244); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_e_2411 = v_field_2410;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_247, v_e_2411}), v_acc_246});
    } else {
      heff_drop(v_k_247);
      heff_drop(v_field_2410);
      return v_acc_246;
    }
  }
}
V g_heff_2ebuild_2edriver_2eevaluate_lam1(V self, V *args) {
  V v_k_2413 = args[0];
  V v_own_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_2414 = (g_list_2emap_24s152505078x225062837(v_own_242));
  V v_t_2415 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_k_2413}));
  return ({ V a_0 = v_t_2415; V a_1 = v_xs_2414; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_2414); r_; });
}
V g_heff_2ebuild_2edriver_2ebenchesOf_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2ebenchesOf_lam2(V self, V *args);
V g_heff_2ebuild_2edriver_2ebenchesOf_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ebenchesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ebenchesOf_entry, 1, 0};

V g_heff_2ebuild_2edriver_2ebenchesOf(V v_c_240) {
top: ;
  V v_all_242 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edriver_2ebenchesOf_lam0, 1, 1, (V[]){heff_dup(v_c_240)}), heff_dup(heff_rfield(v_c_240, 7))));
  return (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edriver_2ebenchesOf_lam1, 1, 2, (V[]){v_c_240, heff_dup(v_all_242)}), v_all_242));
}
V g_heff_2ebuild_2edriver_2ebenchesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ebenchesOf(a[0]);
}
V g_heff_2ebuild_2edriver_2ebenchesOf_lam0(V self, V *args) {
  V v_o_241 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2eisBenchOwn(v_c_240, v_o_241));
}
V g_heff_2ebuild_2edriver_2ebenchesOf_lam2(V self, V *args) {
  V v_t_244 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_o_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = (g_heff_2ebuild_2edriver_2eownUses(heff_dup(v_c_240), heff_rfield(v_t_244, 1)));
  V v_t_246 = (g_heff_2ebuild_2edriver_2ereachOwn(v_c_240, NTAG(TAG_Nil), v_t_245));
  V v_t_247 = (g_list_2ekeepIf_24s1823913665x1128491553(v_t_244, v_t_246));
  return ({ V a_0 = v_o_243; V a_1 = v_t_247; V r_ = (g_list_2eany_24s108509638x1972721376(a_0, a_1)); heff_drop(v_t_247); r_; });
}
V g_heff_2ebuild_2edriver_2ebenchesOf_lam1(V self, V *args) {
  V v_o_243 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_all_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_248 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ebenchesOf_lam2, 1, 2, (V[]){v_c_240, v_o_243}); V a_1 = v_all_242; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_all_242); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_248) == NTAG(TAG_True)));
  heff_drop(v_x1_248);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str11, 0, "");
Clo g_heff_2ebuild_2edriver_2elabelOfV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2elabelOfV_entry, 1, 0};

V g_heff_2ebuild_2edriver_2elabelOfV(V v_v_240) {
top: ;
  V v_t_2414;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VFun: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VCons: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VTag: {
    V v_vs_244 = heff_field(v_v_240, 1);
    v_t_2414 = heff_dup(v_vs_244);
    break;
  }
  case TAG_VInt: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VFloat: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VFloat32: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VStr: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VRune: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VArr: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VBytes: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VBits: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VErased: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_v_240);
  }
  HeffT3 v_t_2415 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2414; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_t_2434;
  {
    V v_field_2417 = v_t_2415.f[1];
    V v_field_2418 = v_t_2415.f[2];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2419 = v_field_2417;
      V v_x12_2420 = v_field_2418;
      heff_drop(v_x12_2420);
      switch (heff_tag_of(v_x_2419)) {
      case TAG_VFun: {
        heff_take_n(v_x_2419, 0ULL, 1);
        v_t_2434 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str0);
        break;
      }
      case TAG_VCons: {
        heff_take_n(v_x_2419, 0ULL, 1);
        v_t_2434 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str1);
        break;
      }
      case TAG_VTag: {
        heff_take_n(v_x_2419, 0ULL, 2);
        v_t_2434 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str2);
        break;
      }
      case TAG_VInt: {
        heff_take_n(v_x_2419, 0ULL, 1);
        v_t_2434 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str3);
        break;
      }
      case TAG_VFloat: {
        heff_take_na(v_x_2419, 0ULL, 1);
        v_t_2434 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str4);
        break;
      }
      case TAG_VFloat32: {
        heff_take_n(v_x_2419, 0ULL, 1);
        v_t_2434 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str5);
        break;
      }
      case TAG_VStr: {
        V v_s_2428 = heff_field(v_x_2419, 0);
        heff_take_n(v_x_2419, 1ULL, 1);
        v_t_2434 = v_s_2428;
        break;
      }
      case TAG_VRune: {
        heff_take_n(v_x_2419, 0ULL, 1);
        v_t_2434 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str6);
        break;
      }
      case TAG_VArr: {
        heff_take_n(v_x_2419, 0ULL, 1);
        v_t_2434 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str7);
        break;
      }
      case TAG_VBytes: {
        heff_take_n(v_x_2419, 0ULL, 1);
        v_t_2434 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str8);
        break;
      }
      case TAG_VBits: {
        heff_take_n(v_x_2419, 0ULL, 2);
        v_t_2434 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str9);
        break;
      }
      case TAG_VErased: {
        v_t_2434 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str10);
        break;
      }
      default: heff_nomatch(v_x_2419);
      }
    } else {
      heff_drop(v_field_2417);
      heff_drop(v_field_2418);
      v_t_2434 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str11);
    }
  }
  V v_t_2448;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VFun: {
    v_t_2448 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VCons: {
    v_t_2448 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VTag: {
    V v_vs_2438 = heff_field(v_v_240, 1);
    v_t_2448 = heff_dup(v_vs_2438);
    break;
  }
  case TAG_VInt: {
    v_t_2448 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VFloat: {
    v_t_2448 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VFloat32: {
    v_t_2448 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VStr: {
    v_t_2448 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VRune: {
    v_t_2448 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VArr: {
    v_t_2448 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VBytes: {
    v_t_2448 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VBits: {
    v_t_2448 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VErased: {
    v_t_2448 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_v_240);
  }
  HeffT3 v_t_2449 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2448; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2448); r_; });
  V v_t_2468;
  {
    V v_field_2451 = v_t_2449.f[1];
    V v_field_2452 = v_t_2449.f[2];
    int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
    if ((v_tag_2450 == ((int64_t)0ULL))) {
      V v_x_2453 = v_field_2451;
      V v_x12_2454 = v_field_2452;
      heff_drop(v_x12_2454);
      switch (heff_tag_of(v_x_2453)) {
      case TAG_VFun: {
        heff_take_n(v_x_2453, 0ULL, 1);
        v_t_2468 = MK_INT(0LL);
        break;
      }
      case TAG_VCons: {
        heff_take_n(v_x_2453, 0ULL, 1);
        v_t_2468 = MK_INT(0LL);
        break;
      }
      case TAG_VTag: {
        heff_take_n(v_x_2453, 0ULL, 2);
        v_t_2468 = MK_INT(0LL);
        break;
      }
      case TAG_VInt: {
        V v_i_2459 = heff_field(v_x_2453, 0);
        heff_take_n(v_x_2453, 1ULL, 1);
        v_t_2468 = v_i_2459;
        break;
      }
      case TAG_VFloat: {
        heff_take_na(v_x_2453, 0ULL, 1);
        v_t_2468 = MK_INT(0LL);
        break;
      }
      case TAG_VFloat32: {
        heff_take_n(v_x_2453, 0ULL, 1);
        v_t_2468 = MK_INT(0LL);
        break;
      }
      case TAG_VStr: {
        heff_take_n(v_x_2453, 0ULL, 1);
        v_t_2468 = MK_INT(0LL);
        break;
      }
      case TAG_VRune: {
        heff_take_n(v_x_2453, 0ULL, 1);
        v_t_2468 = MK_INT(0LL);
        break;
      }
      case TAG_VArr: {
        heff_take_n(v_x_2453, 0ULL, 1);
        v_t_2468 = MK_INT(0LL);
        break;
      }
      case TAG_VBytes: {
        heff_take_n(v_x_2453, 0ULL, 1);
        v_t_2468 = MK_INT(0LL);
        break;
      }
      case TAG_VBits: {
        heff_take_n(v_x_2453, 0ULL, 2);
        v_t_2468 = MK_INT(0LL);
        break;
      }
      case TAG_VErased: {
        v_t_2468 = MK_INT(0LL);
        break;
      }
      default: heff_nomatch(v_x_2453);
      }
    } else {
      heff_drop(v_field_2451);
      heff_drop(v_field_2452);
      v_t_2468 = MK_INT(0LL);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2434, v_t_2468});
}
V g_heff_2ebuild_2edriver_2elabelOfV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2elabelOfV(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str11, 4, "Just");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str19, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eskippedOfV_str23, 0, "");
Clo g_heff_2ebuild_2edriver_2eskippedOfV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eskippedOfV_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eskippedOfV(V v_v_240) {
top: ;
  V v_t_2414;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VFun: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str0);
    break;
  }
  case TAG_VCons: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str1);
    break;
  }
  case TAG_VTag: {
    V v_x_243 = heff_field(v_v_240, 0);
    v_t_2414 = heff_dup(v_x_243);
    break;
  }
  case TAG_VInt: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str2);
    break;
  }
  case TAG_VFloat: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str3);
    break;
  }
  case TAG_VFloat32: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str4);
    break;
  }
  case TAG_VStr: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str5);
    break;
  }
  case TAG_VRune: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str6);
    break;
  }
  case TAG_VArr: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str7);
    break;
  }
  case TAG_VBytes: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str8);
    break;
  }
  case TAG_VBits: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str9);
    break;
  }
  case TAG_VErased: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str10);
    break;
  }
  default: heff_nomatch(v_v_240);
  }
  if (heff_strEq_c(v_t_2414, ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str11))) {
    V v_t_2428;
    switch (heff_tag_of(v_v_240)) {
    case TAG_VFun: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_2418 = heff_field(v_v_240, 1);
      v_t_2428 = heff_dup(v_vs_2418);
      break;
    }
    case TAG_VInt: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBytes: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBits: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_240);
    }
    HeffT3 v_t_2429 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2428; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2428); r_; });
    V v_t_2448;
    {
      V v_field_2431 = v_t_2429.f[1];
      V v_field_2432 = v_t_2429.f[2];
      int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
      if ((v_tag_2430 == ((int64_t)0ULL))) {
        V v_x_2433 = v_field_2431;
        V v_x12_2434 = v_field_2432;
        heff_drop(v_x12_2434);
        switch (heff_tag_of(v_x_2433)) {
        case TAG_VFun: {
          heff_take_n(v_x_2433, 0ULL, 1);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str12);
          break;
        }
        case TAG_VCons: {
          heff_take_n(v_x_2433, 0ULL, 1);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str13);
          break;
        }
        case TAG_VTag: {
          heff_take_n(v_x_2433, 0ULL, 2);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str14);
          break;
        }
        case TAG_VInt: {
          heff_take_n(v_x_2433, 0ULL, 1);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str15);
          break;
        }
        case TAG_VFloat: {
          heff_take_na(v_x_2433, 0ULL, 1);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str16);
          break;
        }
        case TAG_VFloat32: {
          heff_take_n(v_x_2433, 0ULL, 1);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str17);
          break;
        }
        case TAG_VStr: {
          V v_s_2442 = heff_field(v_x_2433, 0);
          heff_take_n(v_x_2433, 1ULL, 1);
          v_t_2448 = v_s_2442;
          break;
        }
        case TAG_VRune: {
          heff_take_n(v_x_2433, 0ULL, 1);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str18);
          break;
        }
        case TAG_VArr: {
          heff_take_n(v_x_2433, 0ULL, 1);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str19);
          break;
        }
        case TAG_VBytes: {
          heff_take_n(v_x_2433, 0ULL, 1);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str20);
          break;
        }
        case TAG_VBits: {
          heff_take_n(v_x_2433, 0ULL, 2);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str21);
          break;
        }
        case TAG_VErased: {
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str22);
          break;
        }
        default: heff_nomatch(v_x_2433);
        }
      } else {
        heff_drop(v_field_2431);
        heff_drop(v_field_2432);
        v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2eskippedOfV_str23);
      }
    }
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2448});
  } else {
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2edriver_2eskippedOfV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eskippedOfV(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2epickIntegrations_str0, 20, "> test integrations ");
Clo g_heff_2ebuild_2edriver_2epickIntegrations_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2epickIntegrations_entry, 3, 0};

V g_heff_2ebuild_2edriver_2epickIntegrations(V v_rs_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_rs_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2epickIntegrations_str0), heff_intShow(heff_dup(v_i_241)));
    HeffT2 v_t_246 = (g_list_2elookupBy_24cpr(heff_dup(g_strEq_get()), v_t_245, heff_dup(v_rs_240)));
    V v_t_2413;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_r_249 = v_field_248;
        switch (heff_tag_of(v_r_249)) {
        case TAG_RSucceeded: {
          V v_v_2410 = heff_field(v_r_249, 0);
          heff_take_n(v_r_249, 1ULL, 1);
          V v_t_2411 = ({ V a_0 = v_v_2410; V r_ = (g_heff_2ebuild_2edriver_2elistOfV(a_0)); heff_drop(v_v_2410); r_; });
          v_t_2413 = (g_list_2emap_24s588468714x1874323009(v_t_2411));
          break;
        }
        case TAG_RAbandoned: {
          v_t_2413 = NTAG(TAG_Nil);
          break;
        }
        case TAG_RDiverged: {
          v_t_2413 = NTAG(TAG_Nil);
          break;
        }
        case TAG_RBug: {
          heff_take_n(v_r_249, 0ULL, 1);
          v_t_2413 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_r_249);
        }
      } else {
        heff_drop(v_field_248);
        v_t_2413 = NTAG(TAG_Nil);
      }
    }
    V v_t_2414 = (g_heff_2ebuild_2edriver_2epickIntegrations(v_rs_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_rest_244));
    return (g_prelude_2e_2b_2b(v_t_2413, v_t_2414));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2epickIntegrations_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2epickIntegrations(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str0, 6, "infixl");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str1, 6, "infixr");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str2, 5, "infix");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str7, 1, " ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str8, 7, " above ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str11, 1, " ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str12, 7, " below ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str13, 6, " below");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str15, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str16, 1, " ");
V g_heff_2ebuild_2edriver_2efixityLine_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2efixityLine_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2efixityLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efixityLine_entry, 3, 0};

V g_heff_2ebuild_2edriver_2efixityLine(V v_fx_240, V v_i_241, V v_g_242) {
top: ;
  V v_assoc_243 = heff_take_field(v_g_242, 1);
  V v_ops_244 = heff_take_field(v_g_242, 2);
  V v_id_245 = heff_take_field(v_g_242, 0);
  V v_loosest_246 = heff_get_n(v_g_242, 3, 5);
  V v_groups_247 = heff_take_field(v_fx_240, 0);
  V v_above_248 = heff_get_n(v_fx_240, 1, 2);
  V v_t_249;
  switch (heff_tag_of(v_assoc_243)) {
  case TAG_AssocLeft: {
    v_t_249 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str0);
    break;
  }
  case TAG_AssocRight: {
    v_t_249 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str1);
    break;
  }
  case TAG_AssocNone: {
    v_t_249 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str2);
    break;
  }
  default: heff_nomatch(v_assoc_243);
  }
  V v_t_2412;
  switch (heff_tag_of(v_ops_244)) {
  case TAG_Nil: {
    v_t_2412 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_ops_244, 0);
    V v_xs_2411 = heff_field(v_ops_244, 1);
    heff_take_n(v_ops_244, 3ULL, 2);
    v_t_2412 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str4); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
    break;
  }
  default: heff_nomatch(v_ops_244);
  }
  V v_t_2417 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2efixityLine_lam0, 1, 3, (V[]){heff_dup(v_id_245), heff_dup(v_groups_247), heff_dup(v_i_241)}), heff_dup(v_above_248)));
  V v_t_2418 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2417));
  V v_ops_2419 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2418));
  V v_t_2425;
  switch (heff_tag_of(v_ops_2419)) {
  case TAG_Nil: {
    v_t_2425 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str5);
    break;
  }
  case TAG_Cons: {
    V v_t_2424;
    switch (heff_tag_of(v_ops_2419)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_ops_2419, 0);
      V v_xs_2423 = heff_field(v_ops_2419, 1);
      heff_take_n(v_ops_2419, 3ULL, 2);
      v_t_2424 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str7); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_ops_2419);
    }
    v_t_2425 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2efixityLine_str8), v_t_2424);
    break;
  }
  default: heff_nomatch(v_ops_2419);
  }
  V v_t_2430 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2efixityLine_lam1, 1, 3, (V[]){v_id_245, v_groups_247, v_i_241}), v_above_248));
  V v_t_2431 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2430));
  V v_ops_2432 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2431));
  V v_t_2438;
  switch (heff_tag_of(v_ops_2432)) {
  case TAG_Nil: {
    v_t_2438 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str9);
    break;
  }
  case TAG_Cons: {
    V v_t_2437;
    switch (heff_tag_of(v_ops_2432)) {
    case TAG_Nil: {
      v_t_2437 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str10);
      break;
    }
    case TAG_Cons: {
      V v_x_2435 = heff_field(v_ops_2432, 0);
      V v_xs_2436 = heff_field(v_ops_2432, 1);
      heff_take_n(v_ops_2432, 3ULL, 2);
      v_t_2437 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str11); V a_1 = v_x_2435; V a_2 = v_xs_2436; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2436); r_; });
      break;
    }
    default: heff_nomatch(v_ops_2432);
    }
    v_t_2438 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2efixityLine_str12), v_t_2437);
    break;
  }
  default: heff_nomatch(v_ops_2432);
  }
  V v_t_2439;
  if ((heff_dup(v_loosest_246) == NTAG(TAG_True))) {
    heff_drop(v_loosest_246);
    v_t_2439 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str13);
  } else {
    heff_drop(v_loosest_246);
    v_t_2439 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str14);
  }
  V v_t_2440 = heff_strAppend(v_t_2438, heff_strAppend(v_t_2439, ((V)&g_heff_2ebuild_2edriver_2efixityLine_str15)));
  V v_t_2441 = heff_strAppend(v_t_2412, heff_strAppend(v_t_2425, v_t_2440));
  return heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ebuild_2edriver_2efixityLine_str16), v_t_2441));
}
V g_heff_2ebuild_2edriver_2efixityLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2efixityLine(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edriver_2efixityLine_lam0(V self, V *args) {
  V v_e_2413 = args[0];
  V v_id_245 = heff_env(self)[0];
  V v_groups_247 = heff_env(self)[1];
  V v_i_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_tighter_2414 = heff_take_field(v_e_2413, 0);
  V v_looser_2415 = heff_get_n(v_e_2413, 1, 2);
  if (heff_strEq_c(v_tighter_2414, v_id_245)) {
    V v_t_2416 = ({ V a_0 = v_groups_247; V a_1 = v_i_241; V a_2 = v_looser_2415; V a_3 = MK_INT(0LL); V r_ = (g_heff_2ebuild_2edriver_2eearlierGo(a_0, a_1, a_2, a_3)); heff_drop(v_groups_247); r_; });
    if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
      heff_drop(v_t_2416);
      return heff_tag_n(TAG_Just, 1, (V[]){v_looser_2415});
    } else {
      heff_drop(v_looser_2415);
      heff_drop(v_t_2416);
      return NTAG(TAG_Nothing);
    }
  } else {
    heff_drop(v_groups_247);
    heff_drop(v_i_241);
    heff_drop(v_looser_2415);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2edriver_2efixityLine_lam1(V self, V *args) {
  V v_e_2426 = args[0];
  V v_id_245 = heff_env(self)[0];
  V v_groups_247 = heff_env(self)[1];
  V v_i_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_looser_2427 = heff_take_field(v_e_2426, 1);
  V v_tighter_2428 = heff_get_n(v_e_2426, 0, 2);
  if (heff_strEq_c(v_looser_2427, v_id_245)) {
    V v_t_2429 = ({ V a_0 = v_groups_247; V a_1 = v_i_241; V a_2 = v_tighter_2428; V a_3 = MK_INT(0LL); V r_ = (g_heff_2ebuild_2edriver_2eearlierGo(a_0, a_1, a_2, a_3)); heff_drop(v_groups_247); r_; });
    if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
      heff_drop(v_t_2429);
      return heff_tag_n(TAG_Just, 1, (V[]){v_tighter_2428});
    } else {
      heff_drop(v_tighter_2428);
      heff_drop(v_t_2429);
      return NTAG(TAG_Nothing);
    }
  } else {
    heff_drop(v_groups_247);
    heff_drop(v_i_241);
    heff_drop(v_tighter_2428);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2edriver_2esignatureOf_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2esignatureOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2esignatureOf_entry, 2, 0};

V g_heff_2ebuild_2edriver_2esignatureOf(V v_c_240, V v_o_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_243 = ({ V b_0 = heff_get_n(v_t_242, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_m_244 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_243; V r_ = (g_list_2efoldl_24s1315672171x449285703(a_0, a_1)); heff_drop(v_t_243); r_; });
  return (g_heff_2ebuild_2edriver_2esigEntry(v_c_240, heff_clo_n(g_heff_2ebuild_2edriver_2esignatureOf_lam0, 1, 1, (V[]){v_m_244}), v_o_241));
}
V g_heff_2ebuild_2edriver_2esignatureOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2esignatureOf(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2esignatureOf_lam0(V self, V *args) {
  V v_k_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_246 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_k_245)));
  HeffT2 v_t_247 = ({ V a_0 = v_m_244; V a_1 = v_k_245; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_m_244); heff_drop(v_k_245); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop(v_d_246);
      V v_x_2410 = v_field_249;
      return v_x_2410;
    } else {
      heff_drop(v_field_249);
      return v_d_246;
    }
  }
}
Clo g_heff_2ebuild_2edriver_2eappendLv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eappendLv_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eappendLv(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2ebuild_2edriver_2eappendLv_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eappendLv_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eappendLv(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2eappendLv_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eappendLv_24dps_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eappendLv_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eappendLv_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eappendLv_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecandLeaves_entry, 1, 0};

V g_heff_2ebuild_2edriver_2ecandLeaves(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = (g_heff_2eelab_2eeffect_2eleaves(heff_rfield(v_r_241, 2)));
    V v_t_244 = (g_heff_2ebuild_2edriver_2ecandLeaves(v_rest_242));
    return (g_heff_2ebuild_2edriver_2eappendLv(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2ecandLeaves(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2efindRunnable_24cpr_str0, 31, " is not a computation, `Co h a`");
HEFF_LIT(g_heff_2ebuild_2edriver_2efindRunnable_24cpr_str1, 14, "no definition ");

HeffT2 g_heff_2ebuild_2edriver_2efindRunnable_24cpr(V v_handled_240, V v_c_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_243 = (g_heff_2ebuild_2edriver_2ecandidatesOf(v_c_241));
    return (g_heff_2ebuild_2edriver_2efindFirst_24cpr(v_handled_240, v_t_243));
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x3_242, 0);
    HeffT2 v_t_245 = (g_list_2efind_24s279352081x1530195138_24cpr(v_x_244, heff_dup(heff_rfield(v_c_241, 7))));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_o_248 = v_field_247;
        HeffT2 v_t_249 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(v_c_241, heff_rfield(v_o_248, 1)));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_eff_2412 = v_field_2411;
            V v_t_2413 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_dup(v_x_244), heff_get_n(v_o_248, 1, 2), v_eff_2412});
            return (g_heff_2ebuild_2edriver_2efits_24cpr(v_handled_240, v_t_2413));
          } else {
            heff_drop_rec(v_o_248, 2);
            heff_drop(v_field_2411);
            V v_f_2414 = heff_strAppend(heff_dup(v_x_244), ((V)&g_heff_2ebuild_2edriver_2efindRunnable_24cpr_str0));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
          }
        }
      } else {
        heff_drop_rec(v_c_241, 14);
        heff_drop(v_field_247);
        V v_f_2415 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2efindRunnable_24cpr_str1), heff_dup(v_x_244));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2415}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}