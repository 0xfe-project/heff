// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_Bug 14592
#define TAG_Div 16157
#define TAG_Ok 9325
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define LBL_above 293969847
#define LBL_again 294104954
#define LBL_alias 294261354
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_assoc 294479919
#define LBL_broken 566525696
#define LBL_bug 307438
#define LBL_cmt 308164
#define LBL_decls 296817955
#define LBL_deps 9575179
#define LBL_diags 296935042
#define LBL_effect 641056956
#define LBL_el 9998
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_err 310239
#define LBL_expected 956903529
#define LBL_exposes 1070285678
#define LBL_first 298798794
#define LBL_fixities 357800079
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_groups 709681407
#define LBL_hidden 729654485
#define LBL_i 323
#define LBL_id 10114
#define LBL_imports 10411951
#define LBL_infos 301706655
#define LBL_instances 1653559473
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_looser 850054335
#define LBL_loosest 581880769
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_ops 319788
#define LBL_order 307364712
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_places 961367927
#define LBL_spans 310996611
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_tighter 1059982480
#define LBL_to 10466
#define LBL_tok 324554
#define LBL_top 324559
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_type_5f 312202367
#define LBL_unreached 121683306
#define LBL_value 313331083
#define LBL_watches 1357821955
static uint32_t shape_expected__from__to[] = {LBL_expected, LBL_from, LBL_to};
static uint32_t shape_first__again[] = {LBL_first, LBL_again};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace, LBL_unreached};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_key__effect[] = {LBL_key, LBL_effect};
static uint32_t shape_known__fixities__lenient__place__path[] = {LBL_known, LBL_fixities, LBL_lenient, LBL_place, LBL_path};
static uint32_t shape_module__alias[] = {LBL_module, LBL_alias};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_name__value__bug[] = {LBL_name, LBL_value, LBL_bug};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_instances};
static uint32_t shape_ty__el[] = {LBL_ty, LBL_el};
V g_heff_2ebuild_2edriver_2ealiasOpen(V, V, V, V);
V g_heff_2ebuild_2edriver_2ealiasOpen_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasOpen_clo;
V g_heff_2ebuild_2edriver_2ealiasPairs(V);
V g_heff_2ebuild_2edriver_2ealiasPairs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasPairs_clo;
V g_heff_2ebuild_2edriver_2ealiasPairs_24dps(V, V);
V g_heff_2ebuild_2edriver_2ealiasPairs_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasPairs_24dps_clo;
V g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224(V, V);
V g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224_clo;
V g_heff_2ebuild_2edriver_2eappendD(V, V);
V g_heff_2ebuild_2edriver_2eappendD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_clo;
V g_heff_2ebuild_2edriver_2eappendD_24tok2(V, V, V);
V g_heff_2ebuild_2edriver_2eappendD_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_24tok2_clo;
V g_heff_2ebuild_2edriver_2eappendLv(V, V);
V g_heff_2ebuild_2edriver_2eappendLv_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendLv_clo;
V g_heff_2ebuild_2edriver_2eappendLv_24dps(V, V, V);
V g_heff_2ebuild_2edriver_2eappendLv_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendLv_24dps_clo;
V g_heff_2ebuild_2edriver_2eappendLv_24tok2(V, V, V);
V g_heff_2ebuild_2edriver_2eappendLv_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendLv_24tok2_clo;
V g_heff_2ebuild_2edriver_2ebenchesOf(V);
V g_heff_2ebuild_2edriver_2ebenchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ebenchesOf_clo;
V g_heff_2ebuild_2edriver_2ebrokenIn(V);
V g_heff_2ebuild_2edriver_2ebrokenIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ebrokenIn_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD_24dps(V, V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_24dps_clo;
V g_heff_2ebuild_2edriver_2eckOf(V);
V g_heff_2ebuild_2edriver_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eckOf_clo;
V g_heff_2ebuild_2edriver_2ecloseTermF(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTermF_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTermF_clo;
V g_heff_2ebuild_2edriver_2ecloseTermF_24generate1(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTermF_24generate1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTermF_24generate1_clo;
V g_heff_2ebuild_2edriver_2ecloseTypeF(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTypeF_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTypeF_clo;
V g_heff_2ebuild_2edriver_2ecloseTypeF_24map0(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTypeF_24map0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTypeF_24map0_clo;
V g_heff_2ebuild_2edriver_2eclosureGo(V, V, V);
V g_heff_2ebuild_2edriver_2eclosureGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eclosureGo_clo;
V g_heff_2ebuild_2edriver_2econcatMapD_24s604825074x1812671623(V);
V g_heff_2ebuild_2edriver_2econcatMapD_24s604825074x1812671623_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2econcatMapD_24s604825074x1812671623_clo;
V g_heff_2ebuild_2edriver_2eearlierGo(V, V, V, V);
V g_heff_2ebuild_2edriver_2eearlierGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eearlierGo_clo;
HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V, V);
V g_heff_2ebuild_2edriver_2eevalPick(V, V, V);
V g_heff_2ebuild_2edriver_2eevalPick_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eevalPick_clo;
V g_heff_2ebuild_2edriver_2eevalPick_24dps(V, V, V, V);
V g_heff_2ebuild_2edriver_2eevalPick_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eevalPick_24dps_clo;
V g_heff_2ebuild_2edriver_2eexpectAfter(V, V, V);
V g_heff_2ebuild_2edriver_2eexpectAfter_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexpectAfter_clo;
HeffT2 g_heff_2ebuild_2edriver_2eexpectGo_24cpr(V, V, V, V);
V g_heff_2ebuild_2edriver_2eexposedDiag(V, V, V, V);
V g_heff_2ebuild_2edriver_2eexposedDiag_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexposedDiag_clo;
V g_heff_2ebuild_2edriver_2eexposedDiagsGo(V, V, V, V);
V g_heff_2ebuild_2edriver_2eexposedDiagsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexposedDiagsGo_clo;
HeffT2 g_heff_2ebuild_2edriver_2efindChecked_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edriver_2efindRunnable_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edriver_2efits_24cpr(V, V);
V g_heff_2ebuild_2edriver_2efixOf(V, V);
V g_heff_2ebuild_2edriver_2efixOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixOf_clo;
V g_heff_2ebuild_2edriver_2efixityLine(V, V, V);
V g_heff_2ebuild_2edriver_2efixityLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixityLine_clo;
V g_heff_2ebuild_2edriver_2eimportedFix(V, V);
V g_heff_2ebuild_2edriver_2eimportedFix_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eimportedFix_clo;
V g_heff_2ebuild_2edriver_2eimportsByName(V, V);
V g_heff_2ebuild_2edriver_2eimportsByName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eimportsByName_clo;
V g_heff_2ebuild_2edriver_2eisBenchTy(V);
V g_heff_2ebuild_2edriver_2eisBenchTy_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eisBenchTy_clo;
V g_heff_2ebuild_2edriver_2elistOfV(V);
V g_heff_2ebuild_2edriver_2elistOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elistOfV_clo;
V g_heff_2ebuild_2edriver_2elistedName(V);
V g_heff_2ebuild_2edriver_2elistedName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elistedName_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2enubStrD_24dps(V, V);
V g_heff_2ebuild_2edriver_2enubStrD_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_24dps_clo;
V g_heff_2ebuild_2edriver_2eownUses(V, V);
V g_heff_2ebuild_2edriver_2eownUses_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eownUses_clo;
V g_heff_2ebuild_2edriver_2epickIntegrations(V, V, V);
V g_heff_2ebuild_2edriver_2epickIntegrations_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2epickIntegrations_clo;
V g_heff_2ebuild_2edriver_2ereachOwn(V, V, V);
V g_heff_2ebuild_2edriver_2ereachOwn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ereachOwn_clo;
HeffT2 g_heff_2ebuild_2edriver_2ereadExpectation_24cpr(V, V, V, V);
V g_heff_2ebuild_2edriver_2eshowTySx(V, V);
V g_heff_2ebuild_2edriver_2eshowTySx_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eshowTySx_clo;
V g_heff_2ebuild_2edriver_2etwicesGo(V, V);
V g_heff_2ebuild_2edriver_2etwicesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etwicesGo_clo;
V g_heff_2ebuild_2edriver_2etwicesGo_24dps(V, V, V);
V g_heff_2ebuild_2edriver_2etwicesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etwicesGo_24dps_clo;
V g_heff_2ebuild_2edriver_2etypeArgsOf(V, V);
V g_heff_2ebuild_2edriver_2etypeArgsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etypeArgsOf_clo;
V g_heff_2ebuild_2edriver_2ewatchExpect(V);
V g_heff_2ebuild_2edriver_2ewatchExpect_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchExpect_clo;
V g_heff_2ebuild_2edriver_2ewithPlace(V, V, V);
V g_heff_2ebuild_2edriver_2ewithPlace_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithPlace_clo;
V g_heff_2ecompile_2einterp_2eapplyErased(V, V);
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eapplyErased_clo;
V g_heff_2ecompile_2einterp_2efixThunk(V, V, V);
V g_heff_2ecompile_2einterp_2efixThunk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixThunk_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2einterp_2eshowValGo_24tok1(V, V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_24tok1_clo;
V g_heff_2eelab_2eeffect_2eleaves(V);
V g_heff_2eelab_2eeffect_2eleaves_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2eleaves_clo;
HeffT3 g_heff_2eelab_2eglobals_2eresolve_24cpr(V, V);
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
HeffT10 g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_24cpr(V, V);
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
V g_heff_2esyntax_2efixity_2eemptyFixities_get(void);
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
V g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(V, V);
V g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_clo;
V g_heff_2esyntax_2esurface_2ereadLexed(V, V, V);
V g_heff_2esyntax_2esurface_2ereadLexed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadLexed_clo;
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s108509638x1972721376(V, V);
V g_list_2eany_24s108509638x1972721376_entry(V self, V *a);
extern Clo g_list_2eany_24s108509638x1972721376_clo;
HeffT2 g_list_2efind_24cpr(V, V);
HeffT2 g_list_2efind_24s279352081x1530195138_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1468236620x1316701813(V, V);
V g_list_2efoldl_24s1468236620x1316701813_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1468236620x1316701813_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1823913665x1128491553(V, V);
V g_list_2ekeepIf_24s1823913665x1128491553_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1823913665x1128491553_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
HeffT2 g_list_2elookup_24s1507486579x90027037_24cpr(V, V);
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f669780424x1745768631(V, V, V, V, V);
V g_list_2emap_24f669780424x1745768631_entry(V self, V *a);
extern Clo g_list_2emap_24f669780424x1745768631_clo;
V g_list_2emap_24s1134414872x1001811115(V);
V g_list_2emap_24s1134414872x1001811115_entry(V self, V *a);
extern Clo g_list_2emap_24s1134414872x1001811115_clo;
V g_list_2emap_24s1960706388x853997965(V);
V g_list_2emap_24s1960706388x853997965_entry(V self, V *a);
extern Clo g_list_2emap_24s1960706388x853997965_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s588468714x1874323009(V);
V g_list_2emap_24s588468714x1874323009_entry(V self, V *a);
extern Clo g_list_2emap_24s588468714x1874323009_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2eordmap_2edelete_24s2135745297x1725920174(V, V);
V g_std_2eordmap_2edelete_24s2135745297x1725920174_entry(V self, V *a);
extern Clo g_std_2eordmap_2edelete_24s2135745297x1725920174_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_heff_2ebuild_2edriver_2enubStrD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2enubStrD_entry, 1, 0};

V g_heff_2ebuild_2edriver_2enubStrD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = ({ V a_0 = v_x_241; V a_1 = v_xs_242; V r_ = (g_list_2ekeepIf_24s930188071x496633547(a_0, a_1)); heff_drop(v_x_241); r_; });
    V v_u_245 = (g_heff_2ebuild_2edriver_2enubStrD_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2enubStrD(a[0]);
}
Clo g_heff_2ebuild_2edriver_2eclosureGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eclosureGo_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eclosureGo(V v_done_240, V v_seen_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_seen_241;
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x3_242, 0);
    V v_ms_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_list_2eany_24s1006624359x760861690(v_m_243, v_seen_241));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_m_243);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_done_240;
      V t_1 = v_seen_241;
      V t_2 = v_ms_244;
      v_done_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      HeffT2 v_t_246 = (g_heff_2ebuild_2edriver_2efindChecked_24cpr(v_done_240, v_m_243));
      V v_t_2410;
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_c_249 = v_field_248;
          v_t_2410 = heff_get_n(v_c_249, 8, 14);
        } else {
          heff_drop(v_field_248);
          v_t_2410 = NTAG(TAG_Nil);
        }
      }
      V v_t_2411 = (g_heff_2ebuild_2edriver_2eappendD(v_ms_244, v_t_2410));
      V t_0 = v_done_240;
      V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_m_243, v_seen_241});
      V t_2 = v_t_2411;
      v_done_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2eclosureGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eclosureGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecatMaybesD_entry, 1, 0};

V g_heff_2ebuild_2edriver_2ecatMaybesD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ebuild_2edriver_2ecatMaybesD_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ecatMaybesD(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ebrokenIn_str0, 1, ".");
V g_heff_2ebuild_2edriver_2ebrokenIn_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ebrokenIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ebrokenIn_entry, 1, 0};

V g_heff_2ebuild_2edriver_2ebrokenIn(V v_c_240) {
top: ;
  V v_t_241 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 10);
  V v_t_242 = ({ V b_0 = heff_get_n(v_t_241, 3, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_243 = ({ V a_0 = heff_dup(v_c_240); V a_1 = ((V)&g_heff_2ebuild_2edriver_2ebrokenIn_str0); V b_2 = MK_INT(0LL); V a_3 = MK_INT(1LL); V a_4 = v_t_242; V r_ = (g_list_2emap_24f669780424x1745768631(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
  V v_t_244 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_243));
  return (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edriver_2ebrokenIn_lam0, 1, 1, (V[]){v_c_240}), v_t_244));
}
V g_heff_2ebuild_2edriver_2ebrokenIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ebrokenIn(a[0]);
}
V g_heff_2ebuild_2edriver_2ebrokenIn_lam0(V self, V *args) {
  V v_o_245 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_get_n(v_c_240, 13, 14);
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop_rec(v_o_245, 3);
    return NTAG(TAG_True);
  }
  case TAG_Just: {
    V v_es_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    return ({ V b_0 = heff_get_n(v_o_245, 0, 3); V a_1 = v_es_247; V r_ = (g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224(b_0, a_1)); heff_drop(b_0); heff_drop(v_es_247); r_; });
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2ebuild_2edriver_2ealiasOpen_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2ealiasOpen_lam2(V self, V *args);
V g_heff_2ebuild_2edriver_2ealiasOpen_lam3(V self, V *args);
V g_heff_2ebuild_2edriver_2ealiasOpen_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ealiasOpen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ealiasOpen_entry, 4, 0};

V g_heff_2ebuild_2edriver_2ealiasOpen(V v_done_240, V v_unwritten_241, V v_g_242, V v_direct_243) {
top: ;
  V v_t_244 = (g_heff_2ebuild_2edriver_2econcatMapD_24s604825074x1812671623(v_direct_243));
  V v_m_245 = (g_heff_2ebuild_2edriver_2eimportsByName(heff_dup(g_std_2eordmap_2eempty_get()), v_t_244));
  V v_t_246 = ({ V a_0 = v_m_245; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_245); r_; });
  V v_t_247 = (g_list_2emap_24s366344330x1145113647(v_t_246));
  return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ealiasOpen_lam0, 2, 2, (V[]){v_done_240, heff_dup(v_unwritten_241)}); V a_1 = v_g_242; V a_2 = v_t_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
}
V g_heff_2ebuild_2edriver_2ealiasOpen_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ebuild_2edriver_2ealiasOpen(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ebuild_2edriver_2ealiasOpen_lam1(V self, V *args) {
  V v_o_2412 = args[0];
  V v_unwritten_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2413 = ({ V b_0 = heff_get_n(v_o_2412, 2, 3); V a_1 = v_unwritten_241; V r_ = (g_list_2eany_24s1006624359x760861690(b_0, a_1)); heff_drop(b_0); heff_drop(v_unwritten_241); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2413) == NTAG(TAG_True)));
  heff_drop(v_x1_2413);
  return v_ret_24bool;
}
V g_heff_2ebuild_2edriver_2ealiasOpen_lam2(V self, V *args) {
  V v_k_2432 = args[0];
  V v_ks_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2433 = ({ V a_0 = v_k_2432; V a_1 = v_ks_2425; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_k_2432); heff_drop_tag(v_ks_2425, 2); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2433) == NTAG(TAG_True)));
  heff_drop(v_x1_2433);
  return v_ret_24bool;
}
V g_heff_2ebuild_2edriver_2ealiasOpen_lam3(V self, V *args) {
  V v_g2_2439 = args[0];
  V v_p_2440 = args[1];
  V v_done_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_done_2410; V a_1 = v_p_2440; V a_2 = v_g2_2439; V r_ = (g_heff_2ebuild_2edriver_2ewithPlace(a_0, a_1, a_2)); heff_drop(v_done_2410); r_; });
}
V g_heff_2ebuild_2edriver_2ealiasOpen_lam0(V self, V *args) {
  V v_g2_248 = args[0];
  V v_os_249 = args[1];
  V v_done_240 = heff_env(self)[0];
  V v_unwritten_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_done_2410 = v_done_240;
  V v_g_2411 = v_g2_248;
  V v_written_2414 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edriver_2ealiasOpen_lam1, 1, 1, (V[]){v_unwritten_241}), heff_dup(v_os_249)));
  V v_x3_2417;
  switch (heff_tag_of(v_written_2414)) {
  case TAG_Nil: {
    v_x3_2417 = v_os_249;
    break;
  }
  case TAG_Cons: {
    heff_drop(v_os_249);
    v_x3_2417 = v_written_2414;
    break;
  }
  default: heff_nomatch(v_written_2414);
  }
  switch (heff_tag_of(v_x3_2417)) {
  case TAG_Nil: {
    heff_drop(v_done_2410);
    return v_g_2411;
  }
  case TAG_Cons: {
    V v_o_2418 = heff_field(v_x3_2417, 0);
    V v_x32_2419 = heff_field(v_x3_2417, 1);
    V v_ru_24x3_2417_24Cons = heff_take_reuse_n(v_x3_2417, 3ULL, 2);
    switch (heff_tag_of(v_x32_2419)) {
    case TAG_Nil: {
      heff_drop(v_done_2410);
      heff_drop_cell(v_ru_24x3_2417_24Cons, 2);
      if (heff_strEq_c(heff_dup(heff_rfield(v_o_2418, 1)), heff_dup(heff_rfield(v_o_2418, 0)))) {
        heff_drop_rec(v_o_2418, 3);
        return v_g_2411;
      } else {
        V v_t_2420 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_g_2411, 2), heff_take_field(v_o_2418, 0), heff_get_n(v_o_2418, 1, 3)));
        return ({ V rv_2 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_g_2411, 251ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 65487u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      }
    }
    case TAG_Cons: {
      V v_x_2423 = heff_dup(heff_rfield(v_o_2418, 0));
      V v_t_2424 = (g_list_2emap_24s1134414872x1001811115(heff_dup(v_x32_2419)));
      V v_ks_2425 = heff_tag_at_n(v_ru_24x3_2417_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_o_2418, 1)), v_t_2424});
      V v_g_2426 = v_g_2411;
      V v_t_2427 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(heff_take_field(v_g_2426, 2), v_x_2423));
      HeffT2 v_t_2428 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_g_2426, 4), v_x_2423));
      V v_t_2434;
      {
        V v_field_2430 = v_t_2428.f[1];
        int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
        if ((v_tag_2429 == ((int64_t)0ULL))) {
          V v_old_2431 = v_field_2430;
          v_t_2434 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edriver_2ealiasOpen_lam2, 1, 1, (V[]){heff_dup(v_ks_2425)}), v_old_2431));
        } else {
          heff_drop(v_field_2430);
          v_t_2434 = NTAG(TAG_Nil);
        }
      }
      V v_t_2435 = (g_prelude_2e_2b_2b(v_t_2434, v_ks_2425));
      V v_t_2436 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_g_2426, 4), v_x_2423, v_t_2435));
      V v_z_2437 = ({ V rv_2 = v_t_2427; V rv_4 = v_t_2436; V rr_ = heff_rec_reuse_nf(v_g_2426, 235ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 64719u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 4) = rv_4; rr_; });
      V v_t_2438 = (g_heff_2ebuild_2edriver_2ewithPlace(v_done_2410, v_o_2418, v_z_2437));
      return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ealiasOpen_lam3, 2, 1, (V[]){v_done_2410}); V a_1 = v_t_2438; V a_2 = v_x32_2419; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop_tag(v_x32_2419, 2); r_; });
    }
    default: return heff_nomatch(v_x32_2419);
    }
  }
  default: return heff_nomatch(v_x3_2417);
  }
}
Clo g_heff_2ebuild_2edriver_2ealiasPairs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ealiasPairs_entry, 1, 0};

V g_heff_2ebuild_2edriver_2ealiasPairs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_i_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_alias_243 = heff_take_field(v_i_241, 1);
    V v_name_244 = heff_get_n(v_i_241, 0, 3);
    switch (heff_tag_of(v_alias_243)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_name_244);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_a_245 = heff_field(v_alias_243, 0);
      heff_take_n(v_alias_243, 1ULL, 1);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_module__alias, (V[]){v_name_244, v_a_245}), heff_hole()});
      V v_u_247 = (g_heff_2ebuild_2edriver_2ealiasPairs_24dps(v_rest_242, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_alias_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2ealiasPairs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ealiasPairs(a[0]);
}
Clo g_heff_2ebuild_2edriver_2ecloseTypeF_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTypeF_24map0_entry, 5, 0};

V g_heff_2ebuild_2edriver_2ecloseTypeF_24map0(V v_r_240, V v_i_241, V v_depth_242, V v_box_24i_243, V v_a_244) {
  int64_t v_i_243 = heff_unbox_word(v_box_24i_243);
  v_a_244 = heff_arrayOwn(v_a_244);
  if ((((int64_t)0ULL) <= v_i_243)) {
    top_TAG_InRange: ;
    if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
      V v_t2_245 = heff_arrayIndexIn_lent(v_a_244, heff_box_word(v_i_243), 2);
      V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 3, (V[]){heff_dup(v_i_241), heff_dup(v_depth_242), v_t2_245}));
      V t_0 = v_r_240;
      V t_1 = v_i_241;
      V t_2 = v_depth_242;
      int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
      V t_4 = heff_arraySetOwnedIn(v_a_244, heff_box_word(v_i_243), v_t_246);
      v_r_240 = t_0;
      v_i_241 = t_1;
      v_depth_242 = t_2;
      v_i_243 = t_3;
      v_a_244 = t_4;
      goto top_TAG_InRange;
    } else {
      heff_drop_rec(v_r_240, 2);
      heff_drop(v_i_241);
      heff_drop(v_depth_242);
      return v_a_244;
    }
  } else {
  }
top: ;
  if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
    V v_t2_245 = heff_arrayIndex_lent(v_a_244, heff_box_word(v_i_243), 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 3, (V[]){heff_dup(v_i_241), heff_dup(v_depth_242), v_t2_245}));
    V t_0 = v_r_240;
    V t_1 = v_i_241;
    V t_2 = v_depth_242;
    int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
    V t_4 = heff_arraySetOwned(v_a_244, heff_box_word(v_i_243), v_t_246);
    v_r_240 = t_0;
    v_i_241 = t_1;
    v_depth_242 = t_2;
    v_i_243 = t_3;
    v_a_244 = t_4;
    goto top;
  } else {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_241);
    heff_drop(v_depth_242);
    return v_a_244;
  }
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_24map0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ecloseTypeF_24map0(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ebuild_2edriver_2ecloseTermF_24generate1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTermF_24generate1_entry, 6, 0};

V g_heff_2ebuild_2edriver_2ecloseTermF_24generate1(V v_xs_240, V v_r_241, V v_i_242, V v_depth_243, V v_box_24i_244, V v_a_245) {
  int64_t v_i_244 = heff_unbox_word(v_box_24i_244);
  v_a_245 = heff_arrayOwn(v_a_245);
  if (((((int64_t)0ULL) <= v_i_244) && (heff_unbox_word(heff_arrayLength_lent(v_a_245, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_244 < heff_unbox_word(heff_arrayLength_lent(v_a_245, 0)))) {
      V v_p_246 = heff_arrayPeekIn(v_xs_240, heff_box_word(v_i_244));
      V v_t_2411;
      switch (heff_tag_of(v_p_246)) {
      case TAG_MkPair: {
        V v_xs_247 = heff_field(v_p_246, 0);
        V v_b_248 = heff_field(v_p_246, 1);
        V v_t_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_247)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 1)), 3, (V[]){heff_dup(v_i_242), heff_intAdd(heff_dup(v_depth_243), v_t_249), heff_dup(v_b_248)}));
        v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_xs_247), v_t_2410});
        break;
      }
      default: heff_nomatch(v_p_246);
      }
      V t_0 = v_xs_240;
      V t_1 = v_r_241;
      V t_2 = v_i_242;
      V t_3 = v_depth_243;
      int64_t t_4 = (v_i_244 + ((int64_t)1ULL));
      V t_5 = heff_arraySetOwnedIn(v_a_245, heff_box_word(v_i_244), v_t_2411);
      v_xs_240 = t_0;
      v_r_241 = t_1;
      v_i_242 = t_2;
      v_depth_243 = t_3;
      v_i_244 = t_4;
      v_a_245 = t_5;
      goto top_TAG_InRange;
    } else {
      heff_drop_rec(v_r_241, 2);
      heff_drop(v_i_242);
      heff_drop(v_depth_243);
      return v_a_245;
    }
  } else {
  }
top: ;
  if ((v_i_244 < heff_unbox_word(heff_arrayLength_lent(v_a_245, 0)))) {
    V v_p_246 = heff_arrayPeek(v_xs_240, heff_box_word(v_i_244));
    V v_t_2411;
    switch (heff_tag_of(v_p_246)) {
    case TAG_MkPair: {
      V v_xs_247 = heff_field(v_p_246, 0);
      V v_b_248 = heff_field(v_p_246, 1);
      V v_t_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_247)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 1)), 3, (V[]){heff_dup(v_i_242), heff_intAdd(heff_dup(v_depth_243), v_t_249), heff_dup(v_b_248)}));
      v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_xs_247), v_t_2410});
      break;
    }
    default: heff_nomatch(v_p_246);
    }
    V t_0 = v_xs_240;
    V t_1 = v_r_241;
    V t_2 = v_i_242;
    V t_3 = v_depth_243;
    int64_t t_4 = (v_i_244 + ((int64_t)1ULL));
    V t_5 = heff_arraySetOwned(v_a_245, heff_box_word(v_i_244), v_t_2411);
    v_xs_240 = t_0;
    v_r_241 = t_1;
    v_i_242 = t_2;
    v_depth_243 = t_3;
    v_i_244 = t_4;
    v_a_245 = t_5;
    goto top;
  } else {
    heff_drop_rec(v_r_241, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_a_245;
  }
}
V g_heff_2ebuild_2edriver_2ecloseTermF_24generate1_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2ecloseTermF_24generate1(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2eckOf_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2eckOf_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eckOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eckOf_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eckOf(V v_idx_240) {
top: ;
  return heff_rec_n(2, shape_ty__el, (V[]){heff_clo_n(g_heff_2ebuild_2edriver_2eckOf_lam0, 3, 1, (V[]){heff_dup(v_idx_240)}), heff_clo_n(g_heff_2ebuild_2edriver_2eckOf_lam1, 3, 1, (V[]){heff_dup(v_idx_240)})});
}
V g_heff_2ebuild_2edriver_2eckOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eckOf(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2eckOf_lam0(V self, V *args) {
  V v_i_241 = args[0];
  V v_depth_242 = args[1];
  V v_t_243 = args[2];
  V v_idx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2ebuild_2edriver_2eckOf(v_idx_240));
  return ({ V a_0 = v_t_244; V a_1 = v_idx_240; V a_2 = v_i_241; V a_3 = v_depth_242; V a_4 = v_t_243; V r_ = (g_heff_2ebuild_2edriver_2ecloseTypeF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_idx_240); r_; });
}
V g_heff_2ebuild_2edriver_2eckOf_lam1(V self, V *args) {
  V v_i_245 = args[0];
  V v_depth_246 = args[1];
  V v_e_247 = args[2];
  V v_idx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2ebuild_2edriver_2eckOf(v_idx_240));
  return ({ V a_0 = v_t_248; V a_1 = v_idx_240; V a_2 = v_i_245; V a_3 = v_depth_246; V a_4 = v_e_247; V r_ = (g_heff_2ebuild_2edriver_2ecloseTermF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_idx_240); r_; });
}
V g_heff_2ebuild_2edriver_2eimportedFix_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eimportedFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eimportedFix_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eimportedFix(V v_done_240, V v_imps_241) {
top: ;
  return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2eimportedFix_lam0, 2, 1, (V[]){heff_dup(v_done_240)}); V a_1 = heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get()); V b_2 = heff_get_n(v_imps_241, 0, 4); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2edriver_2eimportedFix_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eimportedFix(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2eimportedFix_lam0(V self, V *args) {
  V v_f_242 = args[0];
  V v_i_243 = args[1];
  V v_done_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_groups_244 = heff_take_field(v_f_242, 0);
  V v_above_245 = heff_get_n(v_f_242, 1, 2);
  V v_b_246 = ({ V a_0 = v_done_240; V b_1 = heff_get_n(v_i_243, 0, 3); V r_ = (g_heff_2ebuild_2edriver_2efixOf(a_0, b_1)); heff_drop(v_done_240); heff_drop(b_1); r_; });
  V v_groups_247 = heff_take_field(v_b_246, 0);
  V v_above_248 = heff_get_n(v_b_246, 1, 2);
  V v_t_249 = (g_heff_2esyntax_2efixity_2eappendF(v_groups_244, v_groups_247));
  V v_t_2410 = (g_heff_2esyntax_2efixity_2enubByG(v_t_249));
  V v_t_2411 = (g_heff_2esyntax_2efixity_2eappendF(v_above_245, v_above_248));
  V v_t_2412 = (g_heff_2esyntax_2efixity_2enubByE(v_t_2411));
  return heff_rec_n(2, shape_groups__above, (V[]){v_t_2410, v_t_2412});
}
HEFF_LIT(g_heff_2ebuild_2edriver_2elistedName_str0, 1, "(");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistedName_str1, 1, ")");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistedName_str2, 1, "(");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistedName_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistedName_str4, 1, "(");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistedName_str5, 1, ")");
Clo g_heff_2ebuild_2edriver_2elistedName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2elistedName_entry, 1, 0};

V g_heff_2ebuild_2edriver_2elistedName(V v_x_240) {
top: ;
  if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_240, 0)))) {
    if (((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) ? !(heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)57ULL)) : 1)) {
      V v_t_241 = (g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(v_x_240, MK_INT(0LL)));
      if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
        heff_drop(v_t_241);
        return v_x_240;
      } else {
        heff_drop(v_t_241);
        return heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2elistedName_str0), v_x_240), ((V)&g_heff_2ebuild_2edriver_2elistedName_str1));
      }
    } else {
      return heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2elistedName_str2), v_x_240), ((V)&g_heff_2ebuild_2edriver_2elistedName_str3));
    }
  } else {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2elistedName_str4), v_x_240), ((V)&g_heff_2ebuild_2edriver_2elistedName_str5));
  }
}
V g_heff_2ebuild_2edriver_2elistedName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2elistedName(a[0]);
}
Clo g_heff_2ebuild_2edriver_2eexposedDiagsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eexposedDiagsGo_entry, 4, 0};

V g_heff_2ebuild_2edriver_2eexposedDiagsGo(V v_g_240, V v_own_241, V v_before_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_before_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ebuild_2edriver_2eexposedDiag(heff_dup(v_g_240), v_own_241, v_before_242, heff_dup(v_x_244)));
    V v_t_247 = (g_heff_2ebuild_2edriver_2eexposedDiagsGo(v_g_240, v_own_241, heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, v_before_242}), v_rest_245));
    return (g_heff_2ebuild_2edriver_2eappendD(v_t_246, v_t_247));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2edriver_2eexposedDiagsGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2eexposedDiagsGo(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2edriver_2etwicesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2etwicesGo_entry, 2, 0};

V g_heff_2ebuild_2edriver_2etwicesGo(V v_firsts_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_firsts_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_firsts_240, heff_rfield(v_d_242, 0)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_f_247 = v_field_246;
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_first__again, (V[]){v_f_247, v_d_242}), heff_hole()});
        V v_u_249 = (g_heff_2ebuild_2edriver_2etwicesGo_24dps(v_firsts_240, v_rest_243, heff_dup(v_cell_248)));
        heff_drop(v_u_249);
        return v_cell_248;
      } else {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_field_246);
        V v_t_2410 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_firsts_240, heff_dup(heff_rfield(v_d_242, 0)), v_d_242));
        V t_0 = v_t_2410;
        V t_1 = v_rest_243;
        v_firsts_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2etwicesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2etwicesGo(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2eshowTySx_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eshowTySx_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eshowTySx_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eshowTySx(V v_g_240, V v_t_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_get_n(v_g_240, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  V v_m_243 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_242; V r_ = (g_list_2efoldl_24s1468236620x1316701813(a_0, a_1)); heff_drop(v_t_242); r_; });
  V v_t_2410 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2ebuild_2edriver_2eshowTySx_lam0, 1, 1, (V[]){v_m_243})));
  V v_t_2411 = heff_tr(heff_call(heff_get_n(v_t_2410, 1, 2), 1, (V[]){v_t_241}));
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2411; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(a_0, a_1, a_2, a_3)); heff_drop(v_t_2411); r_; });
}
V g_heff_2ebuild_2edriver_2eshowTySx_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eshowTySx(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2eshowTySx_lam0(V self, V *args) {
  V v_k_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_245 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_k_244)));
  HeffT2 v_t_246 = ({ V a_0 = v_m_243; V a_1 = v_k_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_m_243); heff_drop(v_k_244); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_d_245);
      V v_x_249 = v_field_248;
      return v_x_249;
    } else {
      heff_drop(v_field_248);
      return v_d_245;
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectGo_24cpr_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectGo_24cpr_str1, 4, "-- |");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectGo_24cpr_str2, 8, "-- | >>>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectGo_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectGo_24cpr_str4, 1, "\012");

HeffT2 g_heff_2ebuild_2edriver_2eexpectGo_24cpr(V v_doc_240, V v_src_241, V v_i_242, V v_acc_243) {
top: ;
  V v_doc_244 = heff_dup(v_doc_240);
  V v_src_245 = heff_dup(v_src_241);
  V v_i_246 = heff_dup(v_i_242);
  V v_j_247 = heff_strFind_lent(((V)&g_heff_2ebuild_2edriver_2eexpectGo_24cpr_str0), v_src_245, v_i_246, 1);
  V v_t_248;
  if (heff_intLt_c_lent(v_j_247, MK_INT(0LL), 2)) {
    heff_drop(v_j_247);
    v_t_248 = heff_strLength_lent(v_src_245, 0);
  } else {
    v_t_248 = v_j_247;
  }
  V v_s_249 = heff_strSlice_lent(v_src_245, v_i_246, v_t_248, 4);
  V v_t_2410 = (g_prelude_2eskipSpaces(v_s_249, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_2411 = (heff_unbox_word(heff_strLength_lent(v_s_249, 0)) - ((int64_t)1ULL));
  V v_t_2412 = (g_prelude_2eskipSpaces(v_s_249, heff_box_word(v_t_2411), MK_INT(-1LL)));
  V v_line_2413 = heff_strSlice(v_s_249, v_t_2410, heff_intAdd(v_t_2412, MK_INT(1LL)));
  V v_t_2426;
  if (heff_intLe_c(heff_strLength(v_src_245), v_i_246)) {
    heff_drop(v_doc_244);
    heff_drop(v_line_2413);
    v_t_2426 = NTAG(TAG_Nothing);
  } else {
    if ((heff_dup(v_doc_244) == NTAG(TAG_True))) {
      heff_drop(v_doc_244);
      V v_line_2414 = v_line_2413;
      if (heff_strEq_c(heff_strSlice_lent(v_line_2414, MK_INT(0LL), MK_INT(4LL), 6), ((V)&g_heff_2ebuild_2edriver_2eexpectGo_24cpr_str1))) {
        if (!heff_strEq_c(heff_strSlice_lent(v_line_2414, MK_INT(0LL), MK_INT(8LL), 6), ((V)&g_heff_2ebuild_2edriver_2eexpectGo_24cpr_str2))) {
          V v_s_2415 = heff_strSlice(heff_dup(v_line_2414), MK_INT(4LL), heff_strLength_lent(v_line_2414, 0));
          V v_t_2416 = (g_prelude_2eskipSpaces(v_s_2415, MK_INT(0LL), MK_INT(1LL)));
          int64_t v_t_2417 = (heff_unbox_word(heff_strLength_lent(v_s_2415, 0)) - ((int64_t)1ULL));
          V v_t_2418 = (g_prelude_2eskipSpaces(v_s_2415, heff_box_word(v_t_2417), MK_INT(-1LL)));
          V v_t_2419 = heff_strSlice(v_s_2415, v_t_2416, heff_intAdd(v_t_2418, MK_INT(1LL)));
          V v_x1_2420 = heff_bool(heff_strEq_c_lent(v_t_2419, ((V)&g_heff_2ebuild_2edriver_2eexpectGo_24cpr_str3), 2));
          heff_drop(v_t_2419);
          if (!(heff_dup(v_x1_2420) == NTAG(TAG_True))) {
            heff_drop(v_x1_2420);
            V v_s_2421 = heff_strSlice(heff_dup(v_line_2414), MK_INT(4LL), heff_strLength(v_line_2414));
            V v_t_2422 = (g_prelude_2eskipSpaces(v_s_2421, MK_INT(0LL), MK_INT(1LL)));
            int64_t v_t_2423 = (heff_unbox_word(heff_strLength_lent(v_s_2421, 0)) - ((int64_t)1ULL));
            V v_t_2424 = (g_prelude_2eskipSpaces(v_s_2421, heff_box_word(v_t_2423), MK_INT(-1LL)));
            V v_t_2425 = heff_strSlice(v_s_2421, v_t_2422, heff_intAdd(v_t_2424, MK_INT(1LL)));
            v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2425});
          } else {
            heff_drop(v_line_2414);
            heff_drop(v_x1_2420);
            v_t_2426 = NTAG(TAG_Nothing);
          }
        } else {
          heff_drop(v_line_2414);
          v_t_2426 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_line_2414);
        v_t_2426 = NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_doc_244);
      v_t_2426 = ({ V a_0 = v_line_2413; V r_ = (g_heff_2ebuild_2edriver_2ewatchExpect(a_0)); heff_drop(v_line_2413); r_; });
    }
  }
  switch (heff_tag_of(v_t_2426)) {
  case TAG_Nothing: {
    heff_drop(v_doc_240);
    heff_drop(v_src_241);
    return ((HeffT2){{v_acc_243, v_i_242}});
  }
  case TAG_Just: {
    V v_l_2427 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    V v_x_2428 = heff_strLength_lent(v_src_241, 0);
    V v_j_2429 = heff_strFind_lent(((V)&g_heff_2ebuild_2edriver_2eexpectGo_24cpr_str4), v_src_241, v_i_242, 5);
    V v_t_2430;
    if (heff_intLt_c_lent(v_j_2429, MK_INT(0LL), 2)) {
      heff_drop(v_j_2429);
      v_t_2430 = heff_strLength_lent(v_src_241, 0);
    } else {
      v_t_2430 = v_j_2429;
    }
    V v_y_2431 = heff_intAdd(v_t_2430, MK_INT(1LL));
    V v_t_2432;
    if (heff_intLe_c_lent(v_x_2428, v_y_2431, 0)) {
      heff_drop(v_y_2431);
      v_t_2432 = v_x_2428;
    } else {
      heff_drop(v_x_2428);
      v_t_2432 = v_y_2431;
    }
    V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_l_2427, NTAG(TAG_Nil)});
    V v_t_2434 = (g_prelude_2e_2b_2b(v_acc_243, v_t_2433));
    V t_0 = v_doc_240;
    V t_1 = v_src_241;
    V t_2 = v_t_2432;
    V t_3 = v_t_2434;
    v_doc_240 = t_0;
    v_src_241 = t_1;
    v_i_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
  default: return ((HeffT2){{heff_nomatch(v_t_2426)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectAfter_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectAfter_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectAfter_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectAfter_str3, 1, "\012");
Clo g_heff_2ebuild_2edriver_2eexpectAfter_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eexpectAfter_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eexpectAfter(V v_doc_240, V v_src_241, V v_end_242) {
top: ;
  V v_x_243 = heff_strLength_lent(v_src_241, 0);
  V v_j_244 = heff_strFind_lent(((V)&g_heff_2ebuild_2edriver_2eexpectAfter_str0), v_src_241, v_end_242, 1);
  V v_t_245;
  if (heff_intLt_c_lent(v_j_244, MK_INT(0LL), 2)) {
    heff_drop(v_j_244);
    v_t_245 = heff_strLength_lent(v_src_241, 0);
  } else {
    v_t_245 = v_j_244;
  }
  V v_y_246 = heff_intAdd(v_t_245, MK_INT(1LL));
  V v_x_247 = heff_strLength_lent(v_src_241, 0);
  V v_j_248 = heff_strFind_lent(((V)&g_heff_2ebuild_2edriver_2eexpectAfter_str1), v_src_241, v_end_242, 1);
  V v_t_249;
  if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
    heff_drop(v_j_248);
    v_t_249 = heff_strLength_lent(v_src_241, 0);
  } else {
    v_t_249 = v_j_248;
  }
  V v_y_2410 = heff_intAdd(v_t_249, MK_INT(1LL));
  V v_t_2411;
  if (heff_intLe_c_lent(v_x_247, v_y_2410, 0)) {
    heff_drop(v_y_2410);
    v_t_2411 = v_x_247;
  } else {
    heff_drop(v_x_247);
    v_t_2411 = v_y_2410;
  }
  HeffT2 v_t_2412 = (g_heff_2ebuild_2edriver_2eexpectGo_24cpr(v_doc_240, v_src_241, v_t_2411, NTAG(TAG_Nil)));
  {
    V v_field_2413 = v_t_2412.f[0];
    V v_field_2414 = v_t_2412.f[1];
    V v_t_2420;
    switch (heff_tag_of(v_field_2413)) {
    case TAG_Nil: {
      v_t_2420 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_t_2419;
      switch (heff_tag_of(v_field_2413)) {
      case TAG_Nil: {
        v_t_2419 = ((V)&g_heff_2ebuild_2edriver_2eexpectAfter_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2417 = heff_field(v_field_2413, 0);
        V v_xs_2418 = heff_field(v_field_2413, 1);
        heff_take_n(v_field_2413, 3ULL, 2);
        v_t_2419 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2eexpectAfter_str3); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
        break;
      }
      default: heff_nomatch(v_field_2413);
      }
      v_t_2420 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_field_2413);
    }
    V v_t_2421;
    if (heff_intLe_c_lent(v_x_243, v_y_246, 0)) {
      heff_drop(v_y_246);
      v_t_2421 = v_x_243;
    } else {
      heff_drop(v_x_243);
      v_t_2421 = v_y_246;
    }
    return heff_rec_n(3, shape_expected__from__to, (V[]){v_t_2420, v_t_2421, v_field_2414});
  }
}
V g_heff_2ebuild_2edriver_2eexpectAfter_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2eexpectAfter(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str3, 3, "\012  ");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str4, 8, "-- >>> (");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str5, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str6, 2, ")\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str9, 11, "<abandoned>");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str10, 10, "<diverged>");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str11, 15, "<compiler bug: ");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str12, 1, ">");
V g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2edriver_2ereadExpectation_24cpr(V v_ge_240, V v_g_241, V v_ty_242, V v_e_243) {
top: ;
  V v_ge_244 = v_ge_240;
  V v_g_245 = heff_dup(v_g_241);
  V v_x2_246 = ({ V a_0 = v_e_243; V b_1 = ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str1), v_e_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str3); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str4), v_t_249), ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str5));
  V v_src_2411 = heff_strAppend(heff_strAppend(v_t_2410, v_ty_242), ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str6));
  V v_t_2420 = heff_rec_n(5, shape_known__fixities__lenient__place__path, (V[]){heff_clo_n(g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_lam0, 1, 1, (V[]){v_g_241}), heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get()), NTAG(TAG_False), ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str7), ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str8)});
  V v_t_2421 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_2422 = (g_heff_2esyntax_2efmt_2elex_2elexGo(heff_dup(v_src_2411), v_t_2421, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_r_2423 = (g_heff_2esyntax_2esurface_2ereadLexed(v_src_2411, v_t_2420, v_t_2422));
  V v_diags_2424 = heff_take_field(v_r_2423, 1);
  V v_decls_2425 = heff_get_n(v_r_2423, 0, 5);
  switch (heff_tag_of(v_diags_2424)) {
  case TAG_Nil: {
    V v_t_2426 = heff_rec_n(10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, (V[]){v_g_245, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2427 = (g_list_2emap_24s1960706388x853997965(v_decls_2425));
    HeffT10 v_t_2428 = ({ V a_0 = v_t_2426; V a_1 = v_t_2427; HeffT10 r_ = (g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_24cpr(a_0, a_1)); heff_drop(v_t_2427); r_; });
    {
      V v_field_2430 = v_t_2428.f[1];
      V v_field_2433 = v_t_2428.f[4];
      heff_drop(v_t_2428.f[0]);
      heff_drop(v_t_2428.f[2]);
      heff_drop(v_t_2428.f[3]);
      heff_drop(v_t_2428.f[5]);
      heff_drop(v_t_2428.f[6]);
      heff_drop(v_t_2428.f[7]);
      heff_drop(v_t_2428.f[8]);
      heff_drop(v_t_2428.f[9]);
      switch (heff_tag_of(v_field_2430)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_field_2433)) {
        case TAG_Nil: {
          heff_drop(v_ge_244);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_x_2439 = heff_field(v_field_2433, 0);
          heff_take_n(v_field_2433, 1ULL, 2);
          V v_ge_2441 = v_ge_244;
          V v_entry_2442 = heff_get_n(v_x_2439, 1, 2);
          V v_type_5f_2443 = heff_take_field(v_entry_2442, 3);
          V v_syntax_2444 = heff_get_n(v_entry_2442, 0, 4);
          V v_t_2445 = v_type_5f_2443;
          V v_x1_2446 = heff_tr(g_heff_2ecompile_2einterp_2efixThunk(v_ge_2441, v_syntax_2444, MK_INT(0LL)));
          V v_t_2447 = (g_heff_2eelab_2evalue_2ebehavior(v_t_2445));
          V v_t_2448 = (g_heff_2ebuild_2edriver_2etypeArgsOf(MK_INT(0LL), v_t_2447));
          V v_t_2451;
          switch (heff_tag_of(v_x1_2446)) {
          case TAG_Ok: {
            V v_v_2449 = heff_field(v_x1_2446, 0);
            V v_ru_24x1_2446_24Ok = heff_take_reuse_n(v_x1_2446, 1ULL, 1);
            v_t_2451 = heff_tag_at_n(v_ru_24x1_2446_24Ok, TAG_RSucceeded, 1, (V[]){v_v_2449});
            break;
          }
          case TAG_Abn: {
            v_t_2451 = NTAG(TAG_RAbandoned);
            break;
          }
          case TAG_Div: {
            v_t_2451 = NTAG(TAG_RDiverged);
            break;
          }
          case TAG_Bug: {
            V v_what_2450 = heff_field(v_x1_2446, 0);
            V v_ru_24x1_2446_24Bug = heff_take_reuse_n(v_x1_2446, 1ULL, 1);
            v_t_2451 = heff_tag_at_n(v_ru_24x1_2446_24Bug, TAG_RBug, 1, (V[]){v_what_2450});
            break;
          }
          default: heff_nomatch(v_x1_2446);
          }
          V v_x1_2452 = (g_heff_2ecompile_2einterp_2eapplyErased(v_t_2448, v_t_2451));
          V v_f_2455;
          switch (heff_tag_of(v_x1_2452)) {
          case TAG_RSucceeded: {
            V v_v_2453 = heff_field(v_x1_2452, 0);
            V v_ru_24x1_2452_24RSucceeded = heff_take_reuse_n(v_x1_2452, 1ULL, 1);
            v_f_2455 = ({ V a_0 = v_ru_24x1_2452_24RSucceeded; V b_1 = NTAG(TAG_False); V a_2 = v_v_2453; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo_24tok1(a_0, b_1, a_2)); heff_drop(b_1); r_; });
            break;
          }
          case TAG_RAbandoned: {
            v_f_2455 = ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str9);
            break;
          }
          case TAG_RDiverged: {
            v_f_2455 = ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str10);
            break;
          }
          case TAG_RBug: {
            V v_what_2454 = heff_field(v_x1_2452, 0);
            heff_take_n(v_x1_2452, 1ULL, 1);
            v_f_2455 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str11), v_what_2454), ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_str12));
            break;
          }
          default: heff_nomatch(v_x1_2452);
          }
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2455}});
        }
        default: return ((HeffT2){{heff_nomatch(v_field_2433)}});
        }
      }
      case TAG_Cons: {
        heff_take_n(v_field_2430, 0ULL, 2);
        heff_drop(v_ge_244);
        heff_drop(v_field_2433);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_field_2430)}});
      }
    }
  }
  case TAG_Cons: {
    heff_take_n(v_diags_2424, 0ULL, 2);
    heff_drop(v_ge_244);
    heff_drop(v_g_245);
    heff_drop(v_decls_2425);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_diags_2424)}});
  }
}
V g_heff_2ebuild_2edriver_2ereadExpectation_24cpr_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT3 v_t_2413 = (g_heff_2eelab_2eglobals_2eresolve_24cpr(v_g_241, v_x_2412));
  {
    V v_field_2415 = v_t_2413.f[1];
    V v_field_2416 = v_t_2413.f[2];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2414 == ((int64_t)0ULL)) ? ({ V v_x_2417 = heff_dup(v_field_2415); int c_ = 1; heff_drop(v_x_2417); c_; }) : ((v_tag_2414 == ((int64_t)1ULL)) || ((v_tag_2414 == ((int64_t)2ULL)) && ({ V v_x_2418 = heff_dup(v_field_2415); int c_ = ({ V v_x_2419 = heff_dup(v_field_2416); int c_ = 1; heff_drop(v_x_2419); c_; }); heff_drop(v_x_2418); c_; })))));
    heff_drop(v_field_2415);
    heff_drop(v_field_2416);
    return v_ret_24bool;
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalPick_str0, 11, "<abandoned>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalPick_str1, 10, "<diverged>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalPick_str2, 15, "<compiler bug: ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalPick_str3, 1, ">");
Clo g_heff_2ebuild_2edriver_2eevalPick_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eevalPick_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eevalPick(V v_g_240, V v_results_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_key_245 = heff_take_field(v_o_243, 1);
    V v_name_246 = heff_get_n(v_o_243, 0, 2);
    HeffT2 v_t_247 = (g_list_2elookup_24s1507486579x90027037_24cpr(v_key_245, v_results_241));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_r_2410 = v_field_249;
        V v_g_2411 = heff_dup(v_g_240);
        V v_entries_2412 = heff_take_field(v_g_2411, 1);
        V v_aliases_2413 = heff_get_n(v_g_2411, 2, 8);
        V v_k_2414 = v_key_245;
        V v_r_2415 = v_r_2410;
        HeffT2 v_t_2416 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_2412, v_k_2414));
        V v_it_2432;
        {
          V v_field_2418 = v_t_2416.f[1];
          int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
          if ((v_tag_2417 == ((int64_t)0ULL))) {
            heff_drop(v_entries_2412);
            heff_drop(v_aliases_2413);
            heff_drop(v_k_2414);
            V v_e_2419 = v_field_2418;
            V v_t_2420 = (g_heff_2eelab_2evalue_2ebehavior(heff_get_n(v_e_2419, 3, 4)));
            V v_t_2421 = (g_heff_2ebuild_2edriver_2etypeArgsOf(MK_INT(0LL), v_t_2420));
            v_it_2432 = (g_heff_2ecompile_2einterp_2eapplyErased(v_t_2421, v_r_2415));
          } else {
            heff_drop(v_field_2418);
            HeffT2 v_t_2422 = ({ V a_0 = v_aliases_2413; V a_1 = v_k_2414; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_2413); heff_drop(v_k_2414); r_; });
            {
              V v_field_2424 = v_t_2422.f[1];
              int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
              if ((v_tag_2423 == ((int64_t)0ULL))) {
                V v_k2_2425 = v_field_2424;
                HeffT2 v_t_2426 = ({ V a_0 = v_entries_2412; V a_1 = v_k2_2425; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_2412); heff_drop(v_k2_2425); r_; });
                {
                  V v_field_2428 = v_t_2426.f[1];
                  int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
                  if ((v_tag_2427 == ((int64_t)0ULL))) {
                    V v_e_2429 = v_field_2428;
                    V v_t_2430 = (g_heff_2eelab_2evalue_2ebehavior(heff_get_n(v_e_2429, 3, 4)));
                    V v_t_2431 = (g_heff_2ebuild_2edriver_2etypeArgsOf(MK_INT(0LL), v_t_2430));
                    v_it_2432 = (g_heff_2ecompile_2einterp_2eapplyErased(v_t_2431, v_r_2415));
                  } else {
                    heff_drop(v_field_2428);
                    v_it_2432 = v_r_2415;
                  }
                }
              } else {
                heff_drop(v_entries_2412);
                heff_drop(v_field_2424);
                v_it_2432 = v_r_2415;
              }
            }
          }
        }
        V v_t_2433 = (g_heff_2esyntax_2esurfaceprint_2enamed(v_name_246));
        V v_t_2436;
        switch (heff_tag_of(v_it_2432)) {
        case TAG_RSucceeded: {
          V v_v_2434 = heff_dup(heff_field(v_it_2432, 0));
          v_t_2436 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_v_2434; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
          break;
        }
        case TAG_RAbandoned: {
          v_t_2436 = ((V)&g_heff_2ebuild_2edriver_2eevalPick_str0);
          break;
        }
        case TAG_RDiverged: {
          v_t_2436 = ((V)&g_heff_2ebuild_2edriver_2eevalPick_str1);
          break;
        }
        case TAG_RBug: {
          V v_what_2435 = heff_dup(heff_field(v_it_2432, 0));
          v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eevalPick_str2), v_what_2435), ((V)&g_heff_2ebuild_2edriver_2eevalPick_str3));
          break;
        }
        default: heff_nomatch(v_it_2432);
        }
        V v_t_2439;
        switch (heff_tag_of(v_it_2432)) {
        case TAG_RSucceeded: {
          heff_take_n(v_it_2432, 0ULL, 1);
          v_t_2439 = NTAG(TAG_False);
          break;
        }
        case TAG_RAbandoned: {
          v_t_2439 = NTAG(TAG_False);
          break;
        }
        case TAG_RDiverged: {
          v_t_2439 = NTAG(TAG_False);
          break;
        }
        case TAG_RBug: {
          heff_take_n(v_it_2432, 0ULL, 1);
          v_t_2439 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_it_2432);
        }
        V v_cell_2440 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__value__bug, (V[]){v_t_2433, v_t_2436, v_t_2439}), heff_hole()});
        V v_u_2441 = (g_heff_2ebuild_2edriver_2eevalPick_24dps(v_g_240, v_results_241, v_rest_244, heff_dup(v_cell_2440)));
        heff_drop(v_u_2441);
        return v_cell_2440;
      } else {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_key_245);
        heff_drop(v_name_246);
        heff_drop(v_field_249);
        V t_0 = v_g_240;
        V t_1 = v_results_241;
        V t_2 = v_rest_244;
        v_g_240 = t_0;
        v_results_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2eevalPick_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2eevalPick(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edriver_2ebenchesOf_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2ebenchesOf_lam2(V self, V *args);
V g_heff_2ebuild_2edriver_2ebenchesOf_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ebenchesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ebenchesOf_entry, 1, 0};

V g_heff_2ebuild_2edriver_2ebenchesOf(V v_c_240) {
top: ;
  V v_all_2420 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edriver_2ebenchesOf_lam0, 1, 1, (V[]){heff_dup(v_c_240)}), heff_dup(heff_rfield(v_c_240, 7))));
  return (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edriver_2ebenchesOf_lam1, 1, 2, (V[]){v_c_240, heff_dup(v_all_2420)}), v_all_2420));
}
V g_heff_2ebuild_2edriver_2ebenchesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ebenchesOf(a[0]);
}
V g_heff_2ebuild_2edriver_2ebenchesOf_lam0(V self, V *args) {
  V v_o_241 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_242 = v_c_240;
  V v_o_243 = v_o_241;
  V v_g_244 = heff_get_n(heff_get_n(v_c_242, 5, 14), 0, 10);
  V v_entries_245 = heff_take_field(v_g_244, 1);
  V v_aliases_246 = heff_get_n(v_g_244, 2, 8);
  V v_k_247 = heff_get_n(v_o_243, 1, 2);
  HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_245, v_k_247));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      heff_drop(v_entries_245);
      heff_drop(v_aliases_246);
      heff_drop(v_k_247);
      V v_e_2411 = v_field_2410;
      return ({ V b_0 = heff_get_n(v_e_2411, 1, 4); V r_ = (g_heff_2ebuild_2edriver_2eisBenchTy(b_0)); heff_drop(b_0); r_; });
    } else {
      heff_drop(v_field_2410);
      HeffT2 v_t_2412 = ({ V a_0 = v_aliases_246; V a_1 = v_k_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_246); heff_drop(v_k_247); r_; });
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_k2_2415 = v_field_2414;
          HeffT2 v_t_2416 = ({ V a_0 = v_entries_245; V a_1 = v_k2_2415; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_245); heff_drop(v_k2_2415); r_; });
          {
            V v_field_2418 = v_t_2416.f[1];
            int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
            if ((v_tag_2417 == ((int64_t)0ULL))) {
              V v_e_2419 = v_field_2418;
              return ({ V b_0 = heff_get_n(v_e_2419, 1, 4); V r_ = (g_heff_2ebuild_2edriver_2eisBenchTy(b_0)); heff_drop(b_0); r_; });
            } else {
              heff_drop(v_field_2418);
              return NTAG(TAG_False);
            }
          }
        } else {
          heff_drop(v_entries_245);
          heff_drop(v_field_2414);
          return NTAG(TAG_False);
        }
      }
    }
  }
}
V g_heff_2ebuild_2edriver_2ebenchesOf_lam2(V self, V *args) {
  V v_t_2422 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_o_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = (g_heff_2ebuild_2edriver_2eownUses(heff_dup(v_c_240), heff_rfield(v_t_2422, 1)));
  V v_t_2424 = (g_heff_2ebuild_2edriver_2ereachOwn(v_c_240, NTAG(TAG_Nil), v_t_2423));
  V v_t_2425 = (g_list_2ekeepIf_24s1823913665x1128491553(v_t_2422, v_t_2424));
  return ({ V a_0 = v_o_2421; V a_1 = v_t_2425; V r_ = (g_list_2eany_24s108509638x1972721376(a_0, a_1)); heff_drop(v_t_2425); r_; });
}
V g_heff_2ebuild_2edriver_2ebenchesOf_lam1(V self, V *args) {
  V v_o_2421 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_all_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2426 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ebenchesOf_lam2, 1, 2, (V[]){v_c_240, v_o_2421}); V a_1 = v_all_2420; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_all_2420); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2426) == NTAG(TAG_True)));
  heff_drop(v_x1_2426);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2epickIntegrations_str0, 20, "> test integrations ");
Clo g_heff_2ebuild_2edriver_2epickIntegrations_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2epickIntegrations_entry, 3, 0};

V g_heff_2ebuild_2edriver_2epickIntegrations(V v_rs_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2epickIntegrations_str0), heff_intShow(heff_dup(v_i_241)));
    HeffT2 v_t_246 = ({ V a_0 = v_t_245; V a_1 = v_rs_240; HeffT2 r_ = (g_list_2elookup_24s1507486579x90027037_24cpr(a_0, a_1)); heff_drop(v_t_245); r_; });
    V v_t_2413;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_r_249 = v_field_248;
        switch (heff_tag_of(v_r_249)) {
        case TAG_RSucceeded: {
          V v_v_2410 = heff_field(v_r_249, 0);
          heff_take_n(v_r_249, 1ULL, 1);
          V v_t_2411 = ({ V a_0 = v_v_2410; V r_ = (g_heff_2ebuild_2edriver_2elistOfV(a_0)); heff_drop(v_v_2410); r_; });
          v_t_2413 = (g_list_2emap_24s588468714x1874323009(v_t_2411));
          break;
        }
        case TAG_RAbandoned: {
          v_t_2413 = NTAG(TAG_Nil);
          break;
        }
        case TAG_RDiverged: {
          v_t_2413 = NTAG(TAG_Nil);
          break;
        }
        case TAG_RBug: {
          heff_take_n(v_r_249, 0ULL, 1);
          v_t_2413 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_r_249);
        }
      } else {
        heff_drop(v_field_248);
        v_t_2413 = NTAG(TAG_Nil);
      }
    }
    V v_t_2414 = (g_heff_2ebuild_2edriver_2epickIntegrations(v_rs_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_rest_244));
    return (g_prelude_2e_2b_2b(v_t_2413, v_t_2414));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2epickIntegrations_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2epickIntegrations(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str0, 6, "infixl");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str1, 6, "infixr");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str2, 5, "infix");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str5, 1, " ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str8, 1, " ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str9, 7, " above ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str12, 1, " ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str13, 7, " below ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str14, 6, " below");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str16, 1, "\012");
V g_heff_2ebuild_2edriver_2efixityLine_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2efixityLine_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2efixityLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efixityLine_entry, 3, 0};

V g_heff_2ebuild_2edriver_2efixityLine(V v_fx_240, V v_i_241, V v_g_242) {
top: ;
  V v_assoc_243 = heff_take_field(v_g_242, 1);
  V v_ops_244 = heff_take_field(v_g_242, 2);
  V v_id_245 = heff_take_field(v_g_242, 0);
  V v_loosest_246 = heff_get_n(v_g_242, 3, 5);
  V v_groups_247 = heff_take_field(v_fx_240, 0);
  V v_above_248 = heff_get_n(v_fx_240, 1, 2);
  V v_t_249;
  switch (heff_tag_of(v_assoc_243)) {
  case TAG_AssocLeft: {
    v_t_249 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str0);
    break;
  }
  case TAG_AssocRight: {
    v_t_249 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str1);
    break;
  }
  case TAG_AssocNone: {
    v_t_249 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str2);
    break;
  }
  default: heff_nomatch(v_assoc_243);
  }
  V v_t_2412;
  switch (heff_tag_of(v_ops_244)) {
  case TAG_Nil: {
    v_t_2412 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_ops_244, 0);
    V v_xs_2411 = heff_field(v_ops_244, 1);
    heff_take_n(v_ops_244, 3ULL, 2);
    v_t_2412 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str4); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
    break;
  }
  default: heff_nomatch(v_ops_244);
  }
  V v_t_2413 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2edriver_2efixityLine_str5)), v_t_2412);
  V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2efixityLine_lam0, 1, 3, (V[]){heff_dup(v_id_245), heff_dup(v_groups_247), heff_dup(v_i_241)}), heff_dup(v_above_248)));
  V v_t_2419 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2418));
  V v_ops_2420 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2419));
  V v_t_2426;
  switch (heff_tag_of(v_ops_2420)) {
  case TAG_Nil: {
    v_t_2426 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str6);
    break;
  }
  case TAG_Cons: {
    V v_t_2425;
    switch (heff_tag_of(v_ops_2420)) {
    case TAG_Nil: {
      v_t_2425 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_ops_2420, 0);
      V v_xs_2424 = heff_field(v_ops_2420, 1);
      heff_take_n(v_ops_2420, 3ULL, 2);
      v_t_2425 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str8); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
      break;
    }
    default: heff_nomatch(v_ops_2420);
    }
    v_t_2426 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2efixityLine_str9), v_t_2425);
    break;
  }
  default: heff_nomatch(v_ops_2420);
  }
  V v_t_2431 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2efixityLine_lam1, 1, 3, (V[]){v_id_245, v_groups_247, v_i_241}), v_above_248));
  V v_t_2432 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2431));
  V v_ops_2433 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2432));
  V v_t_2439;
  switch (heff_tag_of(v_ops_2433)) {
  case TAG_Nil: {
    v_t_2439 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str10);
    break;
  }
  case TAG_Cons: {
    V v_t_2438;
    switch (heff_tag_of(v_ops_2433)) {
    case TAG_Nil: {
      v_t_2438 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str11);
      break;
    }
    case TAG_Cons: {
      V v_x_2436 = heff_field(v_ops_2433, 0);
      V v_xs_2437 = heff_field(v_ops_2433, 1);
      heff_take_n(v_ops_2433, 3ULL, 2);
      v_t_2438 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str12); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
      break;
    }
    default: heff_nomatch(v_ops_2433);
    }
    v_t_2439 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2efixityLine_str13), v_t_2438);
    break;
  }
  default: heff_nomatch(v_ops_2433);
  }
  V v_t_2440 = heff_strAppend(heff_strAppend(v_t_2413, v_t_2426), v_t_2439);
  V v_t_2441;
  if ((heff_dup(v_loosest_246) == NTAG(TAG_True))) {
    heff_drop(v_loosest_246);
    v_t_2441 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str14);
  } else {
    heff_drop(v_loosest_246);
    v_t_2441 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str15);
  }
  return heff_strAppend(heff_strAppend(v_t_2440, v_t_2441), ((V)&g_heff_2ebuild_2edriver_2efixityLine_str16));
}
V g_heff_2ebuild_2edriver_2efixityLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2efixityLine(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edriver_2efixityLine_lam0(V self, V *args) {
  V v_e_2414 = args[0];
  V v_id_245 = heff_env(self)[0];
  V v_groups_247 = heff_env(self)[1];
  V v_i_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_tighter_2415 = heff_take_field(v_e_2414, 0);
  V v_looser_2416 = heff_get_n(v_e_2414, 1, 2);
  if (heff_strEq_c(v_tighter_2415, v_id_245)) {
    V v_t_2417 = ({ V a_0 = v_groups_247; V a_1 = v_i_241; V a_2 = v_looser_2416; V a_3 = MK_INT(0LL); V r_ = (g_heff_2ebuild_2edriver_2eearlierGo(a_0, a_1, a_2, a_3)); heff_drop(v_groups_247); r_; });
    if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
      heff_drop(v_t_2417);
      return heff_tag_n(TAG_Just, 1, (V[]){v_looser_2416});
    } else {
      heff_drop(v_looser_2416);
      heff_drop(v_t_2417);
      return NTAG(TAG_Nothing);
    }
  } else {
    heff_drop(v_groups_247);
    heff_drop(v_i_241);
    heff_drop(v_looser_2416);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2edriver_2efixityLine_lam1(V self, V *args) {
  V v_e_2427 = args[0];
  V v_id_245 = heff_env(self)[0];
  V v_groups_247 = heff_env(self)[1];
  V v_i_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_looser_2428 = heff_take_field(v_e_2427, 1);
  V v_tighter_2429 = heff_get_n(v_e_2427, 0, 2);
  if (heff_strEq_c(v_looser_2428, v_id_245)) {
    V v_t_2430 = ({ V a_0 = v_groups_247; V a_1 = v_i_241; V a_2 = v_tighter_2429; V a_3 = MK_INT(0LL); V r_ = (g_heff_2ebuild_2edriver_2eearlierGo(a_0, a_1, a_2, a_3)); heff_drop(v_groups_247); r_; });
    if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
      heff_drop(v_t_2430);
      return heff_tag_n(TAG_Just, 1, (V[]){v_tighter_2429});
    } else {
      heff_drop(v_tighter_2429);
      heff_drop(v_t_2430);
      return NTAG(TAG_Nothing);
    }
  } else {
    heff_drop(v_groups_247);
    heff_drop(v_i_241);
    heff_drop(v_tighter_2429);
    return NTAG(TAG_Nothing);
  }
}
Clo g_heff_2ebuild_2edriver_2eappendLv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eappendLv_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eappendLv(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2ebuild_2edriver_2eappendLv_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eappendLv_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eappendLv(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2eappendLv_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eappendLv_24dps_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eappendLv_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eappendLv_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eappendLv_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecandLeaves_entry, 1, 0};

V g_heff_2ebuild_2edriver_2ecandLeaves(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = (g_heff_2eelab_2eeffect_2eleaves(heff_rfield(v_r_241, 2)));
    V v_t_244 = (g_heff_2ebuild_2edriver_2ecandLeaves(v_rest_242));
    return (g_heff_2ebuild_2edriver_2eappendLv(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2ecandLeaves(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2efindRunnable_24cpr_str0, 32, "no computation, `Co h a`, to run");
HEFF_LIT(g_heff_2ebuild_2edriver_2efindRunnable_24cpr_str1, 31, " is not a computation, `Co h a`");
HEFF_LIT(g_heff_2ebuild_2edriver_2efindRunnable_24cpr_str2, 14, "no definition ");
V g_heff_2ebuild_2edriver_2efindRunnable_24cpr_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2efindRunnable_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2edriver_2efindRunnable_24cpr(V v_handled_240, V v_c_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_handled_243 = v_handled_240;
    V v_cands_244 = (g_heff_2ebuild_2edriver_2ecandidatesOf(v_c_241));
    HeffT2 v_t_2413 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2ebuild_2edriver_2efindRunnable_24cpr_lam0, 1, 1, (V[]){heff_dup(v_handled_243)}), v_cands_244));
    {
      V v_field_2415 = v_t_2413.f[1];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        heff_drop(v_handled_243);
        heff_drop(v_cands_244);
        V v_r_2416 = v_field_2415;
        V v_key_2417 = heff_take_field(v_r_2416, 1);
        V v_effect_2418 = heff_get_n(v_r_2416, 2, 3);
        V v_f_2419 = heff_rec_n(2, shape_key__effect, (V[]){v_key_2417, v_effect_2418});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2419}});
      } else {
        heff_drop(v_field_2415);
        switch (heff_tag_of(v_cands_244)) {
        case TAG_Nil: {
          heff_drop(v_handled_243);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2edriver_2efindRunnable_24cpr_str0)}});
        }
        case TAG_Cons: {
          V v_x_2420 = heff_field(v_cands_244, 0);
          heff_take_n(v_cands_244, 1ULL, 2);
          return ({ V a_0 = v_handled_243; V a_1 = v_x_2420; HeffT2 r_ = (g_heff_2ebuild_2edriver_2efits_24cpr(a_0, a_1)); heff_drop(v_handled_243); r_; });
        }
        default: return ((HeffT2){{heff_nomatch(v_cands_244)}});
        }
      }
    }
  }
  case TAG_Just: {
    V v_x_2422 = heff_field(v_x3_242, 0);
    HeffT2 v_t_2423 = (g_list_2efind_24s279352081x1530195138_24cpr(v_x_2422, heff_rfield(v_c_241, 7)));
    {
      V v_field_2425 = v_t_2423.f[1];
      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
      if ((v_tag_2424 == ((int64_t)0ULL))) {
        V v_o_2426 = v_field_2425;
        HeffT2 v_t_2427 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(v_c_241, heff_rfield(v_o_2426, 1)));
        {
          V v_field_2429 = v_t_2427.f[1];
          int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
          if ((v_tag_2428 == ((int64_t)0ULL))) {
            V v_eff_2430 = v_field_2429;
            V v_t_2431 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_dup(v_x_2422), heff_get_n(v_o_2426, 1, 2), v_eff_2430});
            return ({ V a_0 = v_handled_240; V a_1 = v_t_2431; HeffT2 r_ = (g_heff_2ebuild_2edriver_2efits_24cpr(a_0, a_1)); heff_drop(v_handled_240); r_; });
          } else {
            heff_drop(v_handled_240);
            heff_drop_rec(v_o_2426, 2);
            heff_drop(v_field_2429);
            V v_f_2432 = heff_strAppend(heff_dup(v_x_2422), ((V)&g_heff_2ebuild_2edriver_2efindRunnable_24cpr_str1));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2432}});
          }
        }
      } else {
        heff_drop(v_handled_240);
        heff_drop_rec(v_c_241, 14);
        heff_drop(v_field_2425);
        V v_f_2433 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2efindRunnable_24cpr_str2), heff_dup(v_x_2422));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2433}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2ebuild_2edriver_2efindRunnable_24cpr_lam1(V self, V *args) {
  V v_l_247 = args[0];
  V v_handled_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_248 = ({ V a_0 = v_l_247; V a_1 = v_handled_243; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_l_247); heff_drop(v_handled_243); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_248) == NTAG(TAG_True)));
  heff_drop(v_x1_248);
  return v_ret_24bool;
}
V g_heff_2ebuild_2edriver_2efindRunnable_24cpr_lam0(V self, V *args) {
  V v_r_245 = args[0];
  V v_handled_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = ({ V b_0 = heff_get_n(v_r_245, 2, 3); V r_ = (g_heff_2eelab_2eeffect_2eleaves(b_0)); heff_drop(b_0); r_; });
  V v_t_249 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edriver_2efindRunnable_24cpr_lam1, 1, 1, (V[]){v_handled_243}), v_t_246));
  V v_x1_2410 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_249));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2410, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_2410);
  }
}