// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2efmt_2elex_2ekeywords_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 102, 105, 120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2efmt_2elex_2ekeywords_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 102, 105, 120, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2efmt_2elex_2ekeywords_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 102, 105, 120, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2efmt_2elex_2ekeywords_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {65, 114, 114, 97, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2efmt_2elex_2ekeywords_str4 = {{0x80000000u, K_STR, 0}, 7, 7, {97, 98, 97, 110, 100, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2efmt_2elex_2ekeywords_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2efmt_2elex_2ekeywords_str6 = {{0x80000000u, K_STR, 0}, 6, 6, {83, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2efmt_2elex_2ekeywords_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2efmt_2elex_2ekeywords_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2efmt_2elex_2ekeywords_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2efmt_2elex_2ekeywords_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 101, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2efmt_2elex_2ekeywords_str11 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 104, 101, 114, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2efmt_2elex_2ekeywords_str12 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2efmt_2elex_2ekeywords_str13 = {{0x80000000u, K_STR, 0}, 4, 4, {101, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2efmt_2elex_2ekeywords_str14 = {{0x80000000u, K_STR, 0}, 2, 2, {100, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2efmt_2elex_2ekeywords_str15 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2efmt_2elex_2ekeywords_str16 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 104, 101, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2efmt_2elex_2ekeywords_str17 = {{0x80000000u, K_STR, 0}, 4, 4, {99, 97, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2efmt_2elex_2ekeywords_str18 = {{0x80000000u, K_STR, 0}, 2, 2, {111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2efmt_2elex_2ekeywords_str19 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 111, 114, 101, 105, 103, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2efmt_2elex_2ekeywords_str20 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 109, 112, 111, 114, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2efmt_2elex_2ekeywords_str21 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2efmt_2elex_2ekeywords_str22 = {{0x80000000u, K_STR, 0}, 6, 6, {116, 104, 101, 111, 114, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2efmt_2elex_2ekeywords_str23 = {{0x80000000u, K_STR, 0}, 4, 4, {100, 97, 116, 97}};

static V g_heff_2efmt_2elex_2ekeywords_val;
static int g_heff_2efmt_2elex_2ekeywords_st;
static V g_heff_2efmt_2elex_2ekeywords_init(void) {
  V v_t_240 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str2), v_t_240})});
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str4), v_t_241})});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str6), v_t_242})});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str8), v_t_243})});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str9), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str10), v_t_244})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str11), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str12), v_t_245})});
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str13), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str14), v_t_246})});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str15), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str16), v_t_247})});
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str17), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str18), v_t_248})});
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str19), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str20), v_t_249})});
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str21), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str22), v_t_2410})});
  return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2ekeywords_str23), v_t_2411});
}
V g_heff_2efmt_2elex_2ekeywords_get(void) {
  if (g_heff_2efmt_2elex_2ekeywords_st == 2) return g_heff_2efmt_2elex_2ekeywords_val;
  if (g_heff_2efmt_2elex_2ekeywords_st == 1) heff_fail("defined by itself");
  g_heff_2efmt_2elex_2ekeywords_st = 1;
  g_heff_2efmt_2elex_2ekeywords_val = heff_tr(g_heff_2efmt_2elex_2ekeywords_init());
  g_heff_2efmt_2elex_2ekeywords_st = 2;
  return g_heff_2efmt_2elex_2ekeywords_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2efmt_2elex_2esymChars_str0 = {{0x80000000u, K_STR, 0}, 20, 20, {33, 35, 36, 37, 38, 42, 43, 46, 47, 60, 61, 62, 63, 64, 92, 94, 124, 45, 126, 58}};

static V g_heff_2efmt_2elex_2esymChars_val;
static int g_heff_2efmt_2elex_2esymChars_st;
static V g_heff_2efmt_2elex_2esymChars_init(void) {
  return ((V)&g_heff_2efmt_2elex_2esymChars_str0);
}
V g_heff_2efmt_2elex_2esymChars_get(void) {
  if (g_heff_2efmt_2elex_2esymChars_st == 2) return g_heff_2efmt_2elex_2esymChars_val;
  if (g_heff_2efmt_2elex_2esymChars_st == 1) heff_fail("defined by itself");
  g_heff_2efmt_2elex_2esymChars_st = 1;
  g_heff_2efmt_2elex_2esymChars_val = heff_tr(g_heff_2efmt_2elex_2esymChars_init());
  g_heff_2efmt_2elex_2esymChars_st = 2;
  return g_heff_2efmt_2elex_2esymChars_val;
}
Clo g_heff_2efmt_2elex_2eisNameC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elex_2eisNameC_entry, 1, 0};

V g_heff_2efmt_2elex_2eisNameC(V v_c_240) {
top: ;
  V v_t_241 = heff_intLe(MK_INT(97LL), heff_dup(v_c_240));
  V v_t_243;
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    V v_t_242 = heff_intLe(heff_dup(v_c_240), MK_INT(122LL));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      v_t_243 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      v_t_243 = heff_intEq(heff_dup(v_c_240), MK_INT(95LL));
      break;
    }
    default: heff_nomatch(v_t_242);
    }
    break;
  }
  case TAG_False: {
    v_t_243 = heff_intEq(heff_dup(v_c_240), MK_INT(95LL));
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_c_240);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    V v_t_244 = heff_intLe(MK_INT(65LL), heff_dup(v_c_240));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V v_t_245 = heff_intLe(heff_dup(v_c_240), MK_INT(90LL));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        heff_drop(v_c_240);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V v_t_246 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
        switch (heff_tag_of(v_t_246)) {
        case TAG_True: {
          V v_t_247 = heff_intLe(heff_dup(v_c_240), MK_INT(57LL));
          switch (heff_tag_of(v_t_247)) {
          case TAG_True: {
            heff_drop(v_c_240);
            return NTAG(TAG_True);
          }
          case TAG_False: {
            return heff_intEq(v_c_240, MK_INT(39LL));
          }
          default: return heff_nomatch(v_t_247);
          }
        }
        case TAG_False: {
          return heff_intEq(v_c_240, MK_INT(39LL));
        }
        default: return heff_nomatch(v_t_246);
        }
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    case TAG_False: {
      V v_t_248 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        V v_t_249 = heff_intLe(heff_dup(v_c_240), MK_INT(57LL));
        switch (heff_tag_of(v_t_249)) {
        case TAG_True: {
          heff_drop(v_c_240);
          return NTAG(TAG_True);
        }
        case TAG_False: {
          return heff_intEq(v_c_240, MK_INT(39LL));
        }
        default: return heff_nomatch(v_t_249);
        }
      }
      case TAG_False: {
        return heff_intEq(v_c_240, MK_INT(39LL));
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2efmt_2elex_2eisNameC_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elex_2eisNameC(a[0]);
}
Clo g_heff_2efmt_2elex_2enameEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elex_2enameEnd_entry, 2, 0};

V g_heff_2efmt_2elex_2enameEnd(V v_s_240, V v_j_241) {
top: ;
  V v_t_242 = (g_heff_2efmt_2elex_2eisNameC(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_241))));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  }
  case TAG_False: {
    V v_t_243 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(47LL));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V v_c_244 = heff_strCharCode(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
      V v_t_245 = heff_intLe(MK_INT(97LL), heff_dup(v_c_244));
      V v_t_247;
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        V v_t_246 = heff_intLe(heff_dup(v_c_244), MK_INT(122LL));
        switch (heff_tag_of(v_t_246)) {
        case TAG_True: {
          v_t_247 = NTAG(TAG_True);
          break;
        }
        case TAG_False: {
          v_t_247 = heff_intEq(heff_dup(v_c_244), MK_INT(95LL));
          break;
        }
        default: heff_nomatch(v_t_246);
        }
        break;
      }
      case TAG_False: {
        v_t_247 = heff_intEq(heff_dup(v_c_244), MK_INT(95LL));
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_c_244);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      }
      case TAG_False: {
        V v_t_248 = heff_intLe(MK_INT(65LL), heff_dup(v_c_244));
        switch (heff_tag_of(v_t_248)) {
        case TAG_True: {
          V v_t_249 = heff_intLe(v_c_244, MK_INT(90LL));
          switch (heff_tag_of(v_t_249)) {
          case TAG_True: {
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
            v_s_240 = t_0;
            v_j_241 = t_1;
            goto top;
          }
          case TAG_False: {
            heff_drop(v_s_240);
            return v_j_241;
          }
          default: return heff_nomatch(v_t_249);
          }
        }
        case TAG_False: {
          heff_drop(v_s_240);
          heff_drop(v_c_244);
          return v_j_241;
        }
        default: return heff_nomatch(v_t_248);
        }
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    case TAG_False: {
      heff_drop(v_s_240);
      return v_j_241;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2efmt_2elex_2enameEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elex_2enameEnd(a[0], a[1]);
}
Clo g_heff_2efmt_2elex_2eplainEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elex_2eplainEnd_entry, 2, 0};

V g_heff_2efmt_2elex_2eplainEnd(V v_s_240, V v_j_241) {
top: ;
  V v_t_242 = (g_heff_2efmt_2elex_2eisNameC(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_241))));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  }
  case TAG_False: {
    heff_drop(v_s_240);
    return v_j_241;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2efmt_2elex_2eplainEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elex_2eplainEnd(a[0], a[1]);
}
Clo g_heff_2efmt_2elex_2edigitsEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elex_2edigitsEnd_entry, 2, 0};

V g_heff_2efmt_2elex_2edigitsEnd(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_241));
  V v_t_243 = heff_intLe(MK_INT(48LL), heff_dup(v_c_242));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_t_244 = heff_intLe(v_c_242, MK_INT(57LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_j_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_s_240);
      return v_j_241;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_False: {
    heff_drop(v_s_240);
    heff_drop(v_c_242);
    return v_j_241;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2efmt_2elex_2edigitsEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elex_2edigitsEnd(a[0], a[1]);
}
Clo g_heff_2efmt_2elex_2edashesEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elex_2edashesEnd_entry, 2, 0};

V g_heff_2efmt_2elex_2edashesEnd(V v_s_240, V v_j_241) {
top: ;
  V v_t_242 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(45LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    goto top;
  }
  case TAG_False: {
    heff_drop(v_s_240);
    return v_j_241;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2efmt_2elex_2edashesEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elex_2edashesEnd(a[0], a[1]);
}
Clo g_heff_2efmt_2elex_2eeolEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elex_2eeolEnd_entry, 2, 0};

V g_heff_2efmt_2elex_2eeolEnd(V v_s_240, V v_j_241) {
top: ;
  V v_t_242 = heff_intLt(heff_dup(v_j_241), heff_strLength(heff_dup(v_s_240)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_t_243 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(10LL));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_s_240);
      return v_j_241;
    }
    case TAG_False: {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_j_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_False: {
    heff_drop(v_s_240);
    return v_j_241;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2efmt_2elex_2eeolEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elex_2eeolEnd(a[0], a[1]);
}
Clo g_heff_2efmt_2elex_2esymEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elex_2esymEnd_entry, 2, 0};

V g_heff_2efmt_2elex_2esymEnd(V v_s_240, V v_j_241) {
top: ;
  V v_c_242 = heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_241));
  V v_t_243 = heff_intLe(MK_INT(0LL), heff_dup(v_c_242));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_x3_244 = (g_prelude_2eindexFrom(heff_strFromCharCode(v_c_242), heff_dup(g_heff_2efmt_2elex_2esymChars_get()), MK_INT(0LL)));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      heff_drop(v_s_240);
      return v_j_241;
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      V v_t_246 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(45LL));
      V v_x1_248;
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        V v_t_247 = heff_strCharCode(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
        v_x1_248 = heff_intEq(v_t_247, MK_INT(45LL));
        break;
      }
      case TAG_False: {
        v_x1_248 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      switch (heff_tag_of(v_x1_248)) {
      case TAG_True: {
        heff_drop(v_s_240);
        return v_j_241;
      }
      case TAG_False: {
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x1_248);
      }
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  case TAG_False: {
    heff_drop(v_s_240);
    heff_drop(v_c_242);
    return v_j_241;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2efmt_2elex_2esymEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elex_2esymEnd(a[0], a[1]);
}
Clo g_heff_2efmt_2elex_2enumExp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elex_2enumExp_entry, 2, 0};

V g_heff_2efmt_2elex_2enumExp(V v_s_240, V v_b_241) {
top: ;
  V v_t_242 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_b_241)), MK_INT(101LL));
  V v_t_243;
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    v_t_243 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    v_t_243 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_b_241)), MK_INT(69LL));
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_c_244 = heff_strCharCode(heff_dup(v_s_240), heff_intAdd(heff_dup(v_b_241), MK_INT(1LL)));
    V v_t_245 = heff_intLe(MK_INT(48LL), heff_dup(v_c_244));
    V v_t_246;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      v_t_246 = heff_intLe(v_c_244, MK_INT(57LL));
      break;
    }
    case TAG_False: {
      heff_drop(v_c_244);
      v_t_246 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V v_t_247 = (g_heff_2efmt_2elex_2edigitsEnd(v_s_240, heff_intAdd(v_b_241, MK_INT(2LL))));
      return heff_rec(2, shape_83_147, (V[]){v_t_247, NTAG(TAG_True)});
    }
    case TAG_False: {
      V v_t_248 = heff_strCharCode(heff_dup(v_s_240), heff_intAdd(heff_dup(v_b_241), MK_INT(1LL)));
      V v_t_249 = heff_intEq(v_t_248, MK_INT(43LL));
      V v_t_2416;
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        V v_c_2410 = heff_strCharCode(heff_dup(v_s_240), heff_intAdd(heff_dup(v_b_241), MK_INT(2LL)));
        V v_t_2411 = heff_intLe(MK_INT(48LL), heff_dup(v_c_2410));
        switch (heff_tag_of(v_t_2411)) {
        case TAG_True: {
          v_t_2416 = heff_intLe(v_c_2410, MK_INT(57LL));
          break;
        }
        case TAG_False: {
          heff_drop(v_c_2410);
          v_t_2416 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        break;
      }
      case TAG_False: {
        V v_t_2412 = heff_strCharCode(heff_dup(v_s_240), heff_intAdd(heff_dup(v_b_241), MK_INT(1LL)));
        V v_t_2413 = heff_intEq(v_t_2412, MK_INT(45LL));
        switch (heff_tag_of(v_t_2413)) {
        case TAG_True: {
          V v_c_2414 = heff_strCharCode(heff_dup(v_s_240), heff_intAdd(heff_dup(v_b_241), MK_INT(2LL)));
          V v_t_2415 = heff_intLe(MK_INT(48LL), heff_dup(v_c_2414));
          switch (heff_tag_of(v_t_2415)) {
          case TAG_True: {
            v_t_2416 = heff_intLe(v_c_2414, MK_INT(57LL));
            break;
          }
          case TAG_False: {
            heff_drop(v_c_2414);
            v_t_2416 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_t_2415);
          }
          break;
        }
        case TAG_False: {
          v_t_2416 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      switch (heff_tag_of(v_t_2416)) {
      case TAG_True: {
        V v_t_2417 = (g_heff_2efmt_2elex_2edigitsEnd(v_s_240, heff_intAdd(v_b_241, MK_INT(2LL))));
        return heff_rec(2, shape_83_147, (V[]){v_t_2417, NTAG(TAG_True)});
      }
      case TAG_False: {
        heff_drop(v_s_240);
        return heff_rec(2, shape_83_147, (V[]){v_b_241, NTAG(TAG_True)});
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_False: {
    heff_drop(v_s_240);
    return heff_rec(2, shape_83_147, (V[]){v_b_241, NTAG(TAG_True)});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2efmt_2elex_2enumExp_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elex_2enumExp(a[0], a[1]);
}
Clo g_heff_2efmt_2elex_2enumFrac_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elex_2enumFrac_entry, 2, 0};

V g_heff_2efmt_2elex_2enumFrac(V v_s_240, V v_a_241) {
top: ;
  V v_t_242 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_a_241)), MK_INT(46LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_c_243 = heff_strCharCode(heff_dup(v_s_240), heff_intAdd(heff_dup(v_a_241), MK_INT(1LL)));
    V v_t_244 = heff_intLe(MK_INT(48LL), heff_dup(v_c_243));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V v_t_245 = heff_intLe(v_c_243, MK_INT(57LL));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        V v_t_246 = (g_heff_2efmt_2elex_2edigitsEnd(heff_dup(v_s_240), heff_intAdd(v_a_241, MK_INT(2LL))));
        HEFF_LAST return g_heff_2efmt_2elex_2enumExp(v_s_240, v_t_246);
      }
      case TAG_False: {
        heff_drop(v_s_240);
        return heff_rec(2, shape_83_147, (V[]){v_a_241, NTAG(TAG_False)});
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    case TAG_False: {
      heff_drop(v_s_240);
      heff_drop(v_c_243);
      return heff_rec(2, shape_83_147, (V[]){v_a_241, NTAG(TAG_False)});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_False: {
    heff_drop(v_s_240);
    return heff_rec(2, shape_83_147, (V[]){v_a_241, NTAG(TAG_False)});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2efmt_2elex_2enumFrac_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elex_2enumFrac(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elex_2estrScan_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elex_2estrScan_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elex_2estrScan_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elex_2estrScan_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {9}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elex_2estrScan_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elex_2estrScan_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {13}};
Clo g_heff_2efmt_2elex_2estrScan_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elex_2estrScan_entry, 3, 0};

V g_heff_2efmt_2elex_2estrScan(V v_s_240, V v_j_241, V v_acc_242) {
top: ;
  V v_t_243 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_j_241));
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    v_t_244 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    v_t_244 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(10LL));
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_s_240);
    return heff_rec(3, shape_129_337_44, (V[]){v_j_241, v_acc_242, NTAG(TAG_False)});
  }
  case TAG_False: {
    V v_t_245 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(34LL));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_s_240);
      return heff_rec(3, shape_129_337_44, (V[]){v_j_241, v_acc_242, NTAG(TAG_True)});
    }
    case TAG_False: {
      V v_t_246 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(92LL));
      V v_t_247;
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        v_t_247 = heff_intLt(heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)), heff_strLength(heff_dup(v_s_240)));
        break;
      }
      case TAG_False: {
        v_t_247 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        V v_e_248 = heff_strSlice(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)), heff_intAdd(heff_dup(v_j_241), MK_INT(2LL)));
        V v_t_249 = heff_strEq(heff_dup(v_e_248), ((V)&g_heff_2efmt_2elex_2estrScan_str0));
        V v_t_2412;
        switch (heff_tag_of(v_t_249)) {
        case TAG_True: {
          heff_drop(v_e_248);
          v_t_2412 = ((V)&g_heff_2efmt_2elex_2estrScan_str1);
          break;
        }
        case TAG_False: {
          V v_t_2410 = heff_strEq(heff_dup(v_e_248), ((V)&g_heff_2efmt_2elex_2estrScan_str2));
          switch (heff_tag_of(v_t_2410)) {
          case TAG_True: {
            heff_drop(v_e_248);
            v_t_2412 = ((V)&g_heff_2efmt_2elex_2estrScan_str3);
            break;
          }
          case TAG_False: {
            V v_t_2411 = heff_strEq(heff_dup(v_e_248), ((V)&g_heff_2efmt_2elex_2estrScan_str4));
            switch (heff_tag_of(v_t_2411)) {
            case TAG_True: {
              heff_drop(v_e_248);
              v_t_2412 = ((V)&g_heff_2efmt_2elex_2estrScan_str5);
              break;
            }
            case TAG_False: {
              v_t_2412 = v_e_248;
              break;
            }
            default: heff_nomatch(v_t_2411);
            }
            break;
          }
          default: heff_nomatch(v_t_2410);
          }
          break;
        }
        default: heff_nomatch(v_t_249);
        }
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
        V t_2 = heff_strAppend(v_acc_242, v_t_2412);
        v_s_240 = t_0;
        v_j_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      }
      case TAG_False: {
        V v_t_2413 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_j_241), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
        V t_2 = heff_strAppend(v_acc_242, v_t_2413);
        v_s_240 = t_0;
        v_j_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2efmt_2elex_2estrScan_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elex_2estrScan(a[0], a[1], a[2]);
}
Clo g_heff_2efmt_2elex_2eblockScan_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elex_2eblockScan_entry, 6, 0};

V g_heff_2efmt_2elex_2eblockScan(V v_s_240, V v_j_241, V v_depth_242, V v_line_243, V v_lineStart_244, V v_first_245) {
top: ;
  V v_t_246 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_j_241));
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_depth_242);
    return heff_rec(5, shape_129_175_176_101_44, (V[]){v_j_241, v_line_243, v_lineStart_244, v_first_245, NTAG(TAG_False)});
  }
  case TAG_False: {
    V v_t_247 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(123LL));
    V v_t_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      V v_t_248 = heff_strCharCode(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
      v_t_249 = heff_intEq(v_t_248, MK_INT(45LL));
      break;
    }
    case TAG_False: {
      v_t_249 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
      V t_2 = heff_intAdd(v_depth_242, MK_INT(1LL));
      V t_3 = v_line_243;
      V t_4 = v_lineStart_244;
      V t_5 = v_first_245;
      v_s_240 = t_0;
      v_j_241 = t_1;
      v_depth_242 = t_2;
      v_line_243 = t_3;
      v_lineStart_244 = t_4;
      v_first_245 = t_5;
      goto top;
    }
    case TAG_False: {
      V v_t_2410 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(45LL));
      V v_t_2412;
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        V v_t_2411 = heff_strCharCode(heff_dup(v_s_240), heff_intAdd(heff_dup(v_j_241), MK_INT(1LL)));
        v_t_2412 = heff_intEq(v_t_2411, MK_INT(125LL));
        break;
      }
      case TAG_False: {
        v_t_2412 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2410);
      }
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        V v_t_2413 = heff_intEq(heff_dup(v_depth_242), MK_INT(1LL));
        switch (heff_tag_of(v_t_2413)) {
        case TAG_True: {
          heff_drop(v_s_240);
          heff_drop(v_depth_242);
          return heff_rec(5, shape_129_175_176_101_44, (V[]){heff_intAdd(v_j_241, MK_INT(2LL)), v_line_243, v_lineStart_244, v_first_245, NTAG(TAG_True)});
        }
        case TAG_False: {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(2LL));
          V t_2 = heff_intSub(v_depth_242, MK_INT(1LL));
          V t_3 = v_line_243;
          V t_4 = v_lineStart_244;
          V t_5 = v_first_245;
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_depth_242 = t_2;
          v_line_243 = t_3;
          v_lineStart_244 = t_4;
          v_first_245 = t_5;
          goto top;
        }
        default: return heff_nomatch(v_t_2413);
        }
      }
      case TAG_False: {
        V v_t_2414 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(10LL));
        switch (heff_tag_of(v_t_2414)) {
        case TAG_True: {
          heff_drop(v_lineStart_244);
          heff_drop(v_first_245);
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(heff_dup(v_j_241), MK_INT(1LL));
          V t_2 = v_depth_242;
          V t_3 = heff_intAdd(v_line_243, MK_INT(1LL));
          V t_4 = heff_intAdd(v_j_241, MK_INT(1LL));
          V t_5 = NTAG(TAG_True);
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_depth_242 = t_2;
          v_line_243 = t_3;
          v_lineStart_244 = t_4;
          v_first_245 = t_5;
          goto top;
        }
        case TAG_False: {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
          V t_2 = v_depth_242;
          V t_3 = v_line_243;
          V t_4 = v_lineStart_244;
          V t_5 = v_first_245;
          v_s_240 = t_0;
          v_j_241 = t_1;
          v_depth_242 = t_2;
          v_line_243 = t_3;
          v_lineStart_244 = t_4;
          v_first_245 = t_5;
          goto top;
        }
        default: return heff_nomatch(v_t_2414);
        }
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2efmt_2elex_2eblockScan_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elex_2eblockScan(a[0], a[1], a[2], a[3], a[4], a[5]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2efmt_2elex_2eoperandBefore_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 105, 101, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2efmt_2elex_2eoperandBefore_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2efmt_2elex_2eoperandBefore_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 116, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2efmt_2elex_2eoperandBefore_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2efmt_2elex_2eoperandBefore_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {105, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2efmt_2elex_2eoperandBefore_str5 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2efmt_2elex_2eoperandBefore_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elex_2eoperandBefore_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elex_2eoperandBefore_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elex_2eoperandBefore_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
Clo g_heff_2efmt_2elex_2eoperandBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elex_2eoperandBefore_entry, 2, 0};

V g_heff_2efmt_2elex_2eoperandBefore(V v_x1_240, V v_start_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_start_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    V v_t_244 = heff_intEq(heff_get(heff_dup(v_t_242), LBL_end), v_start_241);
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V v_t_245 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_t_242), LBL_kind)}));
      V v_t_246 = heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2eoperandBefore_str0), NTAG(TAG_Nil)});
      V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2eoperandBefore_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2eoperandBefore_str2), v_t_246})});
      V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2eoperandBefore_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2eoperandBefore_str4), v_t_247})});
      V v_t_249 = ({ V a_0 = v_t_245; V b_1 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2eoperandBefore_str5), v_t_248}); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        heff_drop(v_t_242);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V v_t_2410 = heff_strEq(heff_get(heff_dup(v_t_242), LBL_kind), ((V)&g_heff_2efmt_2elex_2eoperandBefore_str6));
        switch (heff_tag_of(v_t_2410)) {
        case TAG_True: {
          V v_t_2411 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(v_t_242, LBL_text)}));
          V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2eoperandBefore_str7), NTAG(TAG_Nil)});
          V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2eoperandBefore_str8), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elex_2eoperandBefore_str9), v_t_2412})});
          return ({ V a_0 = v_t_2411; V a_1 = v_t_2413; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop_tag(v_t_2413, 2); r_; });
        }
        case TAG_False: {
          heff_drop(v_t_242);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_t_2410);
        }
      }
      default: return heff_nomatch(v_t_249);
      }
    }
    case TAG_False: {
      heff_drop(v_t_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2efmt_2elex_2eoperandBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elex_2eoperandBefore(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2efmt_2elex_2enameStep_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2efmt_2elex_2enameStep_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2efmt_2elex_2enameStep_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2efmt_2elex_2enameStep_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
Clo g_heff_2efmt_2elex_2enameStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elex_2enameStep_entry, 6, 0};

V g_heff_2efmt_2elex_2enameStep(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_j_245) {
top: ;
  V v_c_246 = heff_strCharCode(heff_dup(v_src_240), heff_dup(v_i_241));
  V v_t_247 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), heff_dup(v_j_245))}));
  V v_t_248 = ({ V a_0 = v_t_247; V b_1 = heff_dup(g_heff_2efmt_2elex_2ekeywords_get()); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  V v_kind_2411;
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    heff_drop(v_c_246);
    v_kind_2411 = ((V)&g_heff_2efmt_2elex_2enameStep_str0);
    break;
  }
  case TAG_False: {
    V v_t_249 = heff_intLe(MK_INT(65LL), heff_dup(v_c_246));
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      V v_t_2410 = heff_intLe(v_c_246, MK_INT(90LL));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        v_kind_2411 = ((V)&g_heff_2efmt_2elex_2enameStep_str1);
        break;
      }
      case TAG_False: {
        v_kind_2411 = ((V)&g_heff_2efmt_2elex_2enameStep_str2);
        break;
      }
      default: heff_nomatch(v_t_2410);
      }
      break;
    }
    case TAG_False: {
      heff_drop(v_c_246);
      v_kind_2411 = ((V)&g_heff_2efmt_2elex_2enameStep_str3);
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V v_t_2412 = heff_rec(7, shape_154_337_320_83_175_48_101, (V[]){v_kind_2411, heff_strSlice(v_src_240, heff_dup(v_i_241), heff_dup(v_j_245)), heff_dup(v_i_241), heff_dup(v_j_245), heff_dup(v_line_242), heff_intSub(v_i_241, heff_dup(v_lineStart_243)), v_first_244});
  return heff_rec(7, shape_129_175_176_101_341_88_45, (V[]){v_j_245, v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag(TAG_Just, 1, (V[]){v_t_2412}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
}
V g_heff_2efmt_2elex_2enameStep_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elex_2enameStep(a[0], a[1], a[2], a[3], a[4], a[5]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2efmt_2elex_2enumStep_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2efmt_2elex_2enumStep_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {105, 110, 116}};
Clo g_heff_2efmt_2elex_2enumStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elex_2enumStep_entry, 6, 0};

V g_heff_2efmt_2elex_2enumStep(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_r_245) {
top: ;
  V v_t_246 = heff_get(heff_dup(v_r_245), LBL_isFloat);
  V v_kind_247;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    v_kind_247 = ((V)&g_heff_2efmt_2elex_2enumStep_str0);
    break;
  }
  case TAG_False: {
    v_kind_247 = ((V)&g_heff_2efmt_2elex_2enumStep_str1);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_t_248 = heff_strSlice(v_src_240, heff_dup(v_i_241), heff_get(heff_dup(v_r_245), LBL_end));
  V v_t_249 = heff_rec(7, shape_154_337_320_83_175_48_101, (V[]){v_kind_247, v_t_248, heff_dup(v_i_241), heff_get(heff_dup(v_r_245), LBL_end), heff_dup(v_line_242), heff_intSub(v_i_241, heff_dup(v_lineStart_243)), v_first_244});
  return heff_rec(7, shape_129_175_176_101_341_88_45, (V[]){heff_get(v_r_245, LBL_end), v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag(TAG_Just, 1, (V[]){v_t_249}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
}
V g_heff_2efmt_2elex_2enumStep_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elex_2enumStep(a[0], a[1], a[2], a[3], a[4], a[5]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2efmt_2elex_2estrStep_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 116, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_heff_2efmt_2elex_2estrStep_str1 = {{0x80000000u, K_STR, 0}, 24, 24, {97, 32, 115, 116, 114, 105, 110, 103, 32, 105, 115, 32, 110, 101, 118, 101, 114, 32, 99, 108, 111, 115, 101, 100}};
Clo g_heff_2efmt_2elex_2estrStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elex_2estrStep_entry, 6, 0};

V g_heff_2efmt_2elex_2estrStep(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_r_245) {
top: ;
  V v_t_246 = heff_get(heff_dup(v_r_245), LBL_closed);
  V v_t_247;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    v_t_247 = heff_intAdd(heff_get(heff_dup(v_r_245), LBL_i), MK_INT(1LL));
    break;
  }
  case TAG_False: {
    v_t_247 = heff_get(heff_dup(v_r_245), LBL_i);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_t_248 = heff_get(heff_dup(v_r_245), LBL_closed);
  V v_end_249;
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    v_end_249 = heff_intAdd(heff_get(heff_dup(v_r_245), LBL_i), MK_INT(1LL));
    break;
  }
  case TAG_False: {
    v_end_249 = heff_get(heff_dup(v_r_245), LBL_i);
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V v_t_2410 = heff_rec(7, shape_154_337_320_83_175_48_101, (V[]){((V)&g_heff_2efmt_2elex_2estrStep_str0), heff_get(heff_dup(v_r_245), LBL_text), heff_dup(v_i_241), v_end_249, heff_dup(v_line_242), heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243)), v_first_244});
  V v_t_2411 = heff_get(heff_dup(v_r_245), LBL_closed);
  V v_t_2413;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_True: {
    heff_drop(v_i_241);
    heff_drop(v_r_245);
    v_t_2413 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_False: {
    V v_t_2412 = heff_rec(3, shape_320_83_193, (V[]){v_i_241, heff_get(v_r_245, LBL_i), ((V)&g_heff_2efmt_2elex_2estrStep_str1)});
    v_t_2413 = heff_tag(TAG_Just, 1, (V[]){v_t_2412});
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  return heff_rec(7, shape_129_175_176_101_341_88_45, (V[]){v_t_247, v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag(TAG_Just, 1, (V[]){v_t_2410}), v_t_2413, NTAG(TAG_Nothing)});
}
V g_heff_2efmt_2elex_2estrStep_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2efmt_2elex_2estrStep(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2efmt_2elex_2eblockCmtStep_str0 = {{0x80000000u, K_STR, 0}, 30, 30, {97, 32, 96, 123, 45, 96, 32, 99, 111, 109, 109, 101, 110, 116, 32, 105, 115, 32, 110, 101, 118, 101, 114, 32, 99, 108, 111, 115, 101, 100}};
Clo g_heff_2efmt_2elex_2eblockCmtStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elex_2eblockCmtStep_entry, 3, 0};

V g_heff_2efmt_2elex_2eblockCmtStep(V v_src_240, V v_i_241, V v_r_242) {
top: ;
  V v_t_243 = heff_get(heff_dup(v_r_242), LBL_closed);
  V v_t_245;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    v_t_245 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_False: {
    V v_t_244 = heff_rec(3, shape_320_83_193, (V[]){heff_dup(v_i_241), heff_get(heff_dup(v_r_242), LBL_i), ((V)&g_heff_2efmt_2elex_2eblockCmtStep_str0)});
    v_t_245 = heff_tag(TAG_Just, 1, (V[]){v_t_244});
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_246 = heff_strSlice(v_src_240, heff_dup(v_i_241), heff_get(heff_dup(v_r_242), LBL_i));
  V v_t_247 = heff_rec(3, shape_320_83_337, (V[]){v_i_241, heff_get(heff_dup(v_r_242), LBL_i), v_t_246});
  return heff_rec(7, shape_129_175_176_101_341_88_45, (V[]){heff_get(heff_dup(v_r_242), LBL_i), heff_get(heff_dup(v_r_242), LBL_line), heff_get(heff_dup(v_r_242), LBL_lineStart), heff_get(v_r_242, LBL_first), NTAG(TAG_Nothing), v_t_245, heff_tag(TAG_Just, 1, (V[]){v_t_247})});
}
V g_heff_2efmt_2elex_2eblockCmtStep_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elex_2eblockCmtStep(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2efmt_2elex_2estepAt_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {45, 45, 32, 62, 62, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2efmt_2elex_2estepAt_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2efmt_2elex_2estepAt_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {45, 45, 32, 62, 62, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2efmt_2elex_2estepAt_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 105, 101, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elex_2estepAt_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2efmt_2elex_2estepAt_str5 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 41, 91, 93, 123, 125, 44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2efmt_2elex_2estepAt_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2efmt_2elex_2estepAt_str7 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2efmt_2elex_2estepAt_str8 = {{0x80000000u, K_STR, 0}, 21, 21, {117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32}};
Clo g_heff_2efmt_2elex_2estepAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elex_2estepAt_entry, 7, 0};

V g_heff_2efmt_2elex_2estepAt(V v_src_240, V v_i_241, V v_line_242, V v_lineStart_243, V v_first_244, V v_toks_245, V v_c_246) {
top: ;
  V v_t_247 = heff_intEq(heff_dup(v_c_246), MK_INT(10LL));
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_src_240);
    heff_drop(v_lineStart_243);
    heff_drop(v_first_244);
    heff_drop(v_toks_245);
    heff_drop(v_c_246);
    return heff_rec(7, shape_129_175_176_101_341_88_45, (V[]){heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_intAdd(v_line_242, MK_INT(1LL)), heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  }
  case TAG_False: {
    V v_t_248 = heff_intEq(heff_dup(v_c_246), MK_INT(32LL));
    V v_t_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      v_t_2410 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      V v_t_249 = heff_intEq(heff_dup(v_c_246), MK_INT(9LL));
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        v_t_2410 = NTAG(TAG_True);
        break;
      }
      case TAG_False: {
        v_t_2410 = heff_intEq(heff_dup(v_c_246), MK_INT(13LL));
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      heff_drop(v_src_240);
      heff_drop(v_toks_245);
      heff_drop(v_c_246);
      return heff_rec(7, shape_129_175_176_101_341_88_45, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), v_line_242, v_lineStart_243, v_first_244, NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    }
    case TAG_False: {
      V v_t_2411 = heff_intEq(heff_dup(v_c_246), MK_INT(45LL));
      V v_t_2413;
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        V v_t_2412 = heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(6LL)));
        v_t_2413 = heff_strEq(v_t_2412, ((V)&g_heff_2efmt_2elex_2estepAt_str0));
        break;
      }
      case TAG_False: {
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
      switch (heff_tag_of(v_t_2413)) {
      case TAG_True: {
        heff_drop(v_src_240);
        heff_drop(v_toks_245);
        heff_drop(v_c_246);
        V v_t_2414 = heff_rec(7, shape_154_337_320_83_175_48_101, (V[]){((V)&g_heff_2efmt_2elex_2estepAt_str1), ((V)&g_heff_2efmt_2elex_2estepAt_str2), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(6LL)), heff_dup(v_line_242), heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243)), v_first_244});
        return heff_rec(7, shape_129_175_176_101_341_88_45, (V[]){heff_intAdd(v_i_241, MK_INT(6LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag(TAG_Just, 1, (V[]){v_t_2414}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      }
      case TAG_False: {
        V v_t_2415 = heff_intEq(heff_dup(v_c_246), MK_INT(45LL));
        V v_t_2425;
        switch (heff_tag_of(v_t_2415)) {
        case TAG_True: {
          V v_t_2416 = (g_heff_2efmt_2elex_2edashesEnd(heff_dup(v_src_240), heff_dup(v_i_241)));
          V v_a_2417 = heff_intSub(v_t_2416, heff_dup(v_i_241));
          V v_t_2418 = heff_intLe(MK_INT(2LL), v_a_2417);
          switch (heff_tag_of(v_t_2418)) {
          case TAG_True: {
            V v_t_2419 = (g_heff_2efmt_2elex_2edashesEnd(heff_dup(v_src_240), heff_dup(v_i_241)));
            V v_c_2420 = heff_strCharCode(heff_dup(v_src_240), v_t_2419);
            V v_t_2421 = heff_intLe(MK_INT(0LL), heff_dup(v_c_2420));
            V v_x1_2424;
            switch (heff_tag_of(v_t_2421)) {
            case TAG_True: {
              V v_x3_2422 = (g_prelude_2eindexFrom(heff_strFromCharCode(v_c_2420), heff_dup(g_heff_2efmt_2elex_2esymChars_get()), MK_INT(0LL)));
              switch (heff_tag_of(v_x3_2422)) {
              case TAG_Nothing: {
                v_x1_2424 = NTAG(TAG_False);
                break;
              }
              case TAG_Just: {
                heff_take_n(v_x3_2422, 0ULL, 1);
                v_x1_2424 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_x3_2422);
              }
              break;
            }
            case TAG_False: {
              heff_drop(v_c_2420);
              v_x1_2424 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_t_2421);
            }
            switch (heff_tag_of(v_x1_2424)) {
            case TAG_True: {
              v_t_2425 = NTAG(TAG_False);
              break;
            }
            case TAG_False: {
              v_t_2425 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_x1_2424);
            }
            break;
          }
          case TAG_False: {
            v_t_2425 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_t_2418);
          }
          break;
        }
        case TAG_False: {
          v_t_2425 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_2415);
        }
        switch (heff_tag_of(v_t_2425)) {
        case TAG_True: {
          heff_drop(v_toks_245);
          heff_drop(v_c_246);
          V v_e_2426 = (g_heff_2efmt_2elex_2eeolEnd(heff_dup(v_src_240), heff_dup(v_i_241)));
          V v_t_2427 = heff_rec(3, shape_320_83_337, (V[]){heff_dup(v_i_241), heff_dup(v_e_2426), heff_strSlice(v_src_240, v_i_241, heff_dup(v_e_2426))});
          return heff_rec(7, shape_129_175_176_101_341_88_45, (V[]){v_e_2426, v_line_242, v_lineStart_243, v_first_244, NTAG(TAG_Nothing), NTAG(TAG_Nothing), heff_tag(TAG_Just, 1, (V[]){v_t_2427})});
        }
        case TAG_False: {
          V v_t_2428 = heff_intEq(heff_dup(v_c_246), MK_INT(123LL));
          V v_t_2430;
          switch (heff_tag_of(v_t_2428)) {
          case TAG_True: {
            V v_t_2429 = heff_strCharCode(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
            v_t_2430 = heff_intEq(v_t_2429, MK_INT(45LL));
            break;
          }
          case TAG_False: {
            v_t_2430 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_t_2428);
          }
          switch (heff_tag_of(v_t_2430)) {
          case TAG_True: {
            heff_drop(v_toks_245);
            heff_drop(v_c_246);
            V v_t_2431 = (g_heff_2efmt_2elex_2eblockScan(heff_dup(v_src_240), heff_dup(v_i_241), MK_INT(0LL), v_line_242, v_lineStart_243, v_first_244));
            return (g_heff_2efmt_2elex_2eblockCmtStep(v_src_240, v_i_241, v_t_2431));
          }
          case TAG_False: {
            V v_t_2432 = heff_intLe(MK_INT(97LL), heff_dup(v_c_246));
            V v_t_2434;
            switch (heff_tag_of(v_t_2432)) {
            case TAG_True: {
              V v_t_2433 = heff_intLe(heff_dup(v_c_246), MK_INT(122LL));
              switch (heff_tag_of(v_t_2433)) {
              case TAG_True: {
                v_t_2434 = NTAG(TAG_True);
                break;
              }
              case TAG_False: {
                v_t_2434 = heff_intEq(heff_dup(v_c_246), MK_INT(95LL));
                break;
              }
              default: heff_nomatch(v_t_2433);
              }
              break;
            }
            case TAG_False: {
              v_t_2434 = heff_intEq(heff_dup(v_c_246), MK_INT(95LL));
              break;
            }
            default: heff_nomatch(v_t_2432);
            }
            V v_t_2436;
            switch (heff_tag_of(v_t_2434)) {
            case TAG_True: {
              v_t_2436 = NTAG(TAG_True);
              break;
            }
            case TAG_False: {
              V v_t_2435 = heff_intLe(MK_INT(65LL), heff_dup(v_c_246));
              switch (heff_tag_of(v_t_2435)) {
              case TAG_True: {
                v_t_2436 = heff_intLe(heff_dup(v_c_246), MK_INT(90LL));
                break;
              }
              case TAG_False: {
                v_t_2436 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_t_2435);
              }
              break;
            }
            default: heff_nomatch(v_t_2434);
            }
            switch (heff_tag_of(v_t_2436)) {
            case TAG_True: {
              heff_drop(v_toks_245);
              heff_drop(v_c_246);
              V v_t_2437 = (g_heff_2efmt_2elex_2enameEnd(heff_dup(v_src_240), heff_dup(v_i_241)));
              return (g_heff_2efmt_2elex_2enameStep(v_src_240, v_i_241, v_line_242, v_lineStart_243, v_first_244, v_t_2437));
            }
            case TAG_False: {
              V v_t_2438 = heff_intEq(heff_dup(v_c_246), MK_INT(46LL));
              V v_t_2445;
              switch (heff_tag_of(v_t_2438)) {
              case TAG_True: {
                V v_c_2439 = heff_strCharCode(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
                V v_t_2440 = heff_intLe(MK_INT(97LL), heff_dup(v_c_2439));
                V v_t_2442;
                switch (heff_tag_of(v_t_2440)) {
                case TAG_True: {
                  V v_t_2441 = heff_intLe(heff_dup(v_c_2439), MK_INT(122LL));
                  switch (heff_tag_of(v_t_2441)) {
                  case TAG_True: {
                    v_t_2442 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_False: {
                    v_t_2442 = heff_intEq(heff_dup(v_c_2439), MK_INT(95LL));
                    break;
                  }
                  default: heff_nomatch(v_t_2441);
                  }
                  break;
                }
                case TAG_False: {
                  v_t_2442 = heff_intEq(heff_dup(v_c_2439), MK_INT(95LL));
                  break;
                }
                default: heff_nomatch(v_t_2440);
                }
                switch (heff_tag_of(v_t_2442)) {
                case TAG_True: {
                  heff_drop(v_c_2439);
                  v_t_2445 = (g_heff_2efmt_2elex_2eoperandBefore(heff_dup(v_toks_245), heff_dup(v_i_241)));
                  break;
                }
                case TAG_False: {
                  V v_t_2443 = heff_intLe(MK_INT(65LL), heff_dup(v_c_2439));
                  switch (heff_tag_of(v_t_2443)) {
                  case TAG_True: {
                    V v_t_2444 = heff_intLe(v_c_2439, MK_INT(90LL));
                    switch (heff_tag_of(v_t_2444)) {
                    case TAG_True: {
                      v_t_2445 = (g_heff_2efmt_2elex_2eoperandBefore(heff_dup(v_toks_245), heff_dup(v_i_241)));
                      break;
                    }
                    case TAG_False: {
                      v_t_2445 = NTAG(TAG_False);
                      break;
                    }
                    default: heff_nomatch(v_t_2444);
                    }
                    break;
                  }
                  case TAG_False: {
                    heff_drop(v_c_2439);
                    v_t_2445 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_t_2443);
                  }
                  break;
                }
                default: heff_nomatch(v_t_2442);
                }
                break;
              }
              case TAG_False: {
                v_t_2445 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_t_2438);
              }
              switch (heff_tag_of(v_t_2445)) {
              case TAG_True: {
                heff_drop(v_toks_245);
                heff_drop(v_c_246);
                V v_j_2446 = (g_heff_2efmt_2elex_2eplainEnd(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))));
                V v_t_2447 = heff_strSlice(v_src_240, heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_dup(v_j_2446));
                V v_t_2448 = heff_rec(7, shape_154_337_320_83_175_48_101, (V[]){((V)&g_heff_2efmt_2elex_2estepAt_str3), v_t_2447, heff_dup(v_i_241), heff_dup(v_j_2446), heff_dup(v_line_242), heff_intSub(v_i_241, heff_dup(v_lineStart_243)), v_first_244});
                return heff_rec(7, shape_129_175_176_101_341_88_45, (V[]){v_j_2446, v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag(TAG_Just, 1, (V[]){v_t_2448}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
              }
              case TAG_False: {
                V v_t_2449 = heff_intLe(MK_INT(48LL), heff_dup(v_c_246));
                V v_t_2461;
                switch (heff_tag_of(v_t_2449)) {
                case TAG_True: {
                  V v_t_2450 = heff_intLe(heff_dup(v_c_246), MK_INT(57LL));
                  switch (heff_tag_of(v_t_2450)) {
                  case TAG_True: {
                    heff_drop(v_toks_245);
                    v_t_2461 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_False: {
                    V v_t_2451 = heff_intEq(heff_dup(v_c_246), MK_INT(45LL));
                    switch (heff_tag_of(v_t_2451)) {
                    case TAG_True: {
                      V v_c_2452 = heff_strCharCode(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
                      V v_t_2453 = heff_intLe(MK_INT(48LL), heff_dup(v_c_2452));
                      switch (heff_tag_of(v_t_2453)) {
                      case TAG_True: {
                        V v_t_2454 = heff_intLe(v_c_2452, MK_INT(57LL));
                        switch (heff_tag_of(v_t_2454)) {
                        case TAG_True: {
                          V v_x1_2455 = (g_heff_2efmt_2elex_2eoperandBefore(v_toks_245, heff_dup(v_i_241)));
                          switch (heff_tag_of(v_x1_2455)) {
                          case TAG_True: {
                            v_t_2461 = NTAG(TAG_False);
                            break;
                          }
                          case TAG_False: {
                            v_t_2461 = NTAG(TAG_True);
                            break;
                          }
                          default: heff_nomatch(v_x1_2455);
                          }
                          break;
                        }
                        case TAG_False: {
                          heff_drop(v_toks_245);
                          v_t_2461 = NTAG(TAG_False);
                          break;
                        }
                        default: heff_nomatch(v_t_2454);
                        }
                        break;
                      }
                      case TAG_False: {
                        heff_drop(v_toks_245);
                        heff_drop(v_c_2452);
                        v_t_2461 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_t_2453);
                      }
                      break;
                    }
                    case TAG_False: {
                      heff_drop(v_toks_245);
                      v_t_2461 = NTAG(TAG_False);
                      break;
                    }
                    default: heff_nomatch(v_t_2451);
                    }
                    break;
                  }
                  default: heff_nomatch(v_t_2450);
                  }
                  break;
                }
                case TAG_False: {
                  V v_t_2456 = heff_intEq(heff_dup(v_c_246), MK_INT(45LL));
                  switch (heff_tag_of(v_t_2456)) {
                  case TAG_True: {
                    V v_c_2457 = heff_strCharCode(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
                    V v_t_2458 = heff_intLe(MK_INT(48LL), heff_dup(v_c_2457));
                    switch (heff_tag_of(v_t_2458)) {
                    case TAG_True: {
                      V v_t_2459 = heff_intLe(v_c_2457, MK_INT(57LL));
                      switch (heff_tag_of(v_t_2459)) {
                      case TAG_True: {
                        V v_x1_2460 = (g_heff_2efmt_2elex_2eoperandBefore(v_toks_245, heff_dup(v_i_241)));
                        switch (heff_tag_of(v_x1_2460)) {
                        case TAG_True: {
                          v_t_2461 = NTAG(TAG_False);
                          break;
                        }
                        case TAG_False: {
                          v_t_2461 = NTAG(TAG_True);
                          break;
                        }
                        default: heff_nomatch(v_x1_2460);
                        }
                        break;
                      }
                      case TAG_False: {
                        heff_drop(v_toks_245);
                        v_t_2461 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_t_2459);
                      }
                      break;
                    }
                    case TAG_False: {
                      heff_drop(v_toks_245);
                      heff_drop(v_c_2457);
                      v_t_2461 = NTAG(TAG_False);
                      break;
                    }
                    default: heff_nomatch(v_t_2458);
                    }
                    break;
                  }
                  case TAG_False: {
                    heff_drop(v_toks_245);
                    v_t_2461 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_t_2456);
                  }
                  break;
                }
                default: heff_nomatch(v_t_2449);
                }
                switch (heff_tag_of(v_t_2461)) {
                case TAG_True: {
                  heff_drop(v_c_246);
                  V v_t_2462 = (g_heff_2efmt_2elex_2edigitsEnd(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))));
                  V v_t_2463 = (g_heff_2efmt_2elex_2enumFrac(heff_dup(v_src_240), v_t_2462));
                  return (g_heff_2efmt_2elex_2enumStep(v_src_240, v_i_241, v_line_242, v_lineStart_243, v_first_244, v_t_2463));
                }
                case TAG_False: {
                  V v_t_2464 = heff_intEq(heff_dup(v_c_246), MK_INT(34LL));
                  switch (heff_tag_of(v_t_2464)) {
                  case TAG_True: {
                    heff_drop(v_c_246);
                    V v_t_2465 = (g_heff_2efmt_2elex_2estrScan(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), ((V)&g_heff_2efmt_2elex_2estepAt_str4)));
                    return ({ V a_0 = v_src_240; V a_1 = v_i_241; V a_2 = v_line_242; V a_3 = v_lineStart_243; V a_4 = v_first_244; V a_5 = v_t_2465; V r_ = (g_heff_2efmt_2elex_2estrStep(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_src_240); r_; });
                  }
                  case TAG_False: {
                    V v_t_2466 = heff_intLe(MK_INT(0LL), heff_dup(v_c_246));
                    V v_t_2469;
                    switch (heff_tag_of(v_t_2466)) {
                    case TAG_True: {
                      V v_x3_2467 = (g_prelude_2eindexFrom(heff_strFromCharCode(heff_dup(v_c_246)), ((V)&g_heff_2efmt_2elex_2estepAt_str5), MK_INT(0LL)));
                      switch (heff_tag_of(v_x3_2467)) {
                      case TAG_Nothing: {
                        v_t_2469 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_Just: {
                        heff_take_n(v_x3_2467, 0ULL, 1);
                        v_t_2469 = NTAG(TAG_True);
                        break;
                      }
                      default: heff_nomatch(v_x3_2467);
                      }
                      break;
                    }
                    case TAG_False: {
                      v_t_2469 = NTAG(TAG_False);
                      break;
                    }
                    default: heff_nomatch(v_t_2466);
                    }
                    switch (heff_tag_of(v_t_2469)) {
                    case TAG_True: {
                      heff_drop(v_c_246);
                      V v_t_2470 = heff_strSlice(v_src_240, heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
                      V v_t_2471 = heff_rec(7, shape_154_337_320_83_175_48_101, (V[]){((V)&g_heff_2efmt_2elex_2estepAt_str6), v_t_2470, heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_dup(v_line_242), heff_intSub(heff_dup(v_i_241), heff_dup(v_lineStart_243)), v_first_244});
                      return heff_rec(7, shape_129_175_176_101_341_88_45, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag(TAG_Just, 1, (V[]){v_t_2471}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                    }
                    case TAG_False: {
                      V v_t_2472 = heff_intLe(MK_INT(0LL), heff_dup(v_c_246));
                      V v_t_2475;
                      switch (heff_tag_of(v_t_2472)) {
                      case TAG_True: {
                        V v_x3_2473 = (g_prelude_2eindexFrom(heff_strFromCharCode(v_c_246), heff_dup(g_heff_2efmt_2elex_2esymChars_get()), MK_INT(0LL)));
                        switch (heff_tag_of(v_x3_2473)) {
                        case TAG_Nothing: {
                          v_t_2475 = NTAG(TAG_False);
                          break;
                        }
                        case TAG_Just: {
                          heff_take_n(v_x3_2473, 0ULL, 1);
                          v_t_2475 = NTAG(TAG_True);
                          break;
                        }
                        default: heff_nomatch(v_x3_2473);
                        }
                        break;
                      }
                      case TAG_False: {
                        heff_drop(v_c_246);
                        v_t_2475 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_t_2472);
                      }
                      switch (heff_tag_of(v_t_2475)) {
                      case TAG_True: {
                        V v_j_2476 = (g_heff_2efmt_2elex_2esymEnd(heff_dup(v_src_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))));
                        V v_t_2477 = heff_rec(7, shape_154_337_320_83_175_48_101, (V[]){((V)&g_heff_2efmt_2elex_2estepAt_str7), heff_strSlice(v_src_240, heff_dup(v_i_241), heff_dup(v_j_2476)), heff_dup(v_i_241), heff_dup(v_j_2476), heff_dup(v_line_242), heff_intSub(v_i_241, heff_dup(v_lineStart_243)), v_first_244});
                        return heff_rec(7, shape_129_175_176_101_341_88_45, (V[]){v_j_2476, v_line_242, v_lineStart_243, NTAG(TAG_False), heff_tag(TAG_Just, 1, (V[]){v_t_2477}), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                      }
                      case TAG_False: {
                        V v_t_2478 = heff_strSlice(v_src_240, heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
                        V v_t_2479 = heff_rec(3, shape_320_83_193, (V[]){heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_strAppend(((V)&g_heff_2efmt_2elex_2estepAt_str8), v_t_2478)});
                        return heff_rec(7, shape_129_175_176_101_341_88_45, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), v_line_242, v_lineStart_243, v_first_244, NTAG(TAG_Nothing), heff_tag(TAG_Just, 1, (V[]){v_t_2479}), NTAG(TAG_Nothing)});
                      }
                      default: return heff_nomatch(v_t_2475);
                      }
                    }
                    default: return heff_nomatch(v_t_2469);
                    }
                  }
                  default: return heff_nomatch(v_t_2464);
                  }
                }
                default: return heff_nomatch(v_t_2461);
                }
              }
              default: return heff_nomatch(v_t_2445);
              }
            }
            default: return heff_nomatch(v_t_2436);
            }
          }
          default: return heff_nomatch(v_t_2430);
          }
        }
        default: return heff_nomatch(v_t_2425);
        }
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2efmt_2elex_2estepAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elex_2estepAt(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2efmt_2elex_2elexGo_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elex_2elexGo_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2efmt_2elex_2elexGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elex_2elexGo_entry, 5, 0};

V g_heff_2efmt_2elex_2elexGo(V v_src_240, V v_st_241, V v_toks_242, V v_errs_243, V v_cmts_244) {
top: ;
  V v_t_245 = heff_intLe(heff_strLength(heff_dup(v_src_240)), heff_get(heff_dup(v_st_241), LBL_i));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    V v_t_246 = heff_intAdd(heff_get(heff_dup(v_st_241), LBL_line), MK_INT(1LL));
    V v_t_247 = heff_rec(7, shape_154_337_320_83_175_48_101, (V[]){((V)&g_heff_2efmt_2elex_2elexGo_str0), ((V)&g_heff_2efmt_2elex_2elexGo_str1), heff_strLength(heff_dup(v_src_240)), heff_strLength(v_src_240), v_t_246, MK_INT(0LL), NTAG(TAG_True)});
    V v_t_248 = heff_get(heff_dup(v_st_241), LBL_tok);
    V v_t_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      v_t_2410 = v_toks_242;
      break;
    }
    case TAG_Just: {
      V v_x_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){v_x_249, v_toks_242});
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_xs_2411 = heff_tag(TAG_Cons, 2, (V[]){v_t_247, v_t_2410});
    V v_t_2412 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2411));
    V v_t_2413 = heff_get(heff_dup(v_st_241), LBL_err);
    V v_xs_2415;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nothing: {
      v_xs_2415 = v_errs_243;
      break;
    }
    case TAG_Just: {
      V v_x_2414 = heff_field(v_t_2413, 0);
      heff_take_n(v_t_2413, 1ULL, 1);
      v_xs_2415 = heff_tag(TAG_Cons, 2, (V[]){v_x_2414, v_errs_243});
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    V v_t_2416 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2415));
    V v_t_2417 = heff_get(v_st_241, LBL_cmt);
    V v_xs_2419;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Nothing: {
      v_xs_2419 = v_cmts_244;
      break;
    }
    case TAG_Just: {
      V v_x_2418 = heff_field(v_t_2417, 0);
      heff_take_n(v_t_2417, 1ULL, 1);
      v_xs_2419 = heff_tag(TAG_Cons, 2, (V[]){v_x_2418, v_cmts_244});
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    V v_t_2420 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2419));
    return heff_rec(3, shape_342_89_49, (V[]){v_t_2412, v_t_2416, v_t_2420});
  }
  case TAG_False: {
    V v_i_2421 = heff_get(heff_dup(v_st_241), LBL_i);
    V v_t_2422 = heff_get(heff_dup(v_st_241), LBL_tok);
    V v_toks_2424;
    switch (heff_tag_of(v_t_2422)) {
    case TAG_Nothing: {
      v_toks_2424 = heff_dup(v_toks_242);
      break;
    }
    case TAG_Just: {
      V v_x_2423 = heff_field(v_t_2422, 0);
      heff_take_n(v_t_2422, 1ULL, 1);
      v_toks_2424 = heff_tag(TAG_Cons, 2, (V[]){v_x_2423, heff_dup(v_toks_242)});
      break;
    }
    default: heff_nomatch(v_t_2422);
    }
    V v_t_2425 = (g_heff_2efmt_2elex_2estepAt(heff_dup(v_src_240), heff_dup(v_i_2421), heff_get(heff_dup(v_st_241), LBL_line), heff_get(heff_dup(v_st_241), LBL_lineStart), heff_get(heff_dup(v_st_241), LBL_first), v_toks_2424, heff_strCharCode(heff_dup(v_src_240), v_i_2421)));
    V v_t_2426 = heff_get(heff_dup(v_st_241), LBL_tok);
    V v_t_2428;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_Nothing: {
      v_t_2428 = v_toks_242;
      break;
    }
    case TAG_Just: {
      V v_x_2427 = heff_field(v_t_2426, 0);
      heff_take_n(v_t_2426, 1ULL, 1);
      v_t_2428 = heff_tag(TAG_Cons, 2, (V[]){v_x_2427, v_toks_242});
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    V v_t_2429 = heff_get(heff_dup(v_st_241), LBL_err);
    V v_t_2431;
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Nothing: {
      v_t_2431 = v_errs_243;
      break;
    }
    case TAG_Just: {
      V v_x_2430 = heff_field(v_t_2429, 0);
      heff_take_n(v_t_2429, 1ULL, 1);
      v_t_2431 = heff_tag(TAG_Cons, 2, (V[]){v_x_2430, v_errs_243});
      break;
    }
    default: heff_nomatch(v_t_2429);
    }
    V v_t_2432 = heff_get(v_st_241, LBL_cmt);
    V v_t_2434;
    switch (heff_tag_of(v_t_2432)) {
    case TAG_Nothing: {
      v_t_2434 = v_cmts_244;
      break;
    }
    case TAG_Just: {
      V v_x_2433 = heff_field(v_t_2432, 0);
      heff_take_n(v_t_2432, 1ULL, 1);
      v_t_2434 = heff_tag(TAG_Cons, 2, (V[]){v_x_2433, v_cmts_244});
      break;
    }
    default: heff_nomatch(v_t_2432);
    }
    V t_0 = v_src_240;
    V t_1 = v_t_2425;
    V t_2 = v_t_2428;
    V t_3 = v_t_2431;
    V t_4 = v_t_2434;
    v_src_240 = t_0;
    v_st_241 = t_1;
    v_toks_242 = t_2;
    v_errs_243 = t_3;
    v_cmts_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2efmt_2elex_2elexGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elex_2elexGo(a[0], a[1], a[2], a[3], a[4]);
}