// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_IApp 21275
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_IPrim 59489
#define TAG_ImplicitParam 51130
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_MkSegment 38079
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define LBL_end 310101
#define LBL_start 311115900
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_clo;
V g_heff_2esyntax_2epresyntax_2ebytesTerm(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesTerm_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
V g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669(V);
V g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_clo;
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(V);
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_clo;
V g_heff_2esyntax_2epresyntax_2ereversedBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2ereversedBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ereversedBytes_clo;
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
V g_heff_2esyntax_2epresyntax_2etwoTo(V);
V g_heff_2esyntax_2epresyntax_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etwoTo_clo;
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(V, V);
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_clo;
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2ewatchOf(V);
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr(V, V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2esyntax_2epresyntax_2etwoTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etwoTo_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2etwoTo(V v_k_240) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    return MK_INT(1LL);
  } else {
    V v_t_242 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_intSub(v_k_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(2LL), v_t_242);
  }
}
V g_heff_2esyntax_2epresyntax_2etwoTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etwoTo(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2elastOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elastOr_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2elastOr(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop(v_z_240);
      return heff_dup(v_x_242);
    }
    case TAG_Cons: {
      V t_0 = v_z_240;
      V t_1 = v_x22_243;
      v_z_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2elastOr(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2epresyntax_2eapp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eapp_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eapp(V v_f_240, V v_args_241) {
top: ;
  switch (heff_tag_of(v_args_241)) {
  case TAG_Nil: {
    return v_f_240;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_f_240)) {
    case TAG_At: {
      V v_f1_244 = heff_dup(heff_field(v_f_240, 0));
      V v_sp_245 = heff_dup(heff_field(v_f_240, 1));
      switch (heff_tag_of(v_f1_244)) {
      case TAG_EVar: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_247 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2410;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_f_240, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2413;
        switch (heff_tag_of(v_x1_247)) {
        case TAG_At: {
          V v_s_2412 = heff_field(v_x1_247, 1);
          heff_take_n(v_x1_247, 2ULL, 2);
          v_t_2413 = v_s_2412;
          break;
        }
        default: heff_nomatch(v_x1_247);
        }
        V v_t_2414 = ({ V rv_1 = heff_get_n(v_t_2413, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2410, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2414});
      }
      case TAG_EImplicitVar: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2416 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2419;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2418 = heff_dup(heff_field(v_f_240, 1));
          v_t_2419 = v_s_2418;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2422;
        switch (heff_tag_of(v_x1_2416)) {
        case TAG_At: {
          V v_s_2421 = heff_field(v_x1_2416, 1);
          heff_take_n(v_x1_2416, 2ULL, 2);
          v_t_2422 = v_s_2421;
          break;
        }
        default: heff_nomatch(v_x1_2416);
        }
        V v_t_2423 = ({ V rv_1 = heff_get_n(v_t_2422, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2419, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2423});
      }
      case TAG_ETag: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2425 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2428;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_f_240, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2431;
        switch (heff_tag_of(v_x1_2425)) {
        case TAG_At: {
          V v_s_2430 = heff_field(v_x1_2425, 1);
          heff_take_n(v_x1_2425, 2ULL, 2);
          v_t_2431 = v_s_2430;
          break;
        }
        default: heff_nomatch(v_x1_2425);
        }
        V v_t_2432 = ({ V rv_1 = heff_get_n(v_t_2431, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2428, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2432});
      }
      case TAG_EInt: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2434 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2437;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_f_240, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2440;
        switch (heff_tag_of(v_x1_2434)) {
        case TAG_At: {
          V v_s_2439 = heff_field(v_x1_2434, 1);
          heff_take_n(v_x1_2434, 2ULL, 2);
          v_t_2440 = v_s_2439;
          break;
        }
        default: heff_nomatch(v_x1_2434);
        }
        V v_t_2441 = ({ V rv_1 = heff_get_n(v_t_2440, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2437, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2441});
      }
      case TAG_EFloat: {
        heff_take_na(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2443 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2446;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2445 = heff_dup(heff_field(v_f_240, 1));
          v_t_2446 = v_s_2445;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2449;
        switch (heff_tag_of(v_x1_2443)) {
        case TAG_At: {
          V v_s_2448 = heff_field(v_x1_2443, 1);
          heff_take_n(v_x1_2443, 2ULL, 2);
          v_t_2449 = v_s_2448;
          break;
        }
        default: heff_nomatch(v_x1_2443);
        }
        V v_t_2450 = ({ V rv_1 = heff_get_n(v_t_2449, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2446, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2450});
      }
      case TAG_EString: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2452 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2455;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2454 = heff_dup(heff_field(v_f_240, 1));
          v_t_2455 = v_s_2454;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2458;
        switch (heff_tag_of(v_x1_2452)) {
        case TAG_At: {
          V v_s_2457 = heff_field(v_x1_2452, 1);
          heff_take_n(v_x1_2452, 2ULL, 2);
          v_t_2458 = v_s_2457;
          break;
        }
        default: heff_nomatch(v_x1_2452);
        }
        V v_t_2459 = ({ V rv_1 = heff_get_n(v_t_2458, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2455, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2459});
      }
      case TAG_EBinary: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2461 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2464;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2463 = heff_dup(heff_field(v_f_240, 1));
          v_t_2464 = v_s_2463;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2467;
        switch (heff_tag_of(v_x1_2461)) {
        case TAG_At: {
          V v_s_2466 = heff_field(v_x1_2461, 1);
          heff_take_n(v_x1_2461, 2ULL, 2);
          v_t_2467 = v_s_2466;
          break;
        }
        default: heff_nomatch(v_x1_2461);
        }
        V v_t_2468 = ({ V rv_1 = heff_get_n(v_t_2467, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2464, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2468});
      }
      case TAG_ERune: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2470 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2473;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2472 = heff_dup(heff_field(v_f_240, 1));
          v_t_2473 = v_s_2472;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2476;
        switch (heff_tag_of(v_x1_2470)) {
        case TAG_At: {
          V v_s_2475 = heff_field(v_x1_2470, 1);
          heff_take_n(v_x1_2470, 2ULL, 2);
          v_t_2476 = v_s_2475;
          break;
        }
        default: heff_nomatch(v_x1_2470);
        }
        V v_t_2477 = ({ V rv_1 = heff_get_n(v_t_2476, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2473, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2477});
      }
      case TAG_EWord: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2479 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2482;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2481 = heff_dup(heff_field(v_f_240, 1));
          v_t_2482 = v_s_2481;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2485;
        switch (heff_tag_of(v_x1_2479)) {
        case TAG_At: {
          V v_s_2484 = heff_field(v_x1_2479, 1);
          heff_take_n(v_x1_2479, 2ULL, 2);
          v_t_2485 = v_s_2484;
          break;
        }
        default: heff_nomatch(v_x1_2479);
        }
        V v_t_2486 = ({ V rv_1 = heff_get_n(v_t_2485, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2482, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2486});
      }
      case TAG_EApp: {
        V v_h_2487 = heff_field(v_f1_244, 0);
        V v_xs_2488 = heff_field(v_f1_244, 1);
        V v_ru_24f1_244_24EApp = heff_take_reuse_n(v_f1_244, 3ULL, 2);
        heff_drop_tag(v_f_240, 2);
        V v_t_2489 = (g_prelude_2e_2b_2b(v_xs_2488, heff_dup(v_args_241)));
        V v_x1_2490 = ({ V a_0 = heff_dup(v_h_2487); V a_1 = v_args_241; V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, a_1)); heff_drop_tag(v_args_241, 2); r_; });
        V v_t_2493;
        switch (heff_tag_of(v_x1_2490)) {
        case TAG_At: {
          V v_s_2492 = heff_field(v_x1_2490, 1);
          heff_take_n(v_x1_2490, 2ULL, 2);
          v_t_2493 = v_s_2492;
          break;
        }
        default: heff_nomatch(v_x1_2490);
        }
        V v_t_2494 = ({ V rv_1 = heff_get_n(v_t_2493, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_245, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24f1_244_24EApp, TAG_EApp, 2, (V[]){v_h_2487, v_t_2489}), v_t_2494});
      }
      case TAG_EProject: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2496 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2499;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2498 = heff_dup(heff_field(v_f_240, 1));
          v_t_2499 = v_s_2498;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24102;
        switch (heff_tag_of(v_x1_2496)) {
        case TAG_At: {
          V v_s_24101 = heff_field(v_x1_2496, 1);
          heff_take_n(v_x1_2496, 2ULL, 2);
          v_t_24102 = v_s_24101;
          break;
        }
        default: heff_nomatch(v_x1_2496);
        }
        V v_t_24103 = ({ V rv_1 = heff_get_n(v_t_24102, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2499, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24103});
      }
      case TAG_ENamed: {
        V v_ru_24f1_244_24ENamed = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24106 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24109;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24108 = heff_dup(heff_field(v_f_240, 1));
          v_t_24109 = v_s_24108;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24112;
        switch (heff_tag_of(v_x1_24106)) {
        case TAG_At: {
          V v_s_24111 = heff_field(v_x1_24106, 1);
          heff_take_n(v_x1_24106, 2ULL, 2);
          v_t_24112 = v_s_24111;
          break;
        }
        default: heff_nomatch(v_x1_24106);
        }
        V v_t_24113 = ({ V rv_1 = heff_get_n(v_t_24112, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24109, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24113});
      }
      case TAG_EPi: {
        V v_ru_24f1_244_24EPi = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24116 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24119;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24118 = heff_dup(heff_field(v_f_240, 1));
          v_t_24119 = v_s_24118;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24122;
        switch (heff_tag_of(v_x1_24116)) {
        case TAG_At: {
          V v_s_24121 = heff_field(v_x1_24116, 1);
          heff_take_n(v_x1_24116, 2ULL, 2);
          v_t_24122 = v_s_24121;
          break;
        }
        default: heff_nomatch(v_x1_24116);
        }
        V v_t_24123 = ({ V rv_1 = heff_get_n(v_t_24122, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24119, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24123});
      }
      case TAG_ELam: {
        V v_ru_24f1_244_24ELam = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24126 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24129;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24128 = heff_dup(heff_field(v_f_240, 1));
          v_t_24129 = v_s_24128;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24132;
        switch (heff_tag_of(v_x1_24126)) {
        case TAG_At: {
          V v_s_24131 = heff_field(v_x1_24126, 1);
          heff_take_n(v_x1_24126, 2ULL, 2);
          v_t_24132 = v_s_24131;
          break;
        }
        default: heff_nomatch(v_x1_24126);
        }
        V v_t_24133 = ({ V rv_1 = heff_get_n(v_t_24132, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24129, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24133});
      }
      case TAG_EAnn: {
        V v_ru_24f1_244_24EAnn = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24136 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24139;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24138 = heff_dup(heff_field(v_f_240, 1));
          v_t_24139 = v_s_24138;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24142;
        switch (heff_tag_of(v_x1_24136)) {
        case TAG_At: {
          V v_s_24141 = heff_field(v_x1_24136, 1);
          heff_take_n(v_x1_24136, 2ULL, 2);
          v_t_24142 = v_s_24141;
          break;
        }
        default: heff_nomatch(v_x1_24136);
        }
        V v_t_24143 = ({ V rv_1 = heff_get_n(v_t_24142, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24139, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24143});
      }
      case TAG_ESpec: {
        heff_take_n(v_f1_244, 0ULL, 4);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24148 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24151;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24150 = heff_dup(heff_field(v_f_240, 1));
          v_t_24151 = v_s_24150;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24154;
        switch (heff_tag_of(v_x1_24148)) {
        case TAG_At: {
          V v_s_24153 = heff_field(v_x1_24148, 1);
          heff_take_n(v_x1_24148, 2ULL, 2);
          v_t_24154 = v_s_24153;
          break;
        }
        default: heff_nomatch(v_x1_24148);
        }
        V v_t_24155 = ({ V rv_1 = heff_get_n(v_t_24154, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24151, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24155});
      }
      case TAG_ESig: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24157 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24160;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24159 = heff_dup(heff_field(v_f_240, 1));
          v_t_24160 = v_s_24159;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24163;
        switch (heff_tag_of(v_x1_24157)) {
        case TAG_At: {
          V v_s_24162 = heff_field(v_x1_24157, 1);
          heff_take_n(v_x1_24157, 2ULL, 2);
          v_t_24163 = v_s_24162;
          break;
        }
        default: heff_nomatch(v_x1_24157);
        }
        V v_t_24164 = ({ V rv_1 = heff_get_n(v_t_24163, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24160, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24164});
      }
      case TAG_ESum: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24166 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24169;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24168 = heff_dup(heff_field(v_f_240, 1));
          v_t_24169 = v_s_24168;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24172;
        switch (heff_tag_of(v_x1_24166)) {
        case TAG_At: {
          V v_s_24171 = heff_field(v_x1_24166, 1);
          heff_take_n(v_x1_24166, 2ULL, 2);
          v_t_24172 = v_s_24171;
          break;
        }
        default: heff_nomatch(v_x1_24166);
        }
        V v_t_24173 = ({ V rv_1 = heff_get_n(v_t_24172, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24169, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24173});
      }
      case TAG_EStruct: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24175 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24178;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24177 = heff_dup(heff_field(v_f_240, 1));
          v_t_24178 = v_s_24177;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24181;
        switch (heff_tag_of(v_x1_24175)) {
        case TAG_At: {
          V v_s_24180 = heff_field(v_x1_24175, 1);
          heff_take_n(v_x1_24175, 2ULL, 2);
          v_t_24181 = v_s_24180;
          break;
        }
        default: heff_nomatch(v_x1_24175);
        }
        V v_t_24182 = ({ V rv_1 = heff_get_n(v_t_24181, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24178, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24182});
      }
      case TAG_EUpdate: {
        V v_ru_24f1_244_24EUpdate = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24185 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24188;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24187 = heff_dup(heff_field(v_f_240, 1));
          v_t_24188 = v_s_24187;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24191;
        switch (heff_tag_of(v_x1_24185)) {
        case TAG_At: {
          V v_s_24190 = heff_field(v_x1_24185, 1);
          heff_take_n(v_x1_24185, 2ULL, 2);
          v_t_24191 = v_s_24190;
          break;
        }
        default: heff_nomatch(v_x1_24185);
        }
        V v_t_24192 = ({ V rv_1 = heff_get_n(v_t_24191, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24188, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24192});
      }
      case TAG_EMatch: {
        V v_ru_24f1_244_24EMatch = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24195 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24198;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24197 = heff_dup(heff_field(v_f_240, 1));
          v_t_24198 = v_s_24197;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24201;
        switch (heff_tag_of(v_x1_24195)) {
        case TAG_At: {
          V v_s_24200 = heff_field(v_x1_24195, 1);
          heff_take_n(v_x1_24195, 2ULL, 2);
          v_t_24201 = v_s_24200;
          break;
        }
        default: heff_nomatch(v_x1_24195);
        }
        V v_t_24202 = ({ V rv_1 = heff_get_n(v_t_24201, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24198, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24202});
      }
      case TAG_ELetIn: {
        V v_ru_24f1_244_24ELetIn = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24205 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24208;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24207 = heff_dup(heff_field(v_f_240, 1));
          v_t_24208 = v_s_24207;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24211;
        switch (heff_tag_of(v_x1_24205)) {
        case TAG_At: {
          V v_s_24210 = heff_field(v_x1_24205, 1);
          heff_take_n(v_x1_24205, 2ULL, 2);
          v_t_24211 = v_s_24210;
          break;
        }
        default: heff_nomatch(v_x1_24205);
        }
        V v_t_24212 = ({ V rv_1 = heff_get_n(v_t_24211, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24208, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24212});
      }
      case TAG_EDo: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24214 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24217;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24216 = heff_dup(heff_field(v_f_240, 1));
          v_t_24217 = v_s_24216;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24220;
        switch (heff_tag_of(v_x1_24214)) {
        case TAG_At: {
          V v_s_24219 = heff_field(v_x1_24214, 1);
          heff_take_n(v_x1_24214, 2ULL, 2);
          v_t_24220 = v_s_24219;
          break;
        }
        default: heff_nomatch(v_x1_24214);
        }
        V v_t_24221 = ({ V rv_1 = heff_get_n(v_t_24220, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24217, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24221});
      }
      case TAG_ELocal: {
        V v_ru_24f1_244_24ELocal = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24224 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24227;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24226 = heff_dup(heff_field(v_f_240, 1));
          v_t_24227 = v_s_24226;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24230;
        switch (heff_tag_of(v_x1_24224)) {
        case TAG_At: {
          V v_s_24229 = heff_field(v_x1_24224, 1);
          heff_take_n(v_x1_24224, 2ULL, 2);
          v_t_24230 = v_s_24229;
          break;
        }
        default: heff_nomatch(v_x1_24224);
        }
        V v_t_24231 = ({ V rv_1 = heff_get_n(v_t_24230, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24227, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24231});
      }
      case TAG_EInvalid: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24233 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24236;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24235 = heff_dup(heff_field(v_f_240, 1));
          v_t_24236 = v_s_24235;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24239;
        switch (heff_tag_of(v_x1_24233)) {
        case TAG_At: {
          V v_s_24238 = heff_field(v_x1_24233, 1);
          heff_take_n(v_x1_24233, 2ULL, 2);
          v_t_24239 = v_s_24238;
          break;
        }
        default: heff_nomatch(v_x1_24233);
        }
        V v_t_24240 = ({ V rv_1 = heff_get_n(v_t_24239, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24236, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24240});
      }
      case TAG_EAssign: {
        heff_take_n(v_f1_244, 0ULL, 3);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24244 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24247;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24246 = heff_dup(heff_field(v_f_240, 1));
          v_t_24247 = v_s_24246;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24250;
        switch (heff_tag_of(v_x1_24244)) {
        case TAG_At: {
          V v_s_24249 = heff_field(v_x1_24244, 1);
          heff_take_n(v_x1_24244, 2ULL, 2);
          v_t_24250 = v_s_24249;
          break;
        }
        default: heff_nomatch(v_x1_24244);
        }
        V v_t_24251 = ({ V rv_1 = heff_get_n(v_t_24250, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24247, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24251});
      }
      case TAG_EWhile: {
        V v_ru_24f1_244_24EWhile = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24254 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24257;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24256 = heff_dup(heff_field(v_f_240, 1));
          v_t_24257 = v_s_24256;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24260;
        switch (heff_tag_of(v_x1_24254)) {
        case TAG_At: {
          V v_s_24259 = heff_field(v_x1_24254, 1);
          heff_take_n(v_x1_24254, 2ULL, 2);
          v_t_24260 = v_s_24259;
          break;
        }
        default: heff_nomatch(v_x1_24254);
        }
        V v_t_24261 = ({ V rv_1 = heff_get_n(v_t_24260, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24257, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EWhile, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24261});
      }
      case TAG_EFor: {
        heff_take_n(v_f1_244, 0ULL, 3);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24265 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24268;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24267 = heff_dup(heff_field(v_f_240, 1));
          v_t_24268 = v_s_24267;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24271;
        switch (heff_tag_of(v_x1_24265)) {
        case TAG_At: {
          V v_s_24270 = heff_field(v_x1_24265, 1);
          heff_take_n(v_x1_24265, 2ULL, 2);
          v_t_24271 = v_s_24270;
          break;
        }
        default: heff_nomatch(v_x1_24265);
        }
        V v_t_24272 = ({ V rv_1 = heff_get_n(v_t_24271, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24268, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24272});
      }
      case TAG_EIfThen: {
        V v_ru_24f1_244_24EIfThen = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24275 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24278;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24277 = heff_dup(heff_field(v_f_240, 1));
          v_t_24278 = v_s_24277;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24281;
        switch (heff_tag_of(v_x1_24275)) {
        case TAG_At: {
          V v_s_24280 = heff_field(v_x1_24275, 1);
          heff_take_n(v_x1_24275, 2ULL, 2);
          v_t_24281 = v_s_24280;
          break;
        }
        default: heff_nomatch(v_x1_24275);
        }
        V v_t_24282 = ({ V rv_1 = heff_get_n(v_t_24281, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24278, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EIfThen, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24282});
      }
      case TAG_EBreak: {
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24283 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24286;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24285 = heff_dup(heff_field(v_f_240, 1));
          v_t_24286 = v_s_24285;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24289;
        switch (heff_tag_of(v_x1_24283)) {
        case TAG_At: {
          V v_s_24288 = heff_field(v_x1_24283, 1);
          heff_take_n(v_x1_24283, 2ULL, 2);
          v_t_24289 = v_s_24288;
          break;
        }
        default: heff_nomatch(v_x1_24283);
        }
        V v_t_24290 = ({ V rv_1 = heff_get_n(v_t_24289, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24286, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24290});
      }
      case TAG_EContinue: {
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24291 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24294;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24293 = heff_dup(heff_field(v_f_240, 1));
          v_t_24294 = v_s_24293;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24297;
        switch (heff_tag_of(v_x1_24291)) {
        case TAG_At: {
          V v_s_24296 = heff_field(v_x1_24291, 1);
          heff_take_n(v_x1_24291, 2ULL, 2);
          v_t_24297 = v_s_24296;
          break;
        }
        default: heff_nomatch(v_x1_24291);
        }
        V v_t_24298 = ({ V rv_1 = heff_get_n(v_t_24297, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24294, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24298});
      }
      case TAG_EReturn: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24300 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24303;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24302 = heff_dup(heff_field(v_f_240, 1));
          v_t_24303 = v_s_24302;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24306;
        switch (heff_tag_of(v_x1_24300)) {
        case TAG_At: {
          V v_s_24305 = heff_field(v_x1_24300, 1);
          heff_take_n(v_x1_24300, 2ULL, 2);
          v_t_24306 = v_s_24305;
          break;
        }
        default: heff_nomatch(v_x1_24300);
        }
        V v_t_24307 = ({ V rv_1 = heff_get_n(v_t_24306, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24303, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24307});
      }
      case TAG_ENest: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24309 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24312;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24311 = heff_dup(heff_field(v_f_240, 1));
          v_t_24312 = v_s_24311;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24315;
        switch (heff_tag_of(v_x1_24309)) {
        case TAG_At: {
          V v_s_24314 = heff_field(v_x1_24309, 1);
          heff_take_n(v_x1_24309, 2ULL, 2);
          v_t_24315 = v_s_24314;
          break;
        }
        default: heff_nomatch(v_x1_24309);
        }
        V v_t_24316 = ({ V rv_1 = heff_get_n(v_t_24315, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24312, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24316});
      }
      case TAG_ELazy: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24318 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24321;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24320 = heff_dup(heff_field(v_f_240, 1));
          v_t_24321 = v_s_24320;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24324;
        switch (heff_tag_of(v_x1_24318)) {
        case TAG_At: {
          V v_s_24323 = heff_field(v_x1_24318, 1);
          heff_take_n(v_x1_24318, 2ULL, 2);
          v_t_24324 = v_s_24323;
          break;
        }
        default: heff_nomatch(v_x1_24318);
        }
        V v_t_24325 = ({ V rv_1 = heff_get_n(v_t_24324, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24321, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24325});
      }
      case TAG_ETuple: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24327 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24330;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24329 = heff_dup(heff_field(v_f_240, 1));
          v_t_24330 = v_s_24329;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24333;
        switch (heff_tag_of(v_x1_24327)) {
        case TAG_At: {
          V v_s_24332 = heff_field(v_x1_24327, 1);
          heff_take_n(v_x1_24327, 2ULL, 2);
          v_t_24333 = v_s_24332;
          break;
        }
        default: heff_nomatch(v_x1_24327);
        }
        V v_t_24334 = ({ V rv_1 = heff_get_n(v_t_24333, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24330, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24334});
      }
      case TAG_ETry: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24336 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24339;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24338 = heff_dup(heff_field(v_f_240, 1));
          v_t_24339 = v_s_24338;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24342;
        switch (heff_tag_of(v_x1_24336)) {
        case TAG_At: {
          V v_s_24341 = heff_field(v_x1_24336, 1);
          heff_take_n(v_x1_24336, 2ULL, 2);
          v_t_24342 = v_s_24341;
          break;
        }
        default: heff_nomatch(v_x1_24336);
        }
        V v_t_24343 = ({ V rv_1 = heff_get_n(v_t_24342, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24339, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24343});
      }
      case TAG_EWith: {
        heff_take_n(v_f1_244, 0ULL, 4);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24348 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24351;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24350 = heff_dup(heff_field(v_f_240, 1));
          v_t_24351 = v_s_24350;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24354;
        switch (heff_tag_of(v_x1_24348)) {
        case TAG_At: {
          V v_s_24353 = heff_field(v_x1_24348, 1);
          heff_take_n(v_x1_24348, 2ULL, 2);
          v_t_24354 = v_s_24353;
          break;
        }
        default: heff_nomatch(v_x1_24348);
        }
        V v_t_24355 = ({ V rv_1 = heff_get_n(v_t_24354, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24351, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24355});
      }
      default: return heff_nomatch(v_f1_244);
      }
    }
    default: return heff_nomatch(v_f_240);
    }
  }
  default: return heff_nomatch(v_args_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eapp(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str3, 0, "");

HeffT2 g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr(V v_x1_240, V v_little_241, V v_v_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SizeDefault: {
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
    V v_t_245 = heff_intAdd(heff_intMod(v_v_242, v_t_243), v_t_244);
    V v_t_246 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
    V v_b_247 = (g_heff_2esyntax_2epresyntax_2enatBytes(heff_box_word((((int64_t)8ULL) / ((int64_t)8ULL))), heff_intMod(v_t_245, v_t_246), ((V)&g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str0)));
    V v_f_248;
    if ((heff_dup(v_little_241) == NTAG(TAG_True))) {
      v_f_248 = ({ V a_0 = v_b_247; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str1); V r_ = (g_heff_2esyntax_2epresyntax_2ereversedBytes(a_0, a_1, a_2)); heff_drop(v_b_247); r_; });
    } else {
      v_f_248 = v_b_247;
    }
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
  }
  case TAG_SizeNumber: {
    V v_n_249 = heff_field(v_x1_240, 0);
    if ((heff_unbox_word(heff_intMod(heff_dup(v_n_249), MK_INT(8LL))) == ((int64_t)0ULL))) {
      V v_t_2411 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_n_249)));
      V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_n_249)));
      V v_t_2413 = heff_intAdd(heff_intMod(v_v_242, v_t_2411), v_t_2412);
      V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_n_249)));
      V v_b_2415 = (g_heff_2esyntax_2epresyntax_2enatBytes(heff_intDiv(heff_dup(v_n_249), MK_INT(8LL)), heff_intMod(v_t_2413, v_t_2414), ((V)&g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str2)));
      V v_f_2416;
      if ((heff_dup(v_little_241) == NTAG(TAG_True))) {
        v_f_2416 = ({ V a_0 = v_b_2415; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str3); V r_ = (g_heff_2esyntax_2epresyntax_2ereversedBytes(a_0, a_1, a_2)); heff_drop(v_b_2415); r_; });
      } else {
        v_f_2416 = v_b_2415;
      }
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
    } else {
      heff_drop(v_v_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_SizeName: {
    heff_drop(v_v_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewatchOf_str0, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewatchOf_str1, 54, "a watch must say what type it has: write `>>> (e : T)`");
Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewatchOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ewatchOf(V v_c_240) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_IsInferable: {
    V v_i_241 = heff_field(v_c_240, 0);
    V v_ru_24c_240_24IsInferable = heff_take_reuse_n(v_c_240, 1ULL, 1);
    V v_t_244;
    switch (heff_tag_of(v_i_241)) {
    case TAG_At: {
      V v_s_243 = heff_dup(heff_field(v_i_241, 1));
      v_t_244 = v_s_243;
      break;
    }
    default: heff_nomatch(v_i_241);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24c_240_24IsInferable, TAG_CInf, 1, (V[]){v_i_241}), v_t_244});
  }
  case TAG_IsCheckable: {
    V v_t_246 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2ewatchOf_str0), NTAG(TAG_Nothing)});
    V v_t_2416;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_247 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_i_247)) {
      case TAG_At: {
        V v_s_249 = heff_field(v_i_247, 1);
        heff_take_n(v_i_247, 2ULL, 2);
        v_t_2416 = v_s_249;
        break;
      }
      default: heff_nomatch(v_i_247);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2410 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_c_2410)) {
      case TAG_At: {
        V v_s_2412 = heff_field(v_c_2410, 1);
        heff_take_n(v_c_2410, 2ULL, 2);
        v_t_2416 = v_s_2412;
        break;
      }
      default: heff_nomatch(v_c_2410);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2413 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_At: {
        V v_s_2415 = heff_field(v_t_2413, 1);
        heff_take_n(v_t_2413, 2ULL, 2);
        v_t_2416 = v_s_2415;
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2417 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_t_2416})});
    V v_t_2427;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2418 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_i_2418)) {
      case TAG_At: {
        V v_s_2420 = heff_field(v_i_2418, 1);
        heff_take_n(v_i_2418, 2ULL, 2);
        v_t_2427 = v_s_2420;
        break;
      }
      default: heff_nomatch(v_i_2418);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2421 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_c_2421)) {
      case TAG_At: {
        V v_s_2423 = heff_field(v_c_2421, 1);
        heff_take_n(v_c_2421, 2ULL, 2);
        v_t_2427 = v_s_2423;
        break;
      }
      default: heff_nomatch(v_c_2421);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2424 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_t_2424)) {
      case TAG_At: {
        V v_s_2426 = heff_field(v_t_2424, 1);
        heff_take_n(v_t_2424, 2ULL, 2);
        v_t_2427 = v_s_2426;
        break;
      }
      default: heff_nomatch(v_t_2424);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_t_2427});
  }
  case TAG_IsType: {
    V v_t_2429 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2ewatchOf_str1), NTAG(TAG_Nothing)});
    V v_t_2439;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2430 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_i_2430)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_i_2430, 1);
        heff_take_n(v_i_2430, 2ULL, 2);
        v_t_2439 = v_s_2432;
        break;
      }
      default: heff_nomatch(v_i_2430);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2433 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_c_2433)) {
      case TAG_At: {
        V v_s_2435 = heff_field(v_c_2433, 1);
        heff_take_n(v_c_2433, 2ULL, 2);
        v_t_2439 = v_s_2435;
        break;
      }
      default: heff_nomatch(v_c_2433);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2436 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_t_2436)) {
      case TAG_At: {
        V v_s_2438 = heff_field(v_t_2436, 1);
        heff_take_n(v_t_2436, 2ULL, 2);
        v_t_2439 = v_s_2438;
        break;
      }
      default: heff_nomatch(v_t_2436);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2440 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2429, v_t_2439})});
    V v_t_2450;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2441 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_i_2441)) {
      case TAG_At: {
        V v_s_2443 = heff_field(v_i_2441, 1);
        heff_take_n(v_i_2441, 2ULL, 2);
        v_t_2450 = v_s_2443;
        break;
      }
      default: heff_nomatch(v_i_2441);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2444 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_c_2444)) {
      case TAG_At: {
        V v_s_2446 = heff_field(v_c_2444, 1);
        heff_take_n(v_c_2444, 2ULL, 2);
        v_t_2450 = v_s_2446;
        break;
      }
      default: heff_nomatch(v_c_2444);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2447 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_t_2447)) {
      case TAG_At: {
        V v_s_2449 = heff_field(v_t_2447, 1);
        heff_take_n(v_t_2447, 2ULL, 2);
        v_t_2450 = v_s_2449;
        break;
      }
      default: heff_nomatch(v_t_2447);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2440, v_t_2450});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewatchOf(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str0, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str1, 10, "bitsConcat");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str2, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str3, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str4, 10, "bitsConcat");

HeffT2 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(V v_segs_240, V v_sp_241, V v_x5_242) {
top: ;
  if ((heff_dup(v_x5_242) == NTAG(TAG_True))) {
    V v_xs_243 = (g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158(((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str0), v_segs_240, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_243));
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_244, heff_dup(v_sp_241)));
    V v_args_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_246));
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str1)}), heff_dup(v_sp_241)});
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_248, v_t_247}), heff_dup(v_sp_241)});
    V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_249}), heff_dup(v_sp_241)});
    V v_args_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str2)}), heff_dup(v_sp_241)});
    V v_t_2413 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2411));
    V v_f_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2412, v_t_2413}), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2414}});
  } else {
    V v_xs_2415 = (g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158(((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str3), v_segs_240, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2415));
    V v_t_2417 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2416, heff_dup(v_sp_241)));
    V v_args_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str4)}), heff_dup(v_sp_241)});
    V v_t_2420 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2418));
    V v_f_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2419, v_t_2420}), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2421}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str0, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str1, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str2, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str3, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str4, 9, "floatBits");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str5, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str6, 17, "prelude.utf8Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str7, 18, "prelude.utf16Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str8, 18, "prelude.utf32Bytes");
Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkSegment: {
      V v_v_243 = heff_field(v_x21_241, 0);
      V v_x212_244 = heff_field(v_x21_241, 1);
      V v_size_245 = heff_field(v_x21_241, 2);
      V v_little_246 = heff_field(v_x21_241, 3);
      V v_signed_247 = heff_field(v_x21_241, 4);
      heff_take_n(v_x21_241, 31ULL, 5);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_SegmentInteger: {
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(8LL), heff_dup(v_sp_242)));
        int64_t v_t_249;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)0ULL);
        }
        int64_t v_t_2410;
        if ((heff_dup(v_signed_247) == NTAG(TAG_True))) {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)0ULL);
        }
        V v_t_2411 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_249 + v_t_2410))});
        V v_t_2412 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_242)})});
        HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_2427;
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_c_2417 = v_field_2415;
            v_t_2427 = v_c_2417;
          } else {
            if ((v_tag_2414 == ((int64_t)1ULL))) {
              V v_i_2419 = v_field_2415;
              V v_t_2422;
              switch (heff_tag_of(v_i_2419)) {
              case TAG_At: {
                V v_s_2421 = heff_dup(heff_field(v_i_2419, 1));
                v_t_2422 = v_s_2421;
                break;
              }
              default: heff_nomatch(v_i_2419);
              }
              v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2419}), v_t_2422});
            } else {
              V v_t_2423 = v_field_2415;
              V v_t_2426;
              switch (heff_tag_of(v_t_2423)) {
              case TAG_At: {
                V v_s_2425 = heff_dup(heff_field(v_t_2423, 1));
                v_t_2426 = v_s_2425;
                break;
              }
              default: heff_nomatch(v_t_2423);
              }
              v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2423}), v_t_2426});
            }
          }
        }
        V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
        V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_242)}), v_t_2428});
        V v_args_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2429});
        V v_t_2431 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2430));
        V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str0)}), heff_dup(v_sp_242)});
        V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2432, v_t_2431}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2433}), v_sp_242});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        switch (heff_tag_of(v_size_245)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_242);
          HeffT2 v_t_2434 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          {
            V v_field_2436 = v_t_2434.f[1];
            int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
            if ((v_tag_2435 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2438 = v_field_2436;
              return v_c_2438;
            } else {
              if ((v_tag_2435 == ((int64_t)1ULL))) {
                V v_i_2440 = v_field_2436;
                V v_t_2443;
                switch (heff_tag_of(v_i_2440)) {
                case TAG_At: {
                  V v_s_2442 = heff_dup(heff_field(v_i_2440, 1));
                  v_t_2443 = v_s_2442;
                  break;
                }
                default: heff_nomatch(v_i_2440);
                }
                return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2440}), v_t_2443});
              } else {
                V v_t_2444 = v_field_2436;
                V v_t_2447;
                switch (heff_tag_of(v_t_2444)) {
                case TAG_At: {
                  V v_s_2446 = heff_dup(heff_field(v_t_2444, 1));
                  v_t_2447 = v_s_2446;
                  break;
                }
                default: heff_nomatch(v_t_2444);
                }
                return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2444}), v_t_2447});
              }
            }
          }
        }
        case TAG_SizeNumber: {
          V v_t_2449 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT2 v_t_2450 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          V v_t_2464;
          {
            V v_field_2452 = v_t_2450.f[1];
            int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
            if ((v_tag_2451 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2454 = v_field_2452;
              v_t_2464 = v_c_2454;
            } else {
              if ((v_tag_2451 == ((int64_t)1ULL))) {
                V v_i_2456 = v_field_2452;
                V v_t_2459;
                switch (heff_tag_of(v_i_2456)) {
                case TAG_At: {
                  V v_s_2458 = heff_dup(heff_field(v_i_2456, 1));
                  v_t_2459 = v_s_2458;
                  break;
                }
                default: heff_nomatch(v_i_2456);
                }
                v_t_2464 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2456}), v_t_2459});
              } else {
                V v_t_2460 = v_field_2452;
                V v_t_2463;
                switch (heff_tag_of(v_t_2460)) {
                case TAG_At: {
                  V v_s_2462 = heff_dup(heff_field(v_t_2460, 1));
                  v_t_2463 = v_s_2462;
                  break;
                }
                default: heff_nomatch(v_t_2460);
                }
                v_t_2464 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2460}), v_t_2463});
              }
            }
          }
          V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2464, NTAG(TAG_Nil)});
          V v_args_2466 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, v_t_2465});
          V v_t_2467 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2466));
          V v_t_2468 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str1)}), heff_dup(v_sp_242)});
          V v_t_2469 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2468, v_t_2467}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2469}), v_sp_242});
        }
        case TAG_SizeName: {
          V v_t_2473 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT2 v_t_2474 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          V v_t_2488;
          {
            V v_field_2476 = v_t_2474.f[1];
            int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
            if ((v_tag_2475 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2478 = v_field_2476;
              v_t_2488 = v_c_2478;
            } else {
              if ((v_tag_2475 == ((int64_t)1ULL))) {
                V v_i_2480 = v_field_2476;
                V v_t_2483;
                switch (heff_tag_of(v_i_2480)) {
                case TAG_At: {
                  V v_s_2482 = heff_dup(heff_field(v_i_2480, 1));
                  v_t_2483 = v_s_2482;
                  break;
                }
                default: heff_nomatch(v_i_2480);
                }
                v_t_2488 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2480}), v_t_2483});
              } else {
                V v_t_2484 = v_field_2476;
                V v_t_2487;
                switch (heff_tag_of(v_t_2484)) {
                case TAG_At: {
                  V v_s_2486 = heff_dup(heff_field(v_t_2484, 1));
                  v_t_2487 = v_s_2486;
                  break;
                }
                default: heff_nomatch(v_t_2484);
                }
                v_t_2488 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2484}), v_t_2487});
              }
            }
          }
          V v_t_2489 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2488, NTAG(TAG_Nil)});
          V v_args_2490 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2473, v_t_2489});
          V v_t_2491 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2490));
          V v_t_2492 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str2)}), heff_dup(v_sp_242)});
          V v_t_2493 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2492, v_t_2491}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2493}), v_sp_242});
        }
        default: return heff_nomatch(v_size_245);
        }
      }
      case TAG_SegmentBits: {
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        HeffT2 v_t_2494 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_24108;
        {
          V v_field_2496 = v_t_2494.f[1];
          int64_t v_tag_2495 = ((int64_t)v_t_2494.f[0]);
          if ((v_tag_2495 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_c_2498 = v_field_2496;
            v_t_24108 = v_c_2498;
          } else {
            if ((v_tag_2495 == ((int64_t)1ULL))) {
              V v_i_24100 = v_field_2496;
              V v_t_24103;
              switch (heff_tag_of(v_i_24100)) {
              case TAG_At: {
                V v_s_24102 = heff_dup(heff_field(v_i_24100, 1));
                v_t_24103 = v_s_24102;
                break;
              }
              default: heff_nomatch(v_i_24100);
              }
              v_t_24108 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24100}), v_t_24103});
            } else {
              V v_t_24104 = v_field_2496;
              V v_t_24107;
              switch (heff_tag_of(v_t_24104)) {
              case TAG_At: {
                V v_s_24106 = heff_dup(heff_field(v_t_24104, 1));
                v_t_24107 = v_s_24106;
                break;
              }
              default: heff_nomatch(v_t_24104);
              }
              v_t_24108 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24104}), v_t_24107});
            }
          }
        }
        V v_args_24109 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24108, NTAG(TAG_Nil)});
        V v_t_24110 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24109));
        V v_t_24111 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str3)}), heff_dup(v_sp_242)});
        V v_t_24112 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24111, v_t_24110}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24112}), v_sp_242});
      }
      case TAG_SegmentFloat: {
        heff_drop(v_signed_247);
        V v_t_24113 = (g_heff_2esyntax_2epresyntax_2esizeTerm(heff_dup(v_size_245), MK_INT(64LL), heff_dup(v_sp_242)));
        int64_t v_t_24114;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_24114 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_24114 = ((int64_t)0ULL);
        }
        V v_t_24115 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_24114 + ((int64_t)0ULL)))});
        V v_t_24116 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24115, heff_dup(v_sp_242)})});
        V v_t_24117 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(64LL), heff_dup(v_sp_242)));
        HeffT2 v_t_24118 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_24132;
        {
          V v_field_24120 = v_t_24118.f[1];
          int64_t v_tag_24119 = ((int64_t)v_t_24118.f[0]);
          if ((v_tag_24119 == ((int64_t)0ULL))) {
            V v_c_24122 = v_field_24120;
            v_t_24132 = v_c_24122;
          } else {
            if ((v_tag_24119 == ((int64_t)1ULL))) {
              V v_i_24124 = v_field_24120;
              V v_t_24127;
              switch (heff_tag_of(v_i_24124)) {
              case TAG_At: {
                V v_s_24126 = heff_dup(heff_field(v_i_24124, 1));
                v_t_24127 = v_s_24126;
                break;
              }
              default: heff_nomatch(v_i_24124);
              }
              v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24124}), v_t_24127});
            } else {
              V v_t_24128 = v_field_24120;
              V v_t_24131;
              switch (heff_tag_of(v_t_24128)) {
              case TAG_At: {
                V v_s_24130 = heff_dup(heff_field(v_t_24128, 1));
                v_t_24131 = v_s_24130;
                break;
              }
              default: heff_nomatch(v_t_24128);
              }
              v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24128}), v_t_24131});
            }
          }
        }
        V v_t_24133 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24132, NTAG(TAG_Nil)});
        V v_args_24134 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24117, v_t_24133});
        V v_t_24135 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24134));
        V v_t_24136 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str4)}), heff_dup(v_sp_242)});
        V v_t_24137 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24136, v_t_24135}), heff_dup(v_sp_242)});
        V v_t_24138 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24137}), heff_dup(v_sp_242)});
        V v_t_24139 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24138, NTAG(TAG_Nil)});
        V v_t_24140 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24116, heff_dup(v_sp_242)}), v_t_24139});
        V v_args_24141 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24113, v_t_24140});
        V v_t_24142 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24141));
        V v_t_24143 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str5)}), heff_dup(v_sp_242)});
        V v_t_24144 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24143, v_t_24142}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24144}), v_sp_242});
      }
      case TAG_SegmentUtf: {
        V v_x2121_24145 = heff_field(v_x212_244, 0);
        V v_ru_24x212_244_24SegmentUtf = heff_take_reuse_n(v_x212_244, 1ULL, 1);
        heff_drop(v_size_245);
        heff_drop(v_signed_247);
        if (heff_intEq_c_lent(v_x2121_24145, MK_INT(8LL), 2)) {
          heff_drop(v_little_246);
          heff_drop(v_x2121_24145);
          V v_t_24147 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
          V v_args_24148 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24147, NTAG(TAG_Nil)});
          V v_t_24149 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24148));
          V v_t_24150 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str6)}), heff_dup(v_sp_242)});
          V v_t_24151 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24150, v_t_24149}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_CInf, 1, (V[]){v_t_24151}), v_sp_242});
        } else {
          if (heff_intEq_c(v_x2121_24145, MK_INT(16LL))) {
            int64_t v_t_24153;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24153 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24153 = ((int64_t)0ULL);
            }
            V v_t_24154 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24153 + ((int64_t)0ULL)))});
            V v_t_24155 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24154, heff_dup(v_sp_242)})});
            V v_t_24156 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24157 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24156, NTAG(TAG_Nil)});
            V v_args_24158 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24155, heff_dup(v_sp_242)}), v_t_24157});
            V v_t_24159 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24158));
            V v_t_24160 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str7)}), heff_dup(v_sp_242)});
            V v_t_24161 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24160, v_t_24159}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24161}), v_sp_242});
          } else {
            int64_t v_t_24162;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24162 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24162 = ((int64_t)0ULL);
            }
            V v_t_24163 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24162 + ((int64_t)0ULL)))});
            V v_t_24164 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24163, heff_dup(v_sp_242)})});
            V v_t_24165 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24166 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24165, NTAG(TAG_Nil)});
            V v_args_24167 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24164, heff_dup(v_sp_242)}), v_t_24166});
            V v_t_24168 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24167));
            V v_t_24169 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str8)}), heff_dup(v_sp_242)});
            V v_t_24170 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24169, v_t_24168}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24170}), v_sp_242});
          }
        }
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_ExplicitParam: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_t_245 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24ExplicitParam = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      HeffT2 v_t_246 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_245));
      V v_t_2420;
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_c_2410 = v_field_248;
          V v_t_2413;
          switch (heff_tag_of(v_c_2410)) {
          case TAG_At: {
            V v_s_2412 = heff_dup(heff_field(v_c_2410, 1));
            v_t_2413 = v_s_2412;
            break;
          }
          default: heff_nomatch(v_c_2410);
          }
          v_t_2420 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2410}), v_t_2413});
        } else {
          if ((v_tag_247 == ((int64_t)1ULL))) {
            V v_i_2415 = v_field_248;
            V v_t_2418;
            switch (heff_tag_of(v_i_2415)) {
            case TAG_At: {
              V v_s_2417 = heff_dup(heff_field(v_i_2415, 1));
              v_t_2418 = v_s_2417;
              break;
            }
            default: heff_nomatch(v_i_2415);
            }
            v_t_2420 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2415}), v_t_2418});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2419 = v_field_248;
            v_t_2420 = v_t_2419;
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_x_243, v_xsp_244, v_t_2420}), v_sp_242});
    }
    case TAG_ImplicitParam: {
      V v_x_2421 = heff_field(v_x21_241, 0);
      V v_xsp_2422 = heff_field(v_x21_241, 1);
      V v_t_2423 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24ImplicitParam = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      HeffT2 v_t_2424 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2423));
      V v_t_2438;
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_c_2428 = v_field_2426;
          V v_t_2431;
          switch (heff_tag_of(v_c_2428)) {
          case TAG_At: {
            V v_s_2430 = heff_dup(heff_field(v_c_2428, 1));
            v_t_2431 = v_s_2430;
            break;
          }
          default: heff_nomatch(v_c_2428);
          }
          v_t_2438 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2428}), v_t_2431});
        } else {
          if ((v_tag_2425 == ((int64_t)1ULL))) {
            V v_i_2433 = v_field_2426;
            V v_t_2436;
            switch (heff_tag_of(v_i_2433)) {
            case TAG_At: {
              V v_s_2435 = heff_dup(heff_field(v_i_2433, 1));
              v_t_2436 = v_s_2435;
              break;
            }
            default: heff_nomatch(v_i_2433);
            }
            v_t_2438 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2433}), v_t_2436});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2437 = v_field_2426;
            v_t_2438 = v_t_2437;
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_x_2421, v_xsp_2422, v_t_2438}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24PiNamed = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_246;
    switch (heff_tag_of(v_t_243)) {
    case TAG_At: {
      V v_n_244 = heff_field(v_t_243, 0);
      V v_sp_245 = heff_field(v_t_243, 1);
      heff_take_n(v_t_243, 3ULL, 2);
      v_t_246 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_245, v_n_244));
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_241, v_sp_242, v_t_246});
  }
  case TAG_PiImplicit: {
    V v_x_247 = heff_field(v_x2_240, 0);
    V v_sp_248 = heff_field(v_x2_240, 1);
    V v_sp2_249 = heff_field(v_x2_240, 2);
    V v_t_2410 = heff_field(v_x2_240, 3);
    V v_d_2411 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24PiImplicit = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_2414;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_At: {
      V v_n_2412 = heff_field(v_t_2410, 0);
      V v_sp_2413 = heff_field(v_t_2410, 1);
      heff_take_n(v_t_2410, 3ULL, 2);
      v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2413, v_n_2412));
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2420;
    switch (heff_tag_of(v_d_2411)) {
    case TAG_Nothing: {
      v_t_2420 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2415 = heff_field(v_d_2411, 0);
      V v_ru_24d_2411_24Just = heff_take_reuse_n(v_d_2411, 1ULL, 1);
      V v_t_2419;
      switch (heff_tag_of(v_x_2415)) {
      case TAG_At: {
        V v_n_2416 = heff_field(v_x_2415, 0);
        V v_sp_2417 = heff_field(v_x_2415, 1);
        V v_ru_24x_2415_24At = heff_take_reuse_n(v_x_2415, 3ULL, 2);
        V v_t_2418 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2416));
        v_t_2419 = heff_tag_at_n(v_ru_24x_2415_24At, TAG_At, 2, (V[]){v_t_2418, v_sp_2417});
        break;
      }
      default: heff_nomatch(v_x_2415);
      }
      v_t_2420 = heff_tag_at_n(v_ru_24d_2411_24Just, TAG_Just, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_d_2411);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_247, v_sp_248, v_sp2_249, v_t_2414, v_t_2420});
  }
  case TAG_PiInstance: {
    V v_x_2421 = heff_field(v_x2_240, 0);
    V v_sp_2422 = heff_field(v_x2_240, 1);
    V v_sp2_2423 = heff_field(v_x2_240, 2);
    V v_t_2424 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24PiInstance = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2427;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_At: {
      V v_n_2425 = heff_field(v_t_2424, 0);
      V v_sp_2426 = heff_field(v_t_2424, 1);
      heff_take_n(v_t_2424, 3ULL, 2);
      v_t_2427 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2426, v_n_2425));
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2421, v_sp_2422, v_sp2_2423, v_t_2427});
  }
  case TAG_PiAnon: {
    V v_t_2428 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24PiAnon = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2431;
    switch (heff_tag_of(v_t_2428)) {
    case TAG_At: {
      V v_n_2429 = heff_field(v_t_2428, 0);
      V v_sp_2430 = heff_field(v_t_2428, 1);
      heff_take_n(v_t_2428, 3ULL, 2);
      v_t_2431 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2430, v_n_2429));
      break;
    }
    default: heff_nomatch(v_t_2428);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2431});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_TPi: {
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_245 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_244, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_240});
  }
  case TAG_TSig: {
    V v_fs_246 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TSig = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_247 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(heff_tag_at_n(v_ru_24n_241_24TSig, TAG_TSig, 1, (V[]){v_fs_246})));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_sp_240});
  }
  case TAG_TSum: {
    V v_vs_248 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TSum = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_249 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(heff_tag_at_n(v_ru_24n_241_24TSum, TAG_TSum, 1, (V[]){v_vs_248})));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_sp_240});
  }
  case TAG_TType: {
    V v_t_2410 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2411 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_sp_240});
  }
  case TAG_TInt: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2413 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_TFloat: {
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2415 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_sp_240});
  }
  case TAG_TString: {
    V v_t_2416 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2417 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2416, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_sp_240});
  }
  case TAG_TRune: {
    V v_t_2418 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2419 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_240});
  }
  case TAG_TArray: {
    V v_t_2421 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2422 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2421, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_sp_240});
  }
  case TAG_TFixed: {
    V v_t_2424 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2425 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_sp_240});
  }
  case TAG_TInf: {
    V v_i_2426 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TInf = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2429;
    switch (heff_tag_of(v_i_2426)) {
    case TAG_At: {
      V v_n_2427 = heff_field(v_i_2426, 0);
      V v_sp_2428 = heff_field(v_i_2426, 1);
      heff_take_n(v_i_2426, 3ULL, 2);
      v_t_2429 = (g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(v_sp_2428, v_n_2427));
      break;
    }
    default: heff_nomatch(v_i_2426);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24TInf, TAG_TInf, 1, (V[]){v_t_2429}), v_sp_240});
  }
  case TAG_TChk: {
    V v_c_2430 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TChk = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2433;
    switch (heff_tag_of(v_c_2430)) {
    case TAG_At: {
      V v_n_2431 = heff_field(v_c_2430, 0);
      V v_sp_2432 = heff_field(v_c_2430, 1);
      heff_take_n(v_c_2430, 3ULL, 2);
      v_t_2433 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2432, v_n_2431));
      break;
    }
    default: heff_nomatch(v_c_2430);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24TChk, TAG_TChk, 1, (V[]){v_t_2433}), v_sp_240});
  }
  case TAG_TNominal: {
    V v_t_2435 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2436 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2435, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2436, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(a[0], a[1]);
}