// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_EApp 33163
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFor 37939
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ENest 28629
#define TAG_EReturn 59059
#define TAG_ETry 51493
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_IApp 21275
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_IPrim 59489
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_MkBinding 51651
#define TAG_MkSegment 38079
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define LBL_end 310101
#define LBL_start 311115900
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1164514720x1739674580_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1164514720x1739674580_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1978526359x90381742_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s42976669x698242400_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s564340418x743780676_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(V, V);
V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_clo;
V g_heff_2esyntax_2epresyntax_2ebytesTerm(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesTerm_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2ejumpE(V);
V g_heff_2esyntax_2epresyntax_2ejumpE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpE_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24s1538488470x1742347707_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2etwoTo(V);
V g_heff_2esyntax_2epresyntax_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etwoTo_clo;
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(V, V);
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_clo;
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2ewatchOf(V);
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeBinary_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
V g_list_2eany_24s2003678755x1820404042(V);
V g_list_2eany_24s2003678755x1820404042_entry(V self, V *a);
extern Clo g_list_2eany_24s2003678755x1820404042_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1992667171x110340492(V);
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
Clo g_heff_2esyntax_2epresyntax_2etwoTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etwoTo_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2etwoTo(V v_k_240) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    return MK_INT(1LL);
  } else {
    V v_t_241 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_intSub(v_k_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(2LL), v_t_241);
  }
}
V g_heff_2esyntax_2epresyntax_2etwoTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etwoTo(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2elastOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elastOr_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2elastOr(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop(v_z_240);
      return heff_dup(v_x_242);
    }
    case TAG_Cons: {
      V t_0 = v_z_240;
      V t_1 = v_x22_243;
      v_z_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2elastOr(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2epresyntax_2eapp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eapp_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eapp(V v_f_240, V v_args_241) {
top: ;
  switch (heff_tag_of(v_args_241)) {
  case TAG_Nil: {
    return v_f_240;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_f_240)) {
    case TAG_At: {
      V v_f1_244 = heff_dup(heff_field(v_f_240, 0));
      switch (heff_tag_of(v_f1_244)) {
      case TAG_EApp: {
        V v_h_246 = heff_field(v_f1_244, 0);
        V v_xs_247 = heff_field(v_f1_244, 1);
        V v_ru_24f1_244_24EApp = heff_take_reuse_n(v_f1_244, 3ULL, 2);
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_sp_249 = heff_field(v_f_240, 1);
          V v_ru_24f_240_24At = heff_take_reuse_n(v_f_240, 2ULL, 2);
          V v_t_2410 = (g_prelude_2e_2b_2b(v_xs_247, heff_dup(v_args_241)));
          V v_x1_2411 = ({ V a_0 = heff_dup(v_h_246); V a_1 = v_args_241; V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, a_1)); heff_drop_tag(v_args_241, 2); r_; });
          V v_t_2414;
          switch (heff_tag_of(v_x1_2411)) {
          case TAG_At: {
            V v_s_2413 = heff_field(v_x1_2411, 1);
            heff_take_n(v_x1_2411, 2ULL, 2);
            v_t_2414 = v_s_2413;
            break;
          }
          default: heff_nomatch(v_x1_2411);
          }
          V v_t_2415 = ({ V rv_1 = heff_get_n(v_t_2414, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_249, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24f_240_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24f1_244_24EApp, TAG_EApp, 2, 1ULL, (V[]){v_h_246, v_t_2410}), v_t_2415});
        }
        default: return heff_nomatch(v_f_240);
        }
      }
      default: {
        heff_drop(v_f1_244);
        V v_a_2418;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2417 = heff_dup(heff_field(v_f_240, 1));
          v_a_2418 = v_s_2417;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2419 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2422;
        switch (heff_tag_of(v_x1_2419)) {
        case TAG_At: {
          V v_s_2421 = heff_field(v_x1_2419, 1);
          heff_take_n(v_x1_2419, 2ULL, 2);
          v_t_2422 = v_s_2421;
          break;
        }
        default: heff_nomatch(v_x1_2419);
        }
        V v_t_2423 = ({ V rv_1 = heff_get_n(v_t_2422, 1, 2); V rr_ = heff_rec_reuse_nf(v_a_2418, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2423});
      }
      }
    }
    default: return heff_nomatch(v_f_240);
    }
  }
  default: return heff_nomatch(v_args_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eapp(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1164514720x1739674580_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkBinding: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24MkBinding = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_a_2438;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2438 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_248)) {
          case TAG_At: {
            V v_a_249 = heff_dup(heff_field(v_a_248, 0));
            switch (heff_tag_of(v_a_249)) {
            case TAG_ELam: {
              heff_take_n(v_a_249, 0ULL, 2);
              switch (heff_tag_of(v_a_248)) {
              case TAG_At: {
                v_a_2438 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_248);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_a_249, 0ULL, 1);
              switch (heff_tag_of(v_a_248)) {
              case TAG_At: {
                v_a_2438 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_248);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_a_249, 0ULL, 1);
              switch (heff_tag_of(v_a_248)) {
              case TAG_At: {
                v_a_2438 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_248);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_a_249, 0ULL, 1);
              switch (heff_tag_of(v_a_248)) {
              case TAG_At: {
                v_a_2438 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_248);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_a_249, 0ULL, 1);
              switch (heff_tag_of(v_a_248)) {
              case TAG_At: {
                v_a_2438 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_248);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_a_249, 0ULL, 4);
              switch (heff_tag_of(v_a_248)) {
              case TAG_At: {
                v_a_2438 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_248);
              }
              break;
            }
            default: {
              heff_drop(v_a_249);
              HeffT2 v_t_2433 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_248)));
              {
                V v_field_2434 = v_t_2433.f[0];
                V v_field_2435 = v_t_2433.f[1];
                V v_a_2436 = v_field_2434;
                V v_a_2437 = v_field_2435;
                heff_drop(v_a_2437);
                v_a_2438 = v_a_2436;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_248);
          }
        }
        V v_t_2439 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_244_24MkBinding, TAG_MkBinding, 3, 7ULL, (V[]){v_a_246, v_a_247, v_a_248}), v_a_245});
        V v_cell_2440 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2439, heff_hole()});
        HeffT2 v_t_2441 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1164514720x1739674580_24dps_24cpr(v_a_2438, v_xs_243, v_cell_2440));
        {
          V v_field_2442 = v_t_2441.f[0];
          V v_field_2443 = v_t_2441.f[1];
          V v_x_2444 = v_field_2442;
          V v__5f_2445 = v_field_2443;
          heff_drop(v__5f_2445);
          return ((HeffT2){{v_x_2444, v_cell_2440}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s42976669x698242400_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_245)) {
    case TAG_At: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24At = heff_take_reuse_n(v_x_245, 3ULL, 2);
      switch (heff_tag_of(v_a_247)) {
      case TAG_SetPath: {
        V v_a_249 = heff_field(v_a_247, 0);
        V v_a_2410 = heff_field(v_a_247, 1);
        V v_ru_24a_247_24SetPath = heff_take_reuse_n(v_a_247, 3ULL, 2);
        V v_a_2411;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2411 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_a_2411 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_2410)));
        }
        V v_t_2412 = heff_tag_re_n(v_ru_24x_245_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_247_24SetPath, TAG_SetPath, 2, 3ULL, (V[]){v_a_249, v_a_2410}), v_a_248});
        V v_cell_2413 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
        V v_u_2414 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2413);
        V t_0 = v_a_2411;
        V t_1 = v_xs_246;
        V t_2 = v_u_2414;
        v_st_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_a_247)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2ejumpE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ejumpE_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ejumpE(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_ELam: {
      heff_take_n(v_e1_241, 0ULL, 2);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EWhile: {
      V v_e11_247 = heff_field(v_e1_241, 0);
      V v_body_248 = heff_field(v_e1_241, 1);
      heff_take_n(v_e1_241, 3ULL, 2);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        switch (heff_tag_of(v_e11_247)) {
        case TAG_At: {
          V v_e1_2411 = heff_dup(heff_field(v_e11_247, 0));
          switch (heff_tag_of(v_e1_2411)) {
          case TAG_ELam: {
            heff_take_n(v_e1_2411, 0ULL, 2);
            switch (heff_tag_of(v_e11_247)) {
            case TAG_At: {
              heff_take_n(v_e11_247, 0ULL, 2);
              HEFF_LAST return g_list_2eany_24s2003678755x1820404042(v_body_248);
            }
            default: return heff_nomatch(v_e11_247);
            }
          }
          case TAG_EReturn: {
            heff_take_n(v_e1_2411, 0ULL, 1);
            heff_drop(v_body_248);
            switch (heff_tag_of(v_e11_247)) {
            case TAG_At: {
              heff_take_n(v_e11_247, 0ULL, 2);
              return NTAG(TAG_True);
            }
            default: return heff_nomatch(v_e11_247);
            }
          }
          default: {
            heff_drop(v_e1_2411);
            HeffT2 v_t_2420 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e11_247));
            {
              V v_field_2421 = v_t_2420.f[0];
              V v_field_2422 = v_t_2420.f[1];
              V v_x_2423 = v_field_2421;
              V v_y_2424 = v_field_2422;
              heff_drop(v_y_2424);
              V v_t_2425 = v_x_2423;
              if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
                heff_drop(v_body_248);
                heff_drop(v_t_2425);
                return NTAG(TAG_True);
              } else {
                heff_drop(v_t_2425);
                HEFF_LAST return g_list_2eany_24s2003678755x1820404042(v_body_248);
              }
            }
          }
          }
        }
        default: return heff_nomatch(v_e11_247);
        }
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EFor: {
      V v_e12_2427 = heff_field(v_e1_241, 1);
      V v_body_2428 = heff_field(v_e1_241, 2);
      heff_take_n(v_e1_241, 6ULL, 3);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        switch (heff_tag_of(v_e12_2427)) {
        case TAG_At: {
          V v_e1_2431 = heff_dup(heff_field(v_e12_2427, 0));
          switch (heff_tag_of(v_e1_2431)) {
          case TAG_ELam: {
            heff_take_n(v_e1_2431, 0ULL, 2);
            switch (heff_tag_of(v_e12_2427)) {
            case TAG_At: {
              heff_take_n(v_e12_2427, 0ULL, 2);
              HEFF_LAST return g_list_2eany_24s2003678755x1820404042(v_body_2428);
            }
            default: return heff_nomatch(v_e12_2427);
            }
          }
          case TAG_EReturn: {
            heff_take_n(v_e1_2431, 0ULL, 1);
            heff_drop(v_body_2428);
            switch (heff_tag_of(v_e12_2427)) {
            case TAG_At: {
              heff_take_n(v_e12_2427, 0ULL, 2);
              return NTAG(TAG_True);
            }
            default: return heff_nomatch(v_e12_2427);
            }
          }
          default: {
            heff_drop(v_e1_2431);
            HeffT2 v_t_2440 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e12_2427));
            {
              V v_field_2441 = v_t_2440.f[0];
              V v_field_2442 = v_t_2440.f[1];
              V v_x_2443 = v_field_2441;
              V v_y_2444 = v_field_2442;
              heff_drop(v_y_2444);
              V v_t_2445 = v_x_2443;
              if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
                heff_drop(v_body_2428);
                heff_drop(v_t_2445);
                return NTAG(TAG_True);
              } else {
                heff_drop(v_t_2445);
                HEFF_LAST return g_list_2eany_24s2003678755x1820404042(v_body_2428);
              }
            }
          }
          }
        }
        default: return heff_nomatch(v_e12_2427);
        }
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EBreak: {
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EContinue: {
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EReturn: {
      heff_take_n(v_e1_241, 0ULL, 1);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    default: {
      heff_drop(v_e1_241);
      HeffT2 v_t_2453 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2454 = v_t_2453.f[0];
        V v_field_2455 = v_t_2453.f[1];
        V v_x_2456 = v_field_2454;
        V v_y_2457 = v_field_2455;
        heff_drop(v_y_2457);
        return v_x_2456;
      }
    }
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ejumpE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ejumpE(a[0]);
}

HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24s1538488470x1742347707_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_sp_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_StmtBind: {
      V v_x_244 = heff_field(v_x31_242, 0);
      V v_xsp_245 = heff_field(v_x31_242, 1);
      V v_e_246 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24StmtBind = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_247 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_e_246), v_st_240));
      return ((HeffT3){{v_x_247, heff_tag_re_n(v_ru_24x31_242_24StmtBind, TAG_StmtBind, 3, 7ULL, (V[]){v_x_244, v_xsp_245, v_e_246}), v_sp_243}});
    }
    case TAG_StmtLet: {
      V v_p_248 = heff_field(v_x31_242, 0);
      V v_e_249 = heff_field(v_x31_242, 1);
      heff_take_n(v_x31_242, 3ULL, 2);
      V v_x_2410 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_e_249), v_st_240));
      return ((HeffT3){{v_x_2410, heff_tag_at_n(v_ru_24x3_241_24At, TAG_StmtLet, 2, (V[]){v_p_248, v_e_249}), v_sp_243}});
    }
    case TAG_StmtExpr: {
      V v_e_2411 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24StmtExpr = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_2412 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_e_2411), v_st_240));
      return ((HeffT3){{v_x_2412, heff_tag_re_n(v_ru_24x31_242_24StmtExpr, TAG_StmtExpr, 1, 1ULL, (V[]){v_e_2411}), v_sp_243}});
    }
    case TAG_StmtLetMut: {
      V v_x_2413 = heff_field(v_x31_242, 0);
      V v_xsp_2414 = heff_field(v_x31_242, 1);
      V v_e_2415 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24StmtLetMut = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_2416 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_e_2415), v_st_240));
      return ((HeffT3){{v_x_2416, heff_tag_re_n(v_ru_24x31_242_24StmtLetMut, TAG_StmtLetMut, 3, 7ULL, (V[]){v_x_2413, v_xsp_2414, v_e_2415}), v_sp_243}});
    }
    case TAG_StmtLetElse: {
      V v_p_2417 = heff_field(v_x31_242, 0);
      V v_e_2418 = heff_field(v_x31_242, 1);
      V v_ss_2419 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24StmtLetElse = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_2420 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_e_2418), v_st_240));
      HeffT2 v_t_2421 = (g_heff_2esyntax_2epresyntax_2eaccList_24s564340418x743780676_24cpr(v_x_2420, v_ss_2419));
      {
        V v_field_2422 = v_t_2421.f[0];
        V v_field_2423 = v_t_2421.f[1];
        V v_x_2424 = v_field_2422;
        V v_y_2425 = v_field_2423;
        return ((HeffT3){{v_x_2424, heff_tag_re_n(v_ru_24x31_242_24StmtLetElse, TAG_StmtLetElse, 3, 3ULL, (V[]){v_p_2417, v_e_2418, v_y_2425}), v_sp_243}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1978526359x90381742_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_245)) {
    case TAG_At: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24At = heff_take_reuse_n(v_x_245, 3ULL, 2);
      switch (heff_tag_of(v_a_247)) {
      case TAG_MkBinding: {
        V v_a_249 = heff_field(v_a_247, 0);
        V v_a_2410 = heff_field(v_a_247, 1);
        V v_a_2411 = heff_field(v_a_247, 2);
        V v_ru_24a_247_24MkBinding = heff_take_reuse_n(v_a_247, 7ULL, 3);
        V v_a_2412 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_a_2411), v_st_240));
        V v_t_2413 = heff_tag_re_n(v_ru_24x_245_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_247_24MkBinding, TAG_MkBinding, 3, 7ULL, (V[]){v_a_249, v_a_2410, v_a_2411}), v_a_248});
        V v_cell_2414 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
        V v_u_2415 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2414);
        V t_0 = v_a_2412;
        V t_1 = v_xs_246;
        V t_2 = v_u_2415;
        v_st_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_a_247)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2ewholeBinary_24cpr(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_acc_241}});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_At: {
      V v_seg_244 = heff_field(v_x11_242, 0);
      HeffT2 v_t_246 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_244));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_s_249 = v_field_248;
          V t_0 = v_rest_243;
          V t_1 = heff_strAppend(v_acc_241, v_s_249);
          v_x1_240 = t_0;
          v_acc_241 = t_1;
          goto top;
        } else {
          heff_drop(v_acc_241);
          heff_drop(v_field_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewatchOf_str0, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewatchOf_str1, 54, "a watch must say what type it has: write `>>> (e : T)`");
Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewatchOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ewatchOf(V v_c_240) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_IsInferable: {
    V v_i_241 = heff_field(v_c_240, 0);
    V v_ru_24c_240_24IsInferable = heff_take_reuse_n(v_c_240, 1ULL, 1);
    V v_t_244;
    switch (heff_tag_of(v_i_241)) {
    case TAG_At: {
      V v_s_243 = heff_dup(heff_field(v_i_241, 1));
      v_t_244 = v_s_243;
      break;
    }
    default: heff_nomatch(v_i_241);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24c_240_24IsInferable, TAG_CInf, 1, (V[]){v_i_241}), v_t_244});
  }
  case TAG_IsCheckable: {
    V v_t_2415;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_246 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_i_246)) {
      case TAG_At: {
        V v_s_248 = heff_field(v_i_246, 1);
        heff_take_n(v_i_246, 2ULL, 2);
        v_t_2415 = v_s_248;
        break;
      }
      default: heff_nomatch(v_i_246);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_249 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_c_249)) {
      case TAG_At: {
        V v_s_2411 = heff_field(v_c_249, 1);
        heff_take_n(v_c_249, 2ULL, 2);
        v_t_2415 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_c_249);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2412 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_At: {
        V v_s_2414 = heff_field(v_t_2412, 1);
        heff_take_n(v_t_2412, 2ULL, 2);
        v_t_2415 = v_s_2414;
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2425;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2416 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_i_2416)) {
      case TAG_At: {
        V v_s_2418 = heff_field(v_i_2416, 1);
        heff_take_n(v_i_2416, 2ULL, 2);
        v_t_2425 = v_s_2418;
        break;
      }
      default: heff_nomatch(v_i_2416);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2419 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_c_2419)) {
      case TAG_At: {
        V v_s_2421 = heff_field(v_c_2419, 1);
        heff_take_n(v_c_2419, 2ULL, 2);
        v_t_2425 = v_s_2421;
        break;
      }
      default: heff_nomatch(v_c_2419);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2422 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_t_2422)) {
      case TAG_At: {
        V v_s_2424 = heff_field(v_t_2422, 1);
        heff_take_n(v_t_2422, 2ULL, 2);
        v_t_2425 = v_s_2424;
        break;
      }
      default: heff_nomatch(v_t_2422);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2426 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2ewatchOf_str0), NTAG(TAG_Nothing)});
    V v_t_2427 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2426, v_t_2415})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2427, v_t_2425});
  }
  case TAG_IsType: {
    V v_t_2438;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2429 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_i_2429)) {
      case TAG_At: {
        V v_s_2431 = heff_field(v_i_2429, 1);
        heff_take_n(v_i_2429, 2ULL, 2);
        v_t_2438 = v_s_2431;
        break;
      }
      default: heff_nomatch(v_i_2429);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2432 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_c_2432)) {
      case TAG_At: {
        V v_s_2434 = heff_field(v_c_2432, 1);
        heff_take_n(v_c_2432, 2ULL, 2);
        v_t_2438 = v_s_2434;
        break;
      }
      default: heff_nomatch(v_c_2432);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2435 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_t_2435)) {
      case TAG_At: {
        V v_s_2437 = heff_field(v_t_2435, 1);
        heff_take_n(v_t_2435, 2ULL, 2);
        v_t_2438 = v_s_2437;
        break;
      }
      default: heff_nomatch(v_t_2435);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2448;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2439 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_i_2439)) {
      case TAG_At: {
        V v_s_2441 = heff_field(v_i_2439, 1);
        heff_take_n(v_i_2439, 2ULL, 2);
        v_t_2448 = v_s_2441;
        break;
      }
      default: heff_nomatch(v_i_2439);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2442 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_c_2442)) {
      case TAG_At: {
        V v_s_2444 = heff_field(v_c_2442, 1);
        heff_take_n(v_c_2442, 2ULL, 2);
        v_t_2448 = v_s_2444;
        break;
      }
      default: heff_nomatch(v_c_2442);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2445 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_t_2445)) {
      case TAG_At: {
        V v_s_2447 = heff_field(v_t_2445, 1);
        heff_take_n(v_t_2445, 2ULL, 2);
        v_t_2448 = v_s_2447;
        break;
      }
      default: heff_nomatch(v_t_2445);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2449 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2ewatchOf_str1), NTAG(TAG_Nothing)});
    V v_t_2450 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2449, v_t_2438})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2450, v_t_2448});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewatchOf(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str0, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str1, 10, "bitsConcat");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str2, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str3, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str4, 10, "bitsConcat");

HeffT3 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(V v_segs_240, V v_sp_241, V v_x5_242) {
top: ;
  if ((heff_dup(v_x5_242) == NTAG(TAG_True))) {
    V v_xs_243 = (g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178(((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str0), v_segs_240, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_243));
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_244, heff_dup(v_sp_241)));
    V v_args_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_246));
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str1)}), heff_dup(v_sp_241)});
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_248, v_t_247}), heff_dup(v_sp_241)});
    V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_249}), heff_dup(v_sp_241)});
    V v_args_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    V v_t_2412 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2411));
    V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str2)}), heff_dup(v_sp_241)});
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_n(TAG_IApp, 2, (V[]){v_t_2413, v_t_2412}), v_sp_241}});
  } else {
    V v_xs_2414 = (g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178(((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str3), v_segs_240, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2414));
    V v_t_2416 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2415, heff_dup(v_sp_241)));
    V v_args_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    V v_t_2418 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2417));
    V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str4)}), heff_dup(v_sp_241)});
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_n(TAG_IApp, 2, (V[]){v_t_2419, v_t_2418}), v_sp_241}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str0, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str1, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str2, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str3, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str4, 9, "floatBits");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str5, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str6, 17, "prelude.utf8Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str7, 18, "prelude.utf16Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str8, 18, "prelude.utf32Bytes");
Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkSegment: {
      V v_v_243 = heff_field(v_x21_241, 0);
      V v_x212_244 = heff_field(v_x21_241, 1);
      V v_size_245 = heff_field(v_x21_241, 2);
      V v_little_246 = heff_field(v_x21_241, 3);
      V v_signed_247 = heff_field(v_x21_241, 4);
      heff_take_n(v_x21_241, 31ULL, 5);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_SegmentInteger: {
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(8LL), heff_dup(v_sp_242)));
        int64_t v_t_249;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)0ULL);
        }
        int64_t v_t_2410;
        if ((heff_dup(v_signed_247) == NTAG(TAG_True))) {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)0ULL);
        }
        HeffT3 v_t_2411 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        {
          V v_field_2413 = v_t_2411.f[1];
          V v_field_2414 = v_t_2411.f[2];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          V v_t_2424;
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_c_2415 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2413, v_field_2414});
            v_t_2424 = v_c_2415;
          } else {
            if ((v_tag_2412 == ((int64_t)1ULL))) {
              V v_i_2416 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2413, v_field_2414});
              V v_t_2419;
              switch (heff_tag_of(v_i_2416)) {
              case TAG_At: {
                V v_s_2418 = heff_dup(heff_field(v_i_2416, 1));
                v_t_2419 = v_s_2418;
                break;
              }
              default: heff_nomatch(v_i_2416);
              }
              v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2416}), v_t_2419});
            } else {
              V v_t_2420 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2413, v_field_2414});
              V v_t_2423;
              switch (heff_tag_of(v_t_2420)) {
              case TAG_At: {
                V v_s_2422 = heff_dup(heff_field(v_t_2420, 1));
                v_t_2423 = v_s_2422;
                break;
              }
              default: heff_nomatch(v_t_2420);
              }
              v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2420}), v_t_2423});
            }
          }
          V v_t_2425 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_249 + v_t_2410))});
          V v_t_2426 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2425, heff_dup(v_sp_242)})});
          V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
          V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2426, heff_dup(v_sp_242)}), v_t_2427});
          V v_args_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2428});
          V v_t_2430 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2429));
          V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str0)}), heff_dup(v_sp_242)});
          V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2431, v_t_2430}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2432}), v_sp_242});
        }
      }
      case TAG_SegmentBinary: {
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        switch (heff_tag_of(v_size_245)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_242);
          HeffT3 v_t_2433 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          {
            V v_field_2435 = v_t_2433.f[1];
            V v_field_2436 = v_t_2433.f[2];
            int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
            if ((v_tag_2434 == ((int64_t)0ULL))) {
              V v_c_2437 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2435, v_field_2436});
              return v_c_2437;
            } else {
              if ((v_tag_2434 == ((int64_t)1ULL))) {
                V v_i_2438 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2435, v_field_2436});
                V v_t_2441;
                switch (heff_tag_of(v_i_2438)) {
                case TAG_At: {
                  V v_s_2440 = heff_dup(heff_field(v_i_2438, 1));
                  v_t_2441 = v_s_2440;
                  break;
                }
                default: heff_nomatch(v_i_2438);
                }
                return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2438}), v_t_2441});
              } else {
                V v_t_2442 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2435, v_field_2436});
                V v_t_2445;
                switch (heff_tag_of(v_t_2442)) {
                case TAG_At: {
                  V v_s_2444 = heff_dup(heff_field(v_t_2442, 1));
                  v_t_2445 = v_s_2444;
                  break;
                }
                default: heff_nomatch(v_t_2442);
                }
                return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2442}), v_t_2445});
              }
            }
          }
        }
        case TAG_SizeNumber: {
          V v_t_2447 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT3 v_t_2448 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          {
            V v_field_2450 = v_t_2448.f[1];
            V v_field_2451 = v_t_2448.f[2];
            int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
            V v_t_2461;
            if ((v_tag_2449 == ((int64_t)0ULL))) {
              V v_c_2452 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2450, v_field_2451});
              v_t_2461 = v_c_2452;
            } else {
              if ((v_tag_2449 == ((int64_t)1ULL))) {
                V v_i_2453 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2450, v_field_2451});
                V v_t_2456;
                switch (heff_tag_of(v_i_2453)) {
                case TAG_At: {
                  V v_s_2455 = heff_dup(heff_field(v_i_2453, 1));
                  v_t_2456 = v_s_2455;
                  break;
                }
                default: heff_nomatch(v_i_2453);
                }
                v_t_2461 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2453}), v_t_2456});
              } else {
                V v_t_2457 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2450, v_field_2451});
                V v_t_2460;
                switch (heff_tag_of(v_t_2457)) {
                case TAG_At: {
                  V v_s_2459 = heff_dup(heff_field(v_t_2457, 1));
                  v_t_2460 = v_s_2459;
                  break;
                }
                default: heff_nomatch(v_t_2457);
                }
                v_t_2461 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2457}), v_t_2460});
              }
            }
            V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
            V v_args_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, v_t_2462});
            V v_t_2464 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2463));
            V v_t_2465 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str1)}), heff_dup(v_sp_242)});
            V v_t_2466 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2465, v_t_2464}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2466}), v_sp_242});
          }
        }
        case TAG_SizeName: {
          V v_t_2470 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT3 v_t_2471 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          {
            V v_field_2473 = v_t_2471.f[1];
            V v_field_2474 = v_t_2471.f[2];
            int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
            V v_t_2484;
            if ((v_tag_2472 == ((int64_t)0ULL))) {
              V v_c_2475 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2473, v_field_2474});
              v_t_2484 = v_c_2475;
            } else {
              if ((v_tag_2472 == ((int64_t)1ULL))) {
                V v_i_2476 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2473, v_field_2474});
                V v_t_2479;
                switch (heff_tag_of(v_i_2476)) {
                case TAG_At: {
                  V v_s_2478 = heff_dup(heff_field(v_i_2476, 1));
                  v_t_2479 = v_s_2478;
                  break;
                }
                default: heff_nomatch(v_i_2476);
                }
                v_t_2484 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2476}), v_t_2479});
              } else {
                V v_t_2480 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2473, v_field_2474});
                V v_t_2483;
                switch (heff_tag_of(v_t_2480)) {
                case TAG_At: {
                  V v_s_2482 = heff_dup(heff_field(v_t_2480, 1));
                  v_t_2483 = v_s_2482;
                  break;
                }
                default: heff_nomatch(v_t_2480);
                }
                v_t_2484 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2480}), v_t_2483});
              }
            }
            V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2484, NTAG(TAG_Nil)});
            V v_args_2486 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2470, v_t_2485});
            V v_t_2487 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2486));
            V v_t_2488 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str2)}), heff_dup(v_sp_242)});
            V v_t_2489 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2488, v_t_2487}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2489}), v_sp_242});
          }
        }
        default: return heff_nomatch(v_size_245);
        }
      }
      case TAG_SegmentBits: {
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        HeffT3 v_t_2490 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        {
          V v_field_2492 = v_t_2490.f[1];
          V v_field_2493 = v_t_2490.f[2];
          int64_t v_tag_2491 = ((int64_t)v_t_2490.f[0]);
          V v_t_24103;
          if ((v_tag_2491 == ((int64_t)0ULL))) {
            V v_c_2494 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2492, v_field_2493});
            v_t_24103 = v_c_2494;
          } else {
            if ((v_tag_2491 == ((int64_t)1ULL))) {
              V v_i_2495 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2492, v_field_2493});
              V v_t_2498;
              switch (heff_tag_of(v_i_2495)) {
              case TAG_At: {
                V v_s_2497 = heff_dup(heff_field(v_i_2495, 1));
                v_t_2498 = v_s_2497;
                break;
              }
              default: heff_nomatch(v_i_2495);
              }
              v_t_24103 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2495}), v_t_2498});
            } else {
              V v_t_2499 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2492, v_field_2493});
              V v_t_24102;
              switch (heff_tag_of(v_t_2499)) {
              case TAG_At: {
                V v_s_24101 = heff_dup(heff_field(v_t_2499, 1));
                v_t_24102 = v_s_24101;
                break;
              }
              default: heff_nomatch(v_t_2499);
              }
              v_t_24103 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2499}), v_t_24102});
            }
          }
          V v_args_24104 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24103, NTAG(TAG_Nil)});
          V v_t_24105 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24104));
          V v_t_24106 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str3)}), heff_dup(v_sp_242)});
          V v_t_24107 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24106, v_t_24105}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24107}), v_sp_242});
        }
      }
      case TAG_SegmentFloat: {
        heff_drop(v_signed_247);
        V v_t_24108 = (g_heff_2esyntax_2epresyntax_2esizeTerm(heff_dup(v_size_245), MK_INT(64LL), heff_dup(v_sp_242)));
        int64_t v_t_24109;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_24109 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_24109 = ((int64_t)0ULL);
        }
        V v_t_24110 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(64LL), heff_dup(v_sp_242)));
        HeffT3 v_t_24111 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        {
          V v_field_24113 = v_t_24111.f[1];
          V v_field_24114 = v_t_24111.f[2];
          int64_t v_tag_24112 = ((int64_t)v_t_24111.f[0]);
          V v_t_24124;
          if ((v_tag_24112 == ((int64_t)0ULL))) {
            V v_c_24115 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24113, v_field_24114});
            v_t_24124 = v_c_24115;
          } else {
            if ((v_tag_24112 == ((int64_t)1ULL))) {
              V v_i_24116 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24113, v_field_24114});
              V v_t_24119;
              switch (heff_tag_of(v_i_24116)) {
              case TAG_At: {
                V v_s_24118 = heff_dup(heff_field(v_i_24116, 1));
                v_t_24119 = v_s_24118;
                break;
              }
              default: heff_nomatch(v_i_24116);
              }
              v_t_24124 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24116}), v_t_24119});
            } else {
              V v_t_24120 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24113, v_field_24114});
              V v_t_24123;
              switch (heff_tag_of(v_t_24120)) {
              case TAG_At: {
                V v_s_24122 = heff_dup(heff_field(v_t_24120, 1));
                v_t_24123 = v_s_24122;
                break;
              }
              default: heff_nomatch(v_t_24120);
              }
              v_t_24124 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24120}), v_t_24123});
            }
          }
          V v_t_24125 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24124, NTAG(TAG_Nil)});
          V v_args_24126 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24110, v_t_24125});
          V v_t_24127 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24126));
          V v_t_24128 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_24109 + ((int64_t)0ULL)))});
          V v_t_24129 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24128, heff_dup(v_sp_242)})});
          V v_t_24130 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str4)}), heff_dup(v_sp_242)});
          V v_t_24131 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24130, v_t_24127}), heff_dup(v_sp_242)});
          V v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24131}), heff_dup(v_sp_242)});
          V v_t_24133 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24132, NTAG(TAG_Nil)});
          V v_t_24134 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24129, heff_dup(v_sp_242)}), v_t_24133});
          V v_args_24135 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24108, v_t_24134});
          V v_t_24136 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24135));
          V v_t_24137 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str5)}), heff_dup(v_sp_242)});
          V v_t_24138 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24137, v_t_24136}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24138}), v_sp_242});
        }
      }
      case TAG_SegmentUtf: {
        V v_x2121_24139 = heff_field(v_x212_244, 0);
        V v_ru_24x212_244_24SegmentUtf = heff_take_reuse_n(v_x212_244, 1ULL, 1);
        heff_drop(v_size_245);
        heff_drop(v_signed_247);
        if (heff_intEq_c_lent(v_x2121_24139, MK_INT(8LL), 2)) {
          heff_drop(v_little_246);
          heff_drop(v_x2121_24139);
          V v_t_24140 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
          V v_args_24141 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24140, NTAG(TAG_Nil)});
          V v_t_24142 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24141));
          V v_t_24143 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str6)}), heff_dup(v_sp_242)});
          V v_t_24144 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24143, v_t_24142}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24144}), v_sp_242});
        } else {
          if (heff_intEq_c(v_x2121_24139, MK_INT(16LL))) {
            int64_t v_t_24145;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24145 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24145 = ((int64_t)0ULL);
            }
            V v_t_24146 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24147 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24145 + ((int64_t)0ULL)))});
            V v_t_24148 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24147, heff_dup(v_sp_242)})});
            V v_t_24149 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24146, NTAG(TAG_Nil)});
            V v_args_24150 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24148, heff_dup(v_sp_242)}), v_t_24149});
            V v_t_24151 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24150));
            V v_t_24152 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str7)}), heff_dup(v_sp_242)});
            V v_t_24153 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24152, v_t_24151}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24153}), v_sp_242});
          } else {
            int64_t v_t_24154;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24154 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24154 = ((int64_t)0ULL);
            }
            V v_t_24155 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24156 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24154 + ((int64_t)0ULL)))});
            V v_t_24157 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24156, heff_dup(v_sp_242)})});
            V v_t_24158 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24155, NTAG(TAG_Nil)});
            V v_args_24159 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24157, heff_dup(v_sp_242)}), v_t_24158});
            V v_t_24160 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24159));
            V v_t_24161 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str8)}), heff_dup(v_sp_242)});
            V v_t_24162 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24161, v_t_24160}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24162}), v_sp_242});
          }
        }
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_TPi: {
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_245 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_244, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_240});
  }
  case TAG_TSig: {
    V v_fs_246 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TSig = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_247 = (g_list_2emap_24s1992667171x110340492(v_fs_246));
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24TSig, TAG_TSig, 1, (V[]){v_t_247}), v_sp_240});
  }
  case TAG_TSum: {
    V v_vs_248 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TSum = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_249 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(heff_tag_re_n(v_ru_24n_241_24TSum, TAG_TSum, 1, 1ULL, (V[]){v_vs_248})));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_sp_240});
  }
  case TAG_TType: {
    V v_t_2410 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2411 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_sp_240});
  }
  case TAG_TInt: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2413 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_TFloat: {
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2415 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_sp_240});
  }
  case TAG_TString: {
    V v_t_2416 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2417 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2416, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_sp_240});
  }
  case TAG_TRune: {
    V v_t_2418 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2419 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_240});
  }
  case TAG_TArray: {
    V v_t_2421 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2422 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2421, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_sp_240});
  }
  case TAG_TFixed: {
    V v_t_2424 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2425 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_sp_240});
  }
  case TAG_TInf: {
    V v_i_2426 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TInf = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2429;
    switch (heff_tag_of(v_i_2426)) {
    case TAG_At: {
      V v_n_2427 = heff_field(v_i_2426, 0);
      V v_sp_2428 = heff_field(v_i_2426, 1);
      V v_ru_24i_2426_24At = heff_take_reuse_n(v_i_2426, 3ULL, 2);
      v_t_2429 = (g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(v_ru_24i_2426_24At, v_sp_2428, v_n_2427));
      break;
    }
    default: heff_nomatch(v_i_2426);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24TInf, TAG_TInf, 1, (V[]){v_t_2429}), v_sp_240});
  }
  case TAG_TChk: {
    V v_c_2430 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TChk = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2433;
    switch (heff_tag_of(v_c_2430)) {
    case TAG_At: {
      V v_n_2431 = heff_field(v_c_2430, 0);
      V v_sp_2432 = heff_field(v_c_2430, 1);
      heff_take_n(v_c_2430, 3ULL, 2);
      v_t_2433 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2432, v_n_2431));
      break;
    }
    default: heff_nomatch(v_c_2430);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24TChk, TAG_TChk, 1, (V[]){v_t_2433}), v_sp_240});
  }
  case TAG_TNominal: {
    V v_t_2435 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2436 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2435, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2436, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(a[0], a[1]);
}