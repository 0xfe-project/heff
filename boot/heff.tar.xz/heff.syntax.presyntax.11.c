// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_EndValue 24675
#define TAG_ExplicitParam 63083
#define TAG_IApp 21275
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_IPrim 59489
#define TAG_ImplicitParam 51130
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_MkSegment 38079
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define LBL_depth 296830685
#define LBL_end 310101
#define LBL_giving 701566649
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_sp 10436
#define LBL_start 311115900
static uint32_t shape_names__muts__loop__sp__depth__giving[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth, LBL_giving};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1654483724x1393507626(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1654483724x1393507626_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1654483724x1393507626_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_clo;
V g_heff_2esyntax_2epresyntax_2ebytesTerm(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesTerm_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2edoBlock_24s1973147116x167776115_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ehasReturn(V);
V g_heff_2esyntax_2epresyntax_2ehasReturn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasReturn_clo;
V g_heff_2esyntax_2epresyntax_2eidNames_get(void);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2ejumpE(V);
V g_heff_2esyntax_2epresyntax_2ejumpE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpE_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
V g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669(V);
V g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_clo;
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(V);
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_clo;
V g_heff_2esyntax_2epresyntax_2ereversedBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2ereversedBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ereversedBytes_clo;
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo;
V g_heff_2esyntax_2epresyntax_2etwoTo(V);
V g_heff_2esyntax_2epresyntax_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etwoTo_clo;
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(V, V);
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_clo;
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2ewatchOf(V);
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr(V, V, V);
V g_list_2eany_24s1414887908x732433189(V);
V g_list_2eany_24s1414887908x732433189_entry(V self, V *a);
extern Clo g_list_2eany_24s1414887908x732433189_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1992667171x110340492(V);
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
Clo g_heff_2esyntax_2epresyntax_2etwoTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etwoTo_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2etwoTo(V v_k_240) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    return MK_INT(1LL);
  } else {
    V v_t_241 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_intSub(v_k_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(2LL), v_t_241);
  }
}
V g_heff_2esyntax_2epresyntax_2etwoTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etwoTo(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2elastOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elastOr_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2elastOr(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop(v_z_240);
      return heff_dup(v_x_242);
    }
    case TAG_Cons: {
      V t_0 = v_z_240;
      V t_1 = v_x22_243;
      v_z_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2elastOr(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2epresyntax_2eapp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eapp_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eapp(V v_f_240, V v_args_241) {
top: ;
  switch (heff_tag_of(v_args_241)) {
  case TAG_Nil: {
    return v_f_240;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_f_240)) {
    case TAG_At: {
      V v_f1_244 = heff_dup(heff_field(v_f_240, 0));
      switch (heff_tag_of(v_f1_244)) {
      case TAG_EVar: {
        heff_take_n(v_f1_244, 0ULL, 1);
        V v_x1_247 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2410;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_f_240, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2413;
        switch (heff_tag_of(v_x1_247)) {
        case TAG_At: {
          V v_s_2412 = heff_field(v_x1_247, 1);
          heff_take_n(v_x1_247, 2ULL, 2);
          v_t_2413 = v_s_2412;
          break;
        }
        default: heff_nomatch(v_x1_247);
        }
        V v_t_2414 = ({ V rv_1 = heff_get_n(v_t_2413, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2410, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2414});
      }
      case TAG_EImplicitVar: {
        heff_take_n(v_f1_244, 0ULL, 1);
        V v_x1_2416 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2419;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2418 = heff_dup(heff_field(v_f_240, 1));
          v_t_2419 = v_s_2418;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2422;
        switch (heff_tag_of(v_x1_2416)) {
        case TAG_At: {
          V v_s_2421 = heff_field(v_x1_2416, 1);
          heff_take_n(v_x1_2416, 2ULL, 2);
          v_t_2422 = v_s_2421;
          break;
        }
        default: heff_nomatch(v_x1_2416);
        }
        V v_t_2423 = ({ V rv_1 = heff_get_n(v_t_2422, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2419, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2423});
      }
      case TAG_ETag: {
        heff_take_n(v_f1_244, 0ULL, 1);
        V v_x1_2425 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2428;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_f_240, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2431;
        switch (heff_tag_of(v_x1_2425)) {
        case TAG_At: {
          V v_s_2430 = heff_field(v_x1_2425, 1);
          heff_take_n(v_x1_2425, 2ULL, 2);
          v_t_2431 = v_s_2430;
          break;
        }
        default: heff_nomatch(v_x1_2425);
        }
        V v_t_2432 = ({ V rv_1 = heff_get_n(v_t_2431, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2428, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2432});
      }
      case TAG_EInt: {
        heff_take_n(v_f1_244, 0ULL, 1);
        V v_x1_2434 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2437;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_f_240, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2440;
        switch (heff_tag_of(v_x1_2434)) {
        case TAG_At: {
          V v_s_2439 = heff_field(v_x1_2434, 1);
          heff_take_n(v_x1_2434, 2ULL, 2);
          v_t_2440 = v_s_2439;
          break;
        }
        default: heff_nomatch(v_x1_2434);
        }
        V v_t_2441 = ({ V rv_1 = heff_get_n(v_t_2440, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2437, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2441});
      }
      case TAG_EFloat: {
        heff_take_na(v_f1_244, 0ULL, 1);
        V v_x1_2443 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2446;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2445 = heff_dup(heff_field(v_f_240, 1));
          v_t_2446 = v_s_2445;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2449;
        switch (heff_tag_of(v_x1_2443)) {
        case TAG_At: {
          V v_s_2448 = heff_field(v_x1_2443, 1);
          heff_take_n(v_x1_2443, 2ULL, 2);
          v_t_2449 = v_s_2448;
          break;
        }
        default: heff_nomatch(v_x1_2443);
        }
        V v_t_2450 = ({ V rv_1 = heff_get_n(v_t_2449, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2446, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2450});
      }
      case TAG_EString: {
        heff_take_n(v_f1_244, 0ULL, 1);
        V v_x1_2452 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2455;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2454 = heff_dup(heff_field(v_f_240, 1));
          v_t_2455 = v_s_2454;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2458;
        switch (heff_tag_of(v_x1_2452)) {
        case TAG_At: {
          V v_s_2457 = heff_field(v_x1_2452, 1);
          heff_take_n(v_x1_2452, 2ULL, 2);
          v_t_2458 = v_s_2457;
          break;
        }
        default: heff_nomatch(v_x1_2452);
        }
        V v_t_2459 = ({ V rv_1 = heff_get_n(v_t_2458, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2455, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2459});
      }
      case TAG_EBinary: {
        heff_take_n(v_f1_244, 0ULL, 1);
        V v_x1_2461 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2464;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2463 = heff_dup(heff_field(v_f_240, 1));
          v_t_2464 = v_s_2463;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2467;
        switch (heff_tag_of(v_x1_2461)) {
        case TAG_At: {
          V v_s_2466 = heff_field(v_x1_2461, 1);
          heff_take_n(v_x1_2461, 2ULL, 2);
          v_t_2467 = v_s_2466;
          break;
        }
        default: heff_nomatch(v_x1_2461);
        }
        V v_t_2468 = ({ V rv_1 = heff_get_n(v_t_2467, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2464, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2468});
      }
      case TAG_ERune: {
        heff_take_n(v_f1_244, 0ULL, 1);
        V v_x1_2470 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2473;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2472 = heff_dup(heff_field(v_f_240, 1));
          v_t_2473 = v_s_2472;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2476;
        switch (heff_tag_of(v_x1_2470)) {
        case TAG_At: {
          V v_s_2475 = heff_field(v_x1_2470, 1);
          heff_take_n(v_x1_2470, 2ULL, 2);
          v_t_2476 = v_s_2475;
          break;
        }
        default: heff_nomatch(v_x1_2470);
        }
        V v_t_2477 = ({ V rv_1 = heff_get_n(v_t_2476, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2473, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2477});
      }
      case TAG_EWord: {
        heff_take_n(v_f1_244, 0ULL, 1);
        V v_x1_2479 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2482;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2481 = heff_dup(heff_field(v_f_240, 1));
          v_t_2482 = v_s_2481;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2485;
        switch (heff_tag_of(v_x1_2479)) {
        case TAG_At: {
          V v_s_2484 = heff_field(v_x1_2479, 1);
          heff_take_n(v_x1_2479, 2ULL, 2);
          v_t_2485 = v_s_2484;
          break;
        }
        default: heff_nomatch(v_x1_2479);
        }
        V v_t_2486 = ({ V rv_1 = heff_get_n(v_t_2485, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2482, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2486});
      }
      case TAG_EApp: {
        V v_h_2487 = heff_field(v_f1_244, 0);
        V v_xs_2488 = heff_field(v_f1_244, 1);
        V v_ru_24f1_244_24EApp = heff_take_reuse_n(v_f1_244, 3ULL, 2);
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_sp_2490 = heff_field(v_f_240, 1);
          V v_ru_24f_240_24At = heff_take_reuse_n(v_f_240, 2ULL, 2);
          V v_t_2491 = (g_prelude_2e_2b_2b(v_xs_2488, heff_dup(v_args_241)));
          V v_x1_2492 = ({ V a_0 = heff_dup(v_h_2487); V a_1 = v_args_241; V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, a_1)); heff_drop_tag(v_args_241, 2); r_; });
          V v_t_2495;
          switch (heff_tag_of(v_x1_2492)) {
          case TAG_At: {
            V v_s_2494 = heff_field(v_x1_2492, 1);
            heff_take_n(v_x1_2492, 2ULL, 2);
            v_t_2495 = v_s_2494;
            break;
          }
          default: heff_nomatch(v_x1_2492);
          }
          V v_t_2496 = ({ V rv_1 = heff_get_n(v_t_2495, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_2490, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24f_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24f1_244_24EApp, TAG_EApp, 2, (V[]){v_h_2487, v_t_2491}), v_t_2496});
        }
        default: return heff_nomatch(v_f_240);
        }
      }
      case TAG_EProject: {
        heff_take_n(v_f1_244, 0ULL, 1);
        V v_x1_2498 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24101;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24100 = heff_dup(heff_field(v_f_240, 1));
          v_t_24101 = v_s_24100;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24104;
        switch (heff_tag_of(v_x1_2498)) {
        case TAG_At: {
          V v_s_24103 = heff_field(v_x1_2498, 1);
          heff_take_n(v_x1_2498, 2ULL, 2);
          v_t_24104 = v_s_24103;
          break;
        }
        default: heff_nomatch(v_x1_2498);
        }
        V v_t_24105 = ({ V rv_1 = heff_get_n(v_t_24104, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24101, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24105});
      }
      case TAG_ENamed: {
        V v_ru_24f1_244_24ENamed = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        V v_x1_24108 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24111;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24110 = heff_dup(heff_field(v_f_240, 1));
          v_t_24111 = v_s_24110;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24114;
        switch (heff_tag_of(v_x1_24108)) {
        case TAG_At: {
          V v_s_24113 = heff_field(v_x1_24108, 1);
          heff_take_n(v_x1_24108, 2ULL, 2);
          v_t_24114 = v_s_24113;
          break;
        }
        default: heff_nomatch(v_x1_24108);
        }
        V v_t_24115 = ({ V rv_1 = heff_get_n(v_t_24114, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24111, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24115});
      }
      case TAG_EPi: {
        V v_ru_24f1_244_24EPi = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        V v_x1_24118 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24121;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24120 = heff_dup(heff_field(v_f_240, 1));
          v_t_24121 = v_s_24120;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24124;
        switch (heff_tag_of(v_x1_24118)) {
        case TAG_At: {
          V v_s_24123 = heff_field(v_x1_24118, 1);
          heff_take_n(v_x1_24118, 2ULL, 2);
          v_t_24124 = v_s_24123;
          break;
        }
        default: heff_nomatch(v_x1_24118);
        }
        V v_t_24125 = ({ V rv_1 = heff_get_n(v_t_24124, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24121, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24125});
      }
      case TAG_ELam: {
        V v_ru_24f1_244_24ELam = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        V v_x1_24128 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24131;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24130 = heff_dup(heff_field(v_f_240, 1));
          v_t_24131 = v_s_24130;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24134;
        switch (heff_tag_of(v_x1_24128)) {
        case TAG_At: {
          V v_s_24133 = heff_field(v_x1_24128, 1);
          heff_take_n(v_x1_24128, 2ULL, 2);
          v_t_24134 = v_s_24133;
          break;
        }
        default: heff_nomatch(v_x1_24128);
        }
        V v_t_24135 = ({ V rv_1 = heff_get_n(v_t_24134, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24131, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24135});
      }
      case TAG_EAnn: {
        V v_ru_24f1_244_24EAnn = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        V v_x1_24138 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24141;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24140 = heff_dup(heff_field(v_f_240, 1));
          v_t_24141 = v_s_24140;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24144;
        switch (heff_tag_of(v_x1_24138)) {
        case TAG_At: {
          V v_s_24143 = heff_field(v_x1_24138, 1);
          heff_take_n(v_x1_24138, 2ULL, 2);
          v_t_24144 = v_s_24143;
          break;
        }
        default: heff_nomatch(v_x1_24138);
        }
        V v_t_24145 = ({ V rv_1 = heff_get_n(v_t_24144, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24141, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24145});
      }
      case TAG_ESpec: {
        heff_take_n(v_f1_244, 0ULL, 4);
        V v_x1_24150 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24153;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24152 = heff_dup(heff_field(v_f_240, 1));
          v_t_24153 = v_s_24152;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24156;
        switch (heff_tag_of(v_x1_24150)) {
        case TAG_At: {
          V v_s_24155 = heff_field(v_x1_24150, 1);
          heff_take_n(v_x1_24150, 2ULL, 2);
          v_t_24156 = v_s_24155;
          break;
        }
        default: heff_nomatch(v_x1_24150);
        }
        V v_t_24157 = ({ V rv_1 = heff_get_n(v_t_24156, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24153, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24157});
      }
      case TAG_ESig: {
        heff_take_n(v_f1_244, 0ULL, 1);
        V v_x1_24159 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24162;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24161 = heff_dup(heff_field(v_f_240, 1));
          v_t_24162 = v_s_24161;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24165;
        switch (heff_tag_of(v_x1_24159)) {
        case TAG_At: {
          V v_s_24164 = heff_field(v_x1_24159, 1);
          heff_take_n(v_x1_24159, 2ULL, 2);
          v_t_24165 = v_s_24164;
          break;
        }
        default: heff_nomatch(v_x1_24159);
        }
        V v_t_24166 = ({ V rv_1 = heff_get_n(v_t_24165, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24162, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24166});
      }
      case TAG_ESum: {
        heff_take_n(v_f1_244, 0ULL, 1);
        V v_x1_24168 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24171;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24170 = heff_dup(heff_field(v_f_240, 1));
          v_t_24171 = v_s_24170;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24174;
        switch (heff_tag_of(v_x1_24168)) {
        case TAG_At: {
          V v_s_24173 = heff_field(v_x1_24168, 1);
          heff_take_n(v_x1_24168, 2ULL, 2);
          v_t_24174 = v_s_24173;
          break;
        }
        default: heff_nomatch(v_x1_24168);
        }
        V v_t_24175 = ({ V rv_1 = heff_get_n(v_t_24174, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24171, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24175});
      }
      case TAG_EStruct: {
        heff_take_n(v_f1_244, 0ULL, 1);
        V v_x1_24177 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24180;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24179 = heff_dup(heff_field(v_f_240, 1));
          v_t_24180 = v_s_24179;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24183;
        switch (heff_tag_of(v_x1_24177)) {
        case TAG_At: {
          V v_s_24182 = heff_field(v_x1_24177, 1);
          heff_take_n(v_x1_24177, 2ULL, 2);
          v_t_24183 = v_s_24182;
          break;
        }
        default: heff_nomatch(v_x1_24177);
        }
        V v_t_24184 = ({ V rv_1 = heff_get_n(v_t_24183, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24180, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24184});
      }
      case TAG_EUpdate: {
        V v_ru_24f1_244_24EUpdate = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        V v_x1_24187 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24190;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24189 = heff_dup(heff_field(v_f_240, 1));
          v_t_24190 = v_s_24189;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24193;
        switch (heff_tag_of(v_x1_24187)) {
        case TAG_At: {
          V v_s_24192 = heff_field(v_x1_24187, 1);
          heff_take_n(v_x1_24187, 2ULL, 2);
          v_t_24193 = v_s_24192;
          break;
        }
        default: heff_nomatch(v_x1_24187);
        }
        V v_t_24194 = ({ V rv_1 = heff_get_n(v_t_24193, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24190, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24194});
      }
      case TAG_EMatch: {
        V v_ru_24f1_244_24EMatch = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        V v_x1_24197 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24200;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24199 = heff_dup(heff_field(v_f_240, 1));
          v_t_24200 = v_s_24199;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24203;
        switch (heff_tag_of(v_x1_24197)) {
        case TAG_At: {
          V v_s_24202 = heff_field(v_x1_24197, 1);
          heff_take_n(v_x1_24197, 2ULL, 2);
          v_t_24203 = v_s_24202;
          break;
        }
        default: heff_nomatch(v_x1_24197);
        }
        V v_t_24204 = ({ V rv_1 = heff_get_n(v_t_24203, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24200, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24204});
      }
      case TAG_ELetIn: {
        V v_ru_24f1_244_24ELetIn = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        V v_x1_24207 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24210;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24209 = heff_dup(heff_field(v_f_240, 1));
          v_t_24210 = v_s_24209;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24213;
        switch (heff_tag_of(v_x1_24207)) {
        case TAG_At: {
          V v_s_24212 = heff_field(v_x1_24207, 1);
          heff_take_n(v_x1_24207, 2ULL, 2);
          v_t_24213 = v_s_24212;
          break;
        }
        default: heff_nomatch(v_x1_24207);
        }
        V v_t_24214 = ({ V rv_1 = heff_get_n(v_t_24213, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24210, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24214});
      }
      case TAG_EDo: {
        heff_take_n(v_f1_244, 0ULL, 1);
        V v_x1_24216 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24219;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24218 = heff_dup(heff_field(v_f_240, 1));
          v_t_24219 = v_s_24218;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24222;
        switch (heff_tag_of(v_x1_24216)) {
        case TAG_At: {
          V v_s_24221 = heff_field(v_x1_24216, 1);
          heff_take_n(v_x1_24216, 2ULL, 2);
          v_t_24222 = v_s_24221;
          break;
        }
        default: heff_nomatch(v_x1_24216);
        }
        V v_t_24223 = ({ V rv_1 = heff_get_n(v_t_24222, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24219, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24223});
      }
      case TAG_ELocal: {
        V v_ru_24f1_244_24ELocal = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        V v_x1_24226 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24229;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24228 = heff_dup(heff_field(v_f_240, 1));
          v_t_24229 = v_s_24228;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24232;
        switch (heff_tag_of(v_x1_24226)) {
        case TAG_At: {
          V v_s_24231 = heff_field(v_x1_24226, 1);
          heff_take_n(v_x1_24226, 2ULL, 2);
          v_t_24232 = v_s_24231;
          break;
        }
        default: heff_nomatch(v_x1_24226);
        }
        V v_t_24233 = ({ V rv_1 = heff_get_n(v_t_24232, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24229, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24233});
      }
      case TAG_EInvalid: {
        heff_take_n(v_f1_244, 0ULL, 1);
        V v_x1_24235 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24238;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24237 = heff_dup(heff_field(v_f_240, 1));
          v_t_24238 = v_s_24237;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24241;
        switch (heff_tag_of(v_x1_24235)) {
        case TAG_At: {
          V v_s_24240 = heff_field(v_x1_24235, 1);
          heff_take_n(v_x1_24235, 2ULL, 2);
          v_t_24241 = v_s_24240;
          break;
        }
        default: heff_nomatch(v_x1_24235);
        }
        V v_t_24242 = ({ V rv_1 = heff_get_n(v_t_24241, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24238, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24242});
      }
      case TAG_EAssign: {
        heff_take_n(v_f1_244, 0ULL, 3);
        V v_x1_24246 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24249;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24248 = heff_dup(heff_field(v_f_240, 1));
          v_t_24249 = v_s_24248;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24252;
        switch (heff_tag_of(v_x1_24246)) {
        case TAG_At: {
          V v_s_24251 = heff_field(v_x1_24246, 1);
          heff_take_n(v_x1_24246, 2ULL, 2);
          v_t_24252 = v_s_24251;
          break;
        }
        default: heff_nomatch(v_x1_24246);
        }
        V v_t_24253 = ({ V rv_1 = heff_get_n(v_t_24252, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24249, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24253});
      }
      case TAG_EWhile: {
        V v_ru_24f1_244_24EWhile = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        V v_x1_24256 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24259;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24258 = heff_dup(heff_field(v_f_240, 1));
          v_t_24259 = v_s_24258;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24262;
        switch (heff_tag_of(v_x1_24256)) {
        case TAG_At: {
          V v_s_24261 = heff_field(v_x1_24256, 1);
          heff_take_n(v_x1_24256, 2ULL, 2);
          v_t_24262 = v_s_24261;
          break;
        }
        default: heff_nomatch(v_x1_24256);
        }
        V v_t_24263 = ({ V rv_1 = heff_get_n(v_t_24262, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24259, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EWhile, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24263});
      }
      case TAG_EFor: {
        heff_take_n(v_f1_244, 0ULL, 3);
        V v_x1_24267 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24270;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24269 = heff_dup(heff_field(v_f_240, 1));
          v_t_24270 = v_s_24269;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24273;
        switch (heff_tag_of(v_x1_24267)) {
        case TAG_At: {
          V v_s_24272 = heff_field(v_x1_24267, 1);
          heff_take_n(v_x1_24267, 2ULL, 2);
          v_t_24273 = v_s_24272;
          break;
        }
        default: heff_nomatch(v_x1_24267);
        }
        V v_t_24274 = ({ V rv_1 = heff_get_n(v_t_24273, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24270, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24274});
      }
      case TAG_EIfThen: {
        V v_ru_24f1_244_24EIfThen = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        V v_x1_24277 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24280;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24279 = heff_dup(heff_field(v_f_240, 1));
          v_t_24280 = v_s_24279;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24283;
        switch (heff_tag_of(v_x1_24277)) {
        case TAG_At: {
          V v_s_24282 = heff_field(v_x1_24277, 1);
          heff_take_n(v_x1_24277, 2ULL, 2);
          v_t_24283 = v_s_24282;
          break;
        }
        default: heff_nomatch(v_x1_24277);
        }
        V v_t_24284 = ({ V rv_1 = heff_get_n(v_t_24283, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24280, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EIfThen, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24284});
      }
      case TAG_EBreak: {
        V v_x1_24285 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24288;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24287 = heff_dup(heff_field(v_f_240, 1));
          v_t_24288 = v_s_24287;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24291;
        switch (heff_tag_of(v_x1_24285)) {
        case TAG_At: {
          V v_s_24290 = heff_field(v_x1_24285, 1);
          heff_take_n(v_x1_24285, 2ULL, 2);
          v_t_24291 = v_s_24290;
          break;
        }
        default: heff_nomatch(v_x1_24285);
        }
        V v_t_24292 = ({ V rv_1 = heff_get_n(v_t_24291, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24288, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24292});
      }
      case TAG_EContinue: {
        V v_x1_24293 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24296;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24295 = heff_dup(heff_field(v_f_240, 1));
          v_t_24296 = v_s_24295;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24299;
        switch (heff_tag_of(v_x1_24293)) {
        case TAG_At: {
          V v_s_24298 = heff_field(v_x1_24293, 1);
          heff_take_n(v_x1_24293, 2ULL, 2);
          v_t_24299 = v_s_24298;
          break;
        }
        default: heff_nomatch(v_x1_24293);
        }
        V v_t_24300 = ({ V rv_1 = heff_get_n(v_t_24299, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24296, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24300});
      }
      case TAG_EReturn: {
        heff_take_n(v_f1_244, 0ULL, 1);
        V v_x1_24302 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24305;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24304 = heff_dup(heff_field(v_f_240, 1));
          v_t_24305 = v_s_24304;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24308;
        switch (heff_tag_of(v_x1_24302)) {
        case TAG_At: {
          V v_s_24307 = heff_field(v_x1_24302, 1);
          heff_take_n(v_x1_24302, 2ULL, 2);
          v_t_24308 = v_s_24307;
          break;
        }
        default: heff_nomatch(v_x1_24302);
        }
        V v_t_24309 = ({ V rv_1 = heff_get_n(v_t_24308, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24305, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24309});
      }
      case TAG_ENest: {
        heff_take_n(v_f1_244, 0ULL, 1);
        V v_x1_24311 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24314;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24313 = heff_dup(heff_field(v_f_240, 1));
          v_t_24314 = v_s_24313;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24317;
        switch (heff_tag_of(v_x1_24311)) {
        case TAG_At: {
          V v_s_24316 = heff_field(v_x1_24311, 1);
          heff_take_n(v_x1_24311, 2ULL, 2);
          v_t_24317 = v_s_24316;
          break;
        }
        default: heff_nomatch(v_x1_24311);
        }
        V v_t_24318 = ({ V rv_1 = heff_get_n(v_t_24317, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24314, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24318});
      }
      case TAG_ELazy: {
        heff_take_n(v_f1_244, 0ULL, 1);
        V v_x1_24320 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24323;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24322 = heff_dup(heff_field(v_f_240, 1));
          v_t_24323 = v_s_24322;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24326;
        switch (heff_tag_of(v_x1_24320)) {
        case TAG_At: {
          V v_s_24325 = heff_field(v_x1_24320, 1);
          heff_take_n(v_x1_24320, 2ULL, 2);
          v_t_24326 = v_s_24325;
          break;
        }
        default: heff_nomatch(v_x1_24320);
        }
        V v_t_24327 = ({ V rv_1 = heff_get_n(v_t_24326, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24323, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24327});
      }
      case TAG_ETuple: {
        heff_take_n(v_f1_244, 0ULL, 1);
        V v_x1_24329 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24332;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24331 = heff_dup(heff_field(v_f_240, 1));
          v_t_24332 = v_s_24331;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24335;
        switch (heff_tag_of(v_x1_24329)) {
        case TAG_At: {
          V v_s_24334 = heff_field(v_x1_24329, 1);
          heff_take_n(v_x1_24329, 2ULL, 2);
          v_t_24335 = v_s_24334;
          break;
        }
        default: heff_nomatch(v_x1_24329);
        }
        V v_t_24336 = ({ V rv_1 = heff_get_n(v_t_24335, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24332, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24336});
      }
      case TAG_ETry: {
        heff_take_n(v_f1_244, 0ULL, 1);
        V v_x1_24338 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24341;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24340 = heff_dup(heff_field(v_f_240, 1));
          v_t_24341 = v_s_24340;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24344;
        switch (heff_tag_of(v_x1_24338)) {
        case TAG_At: {
          V v_s_24343 = heff_field(v_x1_24338, 1);
          heff_take_n(v_x1_24338, 2ULL, 2);
          v_t_24344 = v_s_24343;
          break;
        }
        default: heff_nomatch(v_x1_24338);
        }
        V v_t_24345 = ({ V rv_1 = heff_get_n(v_t_24344, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24341, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24345});
      }
      case TAG_EWith: {
        heff_take_n(v_f1_244, 0ULL, 4);
        V v_x1_24350 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24353;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24352 = heff_dup(heff_field(v_f_240, 1));
          v_t_24353 = v_s_24352;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24356;
        switch (heff_tag_of(v_x1_24350)) {
        case TAG_At: {
          V v_s_24355 = heff_field(v_x1_24350, 1);
          heff_take_n(v_x1_24350, 2ULL, 2);
          v_t_24356 = v_s_24355;
          break;
        }
        default: heff_nomatch(v_x1_24350);
        }
        V v_t_24357 = ({ V rv_1 = heff_get_n(v_t_24356, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24353, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24357});
      }
      default: return heff_nomatch(v_f1_244);
      }
    }
    default: return heff_nomatch(v_f_240);
    }
  }
  default: return heff_nomatch(v_args_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eapp(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2ejumpE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ejumpE_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ejumpE(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_244 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_245 = v_t_244.f[0];
        V v_field_246 = v_t_244.f[1];
        V v_x_247 = v_field_245;
        V v_y_248 = v_field_246;
        heff_drop(v_y_248);
        return v_x_247;
      }
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2410 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_x_2413 = v_field_2411;
        V v_y_2414 = v_field_2412;
        heff_drop(v_y_2414);
        return v_x_2413;
      }
    }
    case TAG_ETag: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2416 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2417 = v_t_2416.f[0];
        V v_field_2418 = v_t_2416.f[1];
        V v_x_2419 = v_field_2417;
        V v_y_2420 = v_field_2418;
        heff_drop(v_y_2420);
        return v_x_2419;
      }
    }
    case TAG_EInt: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2422 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2423 = v_t_2422.f[0];
        V v_field_2424 = v_t_2422.f[1];
        V v_x_2425 = v_field_2423;
        V v_y_2426 = v_field_2424;
        heff_drop(v_y_2426);
        return v_x_2425;
      }
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2428 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2429 = v_t_2428.f[0];
        V v_field_2430 = v_t_2428.f[1];
        V v_x_2431 = v_field_2429;
        V v_y_2432 = v_field_2430;
        heff_drop(v_y_2432);
        return v_x_2431;
      }
    }
    case TAG_EString: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2434 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2435 = v_t_2434.f[0];
        V v_field_2436 = v_t_2434.f[1];
        V v_x_2437 = v_field_2435;
        V v_y_2438 = v_field_2436;
        heff_drop(v_y_2438);
        return v_x_2437;
      }
    }
    case TAG_EBinary: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2440 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2441 = v_t_2440.f[0];
        V v_field_2442 = v_t_2440.f[1];
        V v_x_2443 = v_field_2441;
        V v_y_2444 = v_field_2442;
        heff_drop(v_y_2444);
        return v_x_2443;
      }
    }
    case TAG_ERune: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2446 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2447 = v_t_2446.f[0];
        V v_field_2448 = v_t_2446.f[1];
        V v_x_2449 = v_field_2447;
        V v_y_2450 = v_field_2448;
        heff_drop(v_y_2450);
        return v_x_2449;
      }
    }
    case TAG_EWord: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2452 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2453 = v_t_2452.f[0];
        V v_field_2454 = v_t_2452.f[1];
        V v_x_2455 = v_field_2453;
        V v_y_2456 = v_field_2454;
        heff_drop(v_y_2456);
        return v_x_2455;
      }
    }
    case TAG_EApp: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_2459 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2460 = v_t_2459.f[0];
        V v_field_2461 = v_t_2459.f[1];
        V v_x_2462 = v_field_2460;
        V v_y_2463 = v_field_2461;
        heff_drop(v_y_2463);
        return v_x_2462;
      }
    }
    case TAG_EProject: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2465 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2466 = v_t_2465.f[0];
        V v_field_2467 = v_t_2465.f[1];
        V v_x_2468 = v_field_2466;
        V v_y_2469 = v_field_2467;
        heff_drop(v_y_2469);
        return v_x_2468;
      }
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_2472 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2473 = v_t_2472.f[0];
        V v_field_2474 = v_t_2472.f[1];
        V v_x_2475 = v_field_2473;
        V v_y_2476 = v_field_2474;
        heff_drop(v_y_2476);
        return v_x_2475;
      }
    }
    case TAG_EPi: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_2479 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2480 = v_t_2479.f[0];
        V v_field_2481 = v_t_2479.f[1];
        V v_x_2482 = v_field_2480;
        V v_y_2483 = v_field_2481;
        heff_drop(v_y_2483);
        return v_x_2482;
      }
    }
    case TAG_ELam: {
      heff_take_n(v_e1_241, 0ULL, 2);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EAnn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_2490 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2491 = v_t_2490.f[0];
        V v_field_2492 = v_t_2490.f[1];
        V v_x_2493 = v_field_2491;
        V v_y_2494 = v_field_2492;
        heff_drop(v_y_2494);
        return v_x_2493;
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_241, 0ULL, 4);
      HeffT2 v_t_2499 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24100 = v_t_2499.f[0];
        V v_field_24101 = v_t_2499.f[1];
        V v_x_24102 = v_field_24100;
        V v_y_24103 = v_field_24101;
        heff_drop(v_y_24103);
        return v_x_24102;
      }
    }
    case TAG_ESig: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24105 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24106 = v_t_24105.f[0];
        V v_field_24107 = v_t_24105.f[1];
        V v_x_24108 = v_field_24106;
        V v_y_24109 = v_field_24107;
        heff_drop(v_y_24109);
        return v_x_24108;
      }
    }
    case TAG_ESum: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24111 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24112 = v_t_24111.f[0];
        V v_field_24113 = v_t_24111.f[1];
        V v_x_24114 = v_field_24112;
        V v_y_24115 = v_field_24113;
        heff_drop(v_y_24115);
        return v_x_24114;
      }
    }
    case TAG_EStruct: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24117 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24118 = v_t_24117.f[0];
        V v_field_24119 = v_t_24117.f[1];
        V v_x_24120 = v_field_24118;
        V v_y_24121 = v_field_24119;
        heff_drop(v_y_24121);
        return v_x_24120;
      }
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24124 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24125 = v_t_24124.f[0];
        V v_field_24126 = v_t_24124.f[1];
        V v_x_24127 = v_field_24125;
        V v_y_24128 = v_field_24126;
        heff_drop(v_y_24128);
        return v_x_24127;
      }
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24131 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24132 = v_t_24131.f[0];
        V v_field_24133 = v_t_24131.f[1];
        V v_x_24134 = v_field_24132;
        V v_y_24135 = v_field_24133;
        heff_drop(v_y_24135);
        return v_x_24134;
      }
    }
    case TAG_ELetIn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24138 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24139 = v_t_24138.f[0];
        V v_field_24140 = v_t_24138.f[1];
        V v_x_24141 = v_field_24139;
        V v_y_24142 = v_field_24140;
        heff_drop(v_y_24142);
        return v_x_24141;
      }
    }
    case TAG_EDo: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24144 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24145 = v_t_24144.f[0];
        V v_field_24146 = v_t_24144.f[1];
        V v_x_24147 = v_field_24145;
        V v_y_24148 = v_field_24146;
        heff_drop(v_y_24148);
        return v_x_24147;
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24151 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24152 = v_t_24151.f[0];
        V v_field_24153 = v_t_24151.f[1];
        V v_x_24154 = v_field_24152;
        V v_y_24155 = v_field_24153;
        heff_drop(v_y_24155);
        return v_x_24154;
      }
    }
    case TAG_EInvalid: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24157 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24158 = v_t_24157.f[0];
        V v_field_24159 = v_t_24157.f[1];
        V v_x_24160 = v_field_24158;
        V v_y_24161 = v_field_24159;
        heff_drop(v_y_24161);
        return v_x_24160;
      }
    }
    case TAG_EAssign: {
      heff_take_n(v_e1_241, 0ULL, 3);
      HeffT2 v_t_24165 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24166 = v_t_24165.f[0];
        V v_field_24167 = v_t_24165.f[1];
        V v_x_24168 = v_field_24166;
        V v_y_24169 = v_field_24167;
        heff_drop(v_y_24169);
        return v_x_24168;
      }
    }
    case TAG_EWhile: {
      V v_e11_24170 = heff_field(v_e1_241, 0);
      V v_body_24171 = heff_field(v_e1_241, 1);
      heff_take_n(v_e1_241, 3ULL, 2);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        V v_t_24174 = (g_heff_2esyntax_2epresyntax_2ehasReturn(v_e11_24170));
        if ((heff_dup(v_t_24174) == NTAG(TAG_True))) {
          heff_drop(v_body_24171);
          heff_drop(v_t_24174);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_24174);
          return ({ V a_0 = v_body_24171; V r_ = (g_list_2eany_24s1414887908x732433189(a_0)); heff_drop(v_body_24171); r_; });
        }
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EFor: {
      V v_e12_24176 = heff_field(v_e1_241, 1);
      V v_body_24177 = heff_field(v_e1_241, 2);
      heff_take_n(v_e1_241, 6ULL, 3);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        V v_t_24180 = (g_heff_2esyntax_2epresyntax_2ehasReturn(v_e12_24176));
        if ((heff_dup(v_t_24180) == NTAG(TAG_True))) {
          heff_drop(v_body_24177);
          heff_drop(v_t_24180);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_24180);
          return ({ V a_0 = v_body_24177; V r_ = (g_list_2eany_24s1414887908x732433189(a_0)); heff_drop(v_body_24177); r_; });
        }
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EIfThen: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24183 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24184 = v_t_24183.f[0];
        V v_field_24185 = v_t_24183.f[1];
        V v_x_24186 = v_field_24184;
        V v_y_24187 = v_field_24185;
        heff_drop(v_y_24187);
        return v_x_24186;
      }
    }
    case TAG_EBreak: {
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EContinue: {
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EReturn: {
      heff_take_n(v_e1_241, 0ULL, 1);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_ENest: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24196 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24197 = v_t_24196.f[0];
        V v_field_24198 = v_t_24196.f[1];
        V v_x_24199 = v_field_24197;
        V v_y_24200 = v_field_24198;
        heff_drop(v_y_24200);
        return v_x_24199;
      }
    }
    case TAG_ELazy: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24202 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24203 = v_t_24202.f[0];
        V v_field_24204 = v_t_24202.f[1];
        V v_x_24205 = v_field_24203;
        V v_y_24206 = v_field_24204;
        heff_drop(v_y_24206);
        return v_x_24205;
      }
    }
    case TAG_ETuple: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24208 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24209 = v_t_24208.f[0];
        V v_field_24210 = v_t_24208.f[1];
        V v_x_24211 = v_field_24209;
        V v_y_24212 = v_field_24210;
        heff_drop(v_y_24212);
        return v_x_24211;
      }
    }
    case TAG_ETry: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24214 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24215 = v_t_24214.f[0];
        V v_field_24216 = v_t_24214.f[1];
        V v_x_24217 = v_field_24215;
        V v_y_24218 = v_field_24216;
        heff_drop(v_y_24218);
        return v_x_24217;
      }
    }
    case TAG_EWith: {
      heff_take_n(v_e1_241, 0ULL, 4);
      HeffT2 v_t_24223 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24224 = v_t_24223.f[0];
        V v_field_24225 = v_t_24223.f[1];
        V v_x_24226 = v_field_24224;
        V v_y_24227 = v_field_24225;
        heff_drop(v_y_24227);
        return v_x_24226;
      }
    }
    default: return heff_nomatch(v_e1_241);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ejumpE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ejumpE(a[0]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2edoBlock_24s1973147116x167776115_24cpr(V v_sp_240, V v_stmts_241) {
top: ;
  V v_x1_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stmts_241)));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_sp_240);
    heff_drop(v_stmts_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    heff_take_n(v_x1_242, 1ULL, 2);
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_it11_245 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 2);
      switch (heff_tag_of(v_it11_245)) {
      case TAG_StmtBind: {
        heff_take_n(v_it11_245, 0ULL, 3);
        heff_drop(v_sp_240);
        heff_drop(v_stmts_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_StmtLet: {
        heff_take_n(v_it11_245, 0ULL, 2);
        heff_drop(v_sp_240);
        heff_drop(v_stmts_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_StmtExpr: {
        heff_take_n(v_it11_245, 0ULL, 1);
        V v_t_2413 = heff_rec_n(6, shape_names__muts__loop__sp__depth__giving, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2eidNames_get()), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_sp_240, MK_INT(0LL), NTAG(TAG_Nothing)});
        V v_f_2414 = ({ V a_0 = v_t_2413; V a_1 = v_stmts_241; V a_2 = NTAG(TAG_EndValue); V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_stmts_241); r_; });
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
      }
      case TAG_StmtLetMut: {
        heff_take_n(v_it11_245, 0ULL, 3);
        heff_drop(v_sp_240);
        heff_drop(v_stmts_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_it11_245, 0ULL, 3);
        heff_drop(v_sp_240);
        heff_drop(v_stmts_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it11_245)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_242)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str3, 0, "");

HeffT2 g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr(V v_x1_240, V v_little_241, V v_v_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SizeDefault: {
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
    V v_t_245 = heff_intAdd(heff_intMod(v_v_242, v_t_243), v_t_244);
    V v_t_246 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
    V v_b_247 = (g_heff_2esyntax_2epresyntax_2enatBytes(heff_box_word((((int64_t)8ULL) / ((int64_t)8ULL))), heff_intMod(v_t_245, v_t_246), ((V)&g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str0)));
    V v_f_248;
    if ((heff_dup(v_little_241) == NTAG(TAG_True))) {
      v_f_248 = ({ V a_0 = v_b_247; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str1); V r_ = (g_heff_2esyntax_2epresyntax_2ereversedBytes(a_0, a_1, a_2)); heff_drop(v_b_247); r_; });
    } else {
      v_f_248 = v_b_247;
    }
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
  }
  case TAG_SizeNumber: {
    V v_n_249 = heff_field(v_x1_240, 0);
    if ((heff_unbox_word(heff_intMod(heff_dup(v_n_249), MK_INT(8LL))) == ((int64_t)0ULL))) {
      V v_t_2410 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_n_249)));
      V v_t_2411 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_n_249)));
      V v_t_2412 = heff_intAdd(heff_intMod(v_v_242, v_t_2410), v_t_2411);
      V v_t_2413 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_n_249)));
      V v_b_2414 = (g_heff_2esyntax_2epresyntax_2enatBytes(heff_intDiv(heff_dup(v_n_249), MK_INT(8LL)), heff_intMod(v_t_2412, v_t_2413), ((V)&g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str2)));
      V v_f_2415;
      if ((heff_dup(v_little_241) == NTAG(TAG_True))) {
        v_f_2415 = ({ V a_0 = v_b_2414; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str3); V r_ = (g_heff_2esyntax_2epresyntax_2ereversedBytes(a_0, a_1, a_2)); heff_drop(v_b_2414); r_; });
      } else {
        v_f_2415 = v_b_2414;
      }
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2415}});
    } else {
      heff_drop(v_v_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_SizeName: {
    heff_drop(v_v_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewatchOf_str0, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewatchOf_str1, 54, "a watch must say what type it has: write `>>> (e : T)`");
Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewatchOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ewatchOf(V v_c_240) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_IsInferable: {
    V v_i_241 = heff_field(v_c_240, 0);
    V v_ru_24c_240_24IsInferable = heff_take_reuse_n(v_c_240, 1ULL, 1);
    V v_t_244;
    switch (heff_tag_of(v_i_241)) {
    case TAG_At: {
      V v_s_243 = heff_dup(heff_field(v_i_241, 1));
      v_t_244 = v_s_243;
      break;
    }
    default: heff_nomatch(v_i_241);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24c_240_24IsInferable, TAG_CInf, 1, (V[]){v_i_241}), v_t_244});
  }
  case TAG_IsCheckable: {
    V v_t_246 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2ewatchOf_str0), NTAG(TAG_Nothing)});
    V v_t_2416;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_247 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_i_247)) {
      case TAG_At: {
        V v_s_249 = heff_field(v_i_247, 1);
        heff_take_n(v_i_247, 2ULL, 2);
        v_t_2416 = v_s_249;
        break;
      }
      default: heff_nomatch(v_i_247);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2410 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_c_2410)) {
      case TAG_At: {
        V v_s_2412 = heff_field(v_c_2410, 1);
        heff_take_n(v_c_2410, 2ULL, 2);
        v_t_2416 = v_s_2412;
        break;
      }
      default: heff_nomatch(v_c_2410);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2413 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_At: {
        V v_s_2415 = heff_field(v_t_2413, 1);
        heff_take_n(v_t_2413, 2ULL, 2);
        v_t_2416 = v_s_2415;
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2417 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_t_2416})});
    V v_t_2427;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2418 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_i_2418)) {
      case TAG_At: {
        V v_s_2420 = heff_field(v_i_2418, 1);
        heff_take_n(v_i_2418, 2ULL, 2);
        v_t_2427 = v_s_2420;
        break;
      }
      default: heff_nomatch(v_i_2418);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2421 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_c_2421)) {
      case TAG_At: {
        V v_s_2423 = heff_field(v_c_2421, 1);
        heff_take_n(v_c_2421, 2ULL, 2);
        v_t_2427 = v_s_2423;
        break;
      }
      default: heff_nomatch(v_c_2421);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2424 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_t_2424)) {
      case TAG_At: {
        V v_s_2426 = heff_field(v_t_2424, 1);
        heff_take_n(v_t_2424, 2ULL, 2);
        v_t_2427 = v_s_2426;
        break;
      }
      default: heff_nomatch(v_t_2424);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_t_2427});
  }
  case TAG_IsType: {
    V v_t_2429 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2ewatchOf_str1), NTAG(TAG_Nothing)});
    V v_t_2439;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2430 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_i_2430)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_i_2430, 1);
        heff_take_n(v_i_2430, 2ULL, 2);
        v_t_2439 = v_s_2432;
        break;
      }
      default: heff_nomatch(v_i_2430);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2433 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_c_2433)) {
      case TAG_At: {
        V v_s_2435 = heff_field(v_c_2433, 1);
        heff_take_n(v_c_2433, 2ULL, 2);
        v_t_2439 = v_s_2435;
        break;
      }
      default: heff_nomatch(v_c_2433);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2436 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_t_2436)) {
      case TAG_At: {
        V v_s_2438 = heff_field(v_t_2436, 1);
        heff_take_n(v_t_2436, 2ULL, 2);
        v_t_2439 = v_s_2438;
        break;
      }
      default: heff_nomatch(v_t_2436);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2440 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2429, v_t_2439})});
    V v_t_2450;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2441 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_i_2441)) {
      case TAG_At: {
        V v_s_2443 = heff_field(v_i_2441, 1);
        heff_take_n(v_i_2441, 2ULL, 2);
        v_t_2450 = v_s_2443;
        break;
      }
      default: heff_nomatch(v_i_2441);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2444 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_c_2444)) {
      case TAG_At: {
        V v_s_2446 = heff_field(v_c_2444, 1);
        heff_take_n(v_c_2444, 2ULL, 2);
        v_t_2450 = v_s_2446;
        break;
      }
      default: heff_nomatch(v_c_2444);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2447 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_t_2447)) {
      case TAG_At: {
        V v_s_2449 = heff_field(v_t_2447, 1);
        heff_take_n(v_t_2447, 2ULL, 2);
        v_t_2450 = v_s_2449;
        break;
      }
      default: heff_nomatch(v_t_2447);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2440, v_t_2450});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewatchOf(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str0, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str1, 10, "bitsConcat");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str2, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str3, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str4, 10, "bitsConcat");

HeffT2 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(V v_segs_240, V v_sp_241, V v_x5_242) {
top: ;
  if ((heff_dup(v_x5_242) == NTAG(TAG_True))) {
    V v_xs_243 = (g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1654483724x1393507626(((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str0), v_segs_240, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_243));
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_244, heff_dup(v_sp_241)));
    V v_args_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_246));
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str1)}), heff_dup(v_sp_241)});
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_248, v_t_247}), heff_dup(v_sp_241)});
    V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_249}), heff_dup(v_sp_241)});
    V v_args_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str2)}), heff_dup(v_sp_241)});
    V v_t_2413 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2411));
    V v_f_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2412, v_t_2413}), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2414}});
  } else {
    V v_xs_2415 = (g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1654483724x1393507626(((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str3), v_segs_240, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2415));
    V v_t_2417 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2416, heff_dup(v_sp_241)));
    V v_args_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str4)}), heff_dup(v_sp_241)});
    V v_t_2420 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2418));
    V v_f_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2419, v_t_2420}), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2421}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str0, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str1, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str2, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str3, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str4, 9, "floatBits");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str5, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str6, 17, "prelude.utf8Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str7, 18, "prelude.utf16Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str8, 18, "prelude.utf32Bytes");
Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkSegment: {
      V v_v_243 = heff_field(v_x21_241, 0);
      V v_x212_244 = heff_field(v_x21_241, 1);
      V v_size_245 = heff_field(v_x21_241, 2);
      V v_little_246 = heff_field(v_x21_241, 3);
      V v_signed_247 = heff_field(v_x21_241, 4);
      heff_take_n(v_x21_241, 31ULL, 5);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_SegmentInteger: {
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(8LL), heff_dup(v_sp_242)));
        int64_t v_t_249;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)0ULL);
        }
        int64_t v_t_2410;
        if ((heff_dup(v_signed_247) == NTAG(TAG_True))) {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)0ULL);
        }
        V v_t_2411 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_249 + v_t_2410))});
        V v_t_2412 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_242)})});
        HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_2425;
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_c_2416 = v_field_2415;
            v_t_2425 = v_c_2416;
          } else {
            if ((v_tag_2414 == ((int64_t)1ULL))) {
              V v_i_2417 = v_field_2415;
              V v_t_2420;
              switch (heff_tag_of(v_i_2417)) {
              case TAG_At: {
                V v_s_2419 = heff_dup(heff_field(v_i_2417, 1));
                v_t_2420 = v_s_2419;
                break;
              }
              default: heff_nomatch(v_i_2417);
              }
              v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2417}), v_t_2420});
            } else {
              V v_t_2421 = v_field_2415;
              V v_t_2424;
              switch (heff_tag_of(v_t_2421)) {
              case TAG_At: {
                V v_s_2423 = heff_dup(heff_field(v_t_2421, 1));
                v_t_2424 = v_s_2423;
                break;
              }
              default: heff_nomatch(v_t_2421);
              }
              v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2421}), v_t_2424});
            }
          }
        }
        V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
        V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_242)}), v_t_2426});
        V v_args_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2427});
        V v_t_2429 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2428));
        V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str0)}), heff_dup(v_sp_242)});
        V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2430, v_t_2429}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2431}), v_sp_242});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        switch (heff_tag_of(v_size_245)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_242);
          HeffT2 v_t_2432 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          {
            V v_field_2434 = v_t_2432.f[1];
            int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
            if ((v_tag_2433 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2435 = v_field_2434;
              return v_c_2435;
            } else {
              if ((v_tag_2433 == ((int64_t)1ULL))) {
                V v_i_2436 = v_field_2434;
                V v_t_2439;
                switch (heff_tag_of(v_i_2436)) {
                case TAG_At: {
                  V v_s_2438 = heff_dup(heff_field(v_i_2436, 1));
                  v_t_2439 = v_s_2438;
                  break;
                }
                default: heff_nomatch(v_i_2436);
                }
                return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2436}), v_t_2439});
              } else {
                V v_t_2440 = v_field_2434;
                V v_t_2443;
                switch (heff_tag_of(v_t_2440)) {
                case TAG_At: {
                  V v_s_2442 = heff_dup(heff_field(v_t_2440, 1));
                  v_t_2443 = v_s_2442;
                  break;
                }
                default: heff_nomatch(v_t_2440);
                }
                return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2440}), v_t_2443});
              }
            }
          }
        }
        case TAG_SizeNumber: {
          V v_t_2445 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT2 v_t_2446 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          V v_t_2458;
          {
            V v_field_2448 = v_t_2446.f[1];
            int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
            if ((v_tag_2447 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2449 = v_field_2448;
              v_t_2458 = v_c_2449;
            } else {
              if ((v_tag_2447 == ((int64_t)1ULL))) {
                V v_i_2450 = v_field_2448;
                V v_t_2453;
                switch (heff_tag_of(v_i_2450)) {
                case TAG_At: {
                  V v_s_2452 = heff_dup(heff_field(v_i_2450, 1));
                  v_t_2453 = v_s_2452;
                  break;
                }
                default: heff_nomatch(v_i_2450);
                }
                v_t_2458 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2450}), v_t_2453});
              } else {
                V v_t_2454 = v_field_2448;
                V v_t_2457;
                switch (heff_tag_of(v_t_2454)) {
                case TAG_At: {
                  V v_s_2456 = heff_dup(heff_field(v_t_2454, 1));
                  v_t_2457 = v_s_2456;
                  break;
                }
                default: heff_nomatch(v_t_2454);
                }
                v_t_2458 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2454}), v_t_2457});
              }
            }
          }
          V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, NTAG(TAG_Nil)});
          V v_args_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, v_t_2459});
          V v_t_2461 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2460));
          V v_t_2462 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str1)}), heff_dup(v_sp_242)});
          V v_t_2463 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2462, v_t_2461}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2463}), v_sp_242});
        }
        case TAG_SizeName: {
          V v_t_2467 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT2 v_t_2468 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          V v_t_2480;
          {
            V v_field_2470 = v_t_2468.f[1];
            int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
            if ((v_tag_2469 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2471 = v_field_2470;
              v_t_2480 = v_c_2471;
            } else {
              if ((v_tag_2469 == ((int64_t)1ULL))) {
                V v_i_2472 = v_field_2470;
                V v_t_2475;
                switch (heff_tag_of(v_i_2472)) {
                case TAG_At: {
                  V v_s_2474 = heff_dup(heff_field(v_i_2472, 1));
                  v_t_2475 = v_s_2474;
                  break;
                }
                default: heff_nomatch(v_i_2472);
                }
                v_t_2480 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2472}), v_t_2475});
              } else {
                V v_t_2476 = v_field_2470;
                V v_t_2479;
                switch (heff_tag_of(v_t_2476)) {
                case TAG_At: {
                  V v_s_2478 = heff_dup(heff_field(v_t_2476, 1));
                  v_t_2479 = v_s_2478;
                  break;
                }
                default: heff_nomatch(v_t_2476);
                }
                v_t_2480 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2476}), v_t_2479});
              }
            }
          }
          V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2480, NTAG(TAG_Nil)});
          V v_args_2482 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2467, v_t_2481});
          V v_t_2483 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2482));
          V v_t_2484 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str2)}), heff_dup(v_sp_242)});
          V v_t_2485 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2484, v_t_2483}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2485}), v_sp_242});
        }
        default: return heff_nomatch(v_size_245);
        }
      }
      case TAG_SegmentBits: {
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        HeffT2 v_t_2486 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_2498;
        {
          V v_field_2488 = v_t_2486.f[1];
          int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
          if ((v_tag_2487 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_c_2489 = v_field_2488;
            v_t_2498 = v_c_2489;
          } else {
            if ((v_tag_2487 == ((int64_t)1ULL))) {
              V v_i_2490 = v_field_2488;
              V v_t_2493;
              switch (heff_tag_of(v_i_2490)) {
              case TAG_At: {
                V v_s_2492 = heff_dup(heff_field(v_i_2490, 1));
                v_t_2493 = v_s_2492;
                break;
              }
              default: heff_nomatch(v_i_2490);
              }
              v_t_2498 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2490}), v_t_2493});
            } else {
              V v_t_2494 = v_field_2488;
              V v_t_2497;
              switch (heff_tag_of(v_t_2494)) {
              case TAG_At: {
                V v_s_2496 = heff_dup(heff_field(v_t_2494, 1));
                v_t_2497 = v_s_2496;
                break;
              }
              default: heff_nomatch(v_t_2494);
              }
              v_t_2498 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2494}), v_t_2497});
            }
          }
        }
        V v_args_2499 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2498, NTAG(TAG_Nil)});
        V v_t_24100 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2499));
        V v_t_24101 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str3)}), heff_dup(v_sp_242)});
        V v_t_24102 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24101, v_t_24100}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24102}), v_sp_242});
      }
      case TAG_SegmentFloat: {
        heff_drop(v_signed_247);
        V v_t_24103 = (g_heff_2esyntax_2epresyntax_2esizeTerm(heff_dup(v_size_245), MK_INT(64LL), heff_dup(v_sp_242)));
        int64_t v_t_24104;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_24104 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_24104 = ((int64_t)0ULL);
        }
        V v_t_24105 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_24104 + ((int64_t)0ULL)))});
        V v_t_24106 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24105, heff_dup(v_sp_242)})});
        V v_t_24107 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(64LL), heff_dup(v_sp_242)));
        HeffT2 v_t_24108 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_24120;
        {
          V v_field_24110 = v_t_24108.f[1];
          int64_t v_tag_24109 = ((int64_t)v_t_24108.f[0]);
          if ((v_tag_24109 == ((int64_t)0ULL))) {
            V v_c_24111 = v_field_24110;
            v_t_24120 = v_c_24111;
          } else {
            if ((v_tag_24109 == ((int64_t)1ULL))) {
              V v_i_24112 = v_field_24110;
              V v_t_24115;
              switch (heff_tag_of(v_i_24112)) {
              case TAG_At: {
                V v_s_24114 = heff_dup(heff_field(v_i_24112, 1));
                v_t_24115 = v_s_24114;
                break;
              }
              default: heff_nomatch(v_i_24112);
              }
              v_t_24120 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24112}), v_t_24115});
            } else {
              V v_t_24116 = v_field_24110;
              V v_t_24119;
              switch (heff_tag_of(v_t_24116)) {
              case TAG_At: {
                V v_s_24118 = heff_dup(heff_field(v_t_24116, 1));
                v_t_24119 = v_s_24118;
                break;
              }
              default: heff_nomatch(v_t_24116);
              }
              v_t_24120 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24116}), v_t_24119});
            }
          }
        }
        V v_t_24121 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24120, NTAG(TAG_Nil)});
        V v_args_24122 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24107, v_t_24121});
        V v_t_24123 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24122));
        V v_t_24124 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str4)}), heff_dup(v_sp_242)});
        V v_t_24125 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24124, v_t_24123}), heff_dup(v_sp_242)});
        V v_t_24126 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24125}), heff_dup(v_sp_242)});
        V v_t_24127 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24126, NTAG(TAG_Nil)});
        V v_t_24128 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24106, heff_dup(v_sp_242)}), v_t_24127});
        V v_args_24129 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24103, v_t_24128});
        V v_t_24130 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24129));
        V v_t_24131 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str5)}), heff_dup(v_sp_242)});
        V v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24131, v_t_24130}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24132}), v_sp_242});
      }
      case TAG_SegmentUtf: {
        V v_x2121_24133 = heff_field(v_x212_244, 0);
        V v_ru_24x212_244_24SegmentUtf = heff_take_reuse_n(v_x212_244, 1ULL, 1);
        heff_drop(v_size_245);
        heff_drop(v_signed_247);
        if (heff_intEq_c_lent(v_x2121_24133, MK_INT(8LL), 2)) {
          heff_drop(v_little_246);
          heff_drop(v_x2121_24133);
          V v_t_24134 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
          V v_args_24135 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24134, NTAG(TAG_Nil)});
          V v_t_24136 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24135));
          V v_t_24137 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str6)}), heff_dup(v_sp_242)});
          V v_t_24138 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24137, v_t_24136}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_CInf, 1, (V[]){v_t_24138}), v_sp_242});
        } else {
          if (heff_intEq_c(v_x2121_24133, MK_INT(16LL))) {
            int64_t v_t_24139;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24139 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24139 = ((int64_t)0ULL);
            }
            V v_t_24140 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24139 + ((int64_t)0ULL)))});
            V v_t_24141 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24140, heff_dup(v_sp_242)})});
            V v_t_24142 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24143 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24142, NTAG(TAG_Nil)});
            V v_args_24144 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24141, heff_dup(v_sp_242)}), v_t_24143});
            V v_t_24145 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24144));
            V v_t_24146 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str7)}), heff_dup(v_sp_242)});
            V v_t_24147 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24146, v_t_24145}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24147}), v_sp_242});
          } else {
            int64_t v_t_24148;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24148 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24148 = ((int64_t)0ULL);
            }
            V v_t_24149 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24148 + ((int64_t)0ULL)))});
            V v_t_24150 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24149, heff_dup(v_sp_242)})});
            V v_t_24151 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24152 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24151, NTAG(TAG_Nil)});
            V v_args_24153 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24150, heff_dup(v_sp_242)}), v_t_24152});
            V v_t_24154 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24153));
            V v_t_24155 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str8)}), heff_dup(v_sp_242)});
            V v_t_24156 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24155, v_t_24154}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24156}), v_sp_242});
          }
        }
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_ExplicitParam: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_t_245 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24ExplicitParam = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      HeffT2 v_t_246 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_245));
      V v_t_2418;
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_c_249 = v_field_248;
          V v_t_2412;
          switch (heff_tag_of(v_c_249)) {
          case TAG_At: {
            V v_s_2411 = heff_dup(heff_field(v_c_249, 1));
            v_t_2412 = v_s_2411;
            break;
          }
          default: heff_nomatch(v_c_249);
          }
          v_t_2418 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_249}), v_t_2412});
        } else {
          if ((v_tag_247 == ((int64_t)1ULL))) {
            V v_i_2413 = v_field_248;
            V v_t_2416;
            switch (heff_tag_of(v_i_2413)) {
            case TAG_At: {
              V v_s_2415 = heff_dup(heff_field(v_i_2413, 1));
              v_t_2416 = v_s_2415;
              break;
            }
            default: heff_nomatch(v_i_2413);
            }
            v_t_2418 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2413}), v_t_2416});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2417 = v_field_248;
            v_t_2418 = v_t_2417;
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_x_243, v_xsp_244, v_t_2418}), v_sp_242});
    }
    case TAG_ImplicitParam: {
      V v_x_2419 = heff_field(v_x21_241, 0);
      V v_xsp_2420 = heff_field(v_x21_241, 1);
      V v_t_2421 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24ImplicitParam = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      HeffT2 v_t_2422 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2421));
      V v_t_2434;
      {
        V v_field_2424 = v_t_2422.f[1];
        int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
        if ((v_tag_2423 == ((int64_t)0ULL))) {
          V v_c_2425 = v_field_2424;
          V v_t_2428;
          switch (heff_tag_of(v_c_2425)) {
          case TAG_At: {
            V v_s_2427 = heff_dup(heff_field(v_c_2425, 1));
            v_t_2428 = v_s_2427;
            break;
          }
          default: heff_nomatch(v_c_2425);
          }
          v_t_2434 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2425}), v_t_2428});
        } else {
          if ((v_tag_2423 == ((int64_t)1ULL))) {
            V v_i_2429 = v_field_2424;
            V v_t_2432;
            switch (heff_tag_of(v_i_2429)) {
            case TAG_At: {
              V v_s_2431 = heff_dup(heff_field(v_i_2429, 1));
              v_t_2432 = v_s_2431;
              break;
            }
            default: heff_nomatch(v_i_2429);
            }
            v_t_2434 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2429}), v_t_2432});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2433 = v_field_2424;
            v_t_2434 = v_t_2433;
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_x_2419, v_xsp_2420, v_t_2434}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24PiNamed = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_246;
    switch (heff_tag_of(v_t_243)) {
    case TAG_At: {
      V v_n_244 = heff_field(v_t_243, 0);
      V v_sp_245 = heff_field(v_t_243, 1);
      V v_ru_24t_243_24At = heff_take_reuse_n(v_t_243, 3ULL, 2);
      v_t_246 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_243_24At, v_sp_245, v_n_244));
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_241, v_sp_242, v_t_246});
  }
  case TAG_PiImplicit: {
    V v_x_247 = heff_field(v_x2_240, 0);
    V v_sp_248 = heff_field(v_x2_240, 1);
    V v_sp2_249 = heff_field(v_x2_240, 2);
    V v_t_2410 = heff_field(v_x2_240, 3);
    V v_d_2411 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24PiImplicit = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_2414;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_At: {
      V v_n_2412 = heff_field(v_t_2410, 0);
      V v_sp_2413 = heff_field(v_t_2410, 1);
      V v_ru_24t_2410_24At = heff_take_reuse_n(v_t_2410, 3ULL, 2);
      v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2410_24At, v_sp_2413, v_n_2412));
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2420;
    switch (heff_tag_of(v_d_2411)) {
    case TAG_Nothing: {
      v_t_2420 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2415 = heff_field(v_d_2411, 0);
      V v_ru_24d_2411_24Just = heff_take_reuse_n(v_d_2411, 1ULL, 1);
      V v_t_2419;
      switch (heff_tag_of(v_x_2415)) {
      case TAG_At: {
        V v_n_2416 = heff_field(v_x_2415, 0);
        V v_sp_2417 = heff_field(v_x_2415, 1);
        V v_ru_24x_2415_24At = heff_take_reuse_n(v_x_2415, 3ULL, 2);
        V v_t_2418 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2416));
        v_t_2419 = heff_tag_at_n(v_ru_24x_2415_24At, TAG_At, 2, (V[]){v_t_2418, v_sp_2417});
        break;
      }
      default: heff_nomatch(v_x_2415);
      }
      v_t_2420 = heff_tag_at_n(v_ru_24d_2411_24Just, TAG_Just, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_d_2411);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_247, v_sp_248, v_sp2_249, v_t_2414, v_t_2420});
  }
  case TAG_PiInstance: {
    V v_x_2421 = heff_field(v_x2_240, 0);
    V v_sp_2422 = heff_field(v_x2_240, 1);
    V v_sp2_2423 = heff_field(v_x2_240, 2);
    V v_t_2424 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24PiInstance = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2427;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_At: {
      V v_n_2425 = heff_field(v_t_2424, 0);
      V v_sp_2426 = heff_field(v_t_2424, 1);
      V v_ru_24t_2424_24At = heff_take_reuse_n(v_t_2424, 3ULL, 2);
      v_t_2427 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2424_24At, v_sp_2426, v_n_2425));
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2421, v_sp_2422, v_sp2_2423, v_t_2427});
  }
  case TAG_PiAnon: {
    V v_t_2428 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24PiAnon = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2431;
    switch (heff_tag_of(v_t_2428)) {
    case TAG_At: {
      V v_n_2429 = heff_field(v_t_2428, 0);
      V v_sp_2430 = heff_field(v_t_2428, 1);
      V v_ru_24t_2428_24At = heff_take_reuse_n(v_t_2428, 3ULL, 2);
      v_t_2431 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2428_24At, v_sp_2430, v_n_2429));
      break;
    }
    default: heff_nomatch(v_t_2428);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2431});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_TPi: {
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_245 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_244, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_240});
  }
  case TAG_TSig: {
    V v_fs_246 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TSig = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_247 = (g_list_2emap_24s1992667171x110340492(v_fs_246));
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24TSig, TAG_TSig, 1, (V[]){v_t_247}), v_sp_240});
  }
  case TAG_TSum: {
    V v_vs_248 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TSum = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_249 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(heff_tag_at_n(v_ru_24n_241_24TSum, TAG_TSum, 1, (V[]){v_vs_248})));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_sp_240});
  }
  case TAG_TType: {
    V v_t_2410 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2411 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_sp_240});
  }
  case TAG_TInt: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2413 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_TFloat: {
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2415 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_sp_240});
  }
  case TAG_TString: {
    V v_t_2416 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2417 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2416, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_sp_240});
  }
  case TAG_TRune: {
    V v_t_2418 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2419 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_240});
  }
  case TAG_TArray: {
    V v_t_2421 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2422 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2421, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_sp_240});
  }
  case TAG_TFixed: {
    V v_t_2424 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2425 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_sp_240});
  }
  case TAG_TInf: {
    V v_i_2426 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TInf = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2429;
    switch (heff_tag_of(v_i_2426)) {
    case TAG_At: {
      V v_n_2427 = heff_field(v_i_2426, 0);
      V v_sp_2428 = heff_field(v_i_2426, 1);
      V v_ru_24i_2426_24At = heff_take_reuse_n(v_i_2426, 3ULL, 2);
      v_t_2429 = (g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(v_ru_24i_2426_24At, v_sp_2428, v_n_2427));
      break;
    }
    default: heff_nomatch(v_i_2426);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24TInf, TAG_TInf, 1, (V[]){v_t_2429}), v_sp_240});
  }
  case TAG_TChk: {
    V v_c_2430 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TChk = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2433;
    switch (heff_tag_of(v_c_2430)) {
    case TAG_At: {
      V v_n_2431 = heff_field(v_c_2430, 0);
      V v_sp_2432 = heff_field(v_c_2430, 1);
      heff_take_n(v_c_2430, 3ULL, 2);
      v_t_2433 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2432, v_n_2431));
      break;
    }
    default: heff_nomatch(v_c_2430);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24TChk, TAG_TChk, 1, (V[]){v_t_2433}), v_sp_240});
  }
  case TAG_TNominal: {
    V v_t_2435 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2436 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2435, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2436, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(a[0], a[1]);
}