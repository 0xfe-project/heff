// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_Catch 6517
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_FracNum 48168
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_IntNum 31256
#define TAG_LSnoc 32613
#define TAG_Large 60129
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Record 39342
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SError 24172
#define TAG_SGlobal 8650
#define TAG_SLocal 28569
#define TAG_SaveDelayed 42463
#define TAG_Small 51389
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_TopL 65516
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_aliases 1464806715
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_elabFor 712452832
#define LBL_entries 787768015
#define LBL_globals 352931696
#define LBL_instances 1653559473
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_member 869372357
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ret 322331
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_ty 10476
#define LBL_type_5f 312202367
#define LBL_v 336
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_name__ty__v[] = {LBL_name, LBL_ty, LBL_v};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eelab_2eenvironment_2emultiBind(V, V, V);
V g_heff_2eelab_2eenvironment_2emultiBind_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2emultiBind_clo;
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2ememoed_2eapp(V, V);
V g_heff_2eelab_2ememoed_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eapp_clo;
HeffT2 g_heff_2eelab_2ememoed_2eapp_24cpr(V, V);
V g_heff_2eelab_2ememoed_2efunctionD(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2efunctionD_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2efunctionD_clo;
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erules_2ebrokenInstanceIn(V);
V g_heff_2eelab_2erules_2ebrokenInstanceIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ebrokenInstanceIn_clo;
V g_heff_2eelab_2erules_2ecaseArm(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecaseArm_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseArm_clo;
V g_heff_2eelab_2erules_2ecodeAt(V, V, V, V, V);
V g_heff_2eelab_2erules_2ecodeAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecodeAt_clo;
V g_heff_2eelab_2erules_2ecoeGoal(V, V, V);
V g_heff_2eelab_2erules_2ecoeGoal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecoeGoal_clo;
V g_heff_2eelab_2erules_2eentriesGo_24dps(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eentriesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eentriesGo_24dps_clo;
HeffT1 g_heff_2eelab_2erules_2efindPrim_24cpr(V, V);
HeffT1 g_heff_2eelab_2erules_2efunctionIntro_24cpr(V, V, V);
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
HeffT1 g_heff_2eelab_2erules_2eimplicitLams_24cpr(V);
HeffT2 g_heff_2eelab_2erules_2eindexOfName_24cpr(V, V, V);
V g_heff_2eelab_2erules_2elargeField(V, V, V, V);
V g_heff_2eelab_2erules_2elargeField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elargeField_clo;
HeffT2 g_heff_2eelab_2erules_2elazyOf_24cpr(V);
V g_heff_2eelab_2erules_2enoSuchSetting(V, V, V, V);
V g_heff_2eelab_2erules_2enoSuchSetting_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enoSuchSetting_clo;
V g_heff_2eelab_2erules_2enotANumber(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enotANumber_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotANumber_clo;
V g_heff_2eelab_2erules_2enotFunctionMsg(V);
V g_heff_2eelab_2erules_2enotFunctionMsg_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotFunctionMsg_clo;
HeffT2 g_heff_2eelab_2erules_2eotherTag_24cpr(V, V);
V g_heff_2eelab_2erules_2eplacesSaid_24acc(V, V);
V g_heff_2eelab_2erules_2eplacesSaid_24acc_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesSaid_24acc_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
HeffT1 g_heff_2eelab_2erules_2erecordIntro_24cpr(V, V);
V g_heff_2eelab_2erules_2erecoverWith(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecoverWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecoverWith_clo;
HeffT1 g_heff_2eelab_2erules_2erecovering_24cpr(V);
V g_heff_2eelab_2erules_2erequireAgree(V, V, V);
V g_heff_2eelab_2erules_2erequireAgree_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erequireAgree_clo;
V g_heff_2eelab_2erules_2etyStrIn(V, V, V);
V g_heff_2eelab_2erules_2etyStrIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrIn_clo;
V g_heff_2eelab_2erules_2etyStrM(V, V);
V g_heff_2eelab_2erules_2etyStrM_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrM_clo;
V g_heff_2eelab_2erules_2etyStrZ(V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_clo;
V g_heff_2eelab_2erules_2eupdateOf(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdateOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdateOf_clo;
V g_heff_2eelab_2erules_2eupdateSetting(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdateSetting_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdateSetting_clo;
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
HeffT2 g_heff_2eelab_2evalue_2edecodeEv_24cpr(V);
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263(V);
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_clo;
HeffT2 g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24cpr(V);
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(V, V, V);
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1990719097x1419059608(V);
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_clo;
V g_list_2emap_24s258116700x992061112(V, V);
V g_list_2emap_24s258116700x992061112_entry(V self, V *a);
extern Clo g_list_2emap_24s258116700x992061112_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_heff_2eelab_2erules_2erecovering_24cpr_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2erecovering_24cpr_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecovering_24cpr_lam1, 1, 0};
V g_heff_2eelab_2erules_2erecovering_24cpr_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2erecovering_24cpr_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecovering_24cpr_lam3, 1, 0};
V g_heff_2eelab_2erules_2erecovering_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2erecovering_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2erules_2erecovering_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecovering_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2erecovering_24cpr(V v_c_240) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2erecovering_24cpr_lam0, 4, 1, (V[]){heff_dup(v_c_240)})}});
}
V g_heff_2eelab_2erules_2erecovering_24cpr_lam1(V self, V *args) {
  V v_c0_245 = args[0];
  return v_c0_245;
}
V g_heff_2eelab_2erules_2erecovering_24cpr_lam3(V self, V *args) {
  V v_sv_2410 = args[0];
  return v_sv_2410;
}
V g_heff_2eelab_2erules_2erecovering_24cpr_lam5(V self, V *args) {
  V v_s_2417 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_a_242 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_e_241; V a_1 = v_a_242; V a_2 = v_s_2417; V a_3 = v_x_249; V a_4 = v_x_2413; V a_5 = heff_dup(v_hd_243); V a_6 = heff_get_n(v_hd_243, 0, 3); V r_ = (g_heff_2eelab_2erules_2erecoverWith(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_e_241); r_; });
}
V g_heff_2eelab_2erules_2erecovering_24cpr_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_x_249 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_m_2415;
  switch (heff_tag_of(v_c_240)) {
  case TAG_MkChk: {
    V v_f_2414 = heff_field(v_c_240, 0);
    heff_take_n(v_c_240, 1ULL, 1);
    v_m_2415 = heff_tr(heff_call(v_f_2414, 2, (V[]){heff_dup(v_e_241), heff_dup(v_a_242)}));
    break;
  }
  default: heff_nomatch(v_c_240);
  }
  V v_t_2416 = heff_tr(heff_call(v_m_2415, 2, (V[]){heff_dup(v_hd_243), heff_dup(heff_rfield(v_hd_243, 0))}));
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2416, heff_clo_n(g_heff_2eelab_2erules_2erecovering_24cpr_lam5, 1, 5, (V[]){v_e_241, v_a_242, v_x_249, v_x_2413, heff_dup(v_hd_243)})})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_243, 2), 1, (V[]){v_t_2419}));
  V f_ = heff_get_n(v_hd_243, 1, 3);
  heff_room[0] = v_t_2420;
  heff_room[1] = v_k_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2erecovering_24cpr_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_SaveDelayed, 1, (V[]){((V)&g_heff_2eelab_2erules_2erecovering_24cpr_lam3_clo)})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2erecovering_24cpr_lam4, 1, 6, (V[]){v_c_240, v_e_241, v_a_242, v_hd_243, v_x_249, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2erecovering_24cpr_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_242 = args[1];
  V v_hd_243 = args[2];
  V v_k_244 = args[3];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2erecovering_24cpr_lam1_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_t_248;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecovering_24cpr_lam2, 1, 5, (V[]){v_hd_243, v_c_240, v_e_241, v_a_242, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ebrokenInstanceIn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ebrokenInstanceIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ebrokenInstanceIn_entry, 1, 0};

V g_heff_2eelab_2erules_2ebrokenInstanceIn(V v_e_240) {
top: ;
  V v_t_241 = heff_get_n(heff_dup(heff_rfield(v_e_240, 1)), 7, 8);
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_241));
  return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ebrokenInstanceIn_lam0, 1, 1, (V[]){v_e_240}); V a_1 = v_t_242; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_242); r_; });
}
V g_heff_2eelab_2erules_2ebrokenInstanceIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ebrokenInstanceIn(a[0]);
}
V g_heff_2eelab_2erules_2ebrokenInstanceIn_lam0(V self, V *args) {
  V v_i_243 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_g_244 = heff_get_n(v_e_240, 1, 6);
  V v_k_245 = heff_get_n(v_i_243, 0, 2);
  HeffT2 v_t_246 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_g_244, 1), v_k_245));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop_rec(v_g_244, 8);
      heff_drop(v_k_245);
      V v_e_2410 = v_field_248;
      heff_drop(v_e_2410);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_field_248);
      HeffT2 v_t_2411 = ({ V a_0 = heff_rfield(v_g_244, 2); V a_1 = v_k_245; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_k_245); r_; });
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_k2_2415 = v_field_2413;
          HeffT2 v_t_2416 = ({ V b_0 = heff_get_n(v_g_244, 1, 8); V a_1 = v_k2_2415; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k2_2415); r_; });
          {
            V v_field_2418 = v_t_2416.f[1];
            int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_2417 == ((int64_t)0ULL)) ? ({ V v_x_2420 = heff_dup(v_field_2418); int c_ = 0; heff_drop(v_x_2420); c_; }) : 1));
            heff_drop(v_field_2418);
            return v_ret_24bool;
          }
        } else {
          heff_drop_rec(v_g_244, 8);
          heff_drop(v_field_2413);
          return NTAG(TAG_True);
        }
      }
    }
  }
}
Clo g_heff_2eelab_2erules_2eimplicitLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitLams_entry, 1, 0};

V g_heff_2eelab_2erules_2eimplicitLams(V v_c_240) {
top: ;
  HeffT1 v_t_241 = (g_heff_2eelab_2erules_2eimplicitLams_24cpr(v_c_240));
  {
    V v_field_242 = v_t_241.f[0];
    return heff_tag_n(TAG_MkChk, 1, (V[]){v_field_242});
  }
}
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eimplicitLams(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntro_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntro_24cpr_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntro_24cpr_str2, 1, "_");
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam12(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2efunctionIntro_24cpr(V v_sp_240, V v_x_241, V v_body_242) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam0, 4, 3, (V[]){v_x_241, v_sp_240, heff_dup(v_body_242)})}});
}
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_247, 3, 8); V a_1 = v_a0_244; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam4(V self, V *args) {
  V v_u_2429 = args[0];
  V v_v_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2429);
  return v_v_2424;
}
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam7(V self, V *args) {
  V v_u_2454 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2454);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2411});
}
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam6(V self, V *args) {
  V v_x_2446 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_k_2445 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2447 = heff_take_field(v_e_243, 2);
  V v_t_2450;
  switch (heff_tag_of(v_t_2447)) {
  case TAG_ForNominative: {
    v_t_2450 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2447, 0ULL, 2);
    v_t_2450 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2447);
  }
  V v_t_2451 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_t_2452 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
  V v_t_2453 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2452, heff_dup(v_x_2411)));
  V v_x_2455 = (g_heff_2eelab_2ememoed_2elam(v_t_2450, heff_get_n(v_e_243, 1, 6), v_t_2451, heff_rec_n(2, shape_stx__val, (V[]){v_t_2453, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam7, 1, 1, (V[]){v_x_2411})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_241, v_x_2446})));
  V f_ = v_k_2445;
  args[0] = v_x_2455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam5(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  V v_c_2443 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2443;
  args[0] = v_hd_2444;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam6, 1, 4, (V[]){v_e_243, v_x_2411, v_x_241, v_k_2445});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam3(V self, V *args) {
  V v_v_2424 = args[0];
  V v_scope_27_2425 = args[1];
  V v_cod_2421 = heff_env(self)[0];
  V v_body_242 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_x_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2431;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_vs_2427 = heff_field(v_cod_2421, 1);
    V v_body_2428 = heff_field(v_cod_2421, 2);
    heff_take_n(v_cod_2421, 6ULL, 3);
    v_x1_2431 = heff_tr(heff_call(v_body_2428, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2427, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam4, 1, 1, (V[]){heff_dup(v_v_2424)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2430 = heff_field(v_cod_2421, 0);
    heff_take_n(v_cod_2421, 1ULL, 1);
    v_x1_2431 = v_body_2430;
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_a_2435;
  switch (heff_tag_of(v_x1_2431)) {
  case TAG_Nom: {
    V v_x_2432 = heff_field(v_x1_2431, 0);
    heff_take_n(v_x1_2431, 1ULL, 1);
    v_a_2435 = v_x_2432;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2431, 0ULL, 1);
    v_a_2435 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2434 = heff_field(v_x1_2431, 0);
    heff_take_n(v_x1_2431, 1ULL, 1);
    v_a_2435 = v_x_2434;
    break;
  }
  default: heff_nomatch(v_x1_2431);
  }
  V v_c_2443;
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2436 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    V v_t_2437 = heff_dup(heff_rfield(v_e_243, 2));
    V v_t_2440;
    switch (heff_tag_of(v_t_2437)) {
    case TAG_ForNominative: {
      heff_drop(v_v_2424);
      v_t_2440 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_2438 = heff_field(v_t_2437, 0);
      V v_sp_2439 = heff_field(v_t_2437, 1);
      V v_ru_24t_2437_24ForDescriptive = heff_take_reuse_n(v_t_2437, 3ULL, 2);
      v_t_2440 = heff_tag_at_n(v_ru_24t_2437_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2438, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2439, v_v_2424})});
      break;
    }
    default: heff_nomatch(v_t_2437);
    }
    V v_t_2441 = heff_intAdd(heff_dup(heff_rfield(v_e_243, 3)), MK_INT(1LL));
    V v_t_2442 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2425, heff_dup(heff_rfield(v_e_243, 1)), v_t_2440, v_t_2441, heff_dup(heff_rfield(v_e_243, 4)), heff_dup(heff_rfield(v_e_243, 5))});
    v_c_2443 = heff_tr(heff_call(v_f_2436, 2, (V[]){v_t_2442, v_a_2435}));
    break;
  }
  default: heff_nomatch(v_body_242);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam5, 2, 4, (V[]){v_c_2443, v_e_243, v_x_2411, v_x_241});
}
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam9(V self, V *args) {
  V v_u_2469 = args[0];
  V v_v_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2469);
  return v_v_2462;
}
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam12(V self, V *args) {
  V v_u_24105 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24105);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2411});
}
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam11(V self, V *args) {
  V v_x_2492 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_cod_2421 = heff_env(self)[2];
  V v_k_2491 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2493 = heff_take_field(v_e_243, 2);
  V v_t_2496;
  switch (heff_tag_of(v_t_2493)) {
  case TAG_ForNominative: {
    v_t_2496 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2493, 0ULL, 2);
    v_t_2496 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2493);
  }
  V v_t_2497 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_t_2498 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
  V v_t_2499 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2498, heff_dup(v_x_2411)));
  V v_t_24104;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_n_24100 = heff_field(v_cod_2421, 0);
    heff_take_n(v_cod_2421, 1ULL, 3);
    v_t_24104 = v_n_24100;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2421, 0ULL, 1);
    v_t_24104 = ((V)&g_heff_2eelab_2erules_2efunctionIntro_24cpr_str2);
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_x_24106 = (g_heff_2eelab_2ememoed_2elam(v_t_2496, heff_get_n(v_e_243, 1, 6), v_t_2497, heff_rec_n(2, shape_stx__val, (V[]){v_t_2499, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam12, 1, 1, (V[]){v_x_2411})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_t_24104, v_x_2492})));
  V f_ = v_k_2491;
  args[0] = v_x_24106;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam10(V self, V *args) {
  V v_hd_2490 = args[0];
  V v_k_2491 = args[1];
  V v_c_2489 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_cod_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2489;
  args[0] = v_hd_2490;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam11, 1, 4, (V[]){v_e_243, v_x_2411, v_cod_2421, v_k_2491});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam8(V self, V *args) {
  V v_v_2462 = args[0];
  V v_scope_27_2463 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_cod_2421 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  V v_implicit_2422 = heff_env(self)[5];
  V v_dom_2420 = heff_env(self)[6];
  V v_x_2411 = heff_env(self)[7];
  heff_clo_take(self, 8);
  HeffT1 v_t_2464 = ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_body_242; HeffT1 r_ = (g_heff_2eelab_2erules_2efunctionIntro_24cpr(a_0, a_1, a_2)); heff_drop(v_body_242); r_; });
  {
    V v_field_2465 = v_t_2464.f[0];
    V v_x1_2471;
    switch (heff_tag_of(v_cod_2421)) {
    case TAG_MkClo: {
      V v_vs_2467 = heff_dup(heff_field(v_cod_2421, 1));
      V v_body_2468 = heff_dup(heff_field(v_cod_2421, 2));
      v_x1_2471 = heff_tr(heff_call(v_body_2468, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2467, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam9, 1, 1, (V[]){heff_dup(v_v_2462)})})}));
      break;
    }
    case TAG_CloConst: {
      V v_body_2470 = heff_dup(heff_field(v_cod_2421, 0));
      v_x1_2471 = v_body_2470;
      break;
    }
    default: heff_nomatch(v_cod_2421);
    }
    V v_a_2475;
    switch (heff_tag_of(v_x1_2471)) {
    case TAG_Nom: {
      V v_x_2472 = heff_field(v_x1_2471, 0);
      heff_take_n(v_x1_2471, 1ULL, 1);
      v_a_2475 = v_x_2472;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2471, 0ULL, 1);
      v_a_2475 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2474 = heff_field(v_x1_2471, 0);
      heff_take_n(v_x1_2471, 1ULL, 1);
      v_a_2475 = v_x_2474;
      break;
    }
    default: heff_nomatch(v_x1_2471);
    }
    V v_f_2476 = v_field_2465;
    V v_t_2477 = heff_dup(heff_rfield(v_e_243, 2));
    V v_t_2480;
    switch (heff_tag_of(v_t_2477)) {
    case TAG_ForNominative: {
      v_t_2480 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_2478 = heff_field(v_t_2477, 0);
      V v_sp_2479 = heff_field(v_t_2477, 1);
      V v_ru_24t_2477_24ForDescriptive = heff_take_reuse_n(v_t_2477, 3ULL, 2);
      v_t_2480 = heff_tag_at_n(v_ru_24t_2477_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2478, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2479, heff_dup(v_v_2462)})});
      break;
    }
    default: heff_nomatch(v_t_2477);
    }
    V v_t_2481 = heff_intAdd(heff_dup(heff_rfield(v_e_243, 3)), MK_INT(1LL));
    V v_t_2487;
    switch (heff_tag_of(v_implicit_2422)) {
    case TAG_Expl: {
      heff_drop(v_v_2462);
      heff_drop(v_dom_2420);
      v_t_2487 = heff_dup(heff_rfield(v_e_243, 5));
      break;
    }
    case TAG_Impl: {
      heff_drop(v_v_2462);
      heff_drop(v_dom_2420);
      v_t_2487 = heff_dup(heff_rfield(v_e_243, 5));
      break;
    }
    case TAG_Inst: {
      V v_t_2486;
      switch (heff_tag_of(v_cod_2421)) {
      case TAG_MkClo: {
        V v_n_2482 = heff_dup(heff_field(v_cod_2421, 0));
        v_t_2486 = v_n_2482;
        break;
      }
      case TAG_CloConst: {
        v_t_2486 = ((V)&g_heff_2eelab_2erules_2efunctionIntro_24cpr_str1);
        break;
      }
      default: heff_nomatch(v_cod_2421);
      }
      v_t_2487 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__ty__v, (V[]){v_t_2486, v_dom_2420, v_v_2462}), heff_dup(heff_rfield(v_e_243, 5))});
      break;
    }
    default: heff_nomatch(v_implicit_2422);
    }
    V v_t_2488 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2463, heff_dup(heff_rfield(v_e_243, 1)), v_t_2480, v_t_2481, heff_dup(heff_rfield(v_e_243, 4)), v_t_2487});
    V v_c_2489 = heff_tr(heff_call(v_f_2476, 2, (V[]){v_t_2488, v_a_2475}));
    return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam10, 2, 4, (V[]){v_c_2489, v_e_243, v_x_2411, v_cod_2421});
  }
}
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  V v_body_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2412 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2411)));
  switch (heff_tag_of(v_t_2412)) {
  case TAG_LikeU: {
    V v_ru_24t_2412_24LikeU = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_msg_2414 = ({ V a_0 = v_x_241; V r_ = (g_heff_2eelab_2erules_2enotFunctionMsg(a_0)); heff_drop(v_x_241); r_; });
    V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), v_msg_2414, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2416 = heff_tag_at_n(v_ru_24t_2412_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2417}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2418;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFunction: {
    V v_dom_2420 = heff_field(v_t_2412, 1);
    V v_cod_2421 = heff_field(v_t_2412, 2);
    V v_implicit_2422 = heff_field(v_t_2412, 3);
    heff_take_n(v_t_2412, 14ULL, 4);
    V v_t_2423;
    switch (heff_tag_of(v_implicit_2422)) {
    case TAG_Expl: {
      v_t_2423 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2423 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2423 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2422);
    }
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_sp_240);
      heff_drop(v_implicit_2422);
      heff_drop(v_t_2423);
      V v_t_2456 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_241), v_dom_2420, heff_dup(heff_rfield(v_e_243, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam3, 2, 5, (V[]){v_cod_2421, v_body_242, v_e_243, v_x_2411, v_x_241})));
      V f_ = v_t_2456;
      heff_room[0] = v_hd_245;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2423);
      V v_t_2461;
      switch (heff_tag_of(v_cod_2421)) {
      case TAG_MkClo: {
        V v_n_2457 = heff_dup(heff_field(v_cod_2421, 0));
        v_t_2461 = v_n_2457;
        break;
      }
      case TAG_CloConst: {
        v_t_2461 = ((V)&g_heff_2eelab_2erules_2efunctionIntro_24cpr_str0);
        break;
      }
      default: heff_nomatch(v_cod_2421);
      }
      V v_t_24107 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(v_t_2461, heff_dup(v_dom_2420), heff_dup(heff_rfield(v_e_243, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam8, 2, 8, (V[]){v_sp_240, v_x_241, v_body_242, v_cod_2421, v_e_243, v_implicit_2422, v_dom_2420, v_x_2411})));
      V f_ = v_t_24107;
      heff_room[0] = v_hd_245;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2412, 0ULL, 3);
    heff_drop(v_x_2411);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_msg_24111 = ({ V a_0 = v_x_241; V r_ = (g_heff_2eelab_2erules_2enotFunctionMsg(a_0)); heff_drop(v_x_241); r_; });
    V v_t_24112 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), v_msg_24111, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24113 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24112})});
    V v_t_24114 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24113})});
    V v_t_24115 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24114}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24115;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2412_24LikeSum = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_msg_24117 = ({ V a_0 = v_x_241; V r_ = (g_heff_2eelab_2erules_2enotFunctionMsg(a_0)); heff_drop(v_x_241); r_; });
    V v_t_24118 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), v_msg_24117, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24119 = heff_tag_at_n(v_ru_24t_2412_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24118})});
    V v_t_24120 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24119})});
    V v_t_24121 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24120}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24121;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2411);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_msg_24122 = ({ V a_0 = v_x_241; V r_ = (g_heff_2eelab_2erules_2enotFunctionMsg(a_0)); heff_drop(v_x_241); r_; });
    V v_t_24123 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), v_msg_24122, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24124 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24123})});
    V v_t_24125 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24124})});
    V v_t_24126 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24125}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24126;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2411);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_msg_24127 = ({ V a_0 = v_x_241; V r_ = (g_heff_2eelab_2erules_2enotFunctionMsg(a_0)); heff_drop(v_x_241); r_; });
    V v_t_24128 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), v_msg_24127, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24129 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24128})});
    V v_t_24130 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24129})});
    V v_t_24131 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24130}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24131;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2411);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_msg_24132 = ({ V a_0 = v_x_241; V r_ = (g_heff_2eelab_2erules_2enotFunctionMsg(a_0)); heff_drop(v_x_241); r_; });
    V v_t_24133 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), v_msg_24132, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24134 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24133})});
    V v_t_24135 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
    V v_t_24136 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24135}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24136;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2411);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_msg_24137 = ({ V a_0 = v_x_241; V r_ = (g_heff_2eelab_2erules_2enotFunctionMsg(a_0)); heff_drop(v_x_241); r_; });
    V v_t_24138 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), v_msg_24137, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24139 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24138})});
    V v_t_24140 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24139})});
    V v_t_24141 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24140}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24141;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2412_24LikeArray = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_msg_24143 = ({ V a_0 = v_x_241; V r_ = (g_heff_2eelab_2erules_2enotFunctionMsg(a_0)); heff_drop(v_x_241); r_; });
    V v_t_24144 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), v_msg_24143, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24145 = heff_tag_at_n(v_ru_24t_2412_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24144})});
    V v_t_24146 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24145})});
    V v_t_24147 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24146}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24147;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2412_24LikeFixed = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_msg_24149 = ({ V a_0 = v_x_241; V r_ = (g_heff_2eelab_2erules_2enotFunctionMsg(a_0)); heff_drop(v_x_241); r_; });
    V v_t_24150 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), v_msg_24149, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24151 = heff_tag_at_n(v_ru_24t_2412_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24150})});
    V v_t_24152 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24151})});
    V v_t_24153 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24152}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24153;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2411);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_msg_24154 = ({ V a_0 = v_x_241; V r_ = (g_heff_2eelab_2erules_2enotFunctionMsg(a_0)); heff_drop(v_x_241); r_; });
    V v_t_24155 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), v_msg_24154, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24156 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24155})});
    V v_t_24157 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24156})});
    V v_t_24158 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24157}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24158;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a0_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam1, 1, 1, (V[]){v_a0_244})})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_249}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_t_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_24cpr_lam2, 1, 6, (V[]){v_x_241, v_sp_240, v_hd_245, v_k_246, v_e_243, v_body_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2erequireAgree_str0, 62, "the binder's annotation is not the argument type expected here");
V g_heff_2eelab_2erules_2erequireAgree_lam0(V self, V *args);
V g_heff_2eelab_2erules_2erequireAgree_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2erequireAgree_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erequireAgree_lam1, 2, 0};
Clo g_heff_2eelab_2erules_2erequireAgree_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erequireAgree_entry, 3, 0};

V g_heff_2eelab_2erules_2erequireAgree(V v_e_240, V v_sp_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Left: {
    V v_err_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_note_244 = ({ V a_0 = heff_get_n(v_e_240, 1, 6); V a_1 = v_err_243; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_243); r_; });
    return heff_clo_n(g_heff_2eelab_2erules_2erequireAgree_lam0, 2, 2, (V[]){v_sp_241, v_note_244});
  }
  case TAG_Right: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    return ((V)&g_heff_2eelab_2erules_2erequireAgree_lam1_clo);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2erequireAgree_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erequireAgree(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2erequireAgree_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k2_246 = args[1];
  V v_sp_241 = heff_env(self)[0];
  V v_note_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erequireAgree_str0), v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_244})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_249}));
  V f_ = heff_get_n(v_hd_245, 1, 3);
  args[0] = v_t_2410;
  args[1] = v_k2_246;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erequireAgree_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2ecoeGoal_str0, 11, "prelude.Coe");
HEFF_LIT(g_heff_2eelab_2erules_2ecoeGoal_str1, 11, "prelude.Coe");
V g_heff_2eelab_2erules_2ecoeGoal_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ecoeGoal_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecoeGoal_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ecoeGoal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecoeGoal_entry, 3, 0};

V g_heff_2eelab_2erules_2ecoeGoal(V v_e_240, V v_from_241, V v_to_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_e_240, 1)), 1, 8);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V b_1 = ((V)&g_heff_2eelab_2erules_2ecoeGoal_str0); HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, b_1)); heff_drop(v_t_243); heff_drop(b_1); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_e_248 = v_field_246;
      V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
      V v_t_2410 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_249, heff_dup(v_from_241)));
      V v_t_2411 = heff_tag_n(TAG_SApp, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){((V)&g_heff_2eelab_2erules_2ecoeGoal_str1)}), heff_tag_n(TAG_SCode, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_get_n(heff_get_n(v_e_240, 0, 6), 0, 4);
      V v_t_2413 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2412, heff_dup(v_to_242)));
      V v_t_2415 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SCode, 1, (V[]){v_t_2413}), heff_clo_n(g_heff_2eelab_2erules_2ecoeGoal_lam0, 1, 1, (V[]){v_to_242})});
      HeffT2 v_t_2426 = (g_heff_2eelab_2ememoed_2eapp_24cpr(heff_rec_n(2, shape_stx__val, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2ecoeGoal_lam1, 1, 2, (V[]){v_e_248, v_from_241})}), v_t_2415));
      V v_t_2438;
      {
        V v_field_2428 = v_t_2426.f[1];
        heff_drop(v_t_2426.f[0]);
        V v_t_2429 = heff_tr(heff_call(v_field_2428, 1, (V[]){NTAG(TAG_MkUnit)}));
        HeffT2 v_t_2430 = ({ V a_0 = v_t_2429; HeffT2 r_ = (g_heff_2eelab_2evalue_2edecodeEv_24cpr(a_0)); heff_drop(v_t_2429); r_; });
        {
          V v_field_2432 = v_t_2430.f[1];
          int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
          if ((v_tag_2431 == ((int64_t)0ULL))) {
            V v_x_2434 = v_field_2432;
            v_t_2438 = v_x_2434;
          } else {
            if ((v_tag_2431 == ((int64_t)1ULL))) {
              V v_x11_2436 = v_field_2432;
              heff_drop(v_x11_2436);
              v_t_2438 = heff_abandon();
            } else {
              V v_x_2437 = v_field_2432;
              v_t_2438 = v_x_2437;
            }
          }
        }
      }
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2438});
    } else {
      heff_drop_rec(v_e_240, 6);
      heff_drop(v_from_241);
      heff_drop(v_to_242);
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2eelab_2erules_2ecoeGoal_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ecoeGoal(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2ecoeGoal_lam0(V self, V *args) {
  V v_u_2414 = args[0];
  V v_to_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2414);
  return (g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263(heff_tag_n(TAG_Nom, 1, (V[]){v_to_242})));
}
V g_heff_2eelab_2erules_2ecoeGoal_lam2(V self, V *args) {
  V v_u2_2417 = args[0];
  V v_from_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_2417);
  HeffT2 v_t_2418 = (g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24cpr(heff_tag_n(TAG_Nom, 1, (V[]){v_from_241})));
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    if ((v_tag_2419 == ((int64_t)0ULL))) {
      V v_x_2422 = v_field_2420;
      return v_x_2422;
    } else {
      if ((v_tag_2419 == ((int64_t)1ULL))) {
        V v_x11_2424 = v_field_2420;
        heff_drop(v_x11_2424);
        return heff_abandon();
      } else {
        V v_x_2425 = v_field_2420;
        return v_x_2425;
      }
    }
  }
}
V g_heff_2eelab_2erules_2ecoeGoal_lam1(V self, V *args) {
  V v_u_2416 = args[0];
  V v_e_248 = heff_env(self)[0];
  V v_from_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2416);
  return (g_heff_2eelab_2evalue_2eapp(heff_get_n(v_e_248, 2, 4), heff_clo_n(g_heff_2eelab_2erules_2ecoeGoal_lam2, 1, 1, (V[]){v_from_241})));
}
HEFF_LIT(g_heff_2eelab_2erules_2enotANumber_str0, 8, "a number");
HEFF_LIT(g_heff_2eelab_2erules_2enotANumber_str1, 7, "a float");
HEFF_LIT(g_heff_2eelab_2erules_2enotANumber_str2, 11, ", which is ");
HEFF_LIT(g_heff_2eelab_2erules_2enotANumber_str3, 22, ", but got the literal ");
HEFF_LIT(g_heff_2eelab_2erules_2enotANumber_str4, 14, "expected type ");
V g_heff_2eelab_2erules_2enotANumber_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enotANumber_lam0(V self, V *args);
V g_heff_2eelab_2erules_2enotANumber_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2enotANumber_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enotANumber_entry, 6, 0};

V g_heff_2eelab_2erules_2enotANumber(V v_sp_240, V v_e_241, V v_a_242, V v_lit_243, V v_p_244, V v_p_245) {
top: ;
  V v_t_2428;
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_247 = heff_dup(heff_field(v_a_242, 0));
    switch (heff_tag_of(v_h_247)) {
    case TAG_HLocal: {
      heff_take_n(v_h_247, 0ULL, 1);
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_247, 0ULL, 1);
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_247, 0ULL, 1);
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2428 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_247);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_242);
  }
  if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
    heff_drop(v_sp_240);
    heff_drop(v_e_241);
    heff_drop_rec(v_p_244, 3);
    heff_drop(v_t_2428);
    V v_t_2432 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2enotANumber_lam0, 1, 1, (V[]){v_a_242})});
    return heff_tail(v_p_245, 1, (V[]){v_t_2432});
  } else {
    heff_drop(v_t_2428);
    return (g_heff_2eelab_2erules_2etyStrZ(v_e_241, v_a_242, heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2enotANumber_lam2, 1, 4, (V[]){heff_dup(v_lit_243), v_sp_240, v_p_244, v_p_245})));
  }
}
V g_heff_2eelab_2erules_2enotANumber_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2enotANumber(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2enotANumber_lam1(V self, V *args) {
  V v_u_2430 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2430);
  return v_a_242;
}
V g_heff_2eelab_2erules_2enotANumber_lam0(V self, V *args) {
  V v_u_2429 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2429);
  V v_t_2431 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(NTAG(TAG_HError), heff_clo_n(g_heff_2eelab_2erules_2enotANumber_lam1, 1, 1, (V[]){v_a_242}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2431});
}
V g_heff_2eelab_2erules_2enotANumber_lam2(V self, V *args) {
  V v_x_2433 = args[0];
  V v_lit_243 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_p_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2436;
  switch (heff_tag_of(v_lit_243)) {
  case TAG_IntNum: {
    V v_i_2434 = heff_dup(heff_field(v_lit_243, 0));
    v_t_2436 = heff_intShow(v_i_2434);
    break;
  }
  case TAG_FracNum: {
    V v_x_2435 = heff_tget_v(v_lit_243, 0);
    v_t_2436 = heff_floatShow(v_x_2435);
    break;
  }
  default: heff_nomatch(v_lit_243);
  }
  V v_t_2439;
  switch (heff_tag_of(v_lit_243)) {
  case TAG_IntNum: {
    heff_take_n(v_lit_243, 0ULL, 1);
    v_t_2439 = ((V)&g_heff_2eelab_2erules_2enotANumber_str0);
    break;
  }
  case TAG_FracNum: {
    heff_take_na(v_lit_243, 0ULL, 1);
    v_t_2439 = ((V)&g_heff_2eelab_2erules_2enotANumber_str1);
    break;
  }
  default: heff_nomatch(v_lit_243);
  }
  V v_t_2440 = heff_strAppend(v_t_2436, heff_strAppend(((V)&g_heff_2eelab_2erules_2enotANumber_str2), v_t_2439));
  V v_t_2441 = heff_strAppend(v_x_2433, heff_strAppend(((V)&g_heff_2eelab_2erules_2enotANumber_str3), v_t_2440));
  V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2enotANumber_str4), v_t_2441), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2444}));
  V f_ = heff_get_n(v_p_244, 1, 3);
  heff_room[0] = v_t_2445;
  heff_room[1] = v_p_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2elargeField_str0, 3, " : ");
HEFF_LIT(g_heff_2eelab_2erules_2elargeField_str1, 3, " : ");
Clo g_heff_2eelab_2erules_2elargeField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elargeField_entry, 4, 0};

V g_heff_2eelab_2erules_2elargeField(V v_e_240, V v_x_241, V v_ty_242, V v_after_243) {
top: ;
  V v_x1_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_ty_242, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x1_248;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Nom: {
    V v_t_245 = heff_field(v_x1_244, 0);
    heff_take_n(v_x1_244, 1ULL, 1);
    v_x1_248 = ({ V a_0 = v_t_245; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_245); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_246 = heff_field(v_x1_244, 0);
    heff_take_n(v_x1_244, 1ULL, 1);
    v_x1_248 = ({ V a_0 = v_t_246; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_246); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_247 = heff_field(v_x1_244, 0);
    heff_take_n(v_x1_244, 1ULL, 1);
    v_x1_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_247); r_; });
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Small: {
    heff_drop(v_e_240);
    heff_drop(v_x_241);
    heff_drop_rec(v_ty_242, 2);
    return v_after_243;
  }
  case TAG_Large: {
    heff_drop(v_after_243);
    V v_t_249 = (g_heff_2eelab_2erules_2etyStrM(v_e_240, v_ty_242));
    V v_t_2410 = heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2eelab_2erules_2elargeField_str0), v_t_249));
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
  }
  case TAG_TopL: {
    heff_drop(v_after_243);
    V v_t_2411 = (g_heff_2eelab_2erules_2etyStrM(v_e_240, v_ty_242));
    V v_t_2412 = heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2eelab_2erules_2elargeField_str1), v_t_2411));
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2412});
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2eelab_2erules_2elargeField_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2elargeField(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2erules_2eentriesGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eentriesGo_24dps_entry, 7, 0};

V g_heff_2eelab_2erules_2eentriesGo_24dps(V v_n_240, V v_k_241, V v_places_242, V v_x4_243, V v_x5_244, V v_i_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_k_241);
    heff_drop(v_places_242);
    heff_drop(v_x5_244);
    heff_drop(v_i_245);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_m_247 = heff_field(v_x4_243, 0);
    V v_rest_248 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nil: {
      heff_drop(v_n_240);
      heff_drop(v_k_241);
      heff_drop(v_places_242);
      heff_drop(v_i_245);
      heff_drop_rec(v_m_247, 5);
      heff_drop(v_rest_248);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_pl_249 = heff_field(v_x5_244, 0);
      V v_pls_2410 = heff_field(v_x5_244, 1);
      V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
      V v_t_2413;
      switch (heff_tag_of(v_pl_249)) {
      case TAG_Nothing: {
        v_t_2413 = heff_tr(g_heff_2eelab_2erules_2ecodeAt(heff_dup(v_n_240), heff_dup(v_k_241), heff_dup(v_places_242), heff_dup(v_m_247), heff_dup(v_i_245)));
        break;
      }
      case TAG_Just: {
        V v_p_2411 = heff_field(v_pl_249, 0);
        V v_ru_24pl_249_24Just = heff_take_reuse_n(v_pl_249, 1ULL, 1);
        V v_t_2412 = heff_intSub(heff_intSub(heff_dup(v_k_241), MK_INT(1LL)), v_p_2411);
        v_t_2413 = heff_tag_at_n(v_ru_24pl_249_24Just, TAG_SLocal, 1, (V[]){v_t_2412});
        break;
      }
      default: heff_nomatch(v_pl_249);
      }
      V v_t_2414 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_m_247, 0, 5), v_t_2413});
      V v_cell_2415 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
      V v_u_2416 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2415));
      heff_drop(v_u_2416);
      V t_0 = v_n_240;
      V t_1 = v_k_241;
      V t_2 = v_places_242;
      V t_3 = v_rest_248;
      V t_4 = v_pls_2410;
      V t_5 = heff_intAdd(v_i_245, MK_INT(1LL));
      V t_6 = v_cell_2415;
      v_n_240 = t_0;
      v_k_241 = t_1;
      v_places_242 = t_2;
      v_x4_243 = t_3;
      v_x5_244 = t_4;
      v_i_245 = t_5;
      v_d_246 = t_6;
      goto top;
    }
    default: return heff_nomatch(v_x5_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2eentriesGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eentriesGo_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str3, 45, "non-exhaustive pattern: no case provided for ");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str4, 4, "tag ");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str5, 45, "non-exhaustive pattern: no case provided for ");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str6, 4, "tag ");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str7, 45, "non-exhaustive pattern: no case provided for ");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str8, 4, "tag ");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str9, 43, "wrong number of arguments provided for tag ");
V g_heff_2eelab_2erules_2ecaseArm_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam6(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam7(V self, V *args);
Clo g_heff_2eelab_2erules_2ecaseArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecaseArm_entry, 7, 0};

V g_heff_2eelab_2erules_2ecaseArm(V v_sp_240, V v_e_241, V v_b_242, V v_a_243, V v_x_244, V v_ts_245, V v_casesChk_246) {
top: ;
  HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_casesChk_246, 1), v_x_244));
  V v_it_2416;
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_i_2411 = v_field_249;
      V v_xs_2412 = heff_dup(heff_rfield(v_casesChk_246, 2));
      if (heff_intLe_c_lent(MK_INT(0LL), v_i_2411, 1)) {
        if (heff_intLt_c(heff_dup(v_i_2411), heff_arrayLength_lent(v_xs_2412, 0))) {
          V v_t_2415 = heff_arrayIndex(v_xs_2412, v_i_2411);
          v_it_2416 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2415});
        } else {
          heff_drop(v_i_2411);
          heff_drop(v_xs_2412);
          v_it_2416 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_i_2411);
        heff_drop(v_xs_2412);
        v_it_2416 = NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_field_249);
      v_it_2416 = NTAG(TAG_Nothing);
    }
  }
  switch (heff_tag_of(v_it_2416)) {
  case TAG_Nothing: {
    HeffT2 v_t_2417 = ({ V a_0 = heff_rfield(v_casesChk_246, 1); V b_1 = ((V)&g_heff_2eelab_2erules_2ecaseArm_str0); HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      if ((v_tag_2418 == ((int64_t)0ULL))) {
        V v_i_2421 = v_field_2419;
        V v_xs_2422 = heff_get_n(v_casesChk_246, 2, 3);
        if (heff_intLe_c_lent(MK_INT(0LL), v_i_2421, 1)) {
          if (heff_intLt_c(heff_dup(v_i_2421), heff_arrayLength_lent(v_xs_2422, 0))) {
            heff_drop(v_sp_240);
            V v_t_2425 = heff_arrayIndex(v_xs_2422, v_i_2421);
            switch (heff_tag_of(v_t_2425)) {
            case TAG_MkPair: {
              V v_bodyChk_2427 = heff_field(v_t_2425, 1);
              heff_take_n(v_t_2425, 2ULL, 2);
              V v_t_2428 = (g_list_2emap_24s258116700x992061112(((V)&g_heff_2eelab_2erules_2ecaseArm_str1), heff_dup(v_ts_245)));
              V v_t_2429 = (g_list_2emap_24s1990719097x1419059608(heff_dup(v_ts_245)));
              V v_sc_2430 = (g_heff_2eelab_2eenvironment_2emultiBind(v_t_2428, v_t_2429, heff_take_field(v_e_241, 0)));
              V v_c_2433;
              switch (heff_tag_of(v_bodyChk_2427)) {
              case TAG_MkChk: {
                V v_f_2431 = heff_field(v_bodyChk_2427, 0);
                heff_take_n(v_bodyChk_2427, 1ULL, 1);
                V v_t_2432 = ({ V rv_0 = v_sc_2430; V rr_ = heff_rec_reuse_nf(v_e_241, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                v_c_2433 = heff_tr(heff_call(v_f_2431, 2, (V[]){v_t_2432, v_b_242}));
                break;
              }
              default: heff_nomatch(v_bodyChk_2427);
              }
              return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam0, 2, 3, (V[]){v_c_2433, v_ts_245, v_x_244});
            }
            default: return heff_nomatch(v_t_2425);
            }
          } else {
            heff_drop_rec(v_e_241, 6);
            heff_drop(v_b_242);
            heff_drop(v_ts_245);
            heff_drop(v_i_2421);
            heff_drop(v_xs_2422);
            return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam2, 2, 2, (V[]){v_x_244, v_sp_240});
          }
        } else {
          heff_drop_rec(v_e_241, 6);
          heff_drop(v_b_242);
          heff_drop(v_ts_245);
          heff_drop(v_i_2421);
          heff_drop(v_xs_2422);
          return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam3, 2, 2, (V[]){v_x_244, v_sp_240});
        }
      } else {
        heff_drop_rec(v_e_241, 6);
        heff_drop(v_b_242);
        heff_drop(v_ts_245);
        heff_drop_rec(v_casesChk_246, 3);
        heff_drop(v_field_2419);
        return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam4, 2, 2, (V[]){v_x_244, v_sp_240});
      }
    }
  }
  case TAG_Just: {
    V v_it1_2461 = heff_field(v_it_2416, 0);
    heff_take_n(v_it_2416, 1ULL, 1);
    heff_drop_rec(v_casesChk_246, 3);
    switch (heff_tag_of(v_it1_2461)) {
    case TAG_MkPair: {
      V v_xs_2462 = heff_field(v_it1_2461, 0);
      V v_bodyChk_2463 = heff_field(v_it1_2461, 1);
      heff_take_n(v_it1_2461, 3ULL, 2);
      V v_t_2464 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_245));
      if (heff_intEq_c(heff_arrayLength_lent(v_xs_2462, 0), v_t_2464)) {
        heff_drop(v_sp_240);
        V v_t_2466 = (g_list_2emap_24s1990719097x1419059608(v_ts_245));
        V v_sc_2467 = (g_heff_2eelab_2eenvironment_2emultiBind(heff_arrayToList(heff_dup(v_xs_2462)), v_t_2466, heff_take_field(v_e_241, 0)));
        V v_c_2470;
        switch (heff_tag_of(v_bodyChk_2463)) {
        case TAG_MkChk: {
          V v_f_2468 = heff_field(v_bodyChk_2463, 0);
          heff_take_n(v_bodyChk_2463, 1ULL, 1);
          V v_t_2469 = ({ V rv_0 = v_sc_2467; V rr_ = heff_rec_reuse_nf(v_e_241, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          v_c_2470 = heff_tr(heff_call(v_f_2468, 2, (V[]){v_t_2469, v_b_242}));
          break;
        }
        default: heff_nomatch(v_bodyChk_2463);
        }
        return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam5, 2, 3, (V[]){v_c_2470, v_xs_2462, v_x_244});
      } else {
        heff_drop_rec(v_e_241, 6);
        heff_drop(v_b_242);
        heff_drop(v_ts_245);
        heff_drop(v_xs_2462);
        heff_drop(v_bodyChk_2463);
        return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam7, 2, 2, (V[]){v_x_244, v_sp_240});
      }
    }
    default: return heff_nomatch(v_it1_2461);
    }
  }
  default: return heff_nomatch(v_it_2416);
  }
}
V g_heff_2eelab_2erules_2ecaseArm_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2ecaseArm(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2ecaseArm_lam1(V self, V *args) {
  V v_x_2436 = args[0];
  V v_ts_245 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_2435 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2437 = (g_list_2emap_24s258116700x992061112(((V)&g_heff_2eelab_2erules_2ecaseArm_str2), v_ts_245));
  V v_t_2438 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_arrayFromList(v_t_2437), heff_get_n(v_x_2436, 0, 2)});
  V v_x_2439 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_244, v_t_2438});
  V f_ = v_k_2435;
  args[0] = v_x_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam0(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_c_2433 = heff_env(self)[0];
  V v_ts_245 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2433;
  args[0] = v_hd_2434;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam1, 1, 3, (V[]){v_ts_245, v_x_244, v_k_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam2(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k2_2441 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2442 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ecaseArm_str3), heff_strAppend(((V)&g_heff_2eelab_2erules_2ecaseArm_str4), v_x_244));
  V v_t_2443 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(317LL), NTAG(TAG_SError), v_t_2442, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tr(heff_call(heff_take_field(v_hd_2440, 2), 1, (V[]){v_t_2445}));
  V f_ = heff_get_n(v_hd_2440, 1, 3);
  args[0] = v_t_2446;
  args[1] = v_k2_2441;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam3(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k2_2448 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2449 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ecaseArm_str5), heff_strAppend(((V)&g_heff_2eelab_2erules_2ecaseArm_str6), v_x_244));
  V v_t_2450 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(317LL), NTAG(TAG_SError), v_t_2449, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tr(heff_call(heff_take_field(v_hd_2447, 2), 1, (V[]){v_t_2452}));
  V f_ = heff_get_n(v_hd_2447, 1, 3);
  args[0] = v_t_2453;
  args[1] = v_k2_2448;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam4(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k2_2455 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2456 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ecaseArm_str7), heff_strAppend(((V)&g_heff_2eelab_2erules_2ecaseArm_str8), v_x_244));
  V v_t_2457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(317LL), NTAG(TAG_SError), v_t_2456, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tr(heff_call(heff_take_field(v_hd_2454, 2), 1, (V[]){v_t_2459}));
  V f_ = heff_get_n(v_hd_2454, 1, 3);
  args[0] = v_t_2460;
  args[1] = v_k2_2455;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam6(V self, V *args) {
  V v_x_2473 = args[0];
  V v_xs_2462 = heff_env(self)[0];
  V v_k_2472 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2474 = heff_tag_n(TAG_MkPair, 2, (V[]){v_xs_2462, heff_get_n(v_x_2473, 0, 2)});
  V f_ = v_k_2472;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_244, v_t_2474});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam5(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k_2472 = args[1];
  V v_c_2470 = heff_env(self)[0];
  V v_xs_2462 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2470;
  args[0] = v_hd_2471;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam6, 1, 3, (V[]){v_xs_2462, v_k_2472, v_x_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam7(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k2_2476 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2477 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(316LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2ecaseArm_str9), v_x_244), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tr(heff_call(heff_take_field(v_hd_2475, 2), 1, (V[]){v_t_2479}));
  V f_ = heff_get_n(v_hd_2475, 1, 3);
  args[0] = v_t_2480;
  args[1] = v_k2_2476;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}

HeffT2 g_heff_2eelab_2erules_2eotherTag_24cpr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      heff_drop(v_y_242);
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_ys_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_y_242}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str0, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str1, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str2, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str3, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str4, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str5, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str6, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str7, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str8, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str9, 136, "the record's shape is not in hand here for the update: annotate the binder, `\\(x : T) -> ...`, or give the implicit argument, `(a := T)`");
V g_heff_2eelab_2erules_2eupdateOf_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam11(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam13(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam14(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam12(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam10(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam17(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam16(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam15(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam20(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam19(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam18(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam23(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam22(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam21(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam26(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam25(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam24(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam29(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam28(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam27(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam32(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam31(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam30(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam35(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam34(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam33(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam38(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam37(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam36(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eupdateOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdateOf_entry, 8, 0};

V g_heff_2eelab_2erules_2eupdateOf(V v_sp_240, V v_r_241, V v_e_242, V v_g_243, V v_a0_244, V v_fs_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam0, 1, 1, (V[]){v_a0_244})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam1, 1, 7, (V[]){v_hd_246, v_k_247, v_sp_240, v_e_242, v_fs_245, v_r_241, v_g_243})});
}
V g_heff_2eelab_2erules_2eupdateOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eupdateOf(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2eupdateOf_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_a0_244; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eupdateOf_lam4(V self, V *args) {
  V v_u_2417 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2417);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam3(V self, V *args) {
  V v_u_2416 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2416);
  V v_t_2418 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(NTAG(TAG_HError), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam4, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2418});
}
V g_heff_2eelab_2erules_2eupdateOf_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2415) == NTAG(TAG_True))) {
    heff_drop(v_x_2415);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_2419 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam3, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_2419;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2415);
    heff_drop(v_x_2412);
    V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2422}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2423;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam7(V self, V *args) {
  V v_u_2430 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2430);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam6(V self, V *args) {
  V v_u_2429 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2429);
  V v_t_2431 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(NTAG(TAG_HError), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam7, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2431});
}
V g_heff_2eelab_2erules_2eupdateOf_lam5(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2428) == NTAG(TAG_True))) {
    heff_drop(v_x_2428);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_2432 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam6, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_2432;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2428);
    heff_drop(v_x_2412);
    V v_t_2433 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str1), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2435}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2436;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam9(V self, V *args) {
  V v_x_2443 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_g_243 = heff_env(self)[3];
  V v_x_2412 = heff_env(self)[4];
  V v_fs_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2erules_2eupdateSetting(((V)&g_heff_2eelab_2erules_2eupdateOf_clo), v_e_242, v_sp_240, v_r_241, v_g_243, v_x_2412, v_fs_245, v_x_2443));
}
V g_heff_2eelab_2erules_2eupdateOf_lam11(V self, V *args) {
  V v_v_2446 = args[0];
  V v_scope_27_2447 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_x_2445 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_v_2446);
  HeffT1 v_t_2448 = (g_heff_2eelab_2erules_2erecordIntro_24cpr(v_sp_240, v_x_2445));
  {
    V v_field_2449 = v_t_2448.f[0];
    V v_f_2450 = v_field_2449;
    V v_t_2451 = ({ V rv_0 = v_scope_27_2447; V rr_ = heff_rec_reuse_nf(v_e_242, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_f_2450;
    args[0] = v_t_2451;
    args[1] = v_x_2412;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam13(V self, V *args) {
  V v_u_2461 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2461);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2eelab_2erules_2eupdateOf_lam14(V self, V *args) {
  V v_u_2465 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2465);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2eelab_2erules_2eupdateOf_lam12(V self, V *args) {
  V v_x_2453 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_g_243 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2454 = heff_take_field(v_e_242, 2);
  V v_t_2457;
  switch (heff_tag_of(v_t_2454)) {
  case TAG_ForNominative: {
    v_t_2457 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2454, 0ULL, 2);
    v_t_2457 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2454);
  }
  V v_t_2458 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 2, 4);
  V v_t_2459 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 0, 4);
  V v_t_2460 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2459, heff_dup(v_x_2412)));
  V v_dom_2462 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2460, heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam13, 1, 1, (V[]){heff_dup(v_x_2412)})});
  V v_t_2463 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 0, 4);
  V v_t_2464 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_t_2463, MK_INT(1LL)), heff_dup(v_x_2412)));
  V v_cod_2466 = heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_r_241), heff_rec_n(2, shape_stx__val, (V[]){v_t_2464, heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam14, 1, 1, (V[]){v_x_2412})})});
  V v_t_2467 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 2, 4);
  V v_t_2468 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_dup(heff_rfield(v_e_242, 1)), v_t_2467, v_dom_2462, v_cod_2466));
  V v_t_2469 = (g_heff_2eelab_2ememoed_2elam(v_t_2457, heff_get_n(v_e_242, 1, 6), v_t_2458, v_t_2468, heff_tag_n(TAG_MkAbs, 2, (V[]){v_r_241, v_x_2453})));
  V v_x_2470 = (g_heff_2eelab_2ememoed_2eapp(v_t_2469, v_g_243));
  V f_ = v_k_247;
  args[0] = v_x_2470;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateOf_lam10(V self, V *args) {
  V v_x_2445 = args[0];
  V v_r_241 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_g_243 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2452 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_r_241), heff_dup(v_x_2412), heff_dup(heff_rfield(v_e_242, 0)), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam11, 2, 4, (V[]){v_sp_240, v_x_2445, heff_dup(v_e_242), heff_dup(v_x_2412)})));
  V f_ = v_c_2452;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam12, 1, 5, (V[]){v_e_242, v_x_2412, v_r_241, v_g_243, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eupdateOf_lam8(V self, V *args) {
  V v_x_2442 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_g_243 = heff_env(self)[3];
  V v_x_2412 = heff_env(self)[4];
  V v_fs_245 = heff_env(self)[5];
  V v_keys_2440 = heff_env(self)[6];
  V v_hd_246 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2442);
  V v_c_2444 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam9, 1, 6, (V[]){heff_dup(v_e_242), heff_dup(v_sp_240), heff_dup(v_r_241), heff_dup(v_g_243), heff_dup(v_x_2412), v_fs_245}), v_keys_2440));
  V f_ = v_c_2444;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam10, 1, 7, (V[]){v_r_241, v_x_2412, v_e_242, v_sp_240, v_hd_246, v_g_243, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eupdateOf_lam17(V self, V *args) {
  V v_u_2474 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2474);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam16(V self, V *args) {
  V v_u_2473 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2473);
  V v_t_2475 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(NTAG(TAG_HError), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam17, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2475});
}
V g_heff_2eelab_2erules_2eupdateOf_lam15(V self, V *args) {
  V v_x_2472 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2472) == NTAG(TAG_True))) {
    heff_drop(v_x_2472);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_2476 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam16, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_2476;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2472);
    heff_drop(v_x_2412);
    V v_t_2477 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str2), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2479}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2480;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam20(V self, V *args) {
  V v_u_2483 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2483);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam19(V self, V *args) {
  V v_u_2482 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2482);
  V v_t_2484 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(NTAG(TAG_HError), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam20, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2484});
}
V g_heff_2eelab_2erules_2eupdateOf_lam18(V self, V *args) {
  V v_x_2481 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2481) == NTAG(TAG_True))) {
    heff_drop(v_x_2481);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_2485 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam19, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_2485;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2481);
    heff_drop(v_x_2412);
    V v_t_2486 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str3), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2486})});
    V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
    V v_t_2489 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2488}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2489;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam23(V self, V *args) {
  V v_u_2492 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2492);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam22(V self, V *args) {
  V v_u_2491 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2491);
  V v_t_2493 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(NTAG(TAG_HError), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam23, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2493});
}
V g_heff_2eelab_2erules_2eupdateOf_lam21(V self, V *args) {
  V v_x_2490 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2490) == NTAG(TAG_True))) {
    heff_drop(v_x_2490);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_2494 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam22, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_2494;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2490);
    heff_drop(v_x_2412);
    V v_t_2495 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2496 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2495})});
    V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
    V v_t_2498 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2497}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2498;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam26(V self, V *args) {
  V v_u_24101 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24101);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam25(V self, V *args) {
  V v_u_24100 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24100);
  V v_t_24102 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(NTAG(TAG_HError), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam26, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24102});
}
V g_heff_2eelab_2erules_2eupdateOf_lam24(V self, V *args) {
  V v_x_2499 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2499) == NTAG(TAG_True))) {
    heff_drop(v_x_2499);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_24103 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam25, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_24103;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2499);
    heff_drop(v_x_2412);
    V v_t_24104 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24105 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24104})});
    V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
    V v_t_24107 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24106}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24107;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam29(V self, V *args) {
  V v_u_24110 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24110);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam28(V self, V *args) {
  V v_u_24109 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24109);
  V v_t_24111 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(NTAG(TAG_HError), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam29, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24111});
}
V g_heff_2eelab_2erules_2eupdateOf_lam27(V self, V *args) {
  V v_x_24108 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_24108) == NTAG(TAG_True))) {
    heff_drop(v_x_24108);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_24112 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam28, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_24112;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24108);
    heff_drop(v_x_2412);
    V v_t_24113 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24114 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24113})});
    V v_t_24115 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24114})});
    V v_t_24116 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24115}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24116;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam32(V self, V *args) {
  V v_u_24120 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24120);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam31(V self, V *args) {
  V v_u_24119 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24119);
  V v_t_24121 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(NTAG(TAG_HError), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam32, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24121});
}
V g_heff_2eelab_2erules_2eupdateOf_lam30(V self, V *args) {
  V v_x_24118 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_24118) == NTAG(TAG_True))) {
    heff_drop(v_x_24118);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_24122 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam31, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_24122;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24118);
    heff_drop(v_x_2412);
    V v_t_24123 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24124 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24123})});
    V v_t_24125 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24124})});
    V v_t_24126 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24125}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24126;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam35(V self, V *args) {
  V v_u_24130 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24130);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam34(V self, V *args) {
  V v_u_24129 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24129);
  V v_t_24131 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(NTAG(TAG_HError), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam35, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24131});
}
V g_heff_2eelab_2erules_2eupdateOf_lam33(V self, V *args) {
  V v_x_24128 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_24128) == NTAG(TAG_True))) {
    heff_drop(v_x_24128);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_24132 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam34, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_24132;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24128);
    heff_drop(v_x_2412);
    V v_t_24133 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24134 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24133})});
    V v_t_24135 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
    V v_t_24136 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24135}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24136;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam38(V self, V *args) {
  V v_u_24139 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24139);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam37(V self, V *args) {
  V v_u_24138 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24138);
  V v_t_24140 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(NTAG(TAG_HError), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam38, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24140});
}
V g_heff_2eelab_2erules_2eupdateOf_lam36(V self, V *args) {
  V v_x_24137 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_24137) == NTAG(TAG_True))) {
    heff_drop(v_x_24137);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_24141 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam37, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_24141;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24137);
    heff_drop(v_x_2412);
    V v_t_24142 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(332LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24143 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24142})});
    V v_t_24144 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24143})});
    V v_t_24145 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24144}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24145;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_e_242 = heff_env(self)[3];
  V v_fs_245 = heff_env(self)[4];
  V v_r_241 = heff_env(self)[5];
  V v_g_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam2, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2413, 0ULL, 4);
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam5, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeRecord: {
    V v_fieldTypes_2439 = heff_field(v_t_2413, 2);
    heff_take_n(v_t_2413, 4ULL, 3);
    V v_keys_2440 = heff_arrayToList(heff_get_n(v_fieldTypes_2439, 0, 3));
    V v_c_2441 = (g_heff_2eelab_2erules_2enoSuchSetting(heff_dup(v_e_242), heff_dup(v_x_2412), v_keys_2440, v_fs_245));
    V f_ = v_c_2441;
    heff_room[0] = heff_dup(v_hd_246);
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam8, 1, 9, (V[]){v_e_242, v_sp_240, v_r_241, v_g_243, v_x_2412, v_fs_245, v_keys_2440, v_hd_246, v_k_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam15, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeInt: {
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam18, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeFloat: {
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam21, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeString: {
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam24, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeRune: {
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam27, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam30, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam33, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_NoRules: {
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam36, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  default: return heff_nomatch(v_t_2413);
  }
}

HeffT2 g_heff_2eelab_2erules_2eindexOfName_24cpr(V v_x1_240, V v_x_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x1_240, 0);
    V v_ys_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_y_243, v_x_241, 1)) {
      heff_drop(v_ys_244);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_242}});
    } else {
      V t_0 = v_ys_244;
      V t_1 = v_x_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_x1_240 = t_0;
      v_x_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eplacesSaid_24acc_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eplacesSaid_24acc_str1, 6, ", and ");
HEFF_LIT(g_heff_2eelab_2erules_2eplacesSaid_24acc_str2, 2, ", ");
Clo g_heff_2eelab_2erules_2eplacesSaid_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eplacesSaid_24acc_entry, 2, 0};

V g_heff_2eelab_2erules_2eplacesSaid_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_heff_2eelab_2erules_2eplacesSaid_24acc_str0));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      return heff_strAppend(v_acc_241, heff_dup(v_x_242));
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x12_243, 0);
      V v_x122_245 = heff_field(v_x12_243, 1);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        V v_t_246 = heff_strAppend(heff_dup(v_x_242), heff_strAppend(((V)&g_heff_2eelab_2erules_2eplacesSaid_24acc_str1), heff_dup(v_y_244)));
        return heff_strAppend(v_acc_241, v_t_246);
      }
      case TAG_Cons: {
        V v_s_249 = heff_strAppend(v_acc_241, heff_dup(v_x_242));
        V v_s_2410 = heff_strAppend(v_s_249, ((V)&g_heff_2eelab_2erules_2eplacesSaid_24acc_str2));
        V t_0 = v_x12_243;
        V t_1 = v_s_2410;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eplacesSaid_24acc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eplacesSaid_24acc(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2efindPrim_24cpr_str0, 17, "no such variable ");
HEFF_LIT(g_heff_2eelab_2erules_2efindPrim_24cpr_str1, 9, " in scope");
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2efindPrim_24cpr(V v_sp_240, V v_p_241) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2efindPrim_24cpr_lam0, 1, 2, (V[]){v_p_241, v_sp_240})}});
}
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam2(V self, V *args) {
  V v_mc_2411 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_e_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_e_242; V a_1 = v_mc_2411; V a_2 = heff_get_n(v_e_248, 3, 4); V r_ = (g_heff_2eelab_2erules_2etyStrIn(a_0, a_1, a_2)); heff_drop(v_mc_2411); r_; });
}
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam4(V self, V *args) {
  V v_u_2416 = args[0];
  V v_e_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2416);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_e_248, 2, 4)});
}
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_e_248 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2415);
  V v_t_2417 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_p_241}), heff_clo_n(g_heff_2eelab_2erules_2efindPrim_24cpr_lam4, 1, 1, (V[]){heff_dup(v_e_248)})});
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, heff_get_n(v_e_248, 3, 4)});
  V f_ = v_k_2410;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_e_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_sp_240, heff_dup(v_p_241), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_p_241)}), NTAG(TAG_False), heff_clo_n(g_heff_2eelab_2erules_2efindPrim_24cpr_lam2, 1, 2, (V[]){v_e_242, heff_dup(v_e_248)})});
  V v_t_2413 = heff_tag_n(TAG_Record, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})}));
  V f_ = heff_get_n(v_hd_249, 1, 3);
  args[0] = v_t_2414;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efindPrim_24cpr_lam3, 1, 3, (V[]){v_p_241, v_e_248, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam5(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k2_2420 = args[1];
  V v_p_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efindPrim_24cpr_str0), heff_strAppend(v_p_241, ((V)&g_heff_2eelab_2erules_2efindPrim_24cpr_str1)));
  V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(308LL), NTAG(TAG_SError), v_t_2421, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_call(heff_take_field(v_hd_2419, 2), 1, (V[]){v_t_2424}));
  V f_ = heff_get_n(v_hd_2419, 1, 3);
  args[0] = v_t_2425;
  args[1] = v_k2_2420;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_e_242, 1)), 1, 8);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_p_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_e_248 = v_field_246;
      return heff_clo_n(g_heff_2eelab_2erules_2efindPrim_24cpr_lam1, 2, 4, (V[]){v_sp_240, v_p_241, v_e_242, v_e_248});
    } else {
      heff_drop_rec(v_e_242, 6);
      heff_drop(v_field_246);
      return heff_clo_n(g_heff_2eelab_2erules_2efindPrim_24cpr_lam5, 2, 2, (V[]){v_p_241, v_sp_240});
    }
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2elazyOf_24cpr_str0, 12, "builtin.Lazy");

HeffT2 g_heff_2eelab_2erules_2elazyOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VU: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VDecode: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_HLocal: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_HGlobal: {
      V v_k_248 = heff_field(v_x11_242, 0);
      switch (heff_tag_of(v_x12_243)) {
      case TAG_SpId: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SpApp: {
        V v_x121_249 = heff_field(v_x12_243, 0);
        V v_x_2410 = heff_field(v_x12_243, 1);
        switch (heff_tag_of(v_x121_249)) {
        case TAG_SpId: {
          if (heff_strEq_c_lent(v_k_248, ((V)&g_heff_2eelab_2erules_2elazyOf_24cpr_str0), 2)) {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_2410)}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_SpApp: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SpProj: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SpSpec: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x121_249)}});
        }
      }
      case TAG_SpProj: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SpSpec: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x12_243)}});
      }
    }
    case TAG_HMeta: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_HError: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  case TAG_VFunction: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VRecord: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VSum: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimString: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimRune: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimArray: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFixed: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}