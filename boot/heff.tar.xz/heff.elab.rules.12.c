// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_Catch 6517
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_LikeRecord 38505
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Record 39342
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SError 24172
#define TAG_SGlobal 8650
#define TAG_SLocal 28569
#define TAG_SaveDelayed 42463
#define TAG_SpId 35501
#define TAG_Throw 56084
#define TAG_VCode 11305
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_elabFor 712452832
#define LBL_entries 787768015
#define LBL_globals 352931696
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_matched 1072719718
#define LBL_member 869372357
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ret 322331
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_tags 10047712
#define LBL_ty 10476
#define LBL_type_5f 312202367
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2eenvironment_2eargPartsFrom(V, V, V, V, V, V);
V g_heff_2eelab_2eenvironment_2eargPartsFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2eargPartsFrom_clo;
HeffT2 g_heff_2eelab_2eenvironment_2ematchedTagsAt_24cpr(V, V);
V g_heff_2eelab_2eenvironment_2ematchedTo(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ematchedTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ematchedTo_clo;
V g_heff_2eelab_2eenvironment_2emultiBind(V, V, V);
V g_heff_2eelab_2eenvironment_2emultiBind_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2emultiBind_clo;
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2ememoed_2eapp(V, V);
V g_heff_2eelab_2ememoed_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eapp_clo;
HeffT2 g_heff_2eelab_2ememoed_2eapp_24cpr(V, V);
V g_heff_2eelab_2ememoed_2efunctionD(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2efunctionD_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2efunctionD_clo;
V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erules_2ecaseArm(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecaseArm_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseArm_clo;
V g_heff_2eelab_2erules_2echeckSetting_24generate0(V, V, V);
V g_heff_2eelab_2erules_2echeckSetting_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckSetting_24generate0_clo;
V g_heff_2eelab_2erules_2ecodeAt(V, V, V, V, V);
V g_heff_2eelab_2erules_2ecodeAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecodeAt_clo;
V g_heff_2eelab_2erules_2ecoeGoal(V, V, V);
V g_heff_2eelab_2erules_2ecoeGoal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecoeGoal_clo;
V g_heff_2eelab_2erules_2edefaultCopy(V, V, V);
V g_heff_2eelab_2erules_2edefaultCopy_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaultCopy_clo;
V g_heff_2eelab_2erules_2eentriesGo_24dps(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eentriesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eentriesGo_24dps_clo;
HeffT1 g_heff_2eelab_2erules_2efindPrim_24cpr(V, V);
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
HeffT1 g_heff_2eelab_2erules_2eimplicitLams_24cpr(V);
V g_heff_2eelab_2erules_2einOrder_24dps(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einOrder_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einOrder_24dps_clo;
HeffT2 g_heff_2eelab_2erules_2eindexOfName_24cpr(V, V, V);
V g_heff_2eelab_2erules_2ekeepRecovered(V, V, V, V, V);
V g_heff_2eelab_2erules_2ekeepRecovered_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ekeepRecovered_clo;
V g_heff_2eelab_2erules_2enoSuchSetting(V, V, V, V);
V g_heff_2eelab_2erules_2enoSuchSetting_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enoSuchSetting_clo;
HeffT2 g_heff_2eelab_2erules_2eotherTag_24cpr(V, V);
HeffT1 g_heff_2eelab_2erules_2erecordIntro_24cpr(V, V);
HeffT1 g_heff_2eelab_2erules_2erecovering_24cpr(V);
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471(V, V, V, V, V);
V g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471_clo;
V g_heff_2eelab_2erules_2estandsFor_get(void);
V g_heff_2eelab_2erules_2etyStrIn(V, V, V);
V g_heff_2eelab_2erules_2etyStrIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrIn_clo;
V g_heff_2eelab_2erules_2eupdateOf(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdateOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdateOf_clo;
V g_heff_2eelab_2erules_2eupdateSetting(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdateSetting_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdateSetting_clo;
V g_heff_2eelab_2erules_2ewrittenAt(V, V);
V g_heff_2eelab_2erules_2ewrittenAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ewrittenAt_clo;
HeffT2 g_heff_2eelab_2erules_2ewrittenAt_24cpr(V, V);
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
HeffT2 g_heff_2eelab_2evalue_2edecodeEv_24cpr(V);
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1990719097x1419059608(V);
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_clo;
V g_list_2emap_24s258116700x992061112(V, V);
V g_list_2emap_24s258116700x992061112_entry(V self, V *a);
extern Clo g_list_2emap_24s258116700x992061112_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_heff_2eelab_2erules_2erecovering_24cpr_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2erecovering_24cpr_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecovering_24cpr_lam1, 1, 0};
V g_heff_2eelab_2erules_2erecovering_24cpr_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2erecovering_24cpr_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecovering_24cpr_lam3, 1, 0};
V g_heff_2eelab_2erules_2erecovering_24cpr_lam9(V self, V *args);
V g_heff_2eelab_2erules_2erecovering_24cpr_lam8(V self, V *args);
V g_heff_2eelab_2erules_2erecovering_24cpr_lam7(V self, V *args);
V g_heff_2eelab_2erules_2erecovering_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2erules_2erecovering_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2erecovering_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2erules_2erecovering_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecovering_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2erecovering_24cpr(V v_c_240) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2erecovering_24cpr_lam0, 4, 1, (V[]){heff_dup(v_c_240)})}});
}
V g_heff_2eelab_2erules_2erecovering_24cpr_lam1(V self, V *args) {
  V v_c0_245 = args[0];
  return v_c0_245;
}
V g_heff_2eelab_2erules_2erecovering_24cpr_lam3(V self, V *args) {
  V v_sv_2410 = args[0];
  return v_sv_2410;
}
V g_heff_2eelab_2erules_2erecovering_24cpr_lam9(V self, V *args) {
  V v_u_2429 = args[0];
  V v_a_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2429);
  return v_a_2419;
}
V g_heff_2eelab_2erules_2erecovering_24cpr_lam8(V self, V *args) {
  V v_u_2428 = args[0];
  V v_a_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2428);
  V v_t_2430 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2erecovering_24cpr_lam9, 1, 1, (V[]){v_a_2419}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2430});
}
V g_heff_2eelab_2erules_2erecovering_24cpr_lam7(V self, V *args) {
  V v_x_2427 = args[0];
  V v_a_2419 = heff_env(self)[0];
  V v_k_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  V v_t_2431 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2erecovering_24cpr_lam8, 1, 1, (V[]){v_a_2419})});
  V f_ = v_k_2424;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecovering_24cpr_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_d_2420 = heff_env(self)[0];
  V v_saved_2421 = heff_env(self)[1];
  V v_waiting_2422 = heff_env(self)[2];
  V v_hd_2423 = heff_env(self)[3];
  V v_a_2419 = heff_env(self)[4];
  V v_k_2424 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2426;
  if ((heff_dup(v_x_2425) == NTAG(TAG_True))) {
    heff_drop(v_x_2425);
    v_t_2426 = ({ V rv_0 = MK_INT(-1LL); V rr_ = heff_rec_reuse_nf(v_d_2420, 30ULL, 5, shape_code__severity__msg__span__note, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  } else {
    heff_drop(v_x_2425);
    v_t_2426 = v_d_2420;
  }
  return (g_heff_2eelab_2erules_2ekeepRecovered(v_t_2426, v_saved_2421, v_waiting_2422, v_hd_2423, heff_clo_n(g_heff_2eelab_2erules_2erecovering_24cpr_lam7, 1, 2, (V[]){v_a_2419, v_k_2424})));
}
V g_heff_2eelab_2erules_2erecovering_24cpr_lam5(V self, V *args) {
  V v_s_2417 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_a_242 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_e_2418 = v_e_241;
  heff_drop(v_e_2418);
  V v_a_2419 = v_a_242;
  V v_d_2420 = v_s_2417;
  V v_saved_2421 = v_x_249;
  V v_waiting_2422 = v_x_2413;
  V v_hd_2423 = heff_dup(v_hd_243);
  V v_k_2424 = heff_get_n(v_hd_243, 0, 3);
  return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_2419), heff_dup(v_hd_2423), heff_clo_n(g_heff_2eelab_2erules_2erecovering_24cpr_lam6, 1, 6, (V[]){v_d_2420, v_saved_2421, v_waiting_2422, v_hd_2423, v_a_2419, v_k_2424})));
}
V g_heff_2eelab_2erules_2erecovering_24cpr_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_x_249 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_m_2415;
  switch (heff_tag_of(v_c_240)) {
  case TAG_MkChk: {
    V v_f_2414 = heff_field(v_c_240, 0);
    heff_take_n(v_c_240, 1ULL, 1);
    v_m_2415 = heff_tr(heff_call(v_f_2414, 2, (V[]){heff_dup(v_e_241), heff_dup(v_a_242)}));
    break;
  }
  default: heff_nomatch(v_c_240);
  }
  V v_t_2416 = heff_tr(heff_call(v_m_2415, 2, (V[]){heff_dup(v_hd_243), heff_dup(heff_rfield(v_hd_243, 0))}));
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2416, heff_clo_n(g_heff_2eelab_2erules_2erecovering_24cpr_lam5, 1, 5, (V[]){v_e_241, v_a_242, v_x_249, v_x_2413, heff_dup(v_hd_243)})})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tr(heff_call(heff_take_field(v_hd_243, 2), 1, (V[]){v_t_2433}));
  V f_ = heff_get_n(v_hd_243, 1, 3);
  heff_room[0] = v_t_2434;
  heff_room[1] = v_k_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2erecovering_24cpr_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_SaveDelayed, 1, (V[]){((V)&g_heff_2eelab_2erules_2erecovering_24cpr_lam3_clo)})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2erecovering_24cpr_lam4, 1, 6, (V[]){v_c_240, v_e_241, v_a_242, v_hd_243, v_x_249, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2erecovering_24cpr_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_242 = args[1];
  V v_hd_243 = args[2];
  V v_k_244 = args[3];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2erecovering_24cpr_lam1_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_t_248;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecovering_24cpr_lam2, 1, 5, (V[]){v_hd_243, v_c_240, v_e_241, v_a_242, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2echeckSetting_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckSetting_24generate0_entry, 3, 0};

V g_heff_2eelab_2erules_2echeckSetting_24generate0(V v_xs_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if (((((int64_t)0ULL) <= v_i_241) && (heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_e_243 = heff_arrayPeekIn(v_xs_240, heff_box_word(v_i_241));
      V v_t_247;
      switch (heff_tag_of(v_e_243)) {
      case TAG_Nom: {
        V v_x_244 = heff_field(v_e_243, 0);
        v_t_247 = heff_dup(v_x_244);
        break;
      }
      case TAG_Describe: {
        v_t_247 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_246 = heff_field(v_e_243, 0);
        v_t_247 = heff_dup(v_x_246);
        break;
      }
      default: heff_nomatch(v_e_243);
      }
      V t_0 = v_xs_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), v_t_247);
      v_xs_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_e_243 = heff_arrayPeek(v_xs_240, heff_box_word(v_i_241));
    V v_t_247;
    switch (heff_tag_of(v_e_243)) {
    case TAG_Nom: {
      V v_x_244 = heff_field(v_e_243, 0);
      v_t_247 = heff_dup(v_x_244);
      break;
    }
    case TAG_Describe: {
      v_t_247 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_246 = heff_field(v_e_243, 0);
      v_t_247 = heff_dup(v_x_246);
      break;
    }
    default: heff_nomatch(v_e_243);
    }
    V t_0 = v_xs_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), v_t_247);
    v_xs_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2erules_2echeckSetting_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2echeckSetting_24generate0(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2erules_2eimplicitLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitLams_entry, 1, 0};

V g_heff_2eelab_2erules_2eimplicitLams(V v_c_240) {
top: ;
  HeffT1 v_t_241 = (g_heff_2eelab_2erules_2eimplicitLams_24cpr(v_c_240));
  {
    V v_field_242 = v_t_241.f[0];
    return heff_tag_n(TAG_MkChk, 1, (V[]){v_field_242});
  }
}
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eimplicitLams(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2ecoeGoal_str0, 11, "prelude.Coe");
HEFF_LIT(g_heff_2eelab_2erules_2ecoeGoal_str1, 11, "prelude.Coe");
V g_heff_2eelab_2erules_2ecoeGoal_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ecoeGoal_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ecoeGoal_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ecoeGoal_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2ecoeGoal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecoeGoal_entry, 3, 0};

V g_heff_2eelab_2erules_2ecoeGoal(V v_e_240, V v_from_241, V v_to_242) {
top: ;
  V v_globals_243 = heff_take_field(v_e_240, 1);
  V v_scope_244 = heff_get_n(v_e_240, 0, 6);
  HeffT2 v_t_245 = ({ V b_0 = heff_get_n(v_globals_243, 1, 8); V b_1 = ((V)&g_heff_2eelab_2erules_2ecoeGoal_str0); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_e_248 = v_field_247;
      V v_key_249 = ((V)&g_heff_2eelab_2erules_2ecoeGoal_str1);
      V v_ge_2410 = v_e_248;
      V v_t_2411 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_dup(heff_rfield(v_scope_244, 0)), heff_dup(v_from_241)));
      V v_g1_2433 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SCode, 1, (V[]){v_t_2411}), heff_clo_n(g_heff_2eelab_2erules_2ecoeGoal_lam0, 1, 1, (V[]){v_from_241})});
      V v_stx_2434 = heff_take_field(v_g1_2433, 0);
      V v_val_2435 = heff_get_n(v_g1_2433, 1, 2);
      V v_t_2436 = heff_tag_n(TAG_SApp, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_key_249}), v_stx_2434});
      V v_t_2437 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_get_n(v_scope_244, 0, 5), heff_dup(v_to_242)));
      V v_t_2459 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SCode, 1, (V[]){v_t_2437}), heff_clo_n(g_heff_2eelab_2erules_2ecoeGoal_lam1, 1, 1, (V[]){v_to_242})});
      HeffT2 v_t_2466 = (g_heff_2eelab_2ememoed_2eapp_24cpr(heff_rec_n(2, shape_stx__val, (V[]){v_t_2436, heff_clo_n(g_heff_2eelab_2erules_2ecoeGoal_lam2, 1, 2, (V[]){v_ge_2410, v_val_2435})}), v_t_2459));
      V v_t_2476;
      {
        V v_field_2468 = v_t_2466.f[1];
        heff_drop(v_t_2466.f[0]);
        V v_t_2469 = heff_tr(heff_call(v_field_2468, 1, (V[]){NTAG(TAG_MkUnit)}));
        HeffT2 v_t_2470 = ({ V a_0 = v_t_2469; HeffT2 r_ = (g_heff_2eelab_2evalue_2edecodeEv_24cpr(a_0)); heff_drop(v_t_2469); r_; });
        {
          V v_field_2472 = v_t_2470.f[1];
          int64_t v_tag_2471 = ((int64_t)v_t_2470.f[0]);
          if ((v_tag_2471 == ((int64_t)0ULL))) {
            V v_x_2473 = v_field_2472;
            v_t_2476 = v_x_2473;
          } else {
            if ((v_tag_2471 == ((int64_t)1ULL))) {
              V v_x11_2474 = v_field_2472;
              heff_drop(v_x11_2474);
              v_t_2476 = heff_abandon();
            } else {
              V v_x_2475 = v_field_2472;
              v_t_2476 = v_x_2475;
            }
          }
        }
      }
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2476});
    } else {
      heff_drop(v_from_241);
      heff_drop(v_to_242);
      heff_drop_rec(v_scope_244, 5);
      heff_drop(v_field_247);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2eelab_2erules_2ecoeGoal_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ecoeGoal(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2ecoeGoal_lam0(V self, V *args) {
  V v_u_2412 = args[0];
  V v_from_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2412);
  V v_t_2432;
  switch (heff_tag_of(v_from_241)) {
  case TAG_VU: {
    v_t_2432 = heff_tag_n(TAG_VCode, 1, (V[]){v_from_241});
    break;
  }
  case TAG_VDecode: {
    V v_a_2418 = heff_field(v_from_241, 4);
    heff_take_n(v_from_241, 16ULL, 5);
    v_t_2432 = heff_tr(heff_call(v_a_2418, 1, (V[]){NTAG(TAG_MkUnit)}));
    break;
  }
  case TAG_VFunction: {
    v_t_2432 = heff_tag_n(TAG_VCode, 1, (V[]){v_from_241});
    break;
  }
  case TAG_VRecord: {
    v_t_2432 = heff_tag_n(TAG_VCode, 1, (V[]){v_from_241});
    break;
  }
  case TAG_VSum: {
    v_t_2432 = heff_tag_n(TAG_VCode, 1, (V[]){v_from_241});
    break;
  }
  case TAG_VPrimInt: {
    v_t_2432 = heff_tag_n(TAG_VCode, 1, (V[]){v_from_241});
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2432 = heff_tag_n(TAG_VCode, 1, (V[]){v_from_241});
    break;
  }
  case TAG_VPrimString: {
    v_t_2432 = heff_tag_n(TAG_VCode, 1, (V[]){v_from_241});
    break;
  }
  case TAG_VPrimRune: {
    v_t_2432 = heff_tag_n(TAG_VCode, 1, (V[]){v_from_241});
    break;
  }
  case TAG_VPrimArray: {
    v_t_2432 = heff_tag_n(TAG_VCode, 1, (V[]){v_from_241});
    break;
  }
  case TAG_VFixed: {
    v_t_2432 = heff_tag_n(TAG_VCode, 1, (V[]){v_from_241});
    break;
  }
  default: heff_nomatch(v_from_241);
  }
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2432});
}
V g_heff_2eelab_2erules_2ecoeGoal_lam1(V self, V *args) {
  V v_u_2438 = args[0];
  V v_to_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2438);
  V v_t_2458;
  switch (heff_tag_of(v_to_242)) {
  case TAG_VU: {
    v_t_2458 = heff_tag_n(TAG_VCode, 1, (V[]){v_to_242});
    break;
  }
  case TAG_VDecode: {
    V v_a_2444 = heff_field(v_to_242, 4);
    heff_take_n(v_to_242, 16ULL, 5);
    v_t_2458 = heff_tr(heff_call(v_a_2444, 1, (V[]){NTAG(TAG_MkUnit)}));
    break;
  }
  case TAG_VFunction: {
    v_t_2458 = heff_tag_n(TAG_VCode, 1, (V[]){v_to_242});
    break;
  }
  case TAG_VRecord: {
    v_t_2458 = heff_tag_n(TAG_VCode, 1, (V[]){v_to_242});
    break;
  }
  case TAG_VSum: {
    v_t_2458 = heff_tag_n(TAG_VCode, 1, (V[]){v_to_242});
    break;
  }
  case TAG_VPrimInt: {
    v_t_2458 = heff_tag_n(TAG_VCode, 1, (V[]){v_to_242});
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2458 = heff_tag_n(TAG_VCode, 1, (V[]){v_to_242});
    break;
  }
  case TAG_VPrimString: {
    v_t_2458 = heff_tag_n(TAG_VCode, 1, (V[]){v_to_242});
    break;
  }
  case TAG_VPrimRune: {
    v_t_2458 = heff_tag_n(TAG_VCode, 1, (V[]){v_to_242});
    break;
  }
  case TAG_VPrimArray: {
    v_t_2458 = heff_tag_n(TAG_VCode, 1, (V[]){v_to_242});
    break;
  }
  case TAG_VFixed: {
    v_t_2458 = heff_tag_n(TAG_VCode, 1, (V[]){v_to_242});
    break;
  }
  default: heff_nomatch(v_to_242);
  }
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2458});
}
V g_heff_2eelab_2erules_2ecoeGoal_lam3(V self, V *args) {
  V v_u2_2461 = args[0];
  V v_val_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_2461);
  V v_x1_2462 = heff_tr(heff_call(v_val_2435, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2462)) {
  case TAG_Nom: {
    V v_x_2463 = heff_field(v_x1_2462, 0);
    heff_take_n(v_x1_2462, 1ULL, 1);
    return v_x_2463;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2462, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2465 = heff_field(v_x1_2462, 0);
    heff_take_n(v_x1_2462, 1ULL, 1);
    return v_x_2465;
  }
  default: return heff_nomatch(v_x1_2462);
  }
}
V g_heff_2eelab_2erules_2ecoeGoal_lam2(V self, V *args) {
  V v_u_2460 = args[0];
  V v_ge_2410 = heff_env(self)[0];
  V v_val_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2460);
  return (g_heff_2eelab_2evalue_2eapp(heff_get_n(v_ge_2410, 2, 4), heff_clo_n(g_heff_2eelab_2erules_2ecoeGoal_lam3, 1, 1, (V[]){v_val_2435})));
}
Clo g_heff_2eelab_2erules_2eentriesGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eentriesGo_24dps_entry, 7, 0};

V g_heff_2eelab_2erules_2eentriesGo_24dps(V v_n_240, V v_k_241, V v_places_242, V v_x4_243, V v_x5_244, V v_i_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_k_241);
    heff_drop(v_places_242);
    heff_drop(v_x5_244);
    heff_drop(v_i_245);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_m_247 = heff_field(v_x4_243, 0);
    V v_rest_248 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nil: {
      heff_drop(v_n_240);
      heff_drop(v_k_241);
      heff_drop(v_places_242);
      heff_drop(v_i_245);
      heff_drop_rec(v_m_247, 5);
      heff_drop(v_rest_248);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_pl_249 = heff_field(v_x5_244, 0);
      V v_pls_2410 = heff_field(v_x5_244, 1);
      V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
      V v_t_2413;
      switch (heff_tag_of(v_pl_249)) {
      case TAG_Nothing: {
        v_t_2413 = heff_tr(g_heff_2eelab_2erules_2ecodeAt(heff_dup(v_n_240), heff_dup(v_k_241), heff_dup(v_places_242), heff_dup(v_m_247), heff_dup(v_i_245)));
        break;
      }
      case TAG_Just: {
        V v_p_2411 = heff_field(v_pl_249, 0);
        V v_ru_24pl_249_24Just = heff_take_reuse_n(v_pl_249, 1ULL, 1);
        V v_t_2412 = heff_intSub(heff_intSub(heff_dup(v_k_241), MK_INT(1LL)), v_p_2411);
        v_t_2413 = heff_tag_at_n(v_ru_24pl_249_24Just, TAG_SLocal, 1, (V[]){v_t_2412});
        break;
      }
      default: heff_nomatch(v_pl_249);
      }
      V v_t_2414 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_m_247, 0, 5), v_t_2413});
      V v_cell_2415 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
      V v_u_2416 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2415));
      heff_drop(v_u_2416);
      V t_0 = v_n_240;
      V t_1 = v_k_241;
      V t_2 = v_places_242;
      V t_3 = v_rest_248;
      V t_4 = v_pls_2410;
      V t_5 = heff_intAdd(v_i_245, MK_INT(1LL));
      V t_6 = v_cell_2415;
      v_n_240 = t_0;
      v_k_241 = t_1;
      v_places_242 = t_2;
      v_x4_243 = t_3;
      v_x5_244 = t_4;
      v_i_245 = t_5;
      v_d_246 = t_6;
      goto top;
    }
    default: return heff_nomatch(v_x5_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2eentriesGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eentriesGo_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str3, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str4, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str5, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str6, 45, "non-exhaustive pattern: no case provided for ");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str7, 4, "tag ");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str8, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str9, 45, "non-exhaustive pattern: no case provided for ");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str10, 4, "tag ");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str11, 1, "`");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str12, 1, "`");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str13, 43, "wrong number of arguments provided for tag ");
V g_heff_2eelab_2erules_2ecaseArm_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam6(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam9(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam8(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam7(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam10(V self, V *args);
Clo g_heff_2eelab_2erules_2ecaseArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecaseArm_entry, 9, 0};

V g_heff_2eelab_2erules_2ecaseArm(V v_sp_240, V v_e_241, V v_b_242, V v_a_243, V v_p_244, V v_tags_245, V v_x_246, V v_ts_247, V v_casesChk_248) {
top: ;
  V v_byName_249 = heff_take_field(v_casesChk_248, 1);
  V v_values_2410 = heff_get_n(v_casesChk_248, 2, 3);
  HeffT2 v_t_2411 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_byName_249, v_x_246));
  V v_it_2417;
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_i_2414 = v_field_2413;
      V v_xs_2415 = heff_dup(v_values_2410);
      if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2414, 1) && heff_intLt_c(heff_dup(v_i_2414), heff_arrayLength_lent(v_xs_2415, 0)))) {
        V v_t_2416 = heff_arrayIndex(v_xs_2415, v_i_2414);
        v_it_2417 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
      } else {
        heff_drop(v_i_2414);
        heff_drop(v_xs_2415);
        v_it_2417 = NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_field_2413);
      v_it_2417 = NTAG(TAG_Nothing);
    }
  }
  switch (heff_tag_of(v_it_2417)) {
  case TAG_Nothing: {
    HeffT2 v_t_2418 = ({ V a_0 = v_byName_249; V b_1 = ((V)&g_heff_2eelab_2erules_2ecaseArm_str0); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(v_byName_249); heff_drop(b_1); r_; });
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        V v_i_2421 = v_field_2420;
        V v_xs_2422 = v_values_2410;
        if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2421, 1) && heff_intLt_c(heff_dup(v_i_2421), heff_arrayLength_lent(v_xs_2422, 0)))) {
          V v_t_2423 = heff_arrayIndex(v_xs_2422, v_i_2421);
          switch (heff_tag_of(v_t_2423)) {
          case TAG_MkPair: {
            V v_bodyChk_2425 = heff_field(v_t_2423, 1);
            heff_take_n(v_t_2423, 2ULL, 2);
            V v_t_2426 = ({ V a_0 = v_tags_245; V b_1 = ((V)&g_heff_2eelab_2erules_2ecaseArm_str1); V r_ = (g_heff_2eelab_2erules_2ewrittenAt(a_0, b_1)); heff_drop(b_1); r_; });
            V v_c_2427 = (g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471(heff_dup(v_x_246), heff_dup(heff_rfield(v_e_241, 0)), heff_dup(v_p_244), heff_dup(g_heff_2eelab_2erules_2estandsFor_get()), v_t_2426));
            return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam0, 2, 9, (V[]){v_c_2427, v_ts_247, heff_dup(v_tags_245), v_x_246, v_sp_240, v_p_244, v_e_241, v_bodyChk_2425, v_b_242});
          }
          default: return heff_nomatch(v_t_2423);
          }
        } else {
          heff_drop(v_b_242);
          heff_drop(v_i_2421);
          heff_drop(v_xs_2422);
          V v_t_2459;
          switch (heff_tag_of(v_p_244)) {
          case TAG_Nothing: {
            heff_drop_rec(v_e_241, 6);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_Just: {
            V v_p_2451 = heff_field(v_p_244, 0);
            heff_take_n(v_p_244, 1ULL, 1);
            V v_t_2452 = heff_get_n(heff_get_n(v_e_241, 0, 6), 4, 5);
            HeffT2 v_t_2453 = ({ V b_0 = heff_get_n(v_t_2452, 1, 2); V a_1 = v_p_2451; HeffT2 r_ = (g_heff_2eelab_2eenvironment_2ematchedTagsAt_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
            {
              V v_field_2455 = v_t_2453.f[1];
              int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
              if ((v_tag_2454 == ((int64_t)0ULL))) {
                V v_ys_2456 = v_field_2455;
                V v_t_2457 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_246)}));
                V v_t_2458 = ({ V a_0 = v_t_2457; V a_1 = v_ys_2456; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_ys_2456); r_; });
                v_t_2459 = heff_bool(!(heff_dup(v_t_2458) == NTAG(TAG_True)));
                heff_drop(v_t_2458);
              } else {
                heff_drop(v_field_2455);
                v_t_2459 = NTAG(TAG_False);
              }
            }
            break;
          }
          default: heff_nomatch(v_p_244);
          }
          if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
            heff_drop(v_sp_240);
            heff_drop(v_t_2459);
            V v_t_2460 = (g_list_2emap_24s258116700x992061112(((V)&g_heff_2eelab_2erules_2ecaseArm_str5), v_ts_247));
            V v_t_2461 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_arrayFromList(v_t_2460), NTAG(TAG_SAbandon)});
            V v_x_2462 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_t_2461});
            return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam3, 2, 1, (V[]){v_x_2462});
          } else {
            heff_drop(v_ts_247);
            heff_drop(v_t_2459);
            return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam4, 2, 2, (V[]){v_x_246, v_sp_240});
          }
        }
      } else {
        heff_drop(v_b_242);
        heff_drop(v_values_2410);
        heff_drop(v_field_2420);
        V v_t_2482;
        switch (heff_tag_of(v_p_244)) {
        case TAG_Nothing: {
          heff_drop_rec(v_e_241, 6);
          v_t_2482 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          V v_p_2474 = heff_field(v_p_244, 0);
          heff_take_n(v_p_244, 1ULL, 1);
          V v_t_2475 = heff_get_n(heff_get_n(v_e_241, 0, 6), 4, 5);
          HeffT2 v_t_2476 = ({ V b_0 = heff_get_n(v_t_2475, 1, 2); V a_1 = v_p_2474; HeffT2 r_ = (g_heff_2eelab_2eenvironment_2ematchedTagsAt_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
          {
            V v_field_2478 = v_t_2476.f[1];
            int64_t v_tag_2477 = ((int64_t)v_t_2476.f[0]);
            if ((v_tag_2477 == ((int64_t)0ULL))) {
              V v_ys_2479 = v_field_2478;
              V v_t_2480 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_246)}));
              V v_t_2481 = ({ V a_0 = v_t_2480; V a_1 = v_ys_2479; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_ys_2479); r_; });
              v_t_2482 = heff_bool(!(heff_dup(v_t_2481) == NTAG(TAG_True)));
              heff_drop(v_t_2481);
            } else {
              heff_drop(v_field_2478);
              v_t_2482 = NTAG(TAG_False);
            }
          }
          break;
        }
        default: heff_nomatch(v_p_244);
        }
        if ((heff_dup(v_t_2482) == NTAG(TAG_True))) {
          heff_drop(v_sp_240);
          heff_drop(v_t_2482);
          V v_t_2483 = (g_list_2emap_24s258116700x992061112(((V)&g_heff_2eelab_2erules_2ecaseArm_str8), v_ts_247));
          V v_t_2484 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_arrayFromList(v_t_2483), NTAG(TAG_SAbandon)});
          V v_x_2485 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_t_2484});
          return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam5, 2, 1, (V[]){v_x_2485});
        } else {
          heff_drop(v_ts_247);
          heff_drop(v_t_2482);
          return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam6, 2, 2, (V[]){v_x_246, v_sp_240});
        }
      }
    }
  }
  case TAG_Just: {
    V v_it1_2497 = heff_field(v_it_2417, 0);
    heff_take_n(v_it_2417, 1ULL, 1);
    heff_drop(v_byName_249);
    heff_drop(v_values_2410);
    switch (heff_tag_of(v_it1_2497)) {
    case TAG_MkPair: {
      V v_xs_2498 = heff_field(v_it1_2497, 0);
      V v_bodyChk_2499 = heff_field(v_it1_2497, 1);
      heff_take_n(v_it1_2497, 3ULL, 2);
      V v_t_24100 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_247));
      if (heff_intEq_c(heff_arrayLength_lent(v_xs_2498, 0), v_t_24100)) {
        V v_t_24101 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2ecaseArm_str11), heff_dup(v_x_246)), ((V)&g_heff_2eelab_2erules_2ecaseArm_str12));
        V v_t_24102 = (g_heff_2eelab_2erules_2ewrittenAt(v_tags_245, v_x_246));
        V v_c_24103 = (g_heff_2eelab_2erules_2eseeArm_24s2086087070x1318941471(heff_dup(v_x_246), heff_dup(heff_rfield(v_e_241, 0)), heff_dup(v_p_244), v_t_24101, v_t_24102));
        return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam7, 2, 10, (V[]){v_c_24103, v_ts_247, heff_dup(v_tags_245), v_x_246, v_sp_240, v_p_244, v_e_241, v_xs_2498, v_bodyChk_2499, v_b_242});
      } else {
        heff_drop_rec(v_e_241, 6);
        heff_drop(v_b_242);
        heff_drop(v_p_244);
        heff_drop(v_ts_247);
        heff_drop(v_xs_2498);
        heff_drop(v_bodyChk_2499);
        return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam10, 2, 2, (V[]){v_x_246, v_sp_240});
      }
    }
    default: return heff_nomatch(v_it1_2497);
    }
  }
  default: return heff_nomatch(v_it_2417);
  }
}
V g_heff_2eelab_2erules_2ecaseArm_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a5 = a[5]; V r = g_heff_2eelab_2erules_2ecaseArm(a[0], a[1], a[2], a3, a[4], a5, a[6], a[7], a[8]); heff_drop(a3); heff_drop(a5); return r;
}
V g_heff_2eelab_2erules_2ecaseArm_lam2(V self, V *args) {
  V v_x_2447 = args[0];
  V v_ts_247 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_k_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2448 = (g_list_2emap_24s258116700x992061112(((V)&g_heff_2eelab_2erules_2ecaseArm_str4), v_ts_247));
  V v_t_2449 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_arrayFromList(v_t_2448), heff_get_n(v_x_2447, 0, 2)});
  V v_x_2450 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_t_2449});
  V f_ = v_k_2429;
  args[0] = v_x_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam1(V self, V *args) {
  V v_x_2430 = args[0];
  V v_ts_247 = heff_env(self)[0];
  V v_tags_245 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_e_241 = heff_env(self)[5];
  V v_bodyChk_2425 = heff_env(self)[6];
  V v_b_242 = heff_env(self)[7];
  V v_hd_2428 = heff_env(self)[8];
  V v_k_2429 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2430);
  V v_t_2431 = (g_list_2emap_24s258116700x992061112(((V)&g_heff_2eelab_2erules_2ecaseArm_str2), heff_dup(v_ts_247)));
  V v_t_2432 = (g_list_2emap_24s1990719097x1419059608(heff_dup(v_ts_247)));
  V v_n_2433 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_247));
  HeffT2 v_t_2434 = ({ V a_0 = v_tags_245; V b_1 = ((V)&g_heff_2eelab_2erules_2ecaseArm_str3); HeffT2 r_ = (g_heff_2eelab_2erules_2ewrittenAt_24cpr(a_0, b_1)); heff_drop(v_tags_245); heff_drop(b_1); r_; });
  V v_t_2442;
  {
    V v_field_2436 = v_t_2434.f[1];
    int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
    V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
    V v_t_2439;
    if ((v_tag_2435 == ((int64_t)0ULL))) {
      heff_drop(v_sp_240);
      V v_at_2438 = v_field_2436;
      v_t_2439 = v_at_2438;
    } else {
      heff_drop(v_field_2436);
      v_t_2439 = v_sp_240;
    }
    V v_sc_2440 = (g_heff_2eelab_2eenvironment_2ematchedTo(v_p_244, v_t_2437, v_t_2439, heff_dup(heff_rfield(v_e_241, 0))));
    switch (heff_tag_of(v_p_244)) {
    case TAG_Nothing: {
      heff_drop(v_n_2433);
      v_t_2442 = v_sc_2440;
      break;
    }
    case TAG_Just: {
      V v_p_2441 = heff_field(v_p_244, 0);
      heff_take_n(v_p_244, 1ULL, 1);
      v_t_2442 = (g_heff_2eelab_2eenvironment_2eargPartsFrom(v_p_2441, heff_dup(v_x_246), heff_dup(heff_rfield(v_sc_2440, 0)), MK_INT(0LL), v_n_2433, v_sc_2440));
      break;
    }
    default: heff_nomatch(v_p_244);
    }
  }
  V v_sc_2443 = ({ V a_0 = v_t_2431; V a_1 = v_t_2432; V a_2 = v_t_2442; V r_ = (g_heff_2eelab_2eenvironment_2emultiBind(a_0, a_1, a_2)); heff_drop(v_t_2431); heff_drop(v_t_2432); r_; });
  V v_c_2446;
  switch (heff_tag_of(v_bodyChk_2425)) {
  case TAG_MkChk: {
    V v_f_2444 = heff_field(v_bodyChk_2425, 0);
    heff_take_n(v_bodyChk_2425, 1ULL, 1);
    V v_t_2445 = ({ V rv_0 = v_sc_2443; V rr_ = heff_rec_reuse_nf(v_e_241, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    v_c_2446 = heff_tr(heff_call(v_f_2444, 2, (V[]){v_t_2445, v_b_242}));
    break;
  }
  default: heff_nomatch(v_bodyChk_2425);
  }
  V f_ = v_c_2446;
  heff_room[0] = v_hd_2428;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam2, 1, 3, (V[]){v_ts_247, v_x_246, v_k_2429});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ecaseArm_lam0(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_c_2427 = heff_env(self)[0];
  V v_ts_247 = heff_env(self)[1];
  V v_tags_245 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_e_241 = heff_env(self)[6];
  V v_bodyChk_2425 = heff_env(self)[7];
  V v_b_242 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V f_ = v_c_2427;
  args[0] = heff_dup(v_hd_2428);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam1, 1, 10, (V[]){v_ts_247, v_tags_245, v_x_246, v_sp_240, v_p_244, v_e_241, v_bodyChk_2425, v_b_242, v_hd_2428, v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam3(V self, V *args) {
  V v_hd_2463 = args[0];
  V v_k_2464 = args[1];
  V v_x_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2463);
  V f_ = v_k_2464;
  args[0] = v_x_2462;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam4(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k2_2466 = args[1];
  V v_x_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2467 = heff_take_field(v_hd_2465, 1);
  V v_malg_2468 = heff_get_n(v_hd_2465, 2, 3);
  V v_t_2469 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ecaseArm_str6), heff_strAppend(((V)&g_heff_2eelab_2erules_2ecaseArm_str7), v_x_246));
  V v_t_2470 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(317LL), NTAG(TAG_SError), v_t_2469, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tr(heff_call(v_malg_2468, 1, (V[]){v_t_2472}));
  V f_ = v_bind_2467;
  args[0] = v_t_2473;
  args[1] = v_k2_2466;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam5(V self, V *args) {
  V v_hd_2486 = args[0];
  V v_k_2487 = args[1];
  V v_x_2485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2486);
  V f_ = v_k_2487;
  args[0] = v_x_2485;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam6(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k2_2489 = args[1];
  V v_x_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2490 = heff_take_field(v_hd_2488, 1);
  V v_malg_2491 = heff_get_n(v_hd_2488, 2, 3);
  V v_t_2492 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ecaseArm_str9), heff_strAppend(((V)&g_heff_2eelab_2erules_2ecaseArm_str10), v_x_246));
  V v_t_2493 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(317LL), NTAG(TAG_SError), v_t_2492, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2494 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
  V v_t_2496 = heff_tr(heff_call(v_malg_2491, 1, (V[]){v_t_2495}));
  V f_ = v_bind_2490;
  args[0] = v_t_2496;
  args[1] = v_k2_2489;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam9(V self, V *args) {
  V v_x_24122 = args[0];
  V v_xs_2498 = heff_env(self)[0];
  V v_k_24105 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24123 = heff_tag_n(TAG_MkPair, 2, (V[]){v_xs_2498, heff_get_n(v_x_24122, 0, 2)});
  V f_ = v_k_24105;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_t_24123});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam8(V self, V *args) {
  V v_x_24106 = args[0];
  V v_ts_247 = heff_env(self)[0];
  V v_tags_245 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_e_241 = heff_env(self)[5];
  V v_xs_2498 = heff_env(self)[6];
  V v_bodyChk_2499 = heff_env(self)[7];
  V v_b_242 = heff_env(self)[8];
  V v_hd_24104 = heff_env(self)[9];
  V v_k_24105 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_24106);
  V v_t_24107 = (g_list_2emap_24s1990719097x1419059608(heff_dup(v_ts_247)));
  V v_n_24108 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_247; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ts_247); r_; });
  HeffT2 v_t_24109 = ({ V a_0 = v_tags_245; V a_1 = v_x_246; HeffT2 r_ = (g_heff_2eelab_2erules_2ewrittenAt_24cpr(a_0, a_1)); heff_drop(v_tags_245); r_; });
  V v_t_24117;
  {
    V v_field_24111 = v_t_24109.f[1];
    int64_t v_tag_24110 = ((int64_t)v_t_24109.f[0]);
    V v_t_24112 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
    V v_t_24114;
    if ((v_tag_24110 == ((int64_t)0ULL))) {
      heff_drop(v_sp_240);
      V v_at_24113 = v_field_24111;
      v_t_24114 = v_at_24113;
    } else {
      heff_drop(v_field_24111);
      v_t_24114 = v_sp_240;
    }
    V v_sc_24115 = (g_heff_2eelab_2eenvironment_2ematchedTo(v_p_244, v_t_24112, v_t_24114, heff_dup(heff_rfield(v_e_241, 0))));
    switch (heff_tag_of(v_p_244)) {
    case TAG_Nothing: {
      heff_drop(v_n_24108);
      v_t_24117 = v_sc_24115;
      break;
    }
    case TAG_Just: {
      V v_p_24116 = heff_field(v_p_244, 0);
      heff_take_n(v_p_244, 1ULL, 1);
      v_t_24117 = (g_heff_2eelab_2eenvironment_2eargPartsFrom(v_p_24116, heff_dup(v_x_246), heff_dup(heff_rfield(v_sc_24115, 0)), MK_INT(0LL), v_n_24108, v_sc_24115));
      break;
    }
    default: heff_nomatch(v_p_244);
    }
  }
  V v_sc_24118 = ({ V b_0 = heff_arrayToList(heff_dup(v_xs_2498)); V a_1 = v_t_24107; V a_2 = v_t_24117; V r_ = (g_heff_2eelab_2eenvironment_2emultiBind(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_24107); r_; });
  V v_c_24121;
  switch (heff_tag_of(v_bodyChk_2499)) {
  case TAG_MkChk: {
    V v_f_24119 = heff_field(v_bodyChk_2499, 0);
    heff_take_n(v_bodyChk_2499, 1ULL, 1);
    V v_t_24120 = ({ V rv_0 = v_sc_24118; V rr_ = heff_rec_reuse_nf(v_e_241, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    v_c_24121 = heff_tr(heff_call(v_f_24119, 2, (V[]){v_t_24120, v_b_242}));
    break;
  }
  default: heff_nomatch(v_bodyChk_2499);
  }
  V f_ = v_c_24121;
  heff_room[0] = v_hd_24104;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam9, 1, 3, (V[]){v_xs_2498, v_k_24105, v_x_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ecaseArm_lam7(V self, V *args) {
  V v_hd_24104 = args[0];
  V v_k_24105 = args[1];
  V v_c_24103 = heff_env(self)[0];
  V v_ts_247 = heff_env(self)[1];
  V v_tags_245 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_e_241 = heff_env(self)[6];
  V v_xs_2498 = heff_env(self)[7];
  V v_bodyChk_2499 = heff_env(self)[8];
  V v_b_242 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_24103;
  args[0] = heff_dup(v_hd_24104);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam8, 1, 11, (V[]){v_ts_247, v_tags_245, v_x_246, v_sp_240, v_p_244, v_e_241, v_xs_2498, v_bodyChk_2499, v_b_242, v_hd_24104, v_k_24105});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam10(V self, V *args) {
  V v_hd_24124 = args[0];
  V v_k2_24125 = args[1];
  V v_x_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_24126 = heff_take_field(v_hd_24124, 1);
  V v_malg_24127 = heff_get_n(v_hd_24124, 2, 3);
  V v_t_24128 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(316LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2ecaseArm_str13), v_x_246), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_24129 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24128})});
  V v_t_24130 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24129})});
  V v_t_24131 = heff_tr(heff_call(v_malg_24127, 1, (V[]){v_t_24130}));
  V f_ = v_bind_24126;
  args[0] = v_t_24131;
  args[1] = v_k2_24125;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2einOrder_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einOrder_24dps_entry, 6, 0};

V g_heff_2eelab_2erules_2einOrder_24dps(V v_n_240, V v_body_241, V v_casesChk_242, V v_x4_243, V v_x5_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_body_241);
    heff_drop_rec(v_casesChk_242, 3);
    heff_drop(v_x5_244);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_p_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nil: {
      V v_t_248 = (g_heff_2eelab_2erules_2edefaultCopy(heff_dup(v_n_240), heff_dup(v_body_241), v_p_246));
      V v_cell_249 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_n_240;
      V t_1 = v_body_241;
      V t_2 = v_casesChk_242;
      V t_3 = v_rest_247;
      V t_4 = NTAG(TAG_Nil);
      V t_5 = v_cell_249;
      v_n_240 = t_0;
      v_body_241 = t_1;
      v_casesChk_242 = t_2;
      v_x4_243 = t_3;
      v_x5_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
    case TAG_Cons: {
      V v_c_2411 = heff_field(v_x5_244, 0);
      V v_done_2412 = heff_field(v_x5_244, 1);
      V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
      switch (heff_tag_of(v_p_246)) {
      case TAG_MkPair: {
        V v_x_2413 = heff_dup(heff_field(v_p_246, 0));
        HeffT2 v_t_2415 = ({ V a_0 = heff_rfield(v_casesChk_242, 1); V a_1 = v_x_2413; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_x_2413); r_; });
        {
          V v_field_2417 = v_t_2415.f[1];
          int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            V v_i_2418 = v_field_2417;
            V v_xs_2419 = heff_dup(heff_rfield(v_casesChk_242, 2));
            if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2418, 1) && heff_intLt_c(heff_dup(v_i_2418), heff_arrayLength_lent(v_xs_2419, 0)))) {
              heff_drop_tag(v_p_246, 2);
              heff_drop_cell(v_ru_24x5_244_24Cons, 2);
              V v_x_2420 = heff_arrayIndex(v_xs_2419, v_i_2418);
              heff_drop(v_x_2420);
              V v_cell_2421 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_c_2411, heff_hole()});
              V v_u_2422 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2421));
              heff_drop(v_u_2422);
              V t_0 = v_n_240;
              V t_1 = v_body_241;
              V t_2 = v_casesChk_242;
              V t_3 = v_rest_247;
              V t_4 = v_done_2412;
              V t_5 = v_cell_2421;
              v_n_240 = t_0;
              v_body_241 = t_1;
              v_casesChk_242 = t_2;
              v_x4_243 = t_3;
              v_x5_244 = t_4;
              v_d_245 = t_5;
              goto top;
            } else {
              heff_drop(v_i_2418);
              heff_drop(v_xs_2419);
              V v_t_2423 = (g_heff_2eelab_2erules_2edefaultCopy(heff_dup(v_n_240), heff_dup(v_body_241), v_p_246));
              V v_cell_2424 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
              V v_u_2425 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2424));
              heff_drop(v_u_2425);
              V t_0 = v_n_240;
              V t_1 = v_body_241;
              V t_2 = v_casesChk_242;
              V t_3 = v_rest_247;
              V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_c_2411, v_done_2412});
              V t_5 = v_cell_2424;
              v_n_240 = t_0;
              v_body_241 = t_1;
              v_casesChk_242 = t_2;
              v_x4_243 = t_3;
              v_x5_244 = t_4;
              v_d_245 = t_5;
              goto top;
            }
          } else {
            heff_drop(v_field_2417);
            V v_t_2426 = (g_heff_2eelab_2erules_2edefaultCopy(heff_dup(v_n_240), heff_dup(v_body_241), v_p_246));
            V v_cell_2427 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
            V v_u_2428 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2427));
            heff_drop(v_u_2428);
            V t_0 = v_n_240;
            V t_1 = v_body_241;
            V t_2 = v_casesChk_242;
            V t_3 = v_rest_247;
            V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_c_2411, v_done_2412});
            V t_5 = v_cell_2427;
            v_n_240 = t_0;
            v_body_241 = t_1;
            v_casesChk_242 = t_2;
            v_x4_243 = t_3;
            v_x5_244 = t_4;
            v_d_245 = t_5;
            goto top;
          }
        }
      }
      default: return heff_nomatch(v_p_246);
      }
    }
    default: return heff_nomatch(v_x5_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2einOrder_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einOrder_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}

HeffT2 g_heff_2eelab_2erules_2eotherTag_24cpr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_y_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str0, 136, "the record's shape is not in hand here for the update: annotate the binder, `\\(x : T) -> ...`, or give the implicit argument, `(a := T)`");
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str1, 53, "tried to update a value that was not of a record type");
V g_heff_2eelab_2erules_2eupdateOf_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam11(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam10(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam14(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam13(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam12(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eupdateOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdateOf_entry, 8, 0};

V g_heff_2eelab_2erules_2eupdateOf(V v_sp_240, V v_r_241, V v_e_242, V v_g_243, V v_a0_244, V v_fs_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam0, 1, 1, (V[]){v_a0_244})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam1, 1, 7, (V[]){v_e_242, v_fs_245, v_hd_246, v_sp_240, v_r_241, v_g_243, v_k_247})});
}
V g_heff_2eelab_2erules_2eupdateOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eupdateOf(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2eupdateOf_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 9); V a_1 = v_a0_244; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eupdateOf_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_g_243 = heff_env(self)[3];
  V v_x_2412 = heff_env(self)[4];
  V v_fs_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2erules_2eupdateSetting(((V)&g_heff_2eelab_2erules_2eupdateOf_clo), v_e_242, v_sp_240, v_r_241, v_g_243, v_x_2412, v_fs_245, v_x_2420));
}
V g_heff_2eelab_2erules_2eupdateOf_lam5(V self, V *args) {
  V v_v_2423 = args[0];
  V v_scope_27_2424 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_x_2422 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_v_2423);
  HeffT1 v_t_2425 = (g_heff_2eelab_2erules_2erecordIntro_24cpr(v_sp_240, v_x_2422));
  {
    V v_field_2426 = v_t_2425.f[0];
    V v_f_2427 = v_field_2426;
    V v_t_2428 = ({ V rv_0 = v_scope_27_2424; V rr_ = heff_rec_reuse_nf(v_e_242, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_f_2427;
    args[0] = v_t_2428;
    args[1] = v_x_2412;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam7(V self, V *args) {
  V v_u_2438 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2438);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2eelab_2erules_2eupdateOf_lam8(V self, V *args) {
  V v_u_2442 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2442);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2eelab_2erules_2eupdateOf_lam6(V self, V *args) {
  V v_x_2430 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_g_243 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2431 = heff_take_field(v_e_242, 2);
  V v_t_2434;
  switch (heff_tag_of(v_t_2431)) {
  case TAG_ForNominative: {
    v_t_2434 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2431, 0ULL, 2);
    v_t_2434 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2431);
  }
  V v_t_2435 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 2, 5);
  V v_t_2436 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 0, 5);
  V v_t_2437 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2436, heff_dup(v_x_2412)));
  V v_dom_2439 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2437, heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam7, 1, 1, (V[]){heff_dup(v_x_2412)})});
  V v_t_2440 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 0, 5);
  V v_t_2441 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_t_2440, MK_INT(1LL)), heff_dup(v_x_2412)));
  V v_cod_2443 = heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_r_241), heff_rec_n(2, shape_stx__val, (V[]){v_t_2441, heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam8, 1, 1, (V[]){v_x_2412})})});
  V v_t_2444 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 2, 5);
  V v_t_2445 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_dup(heff_rfield(v_e_242, 1)), v_t_2444, v_dom_2439, v_cod_2443));
  V v_t_2446 = (g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782(v_r_241, v_x_2430, v_t_2434, heff_get_n(v_e_242, 1, 6), v_t_2435, v_t_2445));
  V v_x_2447 = (g_heff_2eelab_2ememoed_2eapp(v_t_2446, v_g_243));
  V f_ = v_k_247;
  args[0] = v_x_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateOf_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_r_241 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_g_243 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2429 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_r_241), heff_dup(v_x_2412), heff_dup(heff_rfield(v_e_242, 0)), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam5, 2, 4, (V[]){v_sp_240, v_x_2422, heff_dup(v_e_242), heff_dup(v_x_2412)})));
  V f_ = v_c_2429;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam6, 1, 5, (V[]){v_e_242, v_x_2412, v_r_241, v_g_243, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eupdateOf_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_g_243 = heff_env(self)[3];
  V v_x_2412 = heff_env(self)[4];
  V v_fs_245 = heff_env(self)[5];
  V v_keys_2417 = heff_env(self)[6];
  V v_hd_246 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2419);
  V v_c_2421 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam3, 1, 6, (V[]){heff_dup(v_e_242), heff_dup(v_sp_240), heff_dup(v_r_241), heff_dup(v_g_243), heff_dup(v_x_2412), v_fs_245}), v_keys_2417));
  V f_ = v_c_2421;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam4, 1, 7, (V[]){v_r_241, v_x_2412, v_e_242, v_sp_240, v_hd_246, v_g_243, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eupdateOf_lam11(V self, V *args) {
  V v_u_2450 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2450);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam10(V self, V *args) {
  V v_u_2449 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2449);
  V v_t_2451 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam11, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2451});
}
V g_heff_2eelab_2erules_2eupdateOf_lam9(V self, V *args) {
  V v_x_2448 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2448) == NTAG(TAG_True))) {
    heff_drop(v_x_2448);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_2452 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam10, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_2452;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2448);
    heff_drop(v_x_2412);
    V v_t_2453 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(332LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2455}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2456;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam14(V self, V *args) {
  V v_u_2459 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2459);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam13(V self, V *args) {
  V v_u_2458 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2458);
  V v_t_2460 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam14, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2460});
}
V g_heff_2eelab_2erules_2eupdateOf_lam12(V self, V *args) {
  V v_x_2457 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2457) == NTAG(TAG_True))) {
    heff_drop(v_x_2457);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_2461 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam13, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_2461;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2457);
    heff_drop(v_x_2412);
    V v_t_2462 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str1), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2464}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2465;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_fs_245 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_r_241 = heff_env(self)[4];
  V v_g_243 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeRecord: {
    V v_fieldTypes_2416 = heff_field(v_t_2413, 2);
    heff_take_n(v_t_2413, 4ULL, 3);
    V v_keys_2417 = heff_arrayToList(heff_get_n(v_fieldTypes_2416, 0, 3));
    V v_c_2418 = (g_heff_2eelab_2erules_2enoSuchSetting(heff_dup(v_e_242), heff_dup(v_x_2412), v_keys_2417, v_fs_245));
    V f_ = v_c_2418;
    heff_room[0] = heff_dup(v_hd_246);
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam2, 1, 9, (V[]){v_e_242, v_sp_240, v_r_241, v_g_243, v_x_2412, v_fs_245, v_keys_2417, v_hd_246, v_k_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_NoRules: {
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam9, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  default: {
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    heff_drop(v_t_2413);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam12, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  }
}

HeffT2 g_heff_2eelab_2erules_2eindexOfName_24cpr(V v_x1_240, V v_x_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x1_240, 0);
    V v_ys_244 = heff_field(v_x1_240, 1);
    if (heff_strEq_c_lent(v_y_243, v_x_241, 0)) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_242}});
    } else {
      V t_0 = v_ys_244;
      V t_1 = v_x_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_x1_240 = t_0;
      v_x_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2efindPrim_24cpr_str0, 17, "no such variable ");
HEFF_LIT(g_heff_2eelab_2erules_2efindPrim_24cpr_str1, 9, " in scope");
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2efindPrim_24cpr(V v_sp_240, V v_p_241) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2efindPrim_24cpr_lam0, 1, 2, (V[]){v_p_241, v_sp_240})}});
}
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam2(V self, V *args) {
  V v_mc_2416 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_type_5f_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_e_242; V a_1 = v_mc_2416; V a_2 = v_type_5f_2410; V r_ = (g_heff_2eelab_2erules_2etyStrIn(a_0, a_1, a_2)); heff_drop(v_mc_2416); r_; });
}
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam4(V self, V *args) {
  V v_u_2421 = args[0];
  V v_value_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2421);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_value_2411});
}
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_key_248 = heff_env(self)[0];
  V v_value_2411 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  V v_type_5f_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2420);
  V v_t_2422 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_key_248}), heff_clo_n(g_heff_2eelab_2erules_2efindPrim_24cpr_lam4, 1, 1, (V[]){v_value_2411})});
  V f_ = v_k_2413;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, v_type_5f_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_key_248 = heff_env(self)[2];
  V v_e_242 = heff_env(self)[3];
  V v_type_5f_2410 = heff_env(self)[4];
  V v_value_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_bind_2414 = heff_take_field(v_hd_2412, 1);
  V v_malg_2415 = heff_get_n(v_hd_2412, 2, 3);
  V v_t_2417 = heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_sp_240, v_p_241, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_key_248)}), NTAG(TAG_False), heff_clo_n(g_heff_2eelab_2erules_2efindPrim_24cpr_lam2, 1, 2, (V[]){v_e_242, heff_dup(v_type_5f_2410)})});
  V v_t_2418 = heff_tag_n(TAG_Record, 2, (V[]){v_t_2417, NTAG(TAG_MkUnit)});
  V v_t_2419 = heff_tr(heff_call(v_malg_2415, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})}));
  V f_ = v_bind_2414;
  args[0] = v_t_2419;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efindPrim_24cpr_lam3, 1, 4, (V[]){v_key_248, v_value_2411, v_k_2413, v_type_5f_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam5(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k2_2424 = args[1];
  V v_p_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2425 = heff_take_field(v_hd_2423, 1);
  V v_malg_2426 = heff_get_n(v_hd_2423, 2, 3);
  V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2efindPrim_24cpr_str0), v_p_241), ((V)&g_heff_2eelab_2erules_2efindPrim_24cpr_str1));
  V v_t_2428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(308LL), NTAG(TAG_SError), v_t_2427, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tr(heff_call(v_malg_2426, 1, (V[]){v_t_2430}));
  V f_ = v_bind_2425;
  args[0] = v_t_2431;
  args[1] = v_k2_2424;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efindPrim_24cpr_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_e_242, 1)), 1, 8);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_p_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_e_247 = v_field_246;
      V v_key_248 = heff_dup(v_p_241);
      V v_ge_249 = v_e_247;
      V v_type_5f_2410 = heff_take_field(v_ge_249, 3);
      V v_value_2411 = heff_get_n(v_ge_249, 2, 4);
      return heff_clo_n(g_heff_2eelab_2erules_2efindPrim_24cpr_lam1, 2, 6, (V[]){v_sp_240, v_p_241, v_key_248, v_e_242, v_type_5f_2410, v_value_2411});
    } else {
      heff_drop_rec(v_e_242, 6);
      heff_drop(v_field_246);
      return heff_clo_n(g_heff_2eelab_2erules_2efindPrim_24cpr_lam5, 2, 2, (V[]){v_p_241, v_sp_240});
    }
  }
}