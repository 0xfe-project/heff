// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DLet 13606
#define TAG_DSets 40405
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PartOp 18051
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SOnce 21704
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define LBL_bindTo 558176963
#define LBL_cond 9554921
#define LBL_full 9650006
#define LBL_op 10312
#define LBL_sts 323756
#define LBL_toDest 1077793512
#define LBL_val 326043
HeffT2 g_heff_2ecompile_2eimperative_2earmNamed_24cpr(V, V);
V g_heff_2ecompile_2eimperative_2edeclsBefore(V, V);
V g_heff_2ecompile_2eimperative_2edeclsBefore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2edeclsBefore_clo;
V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24dps(V, V, V);
V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24dps_clo;
V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24tok1(V, V, V);
V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24tok1_clo;
V g_heff_2ecompile_2eimperative_2egenOf(V);
V g_heff_2ecompile_2eimperative_2egenOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2egenOf_clo;
HeffT8 g_heff_2ecompile_2eimperative_2egenOf_24cpr(V);
V g_heff_2ecompile_2eimperative_2einlinable(V, V, V, V);
V g_heff_2ecompile_2eimperative_2einlinable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2einlinable_clo;
V g_heff_2ecompile_2eimperative_2eisRelCall(V);
V g_heff_2ecompile_2eimperative_2eisRelCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eisRelCall_clo;
V g_heff_2ecompile_2eimperative_2eisSimple(V);
V g_heff_2ecompile_2eimperative_2eisSimple_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eisSimple_clo;
V g_heff_2ecompile_2eimperative_2ematchSet(V, V, V, V);
V g_heff_2ecompile_2eimperative_2ematchSet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2ematchSet_clo;
V g_heff_2ecompile_2eimperative_2eonceK_get(void);
V g_heff_2ecompile_2eimperative_2eonceOp_24s1315731183x405745434(V);
V g_heff_2ecompile_2eimperative_2eonceOp_24s1315731183x405745434_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceOp_24s1315731183x405745434_clo;
V g_heff_2ecompile_2eimperative_2eonceSt_24s1868663870x435913689(V);
V g_heff_2ecompile_2eimperative_2eonceSt_24s1868663870x435913689_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceSt_24s1868663870x435913689_clo;
V g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070(V, V);
V g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070_clo;
V g_heff_2ecompile_2eimperative_2eopOf(V, V);
V g_heff_2ecompile_2eimperative_2eopOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eopOf_clo;
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(V, V);
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_clo;
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_clo;
V g_heff_2ecompile_2eimperative_2epredAny(V, V);
V g_heff_2ecompile_2eimperative_2epredAny_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epredAny_clo;
V g_heff_2ecompile_2eimperative_2esetsOf(V, V, V);
V g_heff_2ecompile_2eimperative_2esetsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2esetsOf_clo;
V g_heff_2ecompile_2eimperative_2esimpleOf(V, V);
V g_heff_2ecompile_2eimperative_2esimpleOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2esimpleOf_clo;
V g_heff_2ecompile_2eimperative_2etailOf(V, V, V);
V g_heff_2ecompile_2eimperative_2etailOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etailOf_clo;
V g_heff_2ecompile_2eimperative_2etoDest(V, V, V);
V g_heff_2ecompile_2eimperative_2etoDest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etoDest_clo;
V g_heff_2ecompile_2eimperative_2evalNamesTop(V, V);
V g_heff_2ecompile_2eimperative_2evalNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2evalNamesTop_clo;
V g_heff_2ecompile_2eir_2eisRel(V);
V g_heff_2ecompile_2eir_2eisRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisRel_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1735038056x329845490(V, V);
V g_list_2efoldl_24s1735038056x329845490_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1735038056x329845490_clo;
V g_list_2efoldl_24s634927308x1347712163(V, V);
V g_list_2efoldl_24s634927308x1347712163_entry(V self, V *a);
extern Clo g_list_2efoldl_24s634927308x1347712163_clo;
V g_list_2emap_24s1737386070x1499208753(V);
V g_list_2emap_24s1737386070x1499208753_entry(V self, V *a);
extern Clo g_list_2emap_24s1737386070x1499208753_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f339900781x1605227681(V, V);
V g_prelude_2e_2b_2b_24f339900781x1605227681_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f339900781x1605227681_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2etraverse_24s1887447647x928396251(V, V);
V g_prelude_2etraverse_24s1887447647x928396251_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1887447647x928396251_clo;

HeffT2 g_heff_2ecompile_2eimperative_2earmNamed_24cpr(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t2_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      if (heff_strEq_c_lent(v_t2_244, v_t_240, 0)) {
        switch (heff_tag_of(v_vs_245)) {
        case TAG_Nil: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_b_246)}});
        }
        case TAG_Cons: {
          V t_0 = v_t_240;
          V t_1 = v_rest_243;
          v_t_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return ((HeffT2){{heff_nomatch(v_vs_245)}});
        }
      } else {
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2eimperative_2eisRelCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eisRelCall_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2eisRelCall(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2422 = heff_field(v_e_240, 0);
    V v_e2_2423 = heff_field(v_e_240, 1);
    switch (heff_tag_of(v_e2_2423)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_e22_2425 = heff_field(v_e2_2423, 1);
      switch (heff_tag_of(v_e22_2425)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_e222_2427 = heff_field(v_e22_2425, 1);
        switch (heff_tag_of(v_e222_2427)) {
        case TAG_Nil: {
          HEFF_LAST return g_heff_2ecompile_2eir_2eisRel(v_p_2422);
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_e222_2427);
        }
      }
      default: return heff_nomatch(v_e22_2425);
      }
    }
    default: return heff_nomatch(v_e2_2423);
    }
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eimperative_2eisRelCall_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2eisRelCall(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam3(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam4(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam5(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2esetsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esetsOf_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2esetsOf(V v_g_240, V v_xs_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_ELet: {
    V v_y_243 = heff_field(v_e_242, 0);
    V v_a_244 = heff_field(v_e_242, 1);
    V v_b_245 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 3)), 2, (V[]){v_y_243, v_a_244}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam0, 1, 4, (V[]){v_m_246, v_g_240, v_xs_241, v_b_245});
  }
  case TAG_EMatch: {
    V v_s_2416 = heff_field(v_e_242, 0);
    V v_arms_2417 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2418 = (g_heff_2ecompile_2eimperative_2ematchSet(v_g_240, heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_s_2416, v_arms_2417));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam1, 1, 2, (V[]){v_m_2418, v_xs_241});
  }
  case TAG_ESet: {
    V v_ys_2424 = heff_field(v_e_242, 0);
    V v_a_2425 = heff_field(v_e_242, 1);
    V v_b_2426 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2427 = (g_heff_2ecompile_2eimperative_2esetsOf(heff_dup(v_g_240), v_ys_2424, v_a_2425));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam2, 1, 4, (V[]){v_m_2427, v_g_240, v_xs_241, v_b_2426});
  }
  case TAG_EValues: {
    V v_es_2437 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_t_2438 = (g_list_2ezipWith_24s1876717925x1404326288(v_xs_241, v_es_2437));
    V v_m_2446 = (g_prelude_2etraverse_24s1887447647x928396251(heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam3, 1, 1, (V[]){v_g_240}), v_t_2438));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam4, 1, 1, (V[]){v_m_2446});
  }
  default: {
    V v_m_2453 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam5, 1, 2, (V[]){v_m_2453, v_xs_241});
  }
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2esetsOf(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam0(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_xs_241 = heff_env(self)[2];
  V v_b_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_m_2411 = (g_heff_2ecompile_2eimperative_2esetsOf(v_g_240, v_xs_241, v_b_245));
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2410}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_n_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      V v_x_2415 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_2412_24MkPair, v_x_249, v_x_2413));
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_x_2415, v_n_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam1(V self, V *args) {
  V v_n_2419 = args[0];
  V v_m_2418 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2420 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_n_2419}));
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_MkPair: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_n_2422 = heff_field(v_x2_2420, 1);
    V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
    V v_x_2423 = (g_heff_2ecompile_2eimperative_2edeclsBefore(v_xs_241, v_x_2421));
    return heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){v_x_2423, v_n_2422});
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam2(V self, V *args) {
  V v_n_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_xs_241 = heff_env(self)[2];
  V v_b_2426 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2429 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_n_2428}));
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_MkPair: {
    V v_x_2430 = heff_field(v_x2_2429, 0);
    V v_n_2431 = heff_field(v_x2_2429, 1);
    V v_ru_24x2_2429_24MkPair = heff_take_reuse_n(v_x2_2429, 3ULL, 2);
    V v_m_2432 = (g_heff_2ecompile_2eimperative_2esetsOf(v_g_240, v_xs_241, v_b_2426));
    V v_x2_2433 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_n_2431}));
    switch (heff_tag_of(v_x2_2433)) {
    case TAG_MkPair: {
      V v_x_2434 = heff_field(v_x2_2433, 0);
      V v_n_2435 = heff_field(v_x2_2433, 1);
      V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
      V v_x_2436 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_2433_24MkPair, v_x_2430, v_x_2434));
      return heff_tag_at_n(v_ru_24x2_2429_24MkPair, TAG_MkPair, 2, (V[]){v_x_2436, v_n_2435});
    }
    default: return heff_nomatch(v_x2_2433);
    }
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam3(V self, V *args) {
  V v_p_2439 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442;
  switch (heff_tag_of(v_p_2439)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_dup(heff_field(v_p_2439, 0));
    v_t_2442 = v_x_2440;
    break;
  }
  default: heff_nomatch(v_p_2439);
  }
  V v_t_2445;
  switch (heff_tag_of(v_p_2439)) {
  case TAG_MkPair: {
    V v_y_2444 = heff_field(v_p_2439, 1);
    heff_take_n(v_p_2439, 2ULL, 2);
    v_t_2445 = v_y_2444;
    break;
  }
  default: heff_nomatch(v_p_2439);
  }
  V f_ = heff_get_n(v_g_240, 3, 8);
  heff_room[0] = v_t_2442;
  heff_room[1] = v_t_2445;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam4(V self, V *args) {
  V v_n_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2448 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_n_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_n_2450 = heff_field(v_x2_2448, 1);
    V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
    V v_t_2451 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_2449));
    V v_x_2452 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2451; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2451); r_; });
    return heff_tag_at_n(v_ru_24x2_2448_24MkPair, TAG_MkPair, 2, (V[]){v_x_2452, v_n_2450});
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam5(V self, V *args) {
  V v_n_2454 = args[0];
  V v_m_2453 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2455 = heff_tr(heff_call(v_m_2453, 1, (V[]){v_n_2454}));
  switch (heff_tag_of(v_x2_2455)) {
  case TAG_MkPair: {
    V v_x_2456 = heff_field(v_x2_2455, 0);
    V v_n_2457 = heff_field(v_x2_2455, 1);
    V v_ru_24x2_2455_24MkPair = heff_take_reuse_n(v_x2_2455, 3ULL, 2);
    V v_x_2458 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_2456, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_2455_24MkPair, TAG_MkPair, 2, (V[]){v_x_2458, v_n_2457});
  }
  default: return heff_nomatch(v_x2_2455);
  }
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2egenOf_24cpr_str0, 2, "t$");
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam3(V self, V *args);
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam5(V self, V *args);
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam6(V self, V *args);
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam4(V self, V *args);
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam7(V self, V *args);
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam9(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam9, 1, 0};
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam8(V self, V *args);

HeffT8 g_heff_2ecompile_2eimperative_2egenOf_24cpr(V v_full_240) {
top: ;
  return ((HeffT8){{heff_dup(v_full_240), heff_clo_n(g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam0, 1, 1, (V[]){heff_dup(v_full_240)}), heff_clo_n(g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam1, 2, 1, (V[]){heff_dup(v_full_240)}), heff_clo_n(g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam2, 2, 1, (V[]){heff_dup(v_full_240)}), heff_clo_n(g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam3, 2, 1, (V[]){heff_dup(v_full_240)}), heff_clo_n(g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam4, 1, 1, (V[]){heff_dup(v_full_240)}), heff_clo_n(g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam7, 1, 1, (V[]){heff_dup(v_full_240)}), heff_clo_n(g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam8, 1, 1, (V[]){v_full_240})}});
}
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = (g_heff_2ecompile_2eimperative_2egenOf(v_full_240));
  return (g_heff_2ecompile_2eimperative_2esimpleOf(v_t_242, v_e_241));
}
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam1(V self, V *args) {
  V v_self_243 = args[0];
  V v_e_244 = args[1];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = (g_heff_2ecompile_2eimperative_2egenOf(v_full_240));
  return (g_heff_2ecompile_2eimperative_2etailOf(v_t_245, v_self_243, v_e_244));
}
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_e_247 = args[1];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2ecompile_2eimperative_2egenOf(v_full_240));
  return (g_heff_2ecompile_2eimperative_2etoDest(v_t_248, heff_tag_n(TAG_DLet, 1, (V[]){v_x_246}), v_e_247));
}
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam3(V self, V *args) {
  V v_d_249 = args[0];
  V v_e_2410 = args[1];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = (g_heff_2ecompile_2eimperative_2egenOf(v_full_240));
  return (g_heff_2ecompile_2eimperative_2etoDest(v_t_2411, v_d_249, v_e_2410));
}
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam5(V self, V *args) {
  V v_n_2425 = args[0];
  V v_m_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2426 = heff_tr(heff_call(v_m_2424, 1, (V[]){v_n_2425}));
  switch (heff_tag_of(v_x2_2426)) {
  case TAG_MkPair: {
    V v_x_2427 = heff_field(v_x2_2426, 0);
    V v_n_2428 = heff_field(v_x2_2426, 1);
    V v_ru_24x2_2426_24MkPair = heff_take_reuse_n(v_x2_2426, 3ULL, 2);
    V v_t_2429 = heff_tag_at_n(v_ru_24x2_2426_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_x_2427});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2429, v_n_2428});
  }
  default: return heff_nomatch(v_x2_2426);
  }
}
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam6(V self, V *args) {
  V v_n_2430 = args[0];
  V v_field_2417 = heff_env(self)[0];
  V v_e_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2egenOf_24cpr_str0), heff_intShow(heff_dup(v_n_2430)));
  V v_m_2432 = heff_tr(heff_call(v_field_2417, 2, (V[]){heff_dup(v_x_2431), v_e_2422}));
  V v_x2_2433 = heff_tr(heff_call(v_m_2432, 1, (V[]){heff_intAdd(v_n_2430, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_n_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_t_2436 = heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){v_x_2434, heff_tag_n(TAG_SVar, 1, (V[]){v_x_2431})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2436, v_n_2435});
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam4(V self, V *args) {
  V v_e_2412 = args[0];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT8 v_t_2413 = (g_heff_2ecompile_2eimperative_2egenOf_24cpr(v_full_240));
  {
    V v_field_2415 = v_t_2413.f[1];
    V v_field_2417 = v_t_2413.f[3];
    heff_drop(v_t_2413.f[0]);
    heff_drop(v_t_2413.f[2]);
    heff_drop(v_t_2413.f[4]);
    heff_drop(v_t_2413.f[5]);
    heff_drop(v_t_2413.f[6]);
    heff_drop(v_t_2413.f[7]);
    V v_e_2422 = v_e_2412;
    V v_t_2423 = (g_heff_2ecompile_2eimperative_2eisSimple(v_e_2422));
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_field_2417);
      heff_drop(v_t_2423);
      V v_m_2424 = heff_tr(heff_call(v_field_2415, 1, (V[]){v_e_2422}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam5, 1, 1, (V[]){v_m_2424});
    } else {
      heff_drop(v_field_2415);
      heff_drop(v_t_2423);
      return heff_clo_n(g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam6, 1, 2, (V[]){v_field_2417, v_e_2422});
    }
  }
}
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam7(V self, V *args) {
  V v_e_2437 = args[0];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2438 = (g_heff_2ecompile_2eimperative_2egenOf(v_full_240));
  return (g_heff_2ecompile_2eimperative_2eopOf(v_t_2438, v_e_2437));
}
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam9(V self, V *args) {
  V v_n_2484 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_2484});
}
V g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam8(V self, V *args) {
  V v_e_2439 = args[0];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_g_2440 = (g_heff_2ecompile_2eimperative_2egenOf(v_full_240));
  V v_e_2441 = v_e_2439;
  V v_t_2442 = heff_dup(heff_rfield(v_g_2440, 0));
  V v_t_2483;
  if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
    heff_drop(v_t_2442);
    v_t_2483 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2442);
    V v_t_2443 = (g_heff_2ecompile_2eimperative_2eisRelCall(v_e_2441));
    if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
      heff_drop(v_t_2443);
      v_t_2483 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_2443);
      switch (heff_tag_of(v_e_2441)) {
      case TAG_EVar: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_2483 = NTAG(TAG_True);
        break;
      }
      case TAG_ESet: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2483 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_2441);
      }
    }
  }
  if ((heff_dup(v_t_2483) == NTAG(TAG_True))) {
    heff_drop(v_t_2483);
    return (g_heff_2ecompile_2eimperative_2epredAny(v_g_2440, v_e_2441));
  } else {
    heff_drop_rec(v_g_2440, 8);
    heff_drop(v_e_2441);
    heff_drop(v_t_2483);
    return ((V)&g_heff_2ecompile_2eimperative_2egenOf_24cpr_lam9_clo);
  }
}
Clo g_heff_2ecompile_2eimperative_2evalNamesTop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2evalNamesTop_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2evalNamesTop(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SVar: {
    V v_x_242 = heff_field(v_x1_240, 0);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_242), v_acc_241});
  }
  case TAG_SGlobal: {
    return v_acc_241;
  }
  case TAG_SInt: {
    return v_acc_241;
  }
  case TAG_SFloat: {
    return v_acc_241;
  }
  case TAG_SStr: {
    return v_acc_241;
  }
  case TAG_SBytes: {
    return v_acc_241;
  }
  case TAG_SFixed: {
    return v_acc_241;
  }
  case TAG_SFloat32: {
    return v_acc_241;
  }
  case TAG_SPrimFn: {
    return v_acc_241;
  }
  case TAG_SLam: {
    return v_acc_241;
  }
  case TAG_STag: {
    V v_args_2415 = heff_field(v_x1_240, 1);
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2415)));
    return ({ V a_0 = v_acc_241; V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_2417); r_; });
  }
  case TAG_SRec: {
    V v_fs_2418 = heff_field(v_x1_240, 0);
    V v_t_2420 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), heff_dup(v_fs_2418)));
    return ({ V a_0 = v_acc_241; V a_1 = v_t_2420; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_2420); r_; });
  }
  case TAG_SProj: {
    V v_v_2421 = heff_field(v_x1_240, 0);
    V t_0 = v_v_2421;
    V t_1 = v_acc_241;
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_SPrim: {
    V v_args_2426 = heff_field(v_x1_240, 1);
    V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2426)));
    return ({ V a_0 = v_acc_241; V a_1 = v_t_2427; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_2427); r_; });
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eimperative_2evalNamesTop_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2evalNamesTop(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eimperative_2eonceSt_24s1868663870x435913689_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eonceSt_24s1868663870x435913689_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2eonceSt_24s1868663870x435913689(V v_st_240) {
top: ;
  switch (heff_tag_of(v_st_240)) {
  case TAG_SLet: {
    V v_x_241 = heff_field(v_st_240, 0);
    V v_o_242 = heff_field(v_st_240, 1);
    V v_ru_24st_240_24SLet = heff_take_reuse_n(v_st_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eimperative_2eonceOp_24s1315731183x405745434(v_o_242));
    return heff_tag_at_n(v_ru_24st_240_24SLet, TAG_SLet, 2, (V[]){v_x_241, v_t_243});
  }
  case TAG_SOnce: {
    V v_x_244 = heff_field(v_st_240, 0);
    V v_o_245 = heff_field(v_st_240, 1);
    V v_ru_24st_240_24SOnce = heff_take_reuse_n(v_st_240, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 1)), 1, (V[]){v_o_245}));
    return heff_tag_at_n(v_ru_24st_240_24SOnce, TAG_SOnce, 2, (V[]){v_x_244, v_t_246});
  }
  case TAG_SDecl: {
    return v_st_240;
  }
  case TAG_SSet: {
    V v_x_248 = heff_field(v_st_240, 0);
    V v_o_249 = heff_field(v_st_240, 1);
    V v_ru_24st_240_24SSet = heff_take_reuse_n(v_st_240, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 1)), 1, (V[]){v_o_249}));
    return heff_tag_at_n(v_ru_24st_240_24SSet, TAG_SSet, 2, (V[]){v_x_248, v_t_2410});
  }
  case TAG_SIf: {
    V v_c_2411 = heff_field(v_st_240, 0);
    V v_ts_2412 = heff_field(v_st_240, 1);
    V v_fs_2413 = heff_field(v_st_240, 2);
    V v_ru_24st_240_24SIf = heff_take_reuse_n(v_st_240, 7ULL, 3);
    V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 2)), 1, (V[]){v_c_2411}));
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 3)), 2, (V[]){v_ts_2412, NTAG(TAG_Nothing)}));
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 3)), 2, (V[]){v_fs_2413, NTAG(TAG_Nothing)}));
    return heff_tag_at_n(v_ru_24st_240_24SIf, TAG_SIf, 3, (V[]){v_t_2414, v_t_2415, v_t_2416});
  }
  case TAG_SCase: {
    V v_v_2417 = heff_field(v_st_240, 0);
    V v_arms_2418 = heff_field(v_st_240, 1);
    V v_ru_24st_240_24SCase = heff_take_reuse_n(v_st_240, 3ULL, 2);
    V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 0)), 1, (V[]){v_v_2417}));
    V v_t_2420 = (g_list_2emap_24s1737386070x1499208753(v_arms_2418));
    return heff_tag_at_n(v_ru_24st_240_24SCase, TAG_SCase, 2, (V[]){v_t_2419, v_t_2420});
  }
  default: return heff_nomatch(v_st_240);
  }
}
V g_heff_2ecompile_2eimperative_2eonceSt_24s1868663870x435913689_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eonceSt_24s1868663870x435913689(a[0]);
}
Clo g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070(V v_x2_240, V v_after_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_after_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_240, 0);
    V v_rest_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SLet: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_o_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24SLet = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_246 = (g_heff_2ecompile_2eimperative_2einlinable(v_x_244, v_o_245, heff_dup(v_rest_243), v_after_241));
      V v_t_249;
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x21_242_24SLet, 2);
        heff_drop(v_t_246);
        V v_t_247 = (g_heff_2ecompile_2eimperative_2eonceOp_24s1315731183x405745434(v_o_245));
        v_t_249 = heff_tag_n(TAG_SOnce, 2, (V[]){v_x_244, v_t_247});
      } else {
        heff_drop(v_t_246);
        V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 1)), 1, (V[]){v_o_245}));
        v_t_249 = heff_tag_at_n(v_ru_24x21_242_24SLet, TAG_SLet, 2, (V[]){v_x_244, v_t_248});
      }
      V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 3)), 2, (V[]){v_rest_243, v_after_241}));
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2410});
    }
    case TAG_SOnce: {
      V v_t_2413 = (g_heff_2ecompile_2eimperative_2eonceSt_24s1868663870x435913689(v_x21_242));
      V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 3)), 2, (V[]){v_rest_243, v_after_241}));
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2413, v_t_2414});
    }
    case TAG_SDecl: {
      V v_t_2416 = (g_heff_2ecompile_2eimperative_2eonceSt_24s1868663870x435913689(v_x21_242));
      V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 3)), 2, (V[]){v_rest_243, v_after_241}));
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2416, v_t_2417});
    }
    case TAG_SSet: {
      V v_t_2420 = (g_heff_2ecompile_2eimperative_2eonceSt_24s1868663870x435913689(v_x21_242));
      V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 3)), 2, (V[]){v_rest_243, v_after_241}));
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2420, v_t_2421});
    }
    case TAG_SIf: {
      V v_t_2425 = (g_heff_2ecompile_2eimperative_2eonceSt_24s1868663870x435913689(v_x21_242));
      V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 3)), 2, (V[]){v_rest_243, v_after_241}));
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2425, v_t_2426});
    }
    case TAG_SCase: {
      V v_t_2429 = (g_heff_2ecompile_2eimperative_2eonceSt_24s1868663870x435913689(v_x21_242));
      V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 3)), 2, (V[]){v_rest_243, v_after_241}));
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2429, v_t_2430});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070(a[0], a[1]);
}
Clo g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24tok1_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24tok1(V v_tok_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_SDecl, 1, (V[]){v_lit_241}), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_st_243 = heff_field(v_x2_242, 0);
    V v_x22_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_x22_244)) {
    case TAG_Nil: {
      V v_t_245 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_st_243, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_SDecl, 1, (V[]){v_lit_241}), v_t_245});
    }
    case TAG_Cons: {
      heff_drop_cell(v_tok_240, 1);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_st_243, heff_hole()});
      V v_u_249 = (g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24dps(v_lit_241, v_x22_244, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_x22_244);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24tok1(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2(V v_tok_240, V v_o_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_o_241)) {
  case TAG_OSimple: {
    V v_v_243 = heff_dup(heff_field(v_o_241, 0));
    V v_t_244 = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(v_v_243, v_acc_242));
    return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_244});
  }
  case TAG_OCall: {
    V v_args_246 = heff_dup(heff_field(v_o_241, 1));
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_246));
    V v_t_248 = ({ V a_0 = v_acc_242; V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_247); r_; });
    return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_248});
  }
  case TAG_OApply: {
    V v_f_249 = heff_dup(heff_field(v_o_241, 0));
    V v_args_2410 = heff_dup(heff_field(v_o_241, 1));
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_f_249, v_args_2410})));
    V v_t_2412 = ({ V a_0 = v_acc_242; V a_1 = v_t_2411; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2411); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_2412});
  }
  case TAG_OPrim: {
    V v_args_2414 = heff_dup(heff_field(v_o_241, 1));
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2414));
    V v_t_2416 = ({ V a_0 = v_acc_242; V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2415); r_; });
    return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_2416});
  }
  case TAG_OAbandon: {
    return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_acc_242});
  }
  case TAG_OBool: {
    V v_c_2417 = heff_dup(heff_field(v_o_241, 0));
    V v_t_2418 = ({ V a_0 = v_c_2417; V a_1 = v_acc_242; V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(a_0, a_1)); heff_drop(v_c_2417); r_; });
    return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_2418});
  }
  default: return heff_nomatch(v_o_241);
  }
}
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2(a[0], a[1], a[2]);
}