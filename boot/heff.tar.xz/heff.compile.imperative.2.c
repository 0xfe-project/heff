// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DSets 40405
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PartOp 18051
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define LBL_bindTo 558176963
#define LBL_cond 9554921
#define LBL_full 9650006
#define LBL_simple 1044855005
#define LBL_sts 323756
#define LBL_toDest 1077793512
#define LBL_val 326043
HeffT2 g_heff_2ecompile_2eimperative_2earmNamed_24cpr(V, V);
V g_heff_2ecompile_2eimperative_2eatomOf(V, V);
V g_heff_2ecompile_2eimperative_2eatomOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eatomOf_clo;
V g_heff_2ecompile_2eimperative_2edeclsBefore(V, V);
V g_heff_2ecompile_2eimperative_2edeclsBefore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2edeclsBefore_clo;
V g_heff_2ecompile_2eimperative_2eisRelCall(V);
V g_heff_2ecompile_2eimperative_2eisRelCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eisRelCall_clo;
V g_heff_2ecompile_2eimperative_2eisSimple(V);
V g_heff_2ecompile_2eimperative_2eisSimple_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eisSimple_clo;
V g_heff_2ecompile_2eimperative_2ematchSet(V, V, V, V);
V g_heff_2ecompile_2eimperative_2ematchSet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2ematchSet_clo;
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(V, V);
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_clo;
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(V, V);
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_clo;
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2_clo;
V g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233(V, V);
V g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_clo;
V g_heff_2ecompile_2eimperative_2epk_get(void);
V g_heff_2ecompile_2eimperative_2epredAny(V, V);
V g_heff_2ecompile_2eimperative_2epredAny_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epredAny_clo;
V g_heff_2ecompile_2eimperative_2epredOf(V, V);
V g_heff_2ecompile_2eimperative_2epredOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epredOf_clo;
V g_heff_2ecompile_2eimperative_2esetsOf(V, V, V);
V g_heff_2ecompile_2eimperative_2esetsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2esetsOf_clo;
V g_heff_2ecompile_2eimperative_2estmtsParts(V);
V g_heff_2ecompile_2eimperative_2estmtsParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2estmtsParts_clo;
V g_heff_2ecompile_2eimperative_2evalNamesTop(V, V);
V g_heff_2ecompile_2eimperative_2evalNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2evalNamesTop_clo;
V g_heff_2ecompile_2eir_2eisRel(V);
V g_heff_2ecompile_2eir_2eisRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisRel_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24s1318914558x1386196507(V, V);
V g_list_2efoldl_24s1318914558x1386196507_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1318914558x1386196507_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1735038056x329845490(V, V);
V g_list_2efoldl_24s1735038056x329845490_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1735038056x329845490_clo;
V g_list_2efoldl_24s2003609603x1707519208(V, V);
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2003609603x1707519208_clo;
V g_list_2efoldl_24s634927308x1347712163(V, V);
V g_list_2efoldl_24s634927308x1347712163_entry(V self, V *a);
extern Clo g_list_2efoldl_24s634927308x1347712163_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f339900781x1605227681(V, V);
V g_prelude_2e_2b_2b_24f339900781x1605227681_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f339900781x1605227681_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2etraverse_24s251316015x352006831(V, V);
V g_prelude_2etraverse_24s251316015x352006831_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s251316015x352006831_clo;

HeffT2 g_heff_2ecompile_2eimperative_2earmNamed_24cpr(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t2_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      if (heff_strEq_c_lent(v_t2_244, v_t_240, 1)) {
        switch (heff_tag_of(v_vs_245)) {
        case TAG_Nil: {
          heff_drop(v_rest_243);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_b_246}});
        }
        case TAG_Cons: {
          heff_take_n(v_vs_245, 0ULL, 2);
          heff_drop(v_b_246);
          V t_0 = v_t_240;
          V t_1 = v_rest_243;
          v_t_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return ((HeffT2){{heff_nomatch(v_vs_245)}});
        }
      } else {
        heff_drop(v_vs_245);
        heff_drop(v_b_246);
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2eimperative_2eisRelCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eisRelCall_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2eisRelCall(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2422 = heff_field(v_e_240, 0);
    V v_e2_2423 = heff_field(v_e_240, 1);
    switch (heff_tag_of(v_e2_2423)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_e22_2425 = heff_field(v_e2_2423, 1);
      switch (heff_tag_of(v_e22_2425)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_e222_2427 = heff_field(v_e22_2425, 1);
        switch (heff_tag_of(v_e222_2427)) {
        case TAG_Nil: {
          HEFF_LAST return g_heff_2ecompile_2eir_2eisRel(v_p_2422);
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_e222_2427);
        }
      }
      default: return heff_nomatch(v_e22_2425);
      }
    }
    default: return heff_nomatch(v_e2_2423);
    }
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eimperative_2eisRelCall_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2eisRelCall(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eimperative_2epredOf_lam0(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epredOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epredOf_lam0, 1, 0};
Clo g_heff_2ecompile_2eimperative_2epredOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epredOf_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epredOf(V v_g_240, V v_e_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_g_240, 0));
  V v_t_2443;
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    v_t_2443 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_242);
    V v_t_243 = (g_heff_2ecompile_2eimperative_2eisRelCall(v_e_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      v_t_2443 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EVar: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_ESet: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_241);
      }
    }
  }
  if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
    heff_drop(v_t_2443);
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredAny(v_g_240, v_e_241);
  } else {
    heff_drop_rec(v_g_240, 8);
    heff_drop(v_e_241);
    heff_drop(v_t_2443);
    return ((V)&g_heff_2ecompile_2eimperative_2epredOf_lam0_clo);
  }
}
V g_heff_2ecompile_2eimperative_2epredOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epredOf(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2epredOf_lam0(V self, V *args) {
  V v_n_2444 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_2444});
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2eatomOf_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2eatomOf_str1, 1, "t");
V g_heff_2ecompile_2eimperative_2eatomOf_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2eatomOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2eatomOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eatomOf_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2eatomOf(V v_g_240, V v_e_241) {
top: ;
  V v_simple_242 = heff_take_field(v_g_240, 1);
  V v_bindTo_243 = heff_get_n(v_g_240, 3, 8);
  V v_t_244 = (g_heff_2ecompile_2eimperative_2eisSimple(v_e_241));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_bindTo_243);
    heff_drop(v_t_244);
    V v_m_245 = heff_tr(heff_call(v_simple_242, 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eatomOf_lam0, 1, 1, (V[]){v_m_245});
  } else {
    heff_drop(v_simple_242);
    heff_drop(v_t_244);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eatomOf_lam1, 1, 2, (V[]){v_bindTo_243, v_e_241});
  }
}
V g_heff_2ecompile_2eimperative_2eatomOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eatomOf(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2eatomOf_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_x_248});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_n_249});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2eimperative_2eatomOf_lam1(V self, V *args) {
  V v_n_2411 = args[0];
  V v_bindTo_243 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2eatomOf_str0), heff_intShow(heff_dup(v_n_2411)));
  V v_x_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2eatomOf_str1), v_t_2412);
  V v_m_2414 = heff_tr(heff_call(v_bindTo_243, 2, (V[]){heff_dup(v_x_2413), v_e_241}));
  V v_x2_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){heff_intAdd(v_n_2411, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    V v_t_2418 = heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){v_x_2416, heff_tag_n(TAG_SVar, 1, (V[]){v_x_2413})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, v_n_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam3(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam4(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam5(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam6(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam7(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam8(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam9(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam10(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam11(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam12(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam13(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam14(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam15(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam16(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam17(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam18(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam19(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam20(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam21(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam22(V self, V *args);
V g_heff_2ecompile_2eimperative_2esetsOf_lam23(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2esetsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esetsOf_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2esetsOf(V v_g_240, V v_xs_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_m_244 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam0, 1, 2, (V[]){v_m_244, v_xs_241});
  }
  case TAG_EGlobal: {
    V v_m_2411 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam1, 1, 2, (V[]){v_m_2411, v_xs_241});
  }
  case TAG_ELam: {
    V v_m_2419 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam2, 1, 2, (V[]){v_m_2419, v_xs_241});
  }
  case TAG_EApp: {
    V v_m_2427 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam3, 1, 2, (V[]){v_m_2427, v_xs_241});
  }
  case TAG_ELet: {
    V v_y_2433 = heff_field(v_e_242, 0);
    V v_a_2434 = heff_field(v_e_242, 1);
    V v_b_2435 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2436 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 3)), 2, (V[]){v_y_2433, v_a_2434}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam4, 1, 4, (V[]){v_m_2436, v_g_240, v_xs_241, v_b_2435});
  }
  case TAG_ERecord: {
    V v_m_2448 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam5, 1, 2, (V[]){v_m_2448, v_xs_241});
  }
  case TAG_EProj: {
    V v_m_2458 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam6, 1, 2, (V[]){v_m_2458, v_xs_241});
  }
  case TAG_ETag: {
    V v_m_2467 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam7, 1, 2, (V[]){v_m_2467, v_xs_241});
  }
  case TAG_EMatch: {
    V v_s_2473 = heff_field(v_e_242, 0);
    V v_arms_2474 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2475 = (g_heff_2ecompile_2eimperative_2ematchSet(v_g_240, heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_s_2473, v_arms_2474));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam8, 1, 2, (V[]){v_m_2475, v_xs_241});
  }
  case TAG_EPrim: {
    V v_m_2482 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam9, 1, 2, (V[]){v_m_2482, v_xs_241});
  }
  case TAG_EPrimCall: {
    V v_m_2490 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam10, 1, 2, (V[]){v_m_2490, v_xs_241});
  }
  case TAG_ECall: {
    V v_m_2498 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam11, 1, 2, (V[]){v_m_2498, v_xs_241});
  }
  case TAG_EInt: {
    V v_m_24105 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam12, 1, 2, (V[]){v_m_24105, v_xs_241});
  }
  case TAG_EFloat: {
    V v_m_24112 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam13, 1, 2, (V[]){v_m_24112, v_xs_241});
  }
  case TAG_EStr: {
    V v_m_24119 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam14, 1, 2, (V[]){v_m_24119, v_xs_241});
  }
  case TAG_EBytes: {
    V v_m_24126 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam15, 1, 2, (V[]){v_m_24126, v_xs_241});
  }
  case TAG_EFixed: {
    V v_m_24134 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam16, 1, 2, (V[]){v_m_24134, v_xs_241});
  }
  case TAG_EFloat32: {
    V v_m_24141 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam17, 1, 2, (V[]){v_m_24141, v_xs_241});
  }
  case TAG_EAbandon: {
    V v_m_24147 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam18, 1, 2, (V[]){v_m_24147, v_xs_241});
  }
  case TAG_EBool: {
    V v_m_24154 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam19, 1, 2, (V[]){v_m_24154, v_xs_241});
  }
  case TAG_ESet: {
    V v_ys_24160 = heff_field(v_e_242, 0);
    V v_a_24161 = heff_field(v_e_242, 1);
    V v_b_24162 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_24163 = (g_heff_2ecompile_2eimperative_2esetsOf(heff_dup(v_g_240), v_ys_24160, v_a_24161));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam20, 1, 4, (V[]){v_m_24163, v_g_240, v_xs_241, v_b_24162});
  }
  case TAG_EValues: {
    V v_es_24173 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_t_24174 = (g_list_2ezipWith_24s1876717925x1404326288(v_xs_241, v_es_24173));
    V v_m_24182 = (g_prelude_2etraverse_24s251316015x352006831(heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam21, 1, 1, (V[]){v_g_240}), v_t_24174));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam22, 1, 1, (V[]){v_m_24182});
  }
  case TAG_EFix: {
    V v_m_24191 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){heff_tag_n(TAG_DSets, 1, (V[]){heff_dup(v_xs_241)}), v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esetsOf_lam23, 1, 2, (V[]){v_m_24191, v_xs_241});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2esetsOf(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_x_249 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_247, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_249, v_n_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam1(V self, V *args) {
  V v_n_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_n_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_x_2416 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_2414, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_x_2416, v_n_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam2(V self, V *args) {
  V v_n_2420 = args[0];
  V v_m_2419 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2421 = heff_tr(heff_call(v_m_2419, 1, (V[]){v_n_2420}));
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_n_2423 = heff_field(v_x2_2421, 1);
    V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
    V v_x_2424 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_2422, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_2421_24MkPair, TAG_MkPair, 2, (V[]){v_x_2424, v_n_2423});
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam3(V self, V *args) {
  V v_n_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2429 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_n_2428}));
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_MkPair: {
    V v_x_2430 = heff_field(v_x2_2429, 0);
    V v_n_2431 = heff_field(v_x2_2429, 1);
    V v_ru_24x2_2429_24MkPair = heff_take_reuse_n(v_x2_2429, 3ULL, 2);
    V v_x_2432 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_2430, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_2429_24MkPair, TAG_MkPair, 2, (V[]){v_x_2432, v_n_2431});
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam4(V self, V *args) {
  V v_n_2437 = args[0];
  V v_m_2436 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_xs_241 = heff_env(self)[2];
  V v_b_2435 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2438 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_n_2437}));
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkPair: {
    V v_x_2439 = heff_field(v_x2_2438, 0);
    V v_n_2440 = heff_field(v_x2_2438, 1);
    V v_ru_24x2_2438_24MkPair = heff_take_reuse_n(v_x2_2438, 3ULL, 2);
    V v_m_2441 = (g_heff_2ecompile_2eimperative_2esetsOf(v_g_240, v_xs_241, v_b_2435));
    V v_x2_2442 = heff_tr(heff_call(v_m_2441, 1, (V[]){v_n_2440}));
    switch (heff_tag_of(v_x2_2442)) {
    case TAG_MkPair: {
      V v_x_2443 = heff_field(v_x2_2442, 0);
      V v_n_2444 = heff_field(v_x2_2442, 1);
      V v_ru_24x2_2442_24MkPair = heff_take_reuse_n(v_x2_2442, 3ULL, 2);
      V v_x_2445 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_2442_24MkPair, v_x_2439, v_x_2443));
      return heff_tag_at_n(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, (V[]){v_x_2445, v_n_2444});
    }
    default: return heff_nomatch(v_x2_2442);
    }
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam5(V self, V *args) {
  V v_n_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_n_2449}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_n_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    V v_x_2453 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_2451, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){v_x_2453, v_n_2452});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam6(V self, V *args) {
  V v_n_2459 = args[0];
  V v_m_2458 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2460 = heff_tr(heff_call(v_m_2458, 1, (V[]){v_n_2459}));
  switch (heff_tag_of(v_x2_2460)) {
  case TAG_MkPair: {
    V v_x_2461 = heff_field(v_x2_2460, 0);
    V v_n_2462 = heff_field(v_x2_2460, 1);
    V v_ru_24x2_2460_24MkPair = heff_take_reuse_n(v_x2_2460, 3ULL, 2);
    V v_x_2463 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_2461, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_2460_24MkPair, TAG_MkPair, 2, (V[]){v_x_2463, v_n_2462});
  }
  default: return heff_nomatch(v_x2_2460);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam7(V self, V *args) {
  V v_n_2468 = args[0];
  V v_m_2467 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2469 = heff_tr(heff_call(v_m_2467, 1, (V[]){v_n_2468}));
  switch (heff_tag_of(v_x2_2469)) {
  case TAG_MkPair: {
    V v_x_2470 = heff_field(v_x2_2469, 0);
    V v_n_2471 = heff_field(v_x2_2469, 1);
    V v_ru_24x2_2469_24MkPair = heff_take_reuse_n(v_x2_2469, 3ULL, 2);
    V v_x_2472 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_2470, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_2469_24MkPair, TAG_MkPair, 2, (V[]){v_x_2472, v_n_2471});
  }
  default: return heff_nomatch(v_x2_2469);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam8(V self, V *args) {
  V v_n_2476 = args[0];
  V v_m_2475 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2477 = heff_tr(heff_call(v_m_2475, 1, (V[]){v_n_2476}));
  switch (heff_tag_of(v_x2_2477)) {
  case TAG_MkPair: {
    V v_x_2478 = heff_field(v_x2_2477, 0);
    V v_n_2479 = heff_field(v_x2_2477, 1);
    V v_ru_24x2_2477_24MkPair = heff_take_reuse_n(v_x2_2477, 3ULL, 2);
    V v_x_2480 = (g_heff_2ecompile_2eimperative_2edeclsBefore(v_xs_241, v_x_2478));
    return heff_tag_at_n(v_ru_24x2_2477_24MkPair, TAG_MkPair, 2, (V[]){v_x_2480, v_n_2479});
  }
  default: return heff_nomatch(v_x2_2477);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam9(V self, V *args) {
  V v_n_2483 = args[0];
  V v_m_2482 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2484 = heff_tr(heff_call(v_m_2482, 1, (V[]){v_n_2483}));
  switch (heff_tag_of(v_x2_2484)) {
  case TAG_MkPair: {
    V v_x_2485 = heff_field(v_x2_2484, 0);
    V v_n_2486 = heff_field(v_x2_2484, 1);
    V v_ru_24x2_2484_24MkPair = heff_take_reuse_n(v_x2_2484, 3ULL, 2);
    V v_x_2487 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_2485, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_2484_24MkPair, TAG_MkPair, 2, (V[]){v_x_2487, v_n_2486});
  }
  default: return heff_nomatch(v_x2_2484);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam10(V self, V *args) {
  V v_n_2491 = args[0];
  V v_m_2490 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2492 = heff_tr(heff_call(v_m_2490, 1, (V[]){v_n_2491}));
  switch (heff_tag_of(v_x2_2492)) {
  case TAG_MkPair: {
    V v_x_2493 = heff_field(v_x2_2492, 0);
    V v_n_2494 = heff_field(v_x2_2492, 1);
    V v_ru_24x2_2492_24MkPair = heff_take_reuse_n(v_x2_2492, 3ULL, 2);
    V v_x_2495 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_2493, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_2492_24MkPair, TAG_MkPair, 2, (V[]){v_x_2495, v_n_2494});
  }
  default: return heff_nomatch(v_x2_2492);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam11(V self, V *args) {
  V v_n_2499 = args[0];
  V v_m_2498 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24100 = heff_tr(heff_call(v_m_2498, 1, (V[]){v_n_2499}));
  switch (heff_tag_of(v_x2_24100)) {
  case TAG_MkPair: {
    V v_x_24101 = heff_field(v_x2_24100, 0);
    V v_n_24102 = heff_field(v_x2_24100, 1);
    V v_ru_24x2_24100_24MkPair = heff_take_reuse_n(v_x2_24100, 3ULL, 2);
    V v_x_24103 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_24101, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_24100_24MkPair, TAG_MkPair, 2, (V[]){v_x_24103, v_n_24102});
  }
  default: return heff_nomatch(v_x2_24100);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam12(V self, V *args) {
  V v_n_24106 = args[0];
  V v_m_24105 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24107 = heff_tr(heff_call(v_m_24105, 1, (V[]){v_n_24106}));
  switch (heff_tag_of(v_x2_24107)) {
  case TAG_MkPair: {
    V v_x_24108 = heff_field(v_x2_24107, 0);
    V v_n_24109 = heff_field(v_x2_24107, 1);
    V v_ru_24x2_24107_24MkPair = heff_take_reuse_n(v_x2_24107, 3ULL, 2);
    V v_x_24110 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_24108, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_24107_24MkPair, TAG_MkPair, 2, (V[]){v_x_24110, v_n_24109});
  }
  default: return heff_nomatch(v_x2_24107);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam13(V self, V *args) {
  V v_n_24113 = args[0];
  V v_m_24112 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24114 = heff_tr(heff_call(v_m_24112, 1, (V[]){v_n_24113}));
  switch (heff_tag_of(v_x2_24114)) {
  case TAG_MkPair: {
    V v_x_24115 = heff_field(v_x2_24114, 0);
    V v_n_24116 = heff_field(v_x2_24114, 1);
    V v_ru_24x2_24114_24MkPair = heff_take_reuse_n(v_x2_24114, 3ULL, 2);
    V v_x_24117 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_24115, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_24114_24MkPair, TAG_MkPair, 2, (V[]){v_x_24117, v_n_24116});
  }
  default: return heff_nomatch(v_x2_24114);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam14(V self, V *args) {
  V v_n_24120 = args[0];
  V v_m_24119 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24121 = heff_tr(heff_call(v_m_24119, 1, (V[]){v_n_24120}));
  switch (heff_tag_of(v_x2_24121)) {
  case TAG_MkPair: {
    V v_x_24122 = heff_field(v_x2_24121, 0);
    V v_n_24123 = heff_field(v_x2_24121, 1);
    V v_ru_24x2_24121_24MkPair = heff_take_reuse_n(v_x2_24121, 3ULL, 2);
    V v_x_24124 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_24122, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_24121_24MkPair, TAG_MkPair, 2, (V[]){v_x_24124, v_n_24123});
  }
  default: return heff_nomatch(v_x2_24121);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam15(V self, V *args) {
  V v_n_24127 = args[0];
  V v_m_24126 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24128 = heff_tr(heff_call(v_m_24126, 1, (V[]){v_n_24127}));
  switch (heff_tag_of(v_x2_24128)) {
  case TAG_MkPair: {
    V v_x_24129 = heff_field(v_x2_24128, 0);
    V v_n_24130 = heff_field(v_x2_24128, 1);
    V v_ru_24x2_24128_24MkPair = heff_take_reuse_n(v_x2_24128, 3ULL, 2);
    V v_x_24131 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_24129, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_24128_24MkPair, TAG_MkPair, 2, (V[]){v_x_24131, v_n_24130});
  }
  default: return heff_nomatch(v_x2_24128);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam16(V self, V *args) {
  V v_n_24135 = args[0];
  V v_m_24134 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24136 = heff_tr(heff_call(v_m_24134, 1, (V[]){v_n_24135}));
  switch (heff_tag_of(v_x2_24136)) {
  case TAG_MkPair: {
    V v_x_24137 = heff_field(v_x2_24136, 0);
    V v_n_24138 = heff_field(v_x2_24136, 1);
    V v_ru_24x2_24136_24MkPair = heff_take_reuse_n(v_x2_24136, 3ULL, 2);
    V v_x_24139 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_24137, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_24136_24MkPair, TAG_MkPair, 2, (V[]){v_x_24139, v_n_24138});
  }
  default: return heff_nomatch(v_x2_24136);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam17(V self, V *args) {
  V v_n_24142 = args[0];
  V v_m_24141 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24143 = heff_tr(heff_call(v_m_24141, 1, (V[]){v_n_24142}));
  switch (heff_tag_of(v_x2_24143)) {
  case TAG_MkPair: {
    V v_x_24144 = heff_field(v_x2_24143, 0);
    V v_n_24145 = heff_field(v_x2_24143, 1);
    V v_ru_24x2_24143_24MkPair = heff_take_reuse_n(v_x2_24143, 3ULL, 2);
    V v_x_24146 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_24144, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_24143_24MkPair, TAG_MkPair, 2, (V[]){v_x_24146, v_n_24145});
  }
  default: return heff_nomatch(v_x2_24143);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam18(V self, V *args) {
  V v_n_24148 = args[0];
  V v_m_24147 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24149 = heff_tr(heff_call(v_m_24147, 1, (V[]){v_n_24148}));
  switch (heff_tag_of(v_x2_24149)) {
  case TAG_MkPair: {
    V v_x_24150 = heff_field(v_x2_24149, 0);
    V v_n_24151 = heff_field(v_x2_24149, 1);
    V v_ru_24x2_24149_24MkPair = heff_take_reuse_n(v_x2_24149, 3ULL, 2);
    V v_x_24152 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_24150, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_24149_24MkPair, TAG_MkPair, 2, (V[]){v_x_24152, v_n_24151});
  }
  default: return heff_nomatch(v_x2_24149);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam19(V self, V *args) {
  V v_n_24155 = args[0];
  V v_m_24154 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24156 = heff_tr(heff_call(v_m_24154, 1, (V[]){v_n_24155}));
  switch (heff_tag_of(v_x2_24156)) {
  case TAG_MkPair: {
    V v_x_24157 = heff_field(v_x2_24156, 0);
    V v_n_24158 = heff_field(v_x2_24156, 1);
    V v_ru_24x2_24156_24MkPair = heff_take_reuse_n(v_x2_24156, 3ULL, 2);
    V v_x_24159 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_24157, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_24156_24MkPair, TAG_MkPair, 2, (V[]){v_x_24159, v_n_24158});
  }
  default: return heff_nomatch(v_x2_24156);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam20(V self, V *args) {
  V v_n_24164 = args[0];
  V v_m_24163 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_xs_241 = heff_env(self)[2];
  V v_b_24162 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24165 = heff_tr(heff_call(v_m_24163, 1, (V[]){v_n_24164}));
  switch (heff_tag_of(v_x2_24165)) {
  case TAG_MkPair: {
    V v_x_24166 = heff_field(v_x2_24165, 0);
    V v_n_24167 = heff_field(v_x2_24165, 1);
    V v_ru_24x2_24165_24MkPair = heff_take_reuse_n(v_x2_24165, 3ULL, 2);
    V v_m_24168 = (g_heff_2ecompile_2eimperative_2esetsOf(v_g_240, v_xs_241, v_b_24162));
    V v_x2_24169 = heff_tr(heff_call(v_m_24168, 1, (V[]){v_n_24167}));
    switch (heff_tag_of(v_x2_24169)) {
    case TAG_MkPair: {
      V v_x_24170 = heff_field(v_x2_24169, 0);
      V v_n_24171 = heff_field(v_x2_24169, 1);
      V v_ru_24x2_24169_24MkPair = heff_take_reuse_n(v_x2_24169, 3ULL, 2);
      V v_x_24172 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_24169_24MkPair, v_x_24166, v_x_24170));
      return heff_tag_at_n(v_ru_24x2_24165_24MkPair, TAG_MkPair, 2, (V[]){v_x_24172, v_n_24171});
    }
    default: return heff_nomatch(v_x2_24169);
    }
  }
  default: return heff_nomatch(v_x2_24165);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam21(V self, V *args) {
  V v_p_24175 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24178;
  switch (heff_tag_of(v_p_24175)) {
  case TAG_MkPair: {
    V v_x_24176 = heff_dup(heff_field(v_p_24175, 0));
    v_t_24178 = v_x_24176;
    break;
  }
  default: heff_nomatch(v_p_24175);
  }
  V v_t_24181;
  switch (heff_tag_of(v_p_24175)) {
  case TAG_MkPair: {
    V v_y_24180 = heff_field(v_p_24175, 1);
    heff_take_n(v_p_24175, 2ULL, 2);
    v_t_24181 = v_y_24180;
    break;
  }
  default: heff_nomatch(v_p_24175);
  }
  V f_ = heff_get_n(v_g_240, 3, 8);
  heff_room[0] = v_t_24178;
  heff_room[1] = v_t_24181;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam22(V self, V *args) {
  V v_n_24183 = args[0];
  V v_m_24182 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24184 = heff_tr(heff_call(v_m_24182, 1, (V[]){v_n_24183}));
  switch (heff_tag_of(v_x2_24184)) {
  case TAG_MkPair: {
    V v_x_24185 = heff_field(v_x2_24184, 0);
    V v_n_24186 = heff_field(v_x2_24184, 1);
    V v_ru_24x2_24184_24MkPair = heff_take_reuse_n(v_x2_24184, 3ULL, 2);
    V v_t_24187 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_24185));
    V v_x_24188 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24187; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_24187); r_; });
    return heff_tag_at_n(v_ru_24x2_24184_24MkPair, TAG_MkPair, 2, (V[]){v_x_24188, v_n_24186});
  }
  default: return heff_nomatch(v_x2_24184);
  }
}
V g_heff_2ecompile_2eimperative_2esetsOf_lam23(V self, V *args) {
  V v_n_24192 = args[0];
  V v_m_24191 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24193 = heff_tr(heff_call(v_m_24191, 1, (V[]){v_n_24192}));
  switch (heff_tag_of(v_x2_24193)) {
  case TAG_MkPair: {
    V v_x_24194 = heff_field(v_x2_24193, 0);
    V v_n_24195 = heff_field(v_x2_24193, 1);
    V v_ru_24x2_24193_24MkPair = heff_take_reuse_n(v_x2_24193, 3ULL, 2);
    V v_x_24196 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_x_24194, v_xs_241));
    return heff_tag_at_n(v_ru_24x2_24193_24MkPair, TAG_MkPair, 2, (V[]){v_x_24196, v_n_24195});
  }
  default: return heff_nomatch(v_x2_24193);
  }
}
Clo g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SLet: {
    V v_o_243 = heff_field(v_x2_240, 1);
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(heff_dup(v_o_243), v_acc_241);
  }
  case TAG_SDecl: {
    return v_acc_241;
  }
  case TAG_SSet: {
    V v_o_246 = heff_field(v_x2_240, 1);
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(heff_dup(v_o_246), v_acc_241);
  }
  case TAG_SIf: {
    V v_c_247 = heff_field(v_x2_240, 0);
    V v_ts_248 = heff_field(v_x2_240, 1);
    V v_fs_249 = heff_field(v_x2_240, 2);
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_249)));
    V v_t_2411 = ({ V a_0 = v_acc_241; V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_2410); r_; });
    V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 3)), 2, (V[]){heff_dup(v_ts_248), v_t_2411}));
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_c_247), v_t_2412});
  }
  case TAG_SCase: {
    V v_v_2413 = heff_field(v_x2_240, 0);
    V v_arms_2414 = heff_field(v_x2_240, 1);
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2414)));
    V v_t_2416 = ({ V a_0 = v_acc_241; V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s1318914558x1386196507(a_0, a_1)); heff_drop(v_t_2415); r_; });
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 0)), 2, (V[]){heff_dup(v_v_2413), v_t_2416});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eimperative_2estmtsParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2estmtsParts_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2estmtsParts(V v_ss_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ss_240));
  return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_241; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_241); r_; });
}
V g_heff_2ecompile_2eimperative_2estmtsParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2estmtsParts(a[0]);
}
Clo g_heff_2ecompile_2eimperative_2evalNamesTop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2evalNamesTop_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2evalNamesTop(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SVar: {
    V v_x_242 = heff_field(v_x1_240, 0);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_242), v_acc_241});
  }
  case TAG_SGlobal: {
    return v_acc_241;
  }
  case TAG_SInt: {
    return v_acc_241;
  }
  case TAG_SFloat: {
    return v_acc_241;
  }
  case TAG_SStr: {
    return v_acc_241;
  }
  case TAG_SBytes: {
    return v_acc_241;
  }
  case TAG_SFixed: {
    return v_acc_241;
  }
  case TAG_SFloat32: {
    return v_acc_241;
  }
  case TAG_SPrimFn: {
    return v_acc_241;
  }
  case TAG_SLam: {
    return v_acc_241;
  }
  case TAG_STag: {
    V v_args_2415 = heff_field(v_x1_240, 1);
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2415)));
    return ({ V a_0 = v_acc_241; V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_2417); r_; });
  }
  case TAG_SRec: {
    V v_fs_2418 = heff_field(v_x1_240, 0);
    V v_t_2420 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), heff_dup(v_fs_2418)));
    return ({ V a_0 = v_acc_241; V a_1 = v_t_2420; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_2420); r_; });
  }
  case TAG_SProj: {
    V v_v_2421 = heff_field(v_x1_240, 0);
    V t_0 = v_v_2421;
    V t_1 = v_acc_241;
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_SPrim: {
    V v_args_2426 = heff_field(v_x1_240, 1);
    V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2426)));
    return ({ V a_0 = v_acc_241; V a_1 = v_t_2427; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_2427); r_; });
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eimperative_2evalNamesTop_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2evalNamesTop(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2(V v_tok_240, V v_o_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_o_241)) {
  case TAG_OSimple: {
    V v_v_243 = heff_dup(heff_field(v_o_241, 0));
    V v_t_244 = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(v_v_243, v_acc_242));
    return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_244});
  }
  case TAG_OCall: {
    V v_args_246 = heff_dup(heff_field(v_o_241, 1));
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_246));
    V v_t_248 = ({ V a_0 = v_acc_242; V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_247); r_; });
    return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_248});
  }
  case TAG_OApply: {
    V v_f_249 = heff_dup(heff_field(v_o_241, 0));
    V v_args_2410 = heff_dup(heff_field(v_o_241, 1));
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_f_249, v_args_2410})));
    V v_t_2412 = ({ V a_0 = v_acc_242; V a_1 = v_t_2411; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2411); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_2412});
  }
  case TAG_OPrim: {
    V v_args_2414 = heff_dup(heff_field(v_o_241, 1));
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2414));
    V v_t_2416 = ({ V a_0 = v_acc_242; V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2415); r_; });
    return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_2416});
  }
  case TAG_OAbandon: {
    return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_acc_242});
  }
  case TAG_OBool: {
    V v_c_2417 = heff_dup(heff_field(v_o_241, 0));
    V v_t_2418 = ({ V a_0 = v_c_2417; V a_1 = v_acc_242; V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(a_0, a_1)); heff_drop(v_c_2417); r_; });
    return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_2418});
  }
  default: return heff_nomatch(v_o_241);
  }
}
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2(a[0], a[1], a[2]);
}