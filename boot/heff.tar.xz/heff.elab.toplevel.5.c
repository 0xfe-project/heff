// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgEvidence 24309
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_ELam 43266
#define TAG_HError 21467
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_LNil 57394
#define TAG_LamName 56383
#define TAG_Left 13886
#define TAG_MkFieldPat 14710
#define TAG_MkSyn 7342
#define TAG_N 306
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define LBL_body 9524841
#define LBL_broken 566525696
#define LBL_diags 296935042
#define LBL_el 9998
#define LBL_end 310101
#define LBL_entry 298026124
#define LBL_failed 665164648
#define LBL_globals 352931696
#define LBL_head 9693863
#define LBL_infos 301706655
#define LBL_isInstance 728053194
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_name 9869138
#define LBL_prim 9944941
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_type_5f 312202367
#define LBL_unreached 121683306
#define LBL_value 313331083
#define LBL_watches 1357821955
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace, LBL_unreached};
static uint32_t shape_name__key__prim__isInstance__entry__failed[] = {LBL_name, LBL_key, LBL_prim, LBL_isInstance, LBL_entry, LBL_failed};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
V g_co_2ebind_24s196996678x1811735276(V, V, V);
V g_co_2ebind_24s196996678x1811735276_entry(V self, V *a);
extern Clo g_co_2ebind_24s196996678x1811735276_clo;
V g_heff_2eelab_2eenvironment_2eemptySt_get(void);
V g_heff_2eelab_2eenvironment_2etryE(V, V, V);
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2etryE_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eglobals_2eaddOwn(V, V, V);
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddOwn_clo;
V g_heff_2eelab_2erules_2eevidenceGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eevidenceGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eevidenceGo_clo;
V g_heff_2eelab_2erules_2efunctionElimC(V, V, V, V, V);
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionElimC_clo;
V g_heff_2eelab_2erules_2enamedGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedGo_clo;
V g_heff_2eelab_2erules_2erecordElim(V, V, V);
V g_heff_2eelab_2erules_2erecordElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordElim_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875(V);
V g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875_clo;
V g_heff_2eelab_2etoplevel_2eappendM(V, V);
V g_heff_2eelab_2etoplevel_2eappendM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_clo;
V g_heff_2eelab_2etoplevel_2eappendM_24dps(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendM_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_24dps_clo;
V g_heff_2eelab_2etoplevel_2eappendM_24tok2(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendM_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_24tok2_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_clo;
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_clo;
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435(V, V, V);
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_clo;
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(V, V, V);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_clo;
V g_heff_2eelab_2etoplevel_2eentryFor(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eentryFor_clo;
V g_heff_2eelab_2etoplevel_2ehasOpPat(V);
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo;
V g_heff_2eelab_2etoplevel_2eisPrimB(V);
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo;
V g_heff_2eelab_2etoplevel_2eonceEach(V, V);
V g_heff_2eelab_2etoplevel_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eonceEach_clo;
V g_heff_2eelab_2etoplevel_2eselfWalk(V);
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo;
V g_heff_2eelab_2etoplevel_2espineVals(V);
V g_heff_2eelab_2etoplevel_2espineVals_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2espineVals_clo;
V g_heff_2eelab_2etoplevel_2ethawGlobals(V, V);
V g_heff_2eelab_2etoplevel_2ethawGlobals_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawGlobals_clo;
V g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883_clo;
V g_heff_2eelab_2etoplevel_2etopOne(V, V, V);
V g_heff_2eelab_2etoplevel_2etopOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopOne_clo;
V g_heff_2eelab_2etoplevel_2etopTake(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopTake_clo;
V g_heff_2eelab_2etoplevel_2ewatchTake(V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchTake_clo;
V g_heff_2eelab_2etoplevel_2ewithInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242(V, V, V);
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2einfSpineOf(V);
V g_heff_2esyntax_2epresyntax_2einfSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
Clo g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_a_244 = heff_field(v_x_241, 1);
      V v_a_245 = (g_heff_2eelab_2etoplevel_2ehasOpPat(v_a_244));
      v_t_246 = heff_bool(!(heff_dup(v_a_245) == NTAG(TAG_True)));
      heff_drop(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_246);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_str0, 2, "p#");
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam8(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(V v_start_240, V v_s_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_At: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_sp_244 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_ArgExplicit: {
      V v_c_245 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      V v_m_246 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_245)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam0, 2, 5, (V[]){v_m_246, v_c_245, v_start_240, v_sp_244, heff_dup(v_s_241)});
    }
    case TAG_ArgProject: {
      V v_x_24102 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      heff_drop(v_start_240);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam2, 2, 3, (V[]){v_sp_244, heff_dup(v_s_241), v_x_24102});
    }
    case TAG_ArgNamed: {
      V v_x_24106 = heff_field(v_x41_243, 0);
      V v_c_24107 = heff_field(v_x41_243, 1);
      heff_take_n(v_x41_243, 3ULL, 2);
      V v_m_24108 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_c_24107));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam3, 2, 5, (V[]){v_m_24108, heff_dup(v_s_241), v_start_240, v_sp_244, v_x_24106});
    }
    case TAG_ArgEvidence: {
      V v_x_24122 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam8, 2, 4, (V[]){heff_dup(v_s_241), v_start_240, v_sp_244, v_x_24122});
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_s_241 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2411 = heff_dup(v_c_245);
  V v_t_2473;
  switch (heff_tag_of(v_c_2411)) {
  case TAG_At: {
    V v_c1_2412 = heff_field(v_c_2411, 0);
    heff_take_n(v_c_2411, 1ULL, 2);
    switch (heff_tag_of(v_c1_2412)) {
    case TAG_CInf: {
      V v_i_2414 = heff_field(v_c1_2412, 0);
      heff_take_n(v_c1_2412, 1ULL, 1);
      V v_t_2415 = (g_heff_2esyntax_2epresyntax_2einfSpineOf(v_i_2414));
      V v_t_2416 = heff_get_n(v_t_2415, 0, 2);
      V v_t_2419;
      switch (heff_tag_of(v_t_2416)) {
      case TAG_At: {
        V v_x_2417 = heff_field(v_t_2416, 0);
        heff_take_n(v_t_2416, 1ULL, 2);
        v_t_2419 = v_x_2417;
        break;
      }
      default: heff_nomatch(v_t_2416);
      }
      switch (heff_tag_of(v_t_2419)) {
      case TAG_IVar: {
        heff_take_n(v_t_2419, 0ULL, 1);
        v_t_2473 = NTAG(TAG_False);
        break;
      }
      case TAG_IInt: {
        heff_take_n(v_t_2419, 0ULL, 1);
        v_t_2473 = NTAG(TAG_False);
        break;
      }
      case TAG_IFloat: {
        heff_take_n(v_t_2419, 0ULL, 1);
        v_t_2473 = NTAG(TAG_False);
        break;
      }
      case TAG_IString: {
        heff_take_n(v_t_2419, 0ULL, 1);
        v_t_2473 = NTAG(TAG_False);
        break;
      }
      case TAG_IBytes: {
        heff_take_n(v_t_2419, 0ULL, 1);
        v_t_2473 = NTAG(TAG_False);
        break;
      }
      case TAG_IPrim: {
        heff_take_n(v_t_2419, 0ULL, 1);
        v_t_2473 = NTAG(TAG_False);
        break;
      }
      case TAG_IRune: {
        heff_take_n(v_t_2419, 0ULL, 1);
        v_t_2473 = NTAG(TAG_False);
        break;
      }
      case TAG_IApp: {
        heff_take_n(v_t_2419, 0ULL, 2);
        v_t_2473 = NTAG(TAG_False);
        break;
      }
      case TAG_IAnn: {
        heff_take_n(v_t_2419, 0ULL, 2);
        v_t_2473 = NTAG(TAG_False);
        break;
      }
      case TAG_ISpec: {
        heff_take_n(v_t_2419, 0ULL, 4);
        v_t_2473 = NTAG(TAG_False);
        break;
      }
      case TAG_IUpdate: {
        heff_take_n(v_t_2419, 0ULL, 2);
        v_t_2473 = NTAG(TAG_False);
        break;
      }
      case TAG_IAnnLam: {
        heff_take_n(v_t_2419, 0ULL, 4);
        v_t_2473 = NTAG(TAG_True);
        break;
      }
      case TAG_IInvalid: {
        heff_take_n(v_t_2419, 0ULL, 3);
        v_t_2473 = NTAG(TAG_False);
        break;
      }
      case TAG_INominal: {
        heff_take_n(v_t_2419, 0ULL, 1);
        v_t_2473 = NTAG(TAG_False);
        break;
      }
      case TAG_ILitEq: {
        heff_take_n(v_t_2419, 0ULL, 4);
        v_t_2473 = NTAG(TAG_False);
        break;
      }
      case TAG_ILazy: {
        heff_take_n(v_t_2419, 0ULL, 1);
        v_t_2473 = NTAG(TAG_False);
        break;
      }
      case TAG_ITuple: {
        heff_take_n(v_t_2419, 0ULL, 1);
        v_t_2473 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2419);
      }
      break;
    }
    case TAG_CType: {
      heff_take_n(v_c1_2412, 0ULL, 1);
      v_t_2473 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_c1_2412, 0ULL, 3);
      v_t_2473 = NTAG(TAG_True);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_c1_2412, 0ULL, 3);
      v_t_2473 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_c1_2412, 0ULL, 4);
      v_t_2473 = NTAG(TAG_True);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_c1_2412, 0ULL, 3);
      v_t_2473 = NTAG(TAG_True);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_c1_2412, 0ULL, 1);
      v_t_2473 = NTAG(TAG_True);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_c1_2412, 0ULL, 2);
      v_t_2473 = NTAG(TAG_True);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_c1_2412, 0ULL, 2);
      v_t_2473 = NTAG(TAG_True);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_c1_2412, 0ULL, 2);
      v_t_2473 = NTAG(TAG_True);
      break;
    }
    case TAG_CAbandon: {
      v_t_2473 = NTAG(TAG_True);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_c1_2412, 0ULL, 1);
      v_t_2473 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_c1_2412);
    }
    break;
  }
  default: heff_nomatch(v_c_2411);
  }
  V v_t_2499;
  switch (heff_tag_of(v_c_245)) {
  case TAG_At: {
    V v_x11_2474 = heff_field(v_c_245, 0);
    heff_take_n(v_c_245, 1ULL, 2);
    switch (heff_tag_of(v_x11_2474)) {
    case TAG_CInf: {
      heff_take_n(v_x11_2474, 0ULL, 1);
      v_t_2499 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_2474, 0ULL, 1);
      v_t_2499 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_2474, 0ULL, 3);
      v_t_2499 = NTAG(TAG_True);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_2474, 0ULL, 3);
      v_t_2499 = NTAG(TAG_False);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_2474, 0ULL, 4);
      v_t_2499 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_2474, 0ULL, 3);
      v_t_2499 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_2474, 0ULL, 1);
      v_t_2499 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_2474, 0ULL, 2);
      v_t_2499 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_2474, 0ULL, 2);
      v_t_2499 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_2474, 0ULL, 2);
      v_t_2499 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_2499 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_2474, 0ULL, 1);
      v_t_2499 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2474);
    }
    break;
  }
  default: heff_nomatch(v_c_245);
  }
  V v_t_24100 = ({ V rv_0 = v_start_240; V rr_ = heff_rec_reuse_nf(v_sp_244, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_24101 = ({ V a_0 = v_t_2473; V a_1 = v_t_2499; V a_2 = v_t_24100; V a_3 = v_s_241; V a_4 = v_x_2410; V r_ = (g_heff_2eelab_2erules_2efunctionElimC(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2473); heff_drop(v_t_2499); heff_drop(v_s_241); r_; });
  V f_ = v_k_248;
  args[0] = v_t_24101;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_m_246 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_s_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_m_246}));
  return (g_co_2ebind_24s196996678x1811735276(v_t_249, v_hd_247, heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam1, 1, 5, (V[]){v_c_245, v_start_240, v_sp_244, v_s_241, v_k_248})));
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam2(V self, V *args) {
  V v_hd_24103 = args[0];
  V v_k_24104 = args[1];
  V v_sp_244 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_x_24102 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24103);
  V v_t_24105 = ({ V a_0 = v_sp_244; V a_1 = v_s_241; V a_2 = v_x_24102; V r_ = (g_heff_2eelab_2erules_2erecordElim(a_0, a_1, a_2)); heff_drop(v_s_241); r_; });
  V f_ = v_k_24104;
  args[0] = v_t_24105;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam7(V self, V *args) {
  V v_x_24118 = args[0];
  V v_start_240 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_x_24106 = heff_env(self)[2];
  V v_x_24112 = heff_env(self)[3];
  V v_e_24113 = heff_env(self)[4];
  V v_hd_24116 = heff_env(self)[5];
  V v_k_24117 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_24118)) {
  case TAG_MkPair: {
    V v_ecallee_24119 = heff_field(v_x_24118, 0);
    V v_a0_24120 = heff_field(v_x_24118, 1);
    heff_take_n(v_x_24118, 3ULL, 2);
    V v_t_24121 = ({ V rv_0 = v_start_240; V rr_ = heff_rec_reuse_nf(v_sp_244, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return ({ V a_0 = v_t_24121; V a_1 = v_x_24106; V a_2 = v_x_24112; V a_3 = v_e_24113; V a_4 = v_ecallee_24119; V a_5 = v_a0_24120; V a_6 = v_hd_24116; V a_7 = v_k_24117; V r_ = (g_heff_2eelab_2erules_2enamedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_24112); r_; });
  }
  default: return heff_nomatch(v_x_24118);
  }
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam6(V self, V *args) {
  V v_hd_24116 = args[0];
  V v_k_24117 = args[1];
  V v_c_24115 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_24106 = heff_env(self)[3];
  V v_x_24112 = heff_env(self)[4];
  V v_e_24113 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_24115;
  args[0] = heff_dup(v_hd_24116);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam7, 1, 7, (V[]){v_start_240, v_sp_244, v_x_24106, v_x_24112, v_e_24113, v_hd_24116, v_k_24117});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam5(V self, V *args) {
  V v_e_24113 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_24106 = heff_env(self)[3];
  V v_x_24112 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_24115;
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_24114 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_24115 = heff_tr(heff_call(v_f_24114, 1, (V[]){heff_dup(v_e_24113)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam6, 2, 6, (V[]){v_c_24115, v_start_240, v_sp_244, v_x_24106, v_x_24112, v_e_24113});
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam4(V self, V *args) {
  V v_x_24112 = args[0];
  V v_k_24110 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_x_24106 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_24110;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam5, 1, 5, (V[]){v_s_241, v_start_240, v_sp_244, v_x_24106, v_x_24112})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam3(V self, V *args) {
  V v_hd_24109 = args[0];
  V v_k_24110 = args[1];
  V v_m_24108 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_x_24106 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24111 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_m_24108}));
  return (g_co_2ebind_24s196996678x1811735276(v_t_24111, v_hd_24109, heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam4, 1, 5, (V[]){v_k_24110, v_s_241, v_start_240, v_sp_244, v_x_24106})));
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam12(V self, V *args) {
  V v_path_24134 = args[0];
  V v_w_24135 = args[1];
  V v_sp_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_sp_24136 = v_sp_244;
  V v_path_24137 = v_path_24134;
  V v_w_24138 = v_w_24135;
  V v_t_24139 = heff_intShow(heff_dup(heff_rfield(v_sp_24136, 0)));
  V v_t_24140 = heff_tag_n(TAG_LamName, 2, (V[]){heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_str0), v_t_24139), heff_dup(v_sp_24136)});
  V v_t_24141 = (g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242(v_w_24138, heff_dup(v_sp_24136), v_path_24137));
  V v_e_24142 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_24140, v_t_24141}), v_sp_24136});
  HeffT2 v_t_24143 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_24142));
  V v_n_24165;
  {
    V v_field_24145 = v_t_24143.f[1];
    int64_t v_tag_24144 = ((int64_t)v_t_24143.f[0]);
    if ((v_tag_24144 == ((int64_t)0ULL))) {
      V v_c_24146 = v_field_24145;
      switch (heff_tag_of(v_c_24146)) {
      case TAG_At: {
        V v_n_24147 = heff_field(v_c_24146, 0);
        V v_sp_24148 = heff_field(v_c_24146, 1);
        V v_ru_24c_24146_24At = heff_take_reuse_n(v_c_24146, 3ULL, 2);
        V v_t_24149 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_24147));
        v_n_24165 = heff_tag_at_n(v_ru_24c_24146_24At, TAG_At, 2, (V[]){v_t_24149, v_sp_24148});
        break;
      }
      default: heff_nomatch(v_c_24146);
      }
    } else {
      if ((v_tag_24144 == ((int64_t)1ULL))) {
        V v_i_24150 = v_field_24145;
        V v_t_24153;
        switch (heff_tag_of(v_i_24150)) {
        case TAG_At: {
          V v_s_24152 = heff_dup(heff_field(v_i_24150, 1));
          v_t_24153 = v_s_24152;
          break;
        }
        default: heff_nomatch(v_i_24150);
        }
        V v_t_24157;
        switch (heff_tag_of(v_i_24150)) {
        case TAG_At: {
          V v_n_24154 = heff_field(v_i_24150, 0);
          V v_sp_24155 = heff_field(v_i_24150, 1);
          V v_ru_24i_24150_24At = heff_take_reuse_n(v_i_24150, 3ULL, 2);
          V v_t_24156 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_24154));
          v_t_24157 = heff_tag_at_n(v_ru_24i_24150_24At, TAG_At, 2, (V[]){v_t_24156, v_sp_24155});
          break;
        }
        default: heff_nomatch(v_i_24150);
        }
        v_n_24165 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24157}), v_t_24153});
      } else {
        V v_t_24158 = v_field_24145;
        V v_t_24161;
        switch (heff_tag_of(v_t_24158)) {
        case TAG_At: {
          V v_s_24160 = heff_dup(heff_field(v_t_24158, 1));
          v_t_24161 = v_s_24160;
          break;
        }
        default: heff_nomatch(v_t_24158);
        }
        V v_t_24164;
        switch (heff_tag_of(v_t_24158)) {
        case TAG_At: {
          V v_n_24162 = heff_field(v_t_24158, 0);
          V v_sp_24163 = heff_field(v_t_24158, 1);
          V v_ru_24t_24158_24At = heff_take_reuse_n(v_t_24158, 3ULL, 2);
          v_t_24164 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_24158_24At, v_sp_24163, v_n_24162));
          break;
        }
        default: heff_nomatch(v_t_24158);
        }
        v_n_24165 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24164}), v_t_24161});
      }
    }
  }
  return (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_24165));
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam11(V self, V *args) {
  V v_x_24130 = args[0];
  V v_start_240 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_x_24122 = heff_env(self)[2];
  V v_e_24125 = heff_env(self)[3];
  V v_hd_24128 = heff_env(self)[4];
  V v_k_24129 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_24130)) {
  case TAG_MkPair: {
    V v_ecallee_24131 = heff_field(v_x_24130, 0);
    V v_a0_24132 = heff_field(v_x_24130, 1);
    heff_take_n(v_x_24130, 3ULL, 2);
    V v_t_24133 = heff_rec_n(2, shape_start__end, (V[]){v_start_240, heff_dup(heff_rfield(v_sp_244, 1))});
    return (g_heff_2eelab_2erules_2eevidenceGo(v_t_24133, v_x_24122, heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam12, 2, 1, (V[]){v_sp_244}), v_e_24125, v_ecallee_24131, v_a0_24132, v_hd_24128, v_k_24129));
  }
  default: return heff_nomatch(v_x_24130);
  }
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam10(V self, V *args) {
  V v_hd_24128 = args[0];
  V v_k_24129 = args[1];
  V v_c_24127 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_24122 = heff_env(self)[3];
  V v_e_24125 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24127;
  args[0] = heff_dup(v_hd_24128);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam11, 1, 6, (V[]){v_start_240, v_sp_244, v_x_24122, v_e_24125, v_hd_24128, v_k_24129});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam9(V self, V *args) {
  V v_e_24125 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_24122 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_24127;
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_24126 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_24127 = heff_tr(heff_call(v_f_24126, 1, (V[]){heff_dup(v_e_24125)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam10, 2, 5, (V[]){v_c_24127, v_start_240, v_sp_244, v_x_24122, v_e_24125});
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam8(V self, V *args) {
  V v_hd_24123 = args[0];
  V v_k_24124 = args[1];
  V v_s_241 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_24122 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_hd_24123);
  V f_ = v_k_24124;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam9, 1, 4, (V[]){v_s_241, v_start_240, v_sp_244, v_x_24122})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2eelab_2etoplevel_2eappendM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendM_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eappendM(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2eelab_2etoplevel_2eappendM_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eappendM_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendM(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2eappendM_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendM_24dps_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eappendM_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eappendM_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendM_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2etoplevel_2espineVals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2espineVals_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2espineVals(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SpId: {
    return NTAG(TAG_Nil);
  }
  case TAG_SpApp: {
    V v_sp_241 = heff_field(v_x1_240, 0);
    V v_e_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24SpApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eelab_2etoplevel_2espineVals(v_sp_241));
    V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24SpApp, TAG_Cons, 2, (V[]){v_e_242, NTAG(TAG_Nil)});
    return (g_heff_2eelab_2etoplevel_2eappendM(v_t_243, v_t_244));
  }
  case TAG_SpProj: {
    V v_sp_245 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    V t_0 = v_sp_245;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SpSpec: {
    V v_sp_247 = heff_field(v_x1_240, 0);
    V v_e_249 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 5ULL, 3);
    V v_t_2410 = (g_heff_2eelab_2etoplevel_2espineVals(v_sp_247));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_249, NTAG(TAG_Nil)});
    return (g_heff_2eelab_2etoplevel_2eappendM(v_t_2410, v_t_2411));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2espineVals_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2espineVals(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2etopOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopOne_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopOne(V v_kf_240, V v_acc_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_n1_243 = heff_dup(heff_field(v_n_242, 0));
    switch (heff_tag_of(v_n1_243)) {
    case TAG_DeclEquations: {
      heff_take_n(v_n1_243, 0ULL, 5);
      V v_t_2410 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), heff_dup(v_n_242), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake(v_kf_240, v_acc_241, v_n_242, v_t_2410));
    }
    case TAG_DeclDefine: {
      heff_take_n(v_n1_243, 0ULL, 5);
      V v_t_2416 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), heff_dup(v_n_242), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake(v_kf_240, v_acc_241, v_n_242, v_t_2416));
    }
    case TAG_DeclTheory: {
      heff_take_n(v_n1_243, 0ULL, 4);
      V v_t_2421 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), heff_dup(v_n_242), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake(v_kf_240, v_acc_241, v_n_242, v_t_2421));
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_n1_243, 0ULL, 3);
      V v_t_2425 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), heff_dup(v_n_242), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake(v_kf_240, v_acc_241, v_n_242, v_t_2425));
    }
    case TAG_DeclTest: {
      V v_x_2426 = heff_field(v_n1_243, 0);
      V v_ru_24n1_243_24DeclTest = heff_take_reuse_n(v_n1_243, 1ULL, 2);
      heff_drop(v_kf_240);
      switch (heff_tag_of(v_n_242)) {
      case TAG_At: {
        V v_sp_2429 = heff_field(v_n_242, 1);
        heff_take_n(v_n_242, 2ULL, 2);
        V v_keys_2430 = heff_take_field(v_acc_241, 2);
        V v_broken_2431 = heff_take_field(v_acc_241, 3);
        V v_watches_2432 = heff_take_field(v_acc_241, 4);
        V v_t_2433 = heff_take_field(v_acc_241, 5);
        V v_spans_2434 = heff_take_field(v_acc_241, 6);
        V v_infos_2435 = heff_take_field(v_acc_241, 7);
        V v_trace_2436 = heff_take_field(v_acc_241, 8);
        V v_unreached_2437 = heff_take_field(v_acc_241, 9);
        V v_t_2438 = heff_tag_at_n(v_ru_24n1_243_24DeclTest, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_x_2426, v_sp_2429}), v_t_2433});
        return ({ V rv_2 = v_keys_2430; V rv_3 = v_broken_2431; V rv_4 = v_watches_2432; V rv_5 = v_t_2438; V rv_6 = v_spans_2434; V rv_7 = v_infos_2435; V rv_8 = v_trace_2436; V rv_9 = v_unreached_2437; V rr_ = heff_rec_reuse_nf(v_acc_241, 3ULL, 10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
      }
      default: return heff_nomatch(v_n_242);
      }
    }
    case TAG_DeclWatch: {
      V v_e_2439 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      heff_drop(v_kf_240);
      switch (heff_tag_of(v_n_242)) {
      case TAG_At: {
        V v_sp_2441 = heff_field(v_n_242, 1);
        heff_take_n(v_n_242, 2ULL, 2);
        V v_t_2442 = heff_tr(g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435(heff_dup(heff_rfield(v_acc_241, 0)), v_e_2439, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
        HEFF_LAST return g_heff_2eelab_2etoplevel_2ewatchTake(v_acc_241, v_sp_2441, v_t_2442);
      }
      default: return heff_nomatch(v_n_242);
      }
    }
    default: return heff_nomatch(v_n1_243);
    }
  }
  default: return heff_nomatch(v_n_242);
  }
}
V g_heff_2eelab_2etoplevel_2etopOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopOne(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883(V v_lit_240, V v_lit_241, V v_acc_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    V v_globals_244 = heff_take_field(v_acc_242, 0);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 1)));
    V v_diags_246 = (g_heff_2eelab_2etoplevel_2eonceEach(NTAG(TAG_Nil), v_t_245));
    V v_keys_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 2)));
    V v_broken_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 3)));
    V v_watches_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 4)));
    V v_tests_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 5)));
    V v_spans_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 6)));
    V v_infos_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 7)));
    V v_trace_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 8)));
    V v_unreached_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_acc_242, 9, 10)));
    return heff_rec_n(10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, (V[]){v_globals_244, v_diags_246, v_keys_247, v_broken_248, v_watches_249, v_tests_2410, v_spans_2411, v_infos_2412, v_trace_2413, v_unreached_2414});
  }
  case TAG_Cons: {
    V v_n_2415 = heff_field(v_x3_243, 0);
    V v_rest_2416 = heff_field(v_x3_243, 1);
    V v_t_2418 = (g_heff_2eelab_2etoplevel_2etopOne(heff_clo_n(g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883_lam0, 1, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}), v_acc_242, heff_dup(v_n_2415)));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_2418;
    V t_3 = v_rest_2416;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_acc_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883_lam0(V self, V *args) {
  V v_a_2417 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_strAppend(heff_strAppend(v_lit_240, v_lit_241), v_a_2417);
}
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_entry, 8, 0};

V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(V v_g_240, V v_d_241, V v_isInstance_242, V v_tyStx_243, V v_mc_244, V v_x7_245, V v_z_246, V v_z_247) {
top: ;
  V v_prim_248 = heff_take_field(v_d_241, 3);
  V v_name_249 = heff_get_n(v_d_241, 0, 4);
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Left: {
    V v_failed_2410 = heff_field(v_x7_245, 0);
    heff_take_n(v_x7_245, 1ULL, 1);
    V v_key_2411;
    if ((heff_dup(v_prim_248) == NTAG(TAG_True))) {
      v_key_2411 = heff_dup(v_name_249);
    } else {
      v_key_2411 = heff_dup(v_name_249);
    }
    HeffT2 v_t_2412 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(v_g_240), NTAG(TAG_N), heff_dup(v_tyStx_243), NTAG(TAG_LNil)));
    V v_t_2420;
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      V v_a_2418;
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        V v_x_2415 = v_field_2414;
        v_a_2418 = v_x_2415;
      } else {
        if ((v_tag_2413 == ((int64_t)1ULL))) {
          V v_x11_2416 = v_field_2414;
          heff_drop(v_x11_2416);
          v_a_2418 = heff_abandon();
        } else {
          V v_x_2417 = v_field_2414;
          v_a_2418 = v_x_2417;
        }
      }
      v_t_2420 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_lam0, 1, 1, (V[]){v_a_2418}), NTAG(TAG_Nothing)));
    }
    HeffT2 v_t_2421 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_243), NTAG(TAG_LNil)));
    V v_t_2427;
    {
      V v_field_2423 = v_t_2421.f[1];
      int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
      if ((v_tag_2422 == ((int64_t)0ULL))) {
        V v_x_2424 = v_field_2423;
        v_t_2427 = v_x_2424;
      } else {
        if ((v_tag_2422 == ((int64_t)1ULL))) {
          V v_x11_2425 = v_field_2423;
          heff_drop(v_x11_2425);
          v_t_2427 = heff_abandon();
        } else {
          V v_x_2426 = v_field_2423;
          v_t_2427 = v_x_2426;
        }
      }
    }
    V v_entry_2428 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SAbandon), v_tyStx_243, v_t_2420, v_t_2427});
    V v_t_2429 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){v_name_249, v_key_2411, v_prim_248, v_isInstance_242, v_entry_2428, heff_tag_n(TAG_Just, 1, (V[]){v_failed_2410})});
    return heff_tail(v_z_247, 1, (V[]){v_t_2429});
  }
  case TAG_Right: {
    V v_t_2430 = heff_field(v_x7_245, 0);
    heff_take_n(v_x7_245, 1ULL, 1);
    V v_key_2431;
    if ((heff_dup(v_prim_248) == NTAG(TAG_True))) {
      v_key_2431 = heff_dup(v_name_249);
    } else {
      v_key_2431 = heff_dup(v_name_249);
    }
    V v_t_2432;
    if ((heff_dup(v_prim_248) == NTAG(TAG_True))) {
      v_t_2432 = heff_dup(v_name_249);
    } else {
      v_t_2432 = heff_dup(v_name_249);
    }
    V v_t_2433 = (g_heff_2eelab_2eunify_2ezonker(v_mc_244));
    V v_t_2434 = heff_tr(heff_call(heff_get_n(v_t_2433, 0, 2), 1, (V[]){heff_get_n(v_t_2430, 0, 2)}));
    V v_t_2435;
    if ((heff_dup(v_prim_248) == NTAG(TAG_True))) {
      v_t_2435 = heff_dup(v_name_249);
    } else {
      v_t_2435 = heff_dup(v_name_249);
    }
    V v_t_2436 = ({ V a_0 = v_t_2435; V r_ = (g_heff_2eelab_2etoplevel_2eselfWalk(a_0)); heff_drop(v_t_2435); r_; });
    V v_t_2437 = heff_tr(heff_call(heff_get_n(v_t_2436, 0, 2), 2, (V[]){MK_INT(0LL), v_t_2434}));
    V v_entry_2438 = (g_heff_2eelab_2etoplevel_2eentryFor(v_g_240, v_t_2432, v_prim_248, v_tyStx_243, v_t_2437));
    V v_t_2439 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){v_name_249, v_key_2431, v_prim_248, v_isInstance_242, v_entry_2438, NTAG(TAG_Nothing)});
    return heff_tail(v_z_247, 1, (V[]){v_t_2439});
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a6 = a[6]; V r = g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(a[0], a[1], a[2], a[3], a4, a[5], a6, a[7]); heff_drop(a4); heff_drop(a6); return r;
}
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_lam0(V self, V *args) {
  V v_u_2419 = args[0];
  V v_a_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2419);
  return v_a_2418;
}
Clo g_heff_2eelab_2etoplevel_2ethawGlobals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ethawGlobals_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ethawGlobals(V v_acc_240, V v_d_241) {
top: ;
  V v_isInstance_242 = heff_take_field(v_d_241, 2);
  V v_key_243 = heff_take_field(v_d_241, 1);
  V v_name_244 = heff_take_field(v_d_241, 0);
  V v_body_245 = heff_take_field(v_d_241, 5);
  V v_ty_246 = heff_get_n(v_d_241, 4, 6);
  V v_t_247 = (g_heff_2eelab_2etoplevel_2eisPrimB(v_body_245));
  V v_t_248 = ({ V a_0 = heff_dup(heff_rfield(v_acc_240, 0)); V a_1 = heff_dup(v_key_243); V a_2 = v_t_247; V a_3 = v_ty_246; V a_4 = v_body_245; V r_ = (g_heff_2eelab_2etoplevel_2eentryFor(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_247); r_; });
  V v_t_249 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(v_key_243), v_t_248, heff_get_n(v_acc_240, 0, 10)));
  V v_t_2410 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(v_name_244), heff_dup(v_key_243), v_t_249));
  return ({ V a_0 = v_isInstance_242; V a_1 = v_key_243; V a_2 = v_name_244; V a_3 = v_t_2410; V r_ = (g_heff_2eelab_2etoplevel_2ewithInstance(a_0, a_1, a_2, a_3)); heff_drop(v_isInstance_242); heff_drop(v_name_244); r_; });
}
V g_heff_2eelab_2etoplevel_2ethawGlobals_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ethawGlobals(a[0], a[1]);
}