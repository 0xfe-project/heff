// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgEvidence 24309
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_Catch 6517
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Expl 20488
#define TAG_FracNum 48168
#define TAG_HError 21467
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_IntNum 31256
#define TAG_LNil 57394
#define TAG_Left 13886
#define TAG_MkChk 56962
#define TAG_MkFieldPat 14710
#define TAG_MkSyn 7342
#define TAG_N 306
#define TAG_Named 2049
#define TAG_NamedImplicit 12352
#define TAG_NamedInstance 32632
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_TagVariant 25174
#define TAG_Throw 56084
#define LBL_aliases 1464806715
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_el 9998
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_failed 665164648
#define LBL_globals 352931696
#define LBL_implicit 319715269
#define LBL_infos 301706655
#define LBL_isInstance 728053194
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_prim 9944941
#define LBL_ret 322331
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_tm 10464
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_typ 324869
#define LBL_type_5f 312202367
#define LBL_value 313331083
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace};
static uint32_t shape_name__key__prim__isInstance__entry__failed[] = {LBL_name, LBL_key, LBL_prim, LBL_isInstance, LBL_entry, LBL_failed};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_name__ty__tm__prim[] = {LBL_name, LBL_ty, LBL_tm, LBL_prim};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
V g_heff_2eelab_2eenvironment_2eemptySt_get(void);
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eglobals_2eaddOwn(V, V, V);
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddOwn_clo;
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(V);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_clo;
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(V);
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_clo;
V g_heff_2eelab_2erules_2eevidenceGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eevidenceGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eevidenceGo_clo;
V g_heff_2eelab_2erules_2efunctionElimC(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionElimC_clo;
V g_heff_2eelab_2erules_2efunctionFormation(V, V);
V g_heff_2eelab_2erules_2efunctionFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionFormation_clo;
V g_heff_2eelab_2erules_2efunctionIntro(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntro_clo;
V g_heff_2eelab_2erules_2efunctionIntroImplicit(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroImplicit_clo;
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
V g_heff_2eelab_2erules_2eimplicitLams_24tok1(V, V);
V g_heff_2eelab_2erules_2eimplicitLams_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_24tok1_clo;
V g_heff_2eelab_2erules_2enamedGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedGo_clo;
V g_heff_2eelab_2erules_2enumLitChk(V, V);
V g_heff_2eelab_2erules_2enumLitChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitChk_clo;
V g_heff_2eelab_2erules_2erecordElim(V, V, V);
V g_heff_2eelab_2erules_2erecordElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordElim_clo;
V g_heff_2eelab_2erules_2erecovering(V);
V g_heff_2eelab_2erules_2erecovering_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecovering_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875(V);
V g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875_clo;
V g_heff_2eelab_2etoplevel_2eappendM(V, V);
V g_heff_2eelab_2etoplevel_2eappendM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_clo;
V g_heff_2eelab_2etoplevel_2eappendM_24dps(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendM_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_24dps_clo;
V g_heff_2eelab_2etoplevel_2eappendM_24tok2(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendM_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_24tok2_clo;
V g_heff_2eelab_2etoplevel_2ebodyDump(V, V);
V g_heff_2eelab_2etoplevel_2ebodyDump_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyDump_clo;
V g_heff_2eelab_2etoplevel_2echecksOnly(V);
V g_heff_2eelab_2etoplevel_2echecksOnly_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echecksOnly_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2echkHeadOf(V, V);
V g_heff_2eelab_2etoplevel_2echkHeadOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkHeadOf_clo;
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1(V, V);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1_clo;
V g_heff_2eelab_2etoplevel_2edefineD(V, V, V, V);
V g_heff_2eelab_2etoplevel_2edefineD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edefineD_clo;
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_clo;
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_clo;
V g_heff_2eelab_2etoplevel_2eelabWatch(V, V);
V g_heff_2eelab_2etoplevel_2eelabWatch_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabWatch_clo;
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(V, V, V);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_clo;
V g_heff_2eelab_2etoplevel_2eentryFor(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eentryFor_clo;
V g_heff_2eelab_2etoplevel_2ehasOpPat(V);
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2eisPrimB(V);
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo;
HeffT2 g_heff_2eelab_2etoplevel_2elamsOf_24cpr(V, V);
V g_heff_2eelab_2etoplevel_2enominalChk(V);
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalChk_clo;
V g_heff_2eelab_2etoplevel_2eparamsInOrder(V, V, V);
V g_heff_2eelab_2etoplevel_2eparamsInOrder_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eparamsInOrder_clo;
HeffT2 g_heff_2eelab_2etoplevel_2eparamsOf_24cpr(V, V, V);
V g_heff_2eelab_2etoplevel_2epatName(V, V, V);
V g_heff_2eelab_2etoplevel_2epatName_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epatName_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk(V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2(V, V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_clo;
V g_heff_2eelab_2etoplevel_2eselfWalk(V);
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo;
V g_heff_2eelab_2etoplevel_2espineVals(V);
V g_heff_2eelab_2etoplevel_2espineVals_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2espineVals_clo;
HeffT2 g_heff_2eelab_2etoplevel_2etagSynonym_24cpr(V);
V g_heff_2eelab_2etoplevel_2ethawGlobals(V, V);
V g_heff_2eelab_2etoplevel_2ethawGlobals_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawGlobals_clo;
V g_heff_2eelab_2etoplevel_2etopOne(V, V, V);
V g_heff_2eelab_2etoplevel_2etopOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopOne_clo;
V g_heff_2eelab_2etoplevel_2etopTake(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopTake_clo;
V g_heff_2eelab_2etoplevel_2etyDump(V, V);
V g_heff_2eelab_2etoplevel_2etyDump_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etyDump_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774(V);
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_clo;
V g_heff_2eelab_2etoplevel_2ewatchTake(V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchTake_clo;
V g_heff_2eelab_2etoplevel_2ewithArgs(V, V);
V g_heff_2eelab_2etoplevel_2ewithArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithArgs_clo;
V g_heff_2eelab_2etoplevel_2ewithInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo;
V g_heff_2eelab_2etoplevel_2ewithOne(V, V);
V g_heff_2eelab_2etoplevel_2ewithOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithOne_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate(V, V, V);
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eevidenceCandidate_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_prelude_2etraverse_24s1211845059x266223635(V);
V g_prelude_2etraverse_24s1211845059x266223635_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1211845059x266223635_clo;
V g_prelude_2etraverse_24s1488190221x1768542206(V);
V g_prelude_2etraverse_24s1488190221x1768542206_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1488190221x1768542206_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str0, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str1, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str2, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str3, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str4, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str5, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str6, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str7, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str8, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str9, 54, "an argument of a `case` pattern is a pattern or a name");
Clo g_heff_2eelab_2etoplevel_2epatName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epatName_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2epatName(V v_p_240, V v_p_241, V v_p_242) {
top: ;
  V v_bind_243 = heff_take_field(v_p_241, 1);
  V v_malg_244 = heff_get_n(v_p_241, 2, 3);
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_245 = heff_field(v_p_240, 0);
    switch (heff_tag_of(v_p1_245)) {
    case TAG_PatVar: {
      V v_x_247 = heff_field(v_p1_245, 0);
      heff_drop(v_bind_243);
      heff_drop(v_malg_244);
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        return heff_tail(v_p_242, 1, (V[]){heff_dup(v_x_247)});
      }
      default: return heff_nomatch(v_p_240);
      }
    }
    case TAG_PatTag: {
      V v_t_2415;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2414 = heff_field(v_p_240, 1);
        v_t_2415 = heff_dup(v_s_2414);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str0), v_t_2415, NTAG(TAG_Nothing)});
      V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tr(heff_call(v_malg_244, 1, (V[]){v_t_2418}));
      return heff_tail(v_bind_243, 2, (V[]){v_t_2419, v_p_242});
    }
    case TAG_PatOp: {
      V v_t_2425;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2424 = heff_field(v_p_240, 1);
        v_t_2425 = heff_dup(v_s_2424);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str1), v_t_2425, NTAG(TAG_Nothing)});
      V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tr(heff_call(v_malg_244, 1, (V[]){v_t_2428}));
      return heff_tail(v_bind_243, 2, (V[]){v_t_2429, v_p_242});
    }
    case TAG_PatInt: {
      V v_t_2433;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_p_240, 1);
        v_t_2433 = heff_dup(v_s_2432);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2434 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str2), v_t_2433, NTAG(TAG_Nothing)});
      V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tr(heff_call(v_malg_244, 1, (V[]){v_t_2436}));
      return heff_tail(v_bind_243, 2, (V[]){v_t_2437, v_p_242});
    }
    case TAG_PatFloat: {
      V v_t_2441;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2440 = heff_field(v_p_240, 1);
        v_t_2441 = heff_dup(v_s_2440);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str3), v_t_2441, NTAG(TAG_Nothing)});
      V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2442})});
      V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
      V v_t_2445 = heff_tr(heff_call(v_malg_244, 1, (V[]){v_t_2444}));
      return heff_tail(v_bind_243, 2, (V[]){v_t_2445, v_p_242});
    }
    case TAG_PatString: {
      V v_t_2449;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2448 = heff_field(v_p_240, 1);
        v_t_2449 = heff_dup(v_s_2448);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2450 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str4), v_t_2449, NTAG(TAG_Nothing)});
      V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2450})});
      V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
      V v_t_2453 = heff_tr(heff_call(v_malg_244, 1, (V[]){v_t_2452}));
      return heff_tail(v_bind_243, 2, (V[]){v_t_2453, v_p_242});
    }
    case TAG_PatBinary: {
      V v_t_2457;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2456 = heff_field(v_p_240, 1);
        v_t_2457 = heff_dup(v_s_2456);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str5), v_t_2457, NTAG(TAG_Nothing)});
      V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2458})});
      V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
      V v_t_2461 = heff_tr(heff_call(v_malg_244, 1, (V[]){v_t_2460}));
      return heff_tail(v_bind_243, 2, (V[]){v_t_2461, v_p_242});
    }
    case TAG_PatRune: {
      V v_t_2465;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2464 = heff_field(v_p_240, 1);
        v_t_2465 = heff_dup(v_s_2464);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2466 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str6), v_t_2465, NTAG(TAG_Nothing)});
      V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2466})});
      V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
      V v_t_2469 = heff_tr(heff_call(v_malg_244, 1, (V[]){v_t_2468}));
      return heff_tail(v_bind_243, 2, (V[]){v_t_2469, v_p_242});
    }
    case TAG_PatRecord: {
      V v_t_2473;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2472 = heff_field(v_p_240, 1);
        v_t_2473 = heff_dup(v_s_2472);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2474 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str7), v_t_2473, NTAG(TAG_Nothing)});
      V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2474})});
      V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
      V v_t_2477 = heff_tr(heff_call(v_malg_244, 1, (V[]){v_t_2476}));
      return heff_tail(v_bind_243, 2, (V[]){v_t_2477, v_p_242});
    }
    case TAG_PatWord: {
      V v_t_2481;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2480 = heff_field(v_p_240, 1);
        v_t_2481 = heff_dup(v_s_2480);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2482 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str8), v_t_2481, NTAG(TAG_Nothing)});
      V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2482})});
      V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
      V v_t_2485 = heff_tr(heff_call(v_malg_244, 1, (V[]){v_t_2484}));
      return heff_tail(v_bind_243, 2, (V[]){v_t_2485, v_p_242});
    }
    case TAG_PatAs: {
      V v_t_2491;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2490 = heff_field(v_p_240, 1);
        v_t_2491 = heff_dup(v_s_2490);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2492 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str9), v_t_2491, NTAG(TAG_Nothing)});
      V v_t_2493 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2492})});
      V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
      V v_t_2495 = heff_tr(heff_call(v_malg_244, 1, (V[]){v_t_2494}));
      return heff_tail(v_bind_243, 2, (V[]){v_t_2495, v_p_242});
    }
    default: return heff_nomatch(v_p1_245);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2etoplevel_2epatName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2epatName(a0, a[1], a[2]); heff_drop(a0); return r;
}

HeffT2 g_heff_2eelab_2etoplevel_2etagSynonym_24cpr(V v_ge_240) {
top: ;
  V v_tySyntax_241 = heff_take_field(v_ge_240, 1);
  V v_syntax_242 = heff_get_n(v_ge_240, 0, 4);
  HeffT2 v_t_243 = (g_heff_2eelab_2etoplevel_2eparamsOf_24cpr(MK_INT(0LL), MK_INT(0LL), v_tySyntax_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_it1_246 = v_field_245;
      switch (heff_tag_of(v_it1_246)) {
      case TAG_MkPair: {
        V v_i_247 = heff_field(v_it1_246, 0);
        V v_k_248 = heff_field(v_it1_246, 1);
        V v_ru_24it1_246_24MkPair = heff_take_reuse_n(v_it1_246, 3ULL, 2);
        HeffT2 v_t_249 = (g_heff_2eelab_2etoplevel_2elamsOf_24cpr(MK_INT(0LL), v_syntax_242));
        {
          V v_field_2410 = v_t_249.f[0];
          V v_field_2411 = v_t_249.f[1];
          V v_n_2412 = v_field_2410;
          V v_it2_2413 = v_field_2411;
          switch (heff_tag_of(v_it2_2413)) {
          case TAG_SLocal: {
            heff_take_n(v_it2_2413, 0ULL, 1);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SGlobal: {
            heff_take_n(v_it2_2413, 0ULL, 1);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SCode: {
            heff_take_n(v_it2_2413, 0ULL, 1);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SApp: {
            heff_take_n(v_it2_2413, 0ULL, 2);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SLam: {
            heff_take_n(v_it2_2413, 0ULL, 2);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SCons: {
            heff_take_n(v_it2_2413, 0ULL, 1);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SProj: {
            heff_take_n(v_it2_2413, 0ULL, 2);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_STag: {
            V v_t_2424 = heff_field(v_it2_2413, 0);
            V v_args_2425 = heff_field(v_it2_2413, 1);
            heff_take_n(v_it2_2413, 3ULL, 2);
            if (heff_intEq_c(v_n_2412, heff_intAdd(v_i_247, heff_dup(v_k_248)))) {
              V v_t_2426 = ({ V a_0 = heff_dup(v_k_248); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(v_args_2425); V r_ = (g_heff_2eelab_2etoplevel_2eparamsInOrder(a_0, a_1, b_2)); heff_drop(b_2); r_; });
              if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
                heff_drop(v_t_2426);
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24it1_246_24MkPair, TAG_MkPair, 2, (V[]){v_t_2424, v_k_248})}});
              } else {
                heff_drop(v_k_248);
                heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
                heff_drop(v_t_2424);
                heff_drop(v_t_2426);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            } else {
              heff_drop(v_k_248);
              heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
              heff_drop(v_t_2424);
              heff_drop(v_args_2425);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
          case TAG_SMatch: {
            heff_take_n(v_it2_2413, 0ULL, 2);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SSpecialize: {
            heff_take_n(v_it2_2413, 0ULL, 3);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SIs: {
            heff_take_n(v_it2_2413, 0ULL, 1);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SOpaque: {
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SAbandon: {
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SRec: {
            heff_take_n(v_it2_2413, 0ULL, 1);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SFix: {
            heff_take_n(v_it2_2413, 0ULL, 2);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SImplicit: {
            heff_take_n(v_it2_2413, 0ULL, 2);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SPrim: {
            heff_take_n(v_it2_2413, 0ULL, 1);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SMetaApp: {
            heff_take_n(v_it2_2413, 0ULL, 3);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SLitInt: {
            heff_take_n(v_it2_2413, 0ULL, 1);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SLitFloat: {
            heff_take_na(v_it2_2413, 0ULL, 1);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SLitString: {
            heff_take_n(v_it2_2413, 0ULL, 1);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SLitBytes: {
            heff_take_n(v_it2_2413, 0ULL, 1);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SLitRune: {
            heff_take_n(v_it2_2413, 0ULL, 1);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SLitFixed: {
            heff_take_n(v_it2_2413, 0ULL, 2);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SLitFloat32: {
            heff_take_na(v_it2_2413, 0ULL, 1);
            heff_drop(v_i_247);
            heff_drop(v_k_248);
            heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
            heff_drop(v_n_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it2_2413)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_246)}});
      }
    } else {
      heff_drop(v_syntax_242);
      heff_drop(v_field_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_a_244 = heff_field(v_x_241, 1);
      V v_a_245 = (g_heff_2eelab_2etoplevel_2ehasOpPat(v_a_244));
      v_t_246 = heff_bool(!(heff_dup(v_a_245) == NTAG(TAG_True)));
      heff_drop(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_246);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam8(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(V v_start_240, V v_s_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_At: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_sp_244 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_ArgExplicit: {
      V v_c_245 = heff_field(v_x41_243, 0);
      V v_t_246 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_245)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam0, 2, 5, (V[]){v_t_246, heff_dup(v_c_245), v_start_240, heff_dup(v_sp_244), heff_dup(v_s_241)});
    }
    case TAG_ArgProject: {
      V v_x_2413 = heff_field(v_x41_243, 0);
      heff_drop(v_start_240);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam2, 2, 3, (V[]){heff_dup(v_sp_244), heff_dup(v_s_241), heff_dup(v_x_2413)});
    }
    case TAG_ArgNamed: {
      V v_x_2417 = heff_field(v_x41_243, 0);
      V v_c_2418 = heff_field(v_x41_243, 1);
      V v_t_2419 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2418)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam3, 2, 5, (V[]){v_t_2419, heff_dup(v_s_241), v_start_240, heff_dup(v_sp_244), heff_dup(v_x_2417)});
    }
    case TAG_ArgEvidence: {
      V v_x_2432 = heff_field(v_x41_243, 0);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam8, 2, 4, (V[]){heff_dup(v_s_241), v_start_240, heff_dup(v_sp_244), heff_dup(v_x_2432)});
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_s_241 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = ({ V a_0 = v_c_245; V r_ = (g_heff_2eelab_2etoplevel_2echecksOnly(a_0)); heff_drop(v_c_245); r_; });
  V v_t_2411 = ({ V rv_0 = v_start_240; V rr_ = heff_rec_reuse_nf(v_sp_244, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2412 = ({ V a_0 = v_t_2410; V a_1 = v_t_2411; V a_2 = v_s_241; V a_3 = v_x_249; V r_ = (g_heff_2eelab_2erules_2efunctionElimC(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); heff_drop(v_s_241); heff_drop(v_x_249); r_; });
  V f_ = v_k_248;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_t_246 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_s_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_246, v_hd_247, heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam1, 1, 5, (V[]){v_c_245, v_start_240, v_sp_244, v_s_241, v_k_248})));
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_sp_244 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2414);
  V v_t_2416 = ({ V a_0 = v_sp_244; V a_1 = v_s_241; V a_2 = v_x_2413; V r_ = (g_heff_2eelab_2erules_2erecordElim(a_0, a_1, a_2)); heff_drop(v_s_241); r_; });
  V f_ = v_k_2415;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam7(V self, V *args) {
  V v_x_2428 = args[0];
  V v_start_240 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  V v_x_2422 = heff_env(self)[3];
  V v_e_2423 = heff_env(self)[4];
  V v_hd_2426 = heff_env(self)[5];
  V v_k_2427 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2428)) {
  case TAG_MkPair: {
    V v_ecallee_2429 = heff_field(v_x_2428, 0);
    V v_a0_2430 = heff_field(v_x_2428, 1);
    heff_take_n(v_x_2428, 3ULL, 2);
    V v_t_2431 = ({ V rv_0 = v_start_240; V rr_ = heff_rec_reuse_nf(v_sp_244, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return ({ V a_0 = v_t_2431; V a_1 = v_x_2417; V a_2 = v_x_2422; V a_3 = v_e_2423; V a_4 = v_ecallee_2429; V a_5 = v_a0_2430; V a_6 = v_hd_2426; V a_7 = v_k_2427; V r_ = (g_heff_2eelab_2erules_2enamedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2422); r_; });
  }
  default: return heff_nomatch(v_x_2428);
  }
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam6(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_c_2425 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_x_2422 = heff_env(self)[4];
  V v_e_2423 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2425;
  args[0] = heff_dup(v_hd_2426);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam7, 1, 7, (V[]){v_start_240, v_sp_244, v_x_2417, v_x_2422, v_e_2423, v_hd_2426, v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam5(V self, V *args) {
  V v_e_2423 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_x_2422 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2425;
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_2424 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_2425 = heff_tr(heff_call(v_f_2424, 1, (V[]){heff_dup(v_e_2423)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam6, 2, 6, (V[]){v_c_2425, v_start_240, v_sp_244, v_x_2417, v_x_2422, v_e_2423});
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam5, 1, 5, (V[]){v_s_241, v_start_240, v_sp_244, v_x_2417, v_x_2422})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_t_2419 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2419, v_hd_2420, heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam4, 1, 5, (V[]){v_k_2421, v_s_241, v_start_240, v_sp_244, v_x_2417})));
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam12(V self, V *args) {
  V v_path_2444 = args[0];
  V v_w_2445 = args[1];
  V v_sp_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_n_2446 = (g_heff_2esyntax_2epresyntax_2eevidenceCandidate(v_sp_244, v_path_2444, v_w_2445));
  return (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_2446));
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam11(V self, V *args) {
  V v_x_2440 = args[0];
  V v_start_240 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_x_2432 = heff_env(self)[2];
  V v_e_2435 = heff_env(self)[3];
  V v_hd_2438 = heff_env(self)[4];
  V v_k_2439 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2440)) {
  case TAG_MkPair: {
    V v_ecallee_2441 = heff_field(v_x_2440, 0);
    V v_a0_2442 = heff_field(v_x_2440, 1);
    heff_take_n(v_x_2440, 3ULL, 2);
    V v_t_2443 = heff_rec_n(2, shape_start__end, (V[]){v_start_240, heff_dup(heff_rfield(v_sp_244, 1))});
    return (g_heff_2eelab_2erules_2eevidenceGo(v_t_2443, v_x_2432, heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam12, 2, 1, (V[]){v_sp_244}), v_e_2435, v_ecallee_2441, v_a0_2442, v_hd_2438, v_k_2439));
  }
  default: return heff_nomatch(v_x_2440);
  }
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam10(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  V v_c_2437 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2432 = heff_env(self)[3];
  V v_e_2435 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2437;
  args[0] = heff_dup(v_hd_2438);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam11, 1, 6, (V[]){v_start_240, v_sp_244, v_x_2432, v_e_2435, v_hd_2438, v_k_2439});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam9(V self, V *args) {
  V v_e_2435 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2437;
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_2436 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_2437 = heff_tr(heff_call(v_f_2436, 1, (V[]){heff_dup(v_e_2435)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam10, 2, 5, (V[]){v_c_2437, v_start_240, v_sp_244, v_x_2432, v_e_2435});
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam8(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_s_241 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam9, 1, 4, (V[]){v_s_241, v_start_240, v_sp_244, v_x_2432})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_str0, 45, "unexpected notation for variant in a sum type");
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_TagVariant: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_args_245 = heff_field(v_x21_241, 2);
      heff_take_n(v_x21_241, 5ULL, 3);
      heff_drop(v_x22_242);
      V v_c_246 = (g_prelude_2etraverse_24s1211845059x266223635(v_args_245));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam0, 2, 2, (V[]){v_c_246, v_x_243});
    }
    case TAG_BadVariant: {
      heff_take_n(v_x21_241, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam2, 2, 1, (V[]){v_x22_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774(a[0]);
}
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, heff_arrayFromList(v_x_249)});
  V f_ = v_k_248;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam1, 1, 2, (V[]){v_x_243, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_x22_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2414 = heff_take_field(v_hd_2412, 1);
  V v_malg_2415 = heff_get_n(v_hd_2412, 2, 3);
  V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_str0), v_x22_242, NTAG(TAG_Nothing)});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_call(v_malg_2415, 1, (V[]){v_t_2418}));
  V f_ = v_bind_2414;
  args[0] = v_t_2419;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2ewithOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithOne_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ewithOne(V v_ab_240, V v_x2_241) {
top: ;
  V v_implicit_242 = heff_take_field(v_ab_240, 3);
  V v_name_243 = heff_take_field(v_ab_240, 1);
  V v_typ_244 = heff_take_field(v_ab_240, 2);
  V v_span_245 = heff_get_n(v_ab_240, 0, 4);
  switch (heff_tag_of(v_implicit_242)) {
  case TAG_Expl: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_MkPair: {
      V v_t_246 = heff_field(v_x2_241, 0);
      V v_c_247 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_t_248 = ({ V a_0 = heff_tag_n(TAG_Named, 2, (V[]){heff_dup(v_name_243), v_typ_244}); V a_1 = v_t_246; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_246); r_; });
      V v_t_249 = ({ V a_0 = v_span_245; V a_1 = v_name_243; V a_2 = v_c_247; V r_ = (g_heff_2eelab_2erules_2efunctionIntro(a_0, a_1, a_2)); heff_drop(v_c_247); r_; });
      return heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_248, v_t_249});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Impl: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_MkPair: {
      V v_t_2410 = heff_field(v_x2_241, 0);
      V v_c_2411 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_t_2412 = heff_tag_n(TAG_NamedImplicit, 4, (V[]){heff_dup(v_span_245), heff_dup(v_name_243), v_typ_244, NTAG(TAG_Nothing)});
      V v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = v_t_2410; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_t_2414 = ({ V a_0 = v_span_245; V a_1 = v_name_243; V a_2 = v_c_2411; V r_ = (g_heff_2eelab_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_c_2411); r_; });
      return heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_t_2414});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Inst: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_MkPair: {
      V v_t_2415 = heff_field(v_x2_241, 0);
      V v_c_2416 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_t_2417 = ({ V a_0 = heff_tag_n(TAG_NamedInstance, 3, (V[]){heff_dup(v_span_245), heff_dup(v_name_243), v_typ_244}); V a_1 = v_t_2415; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_2415); r_; });
      V v_t_2418 = ({ V a_0 = v_span_245; V a_1 = v_name_243; V a_2 = v_c_2416; V r_ = (g_heff_2eelab_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_c_2416); r_; });
      return heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_2417, v_t_2418});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_implicit_242);
  }
}
V g_heff_2eelab_2etoplevel_2ewithOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ewithOne(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2edefineD_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2edefineD_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edefineD_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edefineD_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edefineD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edefineD_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2edefineD(V v_name_240, V v_params_241, V v_tyN_242, V v_bodyN_243) {
top: ;
  V v_c_244 = (g_prelude_2etraverse_24s1488190221x1768542206(v_params_241));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2edefineD_lam0, 2, 4, (V[]){v_c_244, heff_dup(v_tyN_242), heff_dup(v_bodyN_243), v_name_240});
}
V g_heff_2eelab_2etoplevel_2edefineD_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2etoplevel_2edefineD(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2etoplevel_2edefineD_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2418 = ({ V a_0 = v_x_247; V a_1 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2412, v_x_2417}); V r_ = (g_heff_2eelab_2etoplevel_2ewithArgs(a_0, a_1)); heff_drop(v_x_247); r_; });
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_ty_2419 = heff_field(v_x2_2418, 0);
    V v_tm_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    V v_t_2421 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){v_name_240, v_ty_2419, v_tm_2420, NTAG(TAG_False)});
    V f_ = v_k_246;
    args[0] = v_t_2421;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2eelab_2etoplevel_2edefineD_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_bodyN_243 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_n_2415;
  switch (heff_tag_of(v_bodyN_243)) {
  case TAG_At: {
    V v_n_2413 = heff_field(v_bodyN_243, 0);
    V v_sp_2414 = heff_field(v_bodyN_243, 1);
    heff_take_n(v_bodyN_243, 3ULL, 2);
    v_n_2415 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2414, v_n_2413));
    break;
  }
  default: heff_nomatch(v_bodyN_243);
  }
  V v_c_2416 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_2415));
  V f_ = v_c_2416;
  heff_room[0] = v_hd_245;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edefineD_lam3, 1, 4, (V[]){v_x_247, v_x_2412, v_name_240, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2edefineD_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_tyN_242 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_bodyN_243 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_n_2410;
  switch (heff_tag_of(v_tyN_242)) {
  case TAG_At: {
    V v_n_248 = heff_field(v_tyN_242, 0);
    V v_sp_249 = heff_field(v_tyN_242, 1);
    V v_ru_24tyN_242_24At = heff_take_reuse_n(v_tyN_242, 3ULL, 2);
    v_n_2410 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24tyN_242_24At, v_sp_249, v_n_248));
    break;
  }
  default: heff_nomatch(v_tyN_242);
  }
  V v_c_2411 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n_2410));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edefineD_lam2, 1, 5, (V[]){v_bodyN_243, v_hd_245, v_x_247, v_name_240, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2edefineD_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_tyN_242 = heff_env(self)[1];
  V v_bodyN_243 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edefineD_lam1, 1, 5, (V[]){v_tyN_242, v_hd_245, v_bodyN_243, v_name_240, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2eappendM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendM_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eappendM(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2eelab_2etoplevel_2eappendM_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eappendM_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendM(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2eappendM_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendM_24dps_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eappendM_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eappendM_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendM_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2etoplevel_2espineVals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2espineVals_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2espineVals(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SpId: {
    return NTAG(TAG_Nil);
  }
  case TAG_SpApp: {
    V v_sp_241 = heff_field(v_x1_240, 0);
    V v_e_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24SpApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eelab_2etoplevel_2espineVals(v_sp_241));
    V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24SpApp, TAG_Cons, 2, (V[]){v_e_242, NTAG(TAG_Nil)});
    return (g_heff_2eelab_2etoplevel_2eappendM(v_t_243, v_t_244));
  }
  case TAG_SpProj: {
    V v_sp_245 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    V t_0 = v_sp_245;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SpSpec: {
    V v_sp_247 = heff_field(v_x1_240, 0);
    V v_e_249 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 5ULL, 3);
    V v_t_2410 = (g_heff_2eelab_2etoplevel_2espineVals(v_sp_247));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_249, NTAG(TAG_Nil)});
    return (g_heff_2eelab_2etoplevel_2eappendM(v_t_2410, v_t_2411));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2espineVals_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2espineVals(a[0]);
}
V g_heff_2eelab_2etoplevel_2etopOne_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etopOne_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopOne_lam0, 2, 0};
Clo g_heff_2eelab_2etoplevel_2etopOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopOne_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopOne(V v_kf_240, V v_acc_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_n1_243 = heff_dup(heff_field(v_n_242, 0));
    switch (heff_tag_of(v_n1_243)) {
    case TAG_DeclEquations: {
      heff_take_n(v_n1_243, 0ULL, 5);
      V v_t_2410 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), v_n_242, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake(v_kf_240, v_acc_241, v_n_242, v_t_2410));
    }
    case TAG_DeclDefine: {
      heff_take_n(v_n1_243, 0ULL, 5);
      V v_t_2416 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), v_n_242, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake(v_kf_240, v_acc_241, v_n_242, v_t_2416));
    }
    case TAG_DeclTheory: {
      heff_take_n(v_n1_243, 0ULL, 4);
      V v_t_2421 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), v_n_242, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake(v_kf_240, v_acc_241, v_n_242, v_t_2421));
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_n1_243, 0ULL, 3);
      V v_t_2425 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), v_n_242, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake(v_kf_240, v_acc_241, v_n_242, v_t_2425));
    }
    case TAG_DeclTest: {
      V v_x_2426 = heff_field(v_n1_243, 0);
      V v_ru_24n1_243_24DeclTest = heff_take_reuse_n(v_n1_243, 1ULL, 2);
      heff_drop(v_kf_240);
      switch (heff_tag_of(v_n_242)) {
      case TAG_At: {
        V v_sp_2429 = heff_field(v_n_242, 1);
        heff_take_n(v_n_242, 2ULL, 2);
        V v_t_2430 = heff_tag_at_n(v_ru_24n1_243_24DeclTest, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_x_2426, v_sp_2429}), heff_dup(heff_rfield(v_acc_241, 5))});
        return ({ V rv_5 = v_t_2430; V rr_ = heff_rec_reuse_nf(v_acc_241, 479ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 259071u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
      }
      default: return heff_nomatch(v_n_242);
      }
    }
    case TAG_DeclWatch: {
      V v_e_2431 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      heff_drop(v_kf_240);
      switch (heff_tag_of(v_n_242)) {
      case TAG_At: {
        V v_sp_2433 = heff_field(v_n_242, 1);
        heff_take_n(v_n_242, 2ULL, 2);
        V v_m_2434 = (g_heff_2eelab_2etoplevel_2eelabWatch(heff_dup(heff_rfield(v_acc_241, 0)), v_e_2431));
        V v_t_2437 = heff_tr(heff_call(v_m_2434, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), ((V)&g_heff_2eelab_2etoplevel_2etopOne_lam0_clo), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())}));
        HEFF_LAST return g_heff_2eelab_2etoplevel_2ewatchTake(v_acc_241, v_sp_2433, v_t_2437);
      }
      default: return heff_nomatch(v_n_242);
      }
    }
    default: return heff_nomatch(v_n1_243);
    }
  }
  default: return heff_nomatch(v_n_242);
  }
}
V g_heff_2eelab_2etoplevel_2etopOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopOne(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2etopOne_lam0(V self, V *args) {
  V v_x_2435 = args[0];
  V v_st_2436 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2435}), v_st_2436});
}
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_entry, 8, 0};

V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(V v_g_240, V v_d_241, V v_isInstance_242, V v_tyStx_243, V v_mc_244, V v_x7_245, V v_z_246, V v_z_247) {
top: ;
  V v_name_248 = heff_take_field(v_d_241, 0);
  V v_prim_249 = heff_get_n(v_d_241, 3, 4);
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Left: {
    V v_failed_2410 = heff_field(v_x7_245, 0);
    heff_take_n(v_x7_245, 1ULL, 1);
    HeffT2 v_t_2411 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(v_g_240), NTAG(TAG_N), heff_dup(v_tyStx_243), NTAG(TAG_LNil)));
    V v_t_2419;
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      V v_a_2417;
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_x_2414 = v_field_2413;
        v_a_2417 = v_x_2414;
      } else {
        if ((v_tag_2412 == ((int64_t)1ULL))) {
          V v_x11_2415 = v_field_2413;
          heff_drop(v_x11_2415);
          v_a_2417 = heff_abandon();
        } else {
          V v_x_2416 = v_field_2413;
          v_a_2417 = v_x_2416;
        }
      }
      v_t_2419 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_lam0, 1, 1, (V[]){v_a_2417}), NTAG(TAG_Nothing)));
    }
    HeffT2 v_t_2420 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_243), NTAG(TAG_LNil)));
    V v_t_2426;
    {
      V v_field_2422 = v_t_2420.f[1];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        V v_x_2423 = v_field_2422;
        v_t_2426 = v_x_2423;
      } else {
        if ((v_tag_2421 == ((int64_t)1ULL))) {
          V v_x11_2424 = v_field_2422;
          heff_drop(v_x11_2424);
          v_t_2426 = heff_abandon();
        } else {
          V v_x_2425 = v_field_2422;
          v_t_2426 = v_x_2425;
        }
      }
    }
    V v_entry_2427 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SAbandon), v_tyStx_243, v_t_2419, v_t_2426});
    V v_t_2428;
    if ((heff_dup(v_prim_249) == NTAG(TAG_True))) {
      v_t_2428 = heff_dup(v_name_248);
    } else {
      v_t_2428 = heff_dup(v_name_248);
    }
    V v_t_2429 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){v_name_248, v_t_2428, v_prim_249, v_isInstance_242, v_entry_2427, heff_tag_n(TAG_Just, 1, (V[]){v_failed_2410})});
    return heff_tail(v_z_247, 1, (V[]){v_t_2429});
  }
  case TAG_Right: {
    V v_t_2430 = heff_field(v_x7_245, 0);
    heff_take_n(v_x7_245, 1ULL, 1);
    V v_t_2431;
    if ((heff_dup(v_prim_249) == NTAG(TAG_True))) {
      v_t_2431 = heff_dup(v_name_248);
    } else {
      v_t_2431 = heff_dup(v_name_248);
    }
    V v_t_2432 = (g_heff_2eelab_2eunify_2ezonker(v_mc_244));
    V v_t_2433 = heff_tr(heff_call(heff_get_n(v_t_2432, 0, 2), 1, (V[]){heff_get_n(v_t_2430, 0, 2)}));
    V v_t_2434;
    if ((heff_dup(v_prim_249) == NTAG(TAG_True))) {
      v_t_2434 = heff_dup(v_name_248);
    } else {
      v_t_2434 = heff_dup(v_name_248);
    }
    V v_t_2435 = ({ V a_0 = v_t_2434; V r_ = (g_heff_2eelab_2etoplevel_2eselfWalk(a_0)); heff_drop(v_t_2434); r_; });
    V v_t_2436 = heff_tr(heff_call(heff_get_n(v_t_2435, 0, 2), 2, (V[]){MK_INT(0LL), v_t_2433}));
    V v_entry_2437 = (g_heff_2eelab_2etoplevel_2eentryFor(v_g_240, v_t_2431, v_prim_249, v_tyStx_243, v_t_2436));
    V v_t_2438;
    if ((heff_dup(v_prim_249) == NTAG(TAG_True))) {
      v_t_2438 = heff_dup(v_name_248);
    } else {
      v_t_2438 = heff_dup(v_name_248);
    }
    V v_t_2439 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){v_name_248, v_t_2438, v_prim_249, v_isInstance_242, v_entry_2437, NTAG(TAG_Nothing)});
    return heff_tail(v_z_247, 1, (V[]){v_t_2439});
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a6 = a[6]; V r = g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(a[0], a[1], a[2], a[3], a4, a[5], a6, a[7]); heff_drop(a4); heff_drop(a6); return r;
}
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_lam0(V self, V *args) {
  V v_u_2418 = args[0];
  V v_a_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2418);
  return v_a_2417;
}
Clo g_heff_2eelab_2etoplevel_2ethawGlobals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ethawGlobals_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ethawGlobals(V v_acc_240, V v_d_241) {
top: ;
  V v_isInstance_242 = heff_take_field(v_d_241, 2);
  V v_key_243 = heff_take_field(v_d_241, 1);
  V v_name_244 = heff_take_field(v_d_241, 0);
  V v_body_245 = heff_take_field(v_d_241, 5);
  V v_ty_246 = heff_get_n(v_d_241, 4, 6);
  V v_t_247 = (g_heff_2eelab_2etoplevel_2eisPrimB(v_body_245));
  V v_t_248 = ({ V a_0 = heff_dup(heff_rfield(v_acc_240, 0)); V a_1 = heff_dup(v_key_243); V a_2 = v_t_247; V a_3 = v_ty_246; V a_4 = v_body_245; V r_ = (g_heff_2eelab_2etoplevel_2eentryFor(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_247); r_; });
  V v_t_249 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(v_key_243), v_t_248, heff_get_n(v_acc_240, 0, 9)));
  V v_t_2410 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(v_name_244), heff_dup(v_key_243), v_t_249));
  return ({ V a_0 = v_isInstance_242; V a_1 = v_key_243; V a_2 = v_name_244; V a_3 = v_t_2410; V r_ = (g_heff_2eelab_2etoplevel_2ewithInstance(a_0, a_1, a_2, a_3)); heff_drop(v_isInstance_242); heff_drop(v_name_244); r_; });
}
V g_heff_2eelab_2etoplevel_2ethawGlobals_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ethawGlobals(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ebodyDump_str0, 20, "<no such definition>");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ebodyDump_str1, 20, "<no such definition>");
Clo g_heff_2eelab_2etoplevel_2ebodyDump_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebodyDump_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ebodyDump(V v_t_240, V v_k_241) {
top: ;
  V v_g_242 = heff_get_n(v_t_240, 0, 9);
  V v_entries_243 = heff_take_field(v_g_242, 1);
  V v_aliases_244 = heff_get_n(v_g_242, 2, 8);
  HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_entries_243, v_k_241));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_entries_243);
      heff_drop(v_aliases_244);
      V v_e_248 = v_field_247;
      return ({ V b_0 = heff_get_n(v_e_248, 0, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(b_0)); heff_drop(b_0); r_; });
    } else {
      heff_drop(v_field_247);
      HeffT2 v_t_249 = ({ V a_0 = v_aliases_244; V a_1 = v_k_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_aliases_244); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_k2_2412 = v_field_2411;
          HeffT2 v_t_2413 = ({ V a_0 = v_entries_243; V a_1 = v_k2_2412; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_entries_243); heff_drop(v_k2_2412); r_; });
          {
            V v_field_2415 = v_t_2413.f[1];
            int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
            if ((v_tag_2414 == ((int64_t)0ULL))) {
              V v_e_2416 = v_field_2415;
              return ({ V b_0 = heff_get_n(v_e_2416, 0, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(b_0)); heff_drop(b_0); r_; });
            } else {
              heff_drop(v_field_2415);
              return ((V)&g_heff_2eelab_2etoplevel_2ebodyDump_str0);
            }
          }
        } else {
          heff_drop(v_entries_243);
          heff_drop(v_field_2411);
          return ((V)&g_heff_2eelab_2etoplevel_2ebodyDump_str1);
        }
      }
    }
  }
}
V g_heff_2eelab_2etoplevel_2ebodyDump_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2ebodyDump(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2etyDump_str0, 20, "<no such definition>");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etyDump_str1, 20, "<no such definition>");
Clo g_heff_2eelab_2etoplevel_2etyDump_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etyDump_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etyDump(V v_t_240, V v_k_241) {
top: ;
  V v_g_242 = heff_get_n(v_t_240, 0, 9);
  V v_entries_243 = heff_take_field(v_g_242, 1);
  V v_aliases_244 = heff_get_n(v_g_242, 2, 8);
  HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_entries_243, v_k_241));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_entries_243);
      heff_drop(v_aliases_244);
      V v_e_248 = v_field_247;
      return ({ V b_0 = heff_get_n(v_e_248, 1, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(b_0)); heff_drop(b_0); r_; });
    } else {
      heff_drop(v_field_247);
      HeffT2 v_t_249 = ({ V a_0 = v_aliases_244; V a_1 = v_k_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_aliases_244); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_k2_2412 = v_field_2411;
          HeffT2 v_t_2413 = ({ V a_0 = v_entries_243; V a_1 = v_k2_2412; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_entries_243); heff_drop(v_k2_2412); r_; });
          {
            V v_field_2415 = v_t_2413.f[1];
            int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
            if ((v_tag_2414 == ((int64_t)0ULL))) {
              V v_e_2416 = v_field_2415;
              return ({ V b_0 = heff_get_n(v_e_2416, 1, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(b_0)); heff_drop(b_0); r_; });
            } else {
              heff_drop(v_field_2415);
              return ((V)&g_heff_2eelab_2etoplevel_2etyDump_str0);
            }
          }
        } else {
          heff_drop(v_entries_243);
          heff_drop(v_field_2411);
          return ((V)&g_heff_2eelab_2etoplevel_2etyDump_str1);
        }
      }
    }
  }
}
V g_heff_2eelab_2etoplevel_2etyDump_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2etyDump(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1(V v_tok_240, V v_i_241) {
top: ;
  V v_t_2437;
  switch (heff_tag_of(v_i_241)) {
  case TAG_At: {
    V v_x11_242 = heff_dup(heff_field(v_i_241, 0));
    switch (heff_tag_of(v_x11_242)) {
    case TAG_IVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2437 = heff_dup(v_i_241);
      break;
    }
    case TAG_IInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2437 = heff_dup(v_i_241);
      break;
    }
    case TAG_IFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      v_t_2437 = heff_dup(v_i_241);
      break;
    }
    case TAG_IString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2437 = heff_dup(v_i_241);
      break;
    }
    case TAG_IBytes: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2437 = heff_dup(v_i_241);
      break;
    }
    case TAG_IPrim: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2437 = heff_dup(v_i_241);
      break;
    }
    case TAG_IRune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2437 = heff_dup(v_i_241);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_x11_242, 0ULL, 2);
      v_t_2437 = heff_dup(v_i_241);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_x11_242, 0ULL, 2);
      v_t_2437 = heff_dup(v_i_241);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_x11_242, 0ULL, 4);
      v_t_2437 = heff_dup(v_i_241);
      break;
    }
    case TAG_IUpdate: {
      heff_take_n(v_x11_242, 0ULL, 2);
      v_t_2437 = heff_dup(v_i_241);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_x11_242, 0ULL, 4);
      v_t_2437 = heff_dup(v_i_241);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_x11_242, 0ULL, 3);
      v_t_2437 = heff_dup(v_i_241);
      break;
    }
    case TAG_INominal: {
      V v_i_2428 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      switch (heff_tag_of(v_i_241)) {
      case TAG_At: {
        v_t_2437 = v_i_2428;
        break;
      }
      default: heff_nomatch(v_i_241);
      }
      break;
    }
    case TAG_ILitEq: {
      heff_take_n(v_x11_242, 0ULL, 4);
      v_t_2437 = heff_dup(v_i_241);
      break;
    }
    case TAG_ILazy: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2437 = heff_dup(v_i_241);
      break;
    }
    case TAG_ITuple: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2437 = heff_dup(v_i_241);
      break;
    }
    default: heff_nomatch(v_x11_242);
    }
    break;
  }
  default: heff_nomatch(v_i_241);
  }
  V v_t_2471;
  switch (heff_tag_of(v_t_2437)) {
  case TAG_At: {
    V v_x11_2438 = heff_field(v_t_2437, 0);
    heff_take_n(v_t_2437, 1ULL, 2);
    switch (heff_tag_of(v_x11_2438)) {
    case TAG_IVar: {
      heff_take_n(v_x11_2438, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      v_t_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IInt: {
      V v_k_2441 = heff_field(v_x11_2438, 0);
      heff_take_n(v_x11_2438, 1ULL, 1);
      v_t_2471 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){heff_tag_n(TAG_IntNum, 1, (V[]){v_k_2441})});
      break;
    }
    case TAG_IFloat: {
      double v_x_2442 = heff_tflat_f64(v_x11_2438, 0);
      heff_take_na(v_x11_2438, 0ULL, 1);
      v_t_2471 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){heff_tag_nf(TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2442)})});
      break;
    }
    case TAG_IString: {
      heff_take_n(v_x11_2438, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      v_t_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IBytes: {
      heff_take_n(v_x11_2438, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      v_t_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IPrim: {
      heff_take_n(v_x11_2438, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      v_t_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IRune: {
      heff_take_n(v_x11_2438, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      v_t_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_x11_2438, 0ULL, 2);
      heff_drop_cell(v_tok_240, 1);
      v_t_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_x11_2438, 0ULL, 2);
      heff_drop_cell(v_tok_240, 1);
      v_t_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_x11_2438, 0ULL, 4);
      heff_drop_cell(v_tok_240, 1);
      v_t_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IUpdate: {
      heff_take_n(v_x11_2438, 0ULL, 2);
      heff_drop_cell(v_tok_240, 1);
      v_t_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_x11_2438, 0ULL, 4);
      heff_drop_cell(v_tok_240, 1);
      v_t_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_x11_2438, 0ULL, 3);
      heff_drop_cell(v_tok_240, 1);
      v_t_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_INominal: {
      heff_take_n(v_x11_2438, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      v_t_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ILitEq: {
      heff_take_n(v_x11_2438, 0ULL, 4);
      heff_drop_cell(v_tok_240, 1);
      v_t_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ILazy: {
      heff_take_n(v_x11_2438, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      v_t_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ITuple: {
      heff_take_n(v_x11_2438, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      v_t_2471 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2438);
    }
    break;
  }
  default: heff_nomatch(v_t_2437);
  }
  switch (heff_tag_of(v_t_2471)) {
  case TAG_Nothing: {
    V v_c_2472 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_i_241)));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1_lam0, 2, 2, (V[]){v_c_2472, v_i_241});
  }
  case TAG_Just: {
    V v_lit_2478 = heff_field(v_t_2471, 0);
    V v_ru_24t_2471_24Just = heff_take_reuse_n(v_t_2471, 1ULL, 1);
    V v_t_24112;
    switch (heff_tag_of(v_i_241)) {
    case TAG_At: {
      V v_x11_2479 = heff_dup(heff_field(v_i_241, 0));
      switch (heff_tag_of(v_x11_2479)) {
      case TAG_IVar: {
        heff_take_n(v_x11_2479, 0ULL, 1);
        v_t_24112 = NTAG(TAG_False);
        break;
      }
      case TAG_IInt: {
        heff_take_n(v_x11_2479, 0ULL, 1);
        v_t_24112 = NTAG(TAG_False);
        break;
      }
      case TAG_IFloat: {
        heff_take_na(v_x11_2479, 0ULL, 1);
        v_t_24112 = NTAG(TAG_False);
        break;
      }
      case TAG_IString: {
        heff_take_n(v_x11_2479, 0ULL, 1);
        v_t_24112 = NTAG(TAG_False);
        break;
      }
      case TAG_IBytes: {
        heff_take_n(v_x11_2479, 0ULL, 1);
        v_t_24112 = NTAG(TAG_False);
        break;
      }
      case TAG_IPrim: {
        heff_take_n(v_x11_2479, 0ULL, 1);
        v_t_24112 = NTAG(TAG_False);
        break;
      }
      case TAG_IRune: {
        heff_take_n(v_x11_2479, 0ULL, 1);
        v_t_24112 = NTAG(TAG_False);
        break;
      }
      case TAG_IApp: {
        heff_take_n(v_x11_2479, 0ULL, 2);
        v_t_24112 = NTAG(TAG_False);
        break;
      }
      case TAG_IAnn: {
        heff_take_n(v_x11_2479, 0ULL, 2);
        v_t_24112 = NTAG(TAG_False);
        break;
      }
      case TAG_ISpec: {
        heff_take_n(v_x11_2479, 0ULL, 4);
        v_t_24112 = NTAG(TAG_False);
        break;
      }
      case TAG_IUpdate: {
        heff_take_n(v_x11_2479, 0ULL, 2);
        v_t_24112 = NTAG(TAG_False);
        break;
      }
      case TAG_IAnnLam: {
        heff_take_n(v_x11_2479, 0ULL, 4);
        v_t_24112 = NTAG(TAG_False);
        break;
      }
      case TAG_IInvalid: {
        heff_take_n(v_x11_2479, 0ULL, 3);
        v_t_24112 = NTAG(TAG_False);
        break;
      }
      case TAG_INominal: {
        heff_take_n(v_x11_2479, 0ULL, 1);
        v_t_24112 = NTAG(TAG_True);
        break;
      }
      case TAG_ILitEq: {
        heff_take_n(v_x11_2479, 0ULL, 4);
        v_t_24112 = NTAG(TAG_False);
        break;
      }
      case TAG_ILazy: {
        heff_take_n(v_x11_2479, 0ULL, 1);
        v_t_24112 = NTAG(TAG_False);
        break;
      }
      case TAG_ITuple: {
        heff_take_n(v_x11_2479, 0ULL, 1);
        v_t_24112 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2479);
      }
      break;
    }
    default: heff_nomatch(v_i_241);
    }
    V v_t_24120;
    if ((heff_dup(v_t_24112) == NTAG(TAG_True))) {
      heff_drop(v_t_24112);
      V v_t_24115;
      switch (heff_tag_of(v_i_241)) {
      case TAG_At: {
        V v_s_24114 = heff_field(v_i_241, 1);
        heff_take_n(v_i_241, 2ULL, 2);
        v_t_24115 = v_s_24114;
        break;
      }
      default: heff_nomatch(v_i_241);
      }
      V v_t_24116 = (g_heff_2eelab_2erules_2enumLitChk(v_t_24115, v_lit_2478));
      v_t_24120 = ({ V a_0 = v_t_24116; V r_ = (g_heff_2eelab_2etoplevel_2enominalChk(a_0)); heff_drop(v_t_24116); r_; });
    } else {
      heff_drop(v_t_24112);
      V v_t_24119;
      switch (heff_tag_of(v_i_241)) {
      case TAG_At: {
        V v_s_24118 = heff_field(v_i_241, 1);
        heff_take_n(v_i_241, 2ULL, 2);
        v_t_24119 = v_s_24118;
        break;
      }
      default: heff_nomatch(v_i_241);
      }
      v_t_24120 = (g_heff_2eelab_2erules_2enumLitChk(v_t_24119, v_lit_2478));
    }
    V v_x_24121 = ({ V a_0 = v_ru_24t_2471_24Just; V a_1 = v_t_24120; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_t_24120); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1_lam2, 2, 1, (V[]){v_x_24121});
  }
  default: return heff_nomatch(v_t_2471);
  }
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1_lam1(V self, V *args) {
  V v_x_2475 = args[0];
  V v_i_241 = heff_env(self)[0];
  V v_k_2474 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2476 = ({ V a_0 = v_i_241; V a_1 = v_x_2475; V r_ = (g_heff_2eelab_2etoplevel_2echkHeadOf(a_0, a_1)); heff_drop(v_x_2475); r_; });
  V v_x_2477 = ({ V a_0 = v_t_2476; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_t_2476); r_; });
  V f_ = v_k_2474;
  args[0] = v_x_2477;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1_lam0(V self, V *args) {
  V v_hd_2473 = args[0];
  V v_k_2474 = args[1];
  V v_c_2472 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2472;
  args[0] = v_hd_2473;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1_lam1, 1, 2, (V[]){v_i_241, v_k_2474});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1_lam2(V self, V *args) {
  V v_hd_24122 = args[0];
  V v_k_24123 = args[1];
  V v_x_24121 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24122);
  V f_ = v_k_24123;
  args[0] = v_x_24121;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2(V v_tok_240, V v_m_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tr(heff_call(v_m_241, 2, (V[]){heff_dup(v_hd_242), heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_lam0, 1, 1, (V[]){heff_dup(v_hd_242)})}));
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_Catch, 2, (V[]){v_t_245, heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_lam1, 1, 1, (V[]){heff_dup(v_hd_242)})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_248}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_lam2, 1, 1, (V[]){v_k_243})});
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_s_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_lam3(V self, V *args) {
  V v_e_2412 = args[0];
  V v_a_2413 = args[1];
  V v_hd_2414 = args[2];
  V v_k2_2415 = args[3];
  V v_d_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2412);
  heff_drop(v_a_2413);
  V v_bind_2416 = heff_take_field(v_hd_2414, 1);
  V v_malg_2417 = heff_get_n(v_hd_2414, 2, 3);
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_d_2411})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_call(v_malg_2417, 1, (V[]){v_t_2419}));
  V f_ = v_bind_2416;
  args[0] = v_t_2420;
  args[1] = v_k2_2415;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Left: {
    V v_d_2411 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Left = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    V v_t_2421 = ({ V b_0 = heff_tag_at_n(v_ru_24x_2410_24Left, TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_lam3, 4, 1, (V[]){v_d_2411})}); V r_ = (g_heff_2eelab_2erules_2erecovering(b_0)); heff_drop(b_0); r_; });
    V f_ = v_k_243;
    args[0] = v_t_2421;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_c_2422 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    V v_t_2423 = ({ V a_0 = v_c_2422; V r_ = (g_heff_2eelab_2erules_2erecovering(a_0)); heff_drop(v_c_2422); r_; });
    V f_ = v_k_243;
    args[0] = v_t_2423;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2410);
  }
}