// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EQ 8989
#define TAG_GT 9054
#define TAG_LT 9209
#define LBL_end 310101
#define LBL_place 308106529
#define LBL_span 10032145
#define LBL_start 311115900
V g_list_2emerge_2emergeFrom_240(V, V, V, V);
V g_list_2emerge_2emergeFrom_240_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_clo;
V g_list_2emerge_2emergeFrom_240_24dps(V, V, V, V, V);
V g_list_2emerge_2emergeFrom_240_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24dps_clo;
V g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026(V, V, V);
V g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026_clo;
V g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026_24dps(V, V, V, V);
V g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026_24dps_clo;
V g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096(V, V, V);
V g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096_clo;
V g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096_24dps(V, V, V, V);
V g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096_24dps_clo;
V g_list_2emerge_2emergeFrom_240_24s1476184047x773913162(V, V, V);
V g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_clo;
V g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_24dps(V, V, V, V);
V g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_24dps_clo;
V g_list_2emerge_2emergeFrom_240_24s1486691154x115775505(V, V, V);
V g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_clo;
V g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_24dps(V, V, V, V);
V g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_24dps_clo;
V g_list_2emerge_2emergeFrom_240_24s182101113x1216647303(V, V, V);
V g_list_2emerge_2emergeFrom_240_24s182101113x1216647303_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s182101113x1216647303_clo;
V g_list_2emerge_2emergeFrom_240_24s182101113x1216647303_24dps(V, V, V, V);
V g_list_2emerge_2emergeFrom_240_24s182101113x1216647303_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s182101113x1216647303_24dps_clo;
V g_list_2emerge_2emergeFrom_240_24s825587185x1704110321(V, V, V);
V g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_clo;
V g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_24dps(V, V, V, V);
V g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_24dps_clo;
V g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349(V, V);
V g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349_entry(V self, V *a);
extern Clo g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349_clo;
Clo g_list_2emerge_2emergeFrom_240_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_2emergeFrom_240_entry, 4, 0};

V g_list_2emerge_2emergeFrom_240(V v_le_240, V v_left_241, V v_x2_242, V v_ys_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    heff_drop(v_left_241);
    return v_ys_243;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_rest_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_ys_243)) {
    case TAG_Nil: {
      heff_drop(v_le_240);
      heff_drop(v_left_241);
      return heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, v_rest_245});
    }
    case TAG_Cons: {
      switch (heff_tag_of(v_rest_245)) {
      case TAG_Nil: {
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
        V v_u_249 = (g_list_2emerge_2emergeFrom_240_24dps(v_le_240, v_left_241, v_rest_245, v_ys_243, heff_dup(v_cell_248)));
        heff_drop(v_u_249);
        return v_cell_248;
      }
      case TAG_Cons: {
        V v_a_2410 = heff_dup(heff_field(v_rest_245, 0));
        switch (heff_tag_of(v_ys_243)) {
        case TAG_Nil: {
          heff_drop(v_a_2410);
          V v_cell_2412 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
          V v_u_2413 = (g_list_2emerge_2emergeFrom_240_24dps(v_le_240, v_left_241, v_rest_245, v_ys_243, heff_dup(v_cell_2412)));
          heff_drop(v_u_2413);
          return v_cell_2412;
        }
        case TAG_Cons: {
          V v_b_2414 = heff_dup(heff_field(v_ys_243, 0));
          V v_t_2417;
          if ((heff_dup(v_left_241) == NTAG(TAG_True))) {
            v_t_2417 = heff_tr(heff_call(heff_dup(v_le_240), 2, (V[]){v_a_2410, v_b_2414}));
          } else {
            V v_x1_2416 = heff_tr(heff_call(heff_dup(v_le_240), 2, (V[]){v_b_2414, v_a_2410}));
            v_t_2417 = heff_bool(!(heff_dup(v_x1_2416) == NTAG(TAG_True)));
            heff_drop(v_x1_2416);
          }
          if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
            heff_drop(v_t_2417);
            V v_cell_2418 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
            V v_u_2419 = (g_list_2emerge_2emergeFrom_240_24dps(v_le_240, v_left_241, v_rest_245, v_ys_243, heff_dup(v_cell_2418)));
            heff_drop(v_u_2419);
            return v_cell_2418;
          } else {
            heff_drop(v_t_2417);
            V v_cell_2420 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
            V v_t_2421 = heff_bool(!(heff_dup(v_left_241) == NTAG(TAG_True)));
            heff_drop(v_left_241);
            V v_u_2422 = (g_list_2emerge_2emergeFrom_240_24dps(v_le_240, v_t_2421, v_ys_243, v_rest_245, heff_dup(v_cell_2420)));
            heff_drop(v_u_2422);
            return v_cell_2420;
          }
        }
        default: return heff_nomatch(v_ys_243);
        }
      }
      default: return heff_nomatch(v_rest_245);
      }
    }
    default: return heff_nomatch(v_ys_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emerge_2emergeFrom_240_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_2emergeFrom_240(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emerge_2emergeFrom_240_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_2emergeFrom_240_24dps_entry, 5, 0};

V g_list_2emerge_2emergeFrom_240_24dps(V v_le_240, V v_left_241, V v_x2_242, V v_ys_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    heff_drop(v_left_241);
    return heff_setField(v_d_244, MK_INT(1LL), v_ys_243);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_ys_243)) {
    case TAG_Nil: {
      heff_drop(v_le_240);
      heff_drop(v_left_241);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      return heff_setField(v_d_244, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, v_rest_246}));
    }
    case TAG_Cons: {
      switch (heff_tag_of(v_rest_246)) {
      case TAG_Nil: {
        V v_cell_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
        V v_u_2410 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V t_0 = v_le_240;
        V t_1 = v_left_241;
        V t_2 = v_rest_246;
        V t_3 = v_ys_243;
        V t_4 = v_cell_249;
        v_le_240 = t_0;
        v_left_241 = t_1;
        v_x2_242 = t_2;
        v_ys_243 = t_3;
        v_d_244 = t_4;
        goto top;
      }
      case TAG_Cons: {
        V v_a_2411 = heff_dup(heff_field(v_rest_246, 0));
        switch (heff_tag_of(v_ys_243)) {
        case TAG_Nil: {
          heff_drop(v_a_2411);
          V v_cell_2413 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
          V v_u_2414 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2413));
          heff_drop(v_u_2414);
          V t_0 = v_le_240;
          V t_1 = v_left_241;
          V t_2 = v_rest_246;
          V t_3 = v_ys_243;
          V t_4 = v_cell_2413;
          v_le_240 = t_0;
          v_left_241 = t_1;
          v_x2_242 = t_2;
          v_ys_243 = t_3;
          v_d_244 = t_4;
          goto top;
        }
        case TAG_Cons: {
          V v_b_2415 = heff_dup(heff_field(v_ys_243, 0));
          V v_t_2418;
          if ((heff_dup(v_left_241) == NTAG(TAG_True))) {
            v_t_2418 = heff_tr(heff_call(heff_dup(v_le_240), 2, (V[]){v_a_2411, v_b_2415}));
          } else {
            V v_x1_2417 = heff_tr(heff_call(heff_dup(v_le_240), 2, (V[]){v_b_2415, v_a_2411}));
            v_t_2418 = heff_bool(!(heff_dup(v_x1_2417) == NTAG(TAG_True)));
            heff_drop(v_x1_2417);
          }
          if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
            heff_drop(v_t_2418);
            V v_cell_2419 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
            V v_u_2420 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2419));
            heff_drop(v_u_2420);
            V t_0 = v_le_240;
            V t_1 = v_left_241;
            V t_2 = v_rest_246;
            V t_3 = v_ys_243;
            V t_4 = v_cell_2419;
            v_le_240 = t_0;
            v_left_241 = t_1;
            v_x2_242 = t_2;
            v_ys_243 = t_3;
            v_d_244 = t_4;
            goto top;
          } else {
            heff_drop(v_t_2418);
            V v_cell_2421 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
            V v_u_2422 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2421));
            heff_drop(v_u_2422);
            V v_t_2423 = heff_bool(!(heff_dup(v_left_241) == NTAG(TAG_True)));
            heff_drop(v_left_241);
            V t_0 = v_le_240;
            V t_1 = v_t_2423;
            V t_2 = v_ys_243;
            V t_3 = v_rest_246;
            V t_4 = v_cell_2421;
            v_le_240 = t_0;
            v_left_241 = t_1;
            v_x2_242 = t_2;
            v_ys_243 = t_3;
            v_d_244 = t_4;
            goto top;
          }
        }
        default: return heff_nomatch(v_ys_243);
        }
      }
      default: return heff_nomatch(v_rest_246);
      }
    }
    default: return heff_nomatch(v_ys_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emerge_2emergeFrom_240_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_2emergeFrom_240_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026_entry, 3, 0};

V g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026(V v_left_240, V v_x2_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_left_240);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_left_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_rest_244});
    }
    case TAG_Cons: {
      switch (heff_tag_of(v_rest_244)) {
      case TAG_Nil: {
        V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_248 = (g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      }
      case TAG_Cons: {
        V v_a_249 = heff_dup(heff_field(v_rest_244, 0));
        switch (heff_tag_of(v_ys_242)) {
        case TAG_Nil: {
          heff_drop_rec(v_a_249, 6);
          V v_cell_2411 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
          V v_u_2412 = (g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_2411)));
          heff_drop(v_u_2412);
          return v_cell_2411;
        }
        case TAG_Cons: {
          V v_b_2413 = heff_dup(heff_field(v_ys_242, 0));
          if (((heff_dup(v_left_240) == NTAG(TAG_True)) ? heff_intLe_c(heff_dup(heff_rfield(v_a_249, 0)), heff_dup(heff_rfield(v_b_2413, 0))) : !heff_intLe_c(heff_dup(heff_rfield(v_b_2413, 0)), heff_dup(heff_rfield(v_a_249, 0))))) {
            heff_drop_rec(v_a_249, 6);
            heff_drop_rec(v_b_2413, 6);
            V v_cell_2415 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
            V v_u_2416 = (g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_2415)));
            heff_drop(v_u_2416);
            return v_cell_2415;
          } else {
            heff_drop_rec(v_a_249, 6);
            heff_drop_rec(v_b_2413, 6);
            V v_cell_2417 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
            V v_t_2418 = heff_bool(!(heff_dup(v_left_240) == NTAG(TAG_True)));
            heff_drop(v_left_240);
            V v_u_2419 = (g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026_24dps(v_t_2418, v_ys_242, v_rest_244, heff_dup(v_cell_2417)));
            heff_drop(v_u_2419);
            return v_cell_2417;
          }
        }
        default: return heff_nomatch(v_ys_242);
        }
      }
      default: return heff_nomatch(v_rest_244);
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026(a[0], a[1], a[2]);
}
Clo g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026_24dps_entry, 4, 0};

V g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026_24dps(V v_left_240, V v_x2_241, V v_ys_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_left_240);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_242);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_left_240);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_rest_245}));
    }
    case TAG_Cons: {
      switch (heff_tag_of(v_rest_245)) {
      case TAG_Nil: {
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
        V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
        heff_drop(v_u_249);
        V t_0 = v_left_240;
        V t_1 = v_rest_245;
        V t_2 = v_ys_242;
        V t_3 = v_cell_248;
        v_left_240 = t_0;
        v_x2_241 = t_1;
        v_ys_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
      case TAG_Cons: {
        V v_a_2410 = heff_dup(heff_field(v_rest_245, 0));
        switch (heff_tag_of(v_ys_242)) {
        case TAG_Nil: {
          heff_drop_rec(v_a_2410, 6);
          V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
          V v_u_2413 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2412));
          heff_drop(v_u_2413);
          V t_0 = v_left_240;
          V t_1 = v_rest_245;
          V t_2 = v_ys_242;
          V t_3 = v_cell_2412;
          v_left_240 = t_0;
          v_x2_241 = t_1;
          v_ys_242 = t_2;
          v_d_243 = t_3;
          goto top;
        }
        case TAG_Cons: {
          V v_b_2414 = heff_dup(heff_field(v_ys_242, 0));
          if (((heff_dup(v_left_240) == NTAG(TAG_True)) ? heff_intLe_c(heff_dup(heff_rfield(v_a_2410, 0)), heff_dup(heff_rfield(v_b_2414, 0))) : !heff_intLe_c(heff_dup(heff_rfield(v_b_2414, 0)), heff_dup(heff_rfield(v_a_2410, 0))))) {
            heff_drop_rec(v_a_2410, 6);
            heff_drop_rec(v_b_2414, 6);
            V v_cell_2416 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
            V v_u_2417 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2416));
            heff_drop(v_u_2417);
            V t_0 = v_left_240;
            V t_1 = v_rest_245;
            V t_2 = v_ys_242;
            V t_3 = v_cell_2416;
            v_left_240 = t_0;
            v_x2_241 = t_1;
            v_ys_242 = t_2;
            v_d_243 = t_3;
            goto top;
          } else {
            heff_drop_rec(v_a_2410, 6);
            heff_drop_rec(v_b_2414, 6);
            V v_cell_2418 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
            V v_u_2419 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2418));
            heff_drop(v_u_2419);
            V v_t_2420 = heff_bool(!(heff_dup(v_left_240) == NTAG(TAG_True)));
            heff_drop(v_left_240);
            V t_0 = v_t_2420;
            V t_1 = v_ys_242;
            V t_2 = v_rest_245;
            V t_3 = v_cell_2418;
            v_left_240 = t_0;
            v_x2_241 = t_1;
            v_ys_242 = t_2;
            v_d_243 = t_3;
            goto top;
          }
        }
        default: return heff_nomatch(v_ys_242);
        }
      }
      default: return heff_nomatch(v_rest_245);
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_2emergeFrom_240_24s1159998947x1060767026_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_entry, 3, 0};

V g_list_2emerge_2emergeFrom_240_24s825587185x1704110321(V v_left_240, V v_x2_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_left_240);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_left_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_rest_244});
    }
    case TAG_Cons: {
      switch (heff_tag_of(v_rest_244)) {
      case TAG_Nil: {
        V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_248 = (g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      }
      case TAG_Cons: {
        V v_a_249 = heff_dup(heff_field(v_rest_244, 0));
        switch (heff_tag_of(v_ys_242)) {
        case TAG_Nil: {
          heff_drop_rec(v_a_249, 2);
          V v_cell_2411 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
          V v_u_2412 = (g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_2411)));
          heff_drop(v_u_2412);
          return v_cell_2411;
        }
        case TAG_Cons: {
          V v_b_2413 = heff_dup(heff_field(v_ys_242, 0));
          if (((heff_dup(v_left_240) == NTAG(TAG_True)) ? heff_intLe_c(heff_dup(heff_rfield(v_a_249, 0)), heff_dup(heff_rfield(v_b_2413, 0))) : !heff_intLe_c(heff_dup(heff_rfield(v_b_2413, 0)), heff_dup(heff_rfield(v_a_249, 0))))) {
            heff_drop_rec(v_a_249, 2);
            heff_drop_rec(v_b_2413, 2);
            V v_cell_2415 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
            V v_u_2416 = (g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_2415)));
            heff_drop(v_u_2416);
            return v_cell_2415;
          } else {
            heff_drop_rec(v_a_249, 2);
            heff_drop_rec(v_b_2413, 2);
            V v_cell_2417 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
            V v_t_2418 = heff_bool(!(heff_dup(v_left_240) == NTAG(TAG_True)));
            heff_drop(v_left_240);
            V v_u_2419 = (g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_24dps(v_t_2418, v_ys_242, v_rest_244, heff_dup(v_cell_2417)));
            heff_drop(v_u_2419);
            return v_cell_2417;
          }
        }
        default: return heff_nomatch(v_ys_242);
        }
      }
      default: return heff_nomatch(v_rest_244);
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_2emergeFrom_240_24s825587185x1704110321(a[0], a[1], a[2]);
}
Clo g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_24dps_entry, 4, 0};

V g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_24dps(V v_left_240, V v_x2_241, V v_ys_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_left_240);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_242);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_left_240);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_rest_245}));
    }
    case TAG_Cons: {
      switch (heff_tag_of(v_rest_245)) {
      case TAG_Nil: {
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
        V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
        heff_drop(v_u_249);
        V t_0 = v_left_240;
        V t_1 = v_rest_245;
        V t_2 = v_ys_242;
        V t_3 = v_cell_248;
        v_left_240 = t_0;
        v_x2_241 = t_1;
        v_ys_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
      case TAG_Cons: {
        V v_a_2410 = heff_dup(heff_field(v_rest_245, 0));
        switch (heff_tag_of(v_ys_242)) {
        case TAG_Nil: {
          heff_drop_rec(v_a_2410, 2);
          V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
          V v_u_2413 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2412));
          heff_drop(v_u_2413);
          V t_0 = v_left_240;
          V t_1 = v_rest_245;
          V t_2 = v_ys_242;
          V t_3 = v_cell_2412;
          v_left_240 = t_0;
          v_x2_241 = t_1;
          v_ys_242 = t_2;
          v_d_243 = t_3;
          goto top;
        }
        case TAG_Cons: {
          V v_b_2414 = heff_dup(heff_field(v_ys_242, 0));
          if (((heff_dup(v_left_240) == NTAG(TAG_True)) ? heff_intLe_c(heff_dup(heff_rfield(v_a_2410, 0)), heff_dup(heff_rfield(v_b_2414, 0))) : !heff_intLe_c(heff_dup(heff_rfield(v_b_2414, 0)), heff_dup(heff_rfield(v_a_2410, 0))))) {
            heff_drop_rec(v_a_2410, 2);
            heff_drop_rec(v_b_2414, 2);
            V v_cell_2416 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
            V v_u_2417 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2416));
            heff_drop(v_u_2417);
            V t_0 = v_left_240;
            V t_1 = v_rest_245;
            V t_2 = v_ys_242;
            V t_3 = v_cell_2416;
            v_left_240 = t_0;
            v_x2_241 = t_1;
            v_ys_242 = t_2;
            v_d_243 = t_3;
            goto top;
          } else {
            heff_drop_rec(v_a_2410, 2);
            heff_drop_rec(v_b_2414, 2);
            V v_cell_2418 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
            V v_u_2419 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2418));
            heff_drop(v_u_2419);
            V v_t_2420 = heff_bool(!(heff_dup(v_left_240) == NTAG(TAG_True)));
            heff_drop(v_left_240);
            V t_0 = v_t_2420;
            V t_1 = v_ys_242;
            V t_2 = v_rest_245;
            V t_3 = v_cell_2418;
            v_left_240 = t_0;
            v_x2_241 = t_1;
            v_ys_242 = t_2;
            v_d_243 = t_3;
            goto top;
          }
        }
        default: return heff_nomatch(v_ys_242);
        }
      }
      default: return heff_nomatch(v_rest_245);
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096_entry, 3, 0};

V g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096(V v_left_240, V v_x2_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_left_240);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_left_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_rest_244});
    }
    case TAG_Cons: {
      switch (heff_tag_of(v_rest_244)) {
      case TAG_Nil: {
        V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_248 = (g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      }
      case TAG_Cons: {
        V v_a_249 = heff_dup(heff_field(v_rest_244, 0));
        switch (heff_tag_of(v_ys_242)) {
        case TAG_Nil: {
          heff_drop_rec(v_a_249, 5);
          V v_cell_2411 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
          V v_u_2412 = (g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_2411)));
          heff_drop(v_u_2412);
          return v_cell_2411;
        }
        case TAG_Cons: {
          V v_b_2413 = heff_dup(heff_field(v_ys_242, 0));
          if (((heff_dup(v_left_240) == NTAG(TAG_True)) ? ({ V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_a_249, 0)), 1, 2); int c_ = ({ V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_a_249, 0)), 0, 2); int c_ = ({ V v_t_2428 = heff_intSub(heff_dup(v_t_2415), heff_dup(v_t_2416)); int c_ = ({ V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_b_2413, 0)), 1, 2); int c_ = ({ V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_b_2413, 0)), 0, 2); int c_ = ({ V v_t_2429 = heff_intSub(heff_dup(v_t_2417), heff_dup(v_t_2418)); int c_ = heff_intLe_c_lent(v_t_2428, v_t_2429, 0); heff_drop(v_t_2429); c_; }); heff_drop(v_t_2418); c_; }); heff_drop(v_t_2417); c_; }); heff_drop(v_t_2428); c_; }); heff_drop(v_t_2416); c_; }); heff_drop(v_t_2415); c_; }) : ({ V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_b_2413, 0)), 1, 2); int c_ = ({ V v_t_2420 = heff_get_n(heff_dup(heff_rfield(v_b_2413, 0)), 0, 2); int c_ = ({ V v_t_2430 = heff_intSub(heff_dup(v_t_2419), heff_dup(v_t_2420)); int c_ = ({ V v_t_2421 = heff_get_n(heff_dup(heff_rfield(v_a_249, 0)), 1, 2); int c_ = ({ V v_t_2422 = heff_get_n(heff_dup(heff_rfield(v_a_249, 0)), 0, 2); int c_ = ({ V v_t_2431 = heff_intSub(heff_dup(v_t_2421), heff_dup(v_t_2422)); int c_ = !heff_intLe_c_lent(v_t_2430, v_t_2431, 0); heff_drop(v_t_2431); c_; }); heff_drop(v_t_2422); c_; }); heff_drop(v_t_2421); c_; }); heff_drop(v_t_2430); c_; }); heff_drop(v_t_2420); c_; }); heff_drop(v_t_2419); c_; }))) {
            heff_drop_rec(v_a_249, 5);
            heff_drop_rec(v_b_2413, 5);
            V v_cell_2423 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
            V v_u_2424 = (g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_2423)));
            heff_drop(v_u_2424);
            return v_cell_2423;
          } else {
            heff_drop_rec(v_a_249, 5);
            heff_drop_rec(v_b_2413, 5);
            V v_cell_2425 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
            V v_t_2426 = heff_bool(!(heff_dup(v_left_240) == NTAG(TAG_True)));
            heff_drop(v_left_240);
            V v_u_2427 = (g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096_24dps(v_t_2426, v_ys_242, v_rest_244, heff_dup(v_cell_2425)));
            heff_drop(v_u_2427);
            return v_cell_2425;
          }
        }
        default: return heff_nomatch(v_ys_242);
        }
      }
      default: return heff_nomatch(v_rest_244);
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096(a[0], a[1], a[2]);
}
Clo g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096_24dps_entry, 4, 0};

V g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096_24dps(V v_left_240, V v_x2_241, V v_ys_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_left_240);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_242);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_left_240);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_rest_245}));
    }
    case TAG_Cons: {
      switch (heff_tag_of(v_rest_245)) {
      case TAG_Nil: {
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
        V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
        heff_drop(v_u_249);
        V t_0 = v_left_240;
        V t_1 = v_rest_245;
        V t_2 = v_ys_242;
        V t_3 = v_cell_248;
        v_left_240 = t_0;
        v_x2_241 = t_1;
        v_ys_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
      case TAG_Cons: {
        V v_a_2410 = heff_dup(heff_field(v_rest_245, 0));
        switch (heff_tag_of(v_ys_242)) {
        case TAG_Nil: {
          heff_drop_rec(v_a_2410, 5);
          V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
          V v_u_2413 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2412));
          heff_drop(v_u_2413);
          V t_0 = v_left_240;
          V t_1 = v_rest_245;
          V t_2 = v_ys_242;
          V t_3 = v_cell_2412;
          v_left_240 = t_0;
          v_x2_241 = t_1;
          v_ys_242 = t_2;
          v_d_243 = t_3;
          goto top;
        }
        case TAG_Cons: {
          V v_b_2414 = heff_dup(heff_field(v_ys_242, 0));
          if (((heff_dup(v_left_240) == NTAG(TAG_True)) ? ({ V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_a_2410, 0)), 1, 2); int c_ = ({ V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_a_2410, 0)), 0, 2); int c_ = ({ V v_t_2429 = heff_intSub(heff_dup(v_t_2416), heff_dup(v_t_2417)); int c_ = ({ V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_b_2414, 0)), 1, 2); int c_ = ({ V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_b_2414, 0)), 0, 2); int c_ = ({ V v_t_2430 = heff_intSub(heff_dup(v_t_2418), heff_dup(v_t_2419)); int c_ = heff_intLe_c_lent(v_t_2429, v_t_2430, 0); heff_drop(v_t_2430); c_; }); heff_drop(v_t_2419); c_; }); heff_drop(v_t_2418); c_; }); heff_drop(v_t_2429); c_; }); heff_drop(v_t_2417); c_; }); heff_drop(v_t_2416); c_; }) : ({ V v_t_2420 = heff_get_n(heff_dup(heff_rfield(v_b_2414, 0)), 1, 2); int c_ = ({ V v_t_2421 = heff_get_n(heff_dup(heff_rfield(v_b_2414, 0)), 0, 2); int c_ = ({ V v_t_2431 = heff_intSub(heff_dup(v_t_2420), heff_dup(v_t_2421)); int c_ = ({ V v_t_2422 = heff_get_n(heff_dup(heff_rfield(v_a_2410, 0)), 1, 2); int c_ = ({ V v_t_2423 = heff_get_n(heff_dup(heff_rfield(v_a_2410, 0)), 0, 2); int c_ = ({ V v_t_2432 = heff_intSub(heff_dup(v_t_2422), heff_dup(v_t_2423)); int c_ = !heff_intLe_c_lent(v_t_2431, v_t_2432, 0); heff_drop(v_t_2432); c_; }); heff_drop(v_t_2423); c_; }); heff_drop(v_t_2422); c_; }); heff_drop(v_t_2431); c_; }); heff_drop(v_t_2421); c_; }); heff_drop(v_t_2420); c_; }))) {
            heff_drop_rec(v_a_2410, 5);
            heff_drop_rec(v_b_2414, 5);
            V v_cell_2424 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
            V v_u_2425 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2424));
            heff_drop(v_u_2425);
            V t_0 = v_left_240;
            V t_1 = v_rest_245;
            V t_2 = v_ys_242;
            V t_3 = v_cell_2424;
            v_left_240 = t_0;
            v_x2_241 = t_1;
            v_ys_242 = t_2;
            v_d_243 = t_3;
            goto top;
          } else {
            heff_drop_rec(v_a_2410, 5);
            heff_drop_rec(v_b_2414, 5);
            V v_cell_2426 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
            V v_u_2427 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2426));
            heff_drop(v_u_2427);
            V v_t_2428 = heff_bool(!(heff_dup(v_left_240) == NTAG(TAG_True)));
            heff_drop(v_left_240);
            V t_0 = v_t_2428;
            V t_1 = v_ys_242;
            V t_2 = v_rest_245;
            V t_3 = v_cell_2426;
            v_left_240 = t_0;
            v_x2_241 = t_1;
            v_ys_242 = t_2;
            v_d_243 = t_3;
            goto top;
          }
        }
        default: return heff_nomatch(v_ys_242);
        }
      }
      default: return heff_nomatch(v_rest_245);
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emerge_2emergeFrom_240_24s182101113x1216647303_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_2emergeFrom_240_24s182101113x1216647303_entry, 3, 0};

V g_list_2emerge_2emergeFrom_240_24s182101113x1216647303(V v_left_240, V v_x2_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_left_240);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_left_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_rest_244});
    }
    case TAG_Cons: {
      switch (heff_tag_of(v_rest_244)) {
      case TAG_Nil: {
        V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_248 = (g_list_2emerge_2emergeFrom_240_24s182101113x1216647303_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      }
      case TAG_Cons: {
        V v_a_249 = heff_dup(heff_field(v_rest_244, 0));
        switch (heff_tag_of(v_ys_242)) {
        case TAG_Nil: {
          heff_drop_rec(v_a_249, 5);
          V v_cell_2411 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
          V v_u_2412 = (g_list_2emerge_2emergeFrom_240_24s182101113x1216647303_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_2411)));
          heff_drop(v_u_2412);
          return v_cell_2411;
        }
        case TAG_Cons: {
          V v_b_2413 = heff_dup(heff_field(v_ys_242, 0));
          if (((heff_dup(v_left_240) == NTAG(TAG_True)) ? heff_intLe_c(heff_get_n(heff_dup(heff_rfield(v_a_249, 2)), 0, 2), heff_get_n(heff_dup(heff_rfield(v_b_2413, 2)), 0, 2)) : !heff_intLe_c(heff_get_n(heff_dup(heff_rfield(v_b_2413, 2)), 0, 2), heff_get_n(heff_dup(heff_rfield(v_a_249, 2)), 0, 2)))) {
            heff_drop_rec(v_a_249, 5);
            heff_drop_rec(v_b_2413, 5);
            V v_cell_2415 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
            V v_u_2416 = (g_list_2emerge_2emergeFrom_240_24s182101113x1216647303_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_2415)));
            heff_drop(v_u_2416);
            return v_cell_2415;
          } else {
            heff_drop_rec(v_a_249, 5);
            heff_drop_rec(v_b_2413, 5);
            V v_cell_2417 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
            V v_t_2418 = heff_bool(!(heff_dup(v_left_240) == NTAG(TAG_True)));
            heff_drop(v_left_240);
            V v_u_2419 = (g_list_2emerge_2emergeFrom_240_24s182101113x1216647303_24dps(v_t_2418, v_ys_242, v_rest_244, heff_dup(v_cell_2417)));
            heff_drop(v_u_2419);
            return v_cell_2417;
          }
        }
        default: return heff_nomatch(v_ys_242);
        }
      }
      default: return heff_nomatch(v_rest_244);
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emerge_2emergeFrom_240_24s182101113x1216647303_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_2emergeFrom_240_24s182101113x1216647303(a[0], a[1], a[2]);
}
Clo g_list_2emerge_2emergeFrom_240_24s182101113x1216647303_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_2emergeFrom_240_24s182101113x1216647303_24dps_entry, 4, 0};

V g_list_2emerge_2emergeFrom_240_24s182101113x1216647303_24dps(V v_left_240, V v_x2_241, V v_ys_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_left_240);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_242);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_left_240);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_rest_245}));
    }
    case TAG_Cons: {
      switch (heff_tag_of(v_rest_245)) {
      case TAG_Nil: {
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
        V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
        heff_drop(v_u_249);
        V t_0 = v_left_240;
        V t_1 = v_rest_245;
        V t_2 = v_ys_242;
        V t_3 = v_cell_248;
        v_left_240 = t_0;
        v_x2_241 = t_1;
        v_ys_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
      case TAG_Cons: {
        V v_a_2410 = heff_dup(heff_field(v_rest_245, 0));
        switch (heff_tag_of(v_ys_242)) {
        case TAG_Nil: {
          heff_drop_rec(v_a_2410, 5);
          V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
          V v_u_2413 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2412));
          heff_drop(v_u_2413);
          V t_0 = v_left_240;
          V t_1 = v_rest_245;
          V t_2 = v_ys_242;
          V t_3 = v_cell_2412;
          v_left_240 = t_0;
          v_x2_241 = t_1;
          v_ys_242 = t_2;
          v_d_243 = t_3;
          goto top;
        }
        case TAG_Cons: {
          V v_b_2414 = heff_dup(heff_field(v_ys_242, 0));
          if (((heff_dup(v_left_240) == NTAG(TAG_True)) ? heff_intLe_c(heff_get_n(heff_dup(heff_rfield(v_a_2410, 2)), 0, 2), heff_get_n(heff_dup(heff_rfield(v_b_2414, 2)), 0, 2)) : !heff_intLe_c(heff_get_n(heff_dup(heff_rfield(v_b_2414, 2)), 0, 2), heff_get_n(heff_dup(heff_rfield(v_a_2410, 2)), 0, 2)))) {
            heff_drop_rec(v_a_2410, 5);
            heff_drop_rec(v_b_2414, 5);
            V v_cell_2416 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
            V v_u_2417 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2416));
            heff_drop(v_u_2417);
            V t_0 = v_left_240;
            V t_1 = v_rest_245;
            V t_2 = v_ys_242;
            V t_3 = v_cell_2416;
            v_left_240 = t_0;
            v_x2_241 = t_1;
            v_ys_242 = t_2;
            v_d_243 = t_3;
            goto top;
          } else {
            heff_drop_rec(v_a_2410, 5);
            heff_drop_rec(v_b_2414, 5);
            V v_cell_2418 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
            V v_u_2419 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2418));
            heff_drop(v_u_2419);
            V v_t_2420 = heff_bool(!(heff_dup(v_left_240) == NTAG(TAG_True)));
            heff_drop(v_left_240);
            V t_0 = v_t_2420;
            V t_1 = v_ys_242;
            V t_2 = v_rest_245;
            V t_3 = v_cell_2418;
            v_left_240 = t_0;
            v_x2_241 = t_1;
            v_ys_242 = t_2;
            v_d_243 = t_3;
            goto top;
          }
        }
        default: return heff_nomatch(v_ys_242);
        }
      }
      default: return heff_nomatch(v_rest_245);
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emerge_2emergeFrom_240_24s182101113x1216647303_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_2emergeFrom_240_24s182101113x1216647303_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_entry, 3, 0};

V g_list_2emerge_2emergeFrom_240_24s1486691154x115775505(V v_left_240, V v_x2_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_left_240);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_left_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_rest_244});
    }
    case TAG_Cons: {
      switch (heff_tag_of(v_rest_244)) {
      case TAG_Nil: {
        V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_248 = (g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      }
      case TAG_Cons: {
        V v_a_249 = heff_dup(heff_field(v_rest_244, 0));
        switch (heff_tag_of(v_ys_242)) {
        case TAG_Nil: {
          heff_drop_rec(v_a_249, 7);
          V v_cell_2411 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
          V v_u_2412 = (g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_2411)));
          heff_drop(v_u_2412);
          return v_cell_2411;
        }
        case TAG_Cons: {
          V v_b_2413 = heff_dup(heff_field(v_ys_242, 0));
          if (((heff_dup(v_left_240) == NTAG(TAG_True)) ? heff_intLe_c(heff_dup(heff_rfield(v_a_249, 2)), heff_dup(heff_rfield(v_b_2413, 2))) : !heff_intLe_c(heff_dup(heff_rfield(v_b_2413, 2)), heff_dup(heff_rfield(v_a_249, 2))))) {
            heff_drop_rec(v_a_249, 7);
            heff_drop_rec(v_b_2413, 7);
            V v_cell_2415 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
            V v_u_2416 = (g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_2415)));
            heff_drop(v_u_2416);
            return v_cell_2415;
          } else {
            heff_drop_rec(v_a_249, 7);
            heff_drop_rec(v_b_2413, 7);
            V v_cell_2417 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
            V v_t_2418 = heff_bool(!(heff_dup(v_left_240) == NTAG(TAG_True)));
            heff_drop(v_left_240);
            V v_u_2419 = (g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_24dps(v_t_2418, v_ys_242, v_rest_244, heff_dup(v_cell_2417)));
            heff_drop(v_u_2419);
            return v_cell_2417;
          }
        }
        default: return heff_nomatch(v_ys_242);
        }
      }
      default: return heff_nomatch(v_rest_244);
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_2emergeFrom_240_24s1486691154x115775505(a[0], a[1], a[2]);
}
Clo g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_24dps_entry, 4, 0};

V g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_24dps(V v_left_240, V v_x2_241, V v_ys_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_left_240);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_242);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_left_240);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_rest_245}));
    }
    case TAG_Cons: {
      switch (heff_tag_of(v_rest_245)) {
      case TAG_Nil: {
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
        V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
        heff_drop(v_u_249);
        V t_0 = v_left_240;
        V t_1 = v_rest_245;
        V t_2 = v_ys_242;
        V t_3 = v_cell_248;
        v_left_240 = t_0;
        v_x2_241 = t_1;
        v_ys_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
      case TAG_Cons: {
        V v_a_2410 = heff_dup(heff_field(v_rest_245, 0));
        switch (heff_tag_of(v_ys_242)) {
        case TAG_Nil: {
          heff_drop_rec(v_a_2410, 7);
          V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
          V v_u_2413 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2412));
          heff_drop(v_u_2413);
          V t_0 = v_left_240;
          V t_1 = v_rest_245;
          V t_2 = v_ys_242;
          V t_3 = v_cell_2412;
          v_left_240 = t_0;
          v_x2_241 = t_1;
          v_ys_242 = t_2;
          v_d_243 = t_3;
          goto top;
        }
        case TAG_Cons: {
          V v_b_2414 = heff_dup(heff_field(v_ys_242, 0));
          if (((heff_dup(v_left_240) == NTAG(TAG_True)) ? heff_intLe_c(heff_dup(heff_rfield(v_a_2410, 2)), heff_dup(heff_rfield(v_b_2414, 2))) : !heff_intLe_c(heff_dup(heff_rfield(v_b_2414, 2)), heff_dup(heff_rfield(v_a_2410, 2))))) {
            heff_drop_rec(v_a_2410, 7);
            heff_drop_rec(v_b_2414, 7);
            V v_cell_2416 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
            V v_u_2417 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2416));
            heff_drop(v_u_2417);
            V t_0 = v_left_240;
            V t_1 = v_rest_245;
            V t_2 = v_ys_242;
            V t_3 = v_cell_2416;
            v_left_240 = t_0;
            v_x2_241 = t_1;
            v_ys_242 = t_2;
            v_d_243 = t_3;
            goto top;
          } else {
            heff_drop_rec(v_a_2410, 7);
            heff_drop_rec(v_b_2414, 7);
            V v_cell_2418 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
            V v_u_2419 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2418));
            heff_drop(v_u_2419);
            V v_t_2420 = heff_bool(!(heff_dup(v_left_240) == NTAG(TAG_True)));
            heff_drop(v_left_240);
            V t_0 = v_t_2420;
            V t_1 = v_ys_242;
            V t_2 = v_rest_245;
            V t_3 = v_cell_2418;
            v_left_240 = t_0;
            v_x2_241 = t_1;
            v_ys_242 = t_2;
            v_d_243 = t_3;
            goto top;
          }
        }
        default: return heff_nomatch(v_ys_242);
        }
      }
      default: return heff_nomatch(v_rest_245);
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_2emergeFrom_240_24s1486691154x115775505_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_entry, 3, 0};

V g_list_2emerge_2emergeFrom_240_24s1476184047x773913162(V v_left_240, V v_x2_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_left_240);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_left_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_rest_244});
    }
    case TAG_Cons: {
      switch (heff_tag_of(v_rest_244)) {
      case TAG_Nil: {
        V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_248 = (g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      }
      case TAG_Cons: {
        V v_a_249 = heff_dup(heff_field(v_rest_244, 0));
        switch (heff_tag_of(v_ys_242)) {
        case TAG_Nil: {
          heff_drop_rec(v_a_249, 4);
          V v_cell_2411 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
          V v_u_2412 = (g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_2411)));
          heff_drop(v_u_2412);
          return v_cell_2411;
        }
        case TAG_Cons: {
          V v_b_2413 = heff_dup(heff_field(v_ys_242, 0));
          if ((heff_dup(v_left_240) == NTAG(TAG_True))) {
            V v_a_2415 = ({ V b_0 = heff_get_n(v_a_249, 1, 4); V b_1 = heff_get_n(v_b_2413, 1, 4); V r_ = (g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
            switch (heff_tag_of(v_a_2415)) {
            case TAG_LT: {
              V v_cell_2416 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
              V v_u_2417 = (g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_2416)));
              heff_drop(v_u_2417);
              return v_cell_2416;
            }
            case TAG_EQ: {
              V v_cell_2418 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
              V v_u_2419 = (g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_2418)));
              heff_drop(v_u_2419);
              return v_cell_2418;
            }
            case TAG_GT: {
              V v_cell_2420 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
              V v_t_2421 = heff_bool(!(heff_dup(v_left_240) == NTAG(TAG_True)));
              heff_drop(v_left_240);
              V v_u_2422 = (g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_24dps(v_t_2421, v_ys_242, v_rest_244, heff_dup(v_cell_2420)));
              heff_drop(v_u_2422);
              return v_cell_2420;
            }
            default: return heff_nomatch(v_a_2415);
            }
          } else {
            V v_a_2423 = ({ V b_0 = heff_get_n(v_b_2413, 1, 4); V b_1 = heff_get_n(v_a_249, 1, 4); V r_ = (g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
            switch (heff_tag_of(v_a_2423)) {
            case TAG_LT: {
              V v_cell_2424 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
              V v_t_2425 = heff_bool(!(heff_dup(v_left_240) == NTAG(TAG_True)));
              heff_drop(v_left_240);
              V v_u_2426 = (g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_24dps(v_t_2425, v_ys_242, v_rest_244, heff_dup(v_cell_2424)));
              heff_drop(v_u_2426);
              return v_cell_2424;
            }
            case TAG_EQ: {
              V v_cell_2427 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
              V v_t_2428 = heff_bool(!(heff_dup(v_left_240) == NTAG(TAG_True)));
              heff_drop(v_left_240);
              V v_u_2429 = (g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_24dps(v_t_2428, v_ys_242, v_rest_244, heff_dup(v_cell_2427)));
              heff_drop(v_u_2429);
              return v_cell_2427;
            }
            case TAG_GT: {
              V v_cell_2430 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
              V v_u_2431 = (g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_24dps(v_left_240, v_rest_244, v_ys_242, heff_dup(v_cell_2430)));
              heff_drop(v_u_2431);
              return v_cell_2430;
            }
            default: return heff_nomatch(v_a_2423);
            }
          }
        }
        default: return heff_nomatch(v_ys_242);
        }
      }
      default: return heff_nomatch(v_rest_244);
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_2emergeFrom_240_24s1476184047x773913162(a[0], a[1], a[2]);
}
Clo g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_24dps_entry, 4, 0};

V g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_24dps(V v_left_240, V v_x2_241, V v_ys_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_left_240);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_242);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_left_240);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_rest_245}));
    }
    case TAG_Cons: {
      switch (heff_tag_of(v_rest_245)) {
      case TAG_Nil: {
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
        V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
        heff_drop(v_u_249);
        V t_0 = v_left_240;
        V t_1 = v_rest_245;
        V t_2 = v_ys_242;
        V t_3 = v_cell_248;
        v_left_240 = t_0;
        v_x2_241 = t_1;
        v_ys_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
      case TAG_Cons: {
        V v_a_2410 = heff_dup(heff_field(v_rest_245, 0));
        switch (heff_tag_of(v_ys_242)) {
        case TAG_Nil: {
          heff_drop_rec(v_a_2410, 4);
          V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
          V v_u_2413 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2412));
          heff_drop(v_u_2413);
          V t_0 = v_left_240;
          V t_1 = v_rest_245;
          V t_2 = v_ys_242;
          V t_3 = v_cell_2412;
          v_left_240 = t_0;
          v_x2_241 = t_1;
          v_ys_242 = t_2;
          v_d_243 = t_3;
          goto top;
        }
        case TAG_Cons: {
          V v_b_2414 = heff_dup(heff_field(v_ys_242, 0));
          if ((heff_dup(v_left_240) == NTAG(TAG_True))) {
            V v_a_2416 = ({ V b_0 = heff_get_n(v_a_2410, 1, 4); V b_1 = heff_get_n(v_b_2414, 1, 4); V r_ = (g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
            switch (heff_tag_of(v_a_2416)) {
            case TAG_LT: {
              V v_cell_2417 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
              V v_u_2418 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2417));
              heff_drop(v_u_2418);
              V t_0 = v_left_240;
              V t_1 = v_rest_245;
              V t_2 = v_ys_242;
              V t_3 = v_cell_2417;
              v_left_240 = t_0;
              v_x2_241 = t_1;
              v_ys_242 = t_2;
              v_d_243 = t_3;
              goto top;
            }
            case TAG_EQ: {
              V v_cell_2419 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
              V v_u_2420 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2419));
              heff_drop(v_u_2420);
              V t_0 = v_left_240;
              V t_1 = v_rest_245;
              V t_2 = v_ys_242;
              V t_3 = v_cell_2419;
              v_left_240 = t_0;
              v_x2_241 = t_1;
              v_ys_242 = t_2;
              v_d_243 = t_3;
              goto top;
            }
            case TAG_GT: {
              V v_cell_2421 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
              V v_u_2422 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2421));
              heff_drop(v_u_2422);
              V v_t_2423 = heff_bool(!(heff_dup(v_left_240) == NTAG(TAG_True)));
              heff_drop(v_left_240);
              V t_0 = v_t_2423;
              V t_1 = v_ys_242;
              V t_2 = v_rest_245;
              V t_3 = v_cell_2421;
              v_left_240 = t_0;
              v_x2_241 = t_1;
              v_ys_242 = t_2;
              v_d_243 = t_3;
              goto top;
            }
            default: return heff_nomatch(v_a_2416);
            }
          } else {
            V v_a_2424 = ({ V b_0 = heff_get_n(v_b_2414, 1, 4); V b_1 = heff_get_n(v_a_2410, 1, 4); V r_ = (g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
            switch (heff_tag_of(v_a_2424)) {
            case TAG_LT: {
              V v_cell_2425 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
              V v_u_2426 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2425));
              heff_drop(v_u_2426);
              V v_t_2427 = heff_bool(!(heff_dup(v_left_240) == NTAG(TAG_True)));
              heff_drop(v_left_240);
              V t_0 = v_t_2427;
              V t_1 = v_ys_242;
              V t_2 = v_rest_245;
              V t_3 = v_cell_2425;
              v_left_240 = t_0;
              v_x2_241 = t_1;
              v_ys_242 = t_2;
              v_d_243 = t_3;
              goto top;
            }
            case TAG_EQ: {
              V v_cell_2428 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
              V v_u_2429 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2428));
              heff_drop(v_u_2429);
              V v_t_2430 = heff_bool(!(heff_dup(v_left_240) == NTAG(TAG_True)));
              heff_drop(v_left_240);
              V t_0 = v_t_2430;
              V t_1 = v_ys_242;
              V t_2 = v_rest_245;
              V t_3 = v_cell_2428;
              v_left_240 = t_0;
              v_x2_241 = t_1;
              v_ys_242 = t_2;
              v_d_243 = t_3;
              goto top;
            }
            case TAG_GT: {
              V v_cell_2431 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
              V v_u_2432 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2431));
              heff_drop(v_u_2432);
              V t_0 = v_left_240;
              V t_1 = v_rest_245;
              V t_2 = v_ys_242;
              V t_3 = v_cell_2431;
              v_left_240 = t_0;
              v_x2_241 = t_1;
              v_ys_242 = t_2;
              v_d_243 = t_3;
              goto top;
            }
            default: return heff_nomatch(v_a_2424);
            }
          }
        }
        default: return heff_nomatch(v_ys_242);
        }
      }
      default: return heff_nomatch(v_rest_245);
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_2emergeFrom_240_24s1476184047x773913162_24dps(a[0], a[1], a[2], a[3]);
}