// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_BDelayedBy 11524
#define TAG_Become 65038
#define TAG_CBind 55652
#define TAG_Catch 6517
#define TAG_De 8978
#define TAG_Delayed2 38439
#define TAG_Describe 2650
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LSnoc 32613
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkSyn 7342
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_NotInScope 14443
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SaveDelayed 42463
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_SpId 35501
#define TAG_Throw 56084
#define TAG_TopL 65516
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Wake 10253
#define LBL_aliases 1464806715
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_defaults 1389419502
#define LBL_dflt 9576017
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_fields 672433636
#define LBL_globals 352931696
#define LBL_goal 9673690
#define LBL_insts 301719303
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_level 304224158
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_ret 322331
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_ty 10476
#define LBL_val 326043
#define LBL_values 1123329101
#define LBL_var 326049
#define LBL_wantedBy 1134124532
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_len__names__locals__ctx[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eelab_2ememoed_2econs(V, V);
V g_heff_2eelab_2ememoed_2econs_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2econs_clo;
V g_heff_2eelab_2ememoed_2erecordM(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2erecordM_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2erecordM_clo;
V g_heff_2eelab_2emeta_2eattempt(V, V, V);
V g_heff_2eelab_2emeta_2eattempt_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eattempt_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
V g_heff_2eelab_2erename_2efirstAliasOf(V, V);
V g_heff_2eelab_2erename_2efirstAliasOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2efirstAliasOf_clo;
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eanyP(V, V);
V g_heff_2eelab_2erules_2eanyP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eanyP_clo;
V g_heff_2eelab_2erules_2eapartForced(V, V, V);
V g_heff_2eelab_2erules_2eapartForced_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapartForced_clo;
V g_heff_2eelab_2erules_2eapartSpines(V, V, V);
V g_heff_2eelab_2erules_2eapartSpines_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapartSpines_clo;
V g_heff_2eelab_2erules_2eautoRec(V, V, V);
V g_heff_2eelab_2erules_2eautoRec_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eautoRec_clo;
V g_heff_2eelab_2erules_2eboundGo(V, V, V);
V g_heff_2eelab_2erules_2eboundGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eboundGo_clo;
V g_heff_2eelab_2erules_2ecasesAt(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecasesAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecasesAt_clo;
V g_heff_2eelab_2erules_2ecodeAt(V, V, V, V, V);
V g_heff_2eelab_2erules_2ecodeAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecodeAt_clo;
V g_heff_2eelab_2erules_2eelStrZ(V, V, V, V);
V g_heff_2eelab_2erules_2eelStrZ_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelStrZ_clo;
V g_heff_2eelab_2erules_2efieldIdxs(V, V);
V g_heff_2eelab_2erules_2efieldIdxs_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldIdxs_clo;
V g_heff_2eelab_2erules_2efixEnv(V, V, V);
V g_heff_2eelab_2erules_2efixEnv_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efixEnv_clo;
V g_heff_2eelab_2erules_2efreshMeta(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efreshMeta_clo;
V g_heff_2eelab_2erules_2egoalShown(V, V, V);
V g_heff_2eelab_2erules_2egoalShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egoalShown_clo;
V g_heff_2eelab_2erules_2eimplicitDefaultAt(V, V, V);
V g_heff_2eelab_2erules_2eimplicitDefaultAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitDefaultAt_clo;
V g_heff_2eelab_2erules_2eimplicitDefaultChk(V, V);
V g_heff_2eelab_2erules_2eimplicitDefaultChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitDefaultChk_clo;
V g_heff_2eelab_2erules_2eletted(V, V, V, V, V);
V g_heff_2eelab_2erules_2eletted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletted_clo;
V g_heff_2eelab_2erules_2elettedAt(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2elettedAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elettedAt_clo;
V g_heff_2eelab_2erules_2ematchLater(V, V, V, V, V);
V g_heff_2eelab_2erules_2ematchLater_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ematchLater_clo;
V g_heff_2eelab_2erules_2ementionsTermF(V, V, V);
V g_heff_2eelab_2erules_2ementionsTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_clo;
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(V, V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_clo;
V g_heff_2eelab_2erules_2enamesFor(V);
V g_heff_2eelab_2erules_2enamesFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamesFor_clo;
V g_heff_2eelab_2erules_2enamesFor_24dps(V, V);
V g_heff_2eelab_2erules_2enamesFor_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamesFor_24dps_clo;
V g_heff_2eelab_2erules_2enumLitChk(V, V);
V g_heff_2eelab_2erules_2enumLitChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitChk_clo;
V g_heff_2eelab_2erules_2enumLitSyn(V, V);
V g_heff_2eelab_2erules_2enumLitSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitSyn_clo;
V g_heff_2eelab_2erules_2eplacesGo(V, V);
V g_heff_2eelab_2erules_2eplacesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesGo_clo;
V g_heff_2eelab_2erules_2eplacesSaid(V);
V g_heff_2eelab_2erules_2eplacesSaid_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesSaid_clo;
V g_heff_2eelab_2erules_2eplacesSaid_24acc(V, V);
V g_heff_2eelab_2erules_2eplacesSaid_24acc_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesSaid_24acc_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2erecChk(V, V);
V g_heff_2eelab_2erules_2erecChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecChk_clo;
V g_heff_2eelab_2erules_2erecordOf(V, V);
V g_heff_2eelab_2erules_2erecordOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordOf_clo;
V g_heff_2eelab_2erules_2erecoverWith(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecoverWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecoverWith_clo;
V g_heff_2eelab_2erules_2erecovering(V);
V g_heff_2eelab_2erules_2erecovering_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecovering_clo;
V g_heff_2eelab_2erules_2esameField(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esameField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esameField_clo;
V g_heff_2eelab_2erules_2etooDeep(V, V, V, V);
V g_heff_2eelab_2erules_2etooDeep_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etooDeep_clo;
V g_heff_2eelab_2erules_2etooLarge(V, V, V, V, V);
V g_heff_2eelab_2erules_2etooLarge_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etooLarge_clo;
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2etyStrM(V, V);
V g_heff_2eelab_2erules_2etyStrM_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrM_clo;
V g_heff_2eelab_2erules_2etyStrZ(V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_clo;
V g_heff_2eelab_2erules_2euniverseAt(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2euniverseAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseAt_clo;
V g_heff_2eelab_2erules_2evarGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2evarGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evarGo_clo;
V g_heff_2eelab_2eunify_2esubstOf(V);
V g_heff_2eelab_2eunify_2esubstOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstOf_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2edecodeN(V);
V g_heff_2eelab_2evalue_2edecodeN_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeN_clo;
V g_heff_2eelab_2evalue_2eemap_24s196957333x715530534(V);
V g_heff_2eelab_2evalue_2eemap_24s196957333x715530534_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eemap_24s196957333x715530534_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2eany_24s228396297x1310020012(V);
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a);
extern Clo g_list_2eany_24s228396297x1310020012_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f783067987x1926181389(V, V, V, V, V);
V g_list_2emap_24f783067987x1926181389_entry(V self, V *a);
extern Clo g_list_2emap_24f783067987x1926181389_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1729297000x968708966(V);
V g_list_2emap_24s1729297000x968708966_entry(V self, V *a);
extern Clo g_list_2emap_24s1729297000x968708966_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
Clo g_heff_2eelab_2erules_2eanyP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eanyP_entry, 2, 0};

V g_heff_2eelab_2erules_2eanyP(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eanyP_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2eanyP(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2ementionsTermF_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTermF_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ementionsTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsTermF_entry, 3, 0};

V g_heff_2eelab_2erules_2ementionsTermF(V v_r_240, V v_d_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SLocal: {
    V v_i_243 = heff_field(v_t_242, 0);
    return heff_tail(heff_get_n(v_r_240, 2, 3), 2, (V[]){v_d_241, heff_dup(v_i_243)});
  }
  case TAG_SGlobal: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    V v_a_245 = heff_field(v_t_242, 0);
    return heff_tail(heff_get_n(v_r_240, 1, 3), 2, (V[]){v_d_241, heff_dup(v_a_245)});
  }
  case TAG_SApp: {
    V v_f_246 = heff_field(v_t_242, 0);
    V v_a_247 = heff_field(v_t_242, 1);
    V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_241), heff_dup(v_f_246)}));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_d_241);
      heff_drop(v_t_248);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_248);
      return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_d_241, heff_dup(v_a_247)});
    }
  }
  case TAG_SLam: {
    V v_dd_249 = heff_field(v_t_242, 0);
    V v_t2_2410 = heff_field(v_t_242, 1);
    switch (heff_tag_of(v_t2_2410)) {
    case TAG_MkAbs: {
      V v_b_2412 = heff_field(v_t2_2410, 1);
      V v_t_2413 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_241), heff_dup(v_dd_249)}));
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_d_241);
        heff_drop(v_t_2413);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2413);
        return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){heff_intAdd(v_d_241, MK_INT(1LL)), heff_dup(v_b_2412)});
      }
    }
    case TAG_AbsConst: {
      V v_b_2414 = heff_field(v_t2_2410, 0);
      V v_t_2415 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_241), heff_dup(v_dd_249)}));
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_d_241);
        heff_drop(v_t_2415);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2415);
        return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_d_241, heff_dup(v_b_2414)});
      }
    }
    default: return heff_nomatch(v_t2_2410);
    }
  }
  case TAG_SCons: {
    V v_dct_2416 = heff_field(v_t_242, 0);
    V v_t_2417 = heff_arrayToList(heff_dup(heff_rfield(v_dct_2416, 0)));
    V v_t_2418 = heff_arrayToList(heff_dup(heff_rfield(v_dct_2416, 2)));
    V v_t_2419 = (g_heff_2eutil_2edict_2ezipKV(v_t_2417, v_t_2418));
    return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_lam0, 1, 2, (V[]){v_r_240, v_d_241}); V a_1 = v_t_2419; V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2419); r_; });
  }
  case TAG_SProj: {
    V v_e_2423 = heff_field(v_t_242, 0);
    return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_d_241, heff_dup(v_e_2423)});
  }
  case TAG_STag: {
    V v_as_2426 = heff_field(v_t_242, 1);
    V v_t_2427 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_d_241}));
    return ({ V a_0 = v_t_2427; V b_1 = heff_arrayToList(heff_dup(v_as_2426)); V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_SMatch: {
    V v_e_2428 = heff_field(v_t_242, 0);
    V v_cs_2429 = heff_field(v_t_242, 1);
    V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_241), heff_dup(v_e_2428)}));
    if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_d_241);
      heff_drop(v_t_2430);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2430);
      V v_t_2431 = heff_arrayToList(heff_dup(heff_rfield(v_cs_2429, 0)));
      V v_t_2432 = heff_arrayToList(heff_dup(heff_rfield(v_cs_2429, 2)));
      V v_t_2433 = (g_heff_2eutil_2edict_2ezipKV(v_t_2431, v_t_2432));
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_lam1, 1, 2, (V[]){v_d_241, v_r_240}); V a_1 = v_t_2433; V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2433); r_; });
    }
  }
  case TAG_SSpecialize: {
    V v_e_2440 = heff_field(v_t_242, 0);
    V v_v_2442 = heff_field(v_t_242, 2);
    V v_t_2443 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_241), heff_dup(v_e_2440)}));
    if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_d_241);
      heff_drop(v_t_2443);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2443);
      return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_d_241, heff_dup(v_v_2442)});
    }
  }
  case TAG_SIs: {
    V v_e_2444 = heff_field(v_t_242, 0);
    return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_d_241, heff_dup(v_e_2444)});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    V v_e_2445 = heff_field(v_t_242, 0);
    return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_d_241, heff_dup(v_e_2445)});
  }
  case TAG_SFix: {
    V v_dd_2446 = heff_field(v_t_242, 0);
    V v_t2_2447 = heff_field(v_t_242, 1);
    switch (heff_tag_of(v_t2_2447)) {
    case TAG_MkAbs: {
      V v_b_2449 = heff_field(v_t2_2447, 1);
      V v_t_2450 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_241), heff_dup(v_dd_2446)}));
      if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_d_241);
        heff_drop(v_t_2450);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2450);
        return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){heff_intAdd(v_d_241, MK_INT(1LL)), heff_dup(v_b_2449)});
      }
    }
    case TAG_AbsConst: {
      V v_b_2451 = heff_field(v_t2_2447, 0);
      V v_t_2452 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_241), heff_dup(v_dd_2446)}));
      if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_d_241);
        heff_drop(v_t_2452);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2452);
        return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_d_241, heff_dup(v_b_2451)});
      }
    }
    default: return heff_nomatch(v_t2_2447);
    }
  }
  case TAG_SImplicit: {
    V v_e_2454 = heff_field(v_t_242, 1);
    return heff_tail(heff_get_n(v_r_240, 0, 3), 2, (V[]){v_d_241, heff_dup(v_e_2454)});
  }
  case TAG_SPrim: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SMetaApp: {
    V v_ty_2458 = heff_field(v_t_242, 2);
    return heff_tail(heff_get_n(v_r_240, 1, 3), 2, (V[]){v_d_241, heff_dup(v_ty_2458)});
  }
  case TAG_SLitInt: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SLitBytes: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2erules_2ementionsTermF_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2ementionsTermF(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2ementionsTermF_lam0(V self, V *args) {
  V v_x3_2420 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x3_2420)) {
  case TAG_MkPair: {
    V v_v_2422 = heff_field(v_x3_2420, 1);
    heff_take_n(v_x3_2420, 2ULL, 2);
    V f_ = heff_get_n(v_r_240, 0, 3);
    heff_room[0] = v_d_241;
    heff_room[1] = v_v_2422;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x3_2420);
  }
}
V g_heff_2eelab_2erules_2ementionsTermF_lam1(V self, V *args) {
  V v_x3_2434 = args[0];
  V v_d_241 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x3_2434)) {
  case TAG_MkPair: {
    V v_x32_2436 = heff_field(v_x3_2434, 1);
    heff_take_n(v_x3_2434, 2ULL, 2);
    switch (heff_tag_of(v_x32_2436)) {
    case TAG_MkPair: {
      V v_xs_2437 = heff_field(v_x32_2436, 0);
      V v_b_2438 = heff_field(v_x32_2436, 1);
      heff_take_n(v_x32_2436, 3ULL, 2);
      V v_t_2439 = heff_intAdd(v_d_241, heff_arrayLength(v_xs_2437));
      V f_ = heff_get_n(v_r_240, 0, 3);
      heff_room[0] = v_t_2439;
      heff_room[1] = v_b_2438;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_x32_2436);
    }
  }
  default: return heff_nomatch(v_x3_2434);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2enamesFor_str0, 1, "x");
Clo g_heff_2eelab_2erules_2enamesFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enamesFor_entry, 1, 0};

V g_heff_2eelab_2erules_2enamesFor(V v_n_240) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  } else {
    V v_t_242 = heff_intShow(heff_intSub(heff_dup(v_n_240), MK_INT(1LL)));
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2eelab_2erules_2enamesFor_str0), v_t_242), heff_hole()});
    V v_u_244 = (g_heff_2eelab_2erules_2enamesFor_24dps(heff_intSub(v_n_240, MK_INT(1LL)), heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
}
V g_heff_2eelab_2erules_2enamesFor_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enamesFor(a[0]);
}
V g_heff_2eelab_2erules_2eelStrZ_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eelStrZ_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eelStrZ_lam0, 1, 0};
V g_heff_2eelab_2erules_2eelStrZ_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eelStrZ_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eelStrZ_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eelStrZ_entry, 4, 0};

V g_heff_2eelab_2erules_2eelStrZ(V v_e_240, V v_m_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eelStrZ_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_246}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_247, heff_clo_n(g_heff_2eelab_2erules_2eelStrZ_lam1, 1, 3, (V[]){v_m_241, v_e_240, v_k_243})});
}
V g_heff_2eelab_2erules_2eelStrZ_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eelStrZ(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2eelStrZ_lam0(V self, V *args) {
  V v_c_244 = args[0];
  return heff_get_n(v_c_244, 3, 8);
}
V g_heff_2eelab_2erules_2eelStrZ_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_2412 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_2411)));
  V v_t_2413 = heff_get_n(heff_get_n(v_e_240, 1, 6), 2, 7);
  V v_t_2414 = ({ V a_0 = v_t_2413; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_2413); r_; });
  V v_x2_2415 = ({ V a_0 = v_t_2414; V a_1 = v_x_2411; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_2414); r_; });
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nothing: {
    return v_d_2412;
  }
  case TAG_Just: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    heff_take_n(v_x2_2415, 1ULL, 1);
    heff_drop(v_d_2412);
    return v_x_2416;
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2eelab_2erules_2eelStrZ_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = ({ V a_0 = v_x_248; V r_ = (g_heff_2eelab_2eunify_2ezonker(a_0)); heff_drop(v_x_248); r_; });
  V v_e_2410 = heff_tr(heff_call(heff_get_n(v_t_249, 0, 2), 1, (V[]){heff_get_n(v_m_241, 0, 2)}));
  V v_t_2417 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2eelStrZ_lam2, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_e_2418 = heff_tr(heff_call(heff_get_n(v_t_2417, 0, 2), 1, (V[]){v_e_2410}));
  V v_t_2419 = heff_get_n(heff_get_n(v_e_240, 0, 6), 1, 4);
  V v_x_2420 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138(MK_INT(0LL), MK_INT(0LL), v_t_2419, v_e_2418));
  V f_ = v_k_243;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecovering_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2erecovering_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecovering_lam1, 1, 0};
V g_heff_2eelab_2erules_2erecovering_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2erecovering_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecovering_lam3, 1, 0};
V g_heff_2eelab_2erules_2erecovering_lam5(V self, V *args);
V g_heff_2eelab_2erules_2erecovering_lam4(V self, V *args);
V g_heff_2eelab_2erules_2erecovering_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecovering_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecovering_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecovering_entry, 1, 0};

V g_heff_2eelab_2erules_2erecovering(V v_c_240) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecovering_lam0, 4, 1, (V[]){heff_dup(v_c_240)})});
}
V g_heff_2eelab_2erules_2erecovering_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2erecovering(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2erecovering_lam1(V self, V *args) {
  V v_c0_245 = args[0];
  return v_c0_245;
}
V g_heff_2eelab_2erules_2erecovering_lam3(V self, V *args) {
  V v_sv_2410 = args[0];
  return v_sv_2410;
}
V g_heff_2eelab_2erules_2erecovering_lam5(V self, V *args) {
  V v_s_2417 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_a_242 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_e_241; V a_1 = v_a_242; V a_2 = v_s_2417; V a_3 = v_x_249; V a_4 = v_x_2413; V a_5 = heff_dup(v_hd_243); V a_6 = heff_get_n(v_hd_243, 0, 3); V r_ = (g_heff_2eelab_2erules_2erecoverWith(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_e_241); r_; });
}
V g_heff_2eelab_2erules_2erecovering_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_x_249 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_m_2415;
  switch (heff_tag_of(v_c_240)) {
  case TAG_MkChk: {
    V v_f_2414 = heff_field(v_c_240, 0);
    heff_take_n(v_c_240, 1ULL, 1);
    v_m_2415 = heff_tr(heff_call(v_f_2414, 2, (V[]){heff_dup(v_e_241), heff_dup(v_a_242)}));
    break;
  }
  default: heff_nomatch(v_c_240);
  }
  V v_t_2416 = heff_tr(heff_call(v_m_2415, 2, (V[]){heff_dup(v_hd_243), heff_dup(heff_rfield(v_hd_243, 0))}));
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2416, heff_clo_n(g_heff_2eelab_2erules_2erecovering_lam5, 1, 5, (V[]){v_e_241, v_a_242, v_x_249, v_x_2413, heff_dup(v_hd_243)})})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_243, 2), 1, (V[]){v_t_2419}));
  V f_ = heff_get_n(v_hd_243, 1, 3);
  heff_room[0] = v_t_2420;
  heff_room[1] = v_k_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2erecovering_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_SaveDelayed, 1, (V[]){((V)&g_heff_2eelab_2erules_2erecovering_lam3_clo)})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2erecovering_lam4, 1, 6, (V[]){v_c_240, v_e_241, v_a_242, v_hd_243, v_x_249, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2erecovering_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_242 = args[1];
  V v_hd_243 = args[2];
  V v_k_244 = args[3];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2erecovering_lam1_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_t_248;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecovering_lam2, 1, 5, (V[]){v_hd_243, v_c_240, v_e_241, v_a_242, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2eapartForced_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapartForced_entry, 3, 0};

V g_heff_2eelab_2erules_2eapartForced(V v_mc_240, V v_t_241, V v_conclusion_242) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_VU: {
    switch (heff_tag_of(v_conclusion_242)) {
    case TAG_VU: {
      return NTAG(TAG_False);
    }
    case TAG_VDecode: {
      V v_conclusion1_245 = heff_field(v_conclusion_242, 0);
      switch (heff_tag_of(v_conclusion1_245)) {
      case TAG_HLocal: {
        return NTAG(TAG_False);
      }
      case TAG_HGlobal: {
        switch (heff_tag_of(v_t_241)) {
        case TAG_VU: {
          return NTAG(TAG_True);
        }
        case TAG_VDecode: {
          V v_h_2413 = heff_field(v_t_241, 0);
          switch (heff_tag_of(v_h_2413)) {
          case TAG_HLocal: {
            return NTAG(TAG_True);
          }
          case TAG_HGlobal: {
            return NTAG(TAG_True);
          }
          case TAG_HMeta: {
            return NTAG(TAG_True);
          }
          case TAG_HError: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_h_2413);
          }
        }
        case TAG_VFunction: {
          return NTAG(TAG_True);
        }
        case TAG_VRecord: {
          return NTAG(TAG_True);
        }
        case TAG_VSum: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimInt: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimFloat: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimString: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimRune: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimArray: {
          return NTAG(TAG_True);
        }
        case TAG_VFixed: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_t_241);
        }
      }
      case TAG_HMeta: {
        return NTAG(TAG_False);
      }
      case TAG_HError: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_conclusion1_245);
      }
    }
    case TAG_VFunction: {
      return NTAG(TAG_False);
    }
    case TAG_VRecord: {
      return NTAG(TAG_False);
    }
    case TAG_VSum: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimArray: {
      return NTAG(TAG_False);
    }
    case TAG_VFixed: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_conclusion_242);
    }
  }
  case TAG_VDecode: {
    V v_t1_2446 = heff_field(v_t_241, 0);
    V v_sp_2447 = heff_field(v_t_241, 1);
    switch (heff_tag_of(v_t1_2446)) {
    case TAG_HLocal: {
      return NTAG(TAG_False);
    }
    case TAG_HGlobal: {
      V v_k2_2452 = heff_field(v_t1_2446, 0);
      switch (heff_tag_of(v_conclusion_242)) {
      case TAG_VU: {
        return NTAG(TAG_False);
      }
      case TAG_VDecode: {
        V v_conclusion1_2454 = heff_field(v_conclusion_242, 0);
        V v_csp_2455 = heff_field(v_conclusion_242, 1);
        switch (heff_tag_of(v_conclusion1_2454)) {
        case TAG_HLocal: {
          return NTAG(TAG_False);
        }
        case TAG_HGlobal: {
          V v_k_2460 = heff_field(v_conclusion1_2454, 0);
          if (heff_strEq_c_lent(v_k_2460, v_k2_2452, 0)) {
            HEFF_LAST return g_heff_2eelab_2erules_2eapartSpines(v_mc_240, v_sp_2447, v_csp_2455);
          } else {
            return NTAG(TAG_True);
          }
        }
        case TAG_HMeta: {
          return NTAG(TAG_False);
        }
        case TAG_HError: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_conclusion1_2454);
        }
      }
      case TAG_VFunction: {
        return NTAG(TAG_False);
      }
      case TAG_VRecord: {
        return NTAG(TAG_False);
      }
      case TAG_VSum: {
        return NTAG(TAG_False);
      }
      case TAG_VPrimInt: {
        return NTAG(TAG_False);
      }
      case TAG_VPrimFloat: {
        return NTAG(TAG_False);
      }
      case TAG_VPrimString: {
        return NTAG(TAG_False);
      }
      case TAG_VPrimRune: {
        return NTAG(TAG_False);
      }
      case TAG_VPrimArray: {
        return NTAG(TAG_False);
      }
      case TAG_VFixed: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_conclusion_242);
      }
    }
    case TAG_HMeta: {
      return NTAG(TAG_False);
    }
    case TAG_HError: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t1_2446);
    }
  }
  case TAG_VFunction: {
    switch (heff_tag_of(v_conclusion_242)) {
    case TAG_VU: {
      return NTAG(TAG_False);
    }
    case TAG_VDecode: {
      V v_conclusion1_2482 = heff_field(v_conclusion_242, 0);
      switch (heff_tag_of(v_conclusion1_2482)) {
      case TAG_HLocal: {
        return NTAG(TAG_False);
      }
      case TAG_HGlobal: {
        switch (heff_tag_of(v_t_241)) {
        case TAG_VU: {
          return NTAG(TAG_True);
        }
        case TAG_VDecode: {
          V v_h_2490 = heff_field(v_t_241, 0);
          switch (heff_tag_of(v_h_2490)) {
          case TAG_HLocal: {
            return NTAG(TAG_True);
          }
          case TAG_HGlobal: {
            return NTAG(TAG_True);
          }
          case TAG_HMeta: {
            return NTAG(TAG_True);
          }
          case TAG_HError: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_h_2490);
          }
        }
        case TAG_VFunction: {
          return NTAG(TAG_True);
        }
        case TAG_VRecord: {
          return NTAG(TAG_True);
        }
        case TAG_VSum: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimInt: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimFloat: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimString: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimRune: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimArray: {
          return NTAG(TAG_True);
        }
        case TAG_VFixed: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_t_241);
        }
      }
      case TAG_HMeta: {
        return NTAG(TAG_False);
      }
      case TAG_HError: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_conclusion1_2482);
      }
    }
    case TAG_VFunction: {
      return NTAG(TAG_False);
    }
    case TAG_VRecord: {
      return NTAG(TAG_False);
    }
    case TAG_VSum: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimArray: {
      return NTAG(TAG_False);
    }
    case TAG_VFixed: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_conclusion_242);
    }
  }
  case TAG_VRecord: {
    switch (heff_tag_of(v_conclusion_242)) {
    case TAG_VU: {
      return NTAG(TAG_False);
    }
    case TAG_VDecode: {
      V v_conclusion1_24128 = heff_field(v_conclusion_242, 0);
      switch (heff_tag_of(v_conclusion1_24128)) {
      case TAG_HLocal: {
        return NTAG(TAG_False);
      }
      case TAG_HGlobal: {
        switch (heff_tag_of(v_t_241)) {
        case TAG_VU: {
          return NTAG(TAG_True);
        }
        case TAG_VDecode: {
          V v_h_24136 = heff_field(v_t_241, 0);
          switch (heff_tag_of(v_h_24136)) {
          case TAG_HLocal: {
            return NTAG(TAG_True);
          }
          case TAG_HGlobal: {
            return NTAG(TAG_True);
          }
          case TAG_HMeta: {
            return NTAG(TAG_True);
          }
          case TAG_HError: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_h_24136);
          }
        }
        case TAG_VFunction: {
          return NTAG(TAG_True);
        }
        case TAG_VRecord: {
          return NTAG(TAG_True);
        }
        case TAG_VSum: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimInt: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimFloat: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimString: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimRune: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimArray: {
          return NTAG(TAG_True);
        }
        case TAG_VFixed: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_t_241);
        }
      }
      case TAG_HMeta: {
        return NTAG(TAG_False);
      }
      case TAG_HError: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_conclusion1_24128);
      }
    }
    case TAG_VFunction: {
      return NTAG(TAG_False);
    }
    case TAG_VRecord: {
      return NTAG(TAG_False);
    }
    case TAG_VSum: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimArray: {
      return NTAG(TAG_False);
    }
    case TAG_VFixed: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_conclusion_242);
    }
  }
  case TAG_VSum: {
    switch (heff_tag_of(v_conclusion_242)) {
    case TAG_VU: {
      return NTAG(TAG_False);
    }
    case TAG_VDecode: {
      V v_conclusion1_24171 = heff_field(v_conclusion_242, 0);
      switch (heff_tag_of(v_conclusion1_24171)) {
      case TAG_HLocal: {
        return NTAG(TAG_False);
      }
      case TAG_HGlobal: {
        switch (heff_tag_of(v_t_241)) {
        case TAG_VU: {
          return NTAG(TAG_True);
        }
        case TAG_VDecode: {
          V v_h_24179 = heff_field(v_t_241, 0);
          switch (heff_tag_of(v_h_24179)) {
          case TAG_HLocal: {
            return NTAG(TAG_True);
          }
          case TAG_HGlobal: {
            return NTAG(TAG_True);
          }
          case TAG_HMeta: {
            return NTAG(TAG_True);
          }
          case TAG_HError: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_h_24179);
          }
        }
        case TAG_VFunction: {
          return NTAG(TAG_True);
        }
        case TAG_VRecord: {
          return NTAG(TAG_True);
        }
        case TAG_VSum: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimInt: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimFloat: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimString: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimRune: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimArray: {
          return NTAG(TAG_True);
        }
        case TAG_VFixed: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_t_241);
        }
      }
      case TAG_HMeta: {
        return NTAG(TAG_False);
      }
      case TAG_HError: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_conclusion1_24171);
      }
    }
    case TAG_VFunction: {
      return NTAG(TAG_False);
    }
    case TAG_VRecord: {
      return NTAG(TAG_False);
    }
    case TAG_VSum: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimArray: {
      return NTAG(TAG_False);
    }
    case TAG_VFixed: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_conclusion_242);
    }
  }
  case TAG_VPrimInt: {
    switch (heff_tag_of(v_conclusion_242)) {
    case TAG_VU: {
      return NTAG(TAG_False);
    }
    case TAG_VDecode: {
      V v_conclusion1_24213 = heff_field(v_conclusion_242, 0);
      switch (heff_tag_of(v_conclusion1_24213)) {
      case TAG_HLocal: {
        return NTAG(TAG_False);
      }
      case TAG_HGlobal: {
        switch (heff_tag_of(v_t_241)) {
        case TAG_VU: {
          return NTAG(TAG_True);
        }
        case TAG_VDecode: {
          V v_h_24221 = heff_field(v_t_241, 0);
          switch (heff_tag_of(v_h_24221)) {
          case TAG_HLocal: {
            return NTAG(TAG_True);
          }
          case TAG_HGlobal: {
            return NTAG(TAG_True);
          }
          case TAG_HMeta: {
            return NTAG(TAG_True);
          }
          case TAG_HError: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_h_24221);
          }
        }
        case TAG_VFunction: {
          return NTAG(TAG_True);
        }
        case TAG_VRecord: {
          return NTAG(TAG_True);
        }
        case TAG_VSum: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimInt: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimFloat: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimString: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimRune: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimArray: {
          return NTAG(TAG_True);
        }
        case TAG_VFixed: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_t_241);
        }
      }
      case TAG_HMeta: {
        return NTAG(TAG_False);
      }
      case TAG_HError: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_conclusion1_24213);
      }
    }
    case TAG_VFunction: {
      return NTAG(TAG_False);
    }
    case TAG_VRecord: {
      return NTAG(TAG_False);
    }
    case TAG_VSum: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimArray: {
      return NTAG(TAG_False);
    }
    case TAG_VFixed: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_conclusion_242);
    }
  }
  case TAG_VPrimFloat: {
    switch (heff_tag_of(v_conclusion_242)) {
    case TAG_VU: {
      return NTAG(TAG_False);
    }
    case TAG_VDecode: {
      V v_conclusion1_24255 = heff_field(v_conclusion_242, 0);
      switch (heff_tag_of(v_conclusion1_24255)) {
      case TAG_HLocal: {
        return NTAG(TAG_False);
      }
      case TAG_HGlobal: {
        switch (heff_tag_of(v_t_241)) {
        case TAG_VU: {
          return NTAG(TAG_True);
        }
        case TAG_VDecode: {
          V v_h_24263 = heff_field(v_t_241, 0);
          switch (heff_tag_of(v_h_24263)) {
          case TAG_HLocal: {
            return NTAG(TAG_True);
          }
          case TAG_HGlobal: {
            return NTAG(TAG_True);
          }
          case TAG_HMeta: {
            return NTAG(TAG_True);
          }
          case TAG_HError: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_h_24263);
          }
        }
        case TAG_VFunction: {
          return NTAG(TAG_True);
        }
        case TAG_VRecord: {
          return NTAG(TAG_True);
        }
        case TAG_VSum: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimInt: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimFloat: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimString: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimRune: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimArray: {
          return NTAG(TAG_True);
        }
        case TAG_VFixed: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_t_241);
        }
      }
      case TAG_HMeta: {
        return NTAG(TAG_False);
      }
      case TAG_HError: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_conclusion1_24255);
      }
    }
    case TAG_VFunction: {
      return NTAG(TAG_False);
    }
    case TAG_VRecord: {
      return NTAG(TAG_False);
    }
    case TAG_VSum: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimArray: {
      return NTAG(TAG_False);
    }
    case TAG_VFixed: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_conclusion_242);
    }
  }
  case TAG_VPrimString: {
    switch (heff_tag_of(v_conclusion_242)) {
    case TAG_VU: {
      return NTAG(TAG_False);
    }
    case TAG_VDecode: {
      V v_conclusion1_24297 = heff_field(v_conclusion_242, 0);
      switch (heff_tag_of(v_conclusion1_24297)) {
      case TAG_HLocal: {
        return NTAG(TAG_False);
      }
      case TAG_HGlobal: {
        switch (heff_tag_of(v_t_241)) {
        case TAG_VU: {
          return NTAG(TAG_True);
        }
        case TAG_VDecode: {
          V v_h_24305 = heff_field(v_t_241, 0);
          switch (heff_tag_of(v_h_24305)) {
          case TAG_HLocal: {
            return NTAG(TAG_True);
          }
          case TAG_HGlobal: {
            return NTAG(TAG_True);
          }
          case TAG_HMeta: {
            return NTAG(TAG_True);
          }
          case TAG_HError: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_h_24305);
          }
        }
        case TAG_VFunction: {
          return NTAG(TAG_True);
        }
        case TAG_VRecord: {
          return NTAG(TAG_True);
        }
        case TAG_VSum: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimInt: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimFloat: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimString: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimRune: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimArray: {
          return NTAG(TAG_True);
        }
        case TAG_VFixed: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_t_241);
        }
      }
      case TAG_HMeta: {
        return NTAG(TAG_False);
      }
      case TAG_HError: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_conclusion1_24297);
      }
    }
    case TAG_VFunction: {
      return NTAG(TAG_False);
    }
    case TAG_VRecord: {
      return NTAG(TAG_False);
    }
    case TAG_VSum: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimArray: {
      return NTAG(TAG_False);
    }
    case TAG_VFixed: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_conclusion_242);
    }
  }
  case TAG_VPrimRune: {
    switch (heff_tag_of(v_conclusion_242)) {
    case TAG_VU: {
      return NTAG(TAG_False);
    }
    case TAG_VDecode: {
      V v_conclusion1_24339 = heff_field(v_conclusion_242, 0);
      switch (heff_tag_of(v_conclusion1_24339)) {
      case TAG_HLocal: {
        return NTAG(TAG_False);
      }
      case TAG_HGlobal: {
        switch (heff_tag_of(v_t_241)) {
        case TAG_VU: {
          return NTAG(TAG_True);
        }
        case TAG_VDecode: {
          V v_h_24347 = heff_field(v_t_241, 0);
          switch (heff_tag_of(v_h_24347)) {
          case TAG_HLocal: {
            return NTAG(TAG_True);
          }
          case TAG_HGlobal: {
            return NTAG(TAG_True);
          }
          case TAG_HMeta: {
            return NTAG(TAG_True);
          }
          case TAG_HError: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_h_24347);
          }
        }
        case TAG_VFunction: {
          return NTAG(TAG_True);
        }
        case TAG_VRecord: {
          return NTAG(TAG_True);
        }
        case TAG_VSum: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimInt: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimFloat: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimString: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimRune: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimArray: {
          return NTAG(TAG_True);
        }
        case TAG_VFixed: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_t_241);
        }
      }
      case TAG_HMeta: {
        return NTAG(TAG_False);
      }
      case TAG_HError: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_conclusion1_24339);
      }
    }
    case TAG_VFunction: {
      return NTAG(TAG_False);
    }
    case TAG_VRecord: {
      return NTAG(TAG_False);
    }
    case TAG_VSum: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimArray: {
      return NTAG(TAG_False);
    }
    case TAG_VFixed: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_conclusion_242);
    }
  }
  case TAG_VPrimArray: {
    switch (heff_tag_of(v_conclusion_242)) {
    case TAG_VU: {
      return NTAG(TAG_False);
    }
    case TAG_VDecode: {
      V v_conclusion1_24382 = heff_field(v_conclusion_242, 0);
      switch (heff_tag_of(v_conclusion1_24382)) {
      case TAG_HLocal: {
        return NTAG(TAG_False);
      }
      case TAG_HGlobal: {
        switch (heff_tag_of(v_t_241)) {
        case TAG_VU: {
          return NTAG(TAG_True);
        }
        case TAG_VDecode: {
          V v_h_24390 = heff_field(v_t_241, 0);
          switch (heff_tag_of(v_h_24390)) {
          case TAG_HLocal: {
            return NTAG(TAG_True);
          }
          case TAG_HGlobal: {
            return NTAG(TAG_True);
          }
          case TAG_HMeta: {
            return NTAG(TAG_True);
          }
          case TAG_HError: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_h_24390);
          }
        }
        case TAG_VFunction: {
          return NTAG(TAG_True);
        }
        case TAG_VRecord: {
          return NTAG(TAG_True);
        }
        case TAG_VSum: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimInt: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimFloat: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimString: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimRune: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimArray: {
          return NTAG(TAG_True);
        }
        case TAG_VFixed: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_t_241);
        }
      }
      case TAG_HMeta: {
        return NTAG(TAG_False);
      }
      case TAG_HError: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_conclusion1_24382);
      }
    }
    case TAG_VFunction: {
      return NTAG(TAG_False);
    }
    case TAG_VRecord: {
      return NTAG(TAG_False);
    }
    case TAG_VSum: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimArray: {
      return NTAG(TAG_False);
    }
    case TAG_VFixed: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_conclusion_242);
    }
  }
  case TAG_VFixed: {
    switch (heff_tag_of(v_conclusion_242)) {
    case TAG_VU: {
      return NTAG(TAG_False);
    }
    case TAG_VDecode: {
      V v_conclusion1_24425 = heff_field(v_conclusion_242, 0);
      switch (heff_tag_of(v_conclusion1_24425)) {
      case TAG_HLocal: {
        return NTAG(TAG_False);
      }
      case TAG_HGlobal: {
        switch (heff_tag_of(v_t_241)) {
        case TAG_VU: {
          return NTAG(TAG_True);
        }
        case TAG_VDecode: {
          V v_h_24433 = heff_field(v_t_241, 0);
          switch (heff_tag_of(v_h_24433)) {
          case TAG_HLocal: {
            return NTAG(TAG_True);
          }
          case TAG_HGlobal: {
            return NTAG(TAG_True);
          }
          case TAG_HMeta: {
            return NTAG(TAG_True);
          }
          case TAG_HError: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_h_24433);
          }
        }
        case TAG_VFunction: {
          return NTAG(TAG_True);
        }
        case TAG_VRecord: {
          return NTAG(TAG_True);
        }
        case TAG_VSum: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimInt: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimFloat: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimString: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimRune: {
          return NTAG(TAG_True);
        }
        case TAG_VPrimArray: {
          return NTAG(TAG_True);
        }
        case TAG_VFixed: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_t_241);
        }
      }
      case TAG_HMeta: {
        return NTAG(TAG_False);
      }
      case TAG_HError: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_conclusion1_24425);
      }
    }
    case TAG_VFunction: {
      return NTAG(TAG_False);
    }
    case TAG_VRecord: {
      return NTAG(TAG_False);
    }
    case TAG_VSum: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimArray: {
      return NTAG(TAG_False);
    }
    case TAG_VFixed: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_conclusion_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eelab_2erules_2eapartForced_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2eapartForced(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str0, 30, "the search for an instance of ");
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str1, 14, " goes too deep");
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str2, 5, " for ");
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str4, 7, ", then ");
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str5, 17, " instances deep: ");
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str6, 8, ", and on");
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str7, 16, " goes more than ");
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str8, 2, "32");
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str9, 30, "the search for an instance of ");
V g_heff_2eelab_2erules_2etooDeep_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2etooDeep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etooDeep_entry, 4, 0};

V g_heff_2eelab_2erules_2etooDeep(V v_e_240, V v_mc_241, V v_s_242, V v_goal_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_s_242, 1))));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_s_242, 2);
    V v_t_245 = (g_heff_2eelab_2erules_2egoalShown(v_e_240, v_mc_241, v_goal_243));
    return heff_strAppend(((V)&g_heff_2eelab_2erules_2etooDeep_str0), heff_strAppend(v_t_245, ((V)&g_heff_2eelab_2erules_2etooDeep_str1)));
  }
  case TAG_Cons: {
    V v_outermost_246 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 2);
    heff_drop(v_goal_243);
    V v_t_248 = (g_heff_2eelab_2erules_2egoalShown(heff_dup(v_e_240), v_mc_241, heff_get_n(v_outermost_246, 1, 2)));
    V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_s_242, 1, 2)));
    V v_t_2410 = (g_list_2etake(MK_INT(3LL), v_t_249));
    V v_x2_2413 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2etooDeep_lam0, 1, 2, (V[]){v_e_240, heff_dup(v_mc_241)}), v_t_2410));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2eelab_2erules_2etooDeep_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2etooDeep_str4); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    V v_t_2417 = heff_strAppend(((V)&g_heff_2eelab_2erules_2etooDeep_str5), heff_strAppend(v_t_2416, ((V)&g_heff_2eelab_2erules_2etooDeep_str6)));
    V v_t_2418 = heff_strAppend(((V)&g_heff_2eelab_2erules_2etooDeep_str7), heff_strAppend(((V)&g_heff_2eelab_2erules_2etooDeep_str8), v_t_2417));
    return heff_strAppend(((V)&g_heff_2eelab_2erules_2etooDeep_str9), heff_strAppend(v_t_248, v_t_2418));
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eelab_2erules_2etooDeep_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2etooDeep(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2etooDeep_lam0(V self, V *args) {
  V v_w_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_mc_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = ({ V a_0 = v_e_240; V a_1 = v_mc_241; V a_2 = heff_take_field(v_w_2411, 1); V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_mc_241); r_; });
  return heff_strAppend(heff_get_n(v_w_2411, 0, 2), heff_strAppend(((V)&g_heff_2eelab_2erules_2etooDeep_str2), v_t_2412));
}
HEFF_LIT(g_heff_2eelab_2erules_2eimplicitDefaultChk_str0, 83, "an implicit argument's default names definitions only, not the parameters before it");
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2eimplicitDefaultChk_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitDefaultChk_lam3, 1, 0};
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eimplicitDefaultChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitDefaultChk_entry, 2, 0};

V g_heff_2eelab_2erules_2eimplicitDefaultChk(V v_sp_240, V v_c_241) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eimplicitDefaultChk_lam0, 2, 2, (V[]){heff_dup(v_c_241), v_sp_240})});
}
V g_heff_2eelab_2erules_2eimplicitDefaultChk_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2eimplicitDefaultChk(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam3(V self, V *args) {
  V v_c0_249 = args[0];
  return heff_get_n(v_c0_249, 3, 8);
}
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = ({ V a_0 = v_x_2413; V r_ = (g_heff_2eelab_2eunify_2ezonker(a_0)); heff_drop(v_x_2413); r_; });
  V v_stx_2415 = heff_tr(heff_call(heff_get_n(v_t_2414, 0, 2), 1, (V[]){heff_take_field(v_x_248, 0)}));
  V v_t_2416 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(MK_INT(0LL), v_stx_2415));
  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_248, 2);
    heff_drop(v_stx_2415);
    heff_drop(v_t_2416);
    V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(345LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eimplicitDefaultChk_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2419}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2420;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    heff_drop(v_t_2416);
    V v_t_2421 = ({ V rv_0 = v_stx_2415; V rr_ = heff_rec_reuse_nf(v_x_248, 2ULL, 2, shape_stx__val, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_k_247;
    args[0] = v_t_2421;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eimplicitDefaultChk_lam3_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eimplicitDefaultChk_lam4, 1, 4, (V[]){v_x_248, v_sp_240, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eimplicitDefaultChk_lam2, 1, 3, (V[]){v_hd_246, v_sp_240, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eimplicitDefaultChk_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245;
  switch (heff_tag_of(v_c_241)) {
  case TAG_MkChk: {
    V v_f_244 = heff_field(v_c_241, 0);
    heff_take_n(v_c_241, 1ULL, 1);
    v_c_245 = heff_tr(heff_call(v_f_244, 2, (V[]){v_e_242, v_a_243}));
    break;
  }
  default: heff_nomatch(v_c_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eimplicitDefaultChk_lam1, 2, 2, (V[]){v_c_245, v_sp_240});
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eimplicitDefaultAt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitDefaultAt_lam0, 2, 0};
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eimplicitDefaultAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitDefaultAt_entry, 3, 0};

V g_heff_2eelab_2erules_2eimplicitDefaultAt(V v_e_240, V v_ty_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_e_240, 6);
    heff_drop_rec(v_ty_241, 2);
    return ((V)&g_heff_2eelab_2erules_2eimplicitDefaultAt_lam0_clo);
  }
  case TAG_Just: {
    V v_d_245 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(heff_get_n(v_ty_241, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_a_2410;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nom: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      v_a_2410 = v_x_247;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_246, 0ULL, 1);
      v_a_2410 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_249 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      v_a_2410 = v_x_249;
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    V v_t_2411 = ({ V a_0 = heff_take_field(v_d_245, 1); V b_1 = heff_get_n(v_d_245, 0, 2); V r_ = (g_heff_2eelab_2erules_2eimplicitDefaultChk(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2eelab_2erules_2erecovering(a_0)); heff_drop(v_t_2411); r_; });
    V v_c_2415;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_MkChk: {
      V v_f_2413 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      V v_t_2414 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_nf(v_e_240, 59ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4047u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      v_c_2415 = heff_tr(heff_call(v_f_2413, 2, (V[]){v_t_2414, v_a_2410}));
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    return heff_clo_n(g_heff_2eelab_2erules_2eimplicitDefaultAt_lam1, 2, 1, (V[]){v_c_2415});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eimplicitDefaultAt(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2418, 0, 2)});
  V f_ = v_k_2417;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eimplicitDefaultAt_lam2, 1, 1, (V[]){v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eautoRec_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eautoRec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eautoRec_entry, 3, 0};

V g_heff_2eelab_2erules_2eautoRec(V v_sp_240, V v_x_241, V v_c_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eautoRec_lam0, 2, 3, (V[]){v_x_241, v_c_242, v_sp_240})});
}
V g_heff_2eelab_2erules_2eautoRec_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eautoRec(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eautoRec_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a_244 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 1, 4);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 3, 4);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_it_248 = ({ V a_0 = v_x_241; V a_1 = v_t_245; V a_2 = v_t_246; V a_3 = v_t_247; V a_4 = MK_INT(0LL); V a_5 = MK_INT(0LL); V r_ = (g_heff_2eelab_2erules_2evarGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_246); r_; });
  switch (heff_tag_of(v_it_248)) {
  case TAG_Left: {
    V v_it1_249 = heff_field(v_it_248, 0);
    heff_take_n(v_it_248, 1ULL, 1);
    switch (heff_tag_of(v_it1_249)) {
    case TAG_NotInScope: {
      heff_drop(v_sp_240);
      switch (heff_tag_of(v_c_242)) {
      case TAG_MkChk: {
        V v_f_2410 = heff_field(v_c_242, 0);
        heff_take_n(v_c_242, 1ULL, 1);
        V f_ = v_f_2410;
        args[0] = v_e_243;
        args[1] = v_a_244;
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
      default: return heff_nomatch(v_c_242);
      }
    }
    case TAG_Delayed2: {
      V v_x1_2411 = (g_heff_2eelab_2evalue_2elevelOf(v_a_244));
      switch (heff_tag_of(v_x1_2411)) {
      case TAG_Small: {
        V v_t_2412 = (g_heff_2eelab_2erules_2erecChk(v_sp_240, v_c_242));
        switch (heff_tag_of(v_t_2412)) {
        case TAG_MkChk: {
          V v_f_2413 = heff_field(v_t_2412, 0);
          heff_take_n(v_t_2412, 1ULL, 1);
          V f_ = v_f_2413;
          args[0] = v_e_243;
          args[1] = v_a_244;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        default: return heff_nomatch(v_t_2412);
        }
      }
      case TAG_Large: {
        heff_drop(v_sp_240);
        switch (heff_tag_of(v_c_242)) {
        case TAG_MkChk: {
          V v_f_2414 = heff_field(v_c_242, 0);
          heff_take_n(v_c_242, 1ULL, 1);
          V f_ = v_f_2414;
          args[0] = v_e_243;
          args[1] = v_a_244;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        default: return heff_nomatch(v_c_242);
        }
      }
      case TAG_TopL: {
        heff_drop(v_sp_240);
        switch (heff_tag_of(v_c_242)) {
        case TAG_MkChk: {
          V v_f_2415 = heff_field(v_c_242, 0);
          heff_take_n(v_c_242, 1ULL, 1);
          V f_ = v_f_2415;
          args[0] = v_e_243;
          args[1] = v_a_244;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        default: return heff_nomatch(v_c_242);
        }
      }
      default: return heff_nomatch(v_x1_2411);
      }
    }
    default: return heff_nomatch(v_it1_249);
    }
  }
  case TAG_Right: {
    heff_take_n(v_it_248, 0ULL, 1);
    heff_drop(v_sp_240);
    switch (heff_tag_of(v_c_242)) {
    case TAG_MkChk: {
      V v_f_2417 = heff_field(v_c_242, 0);
      heff_take_n(v_c_242, 1ULL, 1);
      V f_ = v_f_2417;
      args[0] = v_e_243;
      args[1] = v_a_244;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_c_242);
    }
  }
  default: return heff_nomatch(v_it_248);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2enumLitSyn_str0, 7, "literal");
V g_heff_2eelab_2erules_2enumLitSyn_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enumLitSyn_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enumLitSyn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitSyn_entry, 2, 0};

V g_heff_2eelab_2erules_2enumLitSyn(V v_sp_240, V v_lit_241) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitSyn_lam0, 3, 2, (V[]){v_sp_240, v_lit_241})});
}
V g_heff_2eelab_2erules_2enumLitSyn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitSyn(a[0], a[1]);
}
V g_heff_2eelab_2erules_2enumLitSyn_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = (g_heff_2eelab_2evalue_2edecodeN(heff_get_n(v_x_248, 1, 2)));
  V v_x_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_t_2414});
  V f_ = v_k_244;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enumLitSyn_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_a_249 = (g_heff_2eelab_2evalue_2edecodeN(heff_dup(heff_rfield(v_x_248, 1))));
  V v_t_2410 = (g_heff_2eelab_2erules_2enumLitChk(v_sp_240, v_lit_241));
  V v_c_2412;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_MkChk: {
    V v_f_2411 = heff_field(v_t_2410, 0);
    heff_take_n(v_t_2410, 1ULL, 1);
    v_c_2412 = heff_tr(heff_call(v_f_2411, 2, (V[]){v_e_242, v_a_249}));
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V f_ = v_c_2412;
  heff_room[0] = v_hd_243;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2enumLitSyn_lam2, 1, 2, (V[]){v_x_248, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2enumLitSyn_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_hd_243 = args[1];
  V v_k_244 = args[2];
  V v_sp_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 0, 4);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 2, 4);
  V v_t_247 = heff_tag_n(TAG_VU, 1, (V[]){NTAG(TAG_SmallU)});
  return ({ V a_0 = v_t_245; V a_1 = v_t_246; V a_2 = v_t_247; V a_3 = ((V)&g_heff_2eelab_2erules_2enumLitSyn_str0); V a_4 = heff_dup(v_sp_240); V a_5 = heff_dup(v_hd_243); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2enumLitSyn_lam1, 1, 5, (V[]){v_sp_240, v_lit_241, v_e_242, v_hd_243, v_k_244}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_246); r_; });
}
Clo g_heff_2eelab_2erules_2erecordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordOf_entry, 2, 0};

V g_heff_2eelab_2erules_2erecordOf(V v_e_240, V v_f_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 2, 4);
  V v_pairs_243 = heff_take_field(v_f_241, 1);
  V v_t_244 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_243)));
  V v_t_245 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_243));
  V v_t_246 = (g_list_2emap_24s1173914895x100384474(v_pairs_243));
  V v_t_247 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_244), v_t_245, heff_arrayFromList(v_t_246)});
  V v_pairs_248 = heff_take_field(v_f_241, 2);
  V v_t_249 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_248)));
  V v_t_2410 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_248));
  V v_t_2411 = (g_list_2emap_24s1173914895x100384474(v_pairs_248));
  V v_t_2412 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_249), v_t_2410, heff_arrayFromList(v_t_2411)});
  return (g_heff_2eelab_2ememoed_2erecordM(heff_get_n(v_e_240, 1, 6), v_t_242, heff_get_n(v_f_241, 0, 4), v_t_247, v_t_2412));
}
V g_heff_2eelab_2erules_2erecordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erecordOf(a[0], a[1]);
}
Clo g_heff_2eelab_2erules_2ecodeAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecodeAt_entry, 5, 0};

V g_heff_2eelab_2erules_2ecodeAt(V v_n_240, V v_at_241, V v_places_242, V v_m_243, V v_i_244) {
top: ;
  V v_t_245 = heff_take_field(v_m_243, 3);
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_n_240);
    heff_drop(v_t_245);
    V v_t_246 = (g_list_2etake(v_i_244, v_places_242));
    V v_t_247 = (g_heff_2eelab_2erules_2efieldIdxs(v_at_241, v_t_246));
    V v_t_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2eelab_2eunify_2esubstOf(a_0)); heff_drop(v_t_247); r_; });
    V v_t_249 = heff_get_n(heff_get_n(v_m_243, 2, 5), 0, 2);
    return heff_tail(heff_get_n(v_t_248, 0, 2), 2, (V[]){MK_INT(0LL), v_t_249});
  } else {
    heff_drop(v_places_242);
    heff_drop(v_i_244);
    heff_drop(v_t_245);
    V v_t_2410 = heff_get_n(heff_get_n(v_m_243, 2, 5), 0, 2);
    if (heff_intEq_c(heff_dup(v_at_241), MK_INT(0LL))) {
      heff_drop(v_n_240);
      heff_drop(v_at_241);
      return v_t_2410;
    } else {
      V v_t_2412 = (g_list_2emap_24f783067987x1926181389(heff_dup(v_n_240), MK_INT(1LL), v_at_241, MK_INT(0LL), heff_intSub(v_n_240, MK_INT(1LL))));
      V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2eelab_2eunify_2esubstOf(a_0)); heff_drop(v_t_2412); r_; });
      return heff_tail(heff_get_n(v_t_2413, 0, 2), 2, (V[]){MK_INT(0LL), v_t_2410});
    }
  }
}
V g_heff_2eelab_2erules_2ecodeAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ecodeAt(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2eelab_2erules_2eletted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eletted_entry, 5, 0};

V g_heff_2eelab_2erules_2eletted(V v_e_240, V v_a_241, V v_made_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_e_240, 2));
  V v_t_248;
  switch (heff_tag_of(v_t_245)) {
  case TAG_ForNominative: {
    v_t_248 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_245, 0ULL, 2);
    v_t_248 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_pairs_249 = (g_list_2emap_24s1729297000x968708966(heff_dup(v_made_242)));
  V v_t_2410 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_249)));
  V v_t_2411 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_249));
  V v_t_2412 = (g_list_2emap_24s1173914895x100384474(v_pairs_249));
  V v_t_2413 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2410), v_t_2411, heff_arrayFromList(v_t_2412)});
  V v_record_2414 = ({ V a_0 = v_t_248; V a_1 = v_t_2413; V r_ = (g_heff_2eelab_2ememoed_2econs(a_0, a_1)); heff_drop(v_t_248); r_; });
  V v_bound_2415 = (g_heff_2eelab_2erules_2eboundGo(heff_dup(v_made_242), heff_dup(v_made_242), MK_INT(0LL)));
  V v_t_2416 = (g_list_2eany_24s228396297x1310020012(v_bound_2415));
  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
    heff_drop(v_t_2416);
    V v_t_2417 = (g_heff_2eelab_2erules_2eplacesGo(heff_dup(v_bound_2415), MK_INT(0LL)));
    return ({ V a_0 = v_e_240; V a_1 = v_a_241; V a_2 = v_made_242; V a_3 = v_record_2414; V a_4 = v_bound_2415; V a_5 = v_t_2417; V a_6 = v_z_243; V a_7 = v_z_244; V r_ = (g_heff_2eelab_2erules_2elettedAt(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_bound_2415); r_; });
  } else {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_made_242);
    heff_drop(v_z_243);
    heff_drop(v_bound_2415);
    heff_drop(v_t_2416);
    return heff_tail(v_z_244, 1, (V[]){v_record_2414});
  }
}
V g_heff_2eelab_2erules_2eletted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eletted(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str0, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str1, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str2, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str3, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str4, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str5, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str6, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str7, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str8, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str9, 34, "cannot match against non-sum type ");
V g_heff_2eelab_2erules_2ematchLater_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam8(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam7(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam6(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam11(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam10(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam9(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam14(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam13(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam12(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam17(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam16(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam15(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam20(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam19(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam18(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam23(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam22(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam21(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam26(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam25(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam24(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam29(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam28(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam27(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam32(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam31(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam30(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ematchLater_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ematchLater_entry, 5, 0};

V g_heff_2eelab_2erules_2ematchLater(V v_sp_240, V v_scrut_241, V v_a_242, V v_tags_243, V v_casesChk_244) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam0, 4, 5, (V[]){v_a_242, v_sp_240, v_scrut_241, heff_dup(v_tags_243), v_casesChk_244})});
}
V g_heff_2eelab_2erules_2ematchLater_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2ematchLater(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2ematchLater_lam1(V self, V *args) {
  V v_c_249 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_249, 3, 8); V a_1 = v_a_242; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2ematchLater_lam5(V self, V *args) {
  V v_u_2418 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2418);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam4(V self, V *args) {
  V v_u_2417 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2417);
  V v_t_2419 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam5, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2419});
}
V g_heff_2eelab_2erules_2ematchLater_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2416) == NTAG(TAG_True))) {
    heff_drop(v_x_2416);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2420 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam4, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2416);
    heff_drop(v_b2_246);
    V v_t_2421 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_2422 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str0), v_t_2421);
    V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2422, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2425}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_2426;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam8(V self, V *args) {
  V v_u_2433 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2433);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam7(V self, V *args) {
  V v_u_2432 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2432);
  V v_t_2434 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam8, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2434});
}
V g_heff_2eelab_2erules_2ematchLater_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2431) == NTAG(TAG_True))) {
    heff_drop(v_x_2431);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2435 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam7, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2435;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2431);
    heff_drop(v_b2_246);
    V v_t_2436 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_2437 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str1), v_t_2436);
    V v_t_2438 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2437, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2440}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_2441;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam11(V self, V *args) {
  V v_u_2447 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2447);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam10(V self, V *args) {
  V v_u_2446 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2446);
  V v_t_2448 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam11, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2448});
}
V g_heff_2eelab_2erules_2ematchLater_lam9(V self, V *args) {
  V v_x_2445 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2445) == NTAG(TAG_True))) {
    heff_drop(v_x_2445);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2449 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam10, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2449;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2445);
    heff_drop(v_b2_246);
    V v_t_2450 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_2451 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str2), v_t_2450);
    V v_t_2452 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2451, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2454}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_2455;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam14(V self, V *args) {
  V v_u_2459 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2459);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam13(V self, V *args) {
  V v_u_2458 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2458);
  V v_t_2460 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam14, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2460});
}
V g_heff_2eelab_2erules_2ematchLater_lam12(V self, V *args) {
  V v_x_2457 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2457) == NTAG(TAG_True))) {
    heff_drop(v_x_2457);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2461 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam13, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2461;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2457);
    heff_drop(v_b2_246);
    V v_t_2462 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_2463 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str3), v_t_2462);
    V v_t_2464 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2463, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2466}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_2467;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam17(V self, V *args) {
  V v_u_2470 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2470);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam16(V self, V *args) {
  V v_u_2469 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2469);
  V v_t_2471 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam17, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2471});
}
V g_heff_2eelab_2erules_2ematchLater_lam15(V self, V *args) {
  V v_x_2468 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2468) == NTAG(TAG_True))) {
    heff_drop(v_x_2468);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2472 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam16, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2472;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2468);
    heff_drop(v_b2_246);
    V v_t_2473 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_2474 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str4), v_t_2473);
    V v_t_2475 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2474, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
    V v_t_2478 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2477}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_2478;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam20(V self, V *args) {
  V v_u_2481 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2481);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam19(V self, V *args) {
  V v_u_2480 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2480);
  V v_t_2482 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam20, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2482});
}
V g_heff_2eelab_2erules_2ematchLater_lam18(V self, V *args) {
  V v_x_2479 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2479) == NTAG(TAG_True))) {
    heff_drop(v_x_2479);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2483 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam19, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2483;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2479);
    heff_drop(v_b2_246);
    V v_t_2484 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_2485 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str5), v_t_2484);
    V v_t_2486 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2485, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2486})});
    V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
    V v_t_2489 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2488}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_2489;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam23(V self, V *args) {
  V v_u_2492 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2492);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam22(V self, V *args) {
  V v_u_2491 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2491);
  V v_t_2493 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam23, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2493});
}
V g_heff_2eelab_2erules_2ematchLater_lam21(V self, V *args) {
  V v_x_2490 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2490) == NTAG(TAG_True))) {
    heff_drop(v_x_2490);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2494 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam22, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2494;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2490);
    heff_drop(v_b2_246);
    V v_t_2495 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_2496 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str6), v_t_2495);
    V v_t_2497 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2496, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2498 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2497})});
    V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
    V v_t_24100 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2499}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_24100;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam26(V self, V *args) {
  V v_u_24104 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24104);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam25(V self, V *args) {
  V v_u_24103 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24103);
  V v_t_24105 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam26, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24105});
}
V g_heff_2eelab_2erules_2ematchLater_lam24(V self, V *args) {
  V v_x_24102 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_24102) == NTAG(TAG_True))) {
    heff_drop(v_x_24102);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_24106 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam25, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_24106;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24102);
    heff_drop(v_b2_246);
    V v_t_24107 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_24108 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str7), v_t_24107);
    V v_t_24109 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24108, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24110 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24109})});
    V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
    V v_t_24112 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24111}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_24112;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam29(V self, V *args) {
  V v_u_24116 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24116);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam28(V self, V *args) {
  V v_u_24115 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24115);
  V v_t_24117 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam29, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24117});
}
V g_heff_2eelab_2erules_2ematchLater_lam27(V self, V *args) {
  V v_x_24114 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_24114) == NTAG(TAG_True))) {
    heff_drop(v_x_24114);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_24118 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam28, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_24118;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24114);
    heff_drop(v_b2_246);
    V v_t_24119 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_24120 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str8), v_t_24119);
    V v_t_24121 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24120, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24122 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24121})});
    V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
    V v_t_24124 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24123}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_24124;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam32(V self, V *args) {
  V v_u_24127 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24127);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam31(V self, V *args) {
  V v_u_24126 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24126);
  V v_t_24128 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam32, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24128});
}
V g_heff_2eelab_2erules_2ematchLater_lam30(V self, V *args) {
  V v_x_24125 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_24125) == NTAG(TAG_True))) {
    heff_drop(v_x_24125);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_24129 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam31, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_24129;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24125);
    heff_drop(v_b2_246);
    V v_t_24130 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_24131 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str9), v_t_24130);
    V v_t_24132 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24131, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24133 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24132})});
    V v_t_24134 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24133})});
    V v_t_24135 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24134}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_24135;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_b2_246 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  V v_e2_245 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_scrut_241 = heff_env(self)[5];
  V v_tags_243 = heff_env(self)[6];
  V v_casesChk_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2414 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2413)));
  switch (heff_tag_of(v_t_2414)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2414, 0ULL, 1);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam3, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2414, 0ULL, 4);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam6, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2414, 0ULL, 3);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam9, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeSum: {
    V v_vs_2456 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    return ({ V a_0 = v_sp_240; V a_1 = v_e2_245; V a_2 = v_b2_246; V a_3 = v_scrut_241; V a_4 = v_x_2413; V a_5 = v_vs_2456; V a_6 = v_tags_243; V a_7 = v_casesChk_244; V a_8 = v_hd_247; V a_9 = v_k_248; V r_ = (g_heff_2eelab_2erules_2ecasesAt(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_tags_243); r_; });
  }
  case TAG_LikeInt: {
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam12, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeFloat: {
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam15, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeString: {
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam18, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeRune: {
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam21, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2414, 0ULL, 1);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam24, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2414, 0ULL, 1);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam27, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_NoRules: {
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam30, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam0(V self, V *args) {
  V v_e2_245 = args[0];
  V v_b2_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V v_a_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_scrut_241 = heff_env(self)[2];
  V v_tags_243 = heff_env(self)[3];
  V v_casesChk_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam1, 1, 1, (V[]){v_a_242})})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  args[0] = v_t_2412;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam2, 1, 8, (V[]){v_hd_247, v_b2_246, v_k_248, v_e2_245, v_sp_240, v_scrut_241, v_tags_243, v_casesChk_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efixEnv_lam0(V self, V *args);
V g_heff_2eelab_2erules_2efixEnv_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2efixEnv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efixEnv_entry, 3, 0};

V g_heff_2eelab_2erules_2efixEnv(V v_e_240, V v_x_241, V v_a_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_v_245 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_t_243}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2efixEnv_lam0, 1, 1, (V[]){heff_dup(v_a_242)}), NTAG(TAG_Nothing)));
  V v_c_246 = heff_take_field(v_e_240, 0);
  V v_t_247 = heff_intAdd(heff_take_field(v_c_246, 0), MK_INT(1LL));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, heff_take_field(v_c_246, 1)});
  V v_t_2410 = heff_tag_n(TAG_LSnoc, 2, (V[]){heff_take_field(v_c_246, 2), heff_clo_n(g_heff_2eelab_2erules_2efixEnv_lam1, 1, 1, (V[]){v_v_245})});
  V v_t_2411 = heff_tag_n(TAG_CBind, 3, (V[]){heff_get_n(v_c_246, 3, 4), heff_tag_n(TAG_BDelayedBy, 1, (V[]){MK_INT(1LL)}), v_a_242});
  return ({ V rv_0 = heff_rec_n(4, shape_len__names__locals__ctx, (V[]){v_t_247, v_t_248, v_t_2410, v_t_2411}); V rv_2 = NTAG(TAG_ForNominative); V rv_3 = MK_INT(0LL); V rr_ = heff_rec_reuse_nf(v_e_240, 50ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 3852u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2eelab_2erules_2efixEnv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efixEnv(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2efixEnv_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_244);
  return v_a_242;
}
V g_heff_2eelab_2erules_2efixEnv_lam1(V self, V *args) {
  V v_u_249 = args[0];
  V v_v_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return v_v_245;
}
HEFF_LIT(g_heff_2eelab_2erules_2esameField_str0, 36, " in the record updated, but of type ");
HEFF_LIT(g_heff_2eelab_2erules_2esameField_str1, 31, " in the record made: set it too");
HEFF_LIT(g_heff_2eelab_2erules_2esameField_str2, 12, " is of type ");
HEFF_LIT(g_heff_2eelab_2erules_2esameField_str3, 6, "field ");
V g_heff_2eelab_2erules_2esameField_lam0(V self, V *args);
V g_heff_2eelab_2erules_2esameField_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esameField_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esameField_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esameField_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2esameField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esameField_entry, 8, 0};

V g_heff_2eelab_2erules_2esameField(V v_sp_240, V v_e_241, V v_x_242, V v_fty_243, V v_m_244, V v_t_245, V v_hd_246, V v_k_247) {
top: ;
  V v_c_248 = heff_dup(heff_rfield(v_e_241, 0));
  return (g_heff_2eelab_2emeta_2eattempt(heff_clo_n(g_heff_2eelab_2erules_2esameField_lam0, 2, 4, (V[]){v_c_248, heff_dup(v_e_241), heff_dup(v_fty_243), heff_dup(v_t_245)}), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2esameField_lam1, 1, 8, (V[]){v_e_241, v_fty_243, v_hd_246, v_t_245, v_x_242, v_sp_240, v_k_247, v_m_244})));
}
V g_heff_2eelab_2erules_2esameField_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esameField(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2esameField_lam0(V self, V *args) {
  V v_p_249 = args[0];
  V v_p_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_fty_243 = heff_env(self)[2];
  V v_t_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_248, 0), heff_get_n(v_c_248, 1, 4)});
  V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo), 4, (V[]){heff_get_n(v_e_241, 1, 6), v_t_2411, v_fty_243, v_t_245}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2412, v_p_249, v_p_2410));
}
V g_heff_2eelab_2erules_2esameField_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_err_2414 = heff_env(self)[1];
  V v_x_2415 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_note_2417 = ({ V a_0 = heff_get_n(v_e_241, 1, 6); V a_1 = v_err_2414; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2414); r_; });
  V v_t_2418 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esameField_str0), heff_strAppend(v_x_2415, ((V)&g_heff_2eelab_2erules_2esameField_str1)));
  V v_t_2419 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esameField_str2), heff_strAppend(v_x_2416, v_t_2418));
  V v_t_2420 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esameField_str3), heff_strAppend(v_x_242, v_t_2419));
  V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_2420, v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){v_note_2417})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2423}));
  V f_ = heff_get_n(v_hd_246, 1, 3);
  heff_room[0] = v_t_2424;
  heff_room[1] = v_k_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esameField_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_err_2414 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2erules_2etyStrZ(heff_dup(v_e_241), v_t_245, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2esameField_lam3, 1, 7, (V[]){v_e_241, v_err_2414, v_x_2415, v_x_242, v_sp_240, v_hd_246, v_k_247})));
}
V g_heff_2eelab_2erules_2esameField_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2429);
  V f_ = v_k_247;
  args[0] = v_m_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esameField_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_fty_243 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_t_245 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_m_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2etyStrZ(heff_dup(v_e_241), v_fty_243, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2esameField_lam2, 1, 7, (V[]){v_e_241, v_t_245, v_hd_246, v_err_2414, v_x_242, v_sp_240, v_k_247})));
  }
  case TAG_Right: {
    V v_ru_24x_2413_24Right = heff_take_reuse_n(v_x_2413, 0ULL, 1);
    heff_drop_rec(v_e_241, 6);
    heff_drop(v_fty_243);
    heff_drop(v_t_245);
    heff_drop(v_x_242);
    heff_drop(v_sp_240);
    V v_t_2426 = heff_tag_n(TAG_Wake, 2, (V[]){NTAG(TAG_False), NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_at_n(v_ru_24x_2413_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2427}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2428;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esameField_lam4, 1, 2, (V[]){v_k_247, v_m_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2413);
  }
}
Clo g_heff_2eelab_2erules_2etooLarge_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etooLarge_entry, 5, 0};

V g_heff_2eelab_2erules_2etooLarge(V v_sp_240, V v_msg_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_245 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(309LL), NTAG(TAG_SError), v_msg_241, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tr(heff_call(heff_take_field(v_p_243, 2), 1, (V[]){v_t_247}));
    return heff_tail(heff_get_n(v_p_243, 1, 3), 2, (V[]){v_t_248, v_p_244});
  }
  case TAG_Just: {
    V v_note_249 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(309LL), NTAG(TAG_SError), v_msg_241, v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){v_note_249})});
    V v_t_2411 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tr(heff_call(heff_take_field(v_p_243, 2), 1, (V[]){v_t_2412}));
    return heff_tail(heff_get_n(v_p_243, 1, 3), 2, (V[]){v_t_2413, v_p_244});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2etooLarge_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etooLarge(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str0, 5, "type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str1, 27, " too large for its universe");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str2, 22, " at non-universe type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str3, 18, "cannot check type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str4, 22, " at non-universe type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str5, 18, "cannot check type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str6, 22, " at non-universe type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str7, 18, "cannot check type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str8, 22, " at non-universe type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str9, 18, "cannot check type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str10, 22, " at non-universe type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str11, 18, "cannot check type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str12, 22, " at non-universe type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str13, 18, "cannot check type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str14, 22, " at non-universe type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str15, 18, "cannot check type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str16, 22, " at non-universe type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str17, 18, "cannot check type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str18, 22, " at non-universe type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str19, 18, "cannot check type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str20, 22, " at non-universe type ");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseAt_str21, 18, "cannot check type ");
V g_heff_2eelab_2erules_2euniverseAt_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2euniverseAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2euniverseAt_entry, 7, 0};

V g_heff_2eelab_2erules_2euniverseAt(V v_sp_240, V v_note_241, V v_e_242, V v_a_243, V v_ty_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_243)));
  switch (heff_tag_of(v_t_247)) {
  case TAG_LikeU: {
    V v_u_248 = heff_field(v_t_247, 0);
    V v_ru_24t_247_24LikeU = heff_take_reuse_n(v_t_247, 1ULL, 1);
    heff_drop(v_a_243);
    V v_x1_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_ty_244, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_x1_2413;
    switch (heff_tag_of(v_x1_249)) {
    case TAG_Nom: {
      V v_t_2410 = heff_field(v_x1_249, 0);
      heff_take_n(v_x1_249, 1ULL, 1);
      v_x1_2413 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2410); r_; });
      break;
    }
    case TAG_Describe: {
      V v_t_2411 = heff_field(v_x1_249, 0);
      heff_take_n(v_x1_249, 1ULL, 1);
      v_x1_2413 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2411); r_; });
      break;
    }
    case TAG_Become: {
      V v_t_2412 = heff_field(v_x1_249, 0);
      heff_take_n(v_x1_249, 1ULL, 1);
      v_x1_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2412); r_; });
      break;
    }
    default: heff_nomatch(v_x1_249);
    }
    V v_t_2414;
    switch (heff_tag_of(v_u_248)) {
    case TAG_SmallU: {
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_Small: {
        v_t_2414 = NTAG(TAG_True);
        break;
      }
      case TAG_Large: {
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_TopL: {
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x1_2413);
      }
      break;
    }
    case TAG_LargeU: {
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_Small: {
        v_t_2414 = NTAG(TAG_True);
        break;
      }
      case TAG_Large: {
        v_t_2414 = NTAG(TAG_True);
        break;
      }
      case TAG_TopL: {
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x1_2413);
      }
      break;
    }
    default: heff_nomatch(v_u_248);
    }
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_sp_240);
      heff_drop(v_note_241);
      heff_drop(v_e_242);
      heff_drop_rec(v_z_245, 3);
      heff_drop(v_t_2414);
      V v_t_2415 = heff_tag_at_n(v_ru_24t_247_24LikeU, TAG_SCode, 1, (V[]){heff_dup(heff_rfield(v_ty_244, 0))});
      return heff_tail(v_z_246, 1, (V[]){heff_rec_n(2, shape_stx__val, (V[]){v_t_2415, heff_clo_n(g_heff_2eelab_2erules_2euniverseAt_lam0, 1, 1, (V[]){v_ty_244})})});
    } else {
      heff_drop_cell(v_ru_24t_247_24LikeU, 1);
      heff_drop(v_t_2414);
      V v_t_2418 = (g_heff_2eelab_2erules_2etyStrM(v_e_242, v_ty_244));
      V v_t_2419 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str0), heff_strAppend(v_t_2418, ((V)&g_heff_2eelab_2erules_2euniverseAt_str1)));
      return (g_heff_2eelab_2erules_2etooLarge(v_sp_240, v_t_2419, v_note_241, v_z_245, v_z_246));
    }
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_247, 0ULL, 4);
    heff_drop(v_note_241);
    V v_t_2424 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_ty_244));
    V v_t_2425 = (g_heff_2eelab_2erules_2etyStr(v_e_242, v_a_243));
    V v_t_2426 = heff_strAppend(v_t_2424, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str2), v_t_2425));
    V v_msg_2427 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str3), v_t_2426);
    V v_t_2428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2427, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tr(heff_call(heff_take_field(v_z_245, 2), 1, (V[]){v_t_2430}));
    return heff_tail(heff_get_n(v_z_245, 1, 3), 2, (V[]){v_t_2431, v_z_246});
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_247, 0ULL, 3);
    heff_drop(v_note_241);
    V v_t_2435 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_ty_244));
    V v_t_2436 = (g_heff_2eelab_2erules_2etyStr(v_e_242, v_a_243));
    V v_t_2437 = heff_strAppend(v_t_2435, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str4), v_t_2436));
    V v_msg_2438 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str5), v_t_2437);
    V v_t_2439 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2438, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tr(heff_call(heff_take_field(v_z_245, 2), 1, (V[]){v_t_2441}));
    return heff_tail(heff_get_n(v_z_245, 1, 3), 2, (V[]){v_t_2442, v_z_246});
  }
  case TAG_LikeSum: {
    V v_ru_24t_247_24LikeSum = heff_take_reuse_n(v_t_247, 0ULL, 1);
    heff_drop(v_note_241);
    V v_t_2444 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_ty_244));
    V v_t_2445 = (g_heff_2eelab_2erules_2etyStr(v_e_242, v_a_243));
    V v_t_2446 = heff_strAppend(v_t_2444, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str6), v_t_2445));
    V v_msg_2447 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str7), v_t_2446);
    V v_t_2448 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2447, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2449 = heff_tag_at_n(v_ru_24t_247_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tr(heff_call(heff_take_field(v_z_245, 2), 1, (V[]){v_t_2450}));
    return heff_tail(heff_get_n(v_z_245, 1, 3), 2, (V[]){v_t_2451, v_z_246});
  }
  case TAG_LikeInt: {
    heff_drop(v_note_241);
    V v_t_2452 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_ty_244));
    V v_t_2453 = (g_heff_2eelab_2erules_2etyStr(v_e_242, v_a_243));
    V v_t_2454 = heff_strAppend(v_t_2452, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str8), v_t_2453));
    V v_msg_2455 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str9), v_t_2454);
    V v_t_2456 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2455, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
    V v_t_2459 = heff_tr(heff_call(heff_take_field(v_z_245, 2), 1, (V[]){v_t_2458}));
    return heff_tail(heff_get_n(v_z_245, 1, 3), 2, (V[]){v_t_2459, v_z_246});
  }
  case TAG_LikeFloat: {
    heff_drop(v_note_241);
    V v_t_2460 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_ty_244));
    V v_t_2461 = (g_heff_2eelab_2erules_2etyStr(v_e_242, v_a_243));
    V v_t_2462 = heff_strAppend(v_t_2460, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str10), v_t_2461));
    V v_msg_2463 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str11), v_t_2462);
    V v_t_2464 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2463, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tr(heff_call(heff_take_field(v_z_245, 2), 1, (V[]){v_t_2466}));
    return heff_tail(heff_get_n(v_z_245, 1, 3), 2, (V[]){v_t_2467, v_z_246});
  }
  case TAG_LikeString: {
    heff_drop(v_note_241);
    V v_t_2468 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_ty_244));
    V v_t_2469 = (g_heff_2eelab_2erules_2etyStr(v_e_242, v_a_243));
    V v_t_2470 = heff_strAppend(v_t_2468, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str12), v_t_2469));
    V v_msg_2471 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str13), v_t_2470);
    V v_t_2472 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2471, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2472})});
    V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tr(heff_call(heff_take_field(v_z_245, 2), 1, (V[]){v_t_2474}));
    return heff_tail(heff_get_n(v_z_245, 1, 3), 2, (V[]){v_t_2475, v_z_246});
  }
  case TAG_LikeRune: {
    heff_drop(v_note_241);
    V v_t_2476 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_ty_244));
    V v_t_2477 = (g_heff_2eelab_2erules_2etyStr(v_e_242, v_a_243));
    V v_t_2478 = heff_strAppend(v_t_2476, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str14), v_t_2477));
    V v_msg_2479 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str15), v_t_2478);
    V v_t_2480 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2479, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
    V v_t_2483 = heff_tr(heff_call(heff_take_field(v_z_245, 2), 1, (V[]){v_t_2482}));
    return heff_tail(heff_get_n(v_z_245, 1, 3), 2, (V[]){v_t_2483, v_z_246});
  }
  case TAG_LikeArray: {
    V v_ru_24t_247_24LikeArray = heff_take_reuse_n(v_t_247, 0ULL, 1);
    heff_drop(v_note_241);
    V v_t_2485 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_ty_244));
    V v_t_2486 = (g_heff_2eelab_2erules_2etyStr(v_e_242, v_a_243));
    V v_t_2487 = heff_strAppend(v_t_2485, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str16), v_t_2486));
    V v_msg_2488 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str17), v_t_2487);
    V v_t_2489 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2488, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2490 = heff_tag_at_n(v_ru_24t_247_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2489})});
    V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tr(heff_call(heff_take_field(v_z_245, 2), 1, (V[]){v_t_2491}));
    return heff_tail(heff_get_n(v_z_245, 1, 3), 2, (V[]){v_t_2492, v_z_246});
  }
  case TAG_LikeFixed: {
    V v_ru_24t_247_24LikeFixed = heff_take_reuse_n(v_t_247, 0ULL, 1);
    heff_drop(v_note_241);
    V v_t_2494 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_ty_244));
    V v_t_2495 = (g_heff_2eelab_2erules_2etyStr(v_e_242, v_a_243));
    V v_t_2496 = heff_strAppend(v_t_2494, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str18), v_t_2495));
    V v_msg_2497 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str19), v_t_2496);
    V v_t_2498 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_2497, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2499 = heff_tag_at_n(v_ru_24t_247_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2498})});
    V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
    V v_t_24101 = heff_tr(heff_call(heff_take_field(v_z_245, 2), 1, (V[]){v_t_24100}));
    return heff_tail(heff_get_n(v_z_245, 1, 3), 2, (V[]){v_t_24101, v_z_246});
  }
  case TAG_NoRules: {
    heff_drop(v_note_241);
    V v_t_24102 = (g_heff_2eelab_2erules_2etyStrM(heff_dup(v_e_242), v_ty_244));
    V v_t_24103 = (g_heff_2eelab_2erules_2etyStr(v_e_242, v_a_243));
    V v_t_24104 = heff_strAppend(v_t_24102, heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str20), v_t_24103));
    V v_msg_24105 = heff_strAppend(((V)&g_heff_2eelab_2erules_2euniverseAt_str21), v_t_24104);
    V v_t_24106 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), v_msg_24105, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24107 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24106})});
    V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
    V v_t_24109 = heff_tr(heff_call(heff_take_field(v_z_245, 2), 1, (V[]){v_t_24108}));
    return heff_tail(heff_get_n(v_z_245, 1, 3), 2, (V[]){v_t_24109, v_z_246});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2eelab_2erules_2euniverseAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2euniverseAt(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2erules_2euniverseAt_lam0(V self, V *args) {
  V v_u_2416 = args[0];
  V v_ty_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2416);
  V v_t_2417 = heff_tr(heff_call(heff_get_n(v_ty_244, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  return (g_heff_2eelab_2evalue_2eemap_24s196957333x715530534(v_t_2417));
}
HEFF_LIT(g_heff_2eelab_2erules_2eplacesSaid_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eplacesSaid_str1, 6, ", and ");
HEFF_LIT(g_heff_2eelab_2erules_2eplacesSaid_str2, 2, ", ");
Clo g_heff_2eelab_2erules_2eplacesSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eplacesSaid_entry, 1, 0};

V g_heff_2eelab_2erules_2eplacesSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2erules_2eplacesSaid_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_y_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2eelab_2erules_2eplacesSaid_str1), heff_dup(v_y_243)));
      }
      case TAG_Cons: {
        V v_s_247 = heff_dup(v_x_241);
        V v_s_248 = heff_strAppend(v_s_247, ((V)&g_heff_2eelab_2erules_2eplacesSaid_str2));
        return (g_heff_2eelab_2erules_2eplacesSaid_24acc(v_x12_242, v_s_248));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eplacesSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eplacesSaid(a0); heff_drop(a0); return r;
}