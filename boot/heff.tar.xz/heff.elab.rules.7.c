// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_CBind 55652
#define TAG_CEmpty 30359
#define TAG_CUndelay 45232
#define TAG_De 8978
#define TAG_Delay 58579
#define TAG_Describe 2650
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Left 13886
#define TAG_LikeSum 15116
#define TAG_MkChk 56962
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_RestoreWaiting 10254
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SaveDelayed 42463
#define TAG_SpId 35501
#define TAG_Throw 56084
#define TAG_Trace 9637
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Wake 10253
#define LBL_arms 9498206
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_digits 615232529
#define LBL_elabFor 712452832
#define LBL_evidence 1128105991
#define LBL_exponent 966452320
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_insts 301719303
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_named 305943379
#define LBL_names 305943394
#define LBL_negative 1666250321
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_text 10052084
#define LBL_trace 311979359
#define LBL_val 326043
#define LBL_values 1123329101
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey, LBL_arms};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_scope__globals__elabFor__lams__self__insts__named__evidence[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts, LBL_named, LBL_evidence};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_co_2ebind_24s1421083649x484987773(V, V, V, V);
V g_co_2ebind_24s1421083649x484987773_entry(V self, V *a);
extern Clo g_co_2ebind_24s1421083649x484987773_clo;
V g_heff_2eelab_2emeta_2eattempt(V, V, V);
V g_heff_2eelab_2emeta_2eattempt_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eattempt_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2emeta_2eliftU_24tok1(V, V, V, V);
V g_heff_2eelab_2emeta_2eliftU_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_24tok1_clo;
V g_heff_2eelab_2erules_2eboundGo(V, V, V);
V g_heff_2eelab_2erules_2eboundGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eboundGo_clo;
V g_heff_2eelab_2erules_2ecasesAt(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecasesAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecasesAt_clo;
HeffT2 g_heff_2eelab_2erules_2ecomputationWorld_24cpr(V, V);
V g_heff_2eelab_2erules_2edelayChkBy(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayChkBy_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayChkBy_clo;
V g_heff_2eelab_2erules_2edescribedBound(V, V);
V g_heff_2eelab_2erules_2edescribedBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edescribedBound_clo;
V g_heff_2eelab_2erules_2eentriesGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eentriesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eentriesGo_clo;
HeffT3 g_heff_2eelab_2erules_2eheldLocal_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2eimplicitDefaultAt(V, V, V, V, V);
V g_heff_2eelab_2erules_2eimplicitDefaultAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitDefaultAt_clo;
V g_heff_2eelab_2erules_2einArguments(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einArguments_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einArguments_clo;
V g_heff_2eelab_2erules_2einstShown(V, V, V);
V g_heff_2eelab_2erules_2einstShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstShown_clo;
V g_heff_2eelab_2erules_2eletsAround(V, V, V, V, V);
V g_heff_2eelab_2erules_2eletsAround_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletsAround_clo;
V g_heff_2eelab_2erules_2eletted(V, V, V, V, V);
V g_heff_2eelab_2erules_2eletted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletted_clo;
V g_heff_2eelab_2erules_2eletted_24generate0(V, V, V);
V g_heff_2eelab_2erules_2eletted_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletted_24generate0_clo;
V g_heff_2eelab_2erules_2eletted_24generate1(V, V, V);
V g_heff_2eelab_2erules_2eletted_24generate1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletted_24generate1_clo;
V g_heff_2eelab_2erules_2eletted_24map0(V, V);
V g_heff_2eelab_2erules_2eletted_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletted_24map0_clo;
V g_heff_2eelab_2erules_2eletted_24map1(V, V);
V g_heff_2eelab_2erules_2eletted_24map1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletted_24map1_clo;
V g_heff_2eelab_2erules_2ematchLater(V, V, V, V, V);
V g_heff_2eelab_2erules_2ematchLater_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ematchLater_clo;
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(V, V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_clo;
V g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_clo;
V g_heff_2eelab_2erules_2enumLitAt_24s82537585x550850204(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitAt_24s82537585x550850204_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitAt_24s82537585x550850204_clo;
HeffT1 g_heff_2eelab_2erules_2enumLitChk_24s578050171x2045645742_24cpr(V, V);
V g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229(V, V, V);
V g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229_clo;
V g_heff_2eelab_2erules_2eplacesGo(V, V);
V g_heff_2eelab_2erules_2eplacesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesGo_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2erecovering(V);
V g_heff_2eelab_2erules_2erecovering_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecovering_clo;
HeffT1 g_heff_2eelab_2erules_2erecovering_24cpr(V);
V g_heff_2eelab_2erules_2esameField(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esameField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esameField_clo;
V g_heff_2eelab_2erules_2esettled(V, V, V, V);
V g_heff_2eelab_2erules_2esettled_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esettled_clo;
V g_heff_2eelab_2erules_2esettled_24tok1(V, V, V, V, V);
V g_heff_2eelab_2erules_2esettled_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esettled_24tok1_clo;
V g_heff_2eelab_2erules_2espineHasLocal(V, V);
V g_heff_2eelab_2erules_2espineHasLocal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2espineHasLocal_clo;
V g_heff_2eelab_2erules_2esumFormation_24generate2(V, V, V);
V g_heff_2eelab_2erules_2esumFormation_24generate2_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24generate2_clo;
V g_heff_2eelab_2erules_2etooLarge(V, V, V, V, V);
V g_heff_2eelab_2erules_2etooLarge_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etooLarge_clo;
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2etyStrZ(V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_clo;
V g_heff_2eelab_2erules_2etyStrZ_24tok1(V, V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_24tok1_clo;
V g_heff_2eelab_2erules_2evaluesGo(V, V, V, V, V);
V g_heff_2eelab_2erules_2evaluesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evaluesGo_clo;
V g_heff_2eelab_2erules_2eworldFirst(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eworldFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eworldFirst_clo;
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo;
HeffT2 g_heff_2eelab_2eunify_2ezonker_24cpr(V);
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_list_2eany_24s228396297x1310020012(V);
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a);
extern Clo g_list_2eany_24s228396297x1310020012_clo;
V g_list_2efoldl_24f1325733028x1311723093(V, V, V);
V g_list_2efoldl_24f1325733028x1311723093_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1325733028x1311723093_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1729297000x968708966(V);
V g_list_2emap_24s1729297000x968708966_entry(V self, V *a);
extern Clo g_list_2emap_24s1729297000x968708966_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
double g_std_2emath_2efromDecimal_w(V, V);
V g_std_2emath_2efromDecimal(V, V);
V g_std_2emath_2efromDecimal_entry(V self, V *a);
extern Clo g_std_2emath_2efromDecimal_clo;
Clo g_heff_2eelab_2erules_2erecovering_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecovering_entry, 1, 0};

V g_heff_2eelab_2erules_2erecovering(V v_c_240) {
top: ;
  HeffT1 v_t_241 = (g_heff_2eelab_2erules_2erecovering_24cpr(v_c_240));
  {
    V v_field_242 = v_t_241.f[0];
    return heff_tag_n(TAG_MkChk, 1, (V[]){v_field_242});
  }
}
V g_heff_2eelab_2erules_2erecovering_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2erecovering(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2esettled_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2esettled_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esettled_lam0, 1, 0};
V g_heff_2eelab_2erules_2esettled_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esettled_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esettled_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esettled_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2esettled_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esettled_entry, 4, 0};

V g_heff_2eelab_2erules_2esettled(V v_final_240, V v_before_241, V v_hd_242, V v_k_243) {
top: ;
  V v_malg_244 = heff_take_field(v_hd_242, 2);
  V v_bind_245 = heff_get_n(v_hd_242, 1, 3);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2esettled_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(v_malg_244), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(v_bind_245), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2erules_2esettled_lam1, 1, 5, (V[]){heff_dup(v_final_240), v_before_241, v_k_243, v_malg_244, v_bind_245})});
}
V g_heff_2eelab_2erules_2esettled_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2esettled(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2esettled_lam0(V self, V *args) {
  V v_c_246 = args[0];
  return heff_get_n(v_c_246, 5, 9);
}
V g_heff_2eelab_2erules_2esettled_lam2(V self, V *args) {
  V v_c_2411 = args[0];
  V v_before_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_5 = v_before_241; V rr_ = heff_rec_reuse_nf(v_c_2411, 479ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 259071u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2erules_2esettled_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_drop(v_x_2419);
  heff_clo_take(self, 1);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esettled_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_malg_244 = heff_env(self)[0];
  V v_bind_245 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_t_2416 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2415, NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tr(heff_call(v_malg_244, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})}));
  V f_ = v_bind_245;
  heff_room[0] = v_t_2418;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esettled_lam4, 1, 1, (V[]){v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esettled_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_final_240 = heff_env(self)[0];
  V v_before_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_malg_244 = heff_env(self)[3];
  V v_bind_245 = heff_env(self)[4];
  if (((heff_dup(v_final_240) == NTAG(TAG_True)) || ({ V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2410)); int c_ = ({ V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_before_241)); int c_ = heff_intEq_c_lent(v_t_2420, v_t_2421, 0); heff_drop(v_t_2421); c_; }); heff_drop(v_t_2420); c_; }))) {
    heff_drop(v_x_2410);
    heff_clo_take(self, 5);
    heff_drop(v_final_240);
    heff_drop(v_before_241);
    heff_drop(v_malg_244);
    heff_drop(v_bind_245);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2410);
    heff_clo_take(self, 5);
    heff_drop(v_final_240);
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esettled_lam2, 1, 1, (V[]){v_before_241})})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_call(heff_dup(v_malg_244), 1, (V[]){v_t_2413}));
    V f_ = heff_dup(v_bind_245);
    heff_room[0] = v_t_2414;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esettled_lam3, 1, 3, (V[]){v_malg_244, v_bind_245, v_k_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eimplicitDefaultAt_str0, 83, "an implicit argument's default names definitions only, not the parameters before it");
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2eimplicitDefaultAt_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitDefaultAt_lam3, 1, 0};
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam5(V self, V *args);
Clo g_heff_2eelab_2erules_2eimplicitDefaultAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitDefaultAt_entry, 5, 0};

V g_heff_2eelab_2erules_2eimplicitDefaultAt(V v_e_240, V v_ty_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_e_240, 8);
    heff_drop_rec(v_ty_241, 2);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){NTAG(TAG_Nothing)});
  }
  case TAG_Just: {
    V v_d_245 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_span_246 = heff_take_field(v_d_245, 1);
    V v_chk_247 = heff_get_n(v_d_245, 0, 2);
    V v_x1_248 = heff_tr(heff_call(heff_get_n(v_ty_241, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_a_2412;
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Nom: {
      V v_x_249 = heff_field(v_x1_248, 0);
      heff_take_n(v_x1_248, 1ULL, 1);
      v_a_2412 = v_x_249;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_248, 0ULL, 1);
      v_a_2412 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2411 = heff_field(v_x1_248, 0);
      heff_take_n(v_x1_248, 1ULL, 1);
      v_a_2412 = v_x_2411;
      break;
    }
    default: heff_nomatch(v_x1_248);
    }
    V v_sp_2413 = v_span_246;
    V v_c_2414 = v_chk_247;
    HeffT1 v_t_2437 = ({ V b_0 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eimplicitDefaultAt_lam0, 2, 2, (V[]){v_c_2414, v_sp_2413})}); HeffT1 r_ = (g_heff_2eelab_2erules_2erecovering_24cpr(b_0)); heff_drop(b_0); r_; });
    {
      V v_field_2438 = v_t_2437.f[0];
      V v_f_2439 = v_field_2438;
      V v_t_2440 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_nf(v_e_240, 251ULL, 8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, 65487u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_c_2441 = heff_tr(heff_call(v_f_2439, 2, (V[]){v_t_2440, v_a_2412}));
      return heff_tail(v_c_2441, 2, (V[]){v_z_243, heff_clo_n(g_heff_2eelab_2erules_2eimplicitDefaultAt_lam5, 1, 1, (V[]){v_z_244})});
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eimplicitDefaultAt(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam3(V self, V *args) {
  V v_c0_2422 = args[0];
  return heff_get_n(v_c0_2422, 3, 9);
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_sp_2413 = heff_env(self)[1];
  V v_hd_2419 = heff_env(self)[2];
  V v_k_2420 = heff_env(self)[3];
  HeffT2 v_t_2427 = ({ V a_0 = v_x_2426; HeffT2 r_ = (g_heff_2eelab_2eunify_2ezonker_24cpr(a_0)); heff_drop(v_x_2426); r_; });
  {
    V v_field_2428 = v_t_2427.f[0];
    heff_drop(v_t_2427.f[1]);
    heff_clo_take(self, 4);
    V v_stx_2430 = heff_tr(heff_call(v_field_2428, 1, (V[]){heff_take_field(v_x_2421, 0)}));
    V v_t_2431 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(MK_INT(0LL), heff_dup(v_stx_2430)));
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_2421, 2);
      heff_drop(v_stx_2430);
      heff_drop(v_t_2431);
      V v_t_2432 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(345LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eimplicitDefaultAt_str0), v_sp_2413, NTAG(TAG_Nothing)});
      V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tr(heff_call(heff_take_field(v_hd_2419, 2), 1, (V[]){v_t_2434}));
      V f_ = heff_get_n(v_hd_2419, 1, 3);
      heff_room[0] = v_t_2435;
      heff_room[1] = v_k_2420;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_2413);
      heff_drop_rec(v_hd_2419, 3);
      heff_drop(v_t_2431);
      V v_t_2436 = ({ V rv_0 = v_stx_2430; V rr_ = heff_rec_reuse_nf(v_x_2421, 2ULL, 2, shape_stx__val, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V f_ = v_k_2420;
      args[0] = v_t_2436;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_2419 = heff_env(self)[0];
  V v_sp_2413 = heff_env(self)[1];
  V v_k_2420 = heff_env(self)[2];
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eimplicitDefaultAt_lam3_clo)})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2419, 2)), 1, (V[]){v_t_2424}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_2419, 1));
  heff_room[0] = v_t_2425;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eimplicitDefaultAt_lam4, 1, 4, (V[]){v_x_2421, v_sp_2413, v_hd_2419, v_k_2420});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam1(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_sp_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eimplicitDefaultAt_lam2, 1, 3, (V[]){v_hd_2419, v_sp_2413, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam0(V self, V *args) {
  V v_e_2415 = args[0];
  V v_a_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_sp_2413 = heff_env(self)[1];
  V v_c_2418;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_c_2414)) {
  case TAG_MkChk: {
    V v_f_2417 = heff_field(v_c_2414, 0);
    heff_take_n(v_c_2414, 1ULL, 1);
    v_c_2418 = heff_tr(heff_call(v_f_2417, 2, (V[]){v_e_2415, v_a_2416}));
    break;
  }
  default: heff_nomatch(v_c_2414);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eimplicitDefaultAt_lam1, 2, 2, (V[]){v_c_2418, v_sp_2413});
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam5(V self, V *args) {
  V v_x_2442 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_t_2443 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2442, 0, 2)});
  heff_clo_take(self, 1);
  V f_ = v_z_244;
  args[0] = v_t_2443;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2eheldLocal_24cpr_str0, 1, "#");
HEFF_LIT(g_heff_2eelab_2erules_2eheldLocal_24cpr_str1, 4, "With");
HEFF_LIT(g_heff_2eelab_2erules_2eheldLocal_24cpr_str2, 5, ".With");

HeffT3 g_heff_2eelab_2erules_2eheldLocal_24cpr(V v_mc_240, V v_l_241, V v_x3_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_CEmpty: {
    heff_drop(v_l_241);
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_CBind: {
    V v_c_244 = heff_field(v_x4_243, 0);
    V v_t_246 = heff_field(v_x4_243, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_l_241);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x3_242, 0);
      V v_xs_248 = heff_field(v_x3_242, 1);
      if (!heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2eelab_2erules_2eheldLocal_24cpr_str0), v_x_247, MK_INT(0LL), 5))) {
        V v_l_249 = heff_dup(v_l_241);
        V v_t_2410 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_240, heff_dup(v_t_246)));
        V v_t_2434;
        switch (heff_tag_of(v_t_2410)) {
        case TAG_VU: {
          heff_take_n(v_t_2410, 0ULL, 1);
          heff_drop(v_l_249);
          v_t_2434 = NTAG(TAG_False);
          break;
        }
        case TAG_VDecode: {
          V v_t1_2412 = heff_field(v_t_2410, 0);
          V v_sp_2413 = heff_field(v_t_2410, 1);
          heff_take_n(v_t_2410, 3ULL, 5);
          switch (heff_tag_of(v_t1_2412)) {
          case TAG_HLocal: {
            heff_take_n(v_t1_2412, 0ULL, 1);
            heff_drop(v_l_249);
            heff_drop(v_sp_2413);
            v_t_2434 = NTAG(TAG_False);
            break;
          }
          case TAG_HGlobal: {
            V v_k_2418 = heff_field(v_t1_2412, 0);
            heff_take_n(v_t1_2412, 1ULL, 1);
            if ((heff_strEq_c_lent(v_k_2418, ((V)&g_heff_2eelab_2erules_2eheldLocal_24cpr_str1), 2) || ({ int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_k_2418, 0)) - ((int64_t)5ULL)); int c_ = ({ V v_t_2437 = heff_strSlice_lent(v_k_2418, heff_box_word(v_t_2419), heff_strLength_lent(v_k_2418, 0), 6); int c_ = heff_strEq_c_lent(v_t_2437, ((V)&g_heff_2eelab_2erules_2eheldLocal_24cpr_str2), 2); heff_drop(v_t_2437); c_; }); c_; }))) {
              heff_drop(v_k_2418);
              v_t_2434 = ({ V a_0 = v_l_249; V a_1 = v_sp_2413; V r_ = (g_heff_2eelab_2erules_2espineHasLocal(a_0, a_1)); heff_drop(v_sp_2413); r_; });
            } else {
              heff_drop(v_l_249);
              heff_drop(v_sp_2413);
              heff_drop(v_k_2418);
              v_t_2434 = NTAG(TAG_False);
            }
            break;
          }
          case TAG_HMeta: {
            heff_take_n(v_t1_2412, 0ULL, 1);
            heff_drop(v_l_249);
            heff_drop(v_sp_2413);
            v_t_2434 = NTAG(TAG_False);
            break;
          }
          case TAG_HError: {
            heff_drop(v_l_249);
            heff_drop(v_sp_2413);
            v_t_2434 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_t1_2412);
          }
          break;
        }
        case TAG_VFunction: {
          heff_take_n(v_t_2410, 0ULL, 6);
          heff_drop(v_l_249);
          v_t_2434 = NTAG(TAG_False);
          break;
        }
        case TAG_VRecord: {
          heff_take_n(v_t_2410, 0ULL, 4);
          heff_drop(v_l_249);
          v_t_2434 = NTAG(TAG_False);
          break;
        }
        case TAG_VSum: {
          heff_take_n(v_t_2410, 0ULL, 1);
          heff_drop(v_l_249);
          v_t_2434 = NTAG(TAG_False);
          break;
        }
        case TAG_VPrimInt: {
          heff_drop(v_l_249);
          v_t_2434 = NTAG(TAG_False);
          break;
        }
        case TAG_VPrimFloat: {
          heff_drop(v_l_249);
          v_t_2434 = NTAG(TAG_False);
          break;
        }
        case TAG_VPrimString: {
          heff_drop(v_l_249);
          v_t_2434 = NTAG(TAG_False);
          break;
        }
        case TAG_VPrimRune: {
          heff_drop(v_l_249);
          v_t_2434 = NTAG(TAG_False);
          break;
        }
        case TAG_VPrimArray: {
          heff_take_n(v_t_2410, 0ULL, 1);
          heff_drop(v_l_249);
          v_t_2434 = NTAG(TAG_False);
          break;
        }
        case TAG_VFixed: {
          heff_take_n(v_t_2410, 0ULL, 1);
          heff_drop(v_l_249);
          v_t_2434 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_2410);
        }
        if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
          heff_drop(v_l_241);
          heff_drop(v_t_2434);
          V v_t_2435 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_240, heff_dup(v_t_246)));
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_247), v_t_2435}});
        } else {
          heff_drop(v_t_2434);
          V t_0 = v_mc_240;
          V t_1 = v_l_241;
          V t_2 = v_xs_248;
          V t_3 = v_c_244;
          v_mc_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
      } else {
        V t_0 = v_mc_240;
        V t_1 = v_l_241;
        V t_2 = v_xs_248;
        V t_3 = v_c_244;
        v_mc_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x3_242)}});
    }
  }
  case TAG_CUndelay: {
    V v_c_2436 = heff_field(v_x4_243, 0);
    V t_0 = v_mc_240;
    V t_1 = v_l_241;
    V t_2 = v_x3_242;
    V t_3 = v_c_2436;
    v_mc_240 = t_0;
    v_l_241 = t_1;
    v_x3_242 = t_2;
    v_x4_243 = t_3;
    goto top;
  }
  default: return ((HeffT3){{heff_nomatch(v_x4_243)}});
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eworldFirst_str0, 5, "unify");
HEFF_LIT(g_heff_2eelab_2erules_2eworldFirst_str1, 6, "world ");
HEFF_LIT(g_heff_2eelab_2erules_2eworldFirst_str2, 7, "  =\?=  ");
HEFF_LIT(g_heff_2eelab_2erules_2eworldFirst_str3, 27, "   ok, before the arguments");
V g_heff_2eelab_2erules_2eworldFirst_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eworldFirst_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eworldFirst_lam0, 1, 0};
V g_heff_2eelab_2erules_2eworldFirst_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2eworldFirst_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eworldFirst_lam2, 2, 0};
V g_heff_2eelab_2erules_2eworldFirst_lam4(V self, V *args); static Clo g_heff_2eelab_2erules_2eworldFirst_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eworldFirst_lam4, 1, 0};
V g_heff_2eelab_2erules_2eworldFirst_lam6(V self, V *args); static Clo g_heff_2eelab_2erules_2eworldFirst_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eworldFirst_lam6, 1, 0};
V g_heff_2eelab_2erules_2eworldFirst_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eworldFirst_lam10(V self, V *args); static Clo g_heff_2eelab_2erules_2eworldFirst_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eworldFirst_lam10, 1, 0};
V g_heff_2eelab_2erules_2eworldFirst_lam12(V self, V *args);
V g_heff_2eelab_2erules_2eworldFirst_lam14(V self, V *args);
V g_heff_2eelab_2erules_2eworldFirst_lam13(V self, V *args);
V g_heff_2eelab_2erules_2eworldFirst_lam15(V self, V *args);
V g_heff_2eelab_2erules_2eworldFirst_lam16(V self, V *args);
V g_heff_2eelab_2erules_2eworldFirst_lam18(V self, V *args);
V g_heff_2eelab_2erules_2eworldFirst_lam17(V self, V *args);
V g_heff_2eelab_2erules_2eworldFirst_lam11(V self, V *args);
V g_heff_2eelab_2erules_2eworldFirst_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eworldFirst_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eworldFirst_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eworldFirst_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eworldFirst_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eworldFirst_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eworldFirst_entry, 9, 0};

V g_heff_2eelab_2erules_2eworldFirst(V v_e_240, V v_sp_241, V v_since_242, V v_n_243, V v_headTy_244, V v_a_245, V v_t_246, V v_hd_247, V v_k_248) {
top: ;
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eworldFirst_lam0_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(heff_rfield(v_hd_247, 1)), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2eelab_2erules_2eworldFirst_lam1, 1, 9, (V[]){v_t_246, v_k_248, v_since_242, v_e_240, v_headTy_244, v_n_243, v_hd_247, v_a_245, v_sp_241})});
}
V g_heff_2eelab_2erules_2eworldFirst_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eworldFirst(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2eelab_2erules_2eworldFirst_lam0(V self, V *args) {
  V v_c_249 = args[0];
  return heff_get_n(v_c_249, 3, 9);
}
V g_heff_2eelab_2erules_2eworldFirst_lam2(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eworldFirst_lam4(V self, V *args) {
  V v_c_2435 = args[0];
  return v_c_2435;
}
V g_heff_2eelab_2erules_2eworldFirst_lam6(V self, V *args) {
  V v_sv_2440 = args[0];
  return v_sv_2440;
}
V g_heff_2eelab_2erules_2eworldFirst_lam8(V self, V *args) {
  V v_p_2448 = args[0];
  V v_p_2449 = args[1];
  V v_g_2444 = heff_env(self)[0];
  V v_len_2446 = heff_env(self)[1];
  V v_names_2447 = heff_env(self)[2];
  V v_hw_2417 = heff_env(self)[3];
  V v_w_2434 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2450 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo), 4, (V[]){v_g_2444, heff_rec_n(2, shape_len__names, (V[]){v_len_2446, v_names_2447}), v_hw_2417, v_w_2434}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2450, v_p_2448, v_p_2449));
}
V g_heff_2eelab_2erules_2eworldFirst_lam10(V self, V *args) {
  V v_c_2456 = args[0];
  return v_c_2456;
}
V g_heff_2eelab_2erules_2eworldFirst_lam12(V self, V *args) {
  V v_c_2464 = args[0];
  V v_x_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ps_2465 = heff_take_field(v_x_2439, 5);
  return ({ V rv_3 = heff_dup(heff_rfield(v_x_2439, 3)); V rv_4 = heff_get_n(v_x_2439, 4, 9); V rv_5 = v_ps_2465; V rr_ = heff_rec_reuse_nf(v_c_2464, 455ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 258111u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2erules_2eworldFirst_lam14(V self, V *args) {
  V v_x_2473 = args[0];
  V v_x_2443 = heff_env(self)[0];
  V v_malg_2454 = heff_env(self)[1];
  V v_bind_2455 = heff_env(self)[2];
  V v_k_2453 = heff_env(self)[3];
  heff_drop(v_x_2473);
  heff_clo_take(self, 4);
  V v_t_2474 = heff_tag_n(TAG_RestoreWaiting, 2, (V[]){v_x_2443, NTAG(TAG_MkUnit)});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tr(heff_call(v_malg_2454, 1, (V[]){v_t_2475}));
  V f_ = v_bind_2455;
  heff_room[0] = v_t_2476;
  heff_room[1] = v_k_2453;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eworldFirst_lam13(V self, V *args) {
  V v_x_2469 = args[0];
  V v_malg_2454 = heff_env(self)[0];
  V v_bind_2455 = heff_env(self)[1];
  V v_x_2443 = heff_env(self)[2];
  V v_k_2453 = heff_env(self)[3];
  V v_t_2470 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2469, NTAG(TAG_MkUnit)});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tr(heff_call(heff_dup(v_malg_2454), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(v_bind_2455);
  heff_room[0] = v_t_2472;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eworldFirst_lam14, 1, 4, (V[]){v_x_2443, v_malg_2454, v_bind_2455, v_k_2453});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eworldFirst_lam15(V self, V *args) {
  V v_u_2480 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_metas_2462 = heff_env(self)[1];
  V v_a_245 = heff_env(self)[2];
  V v_t_246 = heff_env(self)[3];
  heff_drop(v_u_2480);
  heff_clo_take(self, 4);
  V v_t_2481 = (g_heff_2eelab_2erules_2einstShown(heff_dup(v_e_240), v_metas_2462, v_a_245));
  V v_t_2482 = ({ V a_0 = v_e_240; V a_1 = v_metas_2462; V a_2 = v_t_246; V r_ = (g_heff_2eelab_2erules_2einstShown(a_0, a_1, a_2)); heff_drop(v_metas_2462); r_; });
  V v_t_2483 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eworldFirst_str1), v_t_2481), ((V)&g_heff_2eelab_2erules_2eworldFirst_str2));
  return heff_strAppend(heff_strAppend(v_t_2483, v_t_2482), ((V)&g_heff_2eelab_2erules_2eworldFirst_str3));
}
V g_heff_2eelab_2erules_2eworldFirst_lam16(V self, V *args) {
  V v_c_2486 = args[0];
  V v_x_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ps_2487 = heff_take_field(v_x_2439, 5);
  return ({ V rv_3 = heff_dup(heff_rfield(v_x_2439, 3)); V rv_4 = heff_get_n(v_x_2439, 4, 9); V rv_5 = v_ps_2487; V rr_ = heff_rec_reuse_nf(v_c_2486, 455ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 258111u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2erules_2eworldFirst_lam18(V self, V *args) {
  V v_x_2495 = args[0];
  V v_x_2443 = heff_env(self)[0];
  V v_malg_2454 = heff_env(self)[1];
  V v_bind_2455 = heff_env(self)[2];
  V v_k_2453 = heff_env(self)[3];
  heff_drop(v_x_2495);
  heff_clo_take(self, 4);
  V v_t_2496 = heff_tag_n(TAG_RestoreWaiting, 2, (V[]){v_x_2443, NTAG(TAG_MkUnit)});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tr(heff_call(v_malg_2454, 1, (V[]){v_t_2497}));
  V f_ = v_bind_2455;
  heff_room[0] = v_t_2498;
  heff_room[1] = v_k_2453;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eworldFirst_lam17(V self, V *args) {
  V v_x_2491 = args[0];
  V v_malg_2454 = heff_env(self)[0];
  V v_bind_2455 = heff_env(self)[1];
  V v_x_2443 = heff_env(self)[2];
  V v_k_2453 = heff_env(self)[3];
  V v_t_2492 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2491, NTAG(TAG_MkUnit)});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tr(heff_call(heff_dup(v_malg_2454), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(v_bind_2455);
  heff_room[0] = v_t_2494;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eworldFirst_lam18, 1, 4, (V[]){v_x_2443, v_malg_2454, v_bind_2455, v_k_2453});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eworldFirst_lam11(V self, V *args) {
  V v_x_2460 = args[0];
  V v_r_2451 = heff_env(self)[0];
  V v_x_2439 = heff_env(self)[1];
  V v_malg_2454 = heff_env(self)[2];
  V v_bind_2455 = heff_env(self)[3];
  V v_x_2443 = heff_env(self)[4];
  V v_k_2453 = heff_env(self)[5];
  V v_sp_241 = heff_env(self)[6];
  V v_e_240 = heff_env(self)[7];
  V v_a_245 = heff_env(self)[8];
  V v_t_246 = heff_env(self)[9];
  V v_postponed_2461 = heff_take_field(v_x_2460, 5);
  V v_metas_2462 = heff_get_n(v_x_2460, 3, 9);
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_r_2451)) {
  case TAG_Left: {
    V v_ru_24r_2451_24Left = heff_take_reuse_n(v_r_2451, 0ULL, 1);
    heff_drop(v_sp_241);
    heff_drop_rec(v_e_240, 8);
    heff_drop(v_a_245);
    heff_drop(v_t_246);
    heff_drop(v_postponed_2461);
    heff_drop(v_metas_2462);
    V v_t_2466 = heff_tag_at_n(v_ru_24r_2451_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eworldFirst_lam12, 1, 1, (V[]){v_x_2439})})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tr(heff_call(heff_dup(v_malg_2454), 1, (V[]){v_t_2467}));
    V f_ = heff_dup(v_bind_2455);
    heff_room[0] = v_t_2468;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eworldFirst_lam13, 1, 4, (V[]){v_malg_2454, v_bind_2455, v_x_2443, v_k_2453});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_ru_24r_2451_24Right = heff_take_reuse_n(v_r_2451, 0ULL, 1);
    V v_t_2478 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_postponed_2461; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_postponed_2461); r_; });
    V v_t_2479 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_x_2439, 5)));
    if (heff_intEq_c(v_t_2478, v_t_2479)) {
      heff_drop_rec(v_x_2439, 9);
      heff_drop(v_x_2443);
      heff_drop_cell(v_ru_24r_2451_24Right, 1);
      V v_t_2484 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){v_sp_241, ((V)&g_heff_2eelab_2erules_2eworldFirst_str0), heff_clo_n(g_heff_2eelab_2erules_2eworldFirst_lam15, 1, 4, (V[]){v_e_240, v_metas_2462, v_a_245, v_t_246})}), NTAG(TAG_MkUnit)});
      V v_t_2485 = heff_tr(heff_call(v_malg_2454, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})}));
      V f_ = v_bind_2455;
      heff_room[0] = v_t_2485;
      heff_room[1] = v_k_2453;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_241);
      heff_drop_rec(v_e_240, 8);
      heff_drop(v_a_245);
      heff_drop(v_t_246);
      heff_drop(v_metas_2462);
      V v_t_2488 = heff_tag_at_n(v_ru_24r_2451_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eworldFirst_lam16, 1, 1, (V[]){v_x_2439})})});
      V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
      V v_t_2490 = heff_tr(heff_call(heff_dup(v_malg_2454), 1, (V[]){v_t_2489}));
      V f_ = heff_dup(v_bind_2455);
      heff_room[0] = v_t_2490;
      heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eworldFirst_lam17, 1, 4, (V[]){v_malg_2454, v_bind_2455, v_x_2443, v_k_2453});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  default: return heff_nomatch(v_r_2451);
  }
}
V g_heff_2eelab_2erules_2eworldFirst_lam9(V self, V *args) {
  V v_r_2451 = args[0];
  V v_hd_2452 = args[1];
  V v_k_2453 = args[2];
  V v_x_2439 = heff_env(self)[0];
  V v_x_2443 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_a_245 = heff_env(self)[4];
  V v_t_246 = heff_env(self)[5];
  V v_malg_2454 = heff_take_field(v_hd_2452, 2);
  V v_bind_2455 = heff_get_n(v_hd_2452, 1, 3);
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eworldFirst_lam10_clo)})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tr(heff_call(heff_dup(v_malg_2454), 1, (V[]){v_t_2458}));
  heff_clo_take(self, 6);
  V f_ = heff_dup(v_bind_2455);
  args[0] = v_t_2459;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eworldFirst_lam11, 1, 10, (V[]){v_r_2451, v_x_2439, v_malg_2454, v_bind_2455, v_x_2443, v_k_2453, v_sp_241, v_e_240, v_a_245, v_t_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eworldFirst_lam7(V self, V *args) {
  V v_x_2443 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hw_2417 = heff_env(self)[1];
  V v_w_2434 = heff_env(self)[2];
  V v_x_2439 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_a_245 = heff_env(self)[5];
  V v_t_246 = heff_env(self)[6];
  V v_hd_247 = heff_env(self)[7];
  V v_k_248 = heff_env(self)[8];
  V v_g_2444 = heff_dup(heff_rfield(v_e_240, 1));
  V v_c_2445 = heff_dup(heff_rfield(v_e_240, 0));
  V v_len_2446 = heff_take_field(v_c_2445, 0);
  V v_names_2447 = heff_get_n(v_c_2445, 1, 5);
  heff_clo_take(self, 9);
  return (g_co_2ebind_24s1421083649x484987773(heff_clo_n(g_heff_2eelab_2erules_2eworldFirst_lam8, 2, 5, (V[]){v_g_2444, v_len_2446, v_names_2447, v_hw_2417, v_w_2434}), heff_clo_n(g_heff_2eelab_2erules_2eworldFirst_lam9, 3, 6, (V[]){v_x_2439, v_x_2443, v_sp_241, v_e_240, v_a_245, v_t_246}), v_hd_247, v_k_248));
}
V g_heff_2eelab_2erules_2eworldFirst_lam5(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hw_2417 = heff_env(self)[2];
  V v_w_2434 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_a_245 = heff_env(self)[5];
  V v_t_246 = heff_env(self)[6];
  V v_k_248 = heff_env(self)[7];
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_SaveDelayed, 1, (V[]){((V)&g_heff_2eelab_2erules_2eworldFirst_lam6_clo)})});
  V v_t_2442 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})}));
  heff_clo_take(self, 8);
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  heff_room[0] = v_t_2442;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eworldFirst_lam7, 1, 9, (V[]){v_e_240, v_hw_2417, v_w_2434, v_x_2439, v_sp_241, v_a_245, v_t_246, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eworldFirst_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_a_245 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_hw_2417 = heff_env(self)[5];
  V v_sp_241 = heff_env(self)[6];
  V v_t_246 = heff_env(self)[7];
  if (!(heff_dup(v_x_2430) == NTAG(TAG_True))) {
    heff_drop(v_x_2430);
    heff_clo_take(self, 8);
    heff_drop(v_x_2413);
    heff_drop(v_a_245);
    heff_drop_rec(v_hd_247, 3);
    heff_drop_rec(v_e_240, 8);
    heff_drop(v_hw_2417);
    heff_drop(v_sp_241);
    heff_drop(v_t_246);
    V f_ = v_k_248;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2430);
    heff_clo_take(self, 8);
    HeffT2 v_t_2431 = ({ V a_0 = v_x_2413; V a_1 = heff_dup(v_a_245); HeffT2 r_ = (g_heff_2eelab_2erules_2ecomputationWorld_24cpr(a_0, a_1)); heff_drop(v_x_2413); r_; });
    {
      V v_field_2433 = v_t_2431.f[1];
      int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
      if ((v_tag_2432 == ((int64_t)0ULL))) {
        V v_w_2434 = v_field_2433;
        V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eworldFirst_lam4_clo)})});
        V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
        V v_t_2438 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2437}));
        V f_ = heff_dup(heff_rfield(v_hd_247, 1));
        heff_room[0] = v_t_2438;
        heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eworldFirst_lam5, 1, 8, (V[]){v_hd_247, v_e_240, v_hw_2417, v_w_2434, v_sp_241, v_a_245, v_t_246, v_k_248});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_a_245);
        heff_drop_rec(v_hd_247, 3);
        heff_drop_rec(v_e_240, 8);
        heff_drop(v_hw_2417);
        heff_drop(v_sp_241);
        heff_drop(v_t_246);
        heff_drop(v_field_2433);
        V f_ = v_k_248;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
}
V g_heff_2eelab_2erules_2eworldFirst_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_t_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_since_242 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_headTy_244 = heff_env(self)[4];
  V v_n_243 = heff_env(self)[5];
  V v_hd_247 = heff_env(self)[6];
  V v_a_245 = heff_env(self)[7];
  V v_sp_241 = heff_env(self)[8];
  HeffT2 v_t_2414 = (g_heff_2eelab_2erules_2ecomputationWorld_24cpr(v_x_2413, heff_dup(v_t_246)));
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_hw_2417 = v_field_2416;
      V v_it_2418 = (g_heff_2eelab_2evalue_2eforceEl(v_x_2413, heff_dup(v_hw_2417)));
      switch (heff_tag_of(v_it_2418)) {
      case TAG_VNeu: {
        V v_it1_2419 = heff_field(v_it_2418, 0);
        heff_take_n(v_it_2418, 1ULL, 5);
        switch (heff_tag_of(v_it1_2419)) {
        case TAG_HLocal: {
          heff_take_n(v_it1_2419, 0ULL, 1);
          heff_drop(v_x_2413);
          heff_clo_take(self, 9);
          heff_drop(v_t_246);
          heff_drop(v_since_242);
          heff_drop_rec(v_e_240, 8);
          heff_drop(v_headTy_244);
          heff_drop(v_n_243);
          heff_drop_rec(v_hd_247, 3);
          heff_drop(v_a_245);
          heff_drop(v_sp_241);
          heff_drop(v_hw_2417);
          V f_ = v_k_248;
          args[0] = NTAG(TAG_MkUnit);
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
        case TAG_HGlobal: {
          heff_take_n(v_it1_2419, 0ULL, 1);
          heff_drop(v_x_2413);
          heff_clo_take(self, 9);
          heff_drop(v_t_246);
          heff_drop(v_since_242);
          heff_drop_rec(v_e_240, 8);
          heff_drop(v_headTy_244);
          heff_drop(v_n_243);
          heff_drop_rec(v_hd_247, 3);
          heff_drop(v_a_245);
          heff_drop(v_sp_241);
          heff_drop(v_hw_2417);
          V f_ = v_k_248;
          args[0] = NTAG(TAG_MkUnit);
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
        case TAG_HMeta: {
          V v_m_2426 = heff_field(v_it1_2419, 0);
          heff_take_n(v_it1_2419, 1ULL, 1);
          V v_t_2429;
          heff_clo_take(self, 9);
          if (heff_intLt_c_lent(v_m_2426, v_since_242, 2)) {
            heff_drop(v_headTy_244);
            heff_drop(v_n_243);
            heff_drop(v_m_2426);
            v_t_2429 = ((V)&g_heff_2eelab_2erules_2eworldFirst_lam2_clo);
          } else {
            v_t_2429 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2einArguments_clo), 5, (V[]){heff_dup(v_e_240), heff_dup(v_x_2413), v_m_2426, v_headTy_244, v_n_243}));
          }
          V f_ = v_t_2429;
          heff_room[0] = heff_dup(v_hd_247);
          heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eworldFirst_lam3, 1, 8, (V[]){v_k_248, v_x_2413, v_a_245, v_hd_247, v_e_240, v_hw_2417, v_sp_241, v_t_246});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_HError: {
          heff_drop(v_x_2413);
          heff_clo_take(self, 9);
          heff_drop(v_t_246);
          heff_drop(v_since_242);
          heff_drop_rec(v_e_240, 8);
          heff_drop(v_headTy_244);
          heff_drop(v_n_243);
          heff_drop_rec(v_hd_247, 3);
          heff_drop(v_a_245);
          heff_drop(v_sp_241);
          heff_drop(v_hw_2417);
          V f_ = v_k_248;
          args[0] = NTAG(TAG_MkUnit);
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
        default: return heff_nomatch(v_it1_2419);
        }
      }
      case TAG_VCode: {
        heff_take_n(v_it_2418, 0ULL, 1);
        heff_drop(v_x_2413);
        heff_clo_take(self, 9);
        heff_drop(v_t_246);
        heff_drop(v_since_242);
        heff_drop_rec(v_e_240, 8);
        heff_drop(v_headTy_244);
        heff_drop(v_n_243);
        heff_drop_rec(v_hd_247, 3);
        heff_drop(v_a_245);
        heff_drop(v_sp_241);
        heff_drop(v_hw_2417);
        V f_ = v_k_248;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_VLam: {
        heff_take_n(v_it_2418, 0ULL, 2);
        heff_drop(v_x_2413);
        heff_clo_take(self, 9);
        heff_drop(v_t_246);
        heff_drop(v_since_242);
        heff_drop_rec(v_e_240, 8);
        heff_drop(v_headTy_244);
        heff_drop(v_n_243);
        heff_drop_rec(v_hd_247, 3);
        heff_drop(v_a_245);
        heff_drop(v_sp_241);
        heff_drop(v_hw_2417);
        V f_ = v_k_248;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_VCons: {
        heff_take_n(v_it_2418, 0ULL, 1);
        heff_drop(v_x_2413);
        heff_clo_take(self, 9);
        heff_drop(v_t_246);
        heff_drop(v_since_242);
        heff_drop_rec(v_e_240, 8);
        heff_drop(v_headTy_244);
        heff_drop(v_n_243);
        heff_drop_rec(v_hd_247, 3);
        heff_drop(v_a_245);
        heff_drop(v_sp_241);
        heff_drop(v_hw_2417);
        V f_ = v_k_248;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_VOpaque: {
        heff_drop(v_x_2413);
        heff_clo_take(self, 9);
        heff_drop(v_t_246);
        heff_drop(v_since_242);
        heff_drop_rec(v_e_240, 8);
        heff_drop(v_headTy_244);
        heff_drop(v_n_243);
        heff_drop_rec(v_hd_247, 3);
        heff_drop(v_a_245);
        heff_drop(v_sp_241);
        heff_drop(v_hw_2417);
        V f_ = v_k_248;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_it_2418);
      }
    } else {
      heff_drop(v_x_2413);
      heff_clo_take(self, 9);
      heff_drop(v_t_246);
      heff_drop(v_since_242);
      heff_drop_rec(v_e_240, 8);
      heff_drop(v_headTy_244);
      heff_drop(v_n_243);
      heff_drop_rec(v_hd_247, 3);
      heff_drop(v_a_245);
      heff_drop(v_sp_241);
      heff_drop(v_field_2416);
      V f_ = v_k_248;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_str0, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_str1, 22, ", but got the literal ");
HEFF_LIT(g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_str2, 11, ", which is ");
HEFF_LIT(g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_str3, 7, "a float");
V g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_lam0(V self, V *args);
V g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_entry, 6, 0};

V g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(V v_lit_240, V v_sp_241, V v_e_242, V v_a_243, V v_p_244, V v_p_245) {
top: ;
  V v_negative_246 = heff_take_field(v_lit_240, 0);
  V v_digits_247 = heff_take_field(v_lit_240, 1);
  V v_exponent_248 = heff_get_n(v_lit_240, 2, 3);
  V v_t_2431;
  switch (heff_tag_of(v_a_243)) {
  case TAG_VU: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_2410 = heff_dup(heff_field(v_a_243, 0));
    switch (heff_tag_of(v_h_2410)) {
    case TAG_HLocal: {
      heff_take_n(v_h_2410, 0ULL, 1);
      v_t_2431 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_2410, 0ULL, 1);
      v_t_2431 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_2410, 0ULL, 1);
      v_t_2431 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2431 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_2410);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_243);
  }
  if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
    heff_drop(v_sp_241);
    heff_drop(v_e_242);
    heff_drop_rec(v_p_244, 3);
    heff_drop(v_negative_246);
    heff_drop(v_digits_247);
    heff_drop(v_exponent_248);
    heff_drop(v_t_2431);
    V v_t_2435 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_lam0, 1, 1, (V[]){v_a_243})});
    return heff_tail(v_p_245, 1, (V[]){v_t_2435});
  } else {
    heff_drop(v_t_2431);
    return (g_heff_2eelab_2erules_2etyStrZ(v_e_242, v_a_243, heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_lam2, 1, 6, (V[]){v_negative_246, v_digits_247, v_exponent_248, v_sp_241, v_p_244, v_p_245})));
  }
}
V g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_lam1(V self, V *args) {
  V v_u_2433 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_drop(v_u_2433);
  heff_clo_take(self, 1);
  return v_a_243;
}
V g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_lam0(V self, V *args) {
  V v_u_2432 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_drop(v_u_2432);
  heff_clo_take(self, 1);
  V v_t_2434 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_lam1, 1, 1, (V[]){v_a_243}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2434});
}
V g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_lam2(V self, V *args) {
  V v_x_2436 = args[0];
  V v_negative_246 = heff_env(self)[0];
  V v_digits_247 = heff_env(self)[1];
  V v_exponent_248 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2437 = v_negative_246;
  double v_t_2439;
  if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
    heff_drop(v_t_2437);
    double v_x_2438 = (g_std_2emath_2efromDecimal_w(v_digits_247, v_exponent_248));
    v_t_2439 = ((-1.0) * v_x_2438);
  } else {
    heff_drop(v_t_2437);
    v_t_2439 = (g_std_2emath_2efromDecimal_w(v_digits_247, v_exponent_248));
  }
  V v_t_2440 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_str0), v_x_2436), ((V)&g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_str1));
  V v_t_2441 = heff_strAppend(v_t_2440, heff_floatShow(heff_box_f64(v_t_2439)));
  V v_msg_2442 = heff_strAppend(heff_strAppend(v_t_2441, ((V)&g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_str2)), ((V)&g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_str3));
  V v_t_2443 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_msg_2442, v_sp_241, NTAG(TAG_Nothing)});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2445}));
  V f_ = heff_get_n(v_p_244, 1, 3);
  heff_room[0] = v_t_2446;
  heff_room[1] = v_p_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eletted_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eletted_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eletted_lam0, 1, 0};
V g_heff_2eelab_2erules_2eletted_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2eletted_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eletted_lam2, 1, 0};
V g_heff_2eelab_2erules_2eletted_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eletted_lam3(V self, V *args);
Clo g_heff_2eelab_2erules_2eletted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eletted_entry, 5, 0};

V g_heff_2eelab_2erules_2eletted(V v_e_240, V v_a_241, V v_made_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_e_240, 2));
  V v_c_248;
  switch (heff_tag_of(v_t_245)) {
  case TAG_ForNominative: {
    v_c_248 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_245, 0ULL, 2);
    v_c_248 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_pairs_249 = (g_list_2emap_24s1729297000x968708966(heff_dup(v_made_242)));
  V v_t_2410 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_249)));
  V v_t_2411 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_249));
  V v_t_2412 = (g_list_2emap_24s1173914895x100384474(v_pairs_249));
  V v_d_2413 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2410), v_t_2411, heff_arrayFromList(v_t_2412)});
  V v_xs_2414 = heff_dup(heff_rfield(v_d_2413, 2));
  V v_m_2415 = heff_arrayLength_lent(v_xs_2414, 0);
  V v_t_2420;
  if ((heff_peek_word(v_m_2415) <= ((int64_t)0ULL))) {
    heff_drop(v_xs_2414);
    v_t_2420 = heff_arrayGenerate(v_m_2415, ((V)&g_heff_2eelab_2erules_2eletted_lam0_clo));
  } else {
    V v_m_2417 = heff_arrayIndex_lent(v_xs_2414, MK_INT(0LL), 2);
    V v_y_2418 = heff_get_n(v_m_2417, 0, 2);
    V v_t_2419 = heff_arrayKeepsAs_lent(v_xs_2414, v_y_2418, 0);
    if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
      heff_drop(v_m_2415);
      heff_drop(v_t_2419);
      v_t_2420 = (g_heff_2eelab_2erules_2eletted_24map0(MK_INT(1LL), heff_arraySet(v_xs_2414, MK_INT(0LL), v_y_2418)));
    } else {
      heff_drop(v_t_2419);
      v_t_2420 = ({ V a_0 = v_xs_2414; V a_1 = MK_INT(1LL); V a_2 = heff_arrayReplicate(v_m_2415, v_y_2418); V r_ = (g_heff_2eelab_2erules_2eletted_24generate0(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    }
  }
  V v_t_2421 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_dup(heff_rfield(v_d_2413, 0)), heff_dup(heff_rfield(v_d_2413, 1)), v_t_2420});
  V v_record_2432 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SCons, 1, (V[]){v_t_2421}), heff_clo_n(g_heff_2eelab_2erules_2eletted_lam1, 1, 2, (V[]){v_d_2413, v_c_248})});
  V v_bound_2433 = (g_heff_2eelab_2erules_2eboundGo(v_made_242, heff_dup(v_made_242), MK_INT(0LL)));
  V v_t_2434 = (g_list_2eany_24s228396297x1310020012(v_bound_2433));
  if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
    heff_drop(v_t_2434);
    V v_e_2435 = v_e_240;
    V v_a_2436 = v_a_241;
    V v_made_2437 = v_made_242;
    V v_record_2438 = v_record_2432;
    V v_bound_2439 = heff_dup(v_bound_2433);
    V v_places_2440 = (g_heff_2eelab_2erules_2eplacesGo(v_bound_2433, MK_INT(0LL)));
    V v_c_2441 = (g_heff_2eelab_2erules_2edescribedBound(v_made_2437, v_bound_2439));
    return heff_tail(v_c_2441, 2, (V[]){v_z_243, heff_clo_n(g_heff_2eelab_2erules_2eletted_lam3, 1, 7, (V[]){v_e_2435, v_places_2440, v_made_2437, v_bound_2439, v_a_2436, v_record_2438, v_z_244})});
  } else {
    heff_drop_rec(v_e_240, 8);
    heff_drop(v_a_241);
    heff_drop(v_made_242);
    heff_drop(v_z_243);
    heff_drop(v_bound_2433);
    heff_drop(v_t_2434);
    return heff_tail(v_z_244, 1, (V[]){v_record_2432});
  }
}
V g_heff_2eelab_2erules_2eletted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eletted(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2eletted_lam0(V self, V *args) {
  V v_u_2416 = args[0];
  heff_drop(v_u_2416);
  return heff_abandon();
}
V g_heff_2eelab_2erules_2eletted_lam2(V self, V *args) {
  V v_u_2425 = args[0];
  heff_drop(v_u_2425);
  return heff_abandon();
}
V g_heff_2eelab_2erules_2eletted_lam1(V self, V *args) {
  V v_u_2422 = args[0];
  V v_d_2413 = heff_env(self)[0];
  V v_c_248 = heff_env(self)[1];
  heff_drop(v_u_2422);
  heff_clo_take(self, 2);
  V v_xs_2423 = heff_take_field(v_d_2413, 2);
  V v_m_2424 = heff_arrayLength_lent(v_xs_2423, 0);
  V v_t_2429;
  if ((heff_peek_word(v_m_2424) <= ((int64_t)0ULL))) {
    heff_drop(v_xs_2423);
    v_t_2429 = heff_arrayGenerate(v_m_2424, ((V)&g_heff_2eelab_2erules_2eletted_lam2_clo));
  } else {
    V v_m_2426 = heff_arrayIndex_lent(v_xs_2423, MK_INT(0LL), 2);
    V v_y_2427 = heff_tr(heff_call(heff_get_n(v_m_2426, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2428 = heff_arrayKeepsAs_lent(v_xs_2423, v_y_2427, 0);
    if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
      heff_drop(v_m_2424);
      heff_drop(v_t_2428);
      v_t_2429 = (g_heff_2eelab_2erules_2eletted_24map1(MK_INT(1LL), heff_arraySet(v_xs_2423, MK_INT(0LL), v_y_2427)));
    } else {
      heff_drop(v_t_2428);
      v_t_2429 = ({ V a_0 = v_xs_2423; V a_1 = MK_INT(1LL); V a_2 = heff_arrayReplicate(v_m_2424, v_y_2427); V r_ = (g_heff_2eelab_2erules_2eletted_24generate1(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
    }
  }
  V v_t_2430 = ({ V rv_2 = v_t_2429; V rr_ = heff_rec_reuse_nf(v_d_2413, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_x_2431 = heff_tag_n(TAG_VCons, 1, (V[]){v_t_2430});
  switch (heff_tag_of(v_c_248)) {
  case TAG_N: {
    return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2431});
  }
  case TAG_De: {
    return heff_tag_n(TAG_Describe, 1, (V[]){v_x_2431});
  }
  default: return heff_nomatch(v_c_248);
  }
}
V g_heff_2eelab_2erules_2eletted_lam3(V self, V *args) {
  V v_x_2442 = args[0];
  V v_e_2435 = heff_env(self)[0];
  V v_places_2440 = heff_env(self)[1];
  V v_made_2437 = heff_env(self)[2];
  V v_bound_2439 = heff_env(self)[3];
  V v_a_2436 = heff_env(self)[4];
  V v_record_2438 = heff_env(self)[5];
  V v_z_244 = heff_env(self)[6];
  heff_drop(v_x_2442);
  V v_t_2443 = heff_get_n(heff_dup(heff_rfield(v_e_2435, 0)), 0, 5);
  V v_t_2444 = (g_heff_2eelab_2erules_2evaluesGo(v_t_2443, heff_dup(v_places_2440), heff_dup(v_made_2437), heff_dup(v_places_2440), MK_INT(0LL)));
  heff_clo_take(self, 7);
  V v_t_2445 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_bound_2439; V r_ = (g_list_2efoldl_24f1325733028x1311723093(a_0, a_1, a_2)); heff_drop(v_bound_2439); r_; });
  V v_t_2446 = heff_get_n(heff_dup(heff_rfield(v_e_2435, 0)), 0, 5);
  V v_pairs_2447 = (g_heff_2eelab_2erules_2eentriesGo(v_t_2446, v_t_2445, heff_dup(v_places_2440), v_made_2437, v_places_2440, MK_INT(0LL)));
  V v_t_2448 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_2447)));
  V v_t_2449 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_2447));
  V v_t_2450 = (g_list_2emap_24s1173914895x100384474(v_pairs_2447));
  V v_t_2451 = heff_get_n(heff_get_n(v_e_2435, 0, 8), 0, 5);
  V v_t_2452 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2448), v_t_2449, heff_arrayFromList(v_t_2450)});
  V v_t_2453 = (g_heff_2eelab_2erules_2eletsAround(v_t_2451, v_a_2436, v_t_2444, MK_INT(0LL), heff_tag_n(TAG_SCons, 1, (V[]){v_t_2452})));
  V v_x_2454 = ({ V rv_0 = v_t_2453; V rr_ = heff_rec_reuse_nf(v_record_2438, 2ULL, 2, shape_stx__val, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V f_ = v_z_244;
  args[0] = v_x_2454;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esumFormation_24generate2_lam0(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_24generate2_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2esumFormation_24generate2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_24generate2_entry, 3, 0};

V g_heff_2eelab_2erules_2esumFormation_24generate2(V v_xs_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if (((((int64_t)0ULL) <= v_i_241) && (heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_m_243 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_241), 2);
      V v_t_249 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), heff_clo_n(g_heff_2eelab_2erules_2esumFormation_24generate2_lam0, 1, 1, (V[]){v_m_243}));
      V t_0 = v_xs_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = v_t_249;
      v_xs_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_m_243 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_241), 2);
    V v_t_249 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), heff_clo_n(g_heff_2eelab_2erules_2esumFormation_24generate2_lam1, 1, 1, (V[]){v_m_243}));
    V t_0 = v_xs_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = v_t_249;
    v_xs_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2erules_2esumFormation_24generate2_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2esumFormation_24generate2(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2esumFormation_24generate2_lam0(V self, V *args) {
  V v_u2_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_drop(v_u2_244);
  heff_clo_take(self, 1);
  V v_x1_245 = heff_tr(heff_call(heff_get_n(v_m_243, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Nom: {
    V v_x_246 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 1);
    return v_x_246;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_245, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_248 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 1);
    return v_x_248;
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2eelab_2erules_2esumFormation_24generate2_lam1(V self, V *args) {
  V v_u2_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_drop(v_u2_244);
  heff_clo_take(self, 1);
  V v_x1_245 = heff_tr(heff_call(heff_get_n(v_m_243, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Nom: {
    V v_x_246 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 1);
    return v_x_246;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_245, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_248 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 1);
    return v_x_248;
  }
  default: return heff_nomatch(v_x1_245);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str0, 34, "cannot match against non-sum type ");
V g_heff_2eelab_2erules_2ematchLater_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ematchLater_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ematchLater_entry, 5, 0};

V g_heff_2eelab_2erules_2ematchLater(V v_sp_240, V v_scrut_241, V v_a_242, V v_tags_243, V v_casesChk_244) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam0, 4, 5, (V[]){v_a_242, v_sp_240, v_scrut_241, heff_dup(v_tags_243), v_casesChk_244})});
}
V g_heff_2eelab_2erules_2ematchLater_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2ematchLater(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2ematchLater_lam1(V self, V *args) {
  V v_c_249 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_249, 3, 9); V a_1 = v_a_242; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2ematchLater_lam5(V self, V *args) {
  V v_u_2418 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_drop(v_u_2418);
  heff_clo_take(self, 1);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam4(V self, V *args) {
  V v_u_2417 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_drop(v_u_2417);
  heff_clo_take(self, 1);
  V v_t_2419 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam5, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2419});
}
V g_heff_2eelab_2erules_2ematchLater_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  if ((heff_dup(v_x_2416) == NTAG(TAG_True))) {
    heff_drop(v_x_2416);
    heff_clo_take(self, 6);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2420 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam4, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2416);
    heff_clo_take(self, 6);
    heff_drop(v_b2_246);
    V v_t_2421 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_2422 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str0), v_t_2421);
    V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2422, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2425}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_2426;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e2_245 = heff_env(self)[1];
  V v_b2_246 = heff_env(self)[2];
  V v_scrut_241 = heff_env(self)[3];
  V v_tags_243 = heff_env(self)[4];
  V v_casesChk_244 = heff_env(self)[5];
  V v_hd_247 = heff_env(self)[6];
  V v_k_248 = heff_env(self)[7];
  V v_t_2414 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2413)));
  switch (heff_tag_of(v_t_2414)) {
  case TAG_LikeSum: {
    V v_vs_2415 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    heff_clo_take(self, 8);
    return ({ V a_0 = v_sp_240; V a_1 = v_e2_245; V a_2 = v_b2_246; V a_3 = v_scrut_241; V a_4 = v_x_2413; V a_5 = NTAG(TAG_Nothing); V a_6 = v_vs_2415; V a_7 = v_tags_243; V a_8 = v_casesChk_244; V a_9 = v_hd_247; V a_10 = v_k_248; V r_ = (g_heff_2eelab_2erules_2ecasesAt(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_tags_243); r_; });
  }
  default: {
    heff_clo_take(self, 8);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    heff_drop(v_t_2414);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam3, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam0(V self, V *args) {
  V v_e2_245 = args[0];
  V v_b2_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V v_a_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_scrut_241 = heff_env(self)[2];
  V v_tags_243 = heff_env(self)[3];
  V v_casesChk_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam1, 1, 1, (V[]){v_a_242})})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  args[0] = v_t_2412;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam2, 1, 8, (V[]){v_sp_240, v_e2_245, v_b2_246, v_scrut_241, v_tags_243, v_casesChk_244, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2esameField_str0, 6, "field ");
HEFF_LIT(g_heff_2eelab_2erules_2esameField_str1, 12, " is of type ");
HEFF_LIT(g_heff_2eelab_2erules_2esameField_str2, 36, " in the record updated, but of type ");
HEFF_LIT(g_heff_2eelab_2erules_2esameField_str3, 31, " in the record made: set it too");
V g_heff_2eelab_2erules_2esameField_lam0(V self, V *args);
V g_heff_2eelab_2erules_2esameField_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esameField_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esameField_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esameField_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2esameField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esameField_entry, 8, 0};

V g_heff_2eelab_2erules_2esameField(V v_sp_240, V v_e_241, V v_x_242, V v_fty_243, V v_m_244, V v_t_245, V v_hd_246, V v_k_247) {
top: ;
  V v_g_248 = heff_dup(heff_rfield(v_e_241, 1));
  V v_c_249 = heff_dup(heff_rfield(v_e_241, 0));
  V v_len_2410 = heff_take_field(v_c_249, 0);
  V v_names_2411 = heff_get_n(v_c_249, 1, 5);
  return (g_heff_2eelab_2emeta_2eattempt(heff_clo_n(g_heff_2eelab_2erules_2esameField_lam0, 2, 5, (V[]){v_g_248, v_len_2410, v_names_2411, heff_dup(v_fty_243), heff_dup(v_t_245)}), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2esameField_lam1, 1, 8, (V[]){v_e_241, v_fty_243, v_hd_246, v_t_245, v_x_242, v_sp_240, v_k_247, v_m_244})));
}
V g_heff_2eelab_2erules_2esameField_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esameField(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2esameField_lam0(V self, V *args) {
  V v_p_2412 = args[0];
  V v_p_2413 = args[1];
  V v_g_248 = heff_env(self)[0];
  V v_len_2410 = heff_env(self)[1];
  V v_names_2411 = heff_env(self)[2];
  V v_fty_243 = heff_env(self)[3];
  V v_t_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo), 4, (V[]){v_g_248, heff_rec_n(2, shape_len__names, (V[]){v_len_2410, v_names_2411}), v_fty_243, v_t_245}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2414, v_p_2412, v_p_2413));
}
V g_heff_2eelab_2erules_2esameField_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_err_2416 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_note_2419 = ({ V a_0 = heff_get_n(v_e_241, 1, 8); V a_1 = v_err_2416; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2416); r_; });
  V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2esameField_str0), v_x_242), ((V)&g_heff_2eelab_2erules_2esameField_str1));
  V v_t_2421 = heff_strAppend(heff_strAppend(v_t_2420, v_x_2418), ((V)&g_heff_2eelab_2erules_2esameField_str2));
  V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2421, v_x_2417), ((V)&g_heff_2eelab_2erules_2esameField_str3));
  V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_2422, v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){v_note_2419})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2425}));
  V f_ = heff_get_n(v_hd_246, 1, 3);
  heff_room[0] = v_t_2426;
  heff_room[1] = v_k_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esameField_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_err_2416 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2erules_2etyStrZ(heff_dup(v_e_241), v_t_245, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2esameField_lam3, 1, 7, (V[]){v_e_241, v_err_2416, v_x_242, v_x_2417, v_sp_240, v_hd_246, v_k_247})));
}
V g_heff_2eelab_2erules_2esameField_lam4(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  heff_drop(v_x_2431);
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = v_m_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esameField_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_fty_243 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_t_245 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_m_244 = heff_env(self)[7];
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_err_2416 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Left = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    heff_clo_take(self, 8);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2etyStrZ_24tok1(v_ru_24x_2415_24Left, heff_dup(v_e_241), v_fty_243, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2esameField_lam2, 1, 7, (V[]){v_e_241, v_t_245, v_hd_246, v_err_2416, v_x_242, v_sp_240, v_k_247})));
  }
  case TAG_Right: {
    V v_ru_24x_2415_24Right = heff_take_reuse_n(v_x_2415, 0ULL, 1);
    heff_clo_take(self, 8);
    heff_drop_rec(v_e_241, 8);
    heff_drop(v_fty_243);
    heff_drop(v_t_245);
    heff_drop(v_x_242);
    heff_drop(v_sp_240);
    V v_t_2428 = heff_tag_n(TAG_Wake, 2, (V[]){NTAG(TAG_False), NTAG(TAG_MkUnit)});
    V v_t_2429 = heff_tag_at_n(v_ru_24x_2415_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2429}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2430;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esameField_lam4, 1, 2, (V[]){v_k_247, v_m_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2415);
  }
}
Clo g_heff_2eelab_2erules_2etooLarge_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etooLarge_entry, 5, 0};

V g_heff_2eelab_2erules_2etooLarge(V v_sp_240, V v_msg_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  V v_malg_245 = heff_take_field(v_p_243, 2);
  V v_bind_246 = heff_get_n(v_p_243, 1, 3);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(309LL), NTAG(TAG_SError), v_msg_241, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_call(v_malg_245, 1, (V[]){v_t_249}));
    return heff_tail(v_bind_246, 2, (V[]){v_t_2410, v_p_244});
  }
  case TAG_Just: {
    V v_note_2411 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(309LL), NTAG(TAG_SError), v_msg_241, v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){v_note_2411})});
    V v_t_2413 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(v_malg_245, 1, (V[]){v_t_2414}));
    return heff_tail(v_bind_246, 2, (V[]){v_t_2415, v_p_244});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2etooLarge_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etooLarge(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2eelab_2erules_2enumLitChk_24s578050171x2045645742_24cpr_str0, 7, "literal");
V g_heff_2eelab_2erules_2enumLitChk_24s578050171x2045645742_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enumLitChk_24s578050171x2045645742_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2enumLitChk_24s578050171x2045645742_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enumLitChk_24s578050171x2045645742_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2enumLitChk_24s578050171x2045645742_24cpr(V v_lit_240, V v_sp_241) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_24s578050171x2045645742_24cpr_lam0, 4, 2, (V[]){v_lit_240, v_sp_241})}});
}
V g_heff_2eelab_2erules_2enumLitChk_24s578050171x2045645742_24cpr_lam1(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 9); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2enumLitChk_24s578050171x2045645742_24cpr_lam3(V self, V *args) {
  V v_chk_2435 = args[0];
  V v_hd_2436 = args[1];
  V v_k2_2437 = args[2];
  V v_x_2410 = heff_env(self)[0];
  V v_t_2438 = heff_tr(heff_call(v_chk_2435, 2, (V[]){heff_dup(v_hd_2436), heff_dup(heff_rfield(v_hd_2436, 0))}));
  heff_clo_take(self, 1);
  V v_t_2439 = heff_tag_n(TAG_Delay, 3, (V[]){v_x_2410, v_t_2438, NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tr(heff_call(heff_take_field(v_hd_2436, 2), 1, (V[]){v_t_2440}));
  V f_ = heff_get_n(v_hd_2436, 1, 3);
  args[0] = v_t_2441;
  args[1] = v_k2_2437;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2enumLitChk_24s578050171x2045645742_24cpr_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_t_2433;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_VU: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_t1_2412 = heff_dup(heff_field(v_x_2410, 0));
    switch (heff_tag_of(v_t1_2412)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_2412, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_2412, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_2412, 0ULL, 1);
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_HError: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t1_2412);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
    heff_drop(v_t_2433);
    heff_clo_take(self, 5);
    V v_c_2434 = (g_heff_2eelab_2erules_2enumLitWait_24s40114457x2001757229(v_lit_240, MK_INT(1LL), heff_dup(v_sp_241)));
    return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_24s578050171x2045645742_24cpr_lam3, 3, 1, (V[]){heff_dup(v_x_2410)}); V a_1 = v_e_242; V a_2 = v_sp_241; V a_3 = ((V)&g_heff_2eelab_2erules_2enumLitChk_24s578050171x2045645742_24cpr_str0); V a_4 = v_c_2434; V a_5 = v_x_2410; V a_6 = v_hd_244; V a_7 = v_k_245; V r_ = (g_heff_2eelab_2erules_2edelayChkBy(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_2434); r_; });
  } else {
    heff_drop(v_t_2433);
    heff_clo_take(self, 5);
    return (g_heff_2eelab_2erules_2enumLitAt_24s82537585x550850204(v_lit_240, v_sp_241, v_e_242, v_x_2410, v_hd_244, v_k_245));
  }
}
V g_heff_2eelab_2erules_2enumLitChk_24s578050171x2045645742_24cpr_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a0_243 = args[1];
  V v_hd_244 = args[2];
  V v_k_245 = args[3];
  V v_lit_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_24s578050171x2045645742_24cpr_lam1, 1, 1, (V[]){v_a0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_249;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_24s578050171x2045645742_24cpr_lam2, 1, 5, (V[]){v_lit_240, v_sp_241, v_e_242, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esettled_24tok1_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2esettled_24tok1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esettled_24tok1_lam0, 1, 0};
V g_heff_2eelab_2erules_2esettled_24tok1_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esettled_24tok1_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esettled_24tok1_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esettled_24tok1_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2esettled_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esettled_24tok1_entry, 5, 0};

V g_heff_2eelab_2erules_2esettled_24tok1(V v_tok_240, V v_final_241, V v_before_242, V v_hd_243, V v_k_244) {
top: ;
  V v_malg_245 = heff_take_field(v_hd_243, 2);
  V v_bind_246 = heff_get_n(v_hd_243, 1, 3);
  V v_t_248 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2esettled_24tok1_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(v_malg_245), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(v_bind_246), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2erules_2esettled_24tok1_lam1, 1, 5, (V[]){heff_dup(v_final_241), v_before_242, v_k_244, v_malg_245, v_bind_246})});
}
V g_heff_2eelab_2erules_2esettled_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2esettled_24tok1(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2esettled_24tok1_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 5, 9);
}
V g_heff_2eelab_2erules_2esettled_24tok1_lam2(V self, V *args) {
  V v_c_2412 = args[0];
  V v_before_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_5 = v_before_242; V rr_ = heff_rec_reuse_nf(v_c_2412, 479ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 259071u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2erules_2esettled_24tok1_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_244 = heff_env(self)[0];
  heff_drop(v_x_2420);
  heff_clo_take(self, 1);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esettled_24tok1_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_malg_245 = heff_env(self)[0];
  V v_bind_246 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_t_2417 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  heff_clo_take(self, 3);
  V v_t_2419 = heff_tr(heff_call(v_malg_245, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})}));
  V f_ = v_bind_246;
  heff_room[0] = v_t_2419;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esettled_24tok1_lam4, 1, 1, (V[]){v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esettled_24tok1_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_final_241 = heff_env(self)[0];
  V v_before_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_malg_245 = heff_env(self)[3];
  V v_bind_246 = heff_env(self)[4];
  if (((heff_dup(v_final_241) == NTAG(TAG_True)) || ({ V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2411)); int c_ = ({ V v_t_2422 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_before_242)); int c_ = heff_intEq_c_lent(v_t_2421, v_t_2422, 0); heff_drop(v_t_2422); c_; }); heff_drop(v_t_2421); c_; }))) {
    heff_drop(v_x_2411);
    heff_clo_take(self, 5);
    heff_drop(v_final_241);
    heff_drop(v_before_242);
    heff_drop(v_malg_245);
    heff_drop(v_bind_246);
    V f_ = v_k_244;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2411);
    heff_clo_take(self, 5);
    heff_drop(v_final_241);
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esettled_24tok1_lam2, 1, 1, (V[]){v_before_242})})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_dup(v_malg_245), 1, (V[]){v_t_2414}));
    V f_ = heff_dup(v_bind_246);
    heff_room[0] = v_t_2415;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esettled_24tok1_lam3, 1, 3, (V[]){v_malg_245, v_bind_246, v_k_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}