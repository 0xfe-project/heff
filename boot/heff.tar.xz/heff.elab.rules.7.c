// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_BDelayedBy 11524
#define TAG_Become 65038
#define TAG_CBind 55652
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HLocal 25864
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkChk 56962
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SError 24172
#define TAG_SpId 35501
#define TAG_Throw 56084
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Wake 10253
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_elabFor 712452832
#define LBL_globals 352931696
#define LBL_goal 9673690
#define LBL_infos 301706655
#define LBL_insts 301719303
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_val 326043
#define LBL_values 1123329101
#define LBL_wantedBy 1134124532
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_len__names__locals__ctx[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eelab_2ememoed_2econs(V, V);
V g_heff_2eelab_2ememoed_2econs_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2econs_clo;
V g_heff_2eelab_2emeta_2eattempt(V, V, V);
V g_heff_2eelab_2emeta_2eattempt_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eattempt_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(V, V, V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_clo;
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1(V, V, V, V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_clo;
V g_heff_2eelab_2erules_2ebareCandidates(V, V);
V g_heff_2eelab_2erules_2ebareCandidates_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ebareCandidates_clo;
V g_heff_2eelab_2erules_2eboundGo(V, V, V);
V g_heff_2eelab_2erules_2eboundGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eboundGo_clo;
V g_heff_2eelab_2erules_2ecasesAt(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecasesAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecasesAt_clo;
V g_heff_2eelab_2erules_2efixEnv(V, V, V);
V g_heff_2eelab_2erules_2efixEnv_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efixEnv_clo;
V g_heff_2eelab_2erules_2egoalShown(V, V, V);
V g_heff_2eelab_2erules_2egoalShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egoalShown_clo;
V g_heff_2eelab_2erules_2eimplicitDefaultAt(V, V, V);
V g_heff_2eelab_2erules_2eimplicitDefaultAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitDefaultAt_clo;
V g_heff_2eelab_2erules_2eimplicitDefaultChk(V, V);
V g_heff_2eelab_2erules_2eimplicitDefaultChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitDefaultChk_clo;
V g_heff_2eelab_2erules_2eletted(V, V, V, V, V);
V g_heff_2eelab_2erules_2eletted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletted_clo;
V g_heff_2eelab_2erules_2elettedAt(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2elettedAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elettedAt_clo;
V g_heff_2eelab_2erules_2ematchLater(V, V, V, V, V);
V g_heff_2eelab_2erules_2ematchLater_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ematchLater_clo;
V g_heff_2eelab_2erules_2emetaTyShown(V, V, V);
V g_heff_2eelab_2erules_2emetaTyShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emetaTyShown_clo;
V g_heff_2eelab_2erules_2enamesFor(V);
V g_heff_2eelab_2erules_2enamesFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamesFor_clo;
V g_heff_2eelab_2erules_2epathSaid_2edown_241(V, V);
V g_heff_2eelab_2erules_2epathSaid_2edown_241_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2epathSaid_2edown_241_clo;
V g_heff_2eelab_2erules_2eplacesGo(V, V);
V g_heff_2eelab_2erules_2eplacesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesGo_clo;
V g_heff_2eelab_2erules_2eplacesSaid(V);
V g_heff_2eelab_2erules_2eplacesSaid_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesSaid_clo;
V g_heff_2eelab_2erules_2eplacesSaid_24acc(V, V);
V g_heff_2eelab_2erules_2eplacesSaid_24acc_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesSaid_24acc_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2erecovering(V);
V g_heff_2eelab_2erules_2erecovering_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecovering_clo;
HeffT1 g_heff_2eelab_2erules_2erecovering_24cpr(V);
V g_heff_2eelab_2erules_2esameField(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esameField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esameField_clo;
V g_heff_2eelab_2erules_2esettled(V, V, V, V);
V g_heff_2eelab_2erules_2esettled_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esettled_clo;
V g_heff_2eelab_2erules_2esettled_24tok1(V, V, V, V, V);
V g_heff_2eelab_2erules_2esettled_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esettled_24tok1_clo;
V g_heff_2eelab_2erules_2etooDeep(V, V, V, V);
V g_heff_2eelab_2erules_2etooDeep_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etooDeep_clo;
V g_heff_2eelab_2erules_2etooLarge(V, V, V, V, V);
V g_heff_2eelab_2erules_2etooLarge_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etooLarge_clo;
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2etyStrZ(V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_clo;
V g_heff_2eelab_2erules_2etyStrZ_24tok1(V, V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_24tok1_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_list_2eany_24s228396297x1310020012(V);
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a);
extern Clo g_list_2eany_24s228396297x1310020012_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1729297000x968708966(V);
V g_list_2emap_24s1729297000x968708966_entry(V self, V *a);
extern Clo g_list_2emap_24s1729297000x968708966_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
Clo g_heff_2eelab_2erules_2emetaTyShown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2emetaTyShown_entry, 3, 0};

V g_heff_2eelab_2erules_2emetaTyShown(V v_mc_240, V v_len_241, V v_ty_242) {
top: ;
  V v_xs_243 = (g_heff_2eelab_2erules_2enamesFor(heff_dup(v_len_241)));
  V v_t_2423;
  switch (heff_tag_of(v_ty_242)) {
  case TAG_VU: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VDecode: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFunction: {
    V v_folded_2415 = heff_dup(heff_field(v_ty_242, 5));
    v_t_2423 = v_folded_2415;
    break;
  }
  case TAG_VRecord: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VSum: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimString: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFixed: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_ty_242);
  }
  V v_t_2424 = (g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(v_len_241, v_ty_242, v_t_2423));
  V v_t_2425 = (g_heff_2eelab_2eunify_2ezonker(v_mc_240));
  V v_t_2426 = heff_tr(heff_call(heff_get_n(v_t_2425, 1, 2), 1, (V[]){v_t_2424}));
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_243; V a_3 = v_t_2426; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(a_0, a_1, a_2, a_3)); heff_drop(v_t_2426); r_; });
}
V g_heff_2eelab_2erules_2emetaTyShown_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2emetaTyShown(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2erules_2erecovering_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecovering_entry, 1, 0};

V g_heff_2eelab_2erules_2erecovering(V v_c_240) {
top: ;
  HeffT1 v_t_241 = (g_heff_2eelab_2erules_2erecovering_24cpr(v_c_240));
  {
    V v_field_242 = v_t_241.f[0];
    return heff_tag_n(TAG_MkChk, 1, (V[]){v_field_242});
  }
}
V g_heff_2eelab_2erules_2erecovering_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2erecovering(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str0, 30, "the search for an instance of ");
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str1, 14, " goes too deep");
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str2, 5, " for ");
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str4, 7, ", then ");
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str5, 17, " instances deep: ");
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str6, 8, ", and on");
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str7, 16, " goes more than ");
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str8, 2, "32");
HEFF_LIT(g_heff_2eelab_2erules_2etooDeep_str9, 30, "the search for an instance of ");
V g_heff_2eelab_2erules_2etooDeep_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2etooDeep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etooDeep_entry, 4, 0};

V g_heff_2eelab_2erules_2etooDeep(V v_e_240, V v_mc_241, V v_s_242, V v_goal_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_s_242, 1))));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_s_242, 2);
    V v_t_245 = (g_heff_2eelab_2erules_2egoalShown(v_e_240, v_mc_241, v_goal_243));
    return heff_strAppend(((V)&g_heff_2eelab_2erules_2etooDeep_str0), heff_strAppend(v_t_245, ((V)&g_heff_2eelab_2erules_2etooDeep_str1)));
  }
  case TAG_Cons: {
    V v_outermost_246 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Cons = heff_take_reuse_n(v_t_244, 1ULL, 2);
    heff_drop(v_goal_243);
    V v_t_248 = (g_heff_2eelab_2erules_2egoalShown(heff_dup(v_e_240), v_mc_241, heff_get_n(v_outermost_246, 1, 2)));
    V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_s_242, 1, 2)));
    V v_t_2410 = (g_list_2etake(MK_INT(3LL), v_t_249));
    V v_x2_2415 = (g_list_2emap_24tok2(v_ru_24t_244_24Cons, heff_clo_n(g_heff_2eelab_2erules_2etooDeep_lam0, 1, 2, (V[]){v_e_240, heff_dup(v_mc_241)}), v_t_2410));
    V v_t_2418;
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_Nil: {
      v_t_2418 = ((V)&g_heff_2eelab_2erules_2etooDeep_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      V v_xs_2417 = heff_field(v_x2_2415, 1);
      heff_take_n(v_x2_2415, 3ULL, 2);
      v_t_2418 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2etooDeep_str4); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2415);
    }
    V v_t_2419 = heff_strAppend(((V)&g_heff_2eelab_2erules_2etooDeep_str5), heff_strAppend(v_t_2418, ((V)&g_heff_2eelab_2erules_2etooDeep_str6)));
    V v_t_2420 = heff_strAppend(((V)&g_heff_2eelab_2erules_2etooDeep_str7), heff_strAppend(((V)&g_heff_2eelab_2erules_2etooDeep_str8), v_t_2419));
    return heff_strAppend(((V)&g_heff_2eelab_2erules_2etooDeep_str9), heff_strAppend(v_t_248, v_t_2420));
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eelab_2erules_2etooDeep_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2etooDeep(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2etooDeep_lam0(V self, V *args) {
  V v_w_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_mc_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_name_2412 = heff_take_field(v_w_2411, 0);
  V v_goal_2413 = heff_get_n(v_w_2411, 1, 2);
  V v_t_2414 = ({ V a_0 = v_e_240; V a_1 = v_mc_241; V a_2 = v_goal_2413; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_mc_241); r_; });
  return heff_strAppend(v_name_2412, heff_strAppend(((V)&g_heff_2eelab_2erules_2etooDeep_str2), v_t_2414));
}
V g_heff_2eelab_2erules_2esettled_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2esettled_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esettled_lam0, 1, 0};
V g_heff_2eelab_2erules_2esettled_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esettled_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esettled_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esettled_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2esettled_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esettled_entry, 4, 0};

V g_heff_2eelab_2erules_2esettled(V v_final_240, V v_before_241, V v_hd_242, V v_k_243) {
top: ;
  V v_bind_244 = heff_take_field(v_hd_242, 1);
  V v_malg_245 = heff_get_n(v_hd_242, 2, 3);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2esettled_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(v_malg_245), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(v_bind_244), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2erules_2esettled_lam1, 1, 5, (V[]){heff_dup(v_final_240), v_before_241, v_k_243, v_malg_245, v_bind_244})});
}
V g_heff_2eelab_2erules_2esettled_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2esettled(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2esettled_lam0(V self, V *args) {
  V v_c_246 = args[0];
  return heff_get_n(v_c_246, 5, 8);
}
V g_heff_2eelab_2erules_2esettled_lam2(V self, V *args) {
  V v_c_2411 = args[0];
  V v_before_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_infos_2412 = heff_take_field(v_c_2411, 0);
  V v_recovered_2413 = heff_take_field(v_c_2411, 1);
  V v_poisoned_2414 = heff_take_field(v_c_2411, 2);
  V v_metas_2415 = heff_take_field(v_c_2411, 3);
  V v_nextMeta_2416 = heff_take_field(v_c_2411, 4);
  V v_trace_2417 = heff_take_field(v_c_2411, 6);
  V v_selfKey_2418 = heff_get_n(v_c_2411, 7, 8);
  return heff_rec_n(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){v_infos_2412, v_recovered_2413, v_poisoned_2414, v_metas_2415, v_nextMeta_2416, v_before_241, v_trace_2417, v_selfKey_2418});
}
V g_heff_2eelab_2erules_2esettled_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2426);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esettled_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_malg_245 = heff_env(self)[0];
  V v_bind_244 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2423 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2422, NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_call(v_malg_245, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})}));
  V f_ = v_bind_244;
  heff_room[0] = v_t_2425;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esettled_lam4, 1, 1, (V[]){v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esettled_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_final_240 = heff_env(self)[0];
  V v_before_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_malg_245 = heff_env(self)[3];
  V v_bind_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (((heff_dup(v_final_240) == NTAG(TAG_True)) || ({ V v_t_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2410)); int c_ = ({ V v_t_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_before_241)); int c_ = heff_intEq_c_lent(v_t_2427, v_t_2428, 0); heff_drop(v_t_2428); c_; }); heff_drop(v_t_2427); c_; }))) {
    heff_drop(v_x_2410);
    heff_drop(v_final_240);
    heff_drop(v_before_241);
    heff_drop(v_malg_245);
    heff_drop(v_bind_244);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2410);
    heff_drop(v_final_240);
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esettled_lam2, 1, 1, (V[]){v_before_241})})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tr(heff_call(heff_dup(v_malg_245), 1, (V[]){v_t_2420}));
    V f_ = heff_dup(v_bind_244);
    heff_room[0] = v_t_2421;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esettled_lam3, 1, 3, (V[]){v_malg_245, v_bind_244, v_k_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eimplicitDefaultAt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitDefaultAt_lam0, 2, 0};
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eimplicitDefaultAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitDefaultAt_entry, 3, 0};

V g_heff_2eelab_2erules_2eimplicitDefaultAt(V v_e_240, V v_ty_241, V v_x3_242) {
top: ;
  V v_scope_243 = heff_take_field(v_e_240, 0);
  V v_globals_244 = heff_take_field(v_e_240, 1);
  V v_lams_245 = heff_take_field(v_e_240, 3);
  V v_self_246 = heff_take_field(v_e_240, 4);
  V v_insts_247 = heff_get_n(v_e_240, 5, 6);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ty_241, 2);
    heff_drop(v_scope_243);
    heff_drop(v_globals_244);
    heff_drop(v_lams_245);
    heff_drop(v_self_246);
    heff_drop(v_insts_247);
    return ((V)&g_heff_2eelab_2erules_2eimplicitDefaultAt_lam0_clo);
  }
  case TAG_Just: {
    V v_d_2410 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_span_2411 = heff_take_field(v_d_2410, 1);
    V v_chk_2412 = heff_get_n(v_d_2410, 0, 2);
    V v_x1_2413 = heff_tr(heff_call(heff_get_n(v_ty_241, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_a_2417;
    switch (heff_tag_of(v_x1_2413)) {
    case TAG_Nom: {
      V v_x_2414 = heff_field(v_x1_2413, 0);
      heff_take_n(v_x1_2413, 1ULL, 1);
      v_a_2417 = v_x_2414;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2413, 0ULL, 1);
      v_a_2417 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2416 = heff_field(v_x1_2413, 0);
      heff_take_n(v_x1_2413, 1ULL, 1);
      v_a_2417 = v_x_2416;
      break;
    }
    default: heff_nomatch(v_x1_2413);
    }
    V v_t_2418 = ({ V a_0 = v_span_2411; V a_1 = v_chk_2412; V r_ = (g_heff_2eelab_2erules_2eimplicitDefaultChk(a_0, a_1)); heff_drop(v_chk_2412); r_; });
    HeffT1 v_t_2419 = ({ V a_0 = v_t_2418; HeffT1 r_ = (g_heff_2eelab_2erules_2erecovering_24cpr(a_0)); heff_drop(v_t_2418); r_; });
    V v_c_2423;
    {
      V v_field_2420 = v_t_2419.f[0];
      V v_f_2421 = v_field_2420;
      V v_t_2422 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_243, v_globals_244, NTAG(TAG_ForNominative), v_lams_245, v_self_246, v_insts_247});
      v_c_2423 = heff_tr(heff_call(v_f_2421, 2, (V[]){v_t_2422, v_a_2417}));
    }
    return heff_clo_n(g_heff_2eelab_2erules_2eimplicitDefaultAt_lam1, 2, 1, (V[]){v_c_2423});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eimplicitDefaultAt(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2426, 0, 2)});
  V f_ = v_k_2425;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eimplicitDefaultAt_lam1(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eimplicitDefaultAt_lam2, 1, 1, (V[]){v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2ebareCandidates_str0, 6, "\\p -> ");
V g_heff_2eelab_2erules_2ebareCandidates_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2ebareCandidates_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ebareCandidates_lam0, 2, 0};
V g_heff_2eelab_2erules_2ebareCandidates_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ebareCandidates_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ebareCandidates_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ebareCandidates_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ebareCandidates_entry, 2, 0};

V g_heff_2eelab_2erules_2ebareCandidates(V v_cand_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_cand_240);
    return ((V)&g_heff_2eelab_2erules_2ebareCandidates_lam0_clo);
  }
  case TAG_Cons: {
    V v_path_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_call(heff_dup(v_cand_240), 2, (V[]){heff_dup(v_path_244), NTAG(TAG_Nothing)}));
    return heff_clo_n(g_heff_2eelab_2erules_2ebareCandidates_lam1, 2, 4, (V[]){v_c_246, v_cand_240, v_rest_245, v_path_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2ebareCandidates_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ebareCandidates(a[0], a[1]);
}
V g_heff_2eelab_2erules_2ebareCandidates_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ebareCandidates_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = ({ V b_0 = NTAG(TAG_Nothing); V a_1 = v_path_244; V r_ = (g_heff_2eelab_2erules_2epathSaid_2edown_241(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_244); r_; });
  V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2eelab_2erules_2ebareCandidates_str0), v_t_2412), v_x_249});
  V v_x_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_x_2411});
  V f_ = v_k_248;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ebareCandidates_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_cand_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_path_244 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2410 = (g_heff_2eelab_2erules_2ebareCandidates(v_cand_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ebareCandidates_lam3, 1, 3, (V[]){v_path_244, v_x_249, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ebareCandidates_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_cand_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_path_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ebareCandidates_lam2, 1, 5, (V[]){v_cand_240, v_rest_245, v_hd_247, v_path_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2eletted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eletted_entry, 5, 0};

V g_heff_2eelab_2erules_2eletted(V v_e_240, V v_a_241, V v_made_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_e_240, 2));
  V v_t_248;
  switch (heff_tag_of(v_t_245)) {
  case TAG_ForNominative: {
    v_t_248 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_245, 0ULL, 2);
    v_t_248 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_pairs_249 = (g_list_2emap_24s1729297000x968708966(heff_dup(v_made_242)));
  V v_t_2410 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_249)));
  V v_t_2411 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_249));
  V v_t_2412 = (g_list_2emap_24s1173914895x100384474(v_pairs_249));
  V v_t_2413 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2410), v_t_2411, heff_arrayFromList(v_t_2412)});
  V v_record_2414 = ({ V a_0 = v_t_248; V a_1 = v_t_2413; V r_ = (g_heff_2eelab_2ememoed_2econs(a_0, a_1)); heff_drop(v_t_248); r_; });
  V v_bound_2415 = (g_heff_2eelab_2erules_2eboundGo(v_made_242, heff_dup(v_made_242), MK_INT(0LL)));
  V v_t_2416 = (g_list_2eany_24s228396297x1310020012(v_bound_2415));
  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
    heff_drop(v_t_2416);
    V v_t_2417 = (g_heff_2eelab_2erules_2eplacesGo(heff_dup(v_bound_2415), MK_INT(0LL)));
    return ({ V a_0 = v_e_240; V a_1 = v_a_241; V a_2 = v_made_242; V a_3 = v_record_2414; V a_4 = v_bound_2415; V a_5 = v_t_2417; V a_6 = v_z_243; V a_7 = v_z_244; V r_ = (g_heff_2eelab_2erules_2elettedAt(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_bound_2415); r_; });
  } else {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_made_242);
    heff_drop(v_z_243);
    heff_drop(v_bound_2415);
    heff_drop(v_t_2416);
    return heff_tail(v_z_244, 1, (V[]){v_record_2414});
  }
}
V g_heff_2eelab_2erules_2eletted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eletted(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str0, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str1, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str2, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str3, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str4, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str5, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str6, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str7, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str8, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2ematchLater_str9, 34, "cannot match against non-sum type ");
V g_heff_2eelab_2erules_2ematchLater_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam8(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam7(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam6(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam11(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam10(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam9(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam14(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam13(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam12(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam17(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam16(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam15(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam20(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam19(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam18(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam23(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam22(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam21(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam26(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam25(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam24(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam29(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam28(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam27(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam32(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam31(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam30(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ematchLater_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ematchLater_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ematchLater_entry, 5, 0};

V g_heff_2eelab_2erules_2ematchLater(V v_sp_240, V v_scrut_241, V v_a_242, V v_tags_243, V v_casesChk_244) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam0, 4, 5, (V[]){v_a_242, v_sp_240, v_scrut_241, heff_dup(v_tags_243), v_casesChk_244})});
}
V g_heff_2eelab_2erules_2ematchLater_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2ematchLater(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2ematchLater_lam1(V self, V *args) {
  V v_c_249 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_249, 3, 8); V a_1 = v_a_242; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2ematchLater_lam5(V self, V *args) {
  V v_u_2418 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2418);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam4(V self, V *args) {
  V v_u_2417 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2417);
  V v_t_2419 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam5, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2419});
}
V g_heff_2eelab_2erules_2ematchLater_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2416) == NTAG(TAG_True))) {
    heff_drop(v_x_2416);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2420 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam4, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2416);
    heff_drop(v_b2_246);
    V v_t_2421 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_2422 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str0), v_t_2421);
    V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2422, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2425}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_2426;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam8(V self, V *args) {
  V v_u_2433 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2433);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam7(V self, V *args) {
  V v_u_2432 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2432);
  V v_t_2434 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam8, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2434});
}
V g_heff_2eelab_2erules_2ematchLater_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2431) == NTAG(TAG_True))) {
    heff_drop(v_x_2431);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2435 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam7, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2435;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2431);
    heff_drop(v_b2_246);
    V v_t_2436 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_2437 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str1), v_t_2436);
    V v_t_2438 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2437, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2440}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_2441;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam11(V self, V *args) {
  V v_u_2447 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2447);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam10(V self, V *args) {
  V v_u_2446 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2446);
  V v_t_2448 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam11, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2448});
}
V g_heff_2eelab_2erules_2ematchLater_lam9(V self, V *args) {
  V v_x_2445 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2445) == NTAG(TAG_True))) {
    heff_drop(v_x_2445);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2449 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam10, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2449;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2445);
    heff_drop(v_b2_246);
    V v_t_2450 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_2451 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str2), v_t_2450);
    V v_t_2452 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2451, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2454}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_2455;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam14(V self, V *args) {
  V v_u_2459 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2459);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam13(V self, V *args) {
  V v_u_2458 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2458);
  V v_t_2460 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam14, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2460});
}
V g_heff_2eelab_2erules_2ematchLater_lam12(V self, V *args) {
  V v_x_2457 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2457) == NTAG(TAG_True))) {
    heff_drop(v_x_2457);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2461 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam13, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2461;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2457);
    heff_drop(v_b2_246);
    V v_t_2462 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_2463 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str3), v_t_2462);
    V v_t_2464 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2463, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2466}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_2467;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam17(V self, V *args) {
  V v_u_2470 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2470);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam16(V self, V *args) {
  V v_u_2469 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2469);
  V v_t_2471 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam17, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2471});
}
V g_heff_2eelab_2erules_2ematchLater_lam15(V self, V *args) {
  V v_x_2468 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2468) == NTAG(TAG_True))) {
    heff_drop(v_x_2468);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2472 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam16, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2472;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2468);
    heff_drop(v_b2_246);
    V v_t_2473 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_2474 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str4), v_t_2473);
    V v_t_2475 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2474, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
    V v_t_2478 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2477}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_2478;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam20(V self, V *args) {
  V v_u_2481 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2481);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam19(V self, V *args) {
  V v_u_2480 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2480);
  V v_t_2482 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam20, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2482});
}
V g_heff_2eelab_2erules_2ematchLater_lam18(V self, V *args) {
  V v_x_2479 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2479) == NTAG(TAG_True))) {
    heff_drop(v_x_2479);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2483 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam19, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2483;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2479);
    heff_drop(v_b2_246);
    V v_t_2484 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_2485 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str5), v_t_2484);
    V v_t_2486 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2485, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2486})});
    V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
    V v_t_2489 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2488}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_2489;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam23(V self, V *args) {
  V v_u_2492 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2492);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam22(V self, V *args) {
  V v_u_2491 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2491);
  V v_t_2493 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam23, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2493});
}
V g_heff_2eelab_2erules_2ematchLater_lam21(V self, V *args) {
  V v_x_2490 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2490) == NTAG(TAG_True))) {
    heff_drop(v_x_2490);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2494 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam22, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_2494;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2490);
    heff_drop(v_b2_246);
    V v_t_2495 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_2496 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str6), v_t_2495);
    V v_t_2497 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2496, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2498 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2497})});
    V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
    V v_t_24100 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2499}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_24100;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam26(V self, V *args) {
  V v_u_24104 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24104);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam25(V self, V *args) {
  V v_u_24103 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24103);
  V v_t_24105 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam26, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24105});
}
V g_heff_2eelab_2erules_2ematchLater_lam24(V self, V *args) {
  V v_x_24102 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_24102) == NTAG(TAG_True))) {
    heff_drop(v_x_24102);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_24106 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam25, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_24106;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24102);
    heff_drop(v_b2_246);
    V v_t_24107 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_24108 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str7), v_t_24107);
    V v_t_24109 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24108, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24110 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24109})});
    V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
    V v_t_24112 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24111}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_24112;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam29(V self, V *args) {
  V v_u_24116 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24116);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam28(V self, V *args) {
  V v_u_24115 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24115);
  V v_t_24117 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam29, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24117});
}
V g_heff_2eelab_2erules_2ematchLater_lam27(V self, V *args) {
  V v_x_24114 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_24114) == NTAG(TAG_True))) {
    heff_drop(v_x_24114);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_24118 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam28, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_24118;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24114);
    heff_drop(v_b2_246);
    V v_t_24119 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_24120 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str8), v_t_24119);
    V v_t_24121 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24120, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24122 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24121})});
    V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
    V v_t_24124 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24123}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_24124;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam32(V self, V *args) {
  V v_u_24127 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24127);
  return v_b2_246;
}
V g_heff_2eelab_2erules_2ematchLater_lam31(V self, V *args) {
  V v_u_24126 = args[0];
  V v_b2_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24126);
  V v_t_24128 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam32, 1, 1, (V[]){v_b2_246}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24128});
}
V g_heff_2eelab_2erules_2ematchLater_lam30(V self, V *args) {
  V v_x_24125 = args[0];
  V v_b2_246 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_e2_245 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_24125) == NTAG(TAG_True))) {
    heff_drop(v_x_24125);
    heff_drop(v_e2_245);
    heff_drop(v_x_2413);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_247, 3);
    V v_t_24129 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam31, 1, 1, (V[]){v_b2_246})});
    V f_ = v_k_248;
    args[0] = v_t_24129;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24125);
    heff_drop(v_b2_246);
    V v_t_24130 = (g_heff_2eelab_2erules_2etyStr(v_e2_245, v_x_2413));
    V v_msg_24131 = heff_strAppend(((V)&g_heff_2eelab_2erules_2ematchLater_str9), v_t_24130);
    V v_t_24132 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24131, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24133 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24132})});
    V v_t_24134 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24133})});
    V v_t_24135 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24134}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_24135;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_b2_246 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  V v_e2_245 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_scrut_241 = heff_env(self)[5];
  V v_tags_243 = heff_env(self)[6];
  V v_casesChk_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2414 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2413)));
  switch (heff_tag_of(v_t_2414)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2414, 0ULL, 1);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam3, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2414, 0ULL, 4);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam6, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2414, 0ULL, 3);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam9, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeSum: {
    V v_vs_2456 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    return ({ V a_0 = v_sp_240; V a_1 = v_e2_245; V a_2 = v_b2_246; V a_3 = v_scrut_241; V a_4 = v_x_2413; V a_5 = v_vs_2456; V a_6 = v_tags_243; V a_7 = v_casesChk_244; V a_8 = v_hd_247; V a_9 = v_k_248; V r_ = (g_heff_2eelab_2erules_2ecasesAt(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_tags_243); r_; });
  }
  case TAG_LikeInt: {
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam12, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeFloat: {
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam15, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeString: {
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam18, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeRune: {
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam21, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2414, 0ULL, 1);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam24, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2414, 0ULL, 1);
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam27, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  case TAG_NoRules: {
    heff_drop(v_scrut_241);
    heff_drop(v_tags_243);
    heff_drop(v_casesChk_244);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2413), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam30, 1, 6, (V[]){v_b2_246, v_k_248, v_e2_245, v_x_2413, v_sp_240, v_hd_247})));
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2eelab_2erules_2ematchLater_lam0(V self, V *args) {
  V v_e2_245 = args[0];
  V v_b2_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V v_a_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_scrut_241 = heff_env(self)[2];
  V v_tags_243 = heff_env(self)[3];
  V v_casesChk_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam1, 1, 1, (V[]){v_a_242})})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  args[0] = v_t_2412;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ematchLater_lam2, 1, 8, (V[]){v_hd_247, v_b2_246, v_k_248, v_e2_245, v_sp_240, v_scrut_241, v_tags_243, v_casesChk_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efixEnv_lam0(V self, V *args);
V g_heff_2eelab_2erules_2efixEnv_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2efixEnv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efixEnv_entry, 3, 0};

V g_heff_2eelab_2erules_2efixEnv(V v_e_240, V v_x_241, V v_a_242) {
top: ;
  V v_scope_243 = heff_take_field(v_e_240, 0);
  V v_globals_244 = heff_take_field(v_e_240, 1);
  V v_self_245 = heff_take_field(v_e_240, 4);
  V v_insts_246 = heff_get_n(v_e_240, 5, 6);
  V v_t_247 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_scope_243, 0))});
  V v_v_249 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_247, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2efixEnv_lam0, 1, 1, (V[]){heff_dup(v_a_242)}), NTAG(TAG_Nothing)));
  V v_c_2410 = v_scope_243;
  V v_len_2411 = heff_take_field(v_c_2410, 0);
  V v_names_2412 = heff_take_field(v_c_2410, 1);
  V v_locals_2413 = heff_take_field(v_c_2410, 2);
  V v_ctx_2414 = heff_get_n(v_c_2410, 3, 4);
  V v_t_2415 = heff_tag_n(TAG_CBind, 3, (V[]){v_ctx_2414, heff_tag_n(TAG_BDelayedBy, 1, (V[]){MK_INT(1LL)}), v_a_242});
  V v_t_2417 = heff_rec_n(4, shape_len__names__locals__ctx, (V[]){heff_intAdd(v_len_2411, MK_INT(1LL)), heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, v_names_2412}), heff_tag_n(TAG_LSnoc, 2, (V[]){v_locals_2413, heff_clo_n(g_heff_2eelab_2erules_2efixEnv_lam1, 1, 1, (V[]){v_v_249})}), v_t_2415});
  return heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_t_2417, v_globals_244, NTAG(TAG_ForNominative), MK_INT(0LL), v_self_245, v_insts_246});
}
V g_heff_2eelab_2erules_2efixEnv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efixEnv(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2efixEnv_lam0(V self, V *args) {
  V v_u_248 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  return v_a_242;
}
V g_heff_2eelab_2erules_2efixEnv_lam1(V self, V *args) {
  V v_u_2416 = args[0];
  V v_v_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2416);
  return v_v_249;
}
HEFF_LIT(g_heff_2eelab_2erules_2esameField_str0, 36, " in the record updated, but of type ");
HEFF_LIT(g_heff_2eelab_2erules_2esameField_str1, 31, " in the record made: set it too");
HEFF_LIT(g_heff_2eelab_2erules_2esameField_str2, 12, " is of type ");
HEFF_LIT(g_heff_2eelab_2erules_2esameField_str3, 6, "field ");
V g_heff_2eelab_2erules_2esameField_lam0(V self, V *args);
V g_heff_2eelab_2erules_2esameField_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esameField_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esameField_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esameField_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2esameField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esameField_entry, 8, 0};

V g_heff_2eelab_2erules_2esameField(V v_sp_240, V v_e_241, V v_x_242, V v_fty_243, V v_m_244, V v_t_245, V v_hd_246, V v_k_247) {
top: ;
  V v_c_248 = heff_dup(heff_rfield(v_e_241, 0));
  V v_len_249 = heff_take_field(v_c_248, 0);
  V v_names_2410 = heff_get_n(v_c_248, 1, 4);
  return (g_heff_2eelab_2emeta_2eattempt(heff_clo_n(g_heff_2eelab_2erules_2esameField_lam0, 2, 5, (V[]){heff_dup(v_e_241), v_len_249, v_names_2410, heff_dup(v_fty_243), heff_dup(v_t_245)}), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2esameField_lam1, 1, 8, (V[]){v_e_241, v_fty_243, v_hd_246, v_t_245, v_x_242, v_sp_240, v_k_247, v_m_244})));
}
V g_heff_2eelab_2erules_2esameField_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esameField(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2esameField_lam0(V self, V *args) {
  V v_p_2411 = args[0];
  V v_p_2412 = args[1];
  V v_e_241 = heff_env(self)[0];
  V v_len_249 = heff_env(self)[1];
  V v_names_2410 = heff_env(self)[2];
  V v_fty_243 = heff_env(self)[3];
  V v_t_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo), 4, (V[]){heff_get_n(v_e_241, 1, 6), heff_rec_n(2, shape_len__names, (V[]){v_len_249, v_names_2410}), v_fty_243, v_t_245}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2413, v_p_2411, v_p_2412));
}
V g_heff_2eelab_2erules_2esameField_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_err_2415 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_note_2418 = ({ V a_0 = heff_get_n(v_e_241, 1, 6); V a_1 = v_err_2415; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2415); r_; });
  V v_t_2419 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esameField_str0), heff_strAppend(v_x_2416, ((V)&g_heff_2eelab_2erules_2esameField_str1)));
  V v_t_2420 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esameField_str2), heff_strAppend(v_x_2417, v_t_2419));
  V v_t_2421 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esameField_str3), heff_strAppend(v_x_242, v_t_2420));
  V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_2421, v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){v_note_2418})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2424}));
  V f_ = heff_get_n(v_hd_246, 1, 3);
  heff_room[0] = v_t_2425;
  heff_room[1] = v_k_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esameField_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_err_2415 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2erules_2etyStrZ(heff_dup(v_e_241), v_t_245, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2esameField_lam3, 1, 7, (V[]){v_e_241, v_err_2415, v_x_2416, v_x_242, v_sp_240, v_hd_246, v_k_247})));
}
V g_heff_2eelab_2erules_2esameField_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2430);
  V f_ = v_k_247;
  args[0] = v_m_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esameField_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_fty_243 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_t_245 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_m_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_err_2415 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Left = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2etyStrZ_24tok1(v_ru_24x_2414_24Left, heff_dup(v_e_241), v_fty_243, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2esameField_lam2, 1, 7, (V[]){v_e_241, v_t_245, v_hd_246, v_err_2415, v_x_242, v_sp_240, v_k_247})));
  }
  case TAG_Right: {
    V v_ru_24x_2414_24Right = heff_take_reuse_n(v_x_2414, 0ULL, 1);
    heff_drop_rec(v_e_241, 6);
    heff_drop(v_fty_243);
    heff_drop(v_t_245);
    heff_drop(v_x_242);
    heff_drop(v_sp_240);
    V v_t_2427 = heff_tag_n(TAG_Wake, 2, (V[]){NTAG(TAG_False), NTAG(TAG_MkUnit)});
    V v_t_2428 = heff_tag_at_n(v_ru_24x_2414_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2428}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2429;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esameField_lam4, 1, 2, (V[]){v_k_247, v_m_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
Clo g_heff_2eelab_2erules_2etooLarge_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etooLarge_entry, 5, 0};

V g_heff_2eelab_2erules_2etooLarge(V v_sp_240, V v_msg_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  V v_bind_245 = heff_take_field(v_p_243, 1);
  V v_malg_246 = heff_get_n(v_p_243, 2, 3);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(309LL), NTAG(TAG_SError), v_msg_241, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_call(v_malg_246, 1, (V[]){v_t_249}));
    return heff_tail(v_bind_245, 2, (V[]){v_t_2410, v_p_244});
  }
  case TAG_Just: {
    V v_note_2411 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(309LL), NTAG(TAG_SError), v_msg_241, v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){v_note_2411})});
    V v_t_2413 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(v_malg_246, 1, (V[]){v_t_2414}));
    return heff_tail(v_bind_245, 2, (V[]){v_t_2415, v_p_244});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2etooLarge_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etooLarge(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2eelab_2erules_2eplacesSaid_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eplacesSaid_str1, 6, ", and ");
HEFF_LIT(g_heff_2eelab_2erules_2eplacesSaid_str2, 2, ", ");
Clo g_heff_2eelab_2erules_2eplacesSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eplacesSaid_entry, 1, 0};

V g_heff_2eelab_2erules_2eplacesSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2erules_2eplacesSaid_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_Cons: {
          V v_y_245 = heff_field(v_x12_242, 0);
          return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2eelab_2erules_2eplacesSaid_str1), heff_dup(v_y_245)));
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_Cons: {
        V v_s_249 = heff_dup(v_x_241);
        V v_s_2410 = heff_strAppend(v_s_249, ((V)&g_heff_2eelab_2erules_2eplacesSaid_str2));
        return (g_heff_2eelab_2erules_2eplacesSaid_24acc(v_x12_242, v_s_2410));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eplacesSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eplacesSaid(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2esettled_24tok1_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2esettled_24tok1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esettled_24tok1_lam0, 1, 0};
V g_heff_2eelab_2erules_2esettled_24tok1_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esettled_24tok1_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esettled_24tok1_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esettled_24tok1_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2esettled_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esettled_24tok1_entry, 5, 0};

V g_heff_2eelab_2erules_2esettled_24tok1(V v_tok_240, V v_final_241, V v_before_242, V v_hd_243, V v_k_244) {
top: ;
  V v_bind_245 = heff_take_field(v_hd_243, 1);
  V v_malg_246 = heff_get_n(v_hd_243, 2, 3);
  V v_t_248 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2esettled_24tok1_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(v_malg_246), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(v_bind_245), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2erules_2esettled_24tok1_lam1, 1, 5, (V[]){heff_dup(v_final_241), v_before_242, v_k_244, v_malg_246, v_bind_245})});
}
V g_heff_2eelab_2erules_2esettled_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2esettled_24tok1(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2esettled_24tok1_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 5, 8);
}
V g_heff_2eelab_2erules_2esettled_24tok1_lam2(V self, V *args) {
  V v_c_2412 = args[0];
  V v_before_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_infos_2413 = heff_take_field(v_c_2412, 0);
  V v_recovered_2414 = heff_take_field(v_c_2412, 1);
  V v_poisoned_2415 = heff_take_field(v_c_2412, 2);
  V v_metas_2416 = heff_take_field(v_c_2412, 3);
  V v_nextMeta_2417 = heff_take_field(v_c_2412, 4);
  V v_trace_2418 = heff_take_field(v_c_2412, 6);
  V v_selfKey_2419 = heff_get_n(v_c_2412, 7, 8);
  return heff_rec_n(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){v_infos_2413, v_recovered_2414, v_poisoned_2415, v_metas_2416, v_nextMeta_2417, v_before_242, v_trace_2418, v_selfKey_2419});
}
V g_heff_2eelab_2erules_2esettled_24tok1_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2427);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esettled_24tok1_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_malg_246 = heff_env(self)[0];
  V v_bind_245 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2424 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2423, NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_call(v_malg_246, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})}));
  V f_ = v_bind_245;
  heff_room[0] = v_t_2426;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esettled_24tok1_lam4, 1, 1, (V[]){v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esettled_24tok1_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_final_241 = heff_env(self)[0];
  V v_before_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_malg_246 = heff_env(self)[3];
  V v_bind_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (((heff_dup(v_final_241) == NTAG(TAG_True)) || ({ V v_t_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2411)); int c_ = ({ V v_t_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_before_242)); int c_ = heff_intEq_c_lent(v_t_2428, v_t_2429, 0); heff_drop(v_t_2429); c_; }); heff_drop(v_t_2428); c_; }))) {
    heff_drop(v_x_2411);
    heff_drop(v_final_241);
    heff_drop(v_before_242);
    heff_drop(v_malg_246);
    heff_drop(v_bind_245);
    V f_ = v_k_244;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2411);
    heff_drop(v_final_241);
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esettled_24tok1_lam2, 1, 1, (V[]){v_before_242})})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tr(heff_call(heff_dup(v_malg_246), 1, (V[]){v_t_2421}));
    V f_ = heff_dup(v_bind_245);
    heff_room[0] = v_t_2422;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esettled_24tok1_lam3, 1, 3, (V[]){v_malg_246, v_bind_245, v_k_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}