// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_WriteErr 37283
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo;
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162(V, V, V);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_clo;
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_get(void);
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0(V, V, V, V);
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_clo;
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091(V, V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_clo;
V g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328(V, V, V);
V g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_clo;
HeffT2 g_heff_2ebuild_2efetch_2especOf_24cpr(V);
V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2eproject_2epseudoParts(V);
V g_heff_2ebuild_2eproject_2epseudoParts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epseudoParts_clo;
V g_heff_2ebuild_2eproject_2erequireMsg_get(void);
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str0, 56, "heff get: no package.hf here: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str1, 35, "heff get: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str2, 35, "heff get: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str3, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str5, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str6, 4, "HEAD");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str7, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str8, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str9, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str10, 1, "\012");
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam0(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam1(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam3(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam7(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam6(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam8(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam10(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam11(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam9(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam5(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam4(V self, V *args);
Clo g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_entry, 4, 0};

V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0(V v_hd_240, V v_k_241, V v_spec_242, V v_x_243) {
top: ;
  switch (heff_tag_of(v_x_243)) {
  case TAG_Left: {
    V v_ru_24x_243_24Left = heff_take_reuse_n(v_x_243, 0ULL, 1);
    heff_drop(v_spec_242);
    V v_t_245 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str0), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag_at_n(v_ru_24x_243_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Right: {
    V v_y_2418 = heff_field(v_x_243, 0);
    V v_ru_24x_243_24Right = heff_take_reuse_n(v_x_243, 1ULL, 1);
    HeffT2 v_t_2419 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(heff_dup(v_y_2418)));
    {
      V v_field_2421 = v_t_2419.f[1];
      int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
      if ((v_tag_2420 == ((int64_t)0ULL))) {
        heff_drop(v_spec_242);
        heff_drop(v_y_2418);
        V v_p_2422 = v_field_2421;
        heff_drop(v_p_2422);
        V v_t_2423 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str1), NTAG(TAG_MkUnit)});
        V v_t_2424 = heff_tag_at_n(v_ru_24x_243_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
        V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
        V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
        V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
        V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
        return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
      } else {
        V v_x_2436 = v_field_2421;
        HeffT2 v_t_2437 = ({ V a_0 = v_x_2436; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_2436); r_; });
        {
          V v_field_2439 = v_t_2437.f[1];
          int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
          if ((v_tag_2438 == ((int64_t)0ULL))) {
            heff_drop(v_spec_242);
            heff_drop(v_y_2418);
            V v_x_2440 = v_field_2439;
            heff_drop(v_x_2440);
            V v_t_2441 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str2), NTAG(TAG_MkUnit)});
            V v_t_2442 = heff_tag_at_n(v_ru_24x_243_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
            V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
            V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
            V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
            V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
            return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2446}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam2, 1, 2, (V[]){v_hd_240, v_k_241})));
          } else {
            V v_pk_2454 = v_field_2439;
            switch (heff_tag_of(v_spec_242)) {
            case TAG_Nothing: {
              heff_drop(v_y_2418);
              heff_drop_cell(v_ru_24x_243_24Right, 1);
              heff_drop(v_pk_2454);
              return heff_tail(heff_dup(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_get()), 2, (V[]){v_hd_240, v_k_241});
            }
            case TAG_Just: {
              V v_s_2455 = heff_field(v_spec_242, 0);
              V v_ru_24spec_242_24Just = heff_take_reuse_n(v_spec_242, 1ULL, 1);
              HeffT2 v_t_2456 = (g_heff_2ebuild_2efetch_2especOf_24cpr(heff_dup(v_s_2455)));
              {
                V v_field_2457 = v_t_2456.f[0];
                V v_field_2458 = v_t_2456.f[1];
                V v_x_2459 = v_field_2457;
                V v_y_2460 = v_field_2458;
                heff_drop(v_y_2460);
                V v_t_2461 = v_x_2459;
                if (heff_strEq_c(v_t_2461, heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
                  heff_drop(v_y_2418);
                  heff_drop(v_pk_2454);
                  heff_drop(v_s_2455);
                  V v_t_2462 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str3), heff_dup(g_heff_2ebuild_2eproject_2erequireMsg_get())), ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str4));
                  V v_t_2463 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2462, NTAG(TAG_MkUnit)});
                  V v_t_2464 = heff_tag_at_n(v_ru_24x_243_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24spec_242_24Just, TAG_InL, 1, (V[]){v_t_2463})});
                  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
                  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
                  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
                  V v_t_2468 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2467})});
                  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2468}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam3, 1, 2, (V[]){v_hd_240, v_k_241})));
                } else {
                  heff_drop_cell(v_ru_24x_243_24Right, 1);
                  heff_drop_cell(v_ru_24spec_242_24Just, 1);
                  return (g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam4, 1, 5, (V[]){v_hd_240, v_s_2455, v_k_241, v_y_2418, v_pk_2454})));
                }
              }
            }
            default: return heff_nomatch(v_spec_242);
            }
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x_243);
  }
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_drop(v_x_2411);
  V v_t_2412 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), v_hd_240, v_k_241));
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_drop(v_x_2429);
  V v_t_2430 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_hd_240, v_k_241));
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam2(V self, V *args) {
  V v_x_2447 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_drop(v_x_2447);
  V v_t_2448 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2453}), v_hd_240, v_k_241));
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam3(V self, V *args) {
  V v_x_2469 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_drop(v_x_2469);
  V v_t_2470 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2474})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2475}), v_hd_240, v_k_241));
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam7(V self, V *args) {
  V v_x_2493 = args[0];
  V v_k_2492 = heff_env(self)[0];
  V v_x_2478 = heff_env(self)[1];
  V v_path_2490 = heff_env(self)[2];
  V v_hd_2491 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2493)) {
  case TAG_Left: {
    V v_why_2494 = heff_field(v_x_2493, 0);
    heff_take_n(v_x_2493, 1ULL, 1);
    heff_clo_take(self, 4);
    heff_drop(v_x_2478);
    heff_drop(v_path_2490);
    heff_drop(v_hd_2491);
    V f_ = v_k_2492;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_why_2494});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_it1_2495 = heff_field(v_x_2493, 0);
    heff_take_n(v_x_2493, 1ULL, 1);
    switch (heff_tag_of(v_it1_2495)) {
    case TAG_Nothing: {
      heff_clo_take(self, 4);
      V v_t_2496 = (g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162(v_x_2478, v_path_2490, ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str6)));
      V f_ = v_t_2496;
      heff_room[0] = v_hd_2491;
      heff_room[1] = v_k_2492;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Just: {
      V v_v_2497 = heff_field(v_it1_2495, 0);
      heff_take_n(v_it1_2495, 1ULL, 1);
      heff_clo_take(self, 4);
      heff_drop(v_x_2478);
      heff_drop(v_path_2490);
      heff_drop(v_hd_2491);
      V f_ = v_k_2492;
      args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_v_2497});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_it1_2495);
    }
  }
  default: return heff_nomatch(v_x_2493);
  }
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam6(V self, V *args) {
  V v_hd_2491 = args[0];
  V v_k_2492 = args[1];
  V v_path_2490 = heff_env(self)[0];
  V v_x_2478 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328(heff_dup(v_path_2490), heff_dup(v_hd_2491), heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam7, 1, 4, (V[]){v_k_2492, v_x_2478, v_path_2490, v_hd_2491})));
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam8(V self, V *args) {
  V v_hd_24111 = args[0];
  V v_k_24112 = args[1];
  V v_rev_2498 = heff_env(self)[0];
  heff_drop(v_hd_24111);
  heff_clo_take(self, 1);
  V f_ = v_k_24112;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_rev_2498});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam10(V self, V *args) {
  V v_x_24126 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_drop(v_x_24126);
  V v_t_24127 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24128 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24127})});
  V v_t_24129 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24128})});
  V v_t_24130 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24129})});
  V v_t_24131 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24130})});
  V v_t_24132 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24131})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24132}), v_hd_240, v_k_241));
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam11(V self, V *args) {
  V v_x_24140 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  if ((heff_dup(v_x_24140) == NTAG(TAG_True))) {
    heff_drop(v_x_24140);
    heff_clo_take(self, 2);
    V f_ = heff_dup(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_get());
    heff_room[0] = v_hd_240;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_24140);
    heff_clo_take(self, 2);
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam9(V self, V *args) {
  V v_x_24117 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_s_2455 = heff_env(self)[2];
  V v_x_2478 = heff_env(self)[3];
  V v_y_2418 = heff_env(self)[4];
  V v_pk_2454 = heff_env(self)[5];
  switch (heff_tag_of(v_x_24117)) {
  case TAG_Left: {
    V v_why_24118 = heff_field(v_x_24117, 0);
    V v_ru_24x_24117_24Left = heff_take_reuse_n(v_x_24117, 1ULL, 1);
    heff_clo_take(self, 6);
    heff_drop(v_s_2455);
    heff_drop(v_x_2478);
    heff_drop(v_y_2418);
    heff_drop(v_pk_2454);
    V v_t_24119 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str9), v_why_24118), ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str10));
    V v_t_24120 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_24119, NTAG(TAG_MkUnit)});
    V v_t_24121 = heff_tag_at_n(v_ru_24x_24117_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24120})});
    V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
    V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
    V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
    V v_t_24125 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24124})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24125}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam10, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Right: {
    V v_ver_24133 = heff_field(v_x_24117, 0);
    heff_take_n(v_x_24117, 1ULL, 1);
    heff_clo_take(self, 6);
    HeffT2 v_t_24134 = (g_heff_2ebuild_2efetch_2especOf_24cpr(v_s_2455));
    {
      V v_field_24135 = v_t_24134.f[0];
      V v_field_24136 = v_t_24134.f[1];
      V v_x_24137 = v_field_24135;
      V v_y_24138 = v_field_24136;
      heff_drop(v_y_24138);
      V v_t_24139 = v_x_24137;
      return (g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091(v_x_2478, v_y_2418, v_pk_2454, v_t_24139, v_ver_24133, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam11, 1, 2, (V[]){v_hd_240, v_k_241})));
    }
  }
  default: return heff_nomatch(v_x_24117);
  }
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam5(V self, V *args) {
  V v_x_2478 = args[0];
  V v_s_2455 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_y_2418 = heff_env(self)[3];
  V v_pk_2454 = heff_env(self)[4];
  HeffT2 v_t_2479 = (g_heff_2ebuild_2efetch_2especOf_24cpr(heff_dup(v_s_2455)));
  {
    V v_field_2480 = v_t_2479.f[0];
    V v_field_2481 = v_t_2479.f[1];
    V v_x_2482 = v_field_2480;
    heff_drop(v_x_2482);
    V v_y_2483 = v_field_2481;
    V v_t_2484 = v_y_2483;
    V v_c_24116;
    switch (heff_tag_of(v_t_2484)) {
    case TAG_Nothing: {
      HeffT2 v_t_2485 = (g_heff_2ebuild_2efetch_2especOf_24cpr(heff_dup(v_s_2455)));
      {
        V v_field_2486 = v_t_2485.f[0];
        V v_field_2487 = v_t_2485.f[1];
        V v_x_2488 = v_field_2486;
        V v_y_2489 = v_field_2487;
        heff_drop(v_y_2489);
        V v_path_2490 = v_x_2488;
        v_c_24116 = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam6, 2, 2, (V[]){v_path_2490, heff_dup(v_x_2478)});
      }
      break;
    }
    case TAG_Just: {
      V v_rev_2498 = heff_field(v_t_2484, 0);
      heff_take_n(v_t_2484, 1ULL, 1);
      HeffT2 v_t_2499 = (g_heff_2ebuild_2efetch_2especOf_24cpr(heff_dup(v_s_2455)));
      {
        V v_field_24100 = v_t_2499.f[0];
        V v_field_24101 = v_t_2499.f[1];
        V v_t_24102 = ({ V a_0 = v_rev_2498; V b_1 = ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str7); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str8), v_rev_2498, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
        V v_t_24103 = ({ V a_0 = v_t_24102; V r_ = (g_heff_2ebuild_2eproject_2epseudoParts(a_0)); heff_drop(v_t_24102); r_; });
        HeffT2 v_t_24104 = ({ V a_0 = v_rev_2498; V a_1 = v_t_24103; HeffT2 r_ = (g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(a_0, a_1)); heff_drop(v_t_24103); r_; });
        {
          V v_field_24105 = v_t_24104.f[0];
          V v_field_24106 = v_t_24104.f[1];
          V v_x_24107 = v_field_24105;
          V v_y_24108 = v_field_24106;
          heff_drop(v_y_24108);
          V v_t_24109 = v_x_24107;
          V v_t_24110 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_24109; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_24109); r_; });
          if (heff_intEq_c(v_t_24110, MK_INT(3LL))) {
            heff_drop(v_field_24100);
            heff_drop(v_field_24101);
            v_c_24116 = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam8, 2, 1, (V[]){v_rev_2498});
          } else {
            V v_x_24113 = v_field_24100;
            V v_y_24114 = v_field_24101;
            heff_drop(v_y_24114);
            V v_t_24115 = v_x_24113;
            v_c_24116 = (g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162(heff_dup(v_x_2478), v_t_24115, v_rev_2498));
          }
        }
      }
      break;
    }
    default: heff_nomatch(v_t_2484);
    }
    heff_clo_take(self, 5);
    V f_ = v_c_24116;
    heff_room[0] = heff_dup(v_hd_240);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam9, 1, 6, (V[]){v_hd_240, v_k_241, v_s_2455, v_x_2478, v_y_2418, v_pk_2454});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam4(V self, V *args) {
  V v_x_2476 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_s_2455 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_y_2418 = heff_env(self)[3];
  V v_pk_2454 = heff_env(self)[4];
  V v_t_2477 = (g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(v_x_2476, ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_str5)));
  heff_clo_take(self, 5);
  V f_ = v_t_2477;
  heff_room[0] = heff_dup(v_hd_240);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_lam5, 1, 5, (V[]){v_s_2455, v_hd_240, v_k_241, v_y_2418, v_pk_2454});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}