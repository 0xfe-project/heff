// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_HMeta 17321
#define TAG_LSnoc 32613
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_entries 787768015
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_value 313331083
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_array_2efoldlFrom(V, V, V, V);
V g_array_2efoldlFrom_entry(V self, V *a);
extern Clo g_array_2efoldlFrom_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevalTypeF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo;
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2edecodeN(V);
V g_heff_2eelab_2evalue_2edecodeN_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeN_clo;
V g_heff_2eelab_2evalue_2eemap_24s196957333x715530534(V);
V g_heff_2eelab_2evalue_2eemap_24s196957333x715530534_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eemap_24s196957333x715530534_clo;
V g_heff_2eelab_2evalue_2elocalsAt(V, V);
V g_heff_2eelab_2evalue_2elocalsAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elocalsAt_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2eproj(V, V);
V g_heff_2eelab_2evalue_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eproj_clo;
V g_heff_2eelab_2evalue_2especialize(V, V, V);
V g_heff_2eelab_2evalue_2especialize_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2especialize_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_heff_2eelab_2eeval_2eevalTermF_lam1(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam0(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam3(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam2(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam5(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam4(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam7(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam6(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam8(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam10(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam9(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam12(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam11(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam14(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam13(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam16(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam15(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam18(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam17(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam20(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam19(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam22(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam21(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam24(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam23(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam26(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam25(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam28(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam27(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam30(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam29(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam32(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam31(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam34(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam33(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam36(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam35(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam38(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam37(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam40(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam39(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam42(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam41(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam44(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam43(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam46(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam45(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam48(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam47(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam49(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam50(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam51(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam52(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam53(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam54(V self, V *args);
Clo g_heff_2eelab_2eeval_2eevalTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTermF_entry, 5, 0};

V g_heff_2eelab_2eeval_2eevalTermF(V v_r_240, V v_g_241, V v_c_242, V v_x4_243, V v_vs_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_SLocal: {
    V v_i_245 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SLocal = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 6);
    heff_drop(v_c_242);
    return heff_tag_at_n(v_ru_24x4_243_24SLocal, TAG_Nom, 1, (V[]){({ V a_0 = v_vs_244; V a_1 = v_i_245; V r_ = heff_tr(g_heff_2eelab_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_vs_244); r_; })});
  }
  case TAG_SGlobal: {
    V v_x_246 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SGlobal = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    V v_t_247 = ({ V a_0 = v_x_246; V b_1 = heff_get_n(v_g_241, 1, 6); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      v_t_249 = heff_abandon();
      break;
    }
    case TAG_Just: {
      V v_e_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_t_249 = v_e_248;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    return heff_tag_at_n(v_ru_24x4_243_24SGlobal, TAG_Nom, 1, (V[]){heff_get_n(v_t_249, 2, 4)});
  }
  case TAG_SCode: {
    V v_a_2410 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_t_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, v_c_242, v_a_2410, v_vs_244}));
    return (g_heff_2eelab_2evalue_2eemap_24s196957333x715530534(v_t_2411));
  }
  case TAG_SApp: {
    V v_x41_2412 = heff_field(v_x4_243, 0);
    V v_t1_2413 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_2412)) {
    case TAG_SLocal: {
      heff_drop(v_c_242);
      V v_f_2421 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam0, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_2422 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_2422)) {
      case TAG_Nom: {
        V v_x_2423 = heff_field(v_x2_2422, 0);
        heff_take_n(v_x2_2422, 1ULL, 1);
        return heff_tail(v_f_2421, 1, (V[]){v_x_2423});
      }
      case TAG_Describe: {
        V v_x_2424 = heff_field(v_x2_2422, 0);
        heff_take_n(v_x2_2422, 1ULL, 1);
        return heff_tail(v_f_2421, 1, (V[]){v_x_2424});
      }
      case TAG_Become: {
        V v_x_2425 = heff_field(v_x2_2422, 0);
        V v_ru_24x2_2422_24Become = heff_take_reuse_n(v_x2_2422, 1ULL, 1);
        V v_x1_2426 = heff_tr(heff_call(v_f_2421, 1, (V[]){v_x_2425}));
        V v_t_2430;
        switch (heff_tag_of(v_x1_2426)) {
        case TAG_Nom: {
          V v_x_2427 = heff_field(v_x1_2426, 0);
          heff_take_n(v_x1_2426, 1ULL, 1);
          v_t_2430 = v_x_2427;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2426, 0ULL, 1);
          v_t_2430 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2429 = heff_field(v_x1_2426, 0);
          heff_take_n(v_x1_2426, 1ULL, 1);
          v_t_2430 = v_x_2429;
          break;
        }
        default: heff_nomatch(v_x1_2426);
        }
        return heff_tag_at_n(v_ru_24x2_2422_24Become, TAG_Become, 1, (V[]){v_t_2430});
      }
      default: return heff_nomatch(v_x2_2422);
      }
    }
    case TAG_SGlobal: {
      heff_drop(v_c_242);
      V v_f_2438 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam2, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_2439 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_2439)) {
      case TAG_Nom: {
        V v_x_2440 = heff_field(v_x2_2439, 0);
        heff_take_n(v_x2_2439, 1ULL, 1);
        return heff_tail(v_f_2438, 1, (V[]){v_x_2440});
      }
      case TAG_Describe: {
        V v_x_2441 = heff_field(v_x2_2439, 0);
        heff_take_n(v_x2_2439, 1ULL, 1);
        return heff_tail(v_f_2438, 1, (V[]){v_x_2441});
      }
      case TAG_Become: {
        V v_x_2442 = heff_field(v_x2_2439, 0);
        V v_ru_24x2_2439_24Become = heff_take_reuse_n(v_x2_2439, 1ULL, 1);
        V v_x1_2443 = heff_tr(heff_call(v_f_2438, 1, (V[]){v_x_2442}));
        V v_t_2447;
        switch (heff_tag_of(v_x1_2443)) {
        case TAG_Nom: {
          V v_x_2444 = heff_field(v_x1_2443, 0);
          heff_take_n(v_x1_2443, 1ULL, 1);
          v_t_2447 = v_x_2444;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2443, 0ULL, 1);
          v_t_2447 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2446 = heff_field(v_x1_2443, 0);
          heff_take_n(v_x1_2443, 1ULL, 1);
          v_t_2447 = v_x_2446;
          break;
        }
        default: heff_nomatch(v_x1_2443);
        }
        return heff_tag_at_n(v_ru_24x2_2439_24Become, TAG_Become, 1, (V[]){v_t_2447});
      }
      default: return heff_nomatch(v_x2_2439);
      }
    }
    case TAG_SCode: {
      heff_drop(v_c_242);
      V v_f_2455 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam4, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_2456 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_2456)) {
      case TAG_Nom: {
        V v_x_2457 = heff_field(v_x2_2456, 0);
        heff_take_n(v_x2_2456, 1ULL, 1);
        return heff_tail(v_f_2455, 1, (V[]){v_x_2457});
      }
      case TAG_Describe: {
        V v_x_2458 = heff_field(v_x2_2456, 0);
        heff_take_n(v_x2_2456, 1ULL, 1);
        return heff_tail(v_f_2455, 1, (V[]){v_x_2458});
      }
      case TAG_Become: {
        V v_x_2459 = heff_field(v_x2_2456, 0);
        V v_ru_24x2_2456_24Become = heff_take_reuse_n(v_x2_2456, 1ULL, 1);
        V v_x1_2460 = heff_tr(heff_call(v_f_2455, 1, (V[]){v_x_2459}));
        V v_t_2464;
        switch (heff_tag_of(v_x1_2460)) {
        case TAG_Nom: {
          V v_x_2461 = heff_field(v_x1_2460, 0);
          heff_take_n(v_x1_2460, 1ULL, 1);
          v_t_2464 = v_x_2461;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2460, 0ULL, 1);
          v_t_2464 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2463 = heff_field(v_x1_2460, 0);
          heff_take_n(v_x1_2460, 1ULL, 1);
          v_t_2464 = v_x_2463;
          break;
        }
        default: heff_nomatch(v_x1_2460);
        }
        return heff_tag_at_n(v_ru_24x2_2456_24Become, TAG_Become, 1, (V[]){v_t_2464});
      }
      default: return heff_nomatch(v_x2_2456);
      }
    }
    case TAG_SApp: {
      heff_drop(v_c_242);
      V v_f_2473 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam6, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_2474 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_2474)) {
      case TAG_Nom: {
        V v_x_2475 = heff_field(v_x2_2474, 0);
        heff_take_n(v_x2_2474, 1ULL, 1);
        return heff_tail(v_f_2473, 1, (V[]){v_x_2475});
      }
      case TAG_Describe: {
        V v_x_2476 = heff_field(v_x2_2474, 0);
        heff_take_n(v_x2_2474, 1ULL, 1);
        return heff_tail(v_f_2473, 1, (V[]){v_x_2476});
      }
      case TAG_Become: {
        V v_x_2477 = heff_field(v_x2_2474, 0);
        V v_ru_24x2_2474_24Become = heff_take_reuse_n(v_x2_2474, 1ULL, 1);
        V v_x1_2478 = heff_tr(heff_call(v_f_2473, 1, (V[]){v_x_2477}));
        V v_t_2482;
        switch (heff_tag_of(v_x1_2478)) {
        case TAG_Nom: {
          V v_x_2479 = heff_field(v_x1_2478, 0);
          heff_take_n(v_x1_2478, 1ULL, 1);
          v_t_2482 = v_x_2479;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2478, 0ULL, 1);
          v_t_2482 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2481 = heff_field(v_x1_2478, 0);
          heff_take_n(v_x1_2478, 1ULL, 1);
          v_t_2482 = v_x_2481;
          break;
        }
        default: heff_nomatch(v_x1_2478);
        }
        return heff_tag_at_n(v_ru_24x2_2474_24Become, TAG_Become, 1, (V[]){v_t_2482});
      }
      default: return heff_nomatch(v_x2_2474);
      }
    }
    case TAG_SLam: {
      V v_x412_2484 = heff_dup(heff_field(v_x41_2412, 1));
      switch (heff_tag_of(v_x412_2484)) {
      case TAG_MkAbs: {
        V v_t_2486 = heff_field(v_x412_2484, 1);
        heff_take_n(v_x412_2484, 2ULL, 2);
        heff_drop_tag(v_x41_2412, 2);
        return heff_tail(heff_dup(heff_rfield(v_r_240, 0)), 4, (V[]){heff_dup(v_g_241), v_c_242, v_t_2486, heff_tag_n(TAG_LSnoc, 2, (V[]){heff_dup(v_vs_244), heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam8, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})})});
      }
      case TAG_AbsConst: {
        V v_ru_24x412_2484_24AbsConst = heff_take_reuse_n(v_x412_2484, 0ULL, 1);
        heff_drop(v_c_242);
        V v_f_2499 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam9, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
        V v_x2_24100 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
        switch (heff_tag_of(v_x2_24100)) {
        case TAG_Nom: {
          V v_x_24101 = heff_field(v_x2_24100, 0);
          heff_take_n(v_x2_24100, 1ULL, 1);
          heff_drop_cell(v_ru_24x412_2484_24AbsConst, 1);
          return heff_tail(v_f_2499, 1, (V[]){v_x_24101});
        }
        case TAG_Describe: {
          V v_x_24102 = heff_field(v_x2_24100, 0);
          heff_take_n(v_x2_24100, 1ULL, 1);
          heff_drop_cell(v_ru_24x412_2484_24AbsConst, 1);
          return heff_tail(v_f_2499, 1, (V[]){v_x_24102});
        }
        case TAG_Become: {
          V v_x_24103 = heff_field(v_x2_24100, 0);
          heff_take_n(v_x2_24100, 1ULL, 1);
          V v_x1_24104 = heff_tr(heff_call(v_f_2499, 1, (V[]){v_x_24103}));
          V v_t_24108;
          switch (heff_tag_of(v_x1_24104)) {
          case TAG_Nom: {
            V v_x_24105 = heff_field(v_x1_24104, 0);
            heff_take_n(v_x1_24104, 1ULL, 1);
            v_t_24108 = v_x_24105;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_24104, 0ULL, 1);
            v_t_24108 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_24107 = heff_field(v_x1_24104, 0);
            heff_take_n(v_x1_24104, 1ULL, 1);
            v_t_24108 = v_x_24107;
            break;
          }
          default: heff_nomatch(v_x1_24104);
          }
          return heff_tag_at_n(v_ru_24x412_2484_24AbsConst, TAG_Become, 1, (V[]){v_t_24108});
        }
        default: return heff_nomatch(v_x2_24100);
        }
      }
      default: return heff_nomatch(v_x412_2484);
      }
    }
    case TAG_SCons: {
      heff_drop(v_c_242);
      V v_f_24116 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam11, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_24117 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_24117)) {
      case TAG_Nom: {
        V v_x_24118 = heff_field(v_x2_24117, 0);
        heff_take_n(v_x2_24117, 1ULL, 1);
        return heff_tail(v_f_24116, 1, (V[]){v_x_24118});
      }
      case TAG_Describe: {
        V v_x_24119 = heff_field(v_x2_24117, 0);
        heff_take_n(v_x2_24117, 1ULL, 1);
        return heff_tail(v_f_24116, 1, (V[]){v_x_24119});
      }
      case TAG_Become: {
        V v_x_24120 = heff_field(v_x2_24117, 0);
        V v_ru_24x2_24117_24Become = heff_take_reuse_n(v_x2_24117, 1ULL, 1);
        V v_x1_24121 = heff_tr(heff_call(v_f_24116, 1, (V[]){v_x_24120}));
        V v_t_24125;
        switch (heff_tag_of(v_x1_24121)) {
        case TAG_Nom: {
          V v_x_24122 = heff_field(v_x1_24121, 0);
          heff_take_n(v_x1_24121, 1ULL, 1);
          v_t_24125 = v_x_24122;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24121, 0ULL, 1);
          v_t_24125 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24124 = heff_field(v_x1_24121, 0);
          heff_take_n(v_x1_24121, 1ULL, 1);
          v_t_24125 = v_x_24124;
          break;
        }
        default: heff_nomatch(v_x1_24121);
        }
        return heff_tag_at_n(v_ru_24x2_24117_24Become, TAG_Become, 1, (V[]){v_t_24125});
      }
      default: return heff_nomatch(v_x2_24117);
      }
    }
    case TAG_SProj: {
      heff_drop(v_c_242);
      V v_f_24134 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam13, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_24135 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_24135)) {
      case TAG_Nom: {
        V v_x_24136 = heff_field(v_x2_24135, 0);
        heff_take_n(v_x2_24135, 1ULL, 1);
        return heff_tail(v_f_24134, 1, (V[]){v_x_24136});
      }
      case TAG_Describe: {
        V v_x_24137 = heff_field(v_x2_24135, 0);
        heff_take_n(v_x2_24135, 1ULL, 1);
        return heff_tail(v_f_24134, 1, (V[]){v_x_24137});
      }
      case TAG_Become: {
        V v_x_24138 = heff_field(v_x2_24135, 0);
        V v_ru_24x2_24135_24Become = heff_take_reuse_n(v_x2_24135, 1ULL, 1);
        V v_x1_24139 = heff_tr(heff_call(v_f_24134, 1, (V[]){v_x_24138}));
        V v_t_24143;
        switch (heff_tag_of(v_x1_24139)) {
        case TAG_Nom: {
          V v_x_24140 = heff_field(v_x1_24139, 0);
          heff_take_n(v_x1_24139, 1ULL, 1);
          v_t_24143 = v_x_24140;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24139, 0ULL, 1);
          v_t_24143 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24142 = heff_field(v_x1_24139, 0);
          heff_take_n(v_x1_24139, 1ULL, 1);
          v_t_24143 = v_x_24142;
          break;
        }
        default: heff_nomatch(v_x1_24139);
        }
        return heff_tag_at_n(v_ru_24x2_24135_24Become, TAG_Become, 1, (V[]){v_t_24143});
      }
      default: return heff_nomatch(v_x2_24135);
      }
    }
    case TAG_STag: {
      heff_drop(v_c_242);
      V v_f_24152 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam15, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_24153 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_24153)) {
      case TAG_Nom: {
        V v_x_24154 = heff_field(v_x2_24153, 0);
        heff_take_n(v_x2_24153, 1ULL, 1);
        return heff_tail(v_f_24152, 1, (V[]){v_x_24154});
      }
      case TAG_Describe: {
        V v_x_24155 = heff_field(v_x2_24153, 0);
        heff_take_n(v_x2_24153, 1ULL, 1);
        return heff_tail(v_f_24152, 1, (V[]){v_x_24155});
      }
      case TAG_Become: {
        V v_x_24156 = heff_field(v_x2_24153, 0);
        V v_ru_24x2_24153_24Become = heff_take_reuse_n(v_x2_24153, 1ULL, 1);
        V v_x1_24157 = heff_tr(heff_call(v_f_24152, 1, (V[]){v_x_24156}));
        V v_t_24161;
        switch (heff_tag_of(v_x1_24157)) {
        case TAG_Nom: {
          V v_x_24158 = heff_field(v_x1_24157, 0);
          heff_take_n(v_x1_24157, 1ULL, 1);
          v_t_24161 = v_x_24158;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24157, 0ULL, 1);
          v_t_24161 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24160 = heff_field(v_x1_24157, 0);
          heff_take_n(v_x1_24157, 1ULL, 1);
          v_t_24161 = v_x_24160;
          break;
        }
        default: heff_nomatch(v_x1_24157);
        }
        return heff_tag_at_n(v_ru_24x2_24153_24Become, TAG_Become, 1, (V[]){v_t_24161});
      }
      default: return heff_nomatch(v_x2_24153);
      }
    }
    case TAG_SMatch: {
      heff_drop(v_c_242);
      V v_f_24170 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam17, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_24171 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_24171)) {
      case TAG_Nom: {
        V v_x_24172 = heff_field(v_x2_24171, 0);
        heff_take_n(v_x2_24171, 1ULL, 1);
        return heff_tail(v_f_24170, 1, (V[]){v_x_24172});
      }
      case TAG_Describe: {
        V v_x_24173 = heff_field(v_x2_24171, 0);
        heff_take_n(v_x2_24171, 1ULL, 1);
        return heff_tail(v_f_24170, 1, (V[]){v_x_24173});
      }
      case TAG_Become: {
        V v_x_24174 = heff_field(v_x2_24171, 0);
        V v_ru_24x2_24171_24Become = heff_take_reuse_n(v_x2_24171, 1ULL, 1);
        V v_x1_24175 = heff_tr(heff_call(v_f_24170, 1, (V[]){v_x_24174}));
        V v_t_24179;
        switch (heff_tag_of(v_x1_24175)) {
        case TAG_Nom: {
          V v_x_24176 = heff_field(v_x1_24175, 0);
          heff_take_n(v_x1_24175, 1ULL, 1);
          v_t_24179 = v_x_24176;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24175, 0ULL, 1);
          v_t_24179 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24178 = heff_field(v_x1_24175, 0);
          heff_take_n(v_x1_24175, 1ULL, 1);
          v_t_24179 = v_x_24178;
          break;
        }
        default: heff_nomatch(v_x1_24175);
        }
        return heff_tag_at_n(v_ru_24x2_24171_24Become, TAG_Become, 1, (V[]){v_t_24179});
      }
      default: return heff_nomatch(v_x2_24171);
      }
    }
    case TAG_SSpecialize: {
      heff_drop(v_c_242);
      V v_f_24189 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam19, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_24190 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_24190)) {
      case TAG_Nom: {
        V v_x_24191 = heff_field(v_x2_24190, 0);
        heff_take_n(v_x2_24190, 1ULL, 1);
        return heff_tail(v_f_24189, 1, (V[]){v_x_24191});
      }
      case TAG_Describe: {
        V v_x_24192 = heff_field(v_x2_24190, 0);
        heff_take_n(v_x2_24190, 1ULL, 1);
        return heff_tail(v_f_24189, 1, (V[]){v_x_24192});
      }
      case TAG_Become: {
        V v_x_24193 = heff_field(v_x2_24190, 0);
        V v_ru_24x2_24190_24Become = heff_take_reuse_n(v_x2_24190, 1ULL, 1);
        V v_x1_24194 = heff_tr(heff_call(v_f_24189, 1, (V[]){v_x_24193}));
        V v_t_24198;
        switch (heff_tag_of(v_x1_24194)) {
        case TAG_Nom: {
          V v_x_24195 = heff_field(v_x1_24194, 0);
          heff_take_n(v_x1_24194, 1ULL, 1);
          v_t_24198 = v_x_24195;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24194, 0ULL, 1);
          v_t_24198 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24197 = heff_field(v_x1_24194, 0);
          heff_take_n(v_x1_24194, 1ULL, 1);
          v_t_24198 = v_x_24197;
          break;
        }
        default: heff_nomatch(v_x1_24194);
        }
        return heff_tag_at_n(v_ru_24x2_24190_24Become, TAG_Become, 1, (V[]){v_t_24198});
      }
      default: return heff_nomatch(v_x2_24190);
      }
    }
    case TAG_SIs: {
      heff_drop(v_c_242);
      V v_f_24206 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam21, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_24207 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_24207)) {
      case TAG_Nom: {
        V v_x_24208 = heff_field(v_x2_24207, 0);
        heff_take_n(v_x2_24207, 1ULL, 1);
        return heff_tail(v_f_24206, 1, (V[]){v_x_24208});
      }
      case TAG_Describe: {
        V v_x_24209 = heff_field(v_x2_24207, 0);
        heff_take_n(v_x2_24207, 1ULL, 1);
        return heff_tail(v_f_24206, 1, (V[]){v_x_24209});
      }
      case TAG_Become: {
        V v_x_24210 = heff_field(v_x2_24207, 0);
        V v_ru_24x2_24207_24Become = heff_take_reuse_n(v_x2_24207, 1ULL, 1);
        V v_x1_24211 = heff_tr(heff_call(v_f_24206, 1, (V[]){v_x_24210}));
        V v_t_24215;
        switch (heff_tag_of(v_x1_24211)) {
        case TAG_Nom: {
          V v_x_24212 = heff_field(v_x1_24211, 0);
          heff_take_n(v_x1_24211, 1ULL, 1);
          v_t_24215 = v_x_24212;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24211, 0ULL, 1);
          v_t_24215 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24214 = heff_field(v_x1_24211, 0);
          heff_take_n(v_x1_24211, 1ULL, 1);
          v_t_24215 = v_x_24214;
          break;
        }
        default: heff_nomatch(v_x1_24211);
        }
        return heff_tag_at_n(v_ru_24x2_24207_24Become, TAG_Become, 1, (V[]){v_t_24215});
      }
      default: return heff_nomatch(v_x2_24207);
      }
    }
    case TAG_SOpaque: {
      heff_drop(v_c_242);
      V v_f_24222 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam23, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_24223 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_24223)) {
      case TAG_Nom: {
        V v_x_24224 = heff_field(v_x2_24223, 0);
        heff_take_n(v_x2_24223, 1ULL, 1);
        return heff_tail(v_f_24222, 1, (V[]){v_x_24224});
      }
      case TAG_Describe: {
        V v_x_24225 = heff_field(v_x2_24223, 0);
        heff_take_n(v_x2_24223, 1ULL, 1);
        return heff_tail(v_f_24222, 1, (V[]){v_x_24225});
      }
      case TAG_Become: {
        V v_x_24226 = heff_field(v_x2_24223, 0);
        V v_ru_24x2_24223_24Become = heff_take_reuse_n(v_x2_24223, 1ULL, 1);
        V v_x1_24227 = heff_tr(heff_call(v_f_24222, 1, (V[]){v_x_24226}));
        V v_t_24231;
        switch (heff_tag_of(v_x1_24227)) {
        case TAG_Nom: {
          V v_x_24228 = heff_field(v_x1_24227, 0);
          heff_take_n(v_x1_24227, 1ULL, 1);
          v_t_24231 = v_x_24228;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24227, 0ULL, 1);
          v_t_24231 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24230 = heff_field(v_x1_24227, 0);
          heff_take_n(v_x1_24227, 1ULL, 1);
          v_t_24231 = v_x_24230;
          break;
        }
        default: heff_nomatch(v_x1_24227);
        }
        return heff_tag_at_n(v_ru_24x2_24223_24Become, TAG_Become, 1, (V[]){v_t_24231});
      }
      default: return heff_nomatch(v_x2_24223);
      }
    }
    case TAG_SAbandon: {
      heff_drop(v_c_242);
      V v_f_24238 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam25, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_24239 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_24239)) {
      case TAG_Nom: {
        V v_x_24240 = heff_field(v_x2_24239, 0);
        heff_take_n(v_x2_24239, 1ULL, 1);
        return heff_tail(v_f_24238, 1, (V[]){v_x_24240});
      }
      case TAG_Describe: {
        V v_x_24241 = heff_field(v_x2_24239, 0);
        heff_take_n(v_x2_24239, 1ULL, 1);
        return heff_tail(v_f_24238, 1, (V[]){v_x_24241});
      }
      case TAG_Become: {
        V v_x_24242 = heff_field(v_x2_24239, 0);
        V v_ru_24x2_24239_24Become = heff_take_reuse_n(v_x2_24239, 1ULL, 1);
        V v_x1_24243 = heff_tr(heff_call(v_f_24238, 1, (V[]){v_x_24242}));
        V v_t_24247;
        switch (heff_tag_of(v_x1_24243)) {
        case TAG_Nom: {
          V v_x_24244 = heff_field(v_x1_24243, 0);
          heff_take_n(v_x1_24243, 1ULL, 1);
          v_t_24247 = v_x_24244;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24243, 0ULL, 1);
          v_t_24247 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24246 = heff_field(v_x1_24243, 0);
          heff_take_n(v_x1_24243, 1ULL, 1);
          v_t_24247 = v_x_24246;
          break;
        }
        default: heff_nomatch(v_x1_24243);
        }
        return heff_tag_at_n(v_ru_24x2_24239_24Become, TAG_Become, 1, (V[]){v_t_24247});
      }
      default: return heff_nomatch(v_x2_24239);
      }
    }
    case TAG_SRec: {
      heff_drop(v_c_242);
      V v_f_24255 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam27, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_24256 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_24256)) {
      case TAG_Nom: {
        V v_x_24257 = heff_field(v_x2_24256, 0);
        heff_take_n(v_x2_24256, 1ULL, 1);
        return heff_tail(v_f_24255, 1, (V[]){v_x_24257});
      }
      case TAG_Describe: {
        V v_x_24258 = heff_field(v_x2_24256, 0);
        heff_take_n(v_x2_24256, 1ULL, 1);
        return heff_tail(v_f_24255, 1, (V[]){v_x_24258});
      }
      case TAG_Become: {
        V v_x_24259 = heff_field(v_x2_24256, 0);
        V v_ru_24x2_24256_24Become = heff_take_reuse_n(v_x2_24256, 1ULL, 1);
        V v_x1_24260 = heff_tr(heff_call(v_f_24255, 1, (V[]){v_x_24259}));
        V v_t_24264;
        switch (heff_tag_of(v_x1_24260)) {
        case TAG_Nom: {
          V v_x_24261 = heff_field(v_x1_24260, 0);
          heff_take_n(v_x1_24260, 1ULL, 1);
          v_t_24264 = v_x_24261;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24260, 0ULL, 1);
          v_t_24264 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24263 = heff_field(v_x1_24260, 0);
          heff_take_n(v_x1_24260, 1ULL, 1);
          v_t_24264 = v_x_24263;
          break;
        }
        default: heff_nomatch(v_x1_24260);
        }
        return heff_tag_at_n(v_ru_24x2_24256_24Become, TAG_Become, 1, (V[]){v_t_24264});
      }
      default: return heff_nomatch(v_x2_24256);
      }
    }
    case TAG_SFix: {
      heff_drop(v_c_242);
      V v_f_24273 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam29, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_24274 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_24274)) {
      case TAG_Nom: {
        V v_x_24275 = heff_field(v_x2_24274, 0);
        heff_take_n(v_x2_24274, 1ULL, 1);
        return heff_tail(v_f_24273, 1, (V[]){v_x_24275});
      }
      case TAG_Describe: {
        V v_x_24276 = heff_field(v_x2_24274, 0);
        heff_take_n(v_x2_24274, 1ULL, 1);
        return heff_tail(v_f_24273, 1, (V[]){v_x_24276});
      }
      case TAG_Become: {
        V v_x_24277 = heff_field(v_x2_24274, 0);
        V v_ru_24x2_24274_24Become = heff_take_reuse_n(v_x2_24274, 1ULL, 1);
        V v_x1_24278 = heff_tr(heff_call(v_f_24273, 1, (V[]){v_x_24277}));
        V v_t_24282;
        switch (heff_tag_of(v_x1_24278)) {
        case TAG_Nom: {
          V v_x_24279 = heff_field(v_x1_24278, 0);
          heff_take_n(v_x1_24278, 1ULL, 1);
          v_t_24282 = v_x_24279;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24278, 0ULL, 1);
          v_t_24282 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24281 = heff_field(v_x1_24278, 0);
          heff_take_n(v_x1_24278, 1ULL, 1);
          v_t_24282 = v_x_24281;
          break;
        }
        default: heff_nomatch(v_x1_24278);
        }
        return heff_tag_at_n(v_ru_24x2_24274_24Become, TAG_Become, 1, (V[]){v_t_24282});
      }
      default: return heff_nomatch(v_x2_24274);
      }
    }
    case TAG_SImplicit: {
      heff_drop(v_c_242);
      V v_f_24291 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam31, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_24292 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_24292)) {
      case TAG_Nom: {
        V v_x_24293 = heff_field(v_x2_24292, 0);
        heff_take_n(v_x2_24292, 1ULL, 1);
        return heff_tail(v_f_24291, 1, (V[]){v_x_24293});
      }
      case TAG_Describe: {
        V v_x_24294 = heff_field(v_x2_24292, 0);
        heff_take_n(v_x2_24292, 1ULL, 1);
        return heff_tail(v_f_24291, 1, (V[]){v_x_24294});
      }
      case TAG_Become: {
        V v_x_24295 = heff_field(v_x2_24292, 0);
        V v_ru_24x2_24292_24Become = heff_take_reuse_n(v_x2_24292, 1ULL, 1);
        V v_x1_24296 = heff_tr(heff_call(v_f_24291, 1, (V[]){v_x_24295}));
        V v_t_24300;
        switch (heff_tag_of(v_x1_24296)) {
        case TAG_Nom: {
          V v_x_24297 = heff_field(v_x1_24296, 0);
          heff_take_n(v_x1_24296, 1ULL, 1);
          v_t_24300 = v_x_24297;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24296, 0ULL, 1);
          v_t_24300 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24299 = heff_field(v_x1_24296, 0);
          heff_take_n(v_x1_24296, 1ULL, 1);
          v_t_24300 = v_x_24299;
          break;
        }
        default: heff_nomatch(v_x1_24296);
        }
        return heff_tag_at_n(v_ru_24x2_24292_24Become, TAG_Become, 1, (V[]){v_t_24300});
      }
      default: return heff_nomatch(v_x2_24292);
      }
    }
    case TAG_SPrim: {
      heff_drop(v_c_242);
      V v_f_24308 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam33, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_24309 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_24309)) {
      case TAG_Nom: {
        V v_x_24310 = heff_field(v_x2_24309, 0);
        heff_take_n(v_x2_24309, 1ULL, 1);
        return heff_tail(v_f_24308, 1, (V[]){v_x_24310});
      }
      case TAG_Describe: {
        V v_x_24311 = heff_field(v_x2_24309, 0);
        heff_take_n(v_x2_24309, 1ULL, 1);
        return heff_tail(v_f_24308, 1, (V[]){v_x_24311});
      }
      case TAG_Become: {
        V v_x_24312 = heff_field(v_x2_24309, 0);
        V v_ru_24x2_24309_24Become = heff_take_reuse_n(v_x2_24309, 1ULL, 1);
        V v_x1_24313 = heff_tr(heff_call(v_f_24308, 1, (V[]){v_x_24312}));
        V v_t_24317;
        switch (heff_tag_of(v_x1_24313)) {
        case TAG_Nom: {
          V v_x_24314 = heff_field(v_x1_24313, 0);
          heff_take_n(v_x1_24313, 1ULL, 1);
          v_t_24317 = v_x_24314;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24313, 0ULL, 1);
          v_t_24317 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24316 = heff_field(v_x1_24313, 0);
          heff_take_n(v_x1_24313, 1ULL, 1);
          v_t_24317 = v_x_24316;
          break;
        }
        default: heff_nomatch(v_x1_24313);
        }
        return heff_tag_at_n(v_ru_24x2_24309_24Become, TAG_Become, 1, (V[]){v_t_24317});
      }
      default: return heff_nomatch(v_x2_24309);
      }
    }
    case TAG_SMetaApp: {
      heff_drop(v_c_242);
      V v_f_24327 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam35, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_24328 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_24328)) {
      case TAG_Nom: {
        V v_x_24329 = heff_field(v_x2_24328, 0);
        heff_take_n(v_x2_24328, 1ULL, 1);
        return heff_tail(v_f_24327, 1, (V[]){v_x_24329});
      }
      case TAG_Describe: {
        V v_x_24330 = heff_field(v_x2_24328, 0);
        heff_take_n(v_x2_24328, 1ULL, 1);
        return heff_tail(v_f_24327, 1, (V[]){v_x_24330});
      }
      case TAG_Become: {
        V v_x_24331 = heff_field(v_x2_24328, 0);
        V v_ru_24x2_24328_24Become = heff_take_reuse_n(v_x2_24328, 1ULL, 1);
        V v_x1_24332 = heff_tr(heff_call(v_f_24327, 1, (V[]){v_x_24331}));
        V v_t_24336;
        switch (heff_tag_of(v_x1_24332)) {
        case TAG_Nom: {
          V v_x_24333 = heff_field(v_x1_24332, 0);
          heff_take_n(v_x1_24332, 1ULL, 1);
          v_t_24336 = v_x_24333;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24332, 0ULL, 1);
          v_t_24336 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24335 = heff_field(v_x1_24332, 0);
          heff_take_n(v_x1_24332, 1ULL, 1);
          v_t_24336 = v_x_24335;
          break;
        }
        default: heff_nomatch(v_x1_24332);
        }
        return heff_tag_at_n(v_ru_24x2_24328_24Become, TAG_Become, 1, (V[]){v_t_24336});
      }
      default: return heff_nomatch(v_x2_24328);
      }
    }
    case TAG_SLitInt: {
      heff_drop(v_c_242);
      V v_f_24344 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam37, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_24345 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_24345)) {
      case TAG_Nom: {
        V v_x_24346 = heff_field(v_x2_24345, 0);
        heff_take_n(v_x2_24345, 1ULL, 1);
        return heff_tail(v_f_24344, 1, (V[]){v_x_24346});
      }
      case TAG_Describe: {
        V v_x_24347 = heff_field(v_x2_24345, 0);
        heff_take_n(v_x2_24345, 1ULL, 1);
        return heff_tail(v_f_24344, 1, (V[]){v_x_24347});
      }
      case TAG_Become: {
        V v_x_24348 = heff_field(v_x2_24345, 0);
        V v_ru_24x2_24345_24Become = heff_take_reuse_n(v_x2_24345, 1ULL, 1);
        V v_x1_24349 = heff_tr(heff_call(v_f_24344, 1, (V[]){v_x_24348}));
        V v_t_24353;
        switch (heff_tag_of(v_x1_24349)) {
        case TAG_Nom: {
          V v_x_24350 = heff_field(v_x1_24349, 0);
          heff_take_n(v_x1_24349, 1ULL, 1);
          v_t_24353 = v_x_24350;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24349, 0ULL, 1);
          v_t_24353 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24352 = heff_field(v_x1_24349, 0);
          heff_take_n(v_x1_24349, 1ULL, 1);
          v_t_24353 = v_x_24352;
          break;
        }
        default: heff_nomatch(v_x1_24349);
        }
        return heff_tag_at_n(v_ru_24x2_24345_24Become, TAG_Become, 1, (V[]){v_t_24353});
      }
      default: return heff_nomatch(v_x2_24345);
      }
    }
    case TAG_SLitFloat: {
      heff_drop(v_c_242);
      V v_f_24361 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam39, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_24362 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_24362)) {
      case TAG_Nom: {
        V v_x_24363 = heff_field(v_x2_24362, 0);
        heff_take_n(v_x2_24362, 1ULL, 1);
        return heff_tail(v_f_24361, 1, (V[]){v_x_24363});
      }
      case TAG_Describe: {
        V v_x_24364 = heff_field(v_x2_24362, 0);
        heff_take_n(v_x2_24362, 1ULL, 1);
        return heff_tail(v_f_24361, 1, (V[]){v_x_24364});
      }
      case TAG_Become: {
        V v_x_24365 = heff_field(v_x2_24362, 0);
        V v_ru_24x2_24362_24Become = heff_take_reuse_n(v_x2_24362, 1ULL, 1);
        V v_x1_24366 = heff_tr(heff_call(v_f_24361, 1, (V[]){v_x_24365}));
        V v_t_24370;
        switch (heff_tag_of(v_x1_24366)) {
        case TAG_Nom: {
          V v_x_24367 = heff_field(v_x1_24366, 0);
          heff_take_n(v_x1_24366, 1ULL, 1);
          v_t_24370 = v_x_24367;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24366, 0ULL, 1);
          v_t_24370 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24369 = heff_field(v_x1_24366, 0);
          heff_take_n(v_x1_24366, 1ULL, 1);
          v_t_24370 = v_x_24369;
          break;
        }
        default: heff_nomatch(v_x1_24366);
        }
        return heff_tag_at_n(v_ru_24x2_24362_24Become, TAG_Become, 1, (V[]){v_t_24370});
      }
      default: return heff_nomatch(v_x2_24362);
      }
    }
    case TAG_SLitString: {
      heff_drop(v_c_242);
      V v_f_24378 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam41, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_24379 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_24379)) {
      case TAG_Nom: {
        V v_x_24380 = heff_field(v_x2_24379, 0);
        heff_take_n(v_x2_24379, 1ULL, 1);
        return heff_tail(v_f_24378, 1, (V[]){v_x_24380});
      }
      case TAG_Describe: {
        V v_x_24381 = heff_field(v_x2_24379, 0);
        heff_take_n(v_x2_24379, 1ULL, 1);
        return heff_tail(v_f_24378, 1, (V[]){v_x_24381});
      }
      case TAG_Become: {
        V v_x_24382 = heff_field(v_x2_24379, 0);
        V v_ru_24x2_24379_24Become = heff_take_reuse_n(v_x2_24379, 1ULL, 1);
        V v_x1_24383 = heff_tr(heff_call(v_f_24378, 1, (V[]){v_x_24382}));
        V v_t_24387;
        switch (heff_tag_of(v_x1_24383)) {
        case TAG_Nom: {
          V v_x_24384 = heff_field(v_x1_24383, 0);
          heff_take_n(v_x1_24383, 1ULL, 1);
          v_t_24387 = v_x_24384;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24383, 0ULL, 1);
          v_t_24387 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24386 = heff_field(v_x1_24383, 0);
          heff_take_n(v_x1_24383, 1ULL, 1);
          v_t_24387 = v_x_24386;
          break;
        }
        default: heff_nomatch(v_x1_24383);
        }
        return heff_tag_at_n(v_ru_24x2_24379_24Become, TAG_Become, 1, (V[]){v_t_24387});
      }
      default: return heff_nomatch(v_x2_24379);
      }
    }
    case TAG_SLitRune: {
      heff_drop(v_c_242);
      V v_f_24395 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam43, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_24396 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_24396)) {
      case TAG_Nom: {
        V v_x_24397 = heff_field(v_x2_24396, 0);
        heff_take_n(v_x2_24396, 1ULL, 1);
        return heff_tail(v_f_24395, 1, (V[]){v_x_24397});
      }
      case TAG_Describe: {
        V v_x_24398 = heff_field(v_x2_24396, 0);
        heff_take_n(v_x2_24396, 1ULL, 1);
        return heff_tail(v_f_24395, 1, (V[]){v_x_24398});
      }
      case TAG_Become: {
        V v_x_24399 = heff_field(v_x2_24396, 0);
        V v_ru_24x2_24396_24Become = heff_take_reuse_n(v_x2_24396, 1ULL, 1);
        V v_x1_24400 = heff_tr(heff_call(v_f_24395, 1, (V[]){v_x_24399}));
        V v_t_24404;
        switch (heff_tag_of(v_x1_24400)) {
        case TAG_Nom: {
          V v_x_24401 = heff_field(v_x1_24400, 0);
          heff_take_n(v_x1_24400, 1ULL, 1);
          v_t_24404 = v_x_24401;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24400, 0ULL, 1);
          v_t_24404 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24403 = heff_field(v_x1_24400, 0);
          heff_take_n(v_x1_24400, 1ULL, 1);
          v_t_24404 = v_x_24403;
          break;
        }
        default: heff_nomatch(v_x1_24400);
        }
        return heff_tag_at_n(v_ru_24x2_24396_24Become, TAG_Become, 1, (V[]){v_t_24404});
      }
      default: return heff_nomatch(v_x2_24396);
      }
    }
    case TAG_SLitFixed: {
      heff_drop(v_c_242);
      V v_f_24413 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam45, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_24414 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_24414)) {
      case TAG_Nom: {
        V v_x_24415 = heff_field(v_x2_24414, 0);
        heff_take_n(v_x2_24414, 1ULL, 1);
        return heff_tail(v_f_24413, 1, (V[]){v_x_24415});
      }
      case TAG_Describe: {
        V v_x_24416 = heff_field(v_x2_24414, 0);
        heff_take_n(v_x2_24414, 1ULL, 1);
        return heff_tail(v_f_24413, 1, (V[]){v_x_24416});
      }
      case TAG_Become: {
        V v_x_24417 = heff_field(v_x2_24414, 0);
        V v_ru_24x2_24414_24Become = heff_take_reuse_n(v_x2_24414, 1ULL, 1);
        V v_x1_24418 = heff_tr(heff_call(v_f_24413, 1, (V[]){v_x_24417}));
        V v_t_24422;
        switch (heff_tag_of(v_x1_24418)) {
        case TAG_Nom: {
          V v_x_24419 = heff_field(v_x1_24418, 0);
          heff_take_n(v_x1_24418, 1ULL, 1);
          v_t_24422 = v_x_24419;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24418, 0ULL, 1);
          v_t_24422 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24421 = heff_field(v_x1_24418, 0);
          heff_take_n(v_x1_24418, 1ULL, 1);
          v_t_24422 = v_x_24421;
          break;
        }
        default: heff_nomatch(v_x1_24418);
        }
        return heff_tag_at_n(v_ru_24x2_24414_24Become, TAG_Become, 1, (V[]){v_t_24422});
      }
      default: return heff_nomatch(v_x2_24414);
      }
    }
    case TAG_SLitFloat32: {
      heff_drop(v_c_242);
      V v_f_24430 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam47, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2413, heff_dup(v_vs_244)});
      V v_x2_24431 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2412, v_vs_244}));
      switch (heff_tag_of(v_x2_24431)) {
      case TAG_Nom: {
        V v_x_24432 = heff_field(v_x2_24431, 0);
        heff_take_n(v_x2_24431, 1ULL, 1);
        return heff_tail(v_f_24430, 1, (V[]){v_x_24432});
      }
      case TAG_Describe: {
        V v_x_24433 = heff_field(v_x2_24431, 0);
        heff_take_n(v_x2_24431, 1ULL, 1);
        return heff_tail(v_f_24430, 1, (V[]){v_x_24433});
      }
      case TAG_Become: {
        V v_x_24434 = heff_field(v_x2_24431, 0);
        V v_ru_24x2_24431_24Become = heff_take_reuse_n(v_x2_24431, 1ULL, 1);
        V v_x1_24435 = heff_tr(heff_call(v_f_24430, 1, (V[]){v_x_24434}));
        V v_t_24439;
        switch (heff_tag_of(v_x1_24435)) {
        case TAG_Nom: {
          V v_x_24436 = heff_field(v_x1_24435, 0);
          heff_take_n(v_x1_24435, 1ULL, 1);
          v_t_24439 = v_x_24436;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24435, 0ULL, 1);
          v_t_24439 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24438 = heff_field(v_x1_24435, 0);
          heff_take_n(v_x1_24435, 1ULL, 1);
          v_t_24439 = v_x_24438;
          break;
        }
        default: heff_nomatch(v_x1_24435);
        }
        return heff_tag_at_n(v_ru_24x2_24431_24Become, TAG_Become, 1, (V[]){v_t_24439});
      }
      default: return heff_nomatch(v_x2_24431);
      }
    }
    default: return heff_nomatch(v_x41_2412);
    }
  }
  case TAG_SLam: {
    V v_dom_24440 = heff_field(v_x4_243, 0);
    V v_x42_24441 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24SLam = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x42_24441)) {
    case TAG_MkAbs: {
      V v_x_24442 = heff_field(v_x42_24441, 0);
      V v_t_24443 = heff_field(v_x42_24441, 1);
      heff_take_n(v_x42_24441, 3ULL, 2);
      V v_x_24450 = heff_tag_at_n(v_ru_24x4_243_24SLam, TAG_VLam, 2, (V[]){heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam49, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_dom_24440, heff_dup(v_vs_244)}), heff_tag_n(TAG_MkClo, 3, (V[]){v_x_24442, v_vs_244, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam50, 1, 4, (V[]){v_r_240, v_g_241, heff_dup(v_c_242), v_t_24443})})});
      switch (heff_tag_of(v_c_242)) {
      case TAG_N: {
        return heff_tag_n(TAG_Nom, 1, (V[]){v_x_24450});
      }
      case TAG_De: {
        return heff_tag_n(TAG_Describe, 1, (V[]){v_x_24450});
      }
      default: return heff_nomatch(v_c_242);
      }
    }
    case TAG_AbsConst: {
      V v_t_24451 = heff_field(v_x42_24441, 0);
      V v_ru_24x42_24441_24AbsConst = heff_take_reuse_n(v_x42_24441, 1ULL, 1);
      V v_t_24452 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 4, (V[]){heff_dup(v_g_241), heff_dup(v_c_242), v_t_24451, heff_dup(v_vs_244)}));
      V v_x_24458 = heff_tag_at_n(v_ru_24x4_243_24SLam, TAG_VLam, 2, (V[]){heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam51, 1, 4, (V[]){v_r_240, v_g_241, v_dom_24440, v_vs_244}), heff_tag_n(TAG_CloConst, 1, (V[]){v_t_24452})});
      switch (heff_tag_of(v_c_242)) {
      case TAG_N: {
        return heff_tag_at_n(v_ru_24x42_24441_24AbsConst, TAG_Nom, 1, (V[]){v_x_24458});
      }
      case TAG_De: {
        return heff_tag_at_n(v_ru_24x42_24441_24AbsConst, TAG_Describe, 1, (V[]){v_x_24458});
      }
      default: return heff_nomatch(v_c_242);
      }
    }
    default: return heff_nomatch(v_x42_24441);
    }
  }
  case TAG_SCons: {
    V v_fields_24459 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SCons = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_xs_24460 = heff_take_field(v_fields_24459, 2);
    V v_t_24463 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_24460)), heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam52, 1, 5, (V[]){v_xs_24460, v_r_240, v_g_241, heff_dup(v_c_242), v_vs_244}));
    V v_t_24464 = ({ V rv_2 = v_t_24463; V rr_ = heff_rec_reuse_n(v_fields_24459, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_x_24465 = heff_tag_at_n(v_ru_24x4_243_24SCons, TAG_VCons, 1, (V[]){v_t_24464});
    switch (heff_tag_of(v_c_242)) {
    case TAG_N: {
      return heff_tag_n(TAG_Nom, 1, (V[]){v_x_24465});
    }
    case TAG_De: {
      return heff_tag_n(TAG_Describe, 1, (V[]){v_x_24465});
    }
    default: return heff_nomatch(v_c_242);
    }
  }
  case TAG_SProj: {
    V v_t_24466 = heff_field(v_x4_243, 0);
    V v_x_24467 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    heff_drop(v_c_242);
    V v_x2_24468 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_24466, v_vs_244}));
    switch (heff_tag_of(v_x2_24468)) {
    case TAG_Nom: {
      V v_x_24469 = heff_field(v_x2_24468, 0);
      heff_take_n(v_x2_24468, 1ULL, 1);
      return (g_heff_2eelab_2evalue_2eproj(v_x_24469, v_x_24467));
    }
    case TAG_Describe: {
      V v_x_24470 = heff_field(v_x2_24468, 0);
      heff_take_n(v_x2_24468, 1ULL, 1);
      return (g_heff_2eelab_2evalue_2eproj(v_x_24470, v_x_24467));
    }
    case TAG_Become: {
      V v_x_24471 = heff_field(v_x2_24468, 0);
      V v_ru_24x2_24468_24Become = heff_take_reuse_n(v_x2_24468, 1ULL, 1);
      V v_x1_24472 = (g_heff_2eelab_2evalue_2eproj(v_x_24471, v_x_24467));
      V v_t_24476;
      switch (heff_tag_of(v_x1_24472)) {
      case TAG_Nom: {
        V v_x_24473 = heff_field(v_x1_24472, 0);
        heff_take_n(v_x1_24472, 1ULL, 1);
        v_t_24476 = v_x_24473;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_24472, 0ULL, 1);
        v_t_24476 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24475 = heff_field(v_x1_24472, 0);
        heff_take_n(v_x1_24472, 1ULL, 1);
        v_t_24476 = v_x_24475;
        break;
      }
      default: heff_nomatch(v_x1_24472);
      }
      return heff_tag_at_n(v_ru_24x2_24468_24Become, TAG_Become, 1, (V[]){v_t_24476});
    }
    default: return heff_nomatch(v_x2_24468);
    }
  }
  case TAG_STag: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 6);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SMatch: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 6);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SSpecialize: {
    V v_t_24481 = heff_field(v_x4_243, 0);
    V v_x_24482 = heff_field(v_x4_243, 1);
    V v_t_27_24483 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    heff_drop(v_c_242);
    V v_x1_24484 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 4, (V[]){heff_dup(v_g_241), NTAG(TAG_N), v_t_24481, heff_dup(v_vs_244)}));
    V v_t_24488;
    switch (heff_tag_of(v_x1_24484)) {
    case TAG_Nom: {
      V v_x_24485 = heff_field(v_x1_24484, 0);
      heff_take_n(v_x1_24484, 1ULL, 1);
      v_t_24488 = v_x_24485;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24484, 0ULL, 1);
      v_t_24488 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24487 = heff_field(v_x1_24484, 0);
      heff_take_n(v_x1_24484, 1ULL, 1);
      v_t_24488 = v_x_24487;
      break;
    }
    default: heff_nomatch(v_x1_24484);
    }
    V v_x1_24489 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_27_24483, v_vs_244}));
    V v_t_24493;
    switch (heff_tag_of(v_x1_24489)) {
    case TAG_Nom: {
      V v_x_24490 = heff_field(v_x1_24489, 0);
      heff_take_n(v_x1_24489, 1ULL, 1);
      v_t_24493 = v_x_24490;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24489, 0ULL, 1);
      v_t_24493 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24492 = heff_field(v_x1_24489, 0);
      heff_take_n(v_x1_24489, 1ULL, 1);
      v_t_24493 = v_x_24492;
      break;
    }
    default: heff_nomatch(v_x1_24489);
    }
    return heff_tag_n(TAG_Nom, 1, (V[]){(g_heff_2eelab_2evalue_2especialize(v_t_24488, v_x_24482, v_t_24493))});
  }
  case TAG_SIs: {
    V v_t_24494 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SIs = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    V v_x1_24495 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_24494, v_vs_244}));
    V v_t_24499;
    switch (heff_tag_of(v_x1_24495)) {
    case TAG_Nom: {
      V v_x_24496 = heff_field(v_x1_24495, 0);
      heff_take_n(v_x1_24495, 1ULL, 1);
      v_t_24499 = v_x_24496;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24495, 0ULL, 1);
      v_t_24499 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24498 = heff_field(v_x1_24495, 0);
      heff_take_n(v_x1_24495, 1ULL, 1);
      v_t_24499 = v_x_24498;
      break;
    }
    default: heff_nomatch(v_x1_24495);
    }
    return heff_tag_at_n(v_ru_24x4_243_24SIs, TAG_Become, 1, (V[]){v_t_24499});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 6);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 6);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SRec: {
    V v_ru_24x4_243_24SRec = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 6);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SRec, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SFix: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 6);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SImplicit: {
    V v_e_24504 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 2ULL, 2);
    return heff_tail(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, v_c_242, v_e_24504, v_vs_244});
  }
  case TAG_SPrim: {
    V v_ru_24x4_243_24SPrim = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 6);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SPrim, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SMetaApp: {
    V v_m_24506 = heff_field(v_x4_243, 0);
    V v_idxs_24507 = heff_field(v_x4_243, 1);
    V v_ty_24508 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    heff_drop(v_c_242);
    V v_sp_24511 = (g_array_2efoldlFrom(heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam53, 2, 1, (V[]){heff_dup(v_vs_244)}), MK_INT(0LL), NTAG(TAG_SpId), v_idxs_24507));
    V v_x1_24512 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_ty_24508, v_vs_244}));
    V v_ty_24516;
    switch (heff_tag_of(v_x1_24512)) {
    case TAG_Nom: {
      V v_x_24513 = heff_field(v_x1_24512, 0);
      heff_take_n(v_x1_24512, 1ULL, 1);
      v_ty_24516 = v_x_24513;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24512, 0ULL, 1);
      v_ty_24516 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24515 = heff_field(v_x1_24512, 0);
      heff_take_n(v_x1_24512, 1ULL, 1);
      v_ty_24516 = v_x_24515;
      break;
    }
    default: heff_nomatch(v_x1_24512);
    }
    V v_t_24518 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HMeta, 1, (V[]){v_m_24506}), v_sp_24511, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam54, 1, 1, (V[]){v_ty_24516}), NTAG(TAG_Nothing)));
    return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24518});
  }
  case TAG_SLitInt: {
    V v_ru_24x4_243_24SLitInt = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 6);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SLitInt, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFloat: {
    V v_ru_24x4_243_24SLitFloat = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 6);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SLitFloat, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitString: {
    V v_ru_24x4_243_24SLitString = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 6);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SLitString, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitRune: {
    V v_ru_24x4_243_24SLitRune = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 6);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SLitRune, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 6);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFloat32: {
    V v_ru_24x4_243_24SLitFloat32 = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 6);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SLitFloat32, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eeval_2eevalTermF(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eeval_2eevalTermF_lam1(V self, V *args) {
  V v_u_2416 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2416);
  V v_x1_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_Nom: {
    V v_x_2418 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    return v_x_2418;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2420 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    return v_x_2420;
  }
  default: return heff_nomatch(v_x1_2417);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam0(V self, V *args) {
  V v_f_2415 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2415, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam1, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam3(V self, V *args) {
  V v_u_2433 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2433);
  V v_x1_2434 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_Nom: {
    V v_x_2435 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    return v_x_2435;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2434, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2437 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    return v_x_2437;
  }
  default: return heff_nomatch(v_x1_2434);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam2(V self, V *args) {
  V v_f_2432 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2432, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam3, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam5(V self, V *args) {
  V v_u_2450 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2450);
  V v_x1_2451 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_2451)) {
  case TAG_Nom: {
    V v_x_2452 = heff_field(v_x1_2451, 0);
    heff_take_n(v_x1_2451, 1ULL, 1);
    return v_x_2452;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2451, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2454 = heff_field(v_x1_2451, 0);
    heff_take_n(v_x1_2451, 1ULL, 1);
    return v_x_2454;
  }
  default: return heff_nomatch(v_x1_2451);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam4(V self, V *args) {
  V v_f_2449 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2449, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam5, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam7(V self, V *args) {
  V v_u_2468 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2468);
  V v_x1_2469 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_2469)) {
  case TAG_Nom: {
    V v_x_2470 = heff_field(v_x1_2469, 0);
    heff_take_n(v_x1_2469, 1ULL, 1);
    return v_x_2470;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2469, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2472 = heff_field(v_x1_2469, 0);
    heff_take_n(v_x1_2469, 1ULL, 1);
    return v_x_2472;
  }
  default: return heff_nomatch(v_x1_2469);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam6(V self, V *args) {
  V v_f_2467 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2467, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam7, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam8(V self, V *args) {
  V v_u_2487 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2487);
  V v_x1_2488 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_2488)) {
  case TAG_Nom: {
    V v_x_2489 = heff_field(v_x1_2488, 0);
    heff_take_n(v_x1_2488, 1ULL, 1);
    return v_x_2489;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2488, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2491 = heff_field(v_x1_2488, 0);
    heff_take_n(v_x1_2488, 1ULL, 1);
    return v_x_2491;
  }
  default: return heff_nomatch(v_x1_2488);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam10(V self, V *args) {
  V v_u_2494 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2494);
  V v_x1_2495 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_2495)) {
  case TAG_Nom: {
    V v_x_2496 = heff_field(v_x1_2495, 0);
    heff_take_n(v_x1_2495, 1ULL, 1);
    return v_x_2496;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2495, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2498 = heff_field(v_x1_2495, 0);
    heff_take_n(v_x1_2495, 1ULL, 1);
    return v_x_2498;
  }
  default: return heff_nomatch(v_x1_2495);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam9(V self, V *args) {
  V v_f_2493 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2493, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam10, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam12(V self, V *args) {
  V v_u_24111 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24111);
  V v_x1_24112 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_24112)) {
  case TAG_Nom: {
    V v_x_24113 = heff_field(v_x1_24112, 0);
    heff_take_n(v_x1_24112, 1ULL, 1);
    return v_x_24113;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24112, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24115 = heff_field(v_x1_24112, 0);
    heff_take_n(v_x1_24112, 1ULL, 1);
    return v_x_24115;
  }
  default: return heff_nomatch(v_x1_24112);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam11(V self, V *args) {
  V v_f_24110 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24110, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam12, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam14(V self, V *args) {
  V v_u_24129 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24129);
  V v_x1_24130 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_24130)) {
  case TAG_Nom: {
    V v_x_24131 = heff_field(v_x1_24130, 0);
    heff_take_n(v_x1_24130, 1ULL, 1);
    return v_x_24131;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24130, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24133 = heff_field(v_x1_24130, 0);
    heff_take_n(v_x1_24130, 1ULL, 1);
    return v_x_24133;
  }
  default: return heff_nomatch(v_x1_24130);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam13(V self, V *args) {
  V v_f_24128 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24128, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam14, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam16(V self, V *args) {
  V v_u_24147 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24147);
  V v_x1_24148 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_24148)) {
  case TAG_Nom: {
    V v_x_24149 = heff_field(v_x1_24148, 0);
    heff_take_n(v_x1_24148, 1ULL, 1);
    return v_x_24149;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24148, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24151 = heff_field(v_x1_24148, 0);
    heff_take_n(v_x1_24148, 1ULL, 1);
    return v_x_24151;
  }
  default: return heff_nomatch(v_x1_24148);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam15(V self, V *args) {
  V v_f_24146 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24146, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam16, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam18(V self, V *args) {
  V v_u_24165 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24165);
  V v_x1_24166 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_24166)) {
  case TAG_Nom: {
    V v_x_24167 = heff_field(v_x1_24166, 0);
    heff_take_n(v_x1_24166, 1ULL, 1);
    return v_x_24167;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24166, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24169 = heff_field(v_x1_24166, 0);
    heff_take_n(v_x1_24166, 1ULL, 1);
    return v_x_24169;
  }
  default: return heff_nomatch(v_x1_24166);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam17(V self, V *args) {
  V v_f_24164 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24164, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam18, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam20(V self, V *args) {
  V v_u_24184 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24184);
  V v_x1_24185 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_24185)) {
  case TAG_Nom: {
    V v_x_24186 = heff_field(v_x1_24185, 0);
    heff_take_n(v_x1_24185, 1ULL, 1);
    return v_x_24186;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24185, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24188 = heff_field(v_x1_24185, 0);
    heff_take_n(v_x1_24185, 1ULL, 1);
    return v_x_24188;
  }
  default: return heff_nomatch(v_x1_24185);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam19(V self, V *args) {
  V v_f_24183 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24183, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam20, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam22(V self, V *args) {
  V v_u_24201 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24201);
  V v_x1_24202 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_24202)) {
  case TAG_Nom: {
    V v_x_24203 = heff_field(v_x1_24202, 0);
    heff_take_n(v_x1_24202, 1ULL, 1);
    return v_x_24203;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24202, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24205 = heff_field(v_x1_24202, 0);
    heff_take_n(v_x1_24202, 1ULL, 1);
    return v_x_24205;
  }
  default: return heff_nomatch(v_x1_24202);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam21(V self, V *args) {
  V v_f_24200 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24200, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam22, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam24(V self, V *args) {
  V v_u_24217 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24217);
  V v_x1_24218 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_24218)) {
  case TAG_Nom: {
    V v_x_24219 = heff_field(v_x1_24218, 0);
    heff_take_n(v_x1_24218, 1ULL, 1);
    return v_x_24219;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24218, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24221 = heff_field(v_x1_24218, 0);
    heff_take_n(v_x1_24218, 1ULL, 1);
    return v_x_24221;
  }
  default: return heff_nomatch(v_x1_24218);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam23(V self, V *args) {
  V v_f_24216 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24216, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam24, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam26(V self, V *args) {
  V v_u_24233 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24233);
  V v_x1_24234 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_24234)) {
  case TAG_Nom: {
    V v_x_24235 = heff_field(v_x1_24234, 0);
    heff_take_n(v_x1_24234, 1ULL, 1);
    return v_x_24235;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24234, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24237 = heff_field(v_x1_24234, 0);
    heff_take_n(v_x1_24234, 1ULL, 1);
    return v_x_24237;
  }
  default: return heff_nomatch(v_x1_24234);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam25(V self, V *args) {
  V v_f_24232 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24232, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam26, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam28(V self, V *args) {
  V v_u_24250 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24250);
  V v_x1_24251 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_24251)) {
  case TAG_Nom: {
    V v_x_24252 = heff_field(v_x1_24251, 0);
    heff_take_n(v_x1_24251, 1ULL, 1);
    return v_x_24252;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24251, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24254 = heff_field(v_x1_24251, 0);
    heff_take_n(v_x1_24251, 1ULL, 1);
    return v_x_24254;
  }
  default: return heff_nomatch(v_x1_24251);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam27(V self, V *args) {
  V v_f_24249 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24249, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam28, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam30(V self, V *args) {
  V v_u_24268 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24268);
  V v_x1_24269 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_24269)) {
  case TAG_Nom: {
    V v_x_24270 = heff_field(v_x1_24269, 0);
    heff_take_n(v_x1_24269, 1ULL, 1);
    return v_x_24270;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24269, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24272 = heff_field(v_x1_24269, 0);
    heff_take_n(v_x1_24269, 1ULL, 1);
    return v_x_24272;
  }
  default: return heff_nomatch(v_x1_24269);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam29(V self, V *args) {
  V v_f_24267 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24267, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam30, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam32(V self, V *args) {
  V v_u_24286 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24286);
  V v_x1_24287 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_24287)) {
  case TAG_Nom: {
    V v_x_24288 = heff_field(v_x1_24287, 0);
    heff_take_n(v_x1_24287, 1ULL, 1);
    return v_x_24288;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24287, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24290 = heff_field(v_x1_24287, 0);
    heff_take_n(v_x1_24287, 1ULL, 1);
    return v_x_24290;
  }
  default: return heff_nomatch(v_x1_24287);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam31(V self, V *args) {
  V v_f_24285 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24285, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam32, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam34(V self, V *args) {
  V v_u_24303 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24303);
  V v_x1_24304 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_24304)) {
  case TAG_Nom: {
    V v_x_24305 = heff_field(v_x1_24304, 0);
    heff_take_n(v_x1_24304, 1ULL, 1);
    return v_x_24305;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24304, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24307 = heff_field(v_x1_24304, 0);
    heff_take_n(v_x1_24304, 1ULL, 1);
    return v_x_24307;
  }
  default: return heff_nomatch(v_x1_24304);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam33(V self, V *args) {
  V v_f_24302 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24302, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam34, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam36(V self, V *args) {
  V v_u_24322 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24322);
  V v_x1_24323 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_24323)) {
  case TAG_Nom: {
    V v_x_24324 = heff_field(v_x1_24323, 0);
    heff_take_n(v_x1_24323, 1ULL, 1);
    return v_x_24324;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24323, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24326 = heff_field(v_x1_24323, 0);
    heff_take_n(v_x1_24323, 1ULL, 1);
    return v_x_24326;
  }
  default: return heff_nomatch(v_x1_24323);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam35(V self, V *args) {
  V v_f_24321 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24321, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam36, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam38(V self, V *args) {
  V v_u_24339 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24339);
  V v_x1_24340 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_24340)) {
  case TAG_Nom: {
    V v_x_24341 = heff_field(v_x1_24340, 0);
    heff_take_n(v_x1_24340, 1ULL, 1);
    return v_x_24341;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24340, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24343 = heff_field(v_x1_24340, 0);
    heff_take_n(v_x1_24340, 1ULL, 1);
    return v_x_24343;
  }
  default: return heff_nomatch(v_x1_24340);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam37(V self, V *args) {
  V v_f_24338 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24338, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam38, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam40(V self, V *args) {
  V v_u_24356 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24356);
  V v_x1_24357 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_24357)) {
  case TAG_Nom: {
    V v_x_24358 = heff_field(v_x1_24357, 0);
    heff_take_n(v_x1_24357, 1ULL, 1);
    return v_x_24358;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24357, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24360 = heff_field(v_x1_24357, 0);
    heff_take_n(v_x1_24357, 1ULL, 1);
    return v_x_24360;
  }
  default: return heff_nomatch(v_x1_24357);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam39(V self, V *args) {
  V v_f_24355 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24355, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam40, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam42(V self, V *args) {
  V v_u_24373 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24373);
  V v_x1_24374 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_24374)) {
  case TAG_Nom: {
    V v_x_24375 = heff_field(v_x1_24374, 0);
    heff_take_n(v_x1_24374, 1ULL, 1);
    return v_x_24375;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24374, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24377 = heff_field(v_x1_24374, 0);
    heff_take_n(v_x1_24374, 1ULL, 1);
    return v_x_24377;
  }
  default: return heff_nomatch(v_x1_24374);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam41(V self, V *args) {
  V v_f_24372 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24372, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam42, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam44(V self, V *args) {
  V v_u_24390 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24390);
  V v_x1_24391 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_24391)) {
  case TAG_Nom: {
    V v_x_24392 = heff_field(v_x1_24391, 0);
    heff_take_n(v_x1_24391, 1ULL, 1);
    return v_x_24392;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24391, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24394 = heff_field(v_x1_24391, 0);
    heff_take_n(v_x1_24391, 1ULL, 1);
    return v_x_24394;
  }
  default: return heff_nomatch(v_x1_24391);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam43(V self, V *args) {
  V v_f_24389 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24389, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam44, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam46(V self, V *args) {
  V v_u_24408 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24408);
  V v_x1_24409 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_24409)) {
  case TAG_Nom: {
    V v_x_24410 = heff_field(v_x1_24409, 0);
    heff_take_n(v_x1_24409, 1ULL, 1);
    return v_x_24410;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24409, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24412 = heff_field(v_x1_24409, 0);
    heff_take_n(v_x1_24409, 1ULL, 1);
    return v_x_24412;
  }
  default: return heff_nomatch(v_x1_24409);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam45(V self, V *args) {
  V v_f_24407 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24407, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam46, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam48(V self, V *args) {
  V v_u_24425 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24425);
  V v_x1_24426 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2413, v_vs_244}));
  switch (heff_tag_of(v_x1_24426)) {
  case TAG_Nom: {
    V v_x_24427 = heff_field(v_x1_24426, 0);
    heff_take_n(v_x1_24426, 1ULL, 1);
    return v_x_24427;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24426, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24429 = heff_field(v_x1_24426, 0);
    heff_take_n(v_x1_24426, 1ULL, 1);
    return v_x_24429;
  }
  default: return heff_nomatch(v_x1_24426);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam47(V self, V *args) {
  V v_f_24424 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2413 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24424, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam48, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2413, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam49(V self, V *args) {
  V v_u_24444 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_dom_24440 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24444);
  V v_x1_24445 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_dom_24440, v_vs_244}));
  switch (heff_tag_of(v_x1_24445)) {
  case TAG_Nom: {
    V v_x_24446 = heff_field(v_x1_24445, 0);
    heff_take_n(v_x1_24445, 1ULL, 1);
    return v_x_24446;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24445, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24448 = heff_field(v_x1_24445, 0);
    heff_take_n(v_x1_24445, 1ULL, 1);
    return v_x_24448;
  }
  default: return heff_nomatch(v_x1_24445);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam50(V self, V *args) {
  V v_vs2_24449 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_c_242 = heff_env(self)[2];
  V v_t_24443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_r_240, 0, 2);
  heff_room[0] = v_g_241;
  heff_room[1] = v_c_242;
  heff_room[2] = v_t_24443;
  heff_room[3] = v_vs2_24449;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eeval_2eevalTermF_lam51(V self, V *args) {
  V v_u_24453 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_dom_24440 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24453);
  V v_x1_24454 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_dom_24440, v_vs_244}));
  switch (heff_tag_of(v_x1_24454)) {
  case TAG_Nom: {
    V v_x_24455 = heff_field(v_x1_24454, 0);
    heff_take_n(v_x1_24454, 1ULL, 1);
    return v_x_24455;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24454, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24457 = heff_field(v_x1_24454, 0);
    heff_take_n(v_x1_24454, 1ULL, 1);
    return v_x_24457;
  }
  default: return heff_nomatch(v_x1_24454);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam52(V self, V *args) {
  V v_i_24461 = args[0];
  V v_xs_24460 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_c_242 = heff_env(self)[3];
  V v_vs_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24462 = heff_arrayIndex(v_xs_24460, v_i_24461);
  V f_ = heff_get_n(v_r_240, 0, 2);
  heff_room[0] = v_g_241;
  heff_room[1] = v_c_242;
  heff_room[2] = v_t_24462;
  heff_room[3] = v_vs_244;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eeval_2eevalTermF_lam53(V self, V *args) {
  V v_sp_24509 = args[0];
  V v_i_24510 = args[1];
  V v_vs_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_24509, ({ V a_0 = v_vs_244; V a_1 = v_i_24510; V r_ = heff_tr(g_heff_2eelab_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_vs_244); r_; })});
}
V g_heff_2eelab_2eeval_2eevalTermF_lam54(V self, V *args) {
  V v_u_24517 = args[0];
  V v_ty_24516 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24517);
  return v_ty_24516;
}
V g_heff_2eelab_2eeval_2eevalTypeF_lam0(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_lam2(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_lam1(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_lam5(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_lam4(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_lam3(V self, V *args);
Clo g_heff_2eelab_2eeval_2eevalTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_entry, 5, 0};

V g_heff_2eelab_2eeval_2eevalTypeF(V v_r_240, V v_g_241, V v_c_242, V v_x4_243, V v_vs_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_SU: {
    V v_u_245 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SU = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SU, TAG_Nom, 1, (V[]){heff_tag_n(TAG_VU, 1, (V[]){v_u_245})});
  }
  case TAG_SDecode: {
    V v_t_246 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SDecode = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, v_c_242, v_t_246, v_vs_244}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nom: {
      V v_x_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x4_243_24SDecode, TAG_Nom, 1, (V[]){({ V a_0 = v_x_248; V r_ = (g_heff_2eelab_2evalue_2edecodeN(a_0)); heff_drop(v_x_248); r_; })});
    }
    case TAG_Describe: {
      V v_x_249 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      switch (heff_tag_of(v_x_249)) {
      case TAG_VNeu: {
        heff_take_n(v_x_249, 0ULL, 5);
        heff_drop_cell(v_ru_24x4_243_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VCode: {
        V v_a_2415 = heff_field(v_x_249, 0);
        heff_take_n(v_x_249, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x4_243_24SDecode, TAG_Describe, 1, (V[]){v_a_2415});
      }
      case TAG_VLam: {
        heff_take_n(v_x_249, 0ULL, 2);
        heff_drop_cell(v_ru_24x4_243_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_x_249, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VOpaque: {
        heff_drop_cell(v_ru_24x4_243_24SDecode, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_x_249);
      }
    }
    case TAG_Become: {
      V v_x_2419 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x4_243_24SDecode, TAG_Become, 1, (V[]){({ V a_0 = v_x_2419; V r_ = (g_heff_2eelab_2evalue_2edecodeN(a_0)); heff_drop(v_x_2419); r_; })});
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_SFunction: {
    V v_level_2420 = heff_field(v_x4_243, 0);
    V v_dom_2421 = heff_field(v_x4_243, 1);
    V v_cod_2422 = heff_field(v_x4_243, 2);
    V v_implicit_2423 = heff_field(v_x4_243, 3);
    V v_dflt_2424 = heff_field(v_x4_243, 4);
    V v_ru_24x4_243_24SFunction = heff_take_reuse_n(v_x4_243, 31ULL, 5);
    heff_drop(v_c_242);
    V v_x1_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 4, (V[]){heff_dup(v_g_241), NTAG(TAG_N), v_dom_2421, heff_dup(v_vs_244)}));
    V v_t_2429;
    switch (heff_tag_of(v_x1_2425)) {
    case TAG_Nom: {
      V v_x_2426 = heff_field(v_x1_2425, 0);
      heff_take_n(v_x1_2425, 1ULL, 1);
      v_t_2429 = v_x_2426;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2425, 0ULL, 1);
      v_t_2429 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2428 = heff_field(v_x1_2425, 0);
      heff_take_n(v_x1_2425, 1ULL, 1);
      v_t_2429 = v_x_2428;
      break;
    }
    default: heff_nomatch(v_x1_2425);
    }
    V v_t_2435;
    switch (heff_tag_of(v_cod_2422)) {
    case TAG_MkAbs: {
      V v_x_2430 = heff_field(v_cod_2422, 0);
      V v_t_2431 = heff_field(v_cod_2422, 1);
      heff_take_n(v_cod_2422, 3ULL, 2);
      v_t_2435 = heff_tag_n(TAG_MkClo, 3, (V[]){v_x_2430, v_vs_244, heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_lam0, 1, 3, (V[]){v_r_240, v_g_241, v_t_2431})});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2433 = heff_field(v_cod_2422, 0);
      V v_ru_24cod_2422_24AbsConst = heff_take_reuse_n(v_cod_2422, 1ULL, 1);
      V v_t_2434 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2433, v_vs_244}));
      v_t_2435 = heff_tag_at_n(v_ru_24cod_2422_24AbsConst, TAG_CloConst, 1, (V[]){v_t_2434});
      break;
    }
    default: heff_nomatch(v_cod_2422);
    }
    return heff_tag_n(TAG_Nom, 1, (V[]){heff_tag_at_n(v_ru_24x4_243_24SFunction, TAG_VFunction, 5, (V[]){v_level_2420, v_t_2429, v_t_2435, v_implicit_2423, v_dflt_2424})});
  }
  case TAG_SRecord: {
    V v_level_2436 = heff_field(v_x4_243, 0);
    V v_fieldTypes_2437 = heff_field(v_x4_243, 1);
    V v_defaults_2438 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    heff_drop(v_c_242);
    V v_xs_2439 = heff_take_field(v_fieldTypes_2437, 2);
    V v_t_2448 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2439)), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_lam1, 1, 3, (V[]){v_xs_2439, v_r_240, v_g_241}));
    V v_t_2449 = ({ V rv_2 = v_t_2448; V rr_ = heff_rec_reuse_n(v_fieldTypes_2437, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_Describe, 1, (V[]){heff_tag_n(TAG_VRecord, 4, (V[]){v_level_2436, v_vs_244, v_t_2449, v_defaults_2438})});
  }
  case TAG_SSum: {
    V v_st_2450 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SSum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    V v_xs_2451 = heff_take_field(v_st_2450, 2);
    V v_t_2461 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2451)), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_lam3, 1, 4, (V[]){v_xs_2451, v_r_240, v_g_241, v_vs_244}));
    V v_t_2462 = ({ V rv_2 = v_t_2461; V rr_ = heff_rec_reuse_n(v_st_2450, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24x4_243_24SSum, TAG_Describe, 1, (V[]){heff_tag_n(TAG_VSum, 1, (V[]){v_t_2462})});
  }
  case TAG_SIsTy: {
    V v_t_2463 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SIsTy = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    V v_x1_2464 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2463, v_vs_244}));
    V v_t_2468;
    switch (heff_tag_of(v_x1_2464)) {
    case TAG_Nom: {
      V v_x_2465 = heff_field(v_x1_2464, 0);
      heff_take_n(v_x1_2464, 1ULL, 1);
      v_t_2468 = v_x_2465;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2464, 0ULL, 1);
      v_t_2468 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2467 = heff_field(v_x1_2464, 0);
      heff_take_n(v_x1_2464, 1ULL, 1);
      v_t_2468 = v_x_2467;
      break;
    }
    default: heff_nomatch(v_x1_2464);
    }
    return heff_tag_at_n(v_ru_24x4_243_24SIsTy, TAG_Become, 1, (V[]){v_t_2468});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimInt)});
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimFloat)});
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimString)});
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimRune)});
  }
  case TAG_SPrimArray: {
    V v_a_2469 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SPrimArray = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    V v_x1_2470 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_a_2469, v_vs_244}));
    V v_t_2474;
    switch (heff_tag_of(v_x1_2470)) {
    case TAG_Nom: {
      V v_x_2471 = heff_field(v_x1_2470, 0);
      heff_take_n(v_x1_2470, 1ULL, 1);
      v_t_2474 = v_x_2471;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2470, 0ULL, 1);
      v_t_2474 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2473 = heff_field(v_x1_2470, 0);
      heff_take_n(v_x1_2470, 1ULL, 1);
      v_t_2474 = v_x_2473;
      break;
    }
    default: heff_nomatch(v_x1_2470);
    }
    return heff_tag_at_n(v_ru_24x4_243_24SPrimArray, TAG_Nom, 1, (V[]){heff_tag_n(TAG_VPrimArray, 1, (V[]){v_t_2474})});
  }
  case TAG_SFixed: {
    V v_w_2475 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SFixed = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SFixed, TAG_Nom, 1, (V[]){heff_tag_n(TAG_VFixed, 1, (V[]){v_w_2475})});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eeval_2eevalTypeF(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eeval_2eevalTypeF_lam0(V self, V *args) {
  V v_vs2_2432 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_get_n(v_r_240, 1, 2);
  heff_room[0] = v_g_241;
  heff_room[1] = NTAG(TAG_N);
  heff_room[2] = v_t_2431;
  heff_room[3] = v_vs2_2432;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eeval_2eevalTypeF_lam2(V self, V *args) {
  V v_vs2_2442 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_2443 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2441, v_vs2_2442}));
  V v_t_2447;
  switch (heff_tag_of(v_x1_2443)) {
  case TAG_Nom: {
    V v_x_2444 = heff_field(v_x1_2443, 0);
    heff_take_n(v_x1_2443, 1ULL, 1);
    v_t_2447 = v_x_2444;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2443, 0ULL, 1);
    v_t_2447 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2446 = heff_field(v_x1_2443, 0);
    heff_take_n(v_x1_2443, 1ULL, 1);
    v_t_2447 = v_x_2446;
    break;
  }
  default: heff_nomatch(v_x1_2443);
  }
  return heff_tag_n(TAG_MkField, 2, (V[]){v_t_2447, NTAG(TAG_Nothing)});
}
V g_heff_2eelab_2eeval_2eevalTypeF_lam1(V self, V *args) {
  V v_i_2440 = args[0];
  V v_xs_2439 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2441 = heff_arrayIndex(v_xs_2439, v_i_2440);
  return heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_lam2, 1, 3, (V[]){v_r_240, v_g_241, v_t_2441});
}
V g_heff_2eelab_2eeval_2eevalTypeF_lam5(V self, V *args) {
  V v_u_2456 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t_2455 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2456);
  V v_x1_2457 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2455, v_vs_244}));
  switch (heff_tag_of(v_x1_2457)) {
  case TAG_Nom: {
    V v_x_2458 = heff_field(v_x1_2457, 0);
    heff_take_n(v_x1_2457, 1ULL, 1);
    return v_x_2458;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2457, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2460 = heff_field(v_x1_2457, 0);
    heff_take_n(v_x1_2457, 1ULL, 1);
    return v_x_2460;
  }
  default: return heff_nomatch(v_x1_2457);
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_lam4(V self, V *args) {
  V v_i_2454 = args[0];
  V v_xs_2453 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2455 = heff_arrayIndex(v_xs_2453, v_i_2454);
  return heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_lam5, 1, 4, (V[]){v_r_240, v_g_241, v_t_2455, v_vs_244});
}
V g_heff_2eelab_2eeval_2eevalTypeF_lam3(V self, V *args) {
  V v_i_2452 = args[0];
  V v_xs_2451 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_xs_2453 = heff_arrayIndex(v_xs_2451, v_i_2452);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2453)), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_lam4, 1, 4, (V[]){v_xs_2453, v_r_240, v_g_241, v_vs_244}));
}
V g_heff_2eelab_2eeval_2eevaluator_lam0(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevaluator_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevaluator_lam0, 4, 0};
V g_heff_2eelab_2eeval_2eevaluator_lam1(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevaluator_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevaluator_lam1, 4, 0};

static V g_heff_2eelab_2eeval_2eevaluator_val;
static HEFF_ONCE g_heff_2eelab_2eeval_2eevaluator_st;
static V g_heff_2eelab_2eeval_2eevaluator_init(void) {
  return heff_rec_n(2, shape_el__ty, (V[]){((V)&g_heff_2eelab_2eeval_2eevaluator_lam0_clo), ((V)&g_heff_2eelab_2eeval_2eevaluator_lam1_clo)});
}
V g_heff_2eelab_2eeval_2eevaluator_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eeval_2eevaluator_st)) return g_heff_2eelab_2eeval_2eevaluator_val;
  return heff_global(&g_heff_2eelab_2eeval_2eevaluator_val, &g_heff_2eelab_2eeval_2eevaluator_st, g_heff_2eelab_2eeval_2eevaluator_init);
}
V g_heff_2eelab_2eeval_2eevaluator_lam0(V self, V *args) {
  V v_g_240 = args[0];
  V v_c_241 = args[1];
  V v_s_242 = args[2];
  V v_vs_243 = args[3];
  return (g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, v_c_241, v_s_242, v_vs_243));
}
V g_heff_2eelab_2eeval_2eevaluator_lam1(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_s_246 = args[2];
  V v_vs_247 = args[3];
  return (g_heff_2eelab_2eeval_2eevalTypeF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_244, v_c_245, v_s_246, v_vs_247));
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam0(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam2(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam1(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam5(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam4(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam3(V self, V *args);
Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry, 4, 0};

V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V v_g_240, V v_c_241, V v_x4_242, V v_vs_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SU: {
    V v_u_244 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SU = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_at_n(v_ru_24x4_242_24SU, TAG_Nom, 1, (V[]){heff_tag_n(TAG_VU, 1, (V[]){v_u_244})});
  }
  case TAG_SDecode: {
    V v_t_245 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SDecode = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_x1_246 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, v_c_241, v_t_245, v_vs_243));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nom: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x4_242_24SDecode, TAG_Nom, 1, (V[]){({ V a_0 = v_x_247; V r_ = (g_heff_2eelab_2evalue_2edecodeN(a_0)); heff_drop(v_x_247); r_; })});
    }
    case TAG_Describe: {
      V v_x_248 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_x_248)) {
      case TAG_VNeu: {
        heff_take_n(v_x_248, 0ULL, 5);
        heff_drop_cell(v_ru_24x4_242_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VCode: {
        V v_a_2414 = heff_field(v_x_248, 0);
        heff_take_n(v_x_248, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x4_242_24SDecode, TAG_Describe, 1, (V[]){v_a_2414});
      }
      case TAG_VLam: {
        heff_take_n(v_x_248, 0ULL, 2);
        heff_drop_cell(v_ru_24x4_242_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_x_248, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_242_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VOpaque: {
        heff_drop_cell(v_ru_24x4_242_24SDecode, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_x_248);
      }
    }
    case TAG_Become: {
      V v_x_2418 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x4_242_24SDecode, TAG_Become, 1, (V[]){({ V a_0 = v_x_2418; V r_ = (g_heff_2eelab_2evalue_2edecodeN(a_0)); heff_drop(v_x_2418); r_; })});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_SFunction: {
    V v_level_2419 = heff_field(v_x4_242, 0);
    V v_dom_2420 = heff_field(v_x4_242, 1);
    V v_cod_2421 = heff_field(v_x4_242, 2);
    V v_implicit_2422 = heff_field(v_x4_242, 3);
    V v_dflt_2423 = heff_field(v_x4_242, 4);
    V v_ru_24x4_242_24SFunction = heff_take_reuse_n(v_x4_242, 31ULL, 5);
    heff_drop(v_c_241);
    V v_x1_2424 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(heff_dup(v_g_240), NTAG(TAG_N), v_dom_2420, heff_dup(v_vs_243)));
    V v_t_2428;
    switch (heff_tag_of(v_x1_2424)) {
    case TAG_Nom: {
      V v_x_2425 = heff_field(v_x1_2424, 0);
      heff_take_n(v_x1_2424, 1ULL, 1);
      v_t_2428 = v_x_2425;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2424, 0ULL, 1);
      v_t_2428 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2427 = heff_field(v_x1_2424, 0);
      heff_take_n(v_x1_2424, 1ULL, 1);
      v_t_2428 = v_x_2427;
      break;
    }
    default: heff_nomatch(v_x1_2424);
    }
    V v_t_2433;
    switch (heff_tag_of(v_cod_2421)) {
    case TAG_MkAbs: {
      V v_x_2429 = heff_field(v_cod_2421, 0);
      V v_t_2430 = heff_field(v_cod_2421, 1);
      heff_take_n(v_cod_2421, 3ULL, 2);
      v_t_2433 = heff_tag_n(TAG_MkClo, 3, (V[]){v_x_2429, v_vs_243, heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam0, 1, 2, (V[]){v_g_240, v_t_2430})});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2432 = heff_field(v_cod_2421, 0);
      V v_ru_24cod_2421_24AbsConst = heff_take_reuse_n(v_cod_2421, 1ULL, 1);
      v_t_2433 = heff_tag_at_n(v_ru_24cod_2421_24AbsConst, TAG_CloConst, 1, (V[]){(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_t_2432, v_vs_243))});
      break;
    }
    default: heff_nomatch(v_cod_2421);
    }
    return heff_tag_n(TAG_Nom, 1, (V[]){heff_tag_at_n(v_ru_24x4_242_24SFunction, TAG_VFunction, 5, (V[]){v_level_2419, v_t_2428, v_t_2433, v_implicit_2422, v_dflt_2423})});
  }
  case TAG_SRecord: {
    V v_level_2434 = heff_field(v_x4_242, 0);
    V v_fieldTypes_2435 = heff_field(v_x4_242, 1);
    V v_defaults_2436 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    heff_drop(v_c_241);
    V v_xs_2437 = heff_take_field(v_fieldTypes_2435, 2);
    V v_t_2446 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2437)), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam1, 1, 2, (V[]){v_xs_2437, v_g_240}));
    V v_t_2447 = ({ V rv_2 = v_t_2446; V rr_ = heff_rec_reuse_n(v_fieldTypes_2435, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_Describe, 1, (V[]){heff_tag_n(TAG_VRecord, 4, (V[]){v_level_2434, v_vs_243, v_t_2447, v_defaults_2436})});
  }
  case TAG_SSum: {
    V v_st_2448 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SSum = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    V v_xs_2449 = heff_take_field(v_st_2448, 2);
    V v_t_2459 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2449)), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam3, 1, 3, (V[]){v_xs_2449, v_g_240, v_vs_243}));
    V v_t_2460 = ({ V rv_2 = v_t_2459; V rr_ = heff_rec_reuse_n(v_st_2448, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24x4_242_24SSum, TAG_Describe, 1, (V[]){heff_tag_n(TAG_VSum, 1, (V[]){v_t_2460})});
  }
  case TAG_SIsTy: {
    V v_t_2461 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SIsTy = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    V v_x1_2462 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_t_2461, v_vs_243));
    V v_t_2466;
    switch (heff_tag_of(v_x1_2462)) {
    case TAG_Nom: {
      V v_x_2463 = heff_field(v_x1_2462, 0);
      heff_take_n(v_x1_2462, 1ULL, 1);
      v_t_2466 = v_x_2463;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2462, 0ULL, 1);
      v_t_2466 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2465 = heff_field(v_x1_2462, 0);
      heff_take_n(v_x1_2462, 1ULL, 1);
      v_t_2466 = v_x_2465;
      break;
    }
    default: heff_nomatch(v_x1_2462);
    }
    return heff_tag_at_n(v_ru_24x4_242_24SIsTy, TAG_Become, 1, (V[]){v_t_2466});
  }
  case TAG_SPrimInt: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimInt)});
  }
  case TAG_SPrimFloat: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimFloat)});
  }
  case TAG_SPrimString: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimString)});
  }
  case TAG_SPrimRune: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimRune)});
  }
  case TAG_SPrimArray: {
    V v_a_2467 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SPrimArray = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    V v_x1_2468 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_a_2467, v_vs_243));
    V v_t_2472;
    switch (heff_tag_of(v_x1_2468)) {
    case TAG_Nom: {
      V v_x_2469 = heff_field(v_x1_2468, 0);
      heff_take_n(v_x1_2468, 1ULL, 1);
      v_t_2472 = v_x_2469;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2468, 0ULL, 1);
      v_t_2472 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2471 = heff_field(v_x1_2468, 0);
      heff_take_n(v_x1_2468, 1ULL, 1);
      v_t_2472 = v_x_2471;
      break;
    }
    default: heff_nomatch(v_x1_2468);
    }
    return heff_tag_at_n(v_ru_24x4_242_24SPrimArray, TAG_Nom, 1, (V[]){heff_tag_n(TAG_VPrimArray, 1, (V[]){v_t_2472})});
  }
  case TAG_SFixed: {
    V v_w_2473 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SFixed = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_at_n(v_ru_24x4_242_24SFixed, TAG_Nom, 1, (V[]){heff_tag_n(TAG_VFixed, 1, (V[]){v_w_2473})});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam0(V self, V *args) {
  V v_vs2_2431 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_t_2430, v_vs2_2431));
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam2(V self, V *args) {
  V v_vs2_2440 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2441 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_t_2439, v_vs2_2440));
  V v_t_2445;
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_Nom: {
    V v_x_2442 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_t_2445 = v_x_2442;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2441, 0ULL, 1);
    v_t_2445 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2444 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_t_2445 = v_x_2444;
    break;
  }
  default: heff_nomatch(v_x1_2441);
  }
  return heff_tag_n(TAG_MkField, 2, (V[]){v_t_2445, NTAG(TAG_Nothing)});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam1(V self, V *args) {
  V v_i_2438 = args[0];
  V v_xs_2437 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = heff_arrayIndex(v_xs_2437, v_i_2438);
  return heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam2, 1, 2, (V[]){v_g_240, v_t_2439});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam5(V self, V *args) {
  V v_u_2454 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2453 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2454);
  V v_x1_2455 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_t_2453, v_vs_243));
  switch (heff_tag_of(v_x1_2455)) {
  case TAG_Nom: {
    V v_x_2456 = heff_field(v_x1_2455, 0);
    heff_take_n(v_x1_2455, 1ULL, 1);
    return v_x_2456;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2455, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2458 = heff_field(v_x1_2455, 0);
    heff_take_n(v_x1_2455, 1ULL, 1);
    return v_x_2458;
  }
  default: return heff_nomatch(v_x1_2455);
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam4(V self, V *args) {
  V v_i_2452 = args[0];
  V v_xs_2451 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2453 = heff_arrayIndex(v_xs_2451, v_i_2452);
  return heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam5, 1, 3, (V[]){v_g_240, v_t_2453, v_vs_243});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam3(V self, V *args) {
  V v_i_2450 = args[0];
  V v_xs_2449 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_xs_2451 = heff_arrayIndex(v_xs_2449, v_i_2450);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2451)), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam4, 1, 3, (V[]){v_xs_2451, v_g_240, v_vs_243}));
}