// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_HError 21467
#define TAG_HMeta 17321
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_entries 787768015
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_value 313331083
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_array_2efoldlFrom(V, V, V, V);
V g_array_2efoldlFrom_entry(V self, V *a);
extern Clo g_array_2efoldlFrom_clo;
V g_heff_2eelab_2eeval_2eerrorHeaded(V);
V g_heff_2eelab_2eeval_2eerrorHeaded_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eerrorHeaded_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevalTypeF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24cpr(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
HeffT2 g_heff_2eelab_2evalue_2edecodeEv_24cpr(V);
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263(V);
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_clo;
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24tok1(V, V);
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24tok1_clo;
V g_heff_2eelab_2evalue_2efieldIn(V, V);
V g_heff_2eelab_2evalue_2efieldIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2efieldIn_clo;
V g_heff_2eelab_2evalue_2elocalsAt(V, V);
V g_heff_2eelab_2evalue_2elocalsAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elocalsAt_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_clo;
V g_heff_2eelab_2evalue_2ereflect(V, V, V, V);
V g_heff_2eelab_2evalue_2ereflect_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_clo;
V g_heff_2eelab_2evalue_2ereflect_24tok2(V, V, V, V, V);
V g_heff_2eelab_2evalue_2ereflect_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_24tok2_clo;
V g_heff_2eelab_2evalue_2especialize(V, V, V);
V g_heff_2eelab_2evalue_2especialize_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2especialize_clo;
V g_heff_2eelab_2evalue_2especialize_24tok3(V, V, V, V);
V g_heff_2eelab_2evalue_2especialize_24tok3_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2especialize_24tok3_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_heff_2eelab_2eeval_2eevalTermF_lam1(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam0(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam3(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam2(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam5(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam4(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam7(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam6(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam8(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam10(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam9(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam12(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam11(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam14(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam13(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam16(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam15(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam18(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam17(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam20(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam19(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam22(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam21(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam24(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam23(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam26(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam25(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam28(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam27(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam30(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam29(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam32(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam31(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam34(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam33(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam36(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam35(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam38(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam37(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam40(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam39(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam42(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam41(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam44(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam43(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam46(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam45(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam48(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam47(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam50(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam49(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam51(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam52(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam53(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam54(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam55(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam56(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam57(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam58(V self, V *args);
Clo g_heff_2eelab_2eeval_2eevalTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTermF_entry, 5, 0};

V g_heff_2eelab_2eeval_2eevalTermF(V v_r_240, V v_g_241, V v_c_242, V v_x4_243, V v_vs_244) {
top: ;
  V v_ty_245 = heff_take_field(v_r_240, 1);
  V v_el_246 = heff_get_n(v_r_240, 0, 2);
  switch (heff_tag_of(v_x4_243)) {
  case TAG_SLocal: {
    V v_i_247 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SLocal = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_ty_245);
    heff_drop(v_el_246);
    V v_t_248 = ({ V a_0 = v_vs_244; V a_1 = v_i_247; V r_ = heff_tr(g_heff_2eelab_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_vs_244); r_; });
    return heff_tag_at_n(v_ru_24x4_243_24SLocal, TAG_Nom, 1, (V[]){v_t_248});
  }
  case TAG_SGlobal: {
    V v_x_249 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SGlobal = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_ty_245);
    heff_drop(v_el_246);
    HeffT2 v_t_2410 = ({ V b_0 = heff_get_n(v_g_241, 1, 8); V a_1 = v_x_249; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_249); r_; });
    V v_t_2414;
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_e_2413 = v_field_2412;
        v_t_2414 = v_e_2413;
      } else {
        heff_drop(v_field_2412);
        v_t_2414 = heff_abandon();
      }
    }
    return heff_tag_at_n(v_ru_24x4_243_24SGlobal, TAG_Nom, 1, (V[]){heff_get_n(v_t_2414, 2, 4)});
  }
  case TAG_SCode: {
    V v_a_2415 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SCode = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_el_246);
    V v_t_2416 = heff_tr(heff_call(v_ty_245, 4, (V[]){v_g_241, v_c_242, v_a_2415, v_vs_244}));
    return (g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24tok1(v_ru_24x4_243_24SCode, v_t_2416));
  }
  case TAG_SApp: {
    V v_x41_2417 = heff_field(v_x4_243, 0);
    V v_t1_2418 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    heff_drop(v_ty_245);
    switch (heff_tag_of(v_x41_2417)) {
    case TAG_SLocal: {
      heff_drop(v_c_242);
      V v_f_2426 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam0, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_2427 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_Nom: {
        V v_x_2428 = heff_field(v_x2_2427, 0);
        heff_take_n(v_x2_2427, 1ULL, 1);
        return heff_tail(v_f_2426, 1, (V[]){v_x_2428});
      }
      case TAG_Describe: {
        V v_x_2429 = heff_field(v_x2_2427, 0);
        heff_take_n(v_x2_2427, 1ULL, 1);
        return heff_tail(v_f_2426, 1, (V[]){v_x_2429});
      }
      case TAG_Become: {
        V v_x_2430 = heff_field(v_x2_2427, 0);
        V v_ru_24x2_2427_24Become = heff_take_reuse_n(v_x2_2427, 1ULL, 1);
        V v_x1_2431 = heff_tr(heff_call(v_f_2426, 1, (V[]){v_x_2430}));
        V v_t_2435;
        switch (heff_tag_of(v_x1_2431)) {
        case TAG_Nom: {
          V v_x_2432 = heff_field(v_x1_2431, 0);
          heff_take_n(v_x1_2431, 1ULL, 1);
          v_t_2435 = v_x_2432;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2431, 0ULL, 1);
          v_t_2435 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2434 = heff_field(v_x1_2431, 0);
          heff_take_n(v_x1_2431, 1ULL, 1);
          v_t_2435 = v_x_2434;
          break;
        }
        default: heff_nomatch(v_x1_2431);
        }
        return heff_tag_at_n(v_ru_24x2_2427_24Become, TAG_Become, 1, (V[]){v_t_2435});
      }
      default: return heff_nomatch(v_x2_2427);
      }
    }
    case TAG_SGlobal: {
      heff_drop(v_c_242);
      V v_f_2443 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam2, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_2444 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_2444)) {
      case TAG_Nom: {
        V v_x_2445 = heff_field(v_x2_2444, 0);
        heff_take_n(v_x2_2444, 1ULL, 1);
        return heff_tail(v_f_2443, 1, (V[]){v_x_2445});
      }
      case TAG_Describe: {
        V v_x_2446 = heff_field(v_x2_2444, 0);
        heff_take_n(v_x2_2444, 1ULL, 1);
        return heff_tail(v_f_2443, 1, (V[]){v_x_2446});
      }
      case TAG_Become: {
        V v_x_2447 = heff_field(v_x2_2444, 0);
        V v_ru_24x2_2444_24Become = heff_take_reuse_n(v_x2_2444, 1ULL, 1);
        V v_x1_2448 = heff_tr(heff_call(v_f_2443, 1, (V[]){v_x_2447}));
        V v_t_2452;
        switch (heff_tag_of(v_x1_2448)) {
        case TAG_Nom: {
          V v_x_2449 = heff_field(v_x1_2448, 0);
          heff_take_n(v_x1_2448, 1ULL, 1);
          v_t_2452 = v_x_2449;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2448, 0ULL, 1);
          v_t_2452 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2451 = heff_field(v_x1_2448, 0);
          heff_take_n(v_x1_2448, 1ULL, 1);
          v_t_2452 = v_x_2451;
          break;
        }
        default: heff_nomatch(v_x1_2448);
        }
        return heff_tag_at_n(v_ru_24x2_2444_24Become, TAG_Become, 1, (V[]){v_t_2452});
      }
      default: return heff_nomatch(v_x2_2444);
      }
    }
    case TAG_SCode: {
      heff_drop(v_c_242);
      V v_f_2460 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam4, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_2461 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_2461)) {
      case TAG_Nom: {
        V v_x_2462 = heff_field(v_x2_2461, 0);
        heff_take_n(v_x2_2461, 1ULL, 1);
        return heff_tail(v_f_2460, 1, (V[]){v_x_2462});
      }
      case TAG_Describe: {
        V v_x_2463 = heff_field(v_x2_2461, 0);
        heff_take_n(v_x2_2461, 1ULL, 1);
        return heff_tail(v_f_2460, 1, (V[]){v_x_2463});
      }
      case TAG_Become: {
        V v_x_2464 = heff_field(v_x2_2461, 0);
        V v_ru_24x2_2461_24Become = heff_take_reuse_n(v_x2_2461, 1ULL, 1);
        V v_x1_2465 = heff_tr(heff_call(v_f_2460, 1, (V[]){v_x_2464}));
        V v_t_2469;
        switch (heff_tag_of(v_x1_2465)) {
        case TAG_Nom: {
          V v_x_2466 = heff_field(v_x1_2465, 0);
          heff_take_n(v_x1_2465, 1ULL, 1);
          v_t_2469 = v_x_2466;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2465, 0ULL, 1);
          v_t_2469 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2468 = heff_field(v_x1_2465, 0);
          heff_take_n(v_x1_2465, 1ULL, 1);
          v_t_2469 = v_x_2468;
          break;
        }
        default: heff_nomatch(v_x1_2465);
        }
        return heff_tag_at_n(v_ru_24x2_2461_24Become, TAG_Become, 1, (V[]){v_t_2469});
      }
      default: return heff_nomatch(v_x2_2461);
      }
    }
    case TAG_SApp: {
      heff_drop(v_c_242);
      V v_f_2478 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam6, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_2479 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_2479)) {
      case TAG_Nom: {
        V v_x_2480 = heff_field(v_x2_2479, 0);
        heff_take_n(v_x2_2479, 1ULL, 1);
        return heff_tail(v_f_2478, 1, (V[]){v_x_2480});
      }
      case TAG_Describe: {
        V v_x_2481 = heff_field(v_x2_2479, 0);
        heff_take_n(v_x2_2479, 1ULL, 1);
        return heff_tail(v_f_2478, 1, (V[]){v_x_2481});
      }
      case TAG_Become: {
        V v_x_2482 = heff_field(v_x2_2479, 0);
        V v_ru_24x2_2479_24Become = heff_take_reuse_n(v_x2_2479, 1ULL, 1);
        V v_x1_2483 = heff_tr(heff_call(v_f_2478, 1, (V[]){v_x_2482}));
        V v_t_2487;
        switch (heff_tag_of(v_x1_2483)) {
        case TAG_Nom: {
          V v_x_2484 = heff_field(v_x1_2483, 0);
          heff_take_n(v_x1_2483, 1ULL, 1);
          v_t_2487 = v_x_2484;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2483, 0ULL, 1);
          v_t_2487 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2486 = heff_field(v_x1_2483, 0);
          heff_take_n(v_x1_2483, 1ULL, 1);
          v_t_2487 = v_x_2486;
          break;
        }
        default: heff_nomatch(v_x1_2483);
        }
        return heff_tag_at_n(v_ru_24x2_2479_24Become, TAG_Become, 1, (V[]){v_t_2487});
      }
      default: return heff_nomatch(v_x2_2479);
      }
    }
    case TAG_SLam: {
      V v_x412_2489 = heff_dup(heff_field(v_x41_2417, 1));
      switch (heff_tag_of(v_x412_2489)) {
      case TAG_MkAbs: {
        V v_t_2491 = heff_field(v_x412_2489, 1);
        heff_take_n(v_x412_2489, 2ULL, 2);
        switch (heff_tag_of(v_x41_2417)) {
        case TAG_SLam: {
          heff_take_n(v_x41_2417, 0ULL, 2);
          return heff_tail(heff_dup(v_el_246), 4, (V[]){heff_dup(v_g_241), v_c_242, v_t_2491, heff_tag_n(TAG_LSnoc, 2, (V[]){heff_dup(v_vs_244), heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam8, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})})});
        }
        default: return heff_nomatch(v_x41_2417);
        }
      }
      case TAG_AbsConst: {
        V v_ru_24x412_2489_24AbsConst = heff_take_reuse_n(v_x412_2489, 0ULL, 1);
        heff_drop(v_c_242);
        V v_f_24106 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam9, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
        V v_x2_24107 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
        switch (heff_tag_of(v_x2_24107)) {
        case TAG_Nom: {
          V v_x_24108 = heff_field(v_x2_24107, 0);
          heff_take_n(v_x2_24107, 1ULL, 1);
          heff_drop_cell(v_ru_24x412_2489_24AbsConst, 1);
          return heff_tail(v_f_24106, 1, (V[]){v_x_24108});
        }
        case TAG_Describe: {
          V v_x_24109 = heff_field(v_x2_24107, 0);
          heff_take_n(v_x2_24107, 1ULL, 1);
          heff_drop_cell(v_ru_24x412_2489_24AbsConst, 1);
          return heff_tail(v_f_24106, 1, (V[]){v_x_24109});
        }
        case TAG_Become: {
          V v_x_24110 = heff_field(v_x2_24107, 0);
          heff_take_n(v_x2_24107, 1ULL, 1);
          V v_x1_24111 = heff_tr(heff_call(v_f_24106, 1, (V[]){v_x_24110}));
          V v_t_24115;
          switch (heff_tag_of(v_x1_24111)) {
          case TAG_Nom: {
            V v_x_24112 = heff_field(v_x1_24111, 0);
            heff_take_n(v_x1_24111, 1ULL, 1);
            v_t_24115 = v_x_24112;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_24111, 0ULL, 1);
            v_t_24115 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_24114 = heff_field(v_x1_24111, 0);
            heff_take_n(v_x1_24111, 1ULL, 1);
            v_t_24115 = v_x_24114;
            break;
          }
          default: heff_nomatch(v_x1_24111);
          }
          return heff_tag_at_n(v_ru_24x412_2489_24AbsConst, TAG_Become, 1, (V[]){v_t_24115});
        }
        default: return heff_nomatch(v_x2_24107);
        }
      }
      default: return heff_nomatch(v_x412_2489);
      }
    }
    case TAG_SCons: {
      heff_drop(v_c_242);
      V v_f_24123 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam11, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24124 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24124)) {
      case TAG_Nom: {
        V v_x_24125 = heff_field(v_x2_24124, 0);
        heff_take_n(v_x2_24124, 1ULL, 1);
        return heff_tail(v_f_24123, 1, (V[]){v_x_24125});
      }
      case TAG_Describe: {
        V v_x_24126 = heff_field(v_x2_24124, 0);
        heff_take_n(v_x2_24124, 1ULL, 1);
        return heff_tail(v_f_24123, 1, (V[]){v_x_24126});
      }
      case TAG_Become: {
        V v_x_24127 = heff_field(v_x2_24124, 0);
        V v_ru_24x2_24124_24Become = heff_take_reuse_n(v_x2_24124, 1ULL, 1);
        V v_x1_24128 = heff_tr(heff_call(v_f_24123, 1, (V[]){v_x_24127}));
        V v_t_24132;
        switch (heff_tag_of(v_x1_24128)) {
        case TAG_Nom: {
          V v_x_24129 = heff_field(v_x1_24128, 0);
          heff_take_n(v_x1_24128, 1ULL, 1);
          v_t_24132 = v_x_24129;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24128, 0ULL, 1);
          v_t_24132 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24131 = heff_field(v_x1_24128, 0);
          heff_take_n(v_x1_24128, 1ULL, 1);
          v_t_24132 = v_x_24131;
          break;
        }
        default: heff_nomatch(v_x1_24128);
        }
        return heff_tag_at_n(v_ru_24x2_24124_24Become, TAG_Become, 1, (V[]){v_t_24132});
      }
      default: return heff_nomatch(v_x2_24124);
      }
    }
    case TAG_SProj: {
      heff_drop(v_c_242);
      V v_f_24141 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam13, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24142 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24142)) {
      case TAG_Nom: {
        V v_x_24143 = heff_field(v_x2_24142, 0);
        heff_take_n(v_x2_24142, 1ULL, 1);
        return heff_tail(v_f_24141, 1, (V[]){v_x_24143});
      }
      case TAG_Describe: {
        V v_x_24144 = heff_field(v_x2_24142, 0);
        heff_take_n(v_x2_24142, 1ULL, 1);
        return heff_tail(v_f_24141, 1, (V[]){v_x_24144});
      }
      case TAG_Become: {
        V v_x_24145 = heff_field(v_x2_24142, 0);
        V v_ru_24x2_24142_24Become = heff_take_reuse_n(v_x2_24142, 1ULL, 1);
        V v_x1_24146 = heff_tr(heff_call(v_f_24141, 1, (V[]){v_x_24145}));
        V v_t_24150;
        switch (heff_tag_of(v_x1_24146)) {
        case TAG_Nom: {
          V v_x_24147 = heff_field(v_x1_24146, 0);
          heff_take_n(v_x1_24146, 1ULL, 1);
          v_t_24150 = v_x_24147;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24146, 0ULL, 1);
          v_t_24150 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24149 = heff_field(v_x1_24146, 0);
          heff_take_n(v_x1_24146, 1ULL, 1);
          v_t_24150 = v_x_24149;
          break;
        }
        default: heff_nomatch(v_x1_24146);
        }
        return heff_tag_at_n(v_ru_24x2_24142_24Become, TAG_Become, 1, (V[]){v_t_24150});
      }
      default: return heff_nomatch(v_x2_24142);
      }
    }
    case TAG_STag: {
      heff_drop(v_c_242);
      V v_f_24159 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam15, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24160 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24160)) {
      case TAG_Nom: {
        V v_x_24161 = heff_field(v_x2_24160, 0);
        heff_take_n(v_x2_24160, 1ULL, 1);
        return heff_tail(v_f_24159, 1, (V[]){v_x_24161});
      }
      case TAG_Describe: {
        V v_x_24162 = heff_field(v_x2_24160, 0);
        heff_take_n(v_x2_24160, 1ULL, 1);
        return heff_tail(v_f_24159, 1, (V[]){v_x_24162});
      }
      case TAG_Become: {
        V v_x_24163 = heff_field(v_x2_24160, 0);
        V v_ru_24x2_24160_24Become = heff_take_reuse_n(v_x2_24160, 1ULL, 1);
        V v_x1_24164 = heff_tr(heff_call(v_f_24159, 1, (V[]){v_x_24163}));
        V v_t_24168;
        switch (heff_tag_of(v_x1_24164)) {
        case TAG_Nom: {
          V v_x_24165 = heff_field(v_x1_24164, 0);
          heff_take_n(v_x1_24164, 1ULL, 1);
          v_t_24168 = v_x_24165;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24164, 0ULL, 1);
          v_t_24168 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24167 = heff_field(v_x1_24164, 0);
          heff_take_n(v_x1_24164, 1ULL, 1);
          v_t_24168 = v_x_24167;
          break;
        }
        default: heff_nomatch(v_x1_24164);
        }
        return heff_tag_at_n(v_ru_24x2_24160_24Become, TAG_Become, 1, (V[]){v_t_24168});
      }
      default: return heff_nomatch(v_x2_24160);
      }
    }
    case TAG_SMatch: {
      heff_drop(v_c_242);
      V v_f_24177 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam17, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24178 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24178)) {
      case TAG_Nom: {
        V v_x_24179 = heff_field(v_x2_24178, 0);
        heff_take_n(v_x2_24178, 1ULL, 1);
        return heff_tail(v_f_24177, 1, (V[]){v_x_24179});
      }
      case TAG_Describe: {
        V v_x_24180 = heff_field(v_x2_24178, 0);
        heff_take_n(v_x2_24178, 1ULL, 1);
        return heff_tail(v_f_24177, 1, (V[]){v_x_24180});
      }
      case TAG_Become: {
        V v_x_24181 = heff_field(v_x2_24178, 0);
        V v_ru_24x2_24178_24Become = heff_take_reuse_n(v_x2_24178, 1ULL, 1);
        V v_x1_24182 = heff_tr(heff_call(v_f_24177, 1, (V[]){v_x_24181}));
        V v_t_24186;
        switch (heff_tag_of(v_x1_24182)) {
        case TAG_Nom: {
          V v_x_24183 = heff_field(v_x1_24182, 0);
          heff_take_n(v_x1_24182, 1ULL, 1);
          v_t_24186 = v_x_24183;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24182, 0ULL, 1);
          v_t_24186 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24185 = heff_field(v_x1_24182, 0);
          heff_take_n(v_x1_24182, 1ULL, 1);
          v_t_24186 = v_x_24185;
          break;
        }
        default: heff_nomatch(v_x1_24182);
        }
        return heff_tag_at_n(v_ru_24x2_24178_24Become, TAG_Become, 1, (V[]){v_t_24186});
      }
      default: return heff_nomatch(v_x2_24178);
      }
    }
    case TAG_SSpecialize: {
      heff_drop(v_c_242);
      V v_f_24196 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam19, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24197 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24197)) {
      case TAG_Nom: {
        V v_x_24198 = heff_field(v_x2_24197, 0);
        heff_take_n(v_x2_24197, 1ULL, 1);
        return heff_tail(v_f_24196, 1, (V[]){v_x_24198});
      }
      case TAG_Describe: {
        V v_x_24199 = heff_field(v_x2_24197, 0);
        heff_take_n(v_x2_24197, 1ULL, 1);
        return heff_tail(v_f_24196, 1, (V[]){v_x_24199});
      }
      case TAG_Become: {
        V v_x_24200 = heff_field(v_x2_24197, 0);
        V v_ru_24x2_24197_24Become = heff_take_reuse_n(v_x2_24197, 1ULL, 1);
        V v_x1_24201 = heff_tr(heff_call(v_f_24196, 1, (V[]){v_x_24200}));
        V v_t_24205;
        switch (heff_tag_of(v_x1_24201)) {
        case TAG_Nom: {
          V v_x_24202 = heff_field(v_x1_24201, 0);
          heff_take_n(v_x1_24201, 1ULL, 1);
          v_t_24205 = v_x_24202;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24201, 0ULL, 1);
          v_t_24205 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24204 = heff_field(v_x1_24201, 0);
          heff_take_n(v_x1_24201, 1ULL, 1);
          v_t_24205 = v_x_24204;
          break;
        }
        default: heff_nomatch(v_x1_24201);
        }
        return heff_tag_at_n(v_ru_24x2_24197_24Become, TAG_Become, 1, (V[]){v_t_24205});
      }
      default: return heff_nomatch(v_x2_24197);
      }
    }
    case TAG_SIs: {
      heff_drop(v_c_242);
      V v_f_24213 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam21, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24214 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24214)) {
      case TAG_Nom: {
        V v_x_24215 = heff_field(v_x2_24214, 0);
        heff_take_n(v_x2_24214, 1ULL, 1);
        return heff_tail(v_f_24213, 1, (V[]){v_x_24215});
      }
      case TAG_Describe: {
        V v_x_24216 = heff_field(v_x2_24214, 0);
        heff_take_n(v_x2_24214, 1ULL, 1);
        return heff_tail(v_f_24213, 1, (V[]){v_x_24216});
      }
      case TAG_Become: {
        V v_x_24217 = heff_field(v_x2_24214, 0);
        V v_ru_24x2_24214_24Become = heff_take_reuse_n(v_x2_24214, 1ULL, 1);
        V v_x1_24218 = heff_tr(heff_call(v_f_24213, 1, (V[]){v_x_24217}));
        V v_t_24222;
        switch (heff_tag_of(v_x1_24218)) {
        case TAG_Nom: {
          V v_x_24219 = heff_field(v_x1_24218, 0);
          heff_take_n(v_x1_24218, 1ULL, 1);
          v_t_24222 = v_x_24219;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24218, 0ULL, 1);
          v_t_24222 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24221 = heff_field(v_x1_24218, 0);
          heff_take_n(v_x1_24218, 1ULL, 1);
          v_t_24222 = v_x_24221;
          break;
        }
        default: heff_nomatch(v_x1_24218);
        }
        return heff_tag_at_n(v_ru_24x2_24214_24Become, TAG_Become, 1, (V[]){v_t_24222});
      }
      default: return heff_nomatch(v_x2_24214);
      }
    }
    case TAG_SOpaque: {
      heff_drop(v_c_242);
      V v_f_24229 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam23, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24230 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24230)) {
      case TAG_Nom: {
        V v_x_24231 = heff_field(v_x2_24230, 0);
        heff_take_n(v_x2_24230, 1ULL, 1);
        return heff_tail(v_f_24229, 1, (V[]){v_x_24231});
      }
      case TAG_Describe: {
        V v_x_24232 = heff_field(v_x2_24230, 0);
        heff_take_n(v_x2_24230, 1ULL, 1);
        return heff_tail(v_f_24229, 1, (V[]){v_x_24232});
      }
      case TAG_Become: {
        V v_x_24233 = heff_field(v_x2_24230, 0);
        V v_ru_24x2_24230_24Become = heff_take_reuse_n(v_x2_24230, 1ULL, 1);
        V v_x1_24234 = heff_tr(heff_call(v_f_24229, 1, (V[]){v_x_24233}));
        V v_t_24238;
        switch (heff_tag_of(v_x1_24234)) {
        case TAG_Nom: {
          V v_x_24235 = heff_field(v_x1_24234, 0);
          heff_take_n(v_x1_24234, 1ULL, 1);
          v_t_24238 = v_x_24235;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24234, 0ULL, 1);
          v_t_24238 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24237 = heff_field(v_x1_24234, 0);
          heff_take_n(v_x1_24234, 1ULL, 1);
          v_t_24238 = v_x_24237;
          break;
        }
        default: heff_nomatch(v_x1_24234);
        }
        return heff_tag_at_n(v_ru_24x2_24230_24Become, TAG_Become, 1, (V[]){v_t_24238});
      }
      default: return heff_nomatch(v_x2_24230);
      }
    }
    case TAG_SAbandon: {
      heff_drop(v_c_242);
      V v_f_24245 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam25, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24246 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24246)) {
      case TAG_Nom: {
        V v_x_24247 = heff_field(v_x2_24246, 0);
        heff_take_n(v_x2_24246, 1ULL, 1);
        return heff_tail(v_f_24245, 1, (V[]){v_x_24247});
      }
      case TAG_Describe: {
        V v_x_24248 = heff_field(v_x2_24246, 0);
        heff_take_n(v_x2_24246, 1ULL, 1);
        return heff_tail(v_f_24245, 1, (V[]){v_x_24248});
      }
      case TAG_Become: {
        V v_x_24249 = heff_field(v_x2_24246, 0);
        V v_ru_24x2_24246_24Become = heff_take_reuse_n(v_x2_24246, 1ULL, 1);
        V v_x1_24250 = heff_tr(heff_call(v_f_24245, 1, (V[]){v_x_24249}));
        V v_t_24254;
        switch (heff_tag_of(v_x1_24250)) {
        case TAG_Nom: {
          V v_x_24251 = heff_field(v_x1_24250, 0);
          heff_take_n(v_x1_24250, 1ULL, 1);
          v_t_24254 = v_x_24251;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24250, 0ULL, 1);
          v_t_24254 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24253 = heff_field(v_x1_24250, 0);
          heff_take_n(v_x1_24250, 1ULL, 1);
          v_t_24254 = v_x_24253;
          break;
        }
        default: heff_nomatch(v_x1_24250);
        }
        return heff_tag_at_n(v_ru_24x2_24246_24Become, TAG_Become, 1, (V[]){v_t_24254});
      }
      default: return heff_nomatch(v_x2_24246);
      }
    }
    case TAG_SRec: {
      heff_drop(v_c_242);
      V v_f_24262 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam27, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24263 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24263)) {
      case TAG_Nom: {
        V v_x_24264 = heff_field(v_x2_24263, 0);
        heff_take_n(v_x2_24263, 1ULL, 1);
        return heff_tail(v_f_24262, 1, (V[]){v_x_24264});
      }
      case TAG_Describe: {
        V v_x_24265 = heff_field(v_x2_24263, 0);
        heff_take_n(v_x2_24263, 1ULL, 1);
        return heff_tail(v_f_24262, 1, (V[]){v_x_24265});
      }
      case TAG_Become: {
        V v_x_24266 = heff_field(v_x2_24263, 0);
        V v_ru_24x2_24263_24Become = heff_take_reuse_n(v_x2_24263, 1ULL, 1);
        V v_x1_24267 = heff_tr(heff_call(v_f_24262, 1, (V[]){v_x_24266}));
        V v_t_24271;
        switch (heff_tag_of(v_x1_24267)) {
        case TAG_Nom: {
          V v_x_24268 = heff_field(v_x1_24267, 0);
          heff_take_n(v_x1_24267, 1ULL, 1);
          v_t_24271 = v_x_24268;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24267, 0ULL, 1);
          v_t_24271 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24270 = heff_field(v_x1_24267, 0);
          heff_take_n(v_x1_24267, 1ULL, 1);
          v_t_24271 = v_x_24270;
          break;
        }
        default: heff_nomatch(v_x1_24267);
        }
        return heff_tag_at_n(v_ru_24x2_24263_24Become, TAG_Become, 1, (V[]){v_t_24271});
      }
      default: return heff_nomatch(v_x2_24263);
      }
    }
    case TAG_SFix: {
      heff_drop(v_c_242);
      V v_f_24280 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam29, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24281 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24281)) {
      case TAG_Nom: {
        V v_x_24282 = heff_field(v_x2_24281, 0);
        heff_take_n(v_x2_24281, 1ULL, 1);
        return heff_tail(v_f_24280, 1, (V[]){v_x_24282});
      }
      case TAG_Describe: {
        V v_x_24283 = heff_field(v_x2_24281, 0);
        heff_take_n(v_x2_24281, 1ULL, 1);
        return heff_tail(v_f_24280, 1, (V[]){v_x_24283});
      }
      case TAG_Become: {
        V v_x_24284 = heff_field(v_x2_24281, 0);
        V v_ru_24x2_24281_24Become = heff_take_reuse_n(v_x2_24281, 1ULL, 1);
        V v_x1_24285 = heff_tr(heff_call(v_f_24280, 1, (V[]){v_x_24284}));
        V v_t_24289;
        switch (heff_tag_of(v_x1_24285)) {
        case TAG_Nom: {
          V v_x_24286 = heff_field(v_x1_24285, 0);
          heff_take_n(v_x1_24285, 1ULL, 1);
          v_t_24289 = v_x_24286;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24285, 0ULL, 1);
          v_t_24289 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24288 = heff_field(v_x1_24285, 0);
          heff_take_n(v_x1_24285, 1ULL, 1);
          v_t_24289 = v_x_24288;
          break;
        }
        default: heff_nomatch(v_x1_24285);
        }
        return heff_tag_at_n(v_ru_24x2_24281_24Become, TAG_Become, 1, (V[]){v_t_24289});
      }
      default: return heff_nomatch(v_x2_24281);
      }
    }
    case TAG_SImplicit: {
      heff_drop(v_c_242);
      V v_f_24298 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam31, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24299 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24299)) {
      case TAG_Nom: {
        V v_x_24300 = heff_field(v_x2_24299, 0);
        heff_take_n(v_x2_24299, 1ULL, 1);
        return heff_tail(v_f_24298, 1, (V[]){v_x_24300});
      }
      case TAG_Describe: {
        V v_x_24301 = heff_field(v_x2_24299, 0);
        heff_take_n(v_x2_24299, 1ULL, 1);
        return heff_tail(v_f_24298, 1, (V[]){v_x_24301});
      }
      case TAG_Become: {
        V v_x_24302 = heff_field(v_x2_24299, 0);
        V v_ru_24x2_24299_24Become = heff_take_reuse_n(v_x2_24299, 1ULL, 1);
        V v_x1_24303 = heff_tr(heff_call(v_f_24298, 1, (V[]){v_x_24302}));
        V v_t_24307;
        switch (heff_tag_of(v_x1_24303)) {
        case TAG_Nom: {
          V v_x_24304 = heff_field(v_x1_24303, 0);
          heff_take_n(v_x1_24303, 1ULL, 1);
          v_t_24307 = v_x_24304;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24303, 0ULL, 1);
          v_t_24307 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24306 = heff_field(v_x1_24303, 0);
          heff_take_n(v_x1_24303, 1ULL, 1);
          v_t_24307 = v_x_24306;
          break;
        }
        default: heff_nomatch(v_x1_24303);
        }
        return heff_tag_at_n(v_ru_24x2_24299_24Become, TAG_Become, 1, (V[]){v_t_24307});
      }
      default: return heff_nomatch(v_x2_24299);
      }
    }
    case TAG_SPrim: {
      heff_drop(v_c_242);
      V v_f_24315 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam33, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24316 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24316)) {
      case TAG_Nom: {
        V v_x_24317 = heff_field(v_x2_24316, 0);
        heff_take_n(v_x2_24316, 1ULL, 1);
        return heff_tail(v_f_24315, 1, (V[]){v_x_24317});
      }
      case TAG_Describe: {
        V v_x_24318 = heff_field(v_x2_24316, 0);
        heff_take_n(v_x2_24316, 1ULL, 1);
        return heff_tail(v_f_24315, 1, (V[]){v_x_24318});
      }
      case TAG_Become: {
        V v_x_24319 = heff_field(v_x2_24316, 0);
        V v_ru_24x2_24316_24Become = heff_take_reuse_n(v_x2_24316, 1ULL, 1);
        V v_x1_24320 = heff_tr(heff_call(v_f_24315, 1, (V[]){v_x_24319}));
        V v_t_24324;
        switch (heff_tag_of(v_x1_24320)) {
        case TAG_Nom: {
          V v_x_24321 = heff_field(v_x1_24320, 0);
          heff_take_n(v_x1_24320, 1ULL, 1);
          v_t_24324 = v_x_24321;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24320, 0ULL, 1);
          v_t_24324 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24323 = heff_field(v_x1_24320, 0);
          heff_take_n(v_x1_24320, 1ULL, 1);
          v_t_24324 = v_x_24323;
          break;
        }
        default: heff_nomatch(v_x1_24320);
        }
        return heff_tag_at_n(v_ru_24x2_24316_24Become, TAG_Become, 1, (V[]){v_t_24324});
      }
      default: return heff_nomatch(v_x2_24316);
      }
    }
    case TAG_SMetaApp: {
      heff_drop(v_c_242);
      V v_f_24334 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam35, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24335 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24335)) {
      case TAG_Nom: {
        V v_x_24336 = heff_field(v_x2_24335, 0);
        heff_take_n(v_x2_24335, 1ULL, 1);
        return heff_tail(v_f_24334, 1, (V[]){v_x_24336});
      }
      case TAG_Describe: {
        V v_x_24337 = heff_field(v_x2_24335, 0);
        heff_take_n(v_x2_24335, 1ULL, 1);
        return heff_tail(v_f_24334, 1, (V[]){v_x_24337});
      }
      case TAG_Become: {
        V v_x_24338 = heff_field(v_x2_24335, 0);
        V v_ru_24x2_24335_24Become = heff_take_reuse_n(v_x2_24335, 1ULL, 1);
        V v_x1_24339 = heff_tr(heff_call(v_f_24334, 1, (V[]){v_x_24338}));
        V v_t_24343;
        switch (heff_tag_of(v_x1_24339)) {
        case TAG_Nom: {
          V v_x_24340 = heff_field(v_x1_24339, 0);
          heff_take_n(v_x1_24339, 1ULL, 1);
          v_t_24343 = v_x_24340;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24339, 0ULL, 1);
          v_t_24343 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24342 = heff_field(v_x1_24339, 0);
          heff_take_n(v_x1_24339, 1ULL, 1);
          v_t_24343 = v_x_24342;
          break;
        }
        default: heff_nomatch(v_x1_24339);
        }
        return heff_tag_at_n(v_ru_24x2_24335_24Become, TAG_Become, 1, (V[]){v_t_24343});
      }
      default: return heff_nomatch(v_x2_24335);
      }
    }
    case TAG_SLitInt: {
      heff_drop(v_c_242);
      V v_f_24351 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam37, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24352 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24352)) {
      case TAG_Nom: {
        V v_x_24353 = heff_field(v_x2_24352, 0);
        heff_take_n(v_x2_24352, 1ULL, 1);
        return heff_tail(v_f_24351, 1, (V[]){v_x_24353});
      }
      case TAG_Describe: {
        V v_x_24354 = heff_field(v_x2_24352, 0);
        heff_take_n(v_x2_24352, 1ULL, 1);
        return heff_tail(v_f_24351, 1, (V[]){v_x_24354});
      }
      case TAG_Become: {
        V v_x_24355 = heff_field(v_x2_24352, 0);
        V v_ru_24x2_24352_24Become = heff_take_reuse_n(v_x2_24352, 1ULL, 1);
        V v_x1_24356 = heff_tr(heff_call(v_f_24351, 1, (V[]){v_x_24355}));
        V v_t_24360;
        switch (heff_tag_of(v_x1_24356)) {
        case TAG_Nom: {
          V v_x_24357 = heff_field(v_x1_24356, 0);
          heff_take_n(v_x1_24356, 1ULL, 1);
          v_t_24360 = v_x_24357;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24356, 0ULL, 1);
          v_t_24360 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24359 = heff_field(v_x1_24356, 0);
          heff_take_n(v_x1_24356, 1ULL, 1);
          v_t_24360 = v_x_24359;
          break;
        }
        default: heff_nomatch(v_x1_24356);
        }
        return heff_tag_at_n(v_ru_24x2_24352_24Become, TAG_Become, 1, (V[]){v_t_24360});
      }
      default: return heff_nomatch(v_x2_24352);
      }
    }
    case TAG_SLitFloat: {
      heff_drop(v_c_242);
      V v_f_24368 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam39, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24369 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24369)) {
      case TAG_Nom: {
        V v_x_24370 = heff_field(v_x2_24369, 0);
        heff_take_n(v_x2_24369, 1ULL, 1);
        return heff_tail(v_f_24368, 1, (V[]){v_x_24370});
      }
      case TAG_Describe: {
        V v_x_24371 = heff_field(v_x2_24369, 0);
        heff_take_n(v_x2_24369, 1ULL, 1);
        return heff_tail(v_f_24368, 1, (V[]){v_x_24371});
      }
      case TAG_Become: {
        V v_x_24372 = heff_field(v_x2_24369, 0);
        V v_ru_24x2_24369_24Become = heff_take_reuse_n(v_x2_24369, 1ULL, 1);
        V v_x1_24373 = heff_tr(heff_call(v_f_24368, 1, (V[]){v_x_24372}));
        V v_t_24377;
        switch (heff_tag_of(v_x1_24373)) {
        case TAG_Nom: {
          V v_x_24374 = heff_field(v_x1_24373, 0);
          heff_take_n(v_x1_24373, 1ULL, 1);
          v_t_24377 = v_x_24374;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24373, 0ULL, 1);
          v_t_24377 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24376 = heff_field(v_x1_24373, 0);
          heff_take_n(v_x1_24373, 1ULL, 1);
          v_t_24377 = v_x_24376;
          break;
        }
        default: heff_nomatch(v_x1_24373);
        }
        return heff_tag_at_n(v_ru_24x2_24369_24Become, TAG_Become, 1, (V[]){v_t_24377});
      }
      default: return heff_nomatch(v_x2_24369);
      }
    }
    case TAG_SLitString: {
      heff_drop(v_c_242);
      V v_f_24385 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam41, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24386 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24386)) {
      case TAG_Nom: {
        V v_x_24387 = heff_field(v_x2_24386, 0);
        heff_take_n(v_x2_24386, 1ULL, 1);
        return heff_tail(v_f_24385, 1, (V[]){v_x_24387});
      }
      case TAG_Describe: {
        V v_x_24388 = heff_field(v_x2_24386, 0);
        heff_take_n(v_x2_24386, 1ULL, 1);
        return heff_tail(v_f_24385, 1, (V[]){v_x_24388});
      }
      case TAG_Become: {
        V v_x_24389 = heff_field(v_x2_24386, 0);
        V v_ru_24x2_24386_24Become = heff_take_reuse_n(v_x2_24386, 1ULL, 1);
        V v_x1_24390 = heff_tr(heff_call(v_f_24385, 1, (V[]){v_x_24389}));
        V v_t_24394;
        switch (heff_tag_of(v_x1_24390)) {
        case TAG_Nom: {
          V v_x_24391 = heff_field(v_x1_24390, 0);
          heff_take_n(v_x1_24390, 1ULL, 1);
          v_t_24394 = v_x_24391;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24390, 0ULL, 1);
          v_t_24394 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24393 = heff_field(v_x1_24390, 0);
          heff_take_n(v_x1_24390, 1ULL, 1);
          v_t_24394 = v_x_24393;
          break;
        }
        default: heff_nomatch(v_x1_24390);
        }
        return heff_tag_at_n(v_ru_24x2_24386_24Become, TAG_Become, 1, (V[]){v_t_24394});
      }
      default: return heff_nomatch(v_x2_24386);
      }
    }
    case TAG_SLitBytes: {
      heff_drop(v_c_242);
      V v_f_24402 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam43, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24403 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24403)) {
      case TAG_Nom: {
        V v_x_24404 = heff_field(v_x2_24403, 0);
        heff_take_n(v_x2_24403, 1ULL, 1);
        return heff_tail(v_f_24402, 1, (V[]){v_x_24404});
      }
      case TAG_Describe: {
        V v_x_24405 = heff_field(v_x2_24403, 0);
        heff_take_n(v_x2_24403, 1ULL, 1);
        return heff_tail(v_f_24402, 1, (V[]){v_x_24405});
      }
      case TAG_Become: {
        V v_x_24406 = heff_field(v_x2_24403, 0);
        V v_ru_24x2_24403_24Become = heff_take_reuse_n(v_x2_24403, 1ULL, 1);
        V v_x1_24407 = heff_tr(heff_call(v_f_24402, 1, (V[]){v_x_24406}));
        V v_t_24411;
        switch (heff_tag_of(v_x1_24407)) {
        case TAG_Nom: {
          V v_x_24408 = heff_field(v_x1_24407, 0);
          heff_take_n(v_x1_24407, 1ULL, 1);
          v_t_24411 = v_x_24408;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24407, 0ULL, 1);
          v_t_24411 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24410 = heff_field(v_x1_24407, 0);
          heff_take_n(v_x1_24407, 1ULL, 1);
          v_t_24411 = v_x_24410;
          break;
        }
        default: heff_nomatch(v_x1_24407);
        }
        return heff_tag_at_n(v_ru_24x2_24403_24Become, TAG_Become, 1, (V[]){v_t_24411});
      }
      default: return heff_nomatch(v_x2_24403);
      }
    }
    case TAG_SLitRune: {
      heff_drop(v_c_242);
      V v_f_24419 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam45, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24420 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24420)) {
      case TAG_Nom: {
        V v_x_24421 = heff_field(v_x2_24420, 0);
        heff_take_n(v_x2_24420, 1ULL, 1);
        return heff_tail(v_f_24419, 1, (V[]){v_x_24421});
      }
      case TAG_Describe: {
        V v_x_24422 = heff_field(v_x2_24420, 0);
        heff_take_n(v_x2_24420, 1ULL, 1);
        return heff_tail(v_f_24419, 1, (V[]){v_x_24422});
      }
      case TAG_Become: {
        V v_x_24423 = heff_field(v_x2_24420, 0);
        V v_ru_24x2_24420_24Become = heff_take_reuse_n(v_x2_24420, 1ULL, 1);
        V v_x1_24424 = heff_tr(heff_call(v_f_24419, 1, (V[]){v_x_24423}));
        V v_t_24428;
        switch (heff_tag_of(v_x1_24424)) {
        case TAG_Nom: {
          V v_x_24425 = heff_field(v_x1_24424, 0);
          heff_take_n(v_x1_24424, 1ULL, 1);
          v_t_24428 = v_x_24425;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24424, 0ULL, 1);
          v_t_24428 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24427 = heff_field(v_x1_24424, 0);
          heff_take_n(v_x1_24424, 1ULL, 1);
          v_t_24428 = v_x_24427;
          break;
        }
        default: heff_nomatch(v_x1_24424);
        }
        return heff_tag_at_n(v_ru_24x2_24420_24Become, TAG_Become, 1, (V[]){v_t_24428});
      }
      default: return heff_nomatch(v_x2_24420);
      }
    }
    case TAG_SLitFixed: {
      heff_drop(v_c_242);
      V v_f_24437 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam47, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24438 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24438)) {
      case TAG_Nom: {
        V v_x_24439 = heff_field(v_x2_24438, 0);
        heff_take_n(v_x2_24438, 1ULL, 1);
        return heff_tail(v_f_24437, 1, (V[]){v_x_24439});
      }
      case TAG_Describe: {
        V v_x_24440 = heff_field(v_x2_24438, 0);
        heff_take_n(v_x2_24438, 1ULL, 1);
        return heff_tail(v_f_24437, 1, (V[]){v_x_24440});
      }
      case TAG_Become: {
        V v_x_24441 = heff_field(v_x2_24438, 0);
        V v_ru_24x2_24438_24Become = heff_take_reuse_n(v_x2_24438, 1ULL, 1);
        V v_x1_24442 = heff_tr(heff_call(v_f_24437, 1, (V[]){v_x_24441}));
        V v_t_24446;
        switch (heff_tag_of(v_x1_24442)) {
        case TAG_Nom: {
          V v_x_24443 = heff_field(v_x1_24442, 0);
          heff_take_n(v_x1_24442, 1ULL, 1);
          v_t_24446 = v_x_24443;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24442, 0ULL, 1);
          v_t_24446 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24445 = heff_field(v_x1_24442, 0);
          heff_take_n(v_x1_24442, 1ULL, 1);
          v_t_24446 = v_x_24445;
          break;
        }
        default: heff_nomatch(v_x1_24442);
        }
        return heff_tag_at_n(v_ru_24x2_24438_24Become, TAG_Become, 1, (V[]){v_t_24446});
      }
      default: return heff_nomatch(v_x2_24438);
      }
    }
    case TAG_SLitFloat32: {
      heff_drop(v_c_242);
      V v_f_24454 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam49, 1, 4, (V[]){heff_dup(v_el_246), heff_dup(v_g_241), v_t1_2418, heff_dup(v_vs_244)});
      V v_x2_24455 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2417, v_vs_244}));
      switch (heff_tag_of(v_x2_24455)) {
      case TAG_Nom: {
        V v_x_24456 = heff_field(v_x2_24455, 0);
        heff_take_n(v_x2_24455, 1ULL, 1);
        return heff_tail(v_f_24454, 1, (V[]){v_x_24456});
      }
      case TAG_Describe: {
        V v_x_24457 = heff_field(v_x2_24455, 0);
        heff_take_n(v_x2_24455, 1ULL, 1);
        return heff_tail(v_f_24454, 1, (V[]){v_x_24457});
      }
      case TAG_Become: {
        V v_x_24458 = heff_field(v_x2_24455, 0);
        V v_ru_24x2_24455_24Become = heff_take_reuse_n(v_x2_24455, 1ULL, 1);
        V v_x1_24459 = heff_tr(heff_call(v_f_24454, 1, (V[]){v_x_24458}));
        V v_t_24463;
        switch (heff_tag_of(v_x1_24459)) {
        case TAG_Nom: {
          V v_x_24460 = heff_field(v_x1_24459, 0);
          heff_take_n(v_x1_24459, 1ULL, 1);
          v_t_24463 = v_x_24460;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24459, 0ULL, 1);
          v_t_24463 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24462 = heff_field(v_x1_24459, 0);
          heff_take_n(v_x1_24459, 1ULL, 1);
          v_t_24463 = v_x_24462;
          break;
        }
        default: heff_nomatch(v_x1_24459);
        }
        return heff_tag_at_n(v_ru_24x2_24455_24Become, TAG_Become, 1, (V[]){v_t_24463});
      }
      default: return heff_nomatch(v_x2_24455);
      }
    }
    default: return heff_nomatch(v_x41_2417);
    }
  }
  case TAG_SLam: {
    V v_dom_24464 = heff_field(v_x4_243, 0);
    V v_x42_24465 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24SLam = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x42_24465)) {
    case TAG_MkAbs: {
      V v_x_24466 = heff_field(v_x42_24465, 0);
      V v_t_24467 = heff_field(v_x42_24465, 1);
      heff_take_n(v_x42_24465, 3ULL, 2);
      V v_x_24474 = heff_tag_at_n(v_ru_24x4_243_24SLam, TAG_VLam, 2, (V[]){heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam51, 1, 4, (V[]){v_ty_245, heff_dup(v_g_241), v_dom_24464, heff_dup(v_vs_244)}), heff_tag_n(TAG_MkClo, 3, (V[]){v_x_24466, v_vs_244, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam52, 1, 4, (V[]){v_el_246, v_g_241, heff_dup(v_c_242), v_t_24467})})});
      switch (heff_tag_of(v_c_242)) {
      case TAG_N: {
        return heff_tag_n(TAG_Nom, 1, (V[]){v_x_24474});
      }
      case TAG_De: {
        return heff_tag_n(TAG_Describe, 1, (V[]){v_x_24474});
      }
      default: return heff_nomatch(v_c_242);
      }
    }
    case TAG_AbsConst: {
      V v_t_24475 = heff_field(v_x42_24465, 0);
      V v_ru_24x42_24465_24AbsConst = heff_take_reuse_n(v_x42_24465, 1ULL, 1);
      V v_t_24476 = heff_tr(heff_call(v_el_246, 4, (V[]){heff_dup(v_g_241), heff_dup(v_c_242), v_t_24475, heff_dup(v_vs_244)}));
      V v_x_24482 = heff_tag_at_n(v_ru_24x4_243_24SLam, TAG_VLam, 2, (V[]){heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam53, 1, 4, (V[]){v_ty_245, v_g_241, v_dom_24464, v_vs_244}), heff_tag_n(TAG_CloConst, 1, (V[]){v_t_24476})});
      switch (heff_tag_of(v_c_242)) {
      case TAG_N: {
        return heff_tag_at_n(v_ru_24x42_24465_24AbsConst, TAG_Nom, 1, (V[]){v_x_24482});
      }
      case TAG_De: {
        return heff_tag_at_n(v_ru_24x42_24465_24AbsConst, TAG_Describe, 1, (V[]){v_x_24482});
      }
      default: return heff_nomatch(v_c_242);
      }
    }
    default: return heff_nomatch(v_x42_24465);
    }
  }
  case TAG_SCons: {
    V v_fields_24483 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SCons = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_ty_245);
    V v_keys_24484 = heff_take_field(v_fields_24483, 0);
    V v_byName_24485 = heff_take_field(v_fields_24483, 1);
    V v_values_24486 = heff_get_n(v_fields_24483, 2, 3);
    V v_xs_24487 = v_values_24486;
    V v_t_24490 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_24487, 0), heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam54, 1, 5, (V[]){v_xs_24487, v_el_246, v_g_241, heff_dup(v_c_242), v_vs_244}));
    V v_x_24491 = heff_tag_at_n(v_ru_24x4_243_24SCons, TAG_VCons, 1, (V[]){heff_rec_n(3, shape_keys__byName__values, (V[]){v_keys_24484, v_byName_24485, v_t_24490})});
    switch (heff_tag_of(v_c_242)) {
    case TAG_N: {
      return heff_tag_n(TAG_Nom, 1, (V[]){v_x_24491});
    }
    case TAG_De: {
      return heff_tag_n(TAG_Describe, 1, (V[]){v_x_24491});
    }
    default: return heff_nomatch(v_c_242);
    }
  }
  case TAG_SProj: {
    V v_t_24492 = heff_field(v_x4_243, 0);
    V v_x_24493 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    heff_drop(v_c_242);
    heff_drop(v_ty_245);
    V v_f_24508 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam55, 1, 1, (V[]){v_x_24493});
    V v_x2_24509 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t_24492, v_vs_244}));
    switch (heff_tag_of(v_x2_24509)) {
    case TAG_Nom: {
      V v_x_24510 = heff_field(v_x2_24509, 0);
      heff_take_n(v_x2_24509, 1ULL, 1);
      return heff_tail(v_f_24508, 1, (V[]){v_x_24510});
    }
    case TAG_Describe: {
      V v_x_24511 = heff_field(v_x2_24509, 0);
      heff_take_n(v_x2_24509, 1ULL, 1);
      return heff_tail(v_f_24508, 1, (V[]){v_x_24511});
    }
    case TAG_Become: {
      V v_x_24512 = heff_field(v_x2_24509, 0);
      V v_ru_24x2_24509_24Become = heff_take_reuse_n(v_x2_24509, 1ULL, 1);
      V v_x1_24513 = heff_tr(heff_call(v_f_24508, 1, (V[]){v_x_24512}));
      V v_t_24517;
      switch (heff_tag_of(v_x1_24513)) {
      case TAG_Nom: {
        V v_x_24514 = heff_field(v_x1_24513, 0);
        heff_take_n(v_x1_24513, 1ULL, 1);
        v_t_24517 = v_x_24514;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_24513, 0ULL, 1);
        v_t_24517 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24516 = heff_field(v_x1_24513, 0);
        heff_take_n(v_x1_24513, 1ULL, 1);
        v_t_24517 = v_x_24516;
        break;
      }
      default: heff_nomatch(v_x1_24513);
      }
      return heff_tag_at_n(v_ru_24x2_24509_24Become, TAG_Become, 1, (V[]){v_t_24517});
    }
    default: return heff_nomatch(v_x2_24509);
    }
  }
  case TAG_STag: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_ty_245);
    heff_drop(v_el_246);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SMatch: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_ty_245);
    heff_drop(v_el_246);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SSpecialize: {
    V v_t_24522 = heff_field(v_x4_243, 0);
    V v_x_24523 = heff_field(v_x4_243, 1);
    V v_t_27_24524 = heff_field(v_x4_243, 2);
    V v_ru_24x4_243_24SSpecialize = heff_take_reuse_n(v_x4_243, 7ULL, 3);
    heff_drop(v_c_242);
    heff_drop(v_ty_245);
    V v_x1_24525 = heff_tr(heff_call(heff_dup(v_el_246), 4, (V[]){heff_dup(v_g_241), NTAG(TAG_N), v_t_24522, heff_dup(v_vs_244)}));
    V v_t_24529;
    switch (heff_tag_of(v_x1_24525)) {
    case TAG_Nom: {
      V v_x_24526 = heff_field(v_x1_24525, 0);
      heff_take_n(v_x1_24525, 1ULL, 1);
      v_t_24529 = v_x_24526;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24525, 0ULL, 1);
      v_t_24529 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24528 = heff_field(v_x1_24525, 0);
      heff_take_n(v_x1_24525, 1ULL, 1);
      v_t_24529 = v_x_24528;
      break;
    }
    default: heff_nomatch(v_x1_24525);
    }
    V v_x1_24530 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t_27_24524, v_vs_244}));
    V v_t_24534;
    switch (heff_tag_of(v_x1_24530)) {
    case TAG_Nom: {
      V v_x_24531 = heff_field(v_x1_24530, 0);
      heff_take_n(v_x1_24530, 1ULL, 1);
      v_t_24534 = v_x_24531;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24530, 0ULL, 1);
      v_t_24534 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24533 = heff_field(v_x1_24530, 0);
      heff_take_n(v_x1_24530, 1ULL, 1);
      v_t_24534 = v_x_24533;
      break;
    }
    default: heff_nomatch(v_x1_24530);
    }
    V v_t_24535 = (g_heff_2eelab_2evalue_2especialize_24tok3(v_ru_24x4_243_24SSpecialize, v_t_24529, v_x_24523, v_t_24534));
    return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24535});
  }
  case TAG_SIs: {
    V v_t_24536 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SIs = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    heff_drop(v_ty_245);
    V v_x1_24537 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t_24536, v_vs_244}));
    V v_t_24541;
    switch (heff_tag_of(v_x1_24537)) {
    case TAG_Nom: {
      V v_x_24538 = heff_field(v_x1_24537, 0);
      heff_take_n(v_x1_24537, 1ULL, 1);
      v_t_24541 = v_x_24538;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24537, 0ULL, 1);
      v_t_24541 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24540 = heff_field(v_x1_24537, 0);
      heff_take_n(v_x1_24537, 1ULL, 1);
      v_t_24541 = v_x_24540;
      break;
    }
    default: heff_nomatch(v_x1_24537);
    }
    return heff_tag_at_n(v_ru_24x4_243_24SIs, TAG_Become, 1, (V[]){v_t_24541});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_ty_245);
    heff_drop(v_el_246);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_ty_245);
    heff_drop(v_el_246);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SRec: {
    V v_ru_24x4_243_24SRec = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_ty_245);
    heff_drop(v_el_246);
    return heff_tag_at_n(v_ru_24x4_243_24SRec, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SFix: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_ty_245);
    heff_drop(v_el_246);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SImplicit: {
    V v_e_24546 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 2ULL, 2);
    heff_drop(v_ty_245);
    return heff_tail(v_el_246, 4, (V[]){v_g_241, v_c_242, v_e_24546, v_vs_244});
  }
  case TAG_SPrim: {
    V v_ru_24x4_243_24SPrim = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_ty_245);
    heff_drop(v_el_246);
    return heff_tag_at_n(v_ru_24x4_243_24SPrim, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SMetaApp: {
    V v_m_24548 = heff_field(v_x4_243, 0);
    V v_idxs_24549 = heff_field(v_x4_243, 1);
    V v_ty_24550 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    heff_drop(v_c_242);
    heff_drop(v_el_246);
    V v_sp_24554 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam56, 2, 1, (V[]){heff_dup(v_vs_244)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_SpId); V a_3 = v_idxs_24549; V r_ = (g_array_2efoldlFrom(a_0, a_1, a_2, a_3)); heff_drop(v_idxs_24549); r_; });
    V v_x1_24555 = heff_tr(heff_call(v_ty_245, 4, (V[]){v_g_241, NTAG(TAG_N), v_ty_24550, v_vs_244}));
    V v_ty_24559;
    switch (heff_tag_of(v_x1_24555)) {
    case TAG_Nom: {
      V v_x_24556 = heff_field(v_x1_24555, 0);
      heff_take_n(v_x1_24555, 1ULL, 1);
      v_ty_24559 = v_x_24556;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24555, 0ULL, 1);
      v_ty_24559 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24558 = heff_field(v_x1_24555, 0);
      heff_take_n(v_x1_24555, 1ULL, 1);
      v_ty_24559 = v_x_24558;
      break;
    }
    default: heff_nomatch(v_x1_24555);
    }
    V v_t_24562 = (g_heff_2eelab_2evalue_2ereflect(heff_tag_n(TAG_HMeta, 1, (V[]){v_m_24548}), heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam57, 1, 1, (V[]){v_sp_24554}), heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam58, 1, 1, (V[]){v_ty_24559}), NTAG(TAG_Nothing)));
    return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24562});
  }
  case TAG_SLitInt: {
    V v_ru_24x4_243_24SLitInt = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_ty_245);
    heff_drop(v_el_246);
    return heff_tag_at_n(v_ru_24x4_243_24SLitInt, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFloat: {
    V v_ru_24x4_243_24SLitFloat = heff_take_reuse_na(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_ty_245);
    heff_drop(v_el_246);
    return heff_tag_at_n(v_ru_24x4_243_24SLitFloat, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitString: {
    V v_ru_24x4_243_24SLitString = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_ty_245);
    heff_drop(v_el_246);
    return heff_tag_at_n(v_ru_24x4_243_24SLitString, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitBytes: {
    V v_ru_24x4_243_24SLitBytes = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_ty_245);
    heff_drop(v_el_246);
    return heff_tag_at_n(v_ru_24x4_243_24SLitBytes, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitRune: {
    V v_ru_24x4_243_24SLitRune = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_ty_245);
    heff_drop(v_el_246);
    return heff_tag_at_n(v_ru_24x4_243_24SLitRune, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_ty_245);
    heff_drop(v_el_246);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFloat32: {
    V v_ru_24x4_243_24SLitFloat32 = heff_take_reuse_na(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_ty_245);
    heff_drop(v_el_246);
    return heff_tag_at_n(v_ru_24x4_243_24SLitFloat32, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eeval_2eevalTermF(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eeval_2eevalTermF_lam1(V self, V *args) {
  V v_u_2421 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2421);
  V v_x1_2422 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Nom: {
    V v_x_2423 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    return v_x_2423;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2422, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2425 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    return v_x_2425;
  }
  default: return heff_nomatch(v_x1_2422);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam0(V self, V *args) {
  V v_f_2420 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2420, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam1, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam3(V self, V *args) {
  V v_u_2438 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2438);
  V v_x1_2439 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_2439)) {
  case TAG_Nom: {
    V v_x_2440 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    return v_x_2440;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2439, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2442 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    return v_x_2442;
  }
  default: return heff_nomatch(v_x1_2439);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam2(V self, V *args) {
  V v_f_2437 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2437, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam3, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam5(V self, V *args) {
  V v_u_2455 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2455);
  V v_x1_2456 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_2456)) {
  case TAG_Nom: {
    V v_x_2457 = heff_field(v_x1_2456, 0);
    heff_take_n(v_x1_2456, 1ULL, 1);
    return v_x_2457;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2456, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2459 = heff_field(v_x1_2456, 0);
    heff_take_n(v_x1_2456, 1ULL, 1);
    return v_x_2459;
  }
  default: return heff_nomatch(v_x1_2456);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam4(V self, V *args) {
  V v_f_2454 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2454, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam5, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam7(V self, V *args) {
  V v_u_2473 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2473);
  V v_x1_2474 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_2474)) {
  case TAG_Nom: {
    V v_x_2475 = heff_field(v_x1_2474, 0);
    heff_take_n(v_x1_2474, 1ULL, 1);
    return v_x_2475;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2474, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2477 = heff_field(v_x1_2474, 0);
    heff_take_n(v_x1_2474, 1ULL, 1);
    return v_x_2477;
  }
  default: return heff_nomatch(v_x1_2474);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam6(V self, V *args) {
  V v_f_2472 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2472, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam7, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam8(V self, V *args) {
  V v_u_2494 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2494);
  V v_x1_2495 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_2495)) {
  case TAG_Nom: {
    V v_x_2496 = heff_field(v_x1_2495, 0);
    heff_take_n(v_x1_2495, 1ULL, 1);
    return v_x_2496;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2495, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2498 = heff_field(v_x1_2495, 0);
    heff_take_n(v_x1_2495, 1ULL, 1);
    return v_x_2498;
  }
  default: return heff_nomatch(v_x1_2495);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam10(V self, V *args) {
  V v_u_24101 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24101);
  V v_x1_24102 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24102)) {
  case TAG_Nom: {
    V v_x_24103 = heff_field(v_x1_24102, 0);
    heff_take_n(v_x1_24102, 1ULL, 1);
    return v_x_24103;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24102, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24105 = heff_field(v_x1_24102, 0);
    heff_take_n(v_x1_24102, 1ULL, 1);
    return v_x_24105;
  }
  default: return heff_nomatch(v_x1_24102);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam9(V self, V *args) {
  V v_f_24100 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24100, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam10, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam12(V self, V *args) {
  V v_u_24118 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24118);
  V v_x1_24119 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24119)) {
  case TAG_Nom: {
    V v_x_24120 = heff_field(v_x1_24119, 0);
    heff_take_n(v_x1_24119, 1ULL, 1);
    return v_x_24120;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24119, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24122 = heff_field(v_x1_24119, 0);
    heff_take_n(v_x1_24119, 1ULL, 1);
    return v_x_24122;
  }
  default: return heff_nomatch(v_x1_24119);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam11(V self, V *args) {
  V v_f_24117 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24117, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam12, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam14(V self, V *args) {
  V v_u_24136 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24136);
  V v_x1_24137 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24137)) {
  case TAG_Nom: {
    V v_x_24138 = heff_field(v_x1_24137, 0);
    heff_take_n(v_x1_24137, 1ULL, 1);
    return v_x_24138;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24137, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24140 = heff_field(v_x1_24137, 0);
    heff_take_n(v_x1_24137, 1ULL, 1);
    return v_x_24140;
  }
  default: return heff_nomatch(v_x1_24137);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam13(V self, V *args) {
  V v_f_24135 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24135, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam14, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam16(V self, V *args) {
  V v_u_24154 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24154);
  V v_x1_24155 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24155)) {
  case TAG_Nom: {
    V v_x_24156 = heff_field(v_x1_24155, 0);
    heff_take_n(v_x1_24155, 1ULL, 1);
    return v_x_24156;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24155, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24158 = heff_field(v_x1_24155, 0);
    heff_take_n(v_x1_24155, 1ULL, 1);
    return v_x_24158;
  }
  default: return heff_nomatch(v_x1_24155);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam15(V self, V *args) {
  V v_f_24153 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24153, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam16, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam18(V self, V *args) {
  V v_u_24172 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24172);
  V v_x1_24173 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24173)) {
  case TAG_Nom: {
    V v_x_24174 = heff_field(v_x1_24173, 0);
    heff_take_n(v_x1_24173, 1ULL, 1);
    return v_x_24174;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24173, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24176 = heff_field(v_x1_24173, 0);
    heff_take_n(v_x1_24173, 1ULL, 1);
    return v_x_24176;
  }
  default: return heff_nomatch(v_x1_24173);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam17(V self, V *args) {
  V v_f_24171 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24171, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam18, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam20(V self, V *args) {
  V v_u_24191 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24191);
  V v_x1_24192 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24192)) {
  case TAG_Nom: {
    V v_x_24193 = heff_field(v_x1_24192, 0);
    heff_take_n(v_x1_24192, 1ULL, 1);
    return v_x_24193;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24192, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24195 = heff_field(v_x1_24192, 0);
    heff_take_n(v_x1_24192, 1ULL, 1);
    return v_x_24195;
  }
  default: return heff_nomatch(v_x1_24192);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam19(V self, V *args) {
  V v_f_24190 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24190, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam20, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam22(V self, V *args) {
  V v_u_24208 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24208);
  V v_x1_24209 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24209)) {
  case TAG_Nom: {
    V v_x_24210 = heff_field(v_x1_24209, 0);
    heff_take_n(v_x1_24209, 1ULL, 1);
    return v_x_24210;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24209, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24212 = heff_field(v_x1_24209, 0);
    heff_take_n(v_x1_24209, 1ULL, 1);
    return v_x_24212;
  }
  default: return heff_nomatch(v_x1_24209);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam21(V self, V *args) {
  V v_f_24207 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24207, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam22, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam24(V self, V *args) {
  V v_u_24224 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24224);
  V v_x1_24225 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24225)) {
  case TAG_Nom: {
    V v_x_24226 = heff_field(v_x1_24225, 0);
    heff_take_n(v_x1_24225, 1ULL, 1);
    return v_x_24226;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24225, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24228 = heff_field(v_x1_24225, 0);
    heff_take_n(v_x1_24225, 1ULL, 1);
    return v_x_24228;
  }
  default: return heff_nomatch(v_x1_24225);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam23(V self, V *args) {
  V v_f_24223 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24223, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam24, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam26(V self, V *args) {
  V v_u_24240 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24240);
  V v_x1_24241 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24241)) {
  case TAG_Nom: {
    V v_x_24242 = heff_field(v_x1_24241, 0);
    heff_take_n(v_x1_24241, 1ULL, 1);
    return v_x_24242;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24241, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24244 = heff_field(v_x1_24241, 0);
    heff_take_n(v_x1_24241, 1ULL, 1);
    return v_x_24244;
  }
  default: return heff_nomatch(v_x1_24241);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam25(V self, V *args) {
  V v_f_24239 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24239, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam26, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam28(V self, V *args) {
  V v_u_24257 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24257);
  V v_x1_24258 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24258)) {
  case TAG_Nom: {
    V v_x_24259 = heff_field(v_x1_24258, 0);
    heff_take_n(v_x1_24258, 1ULL, 1);
    return v_x_24259;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24258, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24261 = heff_field(v_x1_24258, 0);
    heff_take_n(v_x1_24258, 1ULL, 1);
    return v_x_24261;
  }
  default: return heff_nomatch(v_x1_24258);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam27(V self, V *args) {
  V v_f_24256 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24256, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam28, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam30(V self, V *args) {
  V v_u_24275 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24275);
  V v_x1_24276 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24276)) {
  case TAG_Nom: {
    V v_x_24277 = heff_field(v_x1_24276, 0);
    heff_take_n(v_x1_24276, 1ULL, 1);
    return v_x_24277;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24276, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24279 = heff_field(v_x1_24276, 0);
    heff_take_n(v_x1_24276, 1ULL, 1);
    return v_x_24279;
  }
  default: return heff_nomatch(v_x1_24276);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam29(V self, V *args) {
  V v_f_24274 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24274, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam30, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam32(V self, V *args) {
  V v_u_24293 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24293);
  V v_x1_24294 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24294)) {
  case TAG_Nom: {
    V v_x_24295 = heff_field(v_x1_24294, 0);
    heff_take_n(v_x1_24294, 1ULL, 1);
    return v_x_24295;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24294, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24297 = heff_field(v_x1_24294, 0);
    heff_take_n(v_x1_24294, 1ULL, 1);
    return v_x_24297;
  }
  default: return heff_nomatch(v_x1_24294);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam31(V self, V *args) {
  V v_f_24292 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24292, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam32, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam34(V self, V *args) {
  V v_u_24310 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24310);
  V v_x1_24311 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24311)) {
  case TAG_Nom: {
    V v_x_24312 = heff_field(v_x1_24311, 0);
    heff_take_n(v_x1_24311, 1ULL, 1);
    return v_x_24312;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24311, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24314 = heff_field(v_x1_24311, 0);
    heff_take_n(v_x1_24311, 1ULL, 1);
    return v_x_24314;
  }
  default: return heff_nomatch(v_x1_24311);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam33(V self, V *args) {
  V v_f_24309 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24309, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam34, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam36(V self, V *args) {
  V v_u_24329 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24329);
  V v_x1_24330 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24330)) {
  case TAG_Nom: {
    V v_x_24331 = heff_field(v_x1_24330, 0);
    heff_take_n(v_x1_24330, 1ULL, 1);
    return v_x_24331;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24330, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24333 = heff_field(v_x1_24330, 0);
    heff_take_n(v_x1_24330, 1ULL, 1);
    return v_x_24333;
  }
  default: return heff_nomatch(v_x1_24330);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam35(V self, V *args) {
  V v_f_24328 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24328, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam36, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam38(V self, V *args) {
  V v_u_24346 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24346);
  V v_x1_24347 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24347)) {
  case TAG_Nom: {
    V v_x_24348 = heff_field(v_x1_24347, 0);
    heff_take_n(v_x1_24347, 1ULL, 1);
    return v_x_24348;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24347, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24350 = heff_field(v_x1_24347, 0);
    heff_take_n(v_x1_24347, 1ULL, 1);
    return v_x_24350;
  }
  default: return heff_nomatch(v_x1_24347);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam37(V self, V *args) {
  V v_f_24345 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24345, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam38, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam40(V self, V *args) {
  V v_u_24363 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24363);
  V v_x1_24364 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24364)) {
  case TAG_Nom: {
    V v_x_24365 = heff_field(v_x1_24364, 0);
    heff_take_n(v_x1_24364, 1ULL, 1);
    return v_x_24365;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24364, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24367 = heff_field(v_x1_24364, 0);
    heff_take_n(v_x1_24364, 1ULL, 1);
    return v_x_24367;
  }
  default: return heff_nomatch(v_x1_24364);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam39(V self, V *args) {
  V v_f_24362 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24362, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam40, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam42(V self, V *args) {
  V v_u_24380 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24380);
  V v_x1_24381 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24381)) {
  case TAG_Nom: {
    V v_x_24382 = heff_field(v_x1_24381, 0);
    heff_take_n(v_x1_24381, 1ULL, 1);
    return v_x_24382;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24381, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24384 = heff_field(v_x1_24381, 0);
    heff_take_n(v_x1_24381, 1ULL, 1);
    return v_x_24384;
  }
  default: return heff_nomatch(v_x1_24381);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam41(V self, V *args) {
  V v_f_24379 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24379, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam42, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam44(V self, V *args) {
  V v_u_24397 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24397);
  V v_x1_24398 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24398)) {
  case TAG_Nom: {
    V v_x_24399 = heff_field(v_x1_24398, 0);
    heff_take_n(v_x1_24398, 1ULL, 1);
    return v_x_24399;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24398, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24401 = heff_field(v_x1_24398, 0);
    heff_take_n(v_x1_24398, 1ULL, 1);
    return v_x_24401;
  }
  default: return heff_nomatch(v_x1_24398);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam43(V self, V *args) {
  V v_f_24396 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24396, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam44, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam46(V self, V *args) {
  V v_u_24414 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24414);
  V v_x1_24415 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24415)) {
  case TAG_Nom: {
    V v_x_24416 = heff_field(v_x1_24415, 0);
    heff_take_n(v_x1_24415, 1ULL, 1);
    return v_x_24416;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24415, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24418 = heff_field(v_x1_24415, 0);
    heff_take_n(v_x1_24415, 1ULL, 1);
    return v_x_24418;
  }
  default: return heff_nomatch(v_x1_24415);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam45(V self, V *args) {
  V v_f_24413 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24413, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam46, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam48(V self, V *args) {
  V v_u_24432 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24432);
  V v_x1_24433 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24433)) {
  case TAG_Nom: {
    V v_x_24434 = heff_field(v_x1_24433, 0);
    heff_take_n(v_x1_24433, 1ULL, 1);
    return v_x_24434;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24433, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24436 = heff_field(v_x1_24433, 0);
    heff_take_n(v_x1_24433, 1ULL, 1);
    return v_x_24436;
  }
  default: return heff_nomatch(v_x1_24433);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam47(V self, V *args) {
  V v_f_24431 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24431, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam48, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam50(V self, V *args) {
  V v_u_24449 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24449);
  V v_x1_24450 = heff_tr(heff_call(v_el_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2418, v_vs_244}));
  switch (heff_tag_of(v_x1_24450)) {
  case TAG_Nom: {
    V v_x_24451 = heff_field(v_x1_24450, 0);
    heff_take_n(v_x1_24450, 1ULL, 1);
    return v_x_24451;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24450, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24453 = heff_field(v_x1_24450, 0);
    heff_take_n(v_x1_24450, 1ULL, 1);
    return v_x_24453;
  }
  default: return heff_nomatch(v_x1_24450);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam49(V self, V *args) {
  V v_f_24448 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2418 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24448, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam50, 1, 4, (V[]){v_el_246, v_g_241, v_t1_2418, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam51(V self, V *args) {
  V v_u_24468 = args[0];
  V v_ty_245 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_dom_24464 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24468);
  V v_x1_24469 = heff_tr(heff_call(v_ty_245, 4, (V[]){v_g_241, NTAG(TAG_N), v_dom_24464, v_vs_244}));
  switch (heff_tag_of(v_x1_24469)) {
  case TAG_Nom: {
    V v_x_24470 = heff_field(v_x1_24469, 0);
    heff_take_n(v_x1_24469, 1ULL, 1);
    return v_x_24470;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24469, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24472 = heff_field(v_x1_24469, 0);
    heff_take_n(v_x1_24469, 1ULL, 1);
    return v_x_24472;
  }
  default: return heff_nomatch(v_x1_24469);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam52(V self, V *args) {
  V v_vs2_24473 = args[0];
  V v_el_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_c_242 = heff_env(self)[2];
  V v_t_24467 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_el_246;
  heff_room[0] = v_g_241;
  heff_room[1] = v_c_242;
  heff_room[2] = v_t_24467;
  heff_room[3] = v_vs2_24473;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eeval_2eevalTermF_lam53(V self, V *args) {
  V v_u_24477 = args[0];
  V v_ty_245 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_dom_24464 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24477);
  V v_x1_24478 = heff_tr(heff_call(v_ty_245, 4, (V[]){v_g_241, NTAG(TAG_N), v_dom_24464, v_vs_244}));
  switch (heff_tag_of(v_x1_24478)) {
  case TAG_Nom: {
    V v_x_24479 = heff_field(v_x1_24478, 0);
    heff_take_n(v_x1_24478, 1ULL, 1);
    return v_x_24479;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24478, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24481 = heff_field(v_x1_24478, 0);
    heff_take_n(v_x1_24478, 1ULL, 1);
    return v_x_24481;
  }
  default: return heff_nomatch(v_x1_24478);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam54(V self, V *args) {
  V v_i_24488 = args[0];
  V v_xs_24487 = heff_env(self)[0];
  V v_el_246 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_c_242 = heff_env(self)[3];
  V v_vs_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24489 = heff_arrayIndex(v_xs_24487, v_i_24488);
  V f_ = v_el_246;
  heff_room[0] = v_g_241;
  heff_room[1] = v_c_242;
  heff_room[2] = v_t_24489;
  heff_room[3] = v_vs_244;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eeval_2eevalTermF_lam55(V self, V *args) {
  V v_v_24494 = args[0];
  V v_x_24493 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_v_24494)) {
  case TAG_VNeu: {
    V v_t_24500 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_24494));
    return ({ V a_0 = v_t_24500; V a_1 = v_x_24493; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_24493); r_; });
  }
  case TAG_VCode: {
    V v_t_24502 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_24494));
    return ({ V a_0 = v_t_24502; V a_1 = v_x_24493; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_24493); r_; });
  }
  case TAG_VLam: {
    V v_t_24505 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_24494));
    return ({ V a_0 = v_t_24505; V a_1 = v_x_24493; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_24493); r_; });
  }
  case TAG_VCons: {
    V v_t_24507 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_24494));
    return ({ V a_0 = v_t_24507; V a_1 = v_x_24493; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_24493); r_; });
  }
  case TAG_VOpaque: {
    heff_drop(v_x_24493);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_v_24494);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam56(V self, V *args) {
  V v_sp_24551 = args[0];
  V v_i_24552 = args[1];
  V v_vs_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24553 = ({ V a_0 = v_vs_244; V a_1 = v_i_24552; V r_ = heff_tr(g_heff_2eelab_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_vs_244); r_; });
  return heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_24551, v_t_24553});
}
V g_heff_2eelab_2eeval_2eevalTermF_lam57(V self, V *args) {
  V v_u_24560 = args[0];
  V v_sp_24554 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24560);
  return v_sp_24554;
}
V g_heff_2eelab_2eeval_2eevalTermF_lam58(V self, V *args) {
  V v_u_24561 = args[0];
  V v_ty_24559 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24561);
  return v_ty_24559;
}
Clo g_heff_2eelab_2eeval_2eerrorHeaded_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eerrorHeaded_entry, 1, 0};

V g_heff_2eelab_2eeval_2eerrorHeaded(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    return NTAG(TAG_False);
  }
  case TAG_SApp: {
    V v_t_244 = heff_field(v_x1_240, 0);
    V t_0 = v_t_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SLam: {
    return NTAG(TAG_False);
  }
  case TAG_SCons: {
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    V v_t_249 = heff_field(v_x1_240, 0);
    V t_0 = v_t_249;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_STag: {
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    V v_t_2415 = heff_field(v_x1_240, 0);
    V t_0 = v_t_2415;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SIs: {
    return NTAG(TAG_False);
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_True);
  }
  case TAG_SRec: {
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    return NTAG(TAG_False);
  }
  case TAG_SMetaApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLitInt: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    return NTAG(TAG_False);
  }
  case TAG_SLitBytes: {
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eeval_2eerrorHeaded_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eeval_2eerrorHeaded(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam0(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam0, 1, 0};
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam1(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam1, 1, 0};
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam7(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam5(V self, V *args);

HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24cpr(V v_r_240, V v_g_241, V v_c_242, V v_x4_243, V v_vs_244) {
top: ;
  V v_el_245 = heff_take_field(v_r_240, 0);
  V v_ty_246 = heff_get_n(v_r_240, 1, 2);
  switch (heff_tag_of(v_x4_243)) {
  case TAG_SU: {
    V v_u_247 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SU = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_el_245);
    heff_drop(v_ty_246);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_at_n(v_ru_24x4_243_24SU, TAG_VU, 1, (V[]){v_u_247})}});
  }
  case TAG_SDecode: {
    V v_t_248 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    heff_drop(v_ty_246);
    V v_t_249 = (g_heff_2eelab_2eeval_2eerrorHeaded(v_t_248));
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_g_241);
      heff_drop(v_c_242);
      heff_drop(v_vs_244);
      heff_drop(v_el_245);
      heff_drop(v_t_248);
      heff_drop(v_t_249);
      V v_t_2412 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam0_clo), ((V)&g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam1_clo)});
      return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_2412}});
    } else {
      heff_drop(v_t_249);
      V v_t_2413 = heff_tr(heff_call(v_el_245, 4, (V[]){v_g_241, v_c_242, v_t_248, v_vs_244}));
      return ({ V a_0 = v_t_2413; HeffT2 r_ = (g_heff_2eelab_2evalue_2edecodeEv_24cpr(a_0)); heff_drop(v_t_2413); r_; });
    }
  }
  case TAG_SFunction: {
    V v_level_2414 = heff_field(v_x4_243, 0);
    V v_dom_2415 = heff_field(v_x4_243, 1);
    V v_cod_2416 = heff_field(v_x4_243, 2);
    V v_implicit_2417 = heff_field(v_x4_243, 3);
    V v_dflt_2418 = heff_field(v_x4_243, 4);
    heff_take_n(v_x4_243, 31ULL, 5);
    heff_drop(v_c_242);
    heff_drop(v_el_245);
    V v_x1_2419 = heff_tr(heff_call(heff_dup(v_ty_246), 4, (V[]){heff_dup(v_g_241), NTAG(TAG_N), v_dom_2415, heff_dup(v_vs_244)}));
    V v_t_2423;
    switch (heff_tag_of(v_x1_2419)) {
    case TAG_Nom: {
      V v_x_2420 = heff_field(v_x1_2419, 0);
      heff_take_n(v_x1_2419, 1ULL, 1);
      v_t_2423 = v_x_2420;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2419, 0ULL, 1);
      v_t_2423 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2422 = heff_field(v_x1_2419, 0);
      heff_take_n(v_x1_2419, 1ULL, 1);
      v_t_2423 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x1_2419);
    }
    V v_t_2429;
    switch (heff_tag_of(v_cod_2416)) {
    case TAG_MkAbs: {
      V v_x_2424 = heff_field(v_cod_2416, 0);
      V v_t_2425 = heff_field(v_cod_2416, 1);
      heff_take_n(v_cod_2416, 3ULL, 2);
      v_t_2429 = heff_tag_n(TAG_MkClo, 3, (V[]){v_x_2424, v_vs_244, heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam2, 1, 3, (V[]){v_ty_246, v_g_241, v_t_2425})});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2427 = heff_field(v_cod_2416, 0);
      V v_ru_24cod_2416_24AbsConst = heff_take_reuse_n(v_cod_2416, 1ULL, 1);
      V v_t_2428 = heff_tr(heff_call(v_ty_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2427, v_vs_244}));
      v_t_2429 = heff_tag_at_n(v_ru_24cod_2416_24AbsConst, TAG_CloConst, 1, (V[]){v_t_2428});
      break;
    }
    default: heff_nomatch(v_cod_2416);
    }
    V v_f_2430 = heff_tag_n(TAG_VFunction, 6, (V[]){v_level_2414, v_t_2423, v_t_2429, v_implicit_2417, v_dflt_2418, NTAG(TAG_Nothing)});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_f_2430}});
  }
  case TAG_SRecord: {
    V v_level_2431 = heff_field(v_x4_243, 0);
    V v_fieldTypes_2432 = heff_field(v_x4_243, 1);
    V v_defaults_2433 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    heff_drop(v_c_242);
    heff_drop(v_el_245);
    V v_keys_2434 = heff_take_field(v_fieldTypes_2432, 0);
    V v_byName_2435 = heff_take_field(v_fieldTypes_2432, 1);
    V v_values_2436 = heff_get_n(v_fieldTypes_2432, 2, 3);
    V v_xs_2437 = v_values_2436;
    V v_t_2446 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2437, 0), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam3, 1, 3, (V[]){v_xs_2437, v_ty_246, v_g_241}));
    V v_f_2447 = heff_tag_n(TAG_VRecord, 4, (V[]){v_level_2431, v_vs_244, heff_rec_n(3, shape_keys__byName__values, (V[]){v_keys_2434, v_byName_2435, v_t_2446}), v_defaults_2433});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2447}});
  }
  case TAG_SSum: {
    V v_st_2448 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SSum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    heff_drop(v_el_245);
    V v_keys_2449 = heff_take_field(v_st_2448, 0);
    V v_byName_2450 = heff_take_field(v_st_2448, 1);
    V v_values_2451 = heff_get_n(v_st_2448, 2, 3);
    V v_xs_2452 = v_values_2451;
    V v_t_2462 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2452, 0), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam5, 1, 4, (V[]){v_xs_2452, v_ty_246, v_g_241, v_vs_244}));
    V v_f_2463 = heff_tag_at_n(v_ru_24x4_243_24SSum, TAG_VSum, 1, (V[]){heff_rec_n(3, shape_keys__byName__values, (V[]){v_keys_2449, v_byName_2450, v_t_2462})});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2463}});
  }
  case TAG_SIsTy: {
    V v_t_2464 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    heff_drop(v_el_245);
    V v_x1_2465 = heff_tr(heff_call(v_ty_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2464, v_vs_244}));
    V v_f_2469;
    switch (heff_tag_of(v_x1_2465)) {
    case TAG_Nom: {
      V v_x_2466 = heff_field(v_x1_2465, 0);
      heff_take_n(v_x1_2465, 1ULL, 1);
      v_f_2469 = v_x_2466;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2465, 0ULL, 1);
      v_f_2469 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2468 = heff_field(v_x1_2465, 0);
      heff_take_n(v_x1_2465, 1ULL, 1);
      v_f_2469 = v_x_2468;
      break;
    }
    default: heff_nomatch(v_x1_2465);
    }
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2469}});
  }
  case TAG_SPrimInt: {
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_el_245);
    heff_drop(v_ty_246);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimInt)}});
  }
  case TAG_SPrimFloat: {
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_el_245);
    heff_drop(v_ty_246);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimFloat)}});
  }
  case TAG_SPrimString: {
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_el_245);
    heff_drop(v_ty_246);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimString)}});
  }
  case TAG_SPrimRune: {
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_el_245);
    heff_drop(v_ty_246);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimRune)}});
  }
  case TAG_SPrimArray: {
    V v_a_2470 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SPrimArray = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    heff_drop(v_el_245);
    V v_x1_2471 = heff_tr(heff_call(v_ty_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_a_2470, v_vs_244}));
    V v_t_2475;
    switch (heff_tag_of(v_x1_2471)) {
    case TAG_Nom: {
      V v_x_2472 = heff_field(v_x1_2471, 0);
      heff_take_n(v_x1_2471, 1ULL, 1);
      v_t_2475 = v_x_2472;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2471, 0ULL, 1);
      v_t_2475 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2474 = heff_field(v_x1_2471, 0);
      heff_take_n(v_x1_2471, 1ULL, 1);
      v_t_2475 = v_x_2474;
      break;
    }
    default: heff_nomatch(v_x1_2471);
    }
    V v_f_2476 = heff_tag_at_n(v_ru_24x4_243_24SPrimArray, TAG_VPrimArray, 1, (V[]){v_t_2475});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_f_2476}});
  }
  case TAG_SFixed: {
    V v_w_2477 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SFixed = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    heff_drop(v_el_245);
    heff_drop(v_ty_246);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_at_n(v_ru_24x4_243_24SFixed, TAG_VFixed, 1, (V[]){v_w_2477})}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  heff_drop(v_x_2410);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  heff_drop(v_x_2411);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam2(V self, V *args) {
  V v_vs2_2426 = args[0];
  V v_ty_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t_2425 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_ty_246;
  heff_room[0] = v_g_241;
  heff_room[1] = NTAG(TAG_N);
  heff_room[2] = v_t_2425;
  heff_room[3] = v_vs2_2426;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam4(V self, V *args) {
  V v_vs2_2440 = args[0];
  V v_ty_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t_2439 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_2441 = heff_tr(heff_call(v_ty_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2439, v_vs2_2440}));
  V v_t_2445;
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_Nom: {
    V v_x_2442 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_t_2445 = v_x_2442;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2441, 0ULL, 1);
    v_t_2445 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2444 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_t_2445 = v_x_2444;
    break;
  }
  default: heff_nomatch(v_x1_2441);
  }
  return heff_tag_n(TAG_MkField, 2, (V[]){v_t_2445, NTAG(TAG_Nothing)});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam3(V self, V *args) {
  V v_i_2438 = args[0];
  V v_xs_2437 = heff_env(self)[0];
  V v_ty_246 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2439 = heff_arrayIndex(v_xs_2437, v_i_2438);
  return heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam4, 1, 3, (V[]){v_ty_246, v_g_241, v_t_2439});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam7(V self, V *args) {
  V v_u_2457 = args[0];
  V v_ty_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t_2456 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2457);
  V v_x1_2458 = heff_tr(heff_call(v_ty_246, 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2456, v_vs_244}));
  switch (heff_tag_of(v_x1_2458)) {
  case TAG_Nom: {
    V v_x_2459 = heff_field(v_x1_2458, 0);
    heff_take_n(v_x1_2458, 1ULL, 1);
    return v_x_2459;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2458, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2461 = heff_field(v_x1_2458, 0);
    heff_take_n(v_x1_2458, 1ULL, 1);
    return v_x_2461;
  }
  default: return heff_nomatch(v_x1_2458);
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam6(V self, V *args) {
  V v_i_2455 = args[0];
  V v_xs_2454 = heff_env(self)[0];
  V v_ty_246 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2456 = heff_arrayIndex(v_xs_2454, v_i_2455);
  return heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam7, 1, 4, (V[]){v_ty_246, v_g_241, v_t_2456, v_vs_244});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam5(V self, V *args) {
  V v_i_2453 = args[0];
  V v_xs_2452 = heff_env(self)[0];
  V v_ty_246 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_xs_2454 = heff_arrayIndex(v_xs_2452, v_i_2453);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_2454, 0), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam6, 1, 4, (V[]){v_xs_2454, v_ty_246, v_g_241, v_vs_244}));
}
Clo g_heff_2eelab_2eeval_2eevalTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_entry, 5, 0};

V g_heff_2eelab_2eeval_2eevalTypeF(V v_r_240, V v_g_241, V v_c_242, V v_x4_243, V v_vs_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2eelab_2eeval_2eevalTypeF_24cpr(v_r_240, v_g_241, v_c_242, v_x4_243, v_vs_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Become, 1, (V[]){v_field_247});
    } else {
      if ((v_tag_246 == ((int64_t)1ULL))) {
        return heff_tag_n(TAG_Describe, 1, (V[]){v_field_247});
      } else {
        return heff_tag_n(TAG_Nom, 1, (V[]){v_field_247});
      }
    }
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eeval_2eevalTypeF(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eeval_2eevaluator_lam0(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevaluator_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevaluator_lam0, 4, 0};
V g_heff_2eelab_2eeval_2eevaluator_lam1(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevaluator_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevaluator_lam1, 4, 0};

static V g_heff_2eelab_2eeval_2eevaluator_val;
static HEFF_ONCE g_heff_2eelab_2eeval_2eevaluator_st;
static V g_heff_2eelab_2eeval_2eevaluator_init(void) {
  return heff_rec_n(2, shape_el__ty, (V[]){((V)&g_heff_2eelab_2eeval_2eevaluator_lam0_clo), ((V)&g_heff_2eelab_2eeval_2eevaluator_lam1_clo)});
}
V g_heff_2eelab_2eeval_2eevaluator_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eeval_2eevaluator_st)) return g_heff_2eelab_2eeval_2eevaluator_val;
  return heff_global(&g_heff_2eelab_2eeval_2eevaluator_val, &g_heff_2eelab_2eeval_2eevaluator_st, g_heff_2eelab_2eeval_2eevaluator_init);
}
V g_heff_2eelab_2eeval_2eevaluator_lam0(V self, V *args) {
  V v_g_240 = args[0];
  V v_c_241 = args[1];
  V v_s_242 = args[2];
  V v_vs_243 = args[3];
  return (g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, v_c_241, v_s_242, v_vs_243));
}
V g_heff_2eelab_2eeval_2eevaluator_lam1(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_s_246 = args[2];
  V v_vs_247 = args[3];
  return (g_heff_2eelab_2eeval_2eevalTypeF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_244, v_c_245, v_s_246, v_vs_247));
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam0(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam0, 1, 0};
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam1(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam1, 1, 0};
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam7(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam5(V self, V *args);

HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V v_g_240, V v_c_241, V v_x4_242, V v_vs_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SU: {
    V v_u_244 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SU = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_at_n(v_ru_24x4_242_24SU, TAG_VU, 1, (V[]){v_u_244})}});
  }
  case TAG_SDecode: {
    V v_t_245 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    V v_t_246 = (g_heff_2eelab_2eeval_2eerrorHeaded(v_t_245));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_g_240);
      heff_drop(v_c_241);
      heff_drop(v_vs_243);
      heff_drop(v_t_245);
      heff_drop(v_t_246);
      V v_t_249 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam0_clo), ((V)&g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam1_clo)});
      return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_249}});
    } else {
      heff_drop(v_t_246);
      V v_t_2410 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, v_c_241, v_t_245, v_vs_243));
      return ({ V a_0 = v_t_2410; HeffT2 r_ = (g_heff_2eelab_2evalue_2edecodeEv_24cpr(a_0)); heff_drop(v_t_2410); r_; });
    }
  }
  case TAG_SFunction: {
    V v_level_2411 = heff_field(v_x4_242, 0);
    V v_dom_2412 = heff_field(v_x4_242, 1);
    V v_cod_2413 = heff_field(v_x4_242, 2);
    V v_implicit_2414 = heff_field(v_x4_242, 3);
    V v_dflt_2415 = heff_field(v_x4_242, 4);
    heff_take_n(v_x4_242, 31ULL, 5);
    heff_drop(v_c_241);
    HeffT2 v_t_2416 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(v_g_240), NTAG(TAG_N), v_dom_2412, heff_dup(v_vs_243)));
    V v_t_2422;
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        V v_x_2419 = v_field_2418;
        v_t_2422 = v_x_2419;
      } else {
        if ((v_tag_2417 == ((int64_t)1ULL))) {
          V v_x11_2420 = v_field_2418;
          heff_drop(v_x11_2420);
          v_t_2422 = heff_abandon();
        } else {
          V v_x_2421 = v_field_2418;
          v_t_2422 = v_x_2421;
        }
      }
    }
    V v_t_2428;
    switch (heff_tag_of(v_cod_2413)) {
    case TAG_MkAbs: {
      V v_x_2423 = heff_field(v_cod_2413, 0);
      V v_t_2424 = heff_field(v_cod_2413, 1);
      heff_take_n(v_cod_2413, 3ULL, 2);
      v_t_2428 = heff_tag_n(TAG_MkClo, 3, (V[]){v_x_2423, v_vs_243, heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam2, 1, 2, (V[]){v_g_240, v_t_2424})});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2426 = heff_field(v_cod_2413, 0);
      V v_ru_24cod_2413_24AbsConst = heff_take_reuse_n(v_cod_2413, 1ULL, 1);
      V v_t_2427 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_t_2426, v_vs_243));
      v_t_2428 = heff_tag_at_n(v_ru_24cod_2413_24AbsConst, TAG_CloConst, 1, (V[]){v_t_2427});
      break;
    }
    default: heff_nomatch(v_cod_2413);
    }
    V v_f_2429 = heff_tag_n(TAG_VFunction, 6, (V[]){v_level_2411, v_t_2422, v_t_2428, v_implicit_2414, v_dflt_2415, NTAG(TAG_Nothing)});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_f_2429}});
  }
  case TAG_SRecord: {
    V v_level_2430 = heff_field(v_x4_242, 0);
    V v_fieldTypes_2431 = heff_field(v_x4_242, 1);
    V v_defaults_2432 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    heff_drop(v_c_241);
    V v_keys_2433 = heff_take_field(v_fieldTypes_2431, 0);
    V v_byName_2434 = heff_take_field(v_fieldTypes_2431, 1);
    V v_values_2435 = heff_get_n(v_fieldTypes_2431, 2, 3);
    V v_xs_2436 = v_values_2435;
    V v_t_2447 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2436, 0), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam3, 1, 2, (V[]){v_xs_2436, v_g_240}));
    V v_f_2448 = heff_tag_n(TAG_VRecord, 4, (V[]){v_level_2430, v_vs_243, heff_rec_n(3, shape_keys__byName__values, (V[]){v_keys_2433, v_byName_2434, v_t_2447}), v_defaults_2432});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2448}});
  }
  case TAG_SSum: {
    V v_st_2449 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SSum = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    V v_keys_2450 = heff_take_field(v_st_2449, 0);
    V v_byName_2451 = heff_take_field(v_st_2449, 1);
    V v_values_2452 = heff_get_n(v_st_2449, 2, 3);
    V v_xs_2453 = v_values_2452;
    V v_t_2465 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2453, 0), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam5, 1, 3, (V[]){v_xs_2453, v_g_240, v_vs_243}));
    V v_f_2466 = heff_tag_at_n(v_ru_24x4_242_24SSum, TAG_VSum, 1, (V[]){heff_rec_n(3, shape_keys__byName__values, (V[]){v_keys_2450, v_byName_2451, v_t_2465})});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2466}});
  }
  case TAG_SIsTy: {
    V v_t_2467 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    HeffT2 v_t_2468 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), v_t_2467, v_vs_243));
    V v_f_2474;
    {
      V v_field_2470 = v_t_2468.f[1];
      int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
      if ((v_tag_2469 == ((int64_t)0ULL))) {
        V v_x_2471 = v_field_2470;
        v_f_2474 = v_x_2471;
      } else {
        if ((v_tag_2469 == ((int64_t)1ULL))) {
          V v_x11_2472 = v_field_2470;
          heff_drop(v_x11_2472);
          v_f_2474 = heff_abandon();
        } else {
          V v_x_2473 = v_field_2470;
          v_f_2474 = v_x_2473;
        }
      }
    }
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2474}});
  }
  case TAG_SPrimInt: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimInt)}});
  }
  case TAG_SPrimFloat: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimFloat)}});
  }
  case TAG_SPrimString: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimString)}});
  }
  case TAG_SPrimRune: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimRune)}});
  }
  case TAG_SPrimArray: {
    V v_a_2475 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SPrimArray = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    HeffT2 v_t_2476 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), v_a_2475, v_vs_243));
    V v_t_2482;
    {
      V v_field_2478 = v_t_2476.f[1];
      int64_t v_tag_2477 = ((int64_t)v_t_2476.f[0]);
      if ((v_tag_2477 == ((int64_t)0ULL))) {
        V v_x_2479 = v_field_2478;
        v_t_2482 = v_x_2479;
      } else {
        if ((v_tag_2477 == ((int64_t)1ULL))) {
          V v_x11_2480 = v_field_2478;
          heff_drop(v_x11_2480);
          v_t_2482 = heff_abandon();
        } else {
          V v_x_2481 = v_field_2478;
          v_t_2482 = v_x_2481;
        }
      }
    }
    V v_f_2483 = heff_tag_at_n(v_ru_24x4_242_24SPrimArray, TAG_VPrimArray, 1, (V[]){v_t_2482});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_f_2483}});
  }
  case TAG_SFixed: {
    V v_w_2484 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SFixed = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_at_n(v_ru_24x4_242_24SFixed, TAG_VFixed, 1, (V[]){v_w_2484})}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam0(V self, V *args) {
  V v_x_247 = args[0];
  heff_drop(v_x_247);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam1(V self, V *args) {
  V v_x_248 = args[0];
  heff_drop(v_x_248);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam2(V self, V *args) {
  V v_vs2_2425 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_t_2424, v_vs2_2425));
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam4(V self, V *args) {
  V v_vs2_2439 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2438 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2440 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), v_t_2438, v_vs2_2439));
  V v_t_2446;
  {
    V v_field_2442 = v_t_2440.f[1];
    int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
    if ((v_tag_2441 == ((int64_t)0ULL))) {
      V v_x_2443 = v_field_2442;
      v_t_2446 = v_x_2443;
    } else {
      if ((v_tag_2441 == ((int64_t)1ULL))) {
        V v_x11_2444 = v_field_2442;
        heff_drop(v_x11_2444);
        v_t_2446 = heff_abandon();
      } else {
        V v_x_2445 = v_field_2442;
        v_t_2446 = v_x_2445;
      }
    }
  }
  return heff_tag_n(TAG_MkField, 2, (V[]){v_t_2446, NTAG(TAG_Nothing)});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam3(V self, V *args) {
  V v_i_2437 = args[0];
  V v_xs_2436 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2438 = heff_arrayIndex(v_xs_2436, v_i_2437);
  return heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam4, 1, 2, (V[]){v_g_240, v_t_2438});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam7(V self, V *args) {
  V v_u_2458 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2457 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2458);
  HeffT2 v_t_2459 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), v_t_2457, v_vs_243));
  {
    V v_field_2461 = v_t_2459.f[1];
    int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
    if ((v_tag_2460 == ((int64_t)0ULL))) {
      V v_x_2462 = v_field_2461;
      return v_x_2462;
    } else {
      if ((v_tag_2460 == ((int64_t)1ULL))) {
        V v_x11_2463 = v_field_2461;
        heff_drop(v_x11_2463);
        return heff_abandon();
      } else {
        V v_x_2464 = v_field_2461;
        return v_x_2464;
      }
    }
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam6(V self, V *args) {
  V v_i_2456 = args[0];
  V v_xs_2455 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2457 = heff_arrayIndex(v_xs_2455, v_i_2456);
  return heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam7, 1, 3, (V[]){v_g_240, v_t_2457, v_vs_243});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam5(V self, V *args) {
  V v_i_2454 = args[0];
  V v_xs_2453 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_xs_2455 = heff_arrayIndex(v_xs_2453, v_i_2454);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_2455, 0), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam6, 1, 3, (V[]){v_xs_2455, v_g_240, v_vs_243}));
}
Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry, 4, 0};

V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V v_g_240, V v_c_241, V v_x4_242, V v_vs_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, v_c_241, v_x4_242, v_vs_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Become, 1, (V[]){v_field_246});
    } else {
      if ((v_tag_245 == ((int64_t)1ULL))) {
        return heff_tag_n(TAG_Describe, 1, (V[]){v_field_246});
      } else {
        return heff_tag_n(TAG_Nom, 1, (V[]){v_field_246});
      }
    }
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(a[0], a[1], a[2], a[3]);
}