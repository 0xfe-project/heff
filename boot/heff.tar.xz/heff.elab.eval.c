// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_HMeta 17321
#define TAG_LSnoc 32613
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_entries 787768015
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_value 313331083
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_array_2efoldlFrom(V, V, V, V);
V g_array_2efoldlFrom_entry(V self, V *a);
extern Clo g_array_2efoldlFrom_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevalTypeF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo;
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2edecodeN(V);
V g_heff_2eelab_2evalue_2edecodeN_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeN_clo;
V g_heff_2eelab_2evalue_2eemap_24s196957333x715530534(V);
V g_heff_2eelab_2evalue_2eemap_24s196957333x715530534_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eemap_24s196957333x715530534_clo;
V g_heff_2eelab_2evalue_2elocalsAt(V, V);
V g_heff_2eelab_2evalue_2elocalsAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elocalsAt_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2eproj(V, V);
V g_heff_2eelab_2evalue_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eproj_clo;
V g_heff_2eelab_2evalue_2especialize(V, V, V);
V g_heff_2eelab_2evalue_2especialize_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2especialize_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_heff_2eelab_2eeval_2eevalTermF_lam1(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam0(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam3(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam2(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam5(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam4(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam7(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam6(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam8(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam10(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam9(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam12(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam11(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam14(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam13(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam16(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam15(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam18(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam17(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam20(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam19(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam22(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam21(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam24(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam23(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam26(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam25(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam28(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam27(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam30(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam29(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam32(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam31(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam34(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam33(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam36(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam35(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam38(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam37(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam40(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam39(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam42(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam41(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam44(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam43(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam46(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam45(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam48(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam47(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam50(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam49(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam51(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam52(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam53(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam54(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam55(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam56(V self, V *args);
Clo g_heff_2eelab_2eeval_2eevalTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTermF_entry, 5, 0};

V g_heff_2eelab_2eeval_2eevalTermF(V v_r_240, V v_g_241, V v_c_242, V v_x4_243, V v_vs_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_SLocal: {
    V v_i_245 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SLocal = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 7);
    heff_drop(v_c_242);
    V v_t_246 = ({ V a_0 = v_vs_244; V a_1 = v_i_245; V r_ = heff_tr(g_heff_2eelab_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_vs_244); r_; });
    return heff_tag_at_n(v_ru_24x4_243_24SLocal, TAG_Nom, 1, (V[]){v_t_246});
  }
  case TAG_SGlobal: {
    V v_x_247 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SGlobal = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    V v_t_248 = ({ V a_0 = v_x_247; V b_1 = heff_get_n(v_g_241, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      v_t_2410 = heff_abandon();
      break;
    }
    case TAG_Just: {
      V v_e_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      v_t_2410 = v_e_249;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    return heff_tag_at_n(v_ru_24x4_243_24SGlobal, TAG_Nom, 1, (V[]){heff_get_n(v_t_2410, 2, 4)});
  }
  case TAG_SCode: {
    V v_a_2411 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_t_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, v_c_242, v_a_2411, v_vs_244}));
    return (g_heff_2eelab_2evalue_2eemap_24s196957333x715530534(v_t_2412));
  }
  case TAG_SApp: {
    V v_x41_2413 = heff_field(v_x4_243, 0);
    V v_t1_2414 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_2413)) {
    case TAG_SLocal: {
      heff_drop(v_c_242);
      V v_f_2422 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam0, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_2423 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_2423)) {
      case TAG_Nom: {
        V v_x_2424 = heff_field(v_x2_2423, 0);
        heff_take_n(v_x2_2423, 1ULL, 1);
        return heff_tail(v_f_2422, 1, (V[]){v_x_2424});
      }
      case TAG_Describe: {
        V v_x_2425 = heff_field(v_x2_2423, 0);
        heff_take_n(v_x2_2423, 1ULL, 1);
        return heff_tail(v_f_2422, 1, (V[]){v_x_2425});
      }
      case TAG_Become: {
        V v_x_2426 = heff_field(v_x2_2423, 0);
        V v_ru_24x2_2423_24Become = heff_take_reuse_n(v_x2_2423, 1ULL, 1);
        V v_x1_2427 = heff_tr(heff_call(v_f_2422, 1, (V[]){v_x_2426}));
        V v_t_2431;
        switch (heff_tag_of(v_x1_2427)) {
        case TAG_Nom: {
          V v_x_2428 = heff_field(v_x1_2427, 0);
          heff_take_n(v_x1_2427, 1ULL, 1);
          v_t_2431 = v_x_2428;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2427, 0ULL, 1);
          v_t_2431 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2430 = heff_field(v_x1_2427, 0);
          heff_take_n(v_x1_2427, 1ULL, 1);
          v_t_2431 = v_x_2430;
          break;
        }
        default: heff_nomatch(v_x1_2427);
        }
        return heff_tag_at_n(v_ru_24x2_2423_24Become, TAG_Become, 1, (V[]){v_t_2431});
      }
      default: return heff_nomatch(v_x2_2423);
      }
    }
    case TAG_SGlobal: {
      heff_drop(v_c_242);
      V v_f_2439 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam2, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_2440)) {
      case TAG_Nom: {
        V v_x_2441 = heff_field(v_x2_2440, 0);
        heff_take_n(v_x2_2440, 1ULL, 1);
        return heff_tail(v_f_2439, 1, (V[]){v_x_2441});
      }
      case TAG_Describe: {
        V v_x_2442 = heff_field(v_x2_2440, 0);
        heff_take_n(v_x2_2440, 1ULL, 1);
        return heff_tail(v_f_2439, 1, (V[]){v_x_2442});
      }
      case TAG_Become: {
        V v_x_2443 = heff_field(v_x2_2440, 0);
        V v_ru_24x2_2440_24Become = heff_take_reuse_n(v_x2_2440, 1ULL, 1);
        V v_x1_2444 = heff_tr(heff_call(v_f_2439, 1, (V[]){v_x_2443}));
        V v_t_2448;
        switch (heff_tag_of(v_x1_2444)) {
        case TAG_Nom: {
          V v_x_2445 = heff_field(v_x1_2444, 0);
          heff_take_n(v_x1_2444, 1ULL, 1);
          v_t_2448 = v_x_2445;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2444, 0ULL, 1);
          v_t_2448 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2447 = heff_field(v_x1_2444, 0);
          heff_take_n(v_x1_2444, 1ULL, 1);
          v_t_2448 = v_x_2447;
          break;
        }
        default: heff_nomatch(v_x1_2444);
        }
        return heff_tag_at_n(v_ru_24x2_2440_24Become, TAG_Become, 1, (V[]){v_t_2448});
      }
      default: return heff_nomatch(v_x2_2440);
      }
    }
    case TAG_SCode: {
      heff_drop(v_c_242);
      V v_f_2456 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam4, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_2457 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_2457)) {
      case TAG_Nom: {
        V v_x_2458 = heff_field(v_x2_2457, 0);
        heff_take_n(v_x2_2457, 1ULL, 1);
        return heff_tail(v_f_2456, 1, (V[]){v_x_2458});
      }
      case TAG_Describe: {
        V v_x_2459 = heff_field(v_x2_2457, 0);
        heff_take_n(v_x2_2457, 1ULL, 1);
        return heff_tail(v_f_2456, 1, (V[]){v_x_2459});
      }
      case TAG_Become: {
        V v_x_2460 = heff_field(v_x2_2457, 0);
        V v_ru_24x2_2457_24Become = heff_take_reuse_n(v_x2_2457, 1ULL, 1);
        V v_x1_2461 = heff_tr(heff_call(v_f_2456, 1, (V[]){v_x_2460}));
        V v_t_2465;
        switch (heff_tag_of(v_x1_2461)) {
        case TAG_Nom: {
          V v_x_2462 = heff_field(v_x1_2461, 0);
          heff_take_n(v_x1_2461, 1ULL, 1);
          v_t_2465 = v_x_2462;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2461, 0ULL, 1);
          v_t_2465 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2464 = heff_field(v_x1_2461, 0);
          heff_take_n(v_x1_2461, 1ULL, 1);
          v_t_2465 = v_x_2464;
          break;
        }
        default: heff_nomatch(v_x1_2461);
        }
        return heff_tag_at_n(v_ru_24x2_2457_24Become, TAG_Become, 1, (V[]){v_t_2465});
      }
      default: return heff_nomatch(v_x2_2457);
      }
    }
    case TAG_SApp: {
      heff_drop(v_c_242);
      V v_f_2474 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam6, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_2475 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_2475)) {
      case TAG_Nom: {
        V v_x_2476 = heff_field(v_x2_2475, 0);
        heff_take_n(v_x2_2475, 1ULL, 1);
        return heff_tail(v_f_2474, 1, (V[]){v_x_2476});
      }
      case TAG_Describe: {
        V v_x_2477 = heff_field(v_x2_2475, 0);
        heff_take_n(v_x2_2475, 1ULL, 1);
        return heff_tail(v_f_2474, 1, (V[]){v_x_2477});
      }
      case TAG_Become: {
        V v_x_2478 = heff_field(v_x2_2475, 0);
        V v_ru_24x2_2475_24Become = heff_take_reuse_n(v_x2_2475, 1ULL, 1);
        V v_x1_2479 = heff_tr(heff_call(v_f_2474, 1, (V[]){v_x_2478}));
        V v_t_2483;
        switch (heff_tag_of(v_x1_2479)) {
        case TAG_Nom: {
          V v_x_2480 = heff_field(v_x1_2479, 0);
          heff_take_n(v_x1_2479, 1ULL, 1);
          v_t_2483 = v_x_2480;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2479, 0ULL, 1);
          v_t_2483 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2482 = heff_field(v_x1_2479, 0);
          heff_take_n(v_x1_2479, 1ULL, 1);
          v_t_2483 = v_x_2482;
          break;
        }
        default: heff_nomatch(v_x1_2479);
        }
        return heff_tag_at_n(v_ru_24x2_2475_24Become, TAG_Become, 1, (V[]){v_t_2483});
      }
      default: return heff_nomatch(v_x2_2475);
      }
    }
    case TAG_SLam: {
      V v_x412_2485 = heff_dup(heff_field(v_x41_2413, 1));
      switch (heff_tag_of(v_x412_2485)) {
      case TAG_MkAbs: {
        V v_t_2487 = heff_field(v_x412_2485, 1);
        heff_take_n(v_x412_2485, 2ULL, 2);
        heff_drop_tag(v_x41_2413, 2);
        return heff_tail(heff_dup(heff_rfield(v_r_240, 0)), 4, (V[]){heff_dup(v_g_241), v_c_242, v_t_2487, heff_tag_n(TAG_LSnoc, 2, (V[]){heff_dup(v_vs_244), heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam8, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})})});
      }
      case TAG_AbsConst: {
        V v_ru_24x412_2485_24AbsConst = heff_take_reuse_n(v_x412_2485, 0ULL, 1);
        heff_drop(v_c_242);
        V v_f_24100 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam9, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
        V v_x2_24101 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
        switch (heff_tag_of(v_x2_24101)) {
        case TAG_Nom: {
          V v_x_24102 = heff_field(v_x2_24101, 0);
          heff_take_n(v_x2_24101, 1ULL, 1);
          heff_drop_cell(v_ru_24x412_2485_24AbsConst, 1);
          return heff_tail(v_f_24100, 1, (V[]){v_x_24102});
        }
        case TAG_Describe: {
          V v_x_24103 = heff_field(v_x2_24101, 0);
          heff_take_n(v_x2_24101, 1ULL, 1);
          heff_drop_cell(v_ru_24x412_2485_24AbsConst, 1);
          return heff_tail(v_f_24100, 1, (V[]){v_x_24103});
        }
        case TAG_Become: {
          V v_x_24104 = heff_field(v_x2_24101, 0);
          heff_take_n(v_x2_24101, 1ULL, 1);
          V v_x1_24105 = heff_tr(heff_call(v_f_24100, 1, (V[]){v_x_24104}));
          V v_t_24109;
          switch (heff_tag_of(v_x1_24105)) {
          case TAG_Nom: {
            V v_x_24106 = heff_field(v_x1_24105, 0);
            heff_take_n(v_x1_24105, 1ULL, 1);
            v_t_24109 = v_x_24106;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_24105, 0ULL, 1);
            v_t_24109 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_24108 = heff_field(v_x1_24105, 0);
            heff_take_n(v_x1_24105, 1ULL, 1);
            v_t_24109 = v_x_24108;
            break;
          }
          default: heff_nomatch(v_x1_24105);
          }
          return heff_tag_at_n(v_ru_24x412_2485_24AbsConst, TAG_Become, 1, (V[]){v_t_24109});
        }
        default: return heff_nomatch(v_x2_24101);
        }
      }
      default: return heff_nomatch(v_x412_2485);
      }
    }
    case TAG_SCons: {
      heff_drop(v_c_242);
      V v_f_24117 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam11, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24118 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24118)) {
      case TAG_Nom: {
        V v_x_24119 = heff_field(v_x2_24118, 0);
        heff_take_n(v_x2_24118, 1ULL, 1);
        return heff_tail(v_f_24117, 1, (V[]){v_x_24119});
      }
      case TAG_Describe: {
        V v_x_24120 = heff_field(v_x2_24118, 0);
        heff_take_n(v_x2_24118, 1ULL, 1);
        return heff_tail(v_f_24117, 1, (V[]){v_x_24120});
      }
      case TAG_Become: {
        V v_x_24121 = heff_field(v_x2_24118, 0);
        V v_ru_24x2_24118_24Become = heff_take_reuse_n(v_x2_24118, 1ULL, 1);
        V v_x1_24122 = heff_tr(heff_call(v_f_24117, 1, (V[]){v_x_24121}));
        V v_t_24126;
        switch (heff_tag_of(v_x1_24122)) {
        case TAG_Nom: {
          V v_x_24123 = heff_field(v_x1_24122, 0);
          heff_take_n(v_x1_24122, 1ULL, 1);
          v_t_24126 = v_x_24123;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24122, 0ULL, 1);
          v_t_24126 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24125 = heff_field(v_x1_24122, 0);
          heff_take_n(v_x1_24122, 1ULL, 1);
          v_t_24126 = v_x_24125;
          break;
        }
        default: heff_nomatch(v_x1_24122);
        }
        return heff_tag_at_n(v_ru_24x2_24118_24Become, TAG_Become, 1, (V[]){v_t_24126});
      }
      default: return heff_nomatch(v_x2_24118);
      }
    }
    case TAG_SProj: {
      heff_drop(v_c_242);
      V v_f_24135 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam13, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24136 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24136)) {
      case TAG_Nom: {
        V v_x_24137 = heff_field(v_x2_24136, 0);
        heff_take_n(v_x2_24136, 1ULL, 1);
        return heff_tail(v_f_24135, 1, (V[]){v_x_24137});
      }
      case TAG_Describe: {
        V v_x_24138 = heff_field(v_x2_24136, 0);
        heff_take_n(v_x2_24136, 1ULL, 1);
        return heff_tail(v_f_24135, 1, (V[]){v_x_24138});
      }
      case TAG_Become: {
        V v_x_24139 = heff_field(v_x2_24136, 0);
        V v_ru_24x2_24136_24Become = heff_take_reuse_n(v_x2_24136, 1ULL, 1);
        V v_x1_24140 = heff_tr(heff_call(v_f_24135, 1, (V[]){v_x_24139}));
        V v_t_24144;
        switch (heff_tag_of(v_x1_24140)) {
        case TAG_Nom: {
          V v_x_24141 = heff_field(v_x1_24140, 0);
          heff_take_n(v_x1_24140, 1ULL, 1);
          v_t_24144 = v_x_24141;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24140, 0ULL, 1);
          v_t_24144 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24143 = heff_field(v_x1_24140, 0);
          heff_take_n(v_x1_24140, 1ULL, 1);
          v_t_24144 = v_x_24143;
          break;
        }
        default: heff_nomatch(v_x1_24140);
        }
        return heff_tag_at_n(v_ru_24x2_24136_24Become, TAG_Become, 1, (V[]){v_t_24144});
      }
      default: return heff_nomatch(v_x2_24136);
      }
    }
    case TAG_STag: {
      heff_drop(v_c_242);
      V v_f_24153 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam15, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24154 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24154)) {
      case TAG_Nom: {
        V v_x_24155 = heff_field(v_x2_24154, 0);
        heff_take_n(v_x2_24154, 1ULL, 1);
        return heff_tail(v_f_24153, 1, (V[]){v_x_24155});
      }
      case TAG_Describe: {
        V v_x_24156 = heff_field(v_x2_24154, 0);
        heff_take_n(v_x2_24154, 1ULL, 1);
        return heff_tail(v_f_24153, 1, (V[]){v_x_24156});
      }
      case TAG_Become: {
        V v_x_24157 = heff_field(v_x2_24154, 0);
        V v_ru_24x2_24154_24Become = heff_take_reuse_n(v_x2_24154, 1ULL, 1);
        V v_x1_24158 = heff_tr(heff_call(v_f_24153, 1, (V[]){v_x_24157}));
        V v_t_24162;
        switch (heff_tag_of(v_x1_24158)) {
        case TAG_Nom: {
          V v_x_24159 = heff_field(v_x1_24158, 0);
          heff_take_n(v_x1_24158, 1ULL, 1);
          v_t_24162 = v_x_24159;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24158, 0ULL, 1);
          v_t_24162 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24161 = heff_field(v_x1_24158, 0);
          heff_take_n(v_x1_24158, 1ULL, 1);
          v_t_24162 = v_x_24161;
          break;
        }
        default: heff_nomatch(v_x1_24158);
        }
        return heff_tag_at_n(v_ru_24x2_24154_24Become, TAG_Become, 1, (V[]){v_t_24162});
      }
      default: return heff_nomatch(v_x2_24154);
      }
    }
    case TAG_SMatch: {
      heff_drop(v_c_242);
      V v_f_24171 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam17, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24172 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24172)) {
      case TAG_Nom: {
        V v_x_24173 = heff_field(v_x2_24172, 0);
        heff_take_n(v_x2_24172, 1ULL, 1);
        return heff_tail(v_f_24171, 1, (V[]){v_x_24173});
      }
      case TAG_Describe: {
        V v_x_24174 = heff_field(v_x2_24172, 0);
        heff_take_n(v_x2_24172, 1ULL, 1);
        return heff_tail(v_f_24171, 1, (V[]){v_x_24174});
      }
      case TAG_Become: {
        V v_x_24175 = heff_field(v_x2_24172, 0);
        V v_ru_24x2_24172_24Become = heff_take_reuse_n(v_x2_24172, 1ULL, 1);
        V v_x1_24176 = heff_tr(heff_call(v_f_24171, 1, (V[]){v_x_24175}));
        V v_t_24180;
        switch (heff_tag_of(v_x1_24176)) {
        case TAG_Nom: {
          V v_x_24177 = heff_field(v_x1_24176, 0);
          heff_take_n(v_x1_24176, 1ULL, 1);
          v_t_24180 = v_x_24177;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24176, 0ULL, 1);
          v_t_24180 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24179 = heff_field(v_x1_24176, 0);
          heff_take_n(v_x1_24176, 1ULL, 1);
          v_t_24180 = v_x_24179;
          break;
        }
        default: heff_nomatch(v_x1_24176);
        }
        return heff_tag_at_n(v_ru_24x2_24172_24Become, TAG_Become, 1, (V[]){v_t_24180});
      }
      default: return heff_nomatch(v_x2_24172);
      }
    }
    case TAG_SSpecialize: {
      heff_drop(v_c_242);
      V v_f_24190 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam19, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24191 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24191)) {
      case TAG_Nom: {
        V v_x_24192 = heff_field(v_x2_24191, 0);
        heff_take_n(v_x2_24191, 1ULL, 1);
        return heff_tail(v_f_24190, 1, (V[]){v_x_24192});
      }
      case TAG_Describe: {
        V v_x_24193 = heff_field(v_x2_24191, 0);
        heff_take_n(v_x2_24191, 1ULL, 1);
        return heff_tail(v_f_24190, 1, (V[]){v_x_24193});
      }
      case TAG_Become: {
        V v_x_24194 = heff_field(v_x2_24191, 0);
        V v_ru_24x2_24191_24Become = heff_take_reuse_n(v_x2_24191, 1ULL, 1);
        V v_x1_24195 = heff_tr(heff_call(v_f_24190, 1, (V[]){v_x_24194}));
        V v_t_24199;
        switch (heff_tag_of(v_x1_24195)) {
        case TAG_Nom: {
          V v_x_24196 = heff_field(v_x1_24195, 0);
          heff_take_n(v_x1_24195, 1ULL, 1);
          v_t_24199 = v_x_24196;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24195, 0ULL, 1);
          v_t_24199 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24198 = heff_field(v_x1_24195, 0);
          heff_take_n(v_x1_24195, 1ULL, 1);
          v_t_24199 = v_x_24198;
          break;
        }
        default: heff_nomatch(v_x1_24195);
        }
        return heff_tag_at_n(v_ru_24x2_24191_24Become, TAG_Become, 1, (V[]){v_t_24199});
      }
      default: return heff_nomatch(v_x2_24191);
      }
    }
    case TAG_SIs: {
      heff_drop(v_c_242);
      V v_f_24207 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam21, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24208 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24208)) {
      case TAG_Nom: {
        V v_x_24209 = heff_field(v_x2_24208, 0);
        heff_take_n(v_x2_24208, 1ULL, 1);
        return heff_tail(v_f_24207, 1, (V[]){v_x_24209});
      }
      case TAG_Describe: {
        V v_x_24210 = heff_field(v_x2_24208, 0);
        heff_take_n(v_x2_24208, 1ULL, 1);
        return heff_tail(v_f_24207, 1, (V[]){v_x_24210});
      }
      case TAG_Become: {
        V v_x_24211 = heff_field(v_x2_24208, 0);
        V v_ru_24x2_24208_24Become = heff_take_reuse_n(v_x2_24208, 1ULL, 1);
        V v_x1_24212 = heff_tr(heff_call(v_f_24207, 1, (V[]){v_x_24211}));
        V v_t_24216;
        switch (heff_tag_of(v_x1_24212)) {
        case TAG_Nom: {
          V v_x_24213 = heff_field(v_x1_24212, 0);
          heff_take_n(v_x1_24212, 1ULL, 1);
          v_t_24216 = v_x_24213;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24212, 0ULL, 1);
          v_t_24216 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24215 = heff_field(v_x1_24212, 0);
          heff_take_n(v_x1_24212, 1ULL, 1);
          v_t_24216 = v_x_24215;
          break;
        }
        default: heff_nomatch(v_x1_24212);
        }
        return heff_tag_at_n(v_ru_24x2_24208_24Become, TAG_Become, 1, (V[]){v_t_24216});
      }
      default: return heff_nomatch(v_x2_24208);
      }
    }
    case TAG_SOpaque: {
      heff_drop(v_c_242);
      V v_f_24223 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam23, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24224 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24224)) {
      case TAG_Nom: {
        V v_x_24225 = heff_field(v_x2_24224, 0);
        heff_take_n(v_x2_24224, 1ULL, 1);
        return heff_tail(v_f_24223, 1, (V[]){v_x_24225});
      }
      case TAG_Describe: {
        V v_x_24226 = heff_field(v_x2_24224, 0);
        heff_take_n(v_x2_24224, 1ULL, 1);
        return heff_tail(v_f_24223, 1, (V[]){v_x_24226});
      }
      case TAG_Become: {
        V v_x_24227 = heff_field(v_x2_24224, 0);
        V v_ru_24x2_24224_24Become = heff_take_reuse_n(v_x2_24224, 1ULL, 1);
        V v_x1_24228 = heff_tr(heff_call(v_f_24223, 1, (V[]){v_x_24227}));
        V v_t_24232;
        switch (heff_tag_of(v_x1_24228)) {
        case TAG_Nom: {
          V v_x_24229 = heff_field(v_x1_24228, 0);
          heff_take_n(v_x1_24228, 1ULL, 1);
          v_t_24232 = v_x_24229;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24228, 0ULL, 1);
          v_t_24232 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24231 = heff_field(v_x1_24228, 0);
          heff_take_n(v_x1_24228, 1ULL, 1);
          v_t_24232 = v_x_24231;
          break;
        }
        default: heff_nomatch(v_x1_24228);
        }
        return heff_tag_at_n(v_ru_24x2_24224_24Become, TAG_Become, 1, (V[]){v_t_24232});
      }
      default: return heff_nomatch(v_x2_24224);
      }
    }
    case TAG_SAbandon: {
      heff_drop(v_c_242);
      V v_f_24239 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam25, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24240 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24240)) {
      case TAG_Nom: {
        V v_x_24241 = heff_field(v_x2_24240, 0);
        heff_take_n(v_x2_24240, 1ULL, 1);
        return heff_tail(v_f_24239, 1, (V[]){v_x_24241});
      }
      case TAG_Describe: {
        V v_x_24242 = heff_field(v_x2_24240, 0);
        heff_take_n(v_x2_24240, 1ULL, 1);
        return heff_tail(v_f_24239, 1, (V[]){v_x_24242});
      }
      case TAG_Become: {
        V v_x_24243 = heff_field(v_x2_24240, 0);
        V v_ru_24x2_24240_24Become = heff_take_reuse_n(v_x2_24240, 1ULL, 1);
        V v_x1_24244 = heff_tr(heff_call(v_f_24239, 1, (V[]){v_x_24243}));
        V v_t_24248;
        switch (heff_tag_of(v_x1_24244)) {
        case TAG_Nom: {
          V v_x_24245 = heff_field(v_x1_24244, 0);
          heff_take_n(v_x1_24244, 1ULL, 1);
          v_t_24248 = v_x_24245;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24244, 0ULL, 1);
          v_t_24248 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24247 = heff_field(v_x1_24244, 0);
          heff_take_n(v_x1_24244, 1ULL, 1);
          v_t_24248 = v_x_24247;
          break;
        }
        default: heff_nomatch(v_x1_24244);
        }
        return heff_tag_at_n(v_ru_24x2_24240_24Become, TAG_Become, 1, (V[]){v_t_24248});
      }
      default: return heff_nomatch(v_x2_24240);
      }
    }
    case TAG_SRec: {
      heff_drop(v_c_242);
      V v_f_24256 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam27, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24257 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24257)) {
      case TAG_Nom: {
        V v_x_24258 = heff_field(v_x2_24257, 0);
        heff_take_n(v_x2_24257, 1ULL, 1);
        return heff_tail(v_f_24256, 1, (V[]){v_x_24258});
      }
      case TAG_Describe: {
        V v_x_24259 = heff_field(v_x2_24257, 0);
        heff_take_n(v_x2_24257, 1ULL, 1);
        return heff_tail(v_f_24256, 1, (V[]){v_x_24259});
      }
      case TAG_Become: {
        V v_x_24260 = heff_field(v_x2_24257, 0);
        V v_ru_24x2_24257_24Become = heff_take_reuse_n(v_x2_24257, 1ULL, 1);
        V v_x1_24261 = heff_tr(heff_call(v_f_24256, 1, (V[]){v_x_24260}));
        V v_t_24265;
        switch (heff_tag_of(v_x1_24261)) {
        case TAG_Nom: {
          V v_x_24262 = heff_field(v_x1_24261, 0);
          heff_take_n(v_x1_24261, 1ULL, 1);
          v_t_24265 = v_x_24262;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24261, 0ULL, 1);
          v_t_24265 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24264 = heff_field(v_x1_24261, 0);
          heff_take_n(v_x1_24261, 1ULL, 1);
          v_t_24265 = v_x_24264;
          break;
        }
        default: heff_nomatch(v_x1_24261);
        }
        return heff_tag_at_n(v_ru_24x2_24257_24Become, TAG_Become, 1, (V[]){v_t_24265});
      }
      default: return heff_nomatch(v_x2_24257);
      }
    }
    case TAG_SFix: {
      heff_drop(v_c_242);
      V v_f_24274 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam29, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24275 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24275)) {
      case TAG_Nom: {
        V v_x_24276 = heff_field(v_x2_24275, 0);
        heff_take_n(v_x2_24275, 1ULL, 1);
        return heff_tail(v_f_24274, 1, (V[]){v_x_24276});
      }
      case TAG_Describe: {
        V v_x_24277 = heff_field(v_x2_24275, 0);
        heff_take_n(v_x2_24275, 1ULL, 1);
        return heff_tail(v_f_24274, 1, (V[]){v_x_24277});
      }
      case TAG_Become: {
        V v_x_24278 = heff_field(v_x2_24275, 0);
        V v_ru_24x2_24275_24Become = heff_take_reuse_n(v_x2_24275, 1ULL, 1);
        V v_x1_24279 = heff_tr(heff_call(v_f_24274, 1, (V[]){v_x_24278}));
        V v_t_24283;
        switch (heff_tag_of(v_x1_24279)) {
        case TAG_Nom: {
          V v_x_24280 = heff_field(v_x1_24279, 0);
          heff_take_n(v_x1_24279, 1ULL, 1);
          v_t_24283 = v_x_24280;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24279, 0ULL, 1);
          v_t_24283 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24282 = heff_field(v_x1_24279, 0);
          heff_take_n(v_x1_24279, 1ULL, 1);
          v_t_24283 = v_x_24282;
          break;
        }
        default: heff_nomatch(v_x1_24279);
        }
        return heff_tag_at_n(v_ru_24x2_24275_24Become, TAG_Become, 1, (V[]){v_t_24283});
      }
      default: return heff_nomatch(v_x2_24275);
      }
    }
    case TAG_SImplicit: {
      heff_drop(v_c_242);
      V v_f_24292 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam31, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24293 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24293)) {
      case TAG_Nom: {
        V v_x_24294 = heff_field(v_x2_24293, 0);
        heff_take_n(v_x2_24293, 1ULL, 1);
        return heff_tail(v_f_24292, 1, (V[]){v_x_24294});
      }
      case TAG_Describe: {
        V v_x_24295 = heff_field(v_x2_24293, 0);
        heff_take_n(v_x2_24293, 1ULL, 1);
        return heff_tail(v_f_24292, 1, (V[]){v_x_24295});
      }
      case TAG_Become: {
        V v_x_24296 = heff_field(v_x2_24293, 0);
        V v_ru_24x2_24293_24Become = heff_take_reuse_n(v_x2_24293, 1ULL, 1);
        V v_x1_24297 = heff_tr(heff_call(v_f_24292, 1, (V[]){v_x_24296}));
        V v_t_24301;
        switch (heff_tag_of(v_x1_24297)) {
        case TAG_Nom: {
          V v_x_24298 = heff_field(v_x1_24297, 0);
          heff_take_n(v_x1_24297, 1ULL, 1);
          v_t_24301 = v_x_24298;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24297, 0ULL, 1);
          v_t_24301 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24300 = heff_field(v_x1_24297, 0);
          heff_take_n(v_x1_24297, 1ULL, 1);
          v_t_24301 = v_x_24300;
          break;
        }
        default: heff_nomatch(v_x1_24297);
        }
        return heff_tag_at_n(v_ru_24x2_24293_24Become, TAG_Become, 1, (V[]){v_t_24301});
      }
      default: return heff_nomatch(v_x2_24293);
      }
    }
    case TAG_SPrim: {
      heff_drop(v_c_242);
      V v_f_24309 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam33, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24310 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24310)) {
      case TAG_Nom: {
        V v_x_24311 = heff_field(v_x2_24310, 0);
        heff_take_n(v_x2_24310, 1ULL, 1);
        return heff_tail(v_f_24309, 1, (V[]){v_x_24311});
      }
      case TAG_Describe: {
        V v_x_24312 = heff_field(v_x2_24310, 0);
        heff_take_n(v_x2_24310, 1ULL, 1);
        return heff_tail(v_f_24309, 1, (V[]){v_x_24312});
      }
      case TAG_Become: {
        V v_x_24313 = heff_field(v_x2_24310, 0);
        V v_ru_24x2_24310_24Become = heff_take_reuse_n(v_x2_24310, 1ULL, 1);
        V v_x1_24314 = heff_tr(heff_call(v_f_24309, 1, (V[]){v_x_24313}));
        V v_t_24318;
        switch (heff_tag_of(v_x1_24314)) {
        case TAG_Nom: {
          V v_x_24315 = heff_field(v_x1_24314, 0);
          heff_take_n(v_x1_24314, 1ULL, 1);
          v_t_24318 = v_x_24315;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24314, 0ULL, 1);
          v_t_24318 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24317 = heff_field(v_x1_24314, 0);
          heff_take_n(v_x1_24314, 1ULL, 1);
          v_t_24318 = v_x_24317;
          break;
        }
        default: heff_nomatch(v_x1_24314);
        }
        return heff_tag_at_n(v_ru_24x2_24310_24Become, TAG_Become, 1, (V[]){v_t_24318});
      }
      default: return heff_nomatch(v_x2_24310);
      }
    }
    case TAG_SMetaApp: {
      heff_drop(v_c_242);
      V v_f_24328 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam35, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24329 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24329)) {
      case TAG_Nom: {
        V v_x_24330 = heff_field(v_x2_24329, 0);
        heff_take_n(v_x2_24329, 1ULL, 1);
        return heff_tail(v_f_24328, 1, (V[]){v_x_24330});
      }
      case TAG_Describe: {
        V v_x_24331 = heff_field(v_x2_24329, 0);
        heff_take_n(v_x2_24329, 1ULL, 1);
        return heff_tail(v_f_24328, 1, (V[]){v_x_24331});
      }
      case TAG_Become: {
        V v_x_24332 = heff_field(v_x2_24329, 0);
        V v_ru_24x2_24329_24Become = heff_take_reuse_n(v_x2_24329, 1ULL, 1);
        V v_x1_24333 = heff_tr(heff_call(v_f_24328, 1, (V[]){v_x_24332}));
        V v_t_24337;
        switch (heff_tag_of(v_x1_24333)) {
        case TAG_Nom: {
          V v_x_24334 = heff_field(v_x1_24333, 0);
          heff_take_n(v_x1_24333, 1ULL, 1);
          v_t_24337 = v_x_24334;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24333, 0ULL, 1);
          v_t_24337 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24336 = heff_field(v_x1_24333, 0);
          heff_take_n(v_x1_24333, 1ULL, 1);
          v_t_24337 = v_x_24336;
          break;
        }
        default: heff_nomatch(v_x1_24333);
        }
        return heff_tag_at_n(v_ru_24x2_24329_24Become, TAG_Become, 1, (V[]){v_t_24337});
      }
      default: return heff_nomatch(v_x2_24329);
      }
    }
    case TAG_SLitInt: {
      heff_drop(v_c_242);
      V v_f_24345 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam37, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24346 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24346)) {
      case TAG_Nom: {
        V v_x_24347 = heff_field(v_x2_24346, 0);
        heff_take_n(v_x2_24346, 1ULL, 1);
        return heff_tail(v_f_24345, 1, (V[]){v_x_24347});
      }
      case TAG_Describe: {
        V v_x_24348 = heff_field(v_x2_24346, 0);
        heff_take_n(v_x2_24346, 1ULL, 1);
        return heff_tail(v_f_24345, 1, (V[]){v_x_24348});
      }
      case TAG_Become: {
        V v_x_24349 = heff_field(v_x2_24346, 0);
        V v_ru_24x2_24346_24Become = heff_take_reuse_n(v_x2_24346, 1ULL, 1);
        V v_x1_24350 = heff_tr(heff_call(v_f_24345, 1, (V[]){v_x_24349}));
        V v_t_24354;
        switch (heff_tag_of(v_x1_24350)) {
        case TAG_Nom: {
          V v_x_24351 = heff_field(v_x1_24350, 0);
          heff_take_n(v_x1_24350, 1ULL, 1);
          v_t_24354 = v_x_24351;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24350, 0ULL, 1);
          v_t_24354 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24353 = heff_field(v_x1_24350, 0);
          heff_take_n(v_x1_24350, 1ULL, 1);
          v_t_24354 = v_x_24353;
          break;
        }
        default: heff_nomatch(v_x1_24350);
        }
        return heff_tag_at_n(v_ru_24x2_24346_24Become, TAG_Become, 1, (V[]){v_t_24354});
      }
      default: return heff_nomatch(v_x2_24346);
      }
    }
    case TAG_SLitFloat: {
      heff_drop(v_c_242);
      V v_f_24362 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam39, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24363 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24363)) {
      case TAG_Nom: {
        V v_x_24364 = heff_field(v_x2_24363, 0);
        heff_take_n(v_x2_24363, 1ULL, 1);
        return heff_tail(v_f_24362, 1, (V[]){v_x_24364});
      }
      case TAG_Describe: {
        V v_x_24365 = heff_field(v_x2_24363, 0);
        heff_take_n(v_x2_24363, 1ULL, 1);
        return heff_tail(v_f_24362, 1, (V[]){v_x_24365});
      }
      case TAG_Become: {
        V v_x_24366 = heff_field(v_x2_24363, 0);
        V v_ru_24x2_24363_24Become = heff_take_reuse_n(v_x2_24363, 1ULL, 1);
        V v_x1_24367 = heff_tr(heff_call(v_f_24362, 1, (V[]){v_x_24366}));
        V v_t_24371;
        switch (heff_tag_of(v_x1_24367)) {
        case TAG_Nom: {
          V v_x_24368 = heff_field(v_x1_24367, 0);
          heff_take_n(v_x1_24367, 1ULL, 1);
          v_t_24371 = v_x_24368;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24367, 0ULL, 1);
          v_t_24371 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24370 = heff_field(v_x1_24367, 0);
          heff_take_n(v_x1_24367, 1ULL, 1);
          v_t_24371 = v_x_24370;
          break;
        }
        default: heff_nomatch(v_x1_24367);
        }
        return heff_tag_at_n(v_ru_24x2_24363_24Become, TAG_Become, 1, (V[]){v_t_24371});
      }
      default: return heff_nomatch(v_x2_24363);
      }
    }
    case TAG_SLitString: {
      heff_drop(v_c_242);
      V v_f_24379 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam41, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24380 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24380)) {
      case TAG_Nom: {
        V v_x_24381 = heff_field(v_x2_24380, 0);
        heff_take_n(v_x2_24380, 1ULL, 1);
        return heff_tail(v_f_24379, 1, (V[]){v_x_24381});
      }
      case TAG_Describe: {
        V v_x_24382 = heff_field(v_x2_24380, 0);
        heff_take_n(v_x2_24380, 1ULL, 1);
        return heff_tail(v_f_24379, 1, (V[]){v_x_24382});
      }
      case TAG_Become: {
        V v_x_24383 = heff_field(v_x2_24380, 0);
        V v_ru_24x2_24380_24Become = heff_take_reuse_n(v_x2_24380, 1ULL, 1);
        V v_x1_24384 = heff_tr(heff_call(v_f_24379, 1, (V[]){v_x_24383}));
        V v_t_24388;
        switch (heff_tag_of(v_x1_24384)) {
        case TAG_Nom: {
          V v_x_24385 = heff_field(v_x1_24384, 0);
          heff_take_n(v_x1_24384, 1ULL, 1);
          v_t_24388 = v_x_24385;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24384, 0ULL, 1);
          v_t_24388 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24387 = heff_field(v_x1_24384, 0);
          heff_take_n(v_x1_24384, 1ULL, 1);
          v_t_24388 = v_x_24387;
          break;
        }
        default: heff_nomatch(v_x1_24384);
        }
        return heff_tag_at_n(v_ru_24x2_24380_24Become, TAG_Become, 1, (V[]){v_t_24388});
      }
      default: return heff_nomatch(v_x2_24380);
      }
    }
    case TAG_SLitBytes: {
      heff_drop(v_c_242);
      V v_f_24396 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam43, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24397 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24397)) {
      case TAG_Nom: {
        V v_x_24398 = heff_field(v_x2_24397, 0);
        heff_take_n(v_x2_24397, 1ULL, 1);
        return heff_tail(v_f_24396, 1, (V[]){v_x_24398});
      }
      case TAG_Describe: {
        V v_x_24399 = heff_field(v_x2_24397, 0);
        heff_take_n(v_x2_24397, 1ULL, 1);
        return heff_tail(v_f_24396, 1, (V[]){v_x_24399});
      }
      case TAG_Become: {
        V v_x_24400 = heff_field(v_x2_24397, 0);
        V v_ru_24x2_24397_24Become = heff_take_reuse_n(v_x2_24397, 1ULL, 1);
        V v_x1_24401 = heff_tr(heff_call(v_f_24396, 1, (V[]){v_x_24400}));
        V v_t_24405;
        switch (heff_tag_of(v_x1_24401)) {
        case TAG_Nom: {
          V v_x_24402 = heff_field(v_x1_24401, 0);
          heff_take_n(v_x1_24401, 1ULL, 1);
          v_t_24405 = v_x_24402;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24401, 0ULL, 1);
          v_t_24405 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24404 = heff_field(v_x1_24401, 0);
          heff_take_n(v_x1_24401, 1ULL, 1);
          v_t_24405 = v_x_24404;
          break;
        }
        default: heff_nomatch(v_x1_24401);
        }
        return heff_tag_at_n(v_ru_24x2_24397_24Become, TAG_Become, 1, (V[]){v_t_24405});
      }
      default: return heff_nomatch(v_x2_24397);
      }
    }
    case TAG_SLitRune: {
      heff_drop(v_c_242);
      V v_f_24413 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam45, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24414 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24414)) {
      case TAG_Nom: {
        V v_x_24415 = heff_field(v_x2_24414, 0);
        heff_take_n(v_x2_24414, 1ULL, 1);
        return heff_tail(v_f_24413, 1, (V[]){v_x_24415});
      }
      case TAG_Describe: {
        V v_x_24416 = heff_field(v_x2_24414, 0);
        heff_take_n(v_x2_24414, 1ULL, 1);
        return heff_tail(v_f_24413, 1, (V[]){v_x_24416});
      }
      case TAG_Become: {
        V v_x_24417 = heff_field(v_x2_24414, 0);
        V v_ru_24x2_24414_24Become = heff_take_reuse_n(v_x2_24414, 1ULL, 1);
        V v_x1_24418 = heff_tr(heff_call(v_f_24413, 1, (V[]){v_x_24417}));
        V v_t_24422;
        switch (heff_tag_of(v_x1_24418)) {
        case TAG_Nom: {
          V v_x_24419 = heff_field(v_x1_24418, 0);
          heff_take_n(v_x1_24418, 1ULL, 1);
          v_t_24422 = v_x_24419;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24418, 0ULL, 1);
          v_t_24422 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24421 = heff_field(v_x1_24418, 0);
          heff_take_n(v_x1_24418, 1ULL, 1);
          v_t_24422 = v_x_24421;
          break;
        }
        default: heff_nomatch(v_x1_24418);
        }
        return heff_tag_at_n(v_ru_24x2_24414_24Become, TAG_Become, 1, (V[]){v_t_24422});
      }
      default: return heff_nomatch(v_x2_24414);
      }
    }
    case TAG_SLitFixed: {
      heff_drop(v_c_242);
      V v_f_24431 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam47, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24432 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24432)) {
      case TAG_Nom: {
        V v_x_24433 = heff_field(v_x2_24432, 0);
        heff_take_n(v_x2_24432, 1ULL, 1);
        return heff_tail(v_f_24431, 1, (V[]){v_x_24433});
      }
      case TAG_Describe: {
        V v_x_24434 = heff_field(v_x2_24432, 0);
        heff_take_n(v_x2_24432, 1ULL, 1);
        return heff_tail(v_f_24431, 1, (V[]){v_x_24434});
      }
      case TAG_Become: {
        V v_x_24435 = heff_field(v_x2_24432, 0);
        V v_ru_24x2_24432_24Become = heff_take_reuse_n(v_x2_24432, 1ULL, 1);
        V v_x1_24436 = heff_tr(heff_call(v_f_24431, 1, (V[]){v_x_24435}));
        V v_t_24440;
        switch (heff_tag_of(v_x1_24436)) {
        case TAG_Nom: {
          V v_x_24437 = heff_field(v_x1_24436, 0);
          heff_take_n(v_x1_24436, 1ULL, 1);
          v_t_24440 = v_x_24437;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24436, 0ULL, 1);
          v_t_24440 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24439 = heff_field(v_x1_24436, 0);
          heff_take_n(v_x1_24436, 1ULL, 1);
          v_t_24440 = v_x_24439;
          break;
        }
        default: heff_nomatch(v_x1_24436);
        }
        return heff_tag_at_n(v_ru_24x2_24432_24Become, TAG_Become, 1, (V[]){v_t_24440});
      }
      default: return heff_nomatch(v_x2_24432);
      }
    }
    case TAG_SLitFloat32: {
      heff_drop(v_c_242);
      V v_f_24448 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam49, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2414, heff_dup(v_vs_244)});
      V v_x2_24449 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2413, v_vs_244}));
      switch (heff_tag_of(v_x2_24449)) {
      case TAG_Nom: {
        V v_x_24450 = heff_field(v_x2_24449, 0);
        heff_take_n(v_x2_24449, 1ULL, 1);
        return heff_tail(v_f_24448, 1, (V[]){v_x_24450});
      }
      case TAG_Describe: {
        V v_x_24451 = heff_field(v_x2_24449, 0);
        heff_take_n(v_x2_24449, 1ULL, 1);
        return heff_tail(v_f_24448, 1, (V[]){v_x_24451});
      }
      case TAG_Become: {
        V v_x_24452 = heff_field(v_x2_24449, 0);
        V v_ru_24x2_24449_24Become = heff_take_reuse_n(v_x2_24449, 1ULL, 1);
        V v_x1_24453 = heff_tr(heff_call(v_f_24448, 1, (V[]){v_x_24452}));
        V v_t_24457;
        switch (heff_tag_of(v_x1_24453)) {
        case TAG_Nom: {
          V v_x_24454 = heff_field(v_x1_24453, 0);
          heff_take_n(v_x1_24453, 1ULL, 1);
          v_t_24457 = v_x_24454;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24453, 0ULL, 1);
          v_t_24457 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24456 = heff_field(v_x1_24453, 0);
          heff_take_n(v_x1_24453, 1ULL, 1);
          v_t_24457 = v_x_24456;
          break;
        }
        default: heff_nomatch(v_x1_24453);
        }
        return heff_tag_at_n(v_ru_24x2_24449_24Become, TAG_Become, 1, (V[]){v_t_24457});
      }
      default: return heff_nomatch(v_x2_24449);
      }
    }
    default: return heff_nomatch(v_x41_2413);
    }
  }
  case TAG_SLam: {
    V v_dom_24458 = heff_field(v_x4_243, 0);
    V v_x42_24459 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24SLam = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x42_24459)) {
    case TAG_MkAbs: {
      V v_x_24460 = heff_field(v_x42_24459, 0);
      V v_t_24461 = heff_field(v_x42_24459, 1);
      heff_take_n(v_x42_24459, 3ULL, 2);
      V v_x_24468 = heff_tag_at_n(v_ru_24x4_243_24SLam, TAG_VLam, 2, (V[]){heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam51, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_dom_24458, heff_dup(v_vs_244)}), heff_tag_n(TAG_MkClo, 3, (V[]){v_x_24460, v_vs_244, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam52, 1, 4, (V[]){v_r_240, v_g_241, heff_dup(v_c_242), v_t_24461})})});
      switch (heff_tag_of(v_c_242)) {
      case TAG_N: {
        return heff_tag_n(TAG_Nom, 1, (V[]){v_x_24468});
      }
      case TAG_De: {
        return heff_tag_n(TAG_Describe, 1, (V[]){v_x_24468});
      }
      default: return heff_nomatch(v_c_242);
      }
    }
    case TAG_AbsConst: {
      V v_t_24469 = heff_field(v_x42_24459, 0);
      V v_ru_24x42_24459_24AbsConst = heff_take_reuse_n(v_x42_24459, 1ULL, 1);
      V v_t_24470 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 4, (V[]){heff_dup(v_g_241), heff_dup(v_c_242), v_t_24469, heff_dup(v_vs_244)}));
      V v_x_24476 = heff_tag_at_n(v_ru_24x4_243_24SLam, TAG_VLam, 2, (V[]){heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam53, 1, 4, (V[]){v_r_240, v_g_241, v_dom_24458, v_vs_244}), heff_tag_n(TAG_CloConst, 1, (V[]){v_t_24470})});
      switch (heff_tag_of(v_c_242)) {
      case TAG_N: {
        return heff_tag_at_n(v_ru_24x42_24459_24AbsConst, TAG_Nom, 1, (V[]){v_x_24476});
      }
      case TAG_De: {
        return heff_tag_at_n(v_ru_24x42_24459_24AbsConst, TAG_Describe, 1, (V[]){v_x_24476});
      }
      default: return heff_nomatch(v_c_242);
      }
    }
    default: return heff_nomatch(v_x42_24459);
    }
  }
  case TAG_SCons: {
    V v_fields_24477 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SCons = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_xs_24478 = heff_take_field(v_fields_24477, 2);
    V v_t_24481 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_24478)), heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam54, 1, 5, (V[]){v_xs_24478, v_r_240, v_g_241, heff_dup(v_c_242), v_vs_244}));
    V v_t_24482 = ({ V rv_2 = v_t_24481; V rr_ = heff_rec_reuse_nf(v_fields_24477, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_x_24483 = heff_tag_at_n(v_ru_24x4_243_24SCons, TAG_VCons, 1, (V[]){v_t_24482});
    switch (heff_tag_of(v_c_242)) {
    case TAG_N: {
      return heff_tag_n(TAG_Nom, 1, (V[]){v_x_24483});
    }
    case TAG_De: {
      return heff_tag_n(TAG_Describe, 1, (V[]){v_x_24483});
    }
    default: return heff_nomatch(v_c_242);
    }
  }
  case TAG_SProj: {
    V v_t_24484 = heff_field(v_x4_243, 0);
    V v_x_24485 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    heff_drop(v_c_242);
    V v_x2_24486 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_24484, v_vs_244}));
    switch (heff_tag_of(v_x2_24486)) {
    case TAG_Nom: {
      V v_x_24487 = heff_field(v_x2_24486, 0);
      heff_take_n(v_x2_24486, 1ULL, 1);
      return (g_heff_2eelab_2evalue_2eproj(v_x_24487, v_x_24485));
    }
    case TAG_Describe: {
      V v_x_24488 = heff_field(v_x2_24486, 0);
      heff_take_n(v_x2_24486, 1ULL, 1);
      return (g_heff_2eelab_2evalue_2eproj(v_x_24488, v_x_24485));
    }
    case TAG_Become: {
      V v_x_24489 = heff_field(v_x2_24486, 0);
      V v_ru_24x2_24486_24Become = heff_take_reuse_n(v_x2_24486, 1ULL, 1);
      V v_x1_24490 = (g_heff_2eelab_2evalue_2eproj(v_x_24489, v_x_24485));
      V v_t_24494;
      switch (heff_tag_of(v_x1_24490)) {
      case TAG_Nom: {
        V v_x_24491 = heff_field(v_x1_24490, 0);
        heff_take_n(v_x1_24490, 1ULL, 1);
        v_t_24494 = v_x_24491;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_24490, 0ULL, 1);
        v_t_24494 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24493 = heff_field(v_x1_24490, 0);
        heff_take_n(v_x1_24490, 1ULL, 1);
        v_t_24494 = v_x_24493;
        break;
      }
      default: heff_nomatch(v_x1_24490);
      }
      return heff_tag_at_n(v_ru_24x2_24486_24Become, TAG_Become, 1, (V[]){v_t_24494});
    }
    default: return heff_nomatch(v_x2_24486);
    }
  }
  case TAG_STag: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 7);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SMatch: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 7);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SSpecialize: {
    V v_t_24499 = heff_field(v_x4_243, 0);
    V v_x_24500 = heff_field(v_x4_243, 1);
    V v_t_27_24501 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    heff_drop(v_c_242);
    V v_x1_24502 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 4, (V[]){heff_dup(v_g_241), NTAG(TAG_N), v_t_24499, heff_dup(v_vs_244)}));
    V v_t_24506;
    switch (heff_tag_of(v_x1_24502)) {
    case TAG_Nom: {
      V v_x_24503 = heff_field(v_x1_24502, 0);
      heff_take_n(v_x1_24502, 1ULL, 1);
      v_t_24506 = v_x_24503;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24502, 0ULL, 1);
      v_t_24506 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24505 = heff_field(v_x1_24502, 0);
      heff_take_n(v_x1_24502, 1ULL, 1);
      v_t_24506 = v_x_24505;
      break;
    }
    default: heff_nomatch(v_x1_24502);
    }
    V v_x1_24507 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_27_24501, v_vs_244}));
    V v_t_24511;
    switch (heff_tag_of(v_x1_24507)) {
    case TAG_Nom: {
      V v_x_24508 = heff_field(v_x1_24507, 0);
      heff_take_n(v_x1_24507, 1ULL, 1);
      v_t_24511 = v_x_24508;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24507, 0ULL, 1);
      v_t_24511 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24510 = heff_field(v_x1_24507, 0);
      heff_take_n(v_x1_24507, 1ULL, 1);
      v_t_24511 = v_x_24510;
      break;
    }
    default: heff_nomatch(v_x1_24507);
    }
    V v_t_24512 = (g_heff_2eelab_2evalue_2especialize(v_t_24506, v_x_24500, v_t_24511));
    return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24512});
  }
  case TAG_SIs: {
    V v_t_24513 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SIs = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    V v_x1_24514 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_24513, v_vs_244}));
    V v_t_24518;
    switch (heff_tag_of(v_x1_24514)) {
    case TAG_Nom: {
      V v_x_24515 = heff_field(v_x1_24514, 0);
      heff_take_n(v_x1_24514, 1ULL, 1);
      v_t_24518 = v_x_24515;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24514, 0ULL, 1);
      v_t_24518 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24517 = heff_field(v_x1_24514, 0);
      heff_take_n(v_x1_24514, 1ULL, 1);
      v_t_24518 = v_x_24517;
      break;
    }
    default: heff_nomatch(v_x1_24514);
    }
    return heff_tag_at_n(v_ru_24x4_243_24SIs, TAG_Become, 1, (V[]){v_t_24518});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 7);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 7);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SRec: {
    V v_ru_24x4_243_24SRec = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 7);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SRec, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SFix: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 7);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SImplicit: {
    V v_e_24523 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 2ULL, 2);
    return heff_tail(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, v_c_242, v_e_24523, v_vs_244});
  }
  case TAG_SPrim: {
    V v_ru_24x4_243_24SPrim = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 7);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SPrim, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SMetaApp: {
    V v_m_24525 = heff_field(v_x4_243, 0);
    V v_idxs_24526 = heff_field(v_x4_243, 1);
    V v_ty_24527 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    heff_drop(v_c_242);
    V v_sp_24531 = (g_array_2efoldlFrom(heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam55, 2, 1, (V[]){heff_dup(v_vs_244)}), MK_INT(0LL), NTAG(TAG_SpId), v_idxs_24526));
    V v_x1_24532 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_ty_24527, v_vs_244}));
    V v_ty_24536;
    switch (heff_tag_of(v_x1_24532)) {
    case TAG_Nom: {
      V v_x_24533 = heff_field(v_x1_24532, 0);
      heff_take_n(v_x1_24532, 1ULL, 1);
      v_ty_24536 = v_x_24533;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24532, 0ULL, 1);
      v_ty_24536 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24535 = heff_field(v_x1_24532, 0);
      heff_take_n(v_x1_24532, 1ULL, 1);
      v_ty_24536 = v_x_24535;
      break;
    }
    default: heff_nomatch(v_x1_24532);
    }
    V v_t_24538 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HMeta, 1, (V[]){v_m_24525}), v_sp_24531, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam56, 1, 1, (V[]){v_ty_24536}), NTAG(TAG_Nothing)));
    return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24538});
  }
  case TAG_SLitInt: {
    V v_ru_24x4_243_24SLitInt = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 7);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SLitInt, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFloat: {
    V v_ru_24x4_243_24SLitFloat = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 7);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SLitFloat, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitString: {
    V v_ru_24x4_243_24SLitString = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 7);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SLitString, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitBytes: {
    V v_ru_24x4_243_24SLitBytes = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 7);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SLitBytes, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitRune: {
    V v_ru_24x4_243_24SLitRune = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 7);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SLitRune, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 7);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFloat32: {
    V v_ru_24x4_243_24SLitFloat32 = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 7);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SLitFloat32, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eeval_2eevalTermF(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eeval_2eevalTermF_lam1(V self, V *args) {
  V v_u_2417 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2417);
  V v_x1_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_Nom: {
    V v_x_2419 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    return v_x_2419;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2418, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2421 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    return v_x_2421;
  }
  default: return heff_nomatch(v_x1_2418);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam0(V self, V *args) {
  V v_f_2416 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2416, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam1, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam3(V self, V *args) {
  V v_u_2434 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2434);
  V v_x1_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_Nom: {
    V v_x_2436 = heff_field(v_x1_2435, 0);
    heff_take_n(v_x1_2435, 1ULL, 1);
    return v_x_2436;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2435, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2438 = heff_field(v_x1_2435, 0);
    heff_take_n(v_x1_2435, 1ULL, 1);
    return v_x_2438;
  }
  default: return heff_nomatch(v_x1_2435);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam2(V self, V *args) {
  V v_f_2433 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2433, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam3, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam5(V self, V *args) {
  V v_u_2451 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2451);
  V v_x1_2452 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_2452)) {
  case TAG_Nom: {
    V v_x_2453 = heff_field(v_x1_2452, 0);
    heff_take_n(v_x1_2452, 1ULL, 1);
    return v_x_2453;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2452, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2455 = heff_field(v_x1_2452, 0);
    heff_take_n(v_x1_2452, 1ULL, 1);
    return v_x_2455;
  }
  default: return heff_nomatch(v_x1_2452);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam4(V self, V *args) {
  V v_f_2450 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2450, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam5, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam7(V self, V *args) {
  V v_u_2469 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2469);
  V v_x1_2470 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_2470)) {
  case TAG_Nom: {
    V v_x_2471 = heff_field(v_x1_2470, 0);
    heff_take_n(v_x1_2470, 1ULL, 1);
    return v_x_2471;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2470, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2473 = heff_field(v_x1_2470, 0);
    heff_take_n(v_x1_2470, 1ULL, 1);
    return v_x_2473;
  }
  default: return heff_nomatch(v_x1_2470);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam6(V self, V *args) {
  V v_f_2468 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2468, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam7, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam8(V self, V *args) {
  V v_u_2488 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2488);
  V v_x1_2489 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_2489)) {
  case TAG_Nom: {
    V v_x_2490 = heff_field(v_x1_2489, 0);
    heff_take_n(v_x1_2489, 1ULL, 1);
    return v_x_2490;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2489, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2492 = heff_field(v_x1_2489, 0);
    heff_take_n(v_x1_2489, 1ULL, 1);
    return v_x_2492;
  }
  default: return heff_nomatch(v_x1_2489);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam10(V self, V *args) {
  V v_u_2495 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2495);
  V v_x1_2496 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_2496)) {
  case TAG_Nom: {
    V v_x_2497 = heff_field(v_x1_2496, 0);
    heff_take_n(v_x1_2496, 1ULL, 1);
    return v_x_2497;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2496, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2499 = heff_field(v_x1_2496, 0);
    heff_take_n(v_x1_2496, 1ULL, 1);
    return v_x_2499;
  }
  default: return heff_nomatch(v_x1_2496);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam9(V self, V *args) {
  V v_f_2494 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2494, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam10, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam12(V self, V *args) {
  V v_u_24112 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24112);
  V v_x1_24113 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24113)) {
  case TAG_Nom: {
    V v_x_24114 = heff_field(v_x1_24113, 0);
    heff_take_n(v_x1_24113, 1ULL, 1);
    return v_x_24114;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24113, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24116 = heff_field(v_x1_24113, 0);
    heff_take_n(v_x1_24113, 1ULL, 1);
    return v_x_24116;
  }
  default: return heff_nomatch(v_x1_24113);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam11(V self, V *args) {
  V v_f_24111 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24111, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam12, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam14(V self, V *args) {
  V v_u_24130 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24130);
  V v_x1_24131 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24131)) {
  case TAG_Nom: {
    V v_x_24132 = heff_field(v_x1_24131, 0);
    heff_take_n(v_x1_24131, 1ULL, 1);
    return v_x_24132;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24131, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24134 = heff_field(v_x1_24131, 0);
    heff_take_n(v_x1_24131, 1ULL, 1);
    return v_x_24134;
  }
  default: return heff_nomatch(v_x1_24131);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam13(V self, V *args) {
  V v_f_24129 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24129, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam14, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam16(V self, V *args) {
  V v_u_24148 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24148);
  V v_x1_24149 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24149)) {
  case TAG_Nom: {
    V v_x_24150 = heff_field(v_x1_24149, 0);
    heff_take_n(v_x1_24149, 1ULL, 1);
    return v_x_24150;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24149, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24152 = heff_field(v_x1_24149, 0);
    heff_take_n(v_x1_24149, 1ULL, 1);
    return v_x_24152;
  }
  default: return heff_nomatch(v_x1_24149);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam15(V self, V *args) {
  V v_f_24147 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24147, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam16, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam18(V self, V *args) {
  V v_u_24166 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24166);
  V v_x1_24167 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24167)) {
  case TAG_Nom: {
    V v_x_24168 = heff_field(v_x1_24167, 0);
    heff_take_n(v_x1_24167, 1ULL, 1);
    return v_x_24168;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24167, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24170 = heff_field(v_x1_24167, 0);
    heff_take_n(v_x1_24167, 1ULL, 1);
    return v_x_24170;
  }
  default: return heff_nomatch(v_x1_24167);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam17(V self, V *args) {
  V v_f_24165 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24165, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam18, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam20(V self, V *args) {
  V v_u_24185 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24185);
  V v_x1_24186 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24186)) {
  case TAG_Nom: {
    V v_x_24187 = heff_field(v_x1_24186, 0);
    heff_take_n(v_x1_24186, 1ULL, 1);
    return v_x_24187;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24186, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24189 = heff_field(v_x1_24186, 0);
    heff_take_n(v_x1_24186, 1ULL, 1);
    return v_x_24189;
  }
  default: return heff_nomatch(v_x1_24186);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam19(V self, V *args) {
  V v_f_24184 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24184, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam20, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam22(V self, V *args) {
  V v_u_24202 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24202);
  V v_x1_24203 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24203)) {
  case TAG_Nom: {
    V v_x_24204 = heff_field(v_x1_24203, 0);
    heff_take_n(v_x1_24203, 1ULL, 1);
    return v_x_24204;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24203, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24206 = heff_field(v_x1_24203, 0);
    heff_take_n(v_x1_24203, 1ULL, 1);
    return v_x_24206;
  }
  default: return heff_nomatch(v_x1_24203);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam21(V self, V *args) {
  V v_f_24201 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24201, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam22, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam24(V self, V *args) {
  V v_u_24218 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24218);
  V v_x1_24219 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24219)) {
  case TAG_Nom: {
    V v_x_24220 = heff_field(v_x1_24219, 0);
    heff_take_n(v_x1_24219, 1ULL, 1);
    return v_x_24220;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24219, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24222 = heff_field(v_x1_24219, 0);
    heff_take_n(v_x1_24219, 1ULL, 1);
    return v_x_24222;
  }
  default: return heff_nomatch(v_x1_24219);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam23(V self, V *args) {
  V v_f_24217 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24217, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam24, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam26(V self, V *args) {
  V v_u_24234 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24234);
  V v_x1_24235 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24235)) {
  case TAG_Nom: {
    V v_x_24236 = heff_field(v_x1_24235, 0);
    heff_take_n(v_x1_24235, 1ULL, 1);
    return v_x_24236;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24235, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24238 = heff_field(v_x1_24235, 0);
    heff_take_n(v_x1_24235, 1ULL, 1);
    return v_x_24238;
  }
  default: return heff_nomatch(v_x1_24235);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam25(V self, V *args) {
  V v_f_24233 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24233, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam26, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam28(V self, V *args) {
  V v_u_24251 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24251);
  V v_x1_24252 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24252)) {
  case TAG_Nom: {
    V v_x_24253 = heff_field(v_x1_24252, 0);
    heff_take_n(v_x1_24252, 1ULL, 1);
    return v_x_24253;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24252, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24255 = heff_field(v_x1_24252, 0);
    heff_take_n(v_x1_24252, 1ULL, 1);
    return v_x_24255;
  }
  default: return heff_nomatch(v_x1_24252);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam27(V self, V *args) {
  V v_f_24250 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24250, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam28, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam30(V self, V *args) {
  V v_u_24269 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24269);
  V v_x1_24270 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24270)) {
  case TAG_Nom: {
    V v_x_24271 = heff_field(v_x1_24270, 0);
    heff_take_n(v_x1_24270, 1ULL, 1);
    return v_x_24271;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24270, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24273 = heff_field(v_x1_24270, 0);
    heff_take_n(v_x1_24270, 1ULL, 1);
    return v_x_24273;
  }
  default: return heff_nomatch(v_x1_24270);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam29(V self, V *args) {
  V v_f_24268 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24268, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam30, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam32(V self, V *args) {
  V v_u_24287 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24287);
  V v_x1_24288 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24288)) {
  case TAG_Nom: {
    V v_x_24289 = heff_field(v_x1_24288, 0);
    heff_take_n(v_x1_24288, 1ULL, 1);
    return v_x_24289;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24288, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24291 = heff_field(v_x1_24288, 0);
    heff_take_n(v_x1_24288, 1ULL, 1);
    return v_x_24291;
  }
  default: return heff_nomatch(v_x1_24288);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam31(V self, V *args) {
  V v_f_24286 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24286, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam32, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam34(V self, V *args) {
  V v_u_24304 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24304);
  V v_x1_24305 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24305)) {
  case TAG_Nom: {
    V v_x_24306 = heff_field(v_x1_24305, 0);
    heff_take_n(v_x1_24305, 1ULL, 1);
    return v_x_24306;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24305, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24308 = heff_field(v_x1_24305, 0);
    heff_take_n(v_x1_24305, 1ULL, 1);
    return v_x_24308;
  }
  default: return heff_nomatch(v_x1_24305);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam33(V self, V *args) {
  V v_f_24303 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24303, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam34, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam36(V self, V *args) {
  V v_u_24323 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24323);
  V v_x1_24324 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24324)) {
  case TAG_Nom: {
    V v_x_24325 = heff_field(v_x1_24324, 0);
    heff_take_n(v_x1_24324, 1ULL, 1);
    return v_x_24325;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24324, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24327 = heff_field(v_x1_24324, 0);
    heff_take_n(v_x1_24324, 1ULL, 1);
    return v_x_24327;
  }
  default: return heff_nomatch(v_x1_24324);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam35(V self, V *args) {
  V v_f_24322 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24322, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam36, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam38(V self, V *args) {
  V v_u_24340 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24340);
  V v_x1_24341 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24341)) {
  case TAG_Nom: {
    V v_x_24342 = heff_field(v_x1_24341, 0);
    heff_take_n(v_x1_24341, 1ULL, 1);
    return v_x_24342;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24341, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24344 = heff_field(v_x1_24341, 0);
    heff_take_n(v_x1_24341, 1ULL, 1);
    return v_x_24344;
  }
  default: return heff_nomatch(v_x1_24341);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam37(V self, V *args) {
  V v_f_24339 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24339, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam38, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam40(V self, V *args) {
  V v_u_24357 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24357);
  V v_x1_24358 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24358)) {
  case TAG_Nom: {
    V v_x_24359 = heff_field(v_x1_24358, 0);
    heff_take_n(v_x1_24358, 1ULL, 1);
    return v_x_24359;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24358, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24361 = heff_field(v_x1_24358, 0);
    heff_take_n(v_x1_24358, 1ULL, 1);
    return v_x_24361;
  }
  default: return heff_nomatch(v_x1_24358);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam39(V self, V *args) {
  V v_f_24356 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24356, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam40, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam42(V self, V *args) {
  V v_u_24374 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24374);
  V v_x1_24375 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24375)) {
  case TAG_Nom: {
    V v_x_24376 = heff_field(v_x1_24375, 0);
    heff_take_n(v_x1_24375, 1ULL, 1);
    return v_x_24376;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24375, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24378 = heff_field(v_x1_24375, 0);
    heff_take_n(v_x1_24375, 1ULL, 1);
    return v_x_24378;
  }
  default: return heff_nomatch(v_x1_24375);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam41(V self, V *args) {
  V v_f_24373 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24373, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam42, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam44(V self, V *args) {
  V v_u_24391 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24391);
  V v_x1_24392 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24392)) {
  case TAG_Nom: {
    V v_x_24393 = heff_field(v_x1_24392, 0);
    heff_take_n(v_x1_24392, 1ULL, 1);
    return v_x_24393;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24392, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24395 = heff_field(v_x1_24392, 0);
    heff_take_n(v_x1_24392, 1ULL, 1);
    return v_x_24395;
  }
  default: return heff_nomatch(v_x1_24392);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam43(V self, V *args) {
  V v_f_24390 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24390, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam44, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam46(V self, V *args) {
  V v_u_24408 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24408);
  V v_x1_24409 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24409)) {
  case TAG_Nom: {
    V v_x_24410 = heff_field(v_x1_24409, 0);
    heff_take_n(v_x1_24409, 1ULL, 1);
    return v_x_24410;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24409, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24412 = heff_field(v_x1_24409, 0);
    heff_take_n(v_x1_24409, 1ULL, 1);
    return v_x_24412;
  }
  default: return heff_nomatch(v_x1_24409);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam45(V self, V *args) {
  V v_f_24407 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24407, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam46, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam48(V self, V *args) {
  V v_u_24426 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24426);
  V v_x1_24427 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24427)) {
  case TAG_Nom: {
    V v_x_24428 = heff_field(v_x1_24427, 0);
    heff_take_n(v_x1_24427, 1ULL, 1);
    return v_x_24428;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24427, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24430 = heff_field(v_x1_24427, 0);
    heff_take_n(v_x1_24427, 1ULL, 1);
    return v_x_24430;
  }
  default: return heff_nomatch(v_x1_24427);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam47(V self, V *args) {
  V v_f_24425 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24425, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam48, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam50(V self, V *args) {
  V v_u_24443 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24443);
  V v_x1_24444 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2414, v_vs_244}));
  switch (heff_tag_of(v_x1_24444)) {
  case TAG_Nom: {
    V v_x_24445 = heff_field(v_x1_24444, 0);
    heff_take_n(v_x1_24444, 1ULL, 1);
    return v_x_24445;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24444, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24447 = heff_field(v_x1_24444, 0);
    heff_take_n(v_x1_24444, 1ULL, 1);
    return v_x_24447;
  }
  default: return heff_nomatch(v_x1_24444);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam49(V self, V *args) {
  V v_f_24442 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2414 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24442, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam50, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2414, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam51(V self, V *args) {
  V v_u_24462 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_dom_24458 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24462);
  V v_x1_24463 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_dom_24458, v_vs_244}));
  switch (heff_tag_of(v_x1_24463)) {
  case TAG_Nom: {
    V v_x_24464 = heff_field(v_x1_24463, 0);
    heff_take_n(v_x1_24463, 1ULL, 1);
    return v_x_24464;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24463, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24466 = heff_field(v_x1_24463, 0);
    heff_take_n(v_x1_24463, 1ULL, 1);
    return v_x_24466;
  }
  default: return heff_nomatch(v_x1_24463);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam52(V self, V *args) {
  V v_vs2_24467 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_c_242 = heff_env(self)[2];
  V v_t_24461 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_r_240, 0, 2);
  heff_room[0] = v_g_241;
  heff_room[1] = v_c_242;
  heff_room[2] = v_t_24461;
  heff_room[3] = v_vs2_24467;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eeval_2eevalTermF_lam53(V self, V *args) {
  V v_u_24471 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_dom_24458 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24471);
  V v_x1_24472 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_dom_24458, v_vs_244}));
  switch (heff_tag_of(v_x1_24472)) {
  case TAG_Nom: {
    V v_x_24473 = heff_field(v_x1_24472, 0);
    heff_take_n(v_x1_24472, 1ULL, 1);
    return v_x_24473;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24472, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24475 = heff_field(v_x1_24472, 0);
    heff_take_n(v_x1_24472, 1ULL, 1);
    return v_x_24475;
  }
  default: return heff_nomatch(v_x1_24472);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam54(V self, V *args) {
  V v_i_24479 = args[0];
  V v_xs_24478 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_c_242 = heff_env(self)[3];
  V v_vs_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24480 = heff_arrayIndex(v_xs_24478, v_i_24479);
  V f_ = heff_get_n(v_r_240, 0, 2);
  heff_room[0] = v_g_241;
  heff_room[1] = v_c_242;
  heff_room[2] = v_t_24480;
  heff_room[3] = v_vs_244;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eeval_2eevalTermF_lam55(V self, V *args) {
  V v_sp_24528 = args[0];
  V v_i_24529 = args[1];
  V v_vs_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24530 = ({ V a_0 = v_vs_244; V a_1 = v_i_24529; V r_ = heff_tr(g_heff_2eelab_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_vs_244); r_; });
  return heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_24528, v_t_24530});
}
V g_heff_2eelab_2eeval_2eevalTermF_lam56(V self, V *args) {
  V v_u_24537 = args[0];
  V v_ty_24536 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24537);
  return v_ty_24536;
}
V g_heff_2eelab_2eeval_2eevalTypeF_lam0(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_lam2(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_lam1(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_lam5(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_lam4(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_lam3(V self, V *args);
Clo g_heff_2eelab_2eeval_2eevalTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_entry, 5, 0};

V g_heff_2eelab_2eeval_2eevalTypeF(V v_r_240, V v_g_241, V v_c_242, V v_x4_243, V v_vs_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_SU: {
    V v_u_245 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SU = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SU, TAG_Nom, 1, (V[]){heff_tag_n(TAG_VU, 1, (V[]){v_u_245})});
  }
  case TAG_SDecode: {
    V v_t_246 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SDecode = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, v_c_242, v_t_246, v_vs_244}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nom: {
      V v_x_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      V v_t_249 = ({ V a_0 = v_x_248; V r_ = (g_heff_2eelab_2evalue_2edecodeN(a_0)); heff_drop(v_x_248); r_; });
      return heff_tag_at_n(v_ru_24x4_243_24SDecode, TAG_Nom, 1, (V[]){v_t_249});
    }
    case TAG_Describe: {
      V v_x_2410 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      switch (heff_tag_of(v_x_2410)) {
      case TAG_VNeu: {
        heff_take_n(v_x_2410, 0ULL, 5);
        heff_drop_cell(v_ru_24x4_243_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VCode: {
        V v_a_2416 = heff_field(v_x_2410, 0);
        heff_take_n(v_x_2410, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x4_243_24SDecode, TAG_Describe, 1, (V[]){v_a_2416});
      }
      case TAG_VLam: {
        heff_take_n(v_x_2410, 0ULL, 2);
        heff_drop_cell(v_ru_24x4_243_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_x_2410, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VOpaque: {
        heff_drop_cell(v_ru_24x4_243_24SDecode, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_x_2410);
      }
    }
    case TAG_Become: {
      V v_x_2420 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      V v_t_2421 = ({ V a_0 = v_x_2420; V r_ = (g_heff_2eelab_2evalue_2edecodeN(a_0)); heff_drop(v_x_2420); r_; });
      return heff_tag_at_n(v_ru_24x4_243_24SDecode, TAG_Become, 1, (V[]){v_t_2421});
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_SFunction: {
    V v_level_2422 = heff_field(v_x4_243, 0);
    V v_dom_2423 = heff_field(v_x4_243, 1);
    V v_cod_2424 = heff_field(v_x4_243, 2);
    V v_implicit_2425 = heff_field(v_x4_243, 3);
    V v_dflt_2426 = heff_field(v_x4_243, 4);
    V v_ru_24x4_243_24SFunction = heff_take_reuse_n(v_x4_243, 31ULL, 5);
    heff_drop(v_c_242);
    V v_x1_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 4, (V[]){heff_dup(v_g_241), NTAG(TAG_N), v_dom_2423, heff_dup(v_vs_244)}));
    V v_t_2431;
    switch (heff_tag_of(v_x1_2427)) {
    case TAG_Nom: {
      V v_x_2428 = heff_field(v_x1_2427, 0);
      heff_take_n(v_x1_2427, 1ULL, 1);
      v_t_2431 = v_x_2428;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2427, 0ULL, 1);
      v_t_2431 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2430 = heff_field(v_x1_2427, 0);
      heff_take_n(v_x1_2427, 1ULL, 1);
      v_t_2431 = v_x_2430;
      break;
    }
    default: heff_nomatch(v_x1_2427);
    }
    V v_t_2437;
    switch (heff_tag_of(v_cod_2424)) {
    case TAG_MkAbs: {
      V v_x_2432 = heff_field(v_cod_2424, 0);
      V v_t_2433 = heff_field(v_cod_2424, 1);
      heff_take_n(v_cod_2424, 3ULL, 2);
      v_t_2437 = heff_tag_n(TAG_MkClo, 3, (V[]){v_x_2432, v_vs_244, heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_lam0, 1, 3, (V[]){v_r_240, v_g_241, v_t_2433})});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2435 = heff_field(v_cod_2424, 0);
      V v_ru_24cod_2424_24AbsConst = heff_take_reuse_n(v_cod_2424, 1ULL, 1);
      V v_t_2436 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2435, v_vs_244}));
      v_t_2437 = heff_tag_at_n(v_ru_24cod_2424_24AbsConst, TAG_CloConst, 1, (V[]){v_t_2436});
      break;
    }
    default: heff_nomatch(v_cod_2424);
    }
    return heff_tag_n(TAG_Nom, 1, (V[]){heff_tag_at_n(v_ru_24x4_243_24SFunction, TAG_VFunction, 5, (V[]){v_level_2422, v_t_2431, v_t_2437, v_implicit_2425, v_dflt_2426})});
  }
  case TAG_SRecord: {
    V v_level_2438 = heff_field(v_x4_243, 0);
    V v_fieldTypes_2439 = heff_field(v_x4_243, 1);
    V v_defaults_2440 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    heff_drop(v_c_242);
    V v_xs_2441 = heff_take_field(v_fieldTypes_2439, 2);
    V v_t_2450 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2441)), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_lam1, 1, 3, (V[]){v_xs_2441, v_r_240, v_g_241}));
    V v_t_2451 = ({ V rv_2 = v_t_2450; V rr_ = heff_rec_reuse_nf(v_fieldTypes_2439, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_Describe, 1, (V[]){heff_tag_n(TAG_VRecord, 4, (V[]){v_level_2438, v_vs_244, v_t_2451, v_defaults_2440})});
  }
  case TAG_SSum: {
    V v_st_2452 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SSum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    V v_xs_2453 = heff_take_field(v_st_2452, 2);
    V v_t_2463 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2453)), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_lam3, 1, 4, (V[]){v_xs_2453, v_r_240, v_g_241, v_vs_244}));
    V v_t_2464 = ({ V rv_2 = v_t_2463; V rr_ = heff_rec_reuse_nf(v_st_2452, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24x4_243_24SSum, TAG_Describe, 1, (V[]){heff_tag_n(TAG_VSum, 1, (V[]){v_t_2464})});
  }
  case TAG_SIsTy: {
    V v_t_2465 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SIsTy = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    V v_x1_2466 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2465, v_vs_244}));
    V v_t_2470;
    switch (heff_tag_of(v_x1_2466)) {
    case TAG_Nom: {
      V v_x_2467 = heff_field(v_x1_2466, 0);
      heff_take_n(v_x1_2466, 1ULL, 1);
      v_t_2470 = v_x_2467;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2466, 0ULL, 1);
      v_t_2470 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2469 = heff_field(v_x1_2466, 0);
      heff_take_n(v_x1_2466, 1ULL, 1);
      v_t_2470 = v_x_2469;
      break;
    }
    default: heff_nomatch(v_x1_2466);
    }
    return heff_tag_at_n(v_ru_24x4_243_24SIsTy, TAG_Become, 1, (V[]){v_t_2470});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimInt)});
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimFloat)});
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimString)});
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimRune)});
  }
  case TAG_SPrimArray: {
    V v_a_2471 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SPrimArray = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    V v_x1_2472 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_a_2471, v_vs_244}));
    V v_t_2476;
    switch (heff_tag_of(v_x1_2472)) {
    case TAG_Nom: {
      V v_x_2473 = heff_field(v_x1_2472, 0);
      heff_take_n(v_x1_2472, 1ULL, 1);
      v_t_2476 = v_x_2473;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2472, 0ULL, 1);
      v_t_2476 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2475 = heff_field(v_x1_2472, 0);
      heff_take_n(v_x1_2472, 1ULL, 1);
      v_t_2476 = v_x_2475;
      break;
    }
    default: heff_nomatch(v_x1_2472);
    }
    return heff_tag_at_n(v_ru_24x4_243_24SPrimArray, TAG_Nom, 1, (V[]){heff_tag_n(TAG_VPrimArray, 1, (V[]){v_t_2476})});
  }
  case TAG_SFixed: {
    V v_w_2477 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SFixed = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SFixed, TAG_Nom, 1, (V[]){heff_tag_n(TAG_VFixed, 1, (V[]){v_w_2477})});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eeval_2eevalTypeF(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eeval_2eevalTypeF_lam0(V self, V *args) {
  V v_vs2_2434 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t_2433 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_get_n(v_r_240, 1, 2);
  heff_room[0] = v_g_241;
  heff_room[1] = NTAG(TAG_N);
  heff_room[2] = v_t_2433;
  heff_room[3] = v_vs2_2434;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eeval_2eevalTypeF_lam2(V self, V *args) {
  V v_vs2_2444 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t_2443 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_2445 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2443, v_vs2_2444}));
  V v_t_2449;
  switch (heff_tag_of(v_x1_2445)) {
  case TAG_Nom: {
    V v_x_2446 = heff_field(v_x1_2445, 0);
    heff_take_n(v_x1_2445, 1ULL, 1);
    v_t_2449 = v_x_2446;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2445, 0ULL, 1);
    v_t_2449 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2448 = heff_field(v_x1_2445, 0);
    heff_take_n(v_x1_2445, 1ULL, 1);
    v_t_2449 = v_x_2448;
    break;
  }
  default: heff_nomatch(v_x1_2445);
  }
  return heff_tag_n(TAG_MkField, 2, (V[]){v_t_2449, NTAG(TAG_Nothing)});
}
V g_heff_2eelab_2eeval_2eevalTypeF_lam1(V self, V *args) {
  V v_i_2442 = args[0];
  V v_xs_2441 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2443 = heff_arrayIndex(v_xs_2441, v_i_2442);
  return heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_lam2, 1, 3, (V[]){v_r_240, v_g_241, v_t_2443});
}
V g_heff_2eelab_2eeval_2eevalTypeF_lam5(V self, V *args) {
  V v_u_2458 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t_2457 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2458);
  V v_x1_2459 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2457, v_vs_244}));
  switch (heff_tag_of(v_x1_2459)) {
  case TAG_Nom: {
    V v_x_2460 = heff_field(v_x1_2459, 0);
    heff_take_n(v_x1_2459, 1ULL, 1);
    return v_x_2460;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2459, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2462 = heff_field(v_x1_2459, 0);
    heff_take_n(v_x1_2459, 1ULL, 1);
    return v_x_2462;
  }
  default: return heff_nomatch(v_x1_2459);
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_lam4(V self, V *args) {
  V v_i_2456 = args[0];
  V v_xs_2455 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2457 = heff_arrayIndex(v_xs_2455, v_i_2456);
  return heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_lam5, 1, 4, (V[]){v_r_240, v_g_241, v_t_2457, v_vs_244});
}
V g_heff_2eelab_2eeval_2eevalTypeF_lam3(V self, V *args) {
  V v_i_2454 = args[0];
  V v_xs_2453 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_xs_2455 = heff_arrayIndex(v_xs_2453, v_i_2454);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2455)), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_lam4, 1, 4, (V[]){v_xs_2455, v_r_240, v_g_241, v_vs_244}));
}
V g_heff_2eelab_2eeval_2eevaluator_lam0(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevaluator_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevaluator_lam0, 4, 0};
V g_heff_2eelab_2eeval_2eevaluator_lam1(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevaluator_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevaluator_lam1, 4, 0};

static V g_heff_2eelab_2eeval_2eevaluator_val;
static HEFF_ONCE g_heff_2eelab_2eeval_2eevaluator_st;
static V g_heff_2eelab_2eeval_2eevaluator_init(void) {
  return heff_rec_n(2, shape_el__ty, (V[]){((V)&g_heff_2eelab_2eeval_2eevaluator_lam0_clo), ((V)&g_heff_2eelab_2eeval_2eevaluator_lam1_clo)});
}
V g_heff_2eelab_2eeval_2eevaluator_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eeval_2eevaluator_st)) return g_heff_2eelab_2eeval_2eevaluator_val;
  return heff_global(&g_heff_2eelab_2eeval_2eevaluator_val, &g_heff_2eelab_2eeval_2eevaluator_st, g_heff_2eelab_2eeval_2eevaluator_init);
}
V g_heff_2eelab_2eeval_2eevaluator_lam0(V self, V *args) {
  V v_g_240 = args[0];
  V v_c_241 = args[1];
  V v_s_242 = args[2];
  V v_vs_243 = args[3];
  return (g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, v_c_241, v_s_242, v_vs_243));
}
V g_heff_2eelab_2eeval_2eevaluator_lam1(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_s_246 = args[2];
  V v_vs_247 = args[3];
  return (g_heff_2eelab_2eeval_2eevalTypeF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_244, v_c_245, v_s_246, v_vs_247));
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam0(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam2(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam1(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam5(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam4(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam3(V self, V *args);
Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry, 4, 0};

V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V v_g_240, V v_c_241, V v_x4_242, V v_vs_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SU: {
    V v_u_244 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SU = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_at_n(v_ru_24x4_242_24SU, TAG_Nom, 1, (V[]){heff_tag_n(TAG_VU, 1, (V[]){v_u_244})});
  }
  case TAG_SDecode: {
    V v_t_245 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SDecode = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_x1_246 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, v_c_241, v_t_245, v_vs_243));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nom: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      V v_t_248 = ({ V a_0 = v_x_247; V r_ = (g_heff_2eelab_2evalue_2edecodeN(a_0)); heff_drop(v_x_247); r_; });
      return heff_tag_at_n(v_ru_24x4_242_24SDecode, TAG_Nom, 1, (V[]){v_t_248});
    }
    case TAG_Describe: {
      V v_x_249 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_x_249)) {
      case TAG_VNeu: {
        heff_take_n(v_x_249, 0ULL, 5);
        heff_drop_cell(v_ru_24x4_242_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VCode: {
        V v_a_2415 = heff_field(v_x_249, 0);
        heff_take_n(v_x_249, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x4_242_24SDecode, TAG_Describe, 1, (V[]){v_a_2415});
      }
      case TAG_VLam: {
        heff_take_n(v_x_249, 0ULL, 2);
        heff_drop_cell(v_ru_24x4_242_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_x_249, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_242_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VOpaque: {
        heff_drop_cell(v_ru_24x4_242_24SDecode, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_x_249);
      }
    }
    case TAG_Become: {
      V v_x_2419 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      V v_t_2420 = ({ V a_0 = v_x_2419; V r_ = (g_heff_2eelab_2evalue_2edecodeN(a_0)); heff_drop(v_x_2419); r_; });
      return heff_tag_at_n(v_ru_24x4_242_24SDecode, TAG_Become, 1, (V[]){v_t_2420});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_SFunction: {
    V v_level_2421 = heff_field(v_x4_242, 0);
    V v_dom_2422 = heff_field(v_x4_242, 1);
    V v_cod_2423 = heff_field(v_x4_242, 2);
    V v_implicit_2424 = heff_field(v_x4_242, 3);
    V v_dflt_2425 = heff_field(v_x4_242, 4);
    V v_ru_24x4_242_24SFunction = heff_take_reuse_n(v_x4_242, 31ULL, 5);
    heff_drop(v_c_241);
    V v_x1_2426 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(heff_dup(v_g_240), NTAG(TAG_N), v_dom_2422, heff_dup(v_vs_243)));
    V v_t_2430;
    switch (heff_tag_of(v_x1_2426)) {
    case TAG_Nom: {
      V v_x_2427 = heff_field(v_x1_2426, 0);
      heff_take_n(v_x1_2426, 1ULL, 1);
      v_t_2430 = v_x_2427;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2426, 0ULL, 1);
      v_t_2430 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2429 = heff_field(v_x1_2426, 0);
      heff_take_n(v_x1_2426, 1ULL, 1);
      v_t_2430 = v_x_2429;
      break;
    }
    default: heff_nomatch(v_x1_2426);
    }
    V v_t_2436;
    switch (heff_tag_of(v_cod_2423)) {
    case TAG_MkAbs: {
      V v_x_2431 = heff_field(v_cod_2423, 0);
      V v_t_2432 = heff_field(v_cod_2423, 1);
      heff_take_n(v_cod_2423, 3ULL, 2);
      v_t_2436 = heff_tag_n(TAG_MkClo, 3, (V[]){v_x_2431, v_vs_243, heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam0, 1, 2, (V[]){v_g_240, v_t_2432})});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2434 = heff_field(v_cod_2423, 0);
      V v_ru_24cod_2423_24AbsConst = heff_take_reuse_n(v_cod_2423, 1ULL, 1);
      V v_t_2435 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_t_2434, v_vs_243));
      v_t_2436 = heff_tag_at_n(v_ru_24cod_2423_24AbsConst, TAG_CloConst, 1, (V[]){v_t_2435});
      break;
    }
    default: heff_nomatch(v_cod_2423);
    }
    return heff_tag_n(TAG_Nom, 1, (V[]){heff_tag_at_n(v_ru_24x4_242_24SFunction, TAG_VFunction, 5, (V[]){v_level_2421, v_t_2430, v_t_2436, v_implicit_2424, v_dflt_2425})});
  }
  case TAG_SRecord: {
    V v_level_2437 = heff_field(v_x4_242, 0);
    V v_fieldTypes_2438 = heff_field(v_x4_242, 1);
    V v_defaults_2439 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    heff_drop(v_c_241);
    V v_xs_2440 = heff_take_field(v_fieldTypes_2438, 2);
    V v_t_2449 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2440)), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam1, 1, 2, (V[]){v_xs_2440, v_g_240}));
    V v_t_2450 = ({ V rv_2 = v_t_2449; V rr_ = heff_rec_reuse_nf(v_fieldTypes_2438, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_Describe, 1, (V[]){heff_tag_n(TAG_VRecord, 4, (V[]){v_level_2437, v_vs_243, v_t_2450, v_defaults_2439})});
  }
  case TAG_SSum: {
    V v_st_2451 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SSum = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    V v_xs_2452 = heff_take_field(v_st_2451, 2);
    V v_t_2462 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2452)), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam3, 1, 3, (V[]){v_xs_2452, v_g_240, v_vs_243}));
    V v_t_2463 = ({ V rv_2 = v_t_2462; V rr_ = heff_rec_reuse_nf(v_st_2451, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24x4_242_24SSum, TAG_Describe, 1, (V[]){heff_tag_n(TAG_VSum, 1, (V[]){v_t_2463})});
  }
  case TAG_SIsTy: {
    V v_t_2464 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SIsTy = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    V v_x1_2465 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_t_2464, v_vs_243));
    V v_t_2469;
    switch (heff_tag_of(v_x1_2465)) {
    case TAG_Nom: {
      V v_x_2466 = heff_field(v_x1_2465, 0);
      heff_take_n(v_x1_2465, 1ULL, 1);
      v_t_2469 = v_x_2466;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2465, 0ULL, 1);
      v_t_2469 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2468 = heff_field(v_x1_2465, 0);
      heff_take_n(v_x1_2465, 1ULL, 1);
      v_t_2469 = v_x_2468;
      break;
    }
    default: heff_nomatch(v_x1_2465);
    }
    return heff_tag_at_n(v_ru_24x4_242_24SIsTy, TAG_Become, 1, (V[]){v_t_2469});
  }
  case TAG_SPrimInt: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimInt)});
  }
  case TAG_SPrimFloat: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimFloat)});
  }
  case TAG_SPrimString: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimString)});
  }
  case TAG_SPrimRune: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimRune)});
  }
  case TAG_SPrimArray: {
    V v_a_2470 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SPrimArray = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    V v_x1_2471 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_a_2470, v_vs_243));
    V v_t_2475;
    switch (heff_tag_of(v_x1_2471)) {
    case TAG_Nom: {
      V v_x_2472 = heff_field(v_x1_2471, 0);
      heff_take_n(v_x1_2471, 1ULL, 1);
      v_t_2475 = v_x_2472;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2471, 0ULL, 1);
      v_t_2475 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2474 = heff_field(v_x1_2471, 0);
      heff_take_n(v_x1_2471, 1ULL, 1);
      v_t_2475 = v_x_2474;
      break;
    }
    default: heff_nomatch(v_x1_2471);
    }
    return heff_tag_at_n(v_ru_24x4_242_24SPrimArray, TAG_Nom, 1, (V[]){heff_tag_n(TAG_VPrimArray, 1, (V[]){v_t_2475})});
  }
  case TAG_SFixed: {
    V v_w_2476 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SFixed = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_at_n(v_ru_24x4_242_24SFixed, TAG_Nom, 1, (V[]){heff_tag_n(TAG_VFixed, 1, (V[]){v_w_2476})});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam0(V self, V *args) {
  V v_vs2_2433 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_t_2432, v_vs2_2433));
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam2(V self, V *args) {
  V v_vs2_2443 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2442 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2444 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_t_2442, v_vs2_2443));
  V v_t_2448;
  switch (heff_tag_of(v_x1_2444)) {
  case TAG_Nom: {
    V v_x_2445 = heff_field(v_x1_2444, 0);
    heff_take_n(v_x1_2444, 1ULL, 1);
    v_t_2448 = v_x_2445;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2444, 0ULL, 1);
    v_t_2448 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2447 = heff_field(v_x1_2444, 0);
    heff_take_n(v_x1_2444, 1ULL, 1);
    v_t_2448 = v_x_2447;
    break;
  }
  default: heff_nomatch(v_x1_2444);
  }
  return heff_tag_n(TAG_MkField, 2, (V[]){v_t_2448, NTAG(TAG_Nothing)});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam1(V self, V *args) {
  V v_i_2441 = args[0];
  V v_xs_2440 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2442 = heff_arrayIndex(v_xs_2440, v_i_2441);
  return heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam2, 1, 2, (V[]){v_g_240, v_t_2442});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam5(V self, V *args) {
  V v_u_2457 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2456 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2457);
  V v_x1_2458 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_t_2456, v_vs_243));
  switch (heff_tag_of(v_x1_2458)) {
  case TAG_Nom: {
    V v_x_2459 = heff_field(v_x1_2458, 0);
    heff_take_n(v_x1_2458, 1ULL, 1);
    return v_x_2459;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2458, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2461 = heff_field(v_x1_2458, 0);
    heff_take_n(v_x1_2458, 1ULL, 1);
    return v_x_2461;
  }
  default: return heff_nomatch(v_x1_2458);
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam4(V self, V *args) {
  V v_i_2455 = args[0];
  V v_xs_2454 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2456 = heff_arrayIndex(v_xs_2454, v_i_2455);
  return heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam5, 1, 3, (V[]){v_g_240, v_t_2456, v_vs_243});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam3(V self, V *args) {
  V v_i_2453 = args[0];
  V v_xs_2452 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_xs_2454 = heff_arrayIndex(v_xs_2452, v_i_2453);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2454)), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_lam4, 1, 3, (V[]){v_xs_2454, v_g_240, v_vs_243}));
}