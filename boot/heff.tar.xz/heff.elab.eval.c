// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_HError 21467
#define TAG_HMeta 17321
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_entries 787768015
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_value 313331083
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_array_2efoldlFrom(V, V, V, V);
V g_array_2efoldlFrom_entry(V self, V *a);
extern Clo g_array_2efoldlFrom_clo;
V g_heff_2eelab_2eeval_2eerrorHeaded(V);
V g_heff_2eelab_2eeval_2eerrorHeaded_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eerrorHeaded_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevalTypeF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24cpr(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
HeffT2 g_heff_2eelab_2evalue_2edecodeEv_24cpr(V);
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263(V);
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_clo;
V g_heff_2eelab_2evalue_2efieldIn(V, V);
V g_heff_2eelab_2evalue_2efieldIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2efieldIn_clo;
V g_heff_2eelab_2evalue_2elocalsAt(V, V);
V g_heff_2eelab_2evalue_2elocalsAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elocalsAt_clo;
V g_heff_2eelab_2evalue_2ereflect(V, V, V, V);
V g_heff_2eelab_2evalue_2ereflect_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_clo;
V g_heff_2eelab_2evalue_2ereflect_24s1249042670x1731126382(V, V);
V g_heff_2eelab_2evalue_2ereflect_24s1249042670x1731126382_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_24s1249042670x1731126382_clo;
V g_heff_2eelab_2evalue_2especialize(V, V, V);
V g_heff_2eelab_2evalue_2especialize_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2especialize_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_heff_2eelab_2eeval_2eevalTermF_lam1(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam0(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam3(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam2(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam5(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam4(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam7(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam6(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam8(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam10(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam9(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam12(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam11(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam14(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam13(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam16(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam15(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam18(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam17(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam20(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam19(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam22(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam21(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam24(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam23(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam26(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam25(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam28(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam27(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam30(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam29(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam32(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam31(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam34(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam33(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam36(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam35(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam38(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam37(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam40(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam39(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam42(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam41(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam44(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam43(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam46(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam45(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam48(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam47(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam50(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam49(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam51(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam52(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam53(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam54(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam55(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam56(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam57(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_lam58(V self, V *args);
Clo g_heff_2eelab_2eeval_2eevalTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTermF_entry, 5, 0};

V g_heff_2eelab_2eeval_2eevalTermF(V v_r_240, V v_g_241, V v_c_242, V v_x4_243, V v_vs_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_SLocal: {
    V v_i_245 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SLocal = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    V v_t_246 = ({ V a_0 = v_vs_244; V a_1 = v_i_245; V r_ = heff_tr(g_heff_2eelab_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_vs_244); r_; });
    return heff_tag_at_n(v_ru_24x4_243_24SLocal, TAG_Nom, 1, (V[]){v_t_246});
  }
  case TAG_SGlobal: {
    V v_x_247 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SGlobal = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    HeffT2 v_t_248 = ({ V b_0 = heff_get_n(v_g_241, 1, 8); V a_1 = v_x_247; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_247); r_; });
    V v_t_2413;
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_e_2412 = v_field_2410;
        v_t_2413 = v_e_2412;
      } else {
        heff_drop(v_field_2410);
        v_t_2413 = heff_abandon();
      }
    }
    return heff_tag_at_n(v_ru_24x4_243_24SGlobal, TAG_Nom, 1, (V[]){heff_get_n(v_t_2413, 2, 4)});
  }
  case TAG_SCode: {
    V v_a_2414 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, v_c_242, v_a_2414, v_vs_244}));
    return (g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263(v_t_2415));
  }
  case TAG_SApp: {
    V v_x41_2416 = heff_field(v_x4_243, 0);
    V v_t1_2417 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_2416)) {
    case TAG_SLocal: {
      heff_drop(v_c_242);
      V v_f_2425 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam0, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_2426 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_2426)) {
      case TAG_Nom: {
        V v_x_2427 = heff_field(v_x2_2426, 0);
        heff_take_n(v_x2_2426, 1ULL, 1);
        return heff_tail(v_f_2425, 1, (V[]){v_x_2427});
      }
      case TAG_Describe: {
        V v_x_2428 = heff_field(v_x2_2426, 0);
        heff_take_n(v_x2_2426, 1ULL, 1);
        return heff_tail(v_f_2425, 1, (V[]){v_x_2428});
      }
      case TAG_Become: {
        V v_x_2429 = heff_field(v_x2_2426, 0);
        V v_ru_24x2_2426_24Become = heff_take_reuse_n(v_x2_2426, 1ULL, 1);
        V v_x1_2430 = heff_tr(heff_call(v_f_2425, 1, (V[]){v_x_2429}));
        V v_t_2434;
        switch (heff_tag_of(v_x1_2430)) {
        case TAG_Nom: {
          V v_x_2431 = heff_field(v_x1_2430, 0);
          heff_take_n(v_x1_2430, 1ULL, 1);
          v_t_2434 = v_x_2431;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2430, 0ULL, 1);
          v_t_2434 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2433 = heff_field(v_x1_2430, 0);
          heff_take_n(v_x1_2430, 1ULL, 1);
          v_t_2434 = v_x_2433;
          break;
        }
        default: heff_nomatch(v_x1_2430);
        }
        return heff_tag_at_n(v_ru_24x2_2426_24Become, TAG_Become, 1, (V[]){v_t_2434});
      }
      default: return heff_nomatch(v_x2_2426);
      }
    }
    case TAG_SGlobal: {
      heff_drop(v_c_242);
      V v_f_2442 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam2, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_2443 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_2443)) {
      case TAG_Nom: {
        V v_x_2444 = heff_field(v_x2_2443, 0);
        heff_take_n(v_x2_2443, 1ULL, 1);
        return heff_tail(v_f_2442, 1, (V[]){v_x_2444});
      }
      case TAG_Describe: {
        V v_x_2445 = heff_field(v_x2_2443, 0);
        heff_take_n(v_x2_2443, 1ULL, 1);
        return heff_tail(v_f_2442, 1, (V[]){v_x_2445});
      }
      case TAG_Become: {
        V v_x_2446 = heff_field(v_x2_2443, 0);
        V v_ru_24x2_2443_24Become = heff_take_reuse_n(v_x2_2443, 1ULL, 1);
        V v_x1_2447 = heff_tr(heff_call(v_f_2442, 1, (V[]){v_x_2446}));
        V v_t_2451;
        switch (heff_tag_of(v_x1_2447)) {
        case TAG_Nom: {
          V v_x_2448 = heff_field(v_x1_2447, 0);
          heff_take_n(v_x1_2447, 1ULL, 1);
          v_t_2451 = v_x_2448;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2447, 0ULL, 1);
          v_t_2451 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2450 = heff_field(v_x1_2447, 0);
          heff_take_n(v_x1_2447, 1ULL, 1);
          v_t_2451 = v_x_2450;
          break;
        }
        default: heff_nomatch(v_x1_2447);
        }
        return heff_tag_at_n(v_ru_24x2_2443_24Become, TAG_Become, 1, (V[]){v_t_2451});
      }
      default: return heff_nomatch(v_x2_2443);
      }
    }
    case TAG_SCode: {
      heff_drop(v_c_242);
      V v_f_2459 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam4, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_2460 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_2460)) {
      case TAG_Nom: {
        V v_x_2461 = heff_field(v_x2_2460, 0);
        heff_take_n(v_x2_2460, 1ULL, 1);
        return heff_tail(v_f_2459, 1, (V[]){v_x_2461});
      }
      case TAG_Describe: {
        V v_x_2462 = heff_field(v_x2_2460, 0);
        heff_take_n(v_x2_2460, 1ULL, 1);
        return heff_tail(v_f_2459, 1, (V[]){v_x_2462});
      }
      case TAG_Become: {
        V v_x_2463 = heff_field(v_x2_2460, 0);
        V v_ru_24x2_2460_24Become = heff_take_reuse_n(v_x2_2460, 1ULL, 1);
        V v_x1_2464 = heff_tr(heff_call(v_f_2459, 1, (V[]){v_x_2463}));
        V v_t_2468;
        switch (heff_tag_of(v_x1_2464)) {
        case TAG_Nom: {
          V v_x_2465 = heff_field(v_x1_2464, 0);
          heff_take_n(v_x1_2464, 1ULL, 1);
          v_t_2468 = v_x_2465;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2464, 0ULL, 1);
          v_t_2468 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2467 = heff_field(v_x1_2464, 0);
          heff_take_n(v_x1_2464, 1ULL, 1);
          v_t_2468 = v_x_2467;
          break;
        }
        default: heff_nomatch(v_x1_2464);
        }
        return heff_tag_at_n(v_ru_24x2_2460_24Become, TAG_Become, 1, (V[]){v_t_2468});
      }
      default: return heff_nomatch(v_x2_2460);
      }
    }
    case TAG_SApp: {
      heff_drop(v_c_242);
      V v_f_2477 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam6, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_2478 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_2478)) {
      case TAG_Nom: {
        V v_x_2479 = heff_field(v_x2_2478, 0);
        heff_take_n(v_x2_2478, 1ULL, 1);
        return heff_tail(v_f_2477, 1, (V[]){v_x_2479});
      }
      case TAG_Describe: {
        V v_x_2480 = heff_field(v_x2_2478, 0);
        heff_take_n(v_x2_2478, 1ULL, 1);
        return heff_tail(v_f_2477, 1, (V[]){v_x_2480});
      }
      case TAG_Become: {
        V v_x_2481 = heff_field(v_x2_2478, 0);
        V v_ru_24x2_2478_24Become = heff_take_reuse_n(v_x2_2478, 1ULL, 1);
        V v_x1_2482 = heff_tr(heff_call(v_f_2477, 1, (V[]){v_x_2481}));
        V v_t_2486;
        switch (heff_tag_of(v_x1_2482)) {
        case TAG_Nom: {
          V v_x_2483 = heff_field(v_x1_2482, 0);
          heff_take_n(v_x1_2482, 1ULL, 1);
          v_t_2486 = v_x_2483;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2482, 0ULL, 1);
          v_t_2486 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2485 = heff_field(v_x1_2482, 0);
          heff_take_n(v_x1_2482, 1ULL, 1);
          v_t_2486 = v_x_2485;
          break;
        }
        default: heff_nomatch(v_x1_2482);
        }
        return heff_tag_at_n(v_ru_24x2_2478_24Become, TAG_Become, 1, (V[]){v_t_2486});
      }
      default: return heff_nomatch(v_x2_2478);
      }
    }
    case TAG_SLam: {
      V v_x412_2488 = heff_dup(heff_field(v_x41_2416, 1));
      switch (heff_tag_of(v_x412_2488)) {
      case TAG_MkAbs: {
        V v_t_2490 = heff_field(v_x412_2488, 1);
        heff_take_n(v_x412_2488, 2ULL, 2);
        heff_drop_tag(v_x41_2416, 2);
        return heff_tail(heff_dup(heff_rfield(v_r_240, 0)), 4, (V[]){heff_dup(v_g_241), v_c_242, v_t_2490, heff_tag_n(TAG_LSnoc, 2, (V[]){heff_dup(v_vs_244), heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam8, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})})});
      }
      case TAG_AbsConst: {
        V v_ru_24x412_2488_24AbsConst = heff_take_reuse_n(v_x412_2488, 0ULL, 1);
        heff_drop(v_c_242);
        V v_f_24103 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam9, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
        V v_x2_24104 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
        switch (heff_tag_of(v_x2_24104)) {
        case TAG_Nom: {
          V v_x_24105 = heff_field(v_x2_24104, 0);
          heff_take_n(v_x2_24104, 1ULL, 1);
          heff_drop_cell(v_ru_24x412_2488_24AbsConst, 1);
          return heff_tail(v_f_24103, 1, (V[]){v_x_24105});
        }
        case TAG_Describe: {
          V v_x_24106 = heff_field(v_x2_24104, 0);
          heff_take_n(v_x2_24104, 1ULL, 1);
          heff_drop_cell(v_ru_24x412_2488_24AbsConst, 1);
          return heff_tail(v_f_24103, 1, (V[]){v_x_24106});
        }
        case TAG_Become: {
          V v_x_24107 = heff_field(v_x2_24104, 0);
          heff_take_n(v_x2_24104, 1ULL, 1);
          V v_x1_24108 = heff_tr(heff_call(v_f_24103, 1, (V[]){v_x_24107}));
          V v_t_24112;
          switch (heff_tag_of(v_x1_24108)) {
          case TAG_Nom: {
            V v_x_24109 = heff_field(v_x1_24108, 0);
            heff_take_n(v_x1_24108, 1ULL, 1);
            v_t_24112 = v_x_24109;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_24108, 0ULL, 1);
            v_t_24112 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_24111 = heff_field(v_x1_24108, 0);
            heff_take_n(v_x1_24108, 1ULL, 1);
            v_t_24112 = v_x_24111;
            break;
          }
          default: heff_nomatch(v_x1_24108);
          }
          return heff_tag_at_n(v_ru_24x412_2488_24AbsConst, TAG_Become, 1, (V[]){v_t_24112});
        }
        default: return heff_nomatch(v_x2_24104);
        }
      }
      default: return heff_nomatch(v_x412_2488);
      }
    }
    case TAG_SCons: {
      heff_drop(v_c_242);
      V v_f_24120 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam11, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24121 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24121)) {
      case TAG_Nom: {
        V v_x_24122 = heff_field(v_x2_24121, 0);
        heff_take_n(v_x2_24121, 1ULL, 1);
        return heff_tail(v_f_24120, 1, (V[]){v_x_24122});
      }
      case TAG_Describe: {
        V v_x_24123 = heff_field(v_x2_24121, 0);
        heff_take_n(v_x2_24121, 1ULL, 1);
        return heff_tail(v_f_24120, 1, (V[]){v_x_24123});
      }
      case TAG_Become: {
        V v_x_24124 = heff_field(v_x2_24121, 0);
        V v_ru_24x2_24121_24Become = heff_take_reuse_n(v_x2_24121, 1ULL, 1);
        V v_x1_24125 = heff_tr(heff_call(v_f_24120, 1, (V[]){v_x_24124}));
        V v_t_24129;
        switch (heff_tag_of(v_x1_24125)) {
        case TAG_Nom: {
          V v_x_24126 = heff_field(v_x1_24125, 0);
          heff_take_n(v_x1_24125, 1ULL, 1);
          v_t_24129 = v_x_24126;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24125, 0ULL, 1);
          v_t_24129 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24128 = heff_field(v_x1_24125, 0);
          heff_take_n(v_x1_24125, 1ULL, 1);
          v_t_24129 = v_x_24128;
          break;
        }
        default: heff_nomatch(v_x1_24125);
        }
        return heff_tag_at_n(v_ru_24x2_24121_24Become, TAG_Become, 1, (V[]){v_t_24129});
      }
      default: return heff_nomatch(v_x2_24121);
      }
    }
    case TAG_SProj: {
      heff_drop(v_c_242);
      V v_f_24138 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam13, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24139 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24139)) {
      case TAG_Nom: {
        V v_x_24140 = heff_field(v_x2_24139, 0);
        heff_take_n(v_x2_24139, 1ULL, 1);
        return heff_tail(v_f_24138, 1, (V[]){v_x_24140});
      }
      case TAG_Describe: {
        V v_x_24141 = heff_field(v_x2_24139, 0);
        heff_take_n(v_x2_24139, 1ULL, 1);
        return heff_tail(v_f_24138, 1, (V[]){v_x_24141});
      }
      case TAG_Become: {
        V v_x_24142 = heff_field(v_x2_24139, 0);
        V v_ru_24x2_24139_24Become = heff_take_reuse_n(v_x2_24139, 1ULL, 1);
        V v_x1_24143 = heff_tr(heff_call(v_f_24138, 1, (V[]){v_x_24142}));
        V v_t_24147;
        switch (heff_tag_of(v_x1_24143)) {
        case TAG_Nom: {
          V v_x_24144 = heff_field(v_x1_24143, 0);
          heff_take_n(v_x1_24143, 1ULL, 1);
          v_t_24147 = v_x_24144;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24143, 0ULL, 1);
          v_t_24147 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24146 = heff_field(v_x1_24143, 0);
          heff_take_n(v_x1_24143, 1ULL, 1);
          v_t_24147 = v_x_24146;
          break;
        }
        default: heff_nomatch(v_x1_24143);
        }
        return heff_tag_at_n(v_ru_24x2_24139_24Become, TAG_Become, 1, (V[]){v_t_24147});
      }
      default: return heff_nomatch(v_x2_24139);
      }
    }
    case TAG_STag: {
      heff_drop(v_c_242);
      V v_f_24156 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam15, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24157 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24157)) {
      case TAG_Nom: {
        V v_x_24158 = heff_field(v_x2_24157, 0);
        heff_take_n(v_x2_24157, 1ULL, 1);
        return heff_tail(v_f_24156, 1, (V[]){v_x_24158});
      }
      case TAG_Describe: {
        V v_x_24159 = heff_field(v_x2_24157, 0);
        heff_take_n(v_x2_24157, 1ULL, 1);
        return heff_tail(v_f_24156, 1, (V[]){v_x_24159});
      }
      case TAG_Become: {
        V v_x_24160 = heff_field(v_x2_24157, 0);
        V v_ru_24x2_24157_24Become = heff_take_reuse_n(v_x2_24157, 1ULL, 1);
        V v_x1_24161 = heff_tr(heff_call(v_f_24156, 1, (V[]){v_x_24160}));
        V v_t_24165;
        switch (heff_tag_of(v_x1_24161)) {
        case TAG_Nom: {
          V v_x_24162 = heff_field(v_x1_24161, 0);
          heff_take_n(v_x1_24161, 1ULL, 1);
          v_t_24165 = v_x_24162;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24161, 0ULL, 1);
          v_t_24165 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24164 = heff_field(v_x1_24161, 0);
          heff_take_n(v_x1_24161, 1ULL, 1);
          v_t_24165 = v_x_24164;
          break;
        }
        default: heff_nomatch(v_x1_24161);
        }
        return heff_tag_at_n(v_ru_24x2_24157_24Become, TAG_Become, 1, (V[]){v_t_24165});
      }
      default: return heff_nomatch(v_x2_24157);
      }
    }
    case TAG_SMatch: {
      heff_drop(v_c_242);
      V v_f_24174 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam17, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24175 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24175)) {
      case TAG_Nom: {
        V v_x_24176 = heff_field(v_x2_24175, 0);
        heff_take_n(v_x2_24175, 1ULL, 1);
        return heff_tail(v_f_24174, 1, (V[]){v_x_24176});
      }
      case TAG_Describe: {
        V v_x_24177 = heff_field(v_x2_24175, 0);
        heff_take_n(v_x2_24175, 1ULL, 1);
        return heff_tail(v_f_24174, 1, (V[]){v_x_24177});
      }
      case TAG_Become: {
        V v_x_24178 = heff_field(v_x2_24175, 0);
        V v_ru_24x2_24175_24Become = heff_take_reuse_n(v_x2_24175, 1ULL, 1);
        V v_x1_24179 = heff_tr(heff_call(v_f_24174, 1, (V[]){v_x_24178}));
        V v_t_24183;
        switch (heff_tag_of(v_x1_24179)) {
        case TAG_Nom: {
          V v_x_24180 = heff_field(v_x1_24179, 0);
          heff_take_n(v_x1_24179, 1ULL, 1);
          v_t_24183 = v_x_24180;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24179, 0ULL, 1);
          v_t_24183 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24182 = heff_field(v_x1_24179, 0);
          heff_take_n(v_x1_24179, 1ULL, 1);
          v_t_24183 = v_x_24182;
          break;
        }
        default: heff_nomatch(v_x1_24179);
        }
        return heff_tag_at_n(v_ru_24x2_24175_24Become, TAG_Become, 1, (V[]){v_t_24183});
      }
      default: return heff_nomatch(v_x2_24175);
      }
    }
    case TAG_SSpecialize: {
      heff_drop(v_c_242);
      V v_f_24193 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam19, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24194 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24194)) {
      case TAG_Nom: {
        V v_x_24195 = heff_field(v_x2_24194, 0);
        heff_take_n(v_x2_24194, 1ULL, 1);
        return heff_tail(v_f_24193, 1, (V[]){v_x_24195});
      }
      case TAG_Describe: {
        V v_x_24196 = heff_field(v_x2_24194, 0);
        heff_take_n(v_x2_24194, 1ULL, 1);
        return heff_tail(v_f_24193, 1, (V[]){v_x_24196});
      }
      case TAG_Become: {
        V v_x_24197 = heff_field(v_x2_24194, 0);
        V v_ru_24x2_24194_24Become = heff_take_reuse_n(v_x2_24194, 1ULL, 1);
        V v_x1_24198 = heff_tr(heff_call(v_f_24193, 1, (V[]){v_x_24197}));
        V v_t_24202;
        switch (heff_tag_of(v_x1_24198)) {
        case TAG_Nom: {
          V v_x_24199 = heff_field(v_x1_24198, 0);
          heff_take_n(v_x1_24198, 1ULL, 1);
          v_t_24202 = v_x_24199;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24198, 0ULL, 1);
          v_t_24202 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24201 = heff_field(v_x1_24198, 0);
          heff_take_n(v_x1_24198, 1ULL, 1);
          v_t_24202 = v_x_24201;
          break;
        }
        default: heff_nomatch(v_x1_24198);
        }
        return heff_tag_at_n(v_ru_24x2_24194_24Become, TAG_Become, 1, (V[]){v_t_24202});
      }
      default: return heff_nomatch(v_x2_24194);
      }
    }
    case TAG_SIs: {
      heff_drop(v_c_242);
      V v_f_24210 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam21, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24211 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24211)) {
      case TAG_Nom: {
        V v_x_24212 = heff_field(v_x2_24211, 0);
        heff_take_n(v_x2_24211, 1ULL, 1);
        return heff_tail(v_f_24210, 1, (V[]){v_x_24212});
      }
      case TAG_Describe: {
        V v_x_24213 = heff_field(v_x2_24211, 0);
        heff_take_n(v_x2_24211, 1ULL, 1);
        return heff_tail(v_f_24210, 1, (V[]){v_x_24213});
      }
      case TAG_Become: {
        V v_x_24214 = heff_field(v_x2_24211, 0);
        V v_ru_24x2_24211_24Become = heff_take_reuse_n(v_x2_24211, 1ULL, 1);
        V v_x1_24215 = heff_tr(heff_call(v_f_24210, 1, (V[]){v_x_24214}));
        V v_t_24219;
        switch (heff_tag_of(v_x1_24215)) {
        case TAG_Nom: {
          V v_x_24216 = heff_field(v_x1_24215, 0);
          heff_take_n(v_x1_24215, 1ULL, 1);
          v_t_24219 = v_x_24216;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24215, 0ULL, 1);
          v_t_24219 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24218 = heff_field(v_x1_24215, 0);
          heff_take_n(v_x1_24215, 1ULL, 1);
          v_t_24219 = v_x_24218;
          break;
        }
        default: heff_nomatch(v_x1_24215);
        }
        return heff_tag_at_n(v_ru_24x2_24211_24Become, TAG_Become, 1, (V[]){v_t_24219});
      }
      default: return heff_nomatch(v_x2_24211);
      }
    }
    case TAG_SOpaque: {
      heff_drop(v_c_242);
      V v_f_24226 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam23, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24227 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24227)) {
      case TAG_Nom: {
        V v_x_24228 = heff_field(v_x2_24227, 0);
        heff_take_n(v_x2_24227, 1ULL, 1);
        return heff_tail(v_f_24226, 1, (V[]){v_x_24228});
      }
      case TAG_Describe: {
        V v_x_24229 = heff_field(v_x2_24227, 0);
        heff_take_n(v_x2_24227, 1ULL, 1);
        return heff_tail(v_f_24226, 1, (V[]){v_x_24229});
      }
      case TAG_Become: {
        V v_x_24230 = heff_field(v_x2_24227, 0);
        V v_ru_24x2_24227_24Become = heff_take_reuse_n(v_x2_24227, 1ULL, 1);
        V v_x1_24231 = heff_tr(heff_call(v_f_24226, 1, (V[]){v_x_24230}));
        V v_t_24235;
        switch (heff_tag_of(v_x1_24231)) {
        case TAG_Nom: {
          V v_x_24232 = heff_field(v_x1_24231, 0);
          heff_take_n(v_x1_24231, 1ULL, 1);
          v_t_24235 = v_x_24232;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24231, 0ULL, 1);
          v_t_24235 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24234 = heff_field(v_x1_24231, 0);
          heff_take_n(v_x1_24231, 1ULL, 1);
          v_t_24235 = v_x_24234;
          break;
        }
        default: heff_nomatch(v_x1_24231);
        }
        return heff_tag_at_n(v_ru_24x2_24227_24Become, TAG_Become, 1, (V[]){v_t_24235});
      }
      default: return heff_nomatch(v_x2_24227);
      }
    }
    case TAG_SAbandon: {
      heff_drop(v_c_242);
      V v_f_24242 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam25, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24243)) {
      case TAG_Nom: {
        V v_x_24244 = heff_field(v_x2_24243, 0);
        heff_take_n(v_x2_24243, 1ULL, 1);
        return heff_tail(v_f_24242, 1, (V[]){v_x_24244});
      }
      case TAG_Describe: {
        V v_x_24245 = heff_field(v_x2_24243, 0);
        heff_take_n(v_x2_24243, 1ULL, 1);
        return heff_tail(v_f_24242, 1, (V[]){v_x_24245});
      }
      case TAG_Become: {
        V v_x_24246 = heff_field(v_x2_24243, 0);
        V v_ru_24x2_24243_24Become = heff_take_reuse_n(v_x2_24243, 1ULL, 1);
        V v_x1_24247 = heff_tr(heff_call(v_f_24242, 1, (V[]){v_x_24246}));
        V v_t_24251;
        switch (heff_tag_of(v_x1_24247)) {
        case TAG_Nom: {
          V v_x_24248 = heff_field(v_x1_24247, 0);
          heff_take_n(v_x1_24247, 1ULL, 1);
          v_t_24251 = v_x_24248;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24247, 0ULL, 1);
          v_t_24251 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24250 = heff_field(v_x1_24247, 0);
          heff_take_n(v_x1_24247, 1ULL, 1);
          v_t_24251 = v_x_24250;
          break;
        }
        default: heff_nomatch(v_x1_24247);
        }
        return heff_tag_at_n(v_ru_24x2_24243_24Become, TAG_Become, 1, (V[]){v_t_24251});
      }
      default: return heff_nomatch(v_x2_24243);
      }
    }
    case TAG_SRec: {
      heff_drop(v_c_242);
      V v_f_24259 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam27, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24260 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24260)) {
      case TAG_Nom: {
        V v_x_24261 = heff_field(v_x2_24260, 0);
        heff_take_n(v_x2_24260, 1ULL, 1);
        return heff_tail(v_f_24259, 1, (V[]){v_x_24261});
      }
      case TAG_Describe: {
        V v_x_24262 = heff_field(v_x2_24260, 0);
        heff_take_n(v_x2_24260, 1ULL, 1);
        return heff_tail(v_f_24259, 1, (V[]){v_x_24262});
      }
      case TAG_Become: {
        V v_x_24263 = heff_field(v_x2_24260, 0);
        V v_ru_24x2_24260_24Become = heff_take_reuse_n(v_x2_24260, 1ULL, 1);
        V v_x1_24264 = heff_tr(heff_call(v_f_24259, 1, (V[]){v_x_24263}));
        V v_t_24268;
        switch (heff_tag_of(v_x1_24264)) {
        case TAG_Nom: {
          V v_x_24265 = heff_field(v_x1_24264, 0);
          heff_take_n(v_x1_24264, 1ULL, 1);
          v_t_24268 = v_x_24265;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24264, 0ULL, 1);
          v_t_24268 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24267 = heff_field(v_x1_24264, 0);
          heff_take_n(v_x1_24264, 1ULL, 1);
          v_t_24268 = v_x_24267;
          break;
        }
        default: heff_nomatch(v_x1_24264);
        }
        return heff_tag_at_n(v_ru_24x2_24260_24Become, TAG_Become, 1, (V[]){v_t_24268});
      }
      default: return heff_nomatch(v_x2_24260);
      }
    }
    case TAG_SFix: {
      heff_drop(v_c_242);
      V v_f_24277 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam29, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24278 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24278)) {
      case TAG_Nom: {
        V v_x_24279 = heff_field(v_x2_24278, 0);
        heff_take_n(v_x2_24278, 1ULL, 1);
        return heff_tail(v_f_24277, 1, (V[]){v_x_24279});
      }
      case TAG_Describe: {
        V v_x_24280 = heff_field(v_x2_24278, 0);
        heff_take_n(v_x2_24278, 1ULL, 1);
        return heff_tail(v_f_24277, 1, (V[]){v_x_24280});
      }
      case TAG_Become: {
        V v_x_24281 = heff_field(v_x2_24278, 0);
        V v_ru_24x2_24278_24Become = heff_take_reuse_n(v_x2_24278, 1ULL, 1);
        V v_x1_24282 = heff_tr(heff_call(v_f_24277, 1, (V[]){v_x_24281}));
        V v_t_24286;
        switch (heff_tag_of(v_x1_24282)) {
        case TAG_Nom: {
          V v_x_24283 = heff_field(v_x1_24282, 0);
          heff_take_n(v_x1_24282, 1ULL, 1);
          v_t_24286 = v_x_24283;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24282, 0ULL, 1);
          v_t_24286 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24285 = heff_field(v_x1_24282, 0);
          heff_take_n(v_x1_24282, 1ULL, 1);
          v_t_24286 = v_x_24285;
          break;
        }
        default: heff_nomatch(v_x1_24282);
        }
        return heff_tag_at_n(v_ru_24x2_24278_24Become, TAG_Become, 1, (V[]){v_t_24286});
      }
      default: return heff_nomatch(v_x2_24278);
      }
    }
    case TAG_SImplicit: {
      heff_drop(v_c_242);
      V v_f_24295 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam31, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24296 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24296)) {
      case TAG_Nom: {
        V v_x_24297 = heff_field(v_x2_24296, 0);
        heff_take_n(v_x2_24296, 1ULL, 1);
        return heff_tail(v_f_24295, 1, (V[]){v_x_24297});
      }
      case TAG_Describe: {
        V v_x_24298 = heff_field(v_x2_24296, 0);
        heff_take_n(v_x2_24296, 1ULL, 1);
        return heff_tail(v_f_24295, 1, (V[]){v_x_24298});
      }
      case TAG_Become: {
        V v_x_24299 = heff_field(v_x2_24296, 0);
        V v_ru_24x2_24296_24Become = heff_take_reuse_n(v_x2_24296, 1ULL, 1);
        V v_x1_24300 = heff_tr(heff_call(v_f_24295, 1, (V[]){v_x_24299}));
        V v_t_24304;
        switch (heff_tag_of(v_x1_24300)) {
        case TAG_Nom: {
          V v_x_24301 = heff_field(v_x1_24300, 0);
          heff_take_n(v_x1_24300, 1ULL, 1);
          v_t_24304 = v_x_24301;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24300, 0ULL, 1);
          v_t_24304 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24303 = heff_field(v_x1_24300, 0);
          heff_take_n(v_x1_24300, 1ULL, 1);
          v_t_24304 = v_x_24303;
          break;
        }
        default: heff_nomatch(v_x1_24300);
        }
        return heff_tag_at_n(v_ru_24x2_24296_24Become, TAG_Become, 1, (V[]){v_t_24304});
      }
      default: return heff_nomatch(v_x2_24296);
      }
    }
    case TAG_SPrim: {
      heff_drop(v_c_242);
      V v_f_24312 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam33, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24313 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24313)) {
      case TAG_Nom: {
        V v_x_24314 = heff_field(v_x2_24313, 0);
        heff_take_n(v_x2_24313, 1ULL, 1);
        return heff_tail(v_f_24312, 1, (V[]){v_x_24314});
      }
      case TAG_Describe: {
        V v_x_24315 = heff_field(v_x2_24313, 0);
        heff_take_n(v_x2_24313, 1ULL, 1);
        return heff_tail(v_f_24312, 1, (V[]){v_x_24315});
      }
      case TAG_Become: {
        V v_x_24316 = heff_field(v_x2_24313, 0);
        V v_ru_24x2_24313_24Become = heff_take_reuse_n(v_x2_24313, 1ULL, 1);
        V v_x1_24317 = heff_tr(heff_call(v_f_24312, 1, (V[]){v_x_24316}));
        V v_t_24321;
        switch (heff_tag_of(v_x1_24317)) {
        case TAG_Nom: {
          V v_x_24318 = heff_field(v_x1_24317, 0);
          heff_take_n(v_x1_24317, 1ULL, 1);
          v_t_24321 = v_x_24318;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24317, 0ULL, 1);
          v_t_24321 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24320 = heff_field(v_x1_24317, 0);
          heff_take_n(v_x1_24317, 1ULL, 1);
          v_t_24321 = v_x_24320;
          break;
        }
        default: heff_nomatch(v_x1_24317);
        }
        return heff_tag_at_n(v_ru_24x2_24313_24Become, TAG_Become, 1, (V[]){v_t_24321});
      }
      default: return heff_nomatch(v_x2_24313);
      }
    }
    case TAG_SMetaApp: {
      heff_drop(v_c_242);
      V v_f_24331 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam35, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24332 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24332)) {
      case TAG_Nom: {
        V v_x_24333 = heff_field(v_x2_24332, 0);
        heff_take_n(v_x2_24332, 1ULL, 1);
        return heff_tail(v_f_24331, 1, (V[]){v_x_24333});
      }
      case TAG_Describe: {
        V v_x_24334 = heff_field(v_x2_24332, 0);
        heff_take_n(v_x2_24332, 1ULL, 1);
        return heff_tail(v_f_24331, 1, (V[]){v_x_24334});
      }
      case TAG_Become: {
        V v_x_24335 = heff_field(v_x2_24332, 0);
        V v_ru_24x2_24332_24Become = heff_take_reuse_n(v_x2_24332, 1ULL, 1);
        V v_x1_24336 = heff_tr(heff_call(v_f_24331, 1, (V[]){v_x_24335}));
        V v_t_24340;
        switch (heff_tag_of(v_x1_24336)) {
        case TAG_Nom: {
          V v_x_24337 = heff_field(v_x1_24336, 0);
          heff_take_n(v_x1_24336, 1ULL, 1);
          v_t_24340 = v_x_24337;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24336, 0ULL, 1);
          v_t_24340 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24339 = heff_field(v_x1_24336, 0);
          heff_take_n(v_x1_24336, 1ULL, 1);
          v_t_24340 = v_x_24339;
          break;
        }
        default: heff_nomatch(v_x1_24336);
        }
        return heff_tag_at_n(v_ru_24x2_24332_24Become, TAG_Become, 1, (V[]){v_t_24340});
      }
      default: return heff_nomatch(v_x2_24332);
      }
    }
    case TAG_SLitInt: {
      heff_drop(v_c_242);
      V v_f_24348 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam37, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24349 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24349)) {
      case TAG_Nom: {
        V v_x_24350 = heff_field(v_x2_24349, 0);
        heff_take_n(v_x2_24349, 1ULL, 1);
        return heff_tail(v_f_24348, 1, (V[]){v_x_24350});
      }
      case TAG_Describe: {
        V v_x_24351 = heff_field(v_x2_24349, 0);
        heff_take_n(v_x2_24349, 1ULL, 1);
        return heff_tail(v_f_24348, 1, (V[]){v_x_24351});
      }
      case TAG_Become: {
        V v_x_24352 = heff_field(v_x2_24349, 0);
        V v_ru_24x2_24349_24Become = heff_take_reuse_n(v_x2_24349, 1ULL, 1);
        V v_x1_24353 = heff_tr(heff_call(v_f_24348, 1, (V[]){v_x_24352}));
        V v_t_24357;
        switch (heff_tag_of(v_x1_24353)) {
        case TAG_Nom: {
          V v_x_24354 = heff_field(v_x1_24353, 0);
          heff_take_n(v_x1_24353, 1ULL, 1);
          v_t_24357 = v_x_24354;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24353, 0ULL, 1);
          v_t_24357 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24356 = heff_field(v_x1_24353, 0);
          heff_take_n(v_x1_24353, 1ULL, 1);
          v_t_24357 = v_x_24356;
          break;
        }
        default: heff_nomatch(v_x1_24353);
        }
        return heff_tag_at_n(v_ru_24x2_24349_24Become, TAG_Become, 1, (V[]){v_t_24357});
      }
      default: return heff_nomatch(v_x2_24349);
      }
    }
    case TAG_SLitFloat: {
      heff_drop(v_c_242);
      V v_f_24365 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam39, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24366 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24366)) {
      case TAG_Nom: {
        V v_x_24367 = heff_field(v_x2_24366, 0);
        heff_take_n(v_x2_24366, 1ULL, 1);
        return heff_tail(v_f_24365, 1, (V[]){v_x_24367});
      }
      case TAG_Describe: {
        V v_x_24368 = heff_field(v_x2_24366, 0);
        heff_take_n(v_x2_24366, 1ULL, 1);
        return heff_tail(v_f_24365, 1, (V[]){v_x_24368});
      }
      case TAG_Become: {
        V v_x_24369 = heff_field(v_x2_24366, 0);
        V v_ru_24x2_24366_24Become = heff_take_reuse_n(v_x2_24366, 1ULL, 1);
        V v_x1_24370 = heff_tr(heff_call(v_f_24365, 1, (V[]){v_x_24369}));
        V v_t_24374;
        switch (heff_tag_of(v_x1_24370)) {
        case TAG_Nom: {
          V v_x_24371 = heff_field(v_x1_24370, 0);
          heff_take_n(v_x1_24370, 1ULL, 1);
          v_t_24374 = v_x_24371;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24370, 0ULL, 1);
          v_t_24374 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24373 = heff_field(v_x1_24370, 0);
          heff_take_n(v_x1_24370, 1ULL, 1);
          v_t_24374 = v_x_24373;
          break;
        }
        default: heff_nomatch(v_x1_24370);
        }
        return heff_tag_at_n(v_ru_24x2_24366_24Become, TAG_Become, 1, (V[]){v_t_24374});
      }
      default: return heff_nomatch(v_x2_24366);
      }
    }
    case TAG_SLitString: {
      heff_drop(v_c_242);
      V v_f_24382 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam41, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24383 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24383)) {
      case TAG_Nom: {
        V v_x_24384 = heff_field(v_x2_24383, 0);
        heff_take_n(v_x2_24383, 1ULL, 1);
        return heff_tail(v_f_24382, 1, (V[]){v_x_24384});
      }
      case TAG_Describe: {
        V v_x_24385 = heff_field(v_x2_24383, 0);
        heff_take_n(v_x2_24383, 1ULL, 1);
        return heff_tail(v_f_24382, 1, (V[]){v_x_24385});
      }
      case TAG_Become: {
        V v_x_24386 = heff_field(v_x2_24383, 0);
        V v_ru_24x2_24383_24Become = heff_take_reuse_n(v_x2_24383, 1ULL, 1);
        V v_x1_24387 = heff_tr(heff_call(v_f_24382, 1, (V[]){v_x_24386}));
        V v_t_24391;
        switch (heff_tag_of(v_x1_24387)) {
        case TAG_Nom: {
          V v_x_24388 = heff_field(v_x1_24387, 0);
          heff_take_n(v_x1_24387, 1ULL, 1);
          v_t_24391 = v_x_24388;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24387, 0ULL, 1);
          v_t_24391 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24390 = heff_field(v_x1_24387, 0);
          heff_take_n(v_x1_24387, 1ULL, 1);
          v_t_24391 = v_x_24390;
          break;
        }
        default: heff_nomatch(v_x1_24387);
        }
        return heff_tag_at_n(v_ru_24x2_24383_24Become, TAG_Become, 1, (V[]){v_t_24391});
      }
      default: return heff_nomatch(v_x2_24383);
      }
    }
    case TAG_SLitBytes: {
      heff_drop(v_c_242);
      V v_f_24399 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam43, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24400 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24400)) {
      case TAG_Nom: {
        V v_x_24401 = heff_field(v_x2_24400, 0);
        heff_take_n(v_x2_24400, 1ULL, 1);
        return heff_tail(v_f_24399, 1, (V[]){v_x_24401});
      }
      case TAG_Describe: {
        V v_x_24402 = heff_field(v_x2_24400, 0);
        heff_take_n(v_x2_24400, 1ULL, 1);
        return heff_tail(v_f_24399, 1, (V[]){v_x_24402});
      }
      case TAG_Become: {
        V v_x_24403 = heff_field(v_x2_24400, 0);
        V v_ru_24x2_24400_24Become = heff_take_reuse_n(v_x2_24400, 1ULL, 1);
        V v_x1_24404 = heff_tr(heff_call(v_f_24399, 1, (V[]){v_x_24403}));
        V v_t_24408;
        switch (heff_tag_of(v_x1_24404)) {
        case TAG_Nom: {
          V v_x_24405 = heff_field(v_x1_24404, 0);
          heff_take_n(v_x1_24404, 1ULL, 1);
          v_t_24408 = v_x_24405;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24404, 0ULL, 1);
          v_t_24408 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24407 = heff_field(v_x1_24404, 0);
          heff_take_n(v_x1_24404, 1ULL, 1);
          v_t_24408 = v_x_24407;
          break;
        }
        default: heff_nomatch(v_x1_24404);
        }
        return heff_tag_at_n(v_ru_24x2_24400_24Become, TAG_Become, 1, (V[]){v_t_24408});
      }
      default: return heff_nomatch(v_x2_24400);
      }
    }
    case TAG_SLitRune: {
      heff_drop(v_c_242);
      V v_f_24416 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam45, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24417)) {
      case TAG_Nom: {
        V v_x_24418 = heff_field(v_x2_24417, 0);
        heff_take_n(v_x2_24417, 1ULL, 1);
        return heff_tail(v_f_24416, 1, (V[]){v_x_24418});
      }
      case TAG_Describe: {
        V v_x_24419 = heff_field(v_x2_24417, 0);
        heff_take_n(v_x2_24417, 1ULL, 1);
        return heff_tail(v_f_24416, 1, (V[]){v_x_24419});
      }
      case TAG_Become: {
        V v_x_24420 = heff_field(v_x2_24417, 0);
        V v_ru_24x2_24417_24Become = heff_take_reuse_n(v_x2_24417, 1ULL, 1);
        V v_x1_24421 = heff_tr(heff_call(v_f_24416, 1, (V[]){v_x_24420}));
        V v_t_24425;
        switch (heff_tag_of(v_x1_24421)) {
        case TAG_Nom: {
          V v_x_24422 = heff_field(v_x1_24421, 0);
          heff_take_n(v_x1_24421, 1ULL, 1);
          v_t_24425 = v_x_24422;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24421, 0ULL, 1);
          v_t_24425 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24424 = heff_field(v_x1_24421, 0);
          heff_take_n(v_x1_24421, 1ULL, 1);
          v_t_24425 = v_x_24424;
          break;
        }
        default: heff_nomatch(v_x1_24421);
        }
        return heff_tag_at_n(v_ru_24x2_24417_24Become, TAG_Become, 1, (V[]){v_t_24425});
      }
      default: return heff_nomatch(v_x2_24417);
      }
    }
    case TAG_SLitFixed: {
      heff_drop(v_c_242);
      V v_f_24434 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam47, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24435 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24435)) {
      case TAG_Nom: {
        V v_x_24436 = heff_field(v_x2_24435, 0);
        heff_take_n(v_x2_24435, 1ULL, 1);
        return heff_tail(v_f_24434, 1, (V[]){v_x_24436});
      }
      case TAG_Describe: {
        V v_x_24437 = heff_field(v_x2_24435, 0);
        heff_take_n(v_x2_24435, 1ULL, 1);
        return heff_tail(v_f_24434, 1, (V[]){v_x_24437});
      }
      case TAG_Become: {
        V v_x_24438 = heff_field(v_x2_24435, 0);
        V v_ru_24x2_24435_24Become = heff_take_reuse_n(v_x2_24435, 1ULL, 1);
        V v_x1_24439 = heff_tr(heff_call(v_f_24434, 1, (V[]){v_x_24438}));
        V v_t_24443;
        switch (heff_tag_of(v_x1_24439)) {
        case TAG_Nom: {
          V v_x_24440 = heff_field(v_x1_24439, 0);
          heff_take_n(v_x1_24439, 1ULL, 1);
          v_t_24443 = v_x_24440;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24439, 0ULL, 1);
          v_t_24443 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24442 = heff_field(v_x1_24439, 0);
          heff_take_n(v_x1_24439, 1ULL, 1);
          v_t_24443 = v_x_24442;
          break;
        }
        default: heff_nomatch(v_x1_24439);
        }
        return heff_tag_at_n(v_ru_24x2_24435_24Become, TAG_Become, 1, (V[]){v_t_24443});
      }
      default: return heff_nomatch(v_x2_24435);
      }
    }
    case TAG_SLitFloat32: {
      heff_drop(v_c_242);
      V v_f_24451 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam49, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2417, heff_dup(v_vs_244)});
      V v_x2_24452 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2416, v_vs_244}));
      switch (heff_tag_of(v_x2_24452)) {
      case TAG_Nom: {
        V v_x_24453 = heff_field(v_x2_24452, 0);
        heff_take_n(v_x2_24452, 1ULL, 1);
        return heff_tail(v_f_24451, 1, (V[]){v_x_24453});
      }
      case TAG_Describe: {
        V v_x_24454 = heff_field(v_x2_24452, 0);
        heff_take_n(v_x2_24452, 1ULL, 1);
        return heff_tail(v_f_24451, 1, (V[]){v_x_24454});
      }
      case TAG_Become: {
        V v_x_24455 = heff_field(v_x2_24452, 0);
        V v_ru_24x2_24452_24Become = heff_take_reuse_n(v_x2_24452, 1ULL, 1);
        V v_x1_24456 = heff_tr(heff_call(v_f_24451, 1, (V[]){v_x_24455}));
        V v_t_24460;
        switch (heff_tag_of(v_x1_24456)) {
        case TAG_Nom: {
          V v_x_24457 = heff_field(v_x1_24456, 0);
          heff_take_n(v_x1_24456, 1ULL, 1);
          v_t_24460 = v_x_24457;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24456, 0ULL, 1);
          v_t_24460 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24459 = heff_field(v_x1_24456, 0);
          heff_take_n(v_x1_24456, 1ULL, 1);
          v_t_24460 = v_x_24459;
          break;
        }
        default: heff_nomatch(v_x1_24456);
        }
        return heff_tag_at_n(v_ru_24x2_24452_24Become, TAG_Become, 1, (V[]){v_t_24460});
      }
      default: return heff_nomatch(v_x2_24452);
      }
    }
    default: return heff_nomatch(v_x41_2416);
    }
  }
  case TAG_SLam: {
    V v_dom_24461 = heff_field(v_x4_243, 0);
    V v_x42_24462 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24SLam = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x42_24462)) {
    case TAG_MkAbs: {
      V v_x_24463 = heff_field(v_x42_24462, 0);
      V v_t_24464 = heff_field(v_x42_24462, 1);
      heff_take_n(v_x42_24462, 3ULL, 2);
      V v_x_24471 = heff_tag_at_n(v_ru_24x4_243_24SLam, TAG_VLam, 2, (V[]){heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam51, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_dom_24461, heff_dup(v_vs_244)}), heff_tag_n(TAG_MkClo, 3, (V[]){v_x_24463, v_vs_244, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam52, 1, 4, (V[]){v_r_240, v_g_241, heff_dup(v_c_242), v_t_24464})})});
      switch (heff_tag_of(v_c_242)) {
      case TAG_N: {
        return heff_tag_n(TAG_Nom, 1, (V[]){v_x_24471});
      }
      case TAG_De: {
        return heff_tag_n(TAG_Describe, 1, (V[]){v_x_24471});
      }
      default: return heff_nomatch(v_c_242);
      }
    }
    case TAG_AbsConst: {
      V v_t_24472 = heff_field(v_x42_24462, 0);
      V v_ru_24x42_24462_24AbsConst = heff_take_reuse_n(v_x42_24462, 1ULL, 1);
      V v_t_24473 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 4, (V[]){heff_dup(v_g_241), heff_dup(v_c_242), v_t_24472, heff_dup(v_vs_244)}));
      V v_x_24479 = heff_tag_at_n(v_ru_24x4_243_24SLam, TAG_VLam, 2, (V[]){heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam53, 1, 4, (V[]){v_r_240, v_g_241, v_dom_24461, v_vs_244}), heff_tag_n(TAG_CloConst, 1, (V[]){v_t_24473})});
      switch (heff_tag_of(v_c_242)) {
      case TAG_N: {
        return heff_tag_at_n(v_ru_24x42_24462_24AbsConst, TAG_Nom, 1, (V[]){v_x_24479});
      }
      case TAG_De: {
        return heff_tag_at_n(v_ru_24x42_24462_24AbsConst, TAG_Describe, 1, (V[]){v_x_24479});
      }
      default: return heff_nomatch(v_c_242);
      }
    }
    default: return heff_nomatch(v_x42_24462);
    }
  }
  case TAG_SCons: {
    V v_fields_24480 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SCons = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_xs_24481 = heff_take_field(v_fields_24480, 2);
    V v_t_24484 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_24481, 0), heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam54, 1, 5, (V[]){v_xs_24481, v_r_240, v_g_241, heff_dup(v_c_242), v_vs_244}));
    V v_t_24485 = ({ V rv_2 = v_t_24484; V rr_ = heff_rec_reuse_nf(v_fields_24480, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_x_24486 = heff_tag_at_n(v_ru_24x4_243_24SCons, TAG_VCons, 1, (V[]){v_t_24485});
    switch (heff_tag_of(v_c_242)) {
    case TAG_N: {
      return heff_tag_n(TAG_Nom, 1, (V[]){v_x_24486});
    }
    case TAG_De: {
      return heff_tag_n(TAG_Describe, 1, (V[]){v_x_24486});
    }
    default: return heff_nomatch(v_c_242);
    }
  }
  case TAG_SProj: {
    V v_t_24487 = heff_field(v_x4_243, 0);
    V v_x_24488 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    heff_drop(v_c_242);
    V v_f_24503 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam55, 1, 1, (V[]){v_x_24488});
    V v_x2_24504 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_24487, v_vs_244}));
    switch (heff_tag_of(v_x2_24504)) {
    case TAG_Nom: {
      V v_x_24505 = heff_field(v_x2_24504, 0);
      heff_take_n(v_x2_24504, 1ULL, 1);
      return heff_tail(v_f_24503, 1, (V[]){v_x_24505});
    }
    case TAG_Describe: {
      V v_x_24506 = heff_field(v_x2_24504, 0);
      heff_take_n(v_x2_24504, 1ULL, 1);
      return heff_tail(v_f_24503, 1, (V[]){v_x_24506});
    }
    case TAG_Become: {
      V v_x_24507 = heff_field(v_x2_24504, 0);
      V v_ru_24x2_24504_24Become = heff_take_reuse_n(v_x2_24504, 1ULL, 1);
      V v_x1_24508 = heff_tr(heff_call(v_f_24503, 1, (V[]){v_x_24507}));
      V v_t_24512;
      switch (heff_tag_of(v_x1_24508)) {
      case TAG_Nom: {
        V v_x_24509 = heff_field(v_x1_24508, 0);
        heff_take_n(v_x1_24508, 1ULL, 1);
        v_t_24512 = v_x_24509;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_24508, 0ULL, 1);
        v_t_24512 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24511 = heff_field(v_x1_24508, 0);
        heff_take_n(v_x1_24508, 1ULL, 1);
        v_t_24512 = v_x_24511;
        break;
      }
      default: heff_nomatch(v_x1_24508);
      }
      return heff_tag_at_n(v_ru_24x2_24504_24Become, TAG_Become, 1, (V[]){v_t_24512});
    }
    default: return heff_nomatch(v_x2_24504);
    }
  }
  case TAG_STag: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SMatch: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SSpecialize: {
    V v_t_24517 = heff_field(v_x4_243, 0);
    V v_x_24518 = heff_field(v_x4_243, 1);
    V v_t_27_24519 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    heff_drop(v_c_242);
    V v_x1_24520 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 4, (V[]){heff_dup(v_g_241), NTAG(TAG_N), v_t_24517, heff_dup(v_vs_244)}));
    V v_t_24524;
    switch (heff_tag_of(v_x1_24520)) {
    case TAG_Nom: {
      V v_x_24521 = heff_field(v_x1_24520, 0);
      heff_take_n(v_x1_24520, 1ULL, 1);
      v_t_24524 = v_x_24521;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24520, 0ULL, 1);
      v_t_24524 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24523 = heff_field(v_x1_24520, 0);
      heff_take_n(v_x1_24520, 1ULL, 1);
      v_t_24524 = v_x_24523;
      break;
    }
    default: heff_nomatch(v_x1_24520);
    }
    V v_x1_24525 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_27_24519, v_vs_244}));
    V v_t_24529;
    switch (heff_tag_of(v_x1_24525)) {
    case TAG_Nom: {
      V v_x_24526 = heff_field(v_x1_24525, 0);
      heff_take_n(v_x1_24525, 1ULL, 1);
      v_t_24529 = v_x_24526;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24525, 0ULL, 1);
      v_t_24529 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24528 = heff_field(v_x1_24525, 0);
      heff_take_n(v_x1_24525, 1ULL, 1);
      v_t_24529 = v_x_24528;
      break;
    }
    default: heff_nomatch(v_x1_24525);
    }
    V v_t_24530 = (g_heff_2eelab_2evalue_2especialize(v_t_24524, v_x_24518, v_t_24529));
    return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24530});
  }
  case TAG_SIs: {
    V v_t_24531 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SIs = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    V v_x1_24532 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_24531, v_vs_244}));
    V v_t_24536;
    switch (heff_tag_of(v_x1_24532)) {
    case TAG_Nom: {
      V v_x_24533 = heff_field(v_x1_24532, 0);
      heff_take_n(v_x1_24532, 1ULL, 1);
      v_t_24536 = v_x_24533;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24532, 0ULL, 1);
      v_t_24536 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24535 = heff_field(v_x1_24532, 0);
      heff_take_n(v_x1_24532, 1ULL, 1);
      v_t_24536 = v_x_24535;
      break;
    }
    default: heff_nomatch(v_x1_24532);
    }
    return heff_tag_at_n(v_ru_24x4_243_24SIs, TAG_Become, 1, (V[]){v_t_24536});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SRec: {
    V v_ru_24x4_243_24SRec = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SRec, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SFix: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SImplicit: {
    V v_e_24541 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 2ULL, 2);
    return heff_tail(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, v_c_242, v_e_24541, v_vs_244});
  }
  case TAG_SPrim: {
    V v_ru_24x4_243_24SPrim = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SPrim, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SMetaApp: {
    V v_m_24543 = heff_field(v_x4_243, 0);
    V v_idxs_24544 = heff_field(v_x4_243, 1);
    V v_ty_24545 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    heff_drop(v_c_242);
    V v_sp_24549 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam56, 2, 1, (V[]){heff_dup(v_vs_244)}); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_SpId); V a_3 = v_idxs_24544; V r_ = (g_array_2efoldlFrom(a_0, a_1, a_2, a_3)); heff_drop(v_idxs_24544); r_; });
    V v_x1_24550 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_ty_24545, v_vs_244}));
    V v_ty_24554;
    switch (heff_tag_of(v_x1_24550)) {
    case TAG_Nom: {
      V v_x_24551 = heff_field(v_x1_24550, 0);
      heff_take_n(v_x1_24550, 1ULL, 1);
      v_ty_24554 = v_x_24551;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24550, 0ULL, 1);
      v_ty_24554 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24553 = heff_field(v_x1_24550, 0);
      heff_take_n(v_x1_24550, 1ULL, 1);
      v_ty_24554 = v_x_24553;
      break;
    }
    default: heff_nomatch(v_x1_24550);
    }
    V v_t_24557 = (g_heff_2eelab_2evalue_2ereflect(heff_tag_n(TAG_HMeta, 1, (V[]){v_m_24543}), heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam57, 1, 1, (V[]){v_sp_24549}), heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam58, 1, 1, (V[]){v_ty_24554}), NTAG(TAG_Nothing)));
    return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24557});
  }
  case TAG_SLitInt: {
    V v_ru_24x4_243_24SLitInt = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SLitInt, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFloat: {
    V v_ru_24x4_243_24SLitFloat = heff_take_reuse_na(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SLitFloat, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitString: {
    V v_ru_24x4_243_24SLitString = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SLitString, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitBytes: {
    V v_ru_24x4_243_24SLitBytes = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SLitBytes, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitRune: {
    V v_ru_24x4_243_24SLitRune = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SLitRune, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFloat32: {
    V v_ru_24x4_243_24SLitFloat32 = heff_take_reuse_na(v_x4_243, 0ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop_rec(v_g_241, 8);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at_n(v_ru_24x4_243_24SLitFloat32, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eeval_2eevalTermF(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eeval_2eevalTermF_lam1(V self, V *args) {
  V v_u_2420 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2420);
  V v_x1_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_2421)) {
  case TAG_Nom: {
    V v_x_2422 = heff_field(v_x1_2421, 0);
    heff_take_n(v_x1_2421, 1ULL, 1);
    return v_x_2422;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2421, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2424 = heff_field(v_x1_2421, 0);
    heff_take_n(v_x1_2421, 1ULL, 1);
    return v_x_2424;
  }
  default: return heff_nomatch(v_x1_2421);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam0(V self, V *args) {
  V v_f_2419 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2419, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam1, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam3(V self, V *args) {
  V v_u_2437 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2437);
  V v_x1_2438 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_2438)) {
  case TAG_Nom: {
    V v_x_2439 = heff_field(v_x1_2438, 0);
    heff_take_n(v_x1_2438, 1ULL, 1);
    return v_x_2439;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2438, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2441 = heff_field(v_x1_2438, 0);
    heff_take_n(v_x1_2438, 1ULL, 1);
    return v_x_2441;
  }
  default: return heff_nomatch(v_x1_2438);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam2(V self, V *args) {
  V v_f_2436 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2436, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam3, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam5(V self, V *args) {
  V v_u_2454 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2454);
  V v_x1_2455 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_2455)) {
  case TAG_Nom: {
    V v_x_2456 = heff_field(v_x1_2455, 0);
    heff_take_n(v_x1_2455, 1ULL, 1);
    return v_x_2456;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2455, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2458 = heff_field(v_x1_2455, 0);
    heff_take_n(v_x1_2455, 1ULL, 1);
    return v_x_2458;
  }
  default: return heff_nomatch(v_x1_2455);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam4(V self, V *args) {
  V v_f_2453 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2453, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam5, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam7(V self, V *args) {
  V v_u_2472 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2472);
  V v_x1_2473 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_2473)) {
  case TAG_Nom: {
    V v_x_2474 = heff_field(v_x1_2473, 0);
    heff_take_n(v_x1_2473, 1ULL, 1);
    return v_x_2474;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2473, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2476 = heff_field(v_x1_2473, 0);
    heff_take_n(v_x1_2473, 1ULL, 1);
    return v_x_2476;
  }
  default: return heff_nomatch(v_x1_2473);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam6(V self, V *args) {
  V v_f_2471 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2471, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam7, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam8(V self, V *args) {
  V v_u_2491 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2491);
  V v_x1_2492 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_2492)) {
  case TAG_Nom: {
    V v_x_2493 = heff_field(v_x1_2492, 0);
    heff_take_n(v_x1_2492, 1ULL, 1);
    return v_x_2493;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2492, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2495 = heff_field(v_x1_2492, 0);
    heff_take_n(v_x1_2492, 1ULL, 1);
    return v_x_2495;
  }
  default: return heff_nomatch(v_x1_2492);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam10(V self, V *args) {
  V v_u_2498 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2498);
  V v_x1_2499 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_2499)) {
  case TAG_Nom: {
    V v_x_24100 = heff_field(v_x1_2499, 0);
    heff_take_n(v_x1_2499, 1ULL, 1);
    return v_x_24100;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2499, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24102 = heff_field(v_x1_2499, 0);
    heff_take_n(v_x1_2499, 1ULL, 1);
    return v_x_24102;
  }
  default: return heff_nomatch(v_x1_2499);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam9(V self, V *args) {
  V v_f_2497 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2497, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam10, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam12(V self, V *args) {
  V v_u_24115 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24115);
  V v_x1_24116 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24116)) {
  case TAG_Nom: {
    V v_x_24117 = heff_field(v_x1_24116, 0);
    heff_take_n(v_x1_24116, 1ULL, 1);
    return v_x_24117;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24116, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24119 = heff_field(v_x1_24116, 0);
    heff_take_n(v_x1_24116, 1ULL, 1);
    return v_x_24119;
  }
  default: return heff_nomatch(v_x1_24116);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam11(V self, V *args) {
  V v_f_24114 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24114, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam12, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam14(V self, V *args) {
  V v_u_24133 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24133);
  V v_x1_24134 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24134)) {
  case TAG_Nom: {
    V v_x_24135 = heff_field(v_x1_24134, 0);
    heff_take_n(v_x1_24134, 1ULL, 1);
    return v_x_24135;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24134, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24137 = heff_field(v_x1_24134, 0);
    heff_take_n(v_x1_24134, 1ULL, 1);
    return v_x_24137;
  }
  default: return heff_nomatch(v_x1_24134);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam13(V self, V *args) {
  V v_f_24132 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24132, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam14, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam16(V self, V *args) {
  V v_u_24151 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24151);
  V v_x1_24152 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24152)) {
  case TAG_Nom: {
    V v_x_24153 = heff_field(v_x1_24152, 0);
    heff_take_n(v_x1_24152, 1ULL, 1);
    return v_x_24153;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24152, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24155 = heff_field(v_x1_24152, 0);
    heff_take_n(v_x1_24152, 1ULL, 1);
    return v_x_24155;
  }
  default: return heff_nomatch(v_x1_24152);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam15(V self, V *args) {
  V v_f_24150 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24150, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam16, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam18(V self, V *args) {
  V v_u_24169 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24169);
  V v_x1_24170 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24170)) {
  case TAG_Nom: {
    V v_x_24171 = heff_field(v_x1_24170, 0);
    heff_take_n(v_x1_24170, 1ULL, 1);
    return v_x_24171;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24170, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24173 = heff_field(v_x1_24170, 0);
    heff_take_n(v_x1_24170, 1ULL, 1);
    return v_x_24173;
  }
  default: return heff_nomatch(v_x1_24170);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam17(V self, V *args) {
  V v_f_24168 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24168, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam18, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam20(V self, V *args) {
  V v_u_24188 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24188);
  V v_x1_24189 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24189)) {
  case TAG_Nom: {
    V v_x_24190 = heff_field(v_x1_24189, 0);
    heff_take_n(v_x1_24189, 1ULL, 1);
    return v_x_24190;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24189, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24192 = heff_field(v_x1_24189, 0);
    heff_take_n(v_x1_24189, 1ULL, 1);
    return v_x_24192;
  }
  default: return heff_nomatch(v_x1_24189);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam19(V self, V *args) {
  V v_f_24187 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24187, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam20, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam22(V self, V *args) {
  V v_u_24205 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24205);
  V v_x1_24206 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24206)) {
  case TAG_Nom: {
    V v_x_24207 = heff_field(v_x1_24206, 0);
    heff_take_n(v_x1_24206, 1ULL, 1);
    return v_x_24207;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24206, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24209 = heff_field(v_x1_24206, 0);
    heff_take_n(v_x1_24206, 1ULL, 1);
    return v_x_24209;
  }
  default: return heff_nomatch(v_x1_24206);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam21(V self, V *args) {
  V v_f_24204 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24204, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam22, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam24(V self, V *args) {
  V v_u_24221 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24221);
  V v_x1_24222 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24222)) {
  case TAG_Nom: {
    V v_x_24223 = heff_field(v_x1_24222, 0);
    heff_take_n(v_x1_24222, 1ULL, 1);
    return v_x_24223;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24222, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24225 = heff_field(v_x1_24222, 0);
    heff_take_n(v_x1_24222, 1ULL, 1);
    return v_x_24225;
  }
  default: return heff_nomatch(v_x1_24222);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam23(V self, V *args) {
  V v_f_24220 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24220, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam24, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam26(V self, V *args) {
  V v_u_24237 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24237);
  V v_x1_24238 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24238)) {
  case TAG_Nom: {
    V v_x_24239 = heff_field(v_x1_24238, 0);
    heff_take_n(v_x1_24238, 1ULL, 1);
    return v_x_24239;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24238, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24241 = heff_field(v_x1_24238, 0);
    heff_take_n(v_x1_24238, 1ULL, 1);
    return v_x_24241;
  }
  default: return heff_nomatch(v_x1_24238);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam25(V self, V *args) {
  V v_f_24236 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24236, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam26, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam28(V self, V *args) {
  V v_u_24254 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24254);
  V v_x1_24255 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24255)) {
  case TAG_Nom: {
    V v_x_24256 = heff_field(v_x1_24255, 0);
    heff_take_n(v_x1_24255, 1ULL, 1);
    return v_x_24256;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24255, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24258 = heff_field(v_x1_24255, 0);
    heff_take_n(v_x1_24255, 1ULL, 1);
    return v_x_24258;
  }
  default: return heff_nomatch(v_x1_24255);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam27(V self, V *args) {
  V v_f_24253 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24253, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam28, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam30(V self, V *args) {
  V v_u_24272 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24272);
  V v_x1_24273 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24273)) {
  case TAG_Nom: {
    V v_x_24274 = heff_field(v_x1_24273, 0);
    heff_take_n(v_x1_24273, 1ULL, 1);
    return v_x_24274;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24273, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24276 = heff_field(v_x1_24273, 0);
    heff_take_n(v_x1_24273, 1ULL, 1);
    return v_x_24276;
  }
  default: return heff_nomatch(v_x1_24273);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam29(V self, V *args) {
  V v_f_24271 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24271, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam30, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam32(V self, V *args) {
  V v_u_24290 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24290);
  V v_x1_24291 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24291)) {
  case TAG_Nom: {
    V v_x_24292 = heff_field(v_x1_24291, 0);
    heff_take_n(v_x1_24291, 1ULL, 1);
    return v_x_24292;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24291, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24294 = heff_field(v_x1_24291, 0);
    heff_take_n(v_x1_24291, 1ULL, 1);
    return v_x_24294;
  }
  default: return heff_nomatch(v_x1_24291);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam31(V self, V *args) {
  V v_f_24289 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24289, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam32, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam34(V self, V *args) {
  V v_u_24307 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24307);
  V v_x1_24308 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24308)) {
  case TAG_Nom: {
    V v_x_24309 = heff_field(v_x1_24308, 0);
    heff_take_n(v_x1_24308, 1ULL, 1);
    return v_x_24309;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24308, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24311 = heff_field(v_x1_24308, 0);
    heff_take_n(v_x1_24308, 1ULL, 1);
    return v_x_24311;
  }
  default: return heff_nomatch(v_x1_24308);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam33(V self, V *args) {
  V v_f_24306 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24306, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam34, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam36(V self, V *args) {
  V v_u_24326 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24326);
  V v_x1_24327 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24327)) {
  case TAG_Nom: {
    V v_x_24328 = heff_field(v_x1_24327, 0);
    heff_take_n(v_x1_24327, 1ULL, 1);
    return v_x_24328;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24327, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24330 = heff_field(v_x1_24327, 0);
    heff_take_n(v_x1_24327, 1ULL, 1);
    return v_x_24330;
  }
  default: return heff_nomatch(v_x1_24327);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam35(V self, V *args) {
  V v_f_24325 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24325, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam36, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam38(V self, V *args) {
  V v_u_24343 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24343);
  V v_x1_24344 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24344)) {
  case TAG_Nom: {
    V v_x_24345 = heff_field(v_x1_24344, 0);
    heff_take_n(v_x1_24344, 1ULL, 1);
    return v_x_24345;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24344, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24347 = heff_field(v_x1_24344, 0);
    heff_take_n(v_x1_24344, 1ULL, 1);
    return v_x_24347;
  }
  default: return heff_nomatch(v_x1_24344);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam37(V self, V *args) {
  V v_f_24342 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24342, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam38, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam40(V self, V *args) {
  V v_u_24360 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24360);
  V v_x1_24361 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24361)) {
  case TAG_Nom: {
    V v_x_24362 = heff_field(v_x1_24361, 0);
    heff_take_n(v_x1_24361, 1ULL, 1);
    return v_x_24362;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24361, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24364 = heff_field(v_x1_24361, 0);
    heff_take_n(v_x1_24361, 1ULL, 1);
    return v_x_24364;
  }
  default: return heff_nomatch(v_x1_24361);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam39(V self, V *args) {
  V v_f_24359 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24359, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam40, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam42(V self, V *args) {
  V v_u_24377 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24377);
  V v_x1_24378 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24378)) {
  case TAG_Nom: {
    V v_x_24379 = heff_field(v_x1_24378, 0);
    heff_take_n(v_x1_24378, 1ULL, 1);
    return v_x_24379;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24378, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24381 = heff_field(v_x1_24378, 0);
    heff_take_n(v_x1_24378, 1ULL, 1);
    return v_x_24381;
  }
  default: return heff_nomatch(v_x1_24378);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam41(V self, V *args) {
  V v_f_24376 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24376, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam42, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam44(V self, V *args) {
  V v_u_24394 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24394);
  V v_x1_24395 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24395)) {
  case TAG_Nom: {
    V v_x_24396 = heff_field(v_x1_24395, 0);
    heff_take_n(v_x1_24395, 1ULL, 1);
    return v_x_24396;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24395, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24398 = heff_field(v_x1_24395, 0);
    heff_take_n(v_x1_24395, 1ULL, 1);
    return v_x_24398;
  }
  default: return heff_nomatch(v_x1_24395);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam43(V self, V *args) {
  V v_f_24393 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24393, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam44, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam46(V self, V *args) {
  V v_u_24411 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24411);
  V v_x1_24412 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24412)) {
  case TAG_Nom: {
    V v_x_24413 = heff_field(v_x1_24412, 0);
    heff_take_n(v_x1_24412, 1ULL, 1);
    return v_x_24413;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24412, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24415 = heff_field(v_x1_24412, 0);
    heff_take_n(v_x1_24412, 1ULL, 1);
    return v_x_24415;
  }
  default: return heff_nomatch(v_x1_24412);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam45(V self, V *args) {
  V v_f_24410 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24410, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam46, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam48(V self, V *args) {
  V v_u_24429 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24429);
  V v_x1_24430 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24430)) {
  case TAG_Nom: {
    V v_x_24431 = heff_field(v_x1_24430, 0);
    heff_take_n(v_x1_24430, 1ULL, 1);
    return v_x_24431;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24430, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24433 = heff_field(v_x1_24430, 0);
    heff_take_n(v_x1_24430, 1ULL, 1);
    return v_x_24433;
  }
  default: return heff_nomatch(v_x1_24430);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam47(V self, V *args) {
  V v_f_24428 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24428, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam48, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam50(V self, V *args) {
  V v_u_24446 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24446);
  V v_x1_24447 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2417, v_vs_244}));
  switch (heff_tag_of(v_x1_24447)) {
  case TAG_Nom: {
    V v_x_24448 = heff_field(v_x1_24447, 0);
    heff_take_n(v_x1_24447, 1ULL, 1);
    return v_x_24448;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24447, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24450 = heff_field(v_x1_24447, 0);
    heff_take_n(v_x1_24447, 1ULL, 1);
    return v_x_24450;
  }
  default: return heff_nomatch(v_x1_24447);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam49(V self, V *args) {
  V v_f_24445 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2417 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2evalue_2eapp(v_f_24445, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_lam50, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2417, v_vs_244})));
}
V g_heff_2eelab_2eeval_2eevalTermF_lam51(V self, V *args) {
  V v_u_24465 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_dom_24461 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24465);
  V v_x1_24466 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_dom_24461, v_vs_244}));
  switch (heff_tag_of(v_x1_24466)) {
  case TAG_Nom: {
    V v_x_24467 = heff_field(v_x1_24466, 0);
    heff_take_n(v_x1_24466, 1ULL, 1);
    return v_x_24467;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24466, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24469 = heff_field(v_x1_24466, 0);
    heff_take_n(v_x1_24466, 1ULL, 1);
    return v_x_24469;
  }
  default: return heff_nomatch(v_x1_24466);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam52(V self, V *args) {
  V v_vs2_24470 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_c_242 = heff_env(self)[2];
  V v_t_24464 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_r_240, 0, 2);
  heff_room[0] = v_g_241;
  heff_room[1] = v_c_242;
  heff_room[2] = v_t_24464;
  heff_room[3] = v_vs2_24470;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eeval_2eevalTermF_lam53(V self, V *args) {
  V v_u_24474 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_dom_24461 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24474);
  V v_x1_24475 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_dom_24461, v_vs_244}));
  switch (heff_tag_of(v_x1_24475)) {
  case TAG_Nom: {
    V v_x_24476 = heff_field(v_x1_24475, 0);
    heff_take_n(v_x1_24475, 1ULL, 1);
    return v_x_24476;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24475, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24478 = heff_field(v_x1_24475, 0);
    heff_take_n(v_x1_24475, 1ULL, 1);
    return v_x_24478;
  }
  default: return heff_nomatch(v_x1_24475);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam54(V self, V *args) {
  V v_i_24482 = args[0];
  V v_xs_24481 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_c_242 = heff_env(self)[3];
  V v_vs_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24483 = heff_arrayIndex(v_xs_24481, v_i_24482);
  V f_ = heff_get_n(v_r_240, 0, 2);
  heff_room[0] = v_g_241;
  heff_room[1] = v_c_242;
  heff_room[2] = v_t_24483;
  heff_room[3] = v_vs_244;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eeval_2eevalTermF_lam55(V self, V *args) {
  V v_v_24489 = args[0];
  V v_x_24488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_v_24489)) {
  case TAG_VNeu: {
    V v_t_24495 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_24489));
    return ({ V a_0 = v_t_24495; V a_1 = v_x_24488; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_24488); r_; });
  }
  case TAG_VCode: {
    V v_t_24497 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_24489));
    return ({ V a_0 = v_t_24497; V a_1 = v_x_24488; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_24488); r_; });
  }
  case TAG_VLam: {
    V v_t_24500 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_24489));
    return ({ V a_0 = v_t_24500; V a_1 = v_x_24488; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_24488); r_; });
  }
  case TAG_VCons: {
    V v_t_24502 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_24489));
    return ({ V a_0 = v_t_24502; V a_1 = v_x_24488; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_24488); r_; });
  }
  case TAG_VOpaque: {
    heff_drop(v_x_24488);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_v_24489);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_lam56(V self, V *args) {
  V v_sp_24546 = args[0];
  V v_i_24547 = args[1];
  V v_vs_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24548 = ({ V a_0 = v_vs_244; V a_1 = v_i_24547; V r_ = heff_tr(g_heff_2eelab_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_vs_244); r_; });
  return heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_24546, v_t_24548});
}
V g_heff_2eelab_2eeval_2eevalTermF_lam57(V self, V *args) {
  V v_u_24555 = args[0];
  V v_sp_24549 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24555);
  return v_sp_24549;
}
V g_heff_2eelab_2eeval_2eevalTermF_lam58(V self, V *args) {
  V v_u_24556 = args[0];
  V v_ty_24554 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24556);
  return v_ty_24554;
}
Clo g_heff_2eelab_2eeval_2eerrorHeaded_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eerrorHeaded_entry, 1, 0};

V g_heff_2eelab_2eeval_2eerrorHeaded(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    return NTAG(TAG_False);
  }
  case TAG_SApp: {
    V v_t_244 = heff_field(v_x1_240, 0);
    V t_0 = v_t_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SLam: {
    return NTAG(TAG_False);
  }
  case TAG_SCons: {
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    V v_t_249 = heff_field(v_x1_240, 0);
    V t_0 = v_t_249;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_STag: {
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    V v_t_2415 = heff_field(v_x1_240, 0);
    V t_0 = v_t_2415;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SIs: {
    return NTAG(TAG_False);
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_True);
  }
  case TAG_SRec: {
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    return NTAG(TAG_False);
  }
  case TAG_SMetaApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLitInt: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    return NTAG(TAG_False);
  }
  case TAG_SLitBytes: {
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eeval_2eerrorHeaded_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eeval_2eerrorHeaded(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam0(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam0, 1, 0};
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam1(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam1, 1, 0};
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam7(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam5(V self, V *args);

HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24cpr(V v_r_240, V v_g_241, V v_c_242, V v_x4_243, V v_vs_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_SU: {
    V v_u_245 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SU = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_at_n(v_ru_24x4_243_24SU, TAG_VU, 1, (V[]){v_u_245})}});
  }
  case TAG_SDecode: {
    V v_t_246 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_t_247 = (g_heff_2eelab_2eeval_2eerrorHeaded(v_t_246));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop_rec(v_r_240, 2);
      heff_drop(v_g_241);
      heff_drop(v_c_242);
      heff_drop(v_vs_244);
      heff_drop(v_t_246);
      heff_drop(v_t_247);
      V v_t_2410 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam0_clo), ((V)&g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam1_clo)});
      return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_2410}});
    } else {
      heff_drop(v_t_247);
      V v_t_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 4, (V[]){v_g_241, v_c_242, v_t_246, v_vs_244}));
      return ({ V a_0 = v_t_2411; HeffT2 r_ = (g_heff_2eelab_2evalue_2edecodeEv_24cpr(a_0)); heff_drop(v_t_2411); r_; });
    }
  }
  case TAG_SFunction: {
    V v_level_2412 = heff_field(v_x4_243, 0);
    V v_dom_2413 = heff_field(v_x4_243, 1);
    V v_cod_2414 = heff_field(v_x4_243, 2);
    V v_implicit_2415 = heff_field(v_x4_243, 3);
    V v_dflt_2416 = heff_field(v_x4_243, 4);
    heff_take_n(v_x4_243, 31ULL, 5);
    heff_drop(v_c_242);
    V v_x1_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 4, (V[]){heff_dup(v_g_241), NTAG(TAG_N), v_dom_2413, heff_dup(v_vs_244)}));
    V v_t_2421;
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Nom: {
      V v_x_2418 = heff_field(v_x1_2417, 0);
      heff_take_n(v_x1_2417, 1ULL, 1);
      v_t_2421 = v_x_2418;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2417, 0ULL, 1);
      v_t_2421 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2420 = heff_field(v_x1_2417, 0);
      heff_take_n(v_x1_2417, 1ULL, 1);
      v_t_2421 = v_x_2420;
      break;
    }
    default: heff_nomatch(v_x1_2417);
    }
    V v_t_2427;
    switch (heff_tag_of(v_cod_2414)) {
    case TAG_MkAbs: {
      V v_x_2422 = heff_field(v_cod_2414, 0);
      V v_t_2423 = heff_field(v_cod_2414, 1);
      heff_take_n(v_cod_2414, 3ULL, 2);
      v_t_2427 = heff_tag_n(TAG_MkClo, 3, (V[]){v_x_2422, v_vs_244, heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam2, 1, 3, (V[]){v_r_240, v_g_241, v_t_2423})});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2425 = heff_field(v_cod_2414, 0);
      V v_ru_24cod_2414_24AbsConst = heff_take_reuse_n(v_cod_2414, 1ULL, 1);
      V v_t_2426 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2425, v_vs_244}));
      v_t_2427 = heff_tag_at_n(v_ru_24cod_2414_24AbsConst, TAG_CloConst, 1, (V[]){v_t_2426});
      break;
    }
    default: heff_nomatch(v_cod_2414);
    }
    V v_f_2428 = heff_tag_n(TAG_VFunction, 6, (V[]){v_level_2412, v_t_2421, v_t_2427, v_implicit_2415, v_dflt_2416, NTAG(TAG_Nothing)});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_f_2428}});
  }
  case TAG_SRecord: {
    V v_level_2429 = heff_field(v_x4_243, 0);
    V v_fieldTypes_2430 = heff_field(v_x4_243, 1);
    V v_defaults_2431 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    heff_drop(v_c_242);
    V v_xs_2432 = heff_take_field(v_fieldTypes_2430, 2);
    V v_t_2441 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2432, 0), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam3, 1, 3, (V[]){v_xs_2432, v_r_240, v_g_241}));
    V v_t_2442 = ({ V rv_2 = v_t_2441; V rr_ = heff_rec_reuse_nf(v_fieldTypes_2430, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_f_2443 = heff_tag_n(TAG_VRecord, 4, (V[]){v_level_2429, v_vs_244, v_t_2442, v_defaults_2431});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2443}});
  }
  case TAG_SSum: {
    V v_st_2444 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SSum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    V v_xs_2445 = heff_take_field(v_st_2444, 2);
    V v_t_2455 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2445, 0), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam5, 1, 4, (V[]){v_xs_2445, v_r_240, v_g_241, v_vs_244}));
    V v_t_2456 = ({ V rv_2 = v_t_2455; V rr_ = heff_rec_reuse_nf(v_st_2444, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_f_2457 = heff_tag_at_n(v_ru_24x4_243_24SSum, TAG_VSum, 1, (V[]){v_t_2456});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2457}});
  }
  case TAG_SIsTy: {
    V v_t_2458 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    V v_x1_2459 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2458, v_vs_244}));
    V v_f_2463;
    switch (heff_tag_of(v_x1_2459)) {
    case TAG_Nom: {
      V v_x_2460 = heff_field(v_x1_2459, 0);
      heff_take_n(v_x1_2459, 1ULL, 1);
      v_f_2463 = v_x_2460;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2459, 0ULL, 1);
      v_f_2463 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2462 = heff_field(v_x1_2459, 0);
      heff_take_n(v_x1_2459, 1ULL, 1);
      v_f_2463 = v_x_2462;
      break;
    }
    default: heff_nomatch(v_x1_2459);
    }
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2463}});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimInt)}});
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimFloat)}});
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimString)}});
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimRune)}});
  }
  case TAG_SPrimArray: {
    V v_a_2464 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SPrimArray = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    V v_x1_2465 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_a_2464, v_vs_244}));
    V v_t_2469;
    switch (heff_tag_of(v_x1_2465)) {
    case TAG_Nom: {
      V v_x_2466 = heff_field(v_x1_2465, 0);
      heff_take_n(v_x1_2465, 1ULL, 1);
      v_t_2469 = v_x_2466;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2465, 0ULL, 1);
      v_t_2469 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2468 = heff_field(v_x1_2465, 0);
      heff_take_n(v_x1_2465, 1ULL, 1);
      v_t_2469 = v_x_2468;
      break;
    }
    default: heff_nomatch(v_x1_2465);
    }
    V v_f_2470 = heff_tag_at_n(v_ru_24x4_243_24SPrimArray, TAG_VPrimArray, 1, (V[]){v_t_2469});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_f_2470}});
  }
  case TAG_SFixed: {
    V v_w_2471 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SFixed = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_at_n(v_ru_24x4_243_24SFixed, TAG_VFixed, 1, (V[]){v_w_2471})}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam0(V self, V *args) {
  V v_x_248 = args[0];
  heff_drop(v_x_248);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam1(V self, V *args) {
  V v_x_249 = args[0];
  heff_drop(v_x_249);
  return (g_heff_2eelab_2evalue_2ereflect_24s1249042670x1731126382(NTAG(TAG_HError), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam2(V self, V *args) {
  V v_vs2_2424 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_get_n(v_r_240, 1, 2);
  heff_room[0] = v_g_241;
  heff_room[1] = NTAG(TAG_N);
  heff_room[2] = v_t_2423;
  heff_room[3] = v_vs2_2424;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam4(V self, V *args) {
  V v_vs2_2435 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t_2434 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_2436 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2434, v_vs2_2435}));
  V v_t_2440;
  switch (heff_tag_of(v_x1_2436)) {
  case TAG_Nom: {
    V v_x_2437 = heff_field(v_x1_2436, 0);
    heff_take_n(v_x1_2436, 1ULL, 1);
    v_t_2440 = v_x_2437;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2436, 0ULL, 1);
    v_t_2440 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2439 = heff_field(v_x1_2436, 0);
    heff_take_n(v_x1_2436, 1ULL, 1);
    v_t_2440 = v_x_2439;
    break;
  }
  default: heff_nomatch(v_x1_2436);
  }
  return heff_tag_n(TAG_MkField, 2, (V[]){v_t_2440, NTAG(TAG_Nothing)});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam3(V self, V *args) {
  V v_i_2433 = args[0];
  V v_xs_2432 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2434 = heff_arrayIndex(v_xs_2432, v_i_2433);
  return heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam4, 1, 3, (V[]){v_r_240, v_g_241, v_t_2434});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam7(V self, V *args) {
  V v_u_2450 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t_2449 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2450);
  V v_x1_2451 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2449, v_vs_244}));
  switch (heff_tag_of(v_x1_2451)) {
  case TAG_Nom: {
    V v_x_2452 = heff_field(v_x1_2451, 0);
    heff_take_n(v_x1_2451, 1ULL, 1);
    return v_x_2452;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2451, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2454 = heff_field(v_x1_2451, 0);
    heff_take_n(v_x1_2451, 1ULL, 1);
    return v_x_2454;
  }
  default: return heff_nomatch(v_x1_2451);
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam6(V self, V *args) {
  V v_i_2448 = args[0];
  V v_xs_2447 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2449 = heff_arrayIndex(v_xs_2447, v_i_2448);
  return heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam7, 1, 4, (V[]){v_r_240, v_g_241, v_t_2449, v_vs_244});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam5(V self, V *args) {
  V v_i_2446 = args[0];
  V v_xs_2445 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_xs_2447 = heff_arrayIndex(v_xs_2445, v_i_2446);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_2447, 0), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24cpr_lam6, 1, 4, (V[]){v_xs_2447, v_r_240, v_g_241, v_vs_244}));
}
Clo g_heff_2eelab_2eeval_2eevalTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_entry, 5, 0};

V g_heff_2eelab_2eeval_2eevalTypeF(V v_r_240, V v_g_241, V v_c_242, V v_x4_243, V v_vs_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2eelab_2eeval_2eevalTypeF_24cpr(v_r_240, v_g_241, v_c_242, v_x4_243, v_vs_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Become, 1, (V[]){v_field_247});
    } else {
      if ((v_tag_246 == ((int64_t)1ULL))) {
        return heff_tag_n(TAG_Describe, 1, (V[]){v_field_247});
      } else {
        return heff_tag_n(TAG_Nom, 1, (V[]){v_field_247});
      }
    }
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eeval_2eevalTypeF(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eeval_2eevaluator_lam0(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevaluator_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevaluator_lam0, 4, 0};
V g_heff_2eelab_2eeval_2eevaluator_lam1(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevaluator_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevaluator_lam1, 4, 0};

static V g_heff_2eelab_2eeval_2eevaluator_val;
static HEFF_ONCE g_heff_2eelab_2eeval_2eevaluator_st;
static V g_heff_2eelab_2eeval_2eevaluator_init(void) {
  return heff_rec_n(2, shape_el__ty, (V[]){((V)&g_heff_2eelab_2eeval_2eevaluator_lam0_clo), ((V)&g_heff_2eelab_2eeval_2eevaluator_lam1_clo)});
}
V g_heff_2eelab_2eeval_2eevaluator_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eeval_2eevaluator_st)) return g_heff_2eelab_2eeval_2eevaluator_val;
  return heff_global(&g_heff_2eelab_2eeval_2eevaluator_val, &g_heff_2eelab_2eeval_2eevaluator_st, g_heff_2eelab_2eeval_2eevaluator_init);
}
V g_heff_2eelab_2eeval_2eevaluator_lam0(V self, V *args) {
  V v_g_240 = args[0];
  V v_c_241 = args[1];
  V v_s_242 = args[2];
  V v_vs_243 = args[3];
  return (g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, v_c_241, v_s_242, v_vs_243));
}
V g_heff_2eelab_2eeval_2eevaluator_lam1(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_s_246 = args[2];
  V v_vs_247 = args[3];
  return (g_heff_2eelab_2eeval_2eevalTypeF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_244, v_c_245, v_s_246, v_vs_247));
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam0(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam0, 1, 0};
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam1(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam1, 1, 0};
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam7(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam5(V self, V *args);

HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V v_g_240, V v_c_241, V v_x4_242, V v_vs_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SU: {
    V v_u_244 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SU = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_at_n(v_ru_24x4_242_24SU, TAG_VU, 1, (V[]){v_u_244})}});
  }
  case TAG_SDecode: {
    V v_t_245 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    V v_t_246 = (g_heff_2eelab_2eeval_2eerrorHeaded(v_t_245));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_g_240);
      heff_drop(v_c_241);
      heff_drop(v_vs_243);
      heff_drop(v_t_245);
      heff_drop(v_t_246);
      V v_t_249 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam0_clo), ((V)&g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam1_clo)});
      return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_249}});
    } else {
      heff_drop(v_t_246);
      V v_t_2410 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, v_c_241, v_t_245, v_vs_243));
      return ({ V a_0 = v_t_2410; HeffT2 r_ = (g_heff_2eelab_2evalue_2edecodeEv_24cpr(a_0)); heff_drop(v_t_2410); r_; });
    }
  }
  case TAG_SFunction: {
    V v_level_2411 = heff_field(v_x4_242, 0);
    V v_dom_2412 = heff_field(v_x4_242, 1);
    V v_cod_2413 = heff_field(v_x4_242, 2);
    V v_implicit_2414 = heff_field(v_x4_242, 3);
    V v_dflt_2415 = heff_field(v_x4_242, 4);
    heff_take_n(v_x4_242, 31ULL, 5);
    heff_drop(v_c_241);
    HeffT2 v_t_2416 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(v_g_240), NTAG(TAG_N), v_dom_2412, heff_dup(v_vs_243)));
    V v_t_2424;
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        V v_x_2420 = v_field_2418;
        v_t_2424 = v_x_2420;
      } else {
        if ((v_tag_2417 == ((int64_t)1ULL))) {
          V v_x11_2422 = v_field_2418;
          heff_drop(v_x11_2422);
          v_t_2424 = heff_abandon();
        } else {
          V v_x_2423 = v_field_2418;
          v_t_2424 = v_x_2423;
        }
      }
    }
    V v_t_2430;
    switch (heff_tag_of(v_cod_2413)) {
    case TAG_MkAbs: {
      V v_x_2425 = heff_field(v_cod_2413, 0);
      V v_t_2426 = heff_field(v_cod_2413, 1);
      heff_take_n(v_cod_2413, 3ULL, 2);
      v_t_2430 = heff_tag_n(TAG_MkClo, 3, (V[]){v_x_2425, v_vs_243, heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam2, 1, 2, (V[]){v_g_240, v_t_2426})});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2428 = heff_field(v_cod_2413, 0);
      V v_ru_24cod_2413_24AbsConst = heff_take_reuse_n(v_cod_2413, 1ULL, 1);
      V v_t_2429 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_t_2428, v_vs_243));
      v_t_2430 = heff_tag_at_n(v_ru_24cod_2413_24AbsConst, TAG_CloConst, 1, (V[]){v_t_2429});
      break;
    }
    default: heff_nomatch(v_cod_2413);
    }
    V v_f_2431 = heff_tag_n(TAG_VFunction, 6, (V[]){v_level_2411, v_t_2424, v_t_2430, v_implicit_2414, v_dflt_2415, NTAG(TAG_Nothing)});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_f_2431}});
  }
  case TAG_SRecord: {
    V v_level_2432 = heff_field(v_x4_242, 0);
    V v_fieldTypes_2433 = heff_field(v_x4_242, 1);
    V v_defaults_2434 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    heff_drop(v_c_241);
    V v_xs_2435 = heff_take_field(v_fieldTypes_2433, 2);
    V v_t_2448 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2435, 0), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam3, 1, 2, (V[]){v_xs_2435, v_g_240}));
    V v_t_2449 = ({ V rv_2 = v_t_2448; V rr_ = heff_rec_reuse_nf(v_fieldTypes_2433, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_f_2450 = heff_tag_n(TAG_VRecord, 4, (V[]){v_level_2432, v_vs_243, v_t_2449, v_defaults_2434});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2450}});
  }
  case TAG_SSum: {
    V v_st_2451 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SSum = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    V v_xs_2452 = heff_take_field(v_st_2451, 2);
    V v_t_2466 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2452, 0), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam5, 1, 3, (V[]){v_xs_2452, v_g_240, v_vs_243}));
    V v_t_2467 = ({ V rv_2 = v_t_2466; V rr_ = heff_rec_reuse_nf(v_st_2451, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_f_2468 = heff_tag_at_n(v_ru_24x4_242_24SSum, TAG_VSum, 1, (V[]){v_t_2467});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2468}});
  }
  case TAG_SIsTy: {
    V v_t_2469 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    HeffT2 v_t_2470 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), v_t_2469, v_vs_243));
    V v_f_2478;
    {
      V v_field_2472 = v_t_2470.f[1];
      int64_t v_tag_2471 = ((int64_t)v_t_2470.f[0]);
      if ((v_tag_2471 == ((int64_t)0ULL))) {
        V v_x_2474 = v_field_2472;
        v_f_2478 = v_x_2474;
      } else {
        if ((v_tag_2471 == ((int64_t)1ULL))) {
          V v_x11_2476 = v_field_2472;
          heff_drop(v_x11_2476);
          v_f_2478 = heff_abandon();
        } else {
          V v_x_2477 = v_field_2472;
          v_f_2478 = v_x_2477;
        }
      }
    }
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2478}});
  }
  case TAG_SPrimInt: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimInt)}});
  }
  case TAG_SPrimFloat: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimFloat)}});
  }
  case TAG_SPrimString: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimString)}});
  }
  case TAG_SPrimRune: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimRune)}});
  }
  case TAG_SPrimArray: {
    V v_a_2479 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SPrimArray = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    HeffT2 v_t_2480 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), v_a_2479, v_vs_243));
    V v_t_2488;
    {
      V v_field_2482 = v_t_2480.f[1];
      int64_t v_tag_2481 = ((int64_t)v_t_2480.f[0]);
      if ((v_tag_2481 == ((int64_t)0ULL))) {
        V v_x_2484 = v_field_2482;
        v_t_2488 = v_x_2484;
      } else {
        if ((v_tag_2481 == ((int64_t)1ULL))) {
          V v_x11_2486 = v_field_2482;
          heff_drop(v_x11_2486);
          v_t_2488 = heff_abandon();
        } else {
          V v_x_2487 = v_field_2482;
          v_t_2488 = v_x_2487;
        }
      }
    }
    V v_f_2489 = heff_tag_at_n(v_ru_24x4_242_24SPrimArray, TAG_VPrimArray, 1, (V[]){v_t_2488});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_f_2489}});
  }
  case TAG_SFixed: {
    V v_w_2490 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SFixed = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_at_n(v_ru_24x4_242_24SFixed, TAG_VFixed, 1, (V[]){v_w_2490})}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam0(V self, V *args) {
  V v_x_247 = args[0];
  heff_drop(v_x_247);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam1(V self, V *args) {
  V v_x_248 = args[0];
  heff_drop(v_x_248);
  return (g_heff_2eelab_2evalue_2ereflect_24s1249042670x1731126382(NTAG(TAG_HError), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam2(V self, V *args) {
  V v_vs2_2427 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_t_2426, v_vs2_2427));
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam4(V self, V *args) {
  V v_vs2_2438 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2437 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2439 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), v_t_2437, v_vs2_2438));
  V v_t_2447;
  {
    V v_field_2441 = v_t_2439.f[1];
    int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
    if ((v_tag_2440 == ((int64_t)0ULL))) {
      V v_x_2443 = v_field_2441;
      v_t_2447 = v_x_2443;
    } else {
      if ((v_tag_2440 == ((int64_t)1ULL))) {
        V v_x11_2445 = v_field_2441;
        heff_drop(v_x11_2445);
        v_t_2447 = heff_abandon();
      } else {
        V v_x_2446 = v_field_2441;
        v_t_2447 = v_x_2446;
      }
    }
  }
  return heff_tag_n(TAG_MkField, 2, (V[]){v_t_2447, NTAG(TAG_Nothing)});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam3(V self, V *args) {
  V v_i_2436 = args[0];
  V v_xs_2435 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = heff_arrayIndex(v_xs_2435, v_i_2436);
  return heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam4, 1, 2, (V[]){v_g_240, v_t_2437});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam7(V self, V *args) {
  V v_u_2457 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2456 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2457);
  HeffT2 v_t_2458 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), v_t_2456, v_vs_243));
  {
    V v_field_2460 = v_t_2458.f[1];
    int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
    if ((v_tag_2459 == ((int64_t)0ULL))) {
      V v_x_2462 = v_field_2460;
      return v_x_2462;
    } else {
      if ((v_tag_2459 == ((int64_t)1ULL))) {
        V v_x11_2464 = v_field_2460;
        heff_drop(v_x11_2464);
        return heff_abandon();
      } else {
        V v_x_2465 = v_field_2460;
        return v_x_2465;
      }
    }
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam6(V self, V *args) {
  V v_i_2455 = args[0];
  V v_xs_2454 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2456 = heff_arrayIndex(v_xs_2454, v_i_2455);
  return heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam7, 1, 3, (V[]){v_g_240, v_t_2456, v_vs_243});
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam5(V self, V *args) {
  V v_i_2453 = args[0];
  V v_xs_2452 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_xs_2454 = heff_arrayIndex(v_xs_2452, v_i_2453);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_2454, 0), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam6, 1, 3, (V[]){v_xs_2454, v_g_240, v_vs_243}));
}
Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry, 4, 0};

V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V v_g_240, V v_c_241, V v_x4_242, V v_vs_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, v_c_241, v_x4_242, v_vs_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Become, 1, (V[]){v_field_246});
    } else {
      if ((v_tag_245 == ((int64_t)1ULL))) {
        return heff_tag_n(TAG_Describe, 1, (V[]){v_field_246});
      } else {
        return heff_tag_n(TAG_Nom, 1, (V[]){v_field_246});
      }
    }
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(a[0], a[1], a[2], a[3]);
}