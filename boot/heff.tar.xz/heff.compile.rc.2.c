// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ATail 47533
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLoop 31741
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CTail 59847
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_FtOther 63706
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_ICond 62625
#define TAG_IOp 20150
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_KnownCell 38933
#define TAG_KnownTag 34380
#define TAG_MkBlock 5679
#define TAG_MkCArm 24694
#define TAG_MkWrapper 39179
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_RAbandon 7524
#define TAG_RBox 28228
#define TAG_RCall 39004
#define TAG_RLocal 34280
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define TAG_TakeKeep 54413
#define TAG_TakeN 37047
#define TAG_TakeNone 22612
#define LBL_after 294093302
#define LBL_args 9498020
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_fixed 298804110
#define LBL_funs 9650075
#define LBL_key 315609
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_op 10312
#define LBL_owned 307523263
#define LBL_params 951713969
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_takes 311482598
static uint32_t shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret[] = {LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes, LBL_reprs, LBL_sigs, LBL_ret};
V g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174(V, V);
V g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174_clo;
V g_heff_2ecompile_2eimp_2etimesIn(V, V);
V g_heff_2ecompile_2eimp_2etimesIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2etimesIn_clo;
V g_heff_2ecompile_2erc_2eagrees(V, V, V);
V g_heff_2ecompile_2erc_2eagrees_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eagrees_clo;
V g_heff_2ecompile_2erc_2eapplyLast(V, V, V);
V g_heff_2ecompile_2erc_2eapplyLast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eapplyLast_clo;
V g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_clo;
V g_heff_2ecompile_2erc_2earmOf_24s150833151x1640468863(V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2earmOf_24s150833151x1640468863_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2earmOf_24s150833151x1640468863_clo;
V g_heff_2ecompile_2erc_2eboolDone(V, V);
V g_heff_2ecompile_2erc_2eboolDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eboolDone_clo;
V g_heff_2ecompile_2erc_2ecallAs(V, V, V, V, V);
V g_heff_2ecompile_2erc_2ecallAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ecallAs_clo;
V g_heff_2ecompile_2erc_2ecallLast_24s1815774051x1886726305(V, V, V);
V g_heff_2ecompile_2erc_2ecallLast_24s1815774051x1886726305_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ecallLast_24s1815774051x1886726305_clo;
V g_heff_2ecompile_2erc_2echangedOf(V, V, V);
V g_heff_2ecompile_2erc_2echangedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2echangedOf_clo;
V g_heff_2ecompile_2erc_2ecoerce(V, V, V);
V g_heff_2ecompile_2erc_2ecoerce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ecoerce_clo;
V g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500(V, V, V, V);
V g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500_clo;
V g_heff_2ecompile_2erc_2ecompV_24s792489109x351586786(V, V, V);
V g_heff_2ecompile_2erc_2ecompV_24s792489109x351586786_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ecompV_24s792489109x351586786_clo;
V g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836(V, V);
V g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836_clo;
V g_heff_2ecompile_2erc_2econdF_24s874044303x263379189(V, V);
V g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_clo;
V g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_24dps(V, V, V, V);
V g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_24dps_clo;
V g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483(V, V, V, V, V);
V g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483_clo;
V g_heff_2ecompile_2erc_2edropsOf(V, V);
V g_heff_2ecompile_2erc_2edropsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2edropsOf_clo;
V g_heff_2ecompile_2erc_2eelemI(V, V);
V g_heff_2ecompile_2erc_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eelemI_clo;
V g_heff_2ecompile_2erc_2eelemS(V, V);
V g_heff_2ecompile_2erc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eelemS_clo;
V g_heff_2ecompile_2erc_2efieldMask(V, V, V);
V g_heff_2ecompile_2erc_2efieldMask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efieldMask_clo;
V g_heff_2ecompile_2erc_2efreeGo(V, V, V, V);
V g_heff_2ecompile_2erc_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efreeGo_clo;
V g_heff_2ecompile_2erc_2efvRest(V, V);
V g_heff_2ecompile_2erc_2efvRest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efvRest_clo;
V g_heff_2ecompile_2erc_2efvSts(V);
V g_heff_2ecompile_2erc_2efvSts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efvSts_clo;
V g_heff_2ecompile_2erc_2efvTl(V);
V g_heff_2ecompile_2erc_2efvTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efvTl_clo;
V g_heff_2ecompile_2erc_2efvW(V, V, V);
V g_heff_2ecompile_2erc_2efvW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efvW_clo;
V g_heff_2ecompile_2erc_2ekeptFrom(V, V);
V g_heff_2ecompile_2erc_2ekeptFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ekeptFrom_clo;
V g_heff_2ecompile_2erc_2elentField(V, V, V);
V g_heff_2ecompile_2erc_2elentField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2elentField_clo;
V g_heff_2ecompile_2erc_2elentOr_24s1810949213x1891197566(V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2elentOr_24s1810949213x1891197566_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2elentOr_24s1810949213x1891197566_clo;
V g_heff_2ecompile_2erc_2elentTo(V);
V g_heff_2ecompile_2erc_2elentTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2elentTo_clo;
V g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499(V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499_clo;
V g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499_24dps(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499_24dps_clo;
V g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829(V, V, V, V);
V g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_clo;
V g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_24dps(V, V, V, V, V);
V g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_24dps_clo;
V g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551(V, V, V);
V g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_clo;
V g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_24dps(V, V, V, V);
V g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_24dps_clo;
V g_heff_2ecompile_2erc_2eothersW(V, V, V);
V g_heff_2ecompile_2erc_2eothersW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eothersW_clo;
V g_heff_2ecompile_2erc_2erelTest_24s79554594x384851698(V, V, V, V);
V g_heff_2ecompile_2erc_2erelTest_24s79554594x384851698_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2erelTest_24s79554594x384851698_clo;
V g_heff_2ecompile_2erc_2ereusePrim_get(void);
V g_heff_2ecompile_2erc_2ereusing(V, V, V, V);
V g_heff_2ecompile_2erc_2ereusing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ereusing_clo;
V g_heff_2ecompile_2erc_2eroomFor_get(void);
V g_heff_2ecompile_2erc_2esameS(V, V);
V g_heff_2ecompile_2erc_2esameS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2esameS_clo;
V g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414(V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_clo;
V g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518(V, V, V);
V g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518_clo;
V g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315(V, V);
V g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315_clo;
V g_heff_2ecompile_2erc_2etakeVar(V, V, V, V, V);
V g_heff_2ecompile_2erc_2etakeVar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2etakeVar_clo;
V g_heff_2ecompile_2erc_2etakenFv(V, V, V, V);
V g_heff_2ecompile_2erc_2etakenFv_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2etakenFv_clo;
V g_heff_2ecompile_2erc_2etyAt(V, V);
V g_heff_2ecompile_2erc_2etyAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2etyAt_clo;
V g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(V, V, V, V);
V g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_clo;
V g_heff_2ecompile_2erc_2ewithBorrowed(V, V);
V g_heff_2ecompile_2erc_2ewithBorrowed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ewithBorrowed_clo;
V g_heff_2ecompile_2erc_2ewithKnown(V, V, V);
V g_heff_2ecompile_2erc_2ewithKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ewithKnown_clo;
V g_heff_2ecompile_2erc_2ewrapUnbox(V, V, V);
V g_heff_2ecompile_2erc_2ewrapUnbox_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ewrapUnbox_clo;
V g_heff_2ecompile_2erc_2ewrapperOf(V, V, V, V, V);
V g_heff_2ecompile_2erc_2ewrapperOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ewrapperOf_clo;
V g_heff_2ecompile_2erepr_2efloatShape(V);
V g_heff_2ecompile_2erepr_2efloatShape_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2efloatShape_clo;
V g_heff_2ecompile_2erepr_2eopShape(V, V);
V g_heff_2ecompile_2erepr_2eopShape_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eopShape_clo;
V g_heff_2eelab_2efixed_2efixedPrimOf(V);
V g_heff_2eelab_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimOf_clo;
V g_list_2eall_24s1359914687x262073401(V);
V g_list_2eall_24s1359914687x262073401_entry(V self, V *a);
extern Clo g_list_2eall_24s1359914687x262073401_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f1686830387x1555365313(V, V, V, V);
V g_list_2efoldl_24f1686830387x1555365313_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1686830387x1555365313_clo;
V g_list_2efoldl_24s1104809983x118204267(V, V);
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1104809983x118204267_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1203202837x1639358108(V, V);
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1203202837x1639358108_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1790904629x1122008408(V, V);
V g_list_2efoldl_24s1790904629x1122008408_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1790904629x1122008408_clo;
V g_list_2efoldl_24s421921225x565177679(V, V);
V g_list_2efoldl_24s421921225x565177679_entry(V self, V *a);
extern Clo g_list_2efoldl_24s421921225x565177679_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2emap_24f1548644028x2098102081(V, V);
V g_list_2emap_24f1548644028x2098102081_entry(V self, V *a);
extern Clo g_list_2emap_24f1548644028x2098102081_clo;
V g_list_2emap_24s1490052334x152035327(V);
V g_list_2emap_24s1490052334x152035327_entry(V self, V *a);
extern Clo g_list_2emap_24s1490052334x152035327_clo;
V g_list_2emap_24s1598879313x231311047(V);
V g_list_2emap_24s1598879313x231311047_entry(V self, V *a);
extern Clo g_list_2emap_24s1598879313x231311047_clo;
V g_list_2emap_24s1661823642x1450093706(V);
V g_list_2emap_24s1661823642x1450093706_entry(V self, V *a);
extern Clo g_list_2emap_24s1661823642x1450093706_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
Clo g_heff_2ecompile_2erc_2ewithKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ewithKnown_entry, 3, 0};

V g_heff_2ecompile_2erc_2ewithKnown(V v_x_240, V v_k_241, V v_ce_242) {
top: ;
  V v_t_243 = (g_map_2einsert_24s1341440536x470972936(v_x_240, v_k_241, heff_take_field(v_ce_242, 8)));
  return ({ V rv_8 = v_t_243; V rr_ = heff_rec_reuse_nf(v_ce_242, 7935ULL, 13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, 66912255u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
}
V g_heff_2ecompile_2erc_2ewithKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2ewithKnown(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erc_2efreeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2efreeGo_entry, 4, 0};

V g_heff_2ecompile_2erc_2efreeGo(V v_bs_240, V v_seen_241, V v_x3_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_seen_241);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
  }
  case TAG_Cons: {
    V v_v_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x3_246 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_v_244), v_bs_240));
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      V v_x3_247 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_v_244), v_seen_241));
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        V v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_v_244), NTAG(TAG_MkUnit), v_seen_241));
        V t_0 = v_bs_240;
        V t_1 = v_t_248;
        V t_2 = v_vs_245;
        V t_3 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_v_244, v_acc_243});
        v_bs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      }
      case TAG_Just: {
        heff_take_n(v_x3_247, 0ULL, 1);
        heff_drop(v_v_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_seen_241;
        V t_2 = v_vs_245;
        V t_3 = v_acc_243;
        v_bs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_x3_247);
      }
    }
    case TAG_Just: {
      heff_take_n(v_x3_246, 0ULL, 1);
      heff_drop(v_v_244);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_seen_241;
      V t_2 = v_vs_245;
      V t_3 = v_acc_243;
      v_bs_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erc_2efreeGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erc_2efreeGo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erc_2efvTl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2efvTl_entry, 1, 0};

V g_heff_2ecompile_2erc_2efvTl(V v_t_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_240}), NTAG(TAG_Nil)});
  V v_x2_242 = (g_heff_2ecompile_2erc_2efvW(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_241));
  switch (heff_tag_of(v_x2_242)) {
  case TAG_MkPair: {
    V v_bs_243 = heff_field(v_x2_242, 0);
    V v_ms_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_bs_245 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_243));
    V v_ms_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_244));
    V v_t_247 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_245; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_bs_245); r_; });
    return ({ V a_0 = v_t_247; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_ms_246; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erc_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2erc_2efvTl_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2efvTl(a[0]);
}
Clo g_heff_2ecompile_2erc_2efvSts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2efvSts_entry, 1, 0};

V g_heff_2ecompile_2erc_2efvSts(V v_ss_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_240}), NTAG(TAG_Nil)});
  V v_x2_242 = (g_heff_2ecompile_2erc_2efvW(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_241));
  switch (heff_tag_of(v_x2_242)) {
  case TAG_MkPair: {
    V v_bs_243 = heff_field(v_x2_242, 0);
    V v_ms_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_bs_245 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_243));
    V v_ms_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_244));
    V v_t_247 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_245; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_bs_245); r_; });
    return ({ V a_0 = v_t_247; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_ms_246; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erc_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2erc_2efvSts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2efvSts(a[0]);
}
Clo g_heff_2ecompile_2erc_2efvRest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2efvRest_entry, 2, 0};

V g_heff_2ecompile_2erc_2efvRest(V v_ss_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return (g_heff_2ecompile_2erc_2efvSts(v_ss_240));
  }
  case TAG_Just: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Just, TAG_ITl, 1, (V[]){v_t_242}), NTAG(TAG_Nil)});
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_240}), v_t_243});
    V v_x2_245 = (g_heff_2ecompile_2erc_2efvW(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_244));
    switch (heff_tag_of(v_x2_245)) {
    case TAG_MkPair: {
      V v_bs_246 = heff_field(v_x2_245, 0);
      V v_ms_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      V v_bs_248 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_246));
      V v_ms_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_247));
      V v_t_2410 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_248; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_bs_248); r_; });
      return ({ V a_0 = v_t_2410; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_ms_249; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erc_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); r_; });
    }
    default: return heff_nomatch(v_x2_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erc_2efvRest_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2efvRest(a[0], a[1]);
}
Clo g_heff_2ecompile_2erc_2eelemI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eelemI_entry, 2, 0};

V g_heff_2ecompile_2erc_2eelemI(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_j_242 = heff_field(v_x2_241, 0);
    V v_js_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(v_i_240), heff_dup(v_j_242))) {
      heff_drop(v_i_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_i_240;
      V t_1 = v_js_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erc_2eelemI_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erc_2eelemI(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2erc_2ereusePrim_str0, 6, "$reuse");

static V g_heff_2ecompile_2erc_2ereusePrim_val;
static HEFF_ONCE g_heff_2ecompile_2erc_2ereusePrim_st;
static V g_heff_2ecompile_2erc_2ereusePrim_init(void) {
  return ((V)&g_heff_2ecompile_2erc_2ereusePrim_str0);
}
V g_heff_2ecompile_2erc_2ereusePrim_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erc_2ereusePrim_st)) return g_heff_2ecompile_2erc_2ereusePrim_val;
  return heff_global(&g_heff_2ecompile_2erc_2ereusePrim_val, &g_heff_2ecompile_2erc_2ereusePrim_st, g_heff_2ecompile_2erc_2ereusePrim_init);
}
Clo g_heff_2ecompile_2erc_2esameS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2esameS_entry, 2, 0};

V g_heff_2ecompile_2erc_2esameS(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c(heff_dup(v_x_244), heff_dup(v_y_246))) {
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erc_2esameS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erc_2esameS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erc_2echangedOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2erc_2echangedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2echangedOf_entry, 3, 0};

V g_heff_2ecompile_2erc_2echangedOf(V v_ls_240, V v_x_241, V v_fs_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_fs_242));
  V v_t_244 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_243, MK_INT(1LL))));
  V v_t_245 = (g_list_2ezipWith_24s1876717925x1404326288(v_fs_242, v_t_244));
  V v_t_2413 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2echangedOf_lam0, 1, 2, (V[]){heff_dup(v_ls_240), v_x_241}), v_t_245));
  return (g_list_2emap_24s1490052334x152035327(v_t_2413));
}
V g_heff_2ecompile_2erc_2echangedOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erc_2echangedOf(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2erc_2echangedOf_lam0(V self, V *args) {
  V v_p_246 = args[0];
  V v_ls_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_f_249;
  switch (heff_tag_of(v_p_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_p_246, 0);
    heff_take_n(v_p_246, 1ULL, 2);
    v_f_249 = v_x_247;
    break;
  }
  default: heff_nomatch(v_p_246);
  }
  V v_x2_2410 = ({ V a_0 = v_ls_240; V a_1 = v_f_249; V r_ = (g_heff_2ecompile_2erc_2ekeptFrom(a_0, a_1)); heff_drop(v_ls_240); heff_drop(v_f_249); r_; });
  V v_x1_2412;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nothing: {
    heff_drop(v_x_241);
    v_x1_2412 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    V v_y_2411 = heff_field(v_x2_2410, 0);
    heff_take_n(v_x2_2410, 1ULL, 1);
    v_x1_2412 = heff_strEq(v_x_241, v_y_2411);
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2412) == NTAG(TAG_True)));
  heff_drop(v_x1_2412);
  return v_ret_24bool;
}
Clo g_heff_2ecompile_2erc_2etyAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2etyAt_entry, 2, 0};

V g_heff_2ecompile_2erc_2etyAt(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_FtOther);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_ts_243 = heff_field(v_x2_241, 1);
    if (heff_intLe_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      return heff_dup(v_t_242);
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_ts_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erc_2etyAt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erc_2etyAt(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erc_2eapplyLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eapplyLast_entry, 3, 0};

V g_heff_2ecompile_2erc_2eapplyLast(V v_ce_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_ce_240, 13);
    heff_drop(v_n_241);
    V v_t_243 = heff_tag_n(TAG_CReturn, 1, (V[]){NTAG(TAG_RAbandon)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2412;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_n_241))) {
      if (heff_intLe_c(heff_dup(v_n_241), heff_dup(heff_rfield(v_ce_240, 3)))) {
        heff_drop_rec(v_ce_240, 13);
        heff_drop(v_n_241);
        v_t_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_CInPlace, 2, (V[]){v_f_244, v_vs_245});
      } else {
        if (heff_intLt_c(MK_INT(0LL), heff_get_n(v_ce_240, 3, 13))) {
          if (heff_intLe_c(v_n_241, heff_dup(g_heff_2ecompile_2erc_2eroomFor_get()))) {
            v_t_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_CRoomed, 2, (V[]){v_f_244, v_vs_245});
          } else {
            v_t_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_CTail, 2, (V[]){v_f_244, v_vs_245});
          }
        } else {
          heff_drop(v_n_241);
          v_t_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_CTail, 2, (V[]){v_f_244, v_vs_245});
        }
      }
    } else {
      if (heff_intLt_c(MK_INT(0LL), heff_get_n(v_ce_240, 3, 13))) {
        if (heff_intLe_c(v_n_241, heff_dup(g_heff_2ecompile_2erc_2eroomFor_get()))) {
          v_t_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_CRoomed, 2, (V[]){v_f_244, v_vs_245});
        } else {
          v_t_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_CTail, 2, (V[]){v_f_244, v_vs_245});
        }
      } else {
        heff_drop(v_n_241);
        v_t_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_CTail, 2, (V[]){v_f_244, v_vs_245});
      }
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erc_2eapplyLast_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2eapplyLast(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erc_2eboolDone_lam0(V self, V *args);
Clo g_heff_2ecompile_2erc_2eboolDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eboolDone_entry, 2, 0};

V g_heff_2ecompile_2erc_2eboolDone(V v_ce_240, V v_o_241) {
top: ;
  switch (heff_tag_of(v_o_241)) {
  case TAG_OSimple: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_Nil);
  }
  case TAG_OCall: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_Nil);
  }
  case TAG_OApply: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_Nil);
  }
  case TAG_OPrim: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_Nil);
  }
  case TAG_OAbandon: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_Nil);
  }
  case TAG_OBool: {
    V v_xs_2412 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2eboolDone_lam0, 1, 1, (V[]){heff_dup(v_ce_240)}), heff_dup(heff_rfield(v_ce_240, 4))));
    V v_t_2413 = (g_heff_2ecompile_2erc_2edropsOf(v_ce_240, v_xs_2412));
    return (g_list_2emap_24s1796125103x644876049(v_t_2413));
  }
  default: return heff_nomatch(v_o_241);
  }
}
V g_heff_2ecompile_2erc_2eboolDone_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erc_2eboolDone(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erc_2eboolDone_lam0(V self, V *args) {
  V v_v_2410 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2411 = ({ V a_0 = v_v_2410; V b_1 = heff_get_n(v_ce_240, 5, 13); V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2411) == NTAG(TAG_True)));
  heff_drop(v_x1_2411);
  return v_ret_24bool;
}
Clo g_heff_2ecompile_2erc_2eothersW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eothersW_entry, 3, 0};

V g_heff_2ecompile_2erc_2eothersW(V v_x_240, V v_l_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    heff_drop(v_l_241);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_IVal: {
      V v_x311_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_245)) {
      case TAG_SVar: {
        V v_y_246 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        if (heff_strEq_c(heff_dup(v_x_240), v_y_246)) {
          heff_drop(v_x_240);
          heff_drop(v_l_241);
          heff_drop(v_rest_244);
          return NTAG(TAG_False);
        } else {
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_rest_244;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      }
      case TAG_SGlobal: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SInt: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SStr: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SBytes: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFixed: {
        heff_take_n(v_x311_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat32: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SLam: {
        V v_x3112_2418 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        switch (heff_tag_of(v_x3112_2418)) {
        case TAG_MkBlock: {
          V v_t_2419 = heff_field(v_x3112_2418, 0);
          heff_take_n(v_x3112_2418, 1ULL, 1);
          V v_t_2420 = ({ V a_0 = v_t_2419; V a_1 = NTAG(TAG_Nil); V r_ = heff_tr(g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174(a_0, a_1)); heff_drop(v_t_2419); r_; });
          V v_t_2421 = ({ V a_0 = heff_dup(v_x_240); V a_1 = v_t_2420; V r_ = (g_heff_2ecompile_2eimp_2etimesIn(a_0, a_1)); heff_drop(v_t_2420); r_; });
          if (heff_intEq_c(v_t_2421, MK_INT(0LL))) {
            V t_0 = v_x_240;
            V t_1 = v_l_241;
            V t_2 = v_rest_244;
            v_x_240 = t_0;
            v_l_241 = t_1;
            v_x3_242 = t_2;
            goto top;
          } else {
            heff_drop(v_x_240);
            heff_drop(v_l_241);
            heff_drop(v_rest_244);
            return NTAG(TAG_False);
          }
        }
        default: return heff_nomatch(v_x3112_2418);
        }
      }
      case TAG_STag: {
        V v_as_2424 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2424));
        V v_t_2426 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2425));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2426;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SRec: {
        V v_fs_2427 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2429 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2427));
        V v_t_2430 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2429));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2430;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SProj: {
        V v_e_2431 = heff_field(v_x311_245, 0);
        V v_l2_2432 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 3ULL, 4);
        V v_t_2457;
        switch (heff_tag_of(v_e_2431)) {
        case TAG_SVar: {
          V v_y_2435 = heff_dup(heff_field(v_e_2431, 0));
          v_t_2457 = heff_strEq(heff_dup(v_x_240), v_y_2435);
          break;
        }
        case TAG_SGlobal: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SInt: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SFloat: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SStr: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SBytes: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SFixed: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SFloat32: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SPrimFn: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SLam: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_STag: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SRec: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SProj: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_SPrim: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_e_2431);
        }
        if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          heff_drop(v_e_2431);
          heff_drop(v_t_2457);
          if (heff_strEq_c(heff_dup(v_l_241), v_l2_2432)) {
            heff_drop(v_x_240);
            heff_drop(v_l_241);
            heff_drop(v_rest_244);
            return NTAG(TAG_False);
          } else {
            V t_0 = v_x_240;
            V t_1 = v_l_241;
            V t_2 = v_rest_244;
            v_x_240 = t_0;
            v_l_241 = t_1;
            v_x3_242 = t_2;
            goto top;
          }
        } else {
          heff_drop(v_l2_2432);
          heff_drop(v_t_2457);
          V v_t_2459 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_e_2431}), v_rest_244});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_2459;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      }
      case TAG_SPrim: {
        V v_as_2461 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2462 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2461));
        V v_t_2463 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2462));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2463;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_245);
      }
    }
    case TAG_IOp: {
      V v_x311_2464 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_2464)) {
      case TAG_OSimple: {
        V v_v_2465 = heff_field(v_x311_2464, 0);
        heff_take_n(v_x311_2464, 1ULL, 1);
        V v_t_2466 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_2465}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2466;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OCall: {
        V v_as_2468 = heff_field(v_x311_2464, 1);
        heff_take_n(v_x311_2464, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2469 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2468));
        V v_t_2470 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2469));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2470;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OApply: {
        V v_f_2471 = heff_field(v_x311_2464, 0);
        V v_as_2472 = heff_field(v_x311_2464, 1);
        heff_take_n(v_x311_2464, 3ULL, 2);
        V v_t_2473 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2471, v_as_2472})));
        V v_t_2474 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2473));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2474;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OPrim: {
        V v_as_2476 = heff_field(v_x311_2464, 1);
        heff_take_n(v_x311_2464, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2477 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2476));
        V v_t_2478 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2477));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2478;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OAbandon: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OBool: {
        V v_c_2479 = heff_field(v_x311_2464, 0);
        heff_take_n(v_x311_2464, 1ULL, 1);
        V v_t_2480 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2479}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2480;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_2464);
      }
    }
    case TAG_ICond: {
      V v_x311_2481 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ICond = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_2481)) {
      case TAG_PTrue: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PFalse: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PRel: {
        V v_a_2483 = heff_field(v_x311_2481, 1);
        V v_b_2484 = heff_field(v_x311_2481, 2);
        heff_take_n(v_x311_2481, 6ULL, 3);
        V v_t_2485 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_b_2484}), v_rest_244});
        V v_t_2486 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_IVal, 1, (V[]){v_a_2483}), v_t_2485});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2486;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PBool: {
        V v_v_2487 = heff_field(v_x311_2481, 0);
        heff_take_n(v_x311_2481, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2488 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_2487}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2488;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PNot: {
        V v_c_2489 = heff_field(v_x311_2481, 0);
        heff_take_n(v_x311_2481, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2490 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2489}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2490;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PIf: {
        V v_a_2491 = heff_field(v_x311_2481, 0);
        V v_b_2492 = heff_field(v_x311_2481, 1);
        V v_c_2493 = heff_field(v_x311_2481, 2);
        heff_take_n(v_x311_2481, 7ULL, 3);
        V v_t_2494 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2493}), v_rest_244});
        V v_t_2495 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_ICond, 1, (V[]){v_b_2492}), v_t_2494});
        V v_t_2496 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_a_2491}), v_t_2495});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_2496;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PLet: {
        V v_o_2498 = heff_field(v_x311_2481, 1);
        V v_c_2499 = heff_field(v_x311_2481, 2);
        heff_take_n(v_x311_2481, 6ULL, 3);
        V v_t_24100 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2499}), v_rest_244});
        V v_t_24101 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_IOp, 1, (V[]){v_o_2498}), v_t_24100});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24101;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_2481);
      }
    }
    case TAG_ISts: {
      V v_x311_24102 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ISts = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24102)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ISts, 1);
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_Cons: {
        V v_x3111_24103 = heff_field(v_x311_24102, 0);
        V v_ss_24104 = heff_field(v_x311_24102, 1);
        V v_ru_24x311_24102_24Cons = heff_take_reuse_n(v_x311_24102, 3ULL, 2);
        switch (heff_tag_of(v_x3111_24103)) {
        case TAG_SLet: {
          V v_o_24106 = heff_field(v_x3111_24103, 1);
          heff_take_n(v_x3111_24103, 2ULL, 2);
          V v_t_24107 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24104}), v_rest_244});
          V v_t_24108 = heff_tag_at_n(v_ru_24x311_24102_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_IOp, 1, (V[]){v_o_24106}), v_t_24107});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24108;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SDecl: {
          heff_take_n(v_x3111_24103, 0ULL, 1);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          heff_drop_cell(v_ru_24x311_24102_24Cons, 2);
          V v_t_24110 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24104}), v_rest_244});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24110;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SSet: {
          V v_o_24112 = heff_field(v_x3111_24103, 1);
          heff_take_n(v_x3111_24103, 2ULL, 2);
          V v_t_24113 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24104}), v_rest_244});
          V v_t_24114 = heff_tag_at_n(v_ru_24x311_24102_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_IOp, 1, (V[]){v_o_24112}), v_t_24113});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24114;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SIf: {
          V v_c_24115 = heff_field(v_x3111_24103, 0);
          V v_ts_24116 = heff_field(v_x3111_24103, 1);
          V v_fs_24117 = heff_field(v_x3111_24103, 2);
          heff_take_n(v_x3111_24103, 7ULL, 3);
          V v_t_24118 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24104}), v_rest_244});
          V v_t_24119 = heff_tag_at_n(v_ru_24x311_24102_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_fs_24117}), v_t_24118});
          V v_t_24120 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ts_24116}), v_t_24119});
          V v_t_24121 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24115}), v_t_24120});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24121;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SCase: {
          V v_v_24122 = heff_field(v_x3111_24103, 0);
          V v_arms_24123 = heff_field(v_x3111_24103, 1);
          heff_take_n(v_x3111_24103, 3ULL, 2);
          V v_t_24124 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24104}), v_rest_244});
          V v_t_24125 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24123));
          V v_t_24126 = (g_list_2efoldl_24s1104809983x118204267(v_t_24124, v_t_24125));
          V v_t_24127 = heff_tag_at_n(v_ru_24x311_24102_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_IVal, 1, (V[]){v_v_24122}), v_t_24126});
          V t_0 = v_x_240;
          V t_1 = v_l_241;
          V t_2 = v_t_24127;
          v_x_240 = t_0;
          v_l_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_x3111_24103);
        }
      }
      default: return heff_nomatch(v_x311_24102);
      }
    }
    case TAG_ITl: {
      V v_x311_24128 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ITl = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24128)) {
      case TAG_TSeq: {
        V v_ss_24129 = heff_field(v_x311_24128, 0);
        V v_t_24130 = heff_field(v_x311_24128, 1);
        V v_ru_24x311_24128_24TSeq = heff_take_reuse_n(v_x311_24128, 3ULL, 2);
        V v_t_24131 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_24130}), v_rest_244});
        V v_t_24132 = heff_tag_at_n(v_ru_24x311_24128_24TSeq, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ITl, TAG_ISts, 1, (V[]){v_ss_24129}), v_t_24131});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24132;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TReturn: {
        V v_o_24133 = heff_field(v_x311_24128, 0);
        heff_take_n(v_x311_24128, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24134 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_24133}), v_rest_244});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24134;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TLoop: {
        V v_vs_24135 = heff_field(v_x311_24128, 0);
        heff_take_n(v_x311_24128, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24136 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_24135));
        V v_t_24137 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_24136));
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24137;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TIf: {
        V v_c_24138 = heff_field(v_x311_24128, 0);
        V v_t_24139 = heff_field(v_x311_24128, 1);
        V v_e_24140 = heff_field(v_x311_24128, 2);
        heff_take_n(v_x311_24128, 7ULL, 3);
        V v_t_24141 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_e_24140}), v_rest_244});
        V v_t_24142 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ITl, TAG_ITl, 1, (V[]){v_t_24139}), v_t_24141});
        V v_t_24143 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24138}), v_t_24142});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24143;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TCase: {
        V v_v_24144 = heff_field(v_x311_24128, 0);
        V v_arms_24145 = heff_field(v_x311_24128, 1);
        heff_take_n(v_x311_24128, 3ULL, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24146 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24145));
        V v_t_24147 = (g_list_2efoldl_24s421921225x565177679(v_rest_244, v_t_24146));
        V v_t_24148 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_24144}), v_t_24147});
        V t_0 = v_x_240;
        V t_1 = v_l_241;
        V t_2 = v_t_24148;
        v_x_240 = t_0;
        v_l_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_24128);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erc_2eothersW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2eothersW(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erc_2etakeVar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2etakeVar_entry, 5, 0};

V g_heff_2ecompile_2erc_2etakeVar(V v_ce_240, V v_rest_241, V v_x3_242, V v_l_243, V v_sh_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ce_240, 13);
    heff_drop(v_rest_241);
    heff_drop(v_l_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_x1_248;
    switch (heff_tag_of(v_sh_244)) {
    case TAG_Nil: {
      v_x1_248 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      v_x1_248 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_sh_244);
    }
    if ((heff_dup(v_x1_248) == NTAG(TAG_True))) {
      heff_drop_rec(v_ce_240, 13);
      heff_drop(v_rest_241);
      heff_drop(v_l_243);
      heff_drop(v_x1_248);
      return NTAG(TAG_Nil);
    } else {
      heff_drop(v_x1_248);
      V v_t_249 = (g_heff_2ecompile_2erc_2eelemS(heff_dup(v_x_245), heff_rfield(v_ce_240, 4)));
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_t_249);
        V v_x1_2410 = (g_heff_2ecompile_2erc_2eelemS(heff_dup(v_x_245), heff_rfield(v_ce_240, 6)));
        if ((heff_dup(v_x1_2410) == NTAG(TAG_True))) {
          heff_drop_rec(v_ce_240, 13);
          heff_drop(v_rest_241);
          heff_drop(v_l_243);
          heff_drop(v_x1_2410);
          return NTAG(TAG_Nil);
        } else {
          heff_drop(v_x1_2410);
          V v_x1_2411 = ({ V a_0 = heff_dup(v_x_245); V b_1 = heff_get_n(v_ce_240, 5, 13); V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
          if ((heff_dup(v_x1_2411) == NTAG(TAG_True))) {
            heff_drop(v_rest_241);
            heff_drop(v_l_243);
            heff_drop(v_x1_2411);
            return NTAG(TAG_Nil);
          } else {
            heff_drop(v_x1_2411);
            V v_t_2412 = (g_heff_2ecompile_2erc_2eothersW(heff_dup(v_x_245), heff_dup(v_l_243), v_rest_241));
            if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
              heff_drop(v_t_2412);
              return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_245), v_l_243}), NTAG(TAG_Nil)});
            } else {
              heff_drop(v_l_243);
              heff_drop(v_t_2412);
              return NTAG(TAG_Nil);
            }
          }
        }
      } else {
        heff_drop_rec(v_ce_240, 13);
        heff_drop(v_rest_241);
        heff_drop(v_l_243);
        heff_drop(v_t_249);
        return NTAG(TAG_Nil);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erc_2etakeVar_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a4 = a[4]; V r = g_heff_2ecompile_2erc_2etakeVar(a[0], a[1], a2, a[3], a4); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_heff_2ecompile_2erc_2ecallAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ecallAs_entry, 5, 0};

V g_heff_2ecompile_2erc_2ecallAs(V v_ce_240, V v_g_241, V v_as_242, V v_loop_243, V v_ls_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_ce_240, 2));
  V v_t_2411;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    v_t_2411 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    V v_s_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_s_246, 0)), heff_dup(v_g_241))) {
      V v_t_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_s_246, 1, 2); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_242));
      if (heff_intEq_c(v_t_248, v_t_249)) {
        v_t_2411 = (g_list_2eall_24s1359914687x262073401(v_loop_243));
      } else {
        v_t_2411 = NTAG(TAG_False);
      }
    } else {
      heff_drop_rec(v_s_246, 2);
      v_t_2411 = NTAG(TAG_False);
    }
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop(v_g_241);
    heff_drop(v_ls_244);
    heff_drop(v_t_2411);
    V v_vs_2412 = (g_list_2emap_24s1661823642x1450093706(v_loop_243));
    V v_t_2413 = heff_get_n(v_ce_240, 2, 13);
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nothing: {
      heff_drop(v_vs_2412);
      return NTAG(TAG_Nil);
    }
    case TAG_Just: {
      V v_s_2414 = heff_field(v_t_2413, 0);
      heff_take_n(v_t_2413, 1ULL, 1);
      V v_t_2415 = heff_tag_n(TAG_CLoop, 2, (V[]){heff_get_n(v_s_2414, 1, 2), v_vs_2412});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_t_2413);
    }
  } else {
    heff_drop(v_loop_243);
    heff_drop(v_t_2411);
    V v_t_2416 = (g_heff_2ecompile_2erc_2eagrees(heff_dup(v_ce_240), heff_dup(v_g_241), v_as_242));
    V v_t_2417;
    if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
      heff_drop(v_t_2416);
      v_t_2417 = (g_list_2eall_24s1359914687x262073401(v_ls_244));
    } else {
      heff_drop(v_t_2416);
      v_t_2417 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
      heff_drop(v_t_2417);
      V v_x3_2418 = ({ V a_0 = heff_dup(v_g_241); V b_1 = heff_get_n(v_ce_240, 11, 13); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      V v_x1_2420;
      switch (heff_tag_of(v_x3_2418)) {
      case TAG_Nothing: {
        v_x1_2420 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2419 = heff_field(v_x3_2418, 0);
        V v_ru_24x3_2418_24Just = heff_take_reuse_n(v_x3_2418, 1ULL, 1);
        v_x1_2420 = heff_tag_at_n(v_ru_24x3_2418_24Just, TAG_Just, 1, (V[]){heff_get_n(v_x_2419, 1, 2)});
        break;
      }
      default: heff_nomatch(v_x3_2418);
      }
      V v_t_2422;
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_Nothing: {
        v_t_2422 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_x1_2420, 0ULL, 1);
        v_t_2422 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x1_2420);
      }
      V v_t_2423 = (g_list_2emap_24s1661823642x1450093706(v_ls_244));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CJump, 3, (V[]){v_g_241, v_t_2422, v_t_2423}), NTAG(TAG_Nil)});
    } else {
      heff_drop(v_t_2417);
      V v_x1_2424 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_241), heff_rfield(v_ce_240, 11)));
      V v_t_2426;
      switch (heff_tag_of(v_x1_2424)) {
      case TAG_Nothing: {
        v_t_2426 = NTAG(TAG_RepV);
        break;
      }
      case TAG_Just: {
        V v_s_2425 = heff_field(v_x1_2424, 0);
        heff_take_n(v_x1_2424, 1ULL, 1);
        v_t_2426 = heff_get_n(v_s_2425, 1, 2);
        break;
      }
      default: heff_nomatch(v_x1_2424);
      }
      V v_x3_2427 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_241), heff_rfield(v_ce_240, 11)));
      V v_t_2429;
      switch (heff_tag_of(v_x3_2427)) {
      case TAG_Nothing: {
        v_t_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2428 = heff_field(v_x3_2427, 0);
        V v_ru_24x3_2427_24Just = heff_take_reuse_n(v_x3_2427, 1ULL, 1);
        v_t_2429 = heff_tag_at_n(v_ru_24x3_2427_24Just, TAG_Just, 1, (V[]){heff_get_n(v_x_2428, 1, 2)});
        break;
      }
      default: heff_nomatch(v_x3_2427);
      }
      V v_t_2430 = heff_tag_n(TAG_RCall, 4, (V[]){v_g_241, NTAG(TAG_False), v_t_2429, v_ls_244});
      V v_t_2431 = (g_heff_2ecompile_2erc_2ecoerce(v_t_2426, heff_get_n(v_ce_240, 12, 13), v_t_2430));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CReturn, 1, (V[]){v_t_2431}), NTAG(TAG_Nil)});
    }
  }
}
V g_heff_2ecompile_2erc_2ecallAs_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erc_2ecallAs(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2erc_2ewrapperOf_str0, 4, "box$");
HEFF_LIT(g_heff_2ecompile_2erc_2ewrapperOf_str1, 4, "box$");
HEFF_LIT(g_heff_2ecompile_2erc_2ewrapperOf_str2, 4, "box$");
HEFF_LIT(g_heff_2ecompile_2erc_2ewrapperOf_str3, 4, "box$");
V g_heff_2ecompile_2erc_2ewrapperOf_lam0(V self, V *args);
V g_heff_2ecompile_2erc_2ewrapperOf_lam1(V self, V *args);
V g_heff_2ecompile_2erc_2ewrapperOf_lam2(V self, V *args);
Clo g_heff_2ecompile_2erc_2ewrapperOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ewrapperOf_entry, 5, 0};

V g_heff_2ecompile_2erc_2ewrapperOf(V v_ce_240, V v_key_241, V v_bi_242, V v_sg_243, V v_xs_244) {
top: ;
  V v_t_2410 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2erc_2ewrapperOf_lam0, 2, 1, (V[]){heff_dup(v_ce_240)}), heff_dup(heff_rfield(v_sg_243, 0)), heff_dup(v_xs_244)));
  V v_t_2411 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(heff_rfield(v_sg_243, 0)), heff_dup(v_xs_244)));
  V v_t_2412 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_244));
  V v_t_2413 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2412, MK_INT(1LL))));
  V v_t_2423 = (g_list_2efoldl_24f1686830387x1555365313(NTAG(TAG_Nil), heff_clo_n(g_heff_2ecompile_2erc_2ewrapperOf_lam1, 2, 1, (V[]){heff_dup(v_bi_242)}), v_t_2411, v_t_2413));
  V v_t_2424 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2423; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2423); r_; });
  V v_from_2425 = heff_dup(heff_rfield(v_sg_243, 1));
  V v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_take_field(v_sg_243, 1)});
  V v_t_2433 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2erc_2ewrapperOf_lam2, 2, 1, (V[]){v_ce_240}), heff_get_n(v_sg_243, 0, 2), v_xs_244));
  V v_v_2434 = heff_tag_n(TAG_RCall, 4, (V[]){v_key_241, NTAG(TAG_False), v_t_2426, v_t_2433});
  V v_t_2436;
  switch (heff_tag_of(v_from_2425)) {
  case TAG_RepV: {
    v_t_2436 = v_v_2434;
    break;
  }
  case TAG_RepFix: {
    v_t_2436 = heff_tag_n(TAG_RBox, 2, (V[]){v_from_2425, v_v_2434});
    break;
  }
  case TAG_RepF64: {
    v_t_2436 = heff_tag_n(TAG_RBox, 2, (V[]){v_from_2425, v_v_2434});
    break;
  }
  default: heff_nomatch(v_from_2425);
  }
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CReturn, 1, (V[]){v_t_2436}), NTAG(TAG_Nil)});
  V v_t_2438 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2437));
  return heff_tag_n(TAG_MkWrapper, 2, (V[]){v_t_2410, v_t_2438});
}
V g_heff_2ecompile_2erc_2ewrapperOf_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erc_2ewrapperOf(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erc_2ewrapperOf_lam0(V self, V *args) {
  V v_rp_245 = args[0];
  V v_x_246 = args[1];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_rp_245)) {
  case TAG_RepV: {
    V v_x3_247 = ({ V a_0 = heff_dup(v_x_246); V b_1 = heff_get_n(v_ce_240, 10, 13); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_247)) {
    case TAG_Nothing: {
      return v_x_246;
    }
    case TAG_Just: {
      heff_take_n(v_x3_247, 0ULL, 1);
      return heff_strAppend(((V)&g_heff_2ecompile_2erc_2ewrapperOf_str0), v_x_246);
    }
    default: return heff_nomatch(v_x3_247);
    }
  }
  case TAG_RepFix: {
    heff_take_n(v_rp_245, 0ULL, 1);
    heff_drop_rec(v_ce_240, 13);
    return heff_strAppend(((V)&g_heff_2ecompile_2erc_2ewrapperOf_str1), v_x_246);
  }
  case TAG_RepF64: {
    heff_drop_rec(v_ce_240, 13);
    return heff_strAppend(((V)&g_heff_2ecompile_2erc_2ewrapperOf_str2), v_x_246);
  }
  default: return heff_nomatch(v_rp_245);
  }
}
V g_heff_2ecompile_2erc_2ewrapperOf_lam1(V self, V *args) {
  V v_p_2414 = args[0];
  V v_i_2415 = args[1];
  V v_bi_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = ({ V a_0 = v_i_2415; V a_1 = v_bi_242; V r_ = (g_heff_2ecompile_2erc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
  V v_t_2419;
  switch (heff_tag_of(v_p_2414)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_dup(heff_field(v_p_2414, 0));
    v_t_2419 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_p_2414);
  }
  V v_t_2422;
  switch (heff_tag_of(v_p_2414)) {
  case TAG_MkPair: {
    V v_y_2421 = heff_field(v_p_2414, 1);
    heff_take_n(v_p_2414, 2ULL, 2);
    v_t_2422 = v_y_2421;
    break;
  }
  default: heff_nomatch(v_p_2414);
  }
  return ({ V a_0 = v_t_2416; V a_1 = v_t_2419; V a_2 = v_t_2422; V r_ = (g_heff_2ecompile_2erc_2ewrapUnbox(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
}
V g_heff_2ecompile_2erc_2ewrapperOf_lam2(V self, V *args) {
  V v_rp_2427 = args[0];
  V v_x_2428 = args[1];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_rp_2427)) {
  case TAG_RepV: {
    V v_x3_2429 = ({ V a_0 = heff_dup(v_x_2428); V b_1 = heff_get_n(v_ce_240, 10, 13); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2431;
    switch (heff_tag_of(v_x3_2429)) {
    case TAG_Nothing: {
      v_t_2431 = v_x_2428;
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_2429, 0ULL, 1);
      v_t_2431 = heff_strAppend(((V)&g_heff_2ecompile_2erc_2ewrapperOf_str3), v_x_2428);
      break;
    }
    default: heff_nomatch(v_x3_2429);
    }
    return heff_tag_n(TAG_Given, 1, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_t_2431})});
  }
  case TAG_RepFix: {
    heff_drop_rec(v_ce_240, 13);
    return heff_tag_n(TAG_GivenU, 2, (V[]){v_rp_2427, heff_tag_n(TAG_RLocal, 1, (V[]){v_x_2428})});
  }
  case TAG_RepF64: {
    heff_drop_rec(v_ce_240, 13);
    return heff_tag_n(TAG_GivenU, 2, (V[]){v_rp_2427, heff_tag_n(TAG_RLocal, 1, (V[]){v_x_2428})});
  }
  default: return heff_nomatch(v_rp_2427);
  }
}
Clo g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_24dps_entry, 4, 0};

V g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_24dps(V v_ce_240, V v_live_241, V v_x4_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_242, 0);
    V v_es_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_245)));
    V v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s1790904629x1122008408(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_live_248 = (g_prelude_2e_2b_2b(v_t_247, heff_dup(v_live_241)));
    V v_t_249 = (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(heff_dup(v_ce_240), v_live_248, NTAG(TAG_RepV), v_e_244));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_ce_240;
    V t_1 = v_live_241;
    V t_2 = v_es_245;
    V t_3 = v_cell_2410;
    v_ce_240 = t_0;
    v_live_241 = t_1;
    v_x4_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_24dps_entry, 5, 0};

V g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_24dps(V v_ce_240, V v_live_241, V v_x4_242, V v_x5_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    heff_drop(v_x5_243);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_rp_245 = heff_field(v_x4_242, 0);
    V v_rps_246 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x5_243)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_rp_245);
      heff_drop(v_rps_246);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_e_247 = heff_field(v_x5_243, 0);
      V v_es_248 = heff_field(v_x5_243, 1);
      heff_take_n(v_x5_243, 3ULL, 2);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_248)));
      V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s1790904629x1122008408(a_0, a_1)); heff_drop(v_t_249); r_; });
      V v_live_2411 = (g_prelude_2e_2b_2b(v_t_2410, heff_dup(v_live_241)));
      V v_t_2412 = (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(heff_dup(v_ce_240), v_live_2411, v_rp_245, v_e_247));
      V v_cell_2413 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
      V v_u_2414 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2413));
      heff_drop(v_u_2414);
      V t_0 = v_ce_240;
      V t_1 = v_live_241;
      V t_2 = v_rps_246;
      V t_3 = v_es_248;
      V t_4 = v_cell_2413;
      v_ce_240 = t_0;
      v_live_241 = t_1;
      v_x4_242 = t_2;
      v_x5_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_x5_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2erc_2erelTest_24s79554594x384851698_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2erelTest_24s79554594x384851698_entry, 4, 0};

V g_heff_2ecompile_2erc_2erelTest_24s79554594x384851698(V v_ce_240, V v_live_241, V v_p_242, V v_args_243) {
top: ;
  V v_x2_244 = (g_heff_2eelab_2efixed_2efixedPrimOf(heff_dup(v_p_242)));
  V v_x6_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    v_x6_247 = (g_heff_2ecompile_2erepr_2efloatShape(heff_dup(v_p_242)));
    break;
  }
  case TAG_Just: {
    V v_fp_245 = heff_field(v_x2_244, 0);
    V v_ru_24x2_244_24Just = heff_take_reuse_n(v_x2_244, 1ULL, 1);
    V v_t_246 = heff_tag_at_n(v_ru_24x2_244_24Just, TAG_RepFix, 1, (V[]){heff_dup(heff_rfield(v_fp_245, 0))});
    v_x6_247 = ({ V a_0 = v_t_246; V b_1 = heff_get_n(v_fp_245, 1, 2); V r_ = (g_heff_2ecompile_2erepr_2eopShape(a_0, b_1)); heff_drop(b_1); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  switch (heff_tag_of(v_x6_247)) {
  case TAG_Nothing: {
    V v_t_248 = (g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551(v_ce_240, v_live_241, v_args_243));
    return heff_tag_n(TAG_CondRel, 2, (V[]){v_p_242, v_t_248});
  }
  case TAG_Just: {
    V v_sh_249 = heff_field(v_x6_247, 0);
    heff_take_n(v_x6_247, 1ULL, 1);
    V v_t_2410 = (g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829(v_ce_240, v_live_241, heff_get_n(v_sh_249, 0, 2), v_args_243));
    return heff_tag_n(TAG_CondRelU, 2, (V[]){v_p_242, v_t_2410});
  }
  default: return heff_nomatch(v_x6_247);
  }
}
V g_heff_2ecompile_2erc_2erelTest_24s79554594x384851698_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2erelTest_24s79554594x384851698(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_lam0(V self, V *args);
Clo g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_entry, 2, 0};

V g_heff_2ecompile_2erc_2econdF_24s874044303x263379189(V v_ce_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_PTrue: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_CondTrue);
  }
  case TAG_PFalse: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_CondFalse);
  }
  case TAG_PRel: {
    V v_p_242 = heff_field(v_x3_241, 0);
    V v_a_243 = heff_field(v_x3_241, 1);
    V v_b_244 = heff_field(v_x3_241, 2);
    heff_take_n(v_x3_241, 7ULL, 3);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_244, NTAG(TAG_Nil)});
    return (g_heff_2ecompile_2erc_2erelTest_24s79554594x384851698(v_ce_240, NTAG(TAG_Nil), v_p_242, heff_tag_n(TAG_Cons, 2, (V[]){v_a_243, v_t_245})));
  }
  case TAG_PBool: {
    V v_v_246 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24PBool = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_t_247 = (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_246));
    return heff_tag_at_n(v_ru_24x3_241_24PBool, TAG_CondBool, 1, (V[]){v_t_247});
  }
  case TAG_PNot: {
    V v_c_248 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24PNot = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_cell_249 = heff_tag_at_n(v_ru_24x3_241_24PNot, TAG_CondNot, 1, (V[]){heff_hole()});
    V v_u_2410 = (g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_24dps(v_ce_240, v_c_248, heff_dup(v_cell_249), MK_INT(0LL)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  case TAG_PIf: {
    V v_a_2411 = heff_field(v_x3_241, 0);
    V v_b_2412 = heff_field(v_x3_241, 1);
    V v_c_2413 = heff_field(v_x3_241, 2);
    V v_ru_24x3_241_24PIf = heff_take_reuse_n(v_x3_241, 7ULL, 3);
    V v_t_2414 = (g_heff_2ecompile_2erc_2econdF_24s874044303x263379189(heff_dup(v_ce_240), v_a_2411));
    V v_t_2415 = (g_heff_2ecompile_2erc_2econdF_24s874044303x263379189(heff_dup(v_ce_240), v_b_2412));
    V v_cell_2416 = heff_tag_at_n(v_ru_24x3_241_24PIf, TAG_CondIf, 3, (V[]){v_t_2414, v_t_2415, heff_hole()});
    V v_u_2417 = (g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_24dps(v_ce_240, v_c_2413, heff_dup(v_cell_2416), MK_INT(2LL)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  case TAG_PLet: {
    V v_x_2418 = heff_field(v_x3_241, 0);
    V v_o_2419 = heff_field(v_x3_241, 1);
    V v_c_2420 = heff_field(v_x3_241, 2);
    heff_take_n(v_x3_241, 7ULL, 3);
    V v_x2_2421 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_2418), heff_rfield(v_ce_240, 10)));
    V v_want_2423;
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_Nothing: {
      v_want_2423 = NTAG(TAG_RepV);
      break;
    }
    case TAG_Just: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      heff_take_n(v_x2_2421, 1ULL, 1);
      v_want_2423 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x2_2421);
    }
    V v_t_2424 = (g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500(heff_dup(v_ce_240), NTAG(TAG_Nil), v_want_2423, v_o_2419));
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2418), heff_dup(heff_rfield(v_ce_240, 6))});
    V v_t_2426 = heff_rec_n(13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, (V[]){heff_dup(heff_rfield(v_ce_240, 0)), heff_dup(heff_rfield(v_ce_240, 1)), heff_dup(heff_rfield(v_ce_240, 2)), heff_dup(heff_rfield(v_ce_240, 3)), heff_dup(heff_rfield(v_ce_240, 4)), heff_dup(heff_rfield(v_ce_240, 5)), v_t_2425, heff_dup(heff_rfield(v_ce_240, 7)), heff_dup(heff_rfield(v_ce_240, 8)), heff_dup(heff_rfield(v_ce_240, 9)), heff_dup(heff_rfield(v_ce_240, 10)), heff_dup(heff_rfield(v_ce_240, 11)), heff_dup(heff_rfield(v_ce_240, 12))});
    V v_t_2427 = (g_heff_2ecompile_2erc_2econdF_24s874044303x263379189(v_t_2426, v_c_2420));
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2418), NTAG(TAG_Nil)});
    V v_t_2433 = (g_list_2emap_24f1548644028x2098102081(heff_clo_n(g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_lam0, 1, 1, (V[]){v_ce_240}), v_t_2428));
    return heff_tag_n(TAG_CondLet, 4, (V[]){v_x_2418, v_t_2424, v_t_2427, v_t_2433});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2econdF_24s874044303x263379189(a[0], a[1]);
}
V g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_lam0(V self, V *args) {
  V v_x_2429 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2430 = ({ V a_0 = v_x_2429; V b_1 = heff_get_n(v_ce_240, 10, 13); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  V v_x1_2432;
  switch (heff_tag_of(v_x3_2430)) {
  case TAG_Nothing: {
    v_x1_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_2430, 0ULL, 1);
    v_x1_2432 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_2430);
  }
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2432) == NTAG(TAG_True)));
  heff_drop(v_x1_2432);
  return v_ret_24bool;
}
Clo g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500_entry, 4, 0};

V g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500(V v_ce_240, V v_live_241, V v_want_242, V v_o_243) {
top: ;
  switch (heff_tag_of(v_o_243)) {
  case TAG_OSimple: {
    V v_v_244 = heff_field(v_o_243, 0);
    heff_take_n(v_o_243, 1ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, v_live_241, v_want_242, v_v_244);
  }
  case TAG_OCall: {
    V v_g_245 = heff_field(v_o_243, 0);
    V v_as_246 = heff_field(v_o_243, 1);
    V v_ru_24o_243_24OCall = heff_take_reuse_n(v_o_243, 3ULL, 2);
    V v_x1_247 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_245), heff_rfield(v_ce_240, 11)));
    V v_t_249;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nothing: {
      v_t_249 = NTAG(TAG_RepV);
      break;
    }
    case TAG_Just: {
      V v_s_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      v_t_249 = heff_get_n(v_s_248, 1, 2);
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    V v_t_2410 = (g_heff_2ecompile_2erc_2ecompV_24s792489109x351586786(v_ce_240, v_live_241, heff_tag_at_n(v_ru_24o_243_24OCall, TAG_OCall, 2, (V[]){v_g_245, v_as_246})));
    return (g_heff_2ecompile_2erc_2ecoerce(v_t_249, v_want_242, v_t_2410));
  }
  case TAG_OApply: {
    V v_t_2413 = (g_heff_2ecompile_2erc_2ecompV_24s792489109x351586786(v_ce_240, v_live_241, v_o_243));
    return (g_heff_2ecompile_2erc_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2413));
  }
  case TAG_OPrim: {
    V v_t_2416 = (g_heff_2ecompile_2erc_2ecompV_24s792489109x351586786(v_ce_240, v_live_241, v_o_243));
    return (g_heff_2ecompile_2erc_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2416));
  }
  case TAG_OAbandon: {
    V v_t_2417 = (g_heff_2ecompile_2erc_2ecompV_24s792489109x351586786(v_ce_240, v_live_241, v_o_243));
    return (g_heff_2ecompile_2erc_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2417));
  }
  case TAG_OBool: {
    V v_t_2419 = (g_heff_2ecompile_2erc_2ecompV_24s792489109x351586786(v_ce_240, v_live_241, v_o_243));
    return (g_heff_2ecompile_2erc_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2419));
  }
  default: return heff_nomatch(v_o_243);
  }
}
V g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483_lam0(V self, V *args);
V g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483_lam1(V self, V *args);
V g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483_lam2(V self, V *args);
V g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483_lam3(V self, V *args);
Clo g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483_entry, 5, 0};

V g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483(V v_ce_240, V v_c_241, V v_yes_242, V v_no_243, V v_wanted_244) {
top: ;
  V v_xs_247 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483_lam0, 1, 1, (V[]){heff_dup(v_wanted_244)}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_248 = (g_heff_2ecompile_2erc_2edropsOf(heff_dup(v_ce_240), v_xs_247));
  V v_t_249 = (g_list_2emap_24s1796125103x644876049(v_t_248));
  V v_owned_2411 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483_lam1, 1, 1, (V[]){heff_dup(v_wanted_244)}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2412 = heff_rec_n(13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, (V[]){heff_dup(heff_rfield(v_ce_240, 0)), heff_dup(heff_rfield(v_ce_240, 1)), heff_dup(heff_rfield(v_ce_240, 2)), heff_dup(heff_rfield(v_ce_240, 3)), v_owned_2411, heff_dup(v_wanted_244), heff_dup(heff_rfield(v_ce_240, 6)), heff_dup(heff_rfield(v_ce_240, 7)), heff_dup(heff_rfield(v_ce_240, 8)), heff_dup(heff_rfield(v_ce_240, 9)), heff_dup(heff_rfield(v_ce_240, 10)), heff_dup(heff_rfield(v_ce_240, 11)), heff_dup(heff_rfield(v_ce_240, 12))});
  V v_t_2413 = (g_heff_2ecompile_2erc_2elentTo(v_t_2412));
  V v_t_2414 = (g_heff_2ecompile_2erc_2econdF_24s874044303x263379189(v_t_2413, v_c_241));
  V v_owned_2416 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483_lam2, 1, 1, (V[]){heff_dup(v_wanted_244)}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2417 = heff_rec_n(13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, (V[]){heff_dup(heff_rfield(v_ce_240, 0)), heff_dup(heff_rfield(v_ce_240, 1)), heff_dup(heff_rfield(v_ce_240, 2)), heff_dup(heff_rfield(v_ce_240, 3)), v_owned_2416, heff_dup(heff_rfield(v_ce_240, 5)), heff_dup(heff_rfield(v_ce_240, 6)), heff_dup(heff_rfield(v_ce_240, 7)), heff_dup(heff_rfield(v_ce_240, 8)), heff_dup(heff_rfield(v_ce_240, 9)), heff_dup(heff_rfield(v_ce_240, 10)), heff_dup(heff_rfield(v_ce_240, 11)), heff_dup(heff_rfield(v_ce_240, 12))});
  V v_t_2418 = (g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836(v_t_2417, v_yes_242));
  V v_owned_2420 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483_lam3, 1, 1, (V[]){v_wanted_244}), heff_take_field(v_ce_240, 4)));
  V v_t_2421 = ({ V rv_4 = v_owned_2420; V rr_ = heff_rec_reuse_nf(v_ce_240, 8175ULL, 13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, 67108095u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_t_2422 = (g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836(v_t_2421, v_no_243));
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_t_2414, v_t_2418, v_t_2422}), NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(v_t_249, v_t_2423));
}
V g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483(a[0], a[1], a2, a3, a[4]); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483_lam0(V self, V *args) {
  V v_v_245 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_246 = ({ V a_0 = v_v_245; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wanted_244); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_246) == NTAG(TAG_True)));
  heff_drop(v_x1_246);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483_lam1(V self, V *args) {
  V v_v_2410 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2410; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wanted_244); r_; });
}
V g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483_lam2(V self, V *args) {
  V v_v_2415 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2415; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wanted_244); r_; });
}
V g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483_lam3(V self, V *args) {
  V v_v_2419 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2419; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wanted_244); r_; });
}
V g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_lam0(V self, V *args);
V g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_lam1(V self, V *args);
V g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_lam2(V self, V *args);
V g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_lam3(V self, V *args);
V g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_lam4(V self, V *args);
V g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_lam5(V self, V *args);
Clo g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_entry, 8, 0};

V g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583(V v_ce_240, V v_taken_241, V v_lent_242, V v_t_243, V v_vs_244, V v_fb_245, V v_leaves_246, V v_x9_247) {
top: ;
  switch (heff_tag_of(v_x9_247)) {
  case TAG_MkPair: {
    V v_ru_248 = heff_field(v_x9_247, 0);
    V v_b2_249 = heff_field(v_x9_247, 1);
    V v_ru_24x9_247_24MkPair = heff_take_reuse_n(v_x9_247, 3ULL, 2);
    V v_t_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_244));
    V v_t_2411 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2410, MK_INT(1LL))));
    V v_t_2412 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_vs_244), v_t_2411));
    V v_t_2417 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_lam0, 1, 1, (V[]){heff_dup(v_fb_245)}), v_t_2412));
    V v_t_2419;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      v_t_2419 = NTAG(TAG_True);
    } else {
      switch (heff_tag_of(v_taken_241)) {
      case TAG_Nothing: {
        v_t_2419 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        v_t_2419 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_taken_241);
      }
    }
    V v_t_2426;
    switch (heff_tag_of(v_ru_248)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_taken_241)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x9_247_24MkPair, 2);
        v_t_2426 = NTAG(TAG_TakeNone);
        break;
      }
      case TAG_Just: {
        V v_t_2421 = (g_heff_2ecompile_2erc_2efieldMask(v_fb_245, MK_INT(0LL), v_vs_244));
        V v_t_2422 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_244));
        v_t_2426 = heff_tag_at_n(v_ru_24x9_247_24MkPair, TAG_TakeN, 2, (V[]){v_t_2421, v_t_2422});
        break;
      }
      default: heff_nomatch(v_taken_241);
      }
      break;
    }
    case TAG_Just: {
      V v_ru_2423 = heff_dup(heff_field(v_ru_248, 0));
      heff_drop_cell(v_ru_24x9_247_24MkPair, 2);
      V v_t_2424 = (g_heff_2ecompile_2erc_2efieldMask(v_fb_245, MK_INT(0LL), v_vs_244));
      V v_t_2425 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_244));
      v_t_2426 = heff_tag_n(TAG_TakeKeep, 3, (V[]){v_ru_2423, v_t_2424, v_t_2425});
      break;
    }
    default: heff_nomatch(v_ru_248);
    }
    V v_t_2428;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      v_t_2428 = NTAG(TAG_Nil);
    } else {
      v_t_2428 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_lam1, 1, 1, (V[]){heff_dup(v_fb_245)}), heff_dup(v_vs_244)));
    }
    V v_owned_2429 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_240, 4)), v_t_2428));
    V v_wanted_2430 = (g_prelude_2e_2b_2b(heff_dup(v_fb_245), heff_dup(heff_rfield(v_ce_240, 5))));
    V v_t_2433 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_lam2, 1, 1, (V[]){v_wanted_2430}), v_owned_2429));
    V v_xs_2438 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_lam3, 1, 1, (V[]){heff_dup(v_taken_241)}), v_t_2433));
    V v_t_2439 = (g_heff_2ecompile_2erc_2edropsOf(heff_dup(v_ce_240), v_xs_2438));
    V v_t_2440 = (g_list_2emap_24s1796125103x644876049(v_t_2439));
    V v_t_2442;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      v_t_2442 = NTAG(TAG_Nil);
    } else {
      v_t_2442 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_lam4, 1, 1, (V[]){heff_dup(v_fb_245)}), heff_dup(v_vs_244)));
    }
    V v_t_2444;
    switch (heff_tag_of(v_ru_248)) {
    case TAG_Nothing: {
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2443 = heff_dup(heff_field(v_ru_248, 0));
      v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2443, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_ru_248);
    }
    V v_t_2445 = (g_prelude_2e_2b_2b(v_t_2442, v_t_2444));
    V v_owned_2446 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_240, 4)), v_t_2445));
    V v_t_2448;
    switch (heff_tag_of(v_ru_248)) {
    case TAG_Nothing: {
      v_t_2448 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2447 = heff_dup(heff_field(v_ru_248, 0));
      v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2447, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_ru_248);
    }
    V v_wanted_2449 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_dup(heff_rfield(v_ce_240, 5)), v_fb_245, v_t_2448));
    V v_owned_2451 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_lam5, 1, 1, (V[]){v_wanted_2449}), v_owned_2446));
    V v_t_2452;
    if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
      v_t_2452 = (g_prelude_2e_2b_2b(heff_dup(v_vs_244), heff_dup(heff_rfield(v_ce_240, 6))));
    } else {
      v_t_2452 = heff_dup(heff_rfield(v_ce_240, 6));
    }
    V v_n_2453 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_244; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_vs_244); r_; });
    V v_t_2455;
    switch (heff_tag_of(v_ru_248)) {
    case TAG_Nothing: {
      heff_drop(v_n_2453);
      v_t_2455 = heff_dup(v_ce_240);
      break;
    }
    case TAG_Just: {
      V v_ru_2454 = heff_field(v_ru_248, 0);
      V v_ru_24ru_248_24Just = heff_take_reuse_n(v_ru_248, 1ULL, 1);
      v_t_2455 = (g_heff_2ecompile_2erc_2ewithKnown(v_ru_2454, heff_tag_at_n(v_ru_24ru_248_24Just, TAG_KnownCell, 1, (V[]){v_n_2453}), heff_dup(v_ce_240)));
      break;
    }
    default: heff_nomatch(v_ru_248);
    }
    V v_ce_2456 = (g_heff_2ecompile_2erc_2ewithBorrowed(v_t_2452, v_t_2455));
    V v_ce_2457 = ({ V rv_4 = v_owned_2451; V rv_5 = heff_get_n(v_ce_240, 5, 13); V rr_ = heff_rec_reuse_nf(v_ce_2456, 8143ULL, 13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, 67105023u, 0u); heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
    V v_t_2460;
    switch (heff_tag_of(v_b2_249)) {
    case TAG_ATail: {
      V v_t_2458 = heff_field(v_b2_249, 0);
      heff_take_n(v_b2_249, 1ULL, 1);
      v_t_2460 = (g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315(v_ce_2457, v_t_2458));
      break;
    }
    case TAG_ASts: {
      V v_ss_2459 = heff_field(v_b2_249, 0);
      heff_take_n(v_b2_249, 1ULL, 1);
      v_t_2460 = (g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518(v_ce_2457, v_ss_2459, NTAG(TAG_Nothing)));
      break;
    }
    default: heff_nomatch(v_b2_249);
    }
    V v_t_2461 = (g_prelude_2e_2b_2b(v_t_2440, v_t_2460));
    return heff_tag_n(TAG_MkCArm, 6, (V[]){v_t_243, v_t_2417, v_t_2419, v_t_2426, v_t_2461, v_leaves_246});
  }
  default: return heff_nomatch(v_x9_247);
  }
}
V g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583(a[0], a1, a2, a[3], a[4], a[5], a[6], a[7]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_lam0(V self, V *args) {
  V v_p_2413 = args[0];
  V v_fb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416;
  switch (heff_tag_of(v_p_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_p_2413, 0);
    heff_take_n(v_p_2413, 1ULL, 2);
    v_t_2416 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_p_2413);
  }
  return ({ V a_0 = v_t_2416; V a_1 = v_fb_245; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_fb_245); r_; });
}
V g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_lam1(V self, V *args) {
  V v_v_2427 = args[0];
  V v_fb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2427; V a_1 = v_fb_245; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_fb_245); r_; });
}
V g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_lam2(V self, V *args) {
  V v_v_2431 = args[0];
  V v_wanted_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2432 = ({ V a_0 = v_v_2431; V a_1 = v_wanted_2430; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2430); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2432) == NTAG(TAG_True)));
  heff_drop(v_x1_2432);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_lam3(V self, V *args) {
  V v_v_2434 = args[0];
  V v_taken_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436;
  switch (heff_tag_of(v_taken_241)) {
  case TAG_Nothing: {
    v_t_2436 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2435 = heff_field(v_taken_241, 0);
    heff_take_n(v_taken_241, 1ULL, 1);
    v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2435, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_taken_241);
  }
  V v_x1_2437 = ({ V a_0 = v_v_2434; V a_1 = v_t_2436; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_t_2436); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2437) == NTAG(TAG_True)));
  heff_drop(v_x1_2437);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_lam4(V self, V *args) {
  V v_v_2441 = args[0];
  V v_fb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2441; V a_1 = v_fb_245; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_fb_245); r_; });
}
V g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583_lam5(V self, V *args) {
  V v_v_2450 = args[0];
  V v_wanted_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2450; V a_1 = v_wanted_2449; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2449); r_; });
}
Clo g_heff_2ecompile_2erc_2earmOf_24s150833151x1640468863_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2earmOf_24s150833151x1640468863_entry, 6, 0};

V g_heff_2ecompile_2erc_2earmOf_24s150833151x1640468863(V v_ce0_240, V v_held_241, V v_lent_242, V v_t_243, V v_vs_244, V v_b_245) {
top: ;
  V v_n_246 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_244));
  V v_ce_248;
  switch (heff_tag_of(v_held_241)) {
  case TAG_Nothing: {
    heff_drop(v_n_246);
    v_ce_248 = v_ce0_240;
    break;
  }
  case TAG_Just: {
    V v_x_247 = heff_dup(heff_field(v_held_241, 0));
    v_ce_248 = (g_heff_2ecompile_2erc_2ewithKnown(v_x_247, heff_tag_n(TAG_KnownTag, 1, (V[]){v_n_246}), v_ce0_240));
    break;
  }
  default: heff_nomatch(v_held_241);
  }
  V v_fb_2411;
  switch (heff_tag_of(v_b_245)) {
  case TAG_ATail: {
    V v_t_249 = heff_dup(heff_field(v_b_245, 0));
    v_fb_2411 = (g_heff_2ecompile_2erc_2efvTl(v_t_249));
    break;
  }
  case TAG_ASts: {
    V v_ss_2410 = heff_dup(heff_field(v_b_245, 0));
    v_fb_2411 = (g_heff_2ecompile_2erc_2efvSts(v_ss_2410));
    break;
  }
  default: heff_nomatch(v_b_245);
  }
  V v_taken_2412 = (g_heff_2ecompile_2erc_2etakenFv(heff_dup(v_ce_248), v_held_241, v_vs_244, v_fb_2411));
  V v_t_2415;
  switch (heff_tag_of(v_b_245)) {
  case TAG_ATail: {
    v_t_2415 = NTAG(TAG_False);
    break;
  }
  case TAG_ASts: {
    v_t_2415 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_b_245);
  }
  V v_t_2416 = (g_heff_2ecompile_2erc_2ereusing(heff_dup(v_taken_2412), heff_dup(v_t_243), v_vs_244, v_b_245));
  return ({ V a_0 = v_ce_248; V a_1 = v_taken_2412; V a_2 = v_lent_242; V a_3 = v_t_243; V a_4 = v_vs_244; V a_5 = v_fb_2411; V a_6 = v_t_2415; V a_7 = v_t_2416; V r_ = (g_heff_2ecompile_2erc_2earmKept_24s736346493x916937583(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_taken_2412); r_; });
}
V g_heff_2ecompile_2erc_2earmOf_24s150833151x1640468863_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erc_2earmOf_24s150833151x1640468863(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499_entry, 6, 0};

V g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499(V v_ce_240, V v_live_241, V v_bi_242, V v_i_243, V v_x6_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_ce_240, 13);
    heff_drop(v_live_241);
    heff_drop(v_i_243);
    heff_drop(v_x7_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_246 = heff_field(v_x6_244, 0);
    V v_ps_247 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_x7_245)) {
    case TAG_Nil: {
      heff_drop_rec(v_ce_240, 13);
      heff_drop(v_live_241);
      heff_drop(v_i_243);
      heff_drop(v_p_246);
      heff_drop(v_ps_247);
      heff_drop_cell(v_ru_24x6_244_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_e_248 = heff_field(v_x7_245, 0);
      V v_es_249 = heff_field(v_x7_245, 1);
      heff_take_n(v_x7_245, 3ULL, 2);
      V v_x3_2410 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_p_246), heff_rfield(v_ce_240, 10)));
      V v_t_2412;
      switch (heff_tag_of(v_x3_2410)) {
      case TAG_Nothing: {
        v_t_2412 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_x3_2410, 0ULL, 1);
        v_t_2412 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x3_2410);
      }
      V v_t_2425;
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_249)));
        V v_t_2414 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2413; V r_ = (g_list_2efoldl_24s1790904629x1122008408(a_0, a_1)); heff_drop(v_t_2413); r_; });
        V v_live_2415 = (g_prelude_2e_2b_2b(v_t_2414, heff_dup(v_live_241)));
        V v_x2_2416 = (g_map_2elookup_24s1546226666x2146984184(v_p_246, heff_rfield(v_ce_240, 10)));
        V v_want_2418;
        switch (heff_tag_of(v_x2_2416)) {
        case TAG_Nothing: {
          v_want_2418 = NTAG(TAG_RepV);
          break;
        }
        case TAG_Just: {
          V v_x_2417 = heff_field(v_x2_2416, 0);
          heff_take_n(v_x2_2416, 1ULL, 1);
          v_want_2418 = v_x_2417;
          break;
        }
        default: heff_nomatch(v_x2_2416);
        }
        V v_t_2419 = (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(heff_dup(v_ce_240), v_live_2415, v_want_2418, v_e_248));
        v_t_2425 = heff_tag_n(TAG_Given, 1, (V[]){v_t_2419});
      } else {
        heff_drop(v_p_246);
        heff_drop(v_t_2412);
        V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_249)));
        V v_t_2421 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2420; V r_ = (g_list_2efoldl_24s1790904629x1122008408(a_0, a_1)); heff_drop(v_t_2420); r_; });
        V v_live_2422 = (g_prelude_2e_2b_2b(v_t_2421, heff_dup(v_live_241)));
        V v_t_2423 = (g_heff_2ecompile_2erc_2eelemI(heff_dup(v_i_243), v_bi_242));
        V v_t_2424;
        if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
          heff_drop(v_t_2423);
          v_t_2424 = (g_heff_2ecompile_2erc_2elentField(heff_dup(v_ce_240), v_live_241, v_e_248));
        } else {
          heff_drop(v_t_2423);
          v_t_2424 = NTAG(TAG_Nothing);
        }
        v_t_2425 = (g_heff_2ecompile_2erc_2elentOr_24s1810949213x1891197566(heff_dup(v_ce_240), v_live_2422, v_bi_242, heff_dup(v_i_243), v_e_248, v_t_2424));
      }
      V v_cell_2426 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
      V v_u_2427 = (g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499_24dps(v_ce_240, v_live_241, v_bi_242, heff_intAdd(v_i_243, MK_INT(1LL)), v_ps_247, v_es_249, heff_dup(v_cell_2426)));
      heff_drop(v_u_2427);
      return v_cell_2426;
    }
    default: return heff_nomatch(v_x7_245);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erc_2ecallLast_24s1815774051x1886726305_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ecallLast_24s1815774051x1886726305_entry, 3, 0};

V g_heff_2ecompile_2erc_2ecallLast_24s1815774051x1886726305(V v_ce_240, V v_g_241, V v_as_242) {
top: ;
  V v_x2_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_241), heff_rfield(v_ce_240, 7)));
  V v_t_245;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nothing: {
    v_t_245 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x2_243, 0);
    heff_take_n(v_x2_243, 1ULL, 1);
    v_t_245 = v_x_244;
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_246 = heff_dup(heff_rfield(v_ce_240, 2));
  V v_t_248;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    v_t_248 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_s_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_t_248 = heff_get_n(v_s_247, 1, 2);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_t_249 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_245; V a_3 = MK_INT(0LL); V a_4 = v_t_248; V a_5 = heff_dup(v_as_242); V r_ = (g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_245); r_; });
  V v_x2_2410 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_241), heff_rfield(v_ce_240, 7)));
  V v_t_2412;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    heff_take_n(v_x2_2410, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  V v_x2_2413 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_241), heff_rfield(v_ce_240, 11)));
  V v_t_2415;
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nothing: {
    v_t_2415 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_as_242)));
    break;
  }
  case TAG_Just: {
    V v_s_2414 = heff_field(v_x2_2413, 0);
    heff_take_n(v_x2_2413, 1ULL, 1);
    v_t_2415 = heff_get_n(v_s_2414, 0, 2);
    break;
  }
  default: heff_nomatch(v_x2_2413);
  }
  V v_t_2416 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2412; V a_3 = MK_INT(0LL); V a_4 = v_t_2415; V a_5 = heff_dup(v_as_242); V r_ = (g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2412); r_; });
  return ({ V a_0 = v_ce_240; V a_1 = v_g_241; V a_2 = v_as_242; V a_3 = v_t_249; V a_4 = v_t_2416; V r_ = (g_heff_2ecompile_2erc_2ecallAs(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_as_242); r_; });
}
V g_heff_2ecompile_2erc_2ecallLast_24s1815774051x1886726305_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2ecallLast_24s1815774051x1886726305(a[0], a[1], a[2]);
}