// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Windows 49101
#define LBL_at 9882
#define LBL_base 9511832
#define LBL_by 9918
#define LBL_col 308218
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_doneMods 1906059763
#define LBL_errors 652506774
#define LBL_heff 9694020
#define LBL_imports 10411951
#define LBL_lib 316671
#define LBL_line 9817275
#define LBL_mod 317820
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_named 305943379
#define LBL_own 320000
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_pkg 320582
#define LBL_place 308106529
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_scope 310622830
#define LBL_source 1050636102
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_version 583465758
static uint32_t shape_done__doneMods__errors[] = {LBL_done, LBL_doneMods, LBL_errors};
static uint32_t shape_path__dir__src__own__top__heff__scope[] = {LBL_path, LBL_dir, LBL_src, LBL_own, LBL_top, LBL_heff, LBL_scope};
static uint32_t shape_path__source__place__module__named[] = {LBL_path, LBL_source, LBL_place, LBL_module, LBL_named};
static uint32_t shape_path__version__pkg[] = {LBL_path, LBL_version, LBL_pkg};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2eclashMsg(V, V, V, V);
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eclashMsg_clo;
V g_heff_2ebuild_2eload_2efreeName(V, V, V);
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2efreeName_clo;
V g_heff_2ebuild_2eload_2einside(V, V, V);
V g_heff_2ebuild_2eload_2einside_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2einside_clo;
V g_heff_2ebuild_2eload_2eloadMany(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_clo;
V g_heff_2ebuild_2eload_2enamedGo(V, V);
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_clo;
V g_heff_2ebuild_2eload_2enamedGo_24dps(V, V, V);
V g_heff_2ebuild_2eload_2enamedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_24dps_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056(V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_clo;
V g_heff_2ebuild_2eload_2epartsNamed(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epartsNamed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epartsNamed_clo;
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971(V, V, V);
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_clo;
V g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_clo;
V g_heff_2ebuild_2eload_2epkgOfGo(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOfGo_clo;
V g_heff_2ebuild_2eload_2eplacesOf(V, V, V, V);
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eplacesOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2epushDone(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epushDone_clo;
V g_heff_2ebuild_2eload_2ereadEvery(V, V, V);
V g_heff_2ebuild_2eload_2ereadEvery_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749(V, V);
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_clo;
HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152(V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_clo;
V g_heff_2elsp_2erender_2elineColAt(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColAt_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s241416889x826324235(V, V, V);
V g_list_2eany_24s241416889x826324235_entry(V self, V *a);
extern Clo g_list_2eany_24s241416889x826324235_clo;
HeffT2 g_list_2efind_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s1943838498x1969994910(V, V);
V g_list_2ekeepIf_24s1943838498x1969994910_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1943838498x1969994910_clo;
V g_list_2ekeepIf_24s537296923x1092827761(V, V);
V g_list_2ekeepIf_24s537296923x1092827761_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s537296923x1092827761_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s18996220x10511024(V);
V g_list_2emap_24s18996220x10511024_entry(V self, V *a);
extern Clo g_list_2emap_24s18996220x10511024_clo;
V g_list_2emap_24s2087317732x355496638(V);
V g_list_2emap_24s2087317732x355496638_entry(V self, V *a);
extern Clo g_list_2emap_24s2087317732x355496638_clo;
V g_list_2emap_24s435407392x1528135477(V);
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str4, 2, ": ");
Clo g_heff_2ebuild_2eload_2eproblemMsg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eproblemMsg_entry, 3, 0};

V g_heff_2ebuild_2eload_2eproblemMsg(V v_path_240, V v_src_241, V v_p_242) {
top: ;
  V v_at_243 = heff_take_field(v_p_242, 0);
  V v_msg_244 = heff_get_n(v_p_242, 1, 2);
  V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str0), v_src_241, MK_INT(0LL), 5);
  V v_t_246;
  if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
    heff_drop(v_j_245);
    v_t_246 = NTAG(TAG_Nothing);
  } else {
    v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){v_j_245});
  }
  V v_t_247 = (g_heff_2elsp_2erender_2elineColAt(v_src_241, heff_dup(v_at_243), MK_INT(0LL), MK_INT(0LL), v_t_246));
  V v_t_248 = heff_intAdd(heff_get_n(v_t_247, 0, 3), MK_INT(1LL));
  V v_t_249 = heff_strAppend(heff_strAppend(v_path_240, ((V)&g_heff_2ebuild_2eload_2eproblemMsg_str1)), heff_intShow(v_t_248));
  V v_j_2410 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str2), v_src_241, MK_INT(0LL), 5);
  V v_t_2411;
  if (heff_intLt_c_lent(v_j_2410, MK_INT(0LL), 2)) {
    heff_drop(v_j_2410);
    v_t_2411 = NTAG(TAG_Nothing);
  } else {
    v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){v_j_2410});
  }
  V v_t_2412 = (g_heff_2elsp_2erender_2elineColAt(v_src_241, v_at_243, MK_INT(0LL), MK_INT(0LL), v_t_2411));
  V v_t_2413 = heff_intAdd(heff_get_n(v_t_2412, 2, 3), MK_INT(1LL));
  V v_t_2414 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2eload_2eproblemMsg_str3)), heff_intShow(v_t_2413));
  return heff_strAppend(heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2eload_2eproblemMsg_str4)), v_msg_244);
}
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eload_2eproblemMsg(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str0, 1, "@");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str5, 1, "\\");
Clo g_heff_2ebuild_2eload_2ecachedDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedDir_entry, 3, 0};

V g_heff_2ebuild_2eload_2ecachedDir(V v_ps_240, V v_path_241, V v_v_242) {
top: ;
  V v_mod_243 = heff_take_field(v_ps_240, 3);
  V v_style_244 = heff_get_n(v_ps_240, 5, 6);
  V v_d_245 = v_mod_243;
  V v_s_246 = heff_strAppend(heff_strAppend(v_path_241, ((V)&g_heff_2ebuild_2eload_2ecachedDir_str0)), v_v_242);
  V v_x2_247 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str1); V a_1 = v_s_246; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2ecachedDir_str2), v_s_246, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_246); r_; });
  V v_p_2411;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_p_2411 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_style_244)) {
    case TAG_Posix: {
      v_t_2410 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str4);
      break;
    }
    case TAG_Windows: {
      v_t_2410 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str5);
      break;
    }
    default: heff_nomatch(v_style_244);
    }
    v_p_2411 = ({ V a_0 = v_t_2410; V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_st_2412 = v_style_244;
  V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_2412), v_d_245));
  V v_t_2414 = (g_std_2epath_2eparse(heff_dup(v_st_2412), v_p_2411));
  V v_t_2415 = (g_std_2epath_2ejoin(v_t_2413, v_t_2414));
  return ({ V a_0 = v_st_2412; V a_1 = v_t_2415; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2412); heff_drop(v_t_2415); r_; });
}
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecachedDir(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eload_2enamedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2enamedGo_entry, 2, 0};

V g_heff_2ebuild_2eload_2enamedGo(V v_taken_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_dup(heff_rfield(v_k_242, 3)), MK_INT(1LL)));
    V v_t_245 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_take_field(v_k_242, 0), heff_take_field(v_k_242, 1), heff_take_field(v_k_242, 2), heff_dup(heff_rfield(v_k_242, 3)), v_t_244, heff_take_field(v_k_242, 5), heff_take_field(v_k_242, 6)});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_t_247 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_get_n(v_k_242, 3, 7), MK_INT(1LL)));
    V v_u_248 = (g_heff_2ebuild_2eload_2enamedGo_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_taken_240}), v_rest_243, heff_dup(v_cell_246)));
    heff_drop(v_u_248);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2enamedGo(a[0], a[1]);
}
Clo g_heff_2ebuild_2eload_2epkgOfGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgOfGo_entry, 4, 0};

V g_heff_2ebuild_2eload_2epkgOfGo(V v_ps_240, V v_x2_241, V v_project_242, V v_from_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_from_243);
    return v_project_242;
  }
  case TAG_Cons: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_heff_2ebuild_2eload_2einside(heff_dup(v_ps_240), heff_dup(heff_rfield(v_k_244, 1)), heff_dup(v_from_243)));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_ps_240);
      heff_drop(v_project_242);
      heff_drop(v_from_243);
      heff_drop(v_t_246);
      return heff_dup(v_k_244);
    } else {
      heff_drop(v_t_246);
      V t_0 = v_ps_240;
      V t_1 = v_rest_245;
      V t_2 = v_project_242;
      V t_3 = v_from_243;
      v_ps_240 = t_0;
      v_x2_241 = t_1;
      v_project_242 = t_2;
      v_from_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eload_2epkgOfGo(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_str2, 3, ".hf");
V g_heff_2ebuild_2eload_2ereadEvery_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadEvery_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_lam0, 2, 0};
V g_heff_2ebuild_2eload_2ereadEvery_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadEvery_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_entry, 3, 0};

V g_heff_2ebuild_2eload_2ereadEvery(V v_e_240, V v_read_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_read_241);
    return ((V)&g_heff_2ebuild_2eload_2ereadEvery_lam0_clo);
  }
  case TAG_Cons: {
    V v_pl_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_c_247 = heff_tr(heff_call(heff_dup(v_read_241), 1, (V[]){heff_dup(heff_rfield(v_pl_245, 0))}));
    return heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_lam1, 2, 5, (V[]){v_c_247, heff_dup(v_e_240), v_read_241, v_rest_246, v_pl_245});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2eload_2ereadEvery_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2ereadEvery(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2eload_2ereadEvery_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_pl_245 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2423;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    heff_drop_rec(v_pl_245, 4);
    v_x_2423 = v_x_2412;
    break;
  }
  case TAG_Just: {
    V v_s_2413 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    V v_t_2414 = heff_dup(heff_rfield(v_pl_245, 2));
    V v_p_2417;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nil: {
      v_p_2417 = ((V)&g_heff_2ebuild_2eload_2ereadEvery_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_t_2414, 0);
      V v_xs_2416 = heff_field(v_t_2414, 1);
      heff_take_n(v_t_2414, 3ULL, 2);
      v_p_2417 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2ereadEvery_str1); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    int64_t v_t_2418 = (heff_unbox_word(heff_strLength_lent(v_p_2417, 0)) - ((int64_t)3ULL));
    V v_t_2419 = heff_strSlice(heff_dup(v_p_2417), heff_box_word(v_t_2418), heff_strLength_lent(v_p_2417, 0));
    V v_t_2421;
    if (heff_strEq_c(v_t_2419, ((V)&g_heff_2ebuild_2eload_2ereadEvery_str2))) {
      int64_t v_t_2420 = (heff_unbox_word(heff_strLength_lent(v_p_2417, 0)) - ((int64_t)3ULL));
      v_t_2421 = heff_strSlice(v_p_2417, MK_INT(0LL), heff_box_word(v_t_2420));
    } else {
      v_t_2421 = v_p_2417;
    }
    V v_t_2422 = heff_rec_n(5, shape_path__source__place__module__named, (V[]){heff_dup(heff_rfield(v_pl_245, 0)), v_s_2413, heff_dup(v_pl_245), heff_get_n(v_pl_245, 3, 4), v_t_2421});
    v_x_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_x_2412});
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V f_ = v_k_249;
  args[0] = v_x_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_read_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_pl_245 = heff_env(self)[4];
  V v_k_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2411 = ({ V a_0 = v_e_240; V a_1 = v_read_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2eload_2ereadEvery(a_0, a_1, a_2)); heff_drop(v_e_240); r_; });
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_lam3, 1, 3, (V[]){v_x_2410, v_pl_245, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereadEvery_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_read_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_pl_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_lam2, 1, 6, (V[]){v_e_240, v_read_241, v_rest_246, v_hd_248, v_pl_245, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str0, 9, ": module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str2, 5, " and ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str3, 24, " is more than one file: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str5, 39, ", so it is loaded from neither: rename ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str6, 55, ", and the imports of it, so that the name is one file's");
V g_heff_2ebuild_2eload_2eclashMsg_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eclashMsg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eclashMsg_entry, 4, 0};

V g_heff_2ebuild_2eload_2eclashMsg(V v_ps_240, V v_found_241, V v_from_242, V v_m_243) {
top: ;
  V v_t_244 = heff_strAppend(heff_strAppend(v_from_242, ((V)&g_heff_2ebuild_2eload_2eclashMsg_str0)), v_m_243);
  V v_x2_245 = (g_list_2emap_24s2087317732x355496638(heff_dup(v_found_241)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_t_249 = heff_strAppend(heff_strAppend(v_t_244, ((V)&g_heff_2ebuild_2eload_2eclashMsg_str3)), v_t_248);
  HeffT2 v_t_2415 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2ebuild_2eload_2eclashMsg_lam0, 1, 1, (V[]){v_ps_240}), v_found_241));
  V v_t_2421;
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      heff_drop(v_found_241);
      V v_f_2418 = v_field_2417;
      v_t_2421 = heff_get_n(v_f_2418, 0, 5);
    } else {
      heff_drop(v_field_2417);
      switch (heff_tag_of(v_found_241)) {
      case TAG_Nil: {
        v_t_2421 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str4);
        break;
      }
      case TAG_Cons: {
        V v_f_2419 = heff_field(v_found_241, 0);
        heff_take_n(v_found_241, 1ULL, 2);
        v_t_2421 = heff_get_n(v_f_2419, 0, 5);
        break;
      }
      default: heff_nomatch(v_found_241);
      }
    }
  }
  V v_t_2422 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2eload_2eclashMsg_str5)), v_t_2421);
  return heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2eload_2eclashMsg_str6));
}
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eclashMsg(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2eclashMsg_lam0(V self, V *args) {
  V v_f_2410 = args[0];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2411 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_get_n(v_ps_240, 2, 6), heff_get_n(v_f_2410, 0, 5)));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2412 == ((int64_t)0ULL)) ? ({ V v_x_2414 = heff_dup(v_field_2413); int c_ = 0; heff_drop(v_x_2414); c_; }) : 1));
    heff_drop(v_field_2413);
    return v_ret_24bool;
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_str0, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_str2, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_str3, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_str4, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_str5, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_str7, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_str8, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_str9, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_str10, 2, ": ");
V g_heff_2ebuild_2eload_2eloadMany_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_entry, 11, 0};

V g_heff_2ebuild_2eload_2eloadMany(V v_e_240, V v_ev_241, V v_read_242, V v_ps_243, V v_pkgs_244, V v_stack_245, V v_from_246, V v_imp_247, V v_x7_248, V v_st_249, V v_rs_2410) {
top: ;
  switch (heff_tag_of(v_x7_248)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_ev_241);
    heff_drop(v_read_242);
    heff_drop(v_ps_243);
    heff_drop(v_pkgs_244);
    heff_drop(v_stack_245);
    heff_drop(v_from_246);
    heff_drop(v_imp_247);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_lam0, 2, 2, (V[]){v_st_249, v_rs_2410});
  }
  case TAG_Cons: {
    V v_w_2413 = heff_field(v_x7_248, 0);
    V v_rest_2414 = heff_field(v_x7_248, 1);
    heff_take_n(v_x7_248, 3ULL, 2);
    V v_t_2415 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_243), heff_dup(v_pkgs_244), heff_dup(v_from_246), heff_dup(v_w_2413)));
    V v_c_2416 = (g_heff_2ebuild_2eload_2ereadEvery(v_e_240, heff_dup(v_read_242), v_t_2415));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_lam1, 2, 13, (V[]){v_c_2416, v_ps_243, v_pkgs_244, v_from_246, v_w_2413, v_st_249, v_e_240, v_ev_241, v_read_242, v_stack_245, v_imp_247, v_rest_2414, v_rs_2410});
  }
  default: return heff_nomatch(v_x7_248);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
V g_heff_2ebuild_2eload_2eloadMany_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_st_249 = heff_env(self)[0];
  V v_rs_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_249, v_rs_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_lam4(V self, V *args) {
  V v_x_2475 = args[0];
  V v_imp_247 = heff_env(self)[0];
  V v_module_2434 = heff_env(self)[1];
  V v_ps_243 = heff_env(self)[2];
  V v_named_2438 = heff_env(self)[3];
  V v_path_2436 = heff_env(self)[4];
  V v_source_2437 = heff_env(self)[5];
  V v_w_2413 = heff_env(self)[6];
  V v_rs_2410 = heff_env(self)[7];
  V v_e_240 = heff_env(self)[8];
  V v_ev_241 = heff_env(self)[9];
  V v_read_242 = heff_env(self)[10];
  V v_pkgs_244 = heff_env(self)[11];
  V v_stack_245 = heff_env(self)[12];
  V v_from_246 = heff_env(self)[13];
  V v_rest_2414 = heff_env(self)[14];
  V v_hd_2417 = heff_env(self)[15];
  V v_k_2418 = heff_env(self)[16];
  heff_clo_take(self, 17);
  V v_t_2478;
  switch (heff_tag_of(v_x_2475)) {
  case TAG_MkPair: {
    V v_x_2476 = heff_dup(heff_field(v_x_2475, 0));
    v_t_2478 = v_x_2476;
    break;
  }
  default: heff_nomatch(v_x_2475);
  }
  V v_t_2479 = heff_tr(heff_call(heff_dup(v_imp_247), 1, (V[]){heff_dup(v_module_2434)}));
  V v_t_2482;
  switch (heff_tag_of(v_x_2475)) {
  case TAG_MkPair: {
    V v_y_2481 = heff_field(v_x_2475, 1);
    heff_take_n(v_x_2475, 2ULL, 2);
    v_t_2482 = v_y_2481;
    break;
  }
  default: heff_nomatch(v_x_2475);
  }
  V v_t_2483 = (g_heff_2ebuild_2eload_2epushDone(v_t_2478, heff_dup(v_ps_243), heff_dup(v_module_2434), v_named_2438, v_path_2436, v_source_2437, v_t_2479, v_t_2482));
  V v_m_2484 = v_module_2434;
  V v_t_2485;
  if (heff_strEq_c_lent(v_w_2413, v_m_2484, 0)) {
    heff_drop(v_w_2413);
    heff_drop(v_m_2484);
    v_t_2485 = v_rs_2410;
  } else {
    v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2413, v_m_2484}), v_rs_2410});
  }
  V v_t_2486 = (g_heff_2ebuild_2eload_2eloadMany(v_e_240, v_ev_241, v_read_242, v_ps_243, v_pkgs_244, v_stack_245, v_from_246, v_imp_247, v_rest_2414, v_t_2483, v_t_2485));
  V f_ = v_t_2486;
  heff_room[0] = v_hd_2417;
  heff_room[1] = v_k_2418;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_lam3(V self, V *args) {
  V v_x_2462 = args[0];
  V v_imp_247 = heff_env(self)[0];
  V v_module_2434 = heff_env(self)[1];
  V v_source_2437 = heff_env(self)[2];
  V v_st_249 = heff_env(self)[3];
  V v_from_246 = heff_env(self)[4];
  V v_w_2413 = heff_env(self)[5];
  V v_e_240 = heff_env(self)[6];
  V v_ev_241 = heff_env(self)[7];
  V v_read_242 = heff_env(self)[8];
  V v_ps_243 = heff_env(self)[9];
  V v_pkgs_244 = heff_env(self)[10];
  V v_stack_245 = heff_env(self)[11];
  V v_path_2436 = heff_env(self)[12];
  V v_hd_2417 = heff_env(self)[13];
  V v_named_2438 = heff_env(self)[14];
  V v_rs_2410 = heff_env(self)[15];
  V v_rest_2414 = heff_env(self)[16];
  V v_k_2418 = heff_env(self)[17];
  heff_clo_take(self, 18);
  V v_t_2463 = heff_tr(heff_call(heff_dup(v_imp_247), 1, (V[]){heff_dup(v_module_2434)}));
  V v_t_2464 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2463, heff_dup(v_source_2437)));
  V v_imps_2465 = heff_get_n(v_t_2464, 0, 4);
  V v_t_2466 = (g_list_2emap_24s1817208647x1282894070(v_imps_2465));
  V v_t_2467 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2466));
  V v_t_2473;
  switch (heff_tag_of(v_x_2462)) {
  case TAG_Nothing: {
    v_t_2473 = v_st_249;
    break;
  }
  case TAG_Just: {
    V v_why_2468 = heff_field(v_x_2462, 0);
    heff_take_n(v_x_2462, 1ULL, 1);
    V v_t_2469 = heff_strAppend(heff_strAppend(heff_dup(v_from_246), ((V)&g_heff_2ebuild_2eload_2eloadMany_str9)), heff_dup(v_w_2413));
    V v_t_2470 = heff_strAppend(heff_strAppend(v_t_2469, ((V)&g_heff_2ebuild_2eload_2eloadMany_str10)), v_why_2468);
    V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2470, NTAG(TAG_Nil)});
    V v_t_2472 = (g_prelude_2e_2b_2b(heff_take_field(v_st_249, 2), v_t_2471));
    v_t_2473 = ({ V rv_2 = v_t_2472; V rr_ = heff_rec_reuse_nf(v_st_249, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2462);
  }
  V v_c_2474 = (g_heff_2ebuild_2eload_2eloadMany(heff_dup(v_e_240), heff_dup(v_ev_241), heff_dup(v_read_242), heff_dup(v_ps_243), heff_dup(v_pkgs_244), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2434), heff_dup(v_stack_245)}), heff_dup(v_path_2436), heff_dup(v_imp_247), v_t_2467, v_t_2473, NTAG(TAG_Nil)));
  V f_ = v_c_2474;
  heff_room[0] = heff_dup(v_hd_2417);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_lam4, 1, 17, (V[]){v_imp_247, v_module_2434, v_ps_243, v_named_2438, v_path_2436, v_source_2437, v_w_2413, v_rs_2410, v_e_240, v_ev_241, v_read_242, v_pkgs_244, v_stack_245, v_from_246, v_rest_2414, v_hd_2417, v_k_2418});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_ps_243 = heff_env(self)[0];
  V v_pkgs_244 = heff_env(self)[1];
  V v_from_246 = heff_env(self)[2];
  V v_w_2413 = heff_env(self)[3];
  V v_st_249 = heff_env(self)[4];
  V v_e_240 = heff_env(self)[5];
  V v_ev_241 = heff_env(self)[6];
  V v_read_242 = heff_env(self)[7];
  V v_stack_245 = heff_env(self)[8];
  V v_imp_247 = heff_env(self)[9];
  V v_rest_2414 = heff_env(self)[10];
  V v_rs_2410 = heff_env(self)[11];
  V v_hd_2417 = heff_env(self)[12];
  V v_k_2418 = heff_env(self)[13];
  heff_clo_take(self, 14);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Nil: {
    V v_places_2420 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_243), heff_dup(v_pkgs_244), heff_dup(v_from_246), heff_dup(v_w_2413)));
    V v_t_2421 = heff_strAppend(heff_strAppend(heff_dup(v_from_246), ((V)&g_heff_2ebuild_2eload_2eloadMany_str0)), v_w_2413);
    V v_x2_2422 = (g_list_2emap_24s435407392x1528135477(v_places_2420));
    V v_t_2425;
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nil: {
      v_t_2425 = ((V)&g_heff_2ebuild_2eload_2eloadMany_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_xs_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      v_t_2425 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_str2); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2422);
    }
    V v_t_2426 = heff_strAppend(heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2eload_2eloadMany_str3)), v_t_2425);
    V v_e_2427 = heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2eload_2eloadMany_str4));
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2427, NTAG(TAG_Nil)});
    V v_t_2429 = (g_prelude_2e_2b_2b(heff_take_field(v_st_249, 2), v_t_2428));
    V v_t_2430 = ({ V rv_2 = v_t_2429; V rr_ = heff_rec_reuse_nf(v_st_249, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2431 = (g_heff_2ebuild_2eload_2eloadMany(v_e_240, v_ev_241, v_read_242, v_ps_243, v_pkgs_244, v_stack_245, v_from_246, v_imp_247, v_rest_2414, v_t_2430, v_rs_2410));
    V f_ = v_t_2431;
    heff_room[0] = v_hd_2417;
    heff_room[1] = v_k_2418;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2432 = heff_dup(heff_field(v_x_2419, 0));
    V v_others_2433 = heff_dup(heff_field(v_x_2419, 1));
    V v_module_2434 = heff_take_field(v_f_2432, 3);
    V v_place_2435 = heff_take_field(v_f_2432, 2);
    V v_path_2436 = heff_take_field(v_f_2432, 0);
    V v_source_2437 = heff_take_field(v_f_2432, 1);
    V v_named_2438 = heff_get_n(v_f_2432, 4, 5);
    V v_t_2439 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_module_2434)}));
    V v_t_2440 = (g_list_2eany(v_t_2439, heff_rfield(v_st_249, 1)));
    if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2419, 2);
      heff_drop(v_others_2433);
      heff_drop_rec(v_place_2435, 4);
      heff_drop(v_path_2436);
      heff_drop(v_source_2437);
      heff_drop(v_named_2438);
      heff_drop(v_t_2440);
      V v_m_2441 = v_module_2434;
      V v_t_2442;
      if (heff_strEq_c_lent(v_w_2413, v_m_2441, 0)) {
        heff_drop(v_w_2413);
        heff_drop(v_m_2441);
        v_t_2442 = v_rs_2410;
      } else {
        v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2413, v_m_2441}), v_rs_2410});
      }
      V v_t_2443 = (g_heff_2ebuild_2eload_2eloadMany(v_e_240, v_ev_241, v_read_242, v_ps_243, v_pkgs_244, v_stack_245, v_from_246, v_imp_247, v_rest_2414, v_st_249, v_t_2442));
      V f_ = v_t_2443;
      heff_room[0] = v_hd_2417;
      heff_room[1] = v_k_2418;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2440);
      V v_t_2444 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_module_2434)}));
      V v_t_2445 = (g_list_2eany(v_t_2444, v_stack_245));
      if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2419, 2);
        heff_drop(v_others_2433);
        heff_drop_rec(v_place_2435, 4);
        heff_drop(v_path_2436);
        heff_drop(v_source_2437);
        heff_drop(v_named_2438);
        heff_drop(v_t_2445);
        V v_m_2446 = heff_dup(v_module_2434);
        V v_t_2447 = heff_strAppend(heff_strAppend(heff_dup(v_from_246), ((V)&g_heff_2ebuild_2eload_2eloadMany_str5)), heff_dup(v_m_2446));
        V v_t_2448 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_245)));
        V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_2446, NTAG(TAG_Nil)});
        V v_x2_2450 = (g_prelude_2e_2b_2b(v_t_2448, v_t_2449));
        V v_t_2453;
        switch (heff_tag_of(v_x2_2450)) {
        case TAG_Nil: {
          v_t_2453 = ((V)&g_heff_2ebuild_2eload_2eloadMany_str6);
          break;
        }
        case TAG_Cons: {
          V v_x_2451 = heff_field(v_x2_2450, 0);
          V v_xs_2452 = heff_field(v_x2_2450, 1);
          heff_take_n(v_x2_2450, 3ULL, 2);
          v_t_2453 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_str7); V a_1 = v_x_2451; V a_2 = v_xs_2452; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2452); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2450);
        }
        V v_e_2454 = heff_strAppend(heff_strAppend(v_t_2447, ((V)&g_heff_2ebuild_2eload_2eloadMany_str8)), v_t_2453);
        V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2454, NTAG(TAG_Nil)});
        V v_t_2456 = (g_prelude_2e_2b_2b(heff_take_field(v_st_249, 2), v_t_2455));
        V v_t_2457 = ({ V rv_2 = v_t_2456; V rr_ = heff_rec_reuse_nf(v_st_249, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2458 = v_module_2434;
        V v_t_2459;
        if (heff_strEq_c_lent(v_w_2413, v_m_2458, 0)) {
          heff_drop(v_w_2413);
          heff_drop(v_m_2458);
          v_t_2459 = v_rs_2410;
        } else {
          v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2413, v_m_2458}), v_rs_2410});
        }
        V v_t_2460 = (g_heff_2ebuild_2eload_2eloadMany(v_e_240, v_ev_241, v_read_242, v_ps_243, v_pkgs_244, v_stack_245, v_from_246, v_imp_247, v_rest_2414, v_t_2457, v_t_2459));
        V f_ = v_t_2460;
        heff_room[0] = v_hd_2417;
        heff_room[1] = v_k_2418;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2445);
        switch (heff_tag_of(v_others_2433)) {
        case TAG_Nil: {
          heff_drop_tag(v_x_2419, 2);
          V v_c_2461 = ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_ev_241); V a_2 = heff_dup(v_ps_243); V a_3 = heff_take_field(v_place_2435, 1); V b_4 = heff_get_n(v_place_2435, 2, 4); V r_ = (g_heff_2ebuild_2eload_2epartsNamed(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
          V f_ = v_c_2461;
          heff_room[0] = heff_dup(v_hd_2417);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_lam3, 1, 18, (V[]){v_imp_247, v_module_2434, v_source_2437, v_st_249, v_from_246, v_w_2413, v_e_240, v_ev_241, v_read_242, v_ps_243, v_pkgs_244, v_stack_245, v_path_2436, v_hd_2417, v_named_2438, v_rs_2410, v_rest_2414, v_k_2418});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_Cons: {
          V v_ru_24others_2433_24Cons = heff_take_reuse_n(v_others_2433, 0ULL, 2);
          heff_drop_rec(v_place_2435, 4);
          heff_drop(v_path_2436);
          heff_drop(v_source_2437);
          heff_drop(v_named_2438);
          V v_e_2489 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_243), v_x_2419, heff_dup(v_from_246), heff_dup(v_w_2413)));
          V v_t_2490 = heff_take_field(v_st_249, 0);
          V v_t_2491 = heff_take_field(v_st_249, 1);
          V v_t_2492 = heff_tag_at_n(v_ru_24others_2433_24Cons, TAG_Cons, 2, (V[]){v_e_2489, NTAG(TAG_Nil)});
          V v_t_2493 = (g_prelude_2e_2b_2b(heff_get_n(v_st_249, 2, 3), v_t_2492));
          V v_t_2494 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){v_t_2490, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2434), v_t_2491}), v_t_2493});
          V v_m_2495 = v_module_2434;
          V v_t_2496;
          if (heff_strEq_c_lent(v_w_2413, v_m_2495, 0)) {
            heff_drop(v_w_2413);
            heff_drop(v_m_2495);
            v_t_2496 = v_rs_2410;
          } else {
            v_t_2496 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2413, v_m_2495}), v_rs_2410});
          }
          V v_t_2497 = (g_heff_2ebuild_2eload_2eloadMany(v_e_240, v_ev_241, v_read_242, v_ps_243, v_pkgs_244, v_stack_245, v_from_246, v_imp_247, v_rest_2414, v_t_2494, v_t_2496));
          V f_ = v_t_2497;
          heff_room[0] = v_hd_2417;
          heff_room[1] = v_k_2418;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_others_2433);
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_lam1(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_ps_243 = heff_env(self)[1];
  V v_pkgs_244 = heff_env(self)[2];
  V v_from_246 = heff_env(self)[3];
  V v_w_2413 = heff_env(self)[4];
  V v_st_249 = heff_env(self)[5];
  V v_e_240 = heff_env(self)[6];
  V v_ev_241 = heff_env(self)[7];
  V v_read_242 = heff_env(self)[8];
  V v_stack_245 = heff_env(self)[9];
  V v_imp_247 = heff_env(self)[10];
  V v_rest_2414 = heff_env(self)[11];
  V v_rs_2410 = heff_env(self)[12];
  heff_clo_take(self, 13);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_lam2, 1, 14, (V[]){v_ps_243, v_pkgs_244, v_from_246, v_w_2413, v_st_249, v_e_240, v_ev_241, v_read_242, v_stack_245, v_imp_247, v_rest_2414, v_rs_2410, v_hd_2417, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_str1, 3, "src");
V g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_entry, 4, 0};

V g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344(V v_ps_240, V v_root_241, V v_x_242, V v_pk_243) {
top: ;
  V v_heff_244 = heff_take_field(v_pk_243, 1);
  V v_require_245 = heff_get_n(v_pk_243, 2, 4);
  V v_path_246 = heff_take_field(v_x_242, 0);
  V v_version_247 = heff_get_n(v_x_242, 1, 3);
  V v_require_248 = heff_take_field(v_root_241, 2);
  V v_replace_249 = heff_get_n(v_root_241, 3, 4);
  V v_t_2410 = (g_list_2ekeepIf_24s1943838498x1969994910(v_path_246, v_require_248));
  V v_x_2421;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nil: {
    heff_drop(v_replace_249);
    v_x_2421 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_246), v_version_247));
    break;
  }
  case TAG_Cons: {
    V v_r_2411 = heff_field(v_t_2410, 0);
    heff_take_n(v_t_2410, 1ULL, 2);
    V v_t_2413 = (g_list_2ekeepIf_24s537296923x1092827761(v_r_2411, v_replace_249));
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nil: {
      v_x_2421 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_246), v_version_247));
      break;
    }
    case TAG_Cons: {
      V v_p_2414 = heff_field(v_t_2413, 0);
      heff_take_n(v_t_2413, 1ULL, 2);
      heff_drop(v_version_247);
      V v_d_2416 = heff_dup(heff_rfield(v_ps_240, 0));
      V v_st_2417 = heff_dup(heff_rfield(v_ps_240, 5));
      V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_2417), v_d_2416));
      V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2417), heff_get_n(v_p_2414, 1, 2)));
      V v_t_2420 = (g_std_2epath_2ejoin(v_t_2418, v_t_2419));
      v_x_2421 = ({ V a_0 = v_st_2417; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); heff_drop(v_t_2420); r_; });
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  return heff_clo_n(g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_lam0, 2, 5, (V[]){v_ps_240, v_x_2421, v_require_245, v_path_246, v_heff_244});
}
V g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_lam1(V self, V *args) {
  V v_x_2430 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_require_245 = heff_env(self)[2];
  V v_path_246 = heff_env(self)[3];
  V v_heff_244 = heff_env(self)[4];
  V v_k_2423 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x_2439;
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Left: {
    V v_why_2431 = heff_field(v_x_2430, 0);
    V v_ru_24x_2430_24Left = heff_take_reuse_n(v_x_2430, 1ULL, 1);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_x_2421);
    heff_drop(v_require_245);
    heff_drop(v_path_246);
    heff_drop(v_heff_244);
    v_x_2439 = heff_tag_at_n(v_ru_24x_2430_24Left, TAG_Left, 1, (V[]){v_why_2431});
    break;
  }
  case TAG_Right: {
    V v_name_2432 = heff_field(v_x_2430, 0);
    V v_ru_24x_2430_24Right = heff_take_reuse_n(v_x_2430, 1ULL, 1);
    V v_st_2433 = heff_get_n(v_ps_240, 5, 6);
    V v_t_2434 = (g_std_2epath_2eparse(heff_dup(v_st_2433), heff_dup(v_x_2421)));
    V v_t_2435 = (g_std_2epath_2eparse(heff_dup(v_st_2433), ((V)&g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_str1)));
    V v_t_2436 = (g_std_2epath_2ejoin(v_t_2434, v_t_2435));
    V v_t_2437 = ({ V a_0 = v_st_2433; V a_1 = v_t_2436; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2433); heff_drop(v_t_2436); r_; });
    V v_t_2438 = (g_list_2emap_24s18996220x10511024(v_require_245));
    v_x_2439 = heff_tag_at_n(v_ru_24x_2430_24Right, TAG_Right, 1, (V[]){heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){v_path_246, v_x_2421, v_t_2437, heff_dup(v_name_2432), v_name_2432, v_heff_244, v_t_2438})});
    break;
  }
  default: heff_nomatch(v_x_2430);
  }
  V f_ = v_k_2423;
  args[0] = v_x_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_lam0(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_ps_240 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_require_245 = heff_env(self)[2];
  V v_path_246 = heff_env(self)[3];
  V v_heff_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2424 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_t_2425 = (g_std_2epath_2eparse(heff_dup(v_st_2424), heff_dup(v_x_2421)));
  V v_t_2426 = (g_std_2epath_2eparse(heff_dup(v_st_2424), ((V)&g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_str0)));
  V v_t_2427 = (g_std_2epath_2ejoin(v_t_2425, v_t_2426));
  V v_t_2428 = ({ V a_0 = v_st_2424; V a_1 = v_t_2427; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2424); heff_drop(v_t_2427); r_; });
  V v_c_2429 = (g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056(heff_dup(v_ps_240), v_t_2428));
  V f_ = v_c_2429;
  args[0] = v_hd_2422;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_lam1, 1, 6, (V[]){v_ps_240, v_x_2421, v_require_245, v_path_246, v_heff_244, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_str0, 1, " ");
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_entry, 5, 0};

V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152(V v_rd_240, V v_root_241, V v_x3_242, V v_seen_243, V v_errs_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_rd_240);
    return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_lam0, 2, 2, (V[]){v_seen_243, v_errs_244});
  }
  case TAG_Cons: {
    V v_n_247 = heff_field(v_x3_242, 0);
    V v_rest_248 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_path_249 = heff_take_field(v_n_247, 1);
    V v_version_2410 = heff_take_field(v_n_247, 2);
    V v_by_2411 = heff_get_n(v_n_247, 0, 3);
    if (heff_strEq_c_lent(v_path_249, v_root_241, 0)) {
      heff_drop(v_path_249);
      heff_drop(v_version_2410);
      heff_drop(v_by_2411);
      V t_0 = v_rd_240;
      V t_1 = v_root_241;
      V t_2 = v_rest_248;
      V t_3 = v_seen_243;
      V t_4 = v_errs_244;
      v_rd_240 = t_0;
      v_root_241 = t_1;
      v_x3_242 = t_2;
      v_seen_243 = t_3;
      v_errs_244 = t_4;
      goto top;
    } else {
      V v_t_2412 = (g_list_2eany_24s241416889x826324235(v_path_249, v_version_2410, v_seen_243));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_path_249);
        heff_drop(v_version_2410);
        heff_drop(v_by_2411);
        heff_drop(v_t_2412);
        V t_0 = v_rd_240;
        V t_1 = v_root_241;
        V t_2 = v_rest_248;
        V t_3 = v_seen_243;
        V t_4 = v_errs_244;
        v_rd_240 = t_0;
        v_root_241 = t_1;
        v_x3_242 = t_2;
        v_seen_243 = t_3;
        v_errs_244 = t_4;
        goto top;
      } else {
        heff_drop(v_t_2412);
        V v_c_2413 = heff_tr(heff_call(heff_dup(v_rd_240), 3, (V[]){v_by_2411, heff_dup(v_path_249), heff_dup(v_version_2410)}));
        return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_lam1, 2, 8, (V[]){v_c_2413, v_path_249, v_version_2410, v_seen_243, v_errs_244, v_rd_240, heff_dup(v_root_241), v_rest_248});
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_seen_243 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_seen_243, v_errs_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_path_249 = heff_env(self)[0];
  V v_version_2410 = heff_env(self)[1];
  V v_seen_243 = heff_env(self)[2];
  V v_errs_244 = heff_env(self)[3];
  V v_rd_240 = heff_env(self)[4];
  V v_root_241 = heff_env(self)[5];
  V v_rest_248 = heff_env(self)[6];
  V v_hd_2414 = heff_env(self)[7];
  V v_k_2415 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_why_2417 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    V v_t_2418 = heff_rec_n(3, shape_path__version__pkg, (V[]){v_path_249, v_version_2410, NTAG(TAG_Nothing)});
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
    V v_t_2420 = (g_prelude_2e_2b_2b(v_seen_243, v_t_2419));
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2417, NTAG(TAG_Nil)});
    V v_t_2422 = (g_prelude_2e_2b_2b(v_errs_244, v_t_2421));
    V v_t_2423 = ({ V a_0 = v_rd_240; V a_1 = v_root_241; V a_2 = v_rest_248; V a_3 = v_t_2420; V a_4 = v_t_2422; V r_ = (g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_root_241); r_; });
    V f_ = v_t_2423;
    heff_room[0] = v_hd_2414;
    heff_room[1] = v_k_2415;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_pk_2424 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    V v_t_2425 = heff_strAppend(heff_strAppend(heff_dup(v_path_249), ((V)&g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_str0)), heff_dup(v_version_2410));
    V v_t_2426 = (g_list_2emap_24s675147852x248982264(v_t_2425, heff_dup(heff_rfield(v_pk_2424, 2))));
    V v_t_2427 = (g_prelude_2e_2b_2b(v_rest_248, v_t_2426));
    V v_t_2428 = heff_rec_n(3, shape_path__version__pkg, (V[]){v_path_249, v_version_2410, heff_tag_n(TAG_Just, 1, (V[]){v_pk_2424})});
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
    V v_t_2430 = (g_prelude_2e_2b_2b(v_seen_243, v_t_2429));
    V v_t_2431 = ({ V a_0 = v_rd_240; V a_1 = v_root_241; V a_2 = v_t_2427; V a_3 = v_t_2430; V a_4 = v_errs_244; V r_ = (g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_root_241); r_; });
    V f_ = v_t_2431;
    heff_room[0] = v_hd_2414;
    heff_room[1] = v_k_2415;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_path_249 = heff_env(self)[1];
  V v_version_2410 = heff_env(self)[2];
  V v_seen_243 = heff_env(self)[3];
  V v_errs_244 = heff_env(self)[4];
  V v_rd_240 = heff_env(self)[5];
  V v_root_241 = heff_env(self)[6];
  V v_rest_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_lam2, 1, 9, (V[]){v_path_249, v_version_2410, v_seen_243, v_errs_244, v_rd_240, v_root_241, v_rest_248, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str0, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str2, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str3, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str4, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str5, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str7, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str8, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str9, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str10, 2, ": ");
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_entry, 9, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(V v_lit_240, V v_read_241, V v_ps_242, V v_pkgs_243, V v_stack_244, V v_from_245, V v_x7_246, V v_st_247, V v_rs_248) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_read_241);
    heff_drop(v_ps_242);
    heff_drop(v_pkgs_243);
    heff_drop(v_stack_244);
    heff_drop(v_from_245);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam0, 2, 2, (V[]){v_st_247, v_rs_248});
  }
  case TAG_Cons: {
    V v_w_2411 = heff_field(v_x7_246, 0);
    V v_rest_2412 = heff_field(v_x7_246, 1);
    heff_take_n(v_x7_246, 3ULL, 2);
    V v_t_2413 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_242), heff_dup(v_pkgs_243), heff_dup(v_from_245), heff_dup(v_w_2411)));
    V v_c_2414 = (g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749(heff_dup(v_read_241), v_t_2413));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam1, 2, 11, (V[]){v_c_2414, v_ps_242, v_pkgs_243, v_from_245, v_w_2411, v_st_247, v_lit_240, v_read_241, v_stack_244, v_rest_2412, v_rs_248});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_st_247 = heff_env(self)[0];
  V v_rs_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_247, v_rs_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam4(V self, V *args) {
  V v_x_2472 = args[0];
  V v_ps_242 = heff_env(self)[0];
  V v_module_2432 = heff_env(self)[1];
  V v_named_2436 = heff_env(self)[2];
  V v_path_2434 = heff_env(self)[3];
  V v_source_2435 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_w_2411 = heff_env(self)[6];
  V v_rs_248 = heff_env(self)[7];
  V v_read_241 = heff_env(self)[8];
  V v_pkgs_243 = heff_env(self)[9];
  V v_stack_244 = heff_env(self)[10];
  V v_from_245 = heff_env(self)[11];
  V v_rest_2412 = heff_env(self)[12];
  V v_hd_2415 = heff_env(self)[13];
  V v_k_2416 = heff_env(self)[14];
  heff_clo_take(self, 15);
  V v_t_2475;
  switch (heff_tag_of(v_x_2472)) {
  case TAG_MkPair: {
    V v_x_2473 = heff_dup(heff_field(v_x_2472, 0));
    v_t_2475 = v_x_2473;
    break;
  }
  default: heff_nomatch(v_x_2472);
  }
  V v_t_2478;
  switch (heff_tag_of(v_x_2472)) {
  case TAG_MkPair: {
    V v_y_2477 = heff_field(v_x_2472, 1);
    heff_take_n(v_x_2472, 2ULL, 2);
    v_t_2478 = v_y_2477;
    break;
  }
  default: heff_nomatch(v_x_2472);
  }
  V v_t_2479 = (g_heff_2ebuild_2eload_2epushDone(v_t_2475, heff_dup(v_ps_242), heff_dup(v_module_2432), v_named_2436, v_path_2434, v_source_2435, heff_dup(v_lit_240), v_t_2478));
  V v_m_2480 = v_module_2432;
  V v_t_2481;
  if (heff_strEq_c_lent(v_w_2411, v_m_2480, 0)) {
    heff_drop(v_w_2411);
    heff_drop(v_m_2480);
    v_t_2481 = v_rs_248;
  } else {
    v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2480}), v_rs_248});
  }
  V v_t_2482 = (g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2479, v_t_2481));
  V f_ = v_t_2482;
  heff_room[0] = v_hd_2415;
  heff_room[1] = v_k_2416;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam3(V self, V *args) {
  V v_x_2460 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_source_2435 = heff_env(self)[1];
  V v_st_247 = heff_env(self)[2];
  V v_from_245 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_read_241 = heff_env(self)[5];
  V v_ps_242 = heff_env(self)[6];
  V v_pkgs_243 = heff_env(self)[7];
  V v_module_2432 = heff_env(self)[8];
  V v_stack_244 = heff_env(self)[9];
  V v_path_2434 = heff_env(self)[10];
  V v_hd_2415 = heff_env(self)[11];
  V v_named_2436 = heff_env(self)[12];
  V v_rs_248 = heff_env(self)[13];
  V v_rest_2412 = heff_env(self)[14];
  V v_k_2416 = heff_env(self)[15];
  heff_clo_take(self, 16);
  V v_t_2461 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(v_lit_240), heff_dup(v_source_2435)));
  V v_imps_2462 = heff_get_n(v_t_2461, 0, 4);
  V v_t_2463 = (g_list_2emap_24s1817208647x1282894070(v_imps_2462));
  V v_t_2464 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2463));
  V v_t_2470;
  switch (heff_tag_of(v_x_2460)) {
  case TAG_Nothing: {
    v_t_2470 = v_st_247;
    break;
  }
  case TAG_Just: {
    V v_why_2465 = heff_field(v_x_2460, 0);
    heff_take_n(v_x_2460, 1ULL, 1);
    V v_t_2466 = heff_strAppend(heff_strAppend(heff_dup(v_from_245), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str9)), heff_dup(v_w_2411));
    V v_t_2467 = heff_strAppend(heff_strAppend(v_t_2466, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str10)), v_why_2465);
    V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
    V v_t_2469 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2468));
    v_t_2470 = ({ V rv_2 = v_t_2469; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2460);
  }
  V v_c_2471 = (g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(heff_dup(v_lit_240), heff_dup(v_read_241), heff_dup(v_ps_242), heff_dup(v_pkgs_243), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2432), heff_dup(v_stack_244)}), heff_dup(v_path_2434), v_t_2464, v_t_2470, NTAG(TAG_Nil)));
  V f_ = v_c_2471;
  heff_room[0] = heff_dup(v_hd_2415);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam4, 1, 15, (V[]){v_ps_242, v_module_2432, v_named_2436, v_path_2434, v_source_2435, v_lit_240, v_w_2411, v_rs_248, v_read_241, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ps_242 = heff_env(self)[0];
  V v_pkgs_243 = heff_env(self)[1];
  V v_from_245 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_st_247 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_read_241 = heff_env(self)[6];
  V v_stack_244 = heff_env(self)[7];
  V v_rest_2412 = heff_env(self)[8];
  V v_rs_248 = heff_env(self)[9];
  V v_hd_2415 = heff_env(self)[10];
  V v_k_2416 = heff_env(self)[11];
  heff_clo_take(self, 12);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nil: {
    V v_places_2418 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_242), heff_dup(v_pkgs_243), heff_dup(v_from_245), heff_dup(v_w_2411)));
    V v_t_2419 = heff_strAppend(heff_strAppend(heff_dup(v_from_245), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str0)), v_w_2411);
    V v_x2_2420 = (g_list_2emap_24s435407392x1528135477(v_places_2418));
    V v_t_2423;
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_Nil: {
      v_t_2423 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_xs_2422 = heff_field(v_x2_2420, 1);
      heff_take_n(v_x2_2420, 3ULL, 2);
      v_t_2423 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str2); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2420);
    }
    V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str3)), v_t_2423);
    V v_e_2425 = heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str4));
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2425, NTAG(TAG_Nil)});
    V v_t_2427 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2426));
    V v_t_2428 = ({ V rv_2 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2429 = (g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2428, v_rs_248));
    V f_ = v_t_2429;
    heff_room[0] = v_hd_2415;
    heff_room[1] = v_k_2416;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2430 = heff_dup(heff_field(v_x_2417, 0));
    V v_others_2431 = heff_dup(heff_field(v_x_2417, 1));
    V v_module_2432 = heff_take_field(v_f_2430, 3);
    V v_place_2433 = heff_take_field(v_f_2430, 2);
    V v_path_2434 = heff_take_field(v_f_2430, 0);
    V v_source_2435 = heff_take_field(v_f_2430, 1);
    V v_named_2436 = heff_get_n(v_f_2430, 4, 5);
    V v_t_2437 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_module_2432)}));
    V v_t_2438 = (g_list_2eany(v_t_2437, heff_rfield(v_st_247, 1)));
    if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2417, 2);
      heff_drop(v_others_2431);
      heff_drop_rec(v_place_2433, 4);
      heff_drop(v_path_2434);
      heff_drop(v_source_2435);
      heff_drop(v_named_2436);
      heff_drop(v_t_2438);
      V v_m_2439 = v_module_2432;
      V v_t_2440;
      if (heff_strEq_c_lent(v_w_2411, v_m_2439, 0)) {
        heff_drop(v_w_2411);
        heff_drop(v_m_2439);
        v_t_2440 = v_rs_248;
      } else {
        v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2439}), v_rs_248});
      }
      V v_t_2441 = (g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_st_247, v_t_2440));
      V f_ = v_t_2441;
      heff_room[0] = v_hd_2415;
      heff_room[1] = v_k_2416;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2438);
      V v_t_2442 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_module_2432)}));
      V v_t_2443 = (g_list_2eany(v_t_2442, v_stack_244));
      if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2417, 2);
        heff_drop(v_others_2431);
        heff_drop_rec(v_place_2433, 4);
        heff_drop(v_path_2434);
        heff_drop(v_source_2435);
        heff_drop(v_named_2436);
        heff_drop(v_t_2443);
        V v_m_2444 = heff_dup(v_module_2432);
        V v_t_2445 = heff_strAppend(heff_strAppend(heff_dup(v_from_245), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str5)), heff_dup(v_m_2444));
        V v_t_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_244)));
        V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_2444, NTAG(TAG_Nil)});
        V v_x2_2448 = (g_prelude_2e_2b_2b(v_t_2446, v_t_2447));
        V v_t_2451;
        switch (heff_tag_of(v_x2_2448)) {
        case TAG_Nil: {
          v_t_2451 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str6);
          break;
        }
        case TAG_Cons: {
          V v_x_2449 = heff_field(v_x2_2448, 0);
          V v_xs_2450 = heff_field(v_x2_2448, 1);
          heff_take_n(v_x2_2448, 3ULL, 2);
          v_t_2451 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str7); V a_1 = v_x_2449; V a_2 = v_xs_2450; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2450); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2448);
        }
        V v_e_2452 = heff_strAppend(heff_strAppend(v_t_2445, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str8)), v_t_2451);
        V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2452, NTAG(TAG_Nil)});
        V v_t_2454 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2453));
        V v_t_2455 = ({ V rv_2 = v_t_2454; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2456 = v_module_2432;
        V v_t_2457;
        if (heff_strEq_c_lent(v_w_2411, v_m_2456, 0)) {
          heff_drop(v_w_2411);
          heff_drop(v_m_2456);
          v_t_2457 = v_rs_248;
        } else {
          v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2456}), v_rs_248});
        }
        V v_t_2458 = (g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2455, v_t_2457));
        V f_ = v_t_2458;
        heff_room[0] = v_hd_2415;
        heff_room[1] = v_k_2416;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2443);
        switch (heff_tag_of(v_others_2431)) {
        case TAG_Nil: {
          heff_drop_tag(v_x_2417, 2);
          V v_c_2459 = (g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971(heff_dup(v_ps_242), heff_take_field(v_place_2433, 1), heff_get_n(v_place_2433, 2, 4)));
          V f_ = v_c_2459;
          heff_room[0] = heff_dup(v_hd_2415);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam3, 1, 16, (V[]){v_lit_240, v_source_2435, v_st_247, v_from_245, v_w_2411, v_read_241, v_ps_242, v_pkgs_243, v_module_2432, v_stack_244, v_path_2434, v_hd_2415, v_named_2436, v_rs_248, v_rest_2412, v_k_2416});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_Cons: {
          V v_ru_24others_2431_24Cons = heff_take_reuse_n(v_others_2431, 0ULL, 2);
          heff_drop_rec(v_place_2433, 4);
          heff_drop(v_path_2434);
          heff_drop(v_source_2435);
          heff_drop(v_named_2436);
          V v_e_2485 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_242), v_x_2417, heff_dup(v_from_245), heff_dup(v_w_2411)));
          V v_t_2486 = heff_take_field(v_st_247, 0);
          V v_t_2487 = heff_take_field(v_st_247, 1);
          V v_t_2488 = heff_tag_at_n(v_ru_24others_2431_24Cons, TAG_Cons, 2, (V[]){v_e_2485, NTAG(TAG_Nil)});
          V v_t_2489 = (g_prelude_2e_2b_2b(heff_get_n(v_st_247, 2, 3), v_t_2488));
          V v_t_2490 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){v_t_2486, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2432), v_t_2487}), v_t_2489});
          V v_m_2491 = v_module_2432;
          V v_t_2492;
          if (heff_strEq_c_lent(v_w_2411, v_m_2491, 0)) {
            heff_drop(v_w_2411);
            heff_drop(v_m_2491);
            v_t_2492 = v_rs_248;
          } else {
            v_t_2492 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2491}), v_rs_248});
          }
          V v_t_2493 = (g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2490, v_t_2492));
          V f_ = v_t_2493;
          heff_room[0] = v_hd_2415;
          heff_room[1] = v_k_2416;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_others_2431);
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_ps_242 = heff_env(self)[1];
  V v_pkgs_243 = heff_env(self)[2];
  V v_from_245 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_st_247 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  V v_read_241 = heff_env(self)[7];
  V v_stack_244 = heff_env(self)[8];
  V v_rest_2412 = heff_env(self)[9];
  V v_rs_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam2, 1, 12, (V[]){v_ps_242, v_pkgs_243, v_from_245, v_w_2411, v_st_247, v_lit_240, v_read_241, v_stack_244, v_rest_2412, v_rs_248, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str0, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str2, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str3, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str4, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str5, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str7, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str8, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str9, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str10, 2, ": ");
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_entry, 9, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(V v_read_240, V v_ps_241, V v_pkgs_242, V v_stack_243, V v_from_244, V v_imp_245, V v_x7_246, V v_st_247, V v_rs_248) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_stack_243);
    heff_drop(v_from_244);
    heff_drop(v_imp_245);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam0, 2, 2, (V[]){v_st_247, v_rs_248});
  }
  case TAG_Cons: {
    V v_w_2411 = heff_field(v_x7_246, 0);
    V v_rest_2412 = heff_field(v_x7_246, 1);
    heff_take_n(v_x7_246, 3ULL, 2);
    V v_t_2413 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2411)));
    V v_c_2414 = (g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749(heff_dup(v_read_240), v_t_2413));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam1, 2, 11, (V[]){v_c_2414, v_ps_241, v_pkgs_242, v_from_244, v_w_2411, v_st_247, v_read_240, v_stack_243, v_imp_245, v_rest_2412, v_rs_248});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_st_247 = heff_env(self)[0];
  V v_rs_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_247, v_rs_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam4(V self, V *args) {
  V v_x_2473 = args[0];
  V v_imp_245 = heff_env(self)[0];
  V v_module_2432 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_named_2436 = heff_env(self)[3];
  V v_path_2434 = heff_env(self)[4];
  V v_source_2435 = heff_env(self)[5];
  V v_w_2411 = heff_env(self)[6];
  V v_rs_248 = heff_env(self)[7];
  V v_read_240 = heff_env(self)[8];
  V v_pkgs_242 = heff_env(self)[9];
  V v_stack_243 = heff_env(self)[10];
  V v_from_244 = heff_env(self)[11];
  V v_rest_2412 = heff_env(self)[12];
  V v_hd_2415 = heff_env(self)[13];
  V v_k_2416 = heff_env(self)[14];
  heff_clo_take(self, 15);
  V v_t_2476;
  switch (heff_tag_of(v_x_2473)) {
  case TAG_MkPair: {
    V v_x_2474 = heff_dup(heff_field(v_x_2473, 0));
    v_t_2476 = v_x_2474;
    break;
  }
  default: heff_nomatch(v_x_2473);
  }
  V v_t_2477 = heff_tr(heff_call(heff_dup(v_imp_245), 1, (V[]){heff_dup(v_module_2432)}));
  V v_t_2480;
  switch (heff_tag_of(v_x_2473)) {
  case TAG_MkPair: {
    V v_y_2479 = heff_field(v_x_2473, 1);
    heff_take_n(v_x_2473, 2ULL, 2);
    v_t_2480 = v_y_2479;
    break;
  }
  default: heff_nomatch(v_x_2473);
  }
  V v_t_2481 = (g_heff_2ebuild_2eload_2epushDone(v_t_2476, heff_dup(v_ps_241), heff_dup(v_module_2432), v_named_2436, v_path_2434, v_source_2435, v_t_2477, v_t_2480));
  V v_m_2482 = v_module_2432;
  V v_t_2483;
  if (heff_strEq_c_lent(v_w_2411, v_m_2482, 0)) {
    heff_drop(v_w_2411);
    heff_drop(v_m_2482);
    v_t_2483 = v_rs_248;
  } else {
    v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2482}), v_rs_248});
  }
  V v_t_2484 = (g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2481, v_t_2483));
  V f_ = v_t_2484;
  heff_room[0] = v_hd_2415;
  heff_room[1] = v_k_2416;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam3(V self, V *args) {
  V v_x_2460 = args[0];
  V v_imp_245 = heff_env(self)[0];
  V v_module_2432 = heff_env(self)[1];
  V v_source_2435 = heff_env(self)[2];
  V v_st_247 = heff_env(self)[3];
  V v_from_244 = heff_env(self)[4];
  V v_w_2411 = heff_env(self)[5];
  V v_read_240 = heff_env(self)[6];
  V v_ps_241 = heff_env(self)[7];
  V v_pkgs_242 = heff_env(self)[8];
  V v_stack_243 = heff_env(self)[9];
  V v_path_2434 = heff_env(self)[10];
  V v_hd_2415 = heff_env(self)[11];
  V v_named_2436 = heff_env(self)[12];
  V v_rs_248 = heff_env(self)[13];
  V v_rest_2412 = heff_env(self)[14];
  V v_k_2416 = heff_env(self)[15];
  heff_clo_take(self, 16);
  V v_t_2461 = heff_tr(heff_call(heff_dup(v_imp_245), 1, (V[]){heff_dup(v_module_2432)}));
  V v_t_2462 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2461, heff_dup(v_source_2435)));
  V v_imps_2463 = heff_get_n(v_t_2462, 0, 4);
  V v_t_2464 = (g_list_2emap_24s1817208647x1282894070(v_imps_2463));
  V v_t_2465 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2464));
  V v_t_2471;
  switch (heff_tag_of(v_x_2460)) {
  case TAG_Nothing: {
    v_t_2471 = v_st_247;
    break;
  }
  case TAG_Just: {
    V v_why_2466 = heff_field(v_x_2460, 0);
    heff_take_n(v_x_2460, 1ULL, 1);
    V v_t_2467 = heff_strAppend(heff_strAppend(heff_dup(v_from_244), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str9)), heff_dup(v_w_2411));
    V v_t_2468 = heff_strAppend(heff_strAppend(v_t_2467, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str10)), v_why_2466);
    V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2468, NTAG(TAG_Nil)});
    V v_t_2470 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2469));
    v_t_2471 = ({ V rv_2 = v_t_2470; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2460);
  }
  V v_c_2472 = (g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(heff_dup(v_read_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2432), heff_dup(v_stack_243)}), heff_dup(v_path_2434), heff_dup(v_imp_245), v_t_2465, v_t_2471, NTAG(TAG_Nil)));
  V f_ = v_c_2472;
  heff_room[0] = heff_dup(v_hd_2415);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam4, 1, 15, (V[]){v_imp_245, v_module_2432, v_ps_241, v_named_2436, v_path_2434, v_source_2435, v_w_2411, v_rs_248, v_read_240, v_pkgs_242, v_stack_243, v_from_244, v_rest_2412, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_pkgs_242 = heff_env(self)[1];
  V v_from_244 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_st_247 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_stack_243 = heff_env(self)[6];
  V v_imp_245 = heff_env(self)[7];
  V v_rest_2412 = heff_env(self)[8];
  V v_rs_248 = heff_env(self)[9];
  V v_hd_2415 = heff_env(self)[10];
  V v_k_2416 = heff_env(self)[11];
  heff_clo_take(self, 12);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nil: {
    V v_places_2418 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2411)));
    V v_t_2419 = heff_strAppend(heff_strAppend(heff_dup(v_from_244), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str0)), v_w_2411);
    V v_x2_2420 = (g_list_2emap_24s435407392x1528135477(v_places_2418));
    V v_t_2423;
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_Nil: {
      v_t_2423 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_xs_2422 = heff_field(v_x2_2420, 1);
      heff_take_n(v_x2_2420, 3ULL, 2);
      v_t_2423 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str2); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2420);
    }
    V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str3)), v_t_2423);
    V v_e_2425 = heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str4));
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2425, NTAG(TAG_Nil)});
    V v_t_2427 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2426));
    V v_t_2428 = ({ V rv_2 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2429 = (g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2428, v_rs_248));
    V f_ = v_t_2429;
    heff_room[0] = v_hd_2415;
    heff_room[1] = v_k_2416;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2430 = heff_dup(heff_field(v_x_2417, 0));
    V v_others_2431 = heff_dup(heff_field(v_x_2417, 1));
    V v_module_2432 = heff_take_field(v_f_2430, 3);
    V v_place_2433 = heff_take_field(v_f_2430, 2);
    V v_path_2434 = heff_take_field(v_f_2430, 0);
    V v_source_2435 = heff_take_field(v_f_2430, 1);
    V v_named_2436 = heff_get_n(v_f_2430, 4, 5);
    V v_t_2437 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_module_2432)}));
    V v_t_2438 = (g_list_2eany(v_t_2437, heff_rfield(v_st_247, 1)));
    if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2417, 2);
      heff_drop(v_others_2431);
      heff_drop_rec(v_place_2433, 4);
      heff_drop(v_path_2434);
      heff_drop(v_source_2435);
      heff_drop(v_named_2436);
      heff_drop(v_t_2438);
      V v_m_2439 = v_module_2432;
      V v_t_2440;
      if (heff_strEq_c_lent(v_w_2411, v_m_2439, 0)) {
        heff_drop(v_w_2411);
        heff_drop(v_m_2439);
        v_t_2440 = v_rs_248;
      } else {
        v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2439}), v_rs_248});
      }
      V v_t_2441 = (g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_st_247, v_t_2440));
      V f_ = v_t_2441;
      heff_room[0] = v_hd_2415;
      heff_room[1] = v_k_2416;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2438);
      V v_t_2442 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_module_2432)}));
      V v_t_2443 = (g_list_2eany(v_t_2442, v_stack_243));
      if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2417, 2);
        heff_drop(v_others_2431);
        heff_drop_rec(v_place_2433, 4);
        heff_drop(v_path_2434);
        heff_drop(v_source_2435);
        heff_drop(v_named_2436);
        heff_drop(v_t_2443);
        V v_m_2444 = heff_dup(v_module_2432);
        V v_t_2445 = heff_strAppend(heff_strAppend(heff_dup(v_from_244), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str5)), heff_dup(v_m_2444));
        V v_t_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_243)));
        V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_2444, NTAG(TAG_Nil)});
        V v_x2_2448 = (g_prelude_2e_2b_2b(v_t_2446, v_t_2447));
        V v_t_2451;
        switch (heff_tag_of(v_x2_2448)) {
        case TAG_Nil: {
          v_t_2451 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str6);
          break;
        }
        case TAG_Cons: {
          V v_x_2449 = heff_field(v_x2_2448, 0);
          V v_xs_2450 = heff_field(v_x2_2448, 1);
          heff_take_n(v_x2_2448, 3ULL, 2);
          v_t_2451 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str7); V a_1 = v_x_2449; V a_2 = v_xs_2450; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2450); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2448);
        }
        V v_e_2452 = heff_strAppend(heff_strAppend(v_t_2445, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str8)), v_t_2451);
        V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2452, NTAG(TAG_Nil)});
        V v_t_2454 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2453));
        V v_t_2455 = ({ V rv_2 = v_t_2454; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2456 = v_module_2432;
        V v_t_2457;
        if (heff_strEq_c_lent(v_w_2411, v_m_2456, 0)) {
          heff_drop(v_w_2411);
          heff_drop(v_m_2456);
          v_t_2457 = v_rs_248;
        } else {
          v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2456}), v_rs_248});
        }
        V v_t_2458 = (g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2455, v_t_2457));
        V f_ = v_t_2458;
        heff_room[0] = v_hd_2415;
        heff_room[1] = v_k_2416;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2443);
        switch (heff_tag_of(v_others_2431)) {
        case TAG_Nil: {
          heff_drop_tag(v_x_2417, 2);
          V v_c_2459 = (g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971(heff_dup(v_ps_241), heff_take_field(v_place_2433, 1), heff_get_n(v_place_2433, 2, 4)));
          V f_ = v_c_2459;
          heff_room[0] = heff_dup(v_hd_2415);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam3, 1, 16, (V[]){v_imp_245, v_module_2432, v_source_2435, v_st_247, v_from_244, v_w_2411, v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_path_2434, v_hd_2415, v_named_2436, v_rs_248, v_rest_2412, v_k_2416});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_Cons: {
          V v_ru_24others_2431_24Cons = heff_take_reuse_n(v_others_2431, 0ULL, 2);
          heff_drop_rec(v_place_2433, 4);
          heff_drop(v_path_2434);
          heff_drop(v_source_2435);
          heff_drop(v_named_2436);
          V v_e_2487 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_241), v_x_2417, heff_dup(v_from_244), heff_dup(v_w_2411)));
          V v_t_2488 = heff_take_field(v_st_247, 0);
          V v_t_2489 = heff_take_field(v_st_247, 1);
          V v_t_2490 = heff_tag_at_n(v_ru_24others_2431_24Cons, TAG_Cons, 2, (V[]){v_e_2487, NTAG(TAG_Nil)});
          V v_t_2491 = (g_prelude_2e_2b_2b(heff_get_n(v_st_247, 2, 3), v_t_2490));
          V v_t_2492 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){v_t_2488, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2432), v_t_2489}), v_t_2491});
          V v_m_2493 = v_module_2432;
          V v_t_2494;
          if (heff_strEq_c_lent(v_w_2411, v_m_2493, 0)) {
            heff_drop(v_w_2411);
            heff_drop(v_m_2493);
            v_t_2494 = v_rs_248;
          } else {
            v_t_2494 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2493}), v_rs_248});
          }
          V v_t_2495 = (g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2492, v_t_2494));
          V f_ = v_t_2495;
          heff_room[0] = v_hd_2415;
          heff_room[1] = v_k_2416;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_others_2431);
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_pkgs_242 = heff_env(self)[2];
  V v_from_244 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_st_247 = heff_env(self)[5];
  V v_read_240 = heff_env(self)[6];
  V v_stack_243 = heff_env(self)[7];
  V v_imp_245 = heff_env(self)[8];
  V v_rest_2412 = heff_env(self)[9];
  V v_rs_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam2, 1, 12, (V[]){v_ps_241, v_pkgs_242, v_from_244, v_w_2411, v_st_247, v_read_240, v_stack_243, v_imp_245, v_rest_2412, v_rs_248, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}