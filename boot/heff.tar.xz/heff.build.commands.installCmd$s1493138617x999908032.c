// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_WriteErr 37283
#define LBL_bin 307073
#define LBL_module 878357911
#define LBL_opt 319789
#define LBL_pages 307784670
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_shipTo 1043811586
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_clo;
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_clo;
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_str0, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_str1, 9, "installed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_str2, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_str3, 31, "heff install: no package.hf in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_str5, 7, "install");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_str6, 29, "heff install: no programs in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_str7, 41, ": app/X/ with a build.hf is the program X");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_str8, 1, "\012");
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0(V v_dir_240, V v_st_241, V v_x_242, V v_hd_243, V v_k_244, V v_x_245) {
top: ;
  V v_x_248;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    heff_take_n(v_x_245, 0ULL, 1);
    v_x_248 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_247 = heff_field(v_x_245, 0);
    V v_ru_24x_245_24Right = heff_take_reuse_n(v_x_245, 1ULL, 1);
    v_x_248 = heff_tag_at_n(v_ru_24x_245_24Right, TAG_Just, 1, (V[]){v_y_247});
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(v_x_242)));
  V v_t_2410 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_str0)));
  V v_t_2411 = (g_std_2epath_2ejoin(v_t_249, v_t_2410));
  V v_t_2412 = ({ V a_0 = v_st_241; V a_1 = v_t_2411; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2411); r_; });
  V v_x_2413 = heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){heff_dup(v_dir_240), v_t_2412, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_str1), NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)}), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_str2)});
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    heff_drop(v_st_241);
    heff_drop(v_x_242);
    heff_drop_rec(v_x_2413, 6);
    V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_str3), v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_str4));
    V v_t_2415 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2414, NTAG(TAG_MkUnit)});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_lam0, 1, 2, (V[]){v_hd_243, v_k_244})));
  }
  case TAG_Just: {
    V v_t_2441;
    switch (heff_tag_of(v_x_248)) {
    case TAG_Nothing: {
      heff_drop(v_x_242);
      v_t_2441 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_clo), 2, (V[]){heff_dup(v_st_241), heff_dup(heff_rfield(v_x_2413, 1))}));
      break;
    }
    case TAG_Just: {
      V v_text_2429 = heff_field(v_x_248, 0);
      heff_take_n(v_x_248, 1ULL, 1);
      HeffT2 v_t_2430 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_text_2429));
      {
        V v_field_2432 = v_t_2430.f[1];
        int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
        if ((v_tag_2431 == ((int64_t)0ULL))) {
          heff_drop(v_x_242);
          V v_p_2433 = v_field_2432;
          heff_drop(v_p_2433);
          v_t_2441 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_clo), 2, (V[]){heff_dup(v_st_241), heff_dup(heff_rfield(v_x_2413, 1))}));
        } else {
          V v_x_2434 = v_field_2432;
          HeffT2 v_t_2435 = ({ V a_0 = v_x_2434; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_2434); r_; });
          {
            V v_field_2437 = v_t_2435.f[1];
            int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
            if ((v_tag_2436 == ((int64_t)0ULL))) {
              heff_drop(v_x_242);
              V v_x11_2438 = v_field_2437;
              heff_drop(v_x11_2438);
              v_t_2441 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_clo), 2, (V[]){heff_dup(v_st_241), heff_dup(heff_rfield(v_x_2413, 1))}));
            } else {
              V v_pk_2439 = v_field_2437;
              if (heff_strEq_c(heff_get_n(v_pk_2439, 0, 4), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
                V v_t_2440 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_clo), 2, (V[]){heff_dup(v_st_241), heff_dup(heff_rfield(v_x_2413, 1))}));
                v_t_2441 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_clo), 5, (V[]){heff_dup(v_st_241), heff_dup(v_x_2413), v_x_242, heff_dup(v_dir_240), v_t_2440}));
              } else {
                heff_drop(v_x_242);
                v_t_2441 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_clo), 2, (V[]){heff_dup(v_st_241), heff_dup(heff_rfield(v_x_2413, 1))}));
              }
            }
          }
        }
      }
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    return (g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599(v_st_241, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_str5), v_x_2413, heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_lam1, 2, 1, (V[]){v_dir_240}), v_t_2441, v_hd_243, v_k_244));
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_lam0(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_drop(v_x_2421);
  V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_lam2(V self, V *args) {
  V v_x_2451 = args[0];
  V v_hd_2442 = heff_env(self)[0];
  V v_k_2443 = heff_env(self)[1];
  heff_drop(v_x_2451);
  V v_t_2452 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2457}), v_hd_2442, v_k_2443));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_lam1(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  V v_dir_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2444 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_str6), v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_str7));
  V v_t_2445 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2444, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_str8)), NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2450}), heff_dup(v_hd_2442), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_lam2, 1, 2, (V[]){v_hd_2442, v_k_2443})));
}