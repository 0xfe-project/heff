// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_heff_2elower_2elowerSimplified_lam0(V self, V *args);
V g_heff_2elower_2elowerSimplified_lam1(V self, V *args);
Clo g_heff_2elower_2elowerSimplified_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elower_2elowerSimplified_entry, 3, 0};

V g_heff_2elower_2elowerSimplified(V v_roots_240, V v_errors_241, V v_si_242) {
top: ;
  V v_defs_243 = heff_get(v_si_242, LBL_defs);
  V v_t_244 = (g_prelude_2efoldl_24s569(heff_dup(g_map_2eempty_get()), v_defs_243));
  V v_reached_245 = ({ V a_0 = v_t_244; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_roots_240; V r_ = (g_heff_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  V v_kept_249 = (g_prelude_2efilter(heff_clo(g_heff_2elower_2elowerSimplified_lam0, 1, 1, (V[]){v_reached_245}), v_defs_243));
  V v_ar_2410 = (g_prelude_2efoldl_24s533(heff_dup(g_map_2eempty_get()), v_kept_249));
  V v_t_2414 = (g_prelude_2emap(heff_clo(g_heff_2elower_2elowerSimplified_lam1, 1, 1, (V[]){v_ar_2410}), v_kept_249));
  return heff_rec(2, shape_59_89, (V[]){v_t_2414, v_errors_241});
}
V g_heff_2elower_2elowerSimplified_entry(V self, V *a) {
  (void)self;
  return g_heff_2elower_2elowerSimplified(a[0], a[1], a[2]);
}
V g_heff_2elower_2elowerSimplified_lam0(V self, V *args) {
  V v_d_246 = args[0];
  V v_reached_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_247 = ({ V a_0 = heff_get(v_d_246, LBL_key); V a_1 = v_reached_245; V r_ = (g_map_2elookup_24s9(a_0, a_1)); heff_drop(v_reached_245); r_; });
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_247, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_heff_2elower_2elowerSimplified_lam1(V self, V *args) {
  V v_d_2411 = args[0];
  V v_ar_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = ({ V a_0 = v_ar_2410; V r_ = (g_heff_2earity_2esatOf(a_0)); heff_drop(v_ar_2410); r_; });
  V v_t_2413 = heff_tr(heff_apply(heff_get(v_t_2412, LBL_go), 1, (V[]){heff_get(heff_dup(v_d_2411), LBL_body)}));
  return heff_rec(3, shape_152_198_28, (V[]){heff_get(heff_dup(v_d_2411), LBL_key), heff_get(v_d_2411, LBL_name), v_t_2413});
}
V g_heff_2elower_2elowerErased_lam0(V self, V *args);
Clo g_heff_2elower_2elowerErased_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elower_2elowerErased_entry, 2, 0};

V g_heff_2elower_2elowerErased(V v_roots_240, V v_er_241) {
top: ;
  V v_defs_242 = (g_prelude_2econcatMap_24s567(heff_get(heff_dup(v_er_241), LBL_defs)));
  V v_t_243 = (g_prelude_2efoldl_24s569(heff_dup(g_map_2eempty_get()), v_defs_242));
  V v_reached_244 = ({ V a_0 = v_t_243; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = heff_dup(v_roots_240); V r_ = (g_heff_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
  V v_t_248 = (g_prelude_2efilter(heff_clo(g_heff_2elower_2elowerErased_lam0, 1, 1, (V[]){v_reached_244}), v_defs_242));
  V v_t_249 = (g_heff_2esimplify_2esimplifyProgram(heff_get(heff_dup(v_er_241), LBL_supply), v_t_248));
  return (g_heff_2elower_2elowerSimplified(v_roots_240, heff_get(v_er_241, LBL_errors), v_t_249));
}
V g_heff_2elower_2elowerErased_entry(V self, V *a) {
  (void)self;
  return g_heff_2elower_2elowerErased(a[0], a[1]);
}
V g_heff_2elower_2elowerErased_lam0(V self, V *args) {
  V v_d_245 = args[0];
  V v_reached_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_246 = ({ V a_0 = heff_get(v_d_245, LBL_key); V a_1 = v_reached_244; V r_ = (g_map_2elookup_24s9(a_0, a_1)); heff_drop(v_reached_244); r_; });
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_246, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_246);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2elower_2eentryKey_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {114, 117, 110, 36, 101, 110, 116, 114, 121}};

static V g_heff_2elower_2eentryKey_val;
static int g_heff_2elower_2eentryKey_st;
static V g_heff_2elower_2eentryKey_init(void) {
  return ((V)&g_heff_2elower_2eentryKey_str0);
}
V g_heff_2elower_2eentryKey_get(void) {
  if (g_heff_2elower_2eentryKey_st == 2) return g_heff_2elower_2eentryKey_val;
  if (g_heff_2elower_2eentryKey_st == 1) heff_fail("defined by itself");
  g_heff_2elower_2eentryKey_st = 1;
  g_heff_2elower_2eentryKey_val = heff_tr(g_heff_2elower_2eentryKey_init());
  g_heff_2elower_2eentryKey_st = 2;
  return g_heff_2elower_2eentryKey_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {120, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {120, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {102, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {109, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {109, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {120, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {102, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {120, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str12 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str13 = {{0x80000000u, K_STR, 0}, 2, 2, {112, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str14 = {{0x80000000u, K_STR, 0}, 2, 2, {112, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str15 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elower_2eentryBody_str16 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 101, 114, 102, 111, 114, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elower_2eentryBody_str17 = {{0x80000000u, K_STR, 0}, 4, 4, {109, 97, 108, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elower_2eentryBody_str18 = {{0x80000000u, K_STR, 0}, 4, 4, {98, 105, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elower_2eentryBody_str19 = {{0x80000000u, K_STR, 0}, 3, 3, {114, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str20 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str21 = {{0x80000000u, K_STR, 0}, 2, 2, {120, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str22 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str23 = {{0x80000000u, K_STR, 0}, 2, 2, {120, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elower_2eentryBody_str24 = {{0x80000000u, K_STR, 0}, 2, 2, {120, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elower_2eentryBody_str25 = {{0x80000000u, K_STR, 0}, 6, 6, {77, 107, 85, 110, 105, 116}};
Clo g_heff_2elower_2eentryBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elower_2eentryBody_entry, 2, 0};

V g_heff_2elower_2eentryBody(V v_key_240, V v_n_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2elower_2eentryBody_str0), heff_intShow(heff_dup(v_n_241)));
  V v_t_243 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(1LL)));
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2elower_2eentryBody_str1), v_t_243), NTAG(TAG_Nil)});
  V v_t_245 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(1LL)));
  V v_t_246 = heff_tag(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2elower_2eentryBody_str2), v_t_245)});
  V v_t_247 = heff_strAppend(((V)&g_heff_2elower_2eentryBody_str3), heff_intShow(heff_dup(v_n_241)));
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_EVar, 1, (V[]){v_t_247}), NTAG(TAG_Nil)});
  V v_t_249 = heff_tag(TAG_ELam, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_242, v_t_244}), heff_tag(TAG_EApp, 2, (V[]){v_t_246, v_t_248})});
  V v_t_2410 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(2LL)));
  V v_t_2411 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(3LL)));
  V v_t_2412 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(4LL)));
  V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2elower_2eentryBody_str4), v_t_2412), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2elower_2eentryBody_str5), v_t_2411), v_t_2413});
  V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2elower_2eentryBody_str6), v_t_2410), v_t_2414});
  V v_t_2416 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(2LL)));
  V v_t_2417 = heff_tag(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2elower_2eentryBody_str7), v_t_2416)});
  V v_t_2418 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(5LL)));
  V v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2elower_2eentryBody_str8), v_t_2418), NTAG(TAG_Nil)});
  V v_t_2420 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(3LL)));
  V v_t_2421 = heff_tag(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2elower_2eentryBody_str9), v_t_2420)});
  V v_t_2422 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(5LL)));
  V v_t_2423 = heff_tag(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2elower_2eentryBody_str10), v_t_2422)});
  V v_t_2424 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(4LL)));
  V v_t_2425 = heff_tag(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2elower_2eentryBody_str11), v_t_2424)});
  V v_t_2426 = heff_tag(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
  V v_t_2427 = heff_tag(TAG_EApp, 2, (V[]){v_t_2421, heff_tag(TAG_Cons, 2, (V[]){v_t_2423, v_t_2426})});
  V v_t_2428 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_t_2419, v_t_2427}), NTAG(TAG_Nil)});
  V v_t_2429 = heff_tag(TAG_ELam, 2, (V[]){v_t_2415, heff_tag(TAG_EApp, 2, (V[]){v_t_2417, v_t_2428})});
  V v_t_2430 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(6LL)));
  V v_t_2431 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(7LL)));
  V v_t_2432 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2elower_2eentryBody_str12), v_t_2431), NTAG(TAG_Nil)});
  V v_t_2433 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2elower_2eentryBody_str13), v_t_2430), v_t_2432});
  V v_t_2434 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(6LL)));
  V v_t_2435 = heff_tag(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2elower_2eentryBody_str14), v_t_2434)});
  V v_t_2436 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(7LL)));
  V v_t_2437 = heff_tag(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2elower_2eentryBody_str15), v_t_2436)});
  V v_t_2438 = heff_tag(TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
  V v_t_2439 = heff_tag(TAG_EPrimCall, 2, (V[]){((V)&g_heff_2elower_2eentryBody_str16), heff_tag(TAG_Cons, 2, (V[]){v_t_2435, v_t_2438})});
  V v_t_2440 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elower_2eentryBody_str17), heff_tag(TAG_ELam, 2, (V[]){v_t_2433, v_t_2439})});
  V v_t_2441 = heff_tag(TAG_Cons, 2, (V[]){v_t_2440, NTAG(TAG_Nil)});
  V v_t_2442 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elower_2eentryBody_str18), v_t_2429}), v_t_2441});
  V v_t_2443 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elower_2eentryBody_str19), v_t_249}), v_t_2442});
  V v_t_2444 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(8LL)));
  V v_t_2445 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(9LL)));
  V v_t_2446 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2elower_2eentryBody_str20), v_t_2445), NTAG(TAG_Nil)});
  V v_t_2447 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2elower_2eentryBody_str21), v_t_2444), v_t_2446});
  V v_t_2448 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(9LL)));
  V v_t_2449 = heff_tag(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2elower_2eentryBody_str22), v_t_2448)});
  V v_t_2450 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(8LL)));
  V v_t_2451 = heff_tag(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2elower_2eentryBody_str23), v_t_2450)});
  V v_t_2452 = heff_tag(TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
  V v_t_2453 = heff_tag(TAG_ELam, 2, (V[]){v_t_2447, heff_tag(TAG_EApp, 2, (V[]){v_t_2449, v_t_2452})});
  V v_t_2454 = heff_intShow(heff_intAdd(v_n_241, MK_INT(10LL)));
  V v_t_2455 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2elower_2eentryBody_str24), v_t_2454), NTAG(TAG_Nil)});
  V v_t_2456 = heff_tag(TAG_ETag, 2, (V[]){((V)&g_heff_2elower_2eentryBody_str25), NTAG(TAG_Nil)});
  V v_t_2457 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_t_2455, v_t_2456}), NTAG(TAG_Nil)});
  V v_t_2458 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_ERecord, 1, (V[]){v_t_2443}), heff_tag(TAG_Cons, 2, (V[]){v_t_2453, v_t_2457})});
  return heff_tag(TAG_EApp, 2, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){v_key_240}), v_t_2458});
}
V g_heff_2elower_2eentryBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2elower_2eentryBody(a[0], a[1]);
}
Clo g_heff_2elower_2elowerProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elower_2elowerProgram_entry, 2, 0};

V g_heff_2elower_2elowerProgram(V v_g_240, V v_key_241) {
top: ;
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(g_heff_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
  V v_er_243 = (g_heff_2eerase_2eeraseProgram(v_g_240));
  V v_body_244 = (g_heff_2elower_2eentryBody(v_key_241, heff_get(heff_dup(v_er_243), LBL_supply)));
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(3, shape_152_198_28, (V[]){heff_dup(g_heff_2elower_2eentryKey_get()), heff_dup(g_heff_2elower_2eentryKey_get()), v_body_244}), NTAG(TAG_Nil)});
  V v_t_246 = (g_prelude_2econcatList(heff_get(heff_dup(v_er_243), LBL_defs), v_t_245));
  V v_t_247 = heff_intAdd(heff_get(heff_dup(v_er_243), LBL_supply), MK_INT(11LL));
  V v_t_248 = heff_rec(3, shape_59_89_328, (V[]){v_t_246, heff_get(v_er_243, LBL_errors), v_t_247});
  HEFF_LAST return g_heff_2elower_2elowerErased(v_t_242, v_t_248);
}
V g_heff_2elower_2elowerProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2elower_2elowerProgram(a[0], a[1]);
}
V g_heff_2elower_2eanfKept_lam0(V self, V *args);
Clo g_heff_2elower_2eanfKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elower_2eanfKept_entry, 3, 0};

V g_heff_2elower_2eanfKept(V v_supply_240, V v_kept_241, V v_errors_242) {
top: ;
  V v_ar_243 = (g_prelude_2efoldl_24s533(heff_dup(g_map_2eempty_get()), v_kept_241));
  V v_t_247 = (g_prelude_2emap(heff_clo(g_heff_2elower_2eanfKept_lam0, 1, 1, (V[]){v_ar_243}), v_kept_241));
  V v_l_248 = heff_rec(2, shape_59_89, (V[]){v_t_247, v_errors_242});
  V v_t_249 = (g_heff_2eanf_2etraverseN_24s532(heff_get(heff_dup(v_l_248), LBL_defs)));
  V v_x1_2410 = heff_tr(heff_apply(v_t_249, 1, (V[]){v_supply_240}));
  V v_t_2413;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 2);
    v_t_2413 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  return heff_rec(2, shape_59_89, (V[]){v_t_2413, heff_get(v_l_248, LBL_errors)});
}
V g_heff_2elower_2eanfKept_entry(V self, V *a) {
  (void)self;
  return g_heff_2elower_2eanfKept(a[0], a[1], a[2]);
}
V g_heff_2elower_2eanfKept_lam0(V self, V *args) {
  V v_d_244 = args[0];
  V v_ar_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = ({ V a_0 = v_ar_243; V r_ = (g_heff_2earity_2esatOf(a_0)); heff_drop(v_ar_243); r_; });
  V v_t_246 = heff_tr(heff_apply(heff_get(v_t_245, LBL_go), 1, (V[]){heff_get(heff_dup(v_d_244), LBL_body)}));
  return heff_rec(3, shape_152_198_28, (V[]){heff_get(heff_dup(v_d_244), LBL_key), heff_get(v_d_244, LBL_name), v_t_246});
}
V g_heff_2elower_2eanfSimplified_lam0(V self, V *args);
Clo g_heff_2elower_2eanfSimplified_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elower_2eanfSimplified_entry, 3, 0};

V g_heff_2elower_2eanfSimplified(V v_roots_240, V v_errors_241, V v_si_242) {
top: ;
  V v_defs_243 = heff_get(heff_dup(v_si_242), LBL_defs);
  V v_t_244 = (g_prelude_2efoldl_24s569(heff_dup(g_map_2eempty_get()), v_defs_243));
  V v_reached_245 = ({ V a_0 = v_t_244; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_roots_240; V r_ = (g_heff_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  V v_t_249 = (g_prelude_2efilter(heff_clo(g_heff_2elower_2eanfSimplified_lam0, 1, 1, (V[]){v_reached_245}), v_defs_243));
  HEFF_LAST return g_heff_2elower_2eanfKept(heff_get(v_si_242, LBL_supply), v_t_249, v_errors_241);
}
V g_heff_2elower_2eanfSimplified_entry(V self, V *a) {
  (void)self;
  return g_heff_2elower_2eanfSimplified(a[0], a[1], a[2]);
}
V g_heff_2elower_2eanfSimplified_lam0(V self, V *args) {
  V v_d_246 = args[0];
  V v_reached_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_247 = ({ V a_0 = heff_get(v_d_246, LBL_key); V a_1 = v_reached_245; V r_ = (g_map_2elookup_24s9(a_0, a_1)); heff_drop(v_reached_245); r_; });
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_247, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_heff_2elower_2eanfLowered_lam0(V self, V *args);
Clo g_heff_2elower_2eanfLowered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elower_2eanfLowered_entry, 2, 0};

V g_heff_2elower_2eanfLowered(V v_roots_240, V v_er_241) {
top: ;
  V v_defs_242 = (g_prelude_2econcatMap_24s567(heff_get(heff_dup(v_er_241), LBL_defs)));
  V v_t_243 = (g_prelude_2efoldl_24s569(heff_dup(g_map_2eempty_get()), v_defs_242));
  V v_reached_244 = ({ V a_0 = v_t_243; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = heff_dup(v_roots_240); V r_ = (g_heff_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
  V v_t_248 = (g_prelude_2efilter(heff_clo(g_heff_2elower_2eanfLowered_lam0, 1, 1, (V[]){v_reached_244}), v_defs_242));
  V v_t_249 = (g_heff_2esimplify_2esimplifyProgram(heff_get(heff_dup(v_er_241), LBL_supply), v_t_248));
  return (g_heff_2elower_2eanfSimplified(v_roots_240, heff_get(v_er_241, LBL_errors), v_t_249));
}
V g_heff_2elower_2eanfLowered_entry(V self, V *a) {
  (void)self;
  return g_heff_2elower_2eanfLowered(a[0], a[1]);
}
V g_heff_2elower_2eanfLowered_lam0(V self, V *args) {
  V v_d_245 = args[0];
  V v_reached_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_246 = ({ V a_0 = heff_get(v_d_245, LBL_key); V a_1 = v_reached_244; V r_ = (g_map_2elookup_24s9(a_0, a_1)); heff_drop(v_reached_244); r_; });
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_246, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_246);
  }
}
Clo g_heff_2elower_2elowerProgramAnf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elower_2elowerProgramAnf_entry, 2, 0};

V g_heff_2elower_2elowerProgramAnf(V v_g_240, V v_key_241) {
top: ;
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(g_heff_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
  V v_er_243 = (g_heff_2eerase_2eeraseProgram(v_g_240));
  V v_body_244 = (g_heff_2elower_2eentryBody(v_key_241, heff_get(heff_dup(v_er_243), LBL_supply)));
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(3, shape_152_198_28, (V[]){heff_dup(g_heff_2elower_2eentryKey_get()), heff_dup(g_heff_2elower_2eentryKey_get()), v_body_244}), NTAG(TAG_Nil)});
  V v_t_246 = (g_prelude_2econcatList(heff_get(heff_dup(v_er_243), LBL_defs), v_t_245));
  V v_t_247 = heff_intAdd(heff_get(heff_dup(v_er_243), LBL_supply), MK_INT(11LL));
  V v_t_248 = heff_rec(3, shape_59_89_328, (V[]){v_t_246, heff_get(v_er_243, LBL_errors), v_t_247});
  HEFF_LAST return g_heff_2elower_2eanfLowered(v_t_242, v_t_248);
}
V g_heff_2elower_2elowerProgramAnf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elower_2elowerProgramAnf(a[0], a[1]);
}