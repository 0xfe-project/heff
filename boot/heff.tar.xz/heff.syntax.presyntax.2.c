// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfLet 62066
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_EndJump 17665
#define TAG_EndValue 24675
#define TAG_IApp 21275
#define TAG_IInt 28905
#define TAG_IPrim 59489
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkSegment 38079
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetMut 50164
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TagVariant 25174
#define LBL_bind 9519364
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_end 310101
#define LBL_guard 300063423
#define LBL_head 9693863
#define LBL_inLam 301681229
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_stmts 311127493
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_head__vars__unit__depth[] = {LBL_head, LBL_vars, LBL_unit, LBL_depth};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ealtBy(V, V);
V g_heff_2esyntax_2epresyntax_2ealtBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtBy_clo;
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(V);
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2easAction(V, V, V);
V g_heff_2esyntax_2epresyntax_2easAction_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2easAction_clo;
HeffT1 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(V);
HeffT2 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebytesBinary_24s164675078x1710946710_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2echeckedWays_get(void);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2econtrolT(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econtrolT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econtrolT_clo;
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(V);
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_clo;
V g_heff_2esyntax_2epresyntax_2edeclaredMuts(V);
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_clo;
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183(V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_clo;
V g_heff_2esyntax_2epresyntax_2eguardE(V, V);
V g_heff_2esyntax_2epresyntax_2eguardE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eguardE_clo;
V g_heff_2esyntax_2epresyntax_2ehasNest(V);
V g_heff_2esyntax_2epresyntax_2ehasNest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasNest_clo;
V g_heff_2esyntax_2epresyntax_2eifLetOf(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eifLetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eifLetOf_clo;
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
V g_heff_2esyntax_2epresyntax_2eisMadeName(V);
V g_heff_2esyntax_2epresyntax_2eisMadeName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisMadeName_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall(V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_clo;
V g_heff_2esyntax_2epresyntax_2elastT(V, V, V);
V g_heff_2esyntax_2epresyntax_2elastT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
V g_heff_2esyntax_2epresyntax_2eliftE(V, V, V);
V g_heff_2esyntax_2epresyntax_2eliftE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eliftE_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elocalFun_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24dps(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24dps_clo;
V g_heff_2esyntax_2epresyntax_2escopeJoin(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2escopeJoin_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2escopeJoin_clo;
V g_heff_2esyntax_2epresyntax_2esegmentOdd(V, V);
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2eutf8Of(V);
V g_heff_2esyntax_2epresyntax_2eutf8Of_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eutf8Of_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
V g_heff_2esyntax_2epresyntax_2evariantOf(V, V);
V g_heff_2esyntax_2epresyntax_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_clo;
V g_heff_2esyntax_2epresyntax_2ewholeBinary(V, V);
V g_heff_2esyntax_2epresyntax_2ewholeBinary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewholeBinary_clo;
V g_heff_2esyntax_2epresyntax_2ewithScopeOf(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithScopeOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithScopeOf_clo;
V g_heff_2esyntax_2epresyntax_2ewithT(V, V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithT_clo;
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eall_24s1687051711x1677682329(V, V);
V g_list_2eall_24s1687051711x1677682329_entry(V self, V *a);
extern Clo g_list_2eall_24s1687051711x1677682329_clo;
V g_list_2eany_24s689038521x519269801(V);
V g_list_2eany_24s689038521x519269801_entry(V self, V *a);
extern Clo g_list_2eany_24s689038521x519269801_clo;
V g_list_2eany_24s717144537x1885076661(V);
V g_list_2eany_24s717144537x1885076661_entry(V self, V *a);
extern Clo g_list_2eany_24s717144537x1885076661_clo;
V g_list_2eany_24s930586707x1164893977(V, V);
V g_list_2eany_24s930586707x1164893977_entry(V self, V *a);
extern Clo g_list_2eany_24s930586707x1164893977_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
HeffT2 g_list_2efind_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1935134062x1256175429(V, V);
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1935134062x1256175429_clo;
V g_list_2efoldl_24s947545569x507961639(V, V);
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947545569x507961639_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1782778565x402128078(V);
V g_list_2emap_24s1782778565x402128078_entry(V self, V *a);
extern Clo g_list_2emap_24s1782778565x402128078_clo;
V g_list_2emap_24s34825065x1144190520(V);
V g_list_2emap_24s34825065x1144190520_entry(V self, V *a);
extern Clo g_list_2emap_24s34825065x1144190520_clo;
V g_list_2emap_24s474585387x1072098790(V);
V g_list_2emap_24s474585387x1072098790_entry(V self, V *a);
extern Clo g_list_2emap_24s474585387x1072098790_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2esegmentOdd_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2esegmentOdd(V v_ty_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(v_ty_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2esegmentOdd(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str3, 0, "");
Clo g_heff_2esyntax_2epresyntax_2eutf8Of_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eutf8Of_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eutf8Of(V v_c_240) {
top: ;
  if (heff_intLt_c_lent(v_c_240, MK_INT(128LL), 2)) {
    return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(1LL), v_c_240, ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str0)));
  } else {
    if (heff_intLt_c_lent(v_c_240, MK_INT(2048LL), 2)) {
      int64_t v_t_243 = (((int64_t)192ULL) + (heff_peek_word(v_c_240) / ((int64_t)64ULL)));
      int64_t v_t_244 = ((v_t_243 * ((int64_t)256ULL)) + ((int64_t)128ULL));
      int64_t v_t_245 = (v_t_244 + (heff_unbox_word(v_c_240) % ((int64_t)64ULL)));
      return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(2LL), heff_box_word(v_t_245), ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str1)));
    } else {
      if (heff_intLt_c_lent(v_c_240, MK_INT(65536LL), 2)) {
        int64_t v_t_247 = (((int64_t)224ULL) + (heff_peek_word(v_c_240) / ((int64_t)4096ULL)));
        int64_t v_t_248 = ((v_t_247 * ((int64_t)256ULL)) + ((int64_t)128ULL));
        int64_t v_t_249 = ((heff_peek_word(v_c_240) / ((int64_t)64ULL)) % ((int64_t)64ULL));
        int64_t v_t_2410 = ((v_t_248 + v_t_249) * ((int64_t)256ULL));
        int64_t v_t_2411 = ((v_t_2410 + ((int64_t)128ULL)) + (heff_unbox_word(v_c_240) % ((int64_t)64ULL)));
        return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(3LL), heff_box_word(v_t_2411), ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str2)));
      } else {
        V v_t_2412 = heff_intAdd(MK_INT(240LL), heff_intDiv(heff_dup(v_c_240), MK_INT(262144LL)));
        V v_t_2413 = heff_intAdd(heff_intMul(v_t_2412, MK_INT(256LL)), MK_INT(128LL));
        V v_t_2414 = heff_intMod(heff_intDiv(heff_dup(v_c_240), MK_INT(4096LL)), MK_INT(64LL));
        V v_t_2415 = heff_intMul(heff_intAdd(v_t_2413, v_t_2414), MK_INT(256LL));
        V v_t_2416 = heff_intMod(heff_intDiv(heff_dup(v_c_240), MK_INT(64LL)), MK_INT(64LL));
        V v_t_2417 = heff_intAdd(heff_intAdd(v_t_2415, MK_INT(128LL)), v_t_2416);
        V v_t_2418 = heff_intAdd(heff_intMul(v_t_2417, MK_INT(256LL)), MK_INT(128LL));
        V v_t_2419 = heff_intAdd(v_t_2418, heff_intMod(v_c_240, MK_INT(64LL)));
        return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(4LL), v_t_2419, ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str3)));
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eutf8Of_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eutf8Of(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str1, 4, "Unit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str2, 6, "typeOf");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str3, 6, "typeOf");
V g_heff_2esyntax_2epresyntax_2evarParams_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2evarParams_lam1(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2evarParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2evarParams_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2evarParams(V v_sp_240, V v_unit_241, V v_vars_242) {
top: ;
  if ((heff_dup(v_unit_241) == NTAG(TAG_True))) {
    switch (heff_tag_of(v_vars_242)) {
    case TAG_Nil: {
      V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str0)}), heff_dup(v_sp_240)});
      V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str1)}), v_sp_240});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_t_244}), NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      return (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2evarParams_lam0, 1, 1, (V[]){v_sp_240}), v_vars_242));
    }
    default: return heff_nomatch(v_vars_242);
    }
  } else {
    return (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2evarParams_lam1, 1, 1, (V[]){v_sp_240}), v_vars_242));
  }
}
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2evarParams(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2epresyntax_2evarParams_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_x_247)}), heff_dup(v_sp_240)});
  V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str2)}), heff_dup(v_sp_240)});
  V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_247}), v_sp_240});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_249, v_t_2411));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_t_2412});
}
V g_heff_2esyntax_2epresyntax_2evarParams_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_x_2413)}), heff_dup(v_sp_240)});
  V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str3)}), heff_dup(v_sp_240)});
  V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_2413}), v_sp_240});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2415, v_t_2417));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_t_2418});
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ejumpCall_str0, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2ejumpCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ejumpCall_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ejumpCall(V v_cx_240, V v_sp_241, V v_j_242) {
top: ;
  V v_t_243 = heff_intSub(heff_dup(heff_rfield(v_cx_240, 4)), heff_take_field(v_j_242, 3));
  V v_vars_244 = heff_take_field(v_j_242, 1);
  V v_t_245 = heff_take_field(v_j_242, 2);
  V v_t_249;
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    switch (heff_tag_of(v_vars_244)) {
    case TAG_Nil: {
      V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ejumpCall_str0)}), heff_dup(v_sp_241)});
      v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      v_t_249 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_vars_244));
      break;
    }
    default: heff_nomatch(v_vars_244);
    }
  } else {
    heff_drop(v_t_245);
    v_t_249 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_vars_244));
  }
  V v_t_2410 = (g_heff_2esyntax_2epresyntax_2eapp(heff_get_n(v_j_242, 0, 4), v_t_249));
  return (g_heff_2esyntax_2epresyntax_2eleaving(v_cx_240, v_sp_241, v_t_243, v_t_2410));
}
V g_heff_2esyntax_2epresyntax_2ejumpCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ejumpCall(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epatNames_24dps_str0, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2epatNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epatNames_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2esyntax_2epresyntax_2epatNames_24dps_str0), 2)) {
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        heff_drop(v_x_244);
        return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
      } else {
        V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
        return heff_setField(v_d_241, MK_INT(1LL), v_t_246);
      }
    }
    case TAG_PatTag: {
      V v_ps_249 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_249));
      V v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2410); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2411);
    }
    case TAG_PatOp: {
      V v_ps_2414 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2414));
      V v_t_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2415); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2416);
    }
    case TAG_PatInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRecord: {
      V v_fs_2422 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2422));
      V v_t_2424 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2423; V r_ = (g_list_2efoldl_24s947545569x507961639(a_0, a_1)); heff_drop(v_t_2423); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2424);
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatAs: {
      V v_x_2426 = heff_field(v_x11_242, 0);
      V v_q_2428 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 5ULL, 3);
      V v_cell_2429 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2426, heff_hole()});
      V v_u_2430 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2429));
      heff_drop(v_u_2430);
      V t_0 = v_q_2428;
      V t_1 = v_cell_2429;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epatNames_24dps(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2ehasNest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ehasNest_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ehasNest(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_244 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_245 = v_t_244.f[0];
        V v_field_246 = v_t_244.f[1];
        V v_x_247 = v_field_245;
        V v_y_248 = v_field_246;
        heff_drop(v_y_248);
        return v_x_247;
      }
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2410 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_x_2413 = v_field_2411;
        V v_y_2414 = v_field_2412;
        heff_drop(v_y_2414);
        return v_x_2413;
      }
    }
    case TAG_ETag: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2416 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2417 = v_t_2416.f[0];
        V v_field_2418 = v_t_2416.f[1];
        V v_x_2419 = v_field_2417;
        V v_y_2420 = v_field_2418;
        heff_drop(v_y_2420);
        return v_x_2419;
      }
    }
    case TAG_EInt: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2422 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2423 = v_t_2422.f[0];
        V v_field_2424 = v_t_2422.f[1];
        V v_x_2425 = v_field_2423;
        V v_y_2426 = v_field_2424;
        heff_drop(v_y_2426);
        return v_x_2425;
      }
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2428 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2429 = v_t_2428.f[0];
        V v_field_2430 = v_t_2428.f[1];
        V v_x_2431 = v_field_2429;
        V v_y_2432 = v_field_2430;
        heff_drop(v_y_2432);
        return v_x_2431;
      }
    }
    case TAG_EString: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2434 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2435 = v_t_2434.f[0];
        V v_field_2436 = v_t_2434.f[1];
        V v_x_2437 = v_field_2435;
        V v_y_2438 = v_field_2436;
        heff_drop(v_y_2438);
        return v_x_2437;
      }
    }
    case TAG_EBinary: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2440 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2441 = v_t_2440.f[0];
        V v_field_2442 = v_t_2440.f[1];
        V v_x_2443 = v_field_2441;
        V v_y_2444 = v_field_2442;
        heff_drop(v_y_2444);
        return v_x_2443;
      }
    }
    case TAG_ERune: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2446 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2447 = v_t_2446.f[0];
        V v_field_2448 = v_t_2446.f[1];
        V v_x_2449 = v_field_2447;
        V v_y_2450 = v_field_2448;
        heff_drop(v_y_2450);
        return v_x_2449;
      }
    }
    case TAG_EWord: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2452 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2453 = v_t_2452.f[0];
        V v_field_2454 = v_t_2452.f[1];
        V v_x_2455 = v_field_2453;
        V v_y_2456 = v_field_2454;
        heff_drop(v_y_2456);
        return v_x_2455;
      }
    }
    case TAG_EApp: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_2459 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2460 = v_t_2459.f[0];
        V v_field_2461 = v_t_2459.f[1];
        V v_x_2462 = v_field_2460;
        V v_y_2463 = v_field_2461;
        heff_drop(v_y_2463);
        return v_x_2462;
      }
    }
    case TAG_EProject: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2465 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2466 = v_t_2465.f[0];
        V v_field_2467 = v_t_2465.f[1];
        V v_x_2468 = v_field_2466;
        V v_y_2469 = v_field_2467;
        heff_drop(v_y_2469);
        return v_x_2468;
      }
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_2472 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2473 = v_t_2472.f[0];
        V v_field_2474 = v_t_2472.f[1];
        V v_x_2475 = v_field_2473;
        V v_y_2476 = v_field_2474;
        heff_drop(v_y_2476);
        return v_x_2475;
      }
    }
    case TAG_EPi: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_2479 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2480 = v_t_2479.f[0];
        V v_field_2481 = v_t_2479.f[1];
        V v_x_2482 = v_field_2480;
        V v_y_2483 = v_field_2481;
        heff_drop(v_y_2483);
        return v_x_2482;
      }
    }
    case TAG_ELam: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop_tag(v_e_240, 2);
      return NTAG(TAG_False);
    }
    case TAG_EAnn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_2488 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2489 = v_t_2488.f[0];
        V v_field_2490 = v_t_2488.f[1];
        V v_x_2491 = v_field_2489;
        V v_y_2492 = v_field_2490;
        heff_drop(v_y_2492);
        return v_x_2491;
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_241, 0ULL, 4);
      HeffT2 v_t_2497 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2498 = v_t_2497.f[0];
        V v_field_2499 = v_t_2497.f[1];
        V v_x_24100 = v_field_2498;
        V v_y_24101 = v_field_2499;
        heff_drop(v_y_24101);
        return v_x_24100;
      }
    }
    case TAG_ESig: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24103 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24104 = v_t_24103.f[0];
        V v_field_24105 = v_t_24103.f[1];
        V v_x_24106 = v_field_24104;
        V v_y_24107 = v_field_24105;
        heff_drop(v_y_24107);
        return v_x_24106;
      }
    }
    case TAG_ESum: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24109 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24110 = v_t_24109.f[0];
        V v_field_24111 = v_t_24109.f[1];
        V v_x_24112 = v_field_24110;
        V v_y_24113 = v_field_24111;
        heff_drop(v_y_24113);
        return v_x_24112;
      }
    }
    case TAG_EStruct: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24115 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24116 = v_t_24115.f[0];
        V v_field_24117 = v_t_24115.f[1];
        V v_x_24118 = v_field_24116;
        V v_y_24119 = v_field_24117;
        heff_drop(v_y_24119);
        return v_x_24118;
      }
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24122 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24123 = v_t_24122.f[0];
        V v_field_24124 = v_t_24122.f[1];
        V v_x_24125 = v_field_24123;
        V v_y_24126 = v_field_24124;
        heff_drop(v_y_24126);
        return v_x_24125;
      }
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24129 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24130 = v_t_24129.f[0];
        V v_field_24131 = v_t_24129.f[1];
        V v_x_24132 = v_field_24130;
        V v_y_24133 = v_field_24131;
        heff_drop(v_y_24133);
        return v_x_24132;
      }
    }
    case TAG_ELetIn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24136 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24137 = v_t_24136.f[0];
        V v_field_24138 = v_t_24136.f[1];
        V v_x_24139 = v_field_24137;
        V v_y_24140 = v_field_24138;
        heff_drop(v_y_24140);
        return v_x_24139;
      }
    }
    case TAG_EDo: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop_tag(v_e_240, 2);
      return NTAG(TAG_False);
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24144 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24145 = v_t_24144.f[0];
        V v_field_24146 = v_t_24144.f[1];
        V v_x_24147 = v_field_24145;
        V v_y_24148 = v_field_24146;
        heff_drop(v_y_24148);
        return v_x_24147;
      }
    }
    case TAG_EInvalid: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24150 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24151 = v_t_24150.f[0];
        V v_field_24152 = v_t_24150.f[1];
        V v_x_24153 = v_field_24151;
        V v_y_24154 = v_field_24152;
        heff_drop(v_y_24154);
        return v_x_24153;
      }
    }
    case TAG_EAssign: {
      heff_take_n(v_e1_241, 0ULL, 3);
      HeffT2 v_t_24158 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24159 = v_t_24158.f[0];
        V v_field_24160 = v_t_24158.f[1];
        V v_x_24161 = v_field_24159;
        V v_y_24162 = v_field_24160;
        heff_drop(v_y_24162);
        return v_x_24161;
      }
    }
    case TAG_EWhile: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24165 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24166 = v_t_24165.f[0];
        V v_field_24167 = v_t_24165.f[1];
        V v_x_24168 = v_field_24166;
        V v_y_24169 = v_field_24167;
        heff_drop(v_y_24169);
        return v_x_24168;
      }
    }
    case TAG_EFor: {
      heff_take_n(v_e1_241, 0ULL, 3);
      HeffT2 v_t_24173 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24174 = v_t_24173.f[0];
        V v_field_24175 = v_t_24173.f[1];
        V v_x_24176 = v_field_24174;
        V v_y_24177 = v_field_24175;
        heff_drop(v_y_24177);
        return v_x_24176;
      }
    }
    case TAG_EIfThen: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24180 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24181 = v_t_24180.f[0];
        V v_field_24182 = v_t_24180.f[1];
        V v_x_24183 = v_field_24181;
        V v_y_24184 = v_field_24182;
        heff_drop(v_y_24184);
        return v_x_24183;
      }
    }
    case TAG_EBreak: {
      HeffT2 v_t_24185 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24186 = v_t_24185.f[0];
        V v_field_24187 = v_t_24185.f[1];
        V v_x_24188 = v_field_24186;
        V v_y_24189 = v_field_24187;
        heff_drop(v_y_24189);
        return v_x_24188;
      }
    }
    case TAG_EContinue: {
      HeffT2 v_t_24190 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24191 = v_t_24190.f[0];
        V v_field_24192 = v_t_24190.f[1];
        V v_x_24193 = v_field_24191;
        V v_y_24194 = v_field_24192;
        heff_drop(v_y_24194);
        return v_x_24193;
      }
    }
    case TAG_EReturn: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24196 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24197 = v_t_24196.f[0];
        V v_field_24198 = v_t_24196.f[1];
        V v_x_24199 = v_field_24197;
        V v_y_24200 = v_field_24198;
        heff_drop(v_y_24200);
        return v_x_24199;
      }
    }
    case TAG_ENest: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop_tag(v_e_240, 2);
      return NTAG(TAG_True);
    }
    case TAG_EIfLet: {
      heff_take_n(v_e1_241, 0ULL, 4);
      HeffT2 v_t_24206 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24207 = v_t_24206.f[0];
        V v_field_24208 = v_t_24206.f[1];
        V v_x_24209 = v_field_24207;
        V v_y_24210 = v_field_24208;
        heff_drop(v_y_24210);
        return v_x_24209;
      }
    }
    case TAG_ETry: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop_tag(v_e_240, 2);
      return NTAG(TAG_False);
    }
    case TAG_EWith: {
      heff_take_n(v_e1_241, 0ULL, 4);
      heff_drop_tag(v_e_240, 2);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e1_241);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ehasNest_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ehasNest(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eguardE_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eguardE_str1, 135, "` is a `let mut` variable of the `do` block around: a closure (a lambda, or a `do` block of its own) holds its value, and cannot set it");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eguardE_str2, 95, "`break` is in a lambda: a loop's statements are its body's, and a lambda's body is none of them");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eguardE_str3, 98, "`continue` is in a lambda: a loop's statements are its body's, and a lambda's body is none of them");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eguardE_str4, 105, "`return` is in a lambda: it ends the `do` block it is a statement of, and a lambda's body is no statement");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eguardE_str5, 118, "`(<- c)` is in a lambda, whose body runs later, not where the statement does: bind the action's value before, `x <- c`");
V g_heff_2esyntax_2epresyntax_2eguardE_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam1(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam2(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam3(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam4(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam5(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam6(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam7(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam8(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam9(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam10(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam11(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam12(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam13(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam14(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam15(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam16(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam17(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam18(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam19(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam20(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam21(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam22(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam23(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam24(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam25(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam26(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam27(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam28(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam29(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam30(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2eguardE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eguardE_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eguardE(V v_g_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_At: {
    V v_e1_242 = heff_dup(heff_field(v_e_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_EVar: {
      heff_take_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_f_245 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam0, 2, 1, (V[]){v_f_245}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_x_2412 = v_field_2410;
        heff_drop(v_x_2412);
        V v_y_2413 = v_field_2411;
        return v_y_2413;
      }
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_f_2415 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_2419 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam1, 2, 1, (V[]){v_f_2415}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_2420 = v_t_2419.f[0];
        V v_field_2421 = v_t_2419.f[1];
        V v_x_2422 = v_field_2420;
        heff_drop(v_x_2422);
        V v_y_2423 = v_field_2421;
        return v_y_2423;
      }
    }
    case TAG_ETag: {
      heff_take_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_f_2425 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_2429 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam2, 2, 1, (V[]){v_f_2425}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_2430 = v_t_2429.f[0];
        V v_field_2431 = v_t_2429.f[1];
        V v_x_2432 = v_field_2430;
        heff_drop(v_x_2432);
        V v_y_2433 = v_field_2431;
        return v_y_2433;
      }
    }
    case TAG_EInt: {
      heff_take_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_f_2435 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_2439 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam3, 2, 1, (V[]){v_f_2435}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_2440 = v_t_2439.f[0];
        V v_field_2441 = v_t_2439.f[1];
        V v_x_2442 = v_field_2440;
        heff_drop(v_x_2442);
        V v_y_2443 = v_field_2441;
        return v_y_2443;
      }
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_f_2445 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_2449 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam4, 2, 1, (V[]){v_f_2445}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_2450 = v_t_2449.f[0];
        V v_field_2451 = v_t_2449.f[1];
        V v_x_2452 = v_field_2450;
        heff_drop(v_x_2452);
        V v_y_2453 = v_field_2451;
        return v_y_2453;
      }
    }
    case TAG_EString: {
      heff_take_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_f_2455 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_2459 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam5, 2, 1, (V[]){v_f_2455}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_2460 = v_t_2459.f[0];
        V v_field_2461 = v_t_2459.f[1];
        V v_x_2462 = v_field_2460;
        heff_drop(v_x_2462);
        V v_y_2463 = v_field_2461;
        return v_y_2463;
      }
    }
    case TAG_EBinary: {
      heff_take_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_f_2465 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_2469 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam6, 2, 1, (V[]){v_f_2465}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_2470 = v_t_2469.f[0];
        V v_field_2471 = v_t_2469.f[1];
        V v_x_2472 = v_field_2470;
        heff_drop(v_x_2472);
        V v_y_2473 = v_field_2471;
        return v_y_2473;
      }
    }
    case TAG_ERune: {
      heff_take_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_f_2475 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_2479 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam7, 2, 1, (V[]){v_f_2475}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_2480 = v_t_2479.f[0];
        V v_field_2481 = v_t_2479.f[1];
        V v_x_2482 = v_field_2480;
        heff_drop(v_x_2482);
        V v_y_2483 = v_field_2481;
        return v_y_2483;
      }
    }
    case TAG_EWord: {
      heff_take_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_f_2485 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_2489 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam8, 2, 1, (V[]){v_f_2485}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_2490 = v_t_2489.f[0];
        V v_field_2491 = v_t_2489.f[1];
        V v_x_2492 = v_field_2490;
        heff_drop(v_x_2492);
        V v_y_2493 = v_field_2491;
        return v_y_2493;
      }
    }
    case TAG_EApp: {
      heff_take_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_f_2496 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24100 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam9, 2, 1, (V[]){v_f_2496}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24101 = v_t_24100.f[0];
        V v_field_24102 = v_t_24100.f[1];
        V v_x_24103 = v_field_24101;
        heff_drop(v_x_24103);
        V v_y_24104 = v_field_24102;
        return v_y_24104;
      }
    }
    case TAG_EProject: {
      heff_take_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_f_24106 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24110 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam10, 2, 1, (V[]){v_f_24106}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24111 = v_t_24110.f[0];
        V v_field_24112 = v_t_24110.f[1];
        V v_x_24113 = v_field_24111;
        heff_drop(v_x_24113);
        V v_y_24114 = v_field_24112;
        return v_y_24114;
      }
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_f_24117 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24121 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam11, 2, 1, (V[]){v_f_24117}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24122 = v_t_24121.f[0];
        V v_field_24123 = v_t_24121.f[1];
        V v_x_24124 = v_field_24122;
        heff_drop(v_x_24124);
        V v_y_24125 = v_field_24123;
        return v_y_24125;
      }
    }
    case TAG_EPi: {
      heff_take_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_f_24128 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24132 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam12, 2, 1, (V[]){v_f_24128}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24133 = v_t_24132.f[0];
        V v_field_24134 = v_t_24132.f[1];
        V v_x_24135 = v_field_24133;
        heff_drop(v_x_24135);
        V v_y_24136 = v_field_24134;
        return v_y_24136;
      }
    }
    case TAG_ELam: {
      V v_b_24137 = heff_field(v_e1_242, 0);
      V v_body_24138 = heff_field(v_e1_242, 1);
      V v_ru_24e1_242_24ELam = heff_take_reuse_n(v_e1_242, 3ULL, 2);
      heff_drop_tag(v_e_241, 2);
      V v_t_24139 = ({ V rv_1 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_g_240, 1ULL, 2, shape_muts__inLam, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_24140 = (g_heff_2esyntax_2epresyntax_2eguardE(v_t_24139, v_body_24138));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ELam, TAG_ELam, 2, (V[]){v_b_24137, v_t_24140}), v_sp_243});
    }
    case TAG_EAnn: {
      heff_take_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_f_24143 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24147 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam13, 2, 1, (V[]){v_f_24143}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24148 = v_t_24147.f[0];
        V v_field_24149 = v_t_24147.f[1];
        V v_x_24150 = v_field_24148;
        heff_drop(v_x_24150);
        V v_y_24151 = v_field_24149;
        return v_y_24151;
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_242, 0ULL, 4);
      heff_drop(v_sp_243);
      V v_f_24156 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24160 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam14, 2, 1, (V[]){v_f_24156}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24161 = v_t_24160.f[0];
        V v_field_24162 = v_t_24160.f[1];
        V v_x_24163 = v_field_24161;
        heff_drop(v_x_24163);
        V v_y_24164 = v_field_24162;
        return v_y_24164;
      }
    }
    case TAG_ESig: {
      heff_take_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_f_24166 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24170 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam15, 2, 1, (V[]){v_f_24166}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24171 = v_t_24170.f[0];
        V v_field_24172 = v_t_24170.f[1];
        V v_x_24173 = v_field_24171;
        heff_drop(v_x_24173);
        V v_y_24174 = v_field_24172;
        return v_y_24174;
      }
    }
    case TAG_ESum: {
      heff_take_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_f_24176 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24180 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam16, 2, 1, (V[]){v_f_24176}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24181 = v_t_24180.f[0];
        V v_field_24182 = v_t_24180.f[1];
        V v_x_24183 = v_field_24181;
        heff_drop(v_x_24183);
        V v_y_24184 = v_field_24182;
        return v_y_24184;
      }
    }
    case TAG_EStruct: {
      heff_take_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_f_24186 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24190 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam17, 2, 1, (V[]){v_f_24186}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24191 = v_t_24190.f[0];
        V v_field_24192 = v_t_24190.f[1];
        V v_x_24193 = v_field_24191;
        heff_drop(v_x_24193);
        V v_y_24194 = v_field_24192;
        return v_y_24194;
      }
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_f_24197 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24201 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam18, 2, 1, (V[]){v_f_24197}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24202 = v_t_24201.f[0];
        V v_field_24203 = v_t_24201.f[1];
        V v_x_24204 = v_field_24202;
        heff_drop(v_x_24204);
        V v_y_24205 = v_field_24203;
        return v_y_24205;
      }
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_f_24208 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24212 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam19, 2, 1, (V[]){v_f_24208}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24213 = v_t_24212.f[0];
        V v_field_24214 = v_t_24212.f[1];
        V v_x_24215 = v_field_24213;
        heff_drop(v_x_24215);
        V v_y_24216 = v_field_24214;
        return v_y_24216;
      }
    }
    case TAG_ELetIn: {
      heff_take_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_f_24219 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24223 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam20, 2, 1, (V[]){v_f_24219}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24224 = v_t_24223.f[0];
        V v_field_24225 = v_t_24223.f[1];
        V v_x_24226 = v_field_24224;
        heff_drop(v_x_24226);
        V v_y_24227 = v_field_24225;
        return v_y_24227;
      }
    }
    case TAG_EDo: {
      V v_ss_24228 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24EDo = heff_take_reuse_n(v_e1_242, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      V v_t_24232 = (g_list_2efilter(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam21, 1, 1, (V[]){heff_dup(v_ss_24228)}), heff_get_n(v_g_240, 0, 2)));
      V v_t_24233 = heff_rec_n(2, shape_muts__inLam, (V[]){v_t_24232, NTAG(TAG_False)});
      V v_f_24234 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_t_24233}));
      V v_t_24235 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EDo, TAG_EDo, 1, (V[]){v_ss_24228}), v_sp_243});
      HeffT2 v_t_24239 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam22, 2, 1, (V[]){v_f_24234}), NTAG(TAG_MkUnit), v_t_24235));
      {
        V v_field_24240 = v_t_24239.f[0];
        V v_field_24241 = v_t_24239.f[1];
        V v_x_24242 = v_field_24240;
        heff_drop(v_x_24242);
        V v_y_24243 = v_field_24241;
        return v_y_24243;
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_f_24246 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24250 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam23, 2, 1, (V[]){v_f_24246}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24251 = v_t_24250.f[0];
        V v_field_24252 = v_t_24250.f[1];
        V v_x_24253 = v_field_24251;
        heff_drop(v_x_24253);
        V v_y_24254 = v_field_24252;
        return v_y_24254;
      }
    }
    case TAG_EInvalid: {
      heff_take_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_f_24256 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24260 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam24, 2, 1, (V[]){v_f_24256}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24261 = v_t_24260.f[0];
        V v_field_24262 = v_t_24260.f[1];
        V v_x_24263 = v_field_24261;
        heff_drop(v_x_24263);
        V v_y_24264 = v_field_24262;
        return v_y_24264;
      }
    }
    case TAG_EAssign: {
      V v_x_24265 = heff_field(v_e1_242, 0);
      V v_xsp_24266 = heff_field(v_e1_242, 1);
      V v_v_24267 = heff_field(v_e1_242, 2);
      V v_ru_24e1_242_24EAssign = heff_take_reuse_n(v_e1_242, 7ULL, 3);
      heff_drop_tag(v_e_241, 2);
      V v_t_24268 = (g_list_2eany_24s930586707x1164893977(v_x_24265, heff_rfield(v_g_240, 0)));
      if ((heff_dup(v_t_24268) == NTAG(TAG_True))) {
        heff_drop_rec(v_g_240, 2);
        heff_drop(v_sp_243);
        heff_drop(v_v_24267);
        heff_drop_cell(v_ru_24e1_242_24EAssign, 3);
        heff_drop(v_t_24268);
        V v_t_24269 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eguardE_str0), heff_strAppend(v_x_24265, ((V)&g_heff_2esyntax_2epresyntax_2eguardE_str1)));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24269}), v_xsp_24266});
      } else {
        heff_drop(v_t_24268);
        V v_t_24270 = (g_heff_2esyntax_2epresyntax_2eguardE(v_g_240, v_v_24267));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EAssign, TAG_EAssign, 3, (V[]){v_x_24265, v_xsp_24266, v_t_24270}), v_sp_243});
      }
    }
    case TAG_EWhile: {
      heff_take_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_f_24273 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24277 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam25, 2, 1, (V[]){v_f_24273}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24278 = v_t_24277.f[0];
        V v_field_24279 = v_t_24277.f[1];
        V v_x_24280 = v_field_24278;
        heff_drop(v_x_24280);
        V v_y_24281 = v_field_24279;
        return v_y_24281;
      }
    }
    case TAG_EFor: {
      heff_take_n(v_e1_242, 0ULL, 3);
      heff_drop(v_sp_243);
      V v_f_24285 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24289 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam26, 2, 1, (V[]){v_f_24285}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24290 = v_t_24289.f[0];
        V v_field_24291 = v_t_24289.f[1];
        V v_x_24292 = v_field_24290;
        heff_drop(v_x_24292);
        V v_y_24293 = v_field_24291;
        return v_y_24293;
      }
    }
    case TAG_EIfThen: {
      heff_take_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_f_24296 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24300 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam27, 2, 1, (V[]){v_f_24296}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24301 = v_t_24300.f[0];
        V v_field_24302 = v_t_24300.f[1];
        V v_x_24303 = v_field_24301;
        heff_drop(v_x_24303);
        V v_y_24304 = v_field_24302;
        return v_y_24304;
      }
    }
    case TAG_EBreak: {
      heff_drop_tag(v_e_241, 2);
      V v_t_24305 = heff_get_n(v_g_240, 1, 2);
      if ((heff_dup(v_t_24305) == NTAG(TAG_True))) {
        heff_drop(v_t_24305);
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eguardE_str2)}), v_sp_243});
      } else {
        heff_drop(v_t_24305);
        return heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_EBreak), v_sp_243});
      }
    }
    case TAG_EContinue: {
      heff_drop_tag(v_e_241, 2);
      V v_t_24306 = heff_get_n(v_g_240, 1, 2);
      if ((heff_dup(v_t_24306) == NTAG(TAG_True))) {
        heff_drop(v_t_24306);
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eguardE_str3)}), v_sp_243});
      } else {
        heff_drop(v_t_24306);
        return heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_EContinue), v_sp_243});
      }
    }
    case TAG_EReturn: {
      V v_v_24307 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24EReturn = heff_take_reuse_n(v_e1_242, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      V v_t_24308 = heff_dup(heff_rfield(v_g_240, 1));
      if ((heff_dup(v_t_24308) == NTAG(TAG_True))) {
        heff_drop_rec(v_g_240, 2);
        heff_drop(v_v_24307);
        heff_drop_cell(v_ru_24e1_242_24EReturn, 1);
        heff_drop(v_t_24308);
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eguardE_str4)}), v_sp_243});
      } else {
        heff_drop(v_t_24308);
        V v_t_24309 = (g_heff_2esyntax_2epresyntax_2eguardE(v_g_240, v_v_24307));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EReturn, TAG_EReturn, 1, (V[]){v_t_24309}), v_sp_243});
      }
    }
    case TAG_ENest: {
      V v_c_24310 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24ENest = heff_take_reuse_n(v_e1_242, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      V v_t_24311 = heff_dup(heff_rfield(v_g_240, 1));
      if ((heff_dup(v_t_24311) == NTAG(TAG_True))) {
        heff_drop_rec(v_g_240, 2);
        heff_drop(v_c_24310);
        heff_drop_cell(v_ru_24e1_242_24ENest, 1);
        heff_drop(v_t_24311);
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eguardE_str5)}), v_sp_243});
      } else {
        heff_drop(v_t_24311);
        V v_t_24312 = (g_heff_2esyntax_2epresyntax_2eguardE(v_g_240, v_c_24310));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ENest, TAG_ENest, 1, (V[]){v_t_24312}), v_sp_243});
      }
    }
    case TAG_EIfLet: {
      heff_take_n(v_e1_242, 0ULL, 4);
      heff_drop(v_sp_243);
      V v_f_24317 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24321 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam28, 2, 1, (V[]){v_f_24317}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24322 = v_t_24321.f[0];
        V v_field_24323 = v_t_24321.f[1];
        V v_x_24324 = v_field_24322;
        heff_drop(v_x_24324);
        V v_y_24325 = v_field_24323;
        return v_y_24325;
      }
    }
    case TAG_ETry: {
      heff_take_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_f_24327 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24331 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam29, 2, 1, (V[]){v_f_24327}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24332 = v_t_24331.f[0];
        V v_field_24333 = v_t_24331.f[1];
        V v_x_24334 = v_field_24332;
        heff_drop(v_x_24334);
        V v_y_24335 = v_field_24333;
        return v_y_24335;
      }
    }
    case TAG_EWith: {
      heff_take_n(v_e1_242, 0ULL, 4);
      heff_drop(v_sp_243);
      V v_f_24340 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24344 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam30, 2, 1, (V[]){v_f_24340}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24345 = v_t_24344.f[0];
        V v_field_24346 = v_t_24344.f[1];
        V v_x_24347 = v_field_24345;
        heff_drop(v_x_24347);
        V v_y_24348 = v_field_24346;
        return v_y_24348;
      }
    }
    default: return heff_nomatch(v_e1_242);
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eguardE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eguardE(a[0], a[1]);
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam0(V self, V *args) {
  V v_u_246 = args[0];
  V v_c_247 = args[1];
  V v_f_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tr(heff_call(v_f_245, 1, (V[]){v_c_247}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_246, v_t_248});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam1(V self, V *args) {
  V v_u_2416 = args[0];
  V v_c_2417 = args[1];
  V v_f_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_tr(heff_call(v_f_2415, 1, (V[]){v_c_2417}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2416, v_t_2418});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam2(V self, V *args) {
  V v_u_2426 = args[0];
  V v_c_2427 = args[1];
  V v_f_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = heff_tr(heff_call(v_f_2425, 1, (V[]){v_c_2427}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2426, v_t_2428});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam3(V self, V *args) {
  V v_u_2436 = args[0];
  V v_c_2437 = args[1];
  V v_f_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2438 = heff_tr(heff_call(v_f_2435, 1, (V[]){v_c_2437}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2436, v_t_2438});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam4(V self, V *args) {
  V v_u_2446 = args[0];
  V v_c_2447 = args[1];
  V v_f_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448 = heff_tr(heff_call(v_f_2445, 1, (V[]){v_c_2447}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2446, v_t_2448});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam5(V self, V *args) {
  V v_u_2456 = args[0];
  V v_c_2457 = args[1];
  V v_f_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458 = heff_tr(heff_call(v_f_2455, 1, (V[]){v_c_2457}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2456, v_t_2458});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam6(V self, V *args) {
  V v_u_2466 = args[0];
  V v_c_2467 = args[1];
  V v_f_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2468 = heff_tr(heff_call(v_f_2465, 1, (V[]){v_c_2467}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2466, v_t_2468});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam7(V self, V *args) {
  V v_u_2476 = args[0];
  V v_c_2477 = args[1];
  V v_f_2475 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2478 = heff_tr(heff_call(v_f_2475, 1, (V[]){v_c_2477}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2476, v_t_2478});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam8(V self, V *args) {
  V v_u_2486 = args[0];
  V v_c_2487 = args[1];
  V v_f_2485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2488 = heff_tr(heff_call(v_f_2485, 1, (V[]){v_c_2487}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2486, v_t_2488});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam9(V self, V *args) {
  V v_u_2497 = args[0];
  V v_c_2498 = args[1];
  V v_f_2496 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2499 = heff_tr(heff_call(v_f_2496, 1, (V[]){v_c_2498}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2497, v_t_2499});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam10(V self, V *args) {
  V v_u_24107 = args[0];
  V v_c_24108 = args[1];
  V v_f_24106 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24109 = heff_tr(heff_call(v_f_24106, 1, (V[]){v_c_24108}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24107, v_t_24109});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam11(V self, V *args) {
  V v_u_24118 = args[0];
  V v_c_24119 = args[1];
  V v_f_24117 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24120 = heff_tr(heff_call(v_f_24117, 1, (V[]){v_c_24119}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24118, v_t_24120});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam12(V self, V *args) {
  V v_u_24129 = args[0];
  V v_c_24130 = args[1];
  V v_f_24128 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24131 = heff_tr(heff_call(v_f_24128, 1, (V[]){v_c_24130}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24129, v_t_24131});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam13(V self, V *args) {
  V v_u_24144 = args[0];
  V v_c_24145 = args[1];
  V v_f_24143 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24146 = heff_tr(heff_call(v_f_24143, 1, (V[]){v_c_24145}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24144, v_t_24146});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam14(V self, V *args) {
  V v_u_24157 = args[0];
  V v_c_24158 = args[1];
  V v_f_24156 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24159 = heff_tr(heff_call(v_f_24156, 1, (V[]){v_c_24158}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24157, v_t_24159});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam15(V self, V *args) {
  V v_u_24167 = args[0];
  V v_c_24168 = args[1];
  V v_f_24166 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24169 = heff_tr(heff_call(v_f_24166, 1, (V[]){v_c_24168}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24167, v_t_24169});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam16(V self, V *args) {
  V v_u_24177 = args[0];
  V v_c_24178 = args[1];
  V v_f_24176 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24179 = heff_tr(heff_call(v_f_24176, 1, (V[]){v_c_24178}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24177, v_t_24179});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam17(V self, V *args) {
  V v_u_24187 = args[0];
  V v_c_24188 = args[1];
  V v_f_24186 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24189 = heff_tr(heff_call(v_f_24186, 1, (V[]){v_c_24188}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24187, v_t_24189});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam18(V self, V *args) {
  V v_u_24198 = args[0];
  V v_c_24199 = args[1];
  V v_f_24197 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24200 = heff_tr(heff_call(v_f_24197, 1, (V[]){v_c_24199}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24198, v_t_24200});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam19(V self, V *args) {
  V v_u_24209 = args[0];
  V v_c_24210 = args[1];
  V v_f_24208 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24211 = heff_tr(heff_call(v_f_24208, 1, (V[]){v_c_24210}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24209, v_t_24211});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam20(V self, V *args) {
  V v_u_24220 = args[0];
  V v_c_24221 = args[1];
  V v_f_24219 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24222 = heff_tr(heff_call(v_f_24219, 1, (V[]){v_c_24221}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24220, v_t_24222});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam21(V self, V *args) {
  V v_x_24229 = args[0];
  V v_ss_24228 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24230 = (g_heff_2esyntax_2epresyntax_2edeclaredMuts(v_ss_24228));
  V v_x1_24231 = ({ V a_0 = v_x_24229; V a_1 = v_t_24230; V r_ = (g_list_2eany_24s930586707x1164893977(a_0, a_1)); heff_drop(v_x_24229); heff_drop(v_t_24230); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_24231) == NTAG(TAG_True)));
  heff_drop(v_x1_24231);
  return v_ret_24bool;
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam22(V self, V *args) {
  V v_u_24236 = args[0];
  V v_c_24237 = args[1];
  V v_f_24234 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24238 = heff_tr(heff_call(v_f_24234, 1, (V[]){v_c_24237}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24236, v_t_24238});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam23(V self, V *args) {
  V v_u_24247 = args[0];
  V v_c_24248 = args[1];
  V v_f_24246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24249 = heff_tr(heff_call(v_f_24246, 1, (V[]){v_c_24248}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24247, v_t_24249});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam24(V self, V *args) {
  V v_u_24257 = args[0];
  V v_c_24258 = args[1];
  V v_f_24256 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24259 = heff_tr(heff_call(v_f_24256, 1, (V[]){v_c_24258}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24257, v_t_24259});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam25(V self, V *args) {
  V v_u_24274 = args[0];
  V v_c_24275 = args[1];
  V v_f_24273 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24276 = heff_tr(heff_call(v_f_24273, 1, (V[]){v_c_24275}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24274, v_t_24276});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam26(V self, V *args) {
  V v_u_24286 = args[0];
  V v_c_24287 = args[1];
  V v_f_24285 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24288 = heff_tr(heff_call(v_f_24285, 1, (V[]){v_c_24287}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24286, v_t_24288});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam27(V self, V *args) {
  V v_u_24297 = args[0];
  V v_c_24298 = args[1];
  V v_f_24296 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24299 = heff_tr(heff_call(v_f_24296, 1, (V[]){v_c_24298}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24297, v_t_24299});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam28(V self, V *args) {
  V v_u_24318 = args[0];
  V v_c_24319 = args[1];
  V v_f_24317 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24320 = heff_tr(heff_call(v_f_24317, 1, (V[]){v_c_24319}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24318, v_t_24320});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam29(V self, V *args) {
  V v_u_24328 = args[0];
  V v_c_24329 = args[1];
  V v_f_24327 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24330 = heff_tr(heff_call(v_f_24327, 1, (V[]){v_c_24329}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24328, v_t_24330});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam30(V self, V *args) {
  V v_u_24341 = args[0];
  V v_c_24342 = args[1];
  V v_f_24340 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24343 = heff_tr(heff_call(v_f_24340, 1, (V[]){v_c_24342}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24341, v_t_24343});
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str0, 1, "v");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str1, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str2, 1, "v");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str3, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str4, 1, "v");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str5, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str6, 1, "v");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str7, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str8, 1, "v");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str9, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str10, 1, "v");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str11, 1, "#");
V g_heff_2esyntax_2epresyntax_2eliftE_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V v_l_240, V v_acc_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_At: {
    V v_e1_243 = heff_dup(heff_field(v_e_242, 0));
    V v_sp_244 = heff_dup(heff_field(v_e_242, 1));
    switch (heff_tag_of(v_e1_243)) {
    case TAG_EVar: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_246 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_246, v_acc_241, v_e_242);
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_248 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_248, v_acc_241, v_e_242);
    }
    case TAG_ETag: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2410, v_acc_241, v_e_242);
    }
    case TAG_EInt: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2412, v_acc_241, v_e_242);
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2414, v_acc_241, v_e_242);
    }
    case TAG_EString: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2416 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2416, v_acc_241, v_e_242);
    }
    case TAG_EBinary: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2418 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2418, v_acc_241, v_e_242);
    }
    case TAG_ERune: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2420 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2420, v_acc_241, v_e_242);
    }
    case TAG_EWord: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2422 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2422, v_acc_241, v_e_242);
    }
    case TAG_EApp: {
      heff_take_n(v_e1_243, 0ULL, 2);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2425, v_acc_241, v_e_242);
    }
    case TAG_EProject: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2427, v_acc_241, v_e_242);
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_243, 0ULL, 2);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2430 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2430, v_acc_241, v_e_242);
    }
    case TAG_EPi: {
      heff_take_n(v_e1_243, 0ULL, 2);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2433 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2433, v_acc_241, v_e_242);
    }
    case TAG_ELam: {
      V v_b_2434 = heff_field(v_e1_243, 0);
      V v_body_2435 = heff_field(v_e1_243, 1);
      V v_ru_24e1_243_24ELam = heff_take_reuse_n(v_e1_243, 3ULL, 2);
      heff_drop_tag(v_e_242, 2);
      V v_t_2436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ELam, TAG_ELam, 2, (V[]){v_b_2434, v_body_2435}), v_sp_244});
      V v_f_2437 = (g_heff_2esyntax_2epresyntax_2eguardE(heff_get_n(v_l_240, 1, 2), v_t_2436));
      return ((HeffT2){{v_acc_241, v_f_2437}});
    }
    case TAG_EAnn: {
      heff_take_n(v_e1_243, 0ULL, 2);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2440 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2440, v_acc_241, v_e_242);
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_243, 0ULL, 4);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2445 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2445, v_acc_241, v_e_242);
    }
    case TAG_ESig: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2447 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2447, v_acc_241, v_e_242);
    }
    case TAG_ESum: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2449 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2449, v_acc_241, v_e_242);
    }
    case TAG_EStruct: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2451 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2451, v_acc_241, v_e_242);
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_243, 0ULL, 2);
      heff_drop_rec(v_sp_244, 2);
      V v_t_2454 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_2454, v_acc_241, v_e_242);
    }
    case TAG_EMatch: {
      V v_s_2455 = heff_field(v_e1_243, 0);
      V v_alts_2456 = heff_field(v_e1_243, 1);
      V v_ru_24e1_243_24EMatch = heff_take_reuse_n(v_e1_243, 3ULL, 2);
      heff_drop_tag(v_e_242, 2);
      HeffT2 v_t_2457 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_dup(v_l_240), v_acc_241, v_s_2455));
      {
        V v_field_2458 = v_t_2457.f[0];
        V v_field_2459 = v_t_2457.f[1];
        V v_x_2460 = v_field_2458;
        V v_y_2461 = v_field_2459;
        V v_t_2462 = (g_list_2eany_24s717144537x1885076661(v_alts_2456));
        if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
          heff_drop(v_t_2462);
          V v_t_2463 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
          V v_t_2464 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str1), v_t_2463));
          V v_t_2465 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){heff_dup(v_l_240)}));
          V v_t_2466 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2easAction_clo), 2, (V[]){v_t_2465, heff_get_n(v_l_240, 0, 2)}));
          V v_t_2467 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ealtBy_clo), 1, (V[]){v_t_2466}));
          V v_t_2468 = (g_list_2emap(v_t_2467, v_alts_2456));
          V v_t_2469 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24EMatch, TAG_EMatch, 2, (V[]){v_y_2461, v_t_2468}), heff_dup(v_sp_244)});
          V v_f_2470 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2464, v_t_2469}), v_x_2460});
          V v_t_2471 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
          V v_t_2472 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str2), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str3), v_t_2471));
          V v_f_2473 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2472}), v_sp_244});
          return ((HeffT2){{v_f_2470, v_f_2473}});
        } else {
          heff_drop(v_t_2462);
          V v_f_2474 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
          HeffT2 v_t_2485 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_lam0, 2, 1, (V[]){v_f_2474}), v_x_2460, v_alts_2456));
          {
            V v_field_2486 = v_t_2485.f[0];
            V v_field_2487 = v_t_2485.f[1];
            V v_x_2488 = v_field_2486;
            V v_y_2489 = v_field_2487;
            V v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24EMatch, TAG_EMatch, 2, (V[]){v_y_2461, v_y_2489}), v_sp_244});
            return ((HeffT2){{v_x_2488, v_t_2490}});
          }
        }
      }
    }
    case TAG_ELetIn: {
      V v_rhs_2491 = heff_field(v_e1_243, 0);
      V v_e12_2492 = heff_field(v_e1_243, 1);
      V v_ru_24e1_243_24ELetIn = heff_take_reuse_n(v_e1_243, 3ULL, 2);
      heff_drop_tag(v_e_242, 2);
      switch (heff_tag_of(v_e12_2492)) {
      case TAG_At: {
        V v_e121_2493 = heff_field(v_e12_2492, 0);
        V v_asp_2494 = heff_field(v_e12_2492, 1);
        V v_ru_24e12_2492_24At = heff_take_reuse_n(v_e12_2492, 3ULL, 2);
        switch (heff_tag_of(v_e121_2493)) {
        case TAG_MkAlt: {
          V v_p_2495 = heff_field(v_e121_2493, 0);
          V v_body_2496 = heff_field(v_e121_2493, 1);
          V v_ru_24e121_2493_24MkAlt = heff_take_reuse_n(v_e121_2493, 3ULL, 2);
          HeffT2 v_t_2497 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_dup(v_l_240), v_acc_241, v_rhs_2491));
          {
            V v_field_2498 = v_t_2497.f[0];
            V v_field_2499 = v_t_2497.f[1];
            V v_x_24100 = v_field_2498;
            V v_y_24101 = v_field_2499;
            V v_t_24102 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_body_2496)));
            if ((heff_dup(v_t_24102) == NTAG(TAG_True))) {
              heff_drop(v_t_24102);
              V v_t_24103 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
              V v_t_24104 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str4), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str5), v_t_24103));
              V v_lift_24105 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){heff_dup(v_l_240)}));
              V v_cx_24106 = heff_get_n(v_l_240, 0, 2);
              V v_x1_24107 = heff_tr(heff_call(v_lift_24105, 2, (V[]){NTAG(TAG_Nil), v_body_2496}));
              V v_t_24117;
              switch (heff_tag_of(v_x1_24107)) {
              case TAG_MkPair: {
                V v_x_24108 = heff_field(v_x1_24107, 0);
                V v_y_24109 = heff_field(v_x1_24107, 1);
                V v_ru_24x1_24107_24MkPair = heff_take_reuse_n(v_x1_24107, 3ULL, 2);
                V v_t_24110 = heff_get_n(heff_dup(heff_rfield(v_cx_24106, 0)), 1, 2);
                V v_t_24113;
                switch (heff_tag_of(v_y_24109)) {
                case TAG_At: {
                  V v_s_24112 = heff_dup(heff_field(v_y_24109, 1));
                  v_t_24113 = v_s_24112;
                  break;
                }
                default: heff_nomatch(v_y_24109);
                }
                V v_t_24114 = heff_tag_at_n(v_ru_24e12_2492_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24110}), v_t_24113});
                V v_t_24115 = heff_tag_at_n(v_ru_24x1_24107_24MkPair, TAG_Cons, 2, (V[]){v_y_24109, NTAG(TAG_Nil)});
                V v_t_24116 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24114, v_t_24115));
                v_t_24117 = ({ V a_0 = v_cx_24106; V a_1 = v_x_24108; V a_2 = v_t_24116; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24108); r_; });
                break;
              }
              default: heff_nomatch(v_x1_24107);
              }
              V v_t_24118 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e121_2493_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_2495, v_t_24117}), v_asp_2494});
              V v_t_24119 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ELetIn, TAG_ELetIn, 2, (V[]){v_y_24101, v_t_24118}), heff_dup(v_sp_244)});
              V v_f_24120 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24104, v_t_24119}), v_x_24100});
              V v_t_24121 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
              V v_t_24122 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str6), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str7), v_t_24121));
              V v_f_24123 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24122}), v_sp_244});
              return ((HeffT2){{v_f_24120, v_f_24123}});
            } else {
              heff_drop_cell(v_ru_24e121_2493_24MkAlt, 2);
              heff_drop(v_t_24102);
              HeffT2 v_t_24124 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(v_l_240, v_x_24100, v_body_2496));
              {
                V v_field_24125 = v_t_24124.f[0];
                V v_field_24126 = v_t_24124.f[1];
                V v_x_24127 = v_field_24125;
                V v_y_24128 = v_field_24126;
                V v_t_24129 = heff_tag_at_n(v_ru_24e12_2492_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2495, v_y_24128}), v_asp_2494});
                V v_t_24130 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ELetIn, TAG_ELetIn, 2, (V[]){v_y_24101, v_t_24129}), v_sp_244});
                return ((HeffT2){{v_x_24127, v_t_24130}});
              }
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_e121_2493)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_e12_2492)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24131 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24EDo = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      heff_drop_tag(v_e_242, 2);
      V v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24EDo, TAG_EDo, 1, (V[]){v_ss_24131}), v_sp_244});
      V v_f_24133 = (g_heff_2esyntax_2epresyntax_2eguardE(heff_get_n(v_l_240, 1, 2), v_t_24132));
      return ((HeffT2){{v_acc_241, v_f_24133}});
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_243, 0ULL, 2);
      heff_drop_rec(v_sp_244, 2);
      V v_t_24136 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24136, v_acc_241, v_e_242);
    }
    case TAG_EInvalid: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_24138 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24138, v_acc_241, v_e_242);
    }
    case TAG_EAssign: {
      heff_take_n(v_e1_243, 0ULL, 3);
      heff_drop_rec(v_sp_244, 2);
      V v_t_24142 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24142, v_acc_241, v_e_242);
    }
    case TAG_EWhile: {
      heff_take_n(v_e1_243, 0ULL, 2);
      heff_drop_rec(v_sp_244, 2);
      V v_t_24145 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24145, v_acc_241, v_e_242);
    }
    case TAG_EFor: {
      heff_take_n(v_e1_243, 0ULL, 3);
      heff_drop_rec(v_sp_244, 2);
      V v_t_24149 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24149, v_acc_241, v_e_242);
    }
    case TAG_EIfThen: {
      heff_take_n(v_e1_243, 0ULL, 2);
      heff_drop_rec(v_sp_244, 2);
      V v_t_24152 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24152, v_acc_241, v_e_242);
    }
    case TAG_EBreak: {
      heff_drop_rec(v_sp_244, 2);
      V v_t_24153 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24153, v_acc_241, v_e_242);
    }
    case TAG_EContinue: {
      heff_drop_rec(v_sp_244, 2);
      V v_t_24154 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24154, v_acc_241, v_e_242);
    }
    case TAG_EReturn: {
      heff_take_n(v_e1_243, 0ULL, 1);
      heff_drop_rec(v_sp_244, 2);
      V v_t_24156 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24156, v_acc_241, v_e_242);
    }
    case TAG_ENest: {
      V v_c_24157 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24ENest = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      heff_drop_tag(v_e_242, 2);
      HeffT2 v_t_24158 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(v_l_240, v_acc_241, v_c_24157));
      {
        V v_field_24159 = v_t_24158.f[0];
        V v_field_24160 = v_t_24158.f[1];
        V v_x_24161 = v_field_24159;
        V v_y_24162 = v_field_24160;
        V v_t_24163 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
        V v_t_24164 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str8), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str9), v_t_24163));
        V v_f_24165 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24164, v_y_24162}), v_x_24161});
        V v_t_24166 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
        V v_t_24167 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str10), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str11), v_t_24166));
        V v_f_24168 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ENest, TAG_EVar, 1, (V[]){v_t_24167}), v_sp_244});
        return ((HeffT2){{v_f_24165, v_f_24168}});
      }
    }
    case TAG_EIfLet: {
      V v_p_24169 = heff_field(v_e1_243, 0);
      V v_s_24170 = heff_field(v_e1_243, 1);
      V v_a_24171 = heff_field(v_e1_243, 2);
      V v_e14_24172 = heff_field(v_e1_243, 3);
      heff_take_n(v_e1_243, 15ULL, 4);
      switch (heff_tag_of(v_e14_24172)) {
      case TAG_Nothing: {
        heff_drop_rec(v_sp_244, 2);
        heff_drop(v_p_24169);
        heff_drop(v_s_24170);
        heff_drop(v_a_24171);
        V v_t_24173 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
        HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24173, v_acc_241, v_e_242);
      }
      case TAG_Just: {
        V v_b_24174 = heff_field(v_e14_24172, 0);
        heff_take_n(v_e14_24172, 1ULL, 1);
        heff_drop_tag(v_e_242, 2);
        V v_t_24175 = (g_heff_2esyntax_2epresyntax_2eifLetOf(v_sp_244, v_p_24169, v_s_24170, v_a_24171, v_b_24174));
        V t_0 = v_l_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24175;
        v_l_240 = t_0;
        v_acc_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_e14_24172)}});
      }
    }
    case TAG_ETry: {
      V v_tr_24176 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24ETry = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      heff_drop_rec(v_l_240, 2);
      heff_drop_tag(v_e_242, 2);
      V v_t_24177 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ETry, TAG_ETry, 1, (V[]){v_tr_24176}), v_sp_244});
      return ((HeffT2){{v_acc_241, v_t_24177}});
    }
    case TAG_EWith: {
      V v_w_24178 = heff_field(v_e1_243, 0);
      V v_x_24179 = heff_field(v_e1_243, 1);
      V v_xsp_24180 = heff_field(v_e1_243, 2);
      V v_body_24181 = heff_field(v_e1_243, 3);
      V v_ru_24e1_243_24EWith = heff_take_reuse_n(v_e1_243, 15ULL, 4);
      heff_drop_rec(v_l_240, 2);
      heff_drop_tag(v_e_242, 2);
      V v_t_24182 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24EWith, TAG_EWith, 4, (V[]){v_w_24178, v_x_24179, v_xsp_24180, v_body_24181}), v_sp_244});
      return ((HeffT2){{v_acc_241, v_t_24182}});
    }
    default: return ((HeffT2){{heff_nomatch(v_e1_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}
V g_heff_2esyntax_2epresyntax_2eliftE_24cpr_lam0(V self, V *args) {
  V v_st_2475 = args[0];
  V v_x3_2476 = args[1];
  V v_f_2474 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2476)) {
  case TAG_At: {
    V v_x31_2477 = heff_field(v_x3_2476, 0);
    V v_sp_2478 = heff_field(v_x3_2476, 1);
    V v_ru_24x3_2476_24At = heff_take_reuse_n(v_x3_2476, 3ULL, 2);
    switch (heff_tag_of(v_x31_2477)) {
    case TAG_MkAlt: {
      V v_p_2479 = heff_field(v_x31_2477, 0);
      V v_e_2480 = heff_field(v_x31_2477, 1);
      V v_ru_24x31_2477_24MkAlt = heff_take_reuse_n(v_x31_2477, 3ULL, 2);
      V v_x1_2481 = heff_tr(heff_call(v_f_2474, 2, (V[]){v_st_2475, v_e_2480}));
      switch (heff_tag_of(v_x1_2481)) {
      case TAG_MkPair: {
        V v_x_2482 = heff_field(v_x1_2481, 0);
        V v_y_2483 = heff_field(v_x1_2481, 1);
        heff_take_n(v_x1_2481, 3ULL, 2);
        V v_t_2484 = heff_tag_at_n(v_ru_24x3_2476_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2479, v_y_2483}), v_sp_2478});
        return heff_tag_at_n(v_ru_24x31_2477_24MkAlt, TAG_MkPair, 2, (V[]){v_x_2482, v_t_2484});
      }
      default: return heff_nomatch(v_x1_2481);
      }
    }
    default: return heff_nomatch(v_x31_2477);
    }
  }
  default: return heff_nomatch(v_x3_2476);
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str2, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str3, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str5, 85, "what a `catch` arm hears is its argument: `catch x -> ...`, or `catch (x : T) -> ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str6, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str7, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str8, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str9, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str10, 1, "`");
V g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr(V v_cx_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkCatchArm: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24MkCatchArm = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_LamName: {
      V v_t_2415;
      switch (heff_tag_of(v_x21_242)) {
      case TAG_LamName: {
        V v_x_246 = heff_dup(heff_field(v_x21_242, 0));
        if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str0), 2)) {
          heff_drop_cell(v_ru_24x2_241_24MkCatchArm, 2);
          heff_drop(v_x_246);
          v_t_2415 = NTAG(TAG_Nil);
        } else {
          v_t_2415 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_x_246, NTAG(TAG_Nil)});
        }
        break;
      }
      case TAG_LamImplicit: {
        V v_x_249 = heff_dup(heff_field(v_x21_242, 0));
        v_t_2415 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_x_249, NTAG(TAG_Nil)});
        break;
      }
      case TAG_LamAnn: {
        V v_x_2411 = heff_dup(heff_field(v_x21_242, 0));
        if (heff_strEq_c_lent(v_x_2411, ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str1), 2)) {
          heff_drop_cell(v_ru_24x2_241_24MkCatchArm, 2);
          heff_drop(v_x_2411);
          v_t_2415 = NTAG(TAG_Nil);
        } else {
          v_t_2415 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_x_2411, NTAG(TAG_Nil)});
        }
        break;
      }
      default: heff_nomatch(v_x21_242);
      }
      HeffT2 v_t_2417 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_lam0, 1, 1, (V[]){v_cx_240}), v_t_2415));
      {
        V v_field_2419 = v_t_2417.f[1];
        int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
        if ((v_tag_2418 == ((int64_t)0ULL))) {
          V v_x_2421 = v_field_2419;
          V v_t_2422 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str2), heff_strAppend(heff_dup(v_x_2421), ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str3)));
          V v_t_2423 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str4), heff_strAppend(v_x_2421, v_t_2422));
          V v_t_2431;
          switch (heff_tag_of(v_x21_242)) {
          case TAG_LamName: {
            V v_sp_2425 = heff_field(v_x21_242, 1);
            heff_take_n(v_x21_242, 2ULL, 2);
            v_t_2431 = v_sp_2425;
            break;
          }
          case TAG_LamImplicit: {
            V v_sp_2427 = heff_field(v_x21_242, 1);
            heff_take_n(v_x21_242, 2ULL, 2);
            v_t_2431 = v_sp_2427;
            break;
          }
          case TAG_LamAnn: {
            V v_sp_2429 = heff_field(v_x21_242, 1);
            heff_take_n(v_x21_242, 2ULL, 3);
            v_t_2431 = v_sp_2429;
            break;
          }
          default: heff_nomatch(v_x21_242);
          }
          V v_f_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2423}), v_t_2431});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2432}});
        } else {
          heff_drop_tag(v_x21_242, 2);
          heff_drop(v_field_2419);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    case TAG_LamImplicit: {
      V v_xsp_2434 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_rec(v_cx_240, 5);
      V v_t_2435 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str5)}), v_xsp_2434});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2435}});
    }
    case TAG_LamAnn: {
      V v_t_2448;
      switch (heff_tag_of(v_x21_242)) {
      case TAG_LamName: {
        V v_x_2439 = heff_dup(heff_field(v_x21_242, 0));
        if (heff_strEq_c_lent(v_x_2439, ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str6), 2)) {
          heff_drop_cell(v_ru_24x2_241_24MkCatchArm, 2);
          heff_drop(v_x_2439);
          v_t_2448 = NTAG(TAG_Nil);
        } else {
          v_t_2448 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_x_2439, NTAG(TAG_Nil)});
        }
        break;
      }
      case TAG_LamImplicit: {
        V v_x_2442 = heff_dup(heff_field(v_x21_242, 0));
        v_t_2448 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_x_2442, NTAG(TAG_Nil)});
        break;
      }
      case TAG_LamAnn: {
        V v_x_2444 = heff_dup(heff_field(v_x21_242, 0));
        if (heff_strEq_c_lent(v_x_2444, ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str7), 2)) {
          heff_drop_cell(v_ru_24x2_241_24MkCatchArm, 2);
          heff_drop(v_x_2444);
          v_t_2448 = NTAG(TAG_Nil);
        } else {
          v_t_2448 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_x_2444, NTAG(TAG_Nil)});
        }
        break;
      }
      default: heff_nomatch(v_x21_242);
      }
      HeffT2 v_t_2450 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_lam1, 1, 1, (V[]){v_cx_240}), v_t_2448));
      {
        V v_field_2452 = v_t_2450.f[1];
        int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
        if ((v_tag_2451 == ((int64_t)0ULL))) {
          V v_x_2454 = v_field_2452;
          V v_t_2455 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str8), heff_strAppend(heff_dup(v_x_2454), ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str9)));
          V v_t_2456 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str10), heff_strAppend(v_x_2454, v_t_2455));
          V v_t_2464;
          switch (heff_tag_of(v_x21_242)) {
          case TAG_LamName: {
            V v_sp_2458 = heff_field(v_x21_242, 1);
            heff_take_n(v_x21_242, 2ULL, 2);
            v_t_2464 = v_sp_2458;
            break;
          }
          case TAG_LamImplicit: {
            V v_sp_2460 = heff_field(v_x21_242, 1);
            heff_take_n(v_x21_242, 2ULL, 2);
            v_t_2464 = v_sp_2460;
            break;
          }
          case TAG_LamAnn: {
            V v_sp_2462 = heff_field(v_x21_242, 1);
            heff_take_n(v_x21_242, 2ULL, 3);
            v_t_2464 = v_sp_2462;
            break;
          }
          default: heff_nomatch(v_x21_242);
          }
          V v_f_2465 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2456}), v_t_2464});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2465}});
        } else {
          heff_drop_tag(v_x21_242, 3);
          heff_drop(v_field_2452);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_lam0(V self, V *args) {
  V v_x_2416 = args[0];
  V v_cx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2416; V b_1 = heff_get_n(v_cx_240, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_2416); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_lam1(V self, V *args) {
  V v_x_2449 = args[0];
  V v_cx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2449; V b_1 = heff_get_n(v_cx_240, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_2449); heff_drop(b_1); r_; });
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2escopeJoin_str0, 4, "join");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2escopeJoin_str1, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2escopeJoin_str2, 4, "join");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2escopeJoin_str3, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2escopeJoin_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2escopeJoin_entry, 6, 0};

V g_heff_2esyntax_2epresyntax_2escopeJoin(V v_t_240, V v_cx_241, V v_sp_242, V v_scope_243, V v_rest_244, V v_end_245) {
top: ;
  V v_t_246 = heff_intShow(heff_dup(heff_rfield(v_sp_242, 0)));
  V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2escopeJoin_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2escopeJoin_str1), v_t_246));
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_247}), heff_dup(v_sp_242)});
  V v_t_249 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){v_t_248, heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_241, 4))});
  V v_t_2410 = heff_tr(heff_call(v_scope_243, 1, (V[]){heff_tag_n(TAG_EndJump, 1, (V[]){v_t_249})}));
  V v_t_2411 = heff_intShow(heff_dup(heff_rfield(v_sp_242, 0)));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2escopeJoin_str2), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2escopeJoin_str3), v_t_2411));
  V v_t_2413 = ({ V a_0 = heff_dup(v_sp_242); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_241, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2414 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){v_cx_241, v_rest_244, v_end_245}));
  V v_t_2415 = (g_heff_2esyntax_2epresyntax_2elocalFun(v_t_2412, heff_dup(v_sp_242), v_t_2413, v_t_2414));
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELocal, 2, (V[]){v_t_2410, v_t_2416}), v_sp_242});
}
V g_heff_2esyntax_2epresyntax_2escopeJoin_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2escopeJoin(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithT_str0, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithT_str1, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithT_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithT_str3, 69, "nothing after this `with` runs: its statements do not reach their end");
Clo g_heff_2esyntax_2epresyntax_2ewithT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewithT_entry, 9, 0};

V g_heff_2esyntax_2epresyntax_2ewithT(V v_t_240, V v_cx_241, V v_sp_242, V v_w_243, V v_x_244, V v_xsp_245, V v_body_246, V v_rest_247, V v_end_248) {
top: ;
  V v_t_249 = (g_list_2eany_24s930586707x1164893977(v_x_244, heff_rfield(v_cx_241, 1)));
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_240);
    heff_drop_rec(v_cx_241, 5);
    heff_drop(v_sp_242);
    heff_drop(v_w_243);
    heff_drop(v_body_246);
    heff_drop(v_rest_247);
    heff_drop(v_end_248);
    heff_drop(v_t_249);
    V v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewithT_str0), heff_strAppend(heff_dup(v_x_244), ((V)&g_heff_2esyntax_2epresyntax_2ewithT_str1)));
    V v_t_2411 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewithT_str2), heff_strAppend(v_x_244, v_t_2410));
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2411}), v_xsp_245});
  } else {
    heff_drop(v_t_249);
    V v_scope_2412 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ewithScopeOf_clo), 7, (V[]){heff_dup(v_t_240), heff_dup(v_cx_241), heff_dup(v_sp_242), v_w_243, v_x_244, v_xsp_245, heff_dup(v_body_246)}));
    V v_x1_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_body_246));
    switch (heff_tag_of(v_x1_2413)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_rest_247)) {
      case TAG_Nil: {
        heff_drop(v_t_240);
        heff_drop_rec(v_cx_241, 5);
        heff_drop(v_sp_242);
        return heff_tail(v_scope_2412, 1, (V[]){v_end_248});
      }
      case TAG_Cons: {
        V v_s_2414 = heff_field(v_rest_247, 0);
        V v_rest_2415 = heff_field(v_rest_247, 1);
        V v_ru_24rest_247_24Cons = heff_take_reuse_n(v_rest_247, 3ULL, 2);
        return (g_heff_2esyntax_2epresyntax_2escopeJoin(v_t_240, v_cx_241, v_sp_242, v_scope_2412, heff_tag_at_n(v_ru_24rest_247_24Cons, TAG_Cons, 2, (V[]){v_s_2414, v_rest_2415}), v_end_248));
      }
      default: return heff_nomatch(v_rest_247);
      }
    }
    case TAG_Cons: {
      V v_x_2416 = heff_field(v_x1_2413, 0);
      V v_ru_24x1_2413_24Cons = heff_take_reuse_n(v_x1_2413, 1ULL, 2);
      switch (heff_tag_of(v_x_2416)) {
      case TAG_At: {
        V v_it11_2418 = heff_field(v_x_2416, 0);
        V v_ru_24x_2416_24At = heff_take_reuse_n(v_x_2416, 1ULL, 2);
        switch (heff_tag_of(v_it11_2418)) {
        case TAG_StmtBind: {
          heff_take_n(v_it11_2418, 0ULL, 3);
          heff_drop_cell(v_ru_24x_2416_24At, 2);
          switch (heff_tag_of(v_rest_247)) {
          case TAG_Nil: {
            heff_drop(v_t_240);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_sp_242);
            heff_drop_cell(v_ru_24x1_2413_24Cons, 2);
            return heff_tail(v_scope_2412, 1, (V[]){v_end_248});
          }
          case TAG_Cons: {
            V v_s_2423 = heff_field(v_rest_247, 0);
            V v_rest_2424 = heff_field(v_rest_247, 1);
            heff_take_n(v_rest_247, 3ULL, 2);
            return (g_heff_2esyntax_2epresyntax_2escopeJoin(v_t_240, v_cx_241, v_sp_242, v_scope_2412, heff_tag_at_n(v_ru_24x1_2413_24Cons, TAG_Cons, 2, (V[]){v_s_2423, v_rest_2424}), v_end_248));
          }
          default: return heff_nomatch(v_rest_247);
          }
        }
        case TAG_StmtLet: {
          heff_take_n(v_it11_2418, 0ULL, 2);
          heff_drop_cell(v_ru_24x_2416_24At, 2);
          switch (heff_tag_of(v_rest_247)) {
          case TAG_Nil: {
            heff_drop(v_t_240);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_sp_242);
            heff_drop_cell(v_ru_24x1_2413_24Cons, 2);
            return heff_tail(v_scope_2412, 1, (V[]){v_end_248});
          }
          case TAG_Cons: {
            V v_s_2427 = heff_field(v_rest_247, 0);
            V v_rest_2428 = heff_field(v_rest_247, 1);
            heff_take_n(v_rest_247, 3ULL, 2);
            return (g_heff_2esyntax_2epresyntax_2escopeJoin(v_t_240, v_cx_241, v_sp_242, v_scope_2412, heff_tag_at_n(v_ru_24x1_2413_24Cons, TAG_Cons, 2, (V[]){v_s_2427, v_rest_2428}), v_end_248));
          }
          default: return heff_nomatch(v_rest_247);
          }
        }
        case TAG_StmtExpr: {
          V v_e_2429 = heff_field(v_it11_2418, 0);
          heff_take_n(v_it11_2418, 1ULL, 1);
          V v_falls_2430 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_e_2429));
          switch (heff_tag_of(v_rest_247)) {
          case TAG_Nil: {
            heff_drop(v_t_240);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_sp_242);
            heff_drop_cell(v_ru_24x1_2413_24Cons, 2);
            heff_drop_cell(v_ru_24x_2416_24At, 2);
            heff_drop(v_falls_2430);
            return heff_tail(v_scope_2412, 1, (V[]){v_end_248});
          }
          case TAG_Cons: {
            V v_s_2431 = heff_field(v_rest_247, 0);
            V v_rest_2432 = heff_field(v_rest_247, 1);
            heff_take_n(v_rest_247, 3ULL, 2);
            if ((heff_dup(v_falls_2430) == NTAG(TAG_True))) {
              heff_drop_cell(v_ru_24x_2416_24At, 2);
              heff_drop(v_falls_2430);
              return (g_heff_2esyntax_2epresyntax_2escopeJoin(v_t_240, v_cx_241, v_sp_242, v_scope_2412, heff_tag_at_n(v_ru_24x1_2413_24Cons, TAG_Cons, 2, (V[]){v_s_2431, v_rest_2432}), v_end_248));
            } else {
              heff_drop(v_t_240);
              heff_drop_rec(v_cx_241, 5);
              heff_drop(v_sp_242);
              heff_drop(v_end_248);
              heff_drop(v_scope_2412);
              heff_drop_cell(v_ru_24x1_2413_24Cons, 2);
              heff_drop(v_falls_2430);
              heff_drop(v_rest_2432);
              V v_t_2435;
              switch (heff_tag_of(v_s_2431)) {
              case TAG_At: {
                V v_s_2434 = heff_field(v_s_2431, 1);
                heff_take_n(v_s_2431, 2ULL, 2);
                v_t_2435 = v_s_2434;
                break;
              }
              default: heff_nomatch(v_s_2431);
              }
              return heff_tag_at_n(v_ru_24x_2416_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithT_str3)}), v_t_2435});
            }
          }
          default: return heff_nomatch(v_rest_247);
          }
        }
        case TAG_StmtLetMut: {
          heff_take_n(v_it11_2418, 0ULL, 3);
          heff_drop_cell(v_ru_24x_2416_24At, 2);
          switch (heff_tag_of(v_rest_247)) {
          case TAG_Nil: {
            heff_drop(v_t_240);
            heff_drop_rec(v_cx_241, 5);
            heff_drop(v_sp_242);
            heff_drop_cell(v_ru_24x1_2413_24Cons, 2);
            return heff_tail(v_scope_2412, 1, (V[]){v_end_248});
          }
          case TAG_Cons: {
            V v_s_2439 = heff_field(v_rest_247, 0);
            V v_rest_2440 = heff_field(v_rest_247, 1);
            heff_take_n(v_rest_247, 3ULL, 2);
            return (g_heff_2esyntax_2epresyntax_2escopeJoin(v_t_240, v_cx_241, v_sp_242, v_scope_2412, heff_tag_at_n(v_ru_24x1_2413_24Cons, TAG_Cons, 2, (V[]){v_s_2439, v_rest_2440}), v_end_248));
          }
          default: return heff_nomatch(v_rest_247);
          }
        }
        default: return heff_nomatch(v_it11_2418);
        }
      }
      default: return heff_nomatch(v_x_2416);
      }
    }
    default: return heff_nomatch(v_x1_2413);
    }
  }
}
V g_heff_2esyntax_2epresyntax_2ewithT_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewithT(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_str0, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_str1, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_str2, 4, "last");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_str3, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_str4, 4, "last");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_str5, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_str6, 36, "a `do` block ends with an expression");
Clo g_heff_2esyntax_2epresyntax_2elastT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elastT_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2elastT(V v_t_240, V v_cx_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_sp_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_StmtBind: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_t_240);
      heff_drop_rec(v_cx_241, 5);
      return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_str0)}), v_sp_244});
    }
    case TAG_StmtLet: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_t_240);
      heff_drop_rec(v_cx_241, 5);
      return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_str1)}), v_sp_244});
    }
    case TAG_StmtExpr: {
      V v_e_2410 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24StmtExpr = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      V v_t_2411 = (g_heff_2esyntax_2epresyntax_2eisControl(heff_dup(v_e_2410)));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop_rec(v_sp_244, 2);
        heff_drop_cell(v_ru_24x3_242_24At, 2);
        heff_drop_cell(v_ru_24x31_243_24StmtExpr, 1);
        heff_drop(v_t_2411);
        return (g_heff_2esyntax_2epresyntax_2econtrolT(v_t_240, v_cx_241, v_e_2410, NTAG(TAG_Nil), NTAG(TAG_EndValue)));
      } else {
        heff_drop(v_t_240);
        heff_drop(v_t_2411);
        if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_cx_241, 4)))) {
          V v_t_2413 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
          HeffT2 v_t_2414 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2413}), NTAG(TAG_Nil), v_e_2410));
          {
            V v_field_2415 = v_t_2414.f[0];
            V v_field_2416 = v_t_2414.f[1];
            V v_x_2417 = v_field_2415;
            V v_y_2418 = v_field_2416;
            V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 1, 2);
            V v_t_2420 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2419}), heff_dup(v_sp_244)});
            V v_t_2421 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
            V v_t_2422 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_str2), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_str3), v_t_2421));
            V v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24StmtExpr, TAG_EVar, 1, (V[]){v_t_2422}), heff_dup(v_sp_244)});
            V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
            V v_t_2425 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2420, v_t_2424));
            V v_rest_2426 = (g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_241), heff_dup(v_sp_244), heff_dup(heff_rfield(v_cx_241, 4)), v_t_2425));
            V v_t_2427 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 2);
            V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2427}), heff_dup(heff_rfield(v_cx_241, 3))});
            V v_t_2429 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
            V v_t_2430 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_str4), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_str5), v_t_2429));
            V v_t_2431 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_t_2430, heff_dup(v_sp_244)}), heff_dup(v_rest_2426)});
            V v_t_2434;
            switch (heff_tag_of(v_rest_2426)) {
            case TAG_At: {
              V v_s_2433 = heff_field(v_rest_2426, 1);
              heff_take_n(v_rest_2426, 2ULL, 2);
              v_t_2434 = v_s_2433;
              break;
            }
            default: heff_nomatch(v_rest_2426);
            }
            V v_t_2435 = ({ V rv_1 = heff_get_n(v_t_2434, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_244, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2431, v_t_2435}), NTAG(TAG_Nil)});
            V v_t_2437 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2428, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2418, v_t_2436})));
            return ({ V a_0 = v_cx_241; V a_1 = v_x_2417; V a_2 = v_t_2437; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2417); r_; });
          }
        } else {
          heff_drop_rec(v_sp_244, 2);
          heff_drop_cell(v_ru_24x3_242_24At, 2);
          heff_drop_cell(v_ru_24x31_243_24StmtExpr, 1);
          V v_t_2438 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
          HeffT2 v_t_2439 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2438}), NTAG(TAG_Nil), v_e_2410));
          {
            V v_field_2440 = v_t_2439.f[0];
            V v_field_2441 = v_t_2439.f[1];
            V v_x_2442 = v_field_2440;
            V v_y_2443 = v_field_2441;
            return ({ V a_0 = v_cx_241; V a_1 = v_x_2442; V a_2 = v_y_2443; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2442); r_; });
          }
        }
      }
    }
    case TAG_StmtLetMut: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_t_240);
      heff_drop_rec(v_cx_241, 5);
      return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_str6)}), v_sp_244});
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2epresyntax_2elastT_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2elastT(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2echeckedWays_str0, 235, "any of these: give the type where it is bound, `let x : T = ...`; give it in place, `(e : T)`; or write it where a type is expected of it, as an argument of a function whose type is known or as the body of a definition with a signature");

static V g_heff_2esyntax_2epresyntax_2echeckedWays_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2echeckedWays_st;
static V g_heff_2esyntax_2epresyntax_2echeckedWays_init(void) {
  return ((V)&g_heff_2esyntax_2epresyntax_2echeckedWays_str0);
}
V g_heff_2esyntax_2epresyntax_2echeckedWays_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2echeckedWays_st)) return g_heff_2esyntax_2epresyntax_2echeckedWays_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2echeckedWays_val, &g_heff_2esyntax_2epresyntax_2echeckedWays_st, g_heff_2esyntax_2epresyntax_2echeckedWays_init);
}
V g_heff_2esyntax_2epresyntax_2evariantOf_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2evariantOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2evariantOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2evariantOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_TagVariant: {
      V v_t_244 = heff_field(v_x21_242, 0);
      V v_tsp_245 = heff_field(v_x21_242, 1);
      V v_args_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2evariantOf_lam0, 1, 1, (V[]){v_r_240}), v_args_246));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TagVariant, 3, (V[]){v_t_244, v_tsp_245, v_t_2418}), v_sp_243});
    }
    case TAG_BadVariant: {
      V v_e_2419 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24BadVariant = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2419}));
      V v_t_2430;
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_IsInferable: {
        V v_i_2421 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2424;
        switch (heff_tag_of(v_i_2421)) {
        case TAG_At: {
          V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_i_2421);
        }
        v_t_2430 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2421}), v_t_2424});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2425 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2428;
        switch (heff_tag_of(v_c_2425)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_c_2425, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_c_2425);
        }
        v_t_2430 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2425}), v_t_2428});
        break;
      }
      case TAG_IsType: {
        V v_t_2429 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2430 = v_t_2429;
        break;
      }
      default: heff_nomatch(v_x1_2420);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2430}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2evariantOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2evariantOf(a[0], a[1]);
}
V g_heff_2esyntax_2epresyntax_2evariantOf_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_IsInferable: {
    V v_i_249 = heff_field(v_x1_248, 0);
    V v_ru_24x1_248_24IsInferable = heff_take_reuse_n(v_x1_248, 1ULL, 1);
    V v_t_2412;
    switch (heff_tag_of(v_i_249)) {
    case TAG_At: {
      V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
      v_t_2412 = v_s_2411;
      break;
    }
    default: heff_nomatch(v_i_249);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_248_24IsInferable, TAG_TInf, 1, (V[]){v_i_249}), v_t_2412});
  }
  case TAG_IsCheckable: {
    V v_c_2413 = heff_field(v_x1_248, 0);
    V v_ru_24x1_248_24IsCheckable = heff_take_reuse_n(v_x1_248, 1ULL, 1);
    V v_t_2416;
    switch (heff_tag_of(v_c_2413)) {
    case TAG_At: {
      V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
      v_t_2416 = v_s_2415;
      break;
    }
    default: heff_nomatch(v_c_2413);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_248_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
  }
  case TAG_IsType: {
    V v_t_2417 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    return v_t_2417;
  }
  default: return heff_nomatch(v_x1_248);
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str0, 9, "bitsOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str1, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str2, 17, "prelude.bitsSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str3, 17, "prelude.bitsSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str4, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str5, 11, "bitsOfBytes");
Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026(V v_lit_240, V v_r_241, V v_seg_242) {
top: ;
  switch (heff_tag_of(v_seg_242)) {
  case TAG_At: {
    V v_seg1_243 = heff_dup(heff_field(v_seg_242, 0));
    V v_sp_244 = heff_dup(heff_field(v_seg_242, 1));
    switch (heff_tag_of(v_seg1_243)) {
    case TAG_MkSegment: {
      V v_v_245 = heff_field(v_seg1_243, 0);
      V v_seg12_246 = heff_field(v_seg1_243, 1);
      V v_size_247 = heff_field(v_seg1_243, 2);
      V v_little_248 = heff_field(v_seg1_243, 3);
      V v_signed_249 = heff_field(v_seg1_243, 4);
      heff_take_n(v_seg1_243, 31ULL, 5);
      switch (heff_tag_of(v_seg12_246)) {
      case TAG_SegmentInteger: {
        heff_drop(v_lit_240);
        heff_drop_tag(v_seg_242, 2);
        V v_t_2410 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_247, MK_INT(8LL), heff_dup(v_sp_244)));
        int64_t v_t_2411;
        if ((heff_dup(v_little_248) == NTAG(TAG_True))) {
          heff_drop(v_little_248);
          v_t_2411 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_248);
          v_t_2411 = ((int64_t)0ULL);
        }
        int64_t v_t_2412;
        if ((heff_dup(v_signed_249) == NTAG(TAG_True))) {
          heff_drop(v_signed_249);
          v_t_2412 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_249);
          v_t_2412 = ((int64_t)0ULL);
        }
        V v_t_2413 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_2411 + v_t_2412))});
        V v_t_2414 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_244)})});
        V v_x1_2415 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){v_v_245}));
        V v_t_2425;
        switch (heff_tag_of(v_x1_2415)) {
        case TAG_IsInferable: {
          V v_i_2416 = heff_field(v_x1_2415, 0);
          V v_ru_24x1_2415_24IsInferable = heff_take_reuse_n(v_x1_2415, 1ULL, 1);
          V v_t_2419;
          switch (heff_tag_of(v_i_2416)) {
          case TAG_At: {
            V v_s_2418 = heff_dup(heff_field(v_i_2416, 1));
            v_t_2419 = v_s_2418;
            break;
          }
          default: heff_nomatch(v_i_2416);
          }
          v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2415_24IsInferable, TAG_CInf, 1, (V[]){v_i_2416}), v_t_2419});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2420 = heff_field(v_x1_2415, 0);
          heff_take_n(v_x1_2415, 1ULL, 1);
          v_t_2425 = v_c_2420;
          break;
        }
        case TAG_IsType: {
          V v_t_2421 = heff_field(v_x1_2415, 0);
          V v_ru_24x1_2415_24IsType = heff_take_reuse_n(v_x1_2415, 1ULL, 1);
          V v_t_2424;
          switch (heff_tag_of(v_t_2421)) {
          case TAG_At: {
            V v_s_2423 = heff_dup(heff_field(v_t_2421, 1));
            v_t_2424 = v_s_2423;
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
          v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2415_24IsType, TAG_CType, 1, (V[]){v_t_2421}), v_t_2424});
          break;
        }
        default: heff_nomatch(v_x1_2415);
        }
        V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
        V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, heff_dup(v_sp_244)}), v_t_2426});
        V v_args_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2427});
        V v_t_2429 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_244), v_args_2428));
        V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str0)}), heff_dup(v_sp_244)});
        V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2430, v_t_2429}), heff_dup(v_sp_244)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2431}), v_sp_244});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_lit_240);
        heff_drop(v_sp_244);
        heff_drop(v_v_245);
        heff_drop(v_size_247);
        heff_drop(v_little_248);
        heff_drop(v_signed_249);
        V v_t_2432 = (g_heff_2esyntax_2epresyntax_2ebytesPart(v_r_241, heff_dup(v_seg_242)));
        V v_args_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
        V v_sp_2436;
        switch (heff_tag_of(v_seg_242)) {
        case TAG_At: {
          V v_s_2435 = heff_field(v_seg_242, 1);
          heff_take_n(v_seg_242, 2ULL, 2);
          v_sp_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_seg_242);
        }
        V v_t_2437 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2436), v_args_2433));
        V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str1)}), heff_dup(v_sp_2436)});
        V v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2438, v_t_2437}), heff_dup(v_sp_2436)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2439}), v_sp_2436});
      }
      case TAG_SegmentBits: {
        heff_drop_tag(v_seg_242, 2);
        heff_drop(v_little_248);
        heff_drop(v_signed_249);
        switch (heff_tag_of(v_size_247)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_244);
          switch (heff_tag_of(v_v_245)) {
          case TAG_At: {
            V v_e_2440 = heff_field(v_v_245, 0);
            V v_sp_2441 = heff_field(v_v_245, 1);
            V v_ru_24v_245_24At = heff_take_reuse_n(v_v_245, 3ULL, 2);
            HeffT2 v_t_2442 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(heff_dup(v_e_2440)));
            {
              V v_field_2444 = v_t_2442.f[1];
              int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
              if ((v_tag_2443 == ((int64_t)0ULL))) {
                heff_drop_rec(v_r_241, 2);
                heff_drop(v_e_2440);
                V v_segs_2446 = v_field_2444;
                HeffT1 v_t_2447 = ({ V a_0 = v_lit_240; V b_1 = NTAG(TAG_True); V a_2 = v_segs_2446; V a_3 = v_sp_2441; HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
                {
                  V v_field_2448 = v_t_2447.f[0];
                  V v_a_2449 = v_field_2448;
                  V v_t_2452;
                  switch (heff_tag_of(v_a_2449)) {
                  case TAG_At: {
                    V v_a_2451 = heff_dup(heff_field(v_a_2449, 1));
                    v_t_2452 = v_a_2451;
                    break;
                  }
                  default: heff_nomatch(v_a_2449);
                  }
                  return heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_2449}), v_t_2452});
                }
              } else {
                heff_drop(v_lit_240);
                heff_drop(v_field_2444);
                V v_x1_2453 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_e_2440, v_sp_2441})}));
                switch (heff_tag_of(v_x1_2453)) {
                case TAG_IsInferable: {
                  V v_i_2454 = heff_field(v_x1_2453, 0);
                  heff_take_n(v_x1_2453, 1ULL, 1);
                  V v_t_2457;
                  switch (heff_tag_of(v_i_2454)) {
                  case TAG_At: {
                    V v_s_2456 = heff_dup(heff_field(v_i_2454, 1));
                    v_t_2457 = v_s_2456;
                    break;
                  }
                  default: heff_nomatch(v_i_2454);
                  }
                  return heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2454}), v_t_2457});
                }
                case TAG_IsCheckable: {
                  V v_c_2458 = heff_field(v_x1_2453, 0);
                  heff_take_n(v_x1_2453, 1ULL, 1);
                  heff_drop_cell(v_ru_24v_245_24At, 2);
                  return v_c_2458;
                }
                case TAG_IsType: {
                  V v_t_2459 = heff_field(v_x1_2453, 0);
                  heff_take_n(v_x1_2453, 1ULL, 1);
                  V v_t_2462;
                  switch (heff_tag_of(v_t_2459)) {
                  case TAG_At: {
                    V v_s_2461 = heff_dup(heff_field(v_t_2459, 1));
                    v_t_2462 = v_s_2461;
                    break;
                  }
                  default: heff_nomatch(v_t_2459);
                  }
                  return heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2459}), v_t_2462});
                }
                default: return heff_nomatch(v_x1_2453);
                }
              }
            }
          }
          default: return heff_nomatch(v_v_245);
          }
        }
        case TAG_SizeNumber: {
          V v_t_2464 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_247, MK_INT(0LL), heff_dup(v_sp_244)));
          V v_t_2488;
          switch (heff_tag_of(v_v_245)) {
          case TAG_At: {
            V v_e_2465 = heff_field(v_v_245, 0);
            V v_sp_2466 = heff_field(v_v_245, 1);
            V v_ru_24v_245_24At = heff_take_reuse_n(v_v_245, 3ULL, 2);
            HeffT2 v_t_2467 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(heff_dup(v_e_2465)));
            {
              V v_field_2469 = v_t_2467.f[1];
              int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
              if ((v_tag_2468 == ((int64_t)0ULL))) {
                heff_drop_rec(v_r_241, 2);
                heff_drop(v_e_2465);
                V v_segs_2471 = v_field_2469;
                HeffT1 v_t_2472 = ({ V a_0 = v_lit_240; V b_1 = NTAG(TAG_True); V a_2 = v_segs_2471; V a_3 = v_sp_2466; HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
                {
                  V v_field_2473 = v_t_2472.f[0];
                  V v_a_2474 = v_field_2473;
                  V v_t_2477;
                  switch (heff_tag_of(v_a_2474)) {
                  case TAG_At: {
                    V v_a_2476 = heff_dup(heff_field(v_a_2474, 1));
                    v_t_2477 = v_a_2476;
                    break;
                  }
                  default: heff_nomatch(v_a_2474);
                  }
                  v_t_2488 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_2474}), v_t_2477});
                }
              } else {
                heff_drop(v_lit_240);
                heff_drop(v_field_2469);
                V v_x1_2478 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_e_2465, v_sp_2466})}));
                switch (heff_tag_of(v_x1_2478)) {
                case TAG_IsInferable: {
                  V v_i_2479 = heff_field(v_x1_2478, 0);
                  heff_take_n(v_x1_2478, 1ULL, 1);
                  V v_t_2482;
                  switch (heff_tag_of(v_i_2479)) {
                  case TAG_At: {
                    V v_s_2481 = heff_dup(heff_field(v_i_2479, 1));
                    v_t_2482 = v_s_2481;
                    break;
                  }
                  default: heff_nomatch(v_i_2479);
                  }
                  v_t_2488 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2479}), v_t_2482});
                  break;
                }
                case TAG_IsCheckable: {
                  V v_c_2483 = heff_field(v_x1_2478, 0);
                  heff_take_n(v_x1_2478, 1ULL, 1);
                  heff_drop_cell(v_ru_24v_245_24At, 2);
                  v_t_2488 = v_c_2483;
                  break;
                }
                case TAG_IsType: {
                  V v_t_2484 = heff_field(v_x1_2478, 0);
                  heff_take_n(v_x1_2478, 1ULL, 1);
                  V v_t_2487;
                  switch (heff_tag_of(v_t_2484)) {
                  case TAG_At: {
                    V v_s_2486 = heff_dup(heff_field(v_t_2484, 1));
                    v_t_2487 = v_s_2486;
                    break;
                  }
                  default: heff_nomatch(v_t_2484);
                  }
                  v_t_2488 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2484}), v_t_2487});
                  break;
                }
                default: heff_nomatch(v_x1_2478);
                }
              }
            }
            break;
          }
          default: heff_nomatch(v_v_245);
          }
          V v_t_2489 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2488, NTAG(TAG_Nil)});
          V v_args_2490 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2464, v_t_2489});
          V v_t_2491 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_244), v_args_2490));
          V v_t_2492 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str2)}), heff_dup(v_sp_244)});
          V v_t_2493 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2492, v_t_2491}), heff_dup(v_sp_244)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2493}), v_sp_244});
        }
        case TAG_SizeName: {
          V v_t_2497 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_247, MK_INT(0LL), heff_dup(v_sp_244)));
          V v_t_24121;
          switch (heff_tag_of(v_v_245)) {
          case TAG_At: {
            V v_e_2498 = heff_field(v_v_245, 0);
            V v_sp_2499 = heff_field(v_v_245, 1);
            V v_ru_24v_245_24At = heff_take_reuse_n(v_v_245, 3ULL, 2);
            HeffT2 v_t_24100 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(heff_dup(v_e_2498)));
            {
              V v_field_24102 = v_t_24100.f[1];
              int64_t v_tag_24101 = ((int64_t)v_t_24100.f[0]);
              if ((v_tag_24101 == ((int64_t)0ULL))) {
                heff_drop_rec(v_r_241, 2);
                heff_drop(v_e_2498);
                V v_segs_24104 = v_field_24102;
                HeffT1 v_t_24105 = ({ V a_0 = v_lit_240; V b_1 = NTAG(TAG_True); V a_2 = v_segs_24104; V a_3 = v_sp_2499; HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
                {
                  V v_field_24106 = v_t_24105.f[0];
                  V v_a_24107 = v_field_24106;
                  V v_t_24110;
                  switch (heff_tag_of(v_a_24107)) {
                  case TAG_At: {
                    V v_a_24109 = heff_dup(heff_field(v_a_24107, 1));
                    v_t_24110 = v_a_24109;
                    break;
                  }
                  default: heff_nomatch(v_a_24107);
                  }
                  v_t_24121 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_24107}), v_t_24110});
                }
              } else {
                heff_drop(v_lit_240);
                heff_drop(v_field_24102);
                V v_x1_24111 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_e_2498, v_sp_2499})}));
                switch (heff_tag_of(v_x1_24111)) {
                case TAG_IsInferable: {
                  V v_i_24112 = heff_field(v_x1_24111, 0);
                  heff_take_n(v_x1_24111, 1ULL, 1);
                  V v_t_24115;
                  switch (heff_tag_of(v_i_24112)) {
                  case TAG_At: {
                    V v_s_24114 = heff_dup(heff_field(v_i_24112, 1));
                    v_t_24115 = v_s_24114;
                    break;
                  }
                  default: heff_nomatch(v_i_24112);
                  }
                  v_t_24121 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24112}), v_t_24115});
                  break;
                }
                case TAG_IsCheckable: {
                  V v_c_24116 = heff_field(v_x1_24111, 0);
                  heff_take_n(v_x1_24111, 1ULL, 1);
                  heff_drop_cell(v_ru_24v_245_24At, 2);
                  v_t_24121 = v_c_24116;
                  break;
                }
                case TAG_IsType: {
                  V v_t_24117 = heff_field(v_x1_24111, 0);
                  heff_take_n(v_x1_24111, 1ULL, 1);
                  V v_t_24120;
                  switch (heff_tag_of(v_t_24117)) {
                  case TAG_At: {
                    V v_s_24119 = heff_dup(heff_field(v_t_24117, 1));
                    v_t_24120 = v_s_24119;
                    break;
                  }
                  default: heff_nomatch(v_t_24117);
                  }
                  v_t_24121 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24117}), v_t_24120});
                  break;
                }
                default: heff_nomatch(v_x1_24111);
                }
              }
            }
            break;
          }
          default: heff_nomatch(v_v_245);
          }
          V v_t_24122 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24121, NTAG(TAG_Nil)});
          V v_args_24123 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2497, v_t_24122});
          V v_t_24124 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_244), v_args_24123));
          V v_t_24125 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str3)}), heff_dup(v_sp_244)});
          V v_t_24126 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24125, v_t_24124}), heff_dup(v_sp_244)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24126}), v_sp_244});
        }
        default: return heff_nomatch(v_size_247);
        }
      }
      case TAG_SegmentFloat: {
        heff_drop(v_lit_240);
        heff_drop(v_sp_244);
        heff_drop(v_v_245);
        heff_drop(v_size_247);
        heff_drop(v_little_248);
        heff_drop(v_signed_249);
        V v_t_24127 = (g_heff_2esyntax_2epresyntax_2ebytesPart(v_r_241, heff_dup(v_seg_242)));
        V v_args_24128 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24127, NTAG(TAG_Nil)});
        V v_sp_24131;
        switch (heff_tag_of(v_seg_242)) {
        case TAG_At: {
          V v_s_24130 = heff_field(v_seg_242, 1);
          heff_take_n(v_seg_242, 2ULL, 2);
          v_sp_24131 = v_s_24130;
          break;
        }
        default: heff_nomatch(v_seg_242);
        }
        V v_t_24132 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24131), v_args_24128));
        V v_t_24133 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str4)}), heff_dup(v_sp_24131)});
        V v_t_24134 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24133, v_t_24132}), heff_dup(v_sp_24131)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24134}), v_sp_24131});
      }
      case TAG_SegmentUtf: {
        V v_ru_24seg12_246_24SegmentUtf = heff_take_reuse_n(v_seg12_246, 0ULL, 1);
        heff_drop(v_lit_240);
        heff_drop(v_sp_244);
        heff_drop(v_v_245);
        heff_drop(v_size_247);
        heff_drop(v_little_248);
        heff_drop(v_signed_249);
        V v_t_24136 = (g_heff_2esyntax_2epresyntax_2ebytesPart(v_r_241, heff_dup(v_seg_242)));
        V v_args_24137 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24136, NTAG(TAG_Nil)});
        V v_sp_24140;
        switch (heff_tag_of(v_seg_242)) {
        case TAG_At: {
          V v_s_24139 = heff_field(v_seg_242, 1);
          heff_take_n(v_seg_242, 2ULL, 2);
          v_sp_24140 = v_s_24139;
          break;
        }
        default: heff_nomatch(v_seg_242);
        }
        V v_t_24141 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24140), v_args_24137));
        V v_t_24142 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24seg12_246_24SegmentUtf, TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str5)}), heff_dup(v_sp_24140)});
        V v_t_24143 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24142, v_t_24141}), heff_dup(v_sp_24140)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24143}), v_sp_24140});
      }
      default: return heff_nomatch(v_seg12_246);
      }
    }
    default: return heff_nomatch(v_seg1_243);
    }
  }
  default: return heff_nomatch(v_seg_242);
  }
}
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr_str0, 0, "");

HeffT2 g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(V v_asBits_240, V v_segs_241, V v_sp_242) {
top: ;
  if ((heff_dup(v_asBits_240) == NTAG(TAG_True))) {
    return ({ V a_0 = v_segs_241; V a_1 = v_sp_242; V b_2 = NTAG(TAG_False); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  } else {
    V v_t_243 = (g_list_2eany_24s689038521x519269801(v_segs_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return ({ V a_0 = v_segs_241; V a_1 = v_sp_242; V b_2 = NTAG(TAG_False); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    } else {
      heff_drop(v_t_243);
      V v_t_244 = (g_list_2emap_24s34825065x1144190520(heff_dup(v_segs_241)));
      HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(v_t_244, MK_INT(0LL)));
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          V v_n_249 = v_field_247;
          if (heff_intEq_c(v_n_249, MK_INT(0LL))) {
            V v_x1_2411 = (g_list_2eany_24s689038521x519269801(v_segs_241));
            if ((heff_dup(v_x1_2411) == NTAG(TAG_True))) {
              heff_drop(v_x1_2411);
              return ({ V a_0 = v_segs_241; V a_1 = v_sp_242; V b_2 = NTAG(TAG_True); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
            } else {
              heff_drop(v_x1_2411);
              V v_t_2412 = (g_list_2eall_24s1687051711x1677682329(MK_INT(0LL), v_segs_241));
              if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
                heff_drop(v_t_2412);
                V v_t_2413 = (g_heff_2esyntax_2epresyntax_2ewholeBinary(v_segs_241, ((V)&g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr_str0)));
                HEFF_LAST return g_heff_2esyntax_2epresyntax_2ebytesBinary_24s164675078x1710946710_24cpr(v_segs_241, v_sp_242, v_t_2413);
              } else {
                heff_drop(v_t_2412);
                return ({ V a_0 = v_segs_241; V a_1 = v_sp_242; V b_2 = NTAG(TAG_True); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
              }
            }
          } else {
            return ({ V a_0 = v_segs_241; V a_1 = v_sp_242; V b_2 = NTAG(TAG_False); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
          }
        } else {
          heff_drop(v_field_247);
          return ({ V a_0 = v_segs_241; V a_1 = v_sp_242; V b_2 = NTAG(TAG_False); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        }
      }
    }
  }
}
Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_SetField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_e_245 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24SetField = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      HeffT2 v_t_246 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_245));
      V v_t_2420;
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_2410 = v_field_248;
          v_t_2420 = v_c_2410;
        } else {
          if ((v_tag_247 == ((int64_t)1ULL))) {
            V v_i_2412 = v_field_248;
            V v_t_2415;
            switch (heff_tag_of(v_i_2412)) {
            case TAG_At: {
              V v_s_2414 = heff_dup(heff_field(v_i_2412, 1));
              v_t_2415 = v_s_2414;
              break;
            }
            default: heff_nomatch(v_i_2412);
            }
            v_t_2420 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2412}), v_t_2415});
          } else {
            V v_t_2416 = v_field_248;
            V v_t_2419;
            switch (heff_tag_of(v_t_2416)) {
            case TAG_At: {
              V v_s_2418 = heff_dup(heff_field(v_t_2416, 1));
              v_t_2419 = v_s_2418;
              break;
            }
            default: heff_nomatch(v_t_2416);
            }
            v_t_2420 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2416}), v_t_2419});
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24SetField, TAG_SetField, 3, (V[]){v_x_243, v_xsp_244, v_t_2420}), v_sp_242});
    }
    case TAG_BadFieldSet: {
      V v_e_2421 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24BadFieldSet = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      HeffT2 v_t_2422 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_2421));
      V v_t_2436;
      {
        V v_field_2424 = v_t_2422.f[1];
        int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
        if ((v_tag_2423 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_2426 = v_field_2424;
          v_t_2436 = v_c_2426;
        } else {
          if ((v_tag_2423 == ((int64_t)1ULL))) {
            V v_i_2428 = v_field_2424;
            V v_t_2431;
            switch (heff_tag_of(v_i_2428)) {
            case TAG_At: {
              V v_s_2430 = heff_dup(heff_field(v_i_2428, 1));
              v_t_2431 = v_s_2430;
              break;
            }
            default: heff_nomatch(v_i_2428);
            }
            v_t_2436 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2428}), v_t_2431});
          } else {
            V v_t_2432 = v_field_2424;
            V v_t_2435;
            switch (heff_tag_of(v_t_2432)) {
            case TAG_At: {
              V v_s_2434 = heff_dup(heff_field(v_t_2432, 1));
              v_t_2435 = v_s_2434;
              break;
            }
            default: heff_nomatch(v_t_2432);
            }
            v_t_2436 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2432}), v_t_2435});
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2436}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkAlt: {
      V v_p_243 = heff_field(v_x21_241, 0);
      V v_b_244 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24MkAlt = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_b_244));
      V v_t_2419;
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_249 = v_field_247;
          v_t_2419 = v_c_249;
        } else {
          if ((v_tag_246 == ((int64_t)1ULL))) {
            V v_i_2411 = v_field_247;
            V v_t_2414;
            switch (heff_tag_of(v_i_2411)) {
            case TAG_At: {
              V v_s_2413 = heff_dup(heff_field(v_i_2411, 1));
              v_t_2414 = v_s_2413;
              break;
            }
            default: heff_nomatch(v_i_2411);
            }
            v_t_2419 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2411}), v_t_2414});
          } else {
            V v_t_2415 = v_field_247;
            V v_t_2418;
            switch (heff_tag_of(v_t_2415)) {
            case TAG_At: {
              V v_s_2417 = heff_dup(heff_field(v_t_2415, 1));
              v_t_2418 = v_s_2417;
              break;
            }
            default: heff_nomatch(v_t_2415);
            }
            v_t_2419 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2415}), v_t_2418});
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_243, v_t_2419}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_DeclEquations: {
    V v_f_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_declared_243 = heff_field(v_x2_240, 2);
    V v_ty_244 = heff_field(v_x2_240, 3);
    V v_eqs_245 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24DeclEquations = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_248;
    switch (heff_tag_of(v_ty_244)) {
    case TAG_At: {
      V v_n_246 = heff_field(v_ty_244, 0);
      V v_sp_247 = heff_field(v_ty_244, 1);
      heff_take_n(v_ty_244, 3ULL, 2);
      v_t_248 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_247, v_n_246));
      break;
    }
    default: heff_nomatch(v_ty_244);
    }
    V v_t_249 = (g_list_2emap_24s1782778565x402128078(v_eqs_245));
    return heff_tag_at_n(v_ru_24x2_240_24DeclEquations, TAG_DeclEquations, 5, (V[]){v_f_241, v_sp_242, v_declared_243, v_t_248, v_t_249});
  }
  case TAG_DeclDefine: {
    V v_x_2410 = heff_field(v_x2_240, 0);
    V v_sp_2411 = heff_field(v_x2_240, 1);
    V v_ps_2412 = heff_field(v_x2_240, 2);
    V v_u_2413 = heff_field(v_x2_240, 3);
    V v_body_2414 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24DeclDefine = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_2415 = (g_list_2emap_24s474585387x1072098790(v_ps_2412));
    V v_t_2418;
    switch (heff_tag_of(v_u_2413)) {
    case TAG_At: {
      V v_n_2416 = heff_field(v_u_2413, 0);
      V v_sp_2417 = heff_field(v_u_2413, 1);
      heff_take_n(v_u_2413, 3ULL, 2);
      v_t_2418 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2417, v_n_2416));
      break;
    }
    default: heff_nomatch(v_u_2413);
    }
    V v_t_2422;
    switch (heff_tag_of(v_body_2414)) {
    case TAG_At: {
      V v_n_2419 = heff_field(v_body_2414, 0);
      V v_sp_2420 = heff_field(v_body_2414, 1);
      V v_ru_24body_2414_24At = heff_take_reuse_n(v_body_2414, 3ULL, 2);
      V v_t_2421 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2419));
      v_t_2422 = heff_tag_at_n(v_ru_24body_2414_24At, TAG_At, 2, (V[]){v_t_2421, v_sp_2420});
      break;
    }
    default: heff_nomatch(v_body_2414);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_2410, v_sp_2411, v_t_2415, v_t_2418, v_t_2422});
  }
  case TAG_DeclTheory: {
    V v_x_2423 = heff_field(v_x2_240, 0);
    V v_sp_2424 = heff_field(v_x2_240, 1);
    V v_ps_2425 = heff_field(v_x2_240, 2);
    V v_body_2426 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24DeclTheory = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2427 = (g_list_2emap_24s474585387x1072098790(v_ps_2425));
    V v_t_2431;
    switch (heff_tag_of(v_body_2426)) {
    case TAG_At: {
      V v_n_2428 = heff_field(v_body_2426, 0);
      V v_sp_2429 = heff_field(v_body_2426, 1);
      V v_ru_24body_2426_24At = heff_take_reuse_n(v_body_2426, 3ULL, 2);
      V v_t_2430 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2428));
      v_t_2431 = heff_tag_at_n(v_ru_24body_2426_24At, TAG_At, 2, (V[]){v_t_2430, v_sp_2429});
      break;
    }
    default: heff_nomatch(v_body_2426);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2423, v_sp_2424, v_t_2427, v_t_2431});
  }
  case TAG_DeclPrimitive: {
    V v_x_2432 = heff_field(v_x2_240, 0);
    V v_sp_2433 = heff_field(v_x2_240, 1);
    V v_t_2434 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24DeclPrimitive = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_2437;
    switch (heff_tag_of(v_t_2434)) {
    case TAG_At: {
      V v_n_2435 = heff_field(v_t_2434, 0);
      V v_sp_2436 = heff_field(v_t_2434, 1);
      heff_take_n(v_t_2434, 3ULL, 2);
      v_t_2437 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2436, v_n_2435));
      break;
    }
    default: heff_nomatch(v_t_2434);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2432, v_sp_2433, v_t_2437});
  }
  case TAG_DeclTest: {
    V v_x_2438 = heff_field(v_x2_240, 0);
    V v_sp_2439 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24DeclTest = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24DeclTest, TAG_DeclTest, 2, (V[]){v_x_2438, v_sp_2439});
  }
  case TAG_DeclWatch: {
    V v_c_2440 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24DeclWatch = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2444;
    switch (heff_tag_of(v_c_2440)) {
    case TAG_At: {
      V v_n_2441 = heff_field(v_c_2440, 0);
      V v_sp_2442 = heff_field(v_c_2440, 1);
      V v_ru_24c_2440_24At = heff_take_reuse_n(v_c_2440, 3ULL, 2);
      V v_t_2443 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2441));
      v_t_2444 = heff_tag_at_n(v_ru_24c_2440_24At, TAG_At, 2, (V[]){v_t_2443, v_sp_2442});
      break;
    }
    default: heff_nomatch(v_c_2440);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclWatch, TAG_DeclWatch, 1, (V[]){v_t_2444});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eisMadeName_str0, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2eisMadeName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eisMadeName_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eisMadeName(V v_x_240) {
top: ;
  V v_ret_24bool = heff_bool((heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2esyntax_2epresyntax_2eisMadeName_str0), v_x_240, MK_INT(0LL), 5)) && ((((int64_t)97ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) ? ((heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)122ULL)) || ((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)90ULL)))) : ((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)90ULL))))));
  return v_ret_24bool;
}
V g_heff_2esyntax_2epresyntax_2eisMadeName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2eisMadeName(a0); heff_drop(a0); return r;
}