// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_IApp 21275
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_IPrim 59489
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_TagVariant 25174
#define LBL_e 319
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(V);
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryIn(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158_clo;
V g_heff_2esyntax_2epresyntax_2ebinarySegments(V);
V g_heff_2esyntax_2epresyntax_2ebinarySegments_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinarySegments_clo;
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_clo;
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_clo;
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo;
V g_heff_2esyntax_2epresyntax_2ebytesBinary(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebytesBinary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesBinary_clo;
V g_heff_2esyntax_2epresyntax_2ebytesPart(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_clo;
V g_heff_2esyntax_2epresyntax_2echeckedWays_get(void);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(V);
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902(V);
V g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902_clo;
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183(V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_clo;
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
V g_heff_2esyntax_2epresyntax_2eoddSum(V, V);
V g_heff_2esyntax_2epresyntax_2eoddSum_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eoddSum_clo;
V g_heff_2esyntax_2epresyntax_2esegmentOdd(V, V);
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo;
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2eutf8Of(V);
V g_heff_2esyntax_2epresyntax_2eutf8Of_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eutf8Of_clo;
V g_heff_2esyntax_2epresyntax_2evariantOf(V, V);
V g_heff_2esyntax_2epresyntax_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_clo;
V g_heff_2esyntax_2epresyntax_2ewholeBinary(V, V);
V g_heff_2esyntax_2epresyntax_2ewholeBinary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewholeBinary_clo;
V g_list_2eall_24s1687051711x1677682329(V, V);
V g_list_2eall_24s1687051711x1677682329_entry(V self, V *a);
extern Clo g_list_2eall_24s1687051711x1677682329_clo;
V g_list_2eany_24s689038521x519269801(V);
V g_list_2eany_24s689038521x519269801_entry(V self, V *a);
extern Clo g_list_2eany_24s689038521x519269801_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1782778565x402128078(V);
V g_list_2emap_24s1782778565x402128078_entry(V self, V *a);
extern Clo g_list_2emap_24s1782778565x402128078_clo;
V g_list_2emap_24s34825065x1144190520(V);
V g_list_2emap_24s34825065x1144190520_entry(V self, V *a);
extern Clo g_list_2emap_24s34825065x1144190520_clo;
V g_list_2emap_24s474585387x1072098790(V);
V g_list_2emap_24s474585387x1072098790_entry(V self, V *a);
extern Clo g_list_2emap_24s474585387x1072098790_clo;
Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2esegmentOdd_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2esegmentOdd(V v_ty_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_ty_240)) {
  case TAG_SegmentInteger: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_SizeDefault: {
      return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)});
    }
    case TAG_SizeNumber: {
      V v_n_242 = heff_field(v_x2_241, 0);
      V v_ru_24x2_241_24SizeNumber = heff_take_reuse_n(v_x2_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x2_241_24SizeNumber, TAG_Just, 1, (V[]){heff_intMod(v_n_242, MK_INT(8LL))});
    }
    case TAG_SizeName: {
      V v_unit_245 = heff_field(v_x2_241, 2);
      heff_take_n(v_x2_241, 4ULL, 3);
      if (heff_intEq_c(heff_intMod(v_unit_245, MK_INT(8LL)), MK_INT(0LL))) {
        return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)});
      } else {
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_SegmentBinary: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_SizeDefault: {
      return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)});
    }
    case TAG_SizeNumber: {
      V v_n_247 = heff_field(v_x2_241, 0);
      V v_ru_24x2_241_24SizeNumber = heff_take_reuse_n(v_x2_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x2_241_24SizeNumber, TAG_Just, 1, (V[]){heff_intMod(v_n_247, MK_INT(8LL))});
    }
    case TAG_SizeName: {
      V v_unit_2410 = heff_field(v_x2_241, 2);
      heff_take_n(v_x2_241, 4ULL, 3);
      if (heff_intEq_c(heff_intMod(v_unit_2410, MK_INT(8LL)), MK_INT(0LL))) {
        return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)});
      } else {
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_SegmentBits: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_SizeDefault: {
      return NTAG(TAG_Nothing);
    }
    case TAG_SizeNumber: {
      V v_n_2412 = heff_field(v_x2_241, 0);
      V v_ru_24x2_241_24SizeNumber = heff_take_reuse_n(v_x2_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x2_241_24SizeNumber, TAG_Just, 1, (V[]){heff_intMod(v_n_2412, MK_INT(8LL))});
    }
    case TAG_SizeName: {
      V v_unit_2415 = heff_field(v_x2_241, 2);
      heff_take_n(v_x2_241, 4ULL, 3);
      if (heff_intEq_c(heff_intMod(v_unit_2415, MK_INT(8LL)), MK_INT(0LL))) {
        return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)});
      } else {
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_SegmentFloat: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_SizeDefault: {
      return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)});
    }
    case TAG_SizeNumber: {
      V v_n_2417 = heff_field(v_x2_241, 0);
      V v_ru_24x2_241_24SizeNumber = heff_take_reuse_n(v_x2_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x2_241_24SizeNumber, TAG_Just, 1, (V[]){heff_intMod(v_n_2417, MK_INT(8LL))});
    }
    case TAG_SizeName: {
      V v_unit_2420 = heff_field(v_x2_241, 2);
      heff_take_n(v_x2_241, 4ULL, 3);
      if (heff_intEq_c(heff_intMod(v_unit_2420, MK_INT(8LL)), MK_INT(0LL))) {
        return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)});
      } else {
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_SegmentUtf: {
    V v_ru_24ty_240_24SegmentUtf = heff_take_reuse_n(v_ty_240, 0ULL, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_SizeDefault: {
      return heff_tag_at_n(v_ru_24ty_240_24SegmentUtf, TAG_Just, 1, (V[]){MK_INT(0LL)});
    }
    case TAG_SizeNumber: {
      V v_n_2423 = heff_field(v_x2_241, 0);
      heff_take_n(v_x2_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24ty_240_24SegmentUtf, TAG_Just, 1, (V[]){heff_intMod(v_n_2423, MK_INT(8LL))});
    }
    case TAG_SizeName: {
      V v_unit_2426 = heff_field(v_x2_241, 2);
      heff_take_n(v_x2_241, 4ULL, 3);
      if (heff_intEq_c(heff_intMod(v_unit_2426, MK_INT(8LL)), MK_INT(0LL))) {
        return heff_tag_at_n(v_ru_24ty_240_24SegmentUtf, TAG_Just, 1, (V[]){MK_INT(0LL)});
      } else {
        heff_drop_cell(v_ru_24ty_240_24SegmentUtf, 1);
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_ty_240);
  }
}
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2esegmentOdd(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eoddSum_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eoddSum_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eoddSum(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Just, 1, (V[]){heff_intMod(v_acc_241, MK_INT(8LL))});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop(v_acc_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_n_244 = heff_field(v_x11_242, 0);
      V t_0 = v_x12_243;
      V t_1 = heff_intAdd(v_acc_241, heff_dup(v_n_244));
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eoddSum_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2eoddSum(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str3, 0, "");
Clo g_heff_2esyntax_2epresyntax_2eutf8Of_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eutf8Of_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eutf8Of(V v_c_240) {
top: ;
  if (heff_intLt_c(heff_dup(v_c_240), MK_INT(128LL))) {
    return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(1LL), v_c_240, ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str0)));
  } else {
    if (heff_intLt_c(heff_dup(v_c_240), MK_INT(2048LL))) {
      V v_t_243 = heff_intAdd(MK_INT(192LL), heff_intDiv(heff_dup(v_c_240), MK_INT(64LL)));
      V v_t_244 = heff_intAdd(heff_intMul(v_t_243, MK_INT(256LL)), MK_INT(128LL));
      V v_t_245 = heff_intAdd(v_t_244, heff_intMod(v_c_240, MK_INT(64LL)));
      return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(2LL), v_t_245, ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str1)));
    } else {
      if (heff_intLt_c(heff_dup(v_c_240), MK_INT(65536LL))) {
        V v_t_247 = heff_intAdd(MK_INT(224LL), heff_intDiv(heff_dup(v_c_240), MK_INT(4096LL)));
        V v_t_248 = heff_intAdd(heff_intMul(v_t_247, MK_INT(256LL)), MK_INT(128LL));
        V v_t_249 = heff_intMod(heff_intDiv(heff_dup(v_c_240), MK_INT(64LL)), MK_INT(64LL));
        V v_t_2410 = heff_intMul(heff_intAdd(v_t_248, v_t_249), MK_INT(256LL));
        V v_t_2411 = heff_intAdd(heff_intAdd(v_t_2410, MK_INT(128LL)), heff_intMod(v_c_240, MK_INT(64LL)));
        return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(3LL), v_t_2411, ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str2)));
      } else {
        V v_t_2412 = heff_intAdd(MK_INT(240LL), heff_intDiv(heff_dup(v_c_240), MK_INT(262144LL)));
        V v_t_2413 = heff_intAdd(heff_intMul(v_t_2412, MK_INT(256LL)), MK_INT(128LL));
        V v_t_2414 = heff_intMod(heff_intDiv(heff_dup(v_c_240), MK_INT(4096LL)), MK_INT(64LL));
        V v_t_2415 = heff_intMul(heff_intAdd(v_t_2413, v_t_2414), MK_INT(256LL));
        V v_t_2416 = heff_intMod(heff_intDiv(heff_dup(v_c_240), MK_INT(64LL)), MK_INT(64LL));
        V v_t_2417 = heff_intAdd(heff_intAdd(v_t_2415, MK_INT(128LL)), v_t_2416);
        V v_t_2418 = heff_intAdd(heff_intMul(v_t_2417, MK_INT(256LL)), MK_INT(128LL));
        V v_t_2419 = heff_intAdd(v_t_2418, heff_intMod(v_c_240, MK_INT(64LL)));
        return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(4LL), v_t_2419, ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str3)));
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eutf8Of_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eutf8Of(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2echeckedWays_str0, 235, "any of these: give the type where it is bound, `let x : T = ...`; give it in place, `(e : T)`; or write it where a type is expected of it, as an argument of a function whose type is known or as the body of a definition with a signature");

static V g_heff_2esyntax_2epresyntax_2echeckedWays_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2echeckedWays_st;
static V g_heff_2esyntax_2epresyntax_2echeckedWays_init(void) {
  return ((V)&g_heff_2esyntax_2epresyntax_2echeckedWays_str0);
}
V g_heff_2esyntax_2epresyntax_2echeckedWays_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2echeckedWays_st)) return g_heff_2esyntax_2epresyntax_2echeckedWays_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2echeckedWays_val, &g_heff_2esyntax_2epresyntax_2echeckedWays_st, g_heff_2esyntax_2epresyntax_2echeckedWays_init);
}
V g_heff_2esyntax_2epresyntax_2evariantOf_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2evariantOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2evariantOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2evariantOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_TagVariant: {
      V v_t_244 = heff_field(v_x21_242, 0);
      V v_tsp_245 = heff_field(v_x21_242, 1);
      V v_args_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2evariantOf_lam0, 1, 1, (V[]){v_r_240}), v_args_246));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TagVariant, 3, (V[]){v_t_244, v_tsp_245, v_t_2418}), v_sp_243});
    }
    case TAG_BadVariant: {
      V v_e_2419 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24BadVariant = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2419}));
      V v_t_2430;
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_IsInferable: {
        V v_i_2421 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2424;
        switch (heff_tag_of(v_i_2421)) {
        case TAG_At: {
          V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_i_2421);
        }
        v_t_2430 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2421}), v_t_2424});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2425 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2428;
        switch (heff_tag_of(v_c_2425)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_c_2425, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_c_2425);
        }
        v_t_2430 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2425}), v_t_2428});
        break;
      }
      case TAG_IsType: {
        V v_t_2429 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2430 = v_t_2429;
        break;
      }
      default: heff_nomatch(v_x1_2420);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2430}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2evariantOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2evariantOf(a[0], a[1]);
}
V g_heff_2esyntax_2epresyntax_2evariantOf_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_IsInferable: {
    V v_i_249 = heff_field(v_x1_248, 0);
    V v_ru_24x1_248_24IsInferable = heff_take_reuse_n(v_x1_248, 1ULL, 1);
    V v_t_2412;
    switch (heff_tag_of(v_i_249)) {
    case TAG_At: {
      V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
      v_t_2412 = v_s_2411;
      break;
    }
    default: heff_nomatch(v_i_249);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_248_24IsInferable, TAG_TInf, 1, (V[]){v_i_249}), v_t_2412});
  }
  case TAG_IsCheckable: {
    V v_c_2413 = heff_field(v_x1_248, 0);
    V v_ru_24x1_248_24IsCheckable = heff_take_reuse_n(v_x1_248, 1ULL, 1);
    V v_t_2416;
    switch (heff_tag_of(v_c_2413)) {
    case TAG_At: {
      V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
      v_t_2416 = v_s_2415;
      break;
    }
    default: heff_nomatch(v_c_2413);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_248_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
  }
  case TAG_IsType: {
    V v_t_2417 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    return v_t_2417;
  }
  default: return heff_nomatch(v_x1_248);
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str0, 9, "bitsOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str1, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str2, 17, "prelude.bitsSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str3, 17, "prelude.bitsSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str4, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str5, 11, "bitsOfBytes");
Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026(V v_lit_240, V v_r_241, V v_seg_242) {
top: ;
  switch (heff_tag_of(v_seg_242)) {
  case TAG_At: {
    V v_seg1_243 = heff_dup(heff_field(v_seg_242, 0));
    V v_sp_244 = heff_dup(heff_field(v_seg_242, 1));
    switch (heff_tag_of(v_seg1_243)) {
    case TAG_MkSegment: {
      V v_v_245 = heff_field(v_seg1_243, 0);
      V v_seg12_246 = heff_field(v_seg1_243, 1);
      V v_size_247 = heff_field(v_seg1_243, 2);
      V v_little_248 = heff_field(v_seg1_243, 3);
      V v_signed_249 = heff_field(v_seg1_243, 4);
      heff_take_n(v_seg1_243, 31ULL, 5);
      switch (heff_tag_of(v_seg12_246)) {
      case TAG_SegmentInteger: {
        heff_drop(v_lit_240);
        heff_drop_tag(v_seg_242, 2);
        V v_t_2410 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_247, MK_INT(8LL), heff_dup(v_sp_244)));
        V v_t_2411;
        if ((heff_dup(v_little_248) == NTAG(TAG_True))) {
          heff_drop(v_little_248);
          v_t_2411 = MK_INT(1LL);
        } else {
          heff_drop(v_little_248);
          v_t_2411 = MK_INT(0LL);
        }
        V v_t_2412;
        if ((heff_dup(v_signed_249) == NTAG(TAG_True))) {
          heff_drop(v_signed_249);
          v_t_2412 = MK_INT(2LL);
        } else {
          heff_drop(v_signed_249);
          v_t_2412 = MK_INT(0LL);
        }
        V v_t_2413 = heff_tag_n(TAG_IInt, 1, (V[]){heff_intAdd(v_t_2411, v_t_2412)});
        V v_t_2414 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_244)})});
        V v_x1_2415 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){v_v_245}));
        V v_t_2425;
        switch (heff_tag_of(v_x1_2415)) {
        case TAG_IsInferable: {
          V v_i_2416 = heff_field(v_x1_2415, 0);
          V v_ru_24x1_2415_24IsInferable = heff_take_reuse_n(v_x1_2415, 1ULL, 1);
          V v_t_2419;
          switch (heff_tag_of(v_i_2416)) {
          case TAG_At: {
            V v_s_2418 = heff_dup(heff_field(v_i_2416, 1));
            v_t_2419 = v_s_2418;
            break;
          }
          default: heff_nomatch(v_i_2416);
          }
          v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2415_24IsInferable, TAG_CInf, 1, (V[]){v_i_2416}), v_t_2419});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2420 = heff_field(v_x1_2415, 0);
          heff_take_n(v_x1_2415, 1ULL, 1);
          v_t_2425 = v_c_2420;
          break;
        }
        case TAG_IsType: {
          V v_t_2421 = heff_field(v_x1_2415, 0);
          V v_ru_24x1_2415_24IsType = heff_take_reuse_n(v_x1_2415, 1ULL, 1);
          V v_t_2424;
          switch (heff_tag_of(v_t_2421)) {
          case TAG_At: {
            V v_s_2423 = heff_dup(heff_field(v_t_2421, 1));
            v_t_2424 = v_s_2423;
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
          v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2415_24IsType, TAG_CType, 1, (V[]){v_t_2421}), v_t_2424});
          break;
        }
        default: heff_nomatch(v_x1_2415);
        }
        V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
        V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, heff_dup(v_sp_244)}), v_t_2426});
        V v_args_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2427});
        V v_t_2429 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_244), v_args_2428));
        V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str0)}), heff_dup(v_sp_244)});
        V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2430, v_t_2429}), heff_dup(v_sp_244)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2431}), v_sp_244});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_lit_240);
        heff_drop(v_sp_244);
        heff_drop(v_v_245);
        heff_drop(v_size_247);
        heff_drop(v_little_248);
        heff_drop(v_signed_249);
        V v_t_2432 = (g_heff_2esyntax_2epresyntax_2ebytesPart(v_r_241, heff_dup(v_seg_242)));
        V v_args_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
        V v_sp_2436;
        switch (heff_tag_of(v_seg_242)) {
        case TAG_At: {
          V v_s_2435 = heff_field(v_seg_242, 1);
          heff_take_n(v_seg_242, 2ULL, 2);
          v_sp_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_seg_242);
        }
        V v_t_2437 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2436), v_args_2433));
        V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str1)}), heff_dup(v_sp_2436)});
        V v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2438, v_t_2437}), heff_dup(v_sp_2436)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2439}), v_sp_2436});
      }
      case TAG_SegmentBits: {
        heff_drop_tag(v_seg_242, 2);
        heff_drop(v_little_248);
        heff_drop(v_signed_249);
        switch (heff_tag_of(v_size_247)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_244);
          switch (heff_tag_of(v_v_245)) {
          case TAG_At: {
            V v_e_2440 = heff_field(v_v_245, 0);
            V v_sp_2441 = heff_field(v_v_245, 1);
            V v_ru_24v_245_24At = heff_take_reuse_n(v_v_245, 3ULL, 2);
            V v_t_2442 = (g_heff_2esyntax_2epresyntax_2ebinarySegments(heff_dup(v_e_2440)));
            switch (heff_tag_of(v_t_2442)) {
            case TAG_Nothing: {
              heff_drop(v_lit_240);
              V v_x1_2443 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_e_2440, v_sp_2441})}));
              switch (heff_tag_of(v_x1_2443)) {
              case TAG_IsInferable: {
                V v_i_2444 = heff_field(v_x1_2443, 0);
                heff_take_n(v_x1_2443, 1ULL, 1);
                V v_t_2447;
                switch (heff_tag_of(v_i_2444)) {
                case TAG_At: {
                  V v_s_2446 = heff_dup(heff_field(v_i_2444, 1));
                  v_t_2447 = v_s_2446;
                  break;
                }
                default: heff_nomatch(v_i_2444);
                }
                return heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2444}), v_t_2447});
              }
              case TAG_IsCheckable: {
                V v_c_2448 = heff_field(v_x1_2443, 0);
                heff_take_n(v_x1_2443, 1ULL, 1);
                heff_drop_cell(v_ru_24v_245_24At, 2);
                return v_c_2448;
              }
              case TAG_IsType: {
                V v_t_2449 = heff_field(v_x1_2443, 0);
                heff_take_n(v_x1_2443, 1ULL, 1);
                V v_t_2452;
                switch (heff_tag_of(v_t_2449)) {
                case TAG_At: {
                  V v_s_2451 = heff_dup(heff_field(v_t_2449, 1));
                  v_t_2452 = v_s_2451;
                  break;
                }
                default: heff_nomatch(v_t_2449);
                }
                return heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2449}), v_t_2452});
              }
              default: return heff_nomatch(v_x1_2443);
              }
            }
            case TAG_Just: {
              V v_segs_2453 = heff_field(v_t_2442, 0);
              heff_take_n(v_t_2442, 1ULL, 1);
              heff_drop_rec(v_r_241, 2);
              heff_drop(v_e_2440);
              V v_a_2454 = ({ V a_0 = v_lit_240; V b_1 = NTAG(TAG_True); V a_2 = v_segs_2453; V a_3 = v_sp_2441; V r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
              switch (heff_tag_of(v_a_2454)) {
              case TAG_IsInferable: {
                V v_a_2455 = heff_field(v_a_2454, 0);
                heff_take_n(v_a_2454, 1ULL, 1);
                V v_t_2458;
                switch (heff_tag_of(v_a_2455)) {
                case TAG_At: {
                  V v_a_2457 = heff_dup(heff_field(v_a_2455, 1));
                  v_t_2458 = v_a_2457;
                  break;
                }
                default: heff_nomatch(v_a_2455);
                }
                return heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_2455}), v_t_2458});
              }
              case TAG_IsCheckable: {
                V v_a_2459 = heff_field(v_a_2454, 0);
                heff_take_n(v_a_2454, 1ULL, 1);
                heff_drop_cell(v_ru_24v_245_24At, 2);
                return v_a_2459;
              }
              case TAG_IsType: {
                V v_a_2460 = heff_field(v_a_2454, 0);
                heff_take_n(v_a_2454, 1ULL, 1);
                V v_t_2463;
                switch (heff_tag_of(v_a_2460)) {
                case TAG_At: {
                  V v_a_2462 = heff_dup(heff_field(v_a_2460, 1));
                  v_t_2463 = v_a_2462;
                  break;
                }
                default: heff_nomatch(v_a_2460);
                }
                return heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_2460}), v_t_2463});
              }
              default: return heff_nomatch(v_a_2454);
              }
            }
            default: return heff_nomatch(v_t_2442);
            }
          }
          default: return heff_nomatch(v_v_245);
          }
        }
        case TAG_SizeNumber: {
          V v_t_2465 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_247, MK_INT(0LL), heff_dup(v_sp_244)));
          V v_t_2490;
          switch (heff_tag_of(v_v_245)) {
          case TAG_At: {
            V v_e_2466 = heff_field(v_v_245, 0);
            V v_sp_2467 = heff_field(v_v_245, 1);
            V v_ru_24v_245_24At = heff_take_reuse_n(v_v_245, 3ULL, 2);
            V v_t_2468 = (g_heff_2esyntax_2epresyntax_2ebinarySegments(heff_dup(v_e_2466)));
            switch (heff_tag_of(v_t_2468)) {
            case TAG_Nothing: {
              heff_drop(v_lit_240);
              V v_x1_2469 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_e_2466, v_sp_2467})}));
              switch (heff_tag_of(v_x1_2469)) {
              case TAG_IsInferable: {
                V v_i_2470 = heff_field(v_x1_2469, 0);
                heff_take_n(v_x1_2469, 1ULL, 1);
                V v_t_2473;
                switch (heff_tag_of(v_i_2470)) {
                case TAG_At: {
                  V v_s_2472 = heff_dup(heff_field(v_i_2470, 1));
                  v_t_2473 = v_s_2472;
                  break;
                }
                default: heff_nomatch(v_i_2470);
                }
                v_t_2490 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2470}), v_t_2473});
                break;
              }
              case TAG_IsCheckable: {
                V v_c_2474 = heff_field(v_x1_2469, 0);
                heff_take_n(v_x1_2469, 1ULL, 1);
                heff_drop_cell(v_ru_24v_245_24At, 2);
                v_t_2490 = v_c_2474;
                break;
              }
              case TAG_IsType: {
                V v_t_2475 = heff_field(v_x1_2469, 0);
                heff_take_n(v_x1_2469, 1ULL, 1);
                V v_t_2478;
                switch (heff_tag_of(v_t_2475)) {
                case TAG_At: {
                  V v_s_2477 = heff_dup(heff_field(v_t_2475, 1));
                  v_t_2478 = v_s_2477;
                  break;
                }
                default: heff_nomatch(v_t_2475);
                }
                v_t_2490 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2475}), v_t_2478});
                break;
              }
              default: heff_nomatch(v_x1_2469);
              }
              break;
            }
            case TAG_Just: {
              V v_segs_2479 = heff_field(v_t_2468, 0);
              heff_take_n(v_t_2468, 1ULL, 1);
              heff_drop_rec(v_r_241, 2);
              heff_drop(v_e_2466);
              V v_a_2480 = ({ V a_0 = v_lit_240; V b_1 = NTAG(TAG_True); V a_2 = v_segs_2479; V a_3 = v_sp_2467; V r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
              switch (heff_tag_of(v_a_2480)) {
              case TAG_IsInferable: {
                V v_a_2481 = heff_field(v_a_2480, 0);
                heff_take_n(v_a_2480, 1ULL, 1);
                V v_t_2484;
                switch (heff_tag_of(v_a_2481)) {
                case TAG_At: {
                  V v_a_2483 = heff_dup(heff_field(v_a_2481, 1));
                  v_t_2484 = v_a_2483;
                  break;
                }
                default: heff_nomatch(v_a_2481);
                }
                v_t_2490 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_2481}), v_t_2484});
                break;
              }
              case TAG_IsCheckable: {
                V v_a_2485 = heff_field(v_a_2480, 0);
                heff_take_n(v_a_2480, 1ULL, 1);
                heff_drop_cell(v_ru_24v_245_24At, 2);
                v_t_2490 = v_a_2485;
                break;
              }
              case TAG_IsType: {
                V v_a_2486 = heff_field(v_a_2480, 0);
                heff_take_n(v_a_2480, 1ULL, 1);
                V v_t_2489;
                switch (heff_tag_of(v_a_2486)) {
                case TAG_At: {
                  V v_a_2488 = heff_dup(heff_field(v_a_2486, 1));
                  v_t_2489 = v_a_2488;
                  break;
                }
                default: heff_nomatch(v_a_2486);
                }
                v_t_2490 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_2486}), v_t_2489});
                break;
              }
              default: heff_nomatch(v_a_2480);
              }
              break;
            }
            default: heff_nomatch(v_t_2468);
            }
            break;
          }
          default: heff_nomatch(v_v_245);
          }
          V v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2490, NTAG(TAG_Nil)});
          V v_args_2492 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2465, v_t_2491});
          V v_t_2493 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_244), v_args_2492));
          V v_t_2494 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str2)}), heff_dup(v_sp_244)});
          V v_t_2495 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2494, v_t_2493}), heff_dup(v_sp_244)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2495}), v_sp_244});
        }
        case TAG_SizeName: {
          V v_t_2499 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_247, MK_INT(0LL), heff_dup(v_sp_244)));
          V v_t_24124;
          switch (heff_tag_of(v_v_245)) {
          case TAG_At: {
            V v_e_24100 = heff_field(v_v_245, 0);
            V v_sp_24101 = heff_field(v_v_245, 1);
            V v_ru_24v_245_24At = heff_take_reuse_n(v_v_245, 3ULL, 2);
            V v_t_24102 = (g_heff_2esyntax_2epresyntax_2ebinarySegments(heff_dup(v_e_24100)));
            switch (heff_tag_of(v_t_24102)) {
            case TAG_Nothing: {
              heff_drop(v_lit_240);
              V v_x1_24103 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_e_24100, v_sp_24101})}));
              switch (heff_tag_of(v_x1_24103)) {
              case TAG_IsInferable: {
                V v_i_24104 = heff_field(v_x1_24103, 0);
                heff_take_n(v_x1_24103, 1ULL, 1);
                V v_t_24107;
                switch (heff_tag_of(v_i_24104)) {
                case TAG_At: {
                  V v_s_24106 = heff_dup(heff_field(v_i_24104, 1));
                  v_t_24107 = v_s_24106;
                  break;
                }
                default: heff_nomatch(v_i_24104);
                }
                v_t_24124 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24104}), v_t_24107});
                break;
              }
              case TAG_IsCheckable: {
                V v_c_24108 = heff_field(v_x1_24103, 0);
                heff_take_n(v_x1_24103, 1ULL, 1);
                heff_drop_cell(v_ru_24v_245_24At, 2);
                v_t_24124 = v_c_24108;
                break;
              }
              case TAG_IsType: {
                V v_t_24109 = heff_field(v_x1_24103, 0);
                heff_take_n(v_x1_24103, 1ULL, 1);
                V v_t_24112;
                switch (heff_tag_of(v_t_24109)) {
                case TAG_At: {
                  V v_s_24111 = heff_dup(heff_field(v_t_24109, 1));
                  v_t_24112 = v_s_24111;
                  break;
                }
                default: heff_nomatch(v_t_24109);
                }
                v_t_24124 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24109}), v_t_24112});
                break;
              }
              default: heff_nomatch(v_x1_24103);
              }
              break;
            }
            case TAG_Just: {
              V v_segs_24113 = heff_field(v_t_24102, 0);
              heff_take_n(v_t_24102, 1ULL, 1);
              heff_drop_rec(v_r_241, 2);
              heff_drop(v_e_24100);
              V v_a_24114 = ({ V a_0 = v_lit_240; V b_1 = NTAG(TAG_True); V a_2 = v_segs_24113; V a_3 = v_sp_24101; V r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
              switch (heff_tag_of(v_a_24114)) {
              case TAG_IsInferable: {
                V v_a_24115 = heff_field(v_a_24114, 0);
                heff_take_n(v_a_24114, 1ULL, 1);
                V v_t_24118;
                switch (heff_tag_of(v_a_24115)) {
                case TAG_At: {
                  V v_a_24117 = heff_dup(heff_field(v_a_24115, 1));
                  v_t_24118 = v_a_24117;
                  break;
                }
                default: heff_nomatch(v_a_24115);
                }
                v_t_24124 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_24115}), v_t_24118});
                break;
              }
              case TAG_IsCheckable: {
                V v_a_24119 = heff_field(v_a_24114, 0);
                heff_take_n(v_a_24114, 1ULL, 1);
                heff_drop_cell(v_ru_24v_245_24At, 2);
                v_t_24124 = v_a_24119;
                break;
              }
              case TAG_IsType: {
                V v_a_24120 = heff_field(v_a_24114, 0);
                heff_take_n(v_a_24114, 1ULL, 1);
                V v_t_24123;
                switch (heff_tag_of(v_a_24120)) {
                case TAG_At: {
                  V v_a_24122 = heff_dup(heff_field(v_a_24120, 1));
                  v_t_24123 = v_a_24122;
                  break;
                }
                default: heff_nomatch(v_a_24120);
                }
                v_t_24124 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_24120}), v_t_24123});
                break;
              }
              default: heff_nomatch(v_a_24114);
              }
              break;
            }
            default: heff_nomatch(v_t_24102);
            }
            break;
          }
          default: heff_nomatch(v_v_245);
          }
          V v_t_24125 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24124, NTAG(TAG_Nil)});
          V v_args_24126 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2499, v_t_24125});
          V v_t_24127 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_244), v_args_24126));
          V v_t_24128 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str3)}), heff_dup(v_sp_244)});
          V v_t_24129 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24128, v_t_24127}), heff_dup(v_sp_244)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24129}), v_sp_244});
        }
        default: return heff_nomatch(v_size_247);
        }
      }
      case TAG_SegmentFloat: {
        heff_drop(v_lit_240);
        heff_drop(v_sp_244);
        heff_drop(v_v_245);
        heff_drop(v_size_247);
        heff_drop(v_little_248);
        heff_drop(v_signed_249);
        V v_t_24130 = (g_heff_2esyntax_2epresyntax_2ebytesPart(v_r_241, heff_dup(v_seg_242)));
        V v_args_24131 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24130, NTAG(TAG_Nil)});
        V v_sp_24134;
        switch (heff_tag_of(v_seg_242)) {
        case TAG_At: {
          V v_s_24133 = heff_field(v_seg_242, 1);
          heff_take_n(v_seg_242, 2ULL, 2);
          v_sp_24134 = v_s_24133;
          break;
        }
        default: heff_nomatch(v_seg_242);
        }
        V v_t_24135 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24134), v_args_24131));
        V v_t_24136 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str4)}), heff_dup(v_sp_24134)});
        V v_t_24137 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24136, v_t_24135}), heff_dup(v_sp_24134)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24137}), v_sp_24134});
      }
      case TAG_SegmentUtf: {
        V v_ru_24seg12_246_24SegmentUtf = heff_take_reuse_n(v_seg12_246, 0ULL, 1);
        heff_drop(v_lit_240);
        heff_drop(v_sp_244);
        heff_drop(v_v_245);
        heff_drop(v_size_247);
        heff_drop(v_little_248);
        heff_drop(v_signed_249);
        V v_t_24139 = (g_heff_2esyntax_2epresyntax_2ebytesPart(v_r_241, heff_dup(v_seg_242)));
        V v_args_24140 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24139, NTAG(TAG_Nil)});
        V v_sp_24143;
        switch (heff_tag_of(v_seg_242)) {
        case TAG_At: {
          V v_s_24142 = heff_field(v_seg_242, 1);
          heff_take_n(v_seg_242, 2ULL, 2);
          v_sp_24143 = v_s_24142;
          break;
        }
        default: heff_nomatch(v_seg_242);
        }
        V v_t_24144 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24143), v_args_24140));
        V v_t_24145 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24seg12_246_24SegmentUtf, TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str5)}), heff_dup(v_sp_24143)});
        V v_t_24146 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24145, v_t_24144}), heff_dup(v_sp_24143)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24146}), v_sp_24143});
      }
      default: return heff_nomatch(v_seg12_246);
      }
    }
    default: return heff_nomatch(v_seg1_243);
    }
  }
  default: return heff_nomatch(v_seg_242);
  }
}
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebinaryIn_str0, 0, "");
Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryIn_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryIn(V v_r_240, V v_asBits_241, V v_segs_242, V v_sp_243) {
top: ;
  V v_t_249;
  if ((heff_dup(v_asBits_241) == NTAG(TAG_True))) {
    v_t_249 = NTAG(TAG_True);
  } else {
    V v_t_244 = (g_list_2eany_24s689038521x519269801(v_segs_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      v_t_249 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V v_t_245 = (g_list_2emap_24s34825065x1144190520(heff_dup(v_segs_242)));
      V v_x1_246 = ({ V a_0 = v_t_245; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2epresyntax_2eoddSum(a_0, a_1)); heff_drop(v_t_245); r_; });
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Nothing: {
        v_t_249 = NTAG(TAG_True);
        break;
      }
      case TAG_Just: {
        V v_n_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        v_t_249 = heff_bool(!heff_intEq_c(heff_dup(v_n_247), MK_INT(0LL)));
        heff_drop(v_n_247);
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
    }
  }
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_False); V r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
  } else {
    heff_drop(v_t_249);
    V v_x1_2410 = (g_list_2eany_24s689038521x519269801(v_segs_242));
    if ((heff_dup(v_x1_2410) == NTAG(TAG_True))) {
      heff_drop(v_x1_2410);
      return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_True); V r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
    } else {
      heff_drop(v_x1_2410);
      V v_t_2411 = (g_list_2eall_24s1687051711x1677682329(MK_INT(0LL), v_segs_242));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V v_t_2412 = (g_heff_2esyntax_2epresyntax_2ewholeBinary(v_segs_242, ((V)&g_heff_2esyntax_2epresyntax_2ebinaryIn_str0)));
        HEFF_LAST return g_heff_2esyntax_2epresyntax_2ebytesBinary(v_r_240, v_segs_242, v_sp_243, v_t_2412);
      } else {
        heff_drop(v_t_2411);
        return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_True); V r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2ebinaryIn(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_str0, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_str1, 10, "bitsConcat");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_str2, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_str3, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_str4, 10, "bitsConcat");
Clo g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580(V v_segs_240, V v_sp_241, V v_x5_242) {
top: ;
  if ((heff_dup(v_x5_242) == NTAG(TAG_True))) {
    V v_xs_243 = (g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158(((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_str0), v_segs_240, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_243));
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_244, heff_dup(v_sp_241)));
    V v_args_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_246));
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_str1)}), heff_dup(v_sp_241)});
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_248, v_t_247}), heff_dup(v_sp_241)});
    V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_249}), heff_dup(v_sp_241)});
    V v_args_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_str2)}), heff_dup(v_sp_241)});
    V v_t_2413 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2411));
    V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2412, v_t_2413}), v_sp_241});
    return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2414});
  } else {
    V v_xs_2415 = (g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158(((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_str3), v_segs_240, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2415));
    V v_t_2417 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2416, heff_dup(v_sp_241)));
    V v_args_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_str4)}), heff_dup(v_sp_241)});
    V v_t_2420 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2418));
    V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2419, v_t_2420}), v_sp_241});
    return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2421});
  }
}
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_SetField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_e_245 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24SetField = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      V v_x1_246 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_e_245));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2416 = v_c_2411;
        break;
      }
      case TAG_IsType: {
        V v_t_2412 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_t_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2412}), v_t_2415});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24SetField, TAG_SetField, 3, (V[]){v_x_243, v_xsp_244, v_t_2416}), v_sp_242});
    }
    case TAG_BadFieldSet: {
      V v_e_2417 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24BadFieldSet = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_x1_2418 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_e_2417));
      V v_t_2428;
      switch (heff_tag_of(v_x1_2418)) {
      case TAG_IsInferable: {
        V v_i_2419 = heff_field(v_x1_2418, 0);
        heff_take_n(v_x1_2418, 1ULL, 1);
        V v_t_2422;
        switch (heff_tag_of(v_i_2419)) {
        case TAG_At: {
          V v_s_2421 = heff_dup(heff_field(v_i_2419, 1));
          v_t_2422 = v_s_2421;
          break;
        }
        default: heff_nomatch(v_i_2419);
        }
        v_t_2428 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2419}), v_t_2422});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2423 = heff_field(v_x1_2418, 0);
        heff_take_n(v_x1_2418, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2428 = v_c_2423;
        break;
      }
      case TAG_IsType: {
        V v_t_2424 = heff_field(v_x1_2418, 0);
        heff_take_n(v_x1_2418, 1ULL, 1);
        V v_t_2427;
        switch (heff_tag_of(v_t_2424)) {
        case TAG_At: {
          V v_s_2426 = heff_dup(heff_field(v_t_2424, 1));
          v_t_2427 = v_s_2426;
          break;
        }
        default: heff_nomatch(v_t_2424);
        }
        v_t_2428 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2424}), v_t_2427});
        break;
      }
      default: heff_nomatch(v_x1_2418);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2428}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkAlt: {
      V v_p_243 = heff_field(v_x21_241, 0);
      V v_b_244 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24MkAlt = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_x1_245 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_b_244));
      V v_t_2415;
      switch (heff_tag_of(v_x1_245)) {
      case TAG_IsInferable: {
        V v_i_246 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_249;
        switch (heff_tag_of(v_i_246)) {
        case TAG_At: {
          V v_s_248 = heff_dup(heff_field(v_i_246, 1));
          v_t_249 = v_s_248;
          break;
        }
        default: heff_nomatch(v_i_246);
        }
        v_t_2415 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_246}), v_t_249});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2410 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2415 = v_c_2410;
        break;
      }
      case TAG_IsType: {
        V v_t_2411 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_At: {
          V v_s_2413 = heff_dup(heff_field(v_t_2411, 1));
          v_t_2414 = v_s_2413;
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        v_t_2415 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2411}), v_t_2414});
        break;
      }
      default: heff_nomatch(v_x1_245);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_243, v_t_2415}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkEquation: {
      V v_f_243 = heff_field(v_x21_241, 0);
      V v_fsp_244 = heff_field(v_x21_241, 1);
      V v_ps_245 = heff_field(v_x21_241, 2);
      V v_rhs_246 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24MkEquation = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_x1_247 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_rhs_246));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2417 = v_c_2412;
        break;
      }
      case TAG_IsType: {
        V v_t_2413 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_t_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_t_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2413}), v_t_2416});
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24MkEquation, TAG_MkEquation, 4, (V[]){v_f_243, v_fsp_244, v_ps_245, v_t_2417}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str0, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str1, 49, "cannot use descriptive syntax in nominal position");
Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_TPi: {
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_sp_240});
  }
  case TAG_TSig: {
    V v_ru_24n_241_24TSig = heff_take_reuse_n(v_n_241, 0ULL, 1);
    V v_t_246 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str0), NTAG(TAG_Nothing)});
    V v_t_247 = heff_tag_at_n(v_ru_24n_241_24TSig, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_sp_240});
  }
  case TAG_TSum: {
    V v_ru_24n_241_24TSum = heff_take_reuse_n(v_n_241, 0ULL, 1);
    V v_t_249 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str1), NTAG(TAG_Nothing)});
    V v_t_2410 = heff_tag_at_n(v_ru_24n_241_24TSum, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_sp_240});
  }
  case TAG_TType: {
    V v_t_2411 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_sp_240});
  }
  case TAG_TInt: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_sp_240});
  }
  case TAG_TFloat: {
    V v_t_2413 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_TString: {
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_sp_240});
  }
  case TAG_TRune: {
    V v_t_2415 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_sp_240});
  }
  case TAG_TArray: {
    V v_t_2417 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_sp_240});
  }
  case TAG_TFixed: {
    V v_t_2419 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_240});
  }
  case TAG_TInf: {
    V v_t_2421 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2421, v_sp_240});
  }
  case TAG_TChk: {
    V v_t_2423 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_sp_240});
  }
  case TAG_TNominal: {
    V v_t_2425 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_DeclEquations: {
    V v_f_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_declared_243 = heff_field(v_x2_240, 2);
    V v_ty_244 = heff_field(v_x2_240, 3);
    V v_eqs_245 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24DeclEquations = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_248;
    switch (heff_tag_of(v_ty_244)) {
    case TAG_At: {
      V v_n_246 = heff_field(v_ty_244, 0);
      V v_sp_247 = heff_field(v_ty_244, 1);
      heff_take_n(v_ty_244, 3ULL, 2);
      v_t_248 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_247, v_n_246));
      break;
    }
    default: heff_nomatch(v_ty_244);
    }
    V v_t_249 = (g_list_2emap_24s1782778565x402128078(v_eqs_245));
    return heff_tag_at_n(v_ru_24x2_240_24DeclEquations, TAG_DeclEquations, 5, (V[]){v_f_241, v_sp_242, v_declared_243, v_t_248, v_t_249});
  }
  case TAG_DeclDefine: {
    V v_x_2410 = heff_field(v_x2_240, 0);
    V v_sp_2411 = heff_field(v_x2_240, 1);
    V v_ps_2412 = heff_field(v_x2_240, 2);
    V v_u_2413 = heff_field(v_x2_240, 3);
    V v_body_2414 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24DeclDefine = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_2415 = (g_list_2emap_24s474585387x1072098790(v_ps_2412));
    V v_t_2418;
    switch (heff_tag_of(v_u_2413)) {
    case TAG_At: {
      V v_n_2416 = heff_field(v_u_2413, 0);
      V v_sp_2417 = heff_field(v_u_2413, 1);
      heff_take_n(v_u_2413, 3ULL, 2);
      v_t_2418 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2417, v_n_2416));
      break;
    }
    default: heff_nomatch(v_u_2413);
    }
    V v_t_2422;
    switch (heff_tag_of(v_body_2414)) {
    case TAG_At: {
      V v_n_2419 = heff_field(v_body_2414, 0);
      V v_sp_2420 = heff_field(v_body_2414, 1);
      V v_ru_24body_2414_24At = heff_take_reuse_n(v_body_2414, 3ULL, 2);
      V v_t_2421 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2419));
      v_t_2422 = heff_tag_at_n(v_ru_24body_2414_24At, TAG_At, 2, (V[]){v_t_2421, v_sp_2420});
      break;
    }
    default: heff_nomatch(v_body_2414);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_2410, v_sp_2411, v_t_2415, v_t_2418, v_t_2422});
  }
  case TAG_DeclTheory: {
    V v_x_2423 = heff_field(v_x2_240, 0);
    V v_sp_2424 = heff_field(v_x2_240, 1);
    V v_ps_2425 = heff_field(v_x2_240, 2);
    V v_body_2426 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24DeclTheory = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2427 = (g_list_2emap_24s474585387x1072098790(v_ps_2425));
    V v_t_2431;
    switch (heff_tag_of(v_body_2426)) {
    case TAG_At: {
      V v_n_2428 = heff_field(v_body_2426, 0);
      V v_sp_2429 = heff_field(v_body_2426, 1);
      V v_ru_24body_2426_24At = heff_take_reuse_n(v_body_2426, 3ULL, 2);
      V v_t_2430 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2428));
      v_t_2431 = heff_tag_at_n(v_ru_24body_2426_24At, TAG_At, 2, (V[]){v_t_2430, v_sp_2429});
      break;
    }
    default: heff_nomatch(v_body_2426);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2423, v_sp_2424, v_t_2427, v_t_2431});
  }
  case TAG_DeclPrimitive: {
    V v_x_2432 = heff_field(v_x2_240, 0);
    V v_sp_2433 = heff_field(v_x2_240, 1);
    V v_t_2434 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24DeclPrimitive = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_2437;
    switch (heff_tag_of(v_t_2434)) {
    case TAG_At: {
      V v_n_2435 = heff_field(v_t_2434, 0);
      V v_sp_2436 = heff_field(v_t_2434, 1);
      heff_take_n(v_t_2434, 3ULL, 2);
      v_t_2437 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2436, v_n_2435));
      break;
    }
    default: heff_nomatch(v_t_2434);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2432, v_sp_2433, v_t_2437});
  }
  case TAG_DeclTest: {
    V v_x_2438 = heff_field(v_x2_240, 0);
    V v_sp_2439 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24DeclTest = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24DeclTest, TAG_DeclTest, 2, (V[]){v_x_2438, v_sp_2439});
  }
  case TAG_DeclWatch: {
    V v_c_2440 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24DeclWatch = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2444;
    switch (heff_tag_of(v_c_2440)) {
    case TAG_At: {
      V v_n_2441 = heff_field(v_c_2440, 0);
      V v_sp_2442 = heff_field(v_c_2440, 1);
      V v_ru_24c_2440_24At = heff_take_reuse_n(v_c_2440, 3ULL, 2);
      V v_t_2443 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2441));
      v_t_2444 = heff_tag_at_n(v_ru_24c_2440_24At, TAG_At, 2, (V[]){v_t_2443, v_sp_2442});
      break;
    }
    default: heff_nomatch(v_c_2440);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclWatch, TAG_DeclWatch, 1, (V[]){v_t_2444});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(a[0]);
}