// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_EndValue 24675
#define TAG_IApp 21275
#define TAG_IInt 28905
#define TAG_IPrim 59489
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkSegment 38079
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_TagVariant 25174
#define LBL_bind 9519364
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_end 310101
#define LBL_giving 701566649
#define LBL_guard 300063423
#define LBL_inLam 301681229
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_sp 10436
#define LBL_start 311115900
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_names__muts__loop__sp__depth__giving[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth, LBL_giving};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s122821685x1786755984_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s42976669x698242400_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(V);
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
HeffT1 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(V);
HeffT2 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076(V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_clo;
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo;
V g_heff_2esyntax_2epresyntax_2ebytesPart(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_clo;
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecoNames_get(void);
V g_heff_2esyntax_2epresyntax_2econtrolT(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econtrolT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econtrolT_clo;
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(V);
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_clo;
V g_heff_2esyntax_2epresyntax_2edeclaredMuts(V);
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2edoBlock_24s1455639597x676970604_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183(V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_clo;
V g_heff_2esyntax_2epresyntax_2egiveBackMatch(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egiveBackMatch_clo;
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240(V, V);
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240_clo;
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241(V, V);
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241_clo;
V g_heff_2esyntax_2epresyntax_2eguardE(V, V);
V g_heff_2esyntax_2epresyntax_2eguardE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eguardE_clo;
V g_heff_2esyntax_2epresyntax_2ehasNest(V);
V g_heff_2esyntax_2epresyntax_2ehasNest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasNest_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
V g_heff_2esyntax_2epresyntax_2ejumpE(V);
V g_heff_2esyntax_2epresyntax_2ejumpE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpE_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2elastT(V, V, V);
V g_heff_2esyntax_2epresyntax_2elastT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2escopeJoin(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2escopeJoin_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2escopeJoin_clo;
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo;
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_heff_2esyntax_2epresyntax_2etryScope(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2etryScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etryScope_clo;
V g_heff_2esyntax_2epresyntax_2etryT_24tok1(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2etryT_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etryT_24tok1_clo;
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2evariantOf(V, V);
V g_heff_2esyntax_2epresyntax_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_clo;
V g_heff_2esyntax_2epresyntax_2ewithScopeOf(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithScopeOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithScopeOf_clo;
V g_heff_2esyntax_2epresyntax_2ewithT(V, V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithT_clo;
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eany_24s2077819594x1842428557(V, V);
V g_list_2eany_24s2077819594x1842428557_entry(V self, V *a);
extern Clo g_list_2eany_24s2077819594x1842428557_clo;
HeffT2 g_list_2efind_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1782778565x402128078(V);
V g_list_2emap_24s1782778565x402128078_entry(V self, V *a);
extern Clo g_list_2emap_24s1782778565x402128078_clo;
V g_list_2emap_24s1992667171x110340492(V);
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_clo;
V g_list_2emap_24s474585387x1072098790(V);
V g_list_2emap_24s474585387x1072098790_entry(V self, V *a);
extern Clo g_list_2emap_24s474585387x1072098790_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
Clo g_heff_2esyntax_2epresyntax_2ehasNest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ehasNest_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ehasNest(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_244 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_245 = v_t_244.f[0];
        V v_field_246 = v_t_244.f[1];
        V v_x_247 = v_field_245;
        V v_y_248 = v_field_246;
        heff_drop(v_y_248);
        return v_x_247;
      }
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2410 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_x_2413 = v_field_2411;
        V v_y_2414 = v_field_2412;
        heff_drop(v_y_2414);
        return v_x_2413;
      }
    }
    case TAG_ETag: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2416 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2417 = v_t_2416.f[0];
        V v_field_2418 = v_t_2416.f[1];
        V v_x_2419 = v_field_2417;
        V v_y_2420 = v_field_2418;
        heff_drop(v_y_2420);
        return v_x_2419;
      }
    }
    case TAG_EInt: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2422 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2423 = v_t_2422.f[0];
        V v_field_2424 = v_t_2422.f[1];
        V v_x_2425 = v_field_2423;
        V v_y_2426 = v_field_2424;
        heff_drop(v_y_2426);
        return v_x_2425;
      }
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2428 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2429 = v_t_2428.f[0];
        V v_field_2430 = v_t_2428.f[1];
        V v_x_2431 = v_field_2429;
        V v_y_2432 = v_field_2430;
        heff_drop(v_y_2432);
        return v_x_2431;
      }
    }
    case TAG_EString: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2434 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2435 = v_t_2434.f[0];
        V v_field_2436 = v_t_2434.f[1];
        V v_x_2437 = v_field_2435;
        V v_y_2438 = v_field_2436;
        heff_drop(v_y_2438);
        return v_x_2437;
      }
    }
    case TAG_EBinary: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2440 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2441 = v_t_2440.f[0];
        V v_field_2442 = v_t_2440.f[1];
        V v_x_2443 = v_field_2441;
        V v_y_2444 = v_field_2442;
        heff_drop(v_y_2444);
        return v_x_2443;
      }
    }
    case TAG_ERune: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2446 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2447 = v_t_2446.f[0];
        V v_field_2448 = v_t_2446.f[1];
        V v_x_2449 = v_field_2447;
        V v_y_2450 = v_field_2448;
        heff_drop(v_y_2450);
        return v_x_2449;
      }
    }
    case TAG_EWord: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2452 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2453 = v_t_2452.f[0];
        V v_field_2454 = v_t_2452.f[1];
        V v_x_2455 = v_field_2453;
        V v_y_2456 = v_field_2454;
        heff_drop(v_y_2456);
        return v_x_2455;
      }
    }
    case TAG_EApp: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_2459 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2460 = v_t_2459.f[0];
        V v_field_2461 = v_t_2459.f[1];
        V v_x_2462 = v_field_2460;
        V v_y_2463 = v_field_2461;
        heff_drop(v_y_2463);
        return v_x_2462;
      }
    }
    case TAG_EProject: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_2465 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2466 = v_t_2465.f[0];
        V v_field_2467 = v_t_2465.f[1];
        V v_x_2468 = v_field_2466;
        V v_y_2469 = v_field_2467;
        heff_drop(v_y_2469);
        return v_x_2468;
      }
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_2472 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2473 = v_t_2472.f[0];
        V v_field_2474 = v_t_2472.f[1];
        V v_x_2475 = v_field_2473;
        V v_y_2476 = v_field_2474;
        heff_drop(v_y_2476);
        return v_x_2475;
      }
    }
    case TAG_EPi: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_2479 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2480 = v_t_2479.f[0];
        V v_field_2481 = v_t_2479.f[1];
        V v_x_2482 = v_field_2480;
        V v_y_2483 = v_field_2481;
        heff_drop(v_y_2483);
        return v_x_2482;
      }
    }
    case TAG_ELam: {
      heff_take_n(v_e1_241, 0ULL, 2);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EAnn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_2490 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2491 = v_t_2490.f[0];
        V v_field_2492 = v_t_2490.f[1];
        V v_x_2493 = v_field_2491;
        V v_y_2494 = v_field_2492;
        heff_drop(v_y_2494);
        return v_x_2493;
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_241, 0ULL, 4);
      HeffT2 v_t_2499 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24100 = v_t_2499.f[0];
        V v_field_24101 = v_t_2499.f[1];
        V v_x_24102 = v_field_24100;
        V v_y_24103 = v_field_24101;
        heff_drop(v_y_24103);
        return v_x_24102;
      }
    }
    case TAG_ESig: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24105 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24106 = v_t_24105.f[0];
        V v_field_24107 = v_t_24105.f[1];
        V v_x_24108 = v_field_24106;
        V v_y_24109 = v_field_24107;
        heff_drop(v_y_24109);
        return v_x_24108;
      }
    }
    case TAG_ESum: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24111 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24112 = v_t_24111.f[0];
        V v_field_24113 = v_t_24111.f[1];
        V v_x_24114 = v_field_24112;
        V v_y_24115 = v_field_24113;
        heff_drop(v_y_24115);
        return v_x_24114;
      }
    }
    case TAG_EStruct: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24117 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24118 = v_t_24117.f[0];
        V v_field_24119 = v_t_24117.f[1];
        V v_x_24120 = v_field_24118;
        V v_y_24121 = v_field_24119;
        heff_drop(v_y_24121);
        return v_x_24120;
      }
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24124 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24125 = v_t_24124.f[0];
        V v_field_24126 = v_t_24124.f[1];
        V v_x_24127 = v_field_24125;
        V v_y_24128 = v_field_24126;
        heff_drop(v_y_24128);
        return v_x_24127;
      }
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24131 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24132 = v_t_24131.f[0];
        V v_field_24133 = v_t_24131.f[1];
        V v_x_24134 = v_field_24132;
        V v_y_24135 = v_field_24133;
        heff_drop(v_y_24135);
        return v_x_24134;
      }
    }
    case TAG_ELetIn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24138 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24139 = v_t_24138.f[0];
        V v_field_24140 = v_t_24138.f[1];
        V v_x_24141 = v_field_24139;
        V v_y_24142 = v_field_24140;
        heff_drop(v_y_24142);
        return v_x_24141;
      }
    }
    case TAG_EDo: {
      heff_take_n(v_e1_241, 0ULL, 1);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24148 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24149 = v_t_24148.f[0];
        V v_field_24150 = v_t_24148.f[1];
        V v_x_24151 = v_field_24149;
        V v_y_24152 = v_field_24150;
        heff_drop(v_y_24152);
        return v_x_24151;
      }
    }
    case TAG_EInvalid: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24154 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24155 = v_t_24154.f[0];
        V v_field_24156 = v_t_24154.f[1];
        V v_x_24157 = v_field_24155;
        V v_y_24158 = v_field_24156;
        heff_drop(v_y_24158);
        return v_x_24157;
      }
    }
    case TAG_EAssign: {
      heff_take_n(v_e1_241, 0ULL, 3);
      HeffT2 v_t_24162 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24163 = v_t_24162.f[0];
        V v_field_24164 = v_t_24162.f[1];
        V v_x_24165 = v_field_24163;
        V v_y_24166 = v_field_24164;
        heff_drop(v_y_24166);
        return v_x_24165;
      }
    }
    case TAG_EWhile: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24169 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24170 = v_t_24169.f[0];
        V v_field_24171 = v_t_24169.f[1];
        V v_x_24172 = v_field_24170;
        V v_y_24173 = v_field_24171;
        heff_drop(v_y_24173);
        return v_x_24172;
      }
    }
    case TAG_EFor: {
      heff_take_n(v_e1_241, 0ULL, 3);
      HeffT2 v_t_24177 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24178 = v_t_24177.f[0];
        V v_field_24179 = v_t_24177.f[1];
        V v_x_24180 = v_field_24178;
        V v_y_24181 = v_field_24179;
        heff_drop(v_y_24181);
        return v_x_24180;
      }
    }
    case TAG_EIfThen: {
      heff_take_n(v_e1_241, 0ULL, 2);
      HeffT2 v_t_24184 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24185 = v_t_24184.f[0];
        V v_field_24186 = v_t_24184.f[1];
        V v_x_24187 = v_field_24185;
        V v_y_24188 = v_field_24186;
        heff_drop(v_y_24188);
        return v_x_24187;
      }
    }
    case TAG_EBreak: {
      HeffT2 v_t_24189 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24190 = v_t_24189.f[0];
        V v_field_24191 = v_t_24189.f[1];
        V v_x_24192 = v_field_24190;
        V v_y_24193 = v_field_24191;
        heff_drop(v_y_24193);
        return v_x_24192;
      }
    }
    case TAG_EContinue: {
      HeffT2 v_t_24194 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24195 = v_t_24194.f[0];
        V v_field_24196 = v_t_24194.f[1];
        V v_x_24197 = v_field_24195;
        V v_y_24198 = v_field_24196;
        heff_drop(v_y_24198);
        return v_x_24197;
      }
    }
    case TAG_EReturn: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24200 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24201 = v_t_24200.f[0];
        V v_field_24202 = v_t_24200.f[1];
        V v_x_24203 = v_field_24201;
        V v_y_24204 = v_field_24202;
        heff_drop(v_y_24204);
        return v_x_24203;
      }
    }
    case TAG_ENest: {
      heff_take_n(v_e1_241, 0ULL, 1);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_ELazy: {
      heff_take_n(v_e1_241, 0ULL, 1);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_ETuple: {
      heff_take_n(v_e1_241, 0ULL, 1);
      HeffT2 v_t_24212 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_24213 = v_t_24212.f[0];
        V v_field_24214 = v_t_24212.f[1];
        V v_x_24215 = v_field_24213;
        V v_y_24216 = v_field_24214;
        heff_drop(v_y_24216);
        return v_x_24215;
      }
    }
    case TAG_ETry: {
      heff_take_n(v_e1_241, 0ULL, 1);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EWith: {
      heff_take_n(v_e1_241, 0ULL, 4);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    default: return heff_nomatch(v_e1_241);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ehasNest_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ehasNest(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eguardE_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eguardE_str1, 135, "` is a `let mut` variable of the `do` block around: a closure (a lambda, or a `do` block of its own) holds its value, and cannot set it");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eguardE_str2, 95, "`break` is in a lambda: a loop's statements are its body's, and a lambda's body is none of them");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eguardE_str3, 98, "`continue` is in a lambda: a loop's statements are its body's, and a lambda's body is none of them");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eguardE_str4, 105, "`return` is in a lambda: it ends the `do` block it is a statement of, and a lambda's body is no statement");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eguardE_str5, 118, "`(<- c)` is in a lambda, whose body runs later, not where the statement does: bind the action's value before, `x <- c`");
V g_heff_2esyntax_2epresyntax_2eguardE_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam1(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam2(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam3(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam4(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam5(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam6(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam7(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam8(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam9(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam10(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam11(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam12(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam13(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam14(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam15(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam16(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam17(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam18(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam19(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam20(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam21(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam22(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam23(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam24(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam25(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam26(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam27(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam28(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam29(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam30(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2eguardE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eguardE_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eguardE(V v_g_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_At: {
    V v_e1_242 = heff_dup(heff_field(v_e_241, 0));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_EVar: {
      heff_take_n(v_e1_242, 0ULL, 1);
      V v_f_245 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam0, 2, 1, (V[]){v_f_245}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_x_2412 = v_field_2410;
        heff_drop(v_x_2412);
        V v_y_2413 = v_field_2411;
        return v_y_2413;
      }
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e1_242, 0ULL, 1);
      V v_f_2415 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_2419 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam1, 2, 1, (V[]){v_f_2415}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_2420 = v_t_2419.f[0];
        V v_field_2421 = v_t_2419.f[1];
        V v_x_2422 = v_field_2420;
        heff_drop(v_x_2422);
        V v_y_2423 = v_field_2421;
        return v_y_2423;
      }
    }
    case TAG_ETag: {
      heff_take_n(v_e1_242, 0ULL, 1);
      V v_f_2425 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_2429 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam2, 2, 1, (V[]){v_f_2425}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_2430 = v_t_2429.f[0];
        V v_field_2431 = v_t_2429.f[1];
        V v_x_2432 = v_field_2430;
        heff_drop(v_x_2432);
        V v_y_2433 = v_field_2431;
        return v_y_2433;
      }
    }
    case TAG_EInt: {
      heff_take_n(v_e1_242, 0ULL, 1);
      V v_f_2435 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_2439 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam3, 2, 1, (V[]){v_f_2435}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_2440 = v_t_2439.f[0];
        V v_field_2441 = v_t_2439.f[1];
        V v_x_2442 = v_field_2440;
        heff_drop(v_x_2442);
        V v_y_2443 = v_field_2441;
        return v_y_2443;
      }
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_242, 0ULL, 1);
      V v_f_2445 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_2449 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam4, 2, 1, (V[]){v_f_2445}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_2450 = v_t_2449.f[0];
        V v_field_2451 = v_t_2449.f[1];
        V v_x_2452 = v_field_2450;
        heff_drop(v_x_2452);
        V v_y_2453 = v_field_2451;
        return v_y_2453;
      }
    }
    case TAG_EString: {
      heff_take_n(v_e1_242, 0ULL, 1);
      V v_f_2455 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_2459 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam5, 2, 1, (V[]){v_f_2455}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_2460 = v_t_2459.f[0];
        V v_field_2461 = v_t_2459.f[1];
        V v_x_2462 = v_field_2460;
        heff_drop(v_x_2462);
        V v_y_2463 = v_field_2461;
        return v_y_2463;
      }
    }
    case TAG_EBinary: {
      heff_take_n(v_e1_242, 0ULL, 1);
      V v_f_2465 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_2469 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam6, 2, 1, (V[]){v_f_2465}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_2470 = v_t_2469.f[0];
        V v_field_2471 = v_t_2469.f[1];
        V v_x_2472 = v_field_2470;
        heff_drop(v_x_2472);
        V v_y_2473 = v_field_2471;
        return v_y_2473;
      }
    }
    case TAG_ERune: {
      heff_take_n(v_e1_242, 0ULL, 1);
      V v_f_2475 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_2479 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam7, 2, 1, (V[]){v_f_2475}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_2480 = v_t_2479.f[0];
        V v_field_2481 = v_t_2479.f[1];
        V v_x_2482 = v_field_2480;
        heff_drop(v_x_2482);
        V v_y_2483 = v_field_2481;
        return v_y_2483;
      }
    }
    case TAG_EWord: {
      heff_take_n(v_e1_242, 0ULL, 1);
      V v_f_2485 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_2489 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam8, 2, 1, (V[]){v_f_2485}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_2490 = v_t_2489.f[0];
        V v_field_2491 = v_t_2489.f[1];
        V v_x_2492 = v_field_2490;
        heff_drop(v_x_2492);
        V v_y_2493 = v_field_2491;
        return v_y_2493;
      }
    }
    case TAG_EApp: {
      heff_take_n(v_e1_242, 0ULL, 2);
      V v_f_2496 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24100 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam9, 2, 1, (V[]){v_f_2496}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24101 = v_t_24100.f[0];
        V v_field_24102 = v_t_24100.f[1];
        V v_x_24103 = v_field_24101;
        heff_drop(v_x_24103);
        V v_y_24104 = v_field_24102;
        return v_y_24104;
      }
    }
    case TAG_EProject: {
      heff_take_n(v_e1_242, 0ULL, 1);
      V v_f_24106 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24110 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam10, 2, 1, (V[]){v_f_24106}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24111 = v_t_24110.f[0];
        V v_field_24112 = v_t_24110.f[1];
        V v_x_24113 = v_field_24111;
        heff_drop(v_x_24113);
        V v_y_24114 = v_field_24112;
        return v_y_24114;
      }
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_242, 0ULL, 2);
      V v_f_24117 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24121 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam11, 2, 1, (V[]){v_f_24117}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24122 = v_t_24121.f[0];
        V v_field_24123 = v_t_24121.f[1];
        V v_x_24124 = v_field_24122;
        heff_drop(v_x_24124);
        V v_y_24125 = v_field_24123;
        return v_y_24125;
      }
    }
    case TAG_EPi: {
      heff_take_n(v_e1_242, 0ULL, 2);
      V v_f_24128 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24132 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam12, 2, 1, (V[]){v_f_24128}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24133 = v_t_24132.f[0];
        V v_field_24134 = v_t_24132.f[1];
        V v_x_24135 = v_field_24133;
        heff_drop(v_x_24135);
        V v_y_24136 = v_field_24134;
        return v_y_24136;
      }
    }
    case TAG_ELam: {
      V v_b_24137 = heff_field(v_e1_242, 0);
      V v_body_24138 = heff_field(v_e1_242, 1);
      V v_ru_24e1_242_24ELam = heff_take_reuse_n(v_e1_242, 3ULL, 2);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_24140 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_24141 = ({ V rv_1 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_g_240, 1ULL, 2, shape_muts__inLam, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24142 = (g_heff_2esyntax_2epresyntax_2eguardE(v_t_24141, v_body_24138));
        return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ELam, TAG_ELam, 2, (V[]){v_b_24137, v_t_24142}), v_sp_24140});
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_EAnn: {
      heff_take_n(v_e1_242, 0ULL, 2);
      V v_f_24145 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24149 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam13, 2, 1, (V[]){v_f_24145}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24150 = v_t_24149.f[0];
        V v_field_24151 = v_t_24149.f[1];
        V v_x_24152 = v_field_24150;
        heff_drop(v_x_24152);
        V v_y_24153 = v_field_24151;
        return v_y_24153;
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_242, 0ULL, 4);
      V v_f_24158 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24162 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam14, 2, 1, (V[]){v_f_24158}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24163 = v_t_24162.f[0];
        V v_field_24164 = v_t_24162.f[1];
        V v_x_24165 = v_field_24163;
        heff_drop(v_x_24165);
        V v_y_24166 = v_field_24164;
        return v_y_24166;
      }
    }
    case TAG_ESig: {
      heff_take_n(v_e1_242, 0ULL, 1);
      V v_f_24168 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24172 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam15, 2, 1, (V[]){v_f_24168}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24173 = v_t_24172.f[0];
        V v_field_24174 = v_t_24172.f[1];
        V v_x_24175 = v_field_24173;
        heff_drop(v_x_24175);
        V v_y_24176 = v_field_24174;
        return v_y_24176;
      }
    }
    case TAG_ESum: {
      heff_take_n(v_e1_242, 0ULL, 1);
      V v_f_24178 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24182 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam16, 2, 1, (V[]){v_f_24178}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24183 = v_t_24182.f[0];
        V v_field_24184 = v_t_24182.f[1];
        V v_x_24185 = v_field_24183;
        heff_drop(v_x_24185);
        V v_y_24186 = v_field_24184;
        return v_y_24186;
      }
    }
    case TAG_EStruct: {
      heff_take_n(v_e1_242, 0ULL, 1);
      V v_f_24188 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24192 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam17, 2, 1, (V[]){v_f_24188}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24193 = v_t_24192.f[0];
        V v_field_24194 = v_t_24192.f[1];
        V v_x_24195 = v_field_24193;
        heff_drop(v_x_24195);
        V v_y_24196 = v_field_24194;
        return v_y_24196;
      }
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_242, 0ULL, 2);
      V v_f_24199 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24203 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam18, 2, 1, (V[]){v_f_24199}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24204 = v_t_24203.f[0];
        V v_field_24205 = v_t_24203.f[1];
        V v_x_24206 = v_field_24204;
        heff_drop(v_x_24206);
        V v_y_24207 = v_field_24205;
        return v_y_24207;
      }
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_242, 0ULL, 2);
      V v_f_24210 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24214 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam19, 2, 1, (V[]){v_f_24210}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24215 = v_t_24214.f[0];
        V v_field_24216 = v_t_24214.f[1];
        V v_x_24217 = v_field_24215;
        heff_drop(v_x_24217);
        V v_y_24218 = v_field_24216;
        return v_y_24218;
      }
    }
    case TAG_ELetIn: {
      heff_take_n(v_e1_242, 0ULL, 2);
      V v_f_24221 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24225 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam20, 2, 1, (V[]){v_f_24221}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24226 = v_t_24225.f[0];
        V v_field_24227 = v_t_24225.f[1];
        V v_x_24228 = v_field_24226;
        heff_drop(v_x_24228);
        V v_y_24229 = v_field_24227;
        return v_y_24229;
      }
    }
    case TAG_EDo: {
      V v_ss_24230 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24EDo = heff_take_reuse_n(v_e1_242, 1ULL, 1);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_24232 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_24236 = (g_list_2ekeepIf(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam21, 1, 1, (V[]){heff_dup(v_ss_24230)}), heff_get_n(v_g_240, 0, 2)));
        V v_t_24237 = heff_rec_n(2, shape_muts__inLam, (V[]){v_t_24236, NTAG(TAG_False)});
        V v_f_24238 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_t_24237}));
        V v_t_24239 = heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EDo, TAG_EDo, 1, (V[]){v_ss_24230}), v_sp_24232});
        HeffT2 v_t_24243 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam22, 2, 1, (V[]){v_f_24238}), NTAG(TAG_MkUnit), v_t_24239));
        {
          V v_field_24244 = v_t_24243.f[0];
          V v_field_24245 = v_t_24243.f[1];
          V v_x_24246 = v_field_24244;
          heff_drop(v_x_24246);
          V v_y_24247 = v_field_24245;
          return v_y_24247;
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_242, 0ULL, 2);
      V v_f_24250 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24254 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam23, 2, 1, (V[]){v_f_24250}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24255 = v_t_24254.f[0];
        V v_field_24256 = v_t_24254.f[1];
        V v_x_24257 = v_field_24255;
        heff_drop(v_x_24257);
        V v_y_24258 = v_field_24256;
        return v_y_24258;
      }
    }
    case TAG_EInvalid: {
      heff_take_n(v_e1_242, 0ULL, 1);
      V v_f_24260 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24264 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam24, 2, 1, (V[]){v_f_24260}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24265 = v_t_24264.f[0];
        V v_field_24266 = v_t_24264.f[1];
        V v_x_24267 = v_field_24265;
        heff_drop(v_x_24267);
        V v_y_24268 = v_field_24266;
        return v_y_24268;
      }
    }
    case TAG_EAssign: {
      V v_x_24269 = heff_field(v_e1_242, 0);
      V v_xsp_24270 = heff_field(v_e1_242, 1);
      V v_v_24271 = heff_field(v_e1_242, 2);
      V v_ru_24e1_242_24EAssign = heff_take_reuse_n(v_e1_242, 7ULL, 3);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_24273 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_24274 = (g_list_2eany_24s2077819594x1842428557(v_x_24269, heff_rfield(v_g_240, 0)));
        if ((heff_dup(v_t_24274) == NTAG(TAG_True))) {
          heff_drop_rec(v_g_240, 2);
          heff_drop(v_v_24271);
          heff_drop_cell(v_ru_24e1_242_24EAssign, 3);
          heff_drop(v_sp_24273);
          heff_drop(v_t_24274);
          V v_t_24275 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eguardE_str0), heff_strAppend(v_x_24269, ((V)&g_heff_2esyntax_2epresyntax_2eguardE_str1)));
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24275}), v_xsp_24270});
        } else {
          heff_drop(v_t_24274);
          V v_t_24276 = (g_heff_2esyntax_2epresyntax_2eguardE(v_g_240, v_v_24271));
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EAssign, TAG_EAssign, 3, (V[]){v_x_24269, v_xsp_24270, v_t_24276}), v_sp_24273});
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_EWhile: {
      heff_take_n(v_e1_242, 0ULL, 2);
      V v_f_24279 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24283 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam25, 2, 1, (V[]){v_f_24279}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24284 = v_t_24283.f[0];
        V v_field_24285 = v_t_24283.f[1];
        V v_x_24286 = v_field_24284;
        heff_drop(v_x_24286);
        V v_y_24287 = v_field_24285;
        return v_y_24287;
      }
    }
    case TAG_EFor: {
      heff_take_n(v_e1_242, 0ULL, 3);
      V v_f_24291 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24295 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam26, 2, 1, (V[]){v_f_24291}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24296 = v_t_24295.f[0];
        V v_field_24297 = v_t_24295.f[1];
        V v_x_24298 = v_field_24296;
        heff_drop(v_x_24298);
        V v_y_24299 = v_field_24297;
        return v_y_24299;
      }
    }
    case TAG_EIfThen: {
      heff_take_n(v_e1_242, 0ULL, 2);
      V v_f_24302 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24306 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam27, 2, 1, (V[]){v_f_24302}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24307 = v_t_24306.f[0];
        V v_field_24308 = v_t_24306.f[1];
        V v_x_24309 = v_field_24307;
        heff_drop(v_x_24309);
        V v_y_24310 = v_field_24308;
        return v_y_24310;
      }
    }
    case TAG_EBreak: {
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_24312 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_24313 = heff_get_n(v_g_240, 1, 2);
        if ((heff_dup(v_t_24313) == NTAG(TAG_True))) {
          heff_drop(v_t_24313);
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eguardE_str2)}), v_sp_24312});
        } else {
          heff_drop(v_t_24313);
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){NTAG(TAG_EBreak), v_sp_24312});
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_EContinue: {
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_24315 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_24316 = heff_get_n(v_g_240, 1, 2);
        if ((heff_dup(v_t_24316) == NTAG(TAG_True))) {
          heff_drop(v_t_24316);
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eguardE_str3)}), v_sp_24315});
        } else {
          heff_drop(v_t_24316);
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){NTAG(TAG_EContinue), v_sp_24315});
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_EReturn: {
      V v_v_24317 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24EReturn = heff_take_reuse_n(v_e1_242, 1ULL, 1);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_24319 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_24320 = heff_dup(heff_rfield(v_g_240, 1));
        if ((heff_dup(v_t_24320) == NTAG(TAG_True))) {
          heff_drop_rec(v_g_240, 2);
          heff_drop(v_v_24317);
          heff_drop_cell(v_ru_24e1_242_24EReturn, 1);
          heff_drop(v_t_24320);
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eguardE_str4)}), v_sp_24319});
        } else {
          heff_drop(v_t_24320);
          V v_t_24321 = (g_heff_2esyntax_2epresyntax_2eguardE(v_g_240, v_v_24317));
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EReturn, TAG_EReturn, 1, (V[]){v_t_24321}), v_sp_24319});
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_ENest: {
      V v_c_24322 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24ENest = heff_take_reuse_n(v_e1_242, 1ULL, 1);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_24324 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_24325 = heff_dup(heff_rfield(v_g_240, 1));
        if ((heff_dup(v_t_24325) == NTAG(TAG_True))) {
          heff_drop_rec(v_g_240, 2);
          heff_drop(v_c_24322);
          heff_drop_cell(v_ru_24e1_242_24ENest, 1);
          heff_drop(v_t_24325);
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eguardE_str5)}), v_sp_24324});
        } else {
          heff_drop(v_t_24325);
          V v_t_24326 = (g_heff_2esyntax_2epresyntax_2eguardE(v_g_240, v_c_24322));
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ENest, TAG_ENest, 1, (V[]){v_t_24326}), v_sp_24324});
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_ELazy: {
      V v_body_24327 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24ELazy = heff_take_reuse_n(v_e1_242, 1ULL, 1);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_24329 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_24330 = ({ V rv_1 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_g_240, 1ULL, 2, shape_muts__inLam, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24331 = (g_heff_2esyntax_2epresyntax_2eguardE(v_t_24330, v_body_24327));
        return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ELazy, TAG_ELazy, 1, (V[]){v_t_24331}), v_sp_24329});
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_ETuple: {
      heff_take_n(v_e1_242, 0ULL, 1);
      V v_f_24333 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24337 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam28, 2, 1, (V[]){v_f_24333}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24338 = v_t_24337.f[0];
        V v_field_24339 = v_t_24337.f[1];
        V v_x_24340 = v_field_24338;
        heff_drop(v_x_24340);
        V v_y_24341 = v_field_24339;
        return v_y_24341;
      }
    }
    case TAG_ETry: {
      heff_take_n(v_e1_242, 0ULL, 1);
      V v_f_24343 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24347 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam29, 2, 1, (V[]){v_f_24343}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24348 = v_t_24347.f[0];
        V v_field_24349 = v_t_24347.f[1];
        V v_x_24350 = v_field_24348;
        heff_drop(v_x_24350);
        V v_y_24351 = v_field_24349;
        return v_y_24351;
      }
    }
    case TAG_EWith: {
      heff_take_n(v_e1_242, 0ULL, 4);
      V v_f_24356 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_24360 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam30, 2, 1, (V[]){v_f_24356}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_24361 = v_t_24360.f[0];
        V v_field_24362 = v_t_24360.f[1];
        V v_x_24363 = v_field_24361;
        heff_drop(v_x_24363);
        V v_y_24364 = v_field_24362;
        return v_y_24364;
      }
    }
    default: return heff_nomatch(v_e1_242);
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eguardE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eguardE(a[0], a[1]);
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam0(V self, V *args) {
  V v_u_246 = args[0];
  V v_c_247 = args[1];
  V v_f_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tr(heff_call(v_f_245, 1, (V[]){v_c_247}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_246, v_t_248});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam1(V self, V *args) {
  V v_u_2416 = args[0];
  V v_c_2417 = args[1];
  V v_f_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_tr(heff_call(v_f_2415, 1, (V[]){v_c_2417}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2416, v_t_2418});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam2(V self, V *args) {
  V v_u_2426 = args[0];
  V v_c_2427 = args[1];
  V v_f_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = heff_tr(heff_call(v_f_2425, 1, (V[]){v_c_2427}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2426, v_t_2428});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam3(V self, V *args) {
  V v_u_2436 = args[0];
  V v_c_2437 = args[1];
  V v_f_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2438 = heff_tr(heff_call(v_f_2435, 1, (V[]){v_c_2437}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2436, v_t_2438});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam4(V self, V *args) {
  V v_u_2446 = args[0];
  V v_c_2447 = args[1];
  V v_f_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448 = heff_tr(heff_call(v_f_2445, 1, (V[]){v_c_2447}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2446, v_t_2448});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam5(V self, V *args) {
  V v_u_2456 = args[0];
  V v_c_2457 = args[1];
  V v_f_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458 = heff_tr(heff_call(v_f_2455, 1, (V[]){v_c_2457}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2456, v_t_2458});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam6(V self, V *args) {
  V v_u_2466 = args[0];
  V v_c_2467 = args[1];
  V v_f_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2468 = heff_tr(heff_call(v_f_2465, 1, (V[]){v_c_2467}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2466, v_t_2468});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam7(V self, V *args) {
  V v_u_2476 = args[0];
  V v_c_2477 = args[1];
  V v_f_2475 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2478 = heff_tr(heff_call(v_f_2475, 1, (V[]){v_c_2477}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2476, v_t_2478});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam8(V self, V *args) {
  V v_u_2486 = args[0];
  V v_c_2487 = args[1];
  V v_f_2485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2488 = heff_tr(heff_call(v_f_2485, 1, (V[]){v_c_2487}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2486, v_t_2488});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam9(V self, V *args) {
  V v_u_2497 = args[0];
  V v_c_2498 = args[1];
  V v_f_2496 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2499 = heff_tr(heff_call(v_f_2496, 1, (V[]){v_c_2498}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2497, v_t_2499});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam10(V self, V *args) {
  V v_u_24107 = args[0];
  V v_c_24108 = args[1];
  V v_f_24106 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24109 = heff_tr(heff_call(v_f_24106, 1, (V[]){v_c_24108}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24107, v_t_24109});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam11(V self, V *args) {
  V v_u_24118 = args[0];
  V v_c_24119 = args[1];
  V v_f_24117 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24120 = heff_tr(heff_call(v_f_24117, 1, (V[]){v_c_24119}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24118, v_t_24120});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam12(V self, V *args) {
  V v_u_24129 = args[0];
  V v_c_24130 = args[1];
  V v_f_24128 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24131 = heff_tr(heff_call(v_f_24128, 1, (V[]){v_c_24130}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24129, v_t_24131});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam13(V self, V *args) {
  V v_u_24146 = args[0];
  V v_c_24147 = args[1];
  V v_f_24145 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24148 = heff_tr(heff_call(v_f_24145, 1, (V[]){v_c_24147}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24146, v_t_24148});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam14(V self, V *args) {
  V v_u_24159 = args[0];
  V v_c_24160 = args[1];
  V v_f_24158 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24161 = heff_tr(heff_call(v_f_24158, 1, (V[]){v_c_24160}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24159, v_t_24161});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam15(V self, V *args) {
  V v_u_24169 = args[0];
  V v_c_24170 = args[1];
  V v_f_24168 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24171 = heff_tr(heff_call(v_f_24168, 1, (V[]){v_c_24170}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24169, v_t_24171});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam16(V self, V *args) {
  V v_u_24179 = args[0];
  V v_c_24180 = args[1];
  V v_f_24178 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24181 = heff_tr(heff_call(v_f_24178, 1, (V[]){v_c_24180}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24179, v_t_24181});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam17(V self, V *args) {
  V v_u_24189 = args[0];
  V v_c_24190 = args[1];
  V v_f_24188 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24191 = heff_tr(heff_call(v_f_24188, 1, (V[]){v_c_24190}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24189, v_t_24191});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam18(V self, V *args) {
  V v_u_24200 = args[0];
  V v_c_24201 = args[1];
  V v_f_24199 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24202 = heff_tr(heff_call(v_f_24199, 1, (V[]){v_c_24201}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24200, v_t_24202});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam19(V self, V *args) {
  V v_u_24211 = args[0];
  V v_c_24212 = args[1];
  V v_f_24210 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24213 = heff_tr(heff_call(v_f_24210, 1, (V[]){v_c_24212}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24211, v_t_24213});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam20(V self, V *args) {
  V v_u_24222 = args[0];
  V v_c_24223 = args[1];
  V v_f_24221 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24224 = heff_tr(heff_call(v_f_24221, 1, (V[]){v_c_24223}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24222, v_t_24224});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam21(V self, V *args) {
  V v_x_24233 = args[0];
  V v_ss_24230 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24234 = (g_heff_2esyntax_2epresyntax_2edeclaredMuts(v_ss_24230));
  V v_x1_24235 = ({ V a_0 = v_x_24233; V a_1 = v_t_24234; V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, a_1)); heff_drop(v_x_24233); heff_drop(v_t_24234); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_24235) == NTAG(TAG_True)));
  heff_drop(v_x1_24235);
  return v_ret_24bool;
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam22(V self, V *args) {
  V v_u_24240 = args[0];
  V v_c_24241 = args[1];
  V v_f_24238 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24242 = heff_tr(heff_call(v_f_24238, 1, (V[]){v_c_24241}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24240, v_t_24242});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam23(V self, V *args) {
  V v_u_24251 = args[0];
  V v_c_24252 = args[1];
  V v_f_24250 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24253 = heff_tr(heff_call(v_f_24250, 1, (V[]){v_c_24252}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24251, v_t_24253});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam24(V self, V *args) {
  V v_u_24261 = args[0];
  V v_c_24262 = args[1];
  V v_f_24260 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24263 = heff_tr(heff_call(v_f_24260, 1, (V[]){v_c_24262}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24261, v_t_24263});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam25(V self, V *args) {
  V v_u_24280 = args[0];
  V v_c_24281 = args[1];
  V v_f_24279 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24282 = heff_tr(heff_call(v_f_24279, 1, (V[]){v_c_24281}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24280, v_t_24282});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam26(V self, V *args) {
  V v_u_24292 = args[0];
  V v_c_24293 = args[1];
  V v_f_24291 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24294 = heff_tr(heff_call(v_f_24291, 1, (V[]){v_c_24293}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24292, v_t_24294});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam27(V self, V *args) {
  V v_u_24303 = args[0];
  V v_c_24304 = args[1];
  V v_f_24302 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24305 = heff_tr(heff_call(v_f_24302, 1, (V[]){v_c_24304}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24303, v_t_24305});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam28(V self, V *args) {
  V v_u_24334 = args[0];
  V v_c_24335 = args[1];
  V v_f_24333 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24336 = heff_tr(heff_call(v_f_24333, 1, (V[]){v_c_24335}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24334, v_t_24336});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam29(V self, V *args) {
  V v_u_24344 = args[0];
  V v_c_24345 = args[1];
  V v_f_24343 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24346 = heff_tr(heff_call(v_f_24343, 1, (V[]){v_c_24345}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24344, v_t_24346});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam30(V self, V *args) {
  V v_u_24357 = args[0];
  V v_c_24358 = args[1];
  V v_f_24356 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24359 = heff_tr(heff_call(v_f_24356, 1, (V[]){v_c_24358}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_24357, v_t_24359});
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s42976669x698242400_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        heff_take_n(v_a_244, 3ULL, 2);
        V v_a_248;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_248 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_a_248 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_247)));
        }
        HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2eaccList_24s42976669x698242400_24cpr(v_a_248, v_xs_243));
        {
          V v_field_2410 = v_t_249.f[0];
          V v_field_2411 = v_t_249.f[1];
          V v_x_2412 = v_field_2410;
          V v_y_2413 = v_field_2411;
          V v_t_2414 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_SetPath, 2, (V[]){v_a_246, v_a_247}), v_a_245});
          return ((HeffT2){{v_x_2412, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2414, v_y_2413})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s122821685x1786755984_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        heff_take_n(v_a_244, 3ULL, 2);
        V v_a_248;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_248 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_a_248 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_247)));
        }
        HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2eaccList_24s122821685x1786755984_24cpr(v_a_248, v_xs_243));
        {
          V v_field_2410 = v_t_249.f[0];
          V v_field_2411 = v_t_249.f[1];
          V v_x_2412 = v_field_2410;
          V v_y_2413 = v_field_2411;
          V v_t_2414 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_a_246, v_a_247}), v_a_245});
          return ((HeffT2){{v_x_2412, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2414, v_y_2413})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackMatch_str0, 6, "MkPair");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackMatch_str1, 6, "MkPair");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackMatch_str2, 6, "MkPair");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackMatch_str3, 6, "MkPair");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackMatch_str4, 6, "MkPair");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackMatch_str5, 6, "MkPair");
Clo g_heff_2esyntax_2epresyntax_2egiveBackMatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2egiveBackMatch_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2egiveBackMatch(V v_sp_240, V v_r_241, V v_x3_242, V v_body_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_sp_240, 2);
    heff_drop(v_r_241);
    return v_body_243;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_x32_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x32_245)) {
    case TAG_Nil: {
      V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_244}), heff_dup(v_sp_240)});
      V v_t_247 = (g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240(heff_dup(v_sp_240), v_x32_245));
      V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_t_247}), heff_dup(v_sp_240)});
      V v_t_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
      V v_ps_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_249});
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egiveBackMatch_str0)}), heff_dup(v_sp_240)});
      V v_x1_2412 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2411, v_ps_2410));
      V v_t_2415;
      switch (heff_tag_of(v_x1_2412)) {
      case TAG_At: {
        V v_s_2414 = heff_field(v_x1_2412, 1);
        heff_take_n(v_x1_2412, 2ULL, 2);
        v_t_2415 = v_s_2414;
        break;
      }
      default: heff_nomatch(v_x1_2412);
      }
      V v_t_2416 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2415, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2417 = (g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240(heff_dup(v_sp_240), v_x32_245));
      V v_e_2418 = (g_heff_2esyntax_2epresyntax_2egiveBackMatch(heff_dup(v_sp_240), v_t_2417, v_x32_245, v_body_243));
      V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egiveBackMatch_str1), heff_dup(v_sp_240), v_ps_2410}), heff_dup(v_t_2416)});
      V v_t_2422;
      switch (heff_tag_of(v_e_2418)) {
      case TAG_At: {
        V v_s_2421 = heff_dup(heff_field(v_e_2418, 1));
        v_t_2422 = v_s_2421;
        break;
      }
      default: heff_nomatch(v_e_2418);
      }
      V v_t_2423 = ({ V rv_1 = heff_get_n(v_t_2422, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2416, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2419, v_e_2418}), v_t_2423});
      V v_alts_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
      V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_r_241}), heff_dup(v_sp_240)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2426, v_alts_2425}), v_sp_240});
    }
    case TAG_Cons: {
      V v_x322_2428 = heff_dup(heff_field(v_x32_245, 1));
      switch (heff_tag_of(v_x322_2428)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_x32_245)) {
        case TAG_Cons: {
          V v_y_2429 = heff_field(v_x32_245, 0);
          V v_ru_24x32_245_24Cons = heff_take_reuse_n(v_x32_245, 1ULL, 2);
          V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egiveBackMatch_str2)}), heff_dup(v_sp_240)});
          V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_x_244)}), heff_dup(v_sp_240)});
          V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_y_2429)}), heff_dup(v_sp_240)});
          V v_t_2434 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
          V v_x1_2435 = ({ V a_0 = v_t_2431; V b_1 = heff_tag_at_n(v_ru_24x32_245_24Cons, TAG_Cons, 2, (V[]){v_t_2432, v_t_2434}); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
          V v_t_2438;
          switch (heff_tag_of(v_x1_2435)) {
          case TAG_At: {
            V v_s_2437 = heff_field(v_x1_2435, 1);
            heff_take_n(v_x1_2435, 2ULL, 2);
            v_t_2438 = v_s_2437;
            break;
          }
          default: heff_nomatch(v_x1_2435);
          }
          V v_t_2439 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2438, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_2440 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_244}), heff_dup(v_sp_240)});
          V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_y_2429}), heff_dup(v_sp_240)});
          V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, NTAG(TAG_Nil)});
          V v_t_2443 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egiveBackMatch_str3), heff_dup(v_sp_240), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, v_t_2442})});
          V v_p_2444 = heff_tag_n(TAG_At, 2, (V[]){v_t_2443, v_t_2439});
          V v_t_2447;
          switch (heff_tag_of(v_p_2444)) {
          case TAG_At: {
            V v_s_2446 = heff_dup(heff_field(v_p_2444, 1));
            v_t_2447 = v_s_2446;
            break;
          }
          default: heff_nomatch(v_p_2444);
          }
          V v_t_2450;
          switch (heff_tag_of(v_body_243)) {
          case TAG_At: {
            V v_s_2449 = heff_dup(heff_field(v_body_243, 1));
            v_t_2450 = v_s_2449;
            break;
          }
          default: heff_nomatch(v_body_243);
          }
          V v_t_2451 = ({ V rv_1 = heff_get_n(v_t_2450, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2447, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2452 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2444, v_body_243}), v_t_2451});
          V v_alts_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
          V v_t_2454 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_r_241}), heff_dup(v_sp_240)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2454, v_alts_2453}), v_sp_240});
        }
        default: return heff_nomatch(v_x32_245);
        }
      }
      case TAG_Cons: {
        V v_ru_24x322_2428_24Cons = heff_take_reuse_n(v_x322_2428, 0ULL, 2);
        V v_t_2457 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_244}), heff_dup(v_sp_240)});
        V v_t_2458 = (g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241(heff_dup(v_sp_240), v_x32_245));
        V v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_t_2458}), heff_dup(v_sp_240)});
        V v_t_2460 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2459, NTAG(TAG_Nil)});
        V v_ps_2461 = heff_tag_at_n(v_ru_24x322_2428_24Cons, TAG_Cons, 2, (V[]){v_t_2457, v_t_2460});
        V v_t_2462 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egiveBackMatch_str4)}), heff_dup(v_sp_240)});
        V v_x1_2463 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2462, v_ps_2461));
        V v_t_2466;
        switch (heff_tag_of(v_x1_2463)) {
        case TAG_At: {
          V v_s_2465 = heff_field(v_x1_2463, 1);
          heff_take_n(v_x1_2463, 2ULL, 2);
          v_t_2466 = v_s_2465;
          break;
        }
        default: heff_nomatch(v_x1_2463);
        }
        V v_t_2467 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2466, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_t_2468 = (g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241(heff_dup(v_sp_240), v_x32_245));
        V v_e_2469 = (g_heff_2esyntax_2epresyntax_2egiveBackMatch(heff_dup(v_sp_240), v_t_2468, v_x32_245, v_body_243));
        V v_t_2470 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egiveBackMatch_str5), heff_dup(v_sp_240), v_ps_2461}), heff_dup(v_t_2467)});
        V v_t_2473;
        switch (heff_tag_of(v_e_2469)) {
        case TAG_At: {
          V v_s_2472 = heff_dup(heff_field(v_e_2469, 1));
          v_t_2473 = v_s_2472;
          break;
        }
        default: heff_nomatch(v_e_2469);
        }
        V v_t_2474 = ({ V rv_1 = heff_get_n(v_t_2473, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2467, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2470, v_e_2469}), v_t_2474});
        V v_alts_2476 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2475, NTAG(TAG_Nil)});
        V v_t_2477 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_r_241}), heff_dup(v_sp_240)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2477, v_alts_2476}), v_sp_240});
      }
      default: return heff_nomatch(v_x322_2428);
      }
    }
    default: return heff_nomatch(v_x32_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2egiveBackMatch(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str2, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str3, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str5, 85, "what a `catch` arm hears is its argument: `catch x -> ...`, or `catch (x : T) -> ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str6, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str7, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str8, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str9, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str10, 1, "`");
V g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr(V v_cx_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkCatchArm: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24MkCatchArm = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_LamName: {
      V v_t_2413;
      switch (heff_tag_of(v_x21_242)) {
      case TAG_LamName: {
        V v_x_246 = heff_dup(heff_field(v_x21_242, 0));
        if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str0), 2)) {
          heff_drop_cell(v_ru_24x2_241_24MkCatchArm, 2);
          heff_drop(v_x_246);
          v_t_2413 = NTAG(TAG_Nil);
        } else {
          v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_x_246, NTAG(TAG_Nil)});
        }
        break;
      }
      case TAG_LamImplicit: {
        V v_x_248 = heff_dup(heff_field(v_x21_242, 0));
        v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_x_248, NTAG(TAG_Nil)});
        break;
      }
      case TAG_LamAnn: {
        V v_x_2410 = heff_dup(heff_field(v_x21_242, 0));
        if (heff_strEq_c_lent(v_x_2410, ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str1), 2)) {
          heff_drop_cell(v_ru_24x2_241_24MkCatchArm, 2);
          heff_drop(v_x_2410);
          v_t_2413 = NTAG(TAG_Nil);
        } else {
          v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_x_2410, NTAG(TAG_Nil)});
        }
        break;
      }
      default: heff_nomatch(v_x21_242);
      }
      HeffT2 v_t_2415 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_lam0, 1, 1, (V[]){v_cx_240}), v_t_2413));
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_x_2418 = v_field_2417;
          V v_t_2419 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str2), heff_strAppend(heff_dup(v_x_2418), ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str3)));
          V v_t_2420 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str4), heff_strAppend(v_x_2418, v_t_2419));
          V v_t_2428;
          switch (heff_tag_of(v_x21_242)) {
          case TAG_LamName: {
            V v_sp_2422 = heff_field(v_x21_242, 1);
            heff_take_n(v_x21_242, 2ULL, 2);
            v_t_2428 = v_sp_2422;
            break;
          }
          case TAG_LamImplicit: {
            V v_sp_2424 = heff_field(v_x21_242, 1);
            heff_take_n(v_x21_242, 2ULL, 2);
            v_t_2428 = v_sp_2424;
            break;
          }
          case TAG_LamAnn: {
            V v_sp_2426 = heff_field(v_x21_242, 1);
            heff_take_n(v_x21_242, 2ULL, 3);
            v_t_2428 = v_sp_2426;
            break;
          }
          default: heff_nomatch(v_x21_242);
          }
          V v_f_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2420}), v_t_2428});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2429}});
        } else {
          heff_drop_tag(v_x21_242, 2);
          heff_drop(v_field_2417);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    case TAG_LamImplicit: {
      V v_xsp_2431 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_rec(v_cx_240, 6);
      V v_t_2432 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str5)}), v_xsp_2431});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2432}});
    }
    case TAG_LamAnn: {
      V v_t_2443;
      switch (heff_tag_of(v_x21_242)) {
      case TAG_LamName: {
        V v_x_2436 = heff_dup(heff_field(v_x21_242, 0));
        if (heff_strEq_c_lent(v_x_2436, ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str6), 2)) {
          heff_drop_cell(v_ru_24x2_241_24MkCatchArm, 2);
          heff_drop(v_x_2436);
          v_t_2443 = NTAG(TAG_Nil);
        } else {
          v_t_2443 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_x_2436, NTAG(TAG_Nil)});
        }
        break;
      }
      case TAG_LamImplicit: {
        V v_x_2438 = heff_dup(heff_field(v_x21_242, 0));
        v_t_2443 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_x_2438, NTAG(TAG_Nil)});
        break;
      }
      case TAG_LamAnn: {
        V v_x_2440 = heff_dup(heff_field(v_x21_242, 0));
        if (heff_strEq_c_lent(v_x_2440, ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str7), 2)) {
          heff_drop_cell(v_ru_24x2_241_24MkCatchArm, 2);
          heff_drop(v_x_2440);
          v_t_2443 = NTAG(TAG_Nil);
        } else {
          v_t_2443 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_x_2440, NTAG(TAG_Nil)});
        }
        break;
      }
      default: heff_nomatch(v_x21_242);
      }
      HeffT2 v_t_2445 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_lam1, 1, 1, (V[]){v_cx_240}), v_t_2443));
      {
        V v_field_2447 = v_t_2445.f[1];
        int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
        if ((v_tag_2446 == ((int64_t)0ULL))) {
          V v_x_2448 = v_field_2447;
          V v_t_2449 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str8), heff_strAppend(heff_dup(v_x_2448), ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str9)));
          V v_t_2450 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str10), heff_strAppend(v_x_2448, v_t_2449));
          V v_t_2458;
          switch (heff_tag_of(v_x21_242)) {
          case TAG_LamName: {
            V v_sp_2452 = heff_field(v_x21_242, 1);
            heff_take_n(v_x21_242, 2ULL, 2);
            v_t_2458 = v_sp_2452;
            break;
          }
          case TAG_LamImplicit: {
            V v_sp_2454 = heff_field(v_x21_242, 1);
            heff_take_n(v_x21_242, 2ULL, 2);
            v_t_2458 = v_sp_2454;
            break;
          }
          case TAG_LamAnn: {
            V v_sp_2456 = heff_field(v_x21_242, 1);
            heff_take_n(v_x21_242, 2ULL, 3);
            v_t_2458 = v_sp_2456;
            break;
          }
          default: heff_nomatch(v_x21_242);
          }
          V v_f_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2450}), v_t_2458});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2459}});
        } else {
          heff_drop_tag(v_x21_242, 3);
          heff_drop(v_field_2447);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_cx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2414; V b_1 = heff_get_n(v_cx_240, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_2414); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_lam1(V self, V *args) {
  V v_x_2444 = args[0];
  V v_cx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2444; V b_1 = heff_get_n(v_cx_240, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_2444); heff_drop(b_1); r_; });
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithT_str0, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithT_str1, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithT_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithT_str3, 69, "nothing after this `with` runs: its statements do not reach their end");
Clo g_heff_2esyntax_2epresyntax_2ewithT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewithT_entry, 9, 0};

V g_heff_2esyntax_2epresyntax_2ewithT(V v_t_240, V v_cx_241, V v_sp_242, V v_w_243, V v_x_244, V v_xsp_245, V v_body_246, V v_rest_247, V v_end_248) {
top: ;
  V v_t_249 = (g_list_2eany_24s2077819594x1842428557(v_x_244, heff_rfield(v_cx_241, 1)));
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_240);
    heff_drop_rec(v_cx_241, 6);
    heff_drop(v_sp_242);
    heff_drop(v_w_243);
    heff_drop(v_body_246);
    heff_drop(v_rest_247);
    heff_drop(v_end_248);
    heff_drop(v_t_249);
    V v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewithT_str0), heff_strAppend(heff_dup(v_x_244), ((V)&g_heff_2esyntax_2epresyntax_2ewithT_str1)));
    V v_t_2411 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewithT_str2), heff_strAppend(v_x_244, v_t_2410));
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2411}), v_xsp_245});
  } else {
    heff_drop(v_t_249);
    V v_scope_2412 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ewithScopeOf_clo), 7, (V[]){heff_dup(v_t_240), heff_dup(v_cx_241), heff_dup(v_sp_242), v_w_243, v_x_244, v_xsp_245, heff_dup(v_body_246)}));
    V v_x1_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_body_246));
    V v_falls_2430;
    switch (heff_tag_of(v_x1_2413)) {
    case TAG_Nil: {
      v_falls_2430 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x1_2413, 0);
      heff_take_n(v_x1_2413, 1ULL, 2);
      switch (heff_tag_of(v_x_2414)) {
      case TAG_At: {
        V v_it11_2416 = heff_field(v_x_2414, 0);
        heff_take_n(v_x_2414, 1ULL, 2);
        switch (heff_tag_of(v_it11_2416)) {
        case TAG_StmtBind: {
          heff_take_n(v_it11_2416, 0ULL, 3);
          v_falls_2430 = NTAG(TAG_True);
          break;
        }
        case TAG_StmtLet: {
          heff_take_n(v_it11_2416, 0ULL, 2);
          v_falls_2430 = NTAG(TAG_True);
          break;
        }
        case TAG_StmtExpr: {
          V v_e_2423 = heff_field(v_it11_2416, 0);
          heff_take_n(v_it11_2416, 1ULL, 1);
          v_falls_2430 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_e_2423));
          break;
        }
        case TAG_StmtLetMut: {
          heff_take_n(v_it11_2416, 0ULL, 3);
          v_falls_2430 = NTAG(TAG_True);
          break;
        }
        case TAG_StmtLetElse: {
          heff_take_n(v_it11_2416, 0ULL, 3);
          v_falls_2430 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_it11_2416);
        }
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      break;
    }
    default: heff_nomatch(v_x1_2413);
    }
    switch (heff_tag_of(v_rest_247)) {
    case TAG_Nil: {
      heff_drop(v_t_240);
      heff_drop_rec(v_cx_241, 6);
      heff_drop(v_sp_242);
      heff_drop(v_falls_2430);
      return heff_tail(v_scope_2412, 1, (V[]){v_end_248});
    }
    case TAG_Cons: {
      V v_s_2431 = heff_field(v_rest_247, 0);
      V v_rest_2432 = heff_field(v_rest_247, 1);
      V v_ru_24rest_247_24Cons = heff_take_reuse_n(v_rest_247, 3ULL, 2);
      if ((heff_dup(v_falls_2430) == NTAG(TAG_True))) {
        heff_drop(v_falls_2430);
        return (g_heff_2esyntax_2epresyntax_2escopeJoin(v_t_240, v_cx_241, v_sp_242, v_scope_2412, heff_tag_at_n(v_ru_24rest_247_24Cons, TAG_Cons, 2, (V[]){v_s_2431, v_rest_2432}), v_end_248));
      } else {
        heff_drop(v_t_240);
        heff_drop_rec(v_cx_241, 6);
        heff_drop(v_sp_242);
        heff_drop(v_end_248);
        heff_drop(v_scope_2412);
        heff_drop(v_falls_2430);
        heff_drop(v_rest_2432);
        heff_drop_cell(v_ru_24rest_247_24Cons, 2);
        V v_t_2435;
        switch (heff_tag_of(v_s_2431)) {
        case TAG_At: {
          V v_s_2434 = heff_field(v_s_2431, 1);
          heff_take_n(v_s_2431, 2ULL, 2);
          v_t_2435 = v_s_2434;
          break;
        }
        default: heff_nomatch(v_s_2431);
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithT_str3)}), v_t_2435});
      }
    }
    default: return heff_nomatch(v_rest_247);
    }
  }
}
V g_heff_2esyntax_2epresyntax_2ewithT_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewithT(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_str0, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_str1, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_str2, 4, "last");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_str3, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_str4, 4, "last");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_str5, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_str6, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_str7, 36, "a `do` block ends with an expression");
Clo g_heff_2esyntax_2epresyntax_2elastT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elastT_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2elastT(V v_t_240, V v_cx_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_sp_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_StmtBind: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_t_240);
      heff_drop_rec(v_cx_241, 6);
      return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_str0)}), v_sp_244});
    }
    case TAG_StmtLet: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_t_240);
      heff_drop_rec(v_cx_241, 6);
      return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_str1)}), v_sp_244});
    }
    case TAG_StmtExpr: {
      V v_e_2410 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24StmtExpr = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      V v_t_2411 = (g_heff_2esyntax_2epresyntax_2eisControl(v_e_2410));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop_rec(v_sp_244, 2);
        heff_drop_cell(v_ru_24x3_242_24At, 2);
        heff_drop_cell(v_ru_24x31_243_24StmtExpr, 1);
        heff_drop(v_t_2411);
        return (g_heff_2esyntax_2epresyntax_2econtrolT(v_t_240, v_cx_241, v_e_2410, NTAG(TAG_Nil), NTAG(TAG_EndValue)));
      } else {
        heff_drop(v_t_240);
        heff_drop(v_t_2411);
        if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_cx_241, 4)))) {
          V v_t_2412 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
          HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2412}), NTAG(TAG_Nil), v_e_2410));
          {
            V v_field_2414 = v_t_2413.f[0];
            V v_field_2415 = v_t_2413.f[1];
            V v_x_2416 = v_field_2414;
            V v_y_2417 = v_field_2415;
            V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 1, 3);
            V v_t_2419 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2418}), heff_dup(v_sp_244)});
            V v_t_2420 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
            V v_t_2421 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_str2), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_str3), v_t_2420));
            V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24StmtExpr, TAG_EVar, 1, (V[]){v_t_2421}), heff_dup(v_sp_244)});
            V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
            V v_t_2424 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2419, v_t_2423));
            V v_rest_2425 = (g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_241), heff_dup(v_sp_244), heff_dup(heff_rfield(v_cx_241, 4)), v_t_2424));
            V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 0, 3);
            V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2426}), heff_dup(heff_rfield(v_cx_241, 3))});
            V v_t_2428 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
            V v_t_2429 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_str4), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_str5), v_t_2428));
            V v_t_2430 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_t_2429, heff_dup(v_sp_244)}), heff_dup(v_rest_2425)});
            V v_t_2433;
            switch (heff_tag_of(v_rest_2425)) {
            case TAG_At: {
              V v_s_2432 = heff_field(v_rest_2425, 1);
              heff_take_n(v_rest_2425, 2ULL, 2);
              v_t_2433 = v_s_2432;
              break;
            }
            default: heff_nomatch(v_rest_2425);
            }
            V v_t_2434 = ({ V rv_1 = heff_get_n(v_t_2433, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_244, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2430, v_t_2434}), NTAG(TAG_Nil)});
            V v_t_2436 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2427, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2417, v_t_2435})));
            return ({ V a_0 = v_cx_241; V a_1 = v_x_2416; V a_2 = v_t_2436; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2416); r_; });
          }
        } else {
          heff_drop_rec(v_sp_244, 2);
          heff_drop_cell(v_ru_24x3_242_24At, 2);
          heff_drop_cell(v_ru_24x31_243_24StmtExpr, 1);
          V v_t_2437 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
          HeffT2 v_t_2438 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2437}), NTAG(TAG_Nil), v_e_2410));
          {
            V v_field_2439 = v_t_2438.f[0];
            V v_field_2440 = v_t_2438.f[1];
            V v_x_2441 = v_field_2439;
            V v_y_2442 = v_field_2440;
            return ({ V a_0 = v_cx_241; V a_1 = v_x_2441; V a_2 = v_y_2442; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2441); r_; });
          }
        }
      }
    }
    case TAG_StmtLetMut: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_t_240);
      heff_drop_rec(v_cx_241, 6);
      return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_str6)}), v_sp_244});
    }
    case TAG_StmtLetElse: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_t_240);
      heff_drop_rec(v_cx_241, 6);
      return heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_str7)}), v_sp_244});
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2epresyntax_2elastT_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2elastT(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2epresyntax_2evariantOf_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2evariantOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2evariantOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2evariantOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_TagVariant: {
      V v_t_244 = heff_field(v_x21_242, 0);
      V v_tsp_245 = heff_field(v_x21_242, 1);
      V v_args_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2evariantOf_lam0, 1, 1, (V[]){v_r_240}), v_args_246));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TagVariant, 3, (V[]){v_t_244, v_tsp_245, v_t_2418}), v_sp_243});
    }
    case TAG_BadVariant: {
      V v_e_2419 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24BadVariant = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2419}));
      V v_t_2430;
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_IsInferable: {
        V v_i_2421 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2424;
        switch (heff_tag_of(v_i_2421)) {
        case TAG_At: {
          V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_i_2421);
        }
        v_t_2430 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2421}), v_t_2424});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2425 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2428;
        switch (heff_tag_of(v_c_2425)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_c_2425, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_c_2425);
        }
        v_t_2430 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2425}), v_t_2428});
        break;
      }
      case TAG_IsType: {
        V v_t_2429 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2430 = v_t_2429;
        break;
      }
      default: heff_nomatch(v_x1_2420);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2430}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2evariantOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2evariantOf(a[0], a[1]);
}
V g_heff_2esyntax_2epresyntax_2evariantOf_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_IsInferable: {
    V v_i_249 = heff_field(v_x1_248, 0);
    V v_ru_24x1_248_24IsInferable = heff_take_reuse_n(v_x1_248, 1ULL, 1);
    V v_t_2412;
    switch (heff_tag_of(v_i_249)) {
    case TAG_At: {
      V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
      v_t_2412 = v_s_2411;
      break;
    }
    default: heff_nomatch(v_i_249);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_248_24IsInferable, TAG_TInf, 1, (V[]){v_i_249}), v_t_2412});
  }
  case TAG_IsCheckable: {
    V v_c_2413 = heff_field(v_x1_248, 0);
    V v_ru_24x1_248_24IsCheckable = heff_take_reuse_n(v_x1_248, 1ULL, 1);
    V v_t_2416;
    switch (heff_tag_of(v_c_2413)) {
    case TAG_At: {
      V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
      v_t_2416 = v_s_2415;
      break;
    }
    default: heff_nomatch(v_c_2413);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_248_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
  }
  case TAG_IsType: {
    V v_t_2417 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    return v_t_2417;
  }
  default: return heff_nomatch(v_x1_248);
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str0, 9, "bitsOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str1, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str2, 17, "prelude.bitsSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str3, 17, "prelude.bitsSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str4, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str5, 11, "bitsOfBytes");
Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026(V v_lit_240, V v_r_241, V v_seg_242) {
top: ;
  switch (heff_tag_of(v_seg_242)) {
  case TAG_At: {
    V v_seg1_243 = heff_dup(heff_field(v_seg_242, 0));
    V v_sp_244 = heff_dup(heff_field(v_seg_242, 1));
    switch (heff_tag_of(v_seg1_243)) {
    case TAG_MkSegment: {
      V v_v_245 = heff_field(v_seg1_243, 0);
      V v_seg12_246 = heff_field(v_seg1_243, 1);
      V v_size_247 = heff_field(v_seg1_243, 2);
      V v_little_248 = heff_field(v_seg1_243, 3);
      V v_signed_249 = heff_field(v_seg1_243, 4);
      heff_take_n(v_seg1_243, 31ULL, 5);
      switch (heff_tag_of(v_seg12_246)) {
      case TAG_SegmentInteger: {
        heff_drop(v_lit_240);
        heff_drop_tag(v_seg_242, 2);
        V v_t_2410 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_247, MK_INT(8LL), heff_dup(v_sp_244)));
        int64_t v_t_2411;
        if ((heff_dup(v_little_248) == NTAG(TAG_True))) {
          heff_drop(v_little_248);
          v_t_2411 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_248);
          v_t_2411 = ((int64_t)0ULL);
        }
        int64_t v_t_2412;
        if ((heff_dup(v_signed_249) == NTAG(TAG_True))) {
          heff_drop(v_signed_249);
          v_t_2412 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_249);
          v_t_2412 = ((int64_t)0ULL);
        }
        V v_t_2413 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_2411 + v_t_2412))});
        V v_t_2414 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_244)})});
        V v_x1_2415 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){v_v_245}));
        V v_t_2425;
        switch (heff_tag_of(v_x1_2415)) {
        case TAG_IsInferable: {
          V v_i_2416 = heff_field(v_x1_2415, 0);
          V v_ru_24x1_2415_24IsInferable = heff_take_reuse_n(v_x1_2415, 1ULL, 1);
          V v_t_2419;
          switch (heff_tag_of(v_i_2416)) {
          case TAG_At: {
            V v_s_2418 = heff_dup(heff_field(v_i_2416, 1));
            v_t_2419 = v_s_2418;
            break;
          }
          default: heff_nomatch(v_i_2416);
          }
          v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2415_24IsInferable, TAG_CInf, 1, (V[]){v_i_2416}), v_t_2419});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2420 = heff_field(v_x1_2415, 0);
          heff_take_n(v_x1_2415, 1ULL, 1);
          v_t_2425 = v_c_2420;
          break;
        }
        case TAG_IsType: {
          V v_t_2421 = heff_field(v_x1_2415, 0);
          V v_ru_24x1_2415_24IsType = heff_take_reuse_n(v_x1_2415, 1ULL, 1);
          V v_t_2424;
          switch (heff_tag_of(v_t_2421)) {
          case TAG_At: {
            V v_s_2423 = heff_dup(heff_field(v_t_2421, 1));
            v_t_2424 = v_s_2423;
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
          v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2415_24IsType, TAG_CType, 1, (V[]){v_t_2421}), v_t_2424});
          break;
        }
        default: heff_nomatch(v_x1_2415);
        }
        V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
        V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, heff_dup(v_sp_244)}), v_t_2426});
        V v_args_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2427});
        V v_t_2429 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_244), v_args_2428));
        V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str0)}), heff_dup(v_sp_244)});
        V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2430, v_t_2429}), heff_dup(v_sp_244)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2431}), v_sp_244});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_lit_240);
        heff_drop(v_sp_244);
        heff_drop(v_v_245);
        heff_drop(v_size_247);
        heff_drop(v_little_248);
        heff_drop(v_signed_249);
        V v_t_2432 = (g_heff_2esyntax_2epresyntax_2ebytesPart(v_r_241, heff_dup(v_seg_242)));
        V v_args_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
        V v_sp_2436;
        switch (heff_tag_of(v_seg_242)) {
        case TAG_At: {
          V v_s_2435 = heff_field(v_seg_242, 1);
          heff_take_n(v_seg_242, 2ULL, 2);
          v_sp_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_seg_242);
        }
        V v_t_2437 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2436), v_args_2433));
        V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str1)}), heff_dup(v_sp_2436)});
        V v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2438, v_t_2437}), heff_dup(v_sp_2436)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2439}), v_sp_2436});
      }
      case TAG_SegmentBits: {
        heff_drop_tag(v_seg_242, 2);
        heff_drop(v_little_248);
        heff_drop(v_signed_249);
        switch (heff_tag_of(v_size_247)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_244);
          switch (heff_tag_of(v_v_245)) {
          case TAG_At: {
            V v_e_2440 = heff_field(v_v_245, 0);
            V v_sp_2441 = heff_field(v_v_245, 1);
            V v_ru_24v_245_24At = heff_take_reuse_n(v_v_245, 3ULL, 2);
            HeffT2 v_t_2442 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(heff_dup(v_e_2440)));
            {
              V v_field_2444 = v_t_2442.f[1];
              int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
              if ((v_tag_2443 == ((int64_t)0ULL))) {
                heff_drop_rec(v_r_241, 2);
                heff_drop(v_e_2440);
                V v_segs_2445 = v_field_2444;
                HeffT1 v_t_2446 = ({ V a_0 = v_lit_240; V b_1 = NTAG(TAG_True); V a_2 = v_segs_2445; V a_3 = v_sp_2441; HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
                {
                  V v_field_2447 = v_t_2446.f[0];
                  V v_a_2448 = v_field_2447;
                  V v_t_2451;
                  switch (heff_tag_of(v_a_2448)) {
                  case TAG_At: {
                    V v_a_2450 = heff_dup(heff_field(v_a_2448, 1));
                    v_t_2451 = v_a_2450;
                    break;
                  }
                  default: heff_nomatch(v_a_2448);
                  }
                  return heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_2448}), v_t_2451});
                }
              } else {
                heff_drop(v_lit_240);
                heff_drop(v_field_2444);
                V v_x1_2452 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_e_2440, v_sp_2441})}));
                switch (heff_tag_of(v_x1_2452)) {
                case TAG_IsInferable: {
                  V v_i_2453 = heff_field(v_x1_2452, 0);
                  heff_take_n(v_x1_2452, 1ULL, 1);
                  V v_t_2456;
                  switch (heff_tag_of(v_i_2453)) {
                  case TAG_At: {
                    V v_s_2455 = heff_dup(heff_field(v_i_2453, 1));
                    v_t_2456 = v_s_2455;
                    break;
                  }
                  default: heff_nomatch(v_i_2453);
                  }
                  return heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2453}), v_t_2456});
                }
                case TAG_IsCheckable: {
                  V v_c_2457 = heff_field(v_x1_2452, 0);
                  heff_take_n(v_x1_2452, 1ULL, 1);
                  heff_drop_cell(v_ru_24v_245_24At, 2);
                  return v_c_2457;
                }
                case TAG_IsType: {
                  V v_t_2458 = heff_field(v_x1_2452, 0);
                  heff_take_n(v_x1_2452, 1ULL, 1);
                  V v_t_2461;
                  switch (heff_tag_of(v_t_2458)) {
                  case TAG_At: {
                    V v_s_2460 = heff_dup(heff_field(v_t_2458, 1));
                    v_t_2461 = v_s_2460;
                    break;
                  }
                  default: heff_nomatch(v_t_2458);
                  }
                  return heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2458}), v_t_2461});
                }
                default: return heff_nomatch(v_x1_2452);
                }
              }
            }
          }
          default: return heff_nomatch(v_v_245);
          }
        }
        case TAG_SizeNumber: {
          V v_t_2463 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_247, MK_INT(0LL), heff_dup(v_sp_244)));
          V v_t_2486;
          switch (heff_tag_of(v_v_245)) {
          case TAG_At: {
            V v_e_2464 = heff_field(v_v_245, 0);
            V v_sp_2465 = heff_field(v_v_245, 1);
            V v_ru_24v_245_24At = heff_take_reuse_n(v_v_245, 3ULL, 2);
            HeffT2 v_t_2466 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(heff_dup(v_e_2464)));
            {
              V v_field_2468 = v_t_2466.f[1];
              int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
              if ((v_tag_2467 == ((int64_t)0ULL))) {
                heff_drop_rec(v_r_241, 2);
                heff_drop(v_e_2464);
                V v_segs_2469 = v_field_2468;
                HeffT1 v_t_2470 = ({ V a_0 = v_lit_240; V b_1 = NTAG(TAG_True); V a_2 = v_segs_2469; V a_3 = v_sp_2465; HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
                {
                  V v_field_2471 = v_t_2470.f[0];
                  V v_a_2472 = v_field_2471;
                  V v_t_2475;
                  switch (heff_tag_of(v_a_2472)) {
                  case TAG_At: {
                    V v_a_2474 = heff_dup(heff_field(v_a_2472, 1));
                    v_t_2475 = v_a_2474;
                    break;
                  }
                  default: heff_nomatch(v_a_2472);
                  }
                  v_t_2486 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_2472}), v_t_2475});
                }
              } else {
                heff_drop(v_lit_240);
                heff_drop(v_field_2468);
                V v_x1_2476 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_e_2464, v_sp_2465})}));
                switch (heff_tag_of(v_x1_2476)) {
                case TAG_IsInferable: {
                  V v_i_2477 = heff_field(v_x1_2476, 0);
                  heff_take_n(v_x1_2476, 1ULL, 1);
                  V v_t_2480;
                  switch (heff_tag_of(v_i_2477)) {
                  case TAG_At: {
                    V v_s_2479 = heff_dup(heff_field(v_i_2477, 1));
                    v_t_2480 = v_s_2479;
                    break;
                  }
                  default: heff_nomatch(v_i_2477);
                  }
                  v_t_2486 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2477}), v_t_2480});
                  break;
                }
                case TAG_IsCheckable: {
                  V v_c_2481 = heff_field(v_x1_2476, 0);
                  heff_take_n(v_x1_2476, 1ULL, 1);
                  heff_drop_cell(v_ru_24v_245_24At, 2);
                  v_t_2486 = v_c_2481;
                  break;
                }
                case TAG_IsType: {
                  V v_t_2482 = heff_field(v_x1_2476, 0);
                  heff_take_n(v_x1_2476, 1ULL, 1);
                  V v_t_2485;
                  switch (heff_tag_of(v_t_2482)) {
                  case TAG_At: {
                    V v_s_2484 = heff_dup(heff_field(v_t_2482, 1));
                    v_t_2485 = v_s_2484;
                    break;
                  }
                  default: heff_nomatch(v_t_2482);
                  }
                  v_t_2486 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2482}), v_t_2485});
                  break;
                }
                default: heff_nomatch(v_x1_2476);
                }
              }
            }
            break;
          }
          default: heff_nomatch(v_v_245);
          }
          V v_t_2487 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2486, NTAG(TAG_Nil)});
          V v_args_2488 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2463, v_t_2487});
          V v_t_2489 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_244), v_args_2488));
          V v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str2)}), heff_dup(v_sp_244)});
          V v_t_2491 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2490, v_t_2489}), heff_dup(v_sp_244)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2491}), v_sp_244});
        }
        case TAG_SizeName: {
          V v_t_2495 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_247, MK_INT(0LL), heff_dup(v_sp_244)));
          V v_t_24118;
          switch (heff_tag_of(v_v_245)) {
          case TAG_At: {
            V v_e_2496 = heff_field(v_v_245, 0);
            V v_sp_2497 = heff_field(v_v_245, 1);
            V v_ru_24v_245_24At = heff_take_reuse_n(v_v_245, 3ULL, 2);
            HeffT2 v_t_2498 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(heff_dup(v_e_2496)));
            {
              V v_field_24100 = v_t_2498.f[1];
              int64_t v_tag_2499 = ((int64_t)v_t_2498.f[0]);
              if ((v_tag_2499 == ((int64_t)0ULL))) {
                heff_drop_rec(v_r_241, 2);
                heff_drop(v_e_2496);
                V v_segs_24101 = v_field_24100;
                HeffT1 v_t_24102 = ({ V a_0 = v_lit_240; V b_1 = NTAG(TAG_True); V a_2 = v_segs_24101; V a_3 = v_sp_2497; HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
                {
                  V v_field_24103 = v_t_24102.f[0];
                  V v_a_24104 = v_field_24103;
                  V v_t_24107;
                  switch (heff_tag_of(v_a_24104)) {
                  case TAG_At: {
                    V v_a_24106 = heff_dup(heff_field(v_a_24104, 1));
                    v_t_24107 = v_a_24106;
                    break;
                  }
                  default: heff_nomatch(v_a_24104);
                  }
                  v_t_24118 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_24104}), v_t_24107});
                }
              } else {
                heff_drop(v_lit_240);
                heff_drop(v_field_24100);
                V v_x1_24108 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_e_2496, v_sp_2497})}));
                switch (heff_tag_of(v_x1_24108)) {
                case TAG_IsInferable: {
                  V v_i_24109 = heff_field(v_x1_24108, 0);
                  heff_take_n(v_x1_24108, 1ULL, 1);
                  V v_t_24112;
                  switch (heff_tag_of(v_i_24109)) {
                  case TAG_At: {
                    V v_s_24111 = heff_dup(heff_field(v_i_24109, 1));
                    v_t_24112 = v_s_24111;
                    break;
                  }
                  default: heff_nomatch(v_i_24109);
                  }
                  v_t_24118 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24109}), v_t_24112});
                  break;
                }
                case TAG_IsCheckable: {
                  V v_c_24113 = heff_field(v_x1_24108, 0);
                  heff_take_n(v_x1_24108, 1ULL, 1);
                  heff_drop_cell(v_ru_24v_245_24At, 2);
                  v_t_24118 = v_c_24113;
                  break;
                }
                case TAG_IsType: {
                  V v_t_24114 = heff_field(v_x1_24108, 0);
                  heff_take_n(v_x1_24108, 1ULL, 1);
                  V v_t_24117;
                  switch (heff_tag_of(v_t_24114)) {
                  case TAG_At: {
                    V v_s_24116 = heff_dup(heff_field(v_t_24114, 1));
                    v_t_24117 = v_s_24116;
                    break;
                  }
                  default: heff_nomatch(v_t_24114);
                  }
                  v_t_24118 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24114}), v_t_24117});
                  break;
                }
                default: heff_nomatch(v_x1_24108);
                }
              }
            }
            break;
          }
          default: heff_nomatch(v_v_245);
          }
          V v_t_24119 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24118, NTAG(TAG_Nil)});
          V v_args_24120 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2495, v_t_24119});
          V v_t_24121 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_244), v_args_24120));
          V v_t_24122 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str3)}), heff_dup(v_sp_244)});
          V v_t_24123 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24122, v_t_24121}), heff_dup(v_sp_244)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24123}), v_sp_244});
        }
        default: return heff_nomatch(v_size_247);
        }
      }
      case TAG_SegmentFloat: {
        heff_drop(v_lit_240);
        heff_drop(v_sp_244);
        heff_drop(v_v_245);
        heff_drop(v_size_247);
        heff_drop(v_little_248);
        heff_drop(v_signed_249);
        V v_t_24124 = (g_heff_2esyntax_2epresyntax_2ebytesPart(v_r_241, heff_dup(v_seg_242)));
        V v_args_24125 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24124, NTAG(TAG_Nil)});
        V v_sp_24128;
        switch (heff_tag_of(v_seg_242)) {
        case TAG_At: {
          V v_s_24127 = heff_field(v_seg_242, 1);
          heff_take_n(v_seg_242, 2ULL, 2);
          v_sp_24128 = v_s_24127;
          break;
        }
        default: heff_nomatch(v_seg_242);
        }
        V v_t_24129 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24128), v_args_24125));
        V v_t_24130 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str4)}), heff_dup(v_sp_24128)});
        V v_t_24131 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24130, v_t_24129}), heff_dup(v_sp_24128)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24131}), v_sp_24128});
      }
      case TAG_SegmentUtf: {
        V v_ru_24seg12_246_24SegmentUtf = heff_take_reuse_n(v_seg12_246, 0ULL, 1);
        heff_drop(v_lit_240);
        heff_drop(v_sp_244);
        heff_drop(v_v_245);
        heff_drop(v_size_247);
        heff_drop(v_little_248);
        heff_drop(v_signed_249);
        V v_t_24133 = (g_heff_2esyntax_2epresyntax_2ebytesPart(v_r_241, heff_dup(v_seg_242)));
        V v_args_24134 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24133, NTAG(TAG_Nil)});
        V v_sp_24137;
        switch (heff_tag_of(v_seg_242)) {
        case TAG_At: {
          V v_s_24136 = heff_field(v_seg_242, 1);
          heff_take_n(v_seg_242, 2ULL, 2);
          v_sp_24137 = v_s_24136;
          break;
        }
        default: heff_nomatch(v_seg_242);
        }
        V v_t_24138 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24137), v_args_24134));
        V v_t_24139 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24seg12_246_24SegmentUtf, TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str5)}), heff_dup(v_sp_24137)});
        V v_t_24140 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24139, v_t_24138}), heff_dup(v_sp_24137)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24140}), v_sp_24137});
      }
      default: return heff_nomatch(v_seg12_246);
      }
    }
    default: return heff_nomatch(v_seg1_243);
    }
  }
  default: return heff_nomatch(v_seg_242);
  }
}
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026(a[0], a[1], a[2]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2edoBlock_24s1455639597x676970604_24cpr(V v_sp_240, V v_stmts_241) {
top: ;
  V v_x1_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stmts_241)));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_sp_240);
    heff_drop(v_stmts_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    heff_take_n(v_x1_242, 1ULL, 2);
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_it11_245 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 2);
      switch (heff_tag_of(v_it11_245)) {
      case TAG_StmtBind: {
        heff_take_n(v_it11_245, 0ULL, 3);
        heff_drop(v_sp_240);
        heff_drop(v_stmts_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_StmtLet: {
        heff_take_n(v_it11_245, 0ULL, 2);
        heff_drop(v_sp_240);
        heff_drop(v_stmts_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_StmtExpr: {
        heff_take_n(v_it11_245, 0ULL, 1);
        V v_t_2413 = heff_rec_n(6, shape_names__muts__loop__sp__depth__giving, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2ecoNames_get()), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_sp_240, MK_INT(0LL), NTAG(TAG_Nothing)});
        V v_f_2414 = ({ V a_0 = v_t_2413; V a_1 = v_stmts_241; V a_2 = NTAG(TAG_EndValue); V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_stmts_241); r_; });
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
      }
      case TAG_StmtLetMut: {
        heff_take_n(v_it11_245, 0ULL, 3);
        heff_drop(v_sp_240);
        heff_drop(v_stmts_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_it11_245, 0ULL, 3);
        heff_drop(v_sp_240);
        heff_drop(v_stmts_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it11_245)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_242)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str0, 9, "bitsOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str1, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str2, 17, "prelude.bitsSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str3, 17, "prelude.bitsSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str4, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str5, 11, "bitsOfBytes");
Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076(V v_seg_240) {
top: ;
  switch (heff_tag_of(v_seg_240)) {
  case TAG_At: {
    V v_seg1_241 = heff_dup(heff_field(v_seg_240, 0));
    V v_sp_242 = heff_dup(heff_field(v_seg_240, 1));
    switch (heff_tag_of(v_seg1_241)) {
    case TAG_MkSegment: {
      V v_v_243 = heff_field(v_seg1_241, 0);
      V v_seg12_244 = heff_field(v_seg1_241, 1);
      V v_size_245 = heff_field(v_seg1_241, 2);
      V v_little_246 = heff_field(v_seg1_241, 3);
      V v_signed_247 = heff_field(v_seg1_241, 4);
      heff_take_n(v_seg1_241, 31ULL, 5);
      switch (heff_tag_of(v_seg12_244)) {
      case TAG_SegmentInteger: {
        heff_drop_tag(v_seg_240, 2);
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(8LL), heff_dup(v_sp_242)));
        int64_t v_t_249;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)0ULL);
        }
        int64_t v_t_2410;
        if ((heff_dup(v_signed_247) == NTAG(TAG_True))) {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)0ULL);
        }
        V v_t_2411 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_249 + v_t_2410))});
        V v_t_2412 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_242)})});
        HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_2425;
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_c_2416 = v_field_2415;
            v_t_2425 = v_c_2416;
          } else {
            if ((v_tag_2414 == ((int64_t)1ULL))) {
              V v_i_2417 = v_field_2415;
              V v_t_2420;
              switch (heff_tag_of(v_i_2417)) {
              case TAG_At: {
                V v_s_2419 = heff_dup(heff_field(v_i_2417, 1));
                v_t_2420 = v_s_2419;
                break;
              }
              default: heff_nomatch(v_i_2417);
              }
              v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2417}), v_t_2420});
            } else {
              V v_t_2421 = v_field_2415;
              V v_t_2424;
              switch (heff_tag_of(v_t_2421)) {
              case TAG_At: {
                V v_s_2423 = heff_dup(heff_field(v_t_2421, 1));
                v_t_2424 = v_s_2423;
                break;
              }
              default: heff_nomatch(v_t_2421);
              }
              v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2421}), v_t_2424});
            }
          }
        }
        V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
        V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_242)}), v_t_2426});
        V v_args_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2427});
        V v_t_2429 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2428));
        V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str0)}), heff_dup(v_sp_242)});
        V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2430, v_t_2429}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2431}), v_sp_242});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_sp_242);
        heff_drop(v_v_243);
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        V v_t_2432 = (g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(heff_dup(v_seg_240)));
        V v_args_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
        V v_sp_2436;
        switch (heff_tag_of(v_seg_240)) {
        case TAG_At: {
          V v_s_2435 = heff_field(v_seg_240, 1);
          heff_take_n(v_seg_240, 2ULL, 2);
          v_sp_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_seg_240);
        }
        V v_t_2437 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2436), v_args_2433));
        V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str1)}), heff_dup(v_sp_2436)});
        V v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2438, v_t_2437}), heff_dup(v_sp_2436)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2439}), v_sp_2436});
      }
      case TAG_SegmentBits: {
        heff_drop_tag(v_seg_240, 2);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        switch (heff_tag_of(v_size_245)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_242);
          switch (heff_tag_of(v_v_243)) {
          case TAG_At: {
            V v_e_2440 = heff_field(v_v_243, 0);
            V v_sp_2441 = heff_field(v_v_243, 1);
            V v_ru_24v_243_24At = heff_take_reuse_n(v_v_243, 3ULL, 2);
            HeffT2 v_t_2442 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(heff_dup(v_e_2440)));
            {
              V v_field_2444 = v_t_2442.f[1];
              int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
              if ((v_tag_2443 == ((int64_t)0ULL))) {
                heff_drop(v_e_2440);
                V v_segs_2445 = v_field_2444;
                HeffT2 v_t_2446 = ({ V a_0 = v_segs_2445; V a_1 = v_sp_2441; V b_2 = NTAG(TAG_False); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
                {
                  V v_field_2448 = v_t_2446.f[1];
                  int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
                  if ((v_tag_2447 == ((int64_t)0ULL))) {
                    heff_drop_cell(v_ru_24v_243_24At, 2);
                    V v_a_2449 = v_field_2448;
                    return v_a_2449;
                  } else {
                    if ((v_tag_2447 == ((int64_t)1ULL))) {
                      V v_a_2450 = v_field_2448;
                      V v_t_2453;
                      switch (heff_tag_of(v_a_2450)) {
                      case TAG_At: {
                        V v_a_2452 = heff_dup(heff_field(v_a_2450, 1));
                        v_t_2453 = v_a_2452;
                        break;
                      }
                      default: heff_nomatch(v_a_2450);
                      }
                      return heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_2450}), v_t_2453});
                    } else {
                      V v_a_2454 = v_field_2448;
                      V v_t_2457;
                      switch (heff_tag_of(v_a_2454)) {
                      case TAG_At: {
                        V v_a_2456 = heff_dup(heff_field(v_a_2454, 1));
                        v_t_2457 = v_a_2456;
                        break;
                      }
                      default: heff_nomatch(v_a_2454);
                      }
                      return heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_2454}), v_t_2457});
                    }
                  }
                }
              } else {
                heff_drop(v_field_2444);
                HeffT2 v_t_2458 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){v_e_2440, v_sp_2441})));
                {
                  V v_field_2460 = v_t_2458.f[1];
                  int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
                  if ((v_tag_2459 == ((int64_t)0ULL))) {
                    V v_c_2461 = v_field_2460;
                    return v_c_2461;
                  } else {
                    if ((v_tag_2459 == ((int64_t)1ULL))) {
                      V v_i_2462 = v_field_2460;
                      V v_t_2465;
                      switch (heff_tag_of(v_i_2462)) {
                      case TAG_At: {
                        V v_s_2464 = heff_dup(heff_field(v_i_2462, 1));
                        v_t_2465 = v_s_2464;
                        break;
                      }
                      default: heff_nomatch(v_i_2462);
                      }
                      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2462}), v_t_2465});
                    } else {
                      V v_t_2466 = v_field_2460;
                      V v_t_2469;
                      switch (heff_tag_of(v_t_2466)) {
                      case TAG_At: {
                        V v_s_2468 = heff_dup(heff_field(v_t_2466, 1));
                        v_t_2469 = v_s_2468;
                        break;
                      }
                      default: heff_nomatch(v_t_2466);
                      }
                      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2466}), v_t_2469});
                    }
                  }
                }
              }
            }
          }
          default: return heff_nomatch(v_v_243);
          }
        }
        case TAG_SizeNumber: {
          V v_t_2471 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(0LL), heff_dup(v_sp_242)));
          V v_t_24102;
          switch (heff_tag_of(v_v_243)) {
          case TAG_At: {
            V v_e_2472 = heff_field(v_v_243, 0);
            V v_sp_2473 = heff_field(v_v_243, 1);
            V v_ru_24v_243_24At = heff_take_reuse_n(v_v_243, 3ULL, 2);
            HeffT2 v_t_2474 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(heff_dup(v_e_2472)));
            {
              V v_field_2476 = v_t_2474.f[1];
              int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
              if ((v_tag_2475 == ((int64_t)0ULL))) {
                heff_drop(v_e_2472);
                V v_segs_2477 = v_field_2476;
                HeffT2 v_t_2478 = ({ V a_0 = v_segs_2477; V a_1 = v_sp_2473; V b_2 = NTAG(TAG_False); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
                {
                  V v_field_2480 = v_t_2478.f[1];
                  int64_t v_tag_2479 = ((int64_t)v_t_2478.f[0]);
                  if ((v_tag_2479 == ((int64_t)0ULL))) {
                    heff_drop_cell(v_ru_24v_243_24At, 2);
                    V v_a_2481 = v_field_2480;
                    v_t_24102 = v_a_2481;
                  } else {
                    if ((v_tag_2479 == ((int64_t)1ULL))) {
                      V v_a_2482 = v_field_2480;
                      V v_t_2485;
                      switch (heff_tag_of(v_a_2482)) {
                      case TAG_At: {
                        V v_a_2484 = heff_dup(heff_field(v_a_2482, 1));
                        v_t_2485 = v_a_2484;
                        break;
                      }
                      default: heff_nomatch(v_a_2482);
                      }
                      v_t_24102 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_2482}), v_t_2485});
                    } else {
                      V v_a_2486 = v_field_2480;
                      V v_t_2489;
                      switch (heff_tag_of(v_a_2486)) {
                      case TAG_At: {
                        V v_a_2488 = heff_dup(heff_field(v_a_2486, 1));
                        v_t_2489 = v_a_2488;
                        break;
                      }
                      default: heff_nomatch(v_a_2486);
                      }
                      v_t_24102 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_2486}), v_t_2489});
                    }
                  }
                }
              } else {
                heff_drop(v_field_2476);
                HeffT2 v_t_2490 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){v_e_2472, v_sp_2473})));
                {
                  V v_field_2492 = v_t_2490.f[1];
                  int64_t v_tag_2491 = ((int64_t)v_t_2490.f[0]);
                  if ((v_tag_2491 == ((int64_t)0ULL))) {
                    V v_c_2493 = v_field_2492;
                    v_t_24102 = v_c_2493;
                  } else {
                    if ((v_tag_2491 == ((int64_t)1ULL))) {
                      V v_i_2494 = v_field_2492;
                      V v_t_2497;
                      switch (heff_tag_of(v_i_2494)) {
                      case TAG_At: {
                        V v_s_2496 = heff_dup(heff_field(v_i_2494, 1));
                        v_t_2497 = v_s_2496;
                        break;
                      }
                      default: heff_nomatch(v_i_2494);
                      }
                      v_t_24102 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2494}), v_t_2497});
                    } else {
                      V v_t_2498 = v_field_2492;
                      V v_t_24101;
                      switch (heff_tag_of(v_t_2498)) {
                      case TAG_At: {
                        V v_s_24100 = heff_dup(heff_field(v_t_2498, 1));
                        v_t_24101 = v_s_24100;
                        break;
                      }
                      default: heff_nomatch(v_t_2498);
                      }
                      v_t_24102 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2498}), v_t_24101});
                    }
                  }
                }
              }
            }
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          V v_t_24103 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24102, NTAG(TAG_Nil)});
          V v_args_24104 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2471, v_t_24103});
          V v_t_24105 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24104));
          V v_t_24106 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str2)}), heff_dup(v_sp_242)});
          V v_t_24107 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24106, v_t_24105}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24107}), v_sp_242});
        }
        case TAG_SizeName: {
          V v_t_24111 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(0LL), heff_dup(v_sp_242)));
          V v_t_24142;
          switch (heff_tag_of(v_v_243)) {
          case TAG_At: {
            V v_e_24112 = heff_field(v_v_243, 0);
            V v_sp_24113 = heff_field(v_v_243, 1);
            V v_ru_24v_243_24At = heff_take_reuse_n(v_v_243, 3ULL, 2);
            HeffT2 v_t_24114 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(heff_dup(v_e_24112)));
            {
              V v_field_24116 = v_t_24114.f[1];
              int64_t v_tag_24115 = ((int64_t)v_t_24114.f[0]);
              if ((v_tag_24115 == ((int64_t)0ULL))) {
                heff_drop(v_e_24112);
                V v_segs_24117 = v_field_24116;
                HeffT2 v_t_24118 = ({ V a_0 = v_segs_24117; V a_1 = v_sp_24113; V b_2 = NTAG(TAG_False); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
                {
                  V v_field_24120 = v_t_24118.f[1];
                  int64_t v_tag_24119 = ((int64_t)v_t_24118.f[0]);
                  if ((v_tag_24119 == ((int64_t)0ULL))) {
                    heff_drop_cell(v_ru_24v_243_24At, 2);
                    V v_a_24121 = v_field_24120;
                    v_t_24142 = v_a_24121;
                  } else {
                    if ((v_tag_24119 == ((int64_t)1ULL))) {
                      V v_a_24122 = v_field_24120;
                      V v_t_24125;
                      switch (heff_tag_of(v_a_24122)) {
                      case TAG_At: {
                        V v_a_24124 = heff_dup(heff_field(v_a_24122, 1));
                        v_t_24125 = v_a_24124;
                        break;
                      }
                      default: heff_nomatch(v_a_24122);
                      }
                      v_t_24142 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_24122}), v_t_24125});
                    } else {
                      V v_a_24126 = v_field_24120;
                      V v_t_24129;
                      switch (heff_tag_of(v_a_24126)) {
                      case TAG_At: {
                        V v_a_24128 = heff_dup(heff_field(v_a_24126, 1));
                        v_t_24129 = v_a_24128;
                        break;
                      }
                      default: heff_nomatch(v_a_24126);
                      }
                      v_t_24142 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_24126}), v_t_24129});
                    }
                  }
                }
              } else {
                heff_drop(v_field_24116);
                HeffT2 v_t_24130 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){v_e_24112, v_sp_24113})));
                {
                  V v_field_24132 = v_t_24130.f[1];
                  int64_t v_tag_24131 = ((int64_t)v_t_24130.f[0]);
                  if ((v_tag_24131 == ((int64_t)0ULL))) {
                    V v_c_24133 = v_field_24132;
                    v_t_24142 = v_c_24133;
                  } else {
                    if ((v_tag_24131 == ((int64_t)1ULL))) {
                      V v_i_24134 = v_field_24132;
                      V v_t_24137;
                      switch (heff_tag_of(v_i_24134)) {
                      case TAG_At: {
                        V v_s_24136 = heff_dup(heff_field(v_i_24134, 1));
                        v_t_24137 = v_s_24136;
                        break;
                      }
                      default: heff_nomatch(v_i_24134);
                      }
                      v_t_24142 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24134}), v_t_24137});
                    } else {
                      V v_t_24138 = v_field_24132;
                      V v_t_24141;
                      switch (heff_tag_of(v_t_24138)) {
                      case TAG_At: {
                        V v_s_24140 = heff_dup(heff_field(v_t_24138, 1));
                        v_t_24141 = v_s_24140;
                        break;
                      }
                      default: heff_nomatch(v_t_24138);
                      }
                      v_t_24142 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24138}), v_t_24141});
                    }
                  }
                }
              }
            }
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          V v_t_24143 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24142, NTAG(TAG_Nil)});
          V v_args_24144 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24111, v_t_24143});
          V v_t_24145 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24144));
          V v_t_24146 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str3)}), heff_dup(v_sp_242)});
          V v_t_24147 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24146, v_t_24145}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24147}), v_sp_242});
        }
        default: return heff_nomatch(v_size_245);
        }
      }
      case TAG_SegmentFloat: {
        heff_drop(v_sp_242);
        heff_drop(v_v_243);
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        V v_t_24148 = (g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(heff_dup(v_seg_240)));
        V v_args_24149 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24148, NTAG(TAG_Nil)});
        V v_sp_24152;
        switch (heff_tag_of(v_seg_240)) {
        case TAG_At: {
          V v_s_24151 = heff_field(v_seg_240, 1);
          heff_take_n(v_seg_240, 2ULL, 2);
          v_sp_24152 = v_s_24151;
          break;
        }
        default: heff_nomatch(v_seg_240);
        }
        V v_t_24153 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24152), v_args_24149));
        V v_t_24154 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str4)}), heff_dup(v_sp_24152)});
        V v_t_24155 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24154, v_t_24153}), heff_dup(v_sp_24152)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24155}), v_sp_24152});
      }
      case TAG_SegmentUtf: {
        V v_ru_24seg12_244_24SegmentUtf = heff_take_reuse_n(v_seg12_244, 0ULL, 1);
        heff_drop(v_sp_242);
        heff_drop(v_v_243);
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        V v_t_24157 = (g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(heff_dup(v_seg_240)));
        V v_args_24158 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24157, NTAG(TAG_Nil)});
        V v_sp_24161;
        switch (heff_tag_of(v_seg_240)) {
        case TAG_At: {
          V v_s_24160 = heff_field(v_seg_240, 1);
          heff_take_n(v_seg_240, 2ULL, 2);
          v_sp_24161 = v_s_24160;
          break;
        }
        default: heff_nomatch(v_seg_240);
        }
        V v_t_24162 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24161), v_args_24158));
        V v_t_24163 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24seg12_244_24SegmentUtf, TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str5)}), heff_dup(v_sp_24161)});
        V v_t_24164 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24163, v_t_24162}), heff_dup(v_sp_24161)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24164}), v_sp_24161});
      }
      default: return heff_nomatch(v_seg12_244);
      }
    }
    default: return heff_nomatch(v_seg1_241);
    }
  }
  default: return heff_nomatch(v_seg_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_SetField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_e_245 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24SetField = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      HeffT2 v_t_246 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_245));
      V v_t_2418;
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_249 = v_field_248;
          v_t_2418 = v_c_249;
        } else {
          if ((v_tag_247 == ((int64_t)1ULL))) {
            V v_i_2410 = v_field_248;
            V v_t_2413;
            switch (heff_tag_of(v_i_2410)) {
            case TAG_At: {
              V v_s_2412 = heff_dup(heff_field(v_i_2410, 1));
              v_t_2413 = v_s_2412;
              break;
            }
            default: heff_nomatch(v_i_2410);
            }
            v_t_2418 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2410}), v_t_2413});
          } else {
            V v_t_2414 = v_field_248;
            V v_t_2417;
            switch (heff_tag_of(v_t_2414)) {
            case TAG_At: {
              V v_s_2416 = heff_dup(heff_field(v_t_2414, 1));
              v_t_2417 = v_s_2416;
              break;
            }
            default: heff_nomatch(v_t_2414);
            }
            v_t_2418 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2414}), v_t_2417});
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24SetField, TAG_SetField, 3, (V[]){v_x_243, v_xsp_244, v_t_2418}), v_sp_242});
    }
    case TAG_BadFieldSet: {
      V v_e_2419 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24BadFieldSet = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      HeffT2 v_t_2420 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_2419));
      V v_t_2432;
      {
        V v_field_2422 = v_t_2420.f[1];
        int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
        if ((v_tag_2421 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_2423 = v_field_2422;
          v_t_2432 = v_c_2423;
        } else {
          if ((v_tag_2421 == ((int64_t)1ULL))) {
            V v_i_2424 = v_field_2422;
            V v_t_2427;
            switch (heff_tag_of(v_i_2424)) {
            case TAG_At: {
              V v_s_2426 = heff_dup(heff_field(v_i_2424, 1));
              v_t_2427 = v_s_2426;
              break;
            }
            default: heff_nomatch(v_i_2424);
            }
            v_t_2432 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2424}), v_t_2427});
          } else {
            V v_t_2428 = v_field_2422;
            V v_t_2431;
            switch (heff_tag_of(v_t_2428)) {
            case TAG_At: {
              V v_s_2430 = heff_dup(heff_field(v_t_2428, 1));
              v_t_2431 = v_s_2430;
              break;
            }
            default: heff_nomatch(v_t_2428);
            }
            v_t_2432 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2428}), v_t_2431});
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2432}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkAlt: {
      V v_p_243 = heff_field(v_x21_241, 0);
      V v_b_244 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24MkAlt = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_b_244));
      V v_t_2417;
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_248 = v_field_247;
          v_t_2417 = v_c_248;
        } else {
          if ((v_tag_246 == ((int64_t)1ULL))) {
            V v_i_249 = v_field_247;
            V v_t_2412;
            switch (heff_tag_of(v_i_249)) {
            case TAG_At: {
              V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
              v_t_2412 = v_s_2411;
              break;
            }
            default: heff_nomatch(v_i_249);
            }
            v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_249}), v_t_2412});
          } else {
            V v_t_2413 = v_field_247;
            V v_t_2416;
            switch (heff_tag_of(v_t_2413)) {
            case TAG_At: {
              V v_s_2415 = heff_dup(heff_field(v_t_2413, 1));
              v_t_2416 = v_s_2415;
              break;
            }
            default: heff_nomatch(v_t_2413);
            }
            v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2413}), v_t_2416});
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_243, v_t_2417}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_DeclEquations: {
    V v_f_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_declared_243 = heff_field(v_x2_240, 2);
    V v_ty_244 = heff_field(v_x2_240, 3);
    V v_eqs_245 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24DeclEquations = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_248;
    switch (heff_tag_of(v_ty_244)) {
    case TAG_At: {
      V v_n_246 = heff_field(v_ty_244, 0);
      V v_sp_247 = heff_field(v_ty_244, 1);
      V v_ru_24ty_244_24At = heff_take_reuse_n(v_ty_244, 3ULL, 2);
      v_t_248 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24ty_244_24At, v_sp_247, v_n_246));
      break;
    }
    default: heff_nomatch(v_ty_244);
    }
    V v_t_249 = (g_list_2emap_24s1782778565x402128078(v_eqs_245));
    return heff_tag_at_n(v_ru_24x2_240_24DeclEquations, TAG_DeclEquations, 5, (V[]){v_f_241, v_sp_242, v_declared_243, v_t_248, v_t_249});
  }
  case TAG_DeclDefine: {
    V v_x_2410 = heff_field(v_x2_240, 0);
    V v_sp_2411 = heff_field(v_x2_240, 1);
    V v_ps_2412 = heff_field(v_x2_240, 2);
    V v_u_2413 = heff_field(v_x2_240, 3);
    V v_body_2414 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24DeclDefine = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_2415 = (g_list_2emap_24s474585387x1072098790(v_ps_2412));
    V v_t_2418;
    switch (heff_tag_of(v_u_2413)) {
    case TAG_At: {
      V v_n_2416 = heff_field(v_u_2413, 0);
      V v_sp_2417 = heff_field(v_u_2413, 1);
      V v_ru_24u_2413_24At = heff_take_reuse_n(v_u_2413, 3ULL, 2);
      v_t_2418 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24u_2413_24At, v_sp_2417, v_n_2416));
      break;
    }
    default: heff_nomatch(v_u_2413);
    }
    V v_t_2422;
    switch (heff_tag_of(v_body_2414)) {
    case TAG_At: {
      V v_n_2419 = heff_field(v_body_2414, 0);
      V v_sp_2420 = heff_field(v_body_2414, 1);
      V v_ru_24body_2414_24At = heff_take_reuse_n(v_body_2414, 3ULL, 2);
      V v_t_2421 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2419));
      v_t_2422 = heff_tag_at_n(v_ru_24body_2414_24At, TAG_At, 2, (V[]){v_t_2421, v_sp_2420});
      break;
    }
    default: heff_nomatch(v_body_2414);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_2410, v_sp_2411, v_t_2415, v_t_2418, v_t_2422});
  }
  case TAG_DeclTheory: {
    V v_x_2423 = heff_field(v_x2_240, 0);
    V v_sp_2424 = heff_field(v_x2_240, 1);
    V v_ps_2425 = heff_field(v_x2_240, 2);
    V v_body_2426 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24DeclTheory = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2427 = (g_list_2emap_24s474585387x1072098790(v_ps_2425));
    V v_t_2431;
    switch (heff_tag_of(v_body_2426)) {
    case TAG_At: {
      V v_n_2428 = heff_field(v_body_2426, 0);
      V v_sp_2429 = heff_field(v_body_2426, 1);
      V v_ru_24body_2426_24At = heff_take_reuse_n(v_body_2426, 3ULL, 2);
      V v_t_2430 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2428));
      v_t_2431 = heff_tag_at_n(v_ru_24body_2426_24At, TAG_At, 2, (V[]){v_t_2430, v_sp_2429});
      break;
    }
    default: heff_nomatch(v_body_2426);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2423, v_sp_2424, v_t_2427, v_t_2431});
  }
  case TAG_DeclPrimitive: {
    V v_x_2432 = heff_field(v_x2_240, 0);
    V v_sp_2433 = heff_field(v_x2_240, 1);
    V v_t_2434 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24DeclPrimitive = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_2437;
    switch (heff_tag_of(v_t_2434)) {
    case TAG_At: {
      V v_n_2435 = heff_field(v_t_2434, 0);
      V v_sp_2436 = heff_field(v_t_2434, 1);
      V v_ru_24t_2434_24At = heff_take_reuse_n(v_t_2434, 3ULL, 2);
      v_t_2437 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2434_24At, v_sp_2436, v_n_2435));
      break;
    }
    default: heff_nomatch(v_t_2434);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2432, v_sp_2433, v_t_2437});
  }
  case TAG_DeclTest: {
    V v_x_2438 = heff_field(v_x2_240, 0);
    V v_sp_2439 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24DeclTest = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24DeclTest, TAG_DeclTest, 2, (V[]){v_x_2438, v_sp_2439});
  }
  case TAG_DeclWatch: {
    V v_c_2440 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24DeclWatch = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2444;
    switch (heff_tag_of(v_c_2440)) {
    case TAG_At: {
      V v_n_2441 = heff_field(v_c_2440, 0);
      V v_sp_2442 = heff_field(v_c_2440, 1);
      V v_ru_24c_2440_24At = heff_take_reuse_n(v_c_2440, 3ULL, 2);
      V v_t_2443 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2441));
      v_t_2444 = heff_tag_at_n(v_ru_24c_2440_24At, TAG_At, 2, (V[]){v_t_2443, v_sp_2442});
      break;
    }
    default: heff_nomatch(v_c_2440);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclWatch, TAG_DeclWatch, 1, (V[]){v_t_2444});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etryT_24tok1_str0, 89, "nothing after this `try` runs: neither its statements nor its `catch` arm reach their end");
Clo g_heff_2esyntax_2epresyntax_2etryT_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etryT_24tok1_entry, 7, 0};

V g_heff_2esyntax_2epresyntax_2etryT_24tok1(V v_tok_240, V v_t_241, V v_cx_242, V v_sp_243, V v_tr_244, V v_rest_245, V v_end_246) {
top: ;
  V v_scope_247 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2etryScope_clo), 4, (V[]){heff_dup(v_t_241), heff_dup(v_cx_242), heff_dup(v_sp_243), heff_dup(v_tr_244)}));
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_ETry, 1, (V[]){v_tr_244}), heff_dup(v_sp_243)});
  V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_248}), heff_dup(v_sp_243)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  V v_x1_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2410));
  V v_falls_2428;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nil: {
    v_falls_2428 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 2);
    switch (heff_tag_of(v_x_2412)) {
    case TAG_At: {
      V v_it11_2414 = heff_field(v_x_2412, 0);
      heff_take_n(v_x_2412, 1ULL, 2);
      switch (heff_tag_of(v_it11_2414)) {
      case TAG_StmtBind: {
        heff_take_n(v_it11_2414, 0ULL, 3);
        v_falls_2428 = NTAG(TAG_True);
        break;
      }
      case TAG_StmtLet: {
        heff_take_n(v_it11_2414, 0ULL, 2);
        v_falls_2428 = NTAG(TAG_True);
        break;
      }
      case TAG_StmtExpr: {
        V v_e_2421 = heff_field(v_it11_2414, 0);
        heff_take_n(v_it11_2414, 1ULL, 1);
        v_falls_2428 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_e_2421));
        break;
      }
      case TAG_StmtLetMut: {
        heff_take_n(v_it11_2414, 0ULL, 3);
        v_falls_2428 = NTAG(TAG_True);
        break;
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_it11_2414, 0ULL, 3);
        v_falls_2428 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_it11_2414);
      }
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  switch (heff_tag_of(v_rest_245)) {
  case TAG_Nil: {
    heff_drop(v_t_241);
    heff_drop(v_cx_242);
    heff_drop(v_sp_243);
    heff_drop(v_falls_2428);
    return heff_tail(v_scope_247, 1, (V[]){v_end_246});
  }
  case TAG_Cons: {
    V v_s_2429 = heff_field(v_rest_245, 0);
    V v_rest_2430 = heff_field(v_rest_245, 1);
    V v_ru_24rest_245_24Cons = heff_take_reuse_n(v_rest_245, 3ULL, 2);
    if ((heff_dup(v_falls_2428) == NTAG(TAG_True))) {
      heff_drop(v_falls_2428);
      return (g_heff_2esyntax_2epresyntax_2escopeJoin(v_t_241, v_cx_242, v_sp_243, v_scope_247, heff_tag_at_n(v_ru_24rest_245_24Cons, TAG_Cons, 2, (V[]){v_s_2429, v_rest_2430}), v_end_246));
    } else {
      heff_drop(v_t_241);
      heff_drop(v_cx_242);
      heff_drop(v_sp_243);
      heff_drop(v_end_246);
      heff_drop(v_scope_247);
      heff_drop(v_falls_2428);
      heff_drop(v_rest_2430);
      heff_drop_cell(v_ru_24rest_245_24Cons, 2);
      V v_t_2433;
      switch (heff_tag_of(v_s_2429)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_s_2429, 1);
        heff_take_n(v_s_2429, 2ULL, 2);
        v_t_2433 = v_s_2432;
        break;
      }
      default: heff_nomatch(v_s_2429);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2etryT_24tok1_str0)}), v_t_2433});
    }
  }
  default: return heff_nomatch(v_rest_245);
  }
}
V g_heff_2esyntax_2epresyntax_2etryT_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etryT_24tok1(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2(V v_tok_240, V v_sp_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_n_242)) {
  case TAG_TPi: {
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    V v_t_246 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_245, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_sp_241});
  }
  case TAG_TSig: {
    V v_fs_247 = heff_field(v_n_242, 0);
    heff_take_n(v_n_242, 1ULL, 1);
    V v_t_248 = (g_list_2emap_24s1992667171x110340492(v_fs_247));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_TSig, 1, (V[]){v_t_248}), v_sp_241});
  }
  case TAG_TSum: {
    V v_vs_249 = heff_field(v_n_242, 0);
    V v_ru_24n_242_24TSum = heff_take_reuse_n(v_n_242, 1ULL, 1);
    V v_t_2410 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(heff_tag_at_n(v_ru_24n_242_24TSum, TAG_TSum, 1, (V[]){v_vs_249})));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2410, v_sp_241});
  }
  case TAG_TType: {
    V v_t_2411 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    V v_t_2412 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_sp_241});
  }
  case TAG_TInt: {
    V v_t_2413 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    V v_t_2414 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_sp_241});
  }
  case TAG_TFloat: {
    V v_t_2415 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    V v_t_2416 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2415, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2416, v_sp_241});
  }
  case TAG_TString: {
    V v_t_2417 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    V v_t_2418 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2417, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_sp_241});
  }
  case TAG_TRune: {
    V v_t_2419 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    V v_t_2420 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2419, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_sp_241});
  }
  case TAG_TArray: {
    V v_t_2422 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    V v_t_2423 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2422, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_sp_241});
  }
  case TAG_TFixed: {
    V v_t_2425 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    V v_t_2426 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2425, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2426, v_sp_241});
  }
  case TAG_TInf: {
    V v_i_2427 = heff_field(v_n_242, 0);
    heff_take_n(v_n_242, 1ULL, 1);
    V v_t_2430;
    switch (heff_tag_of(v_i_2427)) {
    case TAG_At: {
      V v_n_2428 = heff_field(v_i_2427, 0);
      V v_sp_2429 = heff_field(v_i_2427, 1);
      V v_ru_24i_2427_24At = heff_take_reuse_n(v_i_2427, 3ULL, 2);
      v_t_2430 = (g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(v_ru_24i_2427_24At, v_sp_2429, v_n_2428));
      break;
    }
    default: heff_nomatch(v_i_2427);
    }
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_t_2430}), v_sp_241});
  }
  case TAG_TChk: {
    V v_c_2431 = heff_field(v_n_242, 0);
    heff_take_n(v_n_242, 1ULL, 1);
    V v_t_2434;
    switch (heff_tag_of(v_c_2431)) {
    case TAG_At: {
      V v_n_2432 = heff_field(v_c_2431, 0);
      V v_sp_2433 = heff_field(v_c_2431, 1);
      heff_take_n(v_c_2431, 3ULL, 2);
      v_t_2434 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2433, v_n_2432));
      break;
    }
    default: heff_nomatch(v_c_2431);
    }
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_t_2434}), v_sp_241});
  }
  case TAG_TNominal: {
    V v_t_2436 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    V v_t_2437 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2436, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2437, v_sp_241});
  }
  default: return heff_nomatch(v_n_242);
  }
}
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2(a[0], a[1], a[2]);
}