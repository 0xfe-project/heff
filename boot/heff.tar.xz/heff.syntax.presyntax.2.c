// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_EndGive 48080
#define TAG_EndJump 17665
#define TAG_EndValue 24675
#define TAG_IApp 21275
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_IPrim 59489
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkSegment 38079
#define TAG_MkTry 8097
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_end 310101
#define LBL_giving 701566649
#define LBL_guard 300063423
#define LBL_head 9693863
#define LBL_inLam 301681229
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_head__vars__unit__depth[] = {LBL_head, LBL_vars, LBL_unit, LBL_depth};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_names__muts__loop__sp__depth__giving[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth, LBL_giving};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s122821685x1786755984_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1685160129x1203636606_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1871252431x1455926961_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s320198774x1124344602_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s386636727x1203660589_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s42976669x698242400_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s605646493x1315728604_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s814616358x897102902_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718_clo;
V g_heff_2esyntax_2epresyntax_2ealtBy(V, V);
V g_heff_2esyntax_2epresyntax_2ealtBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtBy_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2easAction(V, V, V);
V g_heff_2esyntax_2epresyntax_2easAction_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2easAction_clo;
HeffT1 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(V);
HeffT3 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076(V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_clo;
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo;
V g_heff_2esyntax_2epresyntax_2ebytesPart(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_clo;
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2echeckedWays_get(void);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecoNames_get(void);
V g_heff_2esyntax_2epresyntax_2edeclaredMuts(V);
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2edoBlock_24s1455639597x676970604_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2egiveBackMatch(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egiveBackMatch_clo;
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240(V, V);
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240_clo;
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241(V, V);
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241_clo;
V g_heff_2esyntax_2epresyntax_2eguardE(V, V);
V g_heff_2esyntax_2epresyntax_2eguardE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eguardE_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall(V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_clo;
V g_heff_2esyntax_2epresyntax_2ejumpE(V);
V g_heff_2esyntax_2epresyntax_2ejumpE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpE_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_clo;
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
V g_heff_2esyntax_2epresyntax_2eliftE(V, V, V);
V g_heff_2esyntax_2epresyntax_2eliftE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eliftE_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elocalFun_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
V g_heff_2esyntax_2epresyntax_2epackPat(V, V);
V g_heff_2esyntax_2epresyntax_2epackPat_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epackPat_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24dps(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24dps_clo;
V g_heff_2esyntax_2epresyntax_2ereturnOf(V, V, V);
V g_heff_2esyntax_2epresyntax_2ereturnOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ereturnOf_clo;
V g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_clo;
V g_heff_2esyntax_2epresyntax_2esegmentOdd(V, V);
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_clo;
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo;
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eutf8Of(V);
V g_heff_2esyntax_2epresyntax_2eutf8Of_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eutf8Of_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eany_24s2077819594x1842428557(V, V);
V g_list_2eany_24s2077819594x1842428557_entry(V self, V *a);
extern Clo g_list_2eany_24s2077819594x1842428557_clo;
V g_list_2eany_24s717144537x1885076661(V);
V g_list_2eany_24s717144537x1885076661_entry(V self, V *a);
extern Clo g_list_2eany_24s717144537x1885076661_clo;
HeffT2 g_list_2efind_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1935134062x1256175429(V, V);
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1935134062x1256175429_clo;
V g_list_2efoldl_24s947545569x507961639(V, V);
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947545569x507961639_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1992667171x110340492(V);
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2esegmentOdd_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2esegmentOdd(V v_ty_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(v_ty_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2esegmentOdd(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eutf8Of_str3, 0, "");
Clo g_heff_2esyntax_2epresyntax_2eutf8Of_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eutf8Of_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eutf8Of(V v_c_240) {
top: ;
  if (heff_intLt_c_lent(v_c_240, MK_INT(128LL), 2)) {
    return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(1LL), v_c_240, ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str0)));
  } else {
    if (heff_intLt_c_lent(v_c_240, MK_INT(2048LL), 2)) {
      int64_t v_t_241 = (((int64_t)192ULL) + (heff_peek_word(v_c_240) / ((int64_t)64ULL)));
      int64_t v_t_242 = ((v_t_241 * ((int64_t)256ULL)) + ((int64_t)128ULL));
      int64_t v_t_243 = (v_t_242 + (heff_unbox_word(v_c_240) % ((int64_t)64ULL)));
      return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(2LL), heff_box_word(v_t_243), ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str1)));
    } else {
      if (heff_intLt_c_lent(v_c_240, MK_INT(65536LL), 2)) {
        int64_t v_t_244 = (((int64_t)224ULL) + (heff_peek_word(v_c_240) / ((int64_t)4096ULL)));
        int64_t v_t_245 = ((v_t_244 * ((int64_t)256ULL)) + ((int64_t)128ULL));
        int64_t v_t_246 = ((heff_peek_word(v_c_240) / ((int64_t)64ULL)) % ((int64_t)64ULL));
        int64_t v_t_247 = ((v_t_245 + v_t_246) * ((int64_t)256ULL));
        int64_t v_t_248 = ((v_t_247 + ((int64_t)128ULL)) + (heff_unbox_word(v_c_240) % ((int64_t)64ULL)));
        return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(3LL), heff_box_word(v_t_248), ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str2)));
      } else {
        V v_t_249 = heff_intAdd(MK_INT(240LL), heff_intDiv(heff_dup(v_c_240), MK_INT(262144LL)));
        V v_t_2410 = heff_intAdd(heff_intMul(v_t_249, MK_INT(256LL)), MK_INT(128LL));
        V v_t_2411 = heff_intMod(heff_intDiv(heff_dup(v_c_240), MK_INT(4096LL)), MK_INT(64LL));
        V v_t_2412 = heff_intMul(heff_intAdd(v_t_2410, v_t_2411), MK_INT(256LL));
        V v_t_2413 = heff_intMod(heff_intDiv(heff_dup(v_c_240), MK_INT(64LL)), MK_INT(64LL));
        V v_t_2414 = heff_intAdd(heff_intAdd(v_t_2412, MK_INT(128LL)), v_t_2413);
        V v_t_2415 = heff_intAdd(heff_intMul(v_t_2414, MK_INT(256LL)), MK_INT(128LL));
        V v_t_2416 = heff_intAdd(v_t_2415, heff_intMod(v_c_240, MK_INT(64LL)));
        return (g_heff_2esyntax_2epresyntax_2enatBytes(MK_INT(4LL), v_t_2416, ((V)&g_heff_2esyntax_2epresyntax_2eutf8Of_str3)));
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eutf8Of_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eutf8Of(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str1, 4, "Unit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str2, 14, "prelude.typeOf");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2evarParams_str3, 14, "prelude.typeOf");
V g_heff_2esyntax_2epresyntax_2evarParams_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2evarParams_lam1(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2evarParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2evarParams_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2evarParams(V v_sp_240, V v_unit_241, V v_vars_242) {
top: ;
  if ((heff_dup(v_unit_241) == NTAG(TAG_True))) {
    switch (heff_tag_of(v_vars_242)) {
    case TAG_Nil: {
      V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str0)}), heff_dup(v_sp_240)});
      V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str1)}), v_sp_240});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_t_244}), NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      return (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2evarParams_lam0, 1, 1, (V[]){v_sp_240}), v_vars_242));
    }
    default: return heff_nomatch(v_vars_242);
    }
  } else {
    return (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2evarParams_lam1, 1, 1, (V[]){v_sp_240}), v_vars_242));
  }
}
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2evarParams(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2epresyntax_2evarParams_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_x_247)}), heff_dup(v_sp_240)});
  V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str2)}), heff_dup(v_sp_240)});
  V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_247}), v_sp_240});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_249, v_t_2411));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_t_2412});
}
V g_heff_2esyntax_2epresyntax_2evarParams_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_x_2413)}), heff_dup(v_sp_240)});
  V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2evarParams_str3)}), heff_dup(v_sp_240)});
  V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_2413}), v_sp_240});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2415, v_t_2417));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_t_2418});
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ejumpCall_str0, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2ejumpCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ejumpCall_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ejumpCall(V v_cx_240, V v_sp_241, V v_j_242) {
top: ;
  V v_depth_243 = heff_take_field(v_j_242, 3);
  V v_head_244 = heff_take_field(v_j_242, 0);
  V v_vars_245 = heff_take_field(v_j_242, 1);
  V v_unit_246 = heff_get_n(v_j_242, 2, 4);
  V v_t_247 = heff_intSub(heff_dup(heff_rfield(v_cx_240, 4)), v_depth_243);
  V v_vars_248 = v_vars_245;
  V v_t_2412;
  if ((heff_dup(v_unit_246) == NTAG(TAG_True))) {
    heff_drop(v_unit_246);
    switch (heff_tag_of(v_vars_248)) {
    case TAG_Nil: {
      V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ejumpCall_str0)}), heff_dup(v_sp_241)});
      v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      v_t_2412 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_vars_248));
      break;
    }
    default: heff_nomatch(v_vars_248);
    }
  } else {
    heff_drop(v_unit_246);
    v_t_2412 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_vars_248));
  }
  V v_t_2413 = (g_heff_2esyntax_2epresyntax_2eapp(v_head_244, v_t_2412));
  return (g_heff_2esyntax_2epresyntax_2eleaving(v_cx_240, v_sp_241, v_t_247, v_t_2413));
}
V g_heff_2esyntax_2epresyntax_2ejumpCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ejumpCall(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epatNames_24dps_str0, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2epatNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epatNames_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2esyntax_2epresyntax_2epatNames_24dps_str0), 2)) {
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        heff_drop(v_x_244);
        return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
      } else {
        V v_t_245 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
        return heff_setField(v_d_241, MK_INT(1LL), v_t_245);
      }
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_248));
      V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_249); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2410);
    }
    case TAG_PatOp: {
      V v_ps_2413 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2413));
      V v_t_2415 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2414); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2415);
    }
    case TAG_PatInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatFloat: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRecord: {
      V v_fs_2421 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2421));
      V v_t_2423 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s947545569x507961639(a_0, a_1)); heff_drop(v_t_2422); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2423);
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatAs: {
      V v_x_2425 = heff_field(v_x11_242, 0);
      V v_q_2427 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 5ULL, 3);
      V v_cell_2428 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2425, heff_hole()});
      V v_u_2429 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2428));
      heff_drop(v_u_2429);
      V t_0 = v_q_2427;
      V t_1 = v_cell_2428;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epatNames_24dps(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1685160129x1203636606_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkSegment: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        V v_a_2410 = heff_field(v_a_244, 4);
        V v_ru_24a_244_24MkSegment = heff_take_reuse_n(v_a_244, 31ULL, 5);
        V v_a_2440;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2440 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_246)) {
          case TAG_At: {
            V v_a_2411 = heff_dup(heff_field(v_a_246, 0));
            switch (heff_tag_of(v_a_2411)) {
            case TAG_ELam: {
              heff_take_n(v_a_2411, 0ULL, 2);
              switch (heff_tag_of(v_a_246)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_246);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_a_246)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_246);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_a_246)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_246);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_a_246)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_246);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_a_246)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_246);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_a_2411, 0ULL, 4);
              switch (heff_tag_of(v_a_246)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_246);
              }
              break;
            }
            default: {
              heff_drop(v_a_2411);
              HeffT2 v_t_2435 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_246)));
              {
                V v_field_2436 = v_t_2435.f[0];
                V v_field_2437 = v_t_2435.f[1];
                V v_a_2438 = v_field_2436;
                V v_a_2439 = v_field_2437;
                heff_drop(v_a_2439);
                v_a_2440 = v_a_2438;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_246);
          }
        }
        HeffT2 v_t_2441 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1685160129x1203636606_24cpr(v_a_2440, v_xs_243));
        {
          V v_field_2442 = v_t_2441.f[0];
          V v_field_2443 = v_t_2441.f[1];
          V v_x_2444 = v_field_2442;
          V v_y_2445 = v_field_2443;
          V v_t_2446 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a_244_24MkSegment, TAG_MkSegment, 5, (V[]){v_a_246, v_a_247, v_a_248, v_a_249, v_a_2410}), v_a_245});
          return ((HeffT2){{v_x_2444, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2446, v_y_2445})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s814616358x897102902_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_st_244 = v_st_240;
    V v_x3_245 = v_x_242;
    V v_x1_2474;
    switch (heff_tag_of(v_x3_245)) {
    case TAG_At: {
      V v_x31_246 = heff_field(v_x3_245, 0);
      V v_sp_247 = heff_field(v_x3_245, 1);
      V v_ru_24x3_245_24At = heff_take_reuse_n(v_x3_245, 3ULL, 2);
      switch (heff_tag_of(v_x31_246)) {
      case TAG_SetField: {
        V v_x_248 = heff_field(v_x31_246, 0);
        V v_xsp_249 = heff_field(v_x31_246, 1);
        V v_e_2410 = heff_field(v_x31_246, 2);
        V v_ru_24x31_246_24SetField = heff_take_reuse_n(v_x31_246, 7ULL, 3);
        V v_x_2440;
        if ((heff_dup(v_st_244) == NTAG(TAG_True))) {
          heff_drop(v_st_244);
          v_x_2440 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_244);
          switch (heff_tag_of(v_e_2410)) {
          case TAG_At: {
            V v_a_2411 = heff_dup(heff_field(v_e_2410, 0));
            switch (heff_tag_of(v_a_2411)) {
            case TAG_ELam: {
              heff_take_n(v_a_2411, 0ULL, 2);
              switch (heff_tag_of(v_e_2410)) {
              case TAG_At: {
                v_x_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2410);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_e_2410)) {
              case TAG_At: {
                v_x_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2410);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_e_2410)) {
              case TAG_At: {
                v_x_2440 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_2410);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_e_2410)) {
              case TAG_At: {
                v_x_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2410);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_e_2410)) {
              case TAG_At: {
                v_x_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2410);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_a_2411, 0ULL, 4);
              switch (heff_tag_of(v_e_2410)) {
              case TAG_At: {
                v_x_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2410);
              }
              break;
            }
            default: {
              heff_drop(v_a_2411);
              HeffT2 v_t_2435 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_2410)));
              {
                V v_field_2436 = v_t_2435.f[0];
                V v_field_2437 = v_t_2435.f[1];
                V v_a_2438 = v_field_2436;
                V v_a_2439 = v_field_2437;
                heff_drop(v_a_2439);
                v_x_2440 = v_a_2438;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_2410);
          }
        }
        V v_t_2441 = heff_tag_at_n(v_ru_24x3_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_246_24SetField, TAG_SetField, 3, (V[]){v_x_248, v_xsp_249, v_e_2410}), v_sp_247});
        v_x1_2474 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2440, v_t_2441});
        break;
      }
      case TAG_BadFieldSet: {
        V v_e_2442 = heff_field(v_x31_246, 0);
        V v_ru_24x31_246_24BadFieldSet = heff_take_reuse_n(v_x31_246, 1ULL, 1);
        V v_x_2472;
        if ((heff_dup(v_st_244) == NTAG(TAG_True))) {
          heff_drop(v_st_244);
          v_x_2472 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_244);
          switch (heff_tag_of(v_e_2442)) {
          case TAG_At: {
            V v_a_2443 = heff_dup(heff_field(v_e_2442, 0));
            switch (heff_tag_of(v_a_2443)) {
            case TAG_ELam: {
              heff_take_n(v_a_2443, 0ULL, 2);
              switch (heff_tag_of(v_e_2442)) {
              case TAG_At: {
                v_x_2472 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2442);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_a_2443, 0ULL, 1);
              switch (heff_tag_of(v_e_2442)) {
              case TAG_At: {
                v_x_2472 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2442);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_a_2443, 0ULL, 1);
              switch (heff_tag_of(v_e_2442)) {
              case TAG_At: {
                v_x_2472 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_2442);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_a_2443, 0ULL, 1);
              switch (heff_tag_of(v_e_2442)) {
              case TAG_At: {
                v_x_2472 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2442);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_a_2443, 0ULL, 1);
              switch (heff_tag_of(v_e_2442)) {
              case TAG_At: {
                v_x_2472 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2442);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_a_2443, 0ULL, 4);
              switch (heff_tag_of(v_e_2442)) {
              case TAG_At: {
                v_x_2472 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2442);
              }
              break;
            }
            default: {
              heff_drop(v_a_2443);
              HeffT2 v_t_2467 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_2442)));
              {
                V v_field_2468 = v_t_2467.f[0];
                V v_field_2469 = v_t_2467.f[1];
                V v_a_2470 = v_field_2468;
                V v_a_2471 = v_field_2469;
                heff_drop(v_a_2471);
                v_x_2472 = v_a_2470;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_2442);
          }
        }
        V v_t_2473 = heff_tag_at_n(v_ru_24x3_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_246_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_e_2442}), v_sp_247});
        v_x1_2474 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2472, v_t_2473});
        break;
      }
      default: heff_nomatch(v_x31_246);
      }
      break;
    }
    default: heff_nomatch(v_x3_245);
    }
    switch (heff_tag_of(v_x1_2474)) {
    case TAG_MkPair: {
      V v_st_2475 = heff_field(v_x1_2474, 0);
      V v_y_2476 = heff_field(v_x1_2474, 1);
      heff_take_n(v_x1_2474, 3ULL, 2);
      HeffT2 v_t_2477 = (g_heff_2esyntax_2epresyntax_2eaccList_24s814616358x897102902_24cpr(v_st_2475, v_xs_243));
      {
        V v_field_2478 = v_t_2477.f[0];
        V v_field_2479 = v_t_2477.f[1];
        V v_x_2480 = v_field_2478;
        V v_y_2481 = v_field_2479;
        return ((HeffT2){{v_x_2480, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_2476, v_y_2481})}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_2474)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eguardE_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eguardE_str1, 135, "` is a `let mut` variable of the `do` block around: a closure (a lambda, or a `do` block of its own) holds its value, and cannot set it");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eguardE_str2, 95, "`break` is in a lambda: a loop's statements are its body's, and a lambda's body is none of them");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eguardE_str3, 98, "`continue` is in a lambda: a loop's statements are its body's, and a lambda's body is none of them");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eguardE_str4, 105, "`return` is in a lambda: it ends the `do` block it is a statement of, and a lambda's body is no statement");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eguardE_str5, 118, "`(<- c)` is in a lambda, whose body runs later, not where the statement does: bind the action's value before, `x <- c`");
V g_heff_2esyntax_2epresyntax_2eguardE_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam1(V self, V *args);
V g_heff_2esyntax_2epresyntax_2eguardE_lam2(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2eguardE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eguardE_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eguardE(V v_g_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_At: {
    V v_e1_242 = heff_dup(heff_field(v_e_241, 0));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_ELam: {
      V v_b_244 = heff_field(v_e1_242, 0);
      V v_body_245 = heff_field(v_e1_242, 1);
      V v_ru_24e1_242_24ELam = heff_take_reuse_n(v_e1_242, 3ULL, 2);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_247 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_248 = ({ V rv_1 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_g_240, 1ULL, 2, shape_muts__inLam, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_249 = (g_heff_2esyntax_2epresyntax_2eguardE(v_t_248, v_body_245));
        return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ELam, TAG_ELam, 2, (V[]){v_b_244, v_t_249}), v_sp_247});
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_EDo: {
      V v_ss_2410 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24EDo = heff_take_reuse_n(v_e1_242, 1ULL, 1);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_2412 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_2416 = (g_list_2ekeepIf(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam0, 1, 1, (V[]){heff_dup(v_ss_2410)}), heff_get_n(v_g_240, 0, 2)));
        V v_t_2417 = heff_rec_n(2, shape_muts__inLam, (V[]){v_t_2416, NTAG(TAG_False)});
        V v_f_2418 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_t_2417}));
        V v_t_2419 = heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EDo, TAG_EDo, 1, (V[]){v_ss_2410}), v_sp_2412});
        HeffT2 v_t_2423 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam1, 2, 1, (V[]){v_f_2418}), NTAG(TAG_MkUnit), v_t_2419));
        {
          V v_field_2424 = v_t_2423.f[0];
          V v_field_2425 = v_t_2423.f[1];
          V v_x_2426 = v_field_2424;
          heff_drop(v_x_2426);
          V v_y_2427 = v_field_2425;
          return v_y_2427;
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_EAssign: {
      V v_x_2428 = heff_field(v_e1_242, 0);
      V v_xsp_2429 = heff_field(v_e1_242, 1);
      V v_v_2430 = heff_field(v_e1_242, 2);
      V v_ru_24e1_242_24EAssign = heff_take_reuse_n(v_e1_242, 7ULL, 3);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_2432 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_2433 = (g_list_2eany_24s2077819594x1842428557(v_x_2428, heff_rfield(v_g_240, 0)));
        if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
          heff_drop_rec(v_g_240, 2);
          heff_drop(v_v_2430);
          heff_drop_cell(v_ru_24e1_242_24EAssign, 3);
          heff_drop(v_sp_2432);
          heff_drop(v_t_2433);
          V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eguardE_str0), v_x_2428), ((V)&g_heff_2esyntax_2epresyntax_2eguardE_str1));
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2434}), v_xsp_2429});
        } else {
          heff_drop(v_t_2433);
          V v_t_2435 = (g_heff_2esyntax_2epresyntax_2eguardE(v_g_240, v_v_2430));
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EAssign, TAG_EAssign, 3, (V[]){v_x_2428, v_xsp_2429, v_t_2435}), v_sp_2432});
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_EBreak: {
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_2437 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_2438 = heff_get_n(v_g_240, 1, 2);
        if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
          heff_drop(v_t_2438);
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eguardE_str2)}), v_sp_2437});
        } else {
          heff_drop(v_t_2438);
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){NTAG(TAG_EBreak), v_sp_2437});
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_EContinue: {
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_2440 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_2441 = heff_get_n(v_g_240, 1, 2);
        if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
          heff_drop(v_t_2441);
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eguardE_str3)}), v_sp_2440});
        } else {
          heff_drop(v_t_2441);
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){NTAG(TAG_EContinue), v_sp_2440});
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_EReturn: {
      V v_v_2442 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24EReturn = heff_take_reuse_n(v_e1_242, 1ULL, 1);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_2444 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_2445 = heff_dup(heff_rfield(v_g_240, 1));
        if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
          heff_drop_rec(v_g_240, 2);
          heff_drop(v_v_2442);
          heff_drop_cell(v_ru_24e1_242_24EReturn, 1);
          heff_drop(v_t_2445);
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eguardE_str4)}), v_sp_2444});
        } else {
          heff_drop(v_t_2445);
          V v_t_2446 = (g_heff_2esyntax_2epresyntax_2eguardE(v_g_240, v_v_2442));
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EReturn, TAG_EReturn, 1, (V[]){v_t_2446}), v_sp_2444});
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_ENest: {
      V v_c_2447 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24ENest = heff_take_reuse_n(v_e1_242, 1ULL, 1);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_2449 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_2450 = heff_dup(heff_rfield(v_g_240, 1));
        if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
          heff_drop_rec(v_g_240, 2);
          heff_drop(v_c_2447);
          heff_drop_cell(v_ru_24e1_242_24ENest, 1);
          heff_drop(v_t_2450);
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eguardE_str5)}), v_sp_2449});
        } else {
          heff_drop(v_t_2450);
          V v_t_2451 = (g_heff_2esyntax_2epresyntax_2eguardE(v_g_240, v_c_2447));
          return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ENest, TAG_ENest, 1, (V[]){v_t_2451}), v_sp_2449});
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_ELazy: {
      V v_body_2452 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24ELazy = heff_take_reuse_n(v_e1_242, 1ULL, 1);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_sp_2454 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24At = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_2455 = ({ V rv_1 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_g_240, 1ULL, 2, shape_muts__inLam, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2456 = (g_heff_2esyntax_2epresyntax_2eguardE(v_t_2455, v_body_2452));
        return heff_tag_at_n(v_ru_24e_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ELazy, TAG_ELazy, 1, (V[]){v_t_2456}), v_sp_2454});
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    default: {
      heff_drop(v_e1_242);
      V v_f_2457 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eguardE_clo), 1, (V[]){v_g_240}));
      HeffT2 v_t_2461 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eguardE_lam2, 2, 1, (V[]){v_f_2457}), NTAG(TAG_MkUnit), v_e_241));
      {
        V v_field_2462 = v_t_2461.f[0];
        V v_field_2463 = v_t_2461.f[1];
        V v_x_2464 = v_field_2462;
        heff_drop(v_x_2464);
        V v_y_2465 = v_field_2463;
        return v_y_2465;
      }
    }
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eguardE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eguardE(a[0], a[1]);
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_ss_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = (g_heff_2esyntax_2epresyntax_2edeclaredMuts(v_ss_2410));
  V v_x1_2415 = ({ V a_0 = v_x_2413; V a_1 = v_t_2414; V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, a_1)); heff_drop(v_x_2413); heff_drop(v_t_2414); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2415) == NTAG(TAG_True)));
  heff_drop(v_x1_2415);
  return v_ret_24bool;
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam1(V self, V *args) {
  V v_u_2420 = args[0];
  V v_c_2421 = args[1];
  V v_f_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_tr(heff_call(v_f_2418, 1, (V[]){v_c_2421}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2420, v_t_2422});
}
V g_heff_2esyntax_2epresyntax_2eguardE_lam2(V self, V *args) {
  V v_u_2458 = args[0];
  V v_c_2459 = args[1];
  V v_f_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2460 = heff_tr(heff_call(v_f_2457, 1, (V[]){v_c_2459}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_u_2458, v_t_2460});
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str0, 2, "v#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str1, 2, "v#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str2, 2, "v#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str3, 2, "v#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str4, 2, "v#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str5, 2, "v#");
V g_heff_2esyntax_2epresyntax_2eliftE_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V v_l_240, V v_acc_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_At: {
    V v_e1_243 = heff_dup(heff_field(v_e_242, 0));
    switch (heff_tag_of(v_e1_243)) {
    case TAG_ELam: {
      V v_b_245 = heff_field(v_e1_243, 0);
      V v_body_246 = heff_field(v_e1_243, 1);
      V v_ru_24e1_243_24ELam = heff_take_reuse_n(v_e1_243, 3ULL, 2);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_248 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        V v_t_249 = heff_get_n(heff_get_n(v_l_240, 1, 2), 0, 2);
        V v_t_2410 = heff_rec_n(2, shape_muts__inLam, (V[]){v_t_249, NTAG(TAG_True)});
        V v_t_2411 = (g_heff_2esyntax_2epresyntax_2eguardE(v_t_2410, v_body_246));
        V v_f_2412 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ELam, TAG_ELam, 2, (V[]){v_b_245, v_t_2411}), v_sp_248});
        return ((HeffT2){{v_acc_241, v_f_2412}});
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_EMatch: {
      V v_s_2413 = heff_field(v_e1_243, 0);
      V v_alts_2414 = heff_field(v_e1_243, 1);
      V v_ru_24e1_243_24EMatch = heff_take_reuse_n(v_e1_243, 3ULL, 2);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_2416 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        HeffT2 v_t_2417 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_dup(v_l_240), v_acc_241, v_s_2413));
        {
          V v_field_2418 = v_t_2417.f[0];
          V v_field_2419 = v_t_2417.f[1];
          V v_x_2420 = v_field_2418;
          V v_y_2421 = v_field_2419;
          V v_t_2422 = (g_list_2eany_24s717144537x1885076661(v_alts_2414));
          if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
            heff_drop(v_t_2422);
            V v_t_2423 = heff_intShow(heff_dup(heff_rfield(v_sp_2416, 0)));
            V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){heff_dup(v_l_240)}));
            V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2easAction_clo), 2, (V[]){v_t_2424, heff_get_n(v_l_240, 0, 2)}));
            V v_t_2426 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ealtBy_clo), 1, (V[]){v_t_2425}));
            V v_t_2427 = (g_list_2emap(v_t_2426, v_alts_2414));
            V v_t_2428 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24EMatch, TAG_EMatch, 2, (V[]){v_y_2421, v_t_2427}), heff_dup(v_sp_2416)});
            V v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str0), v_t_2423), v_t_2428});
            V v_f_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, v_x_2420});
            V v_t_2431 = heff_intShow(heff_dup(heff_rfield(v_sp_2416, 0)));
            V v_t_2432 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str1), v_t_2431)});
            V v_f_2433 = heff_tag_n(TAG_At, 2, (V[]){v_t_2432, v_sp_2416});
            return ((HeffT2){{v_f_2430, v_f_2433}});
          } else {
            heff_drop(v_t_2422);
            V v_f_2434 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
            HeffT2 v_t_2445 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eliftE_24cpr_lam0, 2, 1, (V[]){v_f_2434}), v_x_2420, v_alts_2414));
            {
              V v_field_2446 = v_t_2445.f[0];
              V v_field_2447 = v_t_2445.f[1];
              V v_x_2448 = v_field_2446;
              V v_y_2449 = v_field_2447;
              V v_t_2450 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24EMatch, TAG_EMatch, 2, (V[]){v_y_2421, v_y_2449}), v_sp_2416});
              return ((HeffT2){{v_x_2448, v_t_2450}});
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_2451 = heff_field(v_e1_243, 0);
      V v_e12_2452 = heff_field(v_e1_243, 1);
      V v_ru_24e1_243_24ELetIn = heff_take_reuse_n(v_e1_243, 3ULL, 2);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_2454 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        switch (heff_tag_of(v_e12_2452)) {
        case TAG_At: {
          V v_e121_2455 = heff_field(v_e12_2452, 0);
          V v_asp_2456 = heff_field(v_e12_2452, 1);
          V v_ru_24e12_2452_24At = heff_take_reuse_n(v_e12_2452, 3ULL, 2);
          switch (heff_tag_of(v_e121_2455)) {
          case TAG_MkAlt: {
            V v_p_2457 = heff_field(v_e121_2455, 0);
            V v_body_2458 = heff_field(v_e121_2455, 1);
            V v_ru_24e121_2455_24MkAlt = heff_take_reuse_n(v_e121_2455, 3ULL, 2);
            HeffT2 v_t_2459 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_dup(v_l_240), v_acc_241, v_rhs_2451));
            {
              V v_field_2460 = v_t_2459.f[0];
              V v_field_2461 = v_t_2459.f[1];
              V v_x_2462 = v_field_2460;
              V v_y_2463 = v_field_2461;
              V v_t_2493;
              switch (heff_tag_of(v_body_2458)) {
              case TAG_At: {
                V v_e1_2464 = heff_dup(heff_field(v_body_2458, 0));
                switch (heff_tag_of(v_e1_2464)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_2464, 0ULL, 2);
                  switch (heff_tag_of(v_body_2458)) {
                  case TAG_At: {
                    v_t_2493 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_body_2458);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_2464, 0ULL, 1);
                  switch (heff_tag_of(v_body_2458)) {
                  case TAG_At: {
                    v_t_2493 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_body_2458);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_2464, 0ULL, 1);
                  switch (heff_tag_of(v_body_2458)) {
                  case TAG_At: {
                    v_t_2493 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_body_2458);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_2464, 0ULL, 1);
                  switch (heff_tag_of(v_body_2458)) {
                  case TAG_At: {
                    v_t_2493 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_body_2458);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_2464, 0ULL, 1);
                  switch (heff_tag_of(v_body_2458)) {
                  case TAG_At: {
                    v_t_2493 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_body_2458);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_2464, 0ULL, 4);
                  switch (heff_tag_of(v_body_2458)) {
                  case TAG_At: {
                    v_t_2493 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_body_2458);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_2464);
                  HeffT2 v_t_2488 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_body_2458)));
                  {
                    V v_field_2489 = v_t_2488.f[0];
                    V v_field_2490 = v_t_2488.f[1];
                    V v_x_2491 = v_field_2489;
                    V v_y_2492 = v_field_2490;
                    heff_drop(v_y_2492);
                    v_t_2493 = v_x_2491;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_body_2458);
              }
              if ((heff_dup(v_t_2493) == NTAG(TAG_True))) {
                heff_drop(v_t_2493);
                V v_t_2494 = heff_intShow(heff_dup(heff_rfield(v_sp_2454, 0)));
                V v_lift_2495 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){heff_dup(v_l_240)}));
                V v_cx_2496 = heff_get_n(v_l_240, 0, 2);
                V v_x1_2497 = heff_tr(heff_call(v_lift_2495, 2, (V[]){NTAG(TAG_Nil), v_body_2458}));
                V v_t_24107;
                switch (heff_tag_of(v_x1_2497)) {
                case TAG_MkPair: {
                  V v_x_2498 = heff_field(v_x1_2497, 0);
                  V v_y_2499 = heff_field(v_x1_2497, 1);
                  V v_ru_24x1_2497_24MkPair = heff_take_reuse_n(v_x1_2497, 3ULL, 2);
                  V v_t_24100 = heff_get_n(heff_dup(heff_rfield(v_cx_2496, 0)), 1, 3);
                  V v_t_24103;
                  switch (heff_tag_of(v_y_2499)) {
                  case TAG_At: {
                    V v_s_24102 = heff_dup(heff_field(v_y_2499, 1));
                    v_t_24103 = v_s_24102;
                    break;
                  }
                  default: heff_nomatch(v_y_2499);
                  }
                  V v_t_24104 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_24100}), v_t_24103});
                  V v_t_24105 = heff_tag_at_n(v_ru_24x1_2497_24MkPair, TAG_Cons, 2, (V[]){v_y_2499, NTAG(TAG_Nil)});
                  V v_t_24106 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24104, v_t_24105));
                  v_t_24107 = ({ V a_0 = v_cx_2496; V a_1 = v_x_2498; V a_2 = v_t_24106; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2498); r_; });
                  break;
                }
                default: heff_nomatch(v_x1_2497);
                }
                V v_t_24108 = heff_tag_at_n(v_ru_24e12_2452_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e121_2455_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_2457, v_t_24107}), v_asp_2456});
                V v_t_24109 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ELetIn, TAG_ELetIn, 2, (V[]){v_y_2463, v_t_24108}), heff_dup(v_sp_2454)});
                V v_t_24110 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str2), v_t_2494), v_t_24109});
                V v_f_24111 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24110, v_x_2462});
                V v_t_24112 = heff_intShow(heff_dup(heff_rfield(v_sp_2454, 0)));
                V v_t_24113 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str3), v_t_24112)});
                V v_f_24114 = heff_tag_n(TAG_At, 2, (V[]){v_t_24113, v_sp_2454});
                return ((HeffT2){{v_f_24111, v_f_24114}});
              } else {
                heff_drop(v_t_2493);
                HeffT2 v_t_24115 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(v_l_240, v_x_2462, v_body_2458));
                {
                  V v_field_24116 = v_t_24115.f[0];
                  V v_field_24117 = v_t_24115.f[1];
                  V v_x_24118 = v_field_24116;
                  V v_y_24119 = v_field_24117;
                  V v_t_24120 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e121_2455_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_2457, v_y_24119}), v_asp_2456});
                  V v_t_24121 = heff_tag_at_n(v_ru_24e12_2452_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ELetIn, TAG_ELetIn, 2, (V[]){v_y_2463, v_t_24120}), v_sp_2454});
                  return ((HeffT2){{v_x_24118, v_t_24121}});
                }
              }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_e121_2455)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_e12_2452)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24122 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24EDo = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_24124 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        V v_t_24125 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24EDo, TAG_EDo, 1, (V[]){v_ss_24122}), v_sp_24124});
        V v_f_24126 = (g_heff_2esyntax_2epresyntax_2eguardE(heff_get_n(v_l_240, 1, 2), v_t_24125));
        return ((HeffT2){{v_acc_241, v_f_24126}});
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_ENest: {
      V v_c_24127 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24ENest = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_24129 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        HeffT2 v_t_24130 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(v_l_240, v_acc_241, v_c_24127));
        {
          V v_field_24131 = v_t_24130.f[0];
          V v_field_24132 = v_t_24130.f[1];
          V v_x_24133 = v_field_24131;
          V v_y_24134 = v_field_24132;
          V v_t_24135 = heff_intShow(heff_dup(heff_rfield(v_sp_24129, 0)));
          V v_t_24136 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str4), v_t_24135), v_y_24134});
          V v_f_24137 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24136, v_x_24133});
          V v_t_24138 = heff_intShow(heff_dup(heff_rfield(v_sp_24129, 0)));
          V v_t_24139 = heff_tag_at_n(v_ru_24e1_243_24ENest, TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eliftE_24cpr_str5), v_t_24138)});
          V v_f_24140 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){v_t_24139, v_sp_24129});
          return ((HeffT2){{v_f_24137, v_f_24140}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_ELazy: {
      V v_body_24141 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24ELazy = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_24143 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        V v_t_24144 = heff_get_n(heff_get_n(v_l_240, 1, 2), 0, 2);
        V v_t_24145 = heff_rec_n(2, shape_muts__inLam, (V[]){v_t_24144, NTAG(TAG_True)});
        V v_t_24146 = (g_heff_2esyntax_2epresyntax_2eguardE(v_t_24145, v_body_24141));
        V v_f_24147 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ELazy, TAG_ELazy, 1, (V[]){v_t_24146}), v_sp_24143});
        return ((HeffT2){{v_acc_241, v_f_24147}});
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_ETry: {
      V v_tr_24148 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24ETry = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      heff_drop_rec(v_l_240, 2);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_24150 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        V v_t_24151 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24ETry, TAG_ETry, 1, (V[]){v_tr_24148}), v_sp_24150});
        return ((HeffT2){{v_acc_241, v_t_24151}});
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    case TAG_EWith: {
      V v_w_24152 = heff_field(v_e1_243, 0);
      V v_x_24153 = heff_field(v_e1_243, 1);
      V v_xsp_24154 = heff_field(v_e1_243, 2);
      V v_body_24155 = heff_field(v_e1_243, 3);
      V v_ru_24e1_243_24EWith = heff_take_reuse_n(v_e1_243, 15ULL, 4);
      heff_drop_rec(v_l_240, 2);
      switch (heff_tag_of(v_e_242)) {
      case TAG_At: {
        V v_sp_24157 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24At = heff_take_reuse_n(v_e_242, 2ULL, 2);
        V v_t_24158 = heff_tag_at_n(v_ru_24e_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24EWith, TAG_EWith, 4, (V[]){v_w_24152, v_x_24153, v_xsp_24154, v_body_24155}), v_sp_24157});
        return ((HeffT2){{v_acc_241, v_t_24158}});
      }
      default: return ((HeffT2){{heff_nomatch(v_e_242)}});
      }
    }
    default: {
      heff_drop(v_e1_243);
      V v_t_24159 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eliftE_clo), 1, (V[]){v_l_240}));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(v_t_24159, v_acc_241, v_e_242);
    }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}
V g_heff_2esyntax_2epresyntax_2eliftE_24cpr_lam0(V self, V *args) {
  V v_st_2435 = args[0];
  V v_x3_2436 = args[1];
  V v_f_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2436)) {
  case TAG_At: {
    V v_x31_2437 = heff_field(v_x3_2436, 0);
    V v_sp_2438 = heff_field(v_x3_2436, 1);
    V v_ru_24x3_2436_24At = heff_take_reuse_n(v_x3_2436, 3ULL, 2);
    switch (heff_tag_of(v_x31_2437)) {
    case TAG_MkAlt: {
      V v_p_2439 = heff_field(v_x31_2437, 0);
      V v_e_2440 = heff_field(v_x31_2437, 1);
      V v_ru_24x31_2437_24MkAlt = heff_take_reuse_n(v_x31_2437, 3ULL, 2);
      V v_x1_2441 = heff_tr(heff_call(v_f_2434, 2, (V[]){v_st_2435, v_e_2440}));
      switch (heff_tag_of(v_x1_2441)) {
      case TAG_MkPair: {
        V v_x_2442 = heff_field(v_x1_2441, 0);
        V v_y_2443 = heff_field(v_x1_2441, 1);
        V v_ru_24x1_2441_24MkPair = heff_take_reuse_n(v_x1_2441, 3ULL, 2);
        V v_t_2444 = heff_tag_at_n(v_ru_24x3_2436_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_2437_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_2439, v_y_2443}), v_sp_2438});
        return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){v_x_2442, v_t_2444});
      }
      default: return heff_nomatch(v_x1_2441);
      }
    }
    default: return heff_nomatch(v_x31_2437);
    }
  }
  default: return heff_nomatch(v_x3_2436);
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s605646493x1315728604_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24SetPath = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_a_2422;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2422 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_247)) {
          case TAG_At: {
            V v_a_248 = heff_dup(heff_field(v_a_247, 0));
            switch (heff_tag_of(v_a_248)) {
            case TAG_ELam: {
              heff_take_n(v_a_248, 0ULL, 2);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2422 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2422 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            default: {
              heff_drop(v_a_248);
              HeffT2 v_t_2417 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_a_247)));
              {
                V v_field_2418 = v_t_2417.f[0];
                V v_field_2419 = v_t_2417.f[1];
                V v_a_2420 = v_field_2418;
                V v_a_2421 = v_field_2419;
                heff_drop(v_a_2421);
                v_a_2422 = v_a_2420;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_247);
          }
        }
        HeffT2 v_t_2423 = (g_heff_2esyntax_2epresyntax_2eaccList_24s605646493x1315728604_24cpr(v_a_2422, v_xs_243));
        {
          V v_field_2424 = v_t_2423.f[0];
          V v_field_2425 = v_t_2423.f[1];
          V v_x_2426 = v_field_2424;
          V v_y_2427 = v_field_2425;
          V v_t_2428 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a_244_24SetPath, TAG_SetPath, 2, (V[]){v_a_246, v_a_247}), v_a_245});
          return ((HeffT2){{v_x_2426, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2428, v_y_2427})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s42976669x698242400_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24SetPath = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_a_248;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_248 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_a_248 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_247)));
        }
        HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2eaccList_24s42976669x698242400_24cpr(v_a_248, v_xs_243));
        {
          V v_field_2410 = v_t_249.f[0];
          V v_field_2411 = v_t_249.f[1];
          V v_x_2412 = v_field_2410;
          V v_y_2413 = v_field_2411;
          V v_t_2414 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a_244_24SetPath, TAG_SetPath, 2, (V[]){v_a_246, v_a_247}), v_a_245});
          return ((HeffT2){{v_x_2412, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2414, v_y_2413})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s122821685x1786755984_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24MkAlt = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_a_248;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_248 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_a_248 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_247)));
        }
        HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2eaccList_24s122821685x1786755984_24cpr(v_a_248, v_xs_243));
        {
          V v_field_2410 = v_t_249.f[0];
          V v_field_2411 = v_t_249.f[1];
          V v_x_2412 = v_field_2410;
          V v_y_2413 = v_field_2411;
          V v_t_2414 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a_244_24MkAlt, TAG_MkAlt, 2, (V[]){v_a_246, v_a_247}), v_a_245});
          return ((HeffT2){{v_x_2412, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2414, v_y_2413})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_dup(heff_field(v_x3_241, 0));
    switch (heff_tag_of(v_x31_242)) {
    case TAG_EVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ENotationVar: {
      heff_take_n(v_x31_242, 0ULL, 3);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EFloat: {
      heff_take_nf(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EString: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EBinary: {
      V v_segs_2413 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EBinary = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2415 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_2416 = (g_heff_2esyntax_2epresyntax_2eaccList_24s320198774x1124344602_24cpr(v_st_240, v_segs_2413));
        {
          V v_field_2417 = v_t_2416.f[0];
          V v_field_2418 = v_t_2416.f[1];
          V v_x_2419 = v_field_2417;
          V v_y_2420 = v_field_2418;
          V v_t_2421 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EBinary, TAG_EBinary, 1, (V[]){v_y_2420}), v_sp_2415});
          return ((HeffT2){{v_x_2419, v_t_2421}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ERune: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EWord: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EApp: {
      V v_h_2424 = heff_field(v_x31_242, 0);
      V v_args_2425 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EApp = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2427 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2428;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2428 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2428 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_h_2424)));
        }
        HeffT2 v_t_2429 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1871252431x1455926961_24cpr(v_x_2428, v_args_2425));
        {
          V v_field_2430 = v_t_2429.f[0];
          V v_field_2431 = v_t_2429.f[1];
          V v_x_2432 = v_field_2430;
          V v_y_2433 = v_field_2431;
          V v_t_2434 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EApp, TAG_EApp, 2, (V[]){v_h_2424, v_y_2433}), v_sp_2427});
          return ((HeffT2){{v_x_2432, v_t_2434}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EProject: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ENamed: {
      V v_x_2436 = heff_field(v_x31_242, 0);
      V v_e_2437 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ENamed = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2439 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2440;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2440 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2440 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_2437)));
        }
        V v_t_2441 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ENamed, TAG_ENamed, 2, (V[]){v_x_2436, v_e_2437}), v_sp_2439});
        return ((HeffT2){{v_x_2440, v_t_2441}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EPi: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ELam: {
      V v_b_2444 = heff_field(v_x31_242, 0);
      V v_body_2445 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELam = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2447 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2448;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2448 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2448 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_body_2445)));
        }
        V v_t_2449 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELam, TAG_ELam, 2, (V[]){v_b_2444, v_body_2445}), v_sp_2447});
        return ((HeffT2){{v_x_2448, v_t_2449}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EAnn: {
      V v_e_2450 = heff_field(v_x31_242, 0);
      V v_t_2451 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EAnn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2453 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2454;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2454 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2454 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_2450)));
        }
        V v_t_2455 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EAnn, TAG_EAnn, 2, (V[]){v_e_2450, v_t_2451}), v_sp_2453});
        return ((HeffT2){{v_x_2454, v_t_2455}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESpec: {
      V v_a_2456 = heff_field(v_x31_242, 0);
      V v_x_2457 = heff_field(v_x31_242, 1);
      V v_xsp_2458 = heff_field(v_x31_242, 2);
      V v_v_2459 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24ESpec = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2461 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          V v_t_2462 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_2456, v_x_2457, v_xsp_2458, v_v_2459}), v_sp_2461});
          return ((HeffT2){{NTAG(TAG_True), v_t_2462}});
        } else {
          heff_drop(v_st_240);
          V v_x_2463 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_2456)));
          V v_x_2464;
          if ((heff_dup(v_x_2463) == NTAG(TAG_True))) {
            heff_drop(v_x_2463);
            v_x_2464 = NTAG(TAG_True);
          } else {
            heff_drop(v_x_2463);
            v_x_2464 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_v_2459)));
          }
          V v_t_2465 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_2456, v_x_2457, v_xsp_2458, v_v_2459}), v_sp_2461});
          return ((HeffT2){{v_x_2464, v_t_2465}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESig: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ESum: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EStruct: {
      V v_fs_2468 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EStruct = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2470 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_2471 = (g_heff_2esyntax_2epresyntax_2eaccList_24s386636727x1203660589_24cpr(v_st_240, v_fs_2468));
        {
          V v_field_2472 = v_t_2471.f[0];
          V v_field_2473 = v_t_2471.f[1];
          V v_x_2474 = v_field_2472;
          V v_y_2475 = v_field_2473;
          V v_t_2476 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EStruct, TAG_EStruct, 1, (V[]){v_y_2475}), v_sp_2470});
          return ((HeffT2){{v_x_2474, v_t_2476}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EUpdate: {
      V v_a_2477 = heff_field(v_x31_242, 0);
      V v_fs_2478 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EUpdate = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2480 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2481;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2481 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2481 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_2477)));
        }
        HeffT2 v_t_2482 = (g_heff_2esyntax_2epresyntax_2eaccList_24s42976669x698242400_24cpr(v_x_2481, v_fs_2478));
        {
          V v_field_2483 = v_t_2482.f[0];
          V v_field_2484 = v_t_2482.f[1];
          V v_x_2485 = v_field_2483;
          V v_y_2486 = v_field_2484;
          V v_t_2487 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EUpdate, TAG_EUpdate, 2, (V[]){v_a_2477, v_y_2486}), v_sp_2480});
          return ((HeffT2){{v_x_2485, v_t_2487}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EMatch: {
      V v_s_2488 = heff_field(v_x31_242, 0);
      V v_alts_2489 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EMatch = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2491 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2492;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2492 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2492 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_s_2488)));
        }
        HeffT2 v_t_2493 = (g_heff_2esyntax_2epresyntax_2eaccList_24s122821685x1786755984_24cpr(v_x_2492, v_alts_2489));
        {
          V v_field_2494 = v_t_2493.f[0];
          V v_field_2495 = v_t_2493.f[1];
          V v_x_2496 = v_field_2494;
          V v_y_2497 = v_field_2495;
          V v_t_2498 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_2488, v_y_2497}), v_sp_2491});
          return ((HeffT2){{v_x_2496, v_t_2498}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_2499 = heff_field(v_x31_242, 0);
      V v_a_24100 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELetIn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24102 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_24100)) {
          case TAG_At: {
            V v_x31_24103 = heff_field(v_a_24100, 0);
            V v_sp_24104 = heff_field(v_a_24100, 1);
            V v_ru_24a_24100_24At = heff_take_reuse_n(v_a_24100, 3ULL, 2);
            switch (heff_tag_of(v_x31_24103)) {
            case TAG_MkAlt: {
              V v_p_24105 = heff_field(v_x31_24103, 0);
              V v_e_24106 = heff_field(v_x31_24103, 1);
              V v_ru_24x31_24103_24MkAlt = heff_take_reuse_n(v_x31_24103, 3ULL, 2);
              V v_t_24107 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_24103_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_24105, v_e_24106}), v_sp_24104});
              V v_t_24108 = heff_tag_at_n(v_ru_24a_24100_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, (V[]){v_rhs_2499, v_t_24107}), v_sp_24102});
              return ((HeffT2){{NTAG(TAG_True), v_t_24108}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_24103)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_24100)}});
          }
        } else {
          heff_drop(v_st_240);
          V v_x_24109 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_rhs_2499)));
          switch (heff_tag_of(v_a_24100)) {
          case TAG_At: {
            V v_x31_24110 = heff_field(v_a_24100, 0);
            V v_sp_24111 = heff_field(v_a_24100, 1);
            V v_ru_24a_24100_24At = heff_take_reuse_n(v_a_24100, 3ULL, 2);
            switch (heff_tag_of(v_x31_24110)) {
            case TAG_MkAlt: {
              V v_p_24112 = heff_field(v_x31_24110, 0);
              V v_e_24113 = heff_field(v_x31_24110, 1);
              V v_ru_24x31_24110_24MkAlt = heff_take_reuse_n(v_x31_24110, 3ULL, 2);
              V v_x_24114;
              if ((heff_dup(v_x_24109) == NTAG(TAG_True))) {
                heff_drop(v_x_24109);
                v_x_24114 = NTAG(TAG_True);
              } else {
                heff_drop(v_x_24109);
                v_x_24114 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_24113)));
              }
              V v_t_24115 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_24110_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_24112, v_e_24113}), v_sp_24111});
              V v_t_24116 = heff_tag_at_n(v_ru_24a_24100_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, (V[]){v_rhs_2499, v_t_24115}), v_sp_24102});
              return ((HeffT2){{v_x_24114, v_t_24116}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_24110)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_24100)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24117 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EDo = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24119 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24120 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_st_240, v_ss_24117));
        {
          V v_field_24121 = v_t_24120.f[0];
          V v_field_24122 = v_t_24120.f[1];
          V v_x_24123 = v_field_24121;
          V v_y_24124 = v_field_24122;
          V v_t_24125 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EDo, TAG_EDo, 1, (V[]){v_y_24124}), v_sp_24119});
          return ((HeffT2){{v_x_24123, v_t_24125}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EAssign: {
      V v_x_24129 = heff_field(v_x31_242, 0);
      V v_xsp_24130 = heff_field(v_x31_242, 1);
      V v_e_24131 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EAssign = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24133 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24134;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24134 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24134 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_24131)));
        }
        V v_t_24135 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EAssign, TAG_EAssign, 3, (V[]){v_x_24129, v_xsp_24130, v_e_24131}), v_sp_24133});
        return ((HeffT2){{v_x_24134, v_t_24135}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWhile: {
      V v_c_24136 = heff_field(v_x31_242, 0);
      V v_body_24137 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EWhile = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24139 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24140;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24140 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24140 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_c_24136)));
        }
        HeffT2 v_t_24141 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_x_24140, v_body_24137));
        {
          V v_field_24142 = v_t_24141.f[0];
          V v_field_24143 = v_t_24141.f[1];
          V v_x_24144 = v_field_24142;
          V v_y_24145 = v_field_24143;
          V v_t_24146 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EWhile, TAG_EWhile, 2, (V[]){v_c_24136, v_y_24145}), v_sp_24139});
          return ((HeffT2){{v_x_24144, v_t_24146}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EFor: {
      V v_p_24147 = heff_field(v_x31_242, 0);
      V v_c_24148 = heff_field(v_x31_242, 1);
      V v_body_24149 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EFor = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24151 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24152;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24152 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24152 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_c_24148)));
        }
        HeffT2 v_t_24153 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_x_24152, v_body_24149));
        {
          V v_field_24154 = v_t_24153.f[0];
          V v_field_24155 = v_t_24153.f[1];
          V v_x_24156 = v_field_24154;
          V v_y_24157 = v_field_24155;
          V v_t_24158 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EFor, TAG_EFor, 3, (V[]){v_p_24147, v_c_24148, v_y_24157}), v_sp_24151});
          return ((HeffT2){{v_x_24156, v_t_24158}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EIfThen: {
      V v_c_24159 = heff_field(v_x31_242, 0);
      V v_a_24160 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EIfThen = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24162 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          V v_t_24163 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24159, v_a_24160}), v_sp_24162});
          return ((HeffT2){{NTAG(TAG_True), v_t_24163}});
        } else {
          heff_drop(v_st_240);
          V v_x_24164 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_c_24159)));
          V v_x_24165;
          if ((heff_dup(v_x_24164) == NTAG(TAG_True))) {
            heff_drop(v_x_24164);
            v_x_24165 = NTAG(TAG_True);
          } else {
            heff_drop(v_x_24164);
            v_x_24165 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_24160)));
          }
          V v_t_24166 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24159, v_a_24160}), v_sp_24162});
          return ((HeffT2){{v_x_24165, v_t_24166}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EBreak: {
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EContinue: {
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EReturn: {
      V v_e_24167 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EReturn = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24169 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24170;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24170 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24170 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_24167)));
        }
        V v_t_24171 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EReturn, TAG_EReturn, 1, (V[]){v_e_24167}), v_sp_24169});
        return ((HeffT2){{v_x_24170, v_t_24171}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ENest: {
      V v_e_24172 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ENest = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24174 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24175;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24175 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24175 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_24172)));
        }
        V v_t_24176 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ENest, TAG_ENest, 1, (V[]){v_e_24172}), v_sp_24174});
        return ((HeffT2){{v_x_24175, v_t_24176}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELazy: {
      V v_e_24177 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ELazy = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24179 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24180;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24180 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24180 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_24177)));
        }
        V v_t_24181 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELazy, TAG_ELazy, 1, (V[]){v_e_24177}), v_sp_24179});
        return ((HeffT2){{v_x_24180, v_t_24181}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETuple: {
      V v_es_24182 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETuple = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24184 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24185 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1871252431x1455926961_24cpr(v_st_240, v_es_24182));
        {
          V v_field_24186 = v_t_24185.f[0];
          V v_field_24187 = v_t_24185.f[1];
          V v_x_24188 = v_field_24186;
          V v_y_24189 = v_field_24187;
          V v_t_24190 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETuple, TAG_ETuple, 1, (V[]){v_y_24189}), v_sp_24184});
          return ((HeffT2){{v_x_24188, v_t_24190}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETry: {
      V v_tr_24191 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETry = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24193 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        switch (heff_tag_of(v_tr_24191)) {
        case TAG_MkTry: {
          V v_err_24194 = heff_field(v_tr_24191, 0);
          V v_body_24195 = heff_field(v_tr_24191, 1);
          V v_c_24196 = heff_field(v_tr_24191, 2);
          V v_ru_24tr_24191_24MkTry = heff_take_reuse_n(v_tr_24191, 7ULL, 3);
          HeffT2 v_t_24197 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_st_240, v_body_24195));
          {
            V v_field_24198 = v_t_24197.f[0];
            V v_field_24199 = v_t_24197.f[1];
            V v_x_24200 = v_field_24198;
            V v_y_24201 = v_field_24199;
            switch (heff_tag_of(v_c_24196)) {
            case TAG_MkCatchArm: {
              V v_b_24202 = heff_field(v_c_24196, 0);
              V v_ss_24203 = heff_field(v_c_24196, 1);
              V v_ru_24c_24196_24MkCatchArm = heff_take_reuse_n(v_c_24196, 3ULL, 2);
              HeffT2 v_t_24204 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_x_24200, v_ss_24203));
              {
                V v_field_24205 = v_t_24204.f[0];
                V v_field_24206 = v_t_24204.f[1];
                V v_x_24207 = v_field_24205;
                V v_y_24208 = v_field_24206;
                V v_t_24209 = heff_tag_at_n(v_ru_24tr_24191_24MkTry, TAG_MkTry, 3, (V[]){v_err_24194, v_y_24201, heff_tag_at_n(v_ru_24c_24196_24MkCatchArm, TAG_MkCatchArm, 2, (V[]){v_b_24202, v_y_24208})});
                V v_t_24210 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETry, TAG_ETry, 1, (V[]){v_t_24209}), v_sp_24193});
                return ((HeffT2){{v_x_24207, v_t_24210}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_c_24196)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_tr_24191)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWith: {
      V v_w_24211 = heff_field(v_x31_242, 0);
      V v_x_24212 = heff_field(v_x31_242, 1);
      V v_xsp_24213 = heff_field(v_x31_242, 2);
      V v_body_24214 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24EWith = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24216 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24217;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24217 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24217 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_w_24211)));
        }
        HeffT2 v_t_24218 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_x_24217, v_body_24214));
        {
          V v_field_24219 = v_t_24218.f[0];
          V v_field_24220 = v_t_24218.f[1];
          V v_x_24221 = v_field_24219;
          V v_y_24222 = v_field_24220;
          V v_t_24223 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EWith, TAG_EWith, 4, (V[]){v_w_24211, v_x_24212, v_xsp_24213, v_y_24222}), v_sp_24216});
          return ((HeffT2){{v_x_24221, v_t_24223}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackMatch_str0, 6, "MkPair");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackMatch_str1, 6, "MkPair");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackMatch_str2, 6, "MkPair");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackMatch_str3, 6, "MkPair");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackMatch_str4, 6, "MkPair");
Clo g_heff_2esyntax_2epresyntax_2egiveBackMatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2egiveBackMatch_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2egiveBackMatch(V v_sp_240, V v_r_241, V v_x3_242, V v_body_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_sp_240, 2);
    heff_drop(v_r_241);
    return v_body_243;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_x32_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x32_245)) {
    case TAG_Nil: {
      V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_244}), heff_dup(v_sp_240)});
      V v_t_247 = (g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240(heff_dup(v_sp_240), v_x32_245));
      V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_t_247}), heff_dup(v_sp_240)});
      V v_t_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
      V v_ps_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_249});
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egiveBackMatch_str0)}), heff_dup(v_sp_240)});
      V v_x1_2412 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2411, v_ps_2410));
      V v_t_2415;
      switch (heff_tag_of(v_x1_2412)) {
      case TAG_At: {
        V v_s_2414 = heff_field(v_x1_2412, 1);
        heff_take_n(v_x1_2412, 2ULL, 2);
        v_t_2415 = v_s_2414;
        break;
      }
      default: heff_nomatch(v_x1_2412);
      }
      V v_t_2416 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2415, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2417 = (g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_240(heff_dup(v_sp_240), v_x32_245));
      V v_e_2418 = (g_heff_2esyntax_2epresyntax_2egiveBackMatch(heff_dup(v_sp_240), v_t_2417, v_x32_245, v_body_243));
      V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egiveBackMatch_str1), heff_dup(v_sp_240), v_ps_2410}), heff_dup(v_t_2416)});
      V v_t_2422;
      switch (heff_tag_of(v_e_2418)) {
      case TAG_At: {
        V v_s_2421 = heff_dup(heff_field(v_e_2418, 1));
        v_t_2422 = v_s_2421;
        break;
      }
      default: heff_nomatch(v_e_2418);
      }
      V v_t_2423 = ({ V rv_1 = heff_get_n(v_t_2422, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2416, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2419, v_e_2418}), v_t_2423});
      V v_alts_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
      V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_r_241}), heff_dup(v_sp_240)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2426, v_alts_2425}), v_sp_240});
    }
    case TAG_Cons: {
      V v_x322_2428 = heff_dup(heff_field(v_x32_245, 1));
      switch (heff_tag_of(v_x322_2428)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_x32_245)) {
        case TAG_Cons: {
          V v_y_2429 = heff_field(v_x32_245, 0);
          V v_ru_24x32_245_24Cons = heff_take_reuse_n(v_x32_245, 1ULL, 2);
          V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_r_241}), heff_dup(v_sp_240)});
          V v_t_2432 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_240, 0)), heff_dup(heff_rfield(v_sp_240, 1))});
          V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_244}), heff_dup(v_sp_240)});
          V v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_y_2429}), heff_dup(v_sp_240)});
          V v_t_2435 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2434, NTAG(TAG_Nil)});
          V v_t_2436 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egiveBackMatch_str2), heff_dup(v_sp_240), heff_tag_at_n(v_ru_24x32_245_24Cons, TAG_Cons, 2, (V[]){v_t_2433, v_t_2435})});
          V v_p_2437 = heff_tag_n(TAG_At, 2, (V[]){v_t_2436, v_t_2432});
          V v_t_2440;
          switch (heff_tag_of(v_p_2437)) {
          case TAG_At: {
            V v_s_2439 = heff_dup(heff_field(v_p_2437, 1));
            v_t_2440 = v_s_2439;
            break;
          }
          default: heff_nomatch(v_p_2437);
          }
          V v_t_2443;
          switch (heff_tag_of(v_body_243)) {
          case TAG_At: {
            V v_s_2442 = heff_dup(heff_field(v_body_243, 1));
            v_t_2443 = v_s_2442;
            break;
          }
          default: heff_nomatch(v_body_243);
          }
          V v_t_2444 = ({ V rv_1 = heff_get_n(v_t_2443, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2440, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2437, v_body_243}), v_t_2444});
          V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, NTAG(TAG_Nil)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2431, v_t_2446}), v_sp_240});
        }
        default: return heff_nomatch(v_x32_245);
        }
      }
      case TAG_Cons: {
        V v_ru_24x322_2428_24Cons = heff_take_reuse_n(v_x322_2428, 0ULL, 2);
        V v_t_2449 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_244}), heff_dup(v_sp_240)});
        V v_t_2450 = (g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241(heff_dup(v_sp_240), v_x32_245));
        V v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_t_2450}), heff_dup(v_sp_240)});
        V v_t_2452 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
        V v_ps_2453 = heff_tag_at_n(v_ru_24x322_2428_24Cons, TAG_Cons, 2, (V[]){v_t_2449, v_t_2452});
        V v_t_2454 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egiveBackMatch_str3)}), heff_dup(v_sp_240)});
        V v_x1_2455 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2454, v_ps_2453));
        V v_t_2458;
        switch (heff_tag_of(v_x1_2455)) {
        case TAG_At: {
          V v_s_2457 = heff_field(v_x1_2455, 1);
          heff_take_n(v_x1_2455, 2ULL, 2);
          v_t_2458 = v_s_2457;
          break;
        }
        default: heff_nomatch(v_x1_2455);
        }
        V v_t_2459 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2458, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_t_2460 = (g_heff_2esyntax_2epresyntax_2egiveBackMatch_2erest_241(heff_dup(v_sp_240), v_x32_245));
        V v_e_2461 = (g_heff_2esyntax_2epresyntax_2egiveBackMatch(heff_dup(v_sp_240), v_t_2460, v_x32_245, v_body_243));
        V v_t_2462 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egiveBackMatch_str4), heff_dup(v_sp_240), v_ps_2453}), heff_dup(v_t_2459)});
        V v_t_2465;
        switch (heff_tag_of(v_e_2461)) {
        case TAG_At: {
          V v_s_2464 = heff_dup(heff_field(v_e_2461, 1));
          v_t_2465 = v_s_2464;
          break;
        }
        default: heff_nomatch(v_e_2461);
        }
        V v_t_2466 = ({ V rv_1 = heff_get_n(v_t_2465, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2459, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2467 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2462, v_e_2461}), v_t_2466});
        V v_alts_2468 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
        V v_t_2469 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_r_241}), heff_dup(v_sp_240)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2469, v_alts_2468}), v_sp_240});
      }
      default: return heff_nomatch(v_x322_2428);
      }
    }
    default: return heff_nomatch(v_x32_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2egiveBackMatch(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str3, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str4, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str5, 85, "what a `catch` arm hears is its argument: `catch x -> ...`, or `catch (x : T) -> ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str6, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str7, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str9, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str10, 7, " := e`)");
V g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_lam1(V self, V *args);

HeffT3 g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr(V v_cx_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkCatchArm: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24MkCatchArm = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_LamName: {
      V v_t_2413;
      switch (heff_tag_of(v_x21_242)) {
      case TAG_LamName: {
        V v_x_246 = heff_dup(heff_field(v_x21_242, 0));
        if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str0), 2)) {
          heff_drop_cell(v_ru_24x2_241_24MkCatchArm, 2);
          heff_drop(v_x_246);
          v_t_2413 = NTAG(TAG_Nil);
        } else {
          v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_x_246, NTAG(TAG_Nil)});
        }
        break;
      }
      case TAG_LamImplicit: {
        V v_x_248 = heff_dup(heff_field(v_x21_242, 0));
        v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_x_248, NTAG(TAG_Nil)});
        break;
      }
      case TAG_LamAnn: {
        V v_x_2410 = heff_dup(heff_field(v_x21_242, 0));
        if (heff_strEq_c_lent(v_x_2410, ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str1), 2)) {
          heff_drop_cell(v_ru_24x2_241_24MkCatchArm, 2);
          heff_drop(v_x_2410);
          v_t_2413 = NTAG(TAG_Nil);
        } else {
          v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_x_2410, NTAG(TAG_Nil)});
        }
        break;
      }
      default: heff_nomatch(v_x21_242);
      }
      HeffT2 v_t_2415 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_lam0, 1, 1, (V[]){v_cx_240}); V a_1 = v_t_2413; HeffT2 r_ = (g_list_2efind_24cpr(a_0, a_1)); heff_drop(v_t_2413); r_; });
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_x_2418 = v_field_2417;
          V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str2), heff_dup(v_x_2418)), ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str3));
          V v_f_2420 = heff_strAppend(heff_strAppend(v_t_2419, v_x_2418), ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str4));
          V v_f_2428;
          switch (heff_tag_of(v_x21_242)) {
          case TAG_LamName: {
            V v_sp_2422 = heff_field(v_x21_242, 1);
            heff_take_n(v_x21_242, 2ULL, 2);
            v_f_2428 = v_sp_2422;
            break;
          }
          case TAG_LamImplicit: {
            V v_sp_2424 = heff_field(v_x21_242, 1);
            heff_take_n(v_x21_242, 2ULL, 2);
            v_f_2428 = v_sp_2424;
            break;
          }
          case TAG_LamAnn: {
            V v_sp_2426 = heff_field(v_x21_242, 1);
            heff_take_n(v_x21_242, 2ULL, 3);
            v_f_2428 = v_sp_2426;
            break;
          }
          default: heff_nomatch(v_x21_242);
          }
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_2420, v_f_2428}});
        } else {
          heff_drop_tag(v_x21_242, 2);
          heff_drop(v_field_2417);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
      }
    }
    case TAG_LamImplicit: {
      V v_xsp_2430 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_rec(v_cx_240, 6);
      heff_drop_cell(v_ru_24x2_241_24MkCatchArm, 2);
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str5), v_xsp_2430}});
    }
    case TAG_LamAnn: {
      V v_t_2441;
      switch (heff_tag_of(v_x21_242)) {
      case TAG_LamName: {
        V v_x_2434 = heff_dup(heff_field(v_x21_242, 0));
        if (heff_strEq_c_lent(v_x_2434, ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str6), 2)) {
          heff_drop_cell(v_ru_24x2_241_24MkCatchArm, 2);
          heff_drop(v_x_2434);
          v_t_2441 = NTAG(TAG_Nil);
        } else {
          v_t_2441 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_x_2434, NTAG(TAG_Nil)});
        }
        break;
      }
      case TAG_LamImplicit: {
        V v_x_2436 = heff_dup(heff_field(v_x21_242, 0));
        v_t_2441 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_x_2436, NTAG(TAG_Nil)});
        break;
      }
      case TAG_LamAnn: {
        V v_x_2438 = heff_dup(heff_field(v_x21_242, 0));
        if (heff_strEq_c_lent(v_x_2438, ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str7), 2)) {
          heff_drop_cell(v_ru_24x2_241_24MkCatchArm, 2);
          heff_drop(v_x_2438);
          v_t_2441 = NTAG(TAG_Nil);
        } else {
          v_t_2441 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_x_2438, NTAG(TAG_Nil)});
        }
        break;
      }
      default: heff_nomatch(v_x21_242);
      }
      HeffT2 v_t_2443 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_lam1, 1, 1, (V[]){v_cx_240}); V a_1 = v_t_2441; HeffT2 r_ = (g_list_2efind_24cpr(a_0, a_1)); heff_drop(v_t_2441); r_; });
      {
        V v_field_2445 = v_t_2443.f[1];
        int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
        if ((v_tag_2444 == ((int64_t)0ULL))) {
          V v_x_2446 = v_field_2445;
          V v_t_2447 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str8), heff_dup(v_x_2446)), ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str9));
          V v_f_2448 = heff_strAppend(heff_strAppend(v_t_2447, v_x_2446), ((V)&g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_str10));
          V v_f_2456;
          switch (heff_tag_of(v_x21_242)) {
          case TAG_LamName: {
            V v_sp_2450 = heff_field(v_x21_242, 1);
            heff_take_n(v_x21_242, 2ULL, 2);
            v_f_2456 = v_sp_2450;
            break;
          }
          case TAG_LamImplicit: {
            V v_sp_2452 = heff_field(v_x21_242, 1);
            heff_take_n(v_x21_242, 2ULL, 2);
            v_f_2456 = v_sp_2452;
            break;
          }
          case TAG_LamAnn: {
            V v_sp_2454 = heff_field(v_x21_242, 1);
            heff_take_n(v_x21_242, 2ULL, 3);
            v_f_2456 = v_sp_2454;
            break;
          }
          default: heff_nomatch(v_x21_242);
          }
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_2448, v_f_2456}});
        } else {
          heff_drop_tag(v_x21_242, 3);
          heff_drop(v_field_2445);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_cx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2414; V b_1 = heff_get_n(v_cx_240, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_2414); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2ecatchWrong_24cpr_lam1(V self, V *args) {
  V v_x_2442 = args[0];
  V v_cx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2442; V b_1 = heff_get_n(v_cx_240, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_2442); heff_drop(b_1); r_; });
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718_str0, 9, "returned#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718_str1, 4, "Left");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718_str2, 9, "returned#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718_str3, 4, "Left");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718_str4, 5, "Right");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718_str5, 5, "Right");
Clo g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718(V v_cx_240, V v_sp_241, V v_x4_242, V v_rest_243, V v_end_244) {
top: ;
  if ((heff_dup(v_x4_242) == NTAG(TAG_True))) {
    V v_t_245 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
    V v_t_246 = heff_tag_n(TAG_PatVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718_str0), v_t_245)});
    V v_ps_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, heff_dup(v_sp_241)}), NTAG(TAG_Nil)});
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718_str1)}), heff_dup(v_sp_241)});
    V v_x1_249 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_248, v_ps_247));
    V v_t_2412;
    switch (heff_tag_of(v_x1_249)) {
    case TAG_At: {
      V v_s_2411 = heff_field(v_x1_249, 1);
      heff_take_n(v_x1_249, 2ULL, 2);
      v_t_2412 = v_s_2411;
      break;
    }
    default: heff_nomatch(v_x1_249);
    }
    V v_t_2413 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_241, 0)); V rr_ = heff_rec_reuse_nf(v_t_2412, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2414 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
    V v_t_2415 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718_str2), v_t_2414)});
    V v_t_2416 = (g_heff_2esyntax_2epresyntax_2ereturnOf(heff_dup(v_cx_240), heff_dup(v_sp_241), heff_tag_n(TAG_At, 2, (V[]){v_t_2415, heff_dup(v_sp_241)})));
    V v_e_2417 = (g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_240), heff_dup(v_sp_241), heff_dup(heff_rfield(v_cx_240, 4)), v_t_2416));
    V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718_str3), heff_dup(v_sp_241), v_ps_247}), heff_dup(v_t_2413)});
    V v_t_2421;
    switch (heff_tag_of(v_e_2417)) {
    case TAG_At: {
      V v_s_2420 = heff_dup(heff_field(v_e_2417, 1));
      v_t_2421 = v_s_2420;
      break;
    }
    default: heff_nomatch(v_e_2417);
    }
    V v_t_2422 = ({ V rv_1 = heff_get_n(v_t_2421, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2413, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2418, v_e_2417}), v_t_2422});
    V v_t_2424 = (g_heff_2esyntax_2epresyntax_2epackPat(heff_dup(v_sp_241), heff_dup(heff_rfield(v_cx_240, 1))));
    V v_ps_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
    V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718_str4)}), heff_dup(v_sp_241)});
    V v_x1_2427 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2426, v_ps_2425));
    V v_t_2430;
    switch (heff_tag_of(v_x1_2427)) {
    case TAG_At: {
      V v_s_2429 = heff_field(v_x1_2427, 1);
      heff_take_n(v_x1_2427, 2ULL, 2);
      v_t_2430 = v_s_2429;
      break;
    }
    default: heff_nomatch(v_x1_2427);
    }
    V v_t_2431 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_241, 0)); V rr_ = heff_rec_reuse_nf(v_t_2430, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_e_2432 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(v_cx_240, v_rest_243, v_end_244));
    V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718_str5), v_sp_241, v_ps_2425}), heff_dup(v_t_2431)});
    V v_t_2436;
    switch (heff_tag_of(v_e_2432)) {
    case TAG_At: {
      V v_s_2435 = heff_dup(heff_field(v_e_2432, 1));
      v_t_2436 = v_s_2435;
      break;
    }
    default: heff_nomatch(v_e_2432);
    }
    V v_t_2437 = ({ V rv_1 = heff_get_n(v_t_2436, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2431, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2433, v_e_2432}), v_t_2437});
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2439});
  } else {
    V v_p_2440 = (g_heff_2esyntax_2epresyntax_2epackPat(v_sp_241, heff_dup(heff_rfield(v_cx_240, 1))));
    V v_e_2441 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(v_cx_240, v_rest_243, v_end_244));
    V v_t_2444;
    switch (heff_tag_of(v_p_2440)) {
    case TAG_At: {
      V v_s_2443 = heff_dup(heff_field(v_p_2440, 1));
      v_t_2444 = v_s_2443;
      break;
    }
    default: heff_nomatch(v_p_2440);
    }
    V v_t_2447;
    switch (heff_tag_of(v_e_2441)) {
    case TAG_At: {
      V v_s_2446 = heff_dup(heff_field(v_e_2441, 1));
      v_t_2447 = v_s_2446;
      break;
    }
    default: heff_nomatch(v_e_2441);
    }
    V v_t_2448 = ({ V rv_1 = heff_get_n(v_t_2447, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2444, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2449 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2440, v_e_2441}), v_t_2448});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, NTAG(TAG_Nil)});
  }
}
V g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2esyntax_2epresyntax_2eafterArms_24s1323524831x10446718(a[0], a[1], a2, a3, a[4]); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_str0, 5, "join#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_str1, 5, "join#");
Clo g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_entry, 6, 0};

V g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567(V v_lit_240, V v_lit_241, V v_cx_242, V v_sp_243, V v_scope_244, V v_end_245) {
top: ;
  V v_t_246 = heff_intShow(heff_dup(heff_rfield(v_sp_243, 0)));
  V v_t_247 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_str0), v_t_246)});
  V v_t_248 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_247, heff_dup(v_sp_243)}), heff_dup(heff_rfield(v_cx_242, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_242, 4))});
  V v_t_249 = heff_tr(heff_call(v_scope_244, 1, (V[]){heff_tag_n(TAG_EndJump, 1, (V[]){v_t_248})}));
  V v_t_2410 = heff_intShow(heff_dup(heff_rfield(v_sp_243, 0)));
  V v_t_2411 = ({ V a_0 = heff_dup(v_sp_243); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_242, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2417;
  switch (heff_tag_of(v_lit_241)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_end_245)) {
    case TAG_EndValue: {
      v_t_2417 = heff_tr(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(v_cx_242, v_lit_240));
      break;
    }
    case TAG_EndJump: {
      v_t_2417 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_242, v_lit_240, v_lit_241, v_end_245));
      break;
    }
    case TAG_EndGive: {
      v_t_2417 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_242, v_lit_240, v_lit_241, v_end_245));
      break;
    }
    default: heff_nomatch(v_end_245);
    }
    break;
  }
  case TAG_Cons: {
    v_t_2417 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_242, v_lit_240, v_lit_241, v_end_245));
    break;
  }
  default: heff_nomatch(v_lit_241);
  }
  V v_t_2418 = (g_heff_2esyntax_2epresyntax_2elocalFun(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_str1), v_t_2410), heff_dup(v_sp_243), v_t_2411, v_t_2417));
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELocal, 2, (V[]){v_t_249, v_t_2419}), v_sp_243});
}
V g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2echeckedWays_str0, 235, "any of these: give the type where it is bound, `let x : T = ...`; give it in place, `(e : T)`; or write it where a type is expected of it, as an argument of a function whose type is known or as the body of a definition with a signature");

static V g_heff_2esyntax_2epresyntax_2echeckedWays_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2echeckedWays_st;
static V g_heff_2esyntax_2epresyntax_2echeckedWays_init(void) {
  return ((V)&g_heff_2esyntax_2epresyntax_2echeckedWays_str0);
}
V g_heff_2esyntax_2epresyntax_2echeckedWays_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2echeckedWays_st)) return g_heff_2esyntax_2epresyntax_2echeckedWays_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2echeckedWays_val, &g_heff_2esyntax_2epresyntax_2echeckedWays_st, g_heff_2esyntax_2epresyntax_2echeckedWays_init);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str0, 9, "bitsOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str1, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str2, 17, "prelude.bitsSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str3, 17, "prelude.bitsSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str4, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str5, 11, "bitsOfBytes");
Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026(V v_lit_240, V v_r_241, V v_seg_242) {
top: ;
  switch (heff_tag_of(v_seg_242)) {
  case TAG_At: {
    V v_seg1_243 = heff_dup(heff_field(v_seg_242, 0));
    V v_sp_244 = heff_dup(heff_field(v_seg_242, 1));
    switch (heff_tag_of(v_seg1_243)) {
    case TAG_MkSegment: {
      V v_v_245 = heff_field(v_seg1_243, 0);
      V v_seg12_246 = heff_field(v_seg1_243, 1);
      V v_size_247 = heff_field(v_seg1_243, 2);
      V v_little_248 = heff_field(v_seg1_243, 3);
      V v_signed_249 = heff_field(v_seg1_243, 4);
      heff_take_n(v_seg1_243, 31ULL, 5);
      switch (heff_tag_of(v_seg12_246)) {
      case TAG_SegmentInteger: {
        heff_drop(v_lit_240);
        heff_drop_tag(v_seg_242, 2);
        V v_t_2410 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_247, MK_INT(8LL), heff_dup(v_sp_244)));
        int64_t v_t_2411;
        if ((heff_dup(v_little_248) == NTAG(TAG_True))) {
          heff_drop(v_little_248);
          v_t_2411 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_248);
          v_t_2411 = ((int64_t)0ULL);
        }
        int64_t v_t_2412;
        if ((heff_dup(v_signed_249) == NTAG(TAG_True))) {
          heff_drop(v_signed_249);
          v_t_2412 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_249);
          v_t_2412 = ((int64_t)0ULL);
        }
        V v_t_2413 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_2411 + v_t_2412))});
        V v_t_2414 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_244)})});
        V v_x1_2415 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){v_v_245}));
        V v_t_2425;
        switch (heff_tag_of(v_x1_2415)) {
        case TAG_IsInferable: {
          V v_i_2416 = heff_field(v_x1_2415, 0);
          V v_ru_24x1_2415_24IsInferable = heff_take_reuse_n(v_x1_2415, 1ULL, 1);
          V v_t_2419;
          switch (heff_tag_of(v_i_2416)) {
          case TAG_At: {
            V v_s_2418 = heff_dup(heff_field(v_i_2416, 1));
            v_t_2419 = v_s_2418;
            break;
          }
          default: heff_nomatch(v_i_2416);
          }
          v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2415_24IsInferable, TAG_CInf, 1, (V[]){v_i_2416}), v_t_2419});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2420 = heff_field(v_x1_2415, 0);
          heff_take_n(v_x1_2415, 1ULL, 1);
          v_t_2425 = v_c_2420;
          break;
        }
        case TAG_IsType: {
          V v_t_2421 = heff_field(v_x1_2415, 0);
          V v_ru_24x1_2415_24IsType = heff_take_reuse_n(v_x1_2415, 1ULL, 1);
          V v_t_2424;
          switch (heff_tag_of(v_t_2421)) {
          case TAG_At: {
            V v_s_2423 = heff_dup(heff_field(v_t_2421, 1));
            v_t_2424 = v_s_2423;
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
          v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2415_24IsType, TAG_CType, 1, (V[]){v_t_2421}), v_t_2424});
          break;
        }
        default: heff_nomatch(v_x1_2415);
        }
        V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
        V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, heff_dup(v_sp_244)}), v_t_2426});
        V v_args_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2427});
        V v_t_2429 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_244), v_args_2428));
        V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str0)}), heff_dup(v_sp_244)});
        V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2430, v_t_2429}), heff_dup(v_sp_244)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2431}), v_sp_244});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_lit_240);
        heff_drop(v_sp_244);
        heff_drop(v_v_245);
        heff_drop(v_size_247);
        heff_drop(v_little_248);
        heff_drop(v_signed_249);
        V v_t_2432 = (g_heff_2esyntax_2epresyntax_2ebytesPart(v_r_241, heff_dup(v_seg_242)));
        V v_args_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
        V v_sp_2436;
        switch (heff_tag_of(v_seg_242)) {
        case TAG_At: {
          V v_s_2435 = heff_field(v_seg_242, 1);
          heff_take_n(v_seg_242, 2ULL, 2);
          v_sp_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_seg_242);
        }
        V v_t_2437 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2436), v_args_2433));
        V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str1)}), heff_dup(v_sp_2436)});
        V v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2438, v_t_2437}), heff_dup(v_sp_2436)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2439}), v_sp_2436});
      }
      case TAG_SegmentBits: {
        heff_drop_tag(v_seg_242, 2);
        heff_drop(v_little_248);
        heff_drop(v_signed_249);
        switch (heff_tag_of(v_size_247)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_244);
          switch (heff_tag_of(v_v_245)) {
          case TAG_At: {
            V v_e_2440 = heff_field(v_v_245, 0);
            V v_sp_2441 = heff_field(v_v_245, 1);
            V v_ru_24v_245_24At = heff_take_reuse_n(v_v_245, 3ULL, 2);
            HeffT2 v_t_2442 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(v_e_2440));
            {
              V v_field_2444 = v_t_2442.f[1];
              int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
              if ((v_tag_2443 == ((int64_t)0ULL))) {
                heff_drop_rec(v_r_241, 2);
                heff_drop(v_e_2440);
                V v_segs_2445 = v_field_2444;
                HeffT1 v_t_2446 = ({ V a_0 = v_lit_240; V b_1 = NTAG(TAG_True); V a_2 = v_segs_2445; V a_3 = v_sp_2441; HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
                {
                  V v_field_2447 = v_t_2446.f[0];
                  V v_a_2448 = v_field_2447;
                  V v_t_2451;
                  switch (heff_tag_of(v_a_2448)) {
                  case TAG_At: {
                    V v_a_2450 = heff_dup(heff_field(v_a_2448, 1));
                    v_t_2451 = v_a_2450;
                    break;
                  }
                  default: heff_nomatch(v_a_2448);
                  }
                  return heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_2448}), v_t_2451});
                }
              } else {
                heff_drop(v_lit_240);
                heff_drop(v_field_2444);
                V v_x1_2452 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_e_2440, v_sp_2441})}));
                switch (heff_tag_of(v_x1_2452)) {
                case TAG_IsInferable: {
                  V v_i_2453 = heff_field(v_x1_2452, 0);
                  V v_ru_24x1_2452_24IsInferable = heff_take_reuse_n(v_x1_2452, 1ULL, 1);
                  V v_t_2456;
                  switch (heff_tag_of(v_i_2453)) {
                  case TAG_At: {
                    V v_s_2455 = heff_dup(heff_field(v_i_2453, 1));
                    v_t_2456 = v_s_2455;
                    break;
                  }
                  default: heff_nomatch(v_i_2453);
                  }
                  return heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2452_24IsInferable, TAG_CInf, 1, (V[]){v_i_2453}), v_t_2456});
                }
                case TAG_IsCheckable: {
                  V v_c_2457 = heff_field(v_x1_2452, 0);
                  heff_take_n(v_x1_2452, 1ULL, 1);
                  heff_drop_cell(v_ru_24v_245_24At, 2);
                  return v_c_2457;
                }
                case TAG_IsType: {
                  V v_t_2458 = heff_field(v_x1_2452, 0);
                  V v_ru_24x1_2452_24IsType = heff_take_reuse_n(v_x1_2452, 1ULL, 1);
                  V v_t_2461;
                  switch (heff_tag_of(v_t_2458)) {
                  case TAG_At: {
                    V v_s_2460 = heff_dup(heff_field(v_t_2458, 1));
                    v_t_2461 = v_s_2460;
                    break;
                  }
                  default: heff_nomatch(v_t_2458);
                  }
                  return heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2452_24IsType, TAG_CType, 1, (V[]){v_t_2458}), v_t_2461});
                }
                default: return heff_nomatch(v_x1_2452);
                }
              }
            }
          }
          default: return heff_nomatch(v_v_245);
          }
        }
        case TAG_SizeNumber: {
          V v_t_2463 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_247, MK_INT(0LL), heff_dup(v_sp_244)));
          V v_t_2486;
          switch (heff_tag_of(v_v_245)) {
          case TAG_At: {
            V v_e_2464 = heff_field(v_v_245, 0);
            V v_sp_2465 = heff_field(v_v_245, 1);
            V v_ru_24v_245_24At = heff_take_reuse_n(v_v_245, 3ULL, 2);
            HeffT2 v_t_2466 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(v_e_2464));
            {
              V v_field_2468 = v_t_2466.f[1];
              int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
              if ((v_tag_2467 == ((int64_t)0ULL))) {
                heff_drop_rec(v_r_241, 2);
                heff_drop(v_e_2464);
                V v_segs_2469 = v_field_2468;
                HeffT1 v_t_2470 = ({ V a_0 = v_lit_240; V b_1 = NTAG(TAG_True); V a_2 = v_segs_2469; V a_3 = v_sp_2465; HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
                {
                  V v_field_2471 = v_t_2470.f[0];
                  V v_a_2472 = v_field_2471;
                  V v_t_2475;
                  switch (heff_tag_of(v_a_2472)) {
                  case TAG_At: {
                    V v_a_2474 = heff_dup(heff_field(v_a_2472, 1));
                    v_t_2475 = v_a_2474;
                    break;
                  }
                  default: heff_nomatch(v_a_2472);
                  }
                  v_t_2486 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_2472}), v_t_2475});
                }
              } else {
                heff_drop(v_lit_240);
                heff_drop(v_field_2468);
                V v_x1_2476 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_e_2464, v_sp_2465})}));
                switch (heff_tag_of(v_x1_2476)) {
                case TAG_IsInferable: {
                  V v_i_2477 = heff_field(v_x1_2476, 0);
                  V v_ru_24x1_2476_24IsInferable = heff_take_reuse_n(v_x1_2476, 1ULL, 1);
                  V v_t_2480;
                  switch (heff_tag_of(v_i_2477)) {
                  case TAG_At: {
                    V v_s_2479 = heff_dup(heff_field(v_i_2477, 1));
                    v_t_2480 = v_s_2479;
                    break;
                  }
                  default: heff_nomatch(v_i_2477);
                  }
                  v_t_2486 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2476_24IsInferable, TAG_CInf, 1, (V[]){v_i_2477}), v_t_2480});
                  break;
                }
                case TAG_IsCheckable: {
                  V v_c_2481 = heff_field(v_x1_2476, 0);
                  heff_take_n(v_x1_2476, 1ULL, 1);
                  heff_drop_cell(v_ru_24v_245_24At, 2);
                  v_t_2486 = v_c_2481;
                  break;
                }
                case TAG_IsType: {
                  V v_t_2482 = heff_field(v_x1_2476, 0);
                  V v_ru_24x1_2476_24IsType = heff_take_reuse_n(v_x1_2476, 1ULL, 1);
                  V v_t_2485;
                  switch (heff_tag_of(v_t_2482)) {
                  case TAG_At: {
                    V v_s_2484 = heff_dup(heff_field(v_t_2482, 1));
                    v_t_2485 = v_s_2484;
                    break;
                  }
                  default: heff_nomatch(v_t_2482);
                  }
                  v_t_2486 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2476_24IsType, TAG_CType, 1, (V[]){v_t_2482}), v_t_2485});
                  break;
                }
                default: heff_nomatch(v_x1_2476);
                }
              }
            }
            break;
          }
          default: heff_nomatch(v_v_245);
          }
          V v_t_2487 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2486, NTAG(TAG_Nil)});
          V v_args_2488 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2463, v_t_2487});
          V v_t_2489 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_244), v_args_2488));
          V v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str2)}), heff_dup(v_sp_244)});
          V v_t_2491 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2490, v_t_2489}), heff_dup(v_sp_244)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2491}), v_sp_244});
        }
        case TAG_SizeName: {
          V v_t_2495 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_247, MK_INT(0LL), heff_dup(v_sp_244)));
          V v_t_24118;
          switch (heff_tag_of(v_v_245)) {
          case TAG_At: {
            V v_e_2496 = heff_field(v_v_245, 0);
            V v_sp_2497 = heff_field(v_v_245, 1);
            V v_ru_24v_245_24At = heff_take_reuse_n(v_v_245, 3ULL, 2);
            HeffT2 v_t_2498 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(v_e_2496));
            {
              V v_field_24100 = v_t_2498.f[1];
              int64_t v_tag_2499 = ((int64_t)v_t_2498.f[0]);
              if ((v_tag_2499 == ((int64_t)0ULL))) {
                heff_drop_rec(v_r_241, 2);
                heff_drop(v_e_2496);
                V v_segs_24101 = v_field_24100;
                HeffT1 v_t_24102 = ({ V a_0 = v_lit_240; V b_1 = NTAG(TAG_True); V a_2 = v_segs_24101; V a_3 = v_sp_2497; HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
                {
                  V v_field_24103 = v_t_24102.f[0];
                  V v_a_24104 = v_field_24103;
                  V v_t_24107;
                  switch (heff_tag_of(v_a_24104)) {
                  case TAG_At: {
                    V v_a_24106 = heff_dup(heff_field(v_a_24104, 1));
                    v_t_24107 = v_a_24106;
                    break;
                  }
                  default: heff_nomatch(v_a_24104);
                  }
                  v_t_24118 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_24104}), v_t_24107});
                }
              } else {
                heff_drop(v_lit_240);
                heff_drop(v_field_24100);
                V v_x1_24108 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_e_2496, v_sp_2497})}));
                switch (heff_tag_of(v_x1_24108)) {
                case TAG_IsInferable: {
                  V v_i_24109 = heff_field(v_x1_24108, 0);
                  V v_ru_24x1_24108_24IsInferable = heff_take_reuse_n(v_x1_24108, 1ULL, 1);
                  V v_t_24112;
                  switch (heff_tag_of(v_i_24109)) {
                  case TAG_At: {
                    V v_s_24111 = heff_dup(heff_field(v_i_24109, 1));
                    v_t_24112 = v_s_24111;
                    break;
                  }
                  default: heff_nomatch(v_i_24109);
                  }
                  v_t_24118 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24108_24IsInferable, TAG_CInf, 1, (V[]){v_i_24109}), v_t_24112});
                  break;
                }
                case TAG_IsCheckable: {
                  V v_c_24113 = heff_field(v_x1_24108, 0);
                  heff_take_n(v_x1_24108, 1ULL, 1);
                  heff_drop_cell(v_ru_24v_245_24At, 2);
                  v_t_24118 = v_c_24113;
                  break;
                }
                case TAG_IsType: {
                  V v_t_24114 = heff_field(v_x1_24108, 0);
                  V v_ru_24x1_24108_24IsType = heff_take_reuse_n(v_x1_24108, 1ULL, 1);
                  V v_t_24117;
                  switch (heff_tag_of(v_t_24114)) {
                  case TAG_At: {
                    V v_s_24116 = heff_dup(heff_field(v_t_24114, 1));
                    v_t_24117 = v_s_24116;
                    break;
                  }
                  default: heff_nomatch(v_t_24114);
                  }
                  v_t_24118 = heff_tag_at_n(v_ru_24v_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24108_24IsType, TAG_CType, 1, (V[]){v_t_24114}), v_t_24117});
                  break;
                }
                default: heff_nomatch(v_x1_24108);
                }
              }
            }
            break;
          }
          default: heff_nomatch(v_v_245);
          }
          V v_t_24119 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24118, NTAG(TAG_Nil)});
          V v_args_24120 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2495, v_t_24119});
          V v_t_24121 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_244), v_args_24120));
          V v_t_24122 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str3)}), heff_dup(v_sp_244)});
          V v_t_24123 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24122, v_t_24121}), heff_dup(v_sp_244)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24123}), v_sp_244});
        }
        default: return heff_nomatch(v_size_247);
        }
      }
      case TAG_SegmentFloat: {
        heff_drop(v_lit_240);
        heff_drop(v_sp_244);
        heff_drop(v_v_245);
        heff_drop(v_size_247);
        heff_drop(v_little_248);
        heff_drop(v_signed_249);
        V v_t_24124 = (g_heff_2esyntax_2epresyntax_2ebytesPart(v_r_241, heff_dup(v_seg_242)));
        V v_args_24125 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24124, NTAG(TAG_Nil)});
        V v_sp_24128;
        switch (heff_tag_of(v_seg_242)) {
        case TAG_At: {
          V v_s_24127 = heff_field(v_seg_242, 1);
          heff_take_n(v_seg_242, 2ULL, 2);
          v_sp_24128 = v_s_24127;
          break;
        }
        default: heff_nomatch(v_seg_242);
        }
        V v_t_24129 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24128), v_args_24125));
        V v_t_24130 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str4)}), heff_dup(v_sp_24128)});
        V v_t_24131 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24130, v_t_24129}), heff_dup(v_sp_24128)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24131}), v_sp_24128});
      }
      case TAG_SegmentUtf: {
        V v_ru_24seg12_246_24SegmentUtf = heff_take_reuse_n(v_seg12_246, 0ULL, 1);
        heff_drop(v_lit_240);
        heff_drop(v_sp_244);
        heff_drop(v_v_245);
        heff_drop(v_size_247);
        heff_drop(v_little_248);
        heff_drop(v_signed_249);
        V v_t_24133 = (g_heff_2esyntax_2epresyntax_2ebytesPart(v_r_241, heff_dup(v_seg_242)));
        V v_args_24134 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24133, NTAG(TAG_Nil)});
        V v_sp_24137;
        switch (heff_tag_of(v_seg_242)) {
        case TAG_At: {
          V v_s_24136 = heff_field(v_seg_242, 1);
          heff_take_n(v_seg_242, 2ULL, 2);
          v_sp_24137 = v_s_24136;
          break;
        }
        default: heff_nomatch(v_seg_242);
        }
        V v_t_24138 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24137), v_args_24134));
        V v_t_24139 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24seg12_246_24SegmentUtf, TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_str5)}), heff_dup(v_sp_24137)});
        V v_t_24140 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24139, v_t_24138}), heff_dup(v_sp_24137)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24140}), v_sp_24137});
      }
      default: return heff_nomatch(v_seg12_246);
      }
    }
    default: return heff_nomatch(v_seg1_243);
    }
  }
  default: return heff_nomatch(v_seg_242);
  }
}
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026(a[0], a[1], a[2]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2edoBlock_24s1455639597x676970604_24cpr(V v_sp_240, V v_stmts_241) {
top: ;
  V v_x1_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stmts_241)));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_sp_240);
    heff_drop(v_stmts_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    heff_take_n(v_x1_242, 1ULL, 2);
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_it11_245 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 2);
      switch (heff_tag_of(v_it11_245)) {
      case TAG_StmtBind: {
        heff_take_n(v_it11_245, 0ULL, 3);
        heff_drop(v_sp_240);
        heff_drop(v_stmts_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_StmtLet: {
        heff_take_n(v_it11_245, 0ULL, 2);
        heff_drop(v_sp_240);
        heff_drop(v_stmts_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_StmtExpr: {
        heff_take_n(v_it11_245, 0ULL, 1);
        V v_t_2413 = heff_rec_n(6, shape_names__muts__loop__sp__depth__giving, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2ecoNames_get()), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_sp_240, MK_INT(0LL), NTAG(TAG_Nothing)});
        V v_f_2414 = ({ V a_0 = v_t_2413; V a_1 = v_stmts_241; V a_2 = NTAG(TAG_EndValue); V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_stmts_241); r_; });
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
      }
      case TAG_StmtLetMut: {
        heff_take_n(v_it11_245, 0ULL, 3);
        heff_drop(v_sp_240);
        heff_drop(v_stmts_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_it11_245, 0ULL, 3);
        heff_drop(v_sp_240);
        heff_drop(v_stmts_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it11_245)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_242)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str0, 9, "bitsOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str1, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str2, 17, "prelude.bitsSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str3, 17, "prelude.bitsSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str4, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str5, 11, "bitsOfBytes");
Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076(V v_seg_240) {
top: ;
  switch (heff_tag_of(v_seg_240)) {
  case TAG_At: {
    V v_seg1_241 = heff_dup(heff_field(v_seg_240, 0));
    V v_sp_242 = heff_dup(heff_field(v_seg_240, 1));
    switch (heff_tag_of(v_seg1_241)) {
    case TAG_MkSegment: {
      V v_v_243 = heff_field(v_seg1_241, 0);
      V v_seg12_244 = heff_field(v_seg1_241, 1);
      V v_size_245 = heff_field(v_seg1_241, 2);
      V v_little_246 = heff_field(v_seg1_241, 3);
      V v_signed_247 = heff_field(v_seg1_241, 4);
      heff_take_n(v_seg1_241, 31ULL, 5);
      switch (heff_tag_of(v_seg12_244)) {
      case TAG_SegmentInteger: {
        heff_drop_tag(v_seg_240, 2);
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(8LL), heff_dup(v_sp_242)));
        int64_t v_t_249;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)0ULL);
        }
        int64_t v_t_2410;
        if ((heff_dup(v_signed_247) == NTAG(TAG_True))) {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)0ULL);
        }
        V v_t_2411 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_249 + v_t_2410))});
        V v_t_2412 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_242)})});
        HeffT3 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_2426;
        {
          V v_field_2415 = v_t_2413.f[1];
          V v_field_2416 = v_t_2413.f[2];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_c_2417 = heff_tag_n(TAG_At, 2, (V[]){v_field_2415, v_field_2416});
            v_t_2426 = v_c_2417;
          } else {
            if ((v_tag_2414 == ((int64_t)1ULL))) {
              heff_drop(v_field_2416);
              V v_i_2418 = v_field_2415;
              V v_t_2421;
              switch (heff_tag_of(v_i_2418)) {
              case TAG_At: {
                V v_s_2420 = heff_dup(heff_field(v_i_2418, 1));
                v_t_2421 = v_s_2420;
                break;
              }
              default: heff_nomatch(v_i_2418);
              }
              v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2418}), v_t_2421});
            } else {
              V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){v_field_2415, v_field_2416});
              V v_t_2425;
              switch (heff_tag_of(v_t_2422)) {
              case TAG_At: {
                V v_s_2424 = heff_dup(heff_field(v_t_2422, 1));
                v_t_2425 = v_s_2424;
                break;
              }
              default: heff_nomatch(v_t_2422);
              }
              v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2422}), v_t_2425});
            }
          }
        }
        V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
        V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_242)}), v_t_2427});
        V v_args_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2428});
        V v_t_2430 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2429));
        V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str0)}), heff_dup(v_sp_242)});
        V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2431, v_t_2430}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2432}), v_sp_242});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_sp_242);
        heff_drop(v_v_243);
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        V v_t_2433 = (g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(heff_dup(v_seg_240)));
        V v_args_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
        V v_sp_2437;
        switch (heff_tag_of(v_seg_240)) {
        case TAG_At: {
          V v_s_2436 = heff_field(v_seg_240, 1);
          heff_take_n(v_seg_240, 2ULL, 2);
          v_sp_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_seg_240);
        }
        V v_t_2438 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2437), v_args_2434));
        V v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str1)}), heff_dup(v_sp_2437)});
        V v_t_2440 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2439, v_t_2438}), heff_dup(v_sp_2437)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2440}), v_sp_2437});
      }
      case TAG_SegmentBits: {
        heff_drop_tag(v_seg_240, 2);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        switch (heff_tag_of(v_size_245)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_242);
          switch (heff_tag_of(v_v_243)) {
          case TAG_At: {
            V v_e_2441 = heff_field(v_v_243, 0);
            V v_sp_2442 = heff_field(v_v_243, 1);
            V v_ru_24v_243_24At = heff_take_reuse_n(v_v_243, 3ULL, 2);
            HeffT2 v_t_2443 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(v_e_2441));
            {
              V v_field_2445 = v_t_2443.f[1];
              int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
              if ((v_tag_2444 == ((int64_t)0ULL))) {
                heff_drop(v_e_2441);
                V v_segs_2446 = v_field_2445;
                HeffT3 v_t_2447 = ({ V a_0 = v_segs_2446; V a_1 = v_sp_2442; V b_2 = NTAG(TAG_False); HeffT3 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
                {
                  V v_field_2449 = v_t_2447.f[1];
                  V v_field_2450 = v_t_2447.f[2];
                  int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
                  if ((v_tag_2448 == ((int64_t)0ULL))) {
                    V v_a_2451 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){v_field_2449, v_field_2450});
                    return v_a_2451;
                  } else {
                    if ((v_tag_2448 == ((int64_t)1ULL))) {
                      heff_drop(v_field_2450);
                      V v_a_2452 = v_field_2449;
                      V v_t_2455;
                      switch (heff_tag_of(v_a_2452)) {
                      case TAG_At: {
                        V v_a_2454 = heff_dup(heff_field(v_a_2452, 1));
                        v_t_2455 = v_a_2454;
                        break;
                      }
                      default: heff_nomatch(v_a_2452);
                      }
                      return heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_2452}), v_t_2455});
                    } else {
                      V v_a_2456 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){v_field_2449, v_field_2450});
                      V v_t_2459;
                      switch (heff_tag_of(v_a_2456)) {
                      case TAG_At: {
                        V v_a_2458 = heff_dup(heff_field(v_a_2456, 1));
                        v_t_2459 = v_a_2458;
                        break;
                      }
                      default: heff_nomatch(v_a_2456);
                      }
                      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_2456}), v_t_2459});
                    }
                  }
                }
              } else {
                heff_drop(v_field_2445);
                HeffT3 v_t_2460 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){v_e_2441, v_sp_2442})));
                {
                  V v_field_2462 = v_t_2460.f[1];
                  V v_field_2463 = v_t_2460.f[2];
                  int64_t v_tag_2461 = ((int64_t)v_t_2460.f[0]);
                  if ((v_tag_2461 == ((int64_t)0ULL))) {
                    V v_c_2464 = heff_tag_n(TAG_At, 2, (V[]){v_field_2462, v_field_2463});
                    return v_c_2464;
                  } else {
                    if ((v_tag_2461 == ((int64_t)1ULL))) {
                      heff_drop(v_field_2463);
                      V v_i_2465 = v_field_2462;
                      V v_t_2468;
                      switch (heff_tag_of(v_i_2465)) {
                      case TAG_At: {
                        V v_s_2467 = heff_dup(heff_field(v_i_2465, 1));
                        v_t_2468 = v_s_2467;
                        break;
                      }
                      default: heff_nomatch(v_i_2465);
                      }
                      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2465}), v_t_2468});
                    } else {
                      V v_t_2469 = heff_tag_n(TAG_At, 2, (V[]){v_field_2462, v_field_2463});
                      V v_t_2472;
                      switch (heff_tag_of(v_t_2469)) {
                      case TAG_At: {
                        V v_s_2471 = heff_dup(heff_field(v_t_2469, 1));
                        v_t_2472 = v_s_2471;
                        break;
                      }
                      default: heff_nomatch(v_t_2469);
                      }
                      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2469}), v_t_2472});
                    }
                  }
                }
              }
            }
          }
          default: return heff_nomatch(v_v_243);
          }
        }
        case TAG_SizeNumber: {
          V v_t_2474 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(0LL), heff_dup(v_sp_242)));
          V v_t_24107;
          switch (heff_tag_of(v_v_243)) {
          case TAG_At: {
            V v_e_2475 = heff_field(v_v_243, 0);
            V v_sp_2476 = heff_field(v_v_243, 1);
            V v_ru_24v_243_24At = heff_take_reuse_n(v_v_243, 3ULL, 2);
            HeffT2 v_t_2477 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(v_e_2475));
            {
              V v_field_2479 = v_t_2477.f[1];
              int64_t v_tag_2478 = ((int64_t)v_t_2477.f[0]);
              if ((v_tag_2478 == ((int64_t)0ULL))) {
                heff_drop(v_e_2475);
                V v_segs_2480 = v_field_2479;
                HeffT3 v_t_2481 = ({ V a_0 = v_segs_2480; V a_1 = v_sp_2476; V b_2 = NTAG(TAG_False); HeffT3 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
                {
                  V v_field_2483 = v_t_2481.f[1];
                  V v_field_2484 = v_t_2481.f[2];
                  int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
                  if ((v_tag_2482 == ((int64_t)0ULL))) {
                    V v_a_2485 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){v_field_2483, v_field_2484});
                    v_t_24107 = v_a_2485;
                  } else {
                    if ((v_tag_2482 == ((int64_t)1ULL))) {
                      heff_drop(v_field_2484);
                      V v_a_2486 = v_field_2483;
                      V v_t_2489;
                      switch (heff_tag_of(v_a_2486)) {
                      case TAG_At: {
                        V v_a_2488 = heff_dup(heff_field(v_a_2486, 1));
                        v_t_2489 = v_a_2488;
                        break;
                      }
                      default: heff_nomatch(v_a_2486);
                      }
                      v_t_24107 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_2486}), v_t_2489});
                    } else {
                      V v_a_2490 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){v_field_2483, v_field_2484});
                      V v_t_2493;
                      switch (heff_tag_of(v_a_2490)) {
                      case TAG_At: {
                        V v_a_2492 = heff_dup(heff_field(v_a_2490, 1));
                        v_t_2493 = v_a_2492;
                        break;
                      }
                      default: heff_nomatch(v_a_2490);
                      }
                      v_t_24107 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_2490}), v_t_2493});
                    }
                  }
                }
              } else {
                heff_drop(v_field_2479);
                HeffT3 v_t_2494 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){v_e_2475, v_sp_2476})));
                {
                  V v_field_2496 = v_t_2494.f[1];
                  V v_field_2497 = v_t_2494.f[2];
                  int64_t v_tag_2495 = ((int64_t)v_t_2494.f[0]);
                  if ((v_tag_2495 == ((int64_t)0ULL))) {
                    V v_c_2498 = heff_tag_n(TAG_At, 2, (V[]){v_field_2496, v_field_2497});
                    v_t_24107 = v_c_2498;
                  } else {
                    if ((v_tag_2495 == ((int64_t)1ULL))) {
                      heff_drop(v_field_2497);
                      V v_i_2499 = v_field_2496;
                      V v_t_24102;
                      switch (heff_tag_of(v_i_2499)) {
                      case TAG_At: {
                        V v_s_24101 = heff_dup(heff_field(v_i_2499, 1));
                        v_t_24102 = v_s_24101;
                        break;
                      }
                      default: heff_nomatch(v_i_2499);
                      }
                      v_t_24107 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2499}), v_t_24102});
                    } else {
                      V v_t_24103 = heff_tag_n(TAG_At, 2, (V[]){v_field_2496, v_field_2497});
                      V v_t_24106;
                      switch (heff_tag_of(v_t_24103)) {
                      case TAG_At: {
                        V v_s_24105 = heff_dup(heff_field(v_t_24103, 1));
                        v_t_24106 = v_s_24105;
                        break;
                      }
                      default: heff_nomatch(v_t_24103);
                      }
                      v_t_24107 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24103}), v_t_24106});
                    }
                  }
                }
              }
            }
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          V v_t_24108 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24107, NTAG(TAG_Nil)});
          V v_args_24109 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2474, v_t_24108});
          V v_t_24110 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24109));
          V v_t_24111 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str2)}), heff_dup(v_sp_242)});
          V v_t_24112 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24111, v_t_24110}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24112}), v_sp_242});
        }
        case TAG_SizeName: {
          V v_t_24116 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(0LL), heff_dup(v_sp_242)));
          V v_t_24149;
          switch (heff_tag_of(v_v_243)) {
          case TAG_At: {
            V v_e_24117 = heff_field(v_v_243, 0);
            V v_sp_24118 = heff_field(v_v_243, 1);
            V v_ru_24v_243_24At = heff_take_reuse_n(v_v_243, 3ULL, 2);
            HeffT2 v_t_24119 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(v_e_24117));
            {
              V v_field_24121 = v_t_24119.f[1];
              int64_t v_tag_24120 = ((int64_t)v_t_24119.f[0]);
              if ((v_tag_24120 == ((int64_t)0ULL))) {
                heff_drop(v_e_24117);
                V v_segs_24122 = v_field_24121;
                HeffT3 v_t_24123 = ({ V a_0 = v_segs_24122; V a_1 = v_sp_24118; V b_2 = NTAG(TAG_False); HeffT3 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
                {
                  V v_field_24125 = v_t_24123.f[1];
                  V v_field_24126 = v_t_24123.f[2];
                  int64_t v_tag_24124 = ((int64_t)v_t_24123.f[0]);
                  if ((v_tag_24124 == ((int64_t)0ULL))) {
                    V v_a_24127 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){v_field_24125, v_field_24126});
                    v_t_24149 = v_a_24127;
                  } else {
                    if ((v_tag_24124 == ((int64_t)1ULL))) {
                      heff_drop(v_field_24126);
                      V v_a_24128 = v_field_24125;
                      V v_t_24131;
                      switch (heff_tag_of(v_a_24128)) {
                      case TAG_At: {
                        V v_a_24130 = heff_dup(heff_field(v_a_24128, 1));
                        v_t_24131 = v_a_24130;
                        break;
                      }
                      default: heff_nomatch(v_a_24128);
                      }
                      v_t_24149 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_24128}), v_t_24131});
                    } else {
                      V v_a_24132 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){v_field_24125, v_field_24126});
                      V v_t_24135;
                      switch (heff_tag_of(v_a_24132)) {
                      case TAG_At: {
                        V v_a_24134 = heff_dup(heff_field(v_a_24132, 1));
                        v_t_24135 = v_a_24134;
                        break;
                      }
                      default: heff_nomatch(v_a_24132);
                      }
                      v_t_24149 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_24132}), v_t_24135});
                    }
                  }
                }
              } else {
                heff_drop(v_field_24121);
                HeffT3 v_t_24136 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){v_e_24117, v_sp_24118})));
                {
                  V v_field_24138 = v_t_24136.f[1];
                  V v_field_24139 = v_t_24136.f[2];
                  int64_t v_tag_24137 = ((int64_t)v_t_24136.f[0]);
                  if ((v_tag_24137 == ((int64_t)0ULL))) {
                    V v_c_24140 = heff_tag_n(TAG_At, 2, (V[]){v_field_24138, v_field_24139});
                    v_t_24149 = v_c_24140;
                  } else {
                    if ((v_tag_24137 == ((int64_t)1ULL))) {
                      heff_drop(v_field_24139);
                      V v_i_24141 = v_field_24138;
                      V v_t_24144;
                      switch (heff_tag_of(v_i_24141)) {
                      case TAG_At: {
                        V v_s_24143 = heff_dup(heff_field(v_i_24141, 1));
                        v_t_24144 = v_s_24143;
                        break;
                      }
                      default: heff_nomatch(v_i_24141);
                      }
                      v_t_24149 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24141}), v_t_24144});
                    } else {
                      V v_t_24145 = heff_tag_n(TAG_At, 2, (V[]){v_field_24138, v_field_24139});
                      V v_t_24148;
                      switch (heff_tag_of(v_t_24145)) {
                      case TAG_At: {
                        V v_s_24147 = heff_dup(heff_field(v_t_24145, 1));
                        v_t_24148 = v_s_24147;
                        break;
                      }
                      default: heff_nomatch(v_t_24145);
                      }
                      v_t_24149 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24145}), v_t_24148});
                    }
                  }
                }
              }
            }
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          V v_t_24150 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24149, NTAG(TAG_Nil)});
          V v_args_24151 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24116, v_t_24150});
          V v_t_24152 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24151));
          V v_t_24153 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str3)}), heff_dup(v_sp_242)});
          V v_t_24154 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24153, v_t_24152}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24154}), v_sp_242});
        }
        default: return heff_nomatch(v_size_245);
        }
      }
      case TAG_SegmentFloat: {
        heff_drop(v_sp_242);
        heff_drop(v_v_243);
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        V v_t_24155 = (g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(heff_dup(v_seg_240)));
        V v_args_24156 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24155, NTAG(TAG_Nil)});
        V v_sp_24159;
        switch (heff_tag_of(v_seg_240)) {
        case TAG_At: {
          V v_s_24158 = heff_field(v_seg_240, 1);
          heff_take_n(v_seg_240, 2ULL, 2);
          v_sp_24159 = v_s_24158;
          break;
        }
        default: heff_nomatch(v_seg_240);
        }
        V v_t_24160 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24159), v_args_24156));
        V v_t_24161 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str4)}), heff_dup(v_sp_24159)});
        V v_t_24162 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24161, v_t_24160}), heff_dup(v_sp_24159)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24162}), v_sp_24159});
      }
      case TAG_SegmentUtf: {
        V v_ru_24seg12_244_24SegmentUtf = heff_take_reuse_n(v_seg12_244, 0ULL, 1);
        heff_drop(v_sp_242);
        heff_drop(v_v_243);
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        V v_t_24164 = (g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(heff_dup(v_seg_240)));
        V v_args_24165 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24164, NTAG(TAG_Nil)});
        V v_sp_24168;
        switch (heff_tag_of(v_seg_240)) {
        case TAG_At: {
          V v_s_24167 = heff_field(v_seg_240, 1);
          heff_take_n(v_seg_240, 2ULL, 2);
          v_sp_24168 = v_s_24167;
          break;
        }
        default: heff_nomatch(v_seg_240);
        }
        V v_t_24169 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24168), v_args_24165));
        V v_t_24170 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24seg12_244_24SegmentUtf, TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_str5)}), heff_dup(v_sp_24168)});
        V v_t_24171 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24170, v_t_24169}), heff_dup(v_sp_24168)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24171}), v_sp_24168});
      }
      default: return heff_nomatch(v_seg12_244);
      }
    }
    default: return heff_nomatch(v_seg1_241);
    }
  }
  default: return heff_nomatch(v_seg_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2(V v_tok_240, V v_sp_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_n_242)) {
  case TAG_TPi: {
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    V v_t_246 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_245, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_sp_241});
  }
  case TAG_TSig: {
    V v_fs_247 = heff_field(v_n_242, 0);
    V v_ru_24n_242_24TSig = heff_take_reuse_n(v_n_242, 1ULL, 1);
    V v_t_248 = (g_list_2emap_24s1992667171x110340492(v_fs_247));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_242_24TSig, TAG_TSig, 1, (V[]){v_t_248}), v_sp_241});
  }
  case TAG_TSum: {
    V v_vs_249 = heff_field(v_n_242, 0);
    V v_ru_24n_242_24TSum = heff_take_reuse_n(v_n_242, 1ULL, 1);
    V v_t_2410 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(heff_tag_at_n(v_ru_24n_242_24TSum, TAG_TSum, 1, (V[]){v_vs_249})));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2410, v_sp_241});
  }
  case TAG_TType: {
    V v_t_2411 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    V v_t_2412 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_sp_241});
  }
  case TAG_TInt: {
    V v_t_2413 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    V v_t_2414 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_sp_241});
  }
  case TAG_TFloat: {
    V v_t_2415 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    V v_t_2416 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2415, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2416, v_sp_241});
  }
  case TAG_TString: {
    V v_t_2417 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    V v_t_2418 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2417, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_sp_241});
  }
  case TAG_TRune: {
    V v_t_2419 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    V v_t_2420 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2419, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_sp_241});
  }
  case TAG_TArray: {
    V v_t_2422 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    V v_t_2423 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2422, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_sp_241});
  }
  case TAG_TFixed: {
    V v_t_2425 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    V v_t_2426 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2425, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2426, v_sp_241});
  }
  case TAG_TInf: {
    V v_i_2427 = heff_field(v_n_242, 0);
    V v_ru_24n_242_24TInf = heff_take_reuse_n(v_n_242, 1ULL, 1);
    V v_t_2430;
    switch (heff_tag_of(v_i_2427)) {
    case TAG_At: {
      V v_n_2428 = heff_field(v_i_2427, 0);
      V v_sp_2429 = heff_field(v_i_2427, 1);
      V v_ru_24i_2427_24At = heff_take_reuse_n(v_i_2427, 3ULL, 2);
      v_t_2430 = (g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(v_ru_24i_2427_24At, v_sp_2429, v_n_2428));
      break;
    }
    default: heff_nomatch(v_i_2427);
    }
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_242_24TInf, TAG_TInf, 1, (V[]){v_t_2430}), v_sp_241});
  }
  case TAG_TChk: {
    V v_c_2431 = heff_field(v_n_242, 0);
    V v_ru_24n_242_24TChk = heff_take_reuse_n(v_n_242, 1ULL, 1);
    V v_t_2434;
    switch (heff_tag_of(v_c_2431)) {
    case TAG_At: {
      V v_n_2432 = heff_field(v_c_2431, 0);
      V v_sp_2433 = heff_field(v_c_2431, 1);
      heff_take_n(v_c_2431, 3ULL, 2);
      v_t_2434 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2433, v_n_2432));
      break;
    }
    default: heff_nomatch(v_c_2431);
    }
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_242_24TChk, TAG_TChk, 1, (V[]){v_t_2434}), v_sp_241});
  }
  case TAG_TNominal: {
    V v_t_2436 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    V v_t_2437 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2436, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2437, v_sp_241});
  }
  default: return heff_nomatch(v_n_242);
  }
}
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_24tok2(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_str0, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_str1, 49, "cannot use descriptive syntax in nominal position");
Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V v_tok_240, V v_sp_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_n_242)) {
  case TAG_TPi: {
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_245, v_sp_241});
  }
  case TAG_TSig: {
    V v_ru_24n_242_24TSig = heff_take_reuse_n(v_n_242, 0ULL, 1);
    V v_t_247 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_str0), NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag_at_n(v_ru_24n_242_24TSig, TAG_TInf, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_247, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_sp_241});
  }
  case TAG_TSum: {
    V v_ru_24n_242_24TSum = heff_take_reuse_n(v_n_242, 0ULL, 1);
    V v_t_2410 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_str1), NTAG(TAG_Nothing)});
    V v_t_2411 = heff_tag_at_n(v_ru_24n_242_24TSum, TAG_TInf, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2410, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_sp_241});
  }
  case TAG_TType: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2412, v_sp_241});
  }
  case TAG_TInt: {
    V v_t_2413 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2413, v_sp_241});
  }
  case TAG_TFloat: {
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2414, v_sp_241});
  }
  case TAG_TString: {
    V v_t_2415 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2415, v_sp_241});
  }
  case TAG_TRune: {
    V v_t_2416 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2416, v_sp_241});
  }
  case TAG_TArray: {
    V v_t_2418 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2418, v_sp_241});
  }
  case TAG_TFixed: {
    V v_t_2420 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2420, v_sp_241});
  }
  case TAG_TInf: {
    V v_t_2422 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2422, v_sp_241});
  }
  case TAG_TChk: {
    V v_t_2424 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2424, v_sp_241});
  }
  case TAG_TNominal: {
    V v_t_2426 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_242));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2426, v_sp_241});
  }
  default: return heff_nomatch(v_n_242);
  }
}
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2ewordOf_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewordOf_24tok2_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ewordOf_24tok2(V v_tok_240, V v_x1_241, V v_sp_242) {
top: ;
  HeffT3 v_t_243 = (g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(v_x1_241, v_sp_242));
  {
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_field_245, v_field_246})});
    } else {
      if ((v_tag_244 == ((int64_t)1ULL))) {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_field_246);
        return heff_tag_n(TAG_IsInferable, 1, (V[]){v_field_245});
      } else {
        return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_field_245, v_field_246})});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2ewordOf_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewordOf_24tok2(a[0], a[1], a[2]);
}